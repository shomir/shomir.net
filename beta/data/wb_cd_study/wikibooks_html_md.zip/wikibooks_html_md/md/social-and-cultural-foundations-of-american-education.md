# Social and Cultural Foundations of American Education/Print version

From Wikibooks, open books for an open world

< [Social and Cultural Foundations of American Education](/wiki/Social_and_Cultural_Foundations_of_American_Education)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

## Contents

  * 1 Development Process
  * 2 Foreword
  * 3 Philosophy and Ethics
  * 4 Essentialism
  * 5 Progressivism
  * 6 Perennialism
  * 7 Existentialism
  * 8 Conclusion
  * 9 Multiple Choice Questions
  * 10 Essay Question
  * 11 References
  * 12 Dynamic Learning Environment
  * 13 The History of American Education
  * 14 Educational Change and the Future of Education
  * 15 Some of the Barriers to Effective Education
  * 16 Classroom Issues
  * 17 The Forgotten Half: Those Who Do Not Succeed in American Schools
  * 18 Staffing Practices
  * 19 Administering the Schools
  * 20 Curriculum Development
  * 21 Technology in Education
  * 22 School//Community//Parental Relationships
  * 23 Multiculturalism
  * 24 Knowing What We Know, Knowing What They Know
  * 25 Assessment|Assessment Practices in Education
  * 26 Acknowledging Differences and Complexity
  * 27 Accountability
  * 28 Choice
  * 29 Student Assessment and Feedback
  * 30 Special Needs
  * 31 Hot Topics in Education

## Development Process[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=1)]

**The WikiText Development Process in ECI301 at Old Dominion University** Darden College of Education, Fall 2006/Spring 2007/Summer 2007/Fall 2007

This WikiText, The Social and Cultural Foundations of Education, is the combined effort of a dedicated group of professional collaborators, faculty, graduate, and undergraduate students. The course was planned over the summer of 2006 by Dr. Patrick O’Shea, Adjunct Faculty Member, who had the original idea for a WikiText, Dwight W. Allen, Eminent Scholar of Educational Reform, Peter Baker, Coordinating Graduate Assistant for ECI301 where the WikiText has been developed and used, and Douglas Allen, Associate Professor of Human Resources Development at the University of Denver.

In the fall they were joined by two other senior researchers, Kevin DePew, Assistant Professor of English, and Danny Curry-Corcoran, Director of Evaluation for the Newport News Public Schools.

The senior research team also offered an applied research course in the fall semester, paralleling the development of the WikiText. The major objective of this course was to plan a series of research initiatives to study the outcomes of this unprecedented, innovative approach to the introduction of students to the profession of teaching. Preparation of the WikiText and the evaluation of learning associated with that text comprised about one half of the total introductory course which also includes traditional lectures, both online and in a face to face format. The course materials and syllabus can be found at: <http://www.odu.edu/educ/dwallen/classallen.htm>.

Though the idea of WikiTexts is new, others have developed texts with the cooperation of students, often though not always graduate students. (See, for example, the developing [student-written text about educational psychology](http://ltc.umanitoba.ca/wikis), as well as the online Wikibooks version called _[Contemporary Educational Psychology_](/wiki/Contemporary_Educational_Psychology)). We decided to take a very different approach taking advantage of the large numbers of students enrolled (about 225) in this introductory class. First of all students were asked to produce a relatively brief (1,000 words) and very narrowly focused article on one of about 75 topics selected by the professional staff as representing a “typical” mix of topics for comparable courses. With about 225 students in the class, we created a “sign up page” in the WikiText which allowed as many as three students to sign up for each topic. In most cases we had two or three student-authored versions of each article.

It was not expected that they would “cover” the topic, but rather would select two to five major concepts they felt would be of value to them as teachers in training. Students were also required to write five multiple choice questions, applying the concepts their article to real life situations, and one essay question. In addition they were asked to find a “sidebar” something that would make the article more interesting – a quote, a video clip, an illustration or cartoon, a chart or graph.

The “book” was written during the first four weeks of class, and the balance of the semester was spent reading the text they had written. Each student was assigned to read and rate only one version of each article, about ten topics each week. Typically we received about 50 ratings of each article. The highest rated article by students was selected as the “official text.” The other articles, some of which were also highly rated are shown as supplementary materials.

## Foreword[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=2)]

This is a textbook created and edited as part of an education course, [ECI 301](http://www.odu.edu/educ/dwallen/eci301new/eci301c.htm), at [Old Dominion University](http://www.odu.edu) in Norfolk, VA. The book's primary contributors have been undergraduate, pre-service teachers.

Our goals for this project are manifold, but I would like to take a minute to highlight some of those that we consider most important. First, we want to prove that a student-authored textbook can be of a quality equal to that of a traditional textbook. After all, it seems counter-intuitive to imagine that students could learn from a textbook that is too sophisticated for them to have written themselves. Furthermore, this text should serve as proof that, due to the vast availability of information via the [Internet](/wiki/The_Internet), traditional textbooks written by intellectual elites are no longer necessary to the same degree they were before the Information Age. Next, the process of creating this text will serve to empower pre-service teachers with knowledge of technology and other skills such as effective communication and self-/peer-editing that will serve them well when they enter the classroom later, as teachers.

If you have stumbled onto this book by mistake, we encourage you to take a few minutes and read a chapter or two. After reading, feel free to click the blue rating buttons at the bottom of each page. This will help us identify the highest- and lowest-quality sections.

Each section of each chapter of this book was researched and developed by the students. Several versions of the articles were developed by different individuals, both within the same class and over several semesters. The students evaluated their peers' articles to determine which ones were the most useful and those versions are the ones seen linked from the contents page of each chapter.

  


## Philosophy and Ethics[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=3)]

What are the philosophies of education?

Would you consider yourself a philosopher? It is inevitable that you are, we all are. We philosophize every day. Any time a person expresses an opinion or evaluates a topic or subject, he or she is philosophizing. Feeling more intelligent yet? Good! If you are considering teaching as a profession, you are responsible for teaching the thought process. The way a student gathers information and applies the knowledge to benefit their life stems from teachers. As complex as that may sound, there is more. The way a teacher instills knowledge also begins from a philosophy of education. Every teacher abides by one or a few consolidated together. The philosophies are as follows: Essentialism, Progressivism, Perennialism, and Existentialism. Why is it important to abide by a teaching philosophy? Well, there are many reasons. But mainly, consistency is important in a classroom. Consistency establishes trust between the student and teacher solidifying expectations. Also, having a teaching philosophy will allow students to be aware of different biases. Teachers want students to form opinions for themselves, not form opinions for them. So in order to be a successful teacher, one must become familiar with the philosophies of education.

## Essentialism[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-1)]

“Essentialism asserts that certain basic ideas skills and bodies of knowledge are essential to human culture and civilization” (Gutek, 263). Essentialists believe it is more beneficial for students to learn from established fundamentals of education. In other words, they abide by the “back to basics” phrase. Teachers rely on traditional structure to gear their components of the curriculum. If the word Essentialism was dissected, we would find the word “essence”. The word essence “refers to what is necessary to and indispensable about something. Essence relates to the intrinsic or fundamental character or nature of something rather than its accidental or incidental features” (Gutek, 263). Dr. Allen states within his online lectures, “Essentialists say that the child is a learner to be shaped and developed. Essentialists say that the mind is the essential element of reality (that's called idealism). Whereas the mind learns from the physical world and the contact with the physical world is called realism. So, realism and idealism by some definition are both branches of Essentialism.” This particular teaching philosophy is known as Basic Education and tends to focus on the specifics. Essentialism is extremely orderly, academically systematic, and emphasizes discipline. A disadvantage of Essentialism is that it is “undemocratic in its overemphasis on the place of adults and the need for conservation of the culture” (Howick, 53). Since it mainly follows routines and has no emphasis on the student’s interest, it may also cause a cultural delay between the student and society.

## Progressivism[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-2)]

“
Education is not preparation for life; education is life itself.
”

—John Dewey

Think of the word “progress” and what it means. Progress “proclaims the possibility of improving something. Progression means to move forward by a series of related steps, a series of end-in-view rather than utopian leaps into the future” (Gutek, 294). Progressivism’s main source of philosophy is John Dewey’s Pragmatic Experimentalism. “The central concept of John Dewey's view of education was that greater emphasis should be placed on the broadening of intellect and development of problem solving and critical thinking skills, rather than simply on the memorization of lessons”. Progressivism proposes human beings learn from past experiences that are physical and/or mental. We are a part of nature and nature is ever changing; therefore, we must be accustom to the principles of change that parallel the nature of human experience. Reflection can help provide action for the future. Progressivists relate this way of instruction with society, politics, the economy, and education considering ways of improvement along the way. Improvement may resonate reform, in a nonviolent way. Reforms envisioned by Progressivists begin with where we are right now and arise from existing conditions. Dr. Allen affirms in his lecture, “Progressivists say we learn from problem solving and that we put ourselves in a context of problem solving, which is what makes the world go around. We learn how to learn.” Instead of education instigated by the teacher, education is initiated by the student. In the classroom, the teacher acts as a guide. “He/she is never obtrusive, always very democratic, and ever respecting the natural rights of all. He/she employs the psychological approach to the organization of subject matter, remembering that the task of providing motivation is more important than the dispensing of information” (Howick, 39). The children’s self expression is strongly encouraged while recognizing the significance of their individual needs. Critics may argue that “experience” is the key to Progressivism and Pragmatism which does not establish an ultimate reality. “Truth can be made by anyone and proven simply by observing the consequences” (Howick, 41). According to pragmatism, all ideas are relative and nothing is ever permanent, which might also include pragmatism itself. What if those principles are called to question for validity, what might the answer be?

## Perennialism[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-3)]

“Perennialism can be defined as an educational theory that proclaims that people possess and share a common nature that defines them as human beings” (Gutek, 279). Unlike, Progressivism, nature is constant and unwavering. The great works written by founders of Western philosophy convey wisdom based on universal truths, and these truths are reoccurring throughout time. These philosophers would include Plato, Aristotle, Aquinas and they concerned themselves with metaphysical questions, what is real? Dr. Allen suggests, “The perennialist will say that it is intellect that distinguishes man from beast, that our ability to think is what gives us consciousness ("I think therefore I am," a position asserted by Renee Descartes), and that our intellect discovers truth which is constant and changeless. Human nature is out there constant and changeless. Mother Nature is out there constant and changeless. And our ability to think and our intellect are there to discover this constant and changeless truth.” As intellectual human beings, we should be able to absorb these truths and live by their values. We can learn rational human nature by possessing all the generations of past, present, and future. “Perennialists look to metaphysics, especially to human nature, so they see the purpose of education, the role of school, and the organization of the curriculum as coming from humanity’s enduring and universal characteristics” (Gutek, 281). The instructors rely on what has been “tried and true” throughout educations history, not on the student’s interests and experiences. Individuals relating to progressivism, the other end of the spectrum, would argue against Perennialism because of the constant instability of reality.

## Existentialism[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-4)]

Existentialism gained more awareness after World War II, during a time when people were searching inward and not willing to accept the classification of the institutions of mass society. “In terms of the philosophy of Existentialism, to exist means that a person is actually present in the world and living at a given time in a particular place” (Gutek, 86). Self definition is the result from choices an individual makes being conscious of the world he/she lives in. There are so many possibilities that cannot derive from just pre-existing metaphysical methods. “For Existentialists, the purpose of education is to cultivate in students awareness that they are free agents, responsible for creating their own selves and purposes” (Gutek, 92). Teachers expose the students to various paths to be chosen, but the student must find the answers from within, not strictly from outside sources. The main focus is freedom. A few other Existentialism concepts are as follows: “Human personality, subjective and individual, is the only proper foundation for education. The goals of education must be expressed in terms of awareness, acceptance, personal responsibility, eventual commitment, and affirmation” (Howick, 111). The Existentialist instructor as an initiator must teach the fundamentals but promote the acceptance of freedom to participate in individual activities. The student assumes the position as the selector. He/she makes a decision of what and how much they will learn. If successful, the student will be a free standing personality in society as oppose to a follower or imitator of teachers. “The weaknesses of Existentialism arise from its position of subjectivity, as well as its strengths. For any number of men to agree to one answer would be to create a postulate and reduce every man’s subjectivity” (Howick, 117).

## Conclusion[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-5)]

Commitment towards a teaching philosophy is not as easy as it seems. One reason, perhaps the most important reason, being it must be a valuable approach to engage the students. Choosing a philosophy framework to organize a classroom cannot have predispositions to the teacher’s personal opinions. Keep in mind the motive for education is to teach students **how** to think for themselves. A teacher’s responsibility is contributing various techniques the student can use to find a solution to a situation. There is no end result to education, only a foundation strong enough to support an individual in the real world.

## Multiple Choice Questions[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-6)]

Click to reveal the answer.

One of the subdivisions of Philosophy is “Metaphysics”, which questions: 

    A. What is truth?
    B. What is real?
    C. What is value?
    D. How to think clearly?

B. What is real?

Mrs. Johnson's teaching philosophy believes intellect is what separates humans from other beings in a stable world. Which philosophy does Mrs. Johnson teach: 

    A. Essentialism
    B. Progressivism
    C. Perennialism
    D. Existentialism

C. Perennialism

Jane’s history class does not involve much of student contribution besides what the teacher recites on traditional American virtues. What philosophy does Jane’s teacher follow? 

    A. Essentialism
    B. Progressivism
    C. Perennialism
    D. Existentialism

A. Essentialism

Mr. Jones believes in a teaching philosophy that provides various group interactions where the students have liberty to explore their individual interests. Which philosophy of education best describes this method? 

    A. Essentialism
    B. Progressivism
    C. Perennialism
    D. Existentialism

D. Existentialism

Which philosophy of education allows the student to learn by reflecting on past experiences in a world where nature is consistently evolving? 

    A. Essentialism
    B. Progressivism
    C. Perennialism
    D. Existentialism

B. Progressivism

## Essay Question[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-7)]

Click to reveal a sample response.

Compare and contrast the teacher’s approach to students between these teaching philosophies: Essentialism, Progressivism, and Perennialism.

Essentialists retrieve the “basics” of education and apply it to their lessons. The branches of Essentialism are realism and idealism. Students are the learners and should be shaped and molded to retain traditional American virtues. The child’s role is to listen and learn. The Essentialist instructor would establish order, routines, and memorization within the classroom. From a Progressivists stand point, education begins with the student and learning how to learn based on problem solving. Reflection aids the students to prepare action for future experience because nature is consistently changing. Progressivists reject formalism and routine. Instead, they embrace a more democratic classroom with open mindedness, responsibility, and whole heartedness. Perennialism advocates nature is constant and changeless. According to Perennialism, education begins with the mind and lessons are based on great philosophers from the past. Theories that remain “tried and true” are the primary sources to their methods. They value the great works of art and literature and emphasize these timeless truths as the groundwork for a cultural society.

When it comes to teaching, there are many differing philosophies that answer the question “what is the right way to teach?” There may be no wrong or right answer to this question. Three of the most common educational philosophies that teachers tend to identify with are essentialism, progressivism, and perennialism.

Essentialism is the philosophy that refers to the use of the “essentials” or the basics in order to teach a student. A teacher who uses this philosophy might view their students’ minds as balls of clay that need to be shaped. The essentialist teacher would focus more on the core subjects such as math, English, science, etc. and places a high emphasis on discipline.

Progressivism is similar in that it places an emphasis on some of the core subjects but with one notable difference. The learning is student-centered and focuses more on problem-solving skills. The progressive teacher believes that nature is changing and since that we are apart of nature, education should change too.

In stark contrast to this would be perrenialism. Perrenialists think that nature is a constant and so is human nature. They focus more on the great ideas of the past and the classics. Similar to progressivists, they believe that one can learn from history. While a progressivst places emphasis on learning from past experiences, the perrenialist focuses more on history’s great thinkers, or the classics.

While each philosophy has notable differences compared to the others, there are similarities as well. Perhaps the most important similarity is the end result of the student receiving the education having a strong foundation and understanding of how to function in the world. — Mallory Creedon

## References[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Philosophy_and_Ethics/Educational_Philosophies&action=edit&section=T-8)]

  * Allen, Dwight. (1997-2007). "Philosophy." Retrieved from [https://www.blackboard.odu.edu/webapps/portal/frameset.jsp?tab=courses&url=/bin/common/course.pl?course_id=_123288_1](https://www.blackboard.odu.edu/webapps/portal/frameset.jsp?tab=courses&url=/bin/common/course.pl?course_id=_123288_1).
  * Gutek, Gerlad L. Philosophical and Ideological Voices in Education. Boston: Pearson Education, Inc., 2004.
  * Howick, William H. Philosophies of Western Education. Danville: The Interstate Printers & Publishers, Inc., 1971.
  * Kidd, Jennifer. "Philosophical Foundations." Class Lecture. ECI 301. Old Dominion University, Norfolk, 3 September 2007.
  * Phenix, Philip H. Philosophies of Education. New York: John Wiley & Sons, 1961.
  * "John Dewey." (September 2, 2007). Wikipedia. Retrieved from <http://en.wikipedia.org/wiki/John_Dewey>[Philosophy and Ethics/Purpose](/w/index.php?title=Philosophy_and_Ethics/Purpose&action=edit&redlink=1)

[Philosophy and Ethics/Wiki Philosophy](/w/index.php?title=Philosophy_and_Ethics/Wiki_Philosophy&action=edit&redlink=1) [Philosophy and Ethics/Ethical Teaching](/w/index.php?title=Philosophy_and_Ethics/Ethical_Teaching&action=edit&redlink=1) [Philosophy and Ethics/Equality](/w/index.php?title=Philosophy_and_Ethics/Equality&action=edit&redlink=1) [Philosophy and Ethics/Teaching Ethics](/w/index.php?title=Philosophy_and_Ethics/Teaching_Ethics&action=edit&redlink=1)

## Dynamic Learning Environment[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=4)]

Dynamic Learning Environment

    [Why is engagement important?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Engagement)
    [How can we motivate students?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Motivation)
    [What roles do fun and joy play in the learning environment?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Fun_and_Joy)
    [What is the role of edutainment?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Edutainment)
    [What are various strategies that can be employed for meaningful learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Multiple_Strategies)
    [How can we teach students to evaluate resources for learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Resource_Evaluation)
    [How can teachers continue to educate themselves?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Continuing_Education)
    [How can we promote learning from peers?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Dynamic_Learning_Environment/Peer_Learning)

  


## The History of American Education[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=5)]

The History of American Education

    [What are the markers of the 17th Century?](/wiki/Social_and_Cultural_Foundations_of_American_Education/History/17th_Century)
    [What are the markers of the 18th Century?](/wiki/Social_and_Cultural_Foundations_of_American_Education/History/18th_Century)
    [What are the markers of the 19th Century?](/wiki/Social_and_Cultural_Foundations_of_American_Education/History/19th_Century)
    [What are the markers of the 20th Century?](/wiki/Social_and_Cultural_Foundations_of_American_Education/History/20th_Century)
    [What are the markers of the 21st Century?](/wiki/Social_and_Cultural_Foundations_of_American_Education/History/21st_Century)

  


## Educational Change and the Future of Education[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=6)]

Educational Change and the Future of Education

    [What is the Allen/Cosby theory of change?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Theory)
    [How has the NCLB act formed visions of change?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/NCLB)
    [What are the goals for educational change?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Goals)
    [What are the desired outcomes of educational change?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Outcomes)
    [What is the role of standards?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Standards)
    [How can we train Americans to compete in a constantly changing world work force?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/World_Work_Force)
    [Why are all subjects are essential to be taught?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Essentials)
    [Why do we need health and physical education in our schools?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Health_and_Physical_Education)
    [How should foreign languages be taught?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Foreign_Languages)
    [How can we improve early childhood education (3- and 4-year-olds) for all?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Early_Childhood_Education)
    [How can we find other ways to finance American schools?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Financing)
    [How can we educate students for creativity, innovation, and entrepreneurship?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Educational_Change/Soft_Skills)

  


## Some of the Barriers to Effective Education[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=7)]

Some of the Barriers to Effective Education

    [How is obsolescence a barrier?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Barriers/Obsolescence)
    [How is mobility a barrier?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Barriers/Mobility)
    [How is equity a barrier?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Barriers/Equity)
    [How is accountability a barrier?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Barriers/Accountability)
    [How can class size act as a barrier?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Barriers/Class_Size)

  


## Classroom Issues[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=8)]

Classroom Issues

    [How do we discipline?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Classroom_Issues/Discipline)
    [What are reward systems, and do they work?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Classroom_Issues/Rewards)
    [Are teachers isolated?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Classroom_Issues/Isolation)
    [How do student dynamics impact learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Classroom_Issues/Student_Dynamics)
    [What is the role of motivation?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Classroom_Issues/Motivation)
    [Can discipline be done positively?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Classroom_Issues/Positive_Discipline)
    [How can resistance to working with others be overcome?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Classroom_Issues/Group_Work)

  


## The Forgotten Half: Those Who Do Not Succeed in American Schools[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=9)]

The Forgotten Half: Those Who Do Not Succeed in American Education

    [Who is the curriculum designed for, and why?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Forgotten_Half/Curriculum)
    [What are the alternatives?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Forgotten_Half/Alternatives)
    [What is the Hope Factor?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Forgotten_Half/Hope_Factor)
    [How do we combat learned helplessness?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Forgotten_Half/Learned_Helplessness)
    [How do differences in perception and reality affect learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Forgotten_Half/Perceptions)

  


## Staffing Practices[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=10)]

Staffing Practices

    [Are teachers interchangeable?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Staffing_Practices/Interchangeability)
    [What are the positives and negatives of class size?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Staffing_Practices/Class_Size)
    [Credentialism—how has this impacted education?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Staffing_Practices/Credentialism)
    [What are the roles of paraprofessionals?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Staffing_Practices/Paraprofessionals)
    [How can we recruit, select, and train new teachers?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Staffing_Practices/New_Teachers)
    [Should teachers be allowed to unionize?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Staffing_Practices/Unions)

  


## Administering the Schools[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=11)]

Administering the School

    [What is the role of the principal?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Administration/Principal)
    [How should personnel be evaluated?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Administration/Personnel_Evaluation)
    [What does it mean for leadership to be ethical?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Administration/Ethical_Leadership)
    [What are the legal issues?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Administration/Legal_Issues)
    [How are schools financed?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Administration/Financing)

  


## Curriculum Development[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=12)]

Curriculum Development

    [What is the standards movement?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Standards_Movement)
    [Can schools integrate vocational and academic learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Vocational-Academic_Learning)
    [Why is special education an issue for all teachers?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Special_Education)
    [How do we plan lessons, and why is it important?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Lesson_Planning)
    [How has technology impacted instructional design?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Technological_Impact)
    [What constitutes an effective instructional method?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Instructional_Methods)
    [Is a national curriculum needed?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/National_Curriculum)
    [What factors influence curriculum design?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Curriculum_Design)
    [What is the importance of early intervention in reading performance?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Curriculum_Development/Reading_Intervention)

  


## Technology in Education[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=13)]

Technology in Education

    [What role does technology play?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Role)
    [How might technology revolutionize education in the future?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Revolution)
    [What are the pros and cons of technology in the classroom?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Pros_and_Cons)
    [How should the Internet be integrated into the classroom?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Internet)
    [Can teachers be replaced by computers?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Teacher_Replacement)
    [Should students have the ability to use computers in the classroom?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Computers)
    [Should students write their own textbooks?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Textbooks)
    [What technology should a teacher use in the classroom?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Classroom_Technology)
    [How can PowerPoint presentations be used effectively?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/PowerPoint)
    [What is the role of social media in instruction?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Technology/Social_Media)

  


## School//Community//Parental Relationships[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=14)]

School/Community/Parental Relationships

    [Where is the school/community disconnect?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Relationships/Disconnect)
    [What are the mutual responsibilities of teachers, parents, and the community for effective schools?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Relationships/Mutual_Responsibilities)
    [Is there unity in diversity?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Relationships/Unity-Diversity)
    [How can families and schools better communicate?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Relationships/Communication)

  


## Multiculturalism[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=15)]

Multiculturalism

    [What is the global context for education?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Multiculturalism/Global_Context)
    [How has our multicultural world changed the responsibilities of teachers?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Multiculturalism/Responsibilities)
    [How have gender issues changed our views?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Multiculturalism/Gender_Issues)
    [How should we think about minorities?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Multiculturalism/Minorities)
    [Is being different bad?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Multiculturalism/Differences)

  


## Knowing What We Know, Knowing What They Know[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=16)]

Knowing What We Know, Knowing What They Know

    [What do we know about brain research?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Knowing/Brain_Research)
    [How do people learn?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Knowing/Learning)
    [What role does action research play?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Knowing/Action_Research)
    [Why is feedback important?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Knowing/Feedback)
    [How can we be encouraging?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Knowing/Encouragement)
    [Why is applied and abstract reasoning so important to the learning process?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Knowing/Reasoning)

  


## Assessment|Assessment Practices in Education[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=17)]

Assessment Practices in Education

    [What roles do assessment of performance and performance appraisal play in schools and administrations?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Assessment/Roles)
    [How can we develop new testing systems emphasizing such areas as creativity and knowing how to work with ideas and abstractions, and functioning on teams?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Assessment/Testing)
    [How can we create and monitor high performance schools?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Assessment/Performance)
    [What is the role of Advanced Placement and the International Baccalaureate in creating national standards?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Assessment/Standards)

  


## Acknowledging Differences and Complexity[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=18)]

Acknowledging Differences and Complexity

    [How can we encourage students and teachers to consider multiple perspectives?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Acknowledgment/Multiple_Perspectives)
    [What are the different concepts of intelligence?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Acknowledgment/Intelligence)
    [What is lifelong learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Acknowledgment/Lifelong_Learning)
    [What is service-learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Acknowledgment/Service_Learning)

  


## Accountability[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=19)]

How Should Schools Be Held Accountable?

    [How should teachers be held accountable?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/Teachers)
    [How should parents be held accountable?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/Parents)
    [How should students be held accountable?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/Students)
    [How can we meet NCLB quality standards?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/NCLB_Standards)
    [How should society respond to under-performing schools?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/Under-performing_Schools)
    [How should society reward outstanding schools and teachers?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/Outstanding_Schools)
    [How can teachers be flexible in an era of accountability?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/Flexibility)
    [What makes NCLB an enemy of quality education?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/NCLB_Enemy)
    [What makes NCLB the savior of quality education?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Accountability/NCLB_Savior)

  


## Choice[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=20)]

Choice

    [What is the case for home schooling?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Choice/For_Home_Schooling)
    [What is the case against home schooling?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Choice/Against_Home_Schooling)
    [What is the case against vouchers?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Choice/Against_Vouchers)
    [What role do charter schools play in education?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Choice/Charter_Schools)

  


## Student Assessment and Feedback[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=21)]

Student Assessment and Feedback

    [How can we construct effective measurements, including exams?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Feedback/Effective_Measurements)
    [What are the principles of effective assessment?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Feedback/Effective_Assessments)
    [What are feedback skills?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Feedback/Feedback_Skills)
    [How should group work be assessed?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Feedback/Group_Work)
    [What role should peer evaluation play in grading and course work?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Feedback/Peer_Evaluation)
    [When should qualitative or quantitative assessments be used?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Feedback/Qualitative-Quantitative)

  


## Special Needs[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=22)]

Special Needs

    [How can we best teach children with disabilities?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Special_Needs/Disabilities)
    [How can we best teach children with autism?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Special_Needs/Autism)
    [How can we learn to understand children with ADD?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Special_Needs/ADD)
    [How can we best accommodate children with hearing impairments?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Special_Needs/Deaf)

  


## Hot Topics in Education[[edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&section=23)]

Hot Topics in Education

    [What is the ideal amount of homework to assign?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Hot_Topics/Homework)
    [What are the effects of the home environment on learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Hot_Topics/Home_Environment)
    [Should school be held year-round?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Hot_Topics/Year-Round_Schooling)
    [Should school districts implement school uniform policies?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Hot_Topics/School_Uniforms)
    [What can be done about the issue of bullying?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Hot_Topics/Bullying)
    [What effects do inequities in school funding have on teaching and learning?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Hot_Topics/Funding_Inequities)
    [What teaching styles can educators employ?](/wiki/Social_and_Cultural_Foundations_of_American_Education/Hot_Topics/Teaching_Styles)
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&oldid=2292774](http://en.wikibooks.org/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&oldid=2292774)" 

[Category](/wiki/Special:Categories): 

  * [Social and Cultural Foundations of American Education](/wiki/Category:Social_and_Cultural_Foundations_of_American_Education)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Social+and+Cultural+Foundations+of+American+Education%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Social+and+Cultural+Foundations+of+American+Education%2FPrint+version)

### Namespaces

  * [Book](/wiki/Social_and_Cultural_Foundations_of_American_Education/Print_version)
  * [Discussion](/w/index.php?title=Talk:Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Social_and_Cultural_Foundations_of_American_Education/Print_version)
  * [Edit](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=edit)
  * [View history](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Social_and_Cultural_Foundations_of_American_Education/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Social_and_Cultural_Foundations_of_American_Education/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&oldid=2292774)
  * [Page information](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Social_and_Cultural_Foundations_of_American_Education%2FPrint_version&id=2292774)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Social+and+Cultural+Foundations+of+American+Education%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Social+and+Cultural+Foundations+of+American+Education%2FPrint+version&oldid=2292774&writer=rl)
  * [Printable version](/w/index.php?title=Social_and_Cultural_Foundations_of_American_Education/Print_version&printable=yes)

  * This page was last modified on 26 March 2012, at 12:08.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Social_and_Cultural_Foundations_of_American_Education/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
