# Geometry/Print version

From Wikibooks, open books for an open world

< [Geometry](/wiki/Geometry)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Geometry](/wiki/Geometry)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Geometry/Print_version&action=purge&printable=yes) this page.

  


Geometry

The current, editable version of this book is available in Wikibooks, the open-content textbooks collection, at  
<http://en.wikibooks.org/wiki/Geometry>

Permission is granted to copy, distribute, and/or modify this document under the terms of the [Creative Commons Attribution-ShareAlike 3.0 License](/wiki/Wikibooks:Creative_Commons_Attribution-ShareAlike_3.0_Unported_License).

# General geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=1)]

# Part I- Euclidean Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=2)]

# Chapter 1: Points, Lines, Line Segments and Rays[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=3)]

Points and lines are two of the most fundamental concepts in Geometry, but they are also the most difficult to define. We can describe intuitively their characteristics, but there is no set definition for them: they, along with the plane, are the undefined terms of geometry. All other geometric definitions and concepts are built on the undefined ideas of the point, line and plane. Nevertheless, we shall try to define them.

## Point[[edit](/w/index.php?title=Geometry/Points,_Lines,_Line_Segments_and_Rays&action=edit&section=T-1)]

A point is an exact location in space. Points are dimensionless. That is, a point has no width, length, or height. We locate points relative to some arbitrary standard point, often called the "origin". Many physical objects suggest the idea of a point. Examples include the tip of a pencil, the corner of a cube, or a dot on a sheet of paper.

## Line[[edit](/w/index.php?title=Geometry/Points,_Lines,_Line_Segments_and_Rays&action=edit&section=T-2)]

As for a line segment, we specify a line with two points. Starting with the corresponding line segment, we find other line segments that share at least two points with the original line segment. In this way we extend the original line segment indefinitely. The set of all possible line segments findable in this way constitutes a line. A line extends indefinitely in a single dimension. Its length, having no limit, is infinite. Like the line segments that constitute it, it has no width or height. You may specify a line by specifying any two points within the line. For any two points, only one line passes through both points. On the other hand, an unlimited number of lines pass through any single point.

## Ray[[edit](/w/index.php?title=Geometry/Points,_Lines,_Line_Segments_and_Rays&action=edit&section=T-3)]

We construct a ray similarly to the way we constructed a line, but we extend the line segment beyond only one of the original two points. A ray extends indefinitely in one direction, but ends at a single point in the other direction. That point is called the end-point of the ray. Note that a line segment has two end-points, a ray one, and a line none.

## Plane[[edit](/w/index.php?title=Geometry/Points,_Lines,_Line_Segments_and_Rays&action=edit&section=T-4)]

A point exists in zero dimensions. A line exists in one dimension, and we specify a line with two points. A plane exists in two dimensions. We specify a plane with three points. Any two of the points specify a line. All possible lines that pass through the third point and **any** point in the line make up a plane. In more obvious language, a plane is a flat surface that extends indefinitely in its two dimensions, length and width. A plane has no height.

## Space[[edit](/w/index.php?title=Geometry/Points,_Lines,_Line_Segments_and_Rays&action=edit&section=T-5)]

Space exists in three dimensions. Space is made up of all possible planes, lines, and points. It extends indefinitely in all directions.

## N-dimensional Space[[edit](/w/index.php?title=Geometry/Points,_Lines,_Line_Segments_and_Rays&action=edit&section=T-6)]

Mathematics can extend space beyond the three dimensions of length, width, and height. We then refer to "normal" space as 3-dimensional space. A 4-dimensional space consists of an infinite number of 3-dimensional spaces. Etc.

## Further reading[[edit](/w/index.php?title=Geometry/Points,_Lines,_Line_Segments_and_Rays&action=edit&section=T-7)]

  * [Point](//en.wikipedia.org/wiki/Point_\(geometry\))

# Chapter 2: Angles[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=4)]

An angle is the union of two rays with a common endpoint, called the _vertex_. The angles formed by vertical and horizontal lines are called right angles; lines, segments, or rays that intersect in right angles are said to be perpendicular.

Angles, for our purposes, can be measured in either degrees (from 0 to 360) or radians (from 0 to ![2\\pi](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png)). Angles length can be determined by measuring along the arc they map out on a circle. In radians we consider the length of the arc of the circle mapped out by the angle. Since the circumference of a circle is ![2\\pi](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png), a right angle is ![\\frac{\\pi}{2}](//upload.wikimedia.org/math/d/c/f/dcfd65e77306c010f27fc20371cf83b1.png) radians. In degrees, the circle is 360 degrees, and so a right angle would be 90 degrees.

## Naming Conventions[[edit](/w/index.php?title=Geometry/Angles&action=edit&section=T-1)]

Angles are named in several ways.

  * By naming the vertex of the angle (only if there is only one angle formed at that vertex; the name must be non-ambiguous) ![\\angle B](//upload.wikimedia.org/math/4/8/d/48d2e15ac57bfe8e0490312bd6a5d0ee.png)
  * By naming a point on each side of the angle with the vertex in between. ![\\angle ABC](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png)
  * By placing a small number on the interior of the angle near the vertex.

## Classification of Angles by Degree Measure[[edit](/w/index.php?title=Geometry/Angles&action=edit&section=T-2)]

**Acute Angle**

  * an angle is said to be acute if it measures between 0 and 90 degrees, exclusive.

![Acute Angle](//upload.wikimedia.org/wikipedia/commons/thumb/b/b3/%C3%81ngulo_agudo.svg/150px-%C3%81ngulo_agudo.svg.png)

**Right Angle**

  * an angle is said to be right if it measures 90 degrees.
  * notice the small box placed in the corner of a right angle, unless the box is present it is not assumed the angle is 90 degrees.
  * all right angles are congruent

![Right angle.svg](//upload.wikimedia.org/wikipedia/commons/thumb/6/6c/Right_angle.svg/100px-Right_angle.svg.png)

**Obtuse Angle**

  * an angle is said to be obtuse if it measures between 90 and 180 degrees, exclusive.

![Obtuse Angle](//upload.wikimedia.org/wikipedia/commons/thumb/a/ab/%C3%81ngulo_obtuso.svg/150px-%C3%81ngulo_obtuso.svg.png)

## Special Pairs of Angles[[edit](/w/index.php?title=Geometry/Angles&action=edit&section=T-3)]

  * adjacent angles 
    * adjacent angles are angles with a common vertex and a common side.
    * adjacent angles have no interior points in common.
  * complementary angles 
    * complementary angles are two angles whose sum is 90 degrees.
    * complementary angles may or may not be adjacent.
    * if two complementary angles are adjacent, then their exterior sides are perpendicular.
  * supplementary angles 
    * two angles are said to be supplementary if their sum is 180 degrees.
    * supplementary angles need not be adjacent.
    * if supplementary angles are adjacent, then the sides they do not share form a line.
  * linear pair 
    * if a pair of angles is both adjacent and supplementary, they are said to form a linear pair.
  * vertical angles 
    * angles with a common vertex whose sides form opposite rays are called vertical angles.
    * vertical angles are congruent.

  


# Chapter 3: Properties[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=5)]

## **Triangle Properties**[[edit](/w/index.php?title=Geometry/Properties&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/72/Congruent_triangles.svg/220px-Congruent_triangles.svg.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Triangle congruency.

**Side-Side-Side (SSS) (Postulate 12)** If three sides of one triangle are congruent to three sides of a second triangle, then the two triangles are congruent.

**Side-Angle-Side (SAS) (Postulate 13)**

If two sides and the included angle of a second triangle, then the two triangles are congruent.

'_Angle-Side-Angle'_ **(ASA)**

If two angles and the included side of one triangle are congruent to two angles and the included side of a second triangle, then two triangles are congruent.

'_Angle-Angle-Side'_ **(AAS)**

If two angles and a non-included side of one triangle are congruent to two angles and the corresponding non-included side of a second triangle, then the two triangles are congruent.

**NO - Angle-Side-Side (ASS)**

_The "ASS" postulate does not work_, unlike the other ones. A way that students can remember this is that "ass" is not a nice word, so we don't use it in geometry (since it does not work).

# Chapter 4. Inductive and Deductive Reasoning[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=6)]

There are two approaches to furthering knowledge: reasoning from known ideas and synthesizing observations. In inductive reasoning you observe the world, and attempt to explain based on your observations. You start with no prior assumptions. Deductive reasoning consists of logical assertions from known facts.

## What you need to know[[edit](/w/index.php?title=Geometry/Inductive_and_Deductive_Reasoning&action=edit&section=T-1)]

Before one can start to understand logic, and thereby begin to prove geometric theorems, one must first know a few vocabulary words and symbols.

**Conditional**: a conditional is something which states that one statement implies another. A conditional contains two parts: the condition and the conclusion, where the former implies the latter. A conditional is always in the form "If _statement 1_, then _statement 2_." In most mathematical notation, a conditional is often written in the form _p_ ⇒ _q_, which is read as "If _p_, then _q_" where _p_ and _q_ are statements.

**Converse**: the converse of a logical statement is when the conclusion becomes the condition and vice versa; i.e., _p_ ⇒ _q_ becomes _q_ ⇒ _p_. For example, the converse of the statement "If someone is a woman, then they are a human" would be "If someone is a human, then they are a woman." The converse of a conditional does not necessarily have the same truth value as the original, though it sometimes does, as will become apparent later.

**AND**: And is a logical operator which is true only when both statements are true. For example, the statement "Diamond is the hardest substance known to man AND a diamond is a metal" is false. While the former statement is true, the latter is not. However, the statement "Diamond is the hardest substance known to man AND diamonds are made of carbon" would be true, because both parts are true.

**OR**: If two statements are joined together by "or," then the truth of the "or" statement is dependant upon whether one or both of the statements from which it is composed is true. For example, the statement "Tuesday is the day after Monday OR Thursday is the day after Saturday" would have a truth value of "true," because even though the latter statement is false, the former is true.

**NOT**: If a statement is preceded by "NOT," then it is evaluating the opposite truth value of that statement. The symbol for "NOT" is For example, if the statement _p_ is "Elvis is dead," then ¬p would be "Elvis is not dead." The concept of "NOT" can cause some confusion when it relates to statements which contain the word "all." For example, if _r_ is "¬". "All men have hair," then _¬r_ would be "All men do not have hair" or "No men have hair." Do not confuse this with "Not all men have hair" or "Some men have hair." The "NOT" should apply to the verb in the statement: in this case, "have." _¬p_ can also be written as NOT _p_ or _~p_. NOT _p_ may also be referred to as the "negation of _p_."

**Inverse**: The inverse of a conditional says that the negation of the condition implies the negation of the conclusion. For example, the inverse of _p_ ⇒ _q_ is _¬p_ ⇒ _¬q_. Like a converse, an inverse does not necessarily have the same truth value as the original conditional.

**Biconditional**: A biconditional is conditional where the condition and the conclusion imply one another. A biconditional starts with the words "if and only if." For example, "If and only if _p_, then _q_" means both that _p_ implies _q_ and that _q_ implies _p_.

**Premise**: A premise is a statement whose truth value is known initially. For example, if one were to say "If today is Thursday, then the cafeteria will serve burritos," and one knew that what day it was, then the premise would be "Today is Thursday" or "Today is not Thursday."

**⇒**: The symbol which denotes a conditional. _p_ ⇒ _q_ is read as "if _p_, then _q_."

**Iff**: Iff is a shortened form of "if and only if." It is read as "if and only if."

**⇔**: The symbol which denotes a biconditonal. _p_ ⇔ _q_ is read as "If and only if _p_, then _q_."

**∴**: The symbol for "therefore." _p_ ∴ _q_ means that one knows that _p_ is true (_p_ is true is the premise), and has logically concluded that _q_ must also be true.

**∧**: The symbol for "and."

**∨**: The symbol for "or."

  


## Deductive Reasoning[[edit](/w/index.php?title=Geometry/Inductive_and_Deductive_Reasoning&action=edit&section=T-2)]

There are a few forms of deductive logic. One of the most common deductive logical arguments is **modus ponens**, which states that:

    _p_ ⇒ _q_
    _p_ ∴ _q_

    _(If_ p_, then_ q_)_
    _(_p_, therefore_ q_)_

An example of modus ponens:

    If I stub my toe, then I will be in pain.
    I stub my toe.
    Therefore, I am in pain.

Another form of deductive logic is **modus tollens**, which states the following.

    _p_ ⇒ _q_
    _¬q_ ∴ _¬p_

    _(If_ p_, then_ q_)_
    _(_not q_, therefore_ not p_)_

  
Modus tollens is just as valid a form of logic as modus ponens. The following is an example which uses modus tollens.

  


    If today is Thursday, then the cafeteria will be serving burritos.

    The cafeteria is not serving burritos, therefore today is not Thursday.

  
Another form of deductive logic is known as the **If-Then Transitive Property**. Simply put, it means that there can be chains of logic where one thing implies another thing. The If-Then Transitive Property states:

    _p_ ⇒ _q_

    (_q_ ⇒ _r_) ∴ (_p_ ⇒ _r_)

  


    _(If_ p_, then_ q_)_

    _(_(If _q_, then _r_), therefore (if _p_, then _r_))

For example, consider the following chain of if-then statements.

    If today is Thursday, then the cafeteria will be serving burritos.
    If the cafeteria will be serving burritos, then I will be happy.

    Therefore, if today is Thursday, then I will be happy.

## Inductive Reasoning[[edit](/w/index.php?title=Geometry/Inductive_and_Deductive_Reasoning&action=edit&section=T-3)]

Inductive reasoning is a logical argument which does not definitely prove a statement, but rather assumes it. Inductive reasoning is used often in life. Polling is an example of the use of inductive reasoning. If one were to poll one thousand people, and 300 of those people selected choice A, then one would infer that 30% of any population might also select choice A. This would be using inductive logic, because it does not definitively prove that 30% of any population would select choice A.

Because of this factor of uncertainty, inductive reasoning should be avoided when possible when attempting to prove geometric properties.

## Truth Tables[[edit](/w/index.php?title=Geometry/Inductive_and_Deductive_Reasoning&action=edit&section=T-4)]

Truth tables are a way that one can display all the possibilities that a logical system may have when given certain premises. The following is a truth table with two premises (_p_ and _q_), which shows the truth value of some basic logical statements. _(NOTE: **T** = **true**; **F** = **false**)_

  


_**p**_
_**q**_
_**¬p**_
_**¬q**_
_**p**_ ⇒ _**q**_
_**p**_ ⇔ _**q**_
_**p**_ ∧ _**q**_
_**p**_ ∨ _**q**_

T
T
F
F
T
T
T
T

T
F
F
T
F
F
F
T

F
T
T
F
T
F
F
T

F
F
T
T
T
T
F
F

  


## See also[[edit](/w/index.php?title=Geometry/Inductive_and_Deductive_Reasoning&action=edit&section=T-5)]

  * [Deductive reasoning](http://en.wikipedia.org/wiki/Deductive_reasoning)
  * [Inductive reasoning](http://en.wikipedia.org/wiki/Inductive_reasoning)

# Chapter 5: Proof[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=7)]

## Introduction[[edit](/w/index.php?title=Geometry/Proof&action=edit&section=T-1)]

Unlike science which has theories, mathematics has a definite notion of proof. Mathematics applies deductive reasoning to create a series of logical statements which show that one thing implies another.

Consider a triangle, which we define as a shape with three vertices joined by three lines. We know that we can arbitrarily pick some point on a page, and make that into a vertex. We repeat that process and pick a second point. Using a ruler, we can connect these two points. We now make a third point, and using the ruler connect it to each of the other points. We have constructed a triangle.

In mathematics we formalize this process into axioms, and carefully lay out the sequence of statements to show what follows. All definitions are clearly defined. In modern mathematics, we are always working within some system where various axioms hold.

## Two-Column Proof[[edit](/w/index.php?title=Geometry/Proof&action=edit&section=T-2)]

The most common form of explicit proof in highschool geometry is a two column proof consists of five parts: the given, the proposition, the statement column, the reason column, and the diagram (if one is given).

### Example of a Two-Column Proof[[edit](/w/index.php?title=Geometry/Proof&action=edit&section=T-3)]

Now, suppose a problem tells you to solve ![x + 1 = 2](//upload.wikimedia.org/math/c/b/8/cb84e006e7cb3b4f6e105ee9a1e2c6c6.png) for ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png), showing all steps made to get to the answer. A proof shows how this is done:

Given: ![x + 1 = 2](//upload.wikimedia.org/math/c/b/8/cb84e006e7cb3b4f6e105ee9a1e2c6c6.png)

Prove: x = 1

Statement
Reason

![x + 1 = 2](//upload.wikimedia.org/math/c/b/8/cb84e006e7cb3b4f6e105ee9a1e2c6c6.png)
Given

![x = 1](//upload.wikimedia.org/math/a/2/5/a255512f9d61a6777bd5a304235bd26d.png)
Property of subtraction

We use "Given" as the first reason, because it is "given" to us in the problem.

## Written Proof[[edit](/w/index.php?title=Geometry/Proof&action=edit&section=T-4)]

Written proofs (also known as informal proofs, paragraph proofs, or 'plans for proof') are written in paragraph form. Other than this formatting difference, they are similar to two-column proofs.

Sometimes it is helpful to start with a written proof, before formalizing the proof in two-column form. If you're having trouble putting your proof into two column form, try "talking it out" in a written proof first.

### Example of a Written Proof[[edit](/w/index.php?title=Geometry/Proof&action=edit&section=T-5)]

We are given that x + 1 = 2, so if we subtract one from each side of the equation (x + 1 - 1 = 2 - 1), then we can see that x = 1 by the definition of subtraction.

## Flowchart Proof[[edit](/w/index.php?title=Geometry/Proof&action=edit&section=T-6)]

A flowchart proof or more simply a flow proof is a graphical representation of a two-column proof. Each set of statement and reasons are recorded in a box and then arrows are drawn from one step to another. This method shows how different ideas come together to formulate the proof. haha!

  
Example: When You!

# Chapter 6. Five Postulates of Euclidean Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=8)]

**Postulates** in geometry are very similar to axioms, self-evident truths, and beliefs in logic, political philosophy and personal decision-making. The five postulates of **Euclidean Geometry** define the basic rules governing the creation and extension of geometric figures with **ruler and compass**. Together with the five axioms (or "common notions") and twenty-three definitions at the beginning of Euclid's _Elements_, they form the basis for the extensive proofs given in this masterful compilation of ancient Greek geometric knowledge. They are as follows:

  1. A straight line may be drawn from any given point to any other.
  2. A straight line may be extended to any finite length.
  3. A circle may be described with any given point as its center and any distance as its radius.
  4. All right angles are congruent.
  5. If a straight line intersects two other straight lines, and so makes the two interior angles on one side of it together less than two right angles, then the other straight lines will meet at a point if extended far enough on the side on which the angles are less than two right angles.

Postulate 5, the so-called **Parallel Postulate** was the source of much annoyance, probably even to Euclid, for being so relatively prolix. Mathematicians have a peculiar sense of aesthetics that values simplicity arising from simplicity, with the long complicated proofs, equations and calculations needed for rigorous certainty done behind the scenes, and to have such a long sentence amidst such other straightforward, intuitive statements seems awkward. As a result, many mathematicians over the centuries have tried to prove the results of the _Elements_ without using the Parallel Postulate, but to no avail. However, in the past two centuries, assorted **non-Euclidean geometries** have been derived based on using the first four Euclidean postulates together with various negations of the fifth.

# Chapter 7. Vertical Angles[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=9)]

**Vertical angles** are a pair of angles with a common _vertex_ whose sides form opposite rays. An extensively useful fact about vertical angles is that they are _congruent._ Aside from saying that any pair of vertical angles "obviously" have the same measure by inspection, we can prove this fact with some simple algebra and an observation about _supplementary angles._ Let two lines intersect at a point, and angles A1 and A2 be a pair of vertical angles thus formed. At the point of intersection, two other angles are also formed, and we'll call either one of them B1 without loss of generality. Since B1 and A1 are supplementary, we can say that the measure of B1 plus the measure of A1 is 180. Similarly, the measure of B1 plus the measure of A2 is 180. Thus the measure of A1 plus the measure of B1 equals the measure of A2 plus the measure of B1, by substitution. Then by subracting the measure of B1 from each side of this equality, we have that the measure of A1 equals the measure of A2.

# Chapter 8. Parallel and Perpendicular Lines and Planes[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=10)]

## Parallel Lines in a Plane[[edit](/w/index.php?title=Geometry/Parallel_and_Perpendicular_Lines_and_Planes&action=edit&section=T-1)]

Two coplanar lines are said to be parallel if they never intersect. For any given point on the first line, its distance to the second line is equal to the distance between any other point on the first line and the second line. The common notation for parallel lines is "||" (a double pipe); it is not unusual to see "//" as well. If line _m_ is parallel to line _n_, we write "m || n". Lines in a plane either coincide, intersect in a point, or are parallel. Controversies surrounding the Parallel Postulate lead to the development of non-Euclidean geometries.

## Parallel Lines and Special Pairs of Angles[[edit](/w/index.php?title=Geometry/Parallel_and_Perpendicular_Lines_and_Planes&action=edit&section=T-2)]

When two (or more) parallel lines are cut by a transversal, the following angle relationships hold:

  * corresponding angles are congruent
  * alternate exterior angles are congruent
  * same-side interior angles are supplementary

## Theorems Involving Parallel Lines[[edit](/w/index.php?title=Geometry/Parallel_and_Perpendicular_Lines_and_Planes&action=edit&section=T-3)]

  * If a line in a plane is perpendicular to one of two parallel lines, it is perpendicular to the other line as well.
  * If a line in a plane is parallel to one of two parallel lines, it is parallel to both parallel lines.
  * If three or more parallel lines are intersected by two or more transversals, then they divide the transversals proportionally.

# Chapter 9. Congruency and Similarity[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=11)]

## Congruency[[edit](/w/index.php?title=Geometry/Congruency_and_Similarity&action=edit&section=T-1)]

_Congruent_ shapes are the same size with corresponding lengths and angles equal. In other words, they are exactly the same size and shape. They will fit on top of each other perfectly. Therefore if you know the size and shape of one you know the size and shape of the others. For example:

![\(Three congruent triangles\)](//upload.wikimedia.org/wikibooks/en/e/e6/CongruentTriangles.png)

Each of the above shapes is congruent to each other. The only difference is in their orientation, or the way they are rotated. If you traced them onto paper and cut them out, you could see that they fit over each other exactly.

![\(Two similar but non-congruent triangles, redrawn to show them the same orientation\)](//upload.wikimedia.org/wikipedia/commons/7/77/Congruent2.png)

Having done this, right away we can see that, though the angles correspond in size and position, the sides do not. Therefore it is proved the triangles are **not** congruent.

## Similarity[[edit](/w/index.php?title=Geometry/Congruency_and_Similarity&action=edit&section=T-2)]

_Similar_ shapes are like congruent shapes in that they must be the same shape, but they don't have to be the same size. Their corresponding angles are congruent and their corresponding sides are in proportion.

![\(Two similar triangles, with side lengths written in\)](//upload.wikimedia.org/wikibooks/en/5/56/Similar1.png)

# Chapter 10. Congruent Triangles[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=12)]

## Methods of Determining Congruence[[edit](/w/index.php?title=Geometry/Congruent_Triangles&action=edit&section=T-1)]

Two triangles are congruent if:

  * each pair of corresponding sides is congruent
  * two pairs of corresponding angles are congruent and a pair of corresponding sides are congruent
  * two pairs of corresponding sides and the angles included between them are congruent

## Tips for Proofs[[edit](/w/index.php?title=Geometry/Congruent_Triangles&action=edit&section=T-2)]

Commonly used prerequisite knowledge in determining the congruence of two triangles includes:

  * by the reflexive property, a segment is congruent to itself
  * vertical angles are congruent
  * when parallel lines are cut by a transversal corresponding angles are congruent
  * when parallel lines are cut by a transversal alternate interior angles are congruent
  * midpoints and bisectors divide segments and angles into two congruent parts

# Chapter 11. Similar Triangles[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=13)]

![Similar Triangles.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Similar_Triangles.svg/300px-Similar_Triangles.svg.png)

For two triangles to be similar, all 3 corresponding angles must be congruent, and all three sides must be proportionally equal. Two triangles are similar if...

  * Two angles of each triangle are congruent.
  * The acute angle of a right triangle is congruent to the acute angle of another right triangle.
  * The two triangles are congruent. Note here that congruency implies similarity.

# Chapter 12. Quadrilaterals[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=14)]

A **quadrilateral** is a [polygon](/wiki/Geometry/Polygon) that has four sides.

## Special Types of Quadrilaterals[[edit](/w/index.php?title=Geometry/Quadrilaterals&action=edit&section=T-1)]

  * **Parallelogram**
    * A parallelogram is a quadrilateral having two pairs of parallel sides.
    * A square, a rhombus, and a rectangle are all examples of parallelograms.
  * **Rhombus**
    * A rhombus is a quadrilateral of which all four sides are the same length.
  * **Rectangle**
    * A rectangle is a parallelogram of which all four angles are 90 degrees.
  * **Square**
    * A square is a quadrilateral of which all four sides are of the same length, and all four angles are 90 degrees.
    * A square is a rectangle, a rhombus, and a parallelogram.
  * **Trapezoid**
    * A trapezoid is a quadrilateral which has two parallel sides (U.S.)
  * **Trapezium**
    * U.S. usage: A trapezium is a quadrilateral which has no parallel sides.
    * U.K usage: A trapezium is a quadrilateral with two parallel sides (same as US trapezoid definition).
  * **Kite**
    * A kite is an quadrilateral with two pairs of congruent adjacent sides.

One of the most important properties used in proofs is that the sum of the angles of the quadrilateral is always 360 degrees. This can easily be proven too:

If you draw a random quadrilateral, and one of its diagonals, you'll split it up into two triangles. Given that the sum of the angles of a triangle is 180 degrees, you can sum them up, and it'll give 360 degrees.

# Chapter 13. Parallelograms[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=15)]

## Parallelograms[[edit](/w/index.php?title=Geometry/Parallelograms&action=edit&section=T-1)]

A **parallelogram** is a geometric figure with two pairs of parallel sides. Parallelograms are a special type of quadrilateral. The opposite sides are equal in length and the opposite angles are also equal. The area is equal to the product of any side and the distance between that side and the line containing the opposite side. ![Parallelogram](//upload.wikimedia.org/wikipedia/commons/3/3e/Pllgm_Geometry.png)

## Properties of Parallelograms[[edit](/w/index.php?title=Geometry/Parallelograms&action=edit&section=T-2)]

The following properties are common to all parallelograms (parallelogram, rhombus, rectangle, square)

  * both pairs of opposite sides are parallel
  * both pairs of opposite sides are congruent
  * both pairs of opposite angles are congruent
  * the diagonals bisect each other

## Special Parallelograms[[edit](/w/index.php?title=Geometry/Parallelograms&action=edit&section=T-3)]

### Rhombus[[edit](/w/index.php?title=Geometry/Parallelograms&action=edit&section=T-4)]

  * A **rhombus** is a parallelogram with four congruent sides.
  * The diagonals of a rhombus are perpendicular.
  * Each diagonal of a rhombus bisects two angles the rhombus.
  * A rhombus may or may not be a square.

![Rhombus](//upload.wikimedia.org/wikipedia/commons/a/a8/Rhmbs_Geometry.png)

### Square[[edit](/w/index.php?title=Geometry/Parallelograms&action=edit&section=T-5)]

  * A **square** is a parallelogram with four right angles and four congruent sides.
  * A square is both a rectangle and a rhombus and inherits all of their properties.

![Square](//upload.wikimedia.org/wikipedia/commons/4/43/Sqr_Geometry.png)

# Chapter 14. Trapezoids[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=16)]

A **Trapezoid** (American English) or **Trapezium** (British English) is a quadrilateral that has two parallel sides and two non parallel sides.

Some properties of trapezoids:

  * The interior angles sum to 360° as in any quadrilateral.
  * The parallel sides are unequal.
  * Each of the parallel sides is called a _base (b)_ of the trapezoid. The two angles that join one base are called 'base angles'.
  * If the two non-parallel sides are equal, the trapezoid is called an _isosceles trapezoid_. 
    * In an isosceles trapezoid, each pair of base angles are equal.
    * If one pair of base angles of a trapezoid are equal, the trapezoid is isosceles.
  * A line segment connecting the midpoints of the non-parallel sides is called the _median (m)_ of the trapeziod. 
    * The median of a trapezoid is equal to one half the sum of the bases (called _b1_ and _b2_).
  * A line segment perpendicular to the bases is called an _altitude (h)_ of the trapezoid.

The _area (A)_ of a trapezoid is equal to the product of an altitude and the median.

    ![ A = mh](//upload.wikimedia.org/math/4/c/8/4c8223bd89407efdb64f8b7049783e94.png)

Recall though that the median is half of the sum of the bases.

    ![ m = \\frac {1}{2}\(b_1+b_2\) ](//upload.wikimedia.org/math/b/8/b/b8b732c8aad206796f58c3cd0f514114.png)

Substituting for m, we get:

    ![ A = \\frac {1}{2}\(b_1+b_2\) h ](//upload.wikimedia.org/math/d/d/a/ddaec1b943f7af9712b538f3c8c936c4.png)

# Chapter 15. Circles/Radii, Chords and Diameters[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=17)]

A circle is a set of all points in a plane that are equidistant from a single point; that single point is called the centre of the circle and the distance between any point on circle and the centre is called radius of the circle.

<http://en.wikipedia.org/upload/d/dd/Circle-2.png>

**Chord**

a chord is an internal segment of a circle that has both of its endpoints on the circumference of the circle.

  * the diameter of a circle is the largest chord possible

**Secant**

a secant of a circle is any line that intersects a circle in two places.

  * a secant contains any chord of the circle

**Tangent**

a tangent to a circle is a line that intersects a circle in exactly one point, called the point of tangency.

  * at the point of tangency the tangent line and the radius of the circle are perpendicular

# Chapter 16. Circles/Arcs[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=18)]

An arc is a segment of the perimeter of a given circle. The measure of an arc is measured as an angle, this could be in radians or degrees (more on radians later). The exact measure of the arc is determined by the measure of the angle formed when a line is drawn from the center of the circle to each end point. As an example the circle below has an arc cut out of it with a measure of 30 degrees.

![Arc1-30deg.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/13/Arc1-30deg.svg/146px-Arc1-30deg.svg.png)

Radians:

As I mentioned before an arc can be measured in degrees or radians. A radian is merely a different method for measuring an angle. If we take a unit circle (which has a radius of 1 unit), then if we take an arc with the length equal to 1 unit, and draw line from each endpoint to the center of the circle the angle formed is equal to 1 radian. this concept is displayed below, in this circle an arc has been cut off by an angle of 1 radian, and therefore the length of the arc is equal to ![2\\pi](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png) because the radius is 1.  


![Geometric Arc.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Geometric_Arc.svg/150px-Geometric_Arc.svg.png)

From this definition we can say that on the unit circle a single radian is equal to ![ 2 \\pi ](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png) radians because the perimeter of a unit circle is equal to ![2\\pi](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png). Another useful property of this definition that will be extremely useful to anyone who studies arcs is that the length of an arc is equal to its measure in radians multiplied by the radius of the circle.  


Converting to and from radians is a fairly simple process. 2 facts are required to do so, first a circle is equal to 360 degrees, and it is also equal to ![2\\pi](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png). using these 2 facts we can form the following formula:  


![2\\pi = 360, \\pi = 180, \\frac{\\pi}{180} = 1](//upload.wikimedia.org/math/0/5/6/0561eb1190197c3b009cbd51ede97801.png), thus 1 degree is equal to ![\\frac{\\pi}{180}](//upload.wikimedia.org/math/1/b/4/1b415b951195024ed49521adb005290a.png) radians.  
From here we can simply multiply ![\\frac{\\pi}{180}](//upload.wikimedia.org/math/1/b/4/1b415b951195024ed49521adb005290a.png) by the number of degrees to convert to radians. for example if we have 20 degrees and want to convert to radians then we proceed as follows:  
![\(\\frac{\\pi}{180}\)20 = \\frac{20\\pi}{180} = \\frac{\\pi}{9}](//upload.wikimedia.org/math/a/f/e/afeea2240cbb6a53a87d61ec995745c7.png) radians.

The same sort of argument can be used to show the formula for getting 1 radian.  


![360 = 2\\pi, 180 = \\pi, \\frac{180}{\\pi} = 1](//upload.wikimedia.org/math/7/a/1/7a18db043dfa095ad4bcc132ee668c0d.png), thus 1 radian is equal to ![\\frac{180}{\\pi}](//upload.wikimedia.org/math/2/9/a/29a5deb469de0790074609a454d058ea.png)  


# Chapter 17. Circles/Tangents and Secants[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=19)]

A **tangent** is a line in the same plane as a given circle that meets that circle in exactly one point. That point is called the **point of tangency**. A tangent cannot pass through a circle; if it does, it is classified as a **chord**. A **secant** is a line containing a chord.

![](//upload.wikimedia.org/wikibooks/en/thumb/d/d1/Tangent_Secant_of_circle.jpg/220px-Tangent_Secant_of_circle.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The point of tangency is labeled A, the tangent line is labeled B, and the secant line is labeled C.

A **common tangent** is a line tangent to two circles in the same plane. If the tangent does not intersect the line containing and connecting the centers of the circles, it is an **external tangent**. If it does, it is an **internal tangent**.

Two circles are tangent to one another if in a plane they intersect the same tangent in the same point.

![](//upload.wikimedia.org/wikibooks/en/thumb/3/3a/Common_Tangent.jpg/220px-Common_Tangent.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The external tangent is labeled A, and the internal tangent is labeled B.

# Chapter 18. Circles/Sectors[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=20)]

## Sector of a circle[[edit](/w/index.php?title=Geometry/Circles/Sectors&action=edit&section=T-1)]

A sector of a circle can be thought of as a pie piece. In the picture below, a sector of the circle is shaded yellow.

![Sector of Circle.jpg](//upload.wikimedia.org/wikibooks/en/1/10/Sector_of_Circle.jpg)

  
To find the area of a sector, find the area of the whole circle and then multiply by the angle of the sector over 360 degrees.

![A = \\pi r^2 \\cdot \\frac{\\theta}{360}](//upload.wikimedia.org/math/e/0/2/e021bd043533d00f05ee66e120357dd8.png)

  


  
A more intuitive approach can be used when the sector is half the circle. In this case the area of the sector would just be the area of the circle divided by 2.

![Half Circle.jpg](//upload.wikimedia.org/wikibooks/en/e/e9/Half_Circle.jpg)

# Appendix A. Postulates & Definitions[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=21)]

#### Acute Angle[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-1)]

    _See_ _**[Angle](/wiki/Geometry/Postulates_%26_Definitions#Angle)**_

#### Addition Property of Equality[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-2)]

For any real numbers _a_, _b_, and _c_, if _a_ = _b_, then _a_ \+ _c_ = _b_ \+ _c_.

#### Angle[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikibooks/en/a/a1/Angle_ABC.png)

Angle ABC is acute.

A figure is an angle if and only if it is composed of two rays which share a common endpoint. Each of these rays (or segments, as the case may be) is known as a **side** of the angle (For example, ![\\overline{AB} \\;](//upload.wikimedia.org/math/0/4/1/041fd12f12552c24ea04c2ed573c5313.png) in the illustration at right), and the common point is known as the angle's _vertex_ (point _B_ in the illustration). Angles are measured by the difference of their slopes. The units for angle measure are radians and degrees. Angles may be classified by their degree measure.

  * **Acute Angle**: an angle is an acute angle if and only if it has a measure of less than 90°
  * **Right Angle**: an angle is an right angle if and only if it has a measure of exactly 90°
  * **Obtuse Angle**: an angle is an obtuse angle if and only if it has a measure of greater than 90°

#### Angle Addition Postulate[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-4)]

If P is in the interior of an angle ![\\angle ABC](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png), then ![\\angle ABC = \\angle ABP + \\angle PBC](//upload.wikimedia.org/math/3/4/0/34039fd34bad4fde1f454b0a96de67cc.png)

## C[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-5)]

#### Center of a circle[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-6)]

Point _P_ is the center of circle _C_ if and only if all points in circle _C_ are equidistant from point _P_ and point _P_ is contained in the same plane as circle _C_.

#### Circle[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-7)]

A collection of points is said to be a circle with a center at point _P_ and a radius of some distance _r_ if and only if it is the collection of all points which are a distance of _r_ away from point _P_ and are contained by a plane which contain point _P_.

#### Concave[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-8)]

A polygon is said to be concave if and only if it contains at least one interior angle with a measure greater than 180° exclusively and less than 360° exclusively.

#### Corresponding angles[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-9)]

![](//upload.wikimedia.org/wikibooks/en/f/f3/CorrespondingAnglesIllustration.jpg)

There are four pairs of corresponding angles: ∠1 and ∠3, ∠2 and ∠4, ∠5 and ∠7, and ∠6 and ∠8.

Two angles formed by a transversal intersecting with two lines are corresponding angles if and only if one is on the inside of the two lines, the other is on the outside of the two lines, and both are on the same side of the transversal.

#### Corresponding Angles Postulate[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-10)]

If two lines cut by a transversal are parallel, then their corresponding angles are congruent.

#### Corresponding Parts of Congruent Triangles are Congruent Postulate[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-11)]

The Corresponding Parts of Congruent Triangles are Congruent Postulate (CPCTC) states:

    If ∆_ABC_ ≅ ∆_XYZ_, then all parts of ∆_ABC_ are congruent to their corresponding parts in ∆_XYZ_. For example:

    

  * ![\\overline {AB}\\;](//upload.wikimedia.org/math/0/4/1/041fd12f12552c24ea04c2ed573c5313.png) ≅ ![\\overline {XY} \\;](//upload.wikimedia.org/math/4/3/f/43fed4a102aea567d7505037b5fab61c.png)

    

  * ![\\overline {BC}\\;](//upload.wikimedia.org/math/b/0/3/b034731b965584925ee3451ee125cd53.png) ≅ ![\\overline {YZ} \\;](//upload.wikimedia.org/math/8/f/3/8f3eec41f402c5896c824c03481f0efa.png)

    

  * ![\\overline {AC}\\;](//upload.wikimedia.org/math/9/0/7/907ffd9fc3f06c76d08fea5d57004a9f.png) ≅ ![\\overline {XZ} \\;](//upload.wikimedia.org/math/7/e/8/7e88f098021a08a0a1b81371977a08df.png)

    

  * ∠ABC ≅ ∠XYZ

    

  * ∠BCA ≅ ∠YZX

    

  * ∠CAB ≅ ∠ZXY

CPCTC also applies to all other parts of the triangles, such as a triangle's altitude, median, circumcenter, et al.

## D[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-12)]

#### Diameter[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-13)]

A line segment is the diameter of a circle if and only if it is a chord of the circle which contains the circle's center.

    _See_ _**[Circle](/wiki/Geometry/Postulates_%26_Definitions#Circle)**_

and if they cross they are congruent

## L[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-14)]

#### Line[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-15)]

A collection of points is a line if and only if the collection of points is perfectly straight (aligned), is infinitely long, and is infinitely thin. Between any two points on a line, there exists an infinite number of points which are also contained by the line. Lines are usually written by two points in the line, such as line AB, or ![\\overleftrightarrow{AB}](//upload.wikimedia.org/math/f/c/d/fcdd8784f7c04dd1740f32abafe9ea3e.png)

#### Line segment[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-16)]

![](//upload.wikimedia.org/wikibooks/en/1/19/Line_Segment.png)

Line segment MN

A collection of points is a line segment if and only if it is perfectly straight, is infinitely thin, and has a finite length. A line segment is measured by the shortest distance between the two extreme points on the line segment, known as endpoints. Between any two points on a line segment, there exists an infinite number of points which are also contained by the line segment.

## P[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-17)]

#### Parallel lines[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-18)]

Two lines or line segments are said to be parallel if and only if the lines are contained by the same plane and have no points in common if continued infinitely.

#### Parallel planes[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-19)]

Two planes are said to be parallel if and only if the planes have no points in common when continued infinitely.

#### Perpendicular lines[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-20)]

Two lines that intersect at a 90° angle.

#### Perpendicular Postulate[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-21)]

Given a line, ![\\overleftrightarrow{AB}](//upload.wikimedia.org/math/f/c/d/fcdd8784f7c04dd1740f32abafe9ea3e.png) and a point P not in line ![\\overleftrightarrow{AB}](//upload.wikimedia.org/math/f/c/d/fcdd8784f7c04dd1740f32abafe9ea3e.png), then there is one and only one line that goes through point P perpendicular to ![\\overleftrightarrow{AB}](//upload.wikimedia.org/math/f/c/d/fcdd8784f7c04dd1740f32abafe9ea3e.png)

#### Plane[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-22)]

An object is a plane if and only if it is a two-dimensional object which has no thickness or curvature and continues infinitely. A plane can be defined by three points. A plane may be considered to be analogous to a piece of paper[[1]](http://en.wikipedia.org/wiki/plane).

#### Point[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-23)]

A point is a zero-dimensional mathematical object representing a location in one or more dimensions[[2]](http://en.wiktionary.org/wiki/point). A point has no size; it has only location.

#### Polygon[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-24)]

A polygon is a closed plane figure composed of at least 3 straight lines. Each side has to intersect another side at their respective endpoints, and that the lines intersecting are not collinear.

## R[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-25)]

#### Radius[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-26)]

The radius of a circle is the distance between any given point on the circle and the circle's center.

    _See_ _**[Circle](/wiki/Geometry/Postulates_%26_Definitions#Circle)**_

#### Ray[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-27)]

A ray is a straight collection of points which continues infinitely in one direction. The point at which the ray stops is known as the ray's endpoint. Between any two points on a ray, there exists an infinite number of points which are also contained by the ray.

#### Ruler Postulate[[edit](/w/index.php?title=Geometry/Appendix_C&action=edit&section=T-28)]

The points on a line can be matched one to one with the real numbers. The real number that corresponds to a point is the point's coordinate. The distance between two points is the absolute value of the difference between the two coordinates of the two points.

  * Part II- Coordinate Geometry:

# Synthetic versus analytic geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=22)]

[Geometry/Synthetic versus analytic geometry](/w/index.php?title=Geometry/Synthetic_versus_analytic_geometry&action=edit&redlink=1)

  * Two and Three-Dimensional Geometry and Other Geometric Figures

# Perimeter and Arclength[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=23)]

## Perimeter of [Circle](/w/index.php?title=Geometry/Circle&action=edit&redlink=1)[[edit](/w/index.php?title=Geometry/Perimeter_and_Arclength&action=edit&section=T-1)]

The circles perimeter ![\\textstyle O](//upload.wikimedia.org/math/8/c/4/8c41ca5c65498e255df5ba9006164325.png) can be calculated using the following formula

    ![\\textstyle O=2 \\pi r](//upload.wikimedia.org/math/b/9/4/b945dc3d7ccc21adf5b987813c823296.png)

where ![\\textstyle \\pi = 3.1415926535 \\dots](//upload.wikimedia.org/math/d/a/d/dadf2f639584031171d3a2d12b90c654.png) and ![\\textstyle r](//upload.wikimedia.org/math/8/3/0/83054bf551c8f66f3faca2d9d367a464.png) the radius of the circle.

## Perimeter of [Polygons](/w/index.php?title=Geometry/Polygons&action=edit&redlink=1)[[edit](/w/index.php?title=Geometry/Perimeter_and_Arclength&action=edit&section=T-2)]

The perimeter of a polygon ![\\textstyle S](//upload.wikimedia.org/math/e/d/0/ed067d84cf744d3703034a9c6bf3f1f5.png) with ![\\textstyle n](//upload.wikimedia.org/math/0/c/5/0c59de0fa75c1baa1c024aabfa43b2e3.png) number of sides abbreviated ![s_1,s_2,\\dots,s_n](//upload.wikimedia.org/math/2/e/7/2e7ad7a9160322212d3f143cd330e064.png) can be caculated using the following formula

    ![S=\\sum_{k=1}^n s_k](//upload.wikimedia.org/math/a/3/f/a3f59e259e47b021995e8ff33822ed1f.png).

## Arclength of Circles[[edit](/w/index.php?title=Geometry/Perimeter_and_Arclength&action=edit&section=T-3)]

The arclength ![\\textstyle b](//upload.wikimedia.org/math/5/2/5/5254b90d248051980262672a1bbc2433.png) of a given circle with radius ![\\textstyle r](//upload.wikimedia.org/math/8/3/0/83054bf551c8f66f3faca2d9d367a464.png) can be calculated using

    ![b=\\frac{v}{2\\pi}2\\pi r=vr](//upload.wikimedia.org/math/1/0/8/10897fe6364742c1357f4c0e3dfa2eae.png)

where ![\\textstyle v](//upload.wikimedia.org/math/0/e/e/0eebef778df80f071321658c5c428db1.png) is the angle given in radians.

## Arclength of [Curves](/w/index.php?title=Geometry/Curves&action=edit&redlink=1)[[edit](/w/index.php?title=Geometry/Perimeter_and_Arclength&action=edit&section=T-4)]

If a curve ![\\textstyle \\gamma](//upload.wikimedia.org/math/8/6/9/869bf519de57786506964e1ec16e0863.png) in ![\\textstyle \\mathbb{R}^3](//upload.wikimedia.org/math/7/5/2/75252d24a6e7b822a70b85328c5801ae.png) have a parameter form ![\\textstyle \\mathbf{r}\\big\(t\\big\)=\\big\(x\\big\(t\\big\),y\\big\(t\\big\),z\\big\(t\\big\)\\big\)](//upload.wikimedia.org/math/7/f/3/7f335e3100348feb8adda225156216fb.png) for ![\\textstyle t \\in \\big\[a,b\\big\]](//upload.wikimedia.org/math/4/a/d/4ad51127eb7e95cad140fa830811e19d.png), then the arclength can be calculated using the following fomula

    ![S=\\int_{a}^{b} \\sqrt{ \\left\(\\frac{dx}{dt}\\right\)^2 + \\left\(\\frac{dy}{dt}\\right\)^2 + \\left\(\\frac{dz}{dt}\\right\)^2 } \\, dt=\\int_{\\textstyle \\gamma} \\sqrt{ \\left\(\\frac{dx}{dt}\\right\)^2 + \\left\(\\frac{dy}{dt}\\right\)^2 + \\left\(\\frac{dz}{dt}\\right\)^2 } \\, dt](//upload.wikimedia.org/math/6/f/2/6f2c49e3ce34b272332081dc1297d0c0.png).

Derivation of formula can be found using differential geometry on infinitely small triangles.

# Area[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=24)]

## Area of [Circles](/w/index.php?title=Geometry/Circle&action=edit&redlink=1)[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-1)]

The method for finding the area of a circle is

    ![Area = \\pi r^2](//upload.wikimedia.org/math/6/d/d/6ddb9c063e5d8191b664b2a1f01ab88b.png)

Where _π_ is a constant roughly equal to 3.14159265358978 and _r_ is the radius of the circle; a line drawn from any point on the circle to its center.

## Area of [Triangles](/wiki/Geometry/Triangle)[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-2)]

Three ways of calculating the area inside of a triangle are mentioned here.

### First method[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-3)]

If one of the sides of the triangle is chosen as a **base**, then a **height** for the triangle and that particular base can be defined. The height is a line segment perpendicular to the base or the line formed by extending the base and the endpoints of the height are the corner point not on the base and a point on the base or line extending the base. Let B = the length of the side chosen as the base. Let  
h = the distance between the endpoints of the height segment which is perpendicular to the base. Then the area of the triangle is given by:

    ![Area = \\frac{B \\times h}{2}](//upload.wikimedia.org/math/f/0/f/f0f7e8ece92b6496dc7e759b5d3904db.png)

This method of calculating the area is good if the value of a base and its corresponding height in the triangle is easily determined. This is particularly true if the triangle is a right triangle, and the lengths of the two sides sharing the 90o angle can be determined.

### Second method[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-4)]

    _Main page: [Hero's Formula](/w/index.php?title=Hero%27s_Formula&action=edit&redlink=1)_, also known as Heron's Formula

If the lengths of all three sides of a triangle are known, Hero's formula may be used to calculate the area of the triangle. First, the **semiperimeter**, s, must be calculated by dividing the sum of the lengths of all three sides by 2. For a triangle having side lengths a, b, and c :

    ![s=\\frac{a+b+c}{2}](//upload.wikimedia.org/math/9/4/e/94e13c4f066fd8802476f8646c1a5134.png)

Then the triangle's area is given by:

    ![Area = \\sqrt{s\\left\(s-a\\right\)\\left\(s-b\\right\)\\left\(s-c\\right\)}](//upload.wikimedia.org/math/0/e/5/0e5e1cb2c7b9e79e9f4472c38b84c625.png)

If the triangle is needle shaped, that is, one of the sides is very much shorter than the other two then it can be difficult to compute the area because the precision needed is greater than that available in the calculator or computer that is used. In otherwords Heron's formula is numerically unstable. Another formula that is much more stable is:

    ![Area = \\frac{\\sqrt{\\left\(a + \\left\( b + c \\right\) \\right\) \\cdot \\left\( c - \\left\( a - b \\right\) \\right\) \\cdot \\left\( c + \\left\( a - b \\right\) \\right\) \\cdot \\left\( a + \\left\( b - c \\right\) \\right\) }}{4}](//upload.wikimedia.org/math/b/2/d/b2d21e9cf30db01e6629c0002768e4f6.png)

where ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png), ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png), and ![c](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png) have been sorted so that ![a \\ge b \\ge c](//upload.wikimedia.org/math/d/c/f/dcfff734d84538ee5c422aec15267d3d.png).

See also [Heron's Formula at MathWorld](http://mathworld.wolfram.com/HeronsFormula.html) and [How JAVA's Floating-Point Hurts Everyone Everywhere](http://www.cs.berkeley.edu/~wkahan/JAVAhurt.pdf)

### Third method[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-5)]

In a triangle with sides length a, b, and c and angles A, B, and C opposite them,

![ A = \\frac{1}{2}ab \\cdot \\sin\(C\) = \\frac{1}{2}bc \\cdot \\sin\(A\) = \\frac{1}{2}ac \\cdot \\sin\(B\)](//upload.wikimedia.org/math/d/6/a/d6a401e009487050aa8c857361a3df0b.png)

This formula is true because ![ h = \\sin\(C\) ](//upload.wikimedia.org/math/b/3/e/b3e59974e903e786fa529cab7f135bf4.png) in the formula ![ A = \\tfrac{1}{2}Bh ](//upload.wikimedia.org/math/5/a/2/5a2f549a40d8e129c8149ab369b01015.png). It is useful because you don't need to find the height from an angle in a separate step, and is also used to prove the law of sines (divide all terms in the above equation by a*b*c and you'll get it directly!)

## Area of [Rectangles](/w/index.php?title=Rectangle&action=edit&redlink=1)[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-6)]

The area calculation of a rectangle is simple and easy to understand. One of the sides is chosen as the **base**, with a length b. An adjacent side is then the **height**, with a length h, because in a rectangle the adjacent sides are perpendicular to the side chosen as the base. The rectangle's area is given by:

![A = b \\cdot h](//upload.wikimedia.org/math/4/4/6/446e9fc01129e2de30cd78e28a9bfd89.png)

Sometimes, the baselength may be referred to as the length of the rectangle, l, and the height as the width of the rectangle, w. Then the area formula becomes:

![A = l \\cdot w](//upload.wikimedia.org/math/d/9/9/d99e962e3d2daa90809617a9f7362814.png)

Regardless of the labels used for the sides, it is apparent that the two formulas are equivalent.

Of course, the area of a square with sides having length s would be:

![A = s^2](//upload.wikimedia.org/math/f/e/8/fe8e3bfc94ba4a588bb3665941f5c614.png)

## Area of [Parallelograms](/wiki/Geometry/Parallelograms)[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-7)]

The area of a parallelogram can be determined using the equation for the area of a rectangle. The formula is:

![A = b \\cdot h](//upload.wikimedia.org/math/4/4/6/446e9fc01129e2de30cd78e28a9bfd89.png)

A is the area of a parallelogram. b is the base. h is the height.

The height is a perpendicular line segment that connects one of the vertices to its opposite side (the base).

## Area of [Rhombus](/w/index.php?title=Geometry/Rhombus&action=edit&redlink=1)[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-8)]

Remember in a rombus all sides are equal in length.

![A= \\frac{d_1 \\cdot d_2}{2}](//upload.wikimedia.org/math/4/f/2/4f2f171f87ca334b881cc39c5424cc92.png) ![d_1](//upload.wikimedia.org/math/9/7/5/975e82ee46300a50d901d66c00fe64b1.png) and ![d_2](//upload.wikimedia.org/math/2/6/e/26ee688d727ea0c771dbdf3f456895bd.png) represent the diagonals.

## Area of [Trapezoids](/wiki/Geometry/Trapezoids)[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-9)]

The area of a trapezoid is derived from taking the arithmetic mean of its two parallel sides to form a rectangle of equal area.

![A = \\frac{\\left\(b_1 + b_2\\right\) \\cdot h}{2}](//upload.wikimedia.org/math/0/8/9/0893398d05d9ae2eb59c983ddadf72dd.png)

Where ![b_1](//upload.wikimedia.org/math/b/a/a/baacbe90a611155ee8de5fa5e833e134.png) and ![b_2](//upload.wikimedia.org/math/5/6/e/56ece28df930bd4d153b6c74ba96c054.png) are the lengths of the two parallel bases.

  


## Area of [Kites](http://en.wikipedia.org/wiki/Kite_\(geometry\))[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-10)]

The area of a kite is based on splitting the kite into four pieces by halving it along each diagonal and using these pieces to form a rectangle of equal area.

![A = {{a \\cdot b} \\over 2} ](//upload.wikimedia.org/math/1/f/f/1ff491c6dfd0f3aebdc435952dde13fd.png)

Where a and b are the diagonals of the kite.

Alternatively, the kite may be divided into two halves, each of which is a triangle, by the longer of its diagonals, a. The area of each triangle is thus

  


    ![{a \\cdot {b \\over 2}} \\over 2 ](//upload.wikimedia.org/math/4/9/f/49ff3a359777c67e11c68be111533a76.png)

  
Where b is the other (shorter) diagonal of the kite. And the total area of the kite (which is composed of two identical such triangles) is

  


    ![ 2 \\cdot {{a \\cdot {b \\over 2}} \\over 2}](//upload.wikimedia.org/math/d/0/7/d07bb60678db75b230eadfda76895e5e.png)

  
Which is the same as

  


    ![{a \\cdot {b \\over 2}}](//upload.wikimedia.org/math/f/2/5/f25bab3fb3a93dc7506d58ce88d5d83c.png)

  
or

  


    ![{a \\cdot b} \\over 2](//upload.wikimedia.org/math/2/9/0/29002ba90cbe98f352108f275dffabba.png)

## Areas of other [Quadrilaterals](/wiki/Geometry/Quadrilaterals)[[edit](/w/index.php?title=Geometry/Area&action=edit&section=T-11)]

The areas of other quadrilaterals are slightly more complex to calculate, but can still be found if the quadrilateral is well-defined. For example, a quadrilateral can be divided into two triangles, or some combination of triangles and rectangles. The areas of the constituent polygons can be found and added up with arithmetic.

# Volume[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=25)]

## Volume[[edit](/w/index.php?title=Geometry/Volume&action=edit&section=T-1)]

Volume is like area expanded out into 3 dimensions. Area deals with only 2 dimensions. For volume we have to consider another dimension. Area can be thought of as how much space some drawing takes up on a flat piece of paper. Volume can be thought of as how much space an object takes up.

  


## Volume formulae[[edit](/w/index.php?title=Geometry/Volume&action=edit&section=T-2)]

Common [equations](/w/index.php?title=Equation&action=edit&redlink=1) for volume:

Shape Equation Variables

A [cube](/w/index.php?title=Cube_\(geometry\)&action=edit&redlink=1):
![s^3 = s \\cdot s \\cdot s](//upload.wikimedia.org/math/e/4/4/e44010f66dd9dd6406531a6fc3a0cb4a.png)
_s_ = length of a side

A rectangular [prism](/w/index.php?title=Prism_\(geometry\)&action=edit&redlink=1):
![l \\cdot w \\cdot h](//upload.wikimedia.org/math/7/e/2/7e2b8aeb51cd37d052bf852e9c4a7491.png)
l = _l_ength, w = _w_idth, h = _h_eight

A [cylinder](/w/index.php?title=Cylinder_\(geometry\)&action=edit&redlink=1) (circular prism):
![\\pi r^2 \\cdot h](//upload.wikimedia.org/math/6/9/8/69833501a76a4bf9d7d823316c905b9d.png)
_r_ = radius of circular face, _h_ = height

Any prism that has a constant cross sectional area along the height:
![A \\cdot h](//upload.wikimedia.org/math/7/4/1/741a059183c2039e948c0ffe7028392c.png)
_A_ = area of the base, _h_ = height

A [sphere](/w/index.php?title=Sphere&action=edit&redlink=1):
![\\frac{4}{3} \\pi r^3](//upload.wikimedia.org/math/9/3/a/93a32e52c9580c5f627ace8dc3ad6397.png)
_r_ = radius of sphere  
which is the [integral](/w/index.php?title=Integral&action=edit&redlink=1) of the [Surface Area](/w/index.php?title=Surface_Area&action=edit&redlink=1) of a [sphere](/w/index.php?title=Sphere&action=edit&redlink=1)

An [ellipsoid](/w/index.php?title=Ellipsoid&action=edit&redlink=1):
![\\frac{4}{3} \\pi abc](//upload.wikimedia.org/math/a/b/d/abd787ced5690e6fca581b0df1f64e01.png)
_a_, _b_, _c_ = semi-axes of ellipsoid

A [pyramid](/w/index.php?title=Pyramid_\(geometry\)&action=edit&redlink=1):
![\\frac{1}{3}Ah](//upload.wikimedia.org/math/0/f/7/0f751a2ee6e3fc58d5417ef6d6ca689b.png)
_A_ = area of the base, _h_ = height of pyramid

A [cone](/w/index.php?title=Cone_\(geometry\)&action=edit&redlink=1) (circular-based pyramid):
![\\frac{1}{3} \\pi r^2 h](//upload.wikimedia.org/math/2/4/2/242324296b597d1761cb0c4ef86f49de.png)
_r_ = radius of [circle](/w/index.php?title=Circle&action=edit&redlink=1) at base, _h_ = distance from base to tip 

.

(The units of volume depend on the units of length - if the lengths are in meters, the volume will be in cubic **meters**, etc.)

## Pappus' Theorem[[edit](/w/index.php?title=Geometry/Volume&action=edit&section=T-3)]

The volume of any solid whose cross sectional areas are all the same is equal to that cross sectional area times the distance the centroid(the center of gravity in a physical object) would travel through the solid.

[Image:PappusCentroidTheoremExample.jpg](/wiki/File:PappusCentroidTheoremExample.jpg)

## Cavalieri's Principle[[edit](/w/index.php?title=Geometry/Volume&action=edit&section=T-4)]

If two solids are contained between two parallel planes and every plane parallel to these two plane has equal cross sections through these two solids, then their volumes are equal.

[Image:CavalierisPrinciple.jpg](/wiki/File:CavalierisPrinciple.jpg)

# Polygons[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=26)]

A **Polygon** is a two-dimensional figure, meaning all of the lines in the figure are contained within one [plane](/wiki/Geometry/Points,_Lines,_Line_Segments_and_Rays). They are classified by the number of angles, which is also the number of sides.

One key point to note is that a polygon must have at least three sides. Normally, three to ten sided figures are referred to by their names (below), while figures with eleven or more sides is an _n_-gon, where _n_ is the number of sides. Hence a forty-sided polygon is called a 40-gon.

  * _[Triangle](/wiki/Geometry/Triangle)_
    
    
        A polygon with three angles and sides.
    

  * _[Quadrilateral](/wiki/Geometry/Quadrilaterals)_
    
    
        A polygon with four angles and sides.
    

  * _Pentagon_
    
    
        A polygon with five angles and sides.
    

  * _Hexagon_
    
    
        A polygon with six angles and sides.
    

  * _Heptagon_
    
    
        A polygon with seven angles and sides.
    

  * _Octogon_
    
    
        A polygon with eight angles and sides.
    

  * _Nonagon_
    
    
        A polygon with nine angles and sides.
    

  * _Decagon_
    
    
        A polygon with ten angles and sides.
    

For a list of n-gon names, go to [[3]](http://mathworld.wolfram.com/Polygon.html) and scroll to the bottom of the page.

  
Polygons are also classified as **convex** or **concave**. A convex polygon has interior angles less than 180 degrees, thus all triangles are convex. If a polygon has at least one internal angle greater than 180 degrees, then it is concave. An easy way to tell if a polygon is concave is if one side can be extended and crosses the interior of the polygon. Concave polygons can be divided into several convex polygons by drawing diagonals. **Regular polygons** are polygons in which all sides and angles are congruent.

# Triangles[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=27)]

A **triangle** is a type of [polygon](/wiki/Geometry/Polygon) having three sides and, therefore, three angles. The triangle is a closed figure formed from three straight [line segments](/wiki/Geometry/Points,_Lines,_Line_Segments_and_Rays) joined at their ends. The [points](/wiki/Geometry/Points,_Lines,_Line_Segments_and_Rays) at the ends can be called the corners, angles, or vertices of the triangle. Since any given triangle lies completely within a [plane](/wiki/Geometry/Points,_Lines,_Line_Segments_and_Rays), triangles are often treated as two-dimensional geometric figures. As such, a triangle has no [volume](/w/index.php?title=Volume&action=edit&redlink=1) and, because it is a two-dimensionally closed figure, the flat part of the plane inside the triangle has an [area](/wiki/Geometry/Area), typically referred to as the area of the triangle. Triangles are always convex polygons.

A triangle must have at least some area, so all three corner points of a triangle cannot lie in the same line. The sum of the lengths of any two sides of a triangle is always greater than the length of the third side. The preceding statement is sometimes called the Triangle Inequality.

## Certain types of triangles[[edit](/w/index.php?title=Geometry/Triangle&action=edit&section=T-1)]

### Categorized by angle[[edit](/w/index.php?title=Geometry/Triangle&action=edit&section=T-2)]

The sum of the interior angles in a triangle always equals 180o. This means that no more than one of the angles can be 90o or more. All three angles can all be less than 90oin the triangle; then it is called an **acute triangle**. One of the angles can be 90o and the other two less than 90o; then the triangle is called a **[right triangle](/wiki/Geometry/Right_Triangles_and_Pythagorean_Theorem)**. Finally, one of the angles can be more than 90o and the other two less; then the triangle is called an **obtuse triangle**.

### Categorized by sides[[edit](/w/index.php?title=Geometry/Triangle&action=edit&section=T-3)]

If all three of the sides of a triangle are of different length, then the triangle is called a **scalene triangle**.

If two of the sides of a triangle are of equal length, then it is called an **isoceles triangle**. In an isoceles triangle, the angle between the two equal sides can be more than, equal to, or less than 90o. The other two angles are both less than 90o.

If all three sides of a triangle are of equal length, then it is called an **equilateral triangle** and all three of the interior angles must be 60o, making it **equilangular**. Because the interior angles are all equal, all equilateral triangles are also the three-sided variety of a **regular polygon** and they are all [similar](/wiki/Geometry/Congruency_and_Similarity), but might not be [congruent](/wiki/Geometry/Congruency_and_Similarity). However, polygons having four or more equal sides might not have equal interior angles, might not be regular polygons, and might not be similar or congruent. Of course, pairs of triangles which are not equilateral might be similar or congruent.

Further discussion of [Congruent Triangles](/wiki/Geometry/Congruent_Triangles) and [Similar Triangles](/wiki/Geometry/Similar_Triangles) may be found in those corresponding sections.

## Opposite corners and sides in triangles[[edit](/w/index.php?title=Geometry/Triangle&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikibooks/en/f/f8/Triangle_ABC.PNG)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Picture of Triangle ABC

If one of the sides of a triangle is chosen, the interior angles of the corners at the side's endpoints can be called adjacent angles. The corner which is not one of these endpoints can be called the corner opposite to the side. The interior angle whose vertex is the opposite corner can be called the angle opposite to the side.

Likewise, if a corner or its angle is chosen, then the two sides sharing an endpoint at that corner can be called adjacent sides. The side not having this corner as one of its two endpoints can be called the side opposite to the corner.

The sides or their lengths of a triangle are typically labeled with lower case letters. The corners or their corresponding angles can be labeled with capital letters. The triangle as a whole can be labeled by a small triangle symbol and its corner points. In a triangle, the largest interior angle is opposite to longest side, and vice versa.

Any triangle can be divided into two right triangles by taking the longest side as a base, and extending a line segment from the opposite corner to a point on the base such that it is perpendicular to the base. Such a line segment would be considered the **height** or **altitude** ( h ) for that particular **base** ( b ). The two right triangles resulting from this division would both share the height as one of its sides. The interior angles at the meeting of the height and base would be 90o for each new right triangle. For acute triangles, any of the three sides can act as the base and have a corresponding height. For more information on right triangles, see [Right Triangles and Pythagorean Theorem](/wiki/Geometry/Right_Triangles_and_Pythagorean_Theorem).

## Area of Triangles[[edit](/w/index.php?title=Geometry/Triangle&action=edit&section=T-5)]

![Triangle \(acute\) bh.PNG](//upload.wikimedia.org/wikibooks/en/3/33/Triangle_%28acute%29_bh.PNG)

If base and height of a triangle are known, then the area of the triangle can be calculated by the formula:

![S = \\frac{b \\times h}{2}](//upload.wikimedia.org/math/e/6/a/e6ae35ec0ea84d2998f0cd37e102f314.png)

(![S](//upload.wikimedia.org/math/5/d/b/5dbc98dcc983a70728bd082d1a47546e.png) is the symbol for area)

  
Ways of calculating the area inside of a triangle are further discussed under [Area](/wiki/Geometry/Area).

## Centres[[edit](/w/index.php?title=Geometry/Triangle&action=edit&section=T-6)]

The centroid is constructed by drawing all the medians of the triangle. All three medians intersect at the same point: this crossing point is the centroid. Centroids are always inside a triangle. They are also the centre of gravity of the triangle.

The three angle bisectors of the triangle intersect at a single point, called the incentre. Incentres are always inside the triangle. The three sides are equidistant from the incentre. The incentre is also the centre of the inscribed circle (incircle) of a triangle, or the interior circle which touches all three sides of the triangle.

The circumcentre is the intersection of all three perpendicular bisectors. Unlike the incentre, it is outside the triangle if the triangle is obtuse. Acute triangles always have circumcentres inside, while the circumcentre of a right triangle is the midpoint of the hypotenuse. The vertices of the triangle are equidistant from the circumcentre. The circumcentre is so called because it is the centre of the circumcircle, or the exterior circle which touches all three vertices of the triangle.

The orthocentre is the crossing point of the three altitudes. It is always inside acute triangles, outside obtuse triangles, and on the right vertex of the right-angled triangle.

Please note that the centres of an equilateral triangle are always the same point.

# Right Triangles and Pythagorean Theorem[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=28)]

## Right triangles[[edit](/w/index.php?title=Geometry/Right_Triangles_and_Pythagorean_Theorem&action=edit&section=T-1)]

**Right triangles** are [triangles](/wiki/Geometry/Triangle) in which one of the interior [angles](/wiki/Geometry/Angles) is 90o. A 90o angle is called a **right angle**. Right triangles are sometimes called **right-angled triangles**. The other two interior angles are **complementary**, i.e. their sum equals 90o. Right triangles have special properties which make it easier to conceptualize and calculate their parameters in many cases.

The side opposite of the right angle is called the **hypotenuse**. The sides adjacent to the right angle are the **legs**. When using the Pythagorean Theorem, the hypotenuse or its length is often labeled with a lower case **c**. The legs (or their lengths) are often labeled **a** and **b**.

![Right triangle shows hyp legs.PNG](//upload.wikimedia.org/wikibooks/en/0/07/Right_triangle_shows_hyp_legs.PNG)

Either of the legs can be considered a base and the other leg would be considered the height (or altitude), because the right angle automatically makes them perpendicular. If the lengths of both the legs are known, then by setting one of these sides as the **base** ( b ) and the other as the **height** ( h ), the area of the right triangle is very easy to calculate using this formula:

  


![Right triangle bh.PNG](//upload.wikimedia.org/wikibooks/en/b/b1/Right_triangle_bh.PNG)![Area = \\,](//upload.wikimedia.org/math/d/9/d/d9de8d521442b72a49759e2bc28a38b6.png)**(1/2)**![ b h \\, ](//upload.wikimedia.org/math/7/8/9/7893a2505ad50c655743101d65181e38.png)

  
This is intuitively logical because another congruent right triangle can be placed against it so that the hypotenuses are the same line segment, forming a rectangle with sides having length b and width h. The area of the rectangle is b × h, so either one of the congruent right triangles forming it has an area equal to half of that rectangle.

![Two right triangles in rectangle.PNG](//upload.wikimedia.org/wikibooks/en/2/2f/Two_right_triangles_in_rectangle.PNG)

Right triangles can be neither equilateral, acute, nor obtuse triangles. Isosceles right triangles have two 45° angles as well as the 90° angle. All isosceles right triangles are similar since corresponding angles in isosceles right triangles are equal. If another triangle can be divided into two right triangles (see [Triangle](/wiki/Geometry/Triangle)), then the area of the triangle may be able to be determined from the sum of the two constituent right triangles. Also the Pythagorean theorem can be used for non right triangles. a2+b2=c2-2c

## Pythagorean Theorem[[edit](/w/index.php?title=Geometry/Right_Triangles_and_Pythagorean_Theorem&action=edit&section=T-2)]

For history regarding the Pythagorean Theorem, see [Pythagorean theorem](//en.wikipedia.org/wiki/Pythagorean_theorem). The **Pythagorean Theorem** states that:

  * In a right triangle, the square of the length of the hypotenuse is equal to the sum of the squares of the lengths of the other two sides.

Let's take a right triangle as shown here and set c equal to the length of the hypotenuse and set a and b each equal to the lengths of the other two sides. Then the Pythagorean Theorem can be stated as this equation:

![Pythagorean triangle.PNG](//upload.wikimedia.org/wikibooks/en/4/42/Pythagorean_triangle.PNG) ![ \\quad  c^2 = a^2 + b^2 ](//upload.wikimedia.org/math/a/8/6/a8695930719c150708aad0fd752996f8.png)

Using the Pythagorean Theorem, if the lengths of any two of the sides of a right triangle are known and it is known which side is the hypotenuse, then the length of the third side can be determined from the formula.

## Sine, Cosine, and Tangent for Right Triangles[[edit](/w/index.php?title=Geometry/Right_Triangles_and_Pythagorean_Theorem&action=edit&section=T-3)]

**Sine**, **Cosine**, and **Tangent** are all functions of an angle, which are useful in right triangle calculations. For an angle designated as θ, the sine function is abbreviated as **sin** θ, the cosine function is abbreviated as **cos** θ, and the tangent function is abbreviated as **tan** θ. For any  
angle θ, sin θ, cos θ, and tan θ are each single determined values and if θ is a known value, sin θ, cos θ, and tan θ can be looked up in a table or found with a calculator. There is a table listing these function values at the end of this section. For an angle between listed values, the sine, cosine, or tangent of that angle can be estimated from the values in the table. Conversely, if a number is known to be the sine, cosine, or tangent of a angle, then such tables could be used in reverse to find (or estimate) the value of a corresponding angle.

These three functions are related to right triangles in the following ways:

In a right triangle,

  * the sine of a non-right angle equals the length of the leg opposite that angle divided by the length of the hypotenuse.

  


  * the cosine of a non-right angle equals the length of the leg adjacent to it divided by the length of the hypotenuse.

  


  * the tangent of a non-right angle equals the length of the leg opposite that angle divided by the length of the leg adjacent to it.

  
For any value of θ where cos θ ≠ 0,

![\\qquad \\tan \\theta  = \\frac {\\sin \\theta } {\\cos \\theta }](//upload.wikimedia.org/math/b/5/c/b5c62a33bf80e4c09e2f6bc7b278e6bc.png).

  


If one considers the diagram representing a right triangle with the two non-right angles θ1and θ2, and the side lengths a,b,c as shown here:

![Right triangle.PNG](//upload.wikimedia.org/wikibooks/en/8/8a/Right_triangle.PNG)

For the functions of angle θ1:

![\\sin \\theta_1 = \\frac {b} {c} \\qquad \\cos \\theta_1 = \\frac{a} {c} \\qquad \\tan \\theta_1 = \\frac {b} {a} ](//upload.wikimedia.org/math/c/6/4/c6476d8a29b700572c0a64a3ea1fad42.png)

  


Analogously, for the functions of angle θ2:

![\\sin \\theta_2 = \\frac {a} {c} \\qquad \\cos \\theta_2 = \\frac {b} {c} \\qquad \\tan \\theta_2 = \\frac {a} {b} ](//upload.wikimedia.org/math/a/f/a/afa8becfbd67a139d81a3e680c9eacc7.png)

  


* * *

### Table of sine, cosine, and tangent for angles θ from 0 to 90°[[edit](/w/index.php?title=Geometry/Right_Triangles_and_Pythagorean_Theorem&action=edit&section=T-4)]

θ in degrees θ in radians sin θ cos θ tan θ

0
0
0.0
1.0
0.0

1
0.017453293
0.01745240
0.9998477
0.017455065

2
0.034906585
0.034899497
0.99939083
0.034920769

3
0.052359878
0.052335956
0.99862953
0.052407779

4
0.06981317
0.069756474
0.99756405
0.069926812

5
0.087266463
0.087155743
0.9961947
0.087488664

6
0.10471976
0.10452846
0.9945219
0.10510424

7
0.12217305
0.12186934
0.99254615
0.12278456

8
0.13962634
0.1391731
0.99026807
0.14054083

9
0.15707963
0.15643447
0.98768834
0.15838444

10
0.17453293
0.17364818
0.98480775
0.17632698

11
0.19198622
0.190809
0.98162718
0.19438031

12
0.20943951
0.20791169
0.9781476
0.21255656

13
0.2268928
0.22495105
0.97437006
0.23086819

14
0.2443461
0.2419219
0.97029573
0.249328

15
0.26179939
0.25881905
0.96592583
0.26794919

16
0.27925268
0.27563736
0.9612617
0.28674539

17
0.29670597
0.2923717
0.95630476
0.30573068

18
0.31415927
0.30901699
0.95105652
0.3249197

19
0.33161256
0.32556815
0.94551858
0.34432761

20
0.34906585
0.34202014
0.93969262
0.36397023

21
0.36651914
0.35836795
0.93358043
0.38386404

22
0.38397244
0.37460659
0.92718385
0.40402623

23
0.40142573
0.39073113
0.92050485
0.42447482

24
0.41887902
0.40673664
0.91354546
0.44522869

25
0.43633231
0.42261826
0.90630779
0.46630766

26
0.45378561
0.43837115
0.89879405
0.48773259

27
0.4712389
0.4539905
0.89100652
0.50952545

28
0.48869219
0.46947156
0.88294759
0.53170943

29
0.50614548
0.48480962
0.87461971
0.55430905

30
0.52359878
0.5
0.8660254
0.57735027

31
0.54105207
0.51503807
0.8571673
0.60086062

32
0.55850536
0.52991926
0.8480481
0.62486935

33
0.57595865
0.54463904
0.83867057
0.64940759

34
0.59341195
0.5591929
0.82903757
0.67450852

35
0.61086524
0.57357644
0.81915204
0.70020754

36
0.62831853
0.58778525
0.80901699
0.72654253

37
0.64577182
0.60181502
0.79863551
0.75355405

38
0.66322512
0.61566148
0.78801075
0.78128563

39
0.68067841
0.62932039
0.77714596
0.80978403

40
0.6981317
0.64278761
0.76604444
0.83909963

41
0.71558499
0.65605903
0.75470958
0.86928674

42
0.73303829
0.66913061
0.74314483
0.90040404

43
0.75049158
0.68199836
0.7313537
0.93251509

44
0.76794487
0.69465837
0.7193398
0.96568877

45
0.78539816
0.70710678
0.70710678
1.0

46
0.80285146
0.7193398
0.69465837
1.03553031

47
0.82030475
0.7313537
0.68199836
1.07236871

48
0.83775804
0.74314483
0.66913061
1.11061251

49
0.85521133
0.75470958
0.65605903
1.15036841

50
0.87266463
0.76604444
0.64278761
1.19175359

51
0.89011792
0.77714596
0.62932039
1.23489716

52
0.90757121
0.78801075
0.61566148
1.27994163

53
0.9250245
0.79863551
0.60181502
1.32704482

54
0.9424778
0.80901699
0.58778525
1.37638192

55
0.95993109
0.81915204
0.57357644
1.42814801

56
0.97738438
0.82903757
0.5591929
1.48256097

57
0.99483767
0.83867057
0.54463904
1.53986496

58
1.01229097
0.8480481
0.52991926
1.60033453

59
1.02974426
0.8571673
0.51503807
1.66427948

60
1.04719755
0.8660254
0.5
1.73205081

61
1.06465084
0.87461971
0.48480962
1.80404776

62
1.08210414
0.88294759
0.46947156
1.88072647

63
1.09955743
0.89100652
0.4539905
1.96261051

64
1.11701072
0.89879405
0.43837115
2.05030384

65
1.13446401
0.90630779
0.42261826
2.14450692

66
1.15191731
0.91354546
0.40673664
2.24603677

67
1.1693706
0.92050485
0.39073113
2.35585237

68
1.18682389
0.92718385
0.37460659
2.47508685

69
1.20427718
0.93358043
0.35836795
2.60508906

70
1.22173048
0.93969262
0.34202014
2.74747742

71
1.23918377
0.94551858
0.32556815
2.90421088

72
1.25663706
0.95105652
0.30901699
3.07768354

73
1.27409035
0.95630476
0.2923717
3.27085262

74
1.29154365
0.9612617
0.27563736
3.48741444

75
1.30899694
0.96592583
0.25881905
3.73205081

76
1.32645023
0.97029573
0.2419219
4.01078093

77
1.34390352
0.97437006
0.22495105
4.33147587

78
1.36135682
0.9781476
0.20791169
4.70463011

79
1.37881011
0.98162718
0.190809
5.14455402

80
1.3962634
0.98480775
0.17364818
5.67128182

81
1.41371669
0.98768834
0.15643447
6.31375151

82
1.43116999
0.99026807
0.1391731
7.11536972

83
1.44862328
0.99254615
0.12186934
8.14434643

84
1.46607657
0.9945219
0.10452846
9.51436445

85
1.48352986
0.9961947
0.087155743
11.4300523

86
1.50098316
0.99756405
0.069756474
14.3006663

87
1.51843645
0.99862953
0.052335956
19.0811367

88
1.53588974
0.99939083
0.034899497
28.6362533

89
1.55334303
0.9998477
0.01745240
57.2899616

90
1.57079633
1.0
0.0
not defined

  
General rules for important angles: ![ sin 45^o = cos 45^o = \\frac{1}{\\sqrt{2}} ](//upload.wikimedia.org/math/b/e/e/bee0c953832c6a5d6134f6b6d81d8706.png)

![ tan 45^o = 1 ](//upload.wikimedia.org/math/e/0/2/e02947e65287e77e2571a4cca45c64cc.png)

![ sin 30^o = \\frac{1}{2} = cos 60^o ](//upload.wikimedia.org/math/8/d/f/8df0e4c9b1f187574388123fc7f63b66.png)

![ cos 30^o = \\frac{\\sqrt{3}}{2} = sin 60^o ](//upload.wikimedia.org/math/6/c/5/6c5fc828ec535e54e1a8759b68217ffe.png)

# Polyominoes[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=29)]

**Polyominoes** are shapes made from connecting unit [squares](/wiki/Geometry/Parallelograms#Square) together, though certain connections are not allowed.

## Domino[[edit](/w/index.php?title=Geometry/Polyominoes&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/58/Side_side_connected.jpg/120px-Side_side_connected.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A Domino

A domino is the shape made from attaching unit squares so that they share one full edge. The term polyomino is based on the word domino. There is only one possible domino.

## Tromino[[edit](/w/index.php?title=Geometry/Polyominoes&action=edit&section=T-2)]

A polymino made from three squares is called a tromino. There are only two possible trominoes.

![TrominoV.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3f/TrominoV.jpg/120px-TrominoV.jpg) ![TrominoI.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9e/TrominoI.jpg/120px-TrominoI.jpg)

## Tetromino[[edit](/w/index.php?title=Geometry/Polyominoes&action=edit&section=T-3)]

A polymino made from four squares is called a tetromino. There are five possible combinations and two reflections:

![Tetrominoes IJLO STZ Worlds.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/39/Tetrominoes_IJLO_STZ_Worlds.svg/360px-Tetrominoes_IJLO_STZ_Worlds.svg.png)

## Pentominoes[[edit](/w/index.php?title=Geometry/Polyominoes&action=edit&section=T-4)]

A polymino made from five squares is called a pentomino. There are twelve possible pentominoes, excluding mirror images and rotations.

# Ellipses[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=30)]

## Ellipses[[edit](/w/index.php?title=Geometry/Ellipses&action=edit&section=T-1)]

Ellipses are sometimes called ovals. Ellipses contain two foci. The sum of the distance from a point on the ellipse to one focus and that same point to the other focus is constant

![Ellipse.jpg](//upload.wikimedia.org/wikibooks/en/1/1a/Ellipse.jpg)

# 2-Dimensional Functions[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=31)]

[Geometry/2-Dimensional Functions](/w/index.php?title=Geometry/2-Dimensional_Functions&action=edit&redlink=1)

# 3-Dimensional Functions[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=32)]

[Geometry/3-Dimensional Functions](/w/index.php?title=Geometry/3-Dimensional_Functions&action=edit&redlink=1)

# Area Shapes Extended into 3rd Dimension[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=33)]

[Geometry/Area Shapes Extended into 3rd Dimension](/w/index.php?title=Geometry/Area_Shapes_Extended_into_3rd_Dimension&action=edit&redlink=1)

# Area Shapes Extended into 3rd Dimension Linearly to a Line or Point[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=34)]

[Geometry/Area Shapes Extended into 3rd Dimension Linearly to a Line or Point](/w/index.php?title=Geometry/Area_Shapes_Extended_into_3rd_Dimension_Linearly_to_a_Line_or_Point&action=edit&redlink=1)

# Polyhedras[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=35)]

[Geometry/Polyhedras](/w/index.php?title=Geometry/Polyhedras&action=edit&redlink=1)

# Ellipsoids and Spheres[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=36)]

[Geometry/Ellipsoids and Spheres](/w/index.php?title=Geometry/Ellipsoids_and_Spheres&action=edit&redlink=1)

# Coordinate Systems[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=37)]

Suppose you are an astronomer in America. You observe an exciting event (say, a supernova) in the sky and would like to tell your colleagues in Europe about it. Suppose the supernova appeared at your zenith. You can't tell astronomers in Europe to look at their zenith because their zenith points in a different direction. You might tell them which constellation to look in. This might not work, though, because it might be too hard to find the supernova by searching an entire constellation. The best solution would be to give them an exact position by using a coordinate system.

On Earth, you can specify a location using latitude and longitude. This system works by measuring the angles separating the location from two great circles on Earth (namely, the equator and the prime meridian). Coordinate systems in the sky work in the same way.

The equatorial coordinate system is the most commonly used. The equatorial system defines two coordinates: **right ascension** and **declination**, based on the axis of the Earth's rotation. The declination is the angle of an object north or south of the celestial equator. Declination on the celestial sphere corresponds to latitude on the Earth. The right ascension of an object is defined by the position of a point on the celestial sphere called the vernal equinox. The further an object is east of the vernal equinox, the greater its right ascension.

  
A coordinate system is a system designed to establish positions with respect to given reference points. The coordinate system consists of one or more reference points, the styles of measurement (linear measurement or angular measurement) from those reference points, and the directions (or axes) in which those measurements will be taken. In astronomy, various coordinate systems are used to precisely define the locations of astronomical objects.

  
Latitude and longitude are used to locate a certain position on the Earth's surface. The lines of latitude (horizontal) and the lines of longitude (vertical) make up an invisible grid over the earth. Lines of latitude are called parallels. Lines of longitude aren't completely straight (they run from the exact point of the north pole to the exact point of the south pole) so they are called meridians. 0 degrees latitude is the Earth's middle, called the equator. O degrees longitude was tricky because there really is no middle of the earth vertically. It was finally agreed that the observatory in Greenwich, U.K. would be 0 degrees longitude due to its significant roll in scientific discoveries and creating latitude and longitude. 0 degrees longitude is called the prime meridian.

Latitude and longitude are measured in degrees. One degree is about 69 miles. There are sixty minutes (') in a degree and sixty seconds (") in a minute. These tiny units make GPS's (Global Positioning Systems) much more exact.

There are a few main lines of latitude:the Arctic Circle, the Antarctic Circle, the Tropic of Cancer, and the Tropic of Capricorn. The Antarctic Circle is 66.5 degrees south of the equator and it marks the temperate zone from the Antarctic zone. The Arctic Circle is an exact mirror in the north. The Tropic of Cancer separates the tropics from the temperate zone. It is 23.5 degrees north of the equator. It is mirrored in the south by the Tropic of Capricorn.

### Horizontal coordinate system[[edit](/w/index.php?title=General_Astronomy/Coordinate_Systems&action=edit&section=T-1)]

One of the simplest ways of placing a star on the night sky is the coordinate system based on altitude and azimuth, thus called the Alt-Az or horizontal coordinate system. The reference circles for this system are the horizon and the celestial meridian, both of which may be most easily graphed for a given location using the celestial sphere.

In simplest terms, the altitude is the angle made from the position of the celestial object (e.g. star) to the point nearest it on the horizon. The azimuth is the angle from the northernmost point of the horizon (which is also its intersection with the celestial meridian) to the point on the horizon nearest the celestial object. Usually azimuth is measured eastwards from due north. So east has az=90°, south has az=180°, west has az=270° and north has az=360° (or 0°). An object's altitude and azimuth change as the earth rotates.

### Equatorial coordinate system[[edit](/w/index.php?title=General_Astronomy/Coordinate_Systems&action=edit&section=T-2)]

The equatorial coordinate system is another system that uses two angles to place an object on the sky: right ascension and declination.

### Ecliptic coordinate system[[edit](/w/index.php?title=General_Astronomy/Coordinate_Systems&action=edit&section=T-3)]

The ecliptic coordinate system is based on the ecliptic plane, i.e., the plane which contains our Sun and Earth's average orbit around it, which is tilted at 23°26' from the plane of Earth's equator. The great circle at which this plane intersects the celestial sphere is the ecliptic, and one of the coordinates used in the ecliptic coordinate system, the ecliptic latitude, describes how far an object is to ecliptic north or to ecliptic south of this circle. On this circle lies the point of the vernal equinox (also called the first point of Aries); ecliptic longitude is measured as the angle of an object relative to this point to ecliptic east. Ecliptic latitude is generally indicated by _φ_, whereas ecliptic longitude is usually indicated by _λ_.

### Galactic coordinate system[[edit](/w/index.php?title=General_Astronomy/Coordinate_Systems&action=edit&section=T-4)]

As a member of the Milky Way Galaxy, we have a clear view of the Milky Way from Earth. Since we are inside the Milky Way, we don't see the galaxy's spiral arms, central bulge and so forth directly as we do for other galaxies. Instead, the Milky Way completely encircles us. We see the Milky Way as a band of faint starlight forming a ring around us on the celestial sphere. The disk of the galaxy forms this ring, and the bulge forms a bright patch in the ring. You can easily see the Milky Way's faint band from a dark, rural location.

Our galaxy defines another useful coordinate system — the **galactic coordinate system**. This system works just like the others we've discussed. It also uses two coordinates to specify the position of an object on the celestial sphere. The galactic coordinate system first defines a galactic latitude, the angle an object makes with the galactic equator. The galactic equator has been selected to run through the center of the Milky Way's band. The second coordinate is galactic longitude, which is the angular separation of the object from the galaxy's "prime meridian," the great circle that passes through the Galactic center and the galactic poles. The galactic coordinate system is useful for describing an object's position with respect to the galaxy's center. For example, if an object has high galactic latitude, you might expect it to be less obstructed by interstellar dust.

### Transformations between coordinate systems[[edit](/w/index.php?title=General_Astronomy/Coordinate_Systems&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/38/Law-of-haversines.svg/220px-Law-of-haversines.svg.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A spherical triangle solved by the law of cosines.

One can use the principles of spherical trigonometry as applied to triangles on the celestial sphere to derive formulas for transforming coordinates in one system to those in another. These formulas generally rely on the spherical law of cosines, known also as the cosine rule for sides. By substituting various angles on the celestial sphere for the angles in the law of cosines and by thereafter applying basic trigonometric identities, most of the formulas necessary for coordinate transformations can be found. The law of cosines is stated thus:

    ![\\cos\(c\) = \\cos\(a\) \\cos\(b\) + \\sin\(a\) \\sin\(b\) \\cos\(C\). \\,](//upload.wikimedia.org/math/b/b/3/bb37f9a9bc68d4f6fdf2a35337093c65.png)

To transform from horizontal to equatorial coordinates, the relevant formulas are as follows:

    ![Dec = \\arcsin\\left\[\\sin\(Alt\) \\sin\(Lat\) + \\cos\(Alt\) \\cos\(Lat\) \\cos\(Az\)\\right\]](//upload.wikimedia.org/math/b/5/2/b52fb2462b58238dae2048bddc7e05cc.png)

    ![RA = LST - \\arccos\\left\[{\\sin\(Alt\) - \\sin\(Dec\) \\sin\(Lat\) \\over \\cos\(Dec\) \\cos\(Lat\)}\\right\],](//upload.wikimedia.org/math/3/0/8/30807203ee46b95e62aff038153d26c9.png)

where _RA_ is the right ascension, _Dec_ is the declination, _LST_ is the local sidereal time, _Alt_ is the altitude, _Az_ is the azimuth, and _Lat_ is the observer's latitude. Using the same symbols and formulas, one can also derive formulas to transform from equatorial to horizontal coordinates:

    ![Alt = \\arcsin\\left\[\\sin\(Dec\) \\sin\(Lat\) + \\cos\(Dec\) \\cos\(Lat\) \\cos\(LST - RA\)\\right\]](//upload.wikimedia.org/math/9/8/d/98d3fda2b7d87fa3a10e7fc1259fcb9d.png)

    ![Az = \\arccos\\left\[{\\sin\(Dec\) - \\sin\(Alt\) \\sin\(Lat\) \\over \\cos\(Alt\) \\cos\(Lat\)}\\right\]](//upload.wikimedia.org/math/8/f/d/8fd764daab74188f28377c1f243d3055.png).

Transformation from equatorial to ecliptic coordinate systems can similarly be accomplished using the following formulas:

    ![\\phi = \\arcsin\\left\[\\sin\(Dec\) \\cos\(\\epsilon\) - \\cos\(Dec\) \\sin\(\\epsilon\) \\sin\(RA\)\\right\]](//upload.wikimedia.org/math/a/3/c/a3c1628eaec24b0861e2a741bf10bece.png)

    ![\\lambda = \\arcsin\\left\[{\\sin\(Dec\) - \\sin\(\\phi\) \\cos\(\\epsilon\) \\over \\cos\(\\phi\) \\sin\(\\epsilon\)}\\right\] = \\arctan\\left\[{\\sin\(RA\) \\cos\(\\epsilon\) + \\tan\(Dec\) \\sin\(\\epsilon\) \\over \\cos\(RA\)}\\right\],](//upload.wikimedia.org/math/4/0/5/40545894ee1eb2b12f1c48025fa82da6.png)

where _RA_ is the right ascension, _Dec_ is the declination, _φ_ is the ecliptic latitude, _λ_ is the ecliptic longitude, and _ε_ is the tilt of Earth's axis relative to the ecliptic plane. Again, using the same formulas and symbols, new formulas for transforming ecliptic to equatorial coordinate systems can be found:

    ![Dec = \\arcsin\\left\[\\sin\(\\phi\) \\cos\(\\epsilon\) + \\cos\(\\phi\) \\sin\(\\epsilon\) \\sin\(\\lambda\)\\right\]](//upload.wikimedia.org/math/0/f/f/0ff7ea58cd10e2e2f82621a88ceba4cc.png)

    ![RA = \\arcsin\\left\[{\\sin\(Dec\) \\cos\(\\epsilon\) - \\sin\(\\phi\) \\over \\cos\(Dec\) \\sin\(\\epsilon\)}\\right\]](//upload.wikimedia.org/math/b/8/e/b8ef5e267e9f29343d753cd437dfc449.png)

  * Traditional Geometry:

# Topology[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=38)]

A topological space is a set X, and a collection of subsets of X, C such that both the empty set and X are contained in C and the union of any subcollection of sets in C and the intersection of any finite subcollection of sets in C are also contained within C. The sets in C are called open sets. Their complements relative to X are called closed sets.

Given two topological spaces, X and Y, a map f from X to Y is continuous if for every open set U of Y, f−1(U) is an open set of X.

# Erlanger Program[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=39)]

[Geometry/Erlanger Program](/w/index.php?title=Geometry/Erlanger_Program&action=edit&redlink=1)

# Hyperbolic and Elliptic Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=40)]

There are precisely three different classes of three-dimensional constant-curvature geometry: Euclidean, hyperbolic and elliptic geometry. The three geometries are all built on the same first four axioms, but each has a unique version of the fifth axiom, also known as the parallel postulate. The 1868 _Essay on an Interpretation of Non-Euclidean Geometry_ by Eugenio Beltrami (1835 - 1900) proved the logical consistency of the two Non-Euclidean geometries, hyperbolic and elliptic.

## The Parallel Postulate[[edit](/w/index.php?title=Geometry/Hyperbolic_and_Elliptic_Geometry&action=edit&section=T-1)]

The parallel postulate is as follows for the corresponding geometries.

**Euclidean geometry:** Playfair's version: "Given a line _l_ and a point _P_ not on _l_, there exists a unique line _m_ through _P_ that is parallel to _l_." Euclid's version: "Suppose that a line _l_ meets two other lines _m_ and _n_ so that the sum of the interior angles on one side of _l_ is less than 180°. Then _m_ and _n_ intersect in a point on that side of _l_." These two versions are equivalent; though Playfair's may be easier to conceive, Euclid's is often useful for proofs.

**Hyperbolic geometry:** Given an arbitrary infinite line _l_ and any point _P_ not on _l_, there exist two or more distinct lines which pass through _P_ and are parallel to _l_.

**Elliptic geometry:** Given an arbitrary infinite line _l_ and any point _P_ not on _l_, there does not exist a line which passes through _P_ and is parallel to _l_.

## Hyperbolic Geometry[[edit](/w/index.php?title=Geometry/Hyperbolic_and_Elliptic_Geometry&action=edit&section=T-2)]

Hyperbolic geometry is also known as saddle geometry or Lobachevskian geometry. It differs in many ways to Euclidean geometry, often leading to quite counter-intuitive results. Some of these remarkable consequences of this geometry's unique fifth postulate include:

1\. The sum of the three interior angles in a triangle is strictly less than 180°. Moreover, the angle sums of two distinct triangles are not necessarily the same.

2\. Two triangles with the same interior angles have the same area.

### Models of Hyperbolic Space[[edit](/w/index.php?title=Geometry/Hyperbolic_and_Elliptic_Geometry&action=edit&section=T-3)]

The following are four of the most common models used to describe hyperbolic space.

1\. **The Poincaré Disc Model**. Also known as the conformal disc model. In it, the hyperbolic plane is represented by the interior of a circle, and lines are represented by arcs of circles that are orthogonal to the boundary circle and by diameters of the boundary circle. Preserves hyperbolic angles.

2\. **The Klein Model**. Also known as the Beltrami-Klein model or projective disc model. In it, the hyperbolic plane is represented by the interior of a circle, and lines are represented by chords of the circle. This model gives a misleading visual representation of the magnitude of angles.

3\. **The Poincaré Half-Plane Model**. The hyperbolic plane is represented by one-half of the Euclidean plane, as defined by a given Euclidean line _l_, where _l_ is not considered part of the hyperbolic space. Lines are represented by half-circles orthogonal to _l_ or rays perpendicular to _l_. Preserves hyperbolic angles.

4\. **The Lorentz Model**. Spheres in Lorentzian four-space. The hyperbolic plane is represented by a two-dimensional hyperboloid of revolution embedded in three-dimensional Minkowski space.

### Defining _Parallel_[[edit](/w/index.php?title=Geometry/Hyperbolic_and_Elliptic_Geometry&action=edit&section=T-4)]

Based on this geometry's definition of the fifth axiom, what does _parallel_ mean? The following definitions are made for this geometry. If a line _l_ and a line _m_ do not intersect in the hyperbolic plane, but intersect at the plane's boundary of infinity, then _l_ and _m_ are said to be **parallel**. If a line _p_ and a line _q_ neither intersect in the hyperbolic plane nor at the boundary at infinity, then _p_ and _q_ are said to be **ultraparallel**.

### The Ultraparallel Theorem[[edit](/w/index.php?title=Geometry/Hyperbolic_and_Elliptic_Geometry&action=edit&section=T-5)]

For any two lines _m_ and _n_ in the hyperbolic plane such that _m_ and _n_ are ultraparallel, there exists a unique line _l_ that is perpendicular to both _m_ and _n_.

## Elliptic Geometry[[edit](/w/index.php?title=Geometry/Hyperbolic_and_Elliptic_Geometry&action=edit&section=T-6)]

Elliptic geometry differs in many ways to Euclidean geometry, often leading to quite counter-intuitive results. For example, directly from this geometry's fifth axiom we have that there exist no parallel lines. Some of the other remarkable consequences of the parallel postulate include: The sum of the three interior angles in a triangle is strictly greater than 180°.

### Models of Elliptic Space[[edit](/w/index.php?title=Geometry/Hyperbolic_and_Elliptic_Geometry&action=edit&section=T-7)]

Spherical geometry gives us perhaps the simplest model of elliptic geometry. Points are represented by points on the sphere. Lines are represented by circles through the points.

# Affine Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=41)]

[Geometry/Affine Geometry](/w/index.php?title=Geometry/Affine_Geometry&action=edit&redlink=1)

# Projective Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=42)]

[Geometry/Projective Geometry](/w/index.php?title=Geometry/Projective_Geometry&action=edit&redlink=1)

# Neutral Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=43)]

## Topics[[edit](/w/index.php?title=Geometry/Neutral_Geometry&action=edit&section=T-1)]

  * [Euclid's First Four Postulates](/w/index.php?title=Geometry/Print_version/Euclid%27s_First_Four_Postulates&action=edit&redlink=1)  

  * [Euclid's Fifth Postulate](/w/index.php?title=Geometry/Print_version/Euclid%27s_Fifth_Postulate&action=edit&redlink=1)  

  * [Incidence Geometry](/w/index.php?title=Geometry/Print_version/Incidence_Geometry&action=edit&redlink=1)  

  * [Projective and Affine Planes](/w/index.php?title=Geometry/Print_version/Projective_and_Affine_Planes&action=edit&redlink=1) (necessary?)  

  * [Axioms of Betweenness](/w/index.php?title=Geometry/Print_version/Axioms_of_Betweenness&action=edit&redlink=1)  

  * [Pasch and Crossbar](/w/index.php?title=Geometry/Print_version/Pasch_and_Crossbar&action=edit&redlink=1)  

  * [Axioms of Congruence](/w/index.php?title=Geometry/Print_version/Axioms_of_Congruence&action=edit&redlink=1)  

  * [Continuity](/w/index.php?title=Geometry/Print_version/Continuity&action=edit&redlink=1) (necessary?)  

  * [Hilbert Planes](/w/index.php?title=Geometry/Print_version/Hilbert_Planes&action=edit&redlink=1)  

  * [Neutral Geometry](/w/index.php?title=Geometry/Print_version/Neutral_Geometry&action=edit&redlink=1)  


## Requests[[edit](/w/index.php?title=Geometry/Neutral_Geometry&action=edit&section=T-2)]

If you would like to request anything in this topic please post it below.

### Request Submissions[[edit](/w/index.php?title=Geometry/Neutral_Geometry&action=edit&section=T-3)]

# Inversive Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=44)]

[Geometry/Inversive Geometry](/w/index.php?title=Geometry/Inversive_Geometry&action=edit&redlink=1)

  * Modern geometry

# Algebraic Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=45)]

[Geometry/Algebraic Geometry](/w/index.php?title=Geometry/Algebraic_Geometry&action=edit&redlink=1)

# Differential Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=46)]

  * [Introduction](/wiki/Geometry/Differential_Geometry/Introduction) ![25 percents developed  as of Jan 23, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  * [Basic Curves](/wiki/Geometry/Differential_Geometry/Basic_Curves)

# Algebraic Topology[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=47)]

[Geometry/Algebraic Topology](/w/index.php?title=Geometry/Algebraic_Topology&action=edit&redlink=1)

# Noncommutative Geometry[[edit](/w/index.php?title=Geometry/Print_version&action=edit&section=48)]

[Geometry/Noncommutative Geometry](/w/index.php?title=Geometry/Noncommutative_Geometry&action=edit&redlink=1)

  * An Alternative Way and Alternative Geometric Means of Calculating the Area of a Circle =

[Geometry/An Alternative Way and Alternative Geometric Means of Calculating the Area of a Circle](/w/index.php?title=Geometry/An_Alternative_Way_and_Alternative_Geometric_Means_of_Calculating_the_Area_of_a_Circle&action=edit&redlink=1)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Geometry/Print_version&oldid=2464164](http://en.wikibooks.org/w/index.php?title=Geometry/Print_version&oldid=2464164)" 

[Category](/wiki/Special:Categories): 

  * [Geometry (book)](/wiki/Category:Geometry_\(book\))

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Geometry%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Geometry%2FPrint+version)

### Namespaces

  * [Book](/wiki/Geometry/Print_version)
  * [Discussion](/w/index.php?title=Talk:Geometry/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Geometry/Print_version)
  * [Edit](/w/index.php?title=Geometry/Print_version&action=edit)
  * [View history](/w/index.php?title=Geometry/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Geometry/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Geometry/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Geometry/Print_version&oldid=2464164)
  * [Page information](/w/index.php?title=Geometry/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Geometry%2FPrint_version&id=2464164)

### In other languages

  * [Português](//pt.wikibooks.org/wiki/Matem%C3%A1tica_elementar/Geometria_plana/Pol%C3%ADgonos)
  * [Česky](//cs.wikibooks.org/wiki/Geometrie)
  * [Français](//fr.wikibooks.org/wiki/G%C3%A9om%C3%A9trie)
  * [עברית](//he.wikibooks.org/wiki/%3F%3F%3F%3F%3F%3F%3F%3F%3F)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Geometry%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Geometry%2FPrint+version&oldid=2464164&writer=rl)
  * [Printable version](/w/index.php?title=Geometry/Print_version&printable=yes)

  * This page was last modified on 15 December 2012, at 22:41.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Geometry/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
