# Na'vi/English-Na'vi dictionary/Print version

From Wikibooks, open books for an open world

< [Na'vi](/wiki/Na%27vi) | [English-Na'vi dictionary](/wiki/Na%27vi/English-Na%27vi_dictionary)

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Na'vi](/wiki/Na%27vi)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Na%27vi/Print_version&action=purge&printable=yes) this page.

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

A _**[printable version](/wiki/Na%27vi/Print_version)**_ of Na’vi grammar is available. ([edit it](//en.wikibooks.org/w/index.php?title=Na%27vi/Print_version&action=edit))

![Nuvola apps bookcase.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Nuvola_apps_bookcase.svg/40px-Nuvola_apps_bookcase.svg.png)

This book has a **[collection](/w/index.php?title=Wikibooks:Collections/Na%27vi/English-Na%27vi_dictionary&action=edit&redlink=1)** providing an on-demand  
**[PDF version](//en.wikibooks.org/w/index.php?title=Special:Collection/render_collection/&colltitle=Wikibooks:Collections/Na%27vi/English-Na%27vi_dictionary)** as well as a  
**[printed book](//en.wikibooks.org/w/index.php?title=Special:Book/order_collection/&colltitle=Wikibooks:Collections/Na%27vi/English-Na%27vi_dictionary)**. ([edit](//en.wikibooks.org/w/index.php?title=Special:Collection/load_collection/&colltitle=Wikibooks:Collections/Na%27vi/English-Na%27vi_dictionary)) ([help](/wiki/Help:Collections))

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Na'vi language**_](//en.wikipedia.org/wiki/Na%27vi_language)

**Na’vi** is a constructed language, created for the fictional [Na’vi](//en.wikipedia.org/wiki/Fictional_universe_in_Avatar#Na.27vi), the humanoid inhabitants of the moon Pandora in the 2009 film _[Avatar_](//en.wikipedia.org/wiki/Avatar_\(2009_film\)). It was designed by [Paul Frommer](//en.wikipedia.org/wiki/Paul_Frommer), a professor at the Marshall School of Business with a doctorate in [linguistics](/wiki/Linguistics), to fit film director [James Cameron](//en.wikipedia.org/wiki/James_Cameron)'s conception of what the language should sound like in the film, to be realistically learnable by the fictional human characters of the film, and to be pronounceable by the real actors, but to not closely resemble any human language.

When the film was released in 2009, Na’vi had a growing vocabulary of about a thousand words, but understanding of its grammar was limited to Frommer.[1] The goal of this book is to make what is known of Na’vi grammar available to fans who are attempting to learn the language.

  
**Na’vi–English**

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

A _****printable version****_ of the English–Na’vi dictionary is available. ([edit it](//en.wikibooks.org/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&action=edit))

This vocabulary is a simple list of the English glosses in the [Na’vi-English dictionary](/wiki/Na%27vi/Na%27vi-English_dictionary).

Multiple senses of words, which are often ambiguous in English but not in Na’vi, may be distinguished as (n) noun, (v) verb, (adj) adjective, (adv) adverb, (trans) transitive, (intrans) intransitive. A few Terran animals are given approximate Pandoran equivalents. Exclamations which cannot be easily translated are listed at the end. Stressed syllables are **bold**.

  


## A

    abandon: _txìng_
    able: _tsu**sun**_. be able: _tsun_
    about: concerning: _te**ri**, -ìri_. about to: _‹ìy›_.
    above: _**i**o_. from above: _ta**'em**_.
    across: _ka_
    action: _kem_
    add: _sung_
    afar: _a**lìm**_
    afraid: be afraid: _**txo**pu si_
    after (time) _maw_. afterwards: _**maw**krr_. right after: _pxi**maw**_.
    afternoon: _ha'**ngir**, (late) kaym_
    again: _nì**mun**_
    against, counter to: _wä+_
    aged: _**ko**ak_
    ago: just a moment ago: _pxiswaw**am**_. Thursday two weeks ago: _mesrrmrr**vam**_.
    agree: _mll**te**_
    agreement: come to an agreement: _mol**te**_
    aim: (v) _kan_. (n) _tì**kan**_.
    air: _ya_
    alala!: _ì**ley**!_
    alien: (n) _**ke**tuwong_. (adj) _**ke**wong_.
    alike: _teng_
    alive: _rusey_. be alive: _rey_.
    all: all of (it, you, them): _nì**wotx**_. all the time / at all times: _**fra**krr_. not at all: _ke ... kaw**'it**_.
    allow: _tung_
    almost: _stum_
    alone (of a person) _nì**'aw**tu_
    along: _ì**lä**+, **ì**lä+_
    also: _kop, nì**teng**_
    although: _hu**fwa**_
    always: _**fra**krr_
    am: _lu_
    amazing (be amazing) _**wo**u_ (slang)
    among: _kip_
    amount: _hìm**txan**_. (small) _'it_.
    ancestor: _**pi**zayu_
    and: (between phrases) _sì_. (between clauses) _**ul**te_. and you?: _nga tut?_
    anger: (v) _stey**ki**_. (n) _tì**sti**_.
    angry: be angry: _sti_. angrily: _nì**sti**_.
    animal: _i**o**ang_
    another one: _**la**po_
    answer: (v) _'eyng, ting tì**'eyng**it_. (n) _tì**'eyng**_. in answer: _nì**'eyng**_.
    apart, divided: _ke**'aw**_
    apologize: _tsap**'a**lute si_
    apology: _tsap**'a**lute_
    apparently: _tat**lam**_
    appear: _lam_
    appearance (look) _tì**lam**_
    appetizing: _**pxa**sul_
    approach: _lok_
    are: _lu_. aren't they?: _ke**fya** srak? ke**fyak**?_
    arm: _pxun_. (pair of) arms: _mepun_.
    around (spatial) _pxaw_
    arrival: _tì**pä**hem_
    arrive: _**pä**hem, **pa**te_
    arrow: _swi**zaw**_
    art: _**tse**o_. (visual) _**rel**tseo_.
    ? artifact: _tì**ngop**_
    artist (visual) _**rel**tseotu_
    as (like) _na, pxel, nì-_. (the same way as) _**teng**fya_. (as for) _-ìri_.
    aside: step/move aside: (give way) _tìng tseng_. (move) _rikx_.
    ask: _pawm_
    ass (rear end) _txìm_
    assist: _srung si_
    assistance: _srung_
    at: _ro+_
    attack (v) _**'e**ko_
    attempt (v) _fmi_
    attention: pay attention: _**el**tu si_
    auspicious: _**et**rìp_
    avatar: _**u**niltì**ran**tokx_
    await: _pey_
    awake: _txen_
    aware: be aware, be in tune: _**ka**me_
    away: (direction) _ne**to**_. (position) _mì**so**_.

## B

    baby: _**prr**nen_
    back: (of body) _txal_. (rear part) _kä**pxì**_. (direction) _ne**'ìm**_. (in response) _nì**'eyng**_. come back, go back, return: _tä**txaw**_. move back, step aside: _rikx_. to back down: _tìng tseng_
    bad (adj) _kawng_
    badge: _**pä**tsì_
    balance of life: _rey**'eng**_
    ball: _rum_
    banshee (flying mount) _**ik**ran_
    barricade, barrier: _e**kxan**_
    bat (animal, approx.) _**ri**ti_
    bathe (wash oneself) _yä**pur**_
    battle group: _**wem**pongu_
    brave: _tstew_
    be (am, is, are): _lu_. be at, occupy a space: _tok_.
    beat (n) _**'e**kong_
    beautiful: (of people) _sevin_. (of things; pleasant to the senses) _lor_
    beauty (of things) _tì**lor**_
    because: (for that reason) _ta**lu**na (ta**lun**), a**lun**ta_. (due to that cause) _ta**wey**ka (ta**weyk**), a**weyk**ta_. because of that: _ta**fral**_.
    become: _slu_
    before: (time) _sre+_. (beforehand) _**sre**krr_. (in front of) _**e**o_. just before, right before (time) _pxi**sre**+_.
    begin: (intrans.) _**sngä**'i_. (begin something) _sngey**kä**'i_.
    beginning: _**sngä**'ikrr_
    behind: _**u**o_. leave behind: _txìng_.
    believe: _spaw_
    beloved (adj.) _**yaw**ne_. (loved one) _**yaw**netu, **yawn**tu_
    below: _**ä**o_
    best: (adj) _swey_. (adv) _nì**swey**_.
    betray: _ka**vuk** si_
    betrayal: _ka**vuk**_
    between: _mì**kam**_
    big (in size or stature) _tsawl_. get big (grow): _tsawl slu_.
    bind: _yìm_
    bird: _**ya**yo_
    bit: a bit: (n) _'it_. (adv) _nì**'it**_.
    bite: _frìp_
    bitter: _**syä'**ä_
    black: _la**yon**_
    bless: be blessed: _**Naw**ma **Sa'**nok **lrr**tok si_ [with dative]
    blind: _kak**rel**_
    blood: _**rey**pay_
    bloom, blossom (v) _'ong_
    blow, strike (n) _tì**ta**kuk_
    blue, green: _**e**an_. in blue: _nì**e**an_.
    body: _tokx_
    bond: (neural connection) _tsa**hey**lu_. (establish a neural connection) _tsa**heyl** si_.
    book: _puk_
    boom! (sound of thunder) _**kxang**angang_
    border: _**pxaw**pa_
    bottom: _**kll**pa_
    bow (weapon) _tsko_. bow and arrow: _tsko swi**zaw**_.
    brain: _**el**tu_
    brainworm (hallucinogenic) _**el**tungawng_
    branch (of a tree) _vul_
    brave: _tstew_. brave person, hero: _**txan**tstew_.
    bread (approx.) _**tsyo**syu_
    brief (adj) _yol_
    bring: (take to a place) _**mu**nge_. (bring here) _za**mu**nge_.
    broken: _fwel_
    brother: (sibling) _tsmuk, **tsmuk**tu_. (male) _**tsmu**kan_.
    bud (n) _**prr**nesyul_
    bug: _**hì**'ang_
    build (v) _**txu**la_
    building (a thing built): _tì**txu**la_
    bulk (the major part) _txam**pxì**_
    bull (approx.) _**tal**i**o**ang_
    burn (v) _nekx_
    but: (basic sense) _slä_. (however) _ngi**an**_. (except) _mung**wrr**, -mungwrr_.
    butt (rear end) _txìm_
    by, along: _ì**lä**+, **ì**lä+_

## C

    call (v) _syaw_
    calm: _ma**wey**_. calmly: _nìm**wey**_.
    camp: (n) _'awm_. (v) _tì**'awm** si_.
    camping: _tì**'awm**_
    can, be able: _tsun_
    captive: _spe**'e**tu_
    capture: _spe**'e**_
    careful: be careful: _**na**ri si_
    carry, bring: _**mu**nge_
    case: in that case: _ha_
    catch (v) _**stä'**nì_
    cattle (approx.) _talioang_
    cause: (reason, source) _o**eyk**_. (produce) _sley**ku**_.
    ceaselessly: _nìlke**ftang**_
    celebration: _ftxo**zä**_
    center (n) _**kxam**tseng_
    ceremonious: _**'e**oio_. ceremoniously: _nì**'e**oio_.
    certain: _law_
    challenge (ceremonial) _fpe**i**o_
    chance, opportunity: _skxom_
    change (intransitive) _**la**tem_. (change something) _ley**ka**tem_.
    charge: (running attack) _kxll_. (to attack) _kxll si_. be in charge, be responsible: _kll**fro'**_.
    chase (v) _**fe**wi_
    chat: (v) _päng**kxo**_. (n) _tìpäng**kxo**_
    check (v) _ste**ftxaw**_
    child: _**'e**veng_. (kid) _**'e**vi_.
    chin: _**tsuk**sìm_
    choice: _tì**ftxey**_
    choose: _ftxey_
    circumference: _**pxaw**pa_
    clan: _o**lo'**_
    clan leader: _olo'**eyk**tan_
    clean: _**la**ro_
    clear, certain: _law_
    clearly: _nì**law**, nì**fya**'o a**law**_
    clever: (person) _**ka**nu_. (idea, plan) _sìl**ron**sem_.
    cliff: _'awkx_
    close (v) _tstu si_
    close (adj): (be close to) _lok_. (close by) _a**sim**_.
    closed: _tstu_
    club (weapon) _txewk_
    cold: _wew_. I feel cold: _oe 'efu wew_.
    colleague: _**ler**tu_
    color: _**'o**pin_
    come: _**za**'u_. come back, go back: _tä**txaw**_.
    common: (ordinary) _le**trr**trr_.
    commune: _tir**e**apäng**kxo**_
    comparatively: _to_
    complete: _'än**syem**_
    completely: _nì**wotx**_
    comprehension _tì**tslam**_
    computer: _**el**tu le**fngap**_
    concerning: _te**ri**, -ìri_
    conclude (end) _**'i'**a_
    conclusion (end) _tì**'i'**a_
    congratulations!: _ay**lrr**tok **nga**ru_
    connect with (establish a neural connection) _tsa**heyl** si_
    connection (neural) _tsa**hey**lu_
    constantly: _nìlke**ftang**_, _nì**tut**_
    construct (v) _**txu**la_
    construction: _tì**txu**la_ (activity or object)
    consume: _nekx_
    continually: _nì**tut**_, _nìlke**ftang**_
    continuation: _tì**tut**_
    conversation: _tìpäng**kxo**_
    converse: _päng**kxo**_
    convey, take: _**mu**nge_
    cook (v) _'em_
    cord (chord? musical?) _te**lem**_
    correct (adj) _ey**awr**_
    correctness: _tì**yawr**_
    counter to, against: _wä+_
    cover, lid: _lew_. to cover: _lew si_.
    cow (approx.) _**tal**i**o**ang_
    crazy, insane: _lek**ye**'ung_
    create: _ngop_
    creation: _tì**ngop**_
    creator: _**ngop**yu_
    creature: _swi**rä**_
    crossbow: _**tska**lep_
    cry (weep) _**tsngaw**vìk_
    cup (n) _tsngal_
    cut (v) _mun**'i**_

## D

    daddy: _**sem**pu_
    daily: (adv) _fra**trr**_. (adj) _le**trr**_.
    dance (v) _srew_
    danger: _**hrr**ap_
    dangerous: _le**hrr**ap_
    dark: _vawm_
    darkness: _tì**vawm**_
    daughter: _**'ite**_
    dawn (nautical twilight, enough light to navigate) _trr**'ong**_. (just before dawn, astronomical twilight, stars disappearing) _sresrr**'ong**_. (just after dawn, civil twilight, bright enough to work) _trr**'ong**maw_.
    day: _trr_. Good day!: _**trr** le**fpom**_.
    dead (adj) _**ke**rusey_
    death: (Death, abstract) _tì**ter**kup_. (of an individual) _kxitx_.
    decide: _**pe**'un_
    decision: _tì**pe**'un_
    deed (n) _kem_
    defeat: be defeated (fall) _zup_
    deer (approx.) _**ye**rik_
    defend: _zong_
    delicious: _lor_
    demon: _**vrr**tep_
    depart: _hum_
    descend: _kll**kä**_
    destroy: _ska**'a**_
    destruction: _tìska**'a**_
    die: _**ter**kup_
    difference: _tì**ke**teng_
    different: _**ke**teng_
    dig up: _kll**ku**lat_
    dim-witted: _**snu**mìna_
    dinner: _**wu**tso_
    dip into liquid: (n) _yem**fpay**_. (v) _yem**fpay** si_.
    direhorse: _**pa'**li_
    dirty: _tsewtx_
    discover: _run_
    discuss: _päng**kxo**_
    discussion: _tìpäng**kxo**_
    distant: (be distant) _lìm_. (at a distance) _a**lìm**_.
    dive (v) _tawng_
    divided: _ke**'aw**_
    do: _si_. (suffice) _tam_. 'that will do': _tam tam_.
    doctor (title) _**tok**tor_
    dog (approx.) _**nan**tang_
    done: _ha**sey**_
    don't!: _rä**'ä**_
    dozen: _vo**sìng**_. two dozen (octal: 30) _**pxe**vol_
    down: downward: _ne**kll**_. 'Get down!': _ne **kll**te!_. 'You're going down!': _**nge**yä **kxe**tse lu **oe**ru!_
    dragon (approx.) _**to**ruk_
    draw: (illustrate) _weyn_. (pull) _za**'ä**rìp_.
    dream (n) _**u**nil_
    Dream Hunt: _**U**nil**ta**ron_
    dreamwalker: _**u**niltì**ran**yu_
    drink (v) _näk_
    drive out: _ku**rakx**_
    drop: (v.trans) _tung**zup**_. (fall) _zup_.
    drum (made of skin) _**a**u_
    dry: _u**kxo**_
    dull (of a blade) _**te**te_
    dunk: (n) _yem**fpay**_. (v) _yem**fpay** si_.
    during: _krr a, a krr,_ etc.
    dusk (nautical twilight, enough light to navigate) _txon**'ong**_. (just before dusk, civil twilight, still enough light to work) _sreton**'ong**_. (just after dusk, astronomical twilight, stars appearing) _txon**'ong**maw_.
    dwell: _**kel**ku si_

## E

    ear: _**mik**yun_. (pair of) ears: _me**mik**yun_.
    Earth: _**'Rr**ta_. Earth Day: _Trr **'Rr**tayä_.
    easily: _nì**ftu**e_
    easy: _**ftu**e_
    eat: _yom_
    edge (perimeter) _**pxaw**pa_
    eh?: _ko_
    eight (octal: 10) _vol_. (human digit '8') _'eyt</t>._
    _eighteen (octal: 22) mevo**mun**_
    eighteenth (number eighteen) _mevo**mu**ve_
    eighth (number eight) _**vol**ve_
    eighty (exact; octal: 120) _zam **me**vol_.
    either: either A or B: _A, B, ke **tsran**ten_.
    elbow: _**pxun**til_
    eleven (octal: 13) _vo**pey**_
    eleventh (number eleven) _vo**pey**ve_
    else: or else: _**txo**kefyaw_. someone else, something else: _**la**po_.
    encounter (v) _ul**txa**run_
    end: (v) _**'i'**a_. (n) _tì**'i'**a_.
    ending: _tì**'i'**a_
    enemy: _**kxu**tu_
    English: _**'Ìng**lìsì_. in English: _nì**'Ìng**lìsì_.
    enjoyable: _mo**wan**_. (of an activity) _**prr**te'._
    enough: (adj) _le**tam'**_. (after an adjective) _nì**tam**_. (be enough) _tam_.
    enter: _**fpxä**kìm_
    equal: _teng_
    erect: _pxim_. (sit) erectly: _nì**pxim**_.
    error: (mistake) _**kxe**yey_. (incorrectness) _tì**kxey**_.
    especially: _nì**pxi**_
    even: (level) _**'eng**eng_. (adv) _keng_. not even once: _ke keng **'aw**lo_. [stress?] even so: _tsalsu**ngay**_.
    evening: (dusk) _txon**'ong**_. (late afternoon) _kaym_.
    every: _fra-_. every day: _fra**trr**_. every night: _fra**txon**_. everyone: _**fra**po_. everything: _**fra**'u_. everywhere: _**fra**tseng_. every time: _**fra**lo_.
    everyday, ordinary: _le**trr**trr_
    evil (adj) _kawng_. (n) _tì**kawng**_.
    examine, check: _ste**ftxaw**_
    example (n) _tì**ke**nong_. be an example: _**ke**nong_.
    excellent: _**txan**tsan_
    except: _mung**wrr**_
    excess (overabundance) _hawng_
    excessive: _le**hawng**_. excessively: _nì**hawng**_.
    exercise, practice (n) _**tskxe**keng_
    explain, explain why: _o**eyk**tìng_
    explanation: _tìo**eyk**tìng_
    explode: _pxor_
    expression (phrase) _**lì'**fyavi_
    eye: _**na**ri_. eyes (2, of person) _me**na**ri_, (4, of horse, banshee) _ay**na**ri_.

## F

    face: _key_
    fair: _mu**i**ä_
    fall (v) _zup_
    false: _tsleng_
    family: _so**a**ia_
    far: (be far) _lìm_. (far away) _a**lìm**_.
    fascinating (be fascinating) _**wo**u_ (slang)
    fast: (quick) _win_. (quickly) _nì**win**_.
    fasten: _yän_
    fate: _syay_
    father: _**sem**pul_
    favorable: _**et**rìp_
    fear: (n) _**txo**pu_. (v) _**txo**pu si_.
    feed: _**yom**tìng_
    feel: _**'e**fu_
    feeling: _tì**'e**fu_
    female (person) _tu**te**_
    few: _hol_
    field (open terrain) _**txa**yo_
    fifteen (octal: 17) _vo**hin**_
    fifteenth (number fifteen) _vo**hi**ve_
    fifth (number five) _**mrr**ve_
    fifty (exact; octal: 62) _puvol**mu**ne,_ (approx.) _**pu**vol_
    fight (n) _wem_
    fill (v) _te**ya** si_
    final: _syen_
    find (v) _run_
    finger: _**zek**wä_
    finished: _ha**sey**_
    fire: _txep_
    first: _**'aw**ve, nì**'aw**ve_
    fish (n) _pay**o**ang_
    five: _mrr_. five hundred (approx.) _**vo**zam_. five thousand (approx.) _**za**zam_. [stress?]
    flesh: _vey_
    floating mountains: _**ik**ni**ma**ya_
    flour: _tsyo_
    flower: _**syu**lang_. (blue sp.) _**se**ze_.
    fly (v) _**tsway**on_
    foe: _**kxu**tu_
    follow: (proceed after) _nong_. (track) _sutx_. (travel along) _kä/za'u ìlä_.
    food: _**syu**ve_. (vegetable) _fkxen_. (animal) _vey_. (meat) _tsngan_. (from flour) _**tsyo**syu_.
    foot: _**ve**nu_. (pair of) feet: _me**ve**nu_.
    for (for the sake of) _fpi+_
    forbidden: _**kxa**nì_
    forest: _**na'**rìng_
    forever: (until the end of time) _tì**'i'**avay **krr**ä_. (incessantly) _nìlke**ftang**_.
    forget: _tswa'_
    forgive: forgive me: _ngay**txo**a_
    forgiveness: _**txo**a_
    formal: _**ske**pek_
    former: _**spu**win_
    fortunate: be fortunate: _**Naw**ma **Sa'**nok **lrr**tok si_ [with dative]
    fortune: _aylrrtok_ (from Eywa)
    forty (exact; octal: 50) _**mrr**vol_
    foul (taste or smell) _vä'._ (do wrong) _tì**kxey** si_
    four: _tsìng_. four hundred (approx.) _**pu**zam_. four thousand (approx.) _**za**zam_.
    fourteen (octal: 16) _vo**fu**_
    fourteenth (number fourteen) _vo**fu**ve_
    fourth (number four) _**tsì**ve_
    freckle (bioluminescent) _tan**hì**_
    fresh (appealing as food) _**pxa**sul_
    Friday (Earth calendar) _trr**pu**ve_
    friend: _**'ey**lan_
    friendship: _tì**'ey**lan_
    from: _ta_. (direction) _ftu_. from above: _ta**'em**_. from among: _ta**kip**_. from up among: _ta**fkip**_.
    front (part or section) _za**pxì**_. in front of: _**e**o_.
    full: _te**ya**_
    fungus: _spxam_
    funny (odd) _**hi**yìk_
    future: _zu**saw**krr_

## G

    game: _u**van**_
    garbage: _sngel_. garbage dump: _**sngel**tseng_.
    get: (receive) _tel_. (understand) _tslam_. Got it!: _tslo**lam**_.
    give: _tìng_. give way: _tìng tseng_.
    glad: be glad _te**ya** si_ [with dative]
    go: (move) _kä_. (go on, proceed) _sa**lew**_. go after, follow: _nong_. go down: _kll**kä**_. go in: _**fpxä**kìm_. go near: _lok_.
    goal (target) _tì**kan**_
    God (Gaea): _**Ey**wa, **Naw**ma **Sa'**nok_
    good: _sìl**tsan**_. (appealing as food) _**pxa**sul_.
    goodbye: (farewell) _**Ey**wa **nga**hu_. (see you soon) _kìye**va**me_
    good night (sleep well) _hi**va**haw nìm**wey**_.
    Got it!: _tslo**lam**_
    grab: _ni**ä**_
    grant (v) _te**swo**tìng_
    grassroots movement: _**ngrr**pongu_
    great (noble) _nawm_. (in quantity) _txan_. great person: _**nawm**tu_.
    Great Leonopteryx (animal like a large banshee) _**to**ruk_
    greed: _tì**txa**new_
    greedy: _**txa**new_
    green, blue: _**e**an_. in green: _nì**e**an_
    grok: _**ka**me_
    ground: _**kll**te_
    group: (of people) _**po**ngu_. (battle group) _**wem**pongu_.
    grow: _tsawl slu_
    guest: _**frr**tu_
    guidance: _tìfyawìn**txu**_
    guide: _fyawìn**txu**_
    guideline, rule: _ko**ren**_
    gunship: _**kun**sìp_

## H

    hair: _**nik**re_ (_ay**nik**re_ ?)
    Hallelujah Mountains: _**ik**ni**ma**ya_
    halt (v) _txey_
    Hammerhead Titanothere (animal like a rhino) _**'ang**tsìk_
    hand: _tsyokx_. (pair of) hands: _me**syokx**_.
    happen: _len_
    happiness, peace: _fpom; ay**lrr**tok_ (from Eywa)
    happy (of occasions) _le**fpom**_. (of people) _nit**ram**_. be happy: _**'e**fu nit**ram**_. happy (celebration) _ay**lrr**tok_ [with dative]
    hard: _txa'_
    harm (n) _kxu_
    harmless: _**kxu**ke_
    harmonious: _me**'em**_
    harmony: _tì**me**'em_. (with nature) _**me**oa**u**nia**e**a_.
    hateful: _fkay_
    have: _lu_ [with dative]
    he: _po, po**an**_
    head: _**re**'o_
    health (physical) _fpom**tokx**_
    healthy: _lefpom**tokx**_
    hear: _stawm_
    heart: _txe'**lan**_. with all one's heart: _nì**ftxa**vang_.
    heavy (weight) _**ku'**up_
    heed: _lek_
    Hellfire Wasp: _zi**ze'**_
    hello: _kal**txì**_
    help: (n) _srung_. (v) _srung si_.
    her: (gen) _**pe**yä_. (acc) _pot, **po**ti_. (dat) _por, **po**ru_. (after prep.) _po_.
    here: _fì**tseng**e, fì**tseng**_ [syll?]
    hero: _**txan**tstew_
    Hexapede (animal like a deer) _**ye**rik_
    hey! (anger, annoyance) _o**ìsss**!_ (threat) _**sa**a!_ (warning, frustration) _**tsa**-**hey**!, **wi**ya!_
    high: _kxayl_
    him: (acc) _pot, **po**ti_. (dat) _por, **po**ru_. (after prep.) _po_.
    hinge: _til_
    his: _**pe**yä_
    hit, strike (v) _**ta**kuk_
    hold off (suspend action) _fpak_
    home: _**kel**ku_
    Hometree: _**Ke**lutral_ [stress?]
    honor (n) _me**u**ia_
    hookah gourd: _txll'u_ [stress?]
    hope (v) _sìl**pey**_
    horse (approx.) _**pa'**li_
    hot: _som_. (to feel that one is hot) _**'e**fu som_.
    house: _**kel**ku_
    how?: _pe**fya**?, **fya**pe?_
    how many?: _pol**pxay**?, hol**pxay**pe?_
    how much?: _pìm**txan**? hìm**txam**pe?_
    however: _ngi**an**_
    howl (n) _**ngu**way_
    human (n) _**taw**tute_
    hundred: (exact, octal: 144) _**zam** tsìvo**sìng**_. (approx.) _**zam** fu **me**zam_. two hundred (approx.) : _**pxe**zam_. five hundred (approx.) _**vo**zam_
    hunger: _tìo**hakx**_
    hungry: _o**hakx**_. be hungry: _**'e**fu o**hakx**_
    hunt: (v) _**ta**ron_. (n) _tì**ta**ron_.
    hunter: _**ta**ronyu_
    hurry (be in a hurry) _**win** sä**pi**_
    hurt: (be painful) _tì**sraw** si_. (hurt someone or something) _tì**sraw** sey**ki**_.

## I

    I: _**o**e_ (_**we**-_ when inflected). (deferential and ceremonial form) _**o**he_.
    idea: _sä**fpìl**_
    idiot: _skxawng_
    if: _txo_. if not: _**txo**kefyaw_.
    illness: (disease) _sä**spxin**_. (state of being ill) _tì**spxin**_.
    image (n) _rel_
    immediately: (right now) _pxi**set**_. (very soon) _pxi**ye'**rìn_
    immerse: _yem**fpay** si_
    immersion: _yem**fpay**_
    important: _le**tsran**ten_. be important: _**tsran**ten_.
    impossible: _kel**tsun**_
    in: _mì+_
    incessantly: _nìlke**ftang**_
    incorrect: _ke**yawr**_
    incorrectness: _tì**kxey**_
    individual (n) _**'aw**po_
    individuality (negative connotation) _tì**'aw**po_
    infant: _**prr**nen_
    inharmonious, divided: _ke**'aw**_
    insane: _lek**ye**'ung_
    insanity: _ke**ye**'ung_
    insect (approx.) _**hì**'ang_
    inside: _mì**fa**, **mì**fa_
    instance: _a**lo**_
    instead of: _tup_
    instruct: _sä**nu**me si_
    instruction: _sä**nu**me_
    insult (n) _zop**lo**_
    intelligence: _tì**ka**nu_. (understanding) _tì**tslam**_.
    intelligent: _**ka**nu_. intelligently: _nì**ka**nu_.
    interesting (be interesting) _**el**tur tì**txen** si_
    interpret: _ral**peng**_
    into (direction) _**nem**fa_
    intriguing (be intriguing) _**el**tur tì**txen** si_
    invention: _tì**ngop**_
    is: _lu_. isn't it? isn't that so?: _ke**fya** srak? ke**fyak**?_
    it: (animate) _po_. (inanimate) _**tsa**'u ~ tsaw_.
    itch (v) _**fkxa**ke_
    its: (animate) _**pe**yä_. (inanimate) _**tse**yä_.

## J

    jellyfish (aerial, approx) _**fpxa**faw_
    join two things together: _'awsteng**yem**_
    joint (n) _til_
    journey: _tì**sop**_
    joyous (of occassions) _le**fpom**_
    jump (v) _spä_
    just: (fair, justified) _mu**i**ä_. (only) _nì**'aw**_. just before: _pxi**sre**_. just after: _pxi**maw**_. just now, just a moment ago: _‹ìm›, pxiswaw**am**_. in just a moment: _‹ìy›, pxiswaw**ay**_.

## K

    keep up with someone: _la**tsi**_
    kid (n) _**'e**vi_
    kill: (v) _tspang_. (n) _tì**tspang**_
    kind: (n) _fnel_. what kind? _**fne**pe, pe**fnel**_
    kiss (v) _pom_
    knee: _ki**nam**til_
    knife: _tstal_
    know: _**o**mum; law lu_ [with dative]. as is known, as you know: _nìaw**no**mum_.

## L

    lake: _**'o**ra_
    land (n) _atx**kxe**_
    language: _**lì'**fya_
    large: _a**pxa**_
    larva, larvae (sp. beetle larva used for food) _**tey**lu_
    last: (final) _syen_. (previous) _ham_. last time: _a**lo** a**ham**_. last night: _txo**nam**_. last Thursday (Thursday of last week) _trrmrr**vam**_.
    laugh (n) _**hang**ham_
    lead (v) _eyk_
    leader: _**eyk**tan_. leader of clan: _olo'**eyk**tan_
    leaf: _rìk_
    leafy: _le**rìk**_
    lean (v) _**tu**von_
    learn: _**nu**me_
    leave: (go away) _hum_. (abandon) _txìng_.
    left (side, direction) _ftär_
    leg: _ki**nam**_
    _Leonopteryx_ (animal like a large banshee) _**to**ruk_
    lesson: _sä**num**vi_
    lest: _**fte**ke_
    let go: _lo**nu**_
    Let's ...!: _... ko_
    level, even: _**'eng**eng_
    lid: _lew_
    life (abstract) _tì**rey**_. (living) _tìru**sey**_. balance of life: _rey**'eng**_.
    light (n) _a**tan**_
    light (adj), lightweight: _syo_
    like (as) _na, pxel, nì-_. (the same way as) _**teng**fya_. like this: _fì**fya**_. like that: _**tsa**fya_.
    likewise: _nì**teng**_
    lip: _**sey**ri_
    liquid: _pay_
    listen: _tìng **mik**yun_ (pron. "tìm mikyun")
    little (adj) _**hì**'i_. a little: _'it, nì**'it**_.
    live (be alive) _rey_. (dwell) _**kel**ku si_.
    living: (alive) _ru**sey**_. (being alive) _tìru**sey**_. living thing: _ru**sey**_.
    location: _**kll**tseng_
    lock up: _sutx_
    long: (length) _ngim_. (time) _txan_.
    look (v) _tìng **na**ri_ (pron. "tìn nari"). look at: _nìn_. look for: _fwew_. look like: _lam_. (n) _tì**lam**_
    lose: lose track of: _**ta**tep_. lose oneself (spiritual sense) _**'i**a_.
    loud: _wok_
    love: (n) _tì**yawn**_. (v) _lu **yaw**ne_ [with dative]. I love you: _nga **yaw**ne lu **oer**_.
    loved (adj) _**yaw**ne_. loved one: _**yaw**netu, **yawn**tu_
    low: _tìm_
    lung: _**tso**pì_. (pair of) lungs: _me**so**pì_.

## M

    majority: _txam**pxì**_
    make: (do) _si_. (create) _ngop_. (build) _**txu**la_.
    male (person) _tu**tan**_
    manner: _**fya**'o_. in a (certain) manner: _nì**fya**'o_.
    mantis (approx.) _**fwä**kì_
    many: _pxay_
    marriage: _tìmun**txa**_
    marry: _mun**txa** si_
    mate (v) _mun**txa** si_
    mated: _mun**txa**_
    mating (n) _tìmun**txa**_
    matriarch: _**tsa**hìk_
    matter: (subject) _**txe**le_. (be important) _**tsran**ten_.
    may, be possible: _**tsun**slu_
    maybe: _kxawm_
    me: (acc) _**oe**ti_ (_**we**ti_). (dat) _**oe**ru, oer_ (_**we**ru, wer_). (after prep.) _**o**e_.
    meadow: _**txa**yo_
    meal (served) _**wu**tso_
    meaning: _ral_
    meantime: in the meantime: _tsa**krr**vay_
    meanwhile (until then) _tsa**krr**vay_
    meat: _tsngan_
    medusa (approx. a large aerial jellyfish) _**fpxa**faw_
    meet: (by chance) _ul**txa**run_. have a meeting: _ul**txa** si_.
    meeting: _ul**txa**_. have a meeting: _ul**txa** si_.
    memory, remembrance: _'ok_
    mess up: _tì**kxey** si_
    message: _'u**pxa**re_
    metal: _fngap_
    metallic: _le**fngap**_
    midday: _**kxam**trr_. (See 'noon'.)
    middle, midpoint: _kxam_
    midnight: _**kxam**txon_
    mighty: _fkew_
    military squad: _**wem**pongu_
    mind (n) _**ron**sem_
    mistake: _**kxe**yey_. make a mistake: _**kxe**yey si_.
    model (n) _**ke**nong_
    moment: _swaw_. (very short time) _**hì**krr_. just a moment ago: _pxiswaw**am**_. in just a moment: _pxiswaw**ay**_.
    mommy: _**sa'**nu_
    Monday (Earth calendar) _trr**mu**ve_
    more: _nì**'ul**_. (for comparison, use: _to_.)
    morning: (daylight before noon) _**re**won_. (dawn) _trr**'ong**_. (For early morning, see 'dawn'.)
    moron: _skxawng_
    moss: _**prr**wll_
    most: (adv: use _**fra**to_). (n) _txam**pxì**_.
    mother: _**sa'**nok_
    mountain: floating mountains: _**i**kni**ma**ya_
    mouth: _kxa_
    move: (shift position) _rikx_. (move something) _**'ä**rìp_.
    movement (grassroots) _**ngrr**pongu_
    much: (great quantity) _txan_. (great extent) _nì**txan**_. so much: _fì**txan**_.
    mushroom (approx.) _spxam_
    music: _**pam**tseo_
    musical instrument (stringed) _**i'**en_
    musician: _**pam**tseotu_
    must: _**ze**ne_. must not: _**zen**ke_ (_zengke_). don't need to: _ke **ze**ne_.
    my: _**oe**yä_ (_**we**yä_)
    My! (encouragement) _nang_
    myriad: _**za**zam_ [stress?]

## N

    Na'vi: (n) _**tu**te_. (adj) _le**Na'**vi_. in Na'vi: _nì**Na'**vi_.
    name (n) _tstxo_. my name is: _oeru syaw ..._. what is your name?: _fyape syaw ngar?_
    near: (be near) _sim_. (nearby) _a**sim**_.
    neck: _pewn_
    need: (v) _kin_. (n) _tì**kin**_. do not need to: _ke **ze**ne_
    necessary: _le**kin**_
    neural connection: _tsa**hey**lu_
    never: _ke ... **kaw**krr_
    nevertheless: _tsalsu**ngay**_
    new: _mip_
    news: _fmawn_
    next: _hay, -ay_. next time: _a**lo** a**hay**_. next Thursday (Thursday of next week) _trrmrr**vay**_
    night: _txon_. tonight: _fì**txon**_. last night: _txo**nam**_. tomorrow night: _txo**nay**_. Good night!: _**txon** le**fpom**_, (sleep well) _hi**va**haw nìm**wey**_.
    nine: (octal: 11) _vo**law**_. (human digit '9') _nayn_.
    nineteen (octal: 23) _mevo**pey**_
    nineteenth (number nineteen) _mevo**pey**ve_
    ninety (approx.) _zam **pxe**vol_
    ninth (number nine) _vo**law**ve_
    no: No!: _**ke**he_. (with a noun: no X) _**ke**a, a**ke**_. No?: _ke**fya** srak, ke**fyak**_. No way! (vulgar) _**pxa**sìk_. No, it can't be! (consternation) _a**u**!_
    noble: _nawm_
    none: _ke ... **ke**'u, ke ... kaw**'it**_
    nonetheless: _tsalsu**ngay**_
    noon: _**kxam**trr_. pre-noon (sun just before zenith) _sre**kam**trr_. post-noon (sun just after zenith) _**kxam**trrmaw_.
    no-one: _ke ... **kaw**tu_
    nose: _**on**tu_
    not: _ke_. not at all, not a bit (adv) _ke ... kaw**'it**_.
    nothing: (pn) _ke ... **ke**'u_. nothing at all (adv) _ke ... **ke**'u_.
    noun: _**tstxo**lì'u_
    now: (sentence opener) _tse_. (at this time) _set_. until now: _vay **set**_. right now: _pxi**set**_. Thursday two weeks from now: _mesrrmrr**vay**_.
    number (n) _hol**pxay**_

## O

    O! (address) _ma_
    oath: _**pä**nu?_
    obey: _lek_
    obstruction: _e**kxan**_
    occasion (happy) _ftxo**zä**_
    occupy (a space) _tok_
    occur: _len_
    ocean: _txam**pay**_
    odd, strange: _**hi**yìk_
    of: _-yä, -ä_. (a clan; used in full names) _te_. (See also 'from'.)
    offense: _zop**lo**_
    often: _pxìm_
    oh! (consternation) _a**u**!_ (poor thing!) _ke**ftxo**!_ (exertion) _sa**u**!_
    old: (not new) _**spu**win_. (not young) _**ko**ak_.
    okay: _tam, tam tam_. ...okay?: _... ko_
    on: _mì+_. on, onto (?) _sìn_.
    once: (in the past) _'aw**li**e_. (not twice) _**'aw**lo_.
    one: _'aw_. one individual: _'awpo_. one time (once) _'awlie, **'aw**lo_. one hundred (approx.) _**zam** fu **me**zam_. one thousand (approx.) _**me**vozam_. [stress?]
    one (pronoun: 'you', 'they') _fko_
    only: _nì**'aw**_
    oomph!: _sa**u**!_
    open: (be open) _pi**ak**_. (open something) _pi**ak** si_.
    opinion: in my opinion: _tì**'e**fumì **oe**yä_
    opportunity: _skxom_
    opposed to: _wä_
    optimal: _swey_. optimally: _nì**swey**_.
    or: _fu_. or else: _**txo**kefyaw_. or not: _fu**ke**_.
    order: in order to: _fte_ [with subjunctive]
    ordinary, everyday: _le**trr**trr_
    other: _**la**he_. other one (person or thing) _**la**po_. to the others: _ay**la**ru_.
    otherwise: _**txo**kefyaw_
    our (including your) _aw**nge**yä, (ay)oengeyä_ [stress?]
    our (but not your) _(ay)**oe**yä_ (_**we**yä, ay**we**yä_)
    out there: _kä**sa**tseng_
    outside: _**wrr**pa_
    overabundance: _hawng_

## P

    pain: _tì**sraw**_
    painful: _sraw_. be painful: _tì**sraw si**_
    Pandora: _Eywa**'e**veng_
    panther (approx.) _**pa**lu**lu**kan_
    part (n) _ha**pxì**_
    party (group of people) _**po**ngu_
    pass (a test) _em**za**'u_. (pass by something) _ftem_.
    passionate: _**ftxa**vang_
    passionately: _nì**ftxa**vang_
    past: the past: _ftaw**nem**krr_
    pasta (approx.) _**tsyo**syu_
    path: _**fya**'o_
    patience: _tìm**wey**pey_
    patient (adj) _lem**wey**pey_. be patient: _ma**wey**pey_. patiently: _nìm**wey**pey_. a patient person: _ma**wey**peyyu_.
    pattern (n) _**re**nu_
    pay attention: _**el**tu si_
    peace: _fpom_
    peaceful: _le**fpom**_. peacefully: _nìm**wey**_.
    peel (v) _**fka**rut_
    people: (persons) _**su**te_. (the People) _**Na'**vi_.
    perceive: _**'e**fu_
    perhaps: _kxawm_
    perimeter: _**pxaw**pa_
    person: _**tu**te_
    phrase: _**lì'**fyavi_
    picture (n) _rel_
    place (n) _**tseng**e, tseng_. [syll?] (v) _yem_.
    plain, field: _**txa**yo_
    plan: (v) _hawl_. (n) _tì**hawl**_.
    plant (n) _**'e**wll_
    play: (play a game) _u**van** si_
    pleasant: (to the senses) _lor_. (of an activity) _**prr**te'._ (enjoyable, of a person or thing) _mo**wan**_
    please!: _ru**txe**!_
    pleasing: _mo**wan**_
    pleasurable (of an activity) _**prr**te'_
    pleasure: _tì**prr**te'_
    practice, training _**tskxe**keng_
    pointedly: _nì**pxi**_
    poison (n) _txum_
    poor thing!: _ke**ftxo**!_
    position: _**kll**tseng_
    possible: _le**tsun**slu_. be possible: _**tsun**slu_.
    power: _tì**txur**_
    powerful: _fkew, **txan**tur_
    prefer: _nul**new**_
    preparations: _tì**hawl**_
    prepare, plan: _hawl_
    present (time) _**se**krr_
    pretty: _se**vin**_
    previous: _ham_. previous instance: _a**lo** a**ham**_.
    prey (n) _tì**tspang**_
    proceed: _sa**lew**_
    probable; probably: _**skxa**kep_
    produce (v) _sley**ku**_
    proliferate: _vi**rä**_
    promise: (n) _**pä**nu_. (v) _**pä**nutìng_.
    propel: _**spu**le_
    proper: _mu**i**ä_
    prophesize: _srese**'a**_
    prophesy: _tì**sre**se'a_
    protect: _**haw**nu, tì**haw**nu si_
    protection: _tì**haw**nu_
    pterosaur (approx.) _**ik**ran_
    pull (v) _za**'ä**rìp_
    purpose (goal) _tì**kan**_
    push (v) _kä**'ä**rìp_
    put: _yem_

## Q

    question (n) _tì**pawm**_
    (question marker) _srak(e)_. (with _fu**ke**_) _ftxey_.
    quiet: (n) _tì**fnu**_. be quiet: _fnu_.
    quote ... unquote: _san ... sìk_
    quotidian: _le**trr**trr_

## R

    rain (n) _**tom**pa_
    rather: (would rather) _nul**new**_. rather than: _tup_.
    ready: _a**lak**si_. get ready: _hawl_.
    rear: (part or section) _kä**pxì**_. (of person) _txìm_.
    reason (n) _lun_
    receive: _tel_
    recent: _sok_
    recline: _**tu**von_
    refuge: _**zong**tseng_
    refuse (v) _sto_
    release: _lo**nu**_
    remain: _'ì**'awn**_
    remember: _**ze**rok_
    remembrance: _'ok_
    represent: _**ke**nong_
    request: (n) _ä**txä**le_. (v) _ä**txä**le si_.
    respond: _'eyng_
    response: _tì**'eyng**_. in response: _nì**'eyng**_.
    responsibility: have responsibility (for): _kll**fro'**_
    responsible: be responsible (for): _kll**fro'**_
    rest (v) _tsu**rokx**_
    restore: _speng_
    return, go back: _tä**txaw**_
    rhino (approx.) _**'ang**tsìk_
    rhythm: _**ka**to_
    ride (v) _**mak**to_. ride out: _kä**mak**to_.
    right: (side, direction) _**ski**en_. (proper) _mu**i**ä_. (correct) _ey**awr**_. you're right: _**nga**ru tì**yawr**_. Right?: _ke**fya** srak? ke**fyak**?_ right now: _pxi**set**_. right before: _pxi**sre**_. right after: _pxi**maw**_.
    river: _kil**van**_. (sacred) _**Swo**tulu_.
    rock, stone: _tskxe_
    root: _ngrr_
    rule (n) _ko**ren**_
    run (n) _tul_
    rush: (v, hurry) _**win** sä**pi**_. (rush something) _**win** si_.

## S

    sacred: _swok_. sacred place: _**swo**tu_. Sacred River: _**Swo**tulu_.
    sad: _ke**ftxo**_. sadly: _nìke**ftxo**_. How sad! _ke**ftxo**!_
    safe: _**kxu**ke_. safe place: _**zong**tseng_.
    safely: _nìzaw**nong**_
    sake: for the sake of: _fpi+_
    same: _teng_
    Saturday (Earth calendar) _trr**ki**ve_
    save: _zong_
    say: _pll**txe**_
    saying ...: _san ... sìk_
    school: _**num**tseng_
    science: _tìfti**a** ki**fkey**ä_
    scream (v) _zawng_
    Screw that! (vulgar) _**pxa**sìk_
    screw up: _tì**kxey** si_
    sea: _txam**pay**_
    second (number two) _**mu**ve_. (short time) _**hì**krr_. (look also under 'moment')
    see: (physical sense) _tse**'a**_. See (spiritual sense) _**ka**me_. see you soon: _kìye**va**me_.
    seed: _ri**na'**_. (of Hometree) _atoki**ri**na'._
    seek: _fwew_
    seem: _lam_
    selfishness: _tì**'aw**po_
    send: _fpe'_
    sense (v) _**'e**fu_
    serve: _kìte**'e** si_
    service: _kìte**'e**_
    seven: _**ki**nä_
    seventeen (octal: 21) _mevo**law**_
    seventeenth (number seventeen) _mevo**law**ve_
    seventh (number seven) _**ki**ve_
    seventy (approx.) _zam vol_
    shaman: _**tsa**hìk_
    sharp: _pxi_
    she: _po, po**e**_
    shelter (v) _**haw**nu_
    shoot: (intrans.) _tem_. (trans.) _tol**tem**_.
    short (of time) _yol_
    show (v) _wìn**txu**_
    shut: (adj) _tstu_. (v) _tstu si_.
    sibling: _tsmuk, **tsmuk**tu_
    sick: _spxin_
    sickness: (disease) _sä**spxin**_. (state of being sick) _tì**spxin**_.
    side: _**pa**'o_
    sign, omen: _a**u**ngia_
    silence: _tì**fnu**_
    simple: _**ftu**e_
    sing: _rol_. singing (instance of): _tìru**sol**_. (art) _**tse**o tìru**so**lä_.
    sister: _**tsmu**ke, tsmuk_
    sit: _heyn_
    six: _**pu**kap_
    sixteen (octal: 20) _**me**vol_
    sixteenth (number sixteen) _**me**volve_
    sixth (number six) _**pu**ve_
    sixty (approx.) _zam_
    size: _tsawl**hì'**_
    skin (n) _**ta'**leng_
    sky: _taw_
    sleep (v) _**ha**haw_. sleep well! _hi**va**haw nìm**wey**_.
    slow: _kì**'ong**_
    slowly: _nìk**'ong**_
    small: (little in size) _**hì**'i_. (small in quantity) _hìm_. (a small amount) _'it_.
    smart: (person) _**ka**nu_. (idea, plan) _sìl**ron**sem_.
    smell (n) _fa**hew**_
    smile: (n) _**lrr**tok_. (v) _**lrr**tok si_.
    smoke (n) _**kxe**ner_
    so: (in that case) _ha_. even so _tsalsu**ngay**_. so much: _fì**txan**_. so that: _fte_. so that not: _**fte**ke_.
    soft: (of an object) _**hew**ne_. (of a sound) _**'a**ngo_.
    some: _-o_. someone: _**tu**teo_. something: _**'u**o_. somewhere: _**tseng**o_.
    son: _**'i**tan_
    song: _tì**rol**, way_
    songchord: _**way**telem_
    soon: _**ye'**rìn_. See you soon: _kìye**va**me_.
    sorry! _ngay**txo**a_
    soul: _vit**ra**_
    sound (n) _pam_
    source: _tsim_
    spaceship: _**taw**sìp_
    spark (n) _**txep**vi_
    speak: _pll**txe**_
    spear (n) _tuk**ru**_
    spin (v) _kìm_
    spiral (n) _'ì**he**yu_
    spirit: _ti**re**a_
    spirit animal: _ti**re**ai**o**ang_
    spirit path: _ti**re**a**fya**'o_
    spread, proliferate: _vi**rä**_
    squad: _**wem**pongu_
    squirt (v) _tsä'_
    Stairway to Heaven: _**ik**ni**ma**ya_
    stand (v) _kll**kxem**_
    star: _tan**hì**_
    start: (intrans.) _**sngä**'i_. (start something) _sngey**kä**'i_.
    stay: _'ì**'awn**_
    still: (yet) _vay **set**_. (as before) _mi_.
    sting (v) _sngap_
    stingbat (flying animal): _**ri**ti_
    stomach (n) _ngäng_
    stone (n) _tskxe_
    stop: (v) _ftang_. (suspend action) _fpak_.
    stopping: _tì**ftang**_. without stopping: _nìlke**ftang**_.
    story, tale: _vur_
    straight: (not crooked) _yey_. (upright) _pxim_.
    strange: (unfamiliar) _stxong_. (odd) _**hi**yìk_.
    stream: _**pay**fya_
    strength: _tì**txur**_
    strike, blow (n) _tì**ta**kuk_
    strike, hit (v) _**ta**kuk_
    stringed instrument: _**i'**en_
    strong: _txur_
    student: _**nu**meyu_
    study: (v) _fti**a**_. (n) _tìfti**a**._
    stupid: _**snu**mìna_
    sturmbeast (animal like cattle) _**tal**i**o**ang_
    subject (n) _**txe**le_
    succeed: _flä_
    such: (adj) _nafì'u_; _tsafnel, fìfnel_ \+ genitive; _tsafne-, fìfne-_ (pl. _tsayfne-, fayfne-_). such as: _pxel_.
    suffice: _tam_
    sufficient: _le**tam**_
    summary: _**vur**vi_
    sun: _**tsaw**ke_. sunrise: (see dawn). sunset: (see dusk).
    Sunday (Earth calendar) _trr**'aw**ve_
    supplies: _**mek**re_
    sustain: _fmal_
    sweet: _ka**lin**_
    swoop (v) _tawng_
    synopsis: _**vur**vi_

## T

    tail: _**kxe**tse_
    take: _**mu**nge_. take time: _krr**nekx**_.
    tale: _vur_
    tall: _tsawl_
    target (n) _tì**kan**_
    teach: _kar_
    teacher: _**kar**yu_
    teaching: _sä**nu**me_
    tell: _peng_
    ten (octal: 12) _vo**mun**_
    tenth (number ten) _vo**mu**ve_
    territory: _kll**pxìl**tu_
    test: (v) _**fme**tok_. (n) _tì**fme**tok_.
    than: _to_. than all: _**fra**to_.
    Thanator (animal like a panther): _**pa**lu**lu**kan_
    thank: _i**ra**yo si_. Thank you!: _i**ra**yo!_
    that: _tsa-_. (that thing) _**tsa**'u, tsaw_. (that action) _**tsa**kem, tsa**kem**_. that one (that person) _**tsa**tu_. that way: _**tsa**fya_. that kind of: _tsafnel_ \+ genitive, _tsafne-_.
    that (conjunction) _tsnì_. (as for that) _**fu**ria_. (as object) _**fu**ta_. (as subject) _fwa_. (which, with a noun) _a + N, N + a_.
    their: (animate) _**fe**yä_. (inanimate) _**se**yä_.
    them (animate): (acc) _fot, **fo**ti_. (dat) _for, **fo**ru_. (after prep.) _fo_.
    them (inanimate): (acc) _sat, **sa**ti_. (dat) _sar, **sa**ru_.
    then: _tsa**krr**_
    there: _**tsa**tseng, tsa**tseng**_. out there: _kä**sa**tseng_. There there!: _tam tam_.
    therefore: _ta**fral**_
    these: _fay+_. these kinds of: _fayfnel_ \+ genitive, _fayfne-_.
    they (animate): _**ay**fo, ay**fo**_, _fo_. (those two) _**me**fo_. (those three) _**pxe**fo_.
    they (inanimate): _(ay)sa'u, (ay)saw_. (those two) _mesa'u, mesaw_. (those three) _pxesa'u, pxesaw_. [stress?]
    "they" (unspecified agent, 'one', 'you') _fko_.
    thing: (object, fact, abstraction) _'u_. (action) _kem_.
    think: _fpìl_
    thinking (way of thinking) _**fpìl**fya_
    third (number three) _**pxey**ve_
    thirteen (octal: 15) _vo**mrr**_
    thirteenth (number thirteen) _vo**mrr**ve_
    thirty (approx.) _**tsì**vol_
    this: (with a noun) _fì-_. (action) _fì**kem**_. (thing) _fì**'u**_. (one) _**fì**po_. this way: _fì**fya**_. this kind of: _fìfnel_ \+ genitive, _fìfne-_. this morning: fì**re**won_. this afternoon:_ fìha'**ngir**_. this evening:_ fì**kaym**_._
    those: _tsay+_. (those things) _**sa**'u_. those kinds of: _tsayfnel_ \+ genitive, _tsayfne-_. (See also 'that', 'they'.)
    thought: _sä**fpìl**_. thought pattern: _**fpìl**fya_.
    thousand: (approx.) _**me**vozam_. four thousand (approx.) _**za**zam_
    thread (n) _kìng_
    three: _pxey_. three hundred (approx.) _**mrr**zam_. three thousand (approx.) _**pu**vozam_. (of other nouns) _pxe+_.
    through: _**kxam**lä_
    throat: _flew_
    throw: _**tsre**'i_
    thunder (sound of) _**kxang**angang!_
    Thursday (Earth calendar) _trr**mrr**ve_
    thus: _fì**fya**, **tsa**fya_
    tie: tie down, fasten: _yän_. tie up, bind: _yìm_.
    time (n) _krr_. take time: _krr**nekx**_. all the time: _**fra**krr_.
    time (adv) _a**lo**, -lo_. 5 times: _a**lo** a**mrr**_. 1 time (once): _**'aw**lo_. 2 times (twice) _**me**lo_. each/every time: _**fra**lo_. at all times: _**fra**krr_. next time: _a**lo** a**hay**_. last time: _a**lo** a**ham**_.
    tired: _ngeyn_
    to: (direction) _ne_. (recipient) _-ur, -ru_. (infinitive) _fte_ [with subjunctive].
    today: _fì**trr**_
    tonight: _fì**txon**_
    toe: _**ven**zek_
    together: _'awsi**teng**_
    tomorrow: _trr**ay**_. tomorrow night: _txo**nay**_. tomorrow morning: _rewo**nay**_. tomorrow afternoon: _ha'ngi**ray**_. tomorrow evening: _kay**may**_.
    tongue: _ftxì_
    too: (as well) _nì**teng**_. (excessively) _nì**hawng**_.
    tooth: _sre'_
    top (n) _**fä**pa_
    torn apart, divided: _ke**'aw**_
    totality: _wotx_
    touch (v) _**'am**pi_
    track, follow: _sutx_
    training: _**tskxe**keng_
    trap (v) _syep_
    travel: _sop_
    treachery: _ka**vuk**_
    tree: _**ut**ral_. Tree of Souls: _Vit**ra**utral_. Tree of Voices: _**Ut**ral Ay**mok**riyä_. Hometree: _Kelutral_. [stress?]
    trip (journey) _tì**sop**_
    true: _ngay_
    truly: _nì**ngay**_
    trunk (of a tree) _**tang**ek_
    truth: _tì**ngay**_
    try (v) _fmi_
    Tuesday (Earth calendar) _trr**pxey**ve_
    tune: be in tune, be aware: _**ka**me_
    turn (v) _mìn_
    turn (n) _a**lo**_. my turn: _a**lo** oeyä_.
    twelfth (number twelve) _vo**sì**ve_
    twelve (octal: 14) _vo**sìng**_
    twentieth (number twenty) _mevo**sì**ve_
    twenty: (exact, octal: 24) _mevo**sìng**_. (approx.) _**me**vol fu **pxe**vol_
    twice: _**me**lo_
    twilight: See 'dusk', 'dawn'.
    two: _**mu**ne_. two hundred (approx.) _**pxe**zam_. two thousand (approx.) _**tsì**vozam_. the two of us: _**mo**e, oeng_ ['weng']. the two of you: _menga_. [stress?] the two of them: _**me**fo, mesa_. (of other nouns) _me+_.
    type, kind: _fnel_. what type? _**fne**pe, pe**fnel**_

## U

    ugly (sight or sound) _vä'_
    unambiguously: _nì**pxi**_
    understand: (a fact) _tslam_. (a person) _**ka**me_.
    understanding: (comprehension) _tì**tslam**_. (wise) _**txan**tslusam_.
    Understood!: _tslo**lam**_
    unequal: _**ke**teng_
    unfamiliar: _stxong_
    unfold: _'ong_
    unfortunately: _nìke**ftxo**_
    unhappy: _ke**ftxo**_
    unhealthy: _kel**fpom**tokx_
    unknown: _stxong_
    unpleasant to the senses: _vä'_
    unquote: _sìk_
    until: _vay**krr**_. until now: _vay **set**_. until then: _tsa**krr**vay_
    up: upward: _ne**fä**_. up among: _fkip_. up to (place, time, or number): _vay_.
    upright: _pxim, nì**pxim**_
    upset (sad) _ke**ftxo**_
    us (excluding you): (acc) _ay**oe**ti_ (_ay**we**ti_). (dat) _ay**oe**ru, ay**oer**_ (_ay**we**ru, ay**wer**_). (after prep.) _ay**o**e_.
    us (including you): multiple forms, including (acc) _aw**nga**ti_. (dat) _aw**nga**ru, aw**ngar**_. (after prep.) _aw**nga**, ay**oeng**_ (_ay**weng**_).
    use (v) _sar_
    useful: _le**sar**_
    using: _fa_

## V

    valid: _ka**ngay**_
    vegetable (food) _fkxen_
    verb: _**kem**lì'u_
    versus: _wä_
    vertical: _pxim_. vertically: _nì**pxim**_.
    very: _nì**txan**_
    via: _ì**lä**+, **ì**lä+_
    village: _tsray_
    violet (flower, approx.) _**se**ze_
    viperwolf: _**nan**tang_
    vision (spiritual) _ä**i**e_
    visit (v) _**frr**fen_
    visitor: _**frr**tu_
    voice (n) _**mok**ri_

## W

    wait, wait for: _pey_
    walk (v) _tì**ran**_
    want: _new_
    war: _tsam_. war party: _**tsam**pongu_.
    warrior: _**tsam**siyu_
    was: _la**mu**, lo**lu**_. wasn't it? _ke**fya** srak? ke**fyak**?_.
    wash: _yur_. (oneself) _yä**pur**_.
    wasp (approx) _zi**ze'**_
    watch: (look at) _nìn_. watch out: _**na**ri si_. watch it! _o**ìsss**!, **tsa**-**hey**!, **wi**ya!, **sa**a!_
    water: _pay_
    way: _**fya**'o_. No way! (vulgar) _**pxa**sìk_. give way: _tìng tseng_. way of thinking: _**fpìl**fya_.
    we (but not you): _ay**o**e_. we two _**mo**e_. we three _**pxo**e_.
    we two (you and I): _oeng_ [weng]. (formal) _**o**he nge**nga**sì_. we, all of us (including you) _aw**nga**, ay**oeng**_
    weak: _meyp_
    weave: _tä**ftxu**_
    weaver: _tä**ftxu**yu_
    Wednesday (Earth calendar) _trr**tsì**ve_
    weep: _**tsngaw**vìk_
    well: (adv) _nìl**tsan**_. as well: _nì**teng**_. (See also 'healthy'.)
    well: (n) _ra**mu**nong_. Well of Souls: _Ayvit**ra**yä Ra**mu**nong_. [stress?]
    well (sentence opener) _tse_
    well-being: _fpom_
    were: _la**mu**, lo**lu**_. weren't they? _ke**fya** srak? ke**fyak**?_.
    what?: (action) _pe**hem**?, **kem**pe?_. (thing) _pe**u**?, **'u**pe?_. (word, utterance) _pe**lì**'u?, lì**'u**pe?_. (what kind?) _**fne**pe, pe**fnel**_. (with other nouns) _pe-, -pe?_. what? you call that a ...? (disparagement) _pak_.
    what a ...! (praise) _nang_.
    when: (not a question) _a krr, krr a_. (if) _txo_.
    when?: _pe**hrr**?, **krr**pe?_
    where?: _pe**seng**?, **tseng**pe?_
    whether: _san **sra**ke, ftxey_
    which?: _pe+, -pe_. which kind? _**fne**pe, pe**fnel**_. which day (of the week, month)? _trr**pe**ve_
    which (not a question) _a + N_
    while: _teng**krr**_ [with the imperfective for the -ing verb]
    white: _teyr_
    who?: _pe**su**?, **tu**pe?_
    whole: (n) _wotx_. (adj) _'än**syem**_.
    why?: _pe**lun**?, **lum**pe?_
    wind (n) _hu**fwe**_
    wing: _tsyal_
    wise: _**txan**tslusam_
    wish (v) _**rang**al_. I wish ...: _nì**rang**al_.
    with: (accompaniment) _hu_. (by means of) _fa_.
    without: _**lu**ke_
    wolf (approx.) _**nan**tang_
    word: _**lì**'u_
    work: (n) _tì**kang**kem_. (v) work: _tì**kang**kem si_.
    world (physical) _ki**fkey**_
    worm: _ngawng_. (hallucinogenic) _**el**tungawng_.
    worst: _**'e**'al_
    worthy: _pxan_
    wow!: _**tew**ti!_
    write: _pam**rel** si_
    writing: _pam**rel**_
    wrong: (incorrect) _ke**yawr**_. (an error) _tì**kxey**_. do wrong: _tì**kxey** si_. you're wrong: _**nga**ru tì**kxey**_

## Y

    yeah: _sran_
    year: _**zì**sìt_
    yellow: _rim_. in yellow: _nì**rim**_.
    yes: _**sra**ne_
    yesterday: _trr**am**_. yesterday night: _txo**nam**_. yesterday morning: _rewo**nam**_. yesterday afternoon: _ha'ngi**ram**_. yesterday evening: _kay**mam**_.
    yet: (still) _mi_. not yet: _vay set_ (with negative verb).
    you (sg.) _nga_. (honorific form) _nge**nga**_. you two: _me**nga**_. you three: _pxe**nga**_. you all: _ay**nga**_. you (unspecified; 'one', 'they') _fko_. [stress?]
    young: _**'e**wan_
    your: _**nge**yä_. (formal) _nge**nge**yä_. [stress?]
    yucky: _vä'_

## Z

    zero: _kew_

## Discourse particles

The following exclamations have no easy translation into English. They stand as a clause of their own:

    of consternation (it can't be!): _a**u**_
    war cry (alala!) _ì**ley**_
    of pity (poor thing!): _ke**ftxo**_
    of anger or annoyance (aargh!) _o**ìsss**_
    vulgar (screw that!) _**pxa**sìk_
    alarm cry; call to defense: _**raw**ke_
    as a threat: _**sa**a_
    upon exertion (oomph!) _sa**u**_
    soothing (there there!) _tam tam_
    of surprise and pleasure (wow!) _**tew**ti_
    of warning or frustration (oy!) _**tsa**-**hey**, **wi**ya_

(See also 'yes', 'no', 'yeah', 'please', 'thank you', 'sorry!', 'forgive me!', 'right?', 'okay', 'understood', 'don't!', 'down!', 'well', 'hello', 'goodbye'.)

The following emotive particles occur at the end of a clause:

    soliciting agreement (Let's X; X, eh?) _ko_
    surprise, exclamation, encouragement (Oh my! What an X!) _nang_
    disparagement (Pshaw! You call that an X?) _pak_

Others help the grammatical flow of discourse:

    direct address (O!) _ma_
    continuation (And you?) _tut_

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&oldid=1742696](http://en.wikibooks.org/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&oldid=1742696)" 

[Category](/wiki/Special:Categories): 

  * [Na'vi](/wiki/Category:Na%27vi)

Hidden categories: 

  * [Books with print version](/wiki/Category:Books_with_print_version)
  * [Books with Public Collections](/wiki/Category:Books_with_Public_Collections)
  * [No references for citations](/wiki/Category:No_references_for_citations)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Na%27vi%2FEnglish-Na%27vi+dictionary%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Na%27vi%2FEnglish-Na%27vi+dictionary%2FPrint+version)

### Namespaces

  * [Book](/wiki/Na%27vi/English-Na%27vi_dictionary/Print_version)
  * [Discussion](/wiki/Talk:Na%27vi/English-Na%27vi_dictionary/Print_version)

### 

### Variants

### Views

  * [Read](/wiki/Na%27vi/English-Na%27vi_dictionary/Print_version)
  * [Edit](/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&action=edit)
  * [View history](/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Na%27vi/English-Na%27vi_dictionary/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Na%27vi/English-Na%27vi_dictionary/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&oldid=1742696)
  * [Page information](/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Na%27vi%2FEnglish-Na%27vi_dictionary%2FPrint_version&id=1742696)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Na%27vi%2FEnglish-Na%27vi+dictionary%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Na%27vi%2FEnglish-Na%27vi+dictionary%2FPrint+version&oldid=1742696&writer=rl)
  * [Printable version](/w/index.php?title=Na%27vi/English-Na%27vi_dictionary/Print_version&printable=yes)

  * This page was last modified on 24 March 2010, at 21:29.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Na%27vi/English-Na%27vi_dictionary/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
