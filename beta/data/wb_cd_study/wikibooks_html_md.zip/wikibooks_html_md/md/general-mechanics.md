# General Mechanics/Print Version

From Wikibooks, open books for an open world

< [General Mechanics](/wiki/General_Mechanics)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=General_Mechanics/Print_Version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=General_Mechanics/Print_Version) on _8 January 2010_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=General_Mechanics/Print_Version&oldid=1693842&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [General Mechanics](/wiki/General_Mechanics)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=General_Mechanics/Print_Version&action=purge&printable=yes) this page.

# Newton's Laws: First principles[[edit](/w/index.php?title=General_Mechanics/Print_Version&action=edit&section=1)]

**[General Mechanics](/wiki/General_Mechanics)**

The fundamental idea of kinematics is the discussion of the movement of objects, without actually taking into account what caused the movement to occur. By using simple calculus, we can find all of the equations for kinematics. To simplify the learning process, we will only consider objects that move with constant acceleration. For the first few parts, we will also assume that there is no friction or air resistance acting on the objects.

# Straight Line Motion (SLM)[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Kinematics&action=edit&section=T-1)]

The name of this section **Straight Line Motion** means that we begin learning about the subject of kinematics by observing motion in one dimension. This means that we will only take one axis of a 3D ![\(x,y,z\)](//upload.wikimedia.org/math/4/b/f/4bf16061f8c120f8adc4ba78f47396a6.png) coordinate system into account. We will be using the ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) axis as our axis of motion.

Throughout our discussion, we will look at the motion of a **rigid body**, one that does not deform as it moves. We idealize the rigid body by assuming that it has no dimensions and is infinitely small. This way we can talk about the entire body instead of saying, "The front of the body is at this point while the rear of the body is at some other point". Also, subscripts on the variables in our equations will indicate the initial value, ![i](//upload.wikimedia.org/math/8/6/5/865c0c0b4ab0e063e5caa3387c1a8741.png), and the final value, ![f](//upload.wikimedia.org/math/8/f/a/8fa14cdd754f91cc6554c9e71929cce7.png), of that variable.

## Displacement[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Kinematics&action=edit&section=T-2)]

To start off with we will define the term **displacement**. Displacement is basically the shortest route of getting from one place to another, basically it is a straight line from the starting point of motion to the ending point of motion. No matter how much movement takes place in between and what sort of things come inbetween, we only care about the first location and the second location. We will use the variable, ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png), to stand for the locations of the rigid body that we are discussing. It is a vector quantity i.e. it has both magnitude and direction, if we want to define displacement for some movement then it would be like - '50 km due North'.

In order to define motion we first must be able to say how far an object has moved. This is done by subtracting the final value of the displacement by the initial value of the displacement. Or, in other words, we subtract the initial position of the object on our coordinate system from the final position of the object on our coordinate system. It is necessary to understand that the values which you receive for this variable can be either positive or negative depending on how the object is moving and where your coordinates start:

    ![x=x_f-x_i\\,\\!](//upload.wikimedia.org/math/0/c/f/0cf3c86ee0ef504724a8c9210c5fc8ad.png)

## Velocity[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Kinematics&action=edit&section=T-3)]

The term **velocity**, ![v](//upload.wikimedia.org/math/9/e/3/9e3669d19b675bd57058fd4664205d2a.png), is often mistaken as being equivalent to the term **speed**. The basic difference between speed and velocity is that, velocity is a vector quantity, whereas speed is a scalar quantity. The term **velocity** refers to the displacement that an object traveled divided by the amount of time it took to move to its new coordinate. From the above discussion you can see that if the object moves backwards with respect to our coordinate system, then we will get a negative displacement. Since we cannot have a negative value for time, we will then get a negative value for velocity( Here the negative sign shows that the body has moved in the backward direction to the coordinates system adopted). The term **speed**, on the other hand refers to the magnitude of the velocity, so that it can only be a positive value. We will not be considering speed in this discussion, only velocity. By using our definition of velocity and the definition of displacement from above, we can express velocity mathematically like this:

    ![\\bar v={\(x_f-x_i\) \\over \(t_f-t_i\)}](//upload.wikimedia.org/math/9/d/8/9d8c292b5922a84641cf8c45f9158408.png)

The line over the velocity means that you are finding the average velocity, not the velocity at a specific point. This equation can be rearranged in a variety of ways in order to solve problems in physics dealing with SLM. Also, by having acceleration as a constant value, we can find the average velocity of an object if we are given the initial and final values of an object's velocity:

    ![\\bar v={\(v_f+v_i\) \\over 2}](//upload.wikimedia.org/math/1/7/d/17daa62fc19042f17c232fbfc2873032.png)

These equations can be combined with the other equations to give useful relationships in order to solve straight line motion problems. For example, to find the initial position of an object, if we are given its final position and the times that the object began moving and finished moving, we can rearrange the equation like this:

    ![x_i=x_f-\\bar v\(t_f-t_i\)\\,\\!](//upload.wikimedia.org/math/d/c/c/dcc5ffc99cd1d755708cbc2b0eab4005.png)

## Acceleration[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Kinematics&action=edit&section=T-4)]

The term **acceleration** means the change in velocity of an object per unit time. It is a vector quantity. We use the variable, ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png), to stand for acceleration. Basically, the sign of acceleration tells us whether the velocity is increasing or decreasing, and its magnitude tells us how much the velocity is changing. In order for an object that is initially at rest to move, it needs to accelerate to a certain speed. During this acceleration, the object moves at a certain velocity at a specific time, and travels a certain distance within that time. Thus, we can describe acceleration mathematically like this:

    ![a={\(v_f-v_i\) \\over \(t_f-t_i\)}](//upload.wikimedia.org/math/8/6/7/86742a1176bda0b5c01cf29c523001c4.png)

Again, we can rearrange our formula, this time using our definition for displacement and velocity, to get a very useful relationship:

    ![x_f=x_i+v_i\(t_f-t_i\)+{1 \\over 2}a\(t_f-t_i\)^2](//upload.wikimedia.org/math/3/6/0/36088017b20f578dc81d305ffb60147f.png)

**[General Mechanics](/wiki/General_Mechanics)**

## History of Dynamics[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Dynamics&action=edit&section=T-1)]

### Aristotle[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Dynamics&action=edit&section=T-2)]

Aristotle expounded a view of dynamics which agrees closely with our everyday experience of the world. Objects only move when a force is exerted upon them. As soon as the force goes away, the object stops moving. The act of pushing a box across the floor illustrates this principle -- the box certainly doesn't move by itself!

However, if we try using Aristotle's dynamics to predict motion we soon run into problems. It suggests that objects under a constant force move with a fixed velocity but while gravity definitely feels like a constant force it clearly doesn't make objects move with constant velocity. A thrown ball can even reverse direction, under the influence of gravity alone.

Eventually, people started looking for a view of dynamics that actually worked. Newton found the answer, partially inspired by the heavens.

### Newton[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Dynamics&action=edit&section=T-3)]

In contrast to earthly behavior, the motions of celestial objects seem effortless. No obvious forces act to keep the planets in motion around the sun. In fact, it appears that celestial objects simply coast along at constant velocity unless something acts on them.

This Newtonian view of dynamics — objects change their velocity rather than their position when a force is exerted on them — is expressed by Newton's second law:

    ![\\mathbf{F}=m\\mathbf{a}](//upload.wikimedia.org/math/7/e/8/7e8eeee0c85073d8a25eb9a28f1005cf.png)

where **F** is the force exerted on a body, _m_ is its mass, and **a** is its acceleration. Newton's first law, which states that an object remains at rest or in uniform motion unless a force acts on it, is actually a special case of Newton's second law which applies when **F**=0.

It is no wonder that the first successes of Newtonian mechanics were in the celestial realm, namely in the predictions of planetary orbits. It took Newton's genius to realize that the same principles which guided the planets also applied to the earthly realm as well.

In the Newtonian view, the tendency of objects to stop when we stop pushing on them is simply a consequence of frictional forces opposing the motion. Friction, which is so important on the earth, is negligible for planetary motions, which is why Newtonian dynamics is more obviously valid for celestial bodies.

Note that the principle of relativity is closely related to Newtonian physics and is incompatible with pre-Newtonian views. After all, two reference frames moving relative to each other cannot be equivalent in the pre-Newtonian view, because objects with nothing pushing on them can only come to rest in one of the two reference frames!

Einstein's relativity is often viewed as a repudiation of Newton, but this is far from the truth — Newtonian physics makes the theory of relativity possible through its invention of the principle of relativity. Compared with the differences between pre-Newtonian and Newtonian dynamics, the changes needed to go from Newtonian to Einsteinian physics constitute minor tinkering.

## Newton's 3 Laws of Motion[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Dynamics&action=edit&section=T-4)]

## **Newton's first law:**[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Dynamics&action=edit&section=T-5)]

"An object at rest tends to stay at rest and an object in motion tends to stay in motion with the same speed and in the same direction unless acted upon by an external force". He gave this law assuming the body or the system to be isolated. If we look upon into our daily life we finds that this law is not applicable in reality like a bicycle stops when we stop paddling, this is because in our daily life there are 2 external forces which opposes the motion, these are frictional force and air resistance( These force aren't included in the course of an isolated system). But if these two forces are absent the above law is applicable, this can be observed in space.

## **Newton's second law:**[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Dynamics&action=edit&section=T-6)]

Newton's second law of motion states, "The rate change of linear momentum of an object is directly proportional to the external force on the object." The concept behind this is - "Forces arises due to interaction between the bodies." With the help of this law we can derive this formula:
    
    
    **F = ma**
    

In this formula, **F** means the force exerted on the object, **m** means the mass of the object, and **a** means the acceleration of the object. Also the second law of motion is universal law in nature, i.e. it consists of both the laws. Newton assumed the body to be an isolated one, thus according to second law, if there is no interaction between bodies of two different systems( means not to be an isolated one), then there is no force that can stop or shake the object from it's state of being. Suppose two bodies are interacting with each other, then each of them would be exerting force on the other( Look from each side and apply second law of motion), it is third law.

## **Newton's third law:**[[edit](/w/index.php?title=General_Mechanics/Fundamental_Principles_of_Dynamics&action=edit&section=T-7)]

"Every action has an equal and opposite reaction" This means if body A exerts a force on body B, then body B exerts a force on body A that is equal in magnitude but opposite in direction from the force from A.

**FAB = - FBA** Force on B due to A = Force on A due to B

  * Negative sign shows that the force is in opposite direction.

**[General Mechanics](/wiki/General_Mechanics)**

## Work[[edit](/w/index.php?title=General_Mechanics/Work_and_Power&action=edit&section=T-1)]

When a force is exerted on an object, energy is transferred to the object. The amount of energy transferred is called the work done on the object. Mathematically work done is defined as the dot\scalar product of force and displacement, thus it is a scalar quantity. However, energy is only transferred if the object moves. Work can be thought of as the process of transforming energy from one form into another. The work _W_ done is

    ![	W=F\\Delta x](//upload.wikimedia.org/math/a/0/4/a046cba249171387a324d4f8dd596185.png)

where the distance moved by the object is Δ_x_ and the force exerted on it is _F_. Notice that work can either be positive or negative. The work is positive if the object being acted upon moves in the same direction as the force, with negative work occurring if the object moves opposite to the force.

This equation assumes that the force remains constant over the full displacement or distance( depending on the situation). If it is not, then it is necessary to break up the displacement into a number of smaller displacements, over each of which the force can be assumed to be constant. The total work is then the sum of the works associated with each small displacement. In the infinitesimal limit this becomes an integral

    ![W=\\int F\(s\)\\,ds](//upload.wikimedia.org/math/1/f/3/1f30495c1bbfcceef73fc752da59cd65.png)

If more than one force acts on an object, the works due to the different forces each add or subtract energy, depending on whether they are positive or negative. The total work is the sum of these individual works.

There are two special cases in which the work done on an object is related to other quantities. If _F_ is the total force acting on the object, then by Newton's second law _W_=_F_Δ_x_=_m_Δ_x_·_a_ . However, _a_=_dv_/_dt_ where _v_ is the velocity of the object, and Δ_x_≈vΔ_t_, where Δ_t_ is the time required by the object to move through distance Δ_x_ . The approximation becomes exact when Δ_x_ and Δ_t_ become very small. Putting all of this together results in

    ![W_{total}=m\\frac{dv}{dt}v\\Delta t=\\Delta t \\frac{d}{dt} \\frac{mv^2}{2}](//upload.wikimedia.org/math/8/3/c/83ccf1812325fd6bd5ae8a7af5d9e85c.png)

We call the quantity _mv_2/2 the _kinetic energy_, or _K_. It represents the amount of work stored as motion. We can then say

    ![W_{total}=\\frac{dK}{dt}\\Delta t=\\Delta K](//upload.wikimedia.org/math/d/1/3/d13dae0106b757114bf1f1a82f636c50.png)

Thus, when _F_ is the only force, the total work on the object equals the change in kinetic energy of the object. This transformation is known as "Work-Energy theorem."

The other special case occurs when the force depends only on position, but is not necessarily the total force acting on the object. In this case we can define a function

    ![V\(x\)=-\\int^x F\(s\)\\,ds](//upload.wikimedia.org/math/e/3/3/e33406842f3e8a1d94db499600626bb7.png)

and the work done by the force in moving from _x_1 to _x_2 is _V_(_x_1)-_V_(_x_2), no matter how quickly or slowly the object moved.

If the force is like this it is called _conservative_ and _V_ is called the potential energy. Differentiating the definition gives

    ![F=-\\frac{dV}{dx}](//upload.wikimedia.org/math/c/a/4/ca45c2a04a2a39a8a712d720c4f13cb7.png)

The minus sign in these equations is purely conventional.

If a force is conservative( The force whose effect doesn't depend on the path it has taken to go through), we can write the work done by it as

    ![W=-\\frac{dV}{dx}\\Delta x= -\\Delta V](//upload.wikimedia.org/math/8/9/b/89b3d1d143f17ce7099d9533d0c17170.png)

where is the change in the potential energy of the object associated with the force of interest.

## Energy[[edit](/w/index.php?title=General_Mechanics/Work_and_Power&action=edit&section=T-2)]

The sum of the _potential_( Energy by virtue of its position) and _kinetic_(Energy by virtue of its motion) energies is constant. We call this constant the total energy _E_:

    ![E = K + U](//upload.wikimedia.org/math/5/b/4/5b4faeae6be42a1e7a0efb77f979e1c6.png)

If all the forces involved are conservative we can equate this with the previous expression for work to get the following relationship between work, kinetic energy, and potential energy:

    ![\\Delta K = W = -\\Delta U](//upload.wikimedia.org/math/6/7/d/67d004dcef2ca442fde3d8e7ce6bf84b.png)

Following this, we have a very important formula, called the '_Conservation of Energy_:

    ![\\Delta\(K+U\)=0](//upload.wikimedia.org/math/1/e/4/1e4c584508debe05d470a41cff131251.png)

This theorem states that the total amount of energy in a system is constant, and that energy can neither be created nor destroyed.

## Power[[edit](/w/index.php?title=General_Mechanics/Work_and_Power&action=edit&section=T-3)]

The power associated with a force is simply the amount of work done by the force divided by the time interval over which it is done. It is therefore the energy per unit time transferred to the object by the force of interest. From above we see that the power is

    ![P=\\frac{F \\Delta x}{\\Delta t}=Fv](//upload.wikimedia.org/math/5/7/1/5717410a9ca254b98329be5c8ba3f709.png)

where is the velocity at which the object is moving. The total power is just the sum of the powers associated with each force. It equals the time rate of change of kinetic energy of the object:

    ![P_{total}=\\frac{W_{total}}{\\Delta t}=\\frac{dK}{dt}](//upload.wikimedia.org/math/3/d/b/3db15ff0d5eea88111835522df452fa4.png)

**[General Mechanics](/wiki/General_Mechanics)**

We will now take a break from physics, and discuss the topics of partial derivatives. Further information about this topic can be found at the [Partial Differential Section](/wiki/Calculus/Partial_differential_equations) in the [Calculus](/wiki/Calculus) book.

## Partial Derivatives[[edit](/w/index.php?title=General_Mechanics/Partial_Derivatives&action=edit&section=T-1)]

In one dimension, the slope of a function, _f_(_x_), is described by a single number, _df/dx_.

In higher dimensions, the slope depends on the direction. For example, if _f_=_x_+2_y_, moving one unit _x_-ward increases _f_ by 1 so the slope in the _x_ direction is 1, but moving one unit _y_-ward increases _f_ by 2 so the slope in the _y_ direction is 2.

It turns out that we can describe the slope in _n_ dimensions with just _n_ numbers, the _partial derivatives_ of _f_.

To calculate them, we differentiate with respect to one coordinate, while holding all the others constant. They are written using a ∂ rather than _d_. E.g.

    ![f\(x+dx,y,z\)=f\(x,y,z\)+\\frac{\\partial f}{\\partial x}dx \\quad \(1\)](//upload.wikimedia.org/math/1/d/c/1dc791a6ab3cf5c18113c938ebaecdac.png)

Notice this is almost the same as the definition of the ordinary derivative.

If we move a small distance in each direction, we can combine three equations like 1 to get

    ![df= \\frac{\\partial f}{\\partial x}dx + \\frac{\\partial f}{\\partial y}dy + \\frac{\\partial f}{\\partial z}dz](//upload.wikimedia.org/math/6/8/9/6897990ff90850f7be1a51dde5b6a1a1.png)

The change in _f_ after a small displacement is the dot product of the displacement and a special vector

    ![\\left\( \\frac{\\partial f}{\\partial x}, \\frac{\\partial f}{\\partial y}, \\frac{\\partial f}{\\partial z} \\right\) \\cdot \\left\( dx, dy, dz \\right\)
=\\operatorname{grad} f = \\nabla f  ](//upload.wikimedia.org/math/1/d/f/1dff0d8626f17f0b72e9c5589fd95265.png)

This vector is called the gradient of _f_. It points up the direction of steepest slope. We will be using this vector quite frequently.

### Partial Derivatives #2[[edit](/w/index.php?title=General_Mechanics/Partial_Derivatives&action=edit&section=T-2)]

Another way to approach differentiation of multiple-variable functions can be found in Feynman Lectures on Physics vol. 2. It's like this:

The differentiation operator is defined like this: ![df = f\(x + \\Delta x, y + \\Delta y, z + \\Delta z\) - f\(x,y,z\)\\,\\!](//upload.wikimedia.org/math/b/7/e/b7e1038e914a59db90e8365008648c1c.png) in the limit of ![\\Delta x, \\Delta y, \\Delta z \\to 0](//upload.wikimedia.org/math/d/0/7/d07d5e43d2201bd0994cc7a0d91b7594.png). Adding & subtracting some terms, we get

![df = \(f\(x + \\Delta x, y + \\Delta y, z + \\Delta z\) - f\(x, y + \\Delta y, z + \\Delta z\)\) + \(f\(x, y + \\Delta y, z + \\Delta z\) - f\(x, y, z + \\Delta z\)\) + \(f\(x, y, z + \\Delta z\) - f\(x,y,z\)\)\\,\\!](//upload.wikimedia.org/math/9/a/9/9a9bc3d5564a755e29453538cec0389f.png)

and this can also be written as

    ![df = \\frac{\\partial f}{\\partial x}dx + \\frac{\\partial f}{\\partial y}dy + \\frac{\\partial f}{\\partial z}dz](//upload.wikimedia.org/math/6/8/9/6897990ff90850f7be1a51dde5b6a1a1.png)

### Alternate Notations[[edit](/w/index.php?title=General_Mechanics/Partial_Derivatives&action=edit&section=T-3)]

For simplicity, we will often use various standard abbreviations, so we can write most of the formulae on one line. This can make it easier to see the important details.

We can abbreviate partial differentials with a subscript, e.g.,

    ![D_x h\(x,y\)= \\frac{\\partial h}{\\partial x} 
\\quad D_x D_y h= D_y D_x h](//upload.wikimedia.org/math/7/9/f/79fa7a5cb5c1a2f36dd327ac1d91d513.png)

or

    ![\\partial_x h= \\frac{\\partial h}{\\partial x} ](//upload.wikimedia.org/math/b/1/7/b1739fc6c87732f1fc9cff4e4c68dbd9.png)

Mostly, to make the formulae even more compact, we will put the subscript on the function itself.

    ![D_x h= h_x \\quad h_{xy}=h_{yx}](//upload.wikimedia.org/math/b/b/d/bbd7eb07ac1ce16621a763af96b0e508.png)

## More Info[[edit](/w/index.php?title=General_Mechanics/Partial_Derivatives&action=edit&section=T-4)]

Refer to the [Partial Differential Section](/wiki/Calculus/Partial_differential_equations) in the [Calculus](/wiki/Calculus) book for more information.

**[General Mechanics](/wiki/General_Mechanics)**

## Motion in 2 and 3 Directions[[edit](/w/index.php?title=General_Mechanics/Motion_in_Two_and_Three_Dimensions&action=edit&section=T-1)]

Previously, we discussed Newtonian dynamics in one dimension. Now that we are familiar with both vectors and partial differentiation, we can extend that discussion to two or three dimensions.

Work becomes a dot product

    ![W=\\mathbf{F}\\cdot \\Delta x](//upload.wikimedia.org/math/4/9/8/498f00c1deb444ca9586e08b03f6dbdc.png)

and likewise power

    ![P=\\mathbf{F}\\cdot \\mathbf{v}](//upload.wikimedia.org/math/6/3/0/6302fde191c039b9373550be61dc76dc.png)

If the force is at right angles to the direction of motion, no work will be done.

In one dimension, we said a force was conservative if it was a function of position alone, or equivalently, the negative slope of a potential energy.

The second definition extends to

    ![\\mathbf{F}=-\\nabla V](//upload.wikimedia.org/math/6/a/2/6a2bf6b30c306427cb19a2e8b3fac19f.png)

In two or more dimensions, these are not equivalent statements. To see this, consider

    ![D_y\\mathbf{F}_x-D_x\\mathbf{F}_y=V_{xy}-V_{yx}](//upload.wikimedia.org/math/7/6/f/76fa778d444d011226625494f1b665bc.png)

Since it doesn't matter which order derivatives are taken in, the left hand side of this equation must be zero for any force which can be written as a gradient, but for an arbitrary force, depending only on position, such as **F**=(_y_, -_x_, 0), the left hand side isn't zero.

Conservative forces are useful because the total work done by them depends only on the difference in potential energy at the endpoints, not on the path taken, from which the conservation of energy immediately follows.

If this is the case, the work done by an infinitesimal displacement _d_**x** must be

    ![W=V\(\\mathbf{x}\)-V\(\\mathbf{x}+d\\mathbf{x}\)=-\(\\nabla V\)\\cdot d\\mathbf{x}](//upload.wikimedia.org/math/f/f/6/ff6018b03616324f41d55abd592b238e.png)

Comparing this with the first equation above, we see that if we have a potential energy then we must have

    ![\\mathbf{F}=-\\nabla V](//upload.wikimedia.org/math/6/a/2/6a2bf6b30c306427cb19a2e8b3fac19f.png)

Any such **F** is a conservative force.

## Circular Motion[[edit](/w/index.php?title=General_Mechanics/Motion_in_Two_and_Three_Dimensions&action=edit&section=T-2)]

An important example of motion in two dimensions is circular motion.

Consider a mass, _m_, moving in a circle, radius _r_.

The _angular velocity_, ω is the rate of change of angle with time. In time Δ_t_ the mass moves through an angle Δθ= ωΔ_t_. The distance the mass moves is then _r_ sin Δθ, but this is approximately _r_Δθ for small angles.

Thus, the distance moved in a small time Δ_t_ is _r_ωΔ_t_, and divided by Δ_t_ gives us the speed, _v_.

    ![v = \\omega r \\, ](//upload.wikimedia.org/math/4/9/1/491a86c1e2d1fe9171cb4540cee75ad4.png)

This is the _speed_ not the _velocity_ because it is not a vector. The velocity is a vector, with magnitude ω_r_ which points tangentially to the circle.

The magnitude of the velocity is constant but its direction changes so the mass is being accelerated.

By a similar argument to that above it can be shown that the magnitude of the acceleration is

    ![a = \\omega v \\, ](//upload.wikimedia.org/math/4/5/a/45a2b3959807efd82e975da067937b49.png)

and that it is pointed inwards, along the radius vector. This is called _centripetal_ acceleration.

By eliminating _v_ or ω from these two equations we can write

    ![\\mathbf{a}= -\\omega^2 \\mathbf{r} = -\\frac{v^2}{r}\\mathbf{ \\hat{ r}}
](//upload.wikimedia.org/math/a/b/a/aba82c69e6dac91e437cc50c8494cce6.png)

Year 10 Force and Work 7 periods

  * Possible Approach:
  * Lesson Suggested Learning Outcomes Course Outline Resources
  * 1 – 3  Recognise that unbalanced forces cause acceleration.
  *  Investigate the relationship between the unbalanced force acting on an object, is mass *and acceleration: Newton’s Second Law. (Use Fnet = ma giving correct units for all quantities)

•**Reinforce ideas about force causing acceleration (= the rate at which speed changes)

  * Experiment 1: Finding the force required to move an object (static friction)
  * Discuss the factors that may affect the frictional forces acting on the block (e.g. load on *the block, surface area in contact with the bench, type of the surfaces in contact …)
  * Attach a force meter to a block at rest on the bench. Pull the force meter and slowly increase *the force until the block just begins to move – record the force meter reading, tabulate data, *repeat, calculate average.
  * [Or, use a bag to which washers may be added, attached to a cord and hanging over the end of *the bench to pull the block.]
  * quantities and the third unknown) – a three symbol triangle may simplify the maths.
  *     *       *         *           *             * Homework: Coursebook – Newton’s second Law
            * force (e.g. when a force acts on a body, it moves faster and kinetic energy increases)
            * • Introduce the relationship between energy transferred and work done.
            * • Define work done in terms of the applied force and the distance through which this ********force acts (Work done = force x distance)
  *     *       *         *           *             * • Use the work rule to calculate work / force / distance (given two quantities and the ********third unknown) – a three symbol triangle may simplify the maths
  *     *       *         *           *             * Homework: Coursebook – Work Done and Energy
  *     *       *         *           *             *               * 6 – 7  Investigate and describe the pattern of results formed from graphing ************************the effects of applied forces on a spring.
  * Explore the relationships between science and technology by investigating the application of *science to technology and the impact of technology on science, e.g. Archimedes’ screw to *illustrate the principle of oits use in water irrigation or the use of springs and similar *propulsion devices in toys
  * Experiment 4: Stretching Springs
  * Hang a spring vertically using a clamp and stand. Add weights to the end of the spring, *measure the length of the spring after each additional weight is added. Calculate the *extension (Note: some initial weight will probably need to be added before the spring *stretches at all) Graph extension vs applied force. Interpret the graph, e.g. find the *extension for unit applied force or applied force per unit extension.
  *     *       *         *           *             *               *                 * Investigate and understand the turning effect of a force.
                * Calculate the turning effect of a force = F x d where force (F) and distance (d) are *********at right angles.
                * Use the lever rule: F1d1 = F2d2 •
  * Discuss and brainstorm ideas about what causes things to turn about a pivot (fulcrum). 
    *       *         *           *             * • Introduce the concept of the turning effect of a force (torque).
            * • Discuss the concept levers – to increase the turning effect, use a greater distance *******(e.g. a long crowbar) and/or a greater force (e.g. a heavier weight)
            * • Use the lever rule to calculate forces and distances at right angles to the applied ********force (given three quantities and the fourth unknown).
  * Experiment 5: The turning effect of a force
  * Kit available from the science Office 
    *       *         *           *             * • Homework: Coursebook – The Turning Effect of a Force
  * Extension

**[General Mechanics](/wiki/General_Mechanics)**

## Changing mass[[edit](/w/index.php?title=General_Mechanics/Momentum&action=edit&section=T-1)]

So far we've assumed that the mass of the objects being considered is constant, which is not always true. Mass is conserved overall, but it can be useful to consider objects, such as rockets, which are losing or gaining mass.

We can work out how to extend Newton's second law to this situation by considering a rocket two ways, as a single object of variable mass, and as two objects of fixed mass which are being pushed apart.

  
We find that

    ![\\mathbf{F} =  \\frac{d\(m \\mathbf{v}\)}{dt}](//upload.wikimedia.org/math/4/1/0/410b166664ba7d9a68e1bdb692a919e6.png)

Force is the rate of change of a quantity, _m_**v**, which we call _linear momentum_.

## Newton's third law[[edit](/w/index.php?title=General_Mechanics/Momentum&action=edit&section=T-2)]

Newton's third law says that the force, **F**12 exerted by a mass, _m_1, on a second mass, _m_2, is equal and opposite to the force **F**21 exerted by the second mass on the first.

    ![\\frac{d\(m_2\\mathbf{v}_2\)}{dt}= \\mathbf{F}_{12}= - \\mathbf{F}_{21} 
=  -\\frac{d\(m_1 \\mathbf{v}_1\)}{dt}](//upload.wikimedia.org/math/d/0/8/d08f3aba92cbd6c4a7f1ae8c4f42927e.png)

if there are no external forces on the two bodies. We can add the two momenta together to get,

    ![\\frac{d\(m_1\\mathbf{v}_1\)}{dt}+\\frac{d\(m_2 \\mathbf{v}_2\)}{dt}
=\\frac{d}{dt}\(m_1\\mathbf{v}_1+m_2\\mathbf{v}_2\)=0](//upload.wikimedia.org/math/2/6/d/26de4cf40d4d32db083e53ba7737d771.png)

so the total linear momentum is conserved.

Ultimately, this is consequence of space being homogeneous.

## Centre of mass[[edit](/w/index.php?title=General_Mechanics/Momentum&action=edit&section=T-3)]

Suppose two constant masses are subject to external forces, **F**1, and **F**2

Then the total force on the system, **F**, is

    ![\\mathbf{F}= \\mathbf{F}_{1}+\\mathbf{F}_{2} =
\\frac{d}{dt}\(m_1\\mathbf{v}_1+m_2\\mathbf{v}_2\)](//upload.wikimedia.org/math/7/d/9/7d9aa60e74970bab548785cdb0f0355a.png)

because the internal forces cancel out.

If the two masses are considered as one system, **F** should be the product of the total mass and _ā_, the average acceleration, which we expect to be related to some kind of average position.

    ![\\begin{matrix}\(m_1+m_2\)\\bar{a} & = & \\frac{d}{dt}\(m_1\\mathbf{v}_1+m_2\\mathbf{v}_2\) \\\\
& = & \\frac{d^2}{dt^2}\(m_1\\mathbf{r}_1+m_2\\mathbf{r}_2\)\\\\
\\bar{a}& = & \\frac{d^2}{dt^2} \\frac{m_1\\mathbf{r}_1+m_2\\mathbf{r}_2}{m_1+m_2}\\\\
\\end{matrix}](//upload.wikimedia.org/math/c/4/3/c43f8e3f75485436256d594249e45b62.png)

The average acceleration is the second derivative of the average position, _weighted by mass_.

This average position is called the _centre of mass_, and accelerates at the same rate as if it had the total mass of the system, and were subject to the total force.

We can extend this to any number of masses under arbitrary external and internal forces.

  * we have _n_ objects, mass _m_1, _m_2 … _m__n_, total mass _M_
  * each mass _m__i_ is at point **r**i,
  * each mass _m_i is subject to an external force **F**_i_
  * the internal force exerted by mass _m__j_ on mass _m__i_ is **F**_ij_

then the position of the centre of mass, **R**, is

    ![\\mathbf{R}=\\frac{\\sum_i m_i \\mathbf{r}_i}{M}](//upload.wikimedia.org/math/9/8/a/98a6d5de7edfbd9b450d3c03a63ae651.png)

We can now take the second derivative of **R**

    ![ \\begin{matrix}
M \\ddot{\\mathbf{R}} & = & \\sum_i m_i \\ddot\\mathbf{r}_i \\\\
& = & \\sum_i \(\\mathbf{F}_i +\\sum_j \\mathbf{F}_{ij}\) \\end{matrix}](//upload.wikimedia.org/math/3/0/f/30fdff0dcf886d0dc3880bdc03fbdb9f.png)

But the sum of _all_ the internal forces is zero, because Newton's third law makes them cancel in pairs. Thus, the second term in the above equation drops out and we are left with:

    ![M \\ddot{\\mathbf{R}} = \\sum_i \\mathbf{F}_i = \\mathbf{F}](//upload.wikimedia.org/math/f/7/f/f7f6cfd5548b4fd6bcb10d921d707c8d.png)

The centre of mass always moves like a body of the same total mass under the total external force, irrespective of the internal forces.

**[General Mechanics](/wiki/General_Mechanics)**

If a rigid body is initially at rest, it will remain at rest if and only if the sum of all the forces and the sum of all the torques acting on the body are zero. As an example, a mass balance with arms of differing length is shown in figure above. The balance beam is subject to three forces pointing upward or downward, the tension _T_ in the string from which the beam is suspended and the weights _M_1g and _M_2g exerted on the beam by the two suspended masses. The parameter _g_ is the local gravitational field and the balance beam itself is assumed to have negligible mass. Taking upward as positive, the force condition for static equilibrium is

    ![T-M_1 g - M_2 g = 0 \\quad \\mbox{Zero net force}](//upload.wikimedia.org/math/9/b/5/9b5902e3e7f24e8b2346f53b916eb739.png)

Defining a counterclockwise torque to be positive, the torque balance computed about the pivot point in figure 10.7 is

    ![\\tau=M_1 g d_1 - M_2 g d_2 = 0 \\quad \\mbox{Zero torque}](//upload.wikimedia.org/math/7/3/4/7341e9e34c2affeef327e95c7a304545.png)

where _d_1 and _d_2 are the lengths of the beam arms. The first of the above equations shows that the tension in the string must be

    ![T=\\left\( M_1 +M_2 \\right\) g](//upload.wikimedia.org/math/6/e/2/6e2cacbb694aa465889a2135fcc87ab9.png)

while the second shows that

    ![\\frac{M_1}{M_2}=\\frac{d_1}{d_2} ](//upload.wikimedia.org/math/5/a/6/5a6bb602bc0a55d522db540f5397e1e0.png)

Thus, the tension in the string is just equal to the weight of the masses attached to the balance beam, while the ratio of the two masses equals the inverse ratio of the associated beam arm lengths.

# Rotational Dynamics[[edit](/w/index.php?title=General_Mechanics/Print_Version&action=edit&section=2)]

**[General Mechanics](/wiki/General_Mechanics)**

There are two ways to multiply two vectors together, the dot product and the cross product. We have already studied the dot product of two vectors, which results in a scalar or single number.

The cross product of two vectors results in a third vector, and is written symbolically as follows:

    ![\\mathbf{A}\\times \\mathbf{B}](//upload.wikimedia.org/math/7/2/d/72d8cf13e3d0f9878b0d11380057e96e.png)

The cross product of two vectors is defined to be perpendicular to the plane defined by these vectors. However, this doesn't tell us whether the resulting vector points upward out of the plane or downward. This ambiguity is resolved using the right-hand rule:

  1. Point the uncurled fingers of your right hand along the direction of the first vector **A**.
  2. Rotate your arm until you can curl your fingers in the direction of the second vector **B**.
  3. Your stretched out thumb now points in the direction of the cross product vector **A**×**B**.

The magnitude of the cross product is given by

    ![|\\mathbf{A}\\times \\mathbf{B}|=|\\mathbf{A}||\\mathbf{B}|\\sin \\theta](//upload.wikimedia.org/math/4/d/6/4d657973acebd7f41fed6a3e0911d6d7.png)

where |**A**| and |**B**| are the magnitudes of **A** and **B**, and θ is the angle between these two vectors. Note that the magnitude of the cross product is zero when the vectors are parallel or anti-parallel, and maximum when they are perpendicular. This contrasts with the dot product, which is maximum for parallel vectors and zero for perpendicular vectors.

Notice that the cross product does not commute, i. e., the order of the vectors is important. In particular, it is easy to show using the right-hand rule that

    ![\\mathbf{A}\\times \\mathbf{B}= -\\mathbf{B}\\times \\mathbf{A}](//upload.wikimedia.org/math/6/0/b/60bae1c23a92324eb26237524e36bbcd.png)

An alternate way to compute the cross product is most useful when the two vectors are expressed in terms of components,

    ![\\mathbf{C}= \\mathbf{A}\\times \\mathbf{B}= \\begin{vmatrix} 
\\mathbf{i} & \\mathbf{j} & \\mathbf{k} \\\\ A_x & A_y & A_z \\\\ B_x & B_y & B_z
\\end{vmatrix}](//upload.wikimedia.org/math/4/7/0/470d9aec6114cb9368b1717112482cc5.png)

where the determinant is expanded as if all the components were numbers, giving

    ![C_x=A_y B_z -A_z B_y](//upload.wikimedia.org/math/4/9/9/4994637b0f58811009d26ac0e65f8f80.png)

are corresponding expressions for the other components.

With the cross product we can also multiply three vectors together, in two different ways.

We can take the dot product of a vector with a cross product, a triple scalar product,

    ![ 
\\mathbf{A} \\cdot \(\\mathbf{B} \\times \\mathbf{C}\) = 
\(\\mathbf{A} \\times \\mathbf{B}\) \\cdot \\mathbf{C}](//upload.wikimedia.org/math/a/6/1/a615302b8708ae19a34ef381f3e83177.png)

The absolute value of this product is the volume of the parallelpiped defined by the three vectors, **A**, **B**, and **C**

Alternately, we can take the cross product of a vector with a cross product, a triple vector product, which can be simplified to a combination of dot products.

    ![ \\mathbf{A} \\times \(\\mathbf{B} \\times \\mathbf{C}\)
=\(\\mathbf{A} \\cdot \\mathbf{C}\) \\mathbf{B} 
-\(\\mathbf{A} \\cdot \\mathbf{B}\) \\mathbf{C}](//upload.wikimedia.org/math/9/3/4/934d5fe098bca846f36a7901bd9d18f7.png)

This form is easier to do calculations with.

The triple vector product is **not** associative.

    ![ \\mathbf{A} \\times \(\\mathbf{B} \\times \\mathbf{C}\)
\\ne \(\\mathbf{A} \\times \\mathbf{B}\) \\times \\mathbf{C}](//upload.wikimedia.org/math/d/8/e/d8ed53785e18adf6325d9b2055ad8949.png)

A nice as well as a useful way to denote the **cross product** is using the indicial notation

    ![ \\mathbf{C = A \\times B} = \\; \\epsilon^{ijk} \\, A_j \\, B_k \\, \\hat e_i ](//upload.wikimedia.org/math/6/6/4/66429e0a948f8443003e877245b60fef.png),

where ![\\epsilon^{ijk}](//upload.wikimedia.org/math/0/f/c/0fc78266f3804695c2baab455ce3f8a6.png) is the Levi-Civita alternating symbol and ![\\hat e_i](//upload.wikimedia.org/math/9/1/4/914327991d13d62ccb0360db13d62b98.png) is either of the unit vectors ![\\hat i, \\hat j, \\hat k](//upload.wikimedia.org/math/f/b/0/fb09546fd2bde47553faed7d05058e73.png). (A good exercise to convince yourself would be to use this expression and see if you can get **C = A x B** as defined before.)

**[General Mechanics](/wiki/General_Mechanics)**

## Torque[[edit](/w/index.php?title=General_Mechanics/Torque_and_Angular_Momentum&action=edit&section=T-1)]

Torque is the action of a force on a mass which induces it to revolve about some point, called the origin. It is defined as

    ![\\mathbf{\\tau}=\\mathbf{r}\\times \\mathbf{F}](//upload.wikimedia.org/math/1/3/d/13d3af87c263449c95dbf582b51a2c89.png)

where **r** is the position of the mass relative to the origin.

Notice that the torque is zero in a number of circumstances. If the force points directly toward or away from the origin, the cross product is zero, resulting in zero torque, even though the force is non-zero. Likewise, if **r**=0, the torque is zero. Thus, a force acting at the origin produces no torque. Both of these limits make sense intuitively, since neither induces the mass to revolve around the origin.

## Angular momentum[[edit](/w/index.php?title=General_Mechanics/Torque_and_Angular_Momentum&action=edit&section=T-2)]

The angular momentum of a mass relative to a point O is defined as

    ![\\mathbf{L}=\\mathbf{r}\\times \\mathbf{p}](//upload.wikimedia.org/math/9/5/d/95de2fe45c8ce9deef85438d31928c57.png)

where p is the ordinary (also called "linear") momentum of the mass. The angular momentum is zero if the motion of the object is directly towards or away from the origin, or if it is located at the origin.

If we take the cross product of the position vector and Newton's second law, we obtain an equation that relates torque and angular momentum:

    ![\\mathbf{r}\\times \\mathbf{F}=\\mathbf{r}\\times \\frac{d\\mathbf{p}}{dt}
=\\frac{d}{dt}\\left\( \\mathbf{r}\\times \\mathbf{p} \\right\)-\\frac{d\\mathbf{r}}{dt}\\times \\mathbf{p}](//upload.wikimedia.org/math/8/0/5/8057876f69aacab1aa33b013a707973b.png)

Since the cross product of parallel vectors is zero, this simplifies to

    ![\\mathbf{\\tau}=\\frac{d\\mathbf{L}}{dt}](//upload.wikimedia.org/math/5/c/1/5c1e6006e6a670ac54aaf330ad400b8a.png)

This is the rotational version of Newton's second law.

For both torque and angular momentum the location of the origin is arbitrary, and is generally chosen for maximum convenience. However, it is necessary to choose the same origin for both the torque and the angular momentum.

For the case of a central force, i. e., one which acts along the line of centers between two objects (such as gravity), there often exists a particularly convenient choice of origin. If the origin is placed at the center of the sun (which is assumed not to move under the influence of the planet's gravity), then the torque exerted on the planet by the sun's gravity is zero, which means that the angular momentum of the planet about the center of the sun is constant in time. No other choice of origin would yield this convenient result.

We already know about two fundamental conservation laws -- those of energy and linear momentum. We believe that angular momentum is similarly conserved in isolated systems. In other words, particles can exchange angular momentum between themselves, but the vector sum of the angular momentum of all the particles in a system isolated from outside influences must remain constant.

  
In the modern view, conservation of angular momentum is a consequence of the isotropy of space -- i. e., the properties of space don't depend on direction. This is in direct analogy with conservation of ordinary momentum, which we recall is a consequence of the homogeneity of space.

## Angular velocity and centrifugal force[[edit](/w/index.php?title=General_Mechanics/Torque_and_Angular_Momentum&action=edit&section=T-3)]

If an object is rotating about an axis, **n**, **n** being a unit vector, at frequency ω we say it has angular velocity **ω**. Despite the name, this is _not_ the rate of change of a angle, nor even of a vector.

If a constant vector **r** is rotating with angular velocity **ω** about a fixed point then

    ![\\dot{\\mathbf{r}}=\\boldsymbol{\\omega} \\times \\mathbf{r}](//upload.wikimedia.org/math/a/3/0/a30a6d26f27e4b8bbfe4b2c9654fe32b.png)

This says the acceleration is always at right angles to both the velocity and the axis of rotation.

When the axis is changing **ω** can be defined as the vector which makes this true.

Note that on the left hand side of this equation **r** is a vector in a fixed coordinate system with variable components but on the right hand side its components are given in a moving coordinate system, where they are fixed.

We can distinguish them more clearly by using subscripts, 'r' for rotating and 'f' for fixed, then extend this to arbitrary vectors

    ![\\dot{\\mathbf{g}}_f=\\dot{\\mathbf{g}}_r+
\\boldsymbol{\\omega} \\times \\mathbf{g}_f](//upload.wikimedia.org/math/8/c/5/8c541033134a6e648eda497535f5695f.png)

for _any_ vector, **g**.

Using this, we can write Newton's second law in the rotating frame.

    ![\\begin{matrix} \\mathbf{F}_f & = & m \\dot{\\mathbf{v}}_f & & \\\\
& = & m\\dot{\\mathbf{v}}_r &+&m \\boldsymbol{\\omega} \\times \\mathbf{v}_f\\\\
& = & m\\ddot{\\mathbf{r}}_r &+&m \\boldsymbol{\\omega} \\times \(2\\dot{\\mathbf{r}}_r+
\\boldsymbol{\\omega} \\times \\mathbf{r}_f\)
\\end{matrix}](//upload.wikimedia.org/math/3/f/4/3f4e0afcf98335b78ed71445a4558d3c.png)

or, rearranging

    ![m\\mathbf{a}_r=\\mathbf{F}-2m\(\\boldsymbol{\\omega} \\times \\mathbf{v}_r\)
-m\\boldsymbol{\\omega} \\times\(\\boldsymbol{\\omega} \\times \\mathbf{r}\)](//upload.wikimedia.org/math/8/2/2/82202a650d44cf7e717aa49af0bfad49.png)

The mass behaves as if there were two additional forces acting on it. The first term, **ω**×**v** is called the _Coriolis_ force. The second term is recognizable as the familiar centrifugal force.

**[General Mechanics](/wiki/General_Mechanics)**

The kinetic energy and angular momentum of the dumbbell may be split into two parts, one having to do with the motion of the center of mass of the dumbbell, the other having to do with the motion of the dumbbell relative to its center of mass.

To do this we first split the position vectors into two parts. The centre of mass is at.

    ![\\mathbf{R}=\\frac{M_1 \\mathbf{r}_1 + M_2 \\mathbf{r}_2}{M_1+M_2}](//upload.wikimedia.org/math/9/b/0/9b05a4a06ac49962b86ed68f20ffffb9.png)

so we can define new position vectors, giving the position of the masses relative to the centre of mass, as shown.

    ![\\mathbf{r}^*_1=\\mathbf{r}_1-\\mathbf{R}_1 \\quad 
\\mathbf{r}^*_1=\\mathbf{r}_1-\\mathbf{R}_1](//upload.wikimedia.org/math/2/e/b/2eb0acb26382f88a7143bb7b0e9e30af.png)

The total kinetic energy is

    ![\\begin{matrix}K & = & \\frac{1}{2}M_1 V_1^2  &+ & \\frac{1}{2}M_2 V_2^2 \\\\
& = &  \\frac{1}{2}M_1 |\\mathbf{V}-\\mathbf{v}^*_1|^2  &+ & \\frac{1}{2}M_2 |\\mathbf{V}-\\mathbf{v}^*_2|^2\\\\
& = & \\frac{1}{2}\(M_1+M_2\)V^2 & + & \\frac{1}{2}M_1 {v^*_1}^2 + \\frac{1}{2}M_2 {v^*_2}^2 \\\\ 
& = & K_{ext} & + & K_{int}\\\\
\\end{matrix} ](//upload.wikimedia.org/math/3/e/5/3e57a9644a5dc42be5e54444708c90fc.png)

which is the sum of the kinetic energy the dumbbell would have if both masses were concentrated at the center of mass, the _translational kinetic energy_ and the kinetic energy it would have if it were observed from a reference frame in which the center of mass is stationary, the _rotational kinetic energy_.

The total angular momentum can be similarly split up

    ![\\begin{matrix}
\\mathbf{L} & = & \\mathbf{L}_{orb} & + & \\mathbf{L}_{spin}\\\\
& = & \(M_1+M_2\)\\mathbf{R}\\times \\mathbf{V} & + & \(M_1\\mathbf{r}^*_1 \\times \\mathbf{v}^*_1 + M_2\\mathbf{r}^*_2 \\times \\mathbf{v}^*_2\)
\\end{matrix}](//upload.wikimedia.org/math/2/2/6/2269cd17d924203b03c57b0ddc6392bd.png)

into the sum of the angular momentum the system would have if all the mass were concentrated at the center of mass, the _orbital angular momentum_, and the angular momentum of motion about the center of mass, the _spin angular momentum_.

We can therefore assume the centre of mass to be fixed.

Since **ω** is enough to describe the dumbbells motion, it should be enough to determine the angular momentum and internal kinetic energy. We will try writing both of these in terms of _ω_

First we use two results from earlier

    ![\\mathbf{L}=\\mathbf{r} \\times \\mathbf{v} \\quad \\mbox{and} \\quad \\mathbf{v}=\\boldsymbol{\\omega} \\times \\mathbf{r}](//upload.wikimedia.org/math/c/0/e/c0edbd8de5660b7b40c63ea7193f8db3.png)

to write the angular momentum in terms of the angular velocity

  
![
\\begin{matrix}
\\mathbf{L} & = & M_1\\mathbf{r}^*_1 \\times \\mathbf{v}^*_1 & + & M_2\\mathbf{r}^*_2 \\times \\mathbf{v}^*_2\\\\
& = & M_1\\mathbf{r}^*_1 \\times \(\\boldsymbol{\\omega} \\times \\mathbf{r}^*_1\) & + & M_2\\mathbf{r}^*_2 \\times \(\\boldsymbol{\\omega} \\times \\mathbf{r}^*_2\)\\\\
 & = & 
M_1 \\left\( \\boldsymbol{\\omega} \\left\( \\mathbf{r}^*_1 \\cdot \\mathbf{r}^*_1\\right\) - \\mathbf{r}^*_1 \\left\( \\mathbf{r}^*_1 \\cdot \\boldsymbol{\\omega} \\right\)\\right\) & + & 
M_2 \\left\( \\boldsymbol{\\omega} \\left\( \\mathbf{r}^*_2 \\cdot \\mathbf{r}^*_2\\right\) - \\mathbf{r}^*_2 \\left\( \\mathbf{r}^*_2 \\cdot \\boldsymbol{\\omega}\\right\) \\right\)\\\\
& = & M_1 \\left\( \\boldsymbol{\\omega} d_1^2 - 
\\mathbf{r}^*_1 \\left\( \\mathbf{r}^*_1 \\cdot \\boldsymbol{\\omega} \\right\)\\right\) 
& + & M_2 \\left\( \\boldsymbol{\\omega} d_2^2 - 
\\mathbf{r}^*_2 \\left\( \\mathbf{r}^*_2 \\cdot \\boldsymbol{\\omega}\\right\) \\right\) \\\\
& = & \(M_1d_1^2+M_2d_2^2\) \\boldsymbol{\\omega} & - & 
\\left \(M_1 \\mathbf{r}^*_1\\left\( \\mathbf{r}^*_1\\cdot \\boldsymbol{\\omega}\\right\)
+ M_2 \\mathbf{r}^*_2\\left\( \\mathbf{r}^*_2\\cdot \\boldsymbol{\\omega}\\right\) \\right\) \\end{matrix}](//upload.wikimedia.org/math/c/0/9/c09fe2ae37b3bfb910f14622211218d5.png)

The first term in the angular momentum is proportional to the angular velocity, as might be expected, but the second term is not.

What this means becomes clearer if we look at the components of **L** For notational convenience we'll write

    ![\\mathbf{r}^*_1 = \(x_1, y_1, z_1\) \\quad \\mathbf{r}^*_2 = \(x_2, y_2, z_2\) 
](//upload.wikimedia.org/math/b/e/2/be2cc106c682cb478d788e8a1525c1e2.png)

These six numbers are constants, reflecting the geometry of the dumbbell.

    ![\\begin{matrix}
L_x & = & \(M_1d_1^2+M_2d_2^2\)\\omega_x  - \(M_1 x_1^2+M_2 x_2^2\)\\omega_x \\\\
&  &  -\(M_1 x_1 y_1+M_2 x_2 y_2\)\\omega_y -  \(M_1 x_1 z_1+M_2 x_2 z_2\)\\omega_z \\\\
L_y & = & \(M_1d_1^2+M_2d_2^2\)\\omega_y  -  \(M_1 x_1^2+M_2 x_2^2\)\\omega_y \\\\
& &  -\(M_1 x_1 y_1+M_2 x_2 y_2\)\\omega_x -  \(M_1 y_1 z_1+M_2 y_2 z_2\)\\omega_z \\\\
L_z & = & \(M_1d_1^2+M_2d_2^2\)\\omega_z  -\(M_1 x_1^2+M_2 x_2^2\)\\omega_z \\\\
& & -\(M_1 x_1 z_1+M_2 x_2 z_2\)\\omega_x - \(M_1 y_1 z_1+M_2 y_2 z_2\)\\omega_y \\\\
\\end{matrix}](//upload.wikimedia.org/math/b/3/5/b35ff5ec706b3ca86aa82816d91b6257.png)

This, we recognise as being a matrix multiplication.

    ![
\\begin{pmatrix} L_x \\\\ L_y \\\\ L_z \\end{pmatrix} =
\\begin{pmatrix} I_{xx} & I_{xy} & I_{xz} \\\\ I_{yx} & I_{yy} & I_{yz} \\\\
I_{zx} & I_{zy} & I_{zz} \\end{pmatrix} 
\\begin{pmatrix} \\omega_x \\\\ \\omega_y \\\\ \\omega_z \\end{pmatrix}
](//upload.wikimedia.org/math/b/d/6/bd6ed73038ba296579818221ec56d34e.png)

where

![
\\begin{pmatrix} I_{xx} & I_{xy} & I_{xz} \\\\ I_{yx} & I_{yy} & I_{yz} \\\\
I_{zx} & I_{zy} & I_{zz} \\end{pmatrix} =
\\begin{pmatrix}
M_1\(d_1^2-x_1^2\)+M_2\(d_2^2-x_2^2\) & -\(M_1 x_1 y_1 + M_2 x_2 y_2\) 
& -\(M_1 x_1 z_1+M_2 x_2 z_2\) \\\\
-\(M_1 x_1 y_1 + M_2 x_2 y_2\) & M_1\(d_1^2-y_1^2\)+M_2\(d_2^2-y_2^2\)
& -\(M_1 y_1 z_1+M_2 y_2 z_2\) \\\\
-\(M_1 x_1 z_1 + M_2 x_2 z_2\) & -\(M_1 y_1 z_1+M_2 y_2 z_2\) & M_1\(d_1^2-z_1^2\)+M_2\(d_2^2-z_2^2\) \\end{pmatrix} ](//upload.wikimedia.org/math/4/0/1/401f4ee5ce9b0510a92377d2f7f86e74.png)

The nine coefficients of the matrix **I** are called _moments of inertia_.

By choosing our axis carefully we can make this matrix diagonal. E.g. if

    ![\\mathbf{r}^*_1 = \(d_1, 0, 0\) \\quad \\mathbf{r}^*_2 = \(-d_2, 0, 0\) ](//upload.wikimedia.org/math/f/2/e/f2eef37eb5a467f5c424eb75d38bb62a.png)

then

    ![
\\begin{pmatrix} I_{xx} & I_{xy} & I_{xz} \\\\ I_{yx} & I_{yy} & I_{yz} \\\\
I_{zx} & I_{zy} & I_{zz} \\end{pmatrix} =
\\begin{pmatrix} 0 & 0 & 0 \\\\ 0 & M_1 d_1^2 +M_2 d_2^2 & 0 \\\\  
0 & 0 & M_1 d_1^2 +M_2 d_2^2 \\end{pmatrix} ](//upload.wikimedia.org/math/e/5/7/e5704e2a9fbf95dfafc7dcb2bb2b808b.png)

Because the dumbbell is aligned along the _x_-axis, rotating it around that axis has no effect.

The relationship between the kinetic energy, _T_, and ω quickly follows.

    ![\\begin{matrix}
2T & = &  M_1 {v^*_1}^2 & + &  M_2 {v^*_2}^2\\\\
& = & M_1 \\mathbf{v}^*_1 \\cdot \(\\boldsymbol{\\omega} \\times \\mathbf{r}^*_1\) & + &
M_1 \\mathbf{v}^*_2 \\cdot \(\\boldsymbol{\\omega} \\times \\mathbf{r}^*_2\) \\\\
& = & M_1 \\boldsymbol{\\omega} \\cdot \(\\mathbf{r}^*_1 \\times \\mathbf{v}^*_1\) & + &
M_2 \\boldsymbol{\\omega} \\cdot \(\\mathbf{r}^*_2 \\times \\mathbf{v}^*_2\)
\\end{matrix}](//upload.wikimedia.org/math/1/5/f/15f0decd7ceff2e82d24f3c10d053eb8.png)

On the right hand side we immediately recognise the definition of angular momentum.

    ![T=\\frac{1}{2} \\boldsymbol{\\omega} \\cdot \\mathbf{L}](//upload.wikimedia.org/math/c/a/1/ca1b3a3c793c43a9511b015fd573dd62.png)

Substituting for **L** gives

    ![T=\\frac{1}{2} \\boldsymbol{\\omega}\\mathbf{I}\\boldsymbol{\\omega}](//upload.wikimedia.org/math/5/f/2/5f28bb4ba7e874a14ff6eeddd7e16bb2.png)

Using the definition

    ![\\boldsymbol{\\omega} = \\omega \\mathbf{n} \\quad 
\\mathbf{n} \\cdot \\mathbf{n}=1 ](//upload.wikimedia.org/math/1/7/9/1799990fa17ef87b6e912c65e5b303dc.png)

this reduces to

    ![T=\\frac{1}{2} I  \\omega^2 ](//upload.wikimedia.org/math/8/3/c/83cb034483607c1dc43ee7ce5e365829.png)

where the _moment of inertia around the axis **n** is_

    ![I=\\mathbf{n} \\mathbf{I} \\mathbf{n} ](//upload.wikimedia.org/math/e/c/6/ec6a82ae035920cdbb397d79c173d752.png)

a constant.

If the dumbbell is aligned along the _x_-axis as before we get

    ![T=\\frac{1}{2} \(M_1 d_1^2 +M_2 d_2^2\) \(\\omega_y^2+\\omega_z^2\)](//upload.wikimedia.org/math/5/c/8/5c8ac569bc1dfedeaad97211e41c8646.png)

These equations of rotational dynamics are similar to those for linear dynamics, except that **I** is a matrix rather than a scalar.

## Further reading[[edit](/w/index.php?title=General_Mechanics/The_Uneven_Dumbbell&action=edit&section=T-1)]

  * [Modern Physics/The Uneven Dumbbell](/wiki/Modern_Physics/The_Uneven_Dumbbell)

**[General Mechanics](/wiki/General_Mechanics)**

## Summation convention[[edit](/w/index.php?title=General_Mechanics/Index_Notation&action=edit&section=T-1)]

If we label the axes as 1,2, and 3 we can write the dot product as a sum

    ![\\mathbf{u} \\cdot \\mathbf{v} = \\sum_{i=1}^3 u_i v_i ](//upload.wikimedia.org/math/c/8/9/c8927a1974faca7e96ba3088b5549bda.png)

If we number the elements of a matrix similarly,

    ![\\mathbf{A}=
\\begin{pmatrix}A_{11} & A_{12} & A_{13}\\\\ A_{21} & A_{22} & A_{23} 
\\\\A_{31} & A_{32} & A_{33} \\end{pmatrix} \\quad 
\\mathbf{B}= \\begin{pmatrix} B_{11} & B_{12} & B_{13}\\\\ B_{21} & B_{22} & B_{23} \\\\B_{31} & B_{32} & B_{33} \\end{pmatrix}](//upload.wikimedia.org/math/d/d/6/dd671a877ad7d252a63473836fd0fbb4.png)

we can write similar expressions for matrix multiplications

    ![\(\\mathbf{A} \\mathbf{u}\)_i=\\sum_{j=1}^3 A_{ij} u_j \\quad
 \(\\mathbf{A} \\mathbf{B}\)_{ik}=\\sum_{j=1}^3 A_{ij} B_{jk}](//upload.wikimedia.org/math/9/0/b/90ba51da8e070317ea647ccf7f6fe17a.png)

Notice that in each case we are summing over the repeated index. Since this is so common, it is now conventional to omit the summation sign.

Instead we simply write

    ![\\mathbf{u} \\cdot \\mathbf{v} =  u_i v_i \\quad
\(\\mathbf{A} \\mathbf{u}\)_i= A_{ij} u_j \\quad 
\(\\mathbf{A} \\mathbf{B}\)_{ik}= A_{ij} B_{jk}](//upload.wikimedia.org/math/8/e/7/8e797ba4cbd95d4f35d4ad549dbd24cc.png)

We can then also number the unit vectors, **ê**_i_, and write

    ![\\mathbf{u}=u_i \\hat{\\mathbf{e}}_i ](//upload.wikimedia.org/math/e/6/7/e67e5194aab9f953d7c103c009f8d3ed.png)

which can be convenient in a rotating coordinate system.

## Kronecker delta[[edit](/w/index.php?title=General_Mechanics/Index_Notation&action=edit&section=T-2)]

The Kronecker delta is

    ![\\delta_{ij}=
\\left\\{ \\begin{matrix} 1 & i=j\\\\ 0 & i\\ne j \\end{matrix} \\right. ](//upload.wikimedia.org/math/c/9/3/c937e8ffff746280960fbf2e841a853f.png)

This is the standard way of writing the identity matrix.

## Levi-Civita (Alternating) symbol[[edit](/w/index.php?title=General_Mechanics/Index_Notation&action=edit&section=T-3)]

Another useful quantity can be defined by

    ![\\epsilon_{ijk}=
\\left\\{ \\begin{matrix} 
1 & \(i,j,k\)= \(1,2,3\) \\mbox{ or } \(2,3,1\) \\mbox{ or } \(3,1,2\) \\\\
-1 & \(i,j,k\)= \(2,1,3\) \\mbox{ or } \(3,2,1\) \\mbox{ or } \(1,3,2\) \\\\
 0 & \\mbox{ otherwise } \\end{matrix} \\right. ](//upload.wikimedia.org/math/b/c/8/bc8e85ee9b67a44b61e612134faaebf3.png)

With this definition it turns out that

    ![\\mathbf{u} \\times \\mathbf{v} = \\epsilon_{ijk}  \\hat{\\mathbf{e}}_i u_j v_k
](//upload.wikimedia.org/math/3/a/9/3a95b6066729b393767739bc5d31b525.png)

and

    ![\\epsilon_{ijk}\\epsilon_{ipq}=
\\delta_{jp}\\delta_{kq}-\\delta_{jq}\\delta_{kp} \\,](//upload.wikimedia.org/math/5/3/6/536211fce94ad4e1ab5a1a0d43fcf503.png)

This will let us write many formulae more compactly.

**[General Mechanics](/wiki/General_Mechanics)**

The uneven dumbbell consisted of just two particles. These results can be extended to cover systems of many particles, and continuous media.

Suppose we have _N_ particles, masses _m_1 to _m__N_, with total mass _M_. Then the centre of mass is

    ![\\mathbf{R}=\\frac{\\sum_n m_n \\mathbf{r}_n}{M}](//upload.wikimedia.org/math/d/d/5/dd5ec9cadb200a989108a25fdc87185f.png)

Note that the summation convention only applies to numbers indexing axes, not to _n_ which indexes particles.

We again define

    ![\\mathbf{r}^*_n=\\mathbf{r}_n-\\mathbf{R}](//upload.wikimedia.org/math/c/9/4/c947ad3e1de34c5128d8e43e7b519101.png)

The kinetic energy splits into

    ![T=\\frac{1}{2}M V^2 + \\frac{1}{2} \\sum_n m_n {v^*_n}^2](//upload.wikimedia.org/math/b/9/2/b9259d55834ea8db16d412b5ee6ee484.png)

and the angular momentum into

    ![\\mathbf{L}=M \\mathbf{R} \\times \\mathbf{V} + 
\\sum_n m_n \\mathbf{r}^*_n \\times  \\mathbf{v}^*_n](//upload.wikimedia.org/math/f/f/9/ff9127b2263d44583f91dd85a892b248.png)

It is not useful to go onto moments of inertia unless the system is approximately rigid but this is still a useful split, letting us separate the overall motion of the system from the internal motions of its part.

**[General Mechanics](/wiki/General_Mechanics)**

If the set of particles in the previous chapter form a rigid body, rotating with angular velocity **ω** about its centre of mass, then the results concerning the moment of inertia from the penultimate chapter can be extended.

We get

    ![I_{ij}=\\sum_n m_n \(r_n^2\\delta_{ij}-{r_n}_i {r_n}_j\)](//upload.wikimedia.org/math/1/5/2/1524661849e0430cb642c5719cf60faf.png)

where (_r__n_1, _r__n_2, _r__n_3) is the position of the nth mass.

In the limit of a continuous body this becomes

    ![I_{ij}=\\int_V \\rho\(\\mathbf{r}\)\(r^2\\delta_{ij}-r_i r_j\) \\, dV](//upload.wikimedia.org/math/f/a/b/faba6adc92edbc608bf40113ee623f0e.png)

where ρ is the density.

Either way we get, splitting **L** into orbital and internal angular momentum,

    ![L_i=M\\epsilon_{ijk}R_j V_k+ I_{ij}\\omega_j](//upload.wikimedia.org/math/5/1/8/5187df1c4d468be703189f6b9aaedfbc.png)

and, splitting _T_ into rotational and translational kinetic energy,

    ![T=\\frac{1}{2} M V_i V_i + \\frac{1}{2} \\omega_i I_{ij} \\omega_j](//upload.wikimedia.org/math/f/a/9/fa913102dbadee4ca9f6df4d8f770fb8.png)

It is always possible to make **I** a diagonal matrix, by a suitable choice of axis.

# Mass Moments Of Inertia Of Common Geometric Shapes[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-1)]

The moments of inertia of simple shapes of uniform density are well known.

### Spherical shell[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-2)]

mass _M_, radius _a_

    ![I_{xx} = I_{yy} = I_{zz}=\\frac{2}{3}Ma^2](//upload.wikimedia.org/math/6/0/a/60a64806827dd902cb37fedccbd8e7e3.png)

### Solid ball[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-3)]

mass _M_, radius _a_

    ![I_{xx} = I_{yy} = I_{zz}=\\frac{2}{5}Ma^2](//upload.wikimedia.org/math/4/6/8/46892e594bf52d2991b835ce29420d1a.png)

### Thin rod[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-4)]

mass _M_, length _a_, orientated along _z_-axis

    ![I_{xx} = I_{yy} = \\frac{1}{12}Ma^2 \\quad I_{zz}=0](//upload.wikimedia.org/math/1/9/b/19bcd33db89b6853d3861d4e1015c773.png)

### Disc[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-5)]

mass _M_, radius _a_, in _x-y_ plane

    ![I_{xx} = I_{yy} = \\frac{1}{4}Ma^2 \\quad 
I_{zz}=\\frac{1}{2}Ma^2](//upload.wikimedia.org/math/a/5/6/a56b968a511e1fcc4043b15bbd7257fc.png)

### Cylinder[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-6)]

mass _M_, radius _a_, length _h_ orientated along _z_-axis

    ![I_{xx} = I_{yy} = M\\left\( \\frac{a^2}{4}+\\frac{h^2}{12} \\right\) \\quad 
I_{zz}=\\frac{1}{2}Ma^2](//upload.wikimedia.org/math/a/b/4/ab43900a708a2b8f6404bcd29969ec3f.png)

### Thin rectangular plate[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-7)]

mass _M_, side length _a_ parallel to _x_-axis, side length _b_ parallel to _y_-axis

    ![I_{xx}=M\\frac{b^2}{12} \\quad I_{yy}=M\\frac{a^2}{12} \\quad 
I_{zz}=M \\left\( \\frac{a^2}{12}+\\frac{b^2}{12} \\right\)](//upload.wikimedia.org/math/d/3/3/d335d84088413d360ffd0d4623e9fc62.png)

## further reading[[edit](/w/index.php?title=General_Mechanics/Rigid_Bodies&action=edit&section=T-8)]

  * [Statics/Moment of Inertia (contents)](/wiki/Statics/Moment_of_Inertia_\(contents\))
  * [Statics/Geometric Properties of Solids](/wiki/Statics/Geometric_Properties_of_Solids)

# Newton's Laws: A second look[[edit](/w/index.php?title=General_Mechanics/Print_Version&action=edit&section=3)]

**[General Mechanics](/wiki/General_Mechanics)**

So far we've tacitly assumed we can just calculate force as a function of position, set up the ODE

    ![m\\ddot{\\mathbf{r}}=\\mathbf{F}\(\\mathbf{r}\)](//upload.wikimedia.org/math/1/9/7/197026e99d4bb7cc1ef17a85f432309f.png)

and start solving.

It is not always so simple.

Often, we have to deal with motion under constraint; a bead sliding on a wire, a ball rolling without slipping, a weight dangling from a string.

There has to be some force keeping the bead on the wire, but we don't know what it is in advance, only what it does. This isn't enough information for us to write down the ODE.

We need a way of solving the problem without knowing the forces in advance.

How easy this is depends on the type of constraint.

  * If the constraint is an inequality, as with the weight on the string, there is no straightforward analytical method.
  * If the constraint can be written as a set of differential equations, and those equations can't be integrated in advance, there is an analytical method, but it is beyond the scope of this book. A ball rolling without slipping falls into this category.
  * If the constraint can be written as a set of algebraic equations, and frictional forces are negligible, there is a straightforward method that solves the problem.

## Generalised coordinates[[edit](/w/index.php?title=General_Mechanics/Motion_Under_Constraint&action=edit&section=T-1)]

Suppose we have a system of _n_ particles satisfying _k_ constraints of the form

    ![f_k\(\\mathbf{r}_1, \\cdots , \\mathbf{r}_n, t\)=0](//upload.wikimedia.org/math/d/d/1/dd1129f3cdb980829b8329e1fab84bbf.png)

then we can use the constraints to eliminate _k_ of the 3_n_ coordinates of the particles, giving us a new set of 3_n_-_k_ independent _generalised coordinates_; _q_1, _q_2, … _q_3_n_-'k_._

Unlike the components of the position vectors, these new coordinates will not all be lengths, and will not typically form vectors. They may often be angles.

We now need to work out what Newton's laws will look like in the generalised coordinates.

### Derivation[[edit](/w/index.php?title=General_Mechanics/Motion_Under_Constraint&action=edit&section=T-2)]

The first step is to eliminate the forces of constraint.

We will need to consider a _virtual displacement_. This is an infinitesimal displacement made, while _holding the forces and constraints constant_. It is not the same as the infinitesimal displacement made during an infinitesimal time, since the forces and constraints may change during that time.

    We write the total force on particle _i_ as 

    ![\\mathbf{F}_i=\\mathbf{F}^a_i+\\mathbf{F}^c_i](//upload.wikimedia.org/math/c/2/a/c2ac40098df8e4d0943a5ddbb88bae7c.png)
    the sum of the externally applied forces and the forces of constraint.

    Newton's second law states 

    ![\\mathbf{F}^a_i+\\mathbf{F}^c_i = \\mathbf{F}_i=\\dot{\\mathbf{p}}_i](//upload.wikimedia.org/math/1/2/7/1272f3661baffc73e0aabda7d109e01a.png)

    We take the dot product of this with the virtual displacement of particle _i_ and sum over all particles. 

    ![
\\sum_i \\left\(\\mathbf{F}^a_i+\\mathbf{F}^c_i-\\dot{\\mathbf{p}}_i \\right\)\\cdot \\delta\\mathbf{r}_i = 0](//upload.wikimedia.org/math/d/b/1/db1939660a22067959016aa6a66c9cdd.png)

    We now assume that the forces of constraint are perpendicular to the virtual displacement. This assumption is generally true in the absence of friction; e.g, the force of constraint that keeps a ball on a surface is normal to the surface.

    This assumption is called _D'Alembert's principle_. Using it we can eliminate the forces of constraint from the problem, giving 

    ![
\\sum_i \\left\(\\mathbf{F}^a_i-\\dot{\\mathbf{p}}_i \\right\)\\cdot \\delta\\mathbf{r}_i = 0](//upload.wikimedia.org/math/0/8/7/087b93ed19fa5314257510573e97786c.png)
    or 

    ![
\\sum_i \\mathbf{F}^a_i \\cdot \\delta\\mathbf{r}_i = 
\\sum_i \\dot{\\mathbf{p}}_i \\cdot \\delta\\mathbf{r}_i \\quad \(1\)](//upload.wikimedia.org/math/4/c/8/4c841ccf7a8a9ea3d2dd685e8fb04992.png)

    The left hand side of this equation is called the _virtual work_.

Now we must change to the generalised co-ordinate system.

    We write 

    ![\\mathbf{r}_i=\\mathbf{r}_i\(q_1, q_2, \\cdots ,q_{3n-k}, t\)](//upload.wikimedia.org/math/8/0/2/8022e0855230ce8432d29adda74bce08.png)

    Using the chain rule gives 

    ![\\mathbf{v}_i=\\sum_j \\frac{\\partial\\mathbf{r}_i}{\\partial q_j} \\dot{q}_j
+ \\frac{\\partial\\mathbf{r}_i}{\\partial t}](//upload.wikimedia.org/math/e/c/c/eccb865c837a363cee1b6df9231984d5.png)
    and 

    ![\\delta\\mathbf{r}_i=\\sum_j \\frac{\\partial\\mathbf{r}_i}{\\partial q_j} \\delta q_j
](//upload.wikimedia.org/math/2/1/5/21524c70be6dac491cde700a90553275.png)

    Note that this implies 

    ![\\frac{\\partial\\mathbf{r}_i}{\\partial q_j}= \\frac{\\partial\\mathbf{v}_i}{\\partial \\dot{q}_j} \\quad \(2\)](//upload.wikimedia.org/math/b/5/a/b5af1192bbb0eb4c77a2d8ce7718f8a9.png)

    The virtual work is, dropping the superscript, 

    ![\\begin{matrix}
\\sum_i \\mathbf{F}_i \\cdot \\delta\\mathbf{r}_i & = & 
\\sum_{i, j} \\mathbf{F}_i \\cdot \\frac{\\partial\\mathbf{r}_i}{\\partial q_j} 
\\delta q_j\\\\ & = & \\sum_j Q_j \\delta q_j \\end{matrix}](//upload.wikimedia.org/math/a/9/c/a9c82c7457eab15afd9110c06e26acf6.png)
    where the _Q__j_ are the components of the generalised force.

We now manipulate the right hand side of (1) into a form comparable with this last equation

    The right hand side term is 

    ![\\begin{matrix}
\\sum_i \\dot{\\mathbf{p}}_i \\cdot \\delta\\mathbf{r}_i & = &
\\sum_i m_i\\ddot{\\mathbf{r}}_i \\cdot \\delta\\mathbf{r}_i \\\\
& = & \\sum_{i, j} m_i\\ddot{\\mathbf{r}}_i \\cdot \\frac{\\partial\\mathbf{r}_i}{\\partial q_j} \\delta q_j \\end{matrix} ](//upload.wikimedia.org/math/1/1/8/1182766628745a97ffc367fab1d4b008.png)

    The terms in the coefficient of _q__j_ can be rearranged

    

    ![\\begin{matrix}
\\sum_i m_i\\ddot{\\mathbf{r}}_i \\cdot \\frac{\\partial\\mathbf{r}_i}{\\partial q_j} &
= & \\sum_i \\left\[ \\frac{d}{dt} \\left\( m_i\\dot{\\mathbf{r}}_i \\cdot \\frac{\\partial\\mathbf{r}_i}{\\partial q_j} \\right\) - 
m_i\\dot{\\mathbf{r}}_i \\cdot \\frac{d}{dt}
\\left\( \\frac{\\partial\\mathbf{r}_i}{\\partial q_j} \\right\) \\right\] \\\\
& = & \\sum_i \\left\[ \\frac{d}{dt} \\left\( m_i\\mathbf{v}_i \\cdot \\frac{\\partial\\mathbf{v}_i}{\\partial \\dot{q}_j} \\right\) - 
m_i \\mathbf{v}_i \\cdot 
\\frac{\\partial\\mathbf{v}_i}{\\partial q_j}\\right\] \\end{matrix}](//upload.wikimedia.org/math/a/f/e/afe218e026688794ae0c72495a1c722a.png)

    on substituting in equation (2) from above

On taking a close look at this last equation, we see a resemblance to the total kinetic energy,

    ![T=\\frac{1}{2}\\sum_i m_i v^2_i](//upload.wikimedia.org/math/8/1/8/81868dd5a5b19ff59633c306957c1db2.png)

    We now further rearrange to get an expression explicitly involving _T_.

    

    ![\\begin{matrix}
\\sum_i m_i\\ddot{\\mathbf{r}}_i \\cdot \\frac{\\partial\\mathbf{r}_i}{\\partial q_j}
& = &
\\sum_i \\left\[ \\frac{d}{dt} \\left\( m_i\\mathbf{v}_i \\cdot \\frac{\\partial\\mathbf{v}_i}{\\partial \\dot{q}_j} \\right\) - 
m_i \\mathbf{v}_i \\cdot \\frac{\\partial\\mathbf{v}_i}{\\partial q_j}\\right\] 
\\\\ & = & 
\\frac{d}{dt} \\left\( \\frac{\\partial}{\\partial \\dot{q}_j} 
\\frac{1}{2} \\sum_i m_i v^2_i  \\right\) - 
\\frac{\\partial}{\\partial q_j}\\frac{1}{2}  \\sum_i m_i v^2_i  \\\\
& = & \\frac{d}{dt} \\left\( \\frac{\\partial}{\\partial \\dot{q}_j} T \\right\) - \\frac{\\partial}{\\partial q_j} T \\end{matrix}](//upload.wikimedia.org/math/2/4/b/24b3633ed98b050781aab7772512a2cb.png)

Putting this last expression into (1) along with the generalised force give

    ![ 
\\sum_j \\left\[ \\frac{d}{dt} \\left\( \\frac{\\partial T}{\\partial \\dot{q}_j} \\right\) - \\frac{\\partial T}{\\partial q_j} -Q_j \\right\] \\delta q_j = 0 ](//upload.wikimedia.org/math/6/8/5/6852bf18759dc345bf1f1370ec701ce9.png)

Since the δ_q__j_, unlike the δ**r**_i_, are independent, this last equation can only be true if all the coefficients vanish.

That is we must have

    ![ \\frac{d}{dt} \\frac{\\partial T}{\\partial \\dot{q}_j} 
- \\frac{\\partial T}{\\partial q_j} = Q_j \\quad \(3\)](//upload.wikimedia.org/math/2/d/a/2dae4327ec0fe626d420a5d412645153.png)

These are the equations of motion for the system, in a general set of coordinates for which all constraints are automatically satisfied.

For example, suppose we have a cylinder, mass _m_, radius _a_, rolling without slipping on a flat plane.

The kinetic energy of the cylinder is

    ![T=\\frac{1}{2}m \\dot{x}^2 + \\frac{1}{8}ma^2 \\dot{\\theta}^2 ](//upload.wikimedia.org/math/b/8/f/b8f6677e3e77e7337eda9d96a6e13573.png)

using the results from [Rigid Bodies](/wiki/General_Mechanics/Rigid_Bodies), where _x_ is the axis in the plane perpendicular to the axis of the cylinder, and θ is the angle of rotation.

Rolling without slipping implies

    ![\\dot{x}=a\\dot{\\theta}](//upload.wikimedia.org/math/1/0/7/107568dad60673d429e2dbea54dda552.png)

so we get

    ![T=\\frac{5}{8}m\\dot{x}^2 \\quad \\frac{5}{4}m\\ddot{x}=Q_x](//upload.wikimedia.org/math/c/8/0/c8011e37f93624748108969302ead99d.png)

The cylinder has the same kinetic energy as if its mass were 20% greater. If there is no torque on the cylinder then _Q__x_=_F__x_, and the cylinder behaves in every respect as though it were a 20% larger point mass.

To use (3) more generally, we need an expression for the _Q__j_

Suppose, as is often the case, that

    ![\\mathbf{F}_i=-\\frac{\\partial}{\\partial \\mathbf{r}_i} V](//upload.wikimedia.org/math/1/d/8/1d81d46c2c37be28bb0db7a3637e0cd7.png)

then, by definition

    ![\\begin{matrix}
\\sum_j Q_j \\delta q_j & = & \\sum_i \\mathbf{F}_i  \\cdot \\delta\\mathbf{r}_i \\\\
& = & \\sum_{i, j} \\mathbf{F}_i  \\cdot 
\\frac{\\partial \\mathbf{r}_i}{\\partial q_j} \\delta q_j \\\\ 
& = &  -\\sum_{i, j} \\frac{\\partial V}{\\partial \\mathbf{r}_i} 
\\frac{\\partial \\mathbf{r}_i}{\\partial q_j} \\delta q_j \\\\ 
& = & -\\sum_j \\frac{\\partial V}{\\partial q_j} \\delta q_j
\\end{matrix}](//upload.wikimedia.org/math/5/e/3/5e38f5085b56c4cc4c7a490078e97dfe.png)

so, equating coefficients, the generalised force is

    ![Q_j=-\\frac{\\partial V}{\\partial j}](//upload.wikimedia.org/math/1/5/f/15ff96955fa9ac6d5fb7de3bb1a1b89e.png)

Putting this generalised force into (3) gives

    ![ \\frac{d}{dt} \\frac{\\partial \(T-V\)}{\\partial \\dot{q}_j} 
- \\frac{\\partial \(T-V\)}{\\partial q_j} = 0](//upload.wikimedia.org/math/f/2/7/f2741cecba20bdb6718029a95ee06ddb.png)

since _V_ has been assumed independent of the velocities.

In fact, this last equation will still be true for some velocity dependent forces, most notably magnetism, for a suitable definition of _V_, but we won't prove this here.

We call the _T-V_ the _Lagrangian_, _L_, and write

    ![ \\frac{d}{dt} \\frac{\\partial L}{\\partial \\dot{q}_j} 
- \\frac{\\partial L}{\\partial q_j} = 0](//upload.wikimedia.org/math/6/d/b/6db580577f81d4e7ea0a6584b270bbe6.png)

We call these equations _Lagrange's equations_. They are useful whenever Cartesian co-ordinates are inconvenient, including motion under constraint.

### Example[[edit](/w/index.php?title=General_Mechanics/Motion_Under_Constraint&action=edit&section=T-3)]

Suppose we have two identical point masses, _m_, connected by a string, length _a_. The string is threaded through an hole in a flat table so that the upper mass is moving in a horizontal plane without friction, and the lower mass is always vertically below the hole. The distance of the upper mass from the hole is _r_.

  
The position of the mass on the table is best described using polar coordinates, (_r_,θ). Its kinetic energy is then

    ![\\frac{1}{2}m \\left\( \\dot{r}^2+r^2 \\dot{\\theta}^2 \\right\) ](//upload.wikimedia.org/math/b/b/9/bb9ffd5a794cd27a788f6e526b20d574.png)

The velocity of the lower mass is _d(a-r)/dt_=_-dr/dt_, so the total kinetic energy is

    ![T= \\frac{1}{2}m \\left\( 2\\dot{r}^2+r^2 \\dot{\\theta}^2 \\right\) ](//upload.wikimedia.org/math/0/2/0/02093dce5ab0e7d001ee0e9c2b436b4e.png)

The potential energy is

    ![V = mg\(a-r\)](//upload.wikimedia.org/math/f/9/8/f9897e6b77f7acb0a370c77b9394e9f0.png)

where _g_ is the gravitational acceleration.

This means

    ![L = \\frac{1}{2}m \\left\( 2\\dot{r}^2+r^2 \\dot{\\theta}^2 \\right\) +mg\(r-a\)](//upload.wikimedia.org/math/1/0/6/1062d4a564e6cee0d999fc53671b52cd.png)

and the equations of motion are

    ![\\begin{matrix}
\\frac{d}{dt} \\frac{\\partial L}{\\partial \\dot{\\theta}} 
- \\frac{\\partial L}{\\partial \\theta} &  = & 
m\\frac{d}{dt}\\left\( r^2 \\dot{\\theta}\\right\) & = &  0 \\\\
\\frac{d}{dt} \\frac{\\partial L}{\\partial \\dot{r}} 
- \\frac{\\partial L}{\\partial r} &  = & 
2m\\ddot{r}-mr\\dot{\\theta}^2+mg & = &  0\\end{matrix}](//upload.wikimedia.org/math/5/2/f/52ffa1a64deff464a6dd5aed79842966.png)

The first of these equations says that the angular momentum is constant, as expected since there is no torque on the particles. If we call this constant angular momentum _l_ then we can write

    ![\\dot{\\theta}=\\frac{l}{mr^2}](//upload.wikimedia.org/math/0/3/f/03fd7871bb7826de1b162471246ae37c.png)

and the second equation of motion becomes

    ![\\ddot{r}=\\frac{l^2}{2m^2r^3}-\\frac{g}{2}](//upload.wikimedia.org/math/f/4/d/f4d99675596ddb5558932f680c13bb06.png)

Clearly, if initially

    ![l^2>g m^2 r^3, \\,](//upload.wikimedia.org/math/e/7/c/e7cf20235857eba71fee1d14381278ca.png)

then the lower ball will be pulled out of the hole, at which point these equations of motions cease to apply. They only hold when 0≤_r_≤_a_, a constraint which is not easily tamable.

Notice, we have not needed to calculate the tension in the string, which is the force of constraint in this problem.

**[General Mechanics](/wiki/General_Mechanics)**

## Reformulating Newton[[edit](/w/index.php?title=General_Mechanics/Alternate_Formulations_of_Newton%27s_Laws&action=edit&section=T-1)]

In the last chapter we saw how to reformulate Newton's laws as a set of second order ordinary differential equations using arbitrary coordinates:

    ![ \\frac{d}{dt}\\frac{\\partial L}{\\partial \\dot{q}_i}-
\\frac{\\partial L}{\\partial q_i} = 0 ](//upload.wikimedia.org/math/9/6/d/96d0f5f17e3a3bfd4c865813d49ffb47.png)

It is often far easier to solve a problem by starting with the Lagrangian than by explicitly using Newton's laws. The Lagrangian is also more useful for theoretical analysis.

However, the Lagrangian approach is not the only useful way to reformulate Newton. There is a second, related, approach which is also highly useful for analysis; namely, writing the equations of motion as a set of first order ordinary differential equations in a particularly natural way.

To do this we will use a standard technique, familiar from your calculus studies.

## Derivation[[edit](/w/index.php?title=General_Mechanics/Alternate_Formulations_of_Newton%27s_Laws&action=edit&section=T-2)]

Consider the function

    ![H\(q,p,t\)=\\dot{q}_i p_i -L\(q, \\dot{q}, t\) ](//upload.wikimedia.org/math/a/9/b/a9b954faefddc82b72ff48ce1a242f60.png)

where the _q__i_ are the generalised coordinates, the _p__i_ are a set of new variables whose meaning we will soon see, _H_ is to be a function of the _p_‘s and _q_‘s alone, and the summation convention is being used.

Then we have

    ![dH=\\dot{q}_i dp_i + p_i d\\dot{q}_i 
-\\frac{\\partial L}{\\partial \\dot{q}_i} d\\dot{q}_i 
-\\frac{\\partial L}{\\partial q_i} dq_i -\\frac{\\partial L}{\\partial t} dt \\quad \(1\)](//upload.wikimedia.org/math/d/4/3/d432dd42f47d696da8098963d896700a.png)

but, since _H_ is a function of the _p_‘s and _q_‘s alone we can also write

    ![dH=\\frac{\\partial H}{\\partial q_i}dq_i + 
\\frac{\\partial H}{\\partial p_i}dp_i + \\frac{\\partial H}{\\partial t}dt \\quad \(2\)
](//upload.wikimedia.org/math/f/3/c/f3cfb62712b86b73bbae6821c5093de9.png)

For these two equations to both be true the coefficients of the differentials must be equal.

Equation (2) does not contain a term in ![d\\dot{q}_i](//upload.wikimedia.org/math/a/7/7/a77d57c173d838ae3aa5d5785a09a536.png), so the coefficient of that term in equation (1) must be zero. I.e,

    ![p_i=\\frac{\\partial L}{\\partial \\dot{q}_i}](//upload.wikimedia.org/math/6/c/3/6c3d9d29893805b871ff722a1a50e90a.png)

which gives us a definition of the _p__i_. Using this in Lagrange's equations gives

    ![\\dot{p}_i=\\frac{\\partial L}{\\partial q_i}](//upload.wikimedia.org/math/3/c/1/3c1546ba856cd26ac91f72000faa8ff5.png)

and equation (1) simplifies to

    ![dH=\\dot{q}_i dp_i - \\dot{p}_i dq_i  
-\\frac{\\partial L}{\\partial t} dt](//upload.wikimedia.org/math/e/3/5/e35ed76152045348891f6e38ebb5586d.png)

A comparison of coefficients with equation (2) now gives the desired set of first order equations for the motion,

    ![\\dot{q}_i=\\frac{\\partial H}{\\partial p_i} \\quad 
 \\dot{p}_i=-\\frac{\\partial H}{\\partial q_i}](//upload.wikimedia.org/math/b/a/a/baa38d965e23f5e09790e821e08cbacd.png)

These are called _Hamilton's equations_ and _H_ is called the _Hamiltonian._

## Physical meaning of H and p[[edit](/w/index.php?title=General_Mechanics/Alternate_Formulations_of_Newton%27s_Laws&action=edit&section=T-3)]

To see what _H_ and the _p__i_'s actually are, let's consider a few typical cases.

_First,_ let's look at a free particle, one subject to no forces. This will let us see what the _p__i_'s mean, physically.

If we use Cartesian coordinates for the free particle, we have

    ![L = T=\\frac{1}{2}m \\left\( \\dot{x}^2+  \\dot{y}^2+  \\dot{z}^2 \\right\) ](//upload.wikimedia.org/math/8/9/7/897e524c7e95170aa305ecddfd65a86d.png)

The _p__i_'s are the differential of this with respect to the velocities.

    ![p_x=\\frac{\\partial L}{\\partial \\dot{x}}=m \\dot{x} \\quad
p_y=\\frac{\\partial L}{\\partial \\dot{y}}=m \\dot{y} \\quad
p_z=\\frac{\\partial L}{\\partial \\dot{z}}=m \\dot{z} ](//upload.wikimedia.org/math/4/6/8/468cae162b0d3d307d20e05ef5523ffb.png)

These are the components of the momentum vector.

If we use cylindrical coordinates, we have

    ![L = T=\\frac{1}{2}m \\left\( \\dot{r}^2+  r^2\\dot{\\theta}^2+  \\dot{z}^2 \\right\) ](//upload.wikimedia.org/math/9/4/f/94f32eeb4dbf539285308152fb9fda1d.png)

and

    ![p_r=\\frac{\\partial L}{\\partial \\dot{r}}=m \\dot{r} \\quad
p_{\\theta}=\\frac{\\partial L}{\\partial \\dot{\\theta}}=m r^2 \\dot{\\theta} \\quad
p_z=\\frac{\\partial L}{\\partial \\dot{z}}=m \\dot{z} ](//upload.wikimedia.org/math/0/0/c/00c78ed347f851879e1404bc845b2446.png)

This time, _p__z_ is the component of momentum is the _z_ direction, _p__r_ is the radial momentum, and _p_θ is the angular momentum, which we've previously seen is the equivalent of momentum for rotation.

Since, in these familiar cases, the _p__i_'s are momenta, we generalise and call the _p__i_'s _conjugate momenta_.

Note that from Hamilton's equations, we see that if _H_ is independent of some coordinate, _q_, then

    ![\\dot{p}_q=-\\frac{\\partial H}{\\partial q} = 0](//upload.wikimedia.org/math/9/1/1/911e7051db7351ae9c428ad8338de144.png)

so the momentum conjugate to _q_ is conserved. This connection between conservation laws and coordinate independence lies at the heart of much physics.

_Secondly_, to see the physical meaning of _H_, we'll consider a particle moving in a potential _V_, described using Cartesian coordinates.

This time the Lagrangian is

    ![L= T-V = \\frac{1}{2}m \\left\( \\dot{x}^2+  \\dot{y}^2+  \\dot{z}^2 \\right\)-V\(x,y,z\)
](//upload.wikimedia.org/math/b/4/f/b4f59c7fcaf4fe5e8fc23a3560417852.png)

We find that the _p__i_'s are

    ![p_x=\\frac{\\partial L}{\\partial \\dot{x}}=m \\dot{x} \\quad
p_y=\\frac{\\partial L}{\\partial \\dot{y}}=m \\dot{y} \\quad
p_z=\\frac{\\partial L}{\\partial \\dot{z}}=m \\dot{z} ](//upload.wikimedia.org/math/4/6/8/468cae162b0d3d307d20e05ef5523ffb.png)

so, again, they are the momenta

Now lets calculate _H_.

    ![\\begin{matrix}
H & = &  \\dot{x}p_x+ \\dot{y}p_y+ \\dot{y}p_y & - & L & &\\\\
 & = & m  \\left\( \\dot{x}^2+  \\dot{y}^2+  \\dot{z}^2 \\right\) & 
- & \\frac{1}{2}m \\left\( \\dot{x}^2+  \\dot{y}^2+  \\dot{z}^2 \\right\) & + & V\\\\
& = &  \\frac{1}{2}m \\left\( \\dot{x}^2+  \\dot{y}^2+  \\dot{z}^2 \\right\) & & & + & V\\\\
& = &  T &  & & + & V \\end{matrix}](//upload.wikimedia.org/math/6/1/0/610d5d51d41d2ab81b11d85dd2540b0d.png)

so _H_ is the total energy, written as a function of the position and momentum.

This is not always true, but it will be true for all common systems which conserve energy.

In general, if we know how the energy of a systems depends on speeds and positions, we know everything about the system.

Physicists will often start work on a problem by writing down an expression for _H_, or _L_, and never bother calculating the actual forces.

## Deeper meaning[[edit](/w/index.php?title=General_Mechanics/Alternate_Formulations_of_Newton%27s_Laws&action=edit&section=T-4)]

If we compare Hamilton's equations,

    ![\\dot{q}_i=\\frac{\\partial H}{\\partial p_i} \\quad 
 \\dot{p}_i=-\\frac{\\partial H}{\\partial q_i}](//upload.wikimedia.org/math/b/a/a/baa38d965e23f5e09790e821e08cbacd.png)

with the equations of geometrical optics.

    ![\\dot{x}_i=\\frac{\\partial \\omega}{\\partial k_i} \\quad 
 \\dot{k}_i=-\\frac{\\partial \\omega}{\\partial x_i}](//upload.wikimedia.org/math/b/2/9/b2909fcc8c659453b98025a025121e61.png)

we see that both sets of equations have the same form.

If we made a substitution of the form,

    ![H=\\alpha \\omega \\quad p=\\alpha k ](//upload.wikimedia.org/math/5/6/f/56f8259d680a108954b19a9e612b3e3e.png)

for any α, the two sets of equations would become identical.

Now, geometrical optics is an approximation to the full solution of any wave equation, valid when the wavelength is small.

Since classical mechanics is just like geometrical optics, classical mechanics could also be small wavelength approximation to a more accurate wave theory.

This is not a proof, _could be_ is not the same as _is_, but it does show that classical mechanics is compatible with wave theories, contrary to intuition.

We will see later that this is not a coincidence, classical mechanics really is a small wavelength approximation to a more accurate wave theory, namely quantum mechanics, and that, in that theory, the energy of matter waves is proportional to frequency and the momentum to wave number, just as the substitution above requires.

Hamilton's equations can also be used to construct a mathematical gadget, called a Poisson bracket, which lets us write the equations of classical mechanics in a way which makes the connections with quantum mechanics even clearer, but an explanation of how would be beyond the scope of this book.

Since classical mechanics is just like geometrical optics, there should be an analog to Fermat's principle, that light takes the quickest path, and there is.

Where light takes the quickest path from _a_ to _b_, matter takes the path of _least action_, where the action is defined as

    ![\\int_a^b L\(x,\\dot{x},t\) \\, dt](//upload.wikimedia.org/math/a/4/8/a4857795c74ca48663707b01f21f66a5.png)

It can be proved that this integral takes extremal values if and only if the system obeys Lagrange's equations. Saying matter takes the path of least action is equivalent to saying it obeys Lagrange's equations, or Newton's laws.

Furthermore, it turns out that in general relativity, the action is proportional to the time taken, so matter is also really taking the quickest path between two points.

**[General Mechanics](/wiki/General_Mechanics)**

We've seen that an Hamiltonian of the form

    ![H=\\frac{\\mathbf{p}\\cdot\\mathbf{p}}{2m}+V\(\\mathbf{r}\)](//upload.wikimedia.org/math/8/3/4/834a3a69417d3227c09a7b73054637f3.png)

describes motion under a conservative force, but this is not the most general possible Hamiltonian.

Many waves are described by another simple form, in the geometrical optics limit,

    ![H=f\(|\\mathbf{p}|\)](//upload.wikimedia.org/math/5/2/8/528ce050a8c0191038ebd597a6532142.png)

What happens if we consider other forms for the Hamiltonian?

Suppose we have

    ![H=\\frac{\\mathbf{p}\\cdot\\mathbf{p}}{2m} + 
\\mathbf{p} \\cdot \\mathbf{A}\(\\mathbf{r}\)](//upload.wikimedia.org/math/1/e/d/1ed1335e9274d1c2afbe3c252e963d8b.png)

The dot product term is the simplest scalar we can add to the kinetic energy that's dependent on momentum. We'll see that it acts like a potential energy.

Using Hamilton's equations we can immediately write down equations of motion.

    ![\\begin{matrix}
\\dot{x}_i & = & \\frac{\\partial H}{\\partial p_i} & = & \\frac{p_i}{m} + A_i \\\\
\\dot{p}_i & = & -\\frac{\\partial H}{\\partial x_i} & = &
 -p_j \\frac{\\partial A_j}{\\partial x_i}
\\end{matrix}](//upload.wikimedia.org/math/6/8/8/6886fbaa3b6c0ec5f77e31d02d010469.png)

Note that we are using the [summation convention](/wiki/General_Mechanics/Index_Notation) here.

Now that we've got the equations of motion, we need to work out what they mean.

The first thing we notice is that the momentum is no longer _m**v**_. There is an additional contribution from the potential field **A**. We can think of this as a form of _potential momentum_, analogous to potential energy.

The force on the particle is

    ![F_i = m \\ddot{x}_i = \\dot{p}_i + m\\frac{d}{dt}A_i\(\\mathbf{r}\)](//upload.wikimedia.org/math/7/0/3/7032e3ba30fccf413d7820c95da6498b.png)

Using the chain rule, and substituting for _dp_/_dt_ with the second equation of motion, we get

    ![F_i =  -p_j \\frac{\\partial A_j}{\\partial x_i} +
m\\dot{x}_j \\frac{\\partial A_i}{\\partial x_j} ](//upload.wikimedia.org/math/2/6/1/26197c7ddc0c679ed0716e153c4d6647.png)

Using the first equation, this becomes

    ![F_i = m \\dot{x}_j 
\\left\( \\frac{\\partial A_i}{\\partial x_j} -\\frac{\\partial A_j}{\\partial x_i}
\\right\) + m A_j \\frac{\\partial A_j}{\\partial x_i} ](//upload.wikimedia.org/math/4/7/3/473baa27def0417aff18439cc2c5b4dc.png)

The term in brackets is recognizable as being the type of thing we see in cross products. With a little manipulation, using the Kronecker delta and alternating symbol, we can write

    ![\\begin{matrix}
F_i & = &  \\dot{x}_j \\left\( \\delta_{il}\\delta_{jk}-\\delta_{ik}\\delta_{jl} \\right\) \\frac{\\partial A_l}{\\partial x_k} & + & m A_j \\frac{\\partial A_j}{\\partial x_i} \\\\
& = & \\dot{x}_j \\epsilon_{nij} \\epsilon_{nlk} \\frac{\\partial A_l}{\\partial x_k} 
& + & m A_j \\frac{\\partial A_j}{\\partial x_i} \\\\
& = & -\\epsilon_{ijn} \\dot{x}_j \\left\( \\nabla \\times \\mathbf{A} \\right\)_n
& + & m A_j \\frac{\\partial A_j}{\\partial x_i} \\\\
& = & -\\epsilon_{ijn} \\dot{x}_j \\left\( \\nabla \\times \\mathbf{A} \\right\)_n
& + & \\frac{1}{2} \\frac{\\partial}{\\partial x_i} A_j A_j
\\end{matrix}](//upload.wikimedia.org/math/5/c/a/5cad7e0979aa81b1fec52ea72b72b2a5.png)

so, writing the last line as a vector equation,

    ![ \\mathbf{F} = -m \\mathbf{v} \\times \(\\nabla \\times \\mathbf{A}\) + 
\\frac{1}{2} m \\nabla A^2 ](//upload.wikimedia.org/math/9/6/2/962a9a3c3d1b2c4a89ba90b5aabf7e93.png)

The force from this potential has a component perpendicular to its curl and to the velocity, and another component which is the gradient of a scalar.

If we add a carefully chosen potential energy to the Hamiltonian we can cancel out this second term.

    ![H=\\frac{p^2}{2m} + \\mathbf{p} \\cdot \\mathbf{A}\(\\mathbf{r}\) + 
\\frac{1}{2} m A^2 \\qquad
\\mathbf{F}= -m \\mathbf{v} \\times \\left \(\\nabla \\times \\mathbf{A} \\right\) ](//upload.wikimedia.org/math/0/e/7/0e718f7f362d622d70be3a8e39c103a4.png)

This Hamiltonian can be simplified to

    ![H = \\frac{1}{2m} \\left\( \\mathbf{p}+ m\\mathbf{A} \\right\)^2 ](//upload.wikimedia.org/math/b/0/f/b0f0e65396fbad468f71d4472a381ea3.png)

where the term in bracket is _m**v**_, written as a function of momentum.

This simple modification to the Hamiltonian gives us a force perpendicular to velocity, like magnetism. Because the force and velocity are perpendicular, the work done by the force is always zero.

_We can use potential fields to describe velocity dependent forces, provided that they do no work._

The coefficient of **A** in these expression is arbitrary. Changing it amount merely to measuring **A** in different units so we can equally well write

    ![H = \\frac{1}{2m} \\left\( \\mathbf{p}+ \\alpha\\mathbf{A} \\right\)^2 \\qquad
\\mathbf{F}= -\\alpha \\mathbf{v} \\times \\left \(\\nabla \\times \\mathbf{A} \\right\) 
](//upload.wikimedia.org/math/c/0/5/c05b5ed5bac2401775601e3ead9dd498.png)

Having α=_m_ means **A** is measured in units of velocity, which may sometimes be convenient, but we can use any other constant value of α that suits our purpose. When we come to study relativity, we'll use α=-1.

Notice that the force depends only on the curl of **A**, not on **A** itself. This means we can add any function with zero curl to **A** without changing anything, just as we can add a constant to the potential energy.

Furthermore, it is a standard result of vector calculus that any vector field is the sum of two components, one with zero curl, the other with zero divergence. Since the zero curl component does not affect the total force, we can require it to be zero; i.e. we can require **A** to have zero divergence.

    ![ \\nabla \\cdot \\mathbf{A}= 0 ](//upload.wikimedia.org/math/8/8/5/885fff5460f988fc87535697ca1c80df.png)

This is called a _gauge_ condition. For the moment, it can be considered to define especially natural values for the integration constants.

**[General Mechanics](/wiki/General_Mechanics)**

![Wiktionary-logo.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wiktionary-logo.svg/40px-Wiktionary-logo.svg.png)

Look up _**[Mach's principle](//en.wiktionary.org/wiki/Mach%27s_principle)**_ in [Wiktionary](//en.wiktionary.org/wiki/), the free dictionary.

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Mach's principle**_](//en.wikipedia.org/wiki/Mach%27s_principle)

Mach's principle is the name given by Einstein to a vague hypothesis first supported by the physicist and philosopher Ernst Mach.

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=General_Mechanics/Print_Version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

# Harmonic Oscillators[[edit](/w/index.php?title=General_Mechanics/Print_Version&action=edit&section=4)]

**[General Mechanics](/wiki/General_Mechanics)**

## Energy Analysis[[edit](/w/index.php?title=General_Mechanics/Energy_Analysis&action=edit&section=T-1)]

**Figure 11.2:** Potential, kinetic, and total energy of a one-dimensional harmonic oscillator plotted as a function of spring displacement.

For a spring, Hooke's law says the total force is proportional to the displacement, and in the opposite direction.

    ![F=-kx](//upload.wikimedia.org/math/9/a/6/9a6fbbfbfe1b1dc27c9df8eb644bd7a8.png)

Since this is independent of velocity, it is a conservative force. We can integrate to find the potential energy of the mass-spring system,

![V\(x\)=\\frac{1}{2}kx^2](//upload.wikimedia.org/math/b/f/0/bf03d7b3000c2a4fdc5e22e239328963.png)

Since a potential energy exists, the total energy

    ![E=\\frac{1}{2}kx^2+\\frac{1}{2}m\\dot{x}^2](//upload.wikimedia.org/math/3/0/5/305143b0c369a56d8d5e04556813ab64.png)

is conserved, i. e., is constant in time.

We can now use energy conservation to determine the velocity in terms of the position

    ![\\dot{x}=\\pm \\sqrt{\\frac{2E}{m}-\\frac{k}{m}x^2}](//upload.wikimedia.org/math/b/6/8/b68d688fce1ec0aff608025e356fcbc4.png)

We could integrate this to determine the position as a function of time, but we can deduce quite a bit from this equation as it is.

It is fairly evident how the mass moves. From Hooke's law, the mass is always _accelerating_ toward the _equilibrium position_, so we know which sign of the square root to take.

The velocity is zero when

    ![x=\\pm \\sqrt{\\frac{2E}{k}}](//upload.wikimedia.org/math/1/7/4/174495b272ad560b5ec01006cffd26ff.png)

If _x_ were larger than this the velocity would have to be imaginary, clearly impossible, so the mass must be confined between these values. We can call them the turning points.

If the mass is moving to the left, it slows down as it approaches the left turning point. It stops when it reaches this point and begins to move to the right. It accelerates until it passes the equilibrium position and then begins to decelerate, stopping at the right turning point, accelerating toward the left, etc. The mass thus oscillates between the left and right turning points.

How does the period of the oscillation depend on the total energy of the system? We can get a general idea without needing to solve the differential equation.

There are only two parameters the period, _T_, could depend on; the mass, _m_, and the spring constant, _k_.

We know _T_ is measured in seconds, and _m_ in kilograms. For the units in Hooke's law to match, _k_ must be measured in N·m-1, or equivalently, in kg·s-2.

We immediately see that the only way to combine _m_ and _k_ to get something measured in seconds is to divide, cancelling out the kg's.

Therefore _T_∝![\\sqrt{m/k}](//upload.wikimedia.org/math/b/4/3/b4349749d129342b6aa9b2cdc6b69bc5.png)

We have established the general way the period depends on the parameters of the problem, without needing to use calculus.

This technique is called _dimensional analysis_, and has wide application. E.g., if we couldn't calculate the proportionality constant exactly, using calculus, we'd be able to deduce by doing one experiment. Without dimensional analysis, if calculus failed us we'd have to do scores of experiments, each for different combinations of _m_ and _k_.

Fortunately, the proportionality constants are typically small numbers, like ![3\\sqrt{2} ](//upload.wikimedia.org/math/5/a/1/5a14d1a28cae6144ec64c8177e765cda.png) or ![\\sqrt{\\pi}/2](//upload.wikimedia.org/math/c/7/b/c7ba9499cd69c81de3472b02b59e3b0a.png).

**[General Mechanics](/wiki/General_Mechanics)**

## Analysis Using Newton's Laws[[edit](/w/index.php?title=General_Mechanics/Analysis_Using_Newton%27s_Laws&action=edit&section=T-1)]

The acceleration of the mass at any time is given by Newton's second law

    ![a=\\frac{d^2x}{dt^2}=\\frac{F}{m}=-\\frac{kx}{m}](//upload.wikimedia.org/math/8/b/c/8bc461cd8806bf0c558f13ca8fdf96b5.png)

An equation of this type is known as a _differential equation_ since it involves a derivative of the dependent variable . Equations of this type are generally more difficult to solve than algebraic equations, as there are no universal techniques for solving all forms of such equations. In fact, it is fair to say that the solutions of most differential equations were originally obtained by _guessing_!

There are systematic ways of solving simple differential equations, such as this one, but for now we will use our knowledge of the physical problem to make an intelligent guess.

We know that the mass oscillates back and forth with a period that is independent of the amplitude of the oscillation. A function which might fill the bill is the sine function. Let us try substituting,

    ![x=A\\, \\sin \\omega t](//upload.wikimedia.org/math/e/8/9/e89362b4e37aa8242f2f9979cdea5c23.png)

where ω is a constant, into this equation.

We get

    ![-\\omega^2 A\\, \\sin \\omega t = -A \\frac{k}{m}\\, \\sin \\omega t](//upload.wikimedia.org/math/7/1/3/713b4e1840a87a85edc2ca1e76a37660.png)

Notice that the sine function cancels out, leaving us with ω2=_k_/_m_. The guess thus works if we set

    ![\\omega=\\sqrt{\\frac{k}{m}}](//upload.wikimedia.org/math/8/0/4/804d9b111040ebe3bcb2c542e4878076.png)

This constant is the angular oscillation frequency for the oscillator, from which we infer the period of oscillation to be

    ![T=2\\pi \\sqrt{\\frac{m}{k}}](//upload.wikimedia.org/math/7/1/5/7158afb6b442a3b16ce00f1ff5350111.png)

This agrees with the result of the dimensional analysis. Because this doesn't depend on _A_, we can see that the period is independent of amplitude.

It is easy to show that the cosine function is equally valid as a solution,

    ![x=B\\, \\cos \\omega t](//upload.wikimedia.org/math/b/6/6/b660ab858140f10e33886d9e8cafa758.png)

for the same ω.

In fact, the most general possible solution is just a combination of these two, i. e.

    ![x=A\\, \\sin \\omega t+B\\, \\cos \\omega t](//upload.wikimedia.org/math/8/0/f/80fc24004cdf1f2c5e3688c44b30946c.png)

The values of _A_ and _B_ depend on the position and velocity of the mass at time _t_=0.

**[General Mechanics](/wiki/General_Mechanics)**

If we wiggle the left end of the spring in the above diagram by amount _d_=_d_0sin ω_F__t_, rather than rigidly fixing it, we have a forced harmonic oscillator.

The constant _d_0 is the amplitude of the imposed wiggling motion. The forcing frequency ω_F_ is not necessarily equal to the natural or resonant frequency of the mass-spring system. Very different behavior occurs depending on whether it is less than, equal to, or greater than ω.

Given the above wiggling, the force of the spring on the mass becomes

    ![F = -k\(x-d\) = -k\(x-d_0 \\sin \\omega_F t\) \\,](//upload.wikimedia.org/math/6/5/a/65a505f087c04ca8dec9eb8f1366f6bb.png)

since the length of the spring is the difference between the positions of the left and right ends. Proceeding as for the unforced mass-spring system, we arrive at the differential equation

    ![\\frac{d^2x}{dt^2}+\\frac{k}{M}x= \\frac{k}{M}d_0 \\sin \\omega_F t](//upload.wikimedia.org/math/2/6/8/268407a5388bedda5ec323598f9d10c3.png)

The solution to this equation turns out to be the sum of a forced part in which _x_∝ sin ω_F__t_, and a free part which is the same as the solution to the unforced equation. We are primarily interested in the forced part of the solution, so let us set _x_=_d_0sin ω_F__t_and substitute this into the equation of motion, giving:

    ![ -\\omega_F^2 x_0 \\sin \\omega_F t + \\frac{k}{M}x_0 \\sin \\omega_F t = \\frac{k}{M}d_0 \\sin \\omega_F t ](//upload.wikimedia.org/math/9/1/0/910ef7de08132faa8e7f208d730cfc23.png)

The sine factor cancels leaving us with an algebraic equation for , the amplitude of the oscillatory motion of the mass.

Solving for the ratio of the oscillation amplitude of the mass to the amplitude of the wiggling motion, we find

    ![\\frac{x_0}{d_0} = \\frac{1}{1-M \\omega_F^2/k} = \\frac{1}{1-\\omega_F^2/\\omega^2} ](//upload.wikimedia.org/math/2/3/d/23d0599b1e599f5968156b92bc8229af.png)

  
where we have recognized that _k_/_M_=ω2, the square of the frequency of the _free_ oscillation.

Notice that if ω_F_<ω, then the motion of the mass is in phase with the wiggling motion and the amplitude of the mass oscillation is greater than the amplitude of the wiggling. As the forcing frequency approaches the natural frequency of the oscillator, the response of the mass grows in amplitude.

When the forcing is at the resonant frequency, the response is technically infinite, though practical limits on the amplitude of the oscillation will intervene in this case -- for instance, the spring cannot stretch or shrink an infinite amount. In many cases friction will act to limit the response of the mass to forcing near the resonant frequency.

When the forcing frequency is greater than the natural frequency, the mass actually moves in the opposite direction of the wiggling motion -- i. e., the response is out of phase with the forcing. The amplitude of the response decreases as the forcing frequency increases above the resonant frequency.

Forced and free harmonic oscillators form an important part of many physical systems. For instance, any elastic material body such as a bridge or an airplane wing has harmonic oscillatory modes. A common engineering problem is to ensure that such modes are damped by friction or some other physical mechanism when there is a possibility of excitation of these modes by naturally occurring processes. A number of disasters can be traced to a failure to properly account for oscillatory forcing in engineered structures.

**[General Mechanics](/wiki/General_Mechanics)**

We often encounter systems which contain multiple harmonic oscillators, such as this:

![CoupledOscillators.png](//upload.wikimedia.org/wikibooks/en/4/4e/CoupledOscillators.png)

two identical masses, _m_, the first attached to a wall by a spring with constant _k_, and the second attached to the first by another, identical spring.

If the springs weren't linked they'd both vibrate at the same frequency, ω=√(_k_/_m_). Linking the springs changes this.

To find out how the linked system behaves, we will start with the Lagrangian, using the displacements of the masses, _x_1 and _x_2, as our coordinates.

A moment's inspection of the system shows

    ![T=\\frac{1}{2}m \\left\( \\dot{x}^2_1 + \\dot{x}^2_2 \\right\) \\quad
V=\\frac{1}{2}k \\left\( x_1^2 + \(x_2-x_1\)^2 \\right\) ](//upload.wikimedia.org/math/b/b/a/bba3d56a51c70fb94d0835c94290b76b.png)

so, using ω²=_k_/_m_,

    ![L=\\frac{1}{2}m \\left\( \\dot{x}^2_1 + \\dot{x}^2_2 \\right\) - 
\\frac{1}{2}m\\omega^2 \\left\( x_1^2 + \(x_2-x_1\)^2 \\right\)](//upload.wikimedia.org/math/7/a/5/7a5e6088fb6c6226304da504f0631cb6.png)

The equations of motion immediately follow.

    ![\\begin{matrix}
\\ddot{x}_1 & = & -\\omega^2 \(2x_1 -x_2\) \\\\
\\ddot{x}_2 & = & -\\omega^2 \(x_2 -x_1\)
\\end{matrix} \\quad \(1\)](//upload.wikimedia.org/math/c/0/4/c0450676d52413f916af39848cc5bac7.png)

To solve these equations we try a solution in trig functions

    ![x_1 = A_1 \\sin \\Omega t \\quad x_2 = A_2 \\sin \\Omega t ](//upload.wikimedia.org/math/7/0/4/70428b15430f3f0c818460278e94909a.png)

Substituting this into (1) gives

    ![\\begin{matrix}
 -\\Omega^2 A_1 & + & \\omega^2 \(2A_1-A_2\) & = & 0 \\\\
 -\\Omega^2 A_2 & + & \\omega^2 \(A_2-A_1\) & = & 0 \\\\
\\end{matrix} ](//upload.wikimedia.org/math/d/5/e/d5e475336606aa918e8ec2639b18fa7e.png)

We would get the same equations from any trig function solution of the same frequency.

Gathering the coefficients of _A_1 and _A_2 together lets rewrite the last equation as

    ![
\\begin{pmatrix} 2\\omega^2-\\Omega^2 & -\\omega^2 \\\\
-\\omega^2 & \\omega^2-\\Omega^2 \\end{pmatrix}
\\begin{pmatrix} A_1 \\\\ A_2 \\end{pmatrix} = 
\\begin{pmatrix} 0 \\\\ 0 \\end{pmatrix} \\quad \(2\)](//upload.wikimedia.org/math/9/0/7/907732b9dae618893ee1cf589d2945fa.png)

We can only solve this equation if the determinant of the matrix is zero.

    ![\\Omega^4-3\\omega^2 \\Omega^2 + \\omega^4 = 0](//upload.wikimedia.org/math/6/7/5/67528b90e75b5543da74f6a99ab6f38a.png)

The solutions are

    ![ \\Omega_{\\pm}^2=\\frac{3 \\pm \\sqrt{5} }{2} \\omega^2 ](//upload.wikimedia.org/math/f/a/d/fad0ba91099587dbf7c7f7e90d288a19.png)

so the combined system has two natural frequencies, one lower and one higher than the natural frequency of the individual springs. This is typical.

We can also calculate the ratio of _A_1 and _A_2 from (2). Dividing by _A_2 gives

    ![\\frac{A_1}{A_2}= 1-\\frac{\\Omega_{\\pm}^2}{\\omega^2}](//upload.wikimedia.org/math/1/f/0/1f093c28e98959200d596a2525f61316.png)

  * For the lower frequency, Ω-, which is less than ω, the ratio is positive, so the two masses move in the same direction with different amplitudes. They are said to be _in phase_.
  * For the higher frequency, Ω+, which is more than ω, the ratio is negative, so the two masses move in the opposite direction with different amplitudes. They are said to be _in antiphase_.

This behaviour is typical when pairs of harmonic oscillators are coupled.

The same approach can also be used for systems with more than two particles.

**[General Mechanics](/wiki/General_Mechanics)**

## Introduction[[edit](/w/index.php?title=General_Mechanics/The_Continuum_Limit&action=edit&section=T-1)]

In principle, we could use the methods described so far to predict the behavior of matter by simply keeping track of each atom.

In practice, this is not a useful approach. Instead, we treat matter as a continuum.

In this section we will see how this is done, and how it leads us back to waves.

For an example, we will consider a set of _N_+1 identical springs and masses, arranged as in the previous section, with spring 0 attached to the wall, and mass _N_ free.

We are interested in what happens for large _N_, the _continuum_ limit.

The system has three other parameters; the spring constant _k_, the particle mass _Δm_, and the spring rest spacing _Δa_, where variable names have been chosen for future convenience. These can be combined with _N_ to give a similar set of parameters for the system.

Suppose all the masses are displaced by _d_ from rest, with total displacement _D_=_dN_ of the system end, then the total potential energy is _kNd_2/2 = _kD_2/(2_N_), so

  * The system's spring constant is _K_=_k/N_
  * The system mass is _m_=_ΔmN_
  * The system rest length is _a_=_ΔaN_

If, as we increase _N_ we change the other three parameters to keep _K_, _m_, and _a_ constant then in the large _N_ limit this _discrete_ system will look like a spring with mass _continuously_ distributed along its length.

For coordinates, we will use the displacements of each mass, _x__n_. For large _N_ the displacement will vary approximately continuously with distance. We can regard it as a continuous function, _x_, with

    ![x\(n\\Delta a\)=x_n \\,](//upload.wikimedia.org/math/c/a/4/ca47dab8f214aad1367ac3240b7b149e.png)

The kinetic energy of the system is then simply

    ![T=\\frac{1}{2} \\Delta m \\sum_0^N \\dot{x}_n^2 ](//upload.wikimedia.org/math/e/1/9/e193d1d489c282ec9850586208f3ebe9.png)

The total potential energy is similarly

    ![V=\\frac{1}{2}k x_0^2 + \\frac{1}{2}k \\sum_1^N \(x_n-x_{n-1}\)^2 ](//upload.wikimedia.org/math/3/0/0/30026819ae7838d733f7bcad79d92581.png)

From this we may deduce the equations of motion in two different ways.

## Equations of motion: First approach[[edit](/w/index.php?title=General_Mechanics/The_Continuum_Limit&action=edit&section=T-2)]

If we take the large _N_ limit first, these sums become integrals.

    ![\\begin{matrix}
T & = & \\frac{m}{2a}\\sum_0^N \\dot{x}_n^2 \\Delta a \\\\
\\lim_{N \\rarr \\infty} T & = & \\frac{m}{2a} \\int_0^a \\dot{x}^2 ds
\\end{matrix}](//upload.wikimedia.org/math/b/4/7/b478c39376d7e166bc57b66b875451ef.png)

where _s_ is the distance from the wall, and

    ![\\begin{matrix}
V & = & \\frac{1}{2}k x_0^2 + \\frac{1}{2}k \\sum_0^{N-1} \(x_n-x_{n+1}\)^2 \\\\
  & = &  \\frac{1}{2}k x_0^2 + \\frac{1}{2}K \\sum 
\\left\( \\frac{ x\(n\\Delta a+\\Delta a\)- x\(n\\Delta a\)}{\\Delta a} \\right\)^2 a \\Delta a\\\\
\\lim_{N \\rarr \\infty} V & = &  \\frac{1}{2}k x\(0\)^2 
+ \\frac{1}{2}Ka \\int \\left\( \\frac{dx}{ds} \\right\)^2 ds
\\end{matrix}](//upload.wikimedia.org/math/d/2/b/d2b79743615add4948279719baca93ef.png)

Since the springs always remain attached to the wall, _x_(0)=0.

The integrand for _T_ is the product of the density and the square of the velocity, just as we might naively expect. Simalarly, _V_ is the integral of the potential energy of a infinitesimal spring over the length of the system.

Using the Lagrangian will let us get equations of motion from these integrals.

It is

    ![\\begin{matrix}
L & = & \\frac{m}{2a} \\int_0^a \\dot{x}^2 ds - \\frac{1}{2}Ka\\int_0^a \\left\( \\frac{dx}{ds} \\right\)^2 ds \\\\
& = & \\frac{m}{2a} \\int_0^a  \(\\dot{x}^2 - \\frac{Ka^2}{m} x^{\\prime 2}\) ds\\\\
\\end{matrix}](//upload.wikimedia.org/math/e/8/c/e8ce3001f28b2beab3b2c9851a148b73.png)

The action of the system is

    ![\\int L dt = \\int \\int \\mathcal{L}\(\\dot{x},x^\\prime\) dx dt \\quad 
\\mbox{ where } \\mathcal{L}=\\frac{m}{2a}\(\\dot{x}^2 - \\frac{Ka^2}{m} x^{\\prime 2}\) 
](//upload.wikimedia.org/math/2/e/9/2e902ee767f17c0e173fd0b1a3423592.png)

Here, we are integrating over both space and time, rather than just space, but this is still very similar in form to the action for a single particle.

We can expect that the principle of least action will lead us to the natural extension of Lagrange's equations to this action,

    ![\\frac{d}{ds}\\frac{\\partial \\mathcal{L}}{\\partial x^\\prime}+
\\frac{d}{dt}\\frac{\\partial \\mathcal{L}}{\\partial \\dot{x}} = 
\\frac{\\partial \\mathcal{L}}{\\partial x} ](//upload.wikimedia.org/math/0/f/e/0fe10cf7984ee272242cb913fa5ddc73.png)

This equation can be proven, using the calculus of variations. Using it for this particular Lagrangian gives

    ![\\frac{\\partial^2 x}{\\partial t^2} - \\frac{Ka^2}{m}\\frac{\\partial^2 x}{\\partial s^2} = 0](//upload.wikimedia.org/math/1/3/5/1355d4f774231f1e0bce4299f71c9fca.png)

This is a _partial differential equation_. We will not be discussing its solution in detail, but we will see that it describes waves.

First, though, we will confirm that these equations are the same as we get if we find the equations of motion first, then take the large _N_ limit.

## Equations of motion: Second approach[[edit](/w/index.php?title=General_Mechanics/The_Continuum_Limit&action=edit&section=T-3)]

First, we will look at the potential energy to see how it depends on the displacements.

![\\begin{matrix}
V & = & \\frac{1}{2}k x_0^2 + \\frac{1}{2}k \\sum_0^{N-1} \(x_n-x_{n+1}\)^2 \\\\
  & = & \\frac{1}{2}k \\left\( x_0^2 \\cdots \(x_{n-1}-x_n\)^2 + \(x_n-x_{n+1}\)^2
\\cdots  \(x_N-x_{N-1}\)^2 \\right\) \\\\
 & = & \\frac{1}{2}k \\left\(
2x_0^2 -2x_0 x_1 \\cdots -2x_n x_{n+1} + 2x^2_n -2x_n x_{n+1} \\cdots
x^2_N - 2x_N x_{N-1} \\right\) \\\\
 & = & \\frac{1}{2}k \\left\( 2x_0^2 -2x_0 x_1 \\cdots 2x_n \(x_n-x_{n+1}-x_{n-1}\) 
\\cdots x^2_N - 2x_N x_{N-1} \\right\) \\\\
\\end{matrix}](//upload.wikimedia.org/math/9/4/b/94b99cd1bad93714372de95d27dd35e7.png)

Notice that we need to treat the displacements of the first and last masses differently from the other coordinates, because the dependence of the Langragian on them is different.

The kinetic energy is symmetric in the coordinates,

    ![T=\\frac{1}{2} \\Delta m \\sum_0^N \\dot{x}_n^2](//upload.wikimedia.org/math/e/1/9/e193d1d489c282ec9850586208f3ebe9.png)

Using Lagrange's equations, we get that, for _x_0

    ![\\Delta m \\ddot{x}_0 + 2k x_0 = k x_1,](//upload.wikimedia.org/math/3/d/3/3d3083a55b1baa3cba36e1b80afd5c95.png)

for _x__N_,

    ![\\Delta m \\ddot{x}_N + k x_N = k x_{N-1},](//upload.wikimedia.org/math/4/7/2/47213b5fa1733fd149c5de80f7779951.png)

and, for all the other _x__n_

    ![\\Delta m \\ddot{x}_n + 2k x_n = k \(x_{n+1}+x_{n-1}\),](//upload.wikimedia.org/math/4/5/0/450dee16bf19b5a57b6dfa682257c957.png)

We can replace _k_ and Δ_m_ by the limiting values K and m using

    ![\\frac{k}{\\Delta m} = \\frac{K a^2}{m \\Delta a^2} ](//upload.wikimedia.org/math/b/6/e/b6e494688ce3ff58fe3534e2681d1d75.png)

giving us

    ![\\begin{matrix}
\\ddot{x}_0 & = & \\frac{K a^2}{m}  \\frac{x_1-2x_0}{\\Delta a^2}\\\\
\\ddot{x}_n & = & \\frac{K a^2}{m} \\frac{x_{n-1}+x_{n+1}-2x_n}{\\Delta a^2}\\\\
\\ddot{x}_N & = & \\frac{K a^2}{m} \\frac{x_{N-1}-x_N}{\\Delta a^2}
\\end{matrix}](//upload.wikimedia.org/math/1/4/2/142715d29aaa72ca04644f266500386f.png)

Looking at the general structure of the right hand side, we see difference between the displacement at nearby points divided by the distance between those points, so we expect that in the limit we will get differentials with respect to _s_, the distance from the wall.

As _N_ tends to infinity both _x_0 and _x_1 tend to _x_(0), which is always zero, so the equation of motion for _x_0 is always true.

In the continuum limit, the equation for _x__N_ becomes

    ![ \\ddot{x}\(a\) = -\\frac{K a^2}{m} \\frac{1}{\\Delta a} \\frac{dx}{ds} ](//upload.wikimedia.org/math/2/b/d/2bdc44d04ffef13891005a1a3d7bc300.png)

Since Δ_a_ tends to zero, for this to be true we must have _x_'=0 at _a_.

For the other displacements,

    ![\\begin{matrix}
\\lim_{\\Delta a \\rarr 0} \\frac{x_{n-1}+x_{n+1}-2x_n}{\\Delta a^2} & = & 
\\lim_{\\Delta a \\rarr 0} & \\frac{1}{\\Delta a} 
\\left\( \\frac{x_{n+1}-x_n}{\\Delta a} - \\frac{x_n-x_{n-1}}{\\Delta a} \\right\) \\\\
& = & \\lim_{\\Delta a \\rarr 0} &
\\frac{x^\\prime\(\(n+1\)\\Delta a\)-x^\\prime\(n\\Delta a\)}{\\Delta a} \\\\
& = & \\left. \\frac{d^2 x}{ds^2} \\right|_{x=a} & \\\\ \\end{matrix}](//upload.wikimedia.org/math/3/4/d/34d98e57aedfb3124951b4846db08b46.png)

so we get the equation

    ![\\frac{\\partial^2 x}{\\partial t^2} - \\frac{Ka^2}{m}\\frac{\\partial^2 x}{\\partial s^2} = 0](//upload.wikimedia.org/math/1/3/5/1355d4f774231f1e0bce4299f71c9fca.png)

just as with the other approach.

## Waves[[edit](/w/index.php?title=General_Mechanics/The_Continuum_Limit&action=edit&section=T-4)]

It is intuitively obvious that if we flick one of the masses in this system, vibrations will propagate down the springs, like waves, so we look for solutions of that form.

A generic travelling wave is

    ![x = A \\sin \(\\omega t - \\kappa x + \\alpha\) \\,](//upload.wikimedia.org/math/6/d/2/6d21b5e3488be0bf1bac15fbcb40a531.png)

Substituting this informed guess into the equation gives

    ![ -A \\omega^2 \\sin \(\\omega t - \\kappa x + \\alpha\) = 
-\\frac{Ka^2}{m} \\kappa^2 \\sin \(\\omega t - \\kappa x + \\alpha\) ](//upload.wikimedia.org/math/5/2/5/525361142cb2440a973c8901df95b590.png)

so this wave is a solution provide the frequency and wavenumber are related by

    ![ \\omega^2 =  \\frac{Ka^2}{m} \\kappa^2 ](//upload.wikimedia.org/math/4/e/6/4e6ad60e09472a46981e4c269becd470.png)

The speed of these waves, _c_, is

    ![c = \\frac{d\\omega}{d\\kappa} = \\pm \\sqrt{\\frac{Ka^2}{m}}](//upload.wikimedia.org/math/c/5/0/c50f8d000ab56824f47e017a5e7c4d4f.png)

Thus, we've gone from Newton's laws to waves.

We can do the same starting with a three-dimensional array of particles, and deduce the equations for longitudinal and transverse waves in a solid. Everything we said about waves earlier will be true for these systems.

This particular system has two boundary conditions: the displacement is zero at the wall, and a local extrema at the free end. This is typical of all such problems.

When we take account of the boundary conditions we find that the correct solutions is a combination of standing waves, of the form

    ![x = A_m \\sin \\left\( \\frac{2b+1}{2}\\frac{\\pi s}{a} \\right\) 
\\sin \\left\( \\sqrt{\\frac{Ka^2}{m}}\\frac{2b+1}{2}\\frac{\\pi}{a}t +\\alpha_m \\right\) ](//upload.wikimedia.org/math/1/7/f/17fd9479232546968925ae0bceff24c9.png)

where _b_ is any integer.

If we also knew the initial displacement we could use Fourier series to obtain the exact solution for all time.

In practice, _N_ is typically large but finite, so the continuum limit is only approximately true. Allowing for this would give us a power series in 1/_N_, describing small corrections to the approximation. These corrections can produce interesting effects, including solutions, but we will not calculate them here.

The continuum limit also fails for small wavelengths, comparable with the particle spacing.

## Fields[[edit](/w/index.php?title=General_Mechanics/The_Continuum_Limit&action=edit&section=T-5)]

In the continuum limit, the spring is described by a variable which is a function of both position and time. Variable such as this are commonly referred to as _fields._

At first sight, classical fields look quite different to classical particles. In one case position is the dependent variable; in the other, it is an independent variable. However, as the above calculations suggest, fields and particles have an underlying unity, if we take a Lagrangian approach.

We can deal with both using essentially the same mathematical techniques, extracting information about both the field and the particles in that field from the same source.

E.g., once we know the Lagrangian for electromagnetism, we can deduce both the partial differential equations for the EM fields, and the forces on charged particles in those fields, from it. We will see precisely how later, when we come to study electromagnetism.

In the example above, the field Lagrangian was the continuum limit of a Lagrangian for the discrete system. It did not have to be. We can investigate the fields described by any Lagrangian we like, whether or not there is an underlying mechanical system.

So far, we've looked at waves and movement under Newton's law, and seen how the study of movement can lead us back to waves. Next, we will look at special relativity, and see how Einstein's insights affect all this.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=General_Mechanics/Print_Version&oldid=1693842](http://en.wikibooks.org/w/index.php?title=General_Mechanics/Print_Version&oldid=1693842)" 

[Category](/wiki/Special:Categories): 

  * [General Mechanics](/wiki/Category:General_Mechanics)

Hidden category: 

  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=General+Mechanics%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=General+Mechanics%2FPrint+Version)

### Namespaces

  * [Book](/wiki/General_Mechanics/Print_Version)
  * [Discussion](/w/index.php?title=Talk:General_Mechanics/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=General_Mechanics/Print_Version&stable=1)
  * [Latest draft](/w/index.php?title=General_Mechanics/Print_Version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=General_Mechanics/Print_Version&action=edit)
  * [View history](/w/index.php?title=General_Mechanics/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/General_Mechanics/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/General_Mechanics/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=General_Mechanics/Print_Version&oldid=1693842)
  * [Page information](/w/index.php?title=General_Mechanics/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=General_Mechanics%2FPrint_Version&id=1693842)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=General+Mechanics%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=General+Mechanics%2FPrint+Version&oldid=1693842&writer=rl)
  * [Printable version](/w/index.php?title=General_Mechanics/Print_Version&printable=yes)

  * This page was last modified on 8 January 2010, at 23:55.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/General_Mechanics/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
