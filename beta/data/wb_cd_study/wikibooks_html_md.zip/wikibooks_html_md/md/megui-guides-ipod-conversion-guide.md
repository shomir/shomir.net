# MeGUI/Guides/iPod Conversion Guide/Print version

From Wikibooks, open books for an open world

< [MeGUI](/wiki/MeGUI) | [Guides](/wiki/MeGUI/Guides) | [iPod Conversion Guide](/wiki/MeGUI/Guides/iPod_Conversion_Guide)

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [MeGUI/Guides/iPod Conversion Guide](/wiki/MeGUI/Guides/iPod_Conversion_Guide)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=purge&printable=yes) this page.

## Contents

  * 1 Introduction
  * 2 Set up
    * 2.1 Basic Info
    * 2.2 Required Programs
    * 2.3 Program Setup
  * 3 Encoding audio
    * 3.1 Basic Info
    * 3.2 Setting up your iPod Profile
    * 3.3 Encoding the Audio
  * 4 Encoding video
    * 4.1 Basic Info
    * 4.2 x264 Preset Setup
    * 4.3 Encoding
  * 5 Muxing streams
    * 5.1 Basic Info
    * 5.2 Muxing

# Introduction[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=edit&section=1)]

![100% developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/100%25.svg/24px-100%25.svg.png)

This Guide will be a walkthrough for the encoding and muxing of an **4th\- & 5th-generation iPod touch**, **iPhone 4**, or **iPad 1st generation & 2** compatible file from a video file. This guide is for use by anyone, newbie or advanced user. This Guide assumes that you know how to create an AVS script and calculate video bitrate. If you do not know how to create an Avisynth script then go [here](/wiki/MeGUI/Guides/Basic_Guide/Video#Creating_the_AviSynth_file). If you do not know how to calculate video bitrate then go [here](/wiki/MeGUI/Guides/Calculating_video_bitrate).

**It Covers:**

  * [Setting up the required programs](/wiki/MeGUI/Guides/iPod_Conversion_Guide/Setup)
  * [Encoding the audio](/wiki/MeGUI/Guides/iPod_Conversion_Guide/Audio), which involves encoding the audio to meet acceptable iPod standards.
  * [Encoding the video](/wiki/MeGUI/Guides/iPod_Conversion_Guide/Video), which involves encoding the video correctly with x264.
  * [Muxing the resulted streams into an mp4 file](/wiki/MeGUI/Guides/iPod_Conversion_Guide/Muxing) to be imported to iTunes.

**It does not cover:**

  * Subtitles.
  * More than one Video or Audio Stream.
  * 5.1 Audio

  


# Set up[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=edit&section=2)]

## Basic Info[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Setup&action=edit&section=T-1)]

This section deals with downloading, installing and configuring the required programs correctly.

## Required Programs[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Setup&action=edit&section=T-2)]

  * MeGUI. For guide on installing MeGUI, read the instructions [here](/wiki/MeGUI/Installation).
  * Any DirectShow filter (or "Codec Pack") that can decode the source file format. There are a few free codec packs: 
    * The **K-Lite Codec Pack** is a complete solution of decoding the majority of files. It contains some more video and audio processing features comparing to the CCCP. Please visit [[1]](http://www.codecguide.com/about_kl.htm) for more information.
    * The CCCP is a codec pack that installs a minimal set of filters that decode the vast majority of files (see [[2]](http://www.cccp-project.net/wiki/index.php?title=FAQ#What_exactly_can_the_CCCP_play.3F) for more info).

## Program Setup[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Setup&action=edit&section=T-3)]

  * **MeGUI:** MeGUI requires no additional setup after you have fully updated it. By default, it will prompt you to update whenever there is one.

  


# Encoding audio[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=edit&section=3)]

## Basic Info[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Audio&action=edit&section=T-1)]

This section covers encoding the audio to reach an iPod compatible standard.

## Setting up your iPod Profile[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Audio&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/12/MeGUI_iPod_encoding_audio_config_box.png/220px-MeGUI_iPod_encoding_audio_config_box.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The items needed attention are in red boxes.

We are going to add an iPod profile to simplify future encoding for MeGUI.

  * In the main window of **MeGUI** go to the audio section. In the Drop down list that is labelled "Codec", choose **"Nero AAC: *scratchpad*"**. Click "Config".
  * Set your settings like the ones shown on the right. 
    * In **"Output channels"**, select **"Downmix Multichannel to stereo"**.
    * Select **"Constant Bitrate"**. Set the slider to **"320kbit/s"**.
    * Set the AAC profile to **AAC-LC**
  * Click "New". Type "iPod Profile". Click "OK"

## Encoding the Audio[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Audio&action=edit&section=T-3)]

All modern iPods supports AAC audio, and it is the best audio codec that MeGUI supports encoding to. We have to use the Nero AAC encoder as it is the only AAC encoder available in MeGUI.

  * On the first page of **MeGUI** click the [...] button next to audio input. Browse for your input file and open it.
  * Click the [...] button next to audio output. Remember the location of the file as it will be used later.
  * Select your iPod Profile in the profiles drop down list.
  * When you are ready, click **Queue**.

  


# Encoding video[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=edit&section=4)]

## Basic Info[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Video&action=edit&section=T-1)]

This section will walkthrough the encoding of an iPod-compatible video file using either Xvid or x264. You can't just use any settings to encode for the iPod, there are limits as it is a portable device and not capable of everything. Here's a table of the more generic restrictions.

iPod touch (4th generation) video specifications [[3]](http://support.apple.com/kb/SP594)

[MPEG-4 AVC](/wiki/MeGUI/Computer_movie_files#MPEG-4_AVC) [MPEG-4 ASP](/wiki/MeGUI/Computer_movie_files#MPEG-4_ASP)

Bitrate
No restriction
25000 kbps

Frame rate
30 fps

Profile
Main @ 3.1
Simple

Max resolution (pixels)
1280 by 720
640 by 480

Max 4:3 resolution (pixels)
960 by 720
640 by 480

Max 16:9 resolution (pixels)
1280 by 720
640 by 360

Container
.m4v, .mp4, or .mov

According to the table, AVC support is significantly better than ASP, so you are encouraged to use AVC.

Note: In your AVS file you will need to resize your video to iPod Standards. You can go below these standards if you like, but **not** above.

## x264 Preset Setup[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Video&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/MeGUI_iPod_encoding_x264_options.png/220px-MeGUI_iPod_encoding_x264_options.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Setting up presets.

We will set up an encoding preset for convenience.

  * Open **MeGUI** to its main window.
  * Select **x264: *scratchpad*** in the codec drop down list. Click "Config".
  * Under **Target Playback Device**, select **iPhone 4, iPad 1/2, iPod touch 4/5** in the drop down list.
  * Click "New" under "Presets", type in "iPod".

## Encoding[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Video&action=edit&section=T-3)]

Once you have finished creating your presets, you can use them! Return to the MeGUI main window.

  * Select your **Video Profile** first. Use **x264: iPod** for **X264** output.
  * Open your AVS script if you have it, and create if not. 
    * When you are creating the AVS script, you **must** resize it to 1280 lines, or your iPod will not play it.
  * Now, select **RAWAVC** for your container.
  * Calculate your bitrate using Bitrate Calculator. Click "Yes" when asked if you want to copy calculated bitrate into video settings.
  * Check that the input AVS script is OK with your iPod. Go to **Tools** -> **AVC Levels Checker**. 
    * If it outputs **"This file matches the criteria"**, then you are good and click "OK".
    * If it outputs other things, then there's something wrong. Make sure your source file is less than or equal to 1280 px by 720 px, or make another AVS script using the "Resize" feature in AVS creator.
  * Finally, select your Video Output location. Remember that your encoded video will have an extension of ".264".
  * Click **Queue**.

  


# Muxing streams[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=edit&section=5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/95/MeGUI_iPod_encoding_selecting_MP4_Muxer.png/220px-MeGUI_iPod_encoding_selecting_MP4_Muxer.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Click Tools. Scroll down to Muxer. Click MP4 Muxer.

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/4a/MeGUI_iPod_encoding_MP4_Muxer_dialog.png/220px-MeGUI_iPod_encoding_MP4_Muxer_dialog.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The options that should be changed are in red boxes.

## Basic Info[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Muxing&action=edit&section=T-1)]

This will cover the requirements of muxing a iPod capable MP4 file with an audio stream, a video stream, and an optional chapter stream.

## Muxing[[edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Muxing&action=edit&section=T-2)]

  * Open MeGUI. Click **Tools**. Scroll down to **Muxer**. Click **MP4 Muxer**.
  * Under video input, browse for your encoded ".264" video file. Leave the **Name** section blank for safety.
  * Under audio input, browse for your encoded ".mp4" audio file.
  * Under chapters, you can add your optional chapter file.
  * Under output, select your target device in "Device type" (iPod or iPhone).
  * Scroll down to **Muxed Output**. Select your file destination. Click **Queue**.

When you are done, load the file into iTunes and transfer it to your iPod. Happy Viewing!

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&oldid=2515733](http://en.wikibooks.org/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&oldid=2515733)" 

[Category](/wiki/Special:Categories): 

  * [MeGUI/Guides](/wiki/Category:MeGUI/Guides)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=MeGUI%2FGuides%2FiPod+Conversion+Guide%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=MeGUI%2FGuides%2FiPod+Conversion+Guide%2FPrint+version)

### Namespaces

  * [Book](/wiki/MeGUI/Guides/iPod_Conversion_Guide/Print_version)
  * [Discussion](/w/index.php?title=Talk:MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/MeGUI/Guides/iPod_Conversion_Guide/Print_version)
  * [Edit](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=edit)
  * [View history](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/MeGUI/Guides/iPod_Conversion_Guide/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/MeGUI/Guides/iPod_Conversion_Guide/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&oldid=2515733)
  * [Page information](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=MeGUI%2FGuides%2FiPod_Conversion_Guide%2FPrint_version&id=2515733)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=MeGUI%2FGuides%2FiPod+Conversion+Guide%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=MeGUI%2FGuides%2FiPod+Conversion+Guide%2FPrint+version&oldid=2515733&writer=rl)
  * [Printable version](/w/index.php?title=MeGUI/Guides/iPod_Conversion_Guide/Print_version&printable=yes)

  * This page was last modified on 24 April 2013, at 00:20.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/MeGUI/Guides/iPod_Conversion_Guide/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
