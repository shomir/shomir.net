# Bodybuilding and Weight Training/Print version

From Wikibooks, open books for an open world

< [Bodybuilding and Weight Training](/wiki/Bodybuilding_and_Weight_Training)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Bodybuilding_and_Weight_Training/Print_version) on _1 January 2010_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&oldid=1634319&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


## Contents

  * 1 Introduction
  * 2 Finding a Gym
    * 2.1 Finding A Gym
  * 3 Bench_Presses
  * 4 Dumbell Curls

# Introduction

Bodybuilding can be a fun and engaging sport. It can also be dangerous if not taken seriously, however, injury is rare and should not be a reason to stay away.

There are a few important questions to ask yourself before you start:

1\. **Where will you work out, and when?** At least three days per week are recommended (not consecutively, though, because your muscles need time to rest and grow in between workout days). Your workout might average somewhere around half an hour to an hour for an average workout.

2\. **Can you manage to eat several meals high in protein every day?** Almost all bodybuilders recommend a high-protein diet. This is important, because protein is the "building block" of muscle. How much protein should you be willing to consume? A common range is 1.0 to 1.5 grams of protein per day for each pound of your body weight (for example: if you weigh 160 pounds, you should try to consume 160 to 240 grams of protein every day for the best results). Be aware that protein supplements are available, such as whey protein powder, but it is generally advocated that at least half of your daily protein intake consists of "real" foods as opposed to protein supplements. Also, many bodybuilders believe it's best to eat around six smaller meals in your day instead of three large meals if you're able.

3\. **What are your goals?** Is your goal to become generally stronger? Perhaps your goal is to transform your body? Depending on your goals, you may need to adjust your workout accordingly. For example, if you're looking to not only gain muscle but also lose fat, you may want to use your resting days as cardio-workout days where you can do cardio exercises such as running and swimming.

  


# Finding a Gym

## Finding A Gym

Finding a gym can be a difficult task. You can do a few things. For example there's probably a recreation center or fitness club in your area. Try looking in the telephone book to find numbers of local workout centers. Many high schools also have designated days where you can come and use the gym for a small fee. Ask friends where they work out and find out others opinions on places you might want to go. Or, if you want to work out close to home, build your own gym. You can get weights, a yoga mat, a treadmill (or take walks), workout bicycle (or bike around), and jump ropes. You can do all your working out in your home at a very low cost. Research what option is best for you, and go for it. This is the easy part!

Created By: [writerhawk](/wiki/User:Witerhawk) 23:21, 30 May 2006 (UTC)

  


# Bench_Presses

* * *

The Bench press

* * *

Main Muscles Used:

Chest, Triceps

* * *

Description:

* * *

The bench press is similar to a push up. however, the differences are that the performers body position is reversed, where the person is lying with their back on a bench like seat and pushing weights connected to two sides of a standard 45 pound metal bar instead of their body weight.

weights used are in common sizes of 45lbs, 35lbs, 25lbs, 10lbs, 5lbs, and 2.5 pound cookies.

Starting position is the bar with, for example, two 45 pound weights on both sides (135 pounds) set on the starting point.

The lifter then positions themselves under the bar near the neck and positions their arms for the bench press. Arms held closer together puts more focus on the triceps, where as the opposite puts more focus on the chest. Find a comfortable grip (this varies by each lifter.)

The lifter then lifts the weights off the hooks holding the bar+weights, and positions it across their chest. This is followed by a lowering of the weights, then pushing it back up to the starting point. Some say one should lower the bar completely to your chest. However, this may cause injuries. Forcing the bar to your chest when it does not occur naturally can cause temporary to permanent injuries to your elbows.

* * *

Common Exercises:

* * *

3 sets of 8 with stretching and a few minutes of rest in between each set. weights lifted vary from person to person. however, it should be a weight that allows the last set to be completed, but at the same time, moderately intense/tiring.

Pyramid sets are also used as a high intensity workout. sets go from 8, 6, 4, 2, 4, 6, 8 with increasing weight, and then decreased as the sets increase again. example of weight increase Example: 8 x 95, 6 x 105, 4 x 125, 2 x 135, 4 x 125, 6x 105, 8x 95

* * *

Safety:

* * *

In general, it is always good to have a spotter when dealing with free wweights. especially with a bench press. failure to be able to lift the weight back onto the safety bar after dismounting it can result in severe injury and even death. A spotter is there to help you live in case of these events.

Also, when bench pressing, avoid over-training to prevent injuries. be smart and lift an amount of weight where it can help you advance in your climb in weight lifting, but not injure you.

Make sure your equipment is in good condition and working order . "Hardware failure" with heavy weights involving you is not fun.

Good form prevents stupid injuries.

Most of all, Have fun!

* * *

Variations of the Bench press

* * *

\- Incline Press - Decline Press

Each variation works a different area of the general chest area (the upper area and lower area) and are done on an inclining or declining bench.

  


# Dumbell Curls

[Bodybuilding and Weight Training/Dumbell Curls](/w/index.php?title=Bodybuilding_and_Weight_Training/Dumbell_Curls&action=edit&redlink=1)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&oldid=1634319](http://en.wikibooks.org/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&oldid=1634319)" 

[Category](/wiki/Special:Categories): 

  * [Bodybuilding and Weight Training](/wiki/Category:Bodybuilding_and_Weight_Training)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Bodybuilding+and+Weight+Training%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Bodybuilding+and+Weight+Training%2FPrint+version)

### Namespaces

  * [Book](/wiki/Bodybuilding_and_Weight_Training/Print_version)
  * [Discussion](/w/index.php?title=Talk:Bodybuilding_and_Weight_Training/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&action=edit)
  * [View history](/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Bodybuilding_and_Weight_Training/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Bodybuilding_and_Weight_Training/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&oldid=1634319)
  * [Page information](/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Bodybuilding_and_Weight_Training%2FPrint_version&id=1634319)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Bodybuilding+and+Weight+Training%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Bodybuilding+and+Weight+Training%2FPrint+version&oldid=1634319&writer=rl)
  * [Printable version](/w/index.php?title=Bodybuilding_and_Weight_Training/Print_version&printable=yes)

  * This page was last modified on 24 September 2009, at 18:16.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Bodybuilding_and_Weight_Training/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
