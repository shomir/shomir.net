# Engineering Thermodynamics/Print version

From Wikibooks, open books for an open world

< [Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Engineering_Thermodynamics/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Engineering_Thermodynamics/Print_version) on _14 November 2012_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Engineering_Thermodynamics/Print_version&oldid=2440944&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


## Contents

  * 1 Preface
  * 2 Introduction
    * 2.1 Introduction to Classical Thermodynamics
      * 2.1.1 The Main Macroscopic Forms of Energy
        * 2.1.1.1 Kinetic Energy
        * 2.1.1.2 Potential Energy
        * 2.1.1.3 Internal Energy of Matter
  * 3 Thermodynamic Systems
    * 3.1 Properties of Pure Substances
      * 3.1.1 Volume
      * 3.1.2 Pressure
      * 3.1.3 Temperature
    * 3.2 Thermodynamic Systems
      * 3.2.1 Systems
      * 3.2.2 Processes
      * 3.2.3 Isothermal Process
    * 3.3 Zeroth Law of Thermodynamics
    * 3.4 Temperature Measurement
    * 3.5 The Ideal Gas
  * 4 Zeroth Law
  * 5 First Law
    * 5.1 Energy
    * 5.2 Work
      * 5.2.1 Flow Energy
      * 5.2.2 Examples of Work
      * 5.2.3 Work in a Polytropic Process
    * 5.3 Heat
      * 5.3.1 Specific Heat
      * 5.3.2 Latent Heat
      * 5.3.3 Adiabatic Process
    * 5.4 First Law of Thermodynamics
      * 5.4.1 Joule Experiments
    * 5.5 Statement of the First Law for a Closed System
      * 5.5.1 Internal Energy
      * 5.5.2 Internal Energy for an Ideal Gas
    * 5.6 Enthalpy
      * 5.6.1 Throttling
  * 6 Second Law
    * 6.1 Introduction
    * 6.2 Introduction
    * 6.3 Statement of the Second Law of Thermodynamics
      * 6.3.1 Kelvin-Planck Statement
      * 6.3.2 Clausius Statement
      * 6.3.3 PMM2
      * 6.3.4 Equivalence of Clausius and Kelvin-Planck Statements
    * 6.4 Carnot Cycle
    * 6.5 Thermodynamic Temperature Scale
    * 6.6 Statement of the Second Law of Thermodynamics
      * 6.6.1 Kelvin-Planck Statement
      * 6.6.2 Clausius Statement
      * 6.6.3 Equivalence of Clausius and Kelvin-Planck Statements
    * 6.7 Carnot Cycle
    * 6.8 Thermodynamic Temperature Scale
    * 6.9 NOTE
    * 6.10 Clausius Theorem
    * 6.11 Entropy
      * 6.11.1 Entropy for an Ideal Gas
    * 6.12 Availability
      * 6.12.1 Availability Function
      * 6.12.2 Irreversibility
      * 6.12.3 Helmholtz and Gibbs Free Energies
  * 7 Third Law
    * 7.1 Third Law of Thermodynamics
  * 8 Applications
    * 8.1 One Component Systems
      * 8.1.1 Gibbs Phase Rule
    * 8.2 Psychrometry
      * 8.2.1 Adiabatic Saturation
      * 8.2.2 Wet Bulb Temperature
      * 8.2.3 Psychrometric Chart
      * 8.2.4 Air Conditioning
    * 8.3 Common Thermodynamic Cycles
      * 8.3.1 Rankine Cycle
      * 8.3.2 Otto Cycle
        * 8.3.2.1 Analysis
      * 8.3.3 Diesel Cycle
        * 8.3.3.1 Analysis
      * 8.3.4 Dual Cycle
      * 8.3.5 Gas Turbine Cycle (or Joule-Brayton Cycle)
        * 8.3.5.1 Analysis
      * 8.3.6 Refrigeration Cycles
  * 9 Further Reading

# Preface

The topic of thermodynamics is taught in Physics and Chemistry courses as part of the regular curriculum. This book deals with Engineering Thermodynamics, where concepts of thermodynamics are used to solve engineering problems. Engineers use thermodynamics to calculate the fuel efficiency of engines, and to find ways to make more efficient systems, be they rockets, refineries, or nuclear reactors. One aspect of "engineering" in the title is that a lot of the data used is empirical (_e.g._ steam tables), since you won't find clean algebraic equations of state for many common working substances. Thermodynamics is the science that deals with transfer of heat and work. Engineering thermodynamics develops the theory and techniques required to use empirical thermodynamic data effectively. However, with the advent of computers most of these techniques are transparent to the engineer, and instead of looking data up in tables, computer applications can be queried to retrieve the required values and use them in calculations. There are even applications which are tailored to specific areas which will give answers for common design situations. But thorough understanding will only come with knowledge of underlying principles, and the ability to judge the limitations of empirical data is perhaps the most important gain from such knowledge.

This book is a work in progress. It is hoped that as it matures, it will be more up to date than the dead tree editions.

Thermodynamics is the study of the relationships between HEAT (thermos) and WORK (dynamics). Thus, it deals with energy interactions in physical systems. Classical thermodynamics can be stated in four laws called the zeroth, first, second, and third laws respectively. The _laws_ of thermodynamics are empirical, _i.e._, they are deduced from experience, and supported by a large body of experimental evidence.

The first chapter is an introduction to thermodynamics, and presents the motivation and scope of the topic. The second chapter, [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems), defines some basic terms which are used throughout the book. In particular, the concepts of system and processes are discussed. The zeroth law is stated and the concept of temperature is developed. The next chapter, [First Law](/wiki/Engineering_Thermodynamics/First_Law), develops ideas required for the statement of the first law of thermodynamics. [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) deals with heat engines and the concept of entropy. [Applications](/wiki/Engineering_Thermodynamics/Applications) of the tools developed in the previous chapters are illustrated, including the use of thermodynamics in everyday engineering situations. [Appendix](/w/index.php?title=Engineering_Thermodynamics/Appendix&action=edit&redlink=1) gives a list of tables for some commonly used properties.

This course forms the foundation for the [Heat Transfer](/wiki/Heat_Transfer) course, where the _rate_ and mechanisms of transmission of energy in the form of heat is studied. The concepts will be used in further courses in heat, [Internal Combustion Engines](/w/index.php?title=Internal_Combustion_Engines&action=edit&redlink=1), [Refrigeration and Air Conditioning](/w/index.php?title=Refrigeration_and_Air_Conditioning&action=edit&redlink=1), and [Turbomachines](/w/index.php?title=Turbomachines&action=edit&redlink=1) to name a few.

  


# Introduction

## Introduction to Classical Thermodynamics

Thermodynamics is the study of energies. More specifically, introductory thermodynamics is the study of energy transfer in systems. Classical thermodynamics consists of methods and constructs that are used to “account” for macroscopic energy transfer. In fact, energy accounting is an appropriate synonym for classical thermodynamics. In much the same way that accountants balance money in and money out of a bank account, rocket scientists simply balance the energy in and out of a rocket engine. Of course just as a bank account’s balance is obfuscated by arcane devices such as interest rates and currency exchange, so too is thermodynamics clouded with seemingly difficult concepts such as irreversibility and enthalpy. But, also just like accounting, a careful review of the rules suggests a coherent strategy for maintaining tabs on a particular account.

If a statement about the simplicity of thermodynamics failed to convert would-be students, they may be captured with a few words on the importance of understanding energy transfer in our society. Up until about 150 years ago or so, the earth’s economy was primarily fueled by carbohydrates. That is to say, humans got stuff done by converting food, through a biological process, to fuel we could spend to do work (e.g. raise barns). This was a hindrance to getting things accomplished, because it turned out that most of that energy went to growing and cultivating more carbohydrates (e.g. crops and livestock). We won’t even talk about how much food the horses ate!

Today, we have the luxury, primarily through an understanding of energy, to concentrate our energy production into efficient low maintenance operations. Massive power plants transfer energy to power tools for raising barns. Extremely efficient rocket engines tame and direct massive amounts of energy to blast TV satellites into orbit. This improvement in energy mastery frees humanity’s time to engage in more worthwhile activities such as watching cable TV. Although most are content to blissfully ignore the intricacies that command their way of life, I challenge you to embrace the contrary.

By no means is the energy battle over. Understanding energy transfer and energy systems is the second step to overcoming the limits to what humanity can accomplish. The first step is commanding an interest in doing so from an inclined portion of the population. Given the reader (and editor) has read this far through this aggrandizing rhetoric, I welcome your interest and hope to see it continue until the end.

### The Main Macroscopic Forms of Energy

It will be in the best interest of the reader to have defined energy before it is discussed further. There are three primary forms of energy that are discussed in macroscopic thermodynamics. Several other forms of energy exist, but they generally exist on a microscopic level and should be deferred to more advanced study.

#### Kinetic Energy

The first form (probably most easily understood idea of energy) is defined by the motion of an object. Kinetic energy is the energy of a moving mass. For instance, a moving car will have more kinetic energy than a stationary car. The same car traveling at 60 km/h has more kinetic energy than it does traveling at 30 km/h.

Kinetic Energy = (1/2) x (mass) x (velocity)2

Ratio of v602 / v302 =((60)(1,000 meters/sec)(3600 sec/hour))2 / ((30)(1,000 meters/sec)(3,600 sec/hour))2

So, once the algebra is completed properly we find the vehicle traveling at 60 km/h has four times the kinetic energy as when it is traveling at 30 km/h, while the vehicle has zero kinetic energy when it is stationary because the velocity = zero(0) results in 1/2mv2(1/2*m*0=0) being zero.

#### Potential Energy

The second type of energy is called potential energy. Gravitational potential energy describes the energy due to elevation. A car at a height of 50 m has more potential energy than a car at a height of 25 m. This may be understood more easily if the car is allowed to drop from its height. On impact with the earth at 0 m, the car that initially rested at 50 m will have more kinetic energy because it was moving faster (allowed more time to accelerate). The idea that potential energy can convert to kinetic energy is the first idea of energy transfer. Transfers between kinetic and potential energy represent one type of account balance rocket scientists need be aware of.

Potential Energy = (mass)*(acceleration due to gravity)*(elevation with respect to reference line) .

#### Internal Energy of Matter

The third and most important concept of energy is reflected by temperature. The internal energy of matter is measured by its temperature. Hot water has more internal energy than the same amount of cold water. Internal energy is a measure of kinetic energy of the molecules and atoms that make up the substance. Since each atom or molecule is acting on its own accord, this internal energy is different from the bulk kinetic energy associated with the movement of the entire solid. The internal energy of matter is exhibited by molecular motion. The molecules of a gas at high temperature zip around their container constantly colliding with walls and other molecules. The molecules of a high temperature solid also move around a lot; however, since they are stuck together with other molecules, the most they can do is vibrate in place.

In a nutshell, the above forms of energy are studied in classical thermodynamics. Those forms of energy are allowed to transfer among each other as well as in to or out of a system. Thermodynamics essentially provides some definitions for interpreting thermodynamic systems. It then goes on to define an important rule about fairly balancing energy and one rule about the quality of energy. (some energy is more valuable) Understanding the framework and the few rules that govern macroscopic thermodynamics proves to be an incredibly powerful set of tools for analyzing a myriad of not only engineering problems, but issues of practical concern. CONTRIBUTION BY CHANGES

  


# Thermodynamic Systems

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

* * *

## Properties of Pure Substances

A cursory review of properties will introduce the variables of thermodynamics to the student. Properties of substances are things such as mass, temperature, volume, and pressure. Properties are used to define the current state of a substance. Several more properties exist to describe substances in thermodynamics, but a stronger understanding of theory is required for their definition and application.

Properties can be _intensive_, if they are point properties (properties that make sense for a point) or _extensive_, if they depend on the amount of matter in the system. Examples of extensive properties of systems are mass of system, number of moles of a substance in a system, and overall or total volume of a system. These properties depend on how much matter of the system you measure. Examples of intensive properties are pressure, temperature, density, volume per mass, molar volume (which is volume per mole), and average molecular weight (or molecular mass). These properties are the same regardless of how you vary the amount of mass of the substance.

Properties are like the variables for substances in that their values are all related by an equation. The relationship between properties is expressed in the form of an equation which is called an _equation of state_. Perhaps the most famous state equation is the Ideal Gas Law. The ideal gas law relates the pressure, volume, and temperature of an ideal gas to one another.

### Volume

**The SI unit for volume is _m3_.** Volume is an extensive property, but both volume per mass and molar volume are intensive properties since they do not depend on the measured mass of the system. A process during which the volume of the system remains constant is called an _isochoric_ process.

### Pressure

The SI unit for pressure is Pa (Pascal), which is equivalent to a ![ N/\(m^2\)](//upload.wikimedia.org/math/6/5/1/6517a23e74c17e72b339b188753a74c6.png). Pressure is an intensive property. A process in which pressure remains constant is called _isobaric_ process.

### Temperature

Temperature, the degree of hotness or coldness of a body.Defined based on the zeroth law of thermodynamics, is a fundamental concept of thermodynamics. We know that a body at high temperature will transfer energy to one at lower temperature. Consider two bodies with different temperatures in contact with each other. Net energy transfer will be from the hotter body to the colder body. At some point, the net energy transfer will be zero, and the bodies are said to be in _thermal equilibrium_. Bodies in thermal equilibrium are defined to have the same temperature.

## Thermodynamic Systems

![Thermodynamic System](//upload.wikimedia.org/wikibooks/en/9/95/System_Engineering_Thermodynamics.png)

In general, a system is a collection of objects, and there is a lot of subtlety in the way it is defined, as in set theory. However, in thermodynamics, it is a much more straightforward concept. A _thermodynamic system_ is defined as a volume in space or a well defined set of materials (matter). The imaginary outer edge of the system is called its _boundary_.

As can be seen from the definition, the boundary can be fixed or moving. A system in which matter crosses the boundary is called an _open_ system.in simple terms,a system which can exchange matter as well as energy with surroundings is a open system. where as a system which can exchange only energy with surrounding is a closed system.ex:liquid in sealed tube. The above image shows a piston cylinder arrangement, where a gas is compressed by the piston. The dotted lines represent the system boundary. As can be seen, due to an opening in the cylinder, gas can escape outside as the piston moves inwards, and gas enters the system when the piston moves outwards. Thus, it is an open system.

![closed system](//upload.wikimedia.org/wikibooks/en/a/ab/Closed_system_Engineering_Thermodynamics.png)

Now consider a similar system, but one in which gas cannot escape. In practice, there might be some space between the piston and the cylinder, but we can ignore it for modeling purposes. Thus the model of this configuration is a closed system.

The region outside the system is called the _surroundings_. The system and the surroundings together are called the _Universe_. A system which does not exchange matter or energy with the surroundings is called an _isolated system_.

Another term sometimes used instead of _system_ is _control volume_. In the case of a closed system, in which the mass of matter inside the system remains constant, the control volume is referred to as _control mass_. A control volume is said to be enclosed by a _control surface_.

### Systems

Classical thermodynamics deals with systems in _equilibrium_. The equilibrium state is defined by the values of observable quantities in the system. These are called _system properties_.

The minimum number of variables required to describe the system depends on the complexity or _degrees of freedom_ of the system. Degrees of freedom refer to the number of properties that can be varied independently of each other in a system. Some of the common system variables are pressure, temperature, and density, though any other physical properties may be used.

Consistent with the axiomatic nature of subject development, many of the relationships between physical properties cannot be completely specified without further development of theory. What is good about classical thermodynamics is that many of the axioms stated here can be derived using techniques of statistical thermodynamics. And statistical thermodynamics gives results in many cases where classical thermodynamics fails, such as in the specific heats of gases with many degrees of freedom. In some sense, the relationship between classical and statistical thermodynamics is similar to the one between classical and quantum mechanics, _i.e._, classical thermodynamics approximates statistical thermodynamics in the macroscopic limit.

### Processes

A change in the system state is called a _process_. When the initial and final states of a process are the same, the process is called a _cycle_. If a process can be run in reverse with no change in the system + surroundings, then the process is called a _reversible_ process. If a process is not reversible it is called an _irreversible_ process.

### Isothermal Process

An _isothermal_ process is one in which the temperature remains constant. Please note that a process being isothermal does not imply anything about the heat transferred or work done, _i.e._ heat transfer may take place during an isothermal process. An isothermal process implies that the product of the volume and the pressure is constant for an ideal gas. i.e. PV = Constant

## Zeroth Law of Thermodynamics

If a system _A_ is in thermal equilibrium with another system _B_ and also with a third system _C_, then all of the systems are in thermal equilibrium with each other. This is called the _zeroth law of thermodynamics_. This is how a thermometer works. If a thermometer is placed in a substance for temperature measurement, the thermometer's glass comes into thermal equilibrium with the substance. The glass then comes into thermal equilibrium with the liquid (mercury, alcohol, etc. . . .) inside the thermometer. Because the substance is in thermal equilibrium with the glass and the glass is in thermal equilibrium with the inner liquid, the substance and liquid must be in thermal equilibrium by the zeroth law. And because they are thermally equivalent, they must have the same temperature.

## Temperature Measurement

Temperature is measured by observing some property of the system which varies with temperature. Such a property is called _thermometric property_ , e.g.:
    
    
       - The volumes of most liquids increase with temperature.
       - The length of a metal rod increases as the temperature increases. 
       - The pressure of a constant volume of gas increases with temperature
    

It is useful to establish a temperature scale so that a cardinal relationship can be established between various systems at different temperatures. This is done by _defining_ the temperature _t_ as a function of a thermometric property _X_, such that the temperature is a linear function of _X_, _i.e._, equal changes in the property _X_ give rise to equal changes in the temperature. Such a linear function is _t_ = _a_ \+ _b_ _X_, for which one needs to assign arbitrary temperatures to two values of _X_ to find the values of the constants _a_ and _b_.

For example, in the case of the _Celsius_ scale, the measurements are based on properties of water at the boiling point and melting point. Suppose the value of the thermometric property is _Xb_ for the normal boiling point and _Xm_ for the normal melting point. Then the temperature is given by _t_ = 100 (_X_ \- _Xm_)/(_Xb_ \- _Xm_), where _X_ is the thermometric property at temperature _t_, and we have chosen _tm_ = 0°C and _tb_ = 100°C. The _normal_ melting and boiling points are the temperatures of melting and boiling at 1 _atmosphere_ pressure.

The major temperature scales are the Celsius scale (°C), the Fahrenheit (°F) and the Kelvin (K) scale. Note the absence of the ° sign for kelvin--it is not degrees Kelvin, but kelvins, not capitalized when spelled out, and with the normal English plural which was added to the degree when Kelvin was an adjective modifying that unit.

Different thermometers are used for different temperature ranges. As the reader might have guessed by now, this means that the different thermometers will only agree on the fixed points. However, a set of thermometers have been carefully selected and calibrated so that this is not a big issue in practice.

The standard in this case is the _International Temperature Scale_, which was introduced in 1927, and revised in 1948, 1968, and 1990. The latest scale is denoted by _T90_ for the Kelvin scale and is defined from 0.65 _K_ upwards. For instance, between 0.65 K and 5.0 _K_ _T90_ is defined in terms of the vapor-pressure temperature relations of _3He_ and _4He_. The ranges for different materials overlap and any of the valid materials can be used as a standard in the overlapping region.

## The Ideal Gas

Recall that a thermodynamic system may have a certain substance or material whose quantity can be expressed in mass or moles in an overall volume. These are extensive properties of the system. If the substance is evenly distributed throughout the volume in question, then a value of volume per amount of substance may be used as an intensive property. For an example, for an amount called a [mole](//en.wikipedia.org/wiki/Mole_\(unit\)), volume per mole is typically called _molar volume_. Also, a volume per mass for a specific substance may be called specific volume. In such cases, an equation of state may relate the three intensive properties, temperature, pressure, and molar or specific volume.

A simple but very useful equation of state is for an ideal gas. The ideal gas is a useful notion in thermodynamics, as it is a simple system that depends on two independent properties. An ideal gas is one that has no intermolecular interactions except for completely elastic collisions with other molecules. For a closed system containing an ideal gas, the state can be specified by giving the values of any two of pressure, temperature, and molar volume.

Consider a system, an ideal gas enclosed in a container. Starting from an initial state 1, where the temperature is _T1_, its temperature is changed to _T2_ through a constant pressure process and then a constant molar volume process, then the ratio of pressures is found to be the same as the ratio of molar volumes. Suppose the initial value of the pressure and molar volume are _p1_ and _V1_ respectively, and final value of pressure and molar volume are _p2_ and _V2_ respectively. Note that we haven't chosen a specific scale for the temperature (like say, the Celsius scale). Now, suppose we were to choose a scale such that _T1_/_T2_ = _p1_/_p2_, we can show that the value of _pV/T_ is constant for an ideal gas, so that it obeys the gas equation _pV = RT_, where _p_ is the absolute pressure, _V_ is the molar volume, and _R_ is a constant known as the [universal gas constant](//en.wikipedia.org/wiki/gas_constant). The temperature _T_ is the absolute temperature in the ideal gas scale, and the scale is found to be the same as the thermodynamic temperature scale. The thermodynamic temperature scale will be defined after the statement of the second law of thermodynamics.

This equation _pV = RT_ is called the equation of state for an ideal gas, and is known as the ideal gas equation. Most common gases obey the ideal gas equation unless they are compressed or cooled to extreme states, so this is a very useful relation. A similar equation may be written where, for the specific type of gas, specific volume is used instead of molar volume and a specific gas constant is used instead of the universal gas constant. This then writes as pv = mrT.

![Ideal Gas Temperature](//upload.wikimedia.org/wikibooks/en/7/75/Idealtemp_Engineering_Thermodynamics.png)

In the above image, the volume of an ideal gas at two different pressures _p1_ and _p2_ is plotted against the temperature in Celsius. If we extrapolate the two straight line graphs, they intersect the temperature axis at a point _t0_, where _t0_ = −273.15°C.

From experiment, it is easy to show that the thermodynamic temperature _T_ is related to the Celsius temperature _t_ by the equation: _T_ = _t_ \+ 273.15. The zero of thermodynamic temperature scale is 0 K, and its significance will be clear when we discuss the second law of thermodynamics.

* * *

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

  


# Zeroth Law

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

* * *

The Zeroth law of Thermodynamics can be stated as:

_If two thermodynamic systems A and B are in thermal equilibrium, and B is also in thermal equilibrium with another system C, then A and C are in thermal equilibrium._
    
    
                                        OR
    

"" If a body isolated from the other environment is in thermal equilibrium with one body & is separately in thermal equilibrium with the another body then three bodies are said to be in the thermal equilibrium with each other.""

This may seem obvious as we are quite familiar with this experiment. When we place in a cup of water (System A) a thermometer (System B) we wait a period of time until they reach equilibrium then read the measurement on the thermometer.

It is called the Zeroth Law as it is not derivable from the other laws and is often useful to understand the concept before presenting the other laws of thermodynamics.

It also states that at absolute zero temperature( i.e. zero Kelvin ) all molecular motion inside a crystal ceases.

The application of zeroth law is mainly seen in the thermodynamic properties.

Source : [[[1]](http://en.wikipedia.org/wiki/Zeroth_law_of_thermodynamics)]

  


# First Law

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

* * *

## Energy

**We use the notion of energy of a body** from Newton's second law, and thus total energy is conserved.**Common forms of energy** in physics are potential and kinetic energy. The potential energy is usually the energy due to matter having certain position (configuration) in a field, commonly the gravitational field of Earth. Kinetic energy is the energy due to motion relative to a frame of reference. In thermodynamics, we deal with mainly work and heat, which are different manifestations of the energy in the universe.

## Work

Work is said to be done by a system if the effect on the surroundings can be reduced solely to that of lifting a weight. Work is only ever done at the boundary of a system. Again, we use the intuitive definition of work, and this will be complete only with the statement of the second law of thermodynamics.

Consider a piston-cylinder arrangement as found in automobile engines. When the gas in the cylinder expands, pushing the piston outwards, it does work on the surroundings. In this case work done is mechanical. But how about other forms of energy like heat? The answer is that heat cannot be completely converted into work, with no other change, due to the second law of thermodynamics.

In the case of the piston-cylinder system, the work done during a cycle is given by _W_, where _W = −∫ F dx = −∫ p dV_, where _F = p A_, and _p_ is the pressure on the inside of the piston (note the minus sign in this relationship). In other words, the work done is the area under the _p-V_ diagram. Here, _F_ is the external opposing force, which is equal and opposite to that exerted by the system. A corollary of the above statement is that a system undergoing free expansion does no work. The above definition of work will only hold for the quasi-static case, when the work done is reversible work.

![Work not a State Function](//upload.wikimedia.org/wikibooks/en/e/ee/Work_notstate_Engineering_Thermodynamics.png)

A consequence of the above statement is that work done is not a state function, since it depends on the path (which curve you consider for integration from state 1 to 2). For a system in a cycle which has states 1 and 2, the work done depends on the path taken during the cycle. If, in the cycle, the movement from 1 to 2 is along _A_ and the return is along _C_, then the work done is the lightly shaded area. However, if the system returns to 1 via the path _B_, then the work done is larger, and is equal to the sum of the two areas.

![Indicator Diagram p vs V](//upload.wikimedia.org/wikibooks/en/a/ab/Indicator_Engineering_Thermodynamics.png)

The above image shows a typical indicator diagram as output by an automobile engine. The shaded region is proportional to the work done by the engine, and the volume _V_ in the _x_-axis is obtained from the piston displacement, while the _y_-axis is from the pressure inside the cylinder. The work done in a cycle is given by _W_, where

![
  W = -\\oint p dV
](//upload.wikimedia.org/math/2/6/4/264754f661cc3fc3ef5957f1db9ec270.png)

Work done by the system is negative, and work done on the system is positive, by the convention used in this book.

### Flow Energy

So far we have looked at the work done to compress fluid in a system. Suppose we have to introduce some amount of fluid into the system at a pressure _p_. Remember from the definition of the system that matter can enter or leave an open system. Consider a small amount of fluid of mass _dm_ with volume _dV_ entering the system. Suppose the area of cross section at the entrance is _A_. Then the distance the force _pA_ has to push is _dx = dV/A_. Thus, the work done to introduce a small amount of fluid is given by _pdV_, and the work done per unit mass is _pv_, where _v = dV/dm_ is the specific volume. This value of _pv_ is called the flow energy.

### Examples of Work

The amount of work done in a process depends on the irreversibilities present. A complete discussion of the irreversibilities is only possible after the discussion of the second law. The equations given above will give the values of work for quasi-static processes, and many real world processes can be approximated by this process. However, note that work is only done if there is an opposing force in the boundary, and that a volume change is not strictly required.

### Work in a Polytropic Process

Consider a polytropic process _pVn=C_, where _C_ is a constant. If the system changes its states from 1 to 2, the work done is given by

![
  W = -\\int_{V_1}^{V_2}\\frac{C}{V^n}dV = -\\frac{p_2V_2 - p_1V_1}{1 - n}
](//upload.wikimedia.org/math/c/c/d/ccd298d16bfed0c01fe8ca429a2c790b.png)

And additionally, if n=1

![
  W = -\\int_{V_1}^{V_2}\\frac{C}{V^n}dV = -C \\ln \\frac{V_2}{V_1}
](//upload.wikimedia.org/math/7/c/b/7cb48911f48044dd3de6339f50c086c3.png)

## Heat

Before thermodynamics was an established science, the popular theory was that heat was a fluid, called _caloric_, that was stored in a body. Thus, it was thought that a hot body transferred heat to a cold body by transferring some of this fluid to it. However, this was soon disproved by showing that heat was generated when drilling bores of guns, where both the drill and the barrel were initially cold.

Heat is the energy exchanged due to a temperature difference. As with work, heat is defined at the boundary of a system and is a path function. Heat rejected by the system is negative, while the heat absorbed by the system is positive.

### Specific Heat

The _specific heat_ of a substance is the amount of heat required for a unit rise in the temperature in a unit mass of the material. If this quantity is to be of any use, the amount of heat transferred should be a linear function of temperature. This is certainly true for ideal gases. This is also true for many metals and also for real gases under certain conditions. In general, we can only talk about the average specific heat, _cav = Q/mΔT_. Since it was customary to give the specific heat as a property in describing a material, methods of analysis came to rely on it for routine calculations. However, since it is only constant for some materials, older calculations became very convoluted for newer materials. For instance, for finding the amount of heat transferred, it would have been simple to give a chart of _Q(ΔT)_ for that material. However, following convention, the tables of _cav(ΔT)_ were given, so that a double iterative solution over _cav_ and _T_ was required.

Calculating specific heat requires us to specify what we do with Volume and Pressure when we change temperature. When Volume is fixed, it is called specific heat at constant volume (Cv). When Pressure is fixed, it is called specific heat at constant pressure (Cp).

### Latent Heat

It can be seen that the specific heat as defined above will be infinitely large for a phase change, where heat is transferred without any change in temperature. Thus, it is much more useful to define a quantity called _latent heat_, which is the amount of energy required to change the phase of a unit mass of a substance at the phase change temperature.

### Adiabatic Process

An _adiabatic_ process is defined as one in which there is no heat transfer with the surroundings, that is, the change in amount of energy dQ=0 . A gas contained in an insulated vessel undergoes an adiabatic process. Adiabatic processes also take place even if the vessel is not insulated if the process is fast enough that there is not enough time for heat to escape (_e.g._ the transmission of sound through air). Adiabatic processes are also ideal approximations for many real processes, like expansion of a vapor in a turbine, where the heat loss is much smaller than the work done.

## First Law of Thermodynamics

### Joule Experiments

![Joule's Experiments for First Law](//upload.wikimedia.org/wikipedia/commons/f/f6/Joule_apparatus.png)

![Joule's Experiments for First Law](//upload.wikimedia.org/wikibooks/en/f/f4/Joule_first_bath_Engineering_Thermodynamics.png)

It was well known that heat and work both change the energy of a system. Joule conducted a series of experiments which showed the relationship between heat and work in a thermodynamic cycle for a system. He used a paddle to stir an insulated vessel filled with fluid. The amount of work done on the paddle was noted (the work was done by lowering a weight, so that work done = _mgz_). Later, this vessel was placed in a bath and cooled. The energy involved in increasing the temperature of the bath was shown to be equal to that supplied by the lowered weight. Joule also performed experiments where electrical work was converted to heat using a coil and obtained the same result.

## Statement of the First Law for a Closed System

The first law states that _when heat and work interactions take place between a closed system and the environment, the algebraic sum of the heat and work interactions for a cycle is zero_.

Mathematically, this is equivalent to
    
    
    dQ + dW = 0 for any cycle closed to mass flow
    

Q is the heat transferred, and W is the work done on or by the system. Since these are the only ways energy can be transferred, this implies that the total energy of the system in the cycle is a constant.

One consequence of the statement is that the total energy of the system is a property of the system. This leads us to the concept of internal energy.

### Internal Energy

In thermodynamics, the _internal energy_ is the energy of a system due to its temperature. The statement of first law refers to thermodynamic cycles. Using the concept of internal energy it is possible to state the first law for a non-cyclic process. Since the first law is another way of stating the conservation of energy, the energy of the system is the sum of the heat and work input, _i.e._, _ΔE = Q + W_. Here _E_ represents the internal energy (U) of the system along with the kinetic energy (KE) and the potential energy (PE) (_E = U + K.E. + P.E._) and is called the _total energy_ of the system. This is the statement of the first law for non-cyclic processes, as long as they are still closed to the flow of mass. The KE and PE terms are relative to an external reference point i.e. the system is the gas within a ball, the ball travels in a trajectory that varies in height H and velocity V and subsequently KE and PE with time, but this has no affect upon the energy of the gas molecules within the ball, which is dictated only by the internal energy of the system (U). Thermodynamics does not define the nature of the internal energy, but it can be rationalised using other theories (i.e. the gas kinetic theory), but in this case is due to the KE and PE of the gas molecules within the ball, not to be mistaken with the KE and PE of the ball itself.

For gases, the value of _K.E._ and _P.E._ is quite small, so the important term is the internal energy function _U_. In particular, since for an ideal gas the state can be specified using two variables, the state variable _u_ is given by _u(v, T)_, where _v_ is the specific volume and _T_ is the temperature.

Introducing this temperature dependence explicitly is important in many calculations. For this purpose, the constant-volume heat capacity is defined as follows: _cv = (∂u/∂t)v_, where _cv_ is the specific heat at constant volume. A constant-pressure heat capacity will be defined later, and it is important to keep them straight. The important point here is that the other variable that U depends on "naturally" is v, so to isolate the temperature dependence of U you want to take the derivative at constant v.

### Internal Energy for an Ideal Gas

In the previous section, the internal energy of an ideal gas was shown to be a function of both the volume and temperature. Joule performed an experiment where a gas at high pressure inside a bath at the same temperature was allowed to expand into a larger volume.

![Joule's Experiment Temperature Invariance](//upload.wikimedia.org/wikibooks/en/5/5e/Joule_Engineering_Thermodynamics.png)

In the above image, two vessels, labeled A and B, are immersed in an insulated tank containing water. A thermometer is used to measure the temperature of the water in the tank. The two vessels A and B are connected by a tube, the flow through which is controlled by a stop. Initially, A contains gas at high pressure, while B is nearly empty. The stop is removed so that the vessels are connected and the final temperature of the bath is noted.

The temperature of the bath was unchanged at the end of the process, showing that the internal energy of an ideal gas was the function of temperature alone. Thus _Joule's law_ is stated as _(∂u/∂v)t = 0_.

## Enthalpy

According to the first law, _dQ + dW = dE_

If all the work is pressure volume work, then we have

_dW = − p dV_

⇒ _dQ = dU + pdV = d(U + pV) - Vdp_

⇒ _d(U + pV) = dQ + Vdp_

We define _H ≡ U + pV_ as the _enthalpy_ of the system, and _h = u + pv_ is the specific enthalpy. In particular, for a constant pressure process,

_ΔQ = ΔH_

With arguments similar to that for _cv_, _cp = (∂h/∂t)p_. Since _h_, _p_, and _t_ are state variables, _cp_ is a state variable. As a corollary, for ideal gases, _cp = cv \+ R_, and for incompressible fluids, _cp = cv_

### Throttling

![Throttling Process](//upload.wikimedia.org/wikibooks/en/8/8f/Throttling_Engineering_Thermodynamics.png)

_Throttling_ is the process in which a fluid passing through a restriction loses pressure. It usually occurs when fluid passes through small orifices like porous plugs. The original throttling experiments were conducted by Joule and Thompson. As seen in the previous section, in adiabatic throttling the enthalpy is constant. What is significant is that for ideal gases, the enthalpy depends only on temperature, so that there is no temperature change, as there is no work done or heat supplied. However, for real gases, below a certain temperature, called the _inversion point_, the temperature drops with a drop in pressure, so that throttling causes cooling, _i.e._, _p1 < p2 ⇒ T1 < T2._ The amount of cooling produced is quantified by the Joule-Thomson coefficient _μJT = (∂T/∂p)h_. For instance, the inversion temperature for air is about 400°C.

* * *

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

  


# Second Law

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

* * *

## Introduction

{EngTherm}}

* * *

## Introduction

The first law is a statement of energy conservation. The rise in temperature of a substance when work is done is well known. Thus work can be completely converted to heat. However, we observe that in nature, we don't see the conversion in the other direction spontaneously.

The statement of the second law is facilitated by using the concept of _heat engines_. Heat engines work in a cycle and convert heat into work. A _thermal reservoir_ is defined as a system which is in equilibrium and large enough so that heat transferred to and from it does not change its temperature appreciably.

[Heat Engine](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Hengine_Engineering_Thermodynamics.png)

Heat engines usually work between two thermal reservoirs, the low temperature reservoir and the high temperature reservoir. The performance of a heat engine is measured by its _thermal efficiency_, which is defined as the ratio of work output to heat input, _i.e._, _η = W/Q1_, where _W_ is the net work done, and _Q1_ is heat transferred from the high temperature reservoir.

[Heat Pumps](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Hpump_Engineering_Thermodynamics.png)

_Heat pumps_ transfer heat from a low temperature reservoir to a high temperature reservoir using external work, and can be considered as reversed heat engines.

## Statement of the Second Law of Thermodynamics

### Kelvin-Planck Statement

It is impossible to construct a heat engine which will operate continuously and convert all the heat it draws from a reservoir into work.

### Clausius Statement

It is impossible to construct a heat pump which will transfer heat from a low temperature reservoir to a high temperature reservoir without using external work.
    
    
                                          "OR"
    

it is impossible to flow heat from low temperature (sink) to high temperature (source) without using expenditures.

### PMM2

A _perpetual motion machine of the second kind_, or _PMM2_ is one which converts all the heat input into work while working in a cycle. A PMM2 has an _ηth_ of 1.

### Equivalence of Clausius and Kelvin-Planck Statements

[Kelvin-Planck from Clausius](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Clausius_Engineering_Thermodynamics.png)

Suppose we can construct a heat pump which transfers heat from a low temperature reservoir to a high temperature one without using external work. Then, we can couple it with a heat engine in such a way that the heat removed by the heat pump from the low temperature reservoir is the same as the heat rejected by the heat engine, so that the combined system is now a heat engine which converts heat to work without any external effect. This is thus in violation of the Kelvin-Planck statement of the second law.

[Clausius from Kelvin-Planck](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Kelplank_Engineering_Thermodynamics.png)

Now suppose we have a heat engine which can convert heat into work without rejecting heat anywhere else. We can combine it with a heat pump so that the work produced by the engine is used by the pump. Now the combined system is a heat pump which uses no external work, violating the Clausius statement of the second law.

Thus, we see that the Clausius and Kelvin-Planck statements are equivalent, and one necessarily implies the other.

## Carnot Cycle

Nicholas Sadi Carnot devised a reversible cycle in 1824 called the _Carnot cycle_ for an engine working between two reservoirs at different temperatures. It consists of two reversible isothermal and two reversible adiabatic processes. For a cycle 1-2-3-4, the working material

  1. Undergoes isothermal expansion in 1-2 while absorbing heat from high temperature reservoir
  2. Undergoes adiabatic expansion in 2-3
  3. Undergoes isothermal compression in 3-4, and
  4. Undergoes adiabatic compression in 4-1.

![Carnot Cycle P-V Diagram](//upload.wikimedia.org/wikibooks/en/3/38/Pvcarnot_Engineering_Thermodynamics.png)

Heat is transferred to the working material during 1-2 (_Q1_) and heat is rejected during 3-4 (_Q2_). The thermal efficiency is thus _ηth = W/Q1_. Applying first law, we have, _W = Q1 − Q2_, so that _ηth = 1 − Q2/Q1_.

_Carnot's principle_ states that

  1. No heat engine working between two thermal reservoirs is more efficient than the Carnot engine, and
  2. All Carnot engines working between reservoirs of the same temperature have the same efficiency.

The proof by contradiction of the above statements come from the second law, by considering cases where they are violated. For instance, if you had a Carnot engine which was more efficient than another one, we could use that as a heat pump (since processes in a Carnot cycle are reversible) and combine with the other engine to produce work without heat rejection, to violate the second law. A corollary of the Carnot principle is that _Q2/Q1_ is purely a function of _t2_ and _t1_, the reservoir temperatures. Or,

![ \\frac{Q_1}{Q_2} = \\phi
  \\left\(
    t_1, t_2
  \\right\)](//upload.wikimedia.org/math/7/4/4/744105a0b60c85fb1a39cb0d9e1ef3b3.png)

## Thermodynamic Temperature Scale

Lord Kelvin used Carnot's principle to establish the thermodynamic temperature scale which is independent of the working material. He considered three temperatures, _t1_, _t2_, and _t3_, such that _t1_ > _t3_ > _t2_.

As shown in the previous section, the ratio of heat transferred only depends on the temperatures. The first law is a statement of energy conservation. The rise in temperature of a substance when work is done is well known. Thus work can be completely converted to heat. However, we observe that in nature, we don't see the conversion in the other direction spontaneously.

The statement of the second law is facilitated by using the concept of _heat engines_. Heat engines work in a cycle and convert heat into work. A _thermal reservoir_ is defined as a system which is in equilibrium and large enough so that heat transferred to and from it does not change its temperature appreciably.

[Heat Engine](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Hengine_Engineering_Thermodynamics.png)

Heat engines usually work between two thermal reservoirs, the low temperature reservoir and the high temperature reservoir. The performance of a heat engine is measured by its _thermal efficiency_, which is defined as the ratio of work output to heat input, _i.e._, _η = W/Q1_, where _W_ is the net work done, and _Q1_ is heat transferred from the high temperature reservoir.

[Heat Pumps](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Hpump_Engineering_Thermodynamics.png)

_Heat pumps_ transfer heat from a low temperature reservoir to a high temperature reservoir using external work, and can be considered as reversed heat engines.

## Statement of the Second Law of Thermodynamics

### Kelvin-Planck Statement

It is impossible to construct a heat engine which will operate continuously and convert all the heat it draws from a reservoir into work.

### Clausius Statement

It is impossible to construct a heat pump which will transfer heat from a low temperature reservoir to a high temperature reservoir without using external work.
    
    
                                          "OR"
    

it is impossible to flow heat from low temperature(sink) to high temperature(source)without using expenditures.=== PMM2 ===

A _perpetual motion machine of the second kind_, or _PMM2_ is one which converts all the heat input into work while working in a cycle. A PMM2 has an _ηth_ of 1.

### Equivalence of Clausius and Kelvin-Planck Statements

[Kelvin-Planck from Clausius](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Clausius_Engineering_Thermodynamics.png)

Suppose we can construct a heat pump which transfers heat from a low temperature reservoir to a high temperature one without using external work. Then, we can couple it with a heat engine in such a way that the heat removed by the heat pump from the low temperature reservoir is the same as the heat rejected by the heat engine, so that the combined system is now a heat engine which converts heat to work without any external effect. This is thus in violation of the Kelvin-Planck statement of the second law.

[Clausius from Kelvin-Planck](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Kelplank_Engineering_Thermodynamics.png)

Now suppose we have a heat engine which can convert heat into work without rejecting heat anywhere else. We can combine it with a heat pump so that the work produced by the engine is used by the pump. Now the combined system is a heat pump which uses no external work, violating the Clausius statement of the second law.

Thus, we see that the Clausius and Kelvin-Planck statements are equivalent, and one necessarily implies the other.

## Carnot Cycle

Nicholas Sadi Carnot devised a reversible cycle in 1824 called the _Carnot cycle_ for an engine working between two reservoirs at different temperatures. It consists of two reversible isothermal and two reversible adiabatic processes. For a cycle 1-2-3-4, the working material

  1. Undergoes isothermal expansion in 1-2 while absorbing heat from high temperature reservoir
  2. Undergoes adiabatic expansion in 2-3
  3. Undergoes isothermal compression in 3-4, and
  4. Undergoes adiabatic compression in 4-1.

![Carnot Cycle P-V Diagram](//upload.wikimedia.org/wikibooks/en/3/38/Pvcarnot_Engineering_Thermodynamics.png)

Heat is transferred to the working material during 1-2 (_Q1_) and heat is rejected during 3-4 (_Q2_). The thermal efficiency is thus _ηth = W/Q1_. Applying first law, we have, _W = Q1 − Q2_, so that _ηth = 1 − Q2/Q1_.

_Carnot's principle_ states that

  1. No heat engine working between two thermal reservoirs is more efficient than the Carnot engine, and
  2. All Carnot engines working between reservoirs of the same temperature have the same efficiency.

The proof by contradiction of the above statements come from the second law, by considering cases where they are violated. For instance, if you had a Carnot engine which was more efficient than another one, we could use that as a heat pump (since processes in a Carnot cycle are reversible) and combine with the other engine to produce work without heat rejection, to violate the second law. A corollary of the Carnot principle is that _Q2/Q1_ is purely a function of _t2_ and _t1_, the reservoir temperatures. Or,

![ \\frac{Q_1}{Q_2} = \\phi
  \\left\(
    t_1, t_2
  \\right\)](//upload.wikimedia.org/math/7/4/4/744105a0b60c85fb1a39cb0d9e1ef3b3.png)

## Thermodynamic Temperature Scale

Lord Kelvin used Carnot's principle to establish the thermodynamic temperature scale which is independent of the working material. He considered three temperatures, _t1_, _t2_, and _t3_, such that _t1_ > _t3_ > _t2_.

As shown in the previous section, the ratio of heat transferred only depends on the temperatures. Considering reservoirs 1 and 2:

![ \\frac{Q_1}{Q_2} = \\phi
  \\left\(
    t_1, t_2
  \\right\)](//upload.wikimedia.org/math/7/4/4/744105a0b60c85fb1a39cb0d9e1ef3b3.png)

Considering reservoirs 2 and 3:

![ \\frac{Q_2}{Q_3} = \\phi
  \\left\(
    t_2, t_3
  \\right\)](//upload.wikimedia.org/math/9/0/c/90c380dfbc78e71587d0a2c02ab1aff3.png)

Considering reservoirs 1 and 3:

![ \\frac{Q_1}{Q_3} = \\phi
  \\left\(
    t_1, t_3
  \\right\)](//upload.wikimedia.org/math/e/a/e/eae61fb2799772f95e9b25114d71a6dd.png)

Eliminating the heat transferred, we have the following condition for the function _φ_.

![ \\phi
  \\left\(
    t_1, t_2 
  \\right\) = \\frac{\\phi
    \\left\(
    t_1, t_3
    \\right\)}{\\phi
    \\left\(
    t_2, t_3
    \\right\)}](//upload.wikimedia.org/math/c/e/6/ce606279ebf65d14d781b636b7ece0f9.png)

Now, it is possible to choose an arbitrary temperature for 3, so it is easy to show using elementary multivariate calculus that _φ_ can be represented in terms of an increasing function of temperature _ζ_ as follows:

![  \\phi
  \\left\(
    t_1, t_2 
  \\right\) = \\frac{\\zeta
    \\left\(
    t_1
    \\right\)}{\\zeta
    \\left\(
    t_2
    \\right\)}
](//upload.wikimedia.org/math/b/a/5/ba52f7b6540da9e72180af2eafeaff53.png)

Now, we can have a one to one association of the function _ζ_ with a new temperature scale called the _thermodynamic temperature scale_, _T_, so that

![\\frac{Q_1}{Q_2} = \\frac{T_1}{T_2}](//upload.wikimedia.org/math/e/e/b/eebf01a5b6aa67f857abf20d47dde166.png)

Thus we have the thermal efficiency of a Carnot engine as

![\\eta_{th} = 1 - \\frac{T_2}{T_1}](//upload.wikimedia.org/math/3/9/0/390adc766645e1858081e10d4498f882.png)

The thermodynamic temperature scale is also known as the Kelvin scale, and it needs only one fixed point, as the other one is absolute zero. The concept of absolute zero will be further refined during the statement of the third law of thermodynamics.

  * 1st Law: Energy can neither be created or destroyed
  * 2nd Law: All spontaneous events act to increase total entropy
  * 3rd Law: Absolute zero is removal of all thermal molecular motion

## NOTE

Reservoirs are systems of large quantity of matter which no temperature difference will occur when finite amount of heat is transferred or removed. Ex- Ocean,lake, air and etc....

## Clausius Theorem

_Clausius theorem_ states that any reversible process can be replaced by a combination of reversible isothermal and adiabatic processes.

![Clausius Theorem](//upload.wikimedia.org/wikibooks/en/a/ac/Clausiusthm_Engineering_Thermodynamics.png)

Consider a reversible process _a-b_. A series of isothermal and adiabatic processes can replace this process if the heat and work interaction in those processes is the same as that in the process _a-b_. Let this process be replaced by the process _a-c-d-b_, where _a-c_ and _d-b_ are reversible adiabatic processes, while _c-d_ is a reversible isothermal process. The isothermal line is chosen such that the area _a-e-c_ is the same as the area _b-e-d_. Now, since the area under the _p-V_ diagram is the work done for a reversible process, we have, the total work done in the cycle _a-c-d-b-a_ is zero. Applying the first law, we have, the total heat transferred is also zero as the process is a cycle. Since _a-c_ and _d-b_ are adiabatic processes, the heat transferred in process _c-d_ is the same as that in the process _a-b_. Now applying first law between the states _a_ and _b_ along _a-b_ and _a-c-d-b_, we have, the work done is the same. Thus the heat and work in the process _a-b_ and _a-c-d-b_ are the same and any reversible process _a-b_ can be replaced with a combination of isothermal and adiabatic processes, which is the Clausius theorem.

A corollary of this theorem is that any reversible cycle can be replaced by a series of Carnot cycles.

Suppose each of these Carnot cycles absorbs heat _dQ1i_ at temperature _T1i_ and rejects heat _dQ2i_ at _T2i_. Then, for each of these engines, we have _dQ1i/dQ2i = −T1i/T2i_. The negative sign is included as the heat lost from the body has a negative value. Summing over a large number of these cycles, we have, in the limit,

![\\oint_R \\frac{dQ}{T} = 0](//upload.wikimedia.org/math/9/5/1/95192c9626f97337fd5aecdd08776727.png)

This means that the quantity _dQ/T_ is a property. It is given the name _entropy_.

Further, using Carnot's principle, for an irreversible cycle, the efficiency is less than that for the Carnot cycle, so that

![\\eta_{irr} = 1 - \\frac{dQ_2}{dQ_1} < \\eta_{Carnot}](//upload.wikimedia.org/math/0/6/1/0612dc4ad12a95f15306e69519e51ee3.png)

![\\frac{dQ_1}{T_1} - \\frac{dQ_2}{T_2} < 0](//upload.wikimedia.org/math/a/f/3/af31e33731cd229b2595deb39726726d.png)

As the heat is transferred out of the system in the second process, we have, assuming the normal conventions for heat transfer,

![\\frac{dQ_1}{T_1} + \\frac{dQ_2}{T_2} < 0](//upload.wikimedia.org/math/a/2/6/a26fee67c23c5aa756e250cf4b8f9544.png)

So that, in the limit we have,

![\\oint_{I} \\frac{dQ}{T} < 0](//upload.wikimedia.org/math/2/0/9/20948effee2aeca3485dd24373ec2c1c.png)

![\\oint \\frac{dQ}{T_{reservoir}} \\leq 0](//upload.wikimedia.org/math/d/a/0/da0b3425b7a5274a707e3af05b21d712.png)

The above inequality is called the _inequality of Clausius_. Here the equality holds in the reversible case.

## Entropy

Entropy is the quantitative statement of the second law of thermodynamics. It is represented by the symbol _S_, and is defined by

![dS \\equiv
\\left\(
  \\frac{dQ}{T}
\\right\)_{rev}
](//upload.wikimedia.org/math/6/0/1/601b2514ae22fa4bb76d16f15a36a2ff.png)

Thus, we can calculate the entropy change of a reversible process by evaluating the Note that as we have used the Carnot cycle, the temperature is the reservoir temperature. However, for a reversible process, the system temperature is the same as the reversible temperature.

Consider a system undergoing a cycle 1-2-1, where it returns to the original state along a different path. Since entropy of the system is a property, the change in entropy of the system in 1-2 and 2-1 are numerically equal. Suppose reversible heat transfer takes place in process 1-2 and irreversible heat transfer takes place in process 2-1. Applying Clausius's inequality, it is easy to see that the heat transfer in process 2-1 _dQirr_ is less than _T dS_. That is, in an irreversible process the same change in entropy takes place with a lower heat transfer. As a corollary, the change in entropy in any process, _dS_, is related to the heat transfer _dQ_ as

_dS ≥ dQ/T_

For an isolated system, _dQ = 0_, so that we have

_dSisolated ≥ 0_

This is called the _principle of increase of entropy_ and is an alternative statement of the second law.

Further, for the whole universe, we have

_ΔS = ΔSsys \+ ΔSsurr > 0_

For a reversible process,

_ΔSsys = (Q/T)rev = −ΔSsurr_

So that

_ΔSuniverse = 0_

for a reversible process.

![T-S diagram for Carnot Cycle](//upload.wikimedia.org/wikibooks/en/5/58/Tscarnot_Engineering_Thermodynamics.png)

Since _T_ and _S_ are properties, you can use a _T-S_ graph instead of a _p-V_ graph to describe the change in the system undergoing a reversible cycle. We have, from the first law, _dQ + dW = 0_. Thus the area under the _T-S_ graph is the work done by the system. Further, the reversible adiabatic processes appear as vertical lines in the graph, while the reversible isothermal processes appear as horizontal lines.

### Entropy for an Ideal Gas

An ideal gas obeys the equation _pv = RT_. According to the first law,

_dQ + dW = dU_

For a reversible process, according to the definition of entropy, we have

_dQ = T dS_

Also, the work done is the pressure volume work, so that

_dW = -p dV_

The change in internal energy:

_dU = m cv dT_

_T dS = p dV + m cv dT_

Taking per unit quantities and applying ideal gas equation,

_ds = R dV/v + cv dT/T_

![\\Delta s = R \\ln \\frac{v_2}{v_1} + c_v \\ln \\frac{T_2}{T_1}](//upload.wikimedia.org/math/3/b/2/3b2e40c5dea7fc6654b8bad36b16f078.png)

As a general rule, all things being equal, entropy increases as, temperature increases and as pressure and concentration decreases and energy stored as internal energy has higher entropy than energy which is stored as kinetic energy.

## Availability

From the second law of thermodynamics, we see that we cannot convert all the heat energy to work. If we consider the aim of extracting useful work from heat, then only some of the heat energy is available to us. It was previously said that an engine working with a reversible cycle was more efficient than an irreversible engine. Now, we consider a system which interacts with a reservoir and generates work, _i.e._, we look for the maximum work that can be extracted from a system given that the surroundings are at a particular temperature.

Consider a system interacting with a reservoir and doing work in the process. Suppose the system changes state from 1 to 2 while it does work. We have, according to the first law,

_dQ - dW = dE_,

where _dE_ is the change in the internal energy of the system. Since it is a property, it is the same for both the reversible and irreversible process. For an irreversible process, it was shown in a previous section that the heat transferred is less than the product of temperature and entropy change. Thus the work done in an irreversible process is lower, from first law.

### Availability Function

The availability function is given by _Φ_, where

_Φ ≡ E − T0S_

where _T0_ is the temperature of the reservoir with which the system interacts. The availability function gives the effectiveness of a process in producing useful work. The above definition is useful for a non-flow process. For a flow process, it is given by

_Ψ ≡ H − T0S_

### Irreversibility

Maximum work can be obtained from a system by a reversible process. The work done in an actual process will be smaller due to the irreversibilities present. The difference is called the _irreversibility_ and is defined as

_I ≡ Wrev − W_

From the first law, we have

_W = ΔE − Q_

_I = ΔE - Q - (Φ2 − Φ1)_

As the system interacts with surroundings of temperature _T0_, we have

_ΔSsurr = Q/T0_

Also, since

_E − Φ = T0 ΔSsys_

we have

_I = T0 (ΔSsys \+ ΔSsurr)_

Thus,

_I ≥ 0_

_I_ represents increase in unavailable energy.

### Helmholtz and Gibbs Free Energies

_Helmholtz Free Energy_ is defined as

_F ≡ U − TS_

The Helmholtz free energy is relevant for a non-flow process. For a flow process, we define the _Gibbs Free Energy_

_G ≡ H − TS_

The Helmholtz and Gibbs free energies have applications in finding the conditions for equilibrium.

* * *

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

  


# Third Law

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

* * *

## Third Law of Thermodynamics

The Third Law of Thermodynamics extends the definition of Entropy:

**Entropy is zero only in a _perfect crystal_ at absolute zero ( 0 kelvin [- 273.15 degree Celsius ]).**

The Third Law of Thermodynamics can mathematically be expressed as

lim ST→0 = 0 (1)

where

S = entropy (J/K)

T = absolute temperature (K)

At a temperature of absolute zero there is no thermal energy or heat. At a temperature of zero Kelvin the atoms in a pure crystalline substance are aligned perfectly and do not move. There is no entropy of mixing since the substance is pure. By -VBM

  


# Applications

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

## One Component Systems

All materials can exist in three phases: _[solid](//en.wikipedia.org/wiki/solid)_, _[liquid](//en.wikipedia.org/wiki/liquid)_, and _[gas](//en.wikipedia.org/wiki/gas)_. All one component systems share certain characteristics, so that a study of a typical one component system will be quite useful.

![One Component System](//upload.wikimedia.org/wikibooks/en/7/74/Onecompon_Engineering_Thermodynamics.png)

For this analysis, we consider heat transferred to the substance at constant pressure. The above chart shows temperature vs. specific volume (1/density) curves for at three different constant pressures. The three line-curves labeled p1, p2, and pc above are isobars, showing conditions at constant pressure. When the liquid and vapor coexist, it is called a saturated state. There is no change in temperature or pressure when liquid and vapor are in equilibrium, so that the temperature is called _saturation temperature_ and the pressure is called _saturation pressure_. Saturated states are represented by the horizontal lines in the chart. In the temperature range where both liquid and vapor of a pure substance can coexist in equilibrium, for every value of saturated temperature, there is only one corresponding value of saturation pressure. If the temperature of the liquid is lower than the saturation temperature, it is called _subcooled liquid_. If the temperature of the vapor or gas is greater than the saturation temperature it is called _superheated vapor_.

The amount of liquid and vapor in a saturated mixture is specified by its _quality x_, which is the fraction of vapor in the mixture. Thus, the horizontal line representing the vaporization of the fluid has a quality of _x=0_ at the left endpoint where it is 100% liquid and a quality of _x=1_ at the right endpoint where it is 100% vapor. The blue curve in the preceding diagram shows saturation temperatures for saturated liquid i. e. where x=0. The green curve in the diagram shows saturation temperatures for saturated vapor i. e. where x=1. These curves are not isobars.

![
  x = \\frac{m_g}{m_f + m_g}
](//upload.wikimedia.org/math/0/1/9/0193af09fbd1d626c02758ad5dd92a42.png)

![
  v_x =
  \\left\(
    1 - x
  \\right\)v_f + xv_g
](//upload.wikimedia.org/math/7/1/4/7140fc60444bcc31b1e7488af7b7d5df.png)

![
  v_{fg} = v_g - v_f
](//upload.wikimedia.org/math/8/8/6/8865fbb9f935f9abede98f9612f86586.png)

If you also consider the solid state, then we get the phase diagram for the material. The point where the solid, liquid, and the vapor state exist in equilibrium is called the  
_triple point_. Note that as the saturation temperatures increase, the liquid and vapor specific volumes approach each other until the blue and green curves come together and meet at point C on the pc isobar. At that point C, called the _critical point_, the liquid and vapor states merge together and all their thermodynamic properties become the same. The critical point has a certain temperature Tc, and pressure pc, which depend on the substance in question. At temperatures above the critical point, the substance is considered a super-heated gas.

This diagram is based on the diagram for water. Other pure (one-component) substances have corresponding temperature vs. specific volume diagrams which are fairly similarly shaped, but the temperatures, pressures, and specific volumes will vary.

The thermodynamic properties of materials are given in charts. One commonly used chart is the _[Mollier Chart](//en.wikipedia.org/wiki/Mollier_Chart)_, which is the plot of [enthalpy](//en.wikipedia.org/wiki/enthalpy) versus [entropy](//en.wikipedia.org/wiki/entropy). The pressure enthalpy chart is frequently used in refrigeration applications. Charts such as these are useful because many processes are isenthalpic, so obtaining values would be as simple as drawing a straight line on the chart and reading off the data.

_Steam tables_ give the values of specific volume, enthalpy, entropy, and internal energy for different temperatures for water. They are of great use to an engineer, with applications in steam turbines, steam engines, and air conditioning, among others.

  
_Gas tables_ give the same equations for common gases like air. Although most gases roughly obey the ideal gas equation, gas tables note the actual values which are more accurate in many cases. They are not as important as steam tables, but in many cases it is much easier to lookup from a table rather than compute answers.

### Gibbs Phase Rule

_Gibbs phase rule_ states that for a heterogeneous system in equilibrium with _C_ components in _P_ phases, the degree of freedom _F = C - P + 2_. Thus, for a one component system with two phases, there is only one degree of freedom. F=1-2+2 F =1 That is, if you are given either the pressure or temperature of wet steam, you can obtain all the properties, while for superheated steam, which has just one phase, you will need both the pressure and the temperature.

## Psychrometry

_Psychrometry_ is the study of air and water vapor mixtures for air conditioning. For this application, air is taken to be a mixture of nitrogen and oxygen with the other gases being small enough so that they can be approximated by more of nitrogen and oxygen without much error. In this psychrometry section, vapor refers to water vapor. For air at normal (atmospheric) pressure, the saturation pressure of vapor is very low. Also, air is far away from its critical point in those conditions. Thus, the air vapor mixture behaves as an ideal gas mixture. If the partial pressure of the vapor is smaller than the saturation pressure for water for that temperature, the mixture is called unsaturated. The amount of moisture in the air vapor mixture is quantified by its _humidity_.

The absolute humidity _ω_ is the ratio of masses of the vapor and air, _i.e._, _ω = mv/ma_. Now, applying ideal gas equation, _pV = mRT_ for water vapor and for air, we have, since the volume and temperature are the same, _ω = 0.622 pv/pa_. The ratio of specific gas constants (R in preceding equation) of water vapor to air equals 0.622 .

The _relative humidity_ _φ_ is the ratio of the vapor pressure to the saturation vapor pressure at that temperature, _i.e._, _φ = pv/pv,sat_.

The _saturation ratio_ is the ratio of the absolute humidity to the absolute humidity at saturation, or, _ψ = ω/ωsat_. It is easy to see that the saturation ratio is very close to the value of relative humidity.

![Absolute Humidity](//upload.wikimedia.org/wikibooks/en/7/7e/Abshum_Engineering_Thermodynamics.png)

The above plot shows the value of absolute humidity versus the temperature. The initial state of the mixture is 1, and it is cooled isobarically, and at constant absolute humidity. When it reaches 2, it is saturated, and its absolute humidity is _ωa_. Further cooling causes condensation and the system moves to point 3, where its absolute humidity is _ωb_. The temperature at 2 is called the _dew point_.

It is customary to state all quantities in psychrometry per unit mass of dry air. Thus, the amount of air condensed in the above chart when moving from 2 to 3 is _ωb − ωa_.

### Adiabatic Saturation

![Adiabatic Saturation](//upload.wikimedia.org/wikibooks/en/4/4e/Adiabatic_saturation_Engineering_Thermodynamics.png)

Consider an unsaturated mixture entering a chamber. Suppose water was sprayed into the stream, so that the humidity increases and it leaves as a saturated mixture. This is accompanied by a loss of temperature due to heat being removed from the air which is used for vaporization. If the water supplied is at the temperature of exit of the stream, then there is no heat transfer from the water to the mixture. The final temperature of the mixture is called _adiabatic saturation temperature_.

### Wet Bulb Temperature

The relative [humidity](//en.wikipedia.org/wiki/humidity) of air vapor mixtures is measured by using dry and wet bulb [thermometers](//en.wikipedia.org/wiki/thermometers). The dry bulb thermometer is an ordinary thermometer, while the wet bulb thermometer has its bulb covered by a moist [wick](//en.wikipedia.org/wiki/wick). When the mixture flows past the two thermometers, the dry bulb thermometer shows the temperature of the stream, while water evaporates from the wick and its temperature falls. This temperature is very close to the [adiabatic](//en.wikipedia.org/wiki/adiabatic) [saturation](//en.wikipedia.org/wiki/saturation) temperature if we neglect the heat transfer due to [convection](//en.wikipedia.org/wiki/convection).

### Psychrometric Chart

![Psychrometric Chart](//upload.wikimedia.org/wikibooks/en/b/b4/Psychrometric_chart_Engineering_Thermodynamics.png)

This chart gives the value of absolute [humidity](//en.wikipedia.org/wiki/humidity) versus temperature, along with the [enthalpy](//en.wikipedia.org/wiki/enthalpy). From this chart you can determine the relative humidity given the dry and wet bulb temperatures. We have, from the first law, that for a flow system with no heat transfer, the enthalpy is a constant. Now, for the [adiabatic](//en.wikipedia.org/wiki/adiabatic) [saturation](//en.wikipedia.org/wiki/saturation) process, there is no heat transfer taking place, so that the adiabatic saturation lines are the same as the wet bulb temperature and the constant enthalpy lines.

**Questions**

**1.** The temperature at [Phoenix](//en.wikipedia.org/wiki/Phoenix) is 35°C with a relative humidity of 40%. Can a room be cooled using a conventional air cooler?

    We need to find the wet bulb temperature for the point _T_ = 35°C and _φ_ = 40%. We have, from the psychrometric chart, the wet bulb temperature is between 20 and 25°C. Thus, you can cool the room down to a comfortable temperature using an evaporative cooler.

**2.** The temperature of [Los Angeles](//en.wikipedia.org/wiki/Los_Angeles) is 37°C with relative humidity of 83%. To what temperature can a room be cooled using a conventional air cooler?

    The wet bulb temperature is about 34.2°C for this situation. Thus, you cannot use an ordinary cooler to reduce room temperature in this situation. You will need to use an air conditioner.

### [Air Conditioning](//en.wikipedia.org/wiki/Air_Conditioning)

The human body can work efficiently only in a narrow range of conditions. Further, it rejects about 60 W of heat continuously into the surroundings, and more during heavy exercise. The temperature of the body is maintained by the evaporation of sweat from the body. Thus, for comfort, both the temperature and the relative humidity should be low.

Conventional air conditioning consists of setting the humidity at an acceptable level, while reducing the temperature. Reducing the humidity to zero is not the ideal objective. For instance, low humidity leads to issues like high chances of static electricity building up, leading to damage of sensitive electronic equipment. A humidity level of 50% is more acceptable in this case.

The most common method of reducing humidity is to cool the air using a conventional air conditioner working on a reversed Carnot cycle. The vapor that condenses is removed. Now, the air that is produced is very cold, and needs to be heated back up to room temperature before it is released back to the air conditioned area.

## Common Thermodynamic Cycles

Several thermodynamic cycles used in machines can be approximated with idealized cycles. It was shown previously that a Carnot engine was the most efficient engine operating between two thermal reservoirs. However, due to practical difficulties, Carnot cycle cannot be implemented in all situations. The following sections deal with idealized (non Carnot) systems found in practice.

### Rankine Cycle

In the Rankine cycle, also called the _standard vapor power cycle_, the working fluid follows a closed cycle. We will consider water as a working substance. In the Rankine cycle, water is pumped from a low pressure to a high pressure using a liquid pump. This water is then heated in the boiler at constant pressure where its temperature increases and it is converted to superheated vapor. This vapor is then expanded in an expander to generate work. This expander can be a turbine or a reciprocating (i.e. piston) machine such as those used in older steam locomotive or ship. The output of the expander is then cooled in a condenser to the liquid state and fed to the pump. The Rankine cycle differs from the Carnot cycle in that the input to the pump is a liquid (it is cooled more in the condenser). This allows the use of a small, low power pump due to the lower specific volume of liquid compared to steam. Also, the heat transfer in the boiler takes place mainly as a result of a phase change, compared to the isothermal heating of the ideal gas in the Carnot cycle, so that the efficiency is quite good (even though it is still lower than the Carnot efficiency). The amount of heat transferred as the liquid is heated to its boiling point is very small compared to the heat transfer during phase change. The steam is superheated so that no liquid state exists inside the turbine. Condensation in the turbine can be devastating as it can cause corrosion and erosion of the blades.

There are several modifications to the Rankine cycle leading to even better practical designs. In the _reheat cycle_ there are two expanders working in series, and the steam from the high pressure stage is heated again in the boiler before it enters the low pressure expander. This avoids the problem of moisture in the turbine and also increases the efficiency. The _regenerative cycle_ is another modification to increase the efficiency of the Rankine cycle. In many Rankine cycle implementations, the water enters the boiler in the subcooled state, and also, the large difference in temperature between the one at which heat is supplied to the boiler and the fluid temperature will give rise to irreversibilities which will cause the efficiency to drop. In the regenerative cycle, the output of the condenser is heated by some steam tapped from the expander. This causes the overall efficiency to increase, due to the reasons noted above.

### Otto Cycle

![Otto Cycle](//upload.wikimedia.org/wikibooks/en/3/3f/Otto_Engineering_Thermodynamics.png)

The _Otto Cycle_ is the idealization for the process found in the reciprocating internal combustion engines which are used by most automobiles. While in an actual engine the gas is released as exhaust, this is found to be a good way to analyze the process. There are, of course, other losses too in the actual engine. For instance, partial combustion and aspiration problems for a high speed engine. The working material in the idealized cycle is an ideal gas, as opposed to the air fuel mixture in an engine.

  1. Heat is transferred at constant volume during 1-2.
  2. The gas expands reversibly and adiabatically during 2-3, where work is done.
  3. Heat is rejected at constant volume at low temperature during 3-4.
  4. The gas is compressed reversibly and adiabatically in 4-1.

#### Analysis

Heat is transferred at constant volume in 1-2, so that _Q1-2 = m cv(T2 − T1)_. Similarly, the heat rejected in 3-4 is _Q3-4 = m cv (T3 − T4)_. The thermal efficiency of the Otto cycle is thus

_ηth = (Q1-2 − Q3-4)/Q1-2_

_ηth = 1 − Q3-4/Q1-2_

_ηth = 1 − (T3 − T4)/(T2 − T1)_

Since 2-3 and 4-1 are reversible adiabatic processes involving an ideal gas, we have,

_T2/T3 = (V3/V2)γ − 1_

and

_T4/T1 = (V1/V4)γ − 1_

But,

_V1 = V2_

and

_V3 = V4_

So, we have

_T2/T3 = T1/T4_

Thus,

_ηth = 1 − (T3/T2)(1 − T4/T3)/(1 − T1/T2)_

Or

_ηth = 1 − T3/T2_

If we introduce the term _rc = V3/V2_ for the compression ratio, then we have,

_ηth = 1 − rc1 − γ_

As can be seen, increasing the compression ratio will improve thermal efficiency. However, increasing the compression ratio causes the peak temperature to go up, which may cause spontaneous, uncontrolled ignition of the fuel, which leads to a shock wave traveling through the cylinder, and is called _knocking_.

### Diesel Cycle

![Diesel Cycle](//upload.wikimedia.org/wikibooks/en/b/b7/Diesel_Engineering_Thermodynamics.png)

The Diesel cycle is the idealized cycle for compression ignition engines (ones that don't use a spark plug). The difference between the Diesel cycle and the Otto cycle is that heat is supplied at constant pressure.

  1. Heat is supplied reversibly at constant pressure in 1-2.
  2. Reversible adiabatic expansion during which work is done in 2-3.
  3. Heat is rejected reversibly at constant volume in 3-4.
  4. Gas is compressed reversibly and adiabatically in 4-1.

#### Analysis

Heat is transferred to the system at constant pressure during 1-2 so that

_Qin = m cp (T2 − T1)_

Heat is rejected by the system at constant volume during 3-4:

_Qout = m cv (T3 − T4)_

Thus, the efficiency of the Diesel cycle is

_ηth = (Qin − Qout)/Qin_

_ηth = 1 − Qout/Qin_

_ηth = 1 − (cv (T3 − T4))/(cp (T2 − T1))_

_ηth = 1 − (1/γ) (T3 − T4)/(T2 − T1)_

![
\\eta_{th} = 1 - \\frac{1}{\\gamma}\\frac{T_4}{T_1}
\\left\(
  \\frac{\\frac{T_3}{T_4} - 1}{\\frac{T_2}{T_1} - 1}
\\right\)
](//upload.wikimedia.org/math/d/d/0/dd06df307b37f6b32de9fd241cd3a452.png)

We define the cutoff ratio as _rt = V2/V1_, and since the pressures at 1 and 2 are equal, we have, applying the ideal gas equation, _T2/T1 = rt_. Now, for the adiabatic processes 2-3 and 4-1 we have,

![
\\frac{T_2}{T_3} =
\\left\(
  \\frac{V_3}{V_2}
\\right\)^{\\gamma - 1}
](//upload.wikimedia.org/math/f/2/e/f2e580f417eaa2a9918cf1f1a98f84c9.png)

![
\\frac{T_1}{T_4} =
\\left\(
  \\frac{V_4}{V_1}
\\right\)^{\\gamma - 1}
](//upload.wikimedia.org/math/f/9/2/f9221f47407debfcb8c7646e5fae3284.png)

Since _V3 = V4_, we have

![
\\frac{T_2}{T_1}\\frac{T_4}{T_3} =
\\left\(
  \\frac{V_1}{V_2}
\\right\)^{\\gamma - 1}
](//upload.wikimedia.org/math/8/d/f/8df8a9a9591b7fef7692b61feb38f8bc.png)

![
\\frac{T_4}{T_3} =
\\left\(
  \\frac{V_1}{V_2}
\\right\)^{\\gamma}
](//upload.wikimedia.org/math/4/0/0/400213ff1219349040f5a5b7e49378d2.png)

![
\\eta_{th} = 1 - \\frac{1}{\\gamma}\\frac{1}{r_c^{\\gamma - 1}}
\\left\(
  \\frac{r_t^\\gamma - 1}{r_t - 1}
\\right\)
](//upload.wikimedia.org/math/a/7/9/a79176cd8f39298a9c87db545a2a3bed.png)

### Dual Cycle

![Dual Cycle](//upload.wikimedia.org/wikibooks/en/9/96/Dual_Engineering_Thermodynamics.png)

The dual cycle is sometimes used to approximate actual cycles as the time taken for heat transfer in the engine is not zero for the Otto cycle (so not constant volume). In the Diesel cycle, due to the nature of the combustion process, the heat input does not occur at constant pressure.

### Gas Turbine Cycle (or Joule-Brayton Cycle)

Gas turbines are rotary internal combustion engines. As the first stage air is drawn in from outside and compressed using a compressor. Then the fuel is introduced and the mixture is ignited in the combustion chamber. The hot gases are expanded using a turbine which produces work. The output of the turbine is vented outside as exhaust.

![Gas Turbine Cycle](//upload.wikimedia.org/wikibooks/en/a/a3/Brayton_Engineering_Thermodynamics.png)

The ideal gas turbine cycle is shown above. The four stages are

  1. Heat input at constant pressure during 1-2.
  2. Reversible adiabatic expansion during 2-3, where work is done.
  3. Heat rejection at constant pressure during 3-4.
  4. Reversible adiabatic compression during 4-1 where work is consumed.

Large amount of work is consumed in process 4-1 for a gas turbine cycle as the working material (gas) is very compressible. The compressor needs to handle a large volume and achieve large compression ratios.

#### Analysis

The heat input in a gas turbine cycle is given by _Qin = m cp (T2 \- T1)_ and the heat rejected _Qout = m cp (T3 \- T4)_. Thus the thermal efficiency is given by

![
  \\eta_{th} = 1 - \\frac{Q_{out}}{Q_{in}}
](//upload.wikimedia.org/math/8/4/e/84efbd59fc1e248802cd7cab4c8932a8.png)

![
  \\eta_{th} = 1 -
  \\left\(
    \\frac{T_3 - T_4}{T_2 - T_1}
  \\right\)
](//upload.wikimedia.org/math/d/8/7/d87e98720dfe25709b50055fde6a4a7c.png)

![
  \\eta_{th} = 1 - \\frac{T_4}{T_1}
  \\left\(
    \\frac{\\frac{T_3}{T_4} - 1}{\\frac{T_2}{T_1} - 1}
  \\right\)
](//upload.wikimedia.org/math/6/b/3/6b3a622d8c0c43f37b3a51b140afa155.png)

Since the adiabatic processes take place between the same pressures, the temperature ratios are the same

![
  \\eta_{th} = 1 - \\frac{T_4}{T_1} = 1 - \\frac{1}{
    \\left\(
    \\frac{p_1}{p_4}
    \\right\)^{\\frac{\\gamma - 1}{\\gamma}}}
](//upload.wikimedia.org/math/c/a/7/ca7f30dcd21bab9d347ac7bf4413d3f3.png)

Or

![
  \\eta_{th} = 1 - \\frac{1}{r_p^{\\frac{\\gamma - 1}{\\gamma}}}
](//upload.wikimedia.org/math/2/5/9/259ac4622ebfd20e242dfdaecdd06e54.png)

Where _rp_ is the pressure ratio and is a fundamental quantity for the gas turbine cycle.

### Refrigeration Cycles

The ideal refrigeration cycle is reverse of Carnot cycle, working as a heat pump instead of as a heat engine. However, there are practical difficulties in making such a system work.

The _gas refrigeration cycle_ is used in aircraft to cool cabin air. The ambient air is compressed and then cooled using work from a turbine. The turbine itself uses work from the compressed air, further cooling it. The output of the turbine as well as the air which is used to cool the output of the compressor is mixed and sent to the cabin.

The Rankine vapor-compression cycle is a common alternative to the ideal Carnot cycle. A working material such as Freon or R-134a, called the _refrigerant_, is chosen based on its boiling point and heat of vaporization. The components of a vapor-compression refrigeration system are the compressor, condenser, the expansion (or throttling) valve, and the evaporator. The working material (in gaseous form) is compressed by the compressor, and its output is cooled to a liquid in the condenser. The output of the condenser is throttled to a lower pressure in the throttling valve, and sent to the evaporator which absorbs heat. The gas from the evaporator is sent to the compressor, completing the cycle.

Standard refrigeration units use the throttling valve instead of a turbine to expand the gas as the work output that would be produced is not significant to justify the cost of a turbine. There are irreversibilities associated with such an expansion, but it is cost effective when construction costs are considered.

* * *

**[Engineering Thermodynamics](/wiki/Engineering_Thermodynamics)** | [Thermodynamic Systems](/wiki/Engineering_Thermodynamics/Thermodynamic_Systems) | [First Law](/wiki/Engineering_Thermodynamics/First_Law) | [Second Law](/wiki/Engineering_Thermodynamics/Second_Law) | [Applications](/wiki/Engineering_Thermodynamics/Applications)

  


# Further Reading

Further reading and resources:

  * Kostic, M. (2008). _Sadi Carnot’s Ingenious Reasoning of Ideal Heat-Engine Reversible Cycles_ (Proceedings of the 4th IASME/WSEAS International Conference on ENERGY, ENVIRONMENT, ECOSYSTEMS and SUSTAINABLE DEVELOPMENT (EEESD'08), Algarve, Portugal, June 11-13, 2008. In NEW ASPECTS OF ENERGY, ENVIRONMENT, ECOSYSTEMS and SUSTAINABLE DEVELOPMENT (Editors: T. Panagopoulos, T. Noronha Vaz , M. D. Carlos Antunes) ed.). WSEAS Press. pp. 159-166. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-960-6766-71-8](/wiki/Special:BookSources/978-960-6766-71-8).  ([full text](http://www.kostic.niu.edu/energy/WSEAS-EEESD08_588-357Kostic-Sadi%20Carnot’s%20Ingenious%20Reasoning.pdf))
  * [Thermodynamics](/wiki/Thermodynamics)
  * [Engineering Thermodynamics - A Graphical Approach](http://www.ent.ohiou.edu/~thermo/) by Dr. Israel Urieli, Ohio University Dept of Mechanical Engineering
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Engineering_Thermodynamics/Print_version&oldid=2440944](http://en.wikibooks.org/w/index.php?title=Engineering_Thermodynamics/Print_version&oldid=2440944)" 

[Category](/wiki/Special:Categories): 

  * [Engineering Thermodynamics](/wiki/Category:Engineering_Thermodynamics)

Hidden category: 

  * [Pages with broken file links](/wiki/Category:Pages_with_broken_file_links)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Engineering+Thermodynamics%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Engineering+Thermodynamics%2FPrint+version)

### Namespaces

  * [Book](/wiki/Engineering_Thermodynamics/Print_version)
  * [Discussion](/w/index.php?title=Talk:Engineering_Thermodynamics/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Engineering_Thermodynamics/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Engineering_Thermodynamics/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Engineering_Thermodynamics/Print_version&action=edit)
  * [View history](/w/index.php?title=Engineering_Thermodynamics/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Engineering_Thermodynamics/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Engineering_Thermodynamics/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Engineering_Thermodynamics/Print_version&oldid=2440944)
  * [Page information](/w/index.php?title=Engineering_Thermodynamics/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Engineering_Thermodynamics%2FPrint_version&id=2440944)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Engineering+Thermodynamics%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Engineering+Thermodynamics%2FPrint+version&oldid=2440944&writer=rl)
  * [Printable version](/w/index.php?title=Engineering_Thermodynamics/Print_version&printable=yes)

  * This page was last modified on 14 November 2012, at 22:16.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Engineering_Thermodynamics/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
