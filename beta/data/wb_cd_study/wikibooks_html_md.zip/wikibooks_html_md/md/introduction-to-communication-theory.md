# Introduction to Communication Theory/Print version

From Wikibooks, open books for an open world

< [Introduction to Communication Theory](/wiki/Introduction_to_Communication_Theory)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Introduction_to_Communication_Theory/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Introduction_to_Communication_Theory/Print_version) on _27 September 2012_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Introduction_to_Communication_Theory/Print_version&oldid=2411935&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


## Contents

  * 1 Introduction
    * 1.1 Introduction
    * 1.2 Defining Communication
    * 1.3 Early Mistakes
  * 2 Evaluating Theory
    * 2.1 Quantitative and Qualitative Research
  * 3 Semiotics
  * 4 Culture
  * 5 Media Content

# Introduction

## Introduction

With every interaction, whether active or passive, we find ourselves communicating with other people. Even our silence connotes some intention, which others may interpret at their discretion. Whether by artifact or by attendance, every human being constantly participates in the process of communication. The field of Communication Theory exists at a crossroads of Psychology and Sociology, borrowing heavily from each, illuminating a process that defines what it is to be human.

## Defining Communication

Reasonable men and woman have put forth plenty of definitions. However, the field and the process are not so easily defined by curt declarative statements or laconic aphorisms. Within every research direction, we discover a new means to describe communication and a new method of investigation. Ironically, many academics encourage their students to develop their own, personal, definition of communication. There is no proper perspective of what communication is, just as there is no limit to the potential of what it is to be human. In this textbook you will be exposed to various perspectives, with which you may find varying concordance. Your role is to approach them with an open but critical mind. Like other Social Sciences, the field of Communication theory is a [soft science](//en.wikipedia.org/wiki/Soft_Science).

_communication means exchange of ideas,views, opinion, understanding,feelings,emotions,facts or information between two or more persons by any sources or medium_

## Early Mistakes

Early theorists of human interaction believed such activity could be measured and predicted with a similar methodology to those used in physics and chemistry. [Positivism](//en.wikipedia.org/wiki/Positivism) within the social sciences often drove the ridiculous notions of determinism rampant in the 19th and early 20th century. [Auguste Comte](//en.wikipedia.org/wiki/Auguste_Comte), while an invaluable contributor to Sociology, derogated woman to a position of innate intellectual inferiority. Whether by biology or ethnology, positivists often asserted the superior nature of one class over another. Biological determinism was heavily referenced within eugenics movements, and remains a hot topic issue in regard to gender imbalances in academia, business and politics. While the laws of physics provide scientists with exact predictive formula, there are no analoguous laws to human behavior, only corrolates (or probabilities). One can certainly state that in all likelihood upper class children will display superior cognitive abilities to those raised in slums. One could argue that the higher instance of men in engineering professions and women in secretarial positions are corrolated with gendered brain chemistry. However, these remain corrolates. To state that woman are inferior in math to men, that poor children (who by majority are of non-European descent) are intellectually inferior, or simply that children who learn to read earlier in life than others are somehow deficient, is to step beyond correlation into prediction. It is to these ends that many scientific endevours step far out of science and into [fallacious reasoning](//en.wikipedia.org/wiki/Logical_fallacy). Just as I.Q. tests presume to measure intelligence, positivists presumed to measure all sorts of amorphous properties, predicting far beyond reasonable evidence.

  


# Evaluating Theory

What makes a [theory](//en.wikipedia.org/wiki/theory) "good"? Six criteria might be said to be properties of a strong theory. (The terminology presented here is drawn from Littlejohn, _Theories of Human Communication_, but a similar set of criteria are widely accepted both within and outside the field of communication.)

Theoretical Scope 
    How general is the theory? That is, how widely applicable is it? In most cases, a theory that may only be applied within a fairly narrow set of circumstances is not considered as useful as a theory that encompasses a very wide range of communicative interactions. The ideal, of course, is a theory that succinctly explains the nature of human communication as a whole.

Appropriateness 
    Theories are often evaluated based upon how well their [epistemological](//en.wikipedia.org/wiki/epistemology), [ontological](//en.wikipedia.org/wiki/ontology), and [axiological](//en.wikipedia.org/wiki/axiology) assumptions relate to the issue or question being explained. If a theory recapitulates its assumptions (if it is [tautological](//en.wikipedia.org/wiki/tautology)), it is not an effective theory.

Heuristic value 
    Some theories suggest the ways in which further research may be conducted. By presenting an explanatory model, the theory generates questions or hypotheses that can be [operationalized](/w/index.php?title=Operationalize&action=edit&redlink=1) relatively easily. In practical terms, the success of a theory may rest on how readily other researchers may continue to do fruitful work in reaction or support.

Validity 
    It may seem obvious that for a theory to be good, it must also be [valid](//en.wikipedia.org/wiki/validity_\(psychometric\)). Validity refers to the degree to which the theory accurately represents the true state of the world. Are the arguments internally consistent and are its predictions and claims derived logically from its assumptions? Many also require that theories be [falsifiable](//en.wikipedia.org/wiki/falsify); that is, theories that present predictions that--if they prove to be incorrect--invalidate the theory. The absence of such questions significantly reduces the value of the theory, since a theory that cannot be proven false (perhaps) cannot be shown to be accurate, either.

Parsimony 
    The law of parsimony ([Occam's razor](//en.wikipedia.org/wiki/Occam%27s_razor)) dictates that a theory should provide the simplest possible (viable) explanation for a phenomenon. Others suggest that good theory exhibits an aesthetic quality, that a good theory is beautiful or natural. That it leads to an "Aha!" moment in which an explanation feels as if it fits.

Openness 
    Theories, perhaps paradoxically, should not exist to the absolute exclusion of other theories. Theory should not be dogma: it should encourage and provide both for skepticism and should--to whatever degree possible--be compatible with other accepted theory.

It is important to note that a theory is not "true," or "false" (despite the above discussion of falsifiability), but rather better or worse at explaining the causes of a particular event. Especially within the social sciences, we may find several different theories that each explain a phenomenon in useful ways. There is value in being able to use theories as "lenses" through which you can understand communication, and through which you can understand the world _together_ with other scholars.

As a task, apply the aforementioned criteria to the Universal Communication Law. How does the Universal Law fit?

The Universal Communication Law :"All living entities, beings and creatures communicate." In a an unpublished interview, Scudder clarified the concept - "All of the living communicate through movements, sounds, reactions, physical changes, gestures, languages, breath, color transformations, etc. Communication is a means of survival, existence and being and does not need another to acknowledge its presence. Examples - the cry of a child (communication that it is hungry, hurt, cold, etc.); the browning of a leaf (communication that it is dehydrated, thirsty per se, dying); the cry of an animal (communicating that it is injured, hungry, angry, etc.). Everything living communicates."

  


## Quantitative and Qualitative Research

Research goals will differ between individual scientists and project demands. There are many studies based on research is accomplished through interviews and social participation with members of cultural groups (see: [Ethnomethodology](//en.wikipedia.org/wiki/Ethnomethodology)). This type of research is known as [qualitative research.](//en.wikipedia.org/wiki/Qualitative_research). It is the task of the author to convey the connection between their research subjects and thesis. Their goal is to describe a phenomenon, to portray a situation so as to enlighten the readers of their work. They stand in stark contrast to quantitative researchers.

The quantitative researcher may eschew the lax methodology of qualitative research. Where qualitative research often demands emotional significance and an engaging rhetorical style, quantitative research is often sterile and to the point. The quantitative researcher may also participate within the speech community of their subject, but they will do so in a very disciplined fashion. They will be on the look for data with which they can record. They may for instance, interview a person, taking note of personal affects and vocalizations. A [sociolinguist](/w/index.php?title=Sociolinguistics&action=edit&redlink=1) for example, will record every utturance of the vowel "r". They'll compile the data and compare it with data from a distinct economic class or a similar group. By keeping a count of every "r" spoken with an accent, for instance, the sociolinguist is able to write a quantitative analysis. They are able to identify patterns that may suggest a useful correlation. Accents for instance will often identify which members of a larger speech community a person identifies with. Predictability is a strong criteria for a quantitative researcher. Thus this type of research is often used in marketing studies. Marketing companies want to know how to effect their audience, and to what degree. Though it is futile to predict marketing effects on a single individual, it is quite possible to predict an overall effect within a large group. Marketers will use various [post-positivist](//en.wikipedia.org/wiki/Post-positivist) studies to enhance the effects of marketing exposure. "Sex sells" can be proven and studied through quantitative means.

These two methods are by no means mutually exclusive. Though they are two different routes they can both be used to further a hypothesis or field of inquiry. [Media studies](//en.wikipedia.org/wiki/Media_studies) and [Semiotics](//en.wikipedia.org/wiki/Semiotics) are two strong implimentations of both techniques. They may demand a researcher to wade through thousands of pieces of media to develop a cogent thesis. The researcher may take note of every sexually suggestive image broadcast within Primetime television viewing hours for a given month. This could be compared against other markets to develop a claim. But the researcher could also view single popular series, and again develop a claim as to the motivation for such content. The field of news-entertainment is often criticized for its choice of scare-stories (see: [Cultivation Theory](//en.wikipedia.org/wiki/Cultivation_Theory) and [Agenda-Setting Theory](//en.wikipedia.org/wiki/Agenda-Setting_Theory)). Only after a series of strong studies, both qualitative and quantitative, can a researcher authoritatively claim that news-entertainment does indeed market trauma, by egregious coverage of violence and catastrophe (if it bleeds it leads). Only then can a researcher credibly claim that such coverage has an effect on television consumers. Only at that point can a study be carried out to identify what that effect is.

Griffin in his textbook, "A First Look at Communication Theory", provides a small chart meant to aid in the evaluation of quantitative and qualitative theory.

Scientific (Quantitative) Theory Interpretive (Qualitative) Theory

Explanation of Data
Understanding of People

Prediction of Future
Clarification of Values

Relative Simplicity
Aesthetic Appeal

Testable Hypotheses
Community of Agreement

Practical Utility
Reform of Society

  


# Semiotics

The literary theorist [Kenneth Burke](//en.wikipedia.org/wiki/Kenneth_Burke) famously described human beings as "the symbol-making, symbol-using, symbol-misusing animal". Our broad use of symbols is a contrast from every species on earth. Only our closest relative, the [Bonobo](//en.wikipedia.org/wiki/Bonobo) has shown any semblance of our symbol-using ability. It is the unique act of creating meaning out of arbitrary signs (be they vocalizations, gestures, or pictographs) that allows us to communicate an infinite range of concepts so fluently.

Through the Looking Glass, Chapter 6, by Lewis Carroll:  
"When I use a word," Humpty Dumpty said, in rather a scornful tone, "it means just what I choose it to mean -- neither more nor less."  
"The question is," said Alice, "whether you can make words mean so many different things."  
"The question is," said Humpty Dumpty, "which is to be master -- that's all."  
  
Put in other words, put forth by different authors, "naming is the fundamental symbolic act".

  


# Culture

Every human being passes through a development period of enculturation. Traits and taboos are passively and actively enculcated through childhood and adolescence. Though individual will curtails some habits, every individual learns at least a part of their native culture. Some may live in interstitial communities, becoming both bilingual and bicultural while others learn later in life how to move through the earth's diverse human populations. But regardless, we all carry our culture with us and in our daily lives, enact culture. Culture, like communication, is a process.

Within communication theory, scientists often study the interaction of people from different cultures. As culture is not a static concept, the very definition of culture becomes broader than you may have assumed. For instance, have you thought of the separation of boys and girls as being a form of cultural separation? For years, Deborah Tannen has studied the language and cultural differences of men and women, girls and boys, within American society. She has found a prevalence of communication differences between genders, that often lead to miscommunication between the two. Consider the difference in culture of people raised in agrarian (rural) and urban (city) environments. The [2004 U.S. Presidential Election](//en.wikipedia.org/wiki/U.S._presidential_election,_2004) shows both diversity and homogeneity of American voting habits. The dark blue areas, representing democrats, mark the waterways and coastal regions of the U.S. The red areas show the geography of the U.S. with a low population per square mile. While many point out the "purple" mixtures of heterogeneous voters, it is clear that there are vast areas of America differentiated by vote. Might they be distanced in culture as well? Though English is the standard (not official) language of the United States, there are many ways of speaking it and there are many regions where other languages are dominant. Intercultural communication is not necessarily International communication. Nor must the interlocutors necessarily belong to different regions or different towns. Within every context, we recreate culture (see: [Adaptive Structuration Theory](//en.wikipedia.org/wiki/Adaptive_Structuration_Theory)) and redefine what our native culture actually is. It is when we come into contact with a person that is separate from our own culture that we engage in intercultural communication, and forge a synthesis of cultures.

Imagine that you have just awoken in a foreign place. There are no trees, no buildings, there is only sand and brush for as far as you can see into the horizon. But there is something else, another person. From the very moment you notice the person, still asleep, you have made judgements. What are they wearing, do they have any markings on their skin, and what color is their skin, and what kind of footwear is that, and are they wearing jewelry, and are they wearing jewelry on their fingers? From the first moment you see a person you're mind produces many questions, questions you've learned from your own culture and from your own experience, questions that make sense of the signs that your senses are perceiving. Signs from the raw data of your environment. But when the signs are about another person, they are forms of communication. If the person has a ring, are they married, if they have jewelry are they rich, if they're not wearing shoes are they laid back, informal, or otherwise defined? With each quantum of perception your brain mind attempts to identify culture.

Your unwitting company has now awoken. Now they are making judgements. Soon one of you will attempt bilateral communication. Until this point you've only been a receiver, and by your own learned admission, a rather unsure receiver. But now you have the opportunity to confirm some of your judgements, whether conscious or unconsciously reached. From the very first moment you notice the other person has seen you, even more judgements rush to your head. How will they acknowledge my presence, and what are they thinking about their own. What is their self-awareness, what is their awareness of me, the Other. If they look into your eyes, is it a sign of compassion or a threat? You open your mouth, a sign from your own culture (and a fairly common sign amongst others) that you intend to speak, to communicate verbally. But the other person upon hearing your words steps back several feet, as if threatened. Nonverbal communication it seems, will be your intercultural starting point. At this point a microculture is being defined. Though it is only a relationship, and a shallow one at that, it has become a confluence of two cultures. How you and the Other will develop this new acquaintance is uncertain. At some point you will have successfully communicated a message nonverbally. Your Other already has. It is through communicative competence whether learned through academia, life or intuition, that you and the Other will build a new culture. This may be a temporary culture, lasting only a day, or it may grow as something more lasting. Still, from the building blocks of universal communication between two people, you will use symbolic communication to convey your intents and negotiate your situation.

  


# Media Content

[Introduction to Communication Theory/Media Content](/w/index.php?title=Introduction_to_Communication_Theory/Media_Content&action=edit&redlink=1)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Introduction_to_Communication_Theory/Print_version&oldid=2411935](http://en.wikibooks.org/w/index.php?title=Introduction_to_Communication_Theory/Print_version&oldid=2411935)" 

[Category](/wiki/Special:Categories): 

  * [Introduction to Communication Theory](/wiki/Category:Introduction_to_Communication_Theory)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Introduction+to+Communication+Theory%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Introduction+to+Communication+Theory%2FPrint+version)

### Namespaces

  * [Book](/wiki/Introduction_to_Communication_Theory/Print_version)
  * [Discussion](/w/index.php?title=Talk:Introduction_to_Communication_Theory/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Introduction_to_Communication_Theory/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Introduction_to_Communication_Theory/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Introduction_to_Communication_Theory/Print_version&action=edit)
  * [View history](/w/index.php?title=Introduction_to_Communication_Theory/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Introduction_to_Communication_Theory/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Introduction_to_Communication_Theory/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Introduction_to_Communication_Theory/Print_version&oldid=2411935)
  * [Page information](/w/index.php?title=Introduction_to_Communication_Theory/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Introduction_to_Communication_Theory%2FPrint_version&id=2411935)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Introduction+to+Communication+Theory%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Introduction+to+Communication+Theory%2FPrint+version&oldid=2411935&writer=rl)
  * [Printable version](/w/index.php?title=Introduction_to_Communication_Theory/Print_version&printable=yes)

  * This page was last modified on 27 September 2012, at 07:03.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Introduction_to_Communication_Theory/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
