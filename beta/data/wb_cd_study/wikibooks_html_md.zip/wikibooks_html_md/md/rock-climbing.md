# Rock Climbing/Print version

From Wikibooks, open books for an open world

< [Rock Climbing](/wiki/Rock_Climbing)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Rock Climbing](/wiki/Rock_Climbing)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Rock_Climbing/Print_version&action=purge&printable=yes) this page.

# Equipment

## Basic gear

### Shoes

Climbing shoes should be tight, but not cause pain. Entry level shoes will have flatter soles, while those that arch are meant for more skilled climbers.

### Chalk

Just as in certain types of gymnastics, rock-climbers typically use chalk (in fact usually magnesium carbonate) for drying their hands to prevent slipping. Chalk comes in three general forms; blocks, powder inside balls of cloth, and liquid.

Blocks of chalk tend to cruble and make a mess so some gyms don't allow their use. Liquid chalk is a mixture of powdered chalk with a volatile liquid which evaporates in a matter of seconds, leaving a relatively long lasting coating of chalk. Chalk balls are probably the most common of the three.

### Helmet

Some climbers use a helmet to protect themselves in high falls, or from falling rocks and other objects.

## Top-roping

### Harness

Unless when bouldering, climbers are usually secured with a rope which is attached to the climber's harnesses, a webbed belt that fits around one's waist and thighs. The belayer will typically also wear a harness to which the belay device is attached, using the belayer's weight as an anchor.

### Rope

### Carabiners and webbing

You will need a few for the anchors.

## Lead-climbing

### Quickdraws

These are pairs of carabiners connected with webbing. These are clipped into anchors bolted into the face of the rock.

### Removable protection

On traditional lead climbes where there are no bolts, protection devices are secured in places such as cracks by the lead, and cleared by the second. These include:

  * Aluminum or steel nuts
  * Hexagonal-shaped chocks
  * Slings
  * Spring loaded camming device
  * Tricams

# Technique

## Use your feet

The choice of where you place your feet is the major determiner of where you can go next.

### Lead with your feet

Your reach extends only as far as you are tall, so to reach farther you have to move your feet up. Obvious, but new climbers tend to focus only on their hands and the direction they are going -- up -- and forget that their feet have to move up the wall too. If you do this, you'll become extremely stretched out on the wall. It's really hard to move out of this position. It'll be hard to see where to place your feet because your torso is pulled in so close to the wall, and it will be hard to actually make the next move. A better technique is to move the feet up, which moves the torso up, which increases the range of holds that the hands can reach. Moving the feet up first also bends the knees and hips which gives the climber leverage, and makes climbing up easier. You do want to stay in close to the wall, but as I'll talk about later, generally you want to twist and keep one side (not your front) in to the wall so that the other side is free to move. Avoid becoming too stretched out as it limits your options.

### Place your feet quickly

When climbing, you want to save your strength for big moves that really require it. Try to avoid whittling away your reserves by using your arms when you could be using your feet throughout the climb. The muscles in your legs are larger and stronger than the muscles in your arms, and you want to try to use this fact to your advantage as much as possible. To do this, keep your feet on the wall! Avoid leaving limbs dangling. Before making a move, think about where your feet are going next. After you make the move, place your feet back on the wall as quickly as possible to minimize the time that you are holding your body weight with your arms.

## Use your legs

As noted above, your legs are stronger than your arms and you should use this to your advantage. Your legs carry your weight every day, but routinely your arms only carry a fraction of it. New climbers tend to focus on their arms and pull themselves up the wall. One of the most common excuses I hear from people who think they can't climb is "but I have no upper body strength". This statement is misguided because massive upper body strength isn't necessary at all. Overusing your arms and neglecting your legs is simply bad technique. Practice using your legs to push yourself up, and using your arms only for balance. Step up to a foot hold and stand up on it by straightening your leg and keeping your hips in to the wall, while at the same time putting as little weight as possible into your hands. (This is easiest to practice on slab or on a wall that's a few degrees from vertical.) This technique will teach you to use your body mechanics efficiently.

Keeping weight out of your hands will also aid in not overgripping (holding on with more strength than is strictly necessary).

Pushing with your legs will also be covered in the section on stemming when talking about using opposing forces.

### Place your feet carefully and firmly

Your feet should not make noise when you place them on the hold. If they are, you are wasting energy by bringing them down faster and harder than is necessary. If your feet are making noise then your foot placement is also likely to be a little sloppy and uncontrolled.

Climb using the edges of your feet. Aim to place the ball of your big toe on the hold. Avoid using the ball of your foot, as using your toe will give you a little more reach, and a little more leverage -- often that's all that is needed to get through the crux of a climb. Climbing shoes are designed to make this efficient. They draw your toes together, giving you a smaller surface to place on the rock, minimizing the size of the foothold you'll need.

Once you have placed your foot, press it firmly downwards and into the wall. Keeping tension in your leg will reduce the chance of your foot slipping, and will of course move you upwards.

See also the section on shifting your weight for advanced foot placement techniques.

Other foot placement techniques involve using your heel hooked around a hold to pull yourself towards it. I'll talk about these in detail in later sections.

### Smear

Smearing is the technique of pushing the flat of your foot on the wall where there is no foothold. The friction between the sole of your shoe and the wall is enough to hold your weight up. It creates a point of contact with the wall to maintain balance while you make a move. As soon as you are able, move the smearing foot back to a foothold. The keys to smearing are the force and direction in which you push into the wall. Friction is proportional to the amount of force applied, so use a lot of muscle to press your foot into the wall. The harder you push, the less likely your foot is to slip off. Also you want to be going up (presumably), so the force should be directed slightly downwards (not just perpendicular to the wall), to give you a bit of help.

### Trust your feet

Yes, the hold is small. Yes, you can stand on it. Yes, it will hold your weight.

Like a ballet shoe, climbing shoes are designed to cram your toes together into a point. This focuses your weight into a smaller area, making it easier to stand on smaller things. It's not natural to stand with only the ball of your big toe on a 5mm (or smaller!) wide ledge, but it is possible, and it is good climbing technique. Learning to trust your feet is necessary to climb harder routes strictly from a physical perspective. It is absolutely essential from a mental perspective to allow you to be comfortable on the rock. If you are constantly questioning if the hold is good enough to step on, then you can't concentrate on the sequence of moves you are executing, and you'll psych yourself out.

## Understand gravity and the forces you exert to oppose it

It takes time, but after enough practice you will begin to develop an intuitive sense for how shifting your limbs changes your centre of gravity and how your body will shift on the rock. With that understanding, you can start using the way your body shifts to your advantage.

### Keep your hips close to the wall

Keeping your body close to the wall accomplishes three things: first, it decreases the distance you have to move to get to the next hold, second, it increases the effectiveness of your footholds, and finally it decreases the amount of force in your arms that you need to hold yourself up. This is true whether the wall is vertical or overhung.

### Flag

Picture the following: you are standing on two footholds which are at the same height, and you have your left hand on a generous handhold. The next hold is farther left. Imagine matching on the rightmost hand hold, then reaching for the next hold with your left hand, all while keeping your feet where they started. If the second hold is far enough to the left, this will shift your centre of gravity far enough to the left that your right side will start to spin out from the wall, and it can be very hard to keep holding on to the new hold with your left hand.

Now imagine the same initial situation and again match hands on the first hand hold. This time though, as you move your left hand out to the next hold to the left, also move your right leg out to the right. This will keep your centre of gravity over your left leg, and will reduce torque. As you do this, also twist your torso to the right so that you are reaching backwards with your left hand for the hold out to the left. This will maximize your reach (see the section on reaching backwards) and will make flagging with your right leg easier as it will be moving out in front of you, not out to the side.

A slightly more awkward, but possible technique is to flag with your left foot to the right. From the same starting situation, switch feet so your right foot is where your left was originally. As you reach for the hold to the left with your left hand, move your left leg to the right behind your right leg to counterbalance. This configuration may be useful depending on the rest of the climb.

### Avoid barndooring

When you have the points of contact between your body and the wall are all to the left or all to the right, gravity will want to pull your body out from the wall. This is called "barn-dooring", as your points of contact act like a hinge and your body rotates around it, away from the wall. To prevent this from happening, either make sure that your center of gravity is between your holds (for example, using your left hand and your right foot as opposed to left hand and left foot), or you can flag to balance out where you body is as compared to the holds.

### Use opposing forces (Stemming)

We've already talked about the importance of pushing your feet into the wall when you climb. Stemming is the art of managing these forces to help you climb up. Think about climbing up the inside of a narrow chimney. You can press a foot into the wall in front of you, the other into the wall behind you, and use these forces to hold your weight up. Then, press your hands into opposite walls, and one at a time, shift both feet up a foot or so, then stand up on your legs. Repeat. This is technique of using opposing forces is called stemming, and it's applicable to many more frequently encountered situations.

Stemming is not useful only in chimneys or in situations where two walls meet at an angle. You will find it useful, especially when climbing a route with many slopers, to push off a lower hold to be able to reach for a higher hold.

### Shift your weight

Often times, a hold may only be good if pulled at from one direction; however, you may not be pulling from that direction when you first use the hold. In order to get a better grip, you will need to shift your weight, so that gravity is pulling you into the hold instead of away. A similar problem occurs when making a horizontal or diagonal move, where reaching for the hold will move you off balance. To compensate, first shift your weight towards where the hold is, so that you remain supported while reaching.

## Maximize your reach

### Reach backwards

People who start climbing want to face towards their next hold as they are reaching for it. Due to the way the shoulder is constructed, turning away from the next hold and reaching backwards for it actually allows a farther reach than reaching forwards does. Think about how you would reach for something that is far under a bed, and use the same twisting motion in your climbing.

### Stand up

Another tendency of beginning climbers is to not take full advantage of the holds available to them. For example, if you have a foot on a hold with your knee bent, stand up before reaching for the next hand hold. Maximize your upwards extension on the available holds before reaching for new hand holds. Keep your arms straight as you do this so as to not pump out your biceps. (There is one situation in which this is not good advice -- if your hand holds are slopers, it's often better to stay underneath or to one side of them.) This is strongly related to keeping your hips close to the wall -- if you do that, you will naturally keep your legs straighter.

### Highstep/Hand-Foot Match

### Bump

Bumping is another technique to gain a few more inches. If the rock is such that the only hold within reach is too small to hang off but just a little farther up is a much more generous hold, you can bump. Move to the lower hold, and quickly use it to gain more momentum, so that you can reach the next solid hold.

## Plan your route

As you are climbing, think at least one move ahead. Make sure that where you place your right hand now is where you want your right hand so that you can move your left. Same for your feet. It doesn't always make sense to grab the first available hold, especially if the climb veers to one side. If you are climbing to the right and moving your right hand, move two holds over so that you can move your left rightwards without having to match. This will make your climbing smoother.

Pay attention to the shape of the holds. If they are only positive (allow for a good grip) on the left hand side, then place your body to the right of the holds, so you can more effectively resist gravity.

## Be elegant

### Just enough force

Easy climbs tend to have holds with enough grip that launching oneself towards the wall can be compensated for by pulling on the holds. Not only will this stop working as the holds become smaller and balance more important, but it also wastes energy. Use only enough force to reach the hold, don't overshoot. (This is related to stepping lightly.) Similarly, use only enough force to grip the hold; don't waste energy squeezing the rock harder than is necessary to hold on.

### Fluidity

Good climbers make climbing look effortless. One aspect of achieving this is maintaining momentum from move to move. If you are planning ahead, don't stop at each move; flow between moves.

## Be bold

A lot of moves in a climbing route may seem difficult at first, especially if you are lead climbing. Psychologically, this makes it difficult to fully commit to the move, since your body is tensing up in anticipation of falling. Remember, however, that all the equipment is there to keep you safe, and that you are usually protected from injury even if you don't make the move. Getting over this psychological fear - being bold on a problem - will help you focus on the climb instead of the fall.

# Training

There are many different training regimes instituted by climbers. As with all sports, training should chosen with respect to the climber's goals and experience level. Training regimes may include a mixture of bouldering, caving, finger and body weight exercises, versa-climber training, route climbing, and up/down climbing.

## Technique

Bouldering usually consists of climbing at a low height without supports and moving laterally, and vertically along the climbing surface. Bouldering routes can be very useful to practice technique as it's easy to start at difficult parts and practice them specifically.

## Strength and endurance

Caving adds an extra dimension of climbing beneath overhanging surfaces, and hanging from the roof.

Body weight exercises or _calisthenics_ that focus on the back,leg, and finger muscles should be a focus for any climber. Leg exercises are essential as climbing is more like crawling than doing repeated chin-ups and a lot of technique is aimed at maximising the use of all limbs, balancing weight between hand- and foot holds.

A Versa climber is cardiovascular machine, sometimes used to train upper body and lower body endurance.

Up/Down climbing is used to also train endurance, and involves climbing up to a location and then climbing back down.

# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Rock_Climbing/Print_version&oldid=1499890](http://en.wikibooks.org/w/index.php?title=Rock_Climbing/Print_version&oldid=1499890)" 

[Category](/wiki/Special:Categories): 

  * [Rock Climbing](/wiki/Category:Rock_Climbing)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Rock+Climbing%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Rock+Climbing%2FPrint+version)

### Namespaces

  * [Book](/wiki/Rock_Climbing/Print_version)
  * [Discussion](/w/index.php?title=Talk:Rock_Climbing/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Rock_Climbing/Print_version)
  * [Edit](/w/index.php?title=Rock_Climbing/Print_version&action=edit)
  * [View history](/w/index.php?title=Rock_Climbing/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Rock_Climbing/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Rock_Climbing/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Rock_Climbing/Print_version&oldid=1499890)
  * [Page information](/w/index.php?title=Rock_Climbing/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Rock_Climbing%2FPrint_version&id=1499890)

### In other languages

  * [Deutsch](//de.wikibooks.org/wiki/Klettern)
  * [Polski](//pl.wikibooks.org/wiki/Wspinaczka)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Rock+Climbing%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Rock+Climbing%2FPrint+version&oldid=1499890&writer=rl)
  * [Printable version](/w/index.php?title=Rock_Climbing/Print_version&printable=yes)

  * This page was last modified on 14 May 2009, at 20:39.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Rock_Climbing/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
