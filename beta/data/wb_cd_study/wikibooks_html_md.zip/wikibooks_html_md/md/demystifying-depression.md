# Demystifying Depression/Print version

From Wikibooks, open books for an open world

< [Demystifying Depression](/wiki/Demystifying_Depression)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

  


![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Demystifying_Depression](/wiki/Demystifying_Depression)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Demystifying_Depression/Print_version&action=purge&printable=yes) this page.

# Table of contents[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=1)]

  1. Introduction
  2. What is Depression?
  3. Normal Neuron Communication: The Role of Serotonin
  4. The Stress System: Adrenaline and Cortisol
  5. The Buildup to a Depression
  6. Speculation on the Physiology of Depression
  7. The Recovery Process
  8. Recovery Guide
  9. General Lifestyle Advice
  10. Daily Routine
  11. Tips for Good Sleep
  12. The Controversy about Antidepressants
  13. Suicide
  14. The Role of Sports
  15. Feeling Good vs. Actual Improvement
  16. Why Moderate Exercise May Sometimes Help
  17. Caveats of Treating Depression with Exercise
  18. A Real World Example
  19. Depression and Ageing
  20. The Genetic Link
  21. Is Depression on the Rise?
  22. Quantifying Depression
  23. The Burnout Syndrome
  24. Happiness
  25. Facing the Prejudice
  26. Conclusion
  27. References
  28. List of Figures

  


# Introduction[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=2)]

Next page: [What Is Depression?](/wiki/Demystifying_Depression/What_Is_Depression), Previous page: [Demystifying Depression](/wiki/Demystifying_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Introduction[[edit](/w/index.php?title=Demystifying_Depression/Introduction&action=edit&section=T-1)]

In order to begin any explanation of the nature of depression, it is advisable to begin by establishing some common terms, distinctions, and popular definitions.  
_But most of all what must be stressed are the meanings and differences between them._  


The volume of misconceptions, stereotypes and prejudices that the vast majority of people have concerning the topic of depression in the medical sense is truly astounding.  


To begin, we must make a very clear distinction between Depression and Clinical/Bipolar Depression.  
_Colloquially, they are used indiscriminately._  


Anyone who has experienced Clinical/Bipolar Depression will tell you that the two are absolutely nothing alike.  


  * "**Depression**" (used in a non medico-legal sense) as the word is commonly used in day to day jargon refers to momentary bouts of the blues or melancholy. 

(and this meaning/understanding is not for any form of medico-legal related fields.)

    * Every human being experiences this from time to time, it is completely normal and after a little while without need of medical intervention you will be back to normal.
  * **Unipolar/Bipolar Depression** (using as in medico-legal sense) is not anything remotely similar to plain old "**Depression**."  


Clinical/Bipolar Depression is a medical condition as true as diabetes (DM Type-II) or cancer (e.g. breast cancer, testicular cancer etc.).

_"Normal" depression is psychological_ whereas _Clinical/Bipolar Depression is both psychological and physiological_, _it is well documented that drastic alterations occur in the brain as well as other changes occur in the rest of the body._

The importance of these distinctions is paramount (most important), you cannot gain an understanding of these conditions without it.

I will urge people who are reading this and who are fortunate not to have experienced clinical/bipolar depression, to keep this distinction clear in your minds while reading the rest of this book, any related material, and most of all when interacting with those who are diagnosed.

**Please pay Attention!**  
For the remainder of this document _for the sake of simplicity when the word "depression" is used it will refer to the medical condition of Clinical or Bipolar Depression_, and the term _"normal depression" will refer to the everyday non diagnosed human experience_.

Now that the most important distinction and definitions are out of the way lets establish some others.

There are two major types of medical depression

  1. Clinical Depression
  2. Bipolar Disorder

_Clinical Depression is an outdated term but is still commonly used. Similarly Bipolar Disorder(BD) was formerly referred to as Manic Depression, but Manic Depression is still widely used to refer to it._

The correct terms to use as accepted by the medical community are:  
**Major Depressive Disorder(MDD)** or **Unipolar Depression** instead of Clinical Depression, and **Bipolar disorder** instead of Manic Depression.

As I said before there are two major kinds of medical Depression, MDD and Bipolar Disorder.  
What's the Difference?

In a nut shell **Bipolar Disorder** is the same as **MDD** except that it has two alternating phases; Depression and Mania.

The experiences are usually the same symptoms that occur with MDD, except that they alternate with Manic Symptoms.

Without going into too much detail at the moment, for our purposes now just think of Mania as the opposite of Depression or an extremely good mood.  
_The phrase extreme highs and lows sums it up quite nicely for our purposes. We'll go into a little bit more detail about mania later but I don't want to leave you thinking the Mania is all fun and games. Even though you do have an elevated mood there are some very negative symptoms that also come along with Manic periods which will be explained latter._

While there are some documented differences between MDD and the depressive phase of Bipolar Disorder, for our understanding they are not relevant and will not be addressed in this book. Both MDD and Bipolar depression are more similar than not, have the same basic symptoms and are usually treated in a similar fashion. Unless otherwise specified when the term depression is used it refers to both Major Depressive Disorder and the Depressive phase of Bipolar Disorder.

If you've noticed I said that MDD and BP are the two major kinds of medical depression. There is another milder but still medically relevant form of depression known as **dystimia** which we'll touch upon briefly later.

Perhaps then some assume that:

Statistics point out that approximately one out of every six people will have a depression (with varying degrees of seriousness) at least once in their lifetime. The magnitude of this number is all the more shocking if one confronts it with the general ignorance about the problem. Even people well-informed about other health issues will often be caught totally by surprise by a depression. I know, I was one of them. Since our early school years we get tons of information about healthy eating, on the perils of smoking and heavy drinking, on avoiding sunburn, etc., etc. But mental health, largely because of the prejudice surrounding any kind of mental illness, is to a large extent ignored. This is more of a tragedy if one realises how far-reaching are the implications for a person's life and productivity, and most importantly, how depression could be avoided altogether if only people knew how to recognize the early symptoms.

As you read through this document, please always bear in mind that whenever the term _depression_ is used it refers specifically to the physical illness more properly described as _[clinical depression](//en.wikipedia.org/wiki/en:clinical_depression)_. One also finds the very same word _depression_ used in the context of other mental disorders (such as _[manic depression](//en.wikipedia.org/wiki/en:manic-depression)_ [[1]](http://www.nimh.nih.gov/publicat/bipolar.cfm)) of which this document does not cover. It is **very important** to keep this distinction in mind. As an example, consider the people who suffer from bouts of melancholy all through their lives. They often describe their subjective feeling as that of being _depressed_. However, when one takes a closer look at more objective indicators, they may not show the symptoms of a clinical depression. This document does not apply to them.

  
One of the enduring myths about clinical depression is that you can cure it simply by convincing a depressed person that life is good and worth living. Likewise, a depressed person will not be magically cured if all of their problems are suddenly solved. In fact, it was my experience (and that of many others) that the factors which contributed to the depression were long past and resolved. However, they had their physical toll in the brain, and that could not be suddenly undone.

Our misuse of language compounds the problem. All too often a perfectly healthy person (brain-wise, of course)will say that they feel depressed when really all they're experiencing is a passing case of the blues. It is far from my intention to dictate how people should use language, but this example illustrates my case. Curiously, one of the tell-tale symptoms of clinical depression is the inability to have strong emotions, including sadness and the blues.

Another important aspect to remember about depression is that it is not an on/off condition. There is a continuum between a perfectly healthy brain and one from a severely depressed person. I estimate that in modern society, those who could be classified as in perfect mental health are probably the minority. Moreover, just like physical fitness goes through ups and downs throughout a lifetime, the mental health of a typical individual will also fluctuate. It is only when the fluctuation dips significantly low for an extended period that the diagnosis of a depression is typically made. Elaborating further on this note, the good news is that a very large number of people who strictly speaking are not depressed and have largely satisfactory lives, could still feel better and happier if they took better care of their brains. The advice herein contained is also for them.

You may wonder why I have bothered to write such a lengthy description of depression if I advise people to seek professional help anyway. In a sense, you are asking for a _rationale_ for this document. Well, I would not have written it if I thought it was irrelevant, dangerous, or simply superfluous- Quite the contrary. I see good reasons that justify it, as follows.

  * The focus of the document is an objective description of clinical depression, explaining the physical illness which progressively takes its toll on the brain. If more people were aware of this fact, they would not be as complacent when the first symptoms appear. Moreover, they would feel less stigmatised and reluctant about seeking professional help.
  * By being better informed, people would realise the importance of seeking **competent** help. Many General Practitioners and even Psychologists are not properly informed about depression, and they can even inadvertently give their patients plenty of bad advice. Worst of all, the situation can worsen dramatically before the patient even realises what is wrong with the advice they are given. This happens frequently, believe it or not. The only solution is for people to be better informed and able to spot whether or not their GP is competent enough to treat them.
  * The enormous cost of health care in affluent societies often translates into health insurers pressuring for the cheaper solution of relying solely on antidepressants. In countries where the GP stands as the _gate-keeper_ for specialised treatment, people may find it difficult to convince their GP to send them to a specialist. The result is treatment based largely on medication, with little or no coaching.
  * Lifestyle plays a large role in the development of depression. Again, by better understanding the problem from an objective perspective, people will more easily assimilate the need to take good care of their sleep and to avoid overloading their brains.

The remainder of this instalment is structured as follows. I will begin by explaining what exactly is a depression and how the problem develops in the first place. Special attention will be given to a description of the most typical symptoms which accompany each stage of the illness. The next step is more personal: it describes the lifestyle changes I had to make to help my brain recover instead of sinking deeper into the illness.

## Medical Disclaimer[[edit](/w/index.php?title=Demystifying_Depression/Introduction&action=edit&section=T-2)]

Wikibooks contains books on many [medical topics](/wiki/Subject:Medicine); however, **no warranty whatsoever** is made that any of the books are accurate. There is absolutely no assurance that any statement contained or cited in a book touching on medical matters is true, correct, precise, or up-to-date. The overwhelming majority of such books are written, in part or in whole, by nonprofessionals. Even if a statement made about medicine is accurate, it may not apply to you or your symptoms.

The medical information provided on Wikibooks is, at best, of a general nature and cannot substitute for the advice of a **medical professional** (for instance, a qualified doctor/physician, nurse, pharmacist/chemist, and so on). **Wikibooks is not a doctor.**

None of the individual contributors, system operators, developers, sponsors of Wikibooks nor anyone else connected to Wikibooks can take any responsibility for the results or consequences of any attempt to use or adopt any of the information presented on this web site.

**Nothing on Wikibooks.org or included as part of any project of [Wikimedia Foundation](//en.wikipedia.org/wiki/Wikimedia_Foundation) Inc., should be construed as an attempt to offer or render a medical opinion or otherwise engage in the [practice of medicine](//en.wikipedia.org/wiki/medicine).**

Next page: [What Is Depression?](/wiki/Demystifying_Depression/What_Is_Depression), Previous page: [Demystifying Depression](/wiki/Demystifying_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# What Is Depression[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=3)]

Next page: [Normal Neuron Communication](/wiki/Demystifying_Depression/Normal_Neuron_Communication), Previous page: [Introduction](/wiki/Demystifying_Depression/Introduction), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## What is Depression?[[edit](/w/index.php?title=Demystifying_Depression/What_Is_Depression&action=edit&section=T-1)]

Depression is a very real medical condition that involves both psychological and biological factors. It is not simply something that is "in your head". Numerous studies have shown significant changes occur to the anatomy of the brain during the course of depression. Further Depression is a whole body illness not only affecting the brain. Those with depression experience a wide variety of physical and mental symptoms. Strong emphasis should be placed on the fact that depressed mood is only one symptom of many involved in an illness that encompasses many.

According to **World Health Organization (W.H.O)** Depression is a _common mental disorder_ that presents with **_depressed mood, loss of interest or pleasure, feelings of guilt or low self-worth, disturbed sleep or appetite, low energy, and poor concentration_**.

  
Next page: [Normal Neuron Communication](/wiki/Demystifying_Depression/Normal_Neuron_Communication), Previous page: [Introduction](/wiki/Demystifying_Depression/Introduction), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Normal Neuron Communication[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=4)]

Next page: [The Stress System](/wiki/Demystifying_Depression/The_Stress_System), Previous page: [What Is Depression?](/wiki/Demystifying_Depression/What_Is_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### Neuron Communication[[edit](/w/index.php?title=Demystifying_Depression/Normal_Neuron_Communication&action=edit&section=T-1)]

Communication between neurons relies on molecules called neurotransmitters. Without going into the details of this process, it suffices to say that for a neuron to transmit information to another neuron, it must release a neurotransmitter in the small gap between the two neurons, called a synapse.

More than 300 different neurotransmitters are known to be used in one role or another by the human brain. Three of them in particular, _serotonin_, _dopamine_, and, _norepinephrine_ have been identified as playing a major part in the physiology of clinical depression although others may also be important.

In a variety of clinical trials it has been shown that the use of drugs that mimic or affect how neurotransmitters are produced, destroyed, and moved in the brain can have verifiable effects on depression.

For example many popular anti-depressants are SSRIs. They decrease the amount of serotonin that neurons remove from synapses.

Although the effective use of these drugs shows that depression can be affected by physical changes in the Brain no one is sure exactly how these medication are effective.

Depression affects the area of the brain responsible among others for memory, learning, and tasks that require concentration and organisation [[2]](http://www.sciam.com/article.cfm?articleID=00083A00-318C-1F30-9AD380A84189F2D7).

Next page: [The Stress System](/wiki/Demystifying_Depression/The_Stress_System), Previous page: [What Is Depression?](/wiki/Demystifying_Depression/What_Is_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# The Stress System[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=5)]

Next page: [The Buildup to a Depression](/wiki/Demystifying_Depression/The_Buildup_to_a_Depression), Previous page: [Normal Neuron Communication](/wiki/Demystifying_Depression/Normal_Neuron_Communication), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### The Stress System: Adrenaline and Cortisol[[edit](/w/index.php?title=Demystifying_Depression/The_Stress_System&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikibooks/en/4/48/Demystifying_Depression-Stress_Compensation.png)

Figure 4: Chronic stress can diminish your maximum normal capacity.

  
The stress system relies on two key hormones: _adrenaline_ and _cortisol_. In short, adrenaline works in the short term, while cortisol has large momentum and works in the long term. (Adrenaline is also known as _epinephrine_ in North America. To be exact, the terms _noradrenaline_ and _norepinephrine_ are used to refer specifically to the neurotransmitter as opposed to the hormone, since they are different molecules. Moreover, there are many other neurotransmitters involved: check reference [[3]](http://www.sciam.com/article.cfm?articleID=00083A00-318C-1F30-9AD380A84189F2D7) for details. The purists will excuse my exclusive use of the word _adrenaline_ throughout the text).

It is important to realise that the stress system can also be activated if your brain perceives danger or any kind of threat. In the first stage, this triggers the release of adrenaline into the bloodstream to prepare the body for action. As a result, your heart beats faster, you begin to sweat, your breath becomes shallower, and your senses become more acute [[4]](http://en.wikipedia.org/wiki/Stress_%28medicine%29). This is the so-called _fight or flight_ response to the stressor event, and was quite adequate during most of our evolution, when these events were quite specific and usually short-term: escaping from a lion, chasing away a rival gang, or facing up to the impudent adolescent trying to woo your mate [[5]](http://en.wikipedia.org/wiki/Fight-or-flight_response). Problems with chronic stress arise because in a modern society we cannot escape easily from the stressor, be it an overbearing boss, crowded cities, or traffic jams. Furthermore, no matter how hard we try to delude ourselves with the pretence of civilisation, at heart we are still primates, and consequently, factors such as social status also play an important role as sources of stress. Moreover, primates have evolved the capacity to stress up the body in _anticipation_ of a possible danger [[6]](http://www.sciam.com/article.cfm?articleID=00083A00-318C-1F30-9AD380A84189F2D7). Again, this was an advantageous adaptation in the context where it evolved, but nothing but trouble for the modern human.

The effect of the stress hormones on the brain is curious and not what you might expect. The initial surge of adrenaline can make you feel good.

![](//upload.wikimedia.org/wikibooks/en/4/42/Demystifying_Depression-Cortisol.png)

Figure 2: The relationship between adrenaline and cortisol.

Just as your levels of adrenaline start coming down, so rises the amount of cortisol flowing through your veins. Moreover, cortisol has a much larger momentum than adrenaline, which means that even though it builds up slowly, it also takes a long time to go back to normal. And should you constantly be engaging in activities which require adrenaline, so will your levels of cortisol slowly increase. In a sense, you can think of cortisol as a measure of the weighted average of your recent levels of adrenaline. I have tried to capture this feature in Figure 2.

Together with the rise of cortisol and the decrease of adrenaline, come the nasty side-effects of the stress hormones. It is at this moment that you feel bad, anxious, and having lots of negative thoughts. And this is perhaps one of the critical features of stress which flies against common sense: you only feel its bad aspects when your body is _stressing down_ and progressing towards a more relaxed state. When you are building up on adrenaline, in effect _stressing up_, you might even be feeling good! This explains what is popularly known as the _adrenaline rush_ and the consequent _adrenaline crash_.

Having too much cortisol flowing through your veins has another nasty side-effect: the recovery time from any adrenaline surge increases. In a sense, the relation between adrenaline and cortisol goes both ways: the adrenaline curve influences the cortisol curve, and vice-versa. Figure 3 tries to capture this reaction effect by showing the adrenaline response curve for three individuals subjected to the same physical exercise. Notice how the more serious the depression (which translates into higher levels of cortisol, as you will soon understand), the longer it takes for the body to go back to normal.

![](//upload.wikimedia.org/wikibooks/en/f/fb/Demystifying_Depression-Adrenaline_Response.png)

Figure 3: The adrenaline response curve for various degrees of depression.

  


On the speculation front, recent findings may have implicated neuron death as the physical underpinning of depression. Furthermore, it seems that the opposite process, termed _neurogenesis_, is crucial for the recovery, and happens naturally in healthy individuals [3,6]. Furthermore, evidence indicates that sleep is fundamental for neurogenesis to take place.

Next page: [The Buildup to a Depression](/wiki/Demystifying_Depression/The_Buildup_to_a_Depression), Previous page: [Normal Neuron Communication](/wiki/Demystifying_Depression/Normal_Neuron_Communication), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# The Buildup to a Depression[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=6)]

Next page: [Speculation on the Physiology of Depression](/wiki/Demystifying_Depression/Speculation_on_the_Physiology_of_Depression), Previous page: [The Stress System](/wiki/Demystifying_Depression/The_Stress_System), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

![](//upload.wikimedia.org/wikibooks/en/e/ee/Demystifying_Depression-Buildup.png)

Figure 5: In the last stages of clinical depression, the maximum capacity is virtually nil, and the adrenaline (anxiety) transforms itself into a 'fire'.

At this stage you are in possession of all the ingredients necessary to understand how depression develops. The negative effect of the stress hormones on the maximum normal capacity is the key to comprehend the _buildup_ process that makes a depression feed on itself, like a [positive feedback](//en.wikipedia.org/wiki/en:positive_feedback) mechanism.

Let us go back to [Figure 4](/wiki/File:Demystifying_Depression-Stress_Compensation.png). Imagine that you would chronically go over your limits, thus forcing your body to constantly rely on the stress hormones to compensate for the lack of serotonin. On the long term, your maximum capacity would therefore be reduced, making it much more likely that you would have to resort to the stress system to compensate. And thus the feedback begins: your maximum capacity is diminished, forcing you to use the stress system all the time; and because of all the stress hormones flowing through your veins, your brain has no chance of recovering, and your maximum capacity diminishes even further.

This may sound very mechanical, but I would say that it is **the key element** that leads to the development of a full-blown clinical depression**.** Alas, it is also something that most doctors fail to realise. And if you are still clinging to "psychological" notions about the illness, it is time you put them into perspective. Psychology plays a role in the factors that lead to the initial dip of your work capacity, but after a certain stage the problem just feeds on itself, and it is crucial to understand that to avoid falling prey of this downward spiral.

Even though the graphs might give the impression that this is a phenomenon that happens very quickly, in reality the process typically takes many years to develop. Moreover, the progressive increase of the levels of stress hormones in your body provide a very good advance warning, if only you know how to read them. I will now provide a basic description of what to expect (and what to do!) at each stage of the process. Beware that different people have different symptoms, so your mileage may vary.

## Early stages[[edit](/w/index.php?title=Demystifying_Depression/The_Buildup_to_a_Depression&action=edit&section=T-1)]

In the very early stages, a depression will not feel like a depression at all. The small amounts of stress hormones could in theory be measured—your blood pressure would be slightly higher than otherwise—but in practise it would be difficult "to extract the signal from the noise". Subjectively, you might feel a bit down and tired, especially during those periods when you are _crashing down_ from the adrenaline, but most people would still not say that they feel depressed. Also, you would start sleeping a bit less than usual, and not feeling quite as fresh when you wake up.

The problem is not very serious yet, and I think that most people could recover on their own if they were to simply take a long holiday and to make sure that they sleep well. There is some evidence that **if done properly** moderate amounts of aerobic exercise might help at this stage. However, be sure to read [The Role of Sports](/wiki/Demystifying_Depression/The_Role_of_Sports) section before you decide to embark on any exercise routine. In fact, I would rather advise people not to begin exercising than to risk having them over do it and making their condition worse. I know this flies against some commonly held beliefs, but **sports alone can worsen a depression**. If you do not believe now, read carefully both installments of this document and you might understand what I mean.

What a great explanation of depression.

## Elevated stress hormones[[edit](/w/index.php?title=Demystifying_Depression/The_Buildup_to_a_Depression&action=edit&section=T-2)]

As the amount of stress hormones increases, you will start feeling some of their nasty side-effects. This is largely person-dependent, but most people start having problems with their digestive system, headaches, and having more frequent nightmares. Since stress depresses the immune system, people also tend to fall sick with infections more often [[7]](http://www.econ.uiuc.edu/~hanko/Bio/stress.html). Only a minority of people suffer from sleep paralysis [[8]](http://watarts.uwaterloo.ca/~acheyne/S_P.html), but it is also a good indicator of elevated stress hormones. An objective measure such as blood pressure should be controlled: it will definitely be higher than normal, and a good doctor would not fail to recognise it. At this stage you are very clearly sleeping less than normal, waking up early in the morning, feeling tired and "lazy" about getting up. Subjectively, you should notice that you do not feel things quite as intensively as you used to: you feel empty, morose, and definitely "depressed" most of the time. Other subjective indicators include loss of appetite and sex-drive, feelings of guilt, lowered self-esteem, and detachment from hobbies or friends [[9]](http://www.nimh.nih.gov/HealthInformation/Depressionmenu.cfm).

At this stage you should not be complacent about the problem. **The best thing** you can do is to go see your doctor**. Take also into consideration that you** have been putting too much pressure on your brain. Really do give it a rest: take a long holiday, make sure you sleep well, and be careful not to get any extra responsibilities. Antidepressants are very effective at this stage, especially if combined with minor lifestyle changes. **(And yet another reason why** you should see your doctor!)

## Problem aggravates[[edit](/w/index.php?title=Demystifying_Depression/The_Buildup_to_a_Depression&action=edit&section=T-3)]

As the _buildup_ towards a depression continues, you get to the point where it is impossible not to notice that there is something definitely wrong. At this point, most people start having serious problems with anxiety, stress, panic attacks, hyperventilation, bouts of psychosis, etc. Your sleep will definitely be a mess, your blood pressure will be high, and your ability to focus at work seriously compromised.

**One should definitely seek professional help at this stage**. In particular, do not make the assumption that your GP will be qualified to treat you. They may, or they may not. Unfortunately, many doctors still do not quite understand what is going on. My experience in this area was quite bad: I spent more than one year jumping from doctor to doctor, with the problem constantly aggravating, and getting all kinds of bad advice. In short, **you need to stop**. Your maximum capacity will probably be so low that you cannot even work full time. Also, specifically ask your doctor for antidepressants. In the country where I live, the Netherlands, this is bit of a taboo subject, so depending on where you live, you might need to convince your doctor not to be stingy and stubborn. Should they suggest that you start exercising, **just ignore that advice**. It is a very good indicator that they do not have a clue of what is going on. Also, you will need to make changes to your lifestyle. The [Recovery Guide](/wiki/Demystifying_Depression/Recovery_Guide) section describes one author's personal experience in that regard.

## Last stages[[edit](/w/index.php?title=Demystifying_Depression/The_Buildup_to_a_Depression&action=edit&section=T-4)]

In the last stages, the maximum capacity is practically nil, and the level of stress hormones so high that people cease to be able to function. The stage of a clinical depression is very difficult to describe in words, but I will do my best. The anxiety transforms itself into a "fire" which constantly burns inside your head; you will feel desperate, much more than you ever felt in your life, as if you could never be happy again; and you will definitely be suicidal, to the point of actually planning suicide or even attempting it (with success in many cases, tragically). During this stage, people can barely sleep, if at all.

To an outsider, the fact that a clinically depressed person is pretty much confined to bed is often misinterpreted. People often think that a clinical depression is a simply a state of apathy. Quite on the contrary: remember that the blood pressure and heart rate of a depressed person are extremely high. Rather than apathy, depression is an overwhelming fire which will not subside and burns you from the inside.

Unfortunately, it is only at this stage that many people finally concede that they need professional help to treat them. Needless to say, you will need to make drastic changes to your lifestyle if you want to recover. You should also be very patient: it will take a long time before things go back to normal. **Most important of all, a clinical psychiatrist is the proper** specialist to accompany you during this period.

Next page: [Speculation on the Physiology of Depression](/wiki/Demystifying_Depression/Speculation_on_the_Physiology_of_Depression), Previous page: [The Stress System](/wiki/Demystifying_Depression/The_Stress_System), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Speculation on the Physiology of Depression[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=7)]

Next page: [The Recovery Process](/wiki/Demystifying_Depression/The_Recovery_Process), Previous page: [The Buildup to a Depression](/wiki/Demystifying_Depression/The_Buildup_to_a_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### Speculation on the Physiology of Depression[[edit](/w/index.php?title=Demystifying_Depression/Speculation_on_the_Physiology_of_Depression&action=edit&section=T-1)]

Some interesting speculations about depression:

  * Neuron death in the hippocampus has been implicated in depression [[10]](http://www.futurepundit.com/archives/000477.html)
  * Neurogenesis (the birth of new neurons) may be necessary for recovery [[11]](http://www.americanscientist.org/template/AssetDetail/assetid/14738/page/4?&print=yes)
  * Neurogenesis happens continuously in the healthy adult brain
  * Most antidepressants require about 2-3 weeks to have an effect
  * Stress may diminish neurogenesis
  * People under stress may sleep less than usual
  * In some cases those recovering from depression sleep more than normal all though the opposite is true in some cases
  * Aging mimics several aspects of depression
  * As people age, they sleep less, spend less time in deep sleep, and wake up more often [[12]](http://helpguide.org/life/sleep_aging.htm)
  * **Neuron death and birth happens continuously in the adult brain**

At least certain parts of the brain continuously renew themselves. Sleep seems to be fundamental for this renewal process---perhaps neurogenesis happens during sleep.

  * **Stress affects sleep, and by consequence, neurogenesis**

There is plenty of speculation concerning the exact mechanism by which stress causes neuron death. Our own conjecture is based on the fact that when under stress, people sleep less than normal. Therefore, rather than directly killing neurons, stress might simply cause the brain to fall behind on its normal regenerative process.

  * **Increase in activity fundamental during recovery**

Some studies show how stimulating environments help with neurogenesis [[13]](http://www.americanscientist.org/template/AssetDetail/assetid/14738/page/4?&print=yes). The reason might be similar to recovery from an injured limb: one has to gradually _push the brain_ into continuing its recovery.

  
Next page: [The Recovery Process](/wiki/Demystifying_Depression/The_Recovery_Process), Previous page: [The Buildup to a Depression](/wiki/Demystifying_Depression/The_Buildup_to_a_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# The Recovery Process[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=8)]

Next page: [Recovery Guide](/wiki/Demystifying_Depression/Recovery_Guide), Previous page: [The Buildup to a Depression](/wiki/Demystifying_Depression/The_Buildup_to_a_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## The Recovery Process[[edit](/w/index.php?title=Demystifying_Depression/The_Recovery_Process&action=edit&section=T-1)]

Depending on your age, your general health status, how serious the depression was, and how well the recovery progresses, it typically takes between two months and two years before you can be fully recovered. Do not despair, however, because this certainly does not mean that during all this period you will feel as bad as in the beginning. The first few months are the hardest, but after that things will slowly improve, and little by little you will get your happiness and normality back. Moreover, remember that you only feel the nasty aspects of a depression when you go over your limits: you just have to be patient and to realise that your limits will indeed be very short during an extended period.

As the recovery progresses, you will feel not only that you can perform more concentration intensive activities and during longer periods, but also that your subjective mood improves. At some point you will be able to start working again, only for a couple of hours each day in the beginning, but increasingly more until you can work full time again. Finally, your mood should start approaching normality towards the later stages of the recovery: you should regain the feelings of _fullness_, vibrancy, and what is sometimes called the _elan vital_.

  
Next page: [Recovery Guide](/wiki/Demystifying_Depression/Recovery_Guide), Previous page: [The Buildup to a Depression](/wiki/Demystifying_Depression/The_Buildup_to_a_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Recovery Guide[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=9)]

Next page: [General Lifestyle Advice](/wiki/Demystifying_Depression/General_Lifestyle_Advice), Previous page: [The Recovery Process](/wiki/Demystifying_Depression/The_Recovery_Process), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Recovery Guide[[edit](/w/index.php?title=Demystifying_Depression/Recovery_Guide&action=edit&section=T-1)]

There are plenty of people with depression who are not being properly treated. Antidepressants revolutionized medicine's approach to the treatment of depression, and even though they are generally effective and an indispensable tool, sole reliance on drugs neglects valuable lifestyle advice. This is important consideration for those with all levels of depression.

The first step tried in recovering from depression should be telling someone and then getting help from a doctor if possible.

In order to recover from a depression, one must first understand the problem.

The following three sections cover the different aspects of the lifestyle changes. The first category deals with general advice which one should always have present. I The next section deals with the daily routine. Even though more flexible in nature, I quickly realized that there were good reasons behind my counselor's insistence that I followed its guidelines. At last, the third section focuses on tips for good sleep. These are by no means specific to a clinical depression.

Next page: [General Lifestyle Advice](/wiki/Demystifying_Depression/General_Lifestyle_Advice), Previous page: [The Recovery Process](/wiki/Demystifying_Depression/The_Recovery_Process), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# General Lifestyle Advice[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=10)]

Next page: [Daily Routine](/wiki/Demystifying_Depression/Daily_Routine), Previous page: [Recovery Guide](/wiki/Demystifying_Depression/Recovery_Guide), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### General Lifestyle Advice[[edit](/w/index.php?title=Demystifying_Depression/General_Lifestyle_Advice&action=edit&section=T-1)]

These are just the general tips that might help with depression. It might take a while to get used to them, but in time they will become second nature. Moreover, remember that depression is not an on/off condition: this same advice is also useful for healthy people who wish to remain that way. Obviously, a healthy person does not need to follow them very strictly, but they remain nevertheless good lifestyle advice.

  


  * **Try to avoid stress**

Stress may exasperate depression

  * **Exercise**
  * **Get Sunshine**
  * **Do things you enjoy**
  * **Practice relaxation exercises**

Yes, I am referring to stuff like meditation and yoga. They actually work, despite all the silly new-age nonsense that surrounds them. If you cannot stand the airy-fairy aspects, try to find a good expert who does not preach them.

Personally, I found that one of the most relaxing things you can do is to lie in the sunshine. This might not be an option if it is winter and/or you happen to live in a cold country, but if you can, do it as much as is safely possible. (But take into account the usual advice concerning the dangers of catching too much sun, obviously! Like in all things, moderation is the key).

**Make a conscious effort to do things with pleasure**

This could take a fair amount of brainwashing, but the idea is that before each activity, no matter how small, you think _I love doing this_ or _I order myself to feel good, right now_. For best results, say it loudly. Also, only do things when you really feel pleasure in doing them, and do them only for as long as that pleasure remains. Should you lose interest or feel tired, then stop.

**Take appropriate medication**

If your gut reaction is that antidepressants are evil, consider informing yourself properly. The truth is that modern drugs are quite effective and generally safe (I am referring in particular to SSRIs and more recent classes [[14]](http://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor)). They do have side-effects, but these are usually mild and quite bearable compared with the illness itself. For best results, have a clinical psychiatrist prescribe them to you: they are generally well informed of the different side-effects and can choose the drug best suited to your case. Also, remember that antidepressants usually require around three weeks before they have an effect. Three weeks are an eternity for someone with a depression, but do not stop taking them just because you do not see an immediate result.

Next page: [Daily Routine](/wiki/Demystifying_Depression/Daily_Routine), Previous page: [Recovery Guide](/wiki/Demystifying_Depression/Recovery_Guide), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Daily Routine[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=11)]

Next page: [Tips for Good Sleep](/wiki/Demystifying_Depression/Tips_for_Good_Sleep), Previous page: [General Lifestyle Advice](/wiki/Demystifying_Depression/General_Lifestyle_Advice), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### Daily Routine[[edit](/w/index.php?title=Demystifying_Depression/Daily_Routine&action=edit&section=T-1)]

I will now make a brief description of the typical daily routine. This advice assumes that the person is in a serious condition, but there are still a few good pointers to extract even for mildly depressed individuals. Also, as the condition improves, one does not need to be as rigorous as in the early stages.

  * **Take your time to do the morning activities**

You surely do not want to rev up your body immediately after waking up! Take your time to get up, to shower, to get dressed, and to breakfast. If it takes you less than one hour and a half to perform these activities, then you are doing them too quickly.

  * **Take a walk in the morning**

The idea is to have a _qualitative walk_. Pay attention to the colours around you, to the smells, the sounds, the shapes, the people, etc. This will help to diffuse your thoughts, and to avoid the obsessive thinking that accompanies depression. Also, since you must limit physical activity, walking every morning is important for your body to burn excess sugar. Walk for about half an hour, and do not forget: lie down for another half an hour afterwards! (Remember [Figure 3](/wiki/File:Demystifying_Depression-Adrenaline_Response.png): your body will take longer than usual to get back to normal).

  * **Find an activity that gives you pleasure**

Like gardening, painting, or bird-watching.

  * **Eat properly and avoid heavy meals**

Digestion is also quite demanding on your body, and therefore it is better to have more meals rather than bigger meals. Also, a depression is really a bad time to be thinking of diets. Eat well and make sure you get all your nutrients.

Some people also swear by the importance of drinking water regularly during the day. The rationale is that dehydration is a stress event, thus triggering the physiological reaction we aim to avoid.

  * **Have a _siesta_**

Even if you cannot sleep, it is important that you lie down for a while until your body is (relatively) rested. We all have a natural dip after lunch, and it is a pity that some modern societies have lost the _siesta_ habit.

Next page: [Tips for Good Sleep](/wiki/Demystifying_Depression/Tips_for_Good_Sleep), Previous page: [General Lifestyle Advice](/wiki/Demystifying_Depression/General_Lifestyle_Advice), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Tips for Good Sleep[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=12)]

Next page: [The Controversy about Antidepressants](/wiki/Demystifying_Depression/The_Controversy_about_Antidepressants), Previous page: [Daily Routine](/wiki/Demystifying_Depression/Daily_Routine), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### Tips for Good Sleep[[edit](/w/index.php?title=Demystifying_Depression/Tips_for_Good_Sleep&action=edit&section=T-1)]

To conclude, I will present just a few tips on how to get a good night's sleep. These are especially important during a depression, but again, they also apply to anyone.

  * **No activities before going to sleep**

You must avoid at all cost any adrenaline coming into your system before sleep time. Be especially careful of anything exciting or stressful. Yes, this includes most of television and even reading! Avoid also any physical exercise less than an hour before going to sleep. Always have in mind that a person with a depression will need longer than normal for the body to recover from any physical effort. Even healthy individuals should avoid doing sports at least a couple of hours before going to bed.

  * **Follow a steady sleep routine**

Try going to bed always at the same time everyday. We all know how working in shifts and jet-lag affect sleep: do not emulate them by going to bed at random times each day!

  * **Give your body time to crash down**

You cannot fall asleep while there is too much adrenaline running through your veins. It can take a while (even hours) before you crash down, and often people lie awake in bed waiting for sleep to come. The problem is that after a while it is very easy to start obsessing about not sleeping, which is a sure way of keeping yourself awake.

The idea is to only get ready for sleep once you have crashed down and feel tired. Before you actually get into bed, just lie there for a while (even with your clothes on), until you feel relaxed and tired.

  * **Go to bed early**

There are several reasons why this is a good practise: foremost to be able to wake naturally rather than with an alarm clock; but also to avoid being out of sync with the solar cycle, and to give your body time to crash down.

  * **Make your bedroom your sanctuary**

Do not have an office in the same room as where you sleep. Dedicate one room simply for sleeping, and make it as uncluttered as possible.

  * **Sleeping Medication**

Sleep is the most important part of your day. If all other methods and tips on how to get a good night's sleep fail; talk to your doctor about taking a low dose sleeping medication.

Next page: [The Controversy about Antidepressants](/wiki/Demystifying_Depression/The_Controversy_about_Antidepressants), Previous page: [Daily Routine](/wiki/Demystifying_Depression/Daily_Routine), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# The Controversy about Antidepressants[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=13)]

Next page: [Suicide](/wiki/Demystifying_Depression/Suicide), Previous page: [Tips for Good Sleep](/wiki/Demystifying_Depression/Tips_for_Good_Sleep), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## The Controversy about Antidepressants[[edit](/w/index.php?title=Demystifying_Depression/The_Controversy_about_Antidepressants&action=edit&section=T-1)]

This is largely country-dependent: in some countries their use is widespread and generates little discussion; in others, many factors contribute to making them practically taboo words. The country where I live, the Netherlands, tends towards the taboo end of the spectrum. The reason has a lot to do with the prevalent (and backwards if you ask me) Calvinist mentality. I know that in other places, such as most of North America and Southern Europe they are much more readily accepted. Your mileage may vary.

The controversy is typically framed in the following ways: doctors nowadays over-prescribe antidepressants, instead of following the psychotherapy route; antidepressants are just a ploy from the evil pharmaceutical multinationals; our societies are drifting towards a "Brave New World" scenario where drugs are used to keep the populace happy and unable to rebel. Well, my personal opinion is that there is some substance to some of these worries, but they are largely exaggerated and fail to acknowledge one very important fact: antidepressants are very effective in treating clinical depression. This is not a matter of opinion: it has been demonstrated in several double-blind clinical trials.

First, on the issue of over-prescription. I would say that they are both over-prescribed and under-prescribed. The problem is that most doctors do not understand depression well, and will prescribe drugs to people whose brains are healthy, and fail to provide them to people who could actually benefit from them. Take people who are mourning, for example. In most cases, these people do not have a depression. Grief is something perfectly normal, and its onset is all too sudden to cause a depression (remember that a depression typically takes _years_ to develop). Likewise, consider giving antidepressants to very young people: the brain of a child or even a teenager has such a fantastic ability to repair itself that it takes quite a pounding for a depression to develop. In these cases, antidepressants and all their unavoidable side effects are more likely to hurt than to help. On the other hand, there are people who have minor problems with stress and anxiety, or whose blood pressure is above normal for no apparent reason. They are often simply told that they should watch out for salt in their diets, or to take up yoga or meditation. This advice might help, but only to a certain degree. I suspect that a course of an antidepressant would have a stronger and more lasting effect.

Moving on to the subject of side-effects. Modern antidepressants are generally well-tolerated and safe to use. They do have side-effects, which depending on the drug and the person can be significant enough that people discontinue taking the medication. However, this is yet another issue where proper handling by a competent professional will make a huge difference. What one often finds is that people are given the wrong drug for their case. Imagine for example an overweight patient being given an antidepressant which increases appetite, or someone who has a satisfactory sex life and is given a drug which upsets their libido. What is required is matching the profile of the patient with the expected side-effects of the drug. Granted, there is plenty of variation among individuals, but the overall pattern is still strong enough that we can categorically say what will be the most likely side-effects of a given antidepressant. A straightforward discussion with a good professional will go a long way towards finding a drug tuned to your particular case, thus minimising the negative side-effects and decreasing the chances of premature discontinuation.

Finally on to the subject of psychotherapy. As someone who had a depression, I can assure you that there is nothing more patronising and irritating than people who bring up the "psychological help". A depressed person will definitely need professional help, but mostly for a proper explanation of the problem, to learn relaxation techniques, to know how to listen to their bodies, and to be coached in the lifestyle changes required for giving their brains a chance to recover. Once they are recovered, perhaps some therapy might be needed to make sure that whatever behavioural patterns which contributed to the development of the illness will not recur. However, and I cannot stress this enough, therapy is not a substitute for medication, and "psychological help" is a misunderstanding.

Next page: [Suicide](/wiki/Demystifying_Depression/Suicide), Previous page: [Tips for Good Sleep](/wiki/Demystifying_Depression/Tips_for_Good_Sleep), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Suicide[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=14)]

Next page: [The Role of Sports](/wiki/Demystifying_Depression/The_Role_of_Sports), Previous page: [The Controversy about Antidepressants](/wiki/Demystifying_Depression/The_Controversy_about_Antidepressants), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Suicide[[edit](/w/index.php?title=Demystifying_Depression/Suicide&action=edit&section=T-1)]

"Suicide is a permanent solution to a temporary problem". There is much wisdom to this sentence, and it is probably the best advice you can give a depressed person. Unfortunately, during that critical stage is difficult for them to visualise the temporary nature of the problem, and suicide is not uncommon. If you a have a friend or a loved one going through that stage of a depression, do take the possibility seriously and do what you can to prevent it from happening. In particular, make sure they are being handled by a competent professional. Fortunately, especially if people are young, this stage will not last very long, typically just a few days or weeks.

  
Next page: [The Role of Sports](/wiki/Demystifying_Depression/The_Role_of_Sports), Previous page: [The Controversy about Antidepressants](/wiki/Demystifying_Depression/The_Controversy_about_Antidepressants), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# The Role of Sports[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=15)]

Next page: [Feeling Good vs Actual Improvement](/wiki/Demystifying_Depression/Feeling_Good_vs_Actual_Improvement), Previous page: [Suicide](/wiki/Demystifying_Depression/Suicide), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## The Role of Sports[[edit](/w/index.php?title=Demystifying_Depression/The_Role_of_Sports&action=edit&section=T-1)]

The role played by sports and physical exercise in depression is far more complex than either the _sports good_ and _sports bad_ mantras would lead one to assume. Moreover, I would say that this is one area where our current understanding of depression is sorely incomplete. Consequently, beware that much of the material in this section is conjectural. I am well aware that most people's gut will be to dismiss my conjectures as pure rubbish, since "everyone knows that sports are good for you". A couple of years ago I would have whole-heartedly agreed with them, but I have learnt otherwise in the meantime. Furthermore, read carefully and you will see that I do not deny that sports can be good for you. I simply add a poignant _however_ to the issue of sports and depression.

This issue is complex enough to warrant a number of subsections. I will first make a distinction between the temporary improvement of mood brought by sports, versus the long-term actual improvement of the depression. Second, I will put forth the tentative mechanism of why moderate amounts of exercise can help to recover from depression. Third, I will describe the caveats of doing exercise to recover from a depression. At last, I will describe a real-world example of how sports can be used to make people be more active during a depression, with the drawback that recovery takes longer.

Sports or exercise is challenging for people experiencing depression primarily because of the engagement of mind, body and spirit. For example, persons depressed as a result of sexual trauma have spent an unknown length of time separated intellectually from their body(ies). One exercise that allows for a kind of autonomy while truly strengthening the body and connecting mind and body is lap swimming. Here an individual can focus on breathing as one would while engaged in meditation. There are also various kinds of disguises involved in swimming starting with swim goggles. The combination of the "mask" and the single swim lane results in a safe environment.

Swimming requires regular participation. The outcomes (for me) are still being recognized, but the main effort to connect or to reconnect the mind and the body through a concentrated routine of swimming for exercise are being realized.

Next page: [Feeling Good vs Actual Improvement](/wiki/Demystifying_Depression/Feeling_Good_vs_Actual_Improvement), Previous page: [Suicide](/wiki/Demystifying_Depression/Suicide), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Feeling Good vs Actual Improvement[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=16)]

Next page: [Why Moderate Exercise May Sometimes Help](/wiki/Demystifying_Depression/Why_Moderate_Exercise_May_Sometimes_Help), Previous page: [The Role of Sports](/wiki/Demystifying_Depression/The_Role_of_Sports), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### Feeling Good vs. Actual Improvement[[edit](/w/index.php?title=Demystifying_Depression/Feeling_Good_vs_Actual_Improvement&action=edit&section=T-1)]

_Sports alone can lift up a depression_, says one of the most common pieces of advice about the illness. Unfortunately, this statement is grossly incomplete, often tragically so. If you have properly understood the roles played by adrenaline and cortisol (take a look again at the section on [The Stress System](/wiki/Demystifying_Depression/The_Stress_System) to refresh your memory), you already have a glimpse of why this is such misleading advice. Exercise can indeed momentarily _lift up_ the subjective feeling of a depressed person, but that is all caused by adrenaline. It is therefore critical to make the distinction between the momentary mood improvement caused by exercise (which is undisputed), and whether it translates into an actual improvement of the underlying depression.

Please refer back to [The Stress System](/wiki/Demystifying_Depression/The_Stress_System). There I have speculated on recent findings which indicate that a process known as _neurogenesis_ ("neuron birth") is implicated in recovery from depression. This process takes about three weeks to occur*, which also happens to be the average time required for antidepressants to have an effect. This coincidence has led some to hypothesise that antidepressants work by stimulating neurogenesis [[15]](http://www.biopsychiatry.com/newbraincell/). The point of this digression is to emphasise that anything which has a positive effect on recovery from depression is likely to require at least three weeks to work and will often take longer to be noticeable. One should therefore be a bit suspicious of any cure which seems to work instantly, as is the case of exercise.

Now the question is: does exercise also have a long-term positive effect on depression, or is it all a short-term illusion?

Next page: [Why Moderate Exercise May Sometimes Help](/wiki/Demystifying_Depression/Why_Moderate_Exercise_May_Sometimes_Help), Previous page: [The Role of Sports](/wiki/Demystifying_Depression/The_Role_of_Sports), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Why Moderate Exercise May Sometimes Help[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=17)]

Next page: [Caveats of Treating Depression with Exercise](/wiki/Demystifying_Depression/Caveats_of_Treating_Depression_with_Exercise), Previous page: [Feeling Good vs Actual Improvement](/wiki/Demystifying_Depression/Feeling_Good_vs_Actual_Improvement), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### Why Moderate Exercise May Sometimes Help[[edit](/w/index.php?title=Demystifying_Depression/Why_Moderate_Exercise_May_Sometimes_Help&action=edit&section=T-1)]

A **moderate** amounts of aerobic exercise seem to help many depressed and healthy individuals.

  
At last, a word of advice. **If you think you have a depression, you should seek professional** help**. It might be tempting for some people to try to exercise their way out of a depression,** but chances are you might actually be making your condition worse. See next section for details.

Next page: [Caveats of Treating Depression with Exercise](/wiki/Demystifying_Depression/Caveats_of_Treating_Depression_with_Exercise), Previous page: [Feeling Good vs Actual Improvement](/wiki/Demystifying_Depression/Feeling_Good_vs_Actual_Improvement), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Caveats of Treating Depression with Exercise[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=18)]

Next page: [A Real World Example](/wiki/Demystifying_Depression/A_Real_World_Example), Previous page: [Why Moderate Exercise May Sometimes Help](/wiki/Demystifying_Depression/Why_Moderate_Exercise_May_Sometimes_Help), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### Caveats of Treating Depression with Exercise[[edit](/w/index.php?title=Demystifying_Depression/Caveats_of_Treating_Depression_with_Exercise&action=edit&section=T-1)]

Looking back on [Figure 2](/wiki/File:Demystifying_Depression-Cortisol.png) from [The Stress System](/wiki/Demystifying_Depression/The_Stress_System), some people might suggest that a person with a severe depression could avoid the _crashing down_ simply by exercising every single day. In a sense, as soon as your body begins to crash, you simply do more exercise to rev it up again. You could therefore reap the positive temporary effects of exercise, and hopefully avoid the negative side. This routine "sort of" works, but is also extremely dangerous, as I will proceed to explain.

The major problem is that having too many stress hormones flowing through veins has a negative effect on sleep. And sleep is crucial for recovery. So people with more severe depressions who exercise every day will not sleep as much as they should, and the recovery will therefore take longer (see [next section](/wiki/Demystifying_Depression/A_Real_World_Example) for a real world example). More seriously, if the amount of exercise is too high, they might even regress. Even more seriously, if the underlying depression worsens, people might be tempted to increase the amount of exercise to compensate, which will quickly lead them into a very dangerous downwards spiral. In a sense, advising a seriously depressed person to exercise is like telling a drunken individual that the best way to avoid a hangover is to keep drinking; or advising a heroin addict that the best way to avoid the withdrawal symptoms is to keep injecting the drug.

This is unfortunately not widely known, but even healthy individuals who exercise too much can develop the symptoms of a depression. This is sometimes referred to as the _athletic overtraining syndrome_ [[16]](http://watarts.uwaterloo.ca/~acheyne/S_P.html), and by now you should have understood the basic mechanism of why it arises.

Next page: [A Real World Example](/wiki/Demystifying_Depression/A_Real_World_Example), Previous page: [Why Moderate Exercise May Sometimes Help](/wiki/Demystifying_Depression/Why_Moderate_Exercise_May_Sometimes_Help), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# A Real World Example[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=19)]

Next page: [Depression and Ageing](/wiki/Demystifying_Depression/Depression_and_Ageing), Previous page: [Caveats of Treating Depression with Exercise](/wiki/Demystifying_Depression/Caveats_of_Treating_Depression_with_Exercise), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

### A Real World Example[[edit](/w/index.php?title=Demystifying_Depression/A_Real_World_Example&action=edit&section=T-1)]

At last I will provide you a real world example which illustrates the caveats of doing sports during depression. Some companies here in the Netherlands rely on a sports-intensive routine to put people back to work sooner. In basic terms, the routine involves running every single morning for a period between one hour and one hour and a half. The running is performed under controlled conditions, to prevent the heart rate from ever going over 130 beats per minute. If you understood the role of sports in depression, you will also realise just how this scheme works: it basically gets their brains running on adrenaline. This is not entirely harmless, as during the recovery period the people will have elevated heart rate and stress hormones flowing through their veins. Also, with all that adrenaline in their systems, they will not sleep as much as they could, which makes a full recovery last much longer, _up to three years_. The advantage of this scheme? Well, they do begin working (part-time of course) much sooner than otherwise.

At this point you might be wondering how they do not realise what is really happening. Remember that adrenaline is an insidious hormone, which makes one feel good even as it revs up the body, and this scheme requires them to exercise _every single day without exception_. Obviously, the idea is to keep them from crashing down from all that adrenaline, and therefore to prevent them from realising their true status. Also, there is widespread ignorance about depression among Dutch GPs, which makes it all the more unlikely that someone will realise that there is something fishy going on. Personally, I find this scheme to be utterly mad. But then, I am not a Calvinist.

Should you be thinking that this scheme is also a perfectly viable alternative way of curing a depression—one which takes longer, is potentially harmful to the general health, **but** does allow one to become active sooner rather than later—I would even be tempted to agree with you. **However**, I still think that the ultimate choice should reside with each individual person. It is their health we are talking about, after all. These people should be properly informed of all possible alternatives and the implications of each one. This is currently not happening.

Next page: [Depression and Ageing](/wiki/Demystifying_Depression/Depression_and_Ageing), Previous page: [Caveats of Treating Depression with Exercise](/wiki/Demystifying_Depression/Caveats_of_Treating_Depression_with_Exercise), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Depression and Ageing[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=20)]

Next page: [The Genetic Link](/wiki/Demystifying_Depression/The_Genetic_Link), Previous page: [A Real World Example](/wiki/Demystifying_Depression/A_Real_World_Example), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Depression and Ageing[[edit](/w/index.php?title=Demystifying_Depression/Depression_and_Ageing&action=edit&section=T-1)]

You do not see 60-year olds having the same lifestyle as 20-year olds. Even a 40 or a 30-year old probably would not be able to accommodate for a long time all the intense living and partying of their youth. We naturally accept that our physical abilities decrease slowly with age, and our brains are no different. Mind you, in this context I will speak only of the brain's endurance, not of the general cognitive abilities. Therefore, do not interpret the graph in Figure 9 as "getting dumber with age". (Though it is most likely that cognitive abilities also decrease with age. Luckily, the added experience can in large part compensate for that).

  


![](//upload.wikimedia.org/wikibooks/en/1/10/Demystifying_Depression-Ageing.png)

Figure 9: The maximum normal capacity naturally decreases with age.

  
Bear in mind that I am largely speculating here, but I would not be surprised if the reason why depression tends to strike first towards the mid 20s (and this is a fact) is related to a dip in the maximum normal capacity which happens after adolescence. Many people simply fail to accommodate for the necessary changes in their lifestyle, and thus find themselves constantly going over their (now slightly diminished) limits.

Still on the speculation front, consider the fact that people tend to sleep less as they get older. Could it be related with the graph in Figure 9? If sleep is indeed fundamental for the brain to repair itself, and if age cuts down the requirements for the maximum normal capacity, it is not too far-fetched to imagine that people would therefore require less sleep as they get older.

Speculations aside, do not look with gloom at the graph. Ageing is not a death sentence as far as feeling well is concerned. People do generally accommodate by making changes to their lifestyle, and remember that depression only arises should you constantly go over your limits. Furthermore, in percentage terms, the natural decrease might not even be large. (Unfortunately, our current understanding of depression does not yet allow us to make precise quantifications. See the section [Quantifying Depression](/wiki/Demystifying_Depression/Quantifying_Depression) for details).

Next page: [The Genetic Link](/wiki/Demystifying_Depression/The_Genetic_Link), Previous page: [A Real World Example](/wiki/Demystifying_Depression/A_Real_World_Example), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# The Genetic Link[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=21)]

Next page: [Is Depression on the Rise?](/wiki/Demystifying_Depression/Is_Depression_on_the_Rise), Previous page: [Depression and Ageing](/wiki/Demystifying_Depression/Depression_and_Ageing), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## The Genetic Link[[edit](/w/index.php?title=Demystifying_Depression/The_Genetic_Link&action=edit&section=T-1)]

I have not brought up the genetic link up till now, but it is without doubt one of the primary risk factors. Depression seems to run in families, and even after the environmental effects are taken into account, the genetic link is still clearly there [[17]](http://www.sciam.com/article.cfm?articleID=00083A00-318C-1F30-9AD380A84189F2D7). Some studies have shown that approximately one out of every three people have a genetic predisposition to develop a depression. However, like in many other cases, the interplay between genes and environment is also relevant for depression: only about half of those with the genetic predisposition will actually develop the illness. In any case, should you have cases of depression among close blood relatives, do take it as a warning that you too might be at risk.

**Note:** A person is most closely related to their siblings, their parents, and their children. In either case, you share with them approximately 50% of your genes (for which there is variance among the breeding population). Grandparents, grandchildren, aunts, uncles, nephews, and nieces are next: the shared portion is approximately 25%. In these cases, the conditional probability of having a depression knowing that your relative had a depression is higher than the above mentioned absolute probability of about one third. For relatives farther beyond the genetic proximity measure (cousins, etc.), the conditional probability approaches the absolute probability for the general population, and is therefore not quite as relevant as an indicator.

Next page: [Is Depression on the Rise?](/wiki/Demystifying_Depression/Is_Depression_on_the_Rise), Previous page: [Depression and Ageing](/wiki/Demystifying_Depression/Depression_and_Ageing), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Is Depression on the Rise[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=22)]

Next page: [Quantifying Depression](/wiki/Demystifying_Depression/Quantifying_Depression), Previous page: [The Genetic Link](/wiki/Demystifying_Depression/The_Genetic_Link), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Is Depression on the Rise?[[edit](/w/index.php?title=Demystifying_Depression/Is_Depression_on_the_Rise&action=edit&section=T-1)]

Is the incidence of depression really on the rise? Statistics seem to point that way [[18]](http://en.wikipedia.org/wiki/Clinical_depression), and considering the risk factors, that should not be altogether surprising. The truth is that many modern hobbies are actually very demanding on the brain. Should a person pull long hours at work and then come home to face an equally demanding hobby, there is a very good chance that they are pushing the brain past its limit.

This is likely to strike a chord with the Kuro5hin crowd: surfing the web and blogging should be seen as work as far as the brain is concerned. In a similar note, _information overload_ is not just a fancy buzzword: it is a factor contributing to the development of depression. The list is long: mobile phones, news tickers, instant messaging, etc. We seem to be very good at devising ways to overload our brains.

On a more positive note, if one considers the current understanding of the problem, plus the available means to treat it, making serious clinical depression a thing of the past is well within our reach. What is required? Just getting the message across! Sadly, it may prove difficult to overcome centuries of prejudice surrounding mental illness.

Next page: [Quantifying Depression](/wiki/Demystifying_Depression/Quantifying_Depression), Previous page: [The Genetic Link](/wiki/Demystifying_Depression/The_Genetic_Link), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Quantifying Depression[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=23)]

Next page: [The Burnout Syndrome](/wiki/Demystifying_Depression/The_Burnout_Syndrome), Previous page: [Is Depression on the Rise?](/wiki/Demystifying_Depression/Is_Depression_on_the_Rise), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Quantifying Depression[[edit](/w/index.php?title=Demystifying_Depression/Quantifying_Depression&action=edit&section=T-1)]

You will certainly have noticed the lack of scale in all the graphs herein shown. The truth is that research into depression has not yet reached the quantification stage. This is a pity, as much of the prejudice (especially in getting official recognition for the problem) could be avoided if there were tests which could estimate the seriousness of a depression. Which is not to say that such tests are not possible. In fact, in this section I intend to propose the means by which they could be developed.

At this point you might be thinking that blood pressure already provides a fine estimation. This is only partially true. Foremost, several factors other than stress levels have an effect on blood pressure. Furthermore, blood pressure is a static measure, unable to differentiate between the state of _deep depression / low activity_ and the state of _mild depression / high activity_. This is an especially crucial distinction in the recovery phase of a depression. (Blood pressure is more reliable during the buildup phase towards a depression precisely because the activity variable tends to be always high, as people struggle to maintain a normal lifestyle).

My suggested test also relies on blood pressure, but adds a dynamic measure of that variable. In short, the idea is to build a graph showing how blood pressure progresses with time as the test subject performs a high-concentration activity. Figure 10 shows what one would be likely to expect from a healthy individual, a mildly depressed one, and one more deeply depressed.

  


![](//upload.wikimedia.org/wikibooks/en/4/44/Demystifying_Depression-Quantification_Test.png)

Figure 10: The blood pressure response curve for three individuals with varying degrees of a depression.

  
Note that a depressed individual will typically not only have a higher blood pressure at rest, but more importantly, a steeper response curve. This could be the basis for developing an objective test of the seriousness of a depression. It would also be extremely valuable for tracking the progress of the illness.

The test activity is an open question. I would suggest a test which would require both high concentration and short-term memory. In my personal experience, I noticed that the simple game _Concentration_ (the one where you are supposed to pick pairs of cards out of a large set of unturned cards [[19]](http://en.wikipedia.org/wiki/Concentration_%28game%29)) provokes an almost immediate response. It might be a good candidate for the test.

Obviously, there is a fair amount of noise which makes a precise measurement harder. How well the test subject slept the night before is one variable hard to control. Likewise for the degree to which they are enjoying the activity. Furthermore, other variables such as current medication and time of day would also interfere.

Another advantage of an objective test would be an estimation of how much time would be required until the test subject could be considered cured. I realise that there are several factors interfering with the progress of the illness, but given a large population of test subjects, one could compensate for factors such as age. It is only a matter of statistics, after all. In any case, a rough estimation is a lot better than no estimation at all.

At last, one small note of hope: there is research underway which uses imaging techniques such as fMRI to look directly into the brain and see the changes caused by depression [[20]](http://en.wikipedia.org/wiki/FMRI). Unfortunately, it might take quite a long time before such research is put into practical use. The test I proposed is low-tech, potentially a lot cheaper, and could be developed immediately.

Next page: [The Burnout Syndrome](/wiki/Demystifying_Depression/The_Burnout_Syndrome), Previous page: [Is Depression on the Rise?](/wiki/Demystifying_Depression/Is_Depression_on_the_Rise), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# The Burnout Syndrome[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=24)]

Next page: [Happiness](/wiki/Demystifying_Depression/Happiness), Previous page: [Quantifying Depression](/wiki/Demystifying_Depression/Quantifying_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## The Burnout Syndrome[[edit](/w/index.php?title=Demystifying_Depression/The_Burnout_Syndrome&action=edit&section=T-1)]

There is much talk (at least in the Netherlands) about the so-called _burnout syndrome_. And as is often the case, there is more noise than signal in this discussion. First of all, in medical terms, there is no such thing as a burnout. There are depressions, period. A _burnout_ is just a depression whose causes are mostly work-related. Remember that the person's attitude towards the task at hand plays an important role in the biochemistry of the brain. Should you have a job that you find boring and repetitive, or should the surrounding circumstances (overbearing boss, bad corridor atmosphere) make you feel uncomfortable about going to work every day, a depression is likely to develop.

Second, when a person is said to be _burned out_, what they have is a lingering depression from which they have not yet fully recovered. Also, there are plenty of mildly _burned out_ individuals who have never received any kind of treatment. They often drone through life for years before the problem is diagnosed.

I made a section out of this issue precisely because the general attitude in this country is to dismiss _burnout_ as just a psychological problem, thus being handled with a lot of complacency, or just ignored. This is all the more tragic if one considers the statistics which show the Netherlands to have some of the highest percentages of people affected by this problem. There is indisputably also a psychological component to _burnout_, but it goes far deeper than that.

Next page: [Happiness](/wiki/Demystifying_Depression/Happiness), Previous page: [Quantifying Depression](/wiki/Demystifying_Depression/Quantifying_Depression), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Happiness[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=25)]

Next page: [Facing the Prejudice](/wiki/Demystifying_Depression/Facing_the_Prejudice), Previous page: [The Burnout Syndrome](/wiki/Demystifying_Depression/The_Burnout_Syndrome), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Happiness[[edit](/w/index.php?title=Demystifying_Depression/Happiness&action=edit&section=T-1)]

Next page: [Facing the Prejudice](/wiki/Demystifying_Depression/Facing_the_Prejudice), Previous page: [The Burnout Syndrome](/wiki/Demystifying_Depression/The_Burnout_Syndrome), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Facing the Prejudice[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=26)]

Next page: [Conclusion](/wiki/Demystifying_Depression/Conclusion), Previous page: [Happiness](/wiki/Demystifying_Depression/Happiness), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Facing the Prejudice[[edit](/w/index.php?title=Demystifying_Depression/Facing_the_Prejudice&action=edit&section=T-1)]

Most of the advice contained in both instalments of this document is based on one very important assumption: society will give you the means to recover. Unfortunately, this is still far from being the case. A seriously depressed person **cannot** constantly go over their limits if their brains are to be given any chance of recovering. Take the practical example of restarting work: one has to build up the activity slowly, in accordance with the increase of the maximum capacity of the brain (remember [Figure 6](/wiki/File:Demystifying_Depression-Recovery.png) from [The Recovery Process](/wiki/Demystifying_Depression/The_Recovery_Process)). Obviously, this requires some sort of official recognition of the particularities of depression. In theory, this is part of the law and recognised in most civilised countries. In practise, things can be very different.

Do not assume that because you live in an otherwise tolerant and socially-minded society, depression will also be well understood. Bear in mind that other factors come into play, most importantly the fact that cure takes **a long time**, which means it is also very expensive for an employer. Also, the overall stance towards mental illness might be biased by the prevailing religious substrate, influencing attitudes even of non-religious people: take the example of Calvinism here in the Netherlands. All in all, when depression is the subject, do not be surprised when society shows its ugly side. The good old advice of stashing away some six-months worth of salary for a rainy day is very much applicable in the case of depression: you will need it.

Interestingly enough, I see no reason—other than prejudice and bad will—why the state of affairs should remain like this. Take again a look at the section on [Quantifying Depression](/wiki/Demystifying_Depression/Quantifying_Depression): it is well within our means to devise reliable objective tests to assess the seriousness of a depression and/or to determine when a person is again fit enough to work. Depression itself provides more than enough misery. It is inhumane and cruel that the problem should be compounded by lack of recognition.

Next page: [Conclusion](/wiki/Demystifying_Depression/Conclusion), Previous page: [Happiness](/wiki/Demystifying_Depression/Happiness), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# Conclusion[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=27)]

Next page: [References](/wiki/Demystifying_Depression/References), Previous page: [Facing the Prejudice](/wiki/Demystifying_Depression/Facing_the_Prejudice), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## Conclusion[[edit](/w/index.php?title=Demystifying_Depression/Conclusion&action=edit&section=T-1)]

The moral of the story is fairly straightforward: depression is a physical illness which should be taken seriously and be treated as soon as the first symptoms arise. Like most other ailments, it feeds on ignorance and complacency, which is all the more tragic if one considers that we have the medical knowledge and the means to make it a thing of the past. Humanity has been tormented too much already.

Next page: [References](/wiki/Demystifying_Depression/References), Previous page: [Facing the Prejudice](/wiki/Demystifying_Depression/Facing_the_Prejudice), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# References[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=28)]

Next page: [List of Figures](/wiki/Demystifying_Depression/List_of_Figures), Previous page: [Conclusion](/wiki/Demystifying_Depression/Conclusion), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

## References[[edit](/w/index.php?title=Demystifying_Depression/References&action=edit&section=T-1)]

  1. [Wikipedia: Dualism (philosophy of mind)](http://en.wikipedia.org/wiki/Dualism_%28philosophy_of_mind%29)
  2. [Wikipedia: Cirrhosis](http://en.wikipedia.org/wiki/Cirrhosis)
  3. [Taming Stress](http://www.sciam.com/article.cfm?articleID=00083A00-318C-1F30-9AD380A84189F2D7)
  4. [Wikipedia: Stress (medicine)](http://en.wikipedia.org/wiki/Stress_%28medicine%29)
  5. [Wikipedia: Fight-or-flight response](http://en.wikipedia.org/wiki/Fight-or-flight_response)
  6. [Neurogenesis in the Human Brain: Fact or fiction?](http://serendip.brynmawr.edu/bb/neuro/neuro00/web1/Wall.html)
  7. [Stress and the Immune System](http://www.econ.uiuc.edu/~hanko/Bio/stress.html)
  8. [Sleep Paralysis Page](http://watarts.uwaterloo.ca/~acheyne/S_P.html)
  9. [NIMH: Depression](http://www.nimh.nih.gov/HealthInformation/Depressionmenu.cfm)
  10. [Wikipedia: Selective serotonin reuptake inhibitor](http://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor)
  11. [NIMH: Bipolar Disorder](http://www.nimh.nih.gov/publicat/bipolar.cfm)
  12. [Why? The Neuroscience of Suicide](http://www.sciam.com/article.cfm?articleID=0006AF90-5BC7-1E1B-8B3B809EC588EEDF)
  13. [Nietzsche's Toxicology](http://www.sciam.com/print_version.cfm?articleID=00019A70-0C1C-1F41-B0B980A841890000)
  14. [Wikipedia: Clinical depression](http://en.wikipedia.org/wiki/Clinical_depression)
  15. [Wikipedia: Concentration (game)](http://en.wikipedia.org/wiki/Concentration_%28game%29)
  16. [Wikipedia: Functional magnetic resonance imaging](http://en.wikipedia.org/wiki/FMRI)
  17. [Depression and the Birth and Death of Brain Cells](http://www.biopsychiatry.com/newbraincell/)
  18. [Overtraining](http://www.physsportsmed.com/issues/2001/05_01/uusitalo.htm)

Next page: [List of Figures](/wiki/Demystifying_Depression/List_of_Figures), Previous page: [Conclusion](/wiki/Demystifying_Depression/Conclusion), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

# List of Figures[[edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit&section=29)]

Next page: none, Previous page: [References](/wiki/Demystifying_Depression/References), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

![](//upload.wikimedia.org/wikibooks/en/3/35/Demystifying_Depression-Maximum_Capacity.png)

Figure 1: The progression of an individual's _maximum normal capacity_ (in effect how large is the supply of serotonin), and the _actual used capacity_ (how much serotonin is effectively used), during the course of an extended period. Notice that there moments when the demand is higher, perhaps because of extra work, but that the maximum capacity was never breached.

![](//upload.wikimedia.org/wikibooks/en/4/42/Demystifying_Depression-Cortisol.png)

Figure 2: The relationship between adrenaline and cortisol.

![](//upload.wikimedia.org/wikibooks/en/f/fb/Demystifying_Depression-Adrenaline_Response.png)

Figure 3: The adrenaline response curve for various degrees of depression.

![](//upload.wikimedia.org/wikibooks/en/4/48/Demystifying_Depression-Stress_Compensation.png)

Figure 4: Chronic stress can diminish your maximum normal capacity.

![](//upload.wikimedia.org/wikibooks/en/e/ee/Demystifying_Depression-Buildup.png)

Figure 5: In the last stages of clinical depression, the maximum capacity is virtually nil, and the adrenaline (anxiety) transforms itself into a 'fire'.

![](//upload.wikimedia.org/wikibooks/en/e/e3/Demystifying_Depression-Recovery.png)

Figure 6: The relationship between daily activity and normal capacity in recovery.

![](//upload.wikimedia.org/wikibooks/en/e/ec/Demystifying_Depression-Hormesis.png)

Figure 7: The hormetic response curve. Note how small amounts of the stressor event have a positive effect, but which decreases rapidly as the amount increases. Large amounts will actually have a negative effect on the body. (The stressor event can be exercise, radiation, or any other agent for which there is a hormetic response).

![](//upload.wikimedia.org/wikibooks/en/d/da/Demystifying_Depression-Exercise.png)

Figure 8: The hormetic response curve for a severely depressed individual and for a healthy one.

![](//upload.wikimedia.org/wikibooks/en/1/10/Demystifying_Depression-Ageing.png)

Figure 9: The maximum normal capacity naturally decreases with age.

![](//upload.wikimedia.org/wikibooks/en/4/44/Demystifying_Depression-Quantification_Test.png)

Figure 10: The blood pressure response curve for three individuals with varying degrees of a depression.

Next page: none, Previous page: [References](/wiki/Demystifying_Depression/References), Top: [Demystifying Depression](/wiki/Demystifying_Depression)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Demystifying_Depression/Print_version&oldid=2502703](http://en.wikibooks.org/w/index.php?title=Demystifying_Depression/Print_version&oldid=2502703)" 

[Category](/wiki/Special:Categories): 

  * [Demystifying Depression](/wiki/Category:Demystifying_Depression)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Demystifying+Depression%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Demystifying+Depression%2FPrint+version)

### Namespaces

  * [Book](/wiki/Demystifying_Depression/Print_version)
  * [Discussion](/w/index.php?title=Talk:Demystifying_Depression/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Demystifying_Depression/Print_version)
  * [Edit](/w/index.php?title=Demystifying_Depression/Print_version&action=edit)
  * [View history](/w/index.php?title=Demystifying_Depression/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Demystifying_Depression/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Demystifying_Depression/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Demystifying_Depression/Print_version&oldid=2502703)
  * [Page information](/w/index.php?title=Demystifying_Depression/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Demystifying_Depression%2FPrint_version&id=2502703)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Demystifying+Depression%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Demystifying+Depression%2FPrint+version&oldid=2502703&writer=rl)
  * [Printable version](/w/index.php?title=Demystifying_Depression/Print_version&printable=yes)

  * This page was last modified on 17 March 2013, at 07:57.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Demystifying_Depression/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
