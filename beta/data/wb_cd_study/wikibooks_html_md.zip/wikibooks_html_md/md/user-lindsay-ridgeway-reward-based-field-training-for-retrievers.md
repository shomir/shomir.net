# User:Lindsay Ridgeway/Reward-based Field Training for Retrievers/Print Version

From Wikibooks, open books for an open world

< [User:Lindsay Ridgeway](/wiki/User:Lindsay_Ridgeway) | [Reward-based Field Training for Retrievers](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers)

Jump to: navigation, search

## Contents

  * 1 Preface
  * 2 Disclaimer
  * 3 How to Use This Book
    * 3.1 Getting Started
    * 3.2 Planning Your Training
  * 4 Principles
    * 4.1 Discovery Training
    * 4.2 Motivation
    * 4.3 Building the Relationship
    * 4.4 Rewards and Aversives, Positive and Negative, Reinforcement and Punishment
    * 4.5 The Specialized Retriever
    * 4.6 The Training Schedule
    * 4.7 Biting and Barking During Training
  * 5 Foundation Behaviors
    * 5.1 Tug
      * 5.1.1 Practicing with Muliple Tug Toys
    * 5.2 Recall
      * 5.2.1 The Dreaded Keep-Away Game
    * 5.3 Attention
      * 5.3.1 Attention as Default Behavior
        * 5.3.1.1 Training the Behavior
      * 5.3.2 Attention Cued as "Watch"
      * 5.3.3 Attention Cued as Dog's Name
      * 5.3.4 Atttention Chained to Other Behaviors
    * 5.4 Tethering
    * 5.5 Leave It
    * 5.6 Housetraining
      * 5.6.1 Training the Behavior
      * 5.6.2 Accidents
    * 5.7 Crate Training
    * 5.8 Settle
    * 5.9 Hand Target
    * 5.10 Cuddling
  * 6 Basic Retriever Skills
    * 6.1 Sit
      * 6.1.1 Training the Behavior
      * 6.1.2 "Sit" as Muscular Impulse
      * 6.1.3 Eliminating Latency
      * 6.1.4 Extending the Behavior
        * 6.1.4.1 Generalizing for Location
        * 6.1.4.2 Distraction Proofing
        * 6.1.4.3 Whistle Sit
        * 6.1.4.4 Distance Sit
    * 6.2 Coming to Heel
      * 6.2.1 Shaping the Behavior
      * 6.2.2 Extending the Behavior
      * 6.2.3 Building Motivation
      * 6.2.4 [More material]
    * 6.3 Steadiness
      * 6.3.1 Training Steadiness
        * 6.3.1.1 The Game
        * 6.3.1.2 Extending the Behavior
        * 6.3.1.3 Notes
    * 6.4 Swimming
    * 6.5 Introducing Gunfire
    * 6.6 Heeling
      * 6.6.1 Prerequisites
      * 6.6.2 Training the Behavior
      * 6.6.3 Extending the Behavior
  * 7 Marked Retrieve
    * 7.1 Prerequisites
    * 7.2 Training the Behavior
    * 7.3 Extending the Behavior
    * 7.4 Carrying the Article
    * 7.5 Reinforcers for Fetch
    * 7.6 Practicing Fetch
      * 7.6.1 Pile Work
      * 7.6.2 Building Style
    * 7.7 Retriever Zen
      * 7.7.1 Proofing Drill
      * 7.7.2 Cued/Not-Cued (CNC) Drill
      * 7.7.3 Confidence Drill
    * 7.8 Extending the Behavior
      * 7.8.1 Doubles, Triples, and More
      * 7.8.2 Obstacles
      * 7.8.3 Cover
      * 7.8.4 Hills
      * 7.8.5 Water Re-entry
      * 7.8.6 Flapping in Face
      * 7.8.7 Dokkens
      * 7.8.8 Decoys
      * 7.8.9 Boats
    * 7.9 Retrieving a Dead Bird
    * 7.10 Retrieving a Live Bird
      * 7.10.1 Intrinsic Reinforcement
    * 7.11 Helping
    * 7.12 Group Training
    * 7.13 Test Series
  * 8 Blind Retrieves
    * 8.1 Sight Blinds
    * 8.2 Handling
      * 8.2.1 The Send-out
      * 8.2.2 Back
      * 8.2.3 Over
      * 8.2.4 Angle Back and Angle In
        * 8.2.4.1 Prerequisites
        * 8.2.4.2 Training the Behavior
        * 8.2.4.3 Switching
      * 8.2.5 Lining
        * 8.2.5.1 Training the Behavior
        * 8.2.5.2 Extending the Behavior
    * 8.3 Handling 101: Pinball Drill
      * 8.3.1 Why Surveyor's Flags?
    * 8.4 Handling 102: The Loopback Drill
      * 8.4.1 Training the Behavior
  * 9 Problem Solving
    * 9.1 Barking
      * 9.1.1 Barking in Crate
      * 9.1.2 Barking During Activities
      * 9.1.3 Barking in Vehicle
      * 9.1.4 More about Barking
    * 9.2 Dropping the Article
      * 9.2.1 Shaping "Take It"
      * 9.2.2 Adding Duration
      * 9.2.3 Adding "Sit"
      * 9.2.4 Adding "Out"
      * 9.2.5 Taking an Article
      * 9.2.6 Training the Hold
      * 9.2.7 Anticipatory Response
    * 9.3 Not Returning with the Article
      * 9.3.1 Management
      * 9.3.2 Luring
      * 9.3.3 Reinforcement
      * 9.3.4 Possessiveness
    * 9.4 Slow Returns
    * 9.5 Beaching
    * 9.6 Cheating
      * 9.6.1 Swim By
      * 9.6.2 Pole De-cheating
        * 9.6.2.1 The Game
        * 9.6.2.2 Extending the Behavior
  * 10 Bibliography
    * 10.1 Email Lists
    * 10.2 Books
    * 10.3 Videos
  * 11 Authors
    * 11.1 Founding Author
    * 11.2 Contributing Authors

## Preface[[edit](/w/index.php?title=User:Lindsay_Ridgeway/The_2Q_Retriever/Preface&action=edit&section=T-1)]

The title of this book, _**The 2Q Retriever: A Field Training Workbook**_, reflects the scope and limitations of the topic discussed:

  * _**2Q**_, a term invented by well known field authority Alice Woodyard, refers to two of the four quadrants of operant conditioning. The book's title means that only training methods based upon rewards are discussed in this book, and that training methods based upon aversives — or "force" as aversives are sometimes called by field trainers — are not used. In terms of behavioral science, _**2Q**_ in the title means that the following methods are covered in this book:

    

  * _Positive reinforcement (+R)_. Desired behavior leads to a reward (a pleasant stimulus), with the observed result that the behavior maintains or increases in probability.
  * _Negative punishment (-P)_. Undesired behavior leads to the removal of a reward, or more commonly, the removal of an opportunity to perform a behavior with a history of being rewarded, with the observed result that the undesired behavior declines in probability.

    In field training, the opposite of a _2Q trainer_ is a _4Q trainer_, one who uses all four operant conditioning quadrants. 4Q field trainers are far more common than 2Q field trainers, and all top field trainers at the time of this writing are 4Q trainers. In terms of behavioral science, the following methods _are_ used by 4Q trainers, but are _not_ used by 2Q trainers and are not covered in this book:

    

  * _Positive punishment (+P)_. Undesired behavior leads to an aversive (an unpleasant stimulus), with the observed result that the behavior declines in probability. Using +P is typically called a _correction_.
  * _Negative reinforcement (-R)_. Desired behavior leads to the escape or avoidance of an aversive, with the observed result that the behavior maintains or increases in probability. -R is observed, in experiments and in the field, to be the most powerful operant conditioning quadrant, so 2Q trainers, who train without -R, face significant challenges in trying to achieve the same training objectives as 4Q trainers.

  * _**Retriever**_ in the title of the book means that only training for retrievers is covered. Training for other canine breeds, including field dogs such as pointers, flushers, and versatile hunters, is not specifically addressed.
  * _**Field Training**_ means that that the book specifically addresses training the dog for field sports. Training for other canine sports, such as agility and obedience, is not specifically addressed. In addition, the book goes far beyond the needs of the pet dog owner.
  * _**Workbook**_ means that this book is designed to be used as an interactive training document, with notations that you would add by printing out pages, or cutting and pasting them into an electronic document.

## Disclaimer[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Disclaimer&action=edit&section=T-1)]

This book was begun by me, Lindsay Ridgeway, in July 2007. At that time, though I had been studying and practicing dog training for over three years, I had never trained a dog to any title, in field sports or any other canine sport.

Typically, one would want to read material like the subject of this book written by an expert with proven credentials.

Unfortunately, that was not available at the time this book was started. As of July 2007, there has never been a field champion retriever trained exclusively by reward-based methods, and perhaps there never will be. Many field trainers believe that it can't be done, and few are willing to make the investment to find out.

On the other hand, I did not want to wait until I've shown it could be done before beginning work on documenting my methods. By the time I have trained a successful field trial dog (if that ever happens), I might no longer have the time, inclination, and memory to explain what I've done.

Therefore, this book was started as a repository for my training notes. In the future, it might be a treatise in how _not_ to train a successful field competitor, or, if I'm fortunate enough to succeed, it might be a record of how the job was done.

At the same time, by presenting this work as a Wikibook, I invite collaboration from others, and some contributors may bring far more knowledge and credentials to the material than I am able to. To the extent that this work becomes supplemented, edited, and vetted by more experienced trainers, this _Disclaimer_ may eventually become merely an introductory note on the genesis of this book.

## How to Use This Book[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/How_to_Use_This_Book&action=edit&section=T-1)]

This book is intended primarily as a manual for training retrievers for field sports. As such, it contains many training plans, each associated with a particular training objective. The training plans are presented in a series of chapters to provide organization for the material.

However, _**this book does not present training plans in the order that training is to occur.**_ Quite the contrary, a puppy is never too young to begin retrieving, yet the marked retrieve is one of the later chapters of this book.

What, then, is the correct sequence of training? The answer is that the training cannot be done in a rigid sequence, for several reasons:

  1. It is essential that many of these skills be started as soon as possible. Examples of cues that deserve immediate training are "here", "sit", and "give it".
  2. During the dog's life, many of those same skills will need constant reinforcement. If you train a particular skill and then do not practice it, you may find that it is not reliable when you need it, even though it was entirely reliable at one time. But which skills need shoring up over the dog's life varies with the dog. For example, a dog with a predisposition toward resource guarding may need continuous practice with a highly reinforcing "give it" his whole life.

No single sequence of training is right for all trainers and all dogs. Eventually, your retriever will need to learn all of the skills presented in this book. Therefore, the best plan is to begin working on a number of skills in parallel, one in one session and one in another, and continue to add more as you complete work in those previously started.

### Getting Started[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/How_to_Use_This_Book&action=edit&section=T-2)]

Begin by examining the table of contents (TOC) for the entire book. A consolidated TOC is available at the top of the **Print Version** of this book.

At the minimum, you may also wish to click on particular topics and glance at the material to get a sense of the content. Thoroughly study the material whenever you prefer to do so:

  * Some readers prefer to read and digest the entire contents of a manual before starting work.
  * Others prefer to defer thorough study of a particular topic until they are about to use the material.

### Planning Your Training[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/How_to_Use_This_Book&action=edit&section=T-3)]

Next comes the key to a solid training progression. _**As you organize each session, day, or week's training, review the TOC again.**_ If an item catches your eye that you've never read before or for which you've forgotten some of the details, click the link and read the material for that topic as well. Then you will have the information you need to plan your next segment of training.

By continually reviewing the TOC, you'll be able to maintain perspective of where you are in your dog's training, and to select the best project for you and your dog at all times.

Here's a general approach for choosing particular training projects:

  * Limit your choices for each session to those training plans for which the dog is ready. Information in each training plan, such as prequesites and sections on _Extending the Behavior_, will help you make that determination.
  * From among those plans for which the dog is ready, select the ones you deem most important at the time:

    — Perhaps you'll choose one that you feel deserves a higher history of reinforcement because of its importance in the dog's life, such as recall.

    — Or perhaps you'll choose one that is ready for more work because you've been concentrating on other areas.

    — Or one day you give a cue in the field and your dog doesn't respond correctly, perhaps too slow, perhaps not at all. So you decide to dedicate an evening, or perhaps a week of evenings, to practicing that cue, perhaps adding the clicker and some high-value treats, to the re-training process.

## Principles[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-1)]

This section contains important information for training your field retriever. Besides being prerequisite to the chapters which follow, this chapter contains information that you may want to reread and refer back to time and again during life with your dog.

### Discovery Training[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-2)]

In many canine performance sports, the dog is trained to perform behaviors that are not natural to the dog. Trainers use extrinsic rewards such as treats, and aversives such as leash pops, to develop a reinforcement history for the desired behavior.

But when a retriever is being trained in field work, a new principle comes into play. . .

### Motivation[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-3)]

The single greatest responsibility of a field trainer is to build your dog's motivation for the game.

While motivation is always enjoyable to see in a performance dog, and may affect scoring in other sports, it plays the highest role in field sports, especially Field Trials. The reason for this is that a successful Field Trial dog is required to overcome difficult challenges, such as rough terrain, heavy cover, and long swims in cold water. These are not merely trained behaviors. The dog must above all _want_ to retrieve in order to find the will to meet such challenges.

In behavioral science, the term _motivation_ is distinguished from _learning_ on the basis of whether the behavior is more or less permanently installed. Thus, a dog who performs a behavior on one day but not another may be more _motivated_ on one day than another, while a dog who _learns_ a behavior on one day will then repeat that behavior on subsequent days.

In this book, the term _motivation_ takes on a more specific meaning. Here, we use _motivation_ to describe the amplitude of the behavior, the enthusiasm and vigor with which the behavior is performed.

Many factors affect a dog's motivation:

  * **Establishing Operations (EOs)**. Examples are whether the dog is hungry and well rested.
  * **Frustration**. A dog with a tolerance for frustration will show higher motivation when appropriate levels of frustration occur, such as when a tug toy is kept out of reach until the dog makes sufficient effort to reach it. Of course, if the frustration level is too high for the particular dog on that particular occasion, the dog simply gives up.
  * **Reinforcement History**. If a dog is reinforced for low levels of enthusiasm, he will learn to perform at those levels. One frequently sees this with trainers who "cheerlead". Their intent is to rev the dog up, but because the dog finds cheerleading reinforcing, in effect the trainer is saying, "That's the way I want you to perform these behaviors."
  * More factors to be listed

### Building the Relationship[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-4)]

Many factors can contribute to relationship building. For example, in Susan Garrett's _Ruff Love_, relationship building is based primarily on the dog learning that all good things come from the trainer.

How you reinforce a behavior can also have a major impact on the relationship. Reinforcing with tug is excellent for relationship building, because it engages the dog's prey drive in a cooperative enterprise (see [Tug](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors#Tug)).

Another way to develop your relationship with the dog is through cuddling (see [Cuddling](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors#Cuddling)).

On the negative side, a lack of consistency in your responses to the dog's behavior, the unskilled use of aversives, and other training errors can detract from the relationship. Even if you are committed to reward-based training, you can see this happen at times, for example if you are feeling tired or impatient. Always watch the dog to see whether he is engaged and enthusiastic in your training, and when you see his behavior going the opposite direction, stop what you are doing. If you are unable to immediately adjust your attitude, it is far better that your dog spend the next few minutes or hours resting in his crate than that you continue with a counter-productive training session.

### Rewards and Aversives, Positive and Negative, Reinforcement and Punishment[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-5)]

This book uses the terms _reward_ and _aversive_, _positive_ and _negative_, and _reinforcement_ and _punishment_ with fairly narrow definitions:

  * A possible _reward_ is a stimulus (such as food or play) that is given after the dog has offered a behavior. If giving the stimulus results in the behavior becoming more likely thereafter, the stimulus is considered to have acted as a reward (also called a _reinforcer_).
  * A possible _aversive_ is a stimulus that occurs after the dog has offered a behavior. If giving the stimulus results in the behavior beoming less likely thereafter, the stimulus is considered to have acted as an aversive (also called a _punisher_).
  * A stimulus can also be recognized as a _reward_ if a behavior decreases when that behavior results in the dog losing the opportunity to obtain the stimulus.
  * A stimulus can also be recognized as an _aversive_ if a behavior increases when that behavior results in the dog escaping or avoiding the stimulus.
  * _Positive_ use of a stimulus means that the stimulus occuring is contingent on a particular behavior. For a reward, the result is an increase the likelihood of the behavior. For an aversive, the result is a decrease in the likelihood of the behavior.
  * _Negative_ use of a stimulus means that the stimulus _not_ occuring is contingent on a particular behavior. For a reward, the result is a decrease in the likelihood of the behavior. For an aversive, the result is an increase in the likelihood of a behavior.
  * A stimulus is considered _reinforcement_ if and only if it results in a behavior maintaining or increasing its frequency. In other words, the litmus test is not whether the dog seems to like or dislike the stimulus. The only way to recognize reinforcement is whether the dog will work for the opportunity to obtain a positive reinforcer (a reward), or will work to escape or avoid a negative reinforcer (an aversive).
  * A stimulus is considered _punishment_ if and only if it results in a behavior decreasing. Again, the litmus test is not whether the dog seems to like or dislike the stimulus. The only way to recognize punishment is whether the dog will work to avoid losing the opportunity to obtain a negative punisher (a reward), or will work to escape or avoid a positive punisher (an aversive).

Note that a reward can be used for both reinforcement (by giving the reward after a behavior) and for punishment (by removing the opportunity to obtain the reward after a behavior). Similarly, an aversive can be used both for punishment (by administering the aversive after the behavior) and for reinforcement (by enabling the dog to escape or avoid the aversive with a particular behavior).

Note also that the terms _positive_ and _negative_ apply to both reinforcement and punishment, and can be used with both rewards and aversives. Since this book is based on methods that use rewards for both positive reinforcement and negative punishment, that is the reason this book uses the term "reward-based" rather than "positive" in the title.

### The Specialized Retriever[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-6)]

  * Does a field champion need "roll over" or "down"?

### The Training Schedule[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-7)]

We Americans typically live our 24 hour days with a continuous stream of awakened activity, followed by a full night's sleep.

Many dogs approximately shadow our schedule, though they may also snooze during the day and perhaps wake up to play at times during the night.

But performance dogs, and especially dogs trained for Field Trials, are often on a different kind of schedule: two or more short training periods each day, with periods of rest and sleep in between.

It is not always easy for amateur trainers to provide such a training schedule for their dogs while maintaining their own busier schedule, but there may be good reasons to try:

  * A well-rested dog is less likely to injure himself.
  * Quiet time gives the dog an opportunity to assimilate what he learned during the preceding session, to ponder it and to sleep on it.
  * Dogs on a training schedule bring all their energy to those short training periods, and tend to work with high motivation and focus. By contrast, dogs shadowing a living schedule learn to pace themselves, bringing less intensity and concentration to each individual task.

In Field Trials, your dog will be competing against dogs with professional trainers who run a string of dogs. Those dogs typically get one training session in the morning, and another in the afternoon. The rest of the time, they are in their kennels, resting and sleeping and assimilating the day's lessons. Unless you have reason to believe that more activity will give your dogs a competitive advantage over that time-honored approach to training, even though you may train only one or two dogs, you may want to provide your dogs with the same kind of schedule that the Pros give their dogs.

### Biting and Barking During Training[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles&action=edit&section=T-8)]

  * Normally, only train one thing at a time, but biting and barking are always relevant.
  * Don't allow biting when taking treats. Hold the treat deep in your hand, and require the dog to use his tongue to reach it.
  * If you reinforce barking, it can become part of the trained behavior. Common examples: "Throw the ball," and barking when backing up.
  * Therefore, don't reinforce barking. Instead, turn your back, wait 10-30 seconds, whatever amount of time results in the behavior declining.
  * If turning your back is not enough to cause the barking to stop, see the section [Barking](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving#Barking) in the chapter "Problem Solving".
  * Whatever method you us, be absolutely consistent, and respond at the very instant of the bark.
  * Don't allow the biting or barking to continue during initial training of a behavior with the idea of fixing the problem later. It can transfer from being a general behavior to becoming specifically associated with that behavior, and it's _much_ more difficult to untrain later.

## Foundation Behaviors[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-1)]

This chapter discusses concepts appropriate to any trained dog and not specific to field work, but necessary for the field dog.

### Tug[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-2)]

  * The relationship-building reinforcer
  * The choice of a tug toy is important. The dog may find playing tug with one toy significantly more enjoyable than another, and therefore, using that toy may have a significantly more reinforcing effect on other behaviors than playing tug with another toy might.

#### Practicing with Muliple Tug Toys[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-3)]

An interesting version of tug is to use two or more toys:

  1. Offer one of the toys, and when the dog grabs the toy, play enthusiastically with him for a few moments.
  2. Then drop the toy, letting the dog continue to play with the toy himself.
  3. Now offer the other toy, perhaps squeaking it, folding it in half and flapping it like jaws, or in some other way enticing the dog with it.
  4. When the dog grabs your new toy, resume enthusiastic tug with this new toy, while using your other hand to slip the other toy away from the dog.
  5. Continue to alternate between the toys, allowing the dog to learn over and over again that it's you, not the toy, that makes the game so much fun.

### Recall[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-4)]

  * The single most important behavior for any dog
  * Use of a long line to avoid rehearsing self-reinforcing behavior
  * Puppy ping-pong
  * Calling from restraint to build motivation
  * Using _tug_ to reinforce (versus _a thrown toy_ \-- exciting but not as good for building a relationship; versus _food_ \-- possibly calming rather than exciting)
  * Choice of the tug toy is important (see Tug)

#### The Dreaded Keep-Away Game[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-5)]

As discussed in _[How to Use This Book](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/How_to_Use_This_Book)_, the first few chapters of this manual describe training that is to occur in parallel, not in sequence one chapter after another.

While "give it" is the basis for retrieving, and also for the refinement of retrieving to hand, it also plays a role in your relationship to the dog so important that it cannot be overstated.

"Give it" is the keystone for solving what is for some dogs the most dreaded enemy of reliable recall, the keep-away game. This information needed in the section on "give it" also.

TO DO: Discuss the no-glance rule.

TO DO: Explain RETRIEVER ZEN: To train the dog to come back with the bird, train the dog to come back without the bird.

### Attention[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-6)]

_Attention_ means that the dog's attention is on you, whether he's in your arms or 500 yards away.

Although it's possible for the dog to look at something else, such as an agility object or a retrieval article, while remaining attentive to the trainer, the term _attention_ is usually meant to include eye contact. It's a key behavior for any performance dog, and valuable for any dog:

  * Enables dog to see visual cues
  * Dog is engaged in the activity with you and ignoring any distractions
  * Ability to gain and hold the dog's attention is as much about you as a trainer as about the dog's skills
  * Attention is a key building block of the overall relationship

#### Attention as Default Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-7)]

_Default_ means that the dog offers the behavior spontaneously, without any cue from the handler.

Attention to you is an good default behavior for many situations, such as you entering the room, the approach of a strange dog or person, confusion about what behavior you are asking for.

##### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-8)]

  * In a small room such as a powder room, place a bowl of treats out of sight, then sit on the floor or a chair with a clicker.
  * Each time the dog looks at you, click and treat. Don't reach for the treat until you've gotten the response you want. Otherwise, reaching for the treat will be the stimulus that triggers the behavior, and you want the behavior to occur without any stimulus from you other than your presence.
  * If the dog doesn't look at you at first, click and treat for a glance in your general direction. Once that is occuring reliably, after 3-5 times, limit your clicks to the longer, more accurate glances, and strengthen that version of the behavior for several clicks. Then again raise the criteria.
  * All organisms are drawn to salient targets, so you can also get the behavior going by moving your face around, smiling and talking to the dog. Again, fade those stimuli as quickly as possible so the dog is seeking eye contact without any action on your part.
  * Assuming the dog likes the treats you're using, you may find you can do this for many reps without the dog losing interest. For example, you can hand feed the dog's entire meal with this exercise. If the dog does begin to lose interest, do something exciting with the dog and then end the session.
  * Repeat this training in a non-distracting environment until the dog understands the game entirely. Then begin to generalize for location and distractions by moving to somewhere else in the house, and then in front or back of your home, and finally in strange locations. Over a period of a few weeks, you'll be able to play the game in any environment, and your dog will have developed a strong habit of giving his attention to you.

#### Attention Cued as "Watch"[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-9)]

Once your dog has developed attention as a default behavior, you can also put eye-contact on verbal cue by saying "watch" just before the dog looks at you several times.

Soon, you'll find that you can say "watch" and the dog will look at you for his click and treat even if he was not just about to.

Don't test this in highly distracting situations, such as dog play or when the dog is sniffing, until you are completely confident that the dog will respond correctly. You don't want the dog rehearsing ignoring you. Are you willing to bet $100 that he'll look at you when you say "watch"?

#### Attention Cued as Dog's Name[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-10)]

Many performance dogs are also trained to respond to their name as cue for "watch". That may or may not be appropriate for retrievers, since their name is also used as a send-out for marks.

If you _are_ going to use the dog's name for both "watch" and/or recall, and _also_ as a send-out on marks, and you plan to train the "watch"/recall version to a reflexive response that you want the dog responding to without thinking, it might be useful to be aware of that reflex when you use the identical cue as a send-out.

On the other hand, you may find that using the dog's name on a send-out isn't a cue at all, but rather a release, allowing the dog to perform his favorite activity, retrieving. Thus using his name that way may serve to strengthen it an attention and recall cue.

#### Atttention Chained to Other Behaviors[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-11)]

Some trainers include eye-contact as a behavior chained onto other behaviors. For example, "leave it" might be shaped so that in the final version of the behavior, the dog not only moves his mouth away from the object, but then looks at you. And "sit" might be shaped so that in the final version of the behavior, eye-contact is required in order to earn reinforcement. Note to Lindsay: Update "leave it" and "sit" with this information.

### Tethering[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-12)]

  * Wearing the dog
  * NILIF
  * Helps recall
  * Helps heeling
  * Even helps learning to swim

### Leave It[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-13)]

  * Trained cheerfully (doggie zen)

### Housetraining[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-14)]

#### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-15)]

  1. Take the dog to the place outside where you want him to eliminate whenever it is likely to happen. This varies from dog to dog, but a good rule of thumb is _between_ any two states of activity: 

    — Time in the crate
    — Sleeping
    — Playing
    — Eating
  2. Whenever the dog eliminates in the desired location, reinforce well. For example, you might congratulate the dog enthusiastically on his brilliance and give him a high-value treat.

#### Accidents[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-16)]

  * Do not punish.
  * If you are not present when the accident occurs, do not interact with the dog at all with respect to the accident. Simply clean it up.
  * If you are present while the accident is in progress, instantly but gently carry the dog outside to the place where you want him to finish.

### Crate Training[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-17)]

  * Clicker-training is one possibility, but doing it the first night you have a new puppy may be unrealistic
  * Many people keep the crate in their bedroom, or even on the same level as their bed, at least the first couple of nights
  * Try covering the crate when the dog cries

    \-- She may not cry the next time, because she may not like having the crate covered and may wish to avoid that happening again
    \-- Or she may cry again, because she may not mind having the crate covered, or may even like it and may cry to make it happen
    \-- Either way, she may not cry in the covered crate

### Settle[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-18)]

  * Cuddling in arms
  * Bodywork
  * Stretches
  * Grooming
  * Nail grinding
  * Tooth brushing
  * Falling asleep in arms on couch

### Hand Target[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-19)]

### Cuddling[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors&action=edit&section=T-20)]

Here, Lindsay Ridgeway describes some of the ways he used cuddling in training his young puppy Laddie, beginning in the summer of 2007:

"At various times such as before bedtime, Laddie, Lumi and I run into the backyard, and I sit or lie down in the grass. I have treats and a tug toy with me. Sometimes the dogs interact with one another, and sometimes Laddie goes off to explore for a little while. But most of the time, he's with me, tumbling around in a circle I make with my arms, playing tug, or retrieving the tug toy when I throw it for him. Often he'll roll into me, pushing against me with his back or head. It makes me feel that he's seeing me as a protector as well as a playmate.

"When DW Renee and I are watching a video, I often have Laddie sit on my lap, at first playing, eventually collapsing like a rag doll and snoozing in my arms.

"Sitting at the computer, I sometimes take Laddie out of the crate and hold him in my lap while typing. He'll try to help me with the mouse and keyboard for awhile, but I cradle him in my arms and snuggle with him, and we sometimes give each other kisses. After a few minutes, he's a rag doll again.

"When we play at the lake, I've found that Lumi wants to be sent right back into the water as soon as possible after every retrieve, while Laddie usually likes to spend some time on dry land before having another dummy thrown for him. So when he brings his dummy back, I often take it from him and then run over to the grass and lie down, and soon he's there with me, tumbling around against me, soaking wet. We wait for Lumi to come back from her much longer throw. Then I'm back on my feet, walking toward the water and swinging one of the dummies, and Laddie's there beside me, looking out at the waves to see where his dummy's going to land so that he can swim out to it. I might put Lumi into a sit and throw Laddie's dummy first to work on Lumi's steadiness, or I might send Lumi out first. Either way, the cuddling break seems to increase Laddie's motivation for his own retrieves, whereas if I just throw the dummy again as soon as he gets back, he might watch it go out but not go after it."

## Basic Retriever Skills[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-1)]

### Sit[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-2)]

Field retrievers need to be able to sit on cue in a number of different situations:

  * While waiting in a blind
  * After coming to heel on either side at the line, for a marked or blind retrieve
  * When delivering the bird after a retrieve
  * During handling, before a "back" or "over" cue
  * In numerous non-fieldwork situations, such as when arriving at the curb before crossing a street

For the experienced dog, in many of those situations, the context acts as the cue, and the only reason to have a verbal cue is during the training phase. For example, it may not be necessary to verbally cue "sit" during delivery of the bird.

On the other hand, the whistle sit is needed whenever the dog is handled.

#### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-3)]

Many people train "sit" by either forcing the dog into a sit position (however gently), or by luring the dog into a sit with a treat or hand target.

It is unnecessary to train "sit" in either of those ways, and both create additional associations within the learning process that are unrelated to the desired behavior and that the dog will eventually need to unlearn. For example, both of those methods require the trainer to be in close proximity to the dog, whereas field dogs need to learn to sit when cued even from hundreds of yards away.

Here's a way to train "sit" called _capturing_ the behavior:

  1. Take the dog, a clicker and a handful of treats into a small, quiet room with no distractions. A small bathroom may serve the purpose.
  2. To get the dog into the training game, click and treat three times. No behavior is required by the dog to earn these treats.
  3. Sit down and wait. Eventually, the dog will also sit down.
  4. At the very instant that the dog puts his butt on the floor, click and treat.
  5. Use your hand or another treat to lure the dog out of the sit, then repeat.
  6. Once the dog begins to quickly sit again as soon as you've distracted him out of the sit, you can begin clicking and then using that treat to get him out of the sit. This will fill him up more slowly and give you more productive training time.
  7. After the dog is reliably sitting down repeatedly, say "sit" just as he is sitting down several times.
  8. When you can anticipate the moment before he is about to sit, say "sit" an instant before the sit a few times.
  9. Soon, you will see from the dog's alertness that he is responding to your verbal cue. When you see that, try saying "sit" at a moment when the dog was not about to sit anyway. If he sits, the behavior is now on cue. If not, return to the earlier steps a bit longer.
  10. If the dog is sometimes not looking at you when he sits, stop clicking and treating any sits when he is not looking at you. You want to "sit" to be an attention cue as well as having the dog in a sit position.

It is not necessary that all of the above steps occur in a single session. Take as many short, fun sessions as necessary to get "sit" on cue.

Notice that you are not requiring the dog to face you, or sit in heel position, or be near you when he sits. Although any of those criteria might be desirable for some performance dogs, it is advantageous for the retriever to be able to sit on cue in any position and at any distance. Be sure to add enthusiastic praise when he sits at some distance from you.

#### "Sit" as Muscular Impulse[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-4)]

An interesting phenomenon is that "sit" has probably become a particular muscular impulse for your dog, not a position. As a result, you may find that the dog will not understand "sit" if you cue it when the dog is lying down or in any other position besides standing.

It is generally not necessary for a field dog to respond to "sit" from any other position besides standing, but if you wish for the dog to be able to respond to "sit" from those positions, realize that you will have to train them separately. Some trainers use a different cue, so that "sit" continues to be the name of a muscular movement and can become essentially reflexive without any conscious thought from the dog.

#### Eliminating Latency[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-5)]

_Latency_ is the delay after a cue is given before the dog responds. Many trainers feel that when a dog is learning a new behavior, he may need time to think about the cue, and the trainer watches for that "lightbulb moment" when the dog seems to figure out what you're asking him to do, that is, what will earn him reinforcement.

However, watching for the lightbulb moment may lead you into a trap. You give the cue and then you wait, and when the dog finally sits down, you celebrate his newfound understanding with special enthusiasm. Even though he eventually does sit down, he has now begun to learn that "sit" does not require an instantaneous movement in order to be reinforced. He may have even learned that the delay increased his reward.

It is a matter of individual style how soon you want to stop clicking and treating for slow responses. One legitimate approach is to _never_ click for more than a split second of latency. You may never get to see a lightbulb moment that way, but you also won't have to extinguish slow latency later. _Extinguish_ means to eliminate a behavior by not reinforcing it.

The key to this is sharp observation. During training, you want a correct response at least 70% of the time you give a cue. If your criteria for a correct response includes split second latency, it behooves you to give cues in such a way that the dog is able to respond correctly at least 70% of the time. If the dog is not doing so, you have raised other criteria, such as distractions or distance, too fast.

#### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-6)]

A number of extensions of "sit" will be required once the behavior is learned:

  * Generalizing for location
  * Distraction proofing
  * Hold and sit
  * Whistle sit
  * Distance sit

Each of these is discussed in the following sections.

##### Generalizing for Location[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-7)]

After training "sit" in the small, quiet location you used for the initial training, you are likely to discover that the dog does not seem to know what "sit" means in any other location. This is because dogs are brilliant discriminators, often cueing on stimuli that was not intended as part of the cue.

So once "sit" is trained in the first location, retrain it repeatedly in other locations. You may need to follow all the same steps, though it's likely they'll go increasingly quickly each time the behavior is retrained. For example:

  * Train in the living room.
  * Train in the kitchen.
  * Train on the front porch.
  * Train in the front yard.
  * Train in the back yard.
  * Train elsewhere in the neighborhood.
  * Train at various training fields.

Eventually, your dog will realize that "sit" means the same thing regardless of location.

##### Distraction Proofing[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-8)]

Just as the dog will initially consider location as one of the stimuli cueing the behavior, he will also take other criteria into account, such as the presense of other people and objects, noise, light, smells, and so forth.

Just as you retrained the dog to sit on cue in new locations, you will also need to repeatedly retrain "sit" as more distractions are added. It is common to think that the dog "knows" the behavior and is inadventently or intentionally ignoring you. A simpler way of thinking about it is that the dog is responding to stimuli, and has not yet learned which stimuli matter and which do not. By retraining "sit" under a series of increasingly distracting situations, the dog can gradually sort out that the only sequence that predicts he will receive reinforcement is whether you cue him to sit and he does so. As simple as that concept may sound, it takes dogs time to learn it, and it's a lesson they have to learn many times before they begin to generalize it for new distractions and other behaviors.

As you are generalizing for location (see above), also begin to add distractions. Eventually, train to the point where the dog responds correctly in even the most challenging conditions, such as around other dogs or with a tennis ball rolling past him.

##### Whistle Sit[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-9)]

To be edited

Another thing you can do is to get a whistle sit with Deuce facing you. With Deuce at some distance, call him to you. When he gets close, while still facing you, whistle one tweet, then immediately use your current "sit" cue. The instant his butt hits the ground, reinforce. You'll have to decide what reinforcement works best for this. It could be praise, it could be throwing a toy. I like using a click and a treat.

After you've done that a few times, Deuce will anticipate the "sit" cue as soon as you whistle. Of course, reinforce him for sitting on the whistle and not waiting for the verbal or visual cue. Once that seems to be fairly reliable, practice-practice-practice using one tweet on the whistle to cue a sit.

Traditional trainers use force (a heeling stick and/or an e-collar) to train a very fast response to the whistle. Since we're not using force, we need to substitute lots of reps and lots of high-value reinforcement.

##### Distance Sit[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-10)]

To train the dog sit and face you at any distance, even hundreds of yards away:

To be edited

The way I would approach it is with a barrier of some kind. You don't need to train it with the whistle. You can train it with the verbal cue, then add the whistle later.

So, for example, in a hallway, you'd put a couple of chairs or something else to block the dog from coming through. Then with the dog on one side, and with you, treats, and a clicker on the other side, you'd cue "sit". Initially, you'd be as close to him as ever, so assuming his sit is already reliable, he'd sit and you'd click/treat.

If he has a "stand" cue, use that to get him on his feet, then click/treat again. If not, you could either take a few days to train "stand", or you could hold the treat in such a way that the dog has to stand to get it, or you could toss the treat on the floor behind him so he has to stand to get to it.

After 2-3 of those, you'd step back one step. Because of the barrier, he can't follow you, so again you'll cue "sit". Hopefully, he'll sit. If not, move closer, do a few more reps, then step back again. Continue in this way until you've got fairly good distance, perhaps 6-8 feet. Each time the dog sits, click and rush forward with a treat.

After that, you have a variety of things to do, in whatever order works best.:

  * You need to fade the barrier. In other words, switch from two chairs to just one (he could get through if he wanted to but you won't reinforce if he does). Then a lower barrier, then a carpet, and finally no barrier at all.
  * You need to proof for new locations, such as the front yard and eventually the field.
  * You need to proof for distractions, such as a bowl of food on the floor, or balloons, or family members wandering around. You'd introduce the distractions first at distance that doesn't bother him, and over a period of one or more sessions, move them closer a little at a time. If he becomes distracted, move them further out again, then start working them closer again.
  * You need to add the whistle tweet as a "sit" cue. To do that, tweet and then cue "sit" several times. Soon, he'll begin to anticipate the verbal cue when he hears the whistle and you won't need to actually say the verbal cue.
  * You need to build distance. Eventually he'll need to be able to sit from hundreds of yards away. That's not necessary now, but once you've faded the barrier, start working on greater distances. One way is with the dog inside a tennis court and you outside.

The reason that distance sit is difficult for most dogs is because of how it's trained originally. Typically a dog will need to learn a whole new concept of what the cue means, that it's a muscle movement, not a position near you. Hopefully, though, he'll get it pretty quickly. The more reinforcement he gets for success, the easier it will be for him to repeat.

### Coming to Heel[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-11)]

#### Shaping the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-12)]

  * Prerequisites: "touch" (hand target), "sit", and sit while holding an article in the mouth Note: Laddie sat without dropping the article without that being trained; that possibility needs to be integrated into this section.
  * Work in a quiet, non-distracting room with a handful of treats and a clicker.
  * Position yourself with the dog behind you and on the side which is not holding the treats and clicker.
  * Put your hand at your side with the palm facing backwards and cue "touch".
  * As soon as the dog touches your hand, cue "sit". "Sit" acts as a reinforcer for "touch".
  * When the dog sits, click and reinforce with a treat. You can feed in position, then call the dog out of position to set up next rep, or toss the treat on the ground to pull the dog out of the sit and set up the next rep.
  * Work both sides.

#### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-13)]

  * Gradually shape improved position of the sit until the dog is sitting directly beside you, facing in the exact direction he was walking as he came to your hand. This will be valuable later for casting.
  * When he's sitting in the correct position, you can add a cue word or let your hand movement evolve into a visual cue.
  * Gradually use the cue to call him to heel from other positions than directly behind you. The eventual goal is for him to be able to come to heel when running toward you from in front.
  * Combine with steadiness training so that the dog is reinforced for coming to heel by the opportunity to retrieve.
  * Add carrying a dummy, Dokken or bird while coming to heel ("coming to heel" is a phrase that traditionally includes the sit).
  * Generalize for location and proof for distractions.

#### Building Motivation[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-14)]

Here's a game that Lindsay Ridgeway used to motivation for the chain of behaviors that make up a retrieve in training Laddie, his Golden puppy, in August 2007:

  1. Swing the dog to heel and cue "sit". Reinforce with food.
  2. Throw the dummy. Dog waits in sit position, coiled and ready to spring.
  3. Release the dog by calling the dog's name.
  4. As the dog runs back with the dummy, swing him to heel and cue "sit". If he's played the game enough, he'll sit with the dummy in his mouth even though he might not be able to keep the dummy in his mouth while sitting as an isolated behavior.
  5. Take the dummy and reinforce with food.
  6. Again throw the dummy as dog waits for release.

If the dog won't hold the dummy while sitting, take the dummy before cueing "sit", or even before cueing the swing to heel. As the dog's motivation for the game increases over time, you may find it's unnecessary to train the hold as a separate behavior, and that one day you'll cue "sit" while the dummy is in the dog's mouth and he'll just do it.

#### [More material][[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-15)]

NOTE TO LINDSAY. Merge this with the notes above. Note that the section notes above click/treat for "touch", and uses "sit" to reinforce "touch" from the beginning of the training. That is a preferred approach, but other material in the section below should also be retained.

A field dog comes to heel at the line before a marked or blind retrieve, and again to deliver the bird or dummy after the retrieve.

A prerequisite to this training is the dog responding to a hand target (see the section [Hand Target](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors#Hand_Target) in the chapter "Foundation Behaviors").

To train coming to heel and sitting:

  1. Go to a quiet location with the dog, a clicker and a handful of treats.
  2. Click and treat three times in quick succession to get the dog into the game.
  3. Move into a position so that the dog is behind you off either flank, put your hand at your side as a target, and cue "touch". Click and treat.
  4. Repeat, randomly calling for "touch" on either side of you. If the dog is less responsive on one side than the other, practice that side more until he is equally responsive on both sides.
  5. As that becomes fluent, the verbal cue "touch" will no longer be needed. Click and treat with special praise and enthusiasm for the dog responding to the visual cue alone.
  6. Next, cue "sit" at the moment that the dog touches your hand. Click and treat for the dog sitting.
  7. Continue to repeat that behavior, gradually requiring more and more behavior from your dog: 
    * Instead of the dog being directly behind you, start with him pointed at your hip, then lead him 90 degrees around and into position.
    * Gradually increase the size of the turn until you can bring him around from in front of you.
    * Gradually ease the requirement that the dog actually touch your hand, as long as he comes to the desired position.
    * Click for rough positioning at first, then gradually raise your standards and don't click if he doesn't meet your current criteria. If he is successful less than 70% of the time, you've raised the bar too high and he's not getting reinforced enough to stay in the game and enjoy it. If he is successful more than 80% of the time, you can increase your criteria a bit.
    * Again, practice both sides in unpredictable sequence.
  8. Occasionally, the dog will sit before you have a chance to cue "sit", perhaps because he is not quite in position. If he is not too far out of position, click and treat for that anticipation, so that he will learn to sit without the verbal cue. Then gradually raise the criteria so that you only click and treat if he is in position when he goes into his sit.
  9. Because you are training both sides, you may not want to bother to train separate verbal cues for each side. Instead, you can gradually fade your target hand into a more subtle version, such as a wristy spiral movement, and let that serve as your visual cue for "come to heel and sit".

As with training "sit" above, you'll need to generalize coming to heel for location and retrain it under increasing levels of distractions.

Take your time with this, so that coming to heel presents a facile, joyous picture.

### Steadiness[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-16)]

A field dog is said to be _steady_ if he can wait at heel until released without any physical restraint. In some venues, it is also impermissible to use verbal cueing.

The two situations a dog typically needs to be steady in competition is when waiting at the line while marks are thrown, and when honoring while another dog runs marks.

Some methods of steadiness training can be de-motivating for the dog, and some trainers prefer to delay training of steadiness. In fact, in the lower levels of competition, such as Working Certificate (WC) and Junior Hunter (JH), the focus is on natural ability rather than training and the dog is not required to be steady. Typically, dogs competing in those events are restrained at the line with a check cord, and no honoring is required by the event.

But reward-based trainers often work to develop _control in drive_, that is, a high level of motivation simultaneous with self-control, from the beginning. The goal is to develop intense focus while waiting, and explosive drive to the mark when released.

#### Training Steadiness[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-17)]

Here is a method used by Lindsay Ridgeway for training Laddie, his male Golden, starting in July 2007 when Laddie was 11 weeks old. At that time, Laddie had been practicing tug, "sit", and retrieving for about four weeks.

##### The Game[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-18)]

  1. Holding the dog in your arms, put down the dummy at arms length from the starting line and get a cookies (such as a meatball from the dog's meal) and the dog's tug toy.
  2. Put the dog on the ground, cue "sit", and feed for that response.
  3. As soon as the dog has eaten the cookie, cue the retrieve. Traditionally, the dog's name is called out, for example, "Laddie!"
  4. Ideally, the dog runs to the dummy, picks it up, and runs back to you with it. 
    * If he doesn't leave the line, run with him part way or all the way to the dummy.
    * If he runs with you but doesn't pick up the dummy, pick it up and throw it a short ways.
    * If he still doesn't pick up the dummy, either this is a bad time to train, or he hasn't had enough work with simple retrieving.
    * If he doesn't return to you with the dummy, try running away from him to get him to chase you with the dummy.
    * If he still doesn't return to you with the dummy, put him on a long line (perhaps 25') so that you can gently reel him in after he has the dummy in his mouth. _**Do not let him rehearse not returning to you with the dummy.**_ That can be a self-reinforcing behavior that you do not want to have to untrain later.
  5. When the dog arrives with the dummy, take it from him and instantly reinforce. A great way to do that is to bring out his tug toy and snake it around on the ground to get him playing tug with you. Other possibilities include handing him a bite of food or throwing the dummy out for him to run and retrieve again. See Notes below.
  6. Pick the dog up and cuddle him, then repeat from the beginning.

##### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-19)]

  1. Once the dog is playing the game reliably, gradually increase the amount of time for the dog to sit before you cue the retrieve. 
    * If he breaks, as he inevitably will in the early sessions, simply pick up the dummy and reposition him at the line, then again cue "sit".
    * It's essential that you not cue the retrieve an instant after he breaks, since that reinforces the break. He must wait until you cue the retrieve, or you pick up the dummy.
  2. Once the dog is reliably waiting for the retrieve cue when the dummy is at arm's length, gradually introduce tossing the dummy while he is waiting.
  3. Once the dog is reliably waiting when you toss the dummy, use someone else to act as your "gunner", throwing the mark for your dog while he remains steady.
  4. Next, assuming the dog has been introduced to gunfire, have the gunner fire a blank pistol before throwing the mark.

##### Notes[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-20)]

  1. If the dog breaks and it becomes necessary to re-cue "sit", do not feed again. That would reinforce the undesirable behavior chain of breaking, then sitting.
  2. Some trainers do not use food in field training. Try the above method both with and without food a few times and see which gives you the most enthusiastic and reliable results with your dog.
  3. Some trainers take the dog's dummy (if he easily gives it up) and with a shout of "hey-hey", throw it again for him, or throw a second dummy, instead of inviting a game of tug. These simple retrieves are called _hey-hey dummies_. The advantage of tug is that it offers a high-drive game as the reinforcer for a high-energy return, as does a hey-hey dummy, but it also helps to build the dog's relationship with the trainer, which hey-hey dummies do not do as well. If it improves your dog's motivation, you could play tug, throw the dummy, and play some more tug before doing the next retrieve. Reinforcing the return with food is not preferred, since food tends to calm the dog and we want the retrieve to be high energy.
  4. On the other hand, some dogs will stop delivering the article to hand if you do not use food in the early stages of training. While that is the case, continue to use food, and then gradually begin to substitute tug and hey-hey throws for the food. A time will come when the dog will have little interest in food, and may even comically seem to be insulted by an offer of food. It is not necessary that the dog start with that attitude. It will come.
  5. Carefully watch the number of retrieves you do per session. If you see loss of interest, you've gone too long. Stop immediately, and next time, do a smaller number of reps. Some trainers do no more than three retrieves per session, and might well end the session after a single, especially high-quality retrieve. When the dog is then enthusiastically praised, watered, and crated, he can lie quietly and think about the great job he did on that most recent event in his memory, visualizing it again and again and integrating it into his future behavior. This visualizing process, often used by human athletes as well, can be more productive than a series of increasingly less focused, less motivated repetitions of the intended behavior.

### Swimming[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-21)]

Another name for retrievers is 'waterdogs'. Most retrievers will take to swimming, especially for retrieving, easily.

_**Important**_ The worst thing you can do is to throw the dog into the water. The second worst is to coerce him into the water.

Instead of using physical force or any sort of coercion:

  1. Find some fairly clear water with an easy entry and wade in as far as you dare. Hopefully your dog will follow you out there. If not, quit and try again another time.
  2. Once he is comfortable getting his feet wet, throw a dummy a foot or two from shore for the dog to chase.
  3. If you have already trained "[give it](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve#Training_.22Give_It.22)", you can cue for him to retrieve to hand. Otherwise, you can wade out to pick up the dummy to throw again.
  4. Very gradually increase the distance you throw the dummy into the water.
  5. Quit each session while the dog is still anxious to play. You want him to be in that state of mind until the next time you bring him to the water.

_**Note**_

If your dog did not follow you into the water, it's either because he doesn't tend to follow you anywhere, or because he found the water uncomfortable.

If you don't feel that he's afraid of the water, or you don't have the option of wading in, you could begin with a short retrieve.

If your dog doesn't tend to follow you around, that is a problem and should be addressed. See topics elsewhere such as:

  * [Building the Relationship](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Principles#Building_the_Relationship)
  * [Tug](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors#Tug)
  * [Tethering](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors#Tethering)
  * [Heeling](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills#Heeling)

### Introducing Gunfire[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-22)]

  1. Introduce loud noises such as pans and cookie sheets
  2. Play this game at home, then in the yard: Train noise as a recall cue: bang (softly at first), then feed; gradually, add distance and volume
  3. Play this game at home, then in the yard: Have "gunner" throw cookie sheet, then throw food on the cookie sheet (simulates running toward the gunner on a marked retrieve)
  4. Introduce gunfire at training and/or events. Key concept: The sequence for dogs new dogs needs to be rest or quiet activity, gunshot, instant opportunity for highly enjoyable stimulus such as treat, tug, chasing the trainer, or a thrown toy. Do _not_ have the gunfire occur while the high-value stimulus is in progress, or reverse conditioning may occur.

_(Note: I posted a more complete description to PGD list in December 2007. That might be worth copying here.)_

### Heeling[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-23)]

Heeling can be trained as the foundation for competitive obedience, rally, and musical freestyle, and possibly other canine sports as well, and a dog skilled in heeling can perform the behavior for dozens or hundreds of paces.

For the competitive field dog, heeling plays a much more limited role, coming to and leaving the starting line. As a result, it can be trained as a simple, short-distance chain of behaviors: sit, heel a few steps, then sit again.

#### Prerequisites[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-24)]

  * Sit
  * [Hand target](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Foundation_Behaviors#Hand_Target)

#### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-25)]

Here are the steps to train a simple, enthusiastic heel suitable for coming to and leaving the starting line:

  1. Start by working in a quiet location in the house, with minimal distractions.
  2. With dog at either side, cue sit (C/T).
  3. Lower the hand on the dog's side so that your palm is facing the dog, step forward and cue "touch", and when the dog touches your hand, cue "sit", then C/T with dog in sit position.
  4. Repeat until dog is performing the single step behavior smoothly and confidently.
  5. Repeat several more times and fade the "sit" cue.
  6. Repeat several more times, replacing "touch" with the cue you wish to use for heeling. If necessary the first few times, say the new cue word and then prompt with touch. Many trainers use "heel" as the cue for heeling, but because it sounds almost identical to "here", some use an alternative cue such as "with me".
  7. You may wish to continue using the hand target with your heeling cue. If you prefer to put you hand in a different position when coming to and leaving the line, such as swinging at your side or resting on your belly, repeat several more times with your hand in the position you would like to use. If necessary the first few times, start with your hand in the new position, then prompt with a hand target.
  8. When all of that is in place for a single step, train it for two steps, then three steps, and so forth.

Although dogs traditionally heeled on the left side, that is, opposite the side that the hunter carried his rifle, and although competitive obedience still requires heeling only on the left, it is advantageous for a competitive field dog to be able to heel on either side.

#### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Basic_Retriever_Skills&action=edit&section=T-26)]

  * If the dog's heeling is not consistently performed with enthusiasm, introduce that as a criterion for clicking. For example, you might C/T the most enthusiastic 70% of your reps, and not C/T the least enthusiastic 30%. Continue to raise the bar until all reps are at a high level of enthusiasm.
  * When the behavior is solid in a quiet location with minimal distractions, train it again in a new location with somewhat increased level of distractions. Continue to generalize for location and proof for distractions until the dog can sit/heel/sit even under competitive conditions.

## Marked Retrieve[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-1)]

### Prerequisites[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-2)]

Though you won't be relying on previously learned cues, you may want to train attention and hand-targeting to establish a foundation for you and your dog training together before training "give it".

Another prerequisite is that the dog consistently rushes to the thrown article (such as a knotted sock) and picks it up. That is natural behavior for many retrievers, but not necessarily for other breeds and possibly not for some retrievers. If your dog does not show that behavior yet, it is too soon to train "give it". First, you need to shape the dog to do that.

### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-3)]

Should this section use "fetch" or "give it"?

Once the prerequisites above are met, here are the steps to training "give it", the foundation for a reliable reward-based retrieve to hand:

  1. Use an article your dog is highly interested in and can comfortably carry in his mouth. A knotted sock works well.
  2. Snake the article around on the floor or in the air to get the dog interested in it.
  3. With the dog in front of you, toss the article into the space between you.
  4. The dog pounces to take the article in his mouth.
  5. At the same moment that the dog picks up the article, grasp the article with one hand.
  6. Hold onto the article until the dog voluntarily opens his mouth to release it. Do not attempt to take the article away from your dog. _**Important**_ The worst thing you could do would be to pry the article from the dog's mouth. That trains resource guarding and keep-away.
  7. At the moment that the dog opens his mouth, click and treat.
  8. Immediately toss the article again.
  9. After a few reps, throw the article so that the dog must turn away from you to put his mouth on it. When he lifts it, he should turn his head at least slightly back toward you. If he does so, grasp the article, hold it until he releases, click and treat. If he does not turn his head back toward you, go back to throwing a shorter distance for additional reps. Don't increase the distance of your throws until the pup is turning his head back to you.
  10. After a few reps of throwing the article just past the dog, gradually add distance, so that the dog has to move a bit away from you to get the article and then bring it back to you. As long as he is doing that, grasp, hold, and click and treat for the release as before.
  11. As you slowly add distance, if the dog stops bringing the article back, reduce distance as much as necessary to get back on track. It is normal in this and all training that the dog will seem to learn a behavior and then, in an instant, forget how to do it. Simply retrain as necessary, starting at the first step again if that's what's required.
  12. At you proceed, when a time comes that you can predict the moment that the dog will open his mouth, say "give it" the instant before. After doing that several times, you'll find that if the dog is not about to give you the article and you say "give it", he'll suddenly turn toward you and offer the article.
  13. It's exciting that the dog is now returning the article to hand on cue, but don't constantly attempt to test how much control you have with the cue. Instead, continue to say "give it" in the natural flow of the training.
  14. Gradually move the cue to earlier and earlier in the process, until you are cueing "give it" as you are throwing the article. But exercise caution not to inadvertently associate the cue with incorrect responses. Observe where your dog is in the learning process, and if you're not willing to bet $100 that he'll retrieve the article and give it to you, don't use the cue.

_**Note**_

The description above sounds as though the entire learning process occurs in a single session. That is unlikely. Limit each session to about ten clicks and treats, and use as many of those short sessions per day as you have time for, but _only_ when your pup shows great enthusiasm for the game. Always quit while the dog is still anxious to play more, so that that is the attitude he carries with him into the next session.

### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-4)]

  * Train each of several objects separately, generalize for location, proof for distractions
  * When ready, practice retrieves with several different kinds of articles in the same session to generalize the behavior (see Laddie's "give it" video)

### Carrying the Article[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-5)]

A retriever should carry the bird, or any other article she retrieves, fully in her mouth.

Some dogs do that naturally, at least for some articles. But many dogs do not carry all articles that way. For example, many dogs will pick a bird up by its head or a wing. Many dogs will also pick up a winged dummy by one of the attached wings.

Some trainers use a special kind of retrieval dummy called a Dokken (after its inventor) to help the dog learn to carry birds correctly. The Dokken looks like a bird and is available in a variety of "species". It's the correct size and weight, and its body has a soft texture that's comfortable in the dog's mouth. But the head and feet are hard and uncomfortable for the dog to hold, so the dog learns to carry the Dokken by its body.

Here is a drill for training the dog to carry any article correctly:

  1. Throw the article a short distance and send the dog with her name.
  2. If the dog picks the article up correctly, simply wait for her to bring the article to you. But if the dog begins to pick the article up incorrectly: 

    a. Say "stop" in a gentle tone while walking quickly to the dog.
    b. Gently pry open the dog's mouth and place the article into her mouth in the desired position.
    c. Say "wait", run a short distance, then spin around and call "Here!"
  3. When the dog arrives, gently take the article and immediately go back to Step 1.
  4. Repeat until the dog is consistently picking the article up and carrying it as desired.

### Reinforcers for Fetch[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-6)]

A time will come when your dog will return the article to hand because he has learned how exciting it is to do so, as a result of your throwing a "hey hey" dummy or initiating a game of tug. But in the early weeks of training "give it", he may not find those activities sufficiently reinforcing to return the article to hand, or he may not have been sufficiently conditioned to understand the relationship between return to hand and the reinforcer.

If that is the case, you can develop a strong habit of your dog returning the article to hand with sessions specifically devoted to exchanging the article for food (see Laddie's "give it" video).

You may also find that you don't need to use treats for land retrieves, but that the dog won't retrieve to hand from water. In that case, again, you can use food to build reinforcement history for the retrieve to hand wherever needed. Eventually, the dog will refuse food and will just want to play tug and/or for you to throw the article again.

Remember that for the game of tug, the toy you use matters. Your dog may find one toy significantly more reinforcing to play tug with than another.

### Practicing Fetch[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-7)]

For a reward-based trainer, "give it" is the equivalent of the traditional trainer's force fetch. The purpose of both games is to instill in the dog the reflexive response of picking up the retrieval article, bringing it to the handler, and holding it until the handler takes it. For a retriever, this is a make-or-break skill, so it is not something to train for a few days and then consider done. Even after the dog is retrieving reliably, any time you notice the fetch element of his behavior slightly less reliable than you want, it's worth devoting several yard sessions, perhaps in the evenings, to a "give it" drill.

#### Pile Work[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-8)]

Here's one example of a fetching drill:

  1. Put dog in a sit.
  2. Place several articles in a pile.
  3. With the dog sitting at heel, cue "give it".
  4. If the dog races to the pile, grabs an article in his mouth, races back, swings enthusiastically to heel, sits, and holds the article gently but firmly until you take it, that's the behavior you want. Let him know verbally, and in whatever other way you've found to be reinforcing for the particular dog. Although many trainers do not train retrievers with food, you may find that food is a great way to build enthusiasm for "give it" with particular dogs.
  5. If the dog is lacking in some aspect of the ideal picture described above, take the article quietly, gently bring him to sit at heel again, and again cue "give it". Whether you see an improvement or not in this next rep, reinforce it. Here's why: 

    — If you see an improvement, obviously you want to increase the likelihood that you'll get the new version rather than the previous one.
    — If you don't see an improvement and don't reinforce, you now have two reps in a row without the version you were looking for. That may mean that you've set your criteria too high for this dog in this session, so you need to lower your criteria or your rate of reinforcement will drop too low. In the meantime, you can give the dog a little reinforcement for staying in the game while you figure out what to change in your behavior.
  6. Your goal is to reinforce approximately 70-80% of the time. When you first raise your criteria, your reinforcement rate will drop to 70%. As the dog begins to respond to the differential information you're giving him and improves, his correct responses and reinforcement rate will increase. When it gets to around 80%, you can again raise your criteria.

#### Building Style[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-9)]

A dog grabbing a bird without even seeming to slow down as he races past it has visual appeal, or "style". Some dogs seem to naturally do this, but here's another "give it" drill that lets your dog learn a stylish pick-up, and builds his drive for fetching at the same time:

  1. Instead of having the dog start at heel, have him sit facing the pile some distance away.
  2. Then you go to the other side of the pile, again some distance away, and cue "give it".
  3. Instead of running out to grab the article, now he grabs the article as he runs past the pile.
  4. As before, use differential reinforcement to increase the version of the behavior you prefer.

### Retriever Zen[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-10)]

A crucial phase of a retriever's training is putting the retrieve on _stimulus control_, that is, training the dog to retrieve when cued to do so, and to not retrieve when not cued to do so.

In other words: _**To train the dog to retrieve, train the dog to not retrieve.**_ Lindsay Ridgeway calls this idea _retriever zen_.

An obvious reason why the dog needs to be able to make this distinction is that in advanced tests and some hunting situations, the dog must ignore diversions and retrieve only the article the dog has been sent to.

But this phase of training cannot wait until needed for advanced work. The reason is that retrieval articles, especially birds, and most especially warm birds, can become extremely valuable to retrievers, with the result that they dog would rather stop out in the field for some alone-time with the bird instead of completing the retrieve. This can happen with any retriever, but it's an especially difficult problem for one being trained with reward-based methods. Retriever zen is vital to preventing that from becoming a problem. _(Note: An explanation, or at least speculation, of why this is the case would be nice here.)_

Three drills can be used in combination to train this concept:

  1. Proofing Drill
  2. Speed Drill
  3. Confidence Drill

Each is discussed below.

#### Proofing Drill[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-11)]

The purpose of this drill is to proof the dog's recall for distractions.

It's a valuable recall drill for any distraction — food, toys, other dogs — but for the purpose of training the retrieve, progress through retrieval articles of increasing value and excitement to the dog. For example, you might progress through the following sequence:

  * Dummy (also known as a bumper): canvas or rubber, 2" or 3", with or without streamers, with or without throw cord, various colors
  * Winged dummy
  * Dead bird
  * Live wrapped bird (wings bound and head hooded)
  * Live shackled bird (feet tied and head hooded)

Here are the steps for the Proofing Drill:

  1. Place the distraction article on the ground.
  2. Walk the dog past the article, so the dog knows that it's there, then continue until far enough away that the dog is no longer glancing at the article.
  3. Throw a treat, such as a cube of freeze-dried liver, for the dog.
  4. As the dog runs to the treat, sidestep toward the distraction article.
  5. As soon as the dog has the treat, call "here" to bring the dog back to you.
  6. Immediately throw the next treat and again sidestep toward the article.
  7. Continue until the dog is running right over the article while running to the treat and returning to you on "here".
  8. _No-glance rule:_ If at any time, the dog glances at the article, you are too close. Move away, then begin inching closer again. The dog may actually trip on the article when you get to the end of the drill.

_**Important**_ The reason for the no-glance rule is that without it, this can be a frustrating game for the dog. Even if the dog is successful, frustration might give the game an unpleasant association, which could result in a deterioration, rather than improvement, in the dog's recall that may show itself in subtle ways, such as trying to play keep-away, in the days after the training.

The Proofing Drill may only be needed once with each article. In later sessions, if the dog is still able to be sent and called over the article, you can skip the Proofing Drill.

#### Cued/Not-Cued (CNC) Drill[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-12)]

The purpose of the CNC Drill is for the dog to learn that "back" means "retrieve". The goal is to refine that learning until the dog's performance of that complex behavior chain called a "retrieve" is unquestioned, reflexive, and performed with speed and exuberance.

Unfortunately, the CNC Drill can also be confusing to the dog. In earlier training, the dog discovered in herself a deep love of retrieving. Now she must discover the joy of retrieving only when cued to do so. That confusion may manifest itself if a variety of ways, such as the dog starting to run out to retrieval articles in field work and then looking up at the handler, apparently not sure what to do next. For that reason, the CNC Drill is used in combination with the Confidence Drill, which repairs that confusion and is described in the following section.

Here are the steps for the CNC Drill:

  1. Use a combination of the articles you've already used in the Proofing Drill above. Using a combination is important. Otherwise, you may discover later that the dog is no longer comfortable with some articles.
  2. Place the articles in a pattern. Some trainers use a straight line or a circle, with the articles separated from one another by about 20 feet. Some place the articles in a wide zigzag pattern, separated by about 10 feet from one another. Use a configuration, and enough distance between articles, so that the dog shows no inclination to skip the next article and go on to the one beyond it.
  3. With the dog on leash, walk the dog right over the top of each article. Shorten the leash to prevent the dog from retrieving any article, without jerking. _**Important**_ On occasion, you may be unsuccessful in preventing the retrieve. It is essential that these not be unpleasant experiences for the dog. An uncued retrieve can be repaired — in fact, that's the purpose of the CNC Drill. A negative association with retrieving may never be completely reversed.
  4. When the dog is able to comfortably walk over the articles without attempting to pick them up, begin to occasionally cue a pick-up. Always cue the pick-up with the dog's name, using the same inflection as you use for sending the dog to a mark. Cue several feet before you get to the article so that the dog leaps forward and pounces on the article.
  5. When the dog is ready, try running the drill without the leash. If the dog attempts an uncued pick-up, gently put the leash back on and continue. Eventually, the dog should be able to run the drill confidently without the leash. Many people take off the leash too soon, complicating and slowing the dog's learning process. Continue to use it until it's completely superfluous.
  6. When the dog is fluent with this drill, you should be able to continue walking at a brisk pace, or even running, and the dog should be able to pick up each article when cued and deliver it to your closest hand without stopping. In the earlier training, you may need to slow down, stop, or even loop around and retrace your steps in order for the dog to be successful with the pick-up.
  7. As soon as the dog delivers the article, praise the dog, transfer the article to your other hand, and toss it behind your back, so that it lands back where it was. Note: With a live duck, you need to place the duck on the ground rather than tossing it to prevent injuring it.
  8. Eventually, make whether or not you cue for each article as random as possible. If the dog has difficulty either retrieving, or ignoring, a particular article, include that problem more often in the mix until the dog is equally fluent retrieving, or ignoring, every article.
  9. At the end of each circle, reward the dog with enthusiatic praise, tug, happy dummies, and/or food.
  10. Practice in both directions.
  11. Always follow the Speed Drill with Confidence Drill (see below).
  12. When the dog is able to work fluently with widely spaced articles, begin to work to walk with the dog through articles that are scattered around near one another on the ground. When the dog is able to enthusiastically pick up the cued articles, and calmly ignore the uncued ones, the Retriever Zen training is complete and need no longer be practiced.

#### Confidence Drill[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-13)]

As mentioned above, although the Speed Drill is vital to the dog's understanding of the retrieve, it can detract from a dog's confidence and exuberance for the retrieve, especially when the dog first experiences it. To counter the demotivating effect of the Speed Drill, follow it with the Confidence Drill:

  1. Place the same articles used for the Speed Drill in a _pile_, that is, a small grouping. Note: The articles should not touch one another or the dog may pick up more than one article at a time, either intentionally or by accident.
  2. Walk some distance from the pile. Use whatever distance seems to be most fun for the dog.
  3. Using the dog's name, send the dog to the pile repeatedly until the dog has retrieved every article. Eventually, it should not be necessary to re-cue the dog to pick up the article when the dog arrives at the pile, but it may be necessary to do so in the early going.
  4. It is unnecessary for the dog to swing to heel and sit for each delivery. The goal is to maximize the reinforcing quality of the retrieval game, so use whatever form of delivery to hand seems most fun for the dog.
  5. For some dogs, you can build enthusiasm for the Confidence Drill by offering treats after some or all of the retrieves in the early sessions. These should be discontinued as the dog gradually shows high enthusiasm without them, because you want the dog focusing on the self-reinforcing quality of the retrieve, not on the treats.
  6. If the dog picks up all articles uncued and without hesitation, and enthusiastically brings each article back to you, you can do another Speed Drill in a subsequent session. If the dog does not do so, skip the Speed Drill and continue to run more Confidence Drills in future sessions until that is the case.

_**Important**_ The sequence of Speed Drill first, then Confidence Drill, is significant. Since the dog enjoys the Confidence Drill more than the Speed Drill, you want the dog to learn that the Speed Drill _predicts_ the Confidence Drill, not the other way around. That will give the dog an increasingly positive association with the Speed Drill.

### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-14)]

#### Doubles, Triples, and More[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-15)]

Once the dog is running singles nicely, you can begin working on multiple marks.

Initially, they are run as multiple singles. That is, one mark is thrown and run, then the next, and so on. Later, two marks are thrown in a sequence, then the dog retrieves one, then the other. Eventually, as many as five marks are thrown before the dog begins to retrieve them one after another.

For two marks thrown as singles, the short mark is usually thrown first, then the long mark. For two marks thrown as a double, the long mark is thrown first, then the short mark is thrown, then the short mark is retrieved, then the long mark is retrieved.

A dog must have a chance to practice multiples, but many trainers believe that even for the most advanced dog, 90% or so of the dog's retrieves should be singles. While memory for the marks is a valuable skill, the skill of highest importance is the ability to see where the bird (or dummy) has fallen and run straight to it.

Start doubles at 180 degrees, and if necessary, use a barrier as you reduce the angle. Dog must retrieve article sent to, and not switch to another article during send-out or return.

#### Obstacles[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-16)]

When the dog is running multiple singles, but even before he is running multiples, you can begin to introduce obstacles such as a log. In competition, the dog will need to go over those obstacles, not around them.

To train confidence with the obstacle, you can begin in the house using a narrow passage, and place an obstacle all the way across it. With you and the dog on one side, throw a favorite retrieval article to the other side, then cue "give it" and be ready with a click and a treat when the dog brings the article back.

Once the dog is bringing the article back over the obstacle, gradually move the obstacle into a more open area, so that there is more and more space on either side of the obstacle. You may find that the dog will go around the obstacle either on the send out, or the return, or both. If that happens, you may have given too much space. But you can also help the dog understand what you want with your clicker:

  * If the dog doesn't go over the obstacle both directions, don't click or feed, just take the article and throw it again. Stay close to the obstacle as you throw it to make over the obstacle the shortest path, and reach your hand partially over the obstacle as a visual target for him to come to when he comes back with the article.
  * If the dog does go over the obstacle both directions, click and treat, perhaps adding some enthusiastic praise, then throw the article again.

That procedure may not work for a dog for whom the opportunity to retrieve is so valuable that he doesn't care whether he gets the click and treat. But if you are working with a dog who is food motivated, and who has not eaten for several hours, he will realize within a few reps that he gets to retrieve again whether he goes over the obstacle or not, but he only gets food when he goes over it.

Continue progress in your home until the dog will go over the obstacle in a completely open room. Then generalize for location (initially, near the front or back door, later in various training areas). As you move outdoors, you'll probably stop reinforcing with food and start reinforcing with active games such as tug and "hey hey" dummies. As always, tug is preferred because it's better for developing the relationship, but also as always, the dog is the sole arbiter of what he finds reinforcing.

The dog will have more difficulty with some placements of the obstacle than others. For example, he may tend to go around obstacles that are mid-way between you and the retrieval article, or he may tend to go around obstacles that are more than a certain distance from you. Learn his weaknesses by trying everything, and practice until the weaknesses are cured. For example, if he goes over the obstacle when it's ten yards from you but goes around it when it's fifty yards away, then over a period of days, set the obstacle at ten yards, then fifteen, then twenty, and so forth.

#### Cover[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-17)]

In a session to practice entry into cover, you might proceed as follows:

  1. Select a finger of cover you will want the dog to cross through when the training is complete.
  2. Stand a yard or two inside the cover and throw to a point along the eventual path, but only a yard or two away from you, so that the dog retrieves entirely within cover.
  3. Lengthen those retrieves.
  4. Throw to the edge of the cover.
  5. Throw to just outside the cover.
  6. Throw to well outside the cover, the end point of the desired behavior.
  7. Move back to the edge of the cover yourself and throw to the same location.
  8. Move back to just outside the cover.
  9. Move well back outside the cover, to the starting line for the desired behavior.

Retrain in several locations, until the dog habitually angles through cover rather than cheating around it. Avoid asking for retrieves the dog is not ready for, since once he practices cheating, it will be more difficult to untrain. It's better to ask for something "too easy" and let the dog have an easy success, then to dig a hole by accidentally having the dog rehearse an incorrect behavior. And of course, reinforce the dog's successes well.

#### Hills[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-18)]

#### Water Re-entry[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-19)]

  * Dog needs to be able to cross a point of land and re-enter water in both directions
  * Also, double re-entry, that is, across two points of land

#### Flapping in Face[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-20)]

  * Use large, stuffed toys
  * Use moving toys

#### Dokkens[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-21)]

  * Train dog to carry a bird by body rather than head, wings or legs
  * Available in various sizes, "species"

#### Decoys[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-22)]

  * Dog needs to practice running past decoys
  * Dog needs to practice retrieving an article near a decoy
  * Decoys on land
  * Decoys on water

#### Boats[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-23)]

  * Dog needs to be comfortable in a boat, both out of water and in water
  * Dog needs to be comfortable retrieving past and near a boat, as with decoys
  * Dog needs to be comfortable with boats out of water as well as in water

### Retrieving a Dead Bird[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-24)]

Once your dog is reliably retrieving dummies to hand, the next thing you'll try him on is retrieving a dead bird, such as a duck. If possible, use a freshly killed bird. If the bird has been frozen, give it several days to thoroughly thaw.

Before trying a retrieve, simply throw the bird for the dog run to run to. Then one of these things will happen:

  * The dog will run to the duck, pick it up, and bring it right back to you.
  * The dog will run to the duck, possibly bring it part of the way to you, but before completing the retrieve, start to chew it or play with it, possibly dragging it off in a different direction.
  * The dog will run to the duck and refuse to pick it up.

If the first of those happens, you're in business. Simply begin to mix in practice with both dummies and ducks.

If the second one happens, the dog loves ducks. That's a _good_ thing. It will provide motivation when difficult challenges arise. But he has to be retrained to retrieve with this new article. Patiently retrain "give it" for a dead duck the way you previously did for a knotted sock or plush animal. If necessary, have the dog drag a long line while you're doing this so that you can catch him. Remove the line when he becomes reliable.

If the third one happens, assuming the dog is a retrieve, he probably still loves ducks, but not cold dead ones. So shape a retrieve for this new, difficult article.

Here's a description of how that might be done:

To be edited

On May 17, 2007, at 6:04 PM, Linda Conrad wrote:

> So, Lindsay, care to share how you got her to love to pick up > birds in 4 weeks time? I only ask because I'm struggling with this > issue right now - I jokingly said as soon as they start running hunt > tests with bumpers and Dokken ducks, we'll be MORE than ready!!!

Hi, Linda. Aren't Dokken's cool? We have a bunch of them, all different "species".

I should mention that it didn't take four weeks to get Lumi to love to pick up ducks, that took only a few minutes, but it took those same few minutes several times over a period of days, during which we had to start at the beginning of the process each time. Eventually, we didn't have to do again, since now Lumi seems all too ready to pick up ducks, but who knows, we may need to do it again some day if she loses that.

Other barriers also needed to be crossed in those four weeks. The actual progression was: 1st week, she wouldn't pick up a duck; 2nd week, she dawdled coming back on land retrieves; 3rd week, she picked up her first flyer (flier?); 4th week, Katie bar the door.

As for picking up ducks, we used shaping, or as it's also known, freeshaping. Although Lumi is a clicker dog, I didn't use a clicker because I felt that for this it would be superfluous. In addition, I didn't shape with food as I usually do (though perhaps I could have) because I felt we needed the best possible reinforcer, and for Lumi, that's swimming (an example of Premack reinforcement).

So each session went like this:

(1) Take a dead duck (preferably not too cold and in the best possible condition) plus a dummy and/or Dokken (I used both, I'll explain below) to the shoreline of some favorite swimming location. We used a fast-running creek, deep enough for Lumi to swim in, one of Lumi's favorite places in the world, about five minutes drive from home.

(2) Toss the duck on the ground near the water.

(3) Shape increasing interaction with the duck, reinforcing each correct response as follows:

(a) At the very instant of the response, Lumi receives a rousing send-out into the water (cue as marker), followed by me throwing the Dokken into the water just ahead of her, or upstream, or somewhere to make the swim the most fun possible. I used the Dokken for the water retrieves to help Lumi practice how to carry a duck.

(b) When Lumi comes back with the Dokken, bring her to heel, take the Dokken, and toss the dummy in the grass a few feet away, cueing "shake". In theory, this should keep me slightly drier than if she shakes as soon as I take the toy.

(c) When Lumi then brings the dummy back to me (again coming to heel), suddenly offer a game of tug (we use only the dummy for tug) for a few seconds.

(d) Finally, toss both toys on the ground, cue "leave it", and draw Lumi's attention back to the dead duck.

(e) Occasionally, I'd reverse the game of tug or the send out, or use only one of two. Lumi likes tug almost as much as retrieving. I don't want Lumi to know what reinforcer she'll get -- her motivation seems highest when I surprise her. (NOTE: Pretty much every field trainer I've met has warned me not to play tug with a retriever. Maybe I'll regret it someday. So far in our brief time in field training, I've seen no disadvantage and it has always had huge motivational benefit in other training.)

(4) As with any shaping I do with Lumi, the key is how I define "correct response" from one successive approximation to the next. For Lumi and me, it was something like:

  * Glance in general direction of the duck -- "GO OUT!" (I might

repeat this definition of a "correct response" or others two or three times, or go immediately to the next level on the next rep.)

  * Glance at duck itself without lowering head
  * Glance at the duck, lowering head slightly
  * Seem to sniff the duck a little
  * Touch nose to the duck -- (Sometimes after some progress, Lumi

stops giving the current level of response, and we'll back up to an easier level and resume from there.)

  * Place mouth on duck -- (When starting, you wonder if this will

ever happen, after seeing how Lumi felt about the duck at the beginning. But she had a strong incentive -- those go-outs, to figure out what it was going to take to be sent out again.)

  * Drag the duck one inch -- (When Lumi finally did that, I knew

that it would be smooth sailing from there, and it was.)

  * Drag the duck three inches, five inches
  * Slightly lift the duck
  * Lift the duck higher
  * Put the duck in my hand, which of course I made as easy as possible
  * "Retrieve" the duck after a toss about one foot away from my hand
  * Retrieve after a toss two feet away, then longer and longer

until I reach my throwing distance limit

  * Put down a "sight blind" with Lumi beside me, walk a short

distance away, send Lumi to retrieve (by now, she's coming to heel with the bird)

  * Put down a sight blind with Lumi waiting some distance away in a

sit, walk back to her, give her a treat her for waiting, then send her

  * Increase the distance on sight blinds
  * If available, recruit a bird boy for some longer marks (good

luck finding a bird boy, that's one of my biggest problems)

I should mention that one of my criteria for correct response is enthusiasm. I might reinforce one or two tentative responses if necessary, but I want to extinguish those (by not reinforcing them) as quickly as possible.

I have no idea if that exact progression will work on other dogs. Lumi and I have done a good bit of shaping in other activities over the years, so she knows this game well. That is, she knows that reinforcement is contingent on her own actions. I suspect that dogs who have not been shaped in the past may need time to learn that concept, but maybe I'm wrong, maybe any retriever would respond as Lumi did to the above sequence regardless of training background.

I know from other lists that people often have questions about shaping, such as, What if the dog just looks at me?, or What if the dog gets interested in something else instead of interacting with me? I'm sorry if no one on this list has such questions, but I'll give a brief answer in case someone does.

First, I'm not a shaping purist. Dogs (and all animals) are most drawn to salient stimuli, so I'm not above moving the duck around to make it more interesting, even though that's not pure shaping. I'm also not above moving around myself, such as moving to the other side of the duck, so that Lumi might brush the duck as she comes toward me. ("You touched the duck! YAY! Go OUT!")

Perhaps most important, I set my criteria at whatever level it takes for me to get a response I can reinforce quickly. I don't want twenty seconds to go by with Lumi just wondering what's going on. Did her eyebrow flicker? Good enough! "GO OUT!"

Then there's timing. Sometimes I watch people trying to shape and there's too much delay between the moment the dog committed to whatever the current criteria are, and the reinforcement. I consider half a second too long. At the very instant Lumi does whatever it is I'm looking for, that's the moment I burst into motion and voice.

So if the dog is just looking at you, move around, move the duck around, take any glance away from you as your criteria until you're getting some fluency with that. If the dog isn't in the game, make the game as easy as necessary by lowering your criteria so that she can get reinforcement quickly (three seconds is what I aim for), and of course use a high value reinforcer.

Sorry if I've given too much detail, just trying to answer as best I could. I hope if you try it you'll let us know how it goes.

### Retrieving a Live Bird[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-25)]

  * When the dog doesn't bring back the bird

    

  * Long line
  * As soon as dog releases bird, throw it again (repeat several times, so dog learns that is most likely outcome)
  * To strengthen the pattern, do this with all retrieves, not just live birds

#### Intrinsic Reinforcement[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-26)]

Lindsay: verify this paragraph, use a quote, give a page number In Susan Garrett's highly acclaimed _Shaping Success_, a time comes when Buzz, the Border Collie whose training history she is relating, sometimes chooses to play on the agility equipment rather than respond to Susan's cues. Susan sees that as an unacceptable decision on Buzz's part, and relates how she effects a diminished interest in the agility equipment and an increased interest in the handler within Buzz's psyche.

While that may be the perfect approach for training agility dogs and those in a variety of other canine sports, agility dogs do not have to swim 300 yards in ice cold water to get to their dogwalks. Since a Field Trial dog may need to do exactly that, along with overcoming other highly challenging obstacles, most FT trainers avoid any training method that risks diminishing the dog's motivation for birds.

But a dog that loves birds can also be a problem. The novice dog is at significant risk of running off with the bird, especially a fresh-killed or crippled flyer, rather than retrieving it to hand as he may have been trained to do with a bumper and even a dead bird.

What is the solution? The answer is not to diminish the dog's love of the bird, but to integrate that love with a love for retrieving that bird to hand.

### Helping[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-27)]

Once you've begun working on handling with the dog (whistle sits and hand cues for overs, angle backs, etc.), you may be tempted to help the dog on marks if he gets off line on the way to the fall.

Some trainers disagree with the handler helping the dog in that situation. In the first place, handling the dog on a mark can affect your score in competition. In addition, the dog can develop the habit of "popping", that is, turning to you for guidance instead of running to the mark with confidence, hunting with sight and scent as necessary.

Yet sometimes a dog will get too far afield for the retrieve to be successful if the dog is left on his own. One way to avoid handling the dog is to call him back, then reset his direction and send him again. Another way is to call "Help!" to the gunner who threw the mark. The gunner can then use a bird call, or "hey hey hey", or an arm swing, or actually throwing another article near the first one, to assist the dog, while you as the handler wait quietly at the line, as you would in competition while the dog is running to the mark.

### Group Training[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-28)]

Discuss the importance of training with a group of experienced trainers with competition goals similar to your own. You may find it impossible to find such a group that uses methods similar to your own, in which case, it is still essential that your dog experience the kinds of set-ups, for years on end, that will only be available if you train with such a group.

### Test Series[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve&action=edit&section=T-29)]

Because the problems that the dog learns to solve occur somewhat haphazardly when training with a group, you may find it beneficial in your private training to follow a more carefully designed sequence of events. For example, you may find that your dog has difficulty with increasing distance, with choice of a retrieval article (birds being more difficult to retrieve correctly than dummies), and momentum-inhibiting terrain (MIT), also known as "factors", such as cover change, water, wind, etc. (discussed above).

To train for all of those considerations in an organized way, you can use a series of "tests". The dog runs one test per session, typically one per day. If the dog passes the test, then you go on to the next one. If not, you train to repair the difficulty, then try the test again.

_(Describe the "Field Training Test Series", including phases, individual tests, and criteria for passing. Include a link to L&L's blog as a sample journal.)_

## Blind Retrieves[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-1)]

### Sight Blinds[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-2)]

  * Gives dogs confidence that a bird is out there, useful for multiple marks as well as for blinds
  * Lets the dog run with confidence, rather than developing a tentative send-out
  * Re-use the same sight blinds at various training locations day after day and help the dog develop memory skills, which may improve his memory for multiple marks as well
  * Sight blinds to a pile, to condition both "back" and "over" cues

### Handling[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-3)]

#### The Send-out[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-4)]

  * The locked-in stare
  * The cue: "back"

#### Back[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-5)]

  * Straight away from you
  * Used for send-out
  * Used from whistle sit

    — Spin either direction
    — Why use it? The dog is already going that direction 

    You anticipate that the dog is about to veer around a factor

#### Over[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-6)]

  * Left and right

#### Angle Back and Angle In[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-7)]

Although it is traditional to train "back" and "over" first, a case can be made for training the angle back and angle in first:

  * Let's think of directions as a clock face, with 12 o'clock being "back" and 6 o'clock being recall. Your visual cue is the hour hand on the clock face, and the dog's direction is that clock face lying on the ground. So, for example, you point directly to the right, 3 o'clock, and your dog is to run directly to the right. You point to the right but on an upward angle, about where the hour hand will be for 1:30, and your dog is to run toward 1-2 o'clock. You point to the left on an upward angle, and the dog is to turn away from you the other direction and run toward 10-11 o'clock.
  * Besides recall (6 o'clock), by far the most common directions are 10-11 o'clock on the left, and 1-2 o'clock on the right. These are called angle backs.
  * The second most commom directions are 9 o'clock and 3 o'clock. These are called overs.
  * Somewhat less common are 7-9 o'clock and 4-5 o'clock. These are called angle ins.
  * In terms of usefulness, it might seem best to train angle backs and overs as the highest priority since they are most common. But angle ins are much easier for you and the dog to discriminate from angle backs than overs are.
  * Therefore, you may find it best to train angle backs and angle ins until they are solid. At that point, you may find that the dog automatically knows what an "over" is without having to train it.

##### Prerequisites[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-8)]

  * "Give it"
  * Whistle "sit"
  * Steady sit until released

##### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-9)]

  1. Place a single dummy at between 1:00 and 2:00 on the clock face, and another between 10:00 and 11:00. Put the dog in the center of the clock face and stand directly in front of him, so that he is facing you and toward 6:00.
  2. Fold your hands into a prayer position and whistle "sit" (one tweet).
  3. At the very instant that the dog sits, reinforce his response by rapidly lifting your left or right arm straight out to the side, but at an upward angle. Use an open hand with the palm facing forward. While moving your hand, also move your body in the same direction, as though you were about to run toward the bumper on that side.
  4. If possible, do not use a verbal cue. Ideally, the dog will respond to the visual cue of your rapidly moving arm. The reason you'd like to skip using a verbal cue is that eventually your dog may be competing at distances where he can't hear you. If necessary, send him with the verbal cue "back", but fade that as soon as possible.
  5. When the dog picks up the dummy, whistle recall.
  6. When the dog returns the dummy to hand, reinforce well, with treats, praise, a hey-hey dummy, tug, or whatever maintains and increases the behavior.
  7. If necessary, put on the dog's lead so that you can throw the dummy back where it was and set up for the next rep.
  8. Practice both sides.
  9. Keep the sessions short and fun.

##### Switching[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-10)]

Some dogs will see that two dummies are out there and will want both of them. They may run to the one you send them to, but then, instead of returning to you, they'll head over to the other dummy.

When a dog interacts with a different bird/dummy than the one you sent him to, it's called "switching", and it's important that the dog not develop that habit. If you find that your dog switches during the initial training of angle backs:

  1. If possible, increase the distance between the dummies. The best situation would be where the dog is aware of, but not distracted by or attracted to, the dummy that is out of play.
  2. As soon as you release the dog, run behind him so that you are quite close to him by the time he picks up the first dummy.
  3. Then cue "give it". Because you are so much closer than the other dummy, and because he knows that "give it" will be highly rewarded, he'll return the dummy to you. At that point, you can throw a hey-hey in the opposite direction or reinforce in other ways, but block him from running to the other dummy or catch him if he gets past you. After reinforcement, put the leash back on him to set up for the next rep.
  4. Another method is to work with a barrier between the two dummies, such as a fence or hedge, starting the dog at a gap in the barrier.
  5. Over time, gradually reduce the distance you need to run with the dog to prevent switching, until you don't need to run with him at all.
  6. Then over more time, gradually reduce the distance between the dummies.

#### Lining[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-11)]

  * The send-out: 

    — Lining up the sit on either side
    — Focusing the eyes
    — Sending out with "back"
    — When to challenge the line: 

    – – In training, no sooner than 75% of the way if possible
    – – In competition, as soon as dog is off line
  * Holding the line

##### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-12)]

A drill known as the _wagon wheel_ is used to train lining:

  1. With dog watching and waiting, throw out a number of dummies in various directions.
  2. Choose one of the dummies.
  3. Walk with dog at heel toward the dummy.
  4. Cue "sit".
  5. Use hand on dogs side to focus dog's eyes on dummy. Train him that your hand tells him when he is looking the correct direction: 

    — Once dog is looking at dummy, keep hand in position while dog maintains stare.
    — Remove hand when dog looks away.
    — When dog looks back, replace hand.
  6. When stare is locked in, send with "back" cue.
  7. If he gets off line and goes to the wrong dummy: 

    — Occasionally, you can call him back to heel without letting him finish the retrieve, but that is highly de-motivating to some dogs.
    — Instead, you can let him finish the retrieve, then use a gentle, neutral tone to cue "sit", take the dummy, and throw it back where it was, without reinforcing the retrieve.
  8. If he goes to the correct dummy, reinforce in one or more ways (remember, the dog's behavior tells you what _he_ finds reinforcing), such as: 

    — Whistle recall as soon as he picks it up.
    — Cheer as he returns, such as with applause and/or "Yay!".
    — Play tug after he returns the dummy to hand.
    — Throw a happy dummy when he returns the dummy to hand.
    — Give him a treat when he returns the dummy to hand.
  9. Throw the dummy back out to its position.
  10. Repeat to a different dummy.

##### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-13)]

  * Increase the distances of the dummies.
  * Decrease the angles.
  * Gradually work with dummies that are different distances. Dogs tend to swerve off line to retrieve the closest dummy, so be patient.
  * Retrain in different and increasingly distracting locations.
  * Introduce more difficult distractions. For example: 

    — Send to a dummy when a dead bird is on either side.
    — Scent an area with a dead bird and then send the dog through that area to a dummy that is not in sight until the dog has gotten through the scented area.

### Handling 101: Pinball Drill[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-14)]

Here's a drill Lindsay Ridgeway used to strengthen Lumi's handling skills in the late summer of 2007. Lindsay liked the drill so much that he ended up using it as the _initial_ method of training handling to Laddie, then four months old:

  1. Prerequisite: Whistle sit.
  2. Use six surveyor's flags in a zig zag pattern leading away from the "start line". Space the flags according to your results over a series of training sessions. An initial spacing of 10 yards may be about right.
  3. Spend as much time as needed, possibly a few seconds, possibly a few sessions, to train the dog to run to between flags 5 and 6, and sit on single tweet of the whistle as he reaches the flag. Click and treat as he reaches the flag and responds to the whistle sit. If the dog bites the flag, don't reinforce that rep, and make a point of whistling "sit" well before he reaches the flag on future reps.
  4. When you start the training, you may find it most effective to run with the dog, then send him the last few steps as he locks onto the flag. Gradually reduce the amount of distance you are running with the dog, until you and the dog can start near flag 5, you can send him to flag 5, and then you can send him to flag 6 with minimum movement yourself.
  5. Continue to train, moving your starting point closer to flag 4.
  6. Add flag 4 to the training. Now the dog runs to flag 4 and sits on cue, then flag 5, then flag 6. As he sits at flag 6, sometimes you can run to him to reinforce, other times you can call him running to you and reinforce as he reaches you.
  7. In the same way, add flags 3, 2, and finally 1 to the training.
  8. As you practice this drill in session after session, the dog is learning the pattern of an actual cold blind, a narrow zig zag between the start line and the article being retrieved.
  9. Use as many sessions as you need to develop this invaluable skill. Keep each session short and always end while the dog wants to keep playing. 

    Continue editing here
  10. Over several sessions, make the diamond larger and larger. Soon, the dog should not be able to see the flags when he first goes out on each cast. This is especially true if you use orange flags, which are difficult for a dog to see until the dog is close.
  11. Add more flags to the course, enabling you to practice all the casts from a variety of distances.
  12. When the dog is ready, add a dummy or bird at the far end of the course. Place it so that the dog cannot see it until he is on the way from the last cast. Having the dog complete the retrieve takes extra time but builds motivation.
  13. To make the drill even more challenging, train the dog to ignore distractions and take the cast. Add distractions such as dummies or dead birds, first so far from the dog's line of travel that he barely notices them. Over time, move them closer to the dog's line. If the dog goes off line to one of the distractions, walk out to him, bring him back to the flag, walk back to the start line, and try again. If he again strays, you've moved the distraction too close too soon. If he gets it right, find a way to immediately reward him for his success.
  14. Similarly, gradually proof for other factors: obstacles such as logs for the dog to jump over, crosswinds, hills, and so forth.

To build the dog's love of the game, you may find it beneficial to occasionally and randomly leave the start line at the instant the dog sits and run out to reinforce, with food, petting, a game of tug, a thrown dummy, or anything the dog loves. Then put him back in his sit, go back to the start line, and give the next cast. You may find it best to reinforce a lot at first, then gradually introduce intermittent reinforcement, keeping the dog guessing as to whether this is the time that you're going to come running out.

#### Why Surveyor's Flags?[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-15)]

Here's a post to the PDG list describing the reasons behind using surveyor's flags for this drill:

On Aug 25, 2007, at 4:53 PM, Lindsay Ridgeway wrote:

Lumi and I started working on cold blinds about a month ago, and when we tried one with a Field Trial training group Wednesday afternoon, I realized that we needed to train more on our own before trying one with a group again.

As background, I began training Lumi overs and backs, angle backs and angle ins, months ago, and we've got a dozen or more schooled blinds we practice daily, one or two per location we happen to train at. We've also done many sight blinds at various distances up to 300 yards for months.

But when it comes to cold blinds, Lumi exhibits some of the same characteristics I've seen in other, more advanced dogs, all of whom are trained with e-collars:

  * "Do I really have to sit and/or change directions when I think I already know where the dummy/bird is?"
  * "I saw your visual cue to send me after the whistle sit, and here I am on my way, but am I going the right way? Gosh I hope you don't stop me and throw another cue at me, I'm doing the best I can."
  * "First you send me to the right, then you send me to the left. I'm starting to wonder if you even know where the bird is yourself."
  * "Whistle sit? Oh, I remember that. I was in the middle of a delicious run toward a dummy/bird in clear sight, but before I could get to it and bring it back to you, you made me screech to a halt, turn to face you, and sit. That was no fun. And not just once, but over and over again, every time we practiced handling. Every time you did it, that whistle sit became less and less appealing. Sure you'd send me again after the sit, but I was already on the way. Why couldn't I just keep going?"

BTW, Lumi has HD and arthritis in both hips. Sitting has never been her favorite thing anyway.

I could see from the beginning that sending Lumi toward a dummy and then stopping her before she got to it, so I could cast her in a different direction as in a baseball diamond, was de-motivating, but at first I figured she'd get over it. In reality, I think the opposite may have been happening. I think stopping her on the way to the visible dummies at "second base" may actually have been cumulatively undermining Lumi's reinforcement history for the correct response.

We also trained on carved out paths. I could send Lumi straight down the path, whistle a sit at the fork, and then cast her to one of several dummies on the various spokes from there. But I never found anyplace to practice that drill with much distance, and even that seemed to be de-motivating. "All those dummies out there, but I have to stop and turn to face you."

Trying to find a way to build motivation, I also tried sitting her in place, throwing dummies in different directions away from her, and then walking away to a "start line" at some distance from where I'd left her sitting. I think that drill improved her understanding of the casts, and it seemed to be fun for her, but it was such a different scenario from a cold blind that it only helped so much.

What I really wanted was a pin-ball set up, where I could send Lumi from target to target, and reinforce every sit in some way, such as throwing a dummy or running out to give her a bite of food.

But the first time I tried it, I realized what a disaster it was if I used dummies as the targets. Either she would pick the dummy up, meaning that she'd either want to bring it to me or she'd have to carry it to the next one, and THEN what would she do? Or I'd have to persuade her not to pick it up. Just great, training a dog to run to a dummy and NOT pick it up. After one session, I could see that using dummies as targets for pin ball was a mistake.

A couple of days ago, I hit upon what may be a solution for all these difficulties. I tried it that morning, with Lumi and even with little Laddie, and was pleased with the results. It trains the remote sit and the casts, and it's FUN. No running toward dummies and not being able to pick them up. Instead, both dogs were excited the whole time. At each sit, Lumi's body language gradually became, "I'm sitting, I'm sitting! What's next, Daddy, what's next?"

I used the same technique a couple more times for Lumi, stretching the pin-ball course out to 100 yards so far, and for the first time I have a dog running from target to target and throwing herself into a sit each time I whistle.

The solution was surprisingly simple. What I did was to set up my pin-ball course with surveyor's flags. Those are thin wire poles with small flags attached. You can buy bundles of them at the hardware store. I use the orange ones because I've heard that dogs can't see orange.

These were the advantages I was looking for:

  * The dog has no particular inclination to retrieve the surveyor's flags. Laddie (4 mo) wanted to bite them some, but it was pretty easy to show him that running to the next one was even more fun.
  * The further they are apart, the harder they are for the dog to see. At some point as you stretch out the distances, the dog is running the right direction based on your cast, trusting that eventually the target will come into sight, and sure enough, it does.
  * With no dummies in the field, you can focus your training exclusively on the cast and the whistle sit, and use any method you like (or rather, that the dog likes) for reinforcing each success. Lumi's favorite version of the game was the session when I had our "start line" next to a creek and sent her into the water as soon as she came racing back from the furthest flag.
  * You don't have to make the dog not pick up a dummy.
  * The dog has the satisfaction of knowing with confidence that she's given the correct response, because the flags provide a physical representation of the remote sit concept. By analogy, a novelist might describe a character carrying a knife, rather than just saying that the guy looked dangerous.
  * Once you've stretched your patterns out far enough, you can add a dummy at the end, out of sight until the dog has been cast from the last flag. Now you've got an actual cold blind, and a precise course in which to train the exact whistle sits and casts you wish to.
  * One day, the flags play such a small role in running the course that they become superfluous and are used only for tune-ups after that.

The idea of using surveyor's flags seems so obvious to me now, that I have to believe other people also use them. But I haven't heard or read of anyone else doing it, and when I mentioned the idea to a couple of my new training buddies, they looked at me like I had two heads. Since they use -R and aren't worried about building a +R history for their dogs' behaviors, they might not have much use for the idea.

Well, my goal was to have Lumi fall in love with whistle sits and remote casts. The surveyor's flags seem to be giving that result, so I thought I'd pass the idea along.

Maybe it will help someone else. Maybe someone can suggest an even better way to train remote casts. Or maybe someone can warn me of some shortcoming to the method I've described that I haven't realized yet.

### Handling 102: The Loopback Drill[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-16)]

While the angle-back is an excellent initial handling cue, one of the most common situations that requires handling is when the dog is tempted to "cheat", that is, to detour away from the direct path to the bird. He may detour:

  * To avoid an obstacle
  * To take a land route instead of a water route ("bank running")
  * To touch a land point instead of swimming past it
  * To avoid a headwind
  * To climb upward or downward on a hillside
  * To check out scented ground
  * To get to a diversion bird
  * For other reasons known only to the dog

In those kinds situations, using an angle-back may not be satisfactory, because the dog's score will be reduced, or the dog may be dropped from the competition, if he does not take the required route. Instead, you may need to undo the detour by sending the dog "over", directly to his right or left, often just a few yards, and then using a back or an angle-back to send him toward the bird on the original line. The dog's ability to respond correctly to "over", for each of the factors listed above, is a key handling skill.

One way to train "over" specifically to erase an attempt to cheat is with the loopback drill. Once trained, it looks like this:

  1. Place the dog in a sit next to an obstacle. For example, the obstacle could be an agility jump bar, a log, the shoreline of a water feature, a stiff crosswind, or halfway up a hillside. Eventually, the dog should practice all of the obstacles listed above.
  2. Place a dummy or bird behind the dog at 12 o'clock, some distance back, perhaps 20 yards.
  3. Stand in front of the dog at 6 o'clock.
  4. Cue "over" both with voice and visually. The dog runs directly to his left or right and overcomes the obstacle.
  5. When the dog has overcome the obstacle, whistle "sit". The dog sits, facing you.
  6. Cue an angle-back to the dummy (to train an angle-back, see "Handling 101: The Pinball Drill"). The dog runs to the dummy and picks it up.
  7. Whistle recall. The dog runs back and delivers the dummy.
  8. Reward the dog.

#### Training the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Blind_Retrieve&action=edit&section=T-17)]

Although your dog may be able to learn the loopback drill in a single session, he may not be able to do it correctly if you simply set the loopback course up as described and try to direct him through it.

To solve that, take as many sessions as necessary to train each of the individual components:

  * "Over" through jump bars or over a log in either direction, perhaps with a dummy on the other side for the dog to retrieve.
  * An angle-back to a pole where the dummy will eventually be placed, first halfway from the corner where you'll be whistle sitting him, then 3/4ths of the way, and so forth.
  * "Over" through an obstacle to a pole at the corner where you'll whistle sit the dog, followed by an angle-back to the pole where the dummy will eventually be placed.

## Problem Solving[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-1)]

### Barking[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-2)]

As discussed under "[Biting and Barking During Training](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Pinciples/Biting_and_Barking_During_Training&action=edit&redlink=1)" in the chapter "Principles", reinforcing a behavior while the dog is barking may reinforce the barking as well, so it's important not to do that.

Barking can also occur in other situations. Some of the problems, and suggested solutions, follow.

#### Barking in Crate[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-3)]

For dogs who bark in their crates, it's sometimes helpful to immediately cover the crate as soon as the dog begins to bark.

Once some trainers find that the dog won't bark with the cover in place, they begin to cover the crate as soon as they put the dog in.

Others prefer to wait until the moment the dog actually begins to bark. The advantage is that you can learn whether the dog actually prefers to have the crate covered:

  * If over time the dog stops barking while the crate is uncovered, that indicates that he doesn't like having the crate covered and learned to stop the behavior that was causing it to happen.
  * If over time the dog continues to bark when the crate is uncovered until you cover it, that indicates he found the having the crate covered pleasant and learned that barking was a way to get the cover in place.

#### Barking During Activities[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-4)]

Here's a method Lindsay Ridgeway used with Lumi and Laddie, his two Goldens, when each was a puppy and occasionally barked at other dogs in pet stores or to demand something in the kitchen. Douglas St. Clair, noting that this technique is too mild to be called a "time out", dubbed it a "time in":

  1. React every single time the dog barks.
  2. React at the very instant that the dog barks.
  3. If necessary, gently snap on the dog's lead. You can use a target hand or a verbal cue to bring him and keep him with you if that works.
  4. Walk some distance away to the most boring available location. Use a neutral or even cheerful demeanor. All that is happening is that the dog has made the choice of barking, and he is learning that his behavior predicts a particular consequence. That consequence is being taken out of the fun location. Harshness adds nothing useful to the lesson, and has the potential for diminising your relationship.
  5. Cue or gently press your dog into a sit. The reason why you might press your dog, rather than cue the sit, is that you're not training "sit" now. If he won't respond reflexively to a verbal or visual cue, you're distracting him from the learning the lesson at hand.
  6. Wait 10-30 seconds with him. You can stand or kneel beside him, you can pet him if you like. It is unnecessary to be unpleasant, but of course it should not be so much fun that the dog would rather do this than whatever he was doing before.
  7. After the boring wait, run back together to what you were doing.

#### Barking in Vehicle[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-5)]

Some dogs bark in the vehicle when waiting their turn for training with a group. They can use a lot of energy doing that, affecting their performance. In addition, it may annoy the other dogs and trainers, perhaps even affecting their performance.

It's possible that if you move the vehicle further from the activities, the dog will stop barking and rest, awaiting his turn. Over time, learning to rest between turns may become a habit and you won't need to continue moving the vehicle as often.

#### More about Barking[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-6)]

Perhaps it would be best to see if the following post has any useful information in it, and extract that information into a compact form for addition to the material above.

Here's a DogTrek post from Lindsay Ridgeway, responding to a question from a woman named Christina about her Golden puppy barking in his crate:

On Aug 27, 2007, at 9:01 AM, Lindsay Ridgeway wrote:

On Aug 27, 2007, at 12:14 AM, Christina wrote:

> He realized yesterday that he has a voice adn barks A LOT when he is > in his pen. I know that sometimes he is barking because he has to pee, > but often it's because he wants to be out with the rest of us. How > long should he be quiet before I let him out? I know with my other > dog, barking is a self-rewarding behavior... is ignoring him enough? > what about when I know he has to pee? Is it ok if he barks when he has > to pee? > > He is 13.5 weeks and very, very smart!

Hi, Christina. Congratulations on your Golden puppy. He sounds like a great dog.

I'm not an expert, but we have three Goldens in the house (among other creatures), including Laddie, my 4 month old. Laddie is the only one who spends any appreciable time in the crate, so I'll tell you about Laddie and crates:

  * We have three crates: one in my office (I often work at home), one

in the car (unlike the other dogs, Laddie only travels in the crate), and one in the bedroom.

  * Peeing has rarely been an issue. I always let Laddie out to pee

immediately before he goes into the crate and as soon as he comes out, and except when he used to sleep in the crate, he was rarely in for more than 2-3 hours at time, usually less. I've read that a two- month old can go three hours, a three-month old can go four hours, and so forth. I found with Laddie that after about the age of 9 weeks, he could go longer than that over night (six hours or more), but as I mentioned, I can't remember him ever having to go more than about three hours during the day. At about 3-1/2 months, I became confident enough in his ability to hold it that I let him take a nap with me in bed a couple of times, and when that went OK, my wife and I let Laddie start sleeping with us and the other two Goldens. He'll probably do that from now on, so he's not in his bedroom crate much any more, and doesn't bark when he is.

  * If your pup needs to pee more than the guidelines I mentioned

above, you might want to check with your vet about a possible medical issue. Laddie will pee pretty much every time he gets on the grass, but he doesn't have to go any more often than those guidelines.

  * For the office crate, Laddie generally barks when no one is in the

same room with him, but activities are in progress in an adjoining room. About two weeks ago, I began the practice of putting a blanket over three sides of his crate immediately at the very first bark. I believe that "immediately" and "very first" were both important. Two things happened. First, he'd stop barking within a minute or two. Second, after a few days of that happening, he stopped barking altogether at most of the times when he would have before, making it unnecessary to cover his crate for several days in row now. I read that experience to mean that the blanket took away whatever stimuli were triggering the barking, enabling him to relax, and also that Laddie gradually concluded that he'd rather have those stimuli than not have them.

  * I think the bark-suppression would have worked just as well if I'd

covered his crate as soon as I put him in for situations where I expected barking. But then he wouldn't have learned how to stop me from putting on the blanket, and I wouldn't have learned whether he prefers the blanket on or off.

  * For the vehicle crate, Laddie generally barks if he can see Lumi

(my big dog) and me training nearby while he awaits his turn. If I have the time, I move the vehicle further from where we're training, and Laddie quiets after a minute or two. I want him to learn to relax when it's not his turn, so that's my preferred approach, though sometimes I just have to let him keep barking. My hope is that in time, by my moving the van so that he can relax, he'll gradually develop the habit of relaxing between turns and I won't have to continue moving the vehicle.

I'd also like to mention some lifestyle issues that may or may not be relevant to the barking:

  * Laddie gets a lot of time with me. Besides just spending time

together, we train at least twice a day, usually more often. When we train, it's always highly active, generally outside, and involves a good bit of running and/or swimming. My intent is that Laddie have a distinct on/off switch, with the ability to play at full speed for short bursts, and then to thoroughly relax during the rest of his life. I've tried to create a schedule for him that promotes that rhythm.

  * Also on the idea of an on/off switch, Laddie and I have a daily

bodywork session. This is when I trim his nails if needed, clean his ears, go over every inch of his body massaging him and checking for ticks, give him his stretches, brush his coat, and brush his teeth. Of course, when I started this when he was seven weeks old, he was unable to relax during those activities. But he quieted gradually day after day, and now is almost as quiet as Lumi during those sessions. I can't prove that this carries over to a more general ability to relax, but maybe it does.

  * Laddie often gets food in his crate with him. This includes his

daily afternoon snack of a frozen chicken wing, the occasional treat- filled Kong, and me often walking over to the crate to give him a small piece of chicken jerky, half a cashew, or some other treat through the bars.

I've often read the rule that you should not pay any attention to the dog when he barks -- no talking (gentle or harsh), no letting him out, not even looking at him. Before I discovered the blanket trick, I followed that rule and asked everyone in the house to also honor it. I don't know if it made a difference, but it's possible it did. For example, maybe the blanket trick wouldn't have worked a month ago, but if we'd reacted to Laddie when he barked at that time, the blanket trick also wouldn't work now. I just don't know about that.

Good luck with the barking and everything else about your new pup. I hope you'll keep us up to date with your life together.

### Dropping the Article[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-7)]

Your dog will need to be able to go into a sit while holding an article. This can be surprisingly difficult for a dog, who may have a strong inclination to drop the article before sitting.

In addition, your dog will need an instant release, not when you grasp the article, but when you cue "out". The reason for not releasing when you grasp the article is that the dog can't judge whether you have a good grip and may drop the article on the ground, thinking you're ready for him to release it.

#### Shaping "Take It"[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-8)]

  * Start by using your finger as the "article".
  * In the first session, click and treat for the motion of grabbing your finger.
  * Be sure to click the bite, not the release.
  * When you can anticipate the moment of the bite, you can add a verbal cue such as "take it". You won't need this cue in the field, but it will help with training the hold.

#### Adding Duration[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-9)]

#### Adding "Sit"[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-10)]

#### Adding "Out"[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-11)]

#### Taking an Article[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-12)]

Once the dog can hold and out with your finger, train the entire behavior again from the beginning with a dummy.

#### Training the Hold[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-13)]

Here's a DogTrek post from Jody Baker describing how to train the whole process:

On Oct 13, 2007, at 2:01 PM, Jody Baker wrote:

It's sometimes hard on us people, when we start out wanting nothing more then to play at something, only to change our minds and suddenly want the dogs to stop all the stuff they've previously done and now do something not nearly as much fun for them.

Several very experienced people now recommend NOT using the clicker for duration with the retrieve. They use it just a bit at the beginning and then not at all after that. Other very experienced people use it the entire time. I'm one who doesn't use it for this particular behavior, I do not want the dog spitting/dropping the object when I click. I prefer to hold it and have the dog back away (move the head back). In other words I don't "take" it away from the dog, instead I put my hands on it and the dog removes his head when I say "give" or "out" or word of your choice. To me this is easier for the dog to understand.

An old retriever way of teaching "hold" is to use your finger. If it's a dog who mouths (which probably won't make any difference for a water dog) you can wear a leather glove. Basically it's putting your finger (I use my forefinger) behind the canine teeth, using the other fingers and thumb to hold the mouth closed, but not tightly. You can use your other hand on the collar to help keep the dog steady (most dogs throw their heads around, fling their bodies etc). You can tell the instance she slightly accepts holding your finger and release. The release is the reinforcement for her "hold" no matter how short that hold is at first.

You can shape her taking your finger if you want. I don't do that, too impatient, besides my dogs are use to me sticking my finger/hand in their mouth from puppy hood, it may be different for you. So I just open their mouth, put my finger in place and wait to see what happens.

The treat I use for doing this is canned cat food. You have the twin kitties (maybe more) so this shouldn't be a problem. I give the food on a spoon as I want the dogs to be OK with metal.

This takes how ever long it takes, some dogs quickly - just a day or two - other dogs maybe a couple of three weeks..

  * Step 1 is as described
  * Step 2 the dog opens her mouth for you to place your finger
  * Step 3 the dog reaches forward for your finger when it's presented
  * Goal - dog takes and holds finger as long as you want with no mouthing.

Now you're ready to use something else. I would start with a dowel about the diameter of your finger - maybe 6 inches long.

You'll want her accepting, reaching forward and holding various objects in the long run. A dumbbell is very good as it helps the dog understand how to pick up something, hold it in the center for balance. After that it will be easy to introduce the other things - ropes, etc that will be needed.

#### Anticipatory Response[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-14)]

As you and the dog work together, he will soon learn that every time he sits down with the article, the next thing that happens is that you grasp the article and take it. He will begin to anticipate that chain of events, and may begin to release the article prematurely, allowing it to drop to the ground.

To prevent his anticipating the "out" cue, you can train him a set of special rules using a dummy. The rule is that when you take the rope, or slide your hand from the dummy to the rope, it means that you are about to initiate a game of tug by trying to pull the dummy away from him, and he is allowed go into a game of tug with you. In this game, you will growl, and pull, and try but fail to take the dummy away from him. Besides enhancing your relationship with a cooperative game, tug is great fun for the dog, so he has a strong incentive to hold on tight, because if he doesn't, he'll "lose" the game.

Make both this game and the "out" cue highly reinforcing, so that the dog is equally happy whichever one occurs, and is waiting to be surprised by whatever is coming next.

### Not Returning with the Article[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-15)]

To be edited

On Aug 13, 2007, at 9:17 PM, kcip@comcast.net wrote:

> My 7-month-old Lab is very enthusiastic about running out to get the bumper/duck, but not so good about bringing it all the way back to me at the line. > Any tips for nipping this in the bud?

Hi, Kathy. Good question. Since no one else has replied yet, here are my thoughts.

First, the enthusiasm you mentioned is great, and IMO the most important thing. Whatever you do, you do not want to do anything to diminish your pup's desire.

Second, I've often heard that it's not unusual for dogs to behave as you're describing, and that later, some of those same dogs go on to become accomplished retrievers. Your dog loves not only the game of retrieving, but also the object, and that's a good thing. Someday the retrieves will require him to run straight through cover, to climb up and down steep banks, and to swim long distances, and he'll need a high level of desire to overcome the challenges.

Third, at 7 months, your dog may still be teething. If so, carrying the object may be causing him discomfort. Some trainers stop asking their dogs to retrieve until the adult teeth are in. I'm not clear on the timing of that, so maybe someone else can answer:

  * How do you know when to stop asking for retrieves?
  * How do you know when to start again?

Fourth, many trainers seems to separate out the game your dog is playing, and the Taught Retrieve. I think the idea is that, if the dog has not yet been through the Taught Retrieve training, you wouldn't necessarily expect a reliable return. I think your dog is almost to the age, maybe a month or two short, where you might want to carry out that training.

That said, I'd also like to add some specific thoughts on the return.

As a reward-based trainer who does not plan to use force/coercion/pressure to train your dog, you have several other tools available to you to deal with the issue: management, luring, and reinforcement. I've broken those out separately.

#### Management[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-16)]

Management means controlling the dog's access to undesirable reinforcers during the period while the dog is learning the desired behavior.

One kind of management for retrievers is to attach a long lead (maybe a 20' nylon rope) to the puppy's collar whenever training. That allows you to catch the dog and reel him in if needed.

Perhaps more important is choosing the right environment to train in. The basic idea is that if you can't get the dog to come to you in the environment you're currently working in, you shouldn't be working in that environment.

A hallway of the house with all the doors closed and minimal distractions leaves the dog little choice but to return. Once he's confidently returning in that context, you can open doors, gradually introduce distractions, and little by little move into more challenging environments.

#### Luring[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-17)]

Luring means showing the dog something to return to. When you use luring, you're not asking the dog to come to you because he's been trained to, you're asking him to come to you because you're showing him something he wants.

The risk of luring is that the dog may only learn to come to you while that lure is present. But used judiciously, luring can be a useful tool for getting the dog in the habit of coming back to you.

The choice of a lure depends not on you but on your dog. What will he come back to you for? Many dogs will chase you if you run away from them, so that's a great lure. Many dogs are attracted by high pitched voices. Another possibility is waving a toy. I found with my puppy that he'd come running if I dropped down into a play bow position. You can also use food as a lure, though there are arguments against that that I won't get into here.

#### Reinforcement[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-18)]

In the end, the most important tool for training the return is making it worth the dog's while. That's operant conditioning: the dog learns that something wonderful happens when he makes a particular choice. The next time he's presented with the same options, he'll be more likely to make the same choice again, and again something wonderful happens. After a substantial history of such reinforcement, that choice becomes habit, virtually reflex.

As with a lure, the choice of a great reinforcer is the dog's, not yours. You might WANT the dog to be highly reinforced by petting, for example, and some dogs are. But some aren't. The rule of thumb is, if the behavior increases (or a well-established behavior continues), it was reinforced. If it doesn't, it wasn't.

The reinforcement might come from the behavior itself. That's why your dog has that enthusiastic run-out. He loves doing it, possibly because it simulates the hunt of his ancestors. That's intrinsic reinforcement, and the behavior is sometimes called a self-reinforcing behavior.

Some behaviors are not immediately self-reinforcing, but later become self-reinforcing. A dog may not love swimming at first, for example, but after a few easy-going sessions gradually discovers what fun it is.

For a retriever, the most valuable reinforcement you can offer is typically another opportunity to retrieve. Again, there's that prey instinct.

Another way to tap into prey instinct is with the game of tug. My older dog's enthusiasm for the retrieve soared to a whole new level the day someone suggested I start playing tug with her when she got back with the article. The only thing I'll caution you about this, though, is that some trainers do not believe in playing tug with a retriever. I'm not sure if it's because they think it will develop a hard mouth, or because they think it will break the dog's "out", that is, willingness to give up the article when cued. I haven't found either to be the case with my dog.

Any of the ways I mentioned as luring might also work as reinforcement. The range is endless: besides throwing a dummy and offering a game of tug, other possibilities are praise, petting, a game of chase, rough-housing, and treats (again, note that some trainers do not use food for training retrievers). The key concept is that you don't decide what the dog finds reinforcing, the dog does. If you try to use praise as a reinforcer, for example, and the dog doesn't find praise reinforcing, then you are not going to get good results. Knowing this, you have the incentive to be a keen observer of how your dog responds to particular stimuli in particular environments.

I'd like to highlight the difference between luring and reinforcement:

  * Let's say the dog is on his way back to you. If you start swinging a dummy and calling hey-hey, that might make him come running to you, which makes you happy, but he hasn't learned from that experience to come to you when you're NOT swinging a dummy and calling hey-hey.
  * On the other hand, let's say that somehow the dog comes back to you (perhaps because of management or luring), and then at that very instant you begin swinging the dummy and calling hey-hey and then you throw it for him to chase. Now the dog has learned that something great happened when he got to you. After a few of those experiences, you won't need to entice him to come to you, because he'll be interested in the consequences of doing so, not the stimulus you used to get him to you.

A few other notes on reinforcement. First, just because a dog likes something doesn't mean it will reinforce behavior. The measure is whether the desired behavior increases. There's a good chance that offering the dog something he likes will increase the behavior he just completed, but it's not guaranteed.

Secondly, reinforcers tend to be context-specific. The dog may find a particular consequence reinforcing for one behavior but not another, reinforcing in one environment but not another, reinforcing on one day but not another.

Thirdly, the amplitude (effectiveness) of a reinforcer varies with Establishing Operations (EOs). Whether the dog is hungry will affect his enthusiasm for food. Whether he's tired will affect his enthusiasm for play. I'd say you want the dog to be fairly hungry and well-rested whenever training.

Sorry if I've gone past your intent when you asked for "tips", but without knowing you, I thought I'd try to cover the main bases.

Best of luck with your puppy. Please keep us up to date with your progress.

For a refresher course to build your dog's reinforcement history for the retrieve, see [Practicing Fetch](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Marked_Retrieve#Practicing_Fetch) in the chapter "Marked Retrieve".

#### Possessiveness[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-19)]

From private correspondence from Alice Woodyard to Lindsay Ridgeway on October 29, 2007:

"It sounds like you are being observant of their bird handling but remember that a bunch of repositioning of the bird, especially AFTER it has been picked up once, is a form of prey-possessiveness that is a close cousin to the not returning, eating, etc. It is a way to procrastinate the delivery and savor the prize. It is not "innocent" if you are seeing quite a bit of it. Not in a dog who is experienced with handling live game. Uh uh. The "N" on this one should go down with practice also. Also a big loop behind you to get into heel position, bigger than the dog normally needs to make, that's a form of parading with the prize, a form of "keep away" from you. As is any slight turning the head away right before the delivery or lowering the head to "get a better hold" when at heel and just before delivery. And of course any mouthing. These are all more little signs that the dog's head is not in the game the way you need it to be, not your game anyway."

### Slow Returns[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-20)]

To be edited

On Aug 25, 2007, at 8:41 AM, kcip@comcast.net wrote:

> Does anyone have some favorite drills/methods for getting your dog > back to the line? I've had him on a long line, but I'm thinking I > need to backtrack and do some drills separate from the actual > retrieving. He runs/swims out to the mark with lots of energy, but > slows down and stops before returning to me with the bumper/bird.

Hi, Kathy. The question I'd ask is, why SHOULD he rush back to the line?

Lumi had the same issue. So for several sessions, we practiced retrieves with our "start line" next to a creek. If I could, I'd get people to throw for me, otherwise I'd do poor-man's marks (Lumi in a sit, I go out and throw bumper, come back to her and send her). Either way, I reinforced every return with a rousing send-out into the water. Needless to say, after a rep or two, she was racing back for that chance to swim.

Then when we started training with a group, I took a chance on looking like a fool by doing the same thing with the group. Lumi would take her turn at the line, but as soon as she brought the bird back, instead of sending her out for another single or casually meandering back to our vehicle like every one else, I'd take her delivery of the bird just as calm as could be, and then, at the moment I had the bird, I'd spin on my heels and race off with Lumi to the nearest water, which was sometimes as much as 200 yards away.

After I'd done that a couple of sessions, I'd have her retrieve both birds, and THEN we'd go racing to the water.

You know what? A time came when she didn't seem to need those send outs to the water any more. She just seemed to enjoy running both ways. I call that "discovery training". The dog discovers that a behavior is fun, even though she didn't find it to be self- reinforcing at first. After that, the behavior maintains itself.

As for looking like a fool, that didn't bother me too much. No dog has a more enthusiastic return than Lumi, and some of the advanced ones I train with are like molasses.

### Beaching[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-21)]

### Cheating[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-22)]

_Cheating_ is the field trainer's name for a dog running around on land instead of swimming straight to the article, or back to the handler, on a water retrieve. Of course, the dog isn't doing anything dishonest, he's just trying to get to the article or handler as fast as possible, and he can run faster than he can swim. Other factors may also trigger cheating, and the term is also broader than water retrieves, and includes for example running around high cover on a land retrieve.

For some of the less advanced retriever titles, such as Working Certificate (WC) and Junior Hunter (JH), cheating doesn't disqualify the dog. But at the more advanced levels, the dog is trained to take a straight line. That training is called _de-cheating_.

A number of training methods exist for de-cheating on water retrieves:

  * One reward-based training method for de-cheating is called the _swim-by_ method.
  * Another reward-based training method for de-cheating is called _pole de-cheating_.
  * Most field trainers also rely on e-collars for de-cheating these days. Use of an e-collar does not fall within the scope of this book (see [Preface](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Preface)).

#### Swim By[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-23)]

The swim-by method require a technical pond with some fairly specific traits not necessarily available to all field trainers.

(details to be added)

#### Pole De-cheating[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-24)]

Here's a description of the pole de-cheating method, invented by Lindsay Ridgeway in July 2007 for de-cheating Lumi, his 3-1/2 year old female Golden:

##### The Game[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-25)]

  1. A prerequisite is that the dog has some experience with "over", a hand signal that sends the dog left or right. It's not necessary that the dog's response be perfectly reliable. In fact, if it were, you'd have no problem with cheating, you'd just cue "over" to keep the dog in the water.
  2. The set up is a straight or preferably convex shoreline, open water, and a pole of some kind in the water. For example, you could use a length of PVC pipe and wade out about 10 feet to push the pole into the floor of the pond.
  3. Stand at the neutral point on the shoreline, closest to the pole. Bring the dog to heel, and throw the dummy to the opposite side of the pole, then send the dog.
  4. When the dog turns back with the dummy, you are already the shortest swim back, so the dog has no way of cheating and will come straight back. But use an "over" cue to send the dog around one side of the pole or the other.
  5. Practice that a few times to be certain that the dog is reliably responding to "over" and swimming on the side of the pole you cue.
  6. Now move a few yards to the left or right for the next retrieve, and again throw the dummy over the pole. When the dog is swimming back, the shore may act as slight suction, but cue "over" to send her to the far side of the pole, thus keeping her away from the shore. If that doesn't work, you may have stepped too far down the shoreline, or you may need to work more on "over" around the pole by going back to practing at the neutral point.
  7. Since it's preferable that the dog not require handling, that is, not require you to cue "over", use extrinsic reinforcement (praise, tug, a hey-hey-dummy, food) to reward the dog when she takes the far side of the pole without having to be cued.
  8. When the dog consistently takes the far side of the pole, you can move a few yards further to reduce the angle between the shoreline, and the dog's swim path, even more.

##### Extending the Behavior[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Problem_Solving&action=edit&section=T-26)]

The pole de-cheating method can be gradually extended to an advanced version of the behavior:

  * Gradually move the starting line further down the shoreline from the pole, reducing the angle until the dog is swimming parallel to the shore.
  * Increase the distance the dog swims to get to the dummy. You can do this by leaving the dog in a sit while you go to place the dummy, or by taking the dog with you and then walking back to the starting line, or by having someone else place the dummy for you.
  * Place the dummy on land so that the dog swims in a straight line, climbs onto shore to retrieve the dummy, then re-enters the water to swim back.
  * Place the dummy on water on the other side of land, so that the dog swims to the far shore, crosses the strip of land, re-enters the water to retrieve the dummy, and then returns the same way in a straight line.
  * Switch to a smaller and smaller pole so that the dog becomes less and less dependent on that visual cue.

## Bibliography[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Bibliography&action=edit&section=T-1)]

### Email Lists[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Bibliography&action=edit&section=T-2)]

[DogTrek](http://groups.yahoo.com/group/DogTrek)

[PositiveGunDogs](http://groups.yahoo.com/group/PositiveGunDogs)

[Clicker_Gundog](http://groups.yahoo.com/group/Clicker_Gundog)

[ClickerSolutions](http://groups.yahoo.com/group/ClickerSolutions)

[Click-L_ABAT](http://groups.yahoo.com/group/Click-L_ABAT)

### Books[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Bibliography&action=edit&section=T-3)]

_Ruff Love_, by Susan Garrett

_Shaping Success_, by Susan Garrett

### Videos[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Bibliography&action=edit&section=T-4)]

_Sound Beginnings: Retriever Training with Jackie Mertens_, Younglove Broadcast Services, <http://www.ybsmedia.com>

## Authors[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Authors&action=edit&section=T-1)]

### Founding Author[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Authors&action=edit&section=T-2)]

**Lindsay Ridgeway**, with Golden Retrievers:

  * Lumiere-du-Soleil (Lumi) born October 24, 2003
  * Topbrass Lad of the Lakes (Laddie) born April 22, 2007

### Contributing Authors[[edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Authors&action=edit&section=T-3)]

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&oldid=1311126](http://en.wikibooks.org/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&oldid=1311126)" 

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=User%3ALindsay+Ridgeway%2FReward-based+Field+Training+for+Retrievers%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=User%3ALindsay+Ridgeway%2FReward-based+Field+Training+for+Retrievers%2FPrint+Version)

### Namespaces

  * [User page](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version)
  * [Discussion](/w/index.php?title=User_talk:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version)
  * [Edit](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&action=edit)
  * [View history](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version)
  * [User contributions](/wiki/Special:Contributions/Lindsay_Ridgeway)
  * [Logs](/wiki/Special:Log/Lindsay_Ridgeway)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&oldid=1311126)
  * [Page information](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&action=info)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=User%3ALindsay+Ridgeway%2FReward-based+Field+Training+for+Retrievers%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=User%3ALindsay+Ridgeway%2FReward-based+Field+Training+for+Retrievers%2FPrint+Version&oldid=1311126&writer=rl)
  * [Printable version](/w/index.php?title=User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version&printable=yes)

  * This page was last modified on 19 October 2008, at 18:07.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/User:Lindsay_Ridgeway/Reward-based_Field_Training_for_Retrievers/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
