# Pictures of Julia and Mandelbrot Sets/Print Version

From Wikibooks, open books for an open world

< [Pictures of Julia and Mandelbrot Sets](/wiki/Pictures_of_Julia_and_Mandelbrot_Sets)

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Pictures of Julia and Mandelbrot Sets](/wiki/Pictures_of_Julia_and_Mandelbrot_Sets)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&action=purge&printable=yes) this page.

  
  


# Foreword

## About This Book

This Wikibook deals with the production of pictures of Julia and Mandelbrot sets. Julia sets and Mandelbrot sets are very well-defined concepts. The most natural way of colouring is by using the potential function, though it is not actually the method most usually used. The book explains how to make pictures that are completely faultless in this regard. All the necessary theory is explained, all the formulas are stated and some words are said about how to put the things into a computer program.

The subject is primary pictures of Julia and Mandelbrot sets in their "pure" form, that is, without artificial intervention in the formula or in the colouring. Exceptions to this rule are techniques such as field lines, landscapes and critical systems for non-complex functions, that appeal to artistic utilization.

The book should not contain theory that has nothing to do with the pictures. Nor should it contain mathematical proofs. For our purposes faultless pictures are enough evidence of correct formulas, because the slightest error in a formula generally leads to serious errors in the picture.

If you find that something in this book ought to be explained in more details, you can either develop it further yourselves or advertise for that on the discussion page.

If you add a new picture or replace an illustration by a new one, it should be of best possible quality and have a size of about 800 pixels. Draw it twice or four times as large and diminish it.

## Julia and Mandelbrot sets

### Julia sets depend on a Rational Function

If a complex rational function is entered in the computer program and submitted to a certain iterative procedure, you get a colouring of the plane called a Julia set (although it is the domain outside the Julia set that is coloured). However, in order to get a picture that has aesthetic value the function must have a certain nature. It must either be constructed in a specific way to ensure that the picture is interesting, or it must contain a parameter, a complex number, that can vary. Being able to vary a parameter increases our chances of finding an interesting Julia sets for some value of the parameter.

What do we mean by 'interesting'? Essentially that the iterative procedure behaves in a somewhat chaotic way. If the iterative procedure's behaviour at each point is easily predicted for a particular function by behaviour of nearby points, then the Julia set for that function is not very crinkly, and rather uninteresting.

  


### A Mandelbrot set is an Atlas to the Related Julia sets

If we vary the parameter in our rational function we can produce a kind of 'map' of values that lead to interesting Julia sets. Values of the complex parameter correspond to points in the plane. The set of points that lead to interesting Julia sets gives us some information about the structure of the Julia sets for the parameter value at each point. Such a set is called a Mandelbrot set. The Mandelbrot set can be regarded as an atlas of the Julia sets.

The difference between the Mandelbrot set for the family and "its" Julia sets, is that the structure of the Mandelbrot set varies from locality to locality, while a Julia set is self-similar: the different localities are transformations of each other.

Sometimes you will prefer the more complex picture of the varying structure of the Mandelbrot set. Sometimes you will prefer the pure structure of the Julia set. Sometimes you will draw the Julia set because the drawing of the Mandelbrot set is slow for certain functions.

  


# The Julia set and the Fatou domains

Let ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) be a differentiable mapping from the complex plane ![\\mathbb{C}](//upload.wikimedia.org/math/f/0/b/f0b01fe0a1eec87c634584ac0694fb71.png) into itself. We assume first that ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is differentiable as a complex function, that is, that ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is a holomorphic function and therefore differentiable as many times as we like. Moreover we assume that ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is rational, that is, ![f\(z\) = p\(z\)/q\(z\)](//upload.wikimedia.org/math/4/8/7/487076fc0a21cc1bc6b4af9cff4d9b0f.png), where both ![p\(z\)](//upload.wikimedia.org/math/c/0/7/c07f09e1ca3053942a3e035409faa7c0.png) and ![q\(z\)](//upload.wikimedia.org/math/a/5/8/a5827c143f7d49ac84e4a10aac2b490c.png) are complex polynomials. If the degrees of ![p\(z\)](//upload.wikimedia.org/math/c/0/7/c07f09e1ca3053942a3e035409faa7c0.png) and ![q\(z\)](//upload.wikimedia.org/math/a/5/8/a5827c143f7d49ac84e4a10aac2b490c.png) are m and n, respectively, we call _d = m - n_ the degree of ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png).

The theory of the Julia sets starts with this question: what can happen when we iterate a point _z_, that is, what happens when we form the sequence ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) (_k = 0, 1, 2, ..._) where ![z_{k+1} = f\(z_k\)](//upload.wikimedia.org/math/5/5/f/55fbdc99f11f048f5c779c40030a2bf3.png) and ![z_0 = z](//upload.wikimedia.org/math/c/3/1/c3130f2b5221651fb09ccdf2f515e1f0.png).

### The three possibilities

Each sequence of iteration falls within one of these three classes:

  


    

    

    **1:** The sequence _converges_ towards a finite cycle of points, and all the points within a sufficiently small neighbourhood of _z_ converge towards the same cycle.
    **2:** The sequence _goes into_ a finite cycle of (finite) polygon shaped or (infinite) annular shaped revolving movements, and all the points within a sufficiently small neighbourhood of _z_ go into similar but concentrically lying movements.
    **3:** The sequence _goes into_ a finite cycle, but z is isolated having this property, _or_: for all the points _w_ within a sufficiently small neighbourhood of _z_, the distance between the iterations of _z_ and _w_ is larger than the distance between _z_ and _w_.

  
In the first case the cycle is _attracting_, in the second it is _neutral_ (in this case there is a finite cycle which is _centre_ for the movements) and in the third case the sequence of iteration is _repelling_.

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Juliasetsdkpictjulnew.jpg/220px-Juliasetsdkpictjulnew.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Five Fatou domains

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Juliasetsdkpictjulc.jpg/220px-Juliasetsdkpictjulc.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

One Fatou domain

The set of points _z_, whose sequences of iteration converge to the same attracting cycle or go into the same neutral cycle, is an open set called a _Fatou domain_ of ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png). The complement to the union of these domains (the points satisfying condition 3) is a closed set called the _Julia set_ of ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png).

The Julia set is always non-empty and uncountable, and it is _infinitely thin_ (without interior points). It is left invariant by ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png), and here the sequences of iteration behave chaotically (apart from a countable number of points whose sequence is finite). The Julia set can be a simple curve, but it is usually a fractal.

The mean theorem on iteration of a complex rational function is:

    

    

    

    _Each of the Fatou domains has the same boundary_

The common boundary is consequently the Julia set. This means that _each_ point of the Julia set is a point of accumulation for _each_ of the Fatou domains.

If there are more than two Fatou domains, we can infer that the Julia set must be a fractal, because _each_ point of the Julia set has points of more than two different open sets infinitely close, but this is "impossible" since the plane is only two-dimensional.

Therefore, if we construct ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) in a particular way, we can know for certain that the Julia set is a fractal. This is the case for Newton iteration for solving an equation ![g\(z\) = 0](//upload.wikimedia.org/math/e/b/d/ebde1c02bb1267461c98228aa0222a6b.png). Here ![f\(z\) = z - g\(z\)/g'\(z\)](//upload.wikimedia.org/math/d/b/0/db0e22b24e87502038b16a5faa90e4f6.png) and the solutions (that can be found by iteration) belong to different Fatou domains (consisting of the points iterating to that solution). The first picture shows the Julia set for the Newton iteration for ![g\(z\) = z^{5} - 1](//upload.wikimedia.org/math/e/b/8/eb8f94ecf9493017c0f6049a12f25b02.png). But a Julia set can be a fractal for other reasons, the next picture shows a Julia set for an iteration of the form ![1000\(1 - z\)/\(8 - 4z + 2z^{2} - z^{3}\) + c](//upload.wikimedia.org/math/4/a/b/4ab2126d4c9108d7eafedd6ab4fc8944.png), and here there is only one Fatou domain.

### The critical points

To begin with, we must find all the Fatou domains. As a Fatou domain is determined if we know a single point in it, we must find a set of points such that each Fatou domain contains at least one of these. This is easily done, because:

    

    

    

    _Each of the Fatou domains contains at least one critical point of ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png)_

A _critical point_ of ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is a (finite) point _z_ satisfying ![f'\(z\) = 0](//upload.wikimedia.org/math/9/9/0/9907568f1330e4375cca91f96fb76c28.png), or _z_ = ∞, if the degree _d_ of ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is at least two, or if ![f\(z\) = 1/g\(z\) + c](//upload.wikimedia.org/math/2/3/7/23732802122d3af9fe78e0acccdea007.png) for some _c_ and a rational function ![g\(z\)](//upload.wikimedia.org/math/1/7/a/17aa20a885a267996bffe03ac0f92a2e.png) satisfying this condition.

As we have presupposed that f(z) is rational, this means that there is only a finite number of Fatou domains.

We can find the solutions to ![f'\(z\) = 0](//upload.wikimedia.org/math/9/9/0/9907568f1330e4375cca91f96fb76c28.png) by Newton iteration: if _z*_ is a solution, a point near _z*_ is iterated towards _z*_ by ![z](//upload.wikimedia.org/math/f/b/a/fbade9e36a3f36d3d676c1b808451dd7.png) → ![z - f'\(z\)/f''\(z\)](//upload.wikimedia.org/math/7/1/a/71ab4656804439caf4be1753c71bda71.png). We can apply Newton iteration on a large number of regularly situated points in the plane, and register the different critical points (if the start point belongs to the Julia set of the iteration, it doesn't necessarily lead to a solution, likewise, we cannot be completely sure that we will catch all critical points, but for our task we should not care about this).

Here we will only deal with the attracting Fatou domains: a neutral domain cannot be coloured in a natural way, and unless ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is particularly chosen, it is improbable in practice that the Fatou domain is neutral.

We can find the different attracting Fatou domains in the following way: We iterate each of the critical points a large number of times (or stop if the iterated point is numerically larger than a given large number), so that the iterated point _z*_ is very near its terminus, which is possibly a cycle containing ∞, and we continue the iteration until the point is very near z* again. The number _r(z*)_ of iterations needed for this is the order of the cycle. Hereafter we register the _different_ cycles by removing the points _z*_ belonging to a formerly registered cycle. This set of points corresponds to the set of Fatou domains.

A Fatou domain can contain several critical points, and from the number of the critical points in the Fatou domains we can say something about the _connectedness_ of the Julia set: the fewer critical points in the Fatou domains, the more connected the Julia set.

### The attraction of the cycle

In order to colour a Fatou domain in a natural and smooth way, besides the order of the cycle we must know its _attraction_ ![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) \- a real number > 1:

For iteration towards an attracting cycle of order _r_, we have that if _z*_ is a point of the cycle, then ![f\(f\(...f\(z*\)\)\) = z*](//upload.wikimedia.org/math/3/0/4/304934b07d9962870575247dcc79405f.png) (the _r_-fold composition), and the attraction is the number ![\\alpha = 1/|\(d\(f\(f\(...f\(z\)\)\)\)/dz\)_{z=z*}|](//upload.wikimedia.org/math/e/8/c/e8c107e48fb1d0be9ccd409a704cd781.png). Note that ![\(d\(f\(f\(...f\(z\)\)\)\)/dz\)_{z=z*}](//upload.wikimedia.org/math/b/f/4/bf4365553dde84997b6adf51e0350c80.png) = the product of ![f'\(z_i\)](//upload.wikimedia.org/math/2/e/e/2ee35d6ca6712e8e5dced4aff3839ffa.png) for the r points of the cycle. If _w_ is a point very near _z*_ and ![w_r](//upload.wikimedia.org/math/6/2/b/62b8555eec1093b555329dd1588fecfc.png) is _w_ iterated _r_ times, we have that ![\\alpha = ](//upload.wikimedia.org/math/1/7/e/17eb927e31859ce116f5c64cbcc30d75.png)limw→z*![|w - z*|/|w_r - z*|](//upload.wikimedia.org/math/1/6/0/160dd871dfc8a39bb5af776b60635414.png).

However, this number ![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) can be ∞, namely if the cycle contains a critical point (meaning that the critical point is iterated into itself after _r_ iterations), and in this case the Fatou domain (and the cycle) is called _super-attracting_. We now set ![\\alpha = ](//upload.wikimedia.org/math/1/7/e/17eb927e31859ce116f5c64cbcc30d75.png)limw→z*![log|w_r - z*|/log|w - z*|](//upload.wikimedia.org/math/0/f/d/0fdcc658c5148ab7887fbec3603e80dd.png) or ![\\alpha = ](//upload.wikimedia.org/math/1/7/e/17eb927e31859ce116f5c64cbcc30d75.png)limw→∞![log|w_r|/log|w|](//upload.wikimedia.org/math/7/6/5/7656c79e0cf819b75d25d9c50240d0b3.png) if _z*_ = ∞.

In the last case, that is, ∞ being a critical point and _belonging_ to the cycle, we have _|d|_ > 1 and ![\\alpha = |d|^{r}](//upload.wikimedia.org/math/1/e/e/1ee4312314f3696e98a7b1f9c46de379.png). In this case we assume that ∞ is a fixed point (_r_ = 1), so that _d_ ≥ 2 and ![\\alpha = d](//upload.wikimedia.org/math/8/c/9/8c9caf201b3ad9d350f67a4332ccab8b.png) (we thus ignore a function such as ![1/\(z - c\)^{2} + c](//upload.wikimedia.org/math/d/b/b/dbba4a71c56aa7d710404a799bc3802e.png), for which the attracting cycle is {_c_, ∞}).

In a case using Newton iteration to solve an equation ![g\(z\) = 0](//upload.wikimedia.org/math/e/b/d/ebde1c02bb1267461c98228aa0222a6b.png) (so that ![f\(z\) = z - g\(z\)/g'\(z\)](//upload.wikimedia.org/math/d/b/0/db0e22b24e87502038b16a5faa90e4f6.png)), the Fatou domains (containing a solution) are super-attracting, and ![\\alpha = 2](//upload.wikimedia.org/math/9/7/d/97d3ea61f35d26c469ef39400d43f1a6.png) (if the solution is not a multiple root).

### Colouring the Fatou domains

Our method of colouring is based on the _real iteration number_, which is connected with the _potential function_ ![\\phi\(z\)](//upload.wikimedia.org/math/6/b/f/6bf906ca163fa54c0433ff4c5af8ea82.png) of the Fatou domain. In the three cases the potential function is given by:

    ![\\phi\(z\) = ](//upload.wikimedia.org/math/6/0/c/60cba576b63ee85aab3d7d375552bbb7.png)limk→∞![1/\(|z_{kr} - z*|\\alpha^{k}\)](//upload.wikimedia.org/math/2/4/4/244b1ce5c05a746c2a1cd103a903dedf.png) (non-super-attraction)
    ![\\phi\(z\) = ](//upload.wikimedia.org/math/6/0/c/60cba576b63ee85aab3d7d375552bbb7.png)limk→∞![log\(1/|z_{kr} - z*|\)/\\alpha^{k}](//upload.wikimedia.org/math/f/6/4/f643d7145f9e74b063205c79794a1e45.png) (super-attraction)
    ![\\phi\(z\) = ](//upload.wikimedia.org/math/6/0/c/60cba576b63ee85aab3d7d375552bbb7.png)limk→∞![log|z_k|/d^{k}](//upload.wikimedia.org/math/e/e/8/ee8946542646fd8b03d4ef04fe29d302.png) (_d_ ≥ 2 and _z*_ = ∞)

The real iteration number depends on the choice of a very small number ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png) (for iteration towards a finite cycle) and a very large number N (e.g. 10100, for iteration towards ∞), and the sequence generated by _z_ is set to stop when either ![|z_k - z*| < \\epsilon](//upload.wikimedia.org/math/3/4/f/34fbc1bcf642618c79318fef2f60a9bb.png) for one of the points _z*_ (corresponding to the Fatou domains) or ![|z_k| > N](//upload.wikimedia.org/math/a/2/0/a208db82a67d811d61fabbceb1bb1aac.png), _or_ when a chosen maximum number M of iterations is reached (which means that we have hit the Julia set, although this is not very probable).

If the cycle is not a fixed point, we must divide the iteration number _k_ by the order _r_ of the cycle, and take the integral part of this number.

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Juliasetsdkpictplay.jpg/220px-Juliasetsdkpictplay.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Nice play of colours

If we calculate ![\\phi\(z\)](//upload.wikimedia.org/math/6/b/f/6bf906ca163fa54c0433ff4c5af8ea82.png) for the _k_ that stops the iteration, and replace ![|z_k - z*|](//upload.wikimedia.org/math/5/1/d/51d7b4a174bea1a6711de92456b38046.png) or ![|z_k|](//upload.wikimedia.org/math/7/1/8/718ade53904a4b7da7a19fda8cc34e4e.png) by ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png) or N, respectively, we must replace the iteration number _k_ by a real number, and this is the real iteration number. It is found by subtracting from _k_ a number in the interval [0, 1[, and in the three cases this is given by:

    ![log\(\\epsilon/|z_k - z*|\)/log\(\\alpha\)](//upload.wikimedia.org/math/9/a/d/9ad71d67763eb189e0bae8ce67898943.png) (non-super-attraction)
    ![log\(log|z_k - z*|/log\(\\epsilon\)\)/log\(\\alpha\)](//upload.wikimedia.org/math/3/d/0/3d0e23d9a77b4da55e4330cbe42a6c9a.png) (super-attraction)
    ![log\(log|z_k|/log\(N\)\)/log\(d\)](//upload.wikimedia.org/math/8/d/d/8dd3c9bd09137170896b4a67d75f1f1d.png) (_d_ ≥ 2 and _z*_ = ∞)

In order to do the colouring, we must have a selection of cyclic colour scales: either pictures or scales constructed mathematically or manually by choosing some colours and connecting them in a continuous way. If the scales contain H colours (e.g. 600), we number the colours from 0 to H-1. Then we multiply the real iteration number by a number determining the _density_ of the colours in the picture, and take the integral part of this product modulo H. The density is in reality the most important factor in the colouring and if it is chosen carefully, we can get a nice play of colours. However, some fractal motives seem to be impossible to colour satisfactorily and in these cases we have to leave the picture in black-and-white or in a moderate grey tone.

### Colouring the Julia set

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Juliasetsdkpictjuldist.jpg/220px-Juliasetsdkpictjuldist.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Julia set drawn from distance estimation

In order to get a nice picture, we must also colour the Julia set, since otherwise the Julia set is only visible through the colouring of the Fatou domains, and this colouring changes vigorously near the Julia set, giving a muddy look (it is possible to avoid this by choosing the colour scale and the density carefully). A point _z_ belongs to the Julia set if the iteration does not stop, that is, if we have reached the chosen maximum number of iterations, M. But as the Julia set is infinitely thin, and as we only perform calculations for regularly situated points, in practice we cannot colour the Julia set in this way. But happily there exists a formula that (up to a constant factor) estimates the distance from the points _z_ outside the Julia set to the Julia set. This formula is associated to a Fatou domain, and the number given by the formula is the more correct the closer we come to the Julia set, so that the deviation is without significance.

The _distance function_ is the function ![\\delta\(z\) = \\phi\(z\)/|\\phi'\(z\)|](//upload.wikimedia.org/math/3/9/c/39cb45c17d28116620b5550011e43e83.png) (see the section _Julia and Mandelbrot sets for non-complex functions_), whose equipotential lines must lie approximately regularly. In the formula appears the derivative ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) of ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) with respect to _z_. But as ![z_k = f\(f\(...f\(z\)\)\)](//upload.wikimedia.org/math/c/c/1/cc1dad8919d403bfbc0c05134e150418.png) (the k-fold composition), ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) is the product of the numbers ![f'\(z_i\)](//upload.wikimedia.org/math/2/e/e/2ee35d6ca6712e8e5dced4aff3839ffa.png) (_i = 0, 1, ..., k-1_), and this sequence can be calculated recursively by ![z'_{k+1} = f'\(z_k\)z'_k](//upload.wikimedia.org/math/f/a/c/faca0e5524c1b2b329b9248003081223.png) and ![z'_0 = 1](//upload.wikimedia.org/math/7/f/5/7f5642825dbbc0db419c9b868b006e5b.png) (_before_ the calculation of the next iteration ![z_{k+1} = f\(z_k\)](//upload.wikimedia.org/math/5/5/f/55fbdc99f11f048f5c779c40030a2bf3.png)). In the three cases we have:

    ![\\delta\(z\) = ](//upload.wikimedia.org/math/f/8/0/f8004950d5b8383aa0d83a5daf61a89d.png)limk→∞![|z_{kr} - z*|/|z'_{kr}|](//upload.wikimedia.org/math/6/a/5/6a51b6ea30e8cfdfd63a5d74cf139ae0.png) (non-super-attraction)
    ![\\delta\(z\) = ](//upload.wikimedia.org/math/f/8/0/f8004950d5b8383aa0d83a5daf61a89d.png)limk→∞![log|z_{kr} - z*||z_{kr} - z*|/|z'_{kr}|](//upload.wikimedia.org/math/f/2/e/f2e3ab3ac3f89b67e9f7e9174e7c30b4.png) (super-attraction)
    ![\\delta\(z\) = ](//upload.wikimedia.org/math/f/8/0/f8004950d5b8383aa0d83a5daf61a89d.png)limk→∞![log|z_k||z_k|/|z'_k|](//upload.wikimedia.org/math/d/f/f/dff04493b827cc349592667a07efc43c.png) (_d_ ≥ 2 and _z*_ = ∞)

If this number (calculated for the last iteration number _kr_ \- to be divided by _r_) is smaller that a given small number, we colour the point _z_ dark-blue, for instance.

### Lighting-effect

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Juliasetsdkpictlightpot.jpg/220px-Juliasetsdkpictlightpot.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Lighting-effect with the potential function

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Juliasetsdkpictlight.jpg/220px-Juliasetsdkpictlight.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Lighting-effect with the distance function

We can make the colouring more attractive for some motives by using lighting-effect. We imagine that we plot the potential function or the distance function over the plane with the fractal and that we enlight the generated hilly landscape from a given direction (determined by two angles) and look at it vertically downwards. For each point we perform the calculations of the real iteration number for two points more, very close to this, one in the _x_-direction and the other in the _y_-direction. The three values of the real iteration number form a little triangle in the space, and we form the scalar product of the normal (unit) vector to the triangle by the unit vector in the direction of the light. After multiplying the scalar product by a number determining the effect of the light, we add this number to the real iteration number (multiplied by the density number).

Instead of the real iteration number, we can also use the corresponding real number constructed from the distance function. The real iteration number usually gives the best result. Using the distance function is equivalent to forming a fractal landscape and looking at it vertically downwards.

The effect is usually best when ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is a polynomial and when the cycle is super-attracting, because singularities of the potential function or the distance function give bulges, which can spoil the colouring.

### The field lines

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/15/Juliasetsdkpictfield.jpg/220px-Juliasetsdkpictfield.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Field lines

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Juliasetsdkpictfield2.jpg/220px-Juliasetsdkpictfield2.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Field lines

In a Fatou domain (that is not neutral) there is a system of lines orthogonal to the system of equipotential lines, and a line of this system is called a _field line_. If we colour the Fatou domain according to the iteration number (and _not_ the real iteration number), the bands of iteration show the course of the equipotential lines, and so also the course of the field lines. If the iteration is towards ∞, we can easily show the course of the field lines, namely by altering the colour according to whether the last point in the sequence is above or below the x-axis, but in this case (more precisely: when the Fatou domain is super-attracting) we cannot draw the field lines coherently (because we use the argument of the product of ![f'\(z_i\)](//upload.wikimedia.org/math/2/e/e/2ee35d6ca6712e8e5dced4aff3839ffa.png) for the points of the cycle). For an attracting cycle _C_, the field lines issue from the points of the cycle and from the (infinite number of) points that iterate _into_ a point of the cycle. And the field lines end on the Julia set in points that are non-chaotic (that is, generating a finite cycle).

Let _r_ be the order of the cycle _C_ and let _z*_ be a point in _C_. We have ![f\(f\(...f\(z*\)\)\) = z*](//upload.wikimedia.org/math/3/0/4/304934b07d9962870575247dcc79405f.png) (the r-fold composition), and we define the complex number ![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) by

    ![\\alpha = \(d\(f\(f\(...f\(z\)\)\)\)/dz\)_{z=z*}](//upload.wikimedia.org/math/1/4/e/14e38ae2f2d2275f012a8af29980e131.png).

If the points of _C_ are ![z_i \(i = 1, 2, ..., r, z_1 = z*\)](//upload.wikimedia.org/math/c/a/8/ca82e112a230d37e4f844aaa1ad20419.png), ![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) is the product of the _r_ numbers ![f'\(z_i\)](//upload.wikimedia.org/math/2/e/e/2ee35d6ca6712e8e5dced4aff3839ffa.png). The real number 1/![|\\alpha|](//upload.wikimedia.org/math/8/c/6/8c6f3d71aa6f8a40e72a88af21464d39.png) is the attraction of the cycle, and our assumption that the cycle is neither neutral nor super-attracting, means that 1 < 1/![|\\alpha|](//upload.wikimedia.org/math/8/c/6/8c6f3d71aa6f8a40e72a88af21464d39.png) < ∞. The point z* is a fixed point for ![f\(f\(...f\(z\)\)\)](//upload.wikimedia.org/math/3/9/a/39ab7c4d07eeb5d7589f4fdc8c893a44.png), and near this point the map ![f\(f\(...f\(z\)\)\)](//upload.wikimedia.org/math/3/9/a/39ab7c4d07eeb5d7589f4fdc8c893a44.png) has (in connection with field lines) character of a rotation with the argument ![\\beta](//upload.wikimedia.org/math/0/7/1/071997f13634882f823041b057f90923.png) of ![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) (so that ![\\alpha = |\\alpha|e^{\\beta i}](//upload.wikimedia.org/math/1/3/c/13ca534997cc9321ae70fc99db3e304e.png)).

In order to colour the Fatou domain, we have chosen a small number ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png) and set the sequences of iteration ![z_k \(k = 0, 1, 2, ..., z_0 = z\)](//upload.wikimedia.org/math/2/b/f/2bf1ee22a544cedbd4ccef400926ae07.png) to stop when ![|z_k - z*| < \\epsilon](//upload.wikimedia.org/math/3/4/f/34fbc1bcf642618c79318fef2f60a9bb.png), and we colour the point _z_ according to the number _k_ (or the real iteration number, if we prefer a smooth colouring). If we choose a direction from _z*_ given by an angle ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png), the field line issuing from _z*_ in this direction consists of the points _z_ such that the argument ![\\psi](//upload.wikimedia.org/math/1/9/d/19df1c2726ed43128440c1157f72a937.png) of the number ![z_k - z*](//upload.wikimedia.org/math/d/2/2/d2205de443996242c3196a05dcadad12.png) satisfies the condition

    ![\\psi - k\\beta = \\theta \(mod 2\\pi\)](//upload.wikimedia.org/math/c/6/b/c6b9baae7aaf4156127bd84d5c93e2dc.png).

For if we pass an iteration band in the direction of the field lines (and away from the cycle), the iteration number _k_ is increased by 1 and the number ![\\psi](//upload.wikimedia.org/math/1/9/d/19df1c2726ed43128440c1157f72a937.png) is increased by ![\\beta](//upload.wikimedia.org/math/0/7/1/071997f13634882f823041b057f90923.png), therefore the number ![\\psi - k\\beta \(mod 2\\pi\)](//upload.wikimedia.org/math/a/9/9/a99557d164f39f911db964d846908c12.png) is constant along the field line.

A colouring of the field lines of the Fatou domain means that we colour the spaces between pairs of field lines: we choose a number of regularly situated directions issuing from _z*_, and in each of these directions we choose two directions around this direction. As it can happen, that the two bounding field lines do not end in the same point of the Julia set, our coloured field lines can ramify (endlessly) in their way towards the Julia set. We can colour on the basis of the distance to the centre line of the field line, and we can mix this colouring with the usual colouring.

Let _n_ be the number of field lines and let _t_ be their relative thickness (a number in the interval [0, 1]). For the point _z_, we have calculated the number ![\\psi - k\\beta \(mod 2\\pi\)](//upload.wikimedia.org/math/a/9/9/a99557d164f39f911db964d846908c12.png), and _z_ belongs to a field line if the number ![v = \(\\psi - k\\beta \(mod 2\\pi\)\)/\(2\\pi\)](//upload.wikimedia.org/math/e/9/e/e9e2bf99338af7b5f6395230f7250657.png) (in the interval [0, 1]) satisfies _|v - i/n| < t/(2n)_ for one of the integers _i_ = 0, 1, ..., _n_, and we can use the number _|v - i/n|/(t/(2n))_ (in the interval [0, 1] - the relative distance to the centre of the field line) to the colouring.

In the first picture, the function is of the form ![z/2 + 1/\(z - z^3/6\) + c](//upload.wikimedia.org/math/f/b/f/fbf0d8859c36e70fd3c9be5317d47d1a.png) and we have only coloured a single Fatou domain. The second picture shows that field lines can be made very decorative (the function is of the form ![z/\(1 + z^3\) + c](//upload.wikimedia.org/math/8/d/0/8d02f541228e3a524483f5180b9796dc.png)).

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Juliasetsdkpictfield3.jpg/220px-Juliasetsdkpictfield3.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Pictures inlaid in Field lines

A (coloured) field line is divided up by the iteration bands, and such a part can be put into a ono-to-one correspondence with the unit square: the one coordinate is the relative distance to one of the bounding field lines, this number is _(v - i/n)/(t/(2n)) + 1/2_, the other is the relative distance to the inner iteration band, this number is the non-integral part of the real iteration number. Therefore we can put pictures into the field lines. As many as we desire, if we index them according to the iteration number and the number of the field line. However, it seems to be difficult to find fractal motives suitable for placing of pictures - if the intention is a picture of some artistic value. But we can restrict the drawing to the field lines (and possibly introduce transparency in the inlaid pictures), and let the domain outside the field lines be another fractal motif (third picture).

### Filled-in Julia sets

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Juliasetsdkpictfilled.jpg/220px-Juliasetsdkpictfilled.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Filled-in Julia set for ![z^3 + c](//upload.wikimedia.org/math/c/6/7/c67084c91c188530b98aa6f8cd08dd5f.png)

The complement to a Fatou domain is called a _filled-in_ Julia set. It is the union of the Julia set and the other Fatou domains. The outer Fatou domain is usually that containing ∞, and the filled-in Julia set is usually coloured black, like the Mandelbrot set. The program is easier to write, but it runs more slowly, because the maximum iteration number is reached for the black points. As the fine Julia sets frequently only have a single Fatou domain, you can as well make such an easier program that only colours a single Fatou domain. You choose a point in the outer Fatou domain and iterate this a large number of times in order to find the attracting cycle, and then the filled-in Julia set consists of the points that are not iterated towards this cycle. If the degree of the rational function is at least two, the filled-in Julia set for the Fatou domain containing ∞ consists of the point whose sequence of iteration remains bounded.

  


# The Mandelbrot set

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Juliasetsdkpictpretty.jpg/220px-Juliasetsdkpictpretty.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Interesting Julia set

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Juliasetsdkpictugly.jpg/220px-Juliasetsdkpictugly.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Ugly Julia set

In appearance a Julia set can go from one extreme to the other. And if we have a family of functions containing a complex parameter _c_, we will observe that by far the majority of _c_-values the Julia set is completely without interest. In fact, the attractive Julia sets are extremely rare.

And these Julia sets are just found by considering a family of iterations and from this constructing a set in the plane that can serve as an atlas of the Julia sets, in the sense that if we find an interesting locality in this set, we can be certain that some part of the pattern at this place will be reflected in the (self-similar) structure of the Julia sets associated to the points here. Such a set is called a _Mandelbrot set_.

Therefore, if we have a function ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png), we introduce a complex parameter _c_ in it, usually by addition: ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png).

### Construction of the Mandelbrot set

The construction of the Mandelbrot set is based on the choice of two critical points ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) and ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) for the function ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png): The Mandelbrot set (associated to the family ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png) and the critical points ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) and ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png)) consists of the complex numbers _c_, such that the sequences of iteration (by ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png)) starting in ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) and ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png), respectively, do **not** have the same terminus. This set is usually coloured black.

### Colouring the domain outside the Mandelbrot set

That a point _c_ is lying outside the Mandelbrot set, means that the second critical point ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) is lying in the same Fatou domain (for the iteration ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png)) as the first critical point ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png), and we can give _c_ the colour of the point ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) in this Fatou domain.

In order to draw the Mandelbrot set and colour the domain outside it, we must have chosen a maximum iteration number M, a very small number ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png) (for iteration towards a finite cycle) and a very large number N (for iteration towards ∞).

If ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) = ∞ (and _d ≥ 2_, so that ∞ is a critical point and a (super-attracting) fixed point) we need of course not iterate ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png): we iterate ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) (by ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png)) and if ![|z_k|](//upload.wikimedia.org/math/7/1/8/718ade53904a4b7da7a19fda8cc34e4e.png) > N for some iteration number _k_ < M, then _c_ is lying outside the Mandelbrot set, and we colour _c_ in the same way as we have coloured a _z_ in a Fatou domain containing ∞. If we have reached the maximum iteration number M, we regard _c_ as belonging to the Mandelbrot set.

If ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) is a finite critical point and if the iteration of ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) (by ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png)) is running to the maximum number of iterations M is reached, the terminus is most probably a finite attracting cycle that is not super-attracting (if not, there can be a fault in the colour of the pixel, but this is without significance in practice). If the last point of this iteration is _z*_, _z*_ belongs to the cycle, but we must know the order and the attraction of the cycle. Therefore we continue the iteration: starting in _z*_ and running until ![|z_k - z*| < \\epsilon](//upload.wikimedia.org/math/3/4/f/34fbc1bcf642618c79318fef2f60a9bb.png), then the number of iterations needed for this is the order _r_ of the cycle, and we calculate the attraction ![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) in the same way as before: 1/![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) is the product of the numbers ![|f'\(z_i\)|](//upload.wikimedia.org/math/b/1/7/b17b4b8b163807e01368e0c6a171e087.png) for the _r_ points of the cycle. We hereafter iterate ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) (by ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png)), and stop when ![|z_k - z*| < \\epsilon](//upload.wikimedia.org/math/3/4/f/34fbc1bcf642618c79318fef2f60a9bb.png). If this iteration runs until the maximum number of iterations M is reached, we regard _c_ as belonging to the Mandelbrot set. If ![|z_k - z*| < \\epsilon](//upload.wikimedia.org/math/3/4/f/34fbc1bcf642618c79318fef2f60a9bb.png) for _k_ < M, we colour _c_ according to _k_, or rather, the corresponding real iteration number, which is found in the same way as for a Fatou domain, by dividing _k_ by _r_ (and taking the integral part) and from this number subtract ![log\(\\epsilon/|z_k - z*|\)/log\(\\alpha\)](//upload.wikimedia.org/math/9/a/d/9ad71d67763eb189e0bae8ce67898943.png).

If the cycle contains ∞, that is, if the iteration of ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) is stopped by ![|z_k|](//upload.wikimedia.org/math/7/1/8/718ade53904a4b7da7a19fda8cc34e4e.png) > N for _k_ < M, we let ∞ be the chosen point of the cycle, and we continue the iteration until we again have ![|z_k|](//upload.wikimedia.org/math/7/1/8/718ade53904a4b7da7a19fda8cc34e4e.png) > N, then the number of iterations needed to do this is the order of the cycle. We then iterate ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) (by ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png)), and stop when ![|z_k|](//upload.wikimedia.org/math/7/1/8/718ade53904a4b7da7a19fda8cc34e4e.png) > N. If this iteration runs until the maximum number of iterations M is reached, we regard _c_ as belonging to the Mandelbrot set. If ![|z_k|](//upload.wikimedia.org/math/7/1/8/718ade53904a4b7da7a19fda8cc34e4e.png) > N for _k_ < M, we colour _c_ according to _k_, or rather, the corresponding real iteration number, which is found in the same way as for a Fatou domain, by dividing _k_ by _r_ (and taking the integral part) and from this number subtract ![log\(log|z_k|/log\(N\)\)/log\(|d|^{r}\)](//upload.wikimedia.org/math/8/a/7/8a7d3454132475785f5997ba5cf5767a.png).

### Colouring the boundary of the Mandelbrot set

That a point _c_ is lying outside the Mandelbrot set, means that the second critical point ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) is lying in the same Fatou domain (for the iteration ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png)) as the first critical point ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png), and the estimation of the distance from ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) to the Julia set, in this Fatou domain, is an estimation of the distance from _c_ to the boundary of the Mandelbrot set. So, the boundary of the Mandelbrot set can be coloured in the same way as a Julia set, but now the derivative of ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) is not with respect to _z_, but with respect to _c_.

If we set ![g\(z\) = f\(z\) + c](//upload.wikimedia.org/math/e/8/3/e83d78623957e5ffe2b3b02643af71b5.png), we have ![z_k = g\(g\(...g\(z\)\)\)](//upload.wikimedia.org/math/7/4/2/742df17ef40ee43af6281f06b0376a8d.png) (the k-fold composition)(the start value z is first ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) and then ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png)), and we find the derivative ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) of ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) with respect to _c_ by recursion: we have ![z'_{k+1} = f'\(z_k\)z'_k + 1](//upload.wikimedia.org/math/b/a/5/ba5de6d3a2bc77e2f322073e960db0db.png), and we find ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) successively by performing this calculation for each iteration, starting with ![z'_0](//upload.wikimedia.org/math/9/6/b/96b6b8185c2952aa104d02f5b6e720f9.png) = 0, together with (and _before_) the calculation of the next iteration value ![z_{k+1} = f\(z_k\) + c](//upload.wikimedia.org/math/f/5/4/f54495d56ca7304fcee1a10d08b33e0f.png), starting with _z_ = ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) and ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png), respectively.

As well as finding the point _z*_ in the cycle by iterating ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) M times, we now also calculate the derivative _z*'_ of _z*_ with respect to _c_, and when iterating ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) towards the cycle, we now also calculate the derivative ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) of ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) with respect to _c_. The formulas for ![\\delta\(z\)](//upload.wikimedia.org/math/3/e/1/3e1ba9c3052842170e80b767442a1329.png) are for the two cases:

    ![\\delta\(z\) = ](//upload.wikimedia.org/math/f/8/0/f8004950d5b8383aa0d83a5daf61a89d.png)limk→∞![|z_{kr} - z*|/|z'_{kr} - z*'|](//upload.wikimedia.org/math/6/9/8/698ac96f5477dd7160fa6148812878fb.png) (non-super-attraction)
    ![\\delta\(z\) = ](//upload.wikimedia.org/math/f/8/0/f8004950d5b8383aa0d83a5daf61a89d.png)limk→∞![log|z_k||z_k|/|z'_k|](//upload.wikimedia.org/math/d/f/f/dff04493b827cc349592667a07efc43c.png) (_d_ ≥ 2 and _z*_ = ∞)

When the value of this number for the last iteration number is smaller than a given small number, we colour the point _c_ dark-blue, for instance.

### Why the Mandelbrot set serves as an atlas of the Julia sets

If we choose a point _c_ near the boundary of the Mandelbrot set, then the Julia set for ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png) will have a (self-similar) structure that has some features in common with the Mandelbrot set at that locality. In the simple case ![f\(z\) = z^{2} + c](//upload.wikimedia.org/math/8/5/6/856b4de6cb4c3523090e58caaa9125d3.png) (the usual Mandelbrot set), the structure of the Julia set for _c_ is exactly the same as the local structure of the Mandelbrot at _c_, but this is usually not the case for general rational functions, only that the structure of the Julia set reflects the local structure of the Mandelbrot set.

Why is this? When _c_ is inside the Mandelbrot set, the sequence generated by ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) does not converge to the terminus of the sequence generated by ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png), and this means that the two Fatou domains containing ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) and ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png), respectively, are different. But when we let _c_ pass over the boundary of the Mandelbrot set, the two sequences now have the same terminus, so that the two Fatou domains become identical. Because one of the Fatou domains has now disappeared, we can infer that the Julia set for ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png) must change in a significant way (it becomes less connected).

It is only when _c_ is near the boundary of the Mandelbrot set that we can predict something about the Julia set, but as there usually are several critical points, we can choose another pair and draw a new Mandelbrot set. Note that if we use two finite critical points and if we invert these, then the black is unaltered, but the colouring and the boundary can alter: the colour is determined by the value in ![zc_2](//upload.wikimedia.org/math/b/b/d/bbdfaff6221c3be3c347091940eb1211.png) of the potential function of the Fatou domain for _c_ containing ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png). In order to get the most aesthetic colouring, we must use the value of the potential function in one and the same point (the second critical point) as _c_ varies. When _c_ passes the boundary of the Mandelbrot set, a Fatou domain disappears, but it is only when the second critical point leaves the Fatou domain, that we get the natural colouring and the boundary.

### The usual Mandelbrot set

For the family ![f\(z\) = z^{2} + c](//upload.wikimedia.org/math/8/5/6/856b4de6cb4c3523090e58caaa9125d3.png), there are two critical points, 0 and ∞, and therefore only one Mandelbrot set. This set consists of the points _c_ such that the sequence generated by 0 (by ![z^{2} + c](//upload.wikimedia.org/math/c/2/d/c2d9e7d195b10b43be48af4db7f274bd.png)) remains bounded. For _c_ outside the Mandelbrot set the sequence converges to ∞, and we can colour according to the number of iterations needed to bring the points outside a large circle with centre in origo. If we only colour according to the iteration number and if we do not draw the boundary, this circle needs only to have radius 2.

For this family, the Julia set for _c_ has two Fatou domains when _c_ is inside the Mandelbrot set, and one when _c_ is outside. When _c_ is inside the Mandelbrot set, the Julia set is connected, and when _c_ is outside, the Julia set is disconnected (and more than that: totally disconnected - a dust cloud - because of the self-similarity). For _c_ belonging to the boundary, the Julia set is connected, but it does not enclose an interior Fatou domain (this can be regarded as degenerated): the Julia set is just a fractal line with a "nose" and a "tail" and a "spine" connecting these two points.

The usual Mandelbrot set consists of an infinite system of cardioids and circles, all lying outside each other and some touching. When we zoom in, we find a swarm of _mini-mandelbrots_. Such mini-mandelbrots (possibly deformed) appear in the Mandelbrot set for **every** complex (differentiable) function, even for transcendental functions (see the picture in the section [Julia and Mandelbrot sets for transcendental functions](/wiki/Pictures_of_Julia_and_Mandelbrot_Sets/Julia_and_Mandelbrot_sets_for_transcendental_functions)).

### The different types of Mandelbrot and Julia sets

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/01/Juliasetsdkpictman24.jpg/220px-Juliasetsdkpictman24.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

![\(z^{2} + z^{4}/2\)/\(2 - z^{2}/20\) + c](//upload.wikimedia.org/math/0/d/b/0dba0ce940243cdbbf4aa3847fdad32d.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Juliasetsdkpictmannew.jpg/220px-Juliasetsdkpictmannew.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

![\(1 + 3z^{4}\)/\(4z^{3}\) + c](//upload.wikimedia.org/math/1/1/8/1180d9e2e61b3ab2ab671059268326cd.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/77/Juliasetsdkpictman23.jpg/220px-Juliasetsdkpictman23.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

![\(1 - z^{2}\)/\(z - 0.01z^{2} + 0.004z^{3}\) + c](//upload.wikimedia.org/math/3/5/f/35fe12ea6d49924d6e866bdf4e902bb0.png)

Of all Mandelbrot sets the usual is the one that possesses most localities of beauty. All other Mandelbrot sets are more or less ugly in their entirety, especially when the function is not a polynomial. In return, it is in such Mandelbrot sets that we can be lucky enough to find the most interesting and original shapes.

When we draw the Mandelbrot set for different rational functions, of course some types of shape will recur, and it should be possible to classify these shapes. We cannot refer the any work in this direction, we can only state the most elementary differentiation:

1\. d > 1 (m > n + 1). Then ∞ is a critical point and a super-attracting fixed point, and we usually use this as the first of the two critical points. For ![f\(z\) = \(z^{2} + z^{4}/2\)/\(2 - z^{2}/20\) + c](//upload.wikimedia.org/math/a/7/4/a7495cf84a44978afdd4aa11e083f4cc.png) (and critical point 0), we can find this motif in the Mandelbrot set (first picture):

2\. d = 1 (m = n + 1). In this case ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is usually constructed from the Newton procedure for solving an equation ![g\(z\) = 0](//upload.wikimedia.org/math/e/b/d/ebde1c02bb1267461c98228aa0222a6b.png): ![f\(z\) = z - g\(z\)/g'\(z\)](//upload.wikimedia.org/math/d/b/0/db0e22b24e87502038b16a5faa90e4f6.png). The critical points are just the solutions to ![g\(z\) = 0](//upload.wikimedia.org/math/e/b/d/ebde1c02bb1267461c98228aa0222a6b.png), and we choose two having the largest distance from each other. For ![g\(z\) = z^{4} - 1](//upload.wikimedia.org/math/c/f/8/cf80af171c729096ac2d57c9164fe9d7.png) and thus ![f\(z\) = \(1 + 3z^{4}\)/\(4z^{3}\)](//upload.wikimedia.org/math/f/8/4/f8404e6de13a2f701853e010ce169ae2.png), we can find this motif in the Mandelbrot set (second picture):

3\. d < 1 (m < n + 1). In this case we usually use two finite critical points, and as the critical points are lying symmetrically around the x-axis (if ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) has real coefficients), we let the pair consist of conjugate numbers (of largest distance). We let the family be ![f\(z\) = \(1 - z^{2}\)/\(z - 0.01z^{2} + 0.004z^{3}\) + c](//upload.wikimedia.org/math/8/0/5/8059216d160e9e1ba9c3480e0f2643e3.png), and we zoom in at the place where the most interesting things seem to be (third picture). We choose three points on the boundary and draw their Julia sets. First a point on the thin tangent line passing through the sea horse valley. Then a point in one of the holes inside the upper black. The last point presupposes that we invert the critical points, so that we can see a part of the boundary that is not visible on this picture of the Mandelbrot set. This boundary forms a continuation downwards of the indicated vertical line in the centre.

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Juliasetsdkpictjul23a.jpg/120px-Juliasetsdkpictjul23a.jpg)

   One Fatou domain

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/a/ae/Juliasetsdkpictjul23b.jpg/120px-Juliasetsdkpictjul23b.jpg)

   Two Fatou domains

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Juliasetsdkpictjul23c.jpg/120px-Juliasetsdkpictjul23c.jpg)

   One Fatou domain

### The parameter _c_

In order to get a _family_ of iterations from the rational function _f(z)_, we have here simply added the parameter _c_ to _f(z)_, so that the family is _z → f(z) + c_. This way is the simplest, and as we can get every Julia set in this way and as a Mandelbrot set locally is like a Julia set and as the type of the Mandelbrot sets constructed from families of the form _z → f(z) + c_ is satisfying in every way, there is no strong reason for letting _c_ enter in a more sophisticated way. But we can find interesting Mandelbrot sets by letting _c_ enter in a specific way. We can transform the Mandelbrot set by replacing the family by _z_ → ![h_1\(c\)f\(z\) + h_2\(c\)](//upload.wikimedia.org/math/5/0/7/507d89d5fe4c372023265fc983a998ec.png), for some functions ![h_1\(z\)](//upload.wikimedia.org/math/c/4/a/c4aca4178a56f4a6e3d0ed70d899d30c.png) and ![h_2\(z\)](//upload.wikimedia.org/math/d/a/9/da92baa2118b76bca524dece71476495.png), and we can construct Mandelbrot sets whose form in their entirety differ from those of the usual type by letting _c_ appear in the coefficients of the rational function _f(z)_.

Now the family is of the form _z → g(z, c)_, and we assume that _g(z, c)_ is rational in both _z_ and _c_. The critical points can now depend on _c_ (we denote the two chosen ![zc_1\(c\)](//upload.wikimedia.org/math/d/f/0/df0d0cd2e5c83748840374a6610fbdcc.png) and ![zc_2\(c\)\)](//upload.wikimedia.org/math/6/2/c/62c96bd83e3059199164d19e2bc8d52d.png), and in order to draw the boundary we must (besides ![g'\(z, c\) = \\partial g\(z, c\)/\\partial{z}](//upload.wikimedia.org/math/d/5/e/d5ebafbc8c465a1c9c9ca22f797a9eff.png)) calculate the derivative of _g(z, c)_ with respect to _c_: _(d/dc)g(z, c)_ (= ![\\partial g\(z, c\)/\\partial{c}](//upload.wikimedia.org/math/2/f/6/2f6d981d1d67fa7d311c1604564a1b42.png) \- see the section [Terminology](/wiki/Pictures_of_Julia_and_Mandelbrot_Sets/Terminology)). And we must also calculate the derivative with respect to _c_ of the critical points ![zc_1\(c\)](//upload.wikimedia.org/math/d/f/0/df0d0cd2e5c83748840374a6610fbdcc.png) and ![zc_2\(c\)](//upload.wikimedia.org/math/a/7/7/a775f1e9f999af93681719c655edb339.png): ![dzc_1\(c\)/dc](//upload.wikimedia.org/math/0/c/2/0c223696dc66d11a72deca6b01eabf4f.png). The iteration is given by ![z_{k+1} = g\(z_k, c\)](//upload.wikimedia.org/math/c/8/c/c8c0f1978ab59f1d4c47482705de0532.png) (starting in ![zc_1\(c\)](//upload.wikimedia.org/math/d/f/0/df0d0cd2e5c83748840374a6610fbdcc.png) and ![zc_2\(c\)](//upload.wikimedia.org/math/a/7/7/a775f1e9f999af93681719c655edb339.png)), and the derivative ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) (with respect to _c_) is calculated by

    

    ![z'_{k+1} = z'_k g'\(z_k, c\) + \(d/dc\)g\(z_k, c\)](//upload.wikimedia.org/math/4/5/8/458df43abec93d235f9a0dcdf6d52ac3.png)

starting with ![z'_0 = dzc_1\(c\)/dc](//upload.wikimedia.org/math/9/3/7/937f66cb0b4db7dfd67ef5b02c28f3e2.png) and ![dzc_2\(c\)/dc](//upload.wikimedia.org/math/6/d/5/6d51fe52a6c35855b32739e3952b54c1.png).

We let _f(z)_, ![h_1\(z\)](//upload.wikimedia.org/math/c/4/a/c4aca4178a56f4a6e3d0ed70d899d30c.png) and ![h_2\(z\)](//upload.wikimedia.org/math/d/a/9/da92baa2118b76bca524dece71476495.png) be respectively ![z^5](//upload.wikimedia.org/math/5/a/e/5ae69eac07e4ea58ba967a29113b7e8b.png), _-iz_ and 1, and ![z^2](//upload.wikimedia.org/math/7/d/b/7db5e3ec92f18b8e39aa043575959617.png), _i(z - 1/z)/√2_ and _i(z + 1/z)/√2_ (first and second picture below). In the last case the four parts meet in the points _±(√2 ± i√2)/2_ which correspond to the points ±_i_ belonging to the usual Mandelbrot set.

Let us now assume that _g(z, c)_ is the rational function given by Newton iteration for the polynomial ![f\(z\) = \(z - 1\)\(z^2 - c\)](//upload.wikimedia.org/math/0/c/c/0ccea5513fc9df31daeb789fd6bef0b7.png), that is, ![g\(z, c\) = z - f\(z\)/f'\(z\) = \(2z^3 - z^2 - c\)/\(3z^2 - 2z - c\)](//upload.wikimedia.org/math/f/7/7/f7788ec82bee69007f44425a82dd4ecf.png). The critical points are the solutions to the equation _g'(z, c) = 0_, and as ![g'\(z, c\) = f\(z\)f^{\(2\)}\(z\)/f'\(z\)^2](//upload.wikimedia.org/math/a/d/d/addf5835498d1b7aa98e502d53dcdadf.png), the critical points are the roots of _f(z) = 0_ (in our case 1 and _±√c_) and the roots of ![f^{\(2\)}\(z\) = 0](//upload.wikimedia.org/math/c/9/0/c90e67a1dd4f67fd5a94e8c80a6e6ff7.png) (in our case 1/3). As a critical point which is a root of _f(z) = 0_ is a fixed point for _g(z, c)_, the second of the critical points used in the construction of the Mandelbrot set (that is, ![zc_2\(c\)](//upload.wikimedia.org/math/a/7/7/a775f1e9f999af93681719c655edb339.png)) must be one of the roots of ![f^{\(2\)}\(z\)](//upload.wikimedia.org/math/a/7/7/a77a3fbfc15212b22fba951799a9c685.png). In our concrete case we construct the Mandelbrot set from only one critical point: ![zc_1\(c\) = zc_2\(c\) = 1/3](//upload.wikimedia.org/math/6/0/3/60372f45ee9feea66f2803f82761e259.png), so that only the boundary of the Mandelbrot set is drawn (third picture).

We have mentioned above that if the terminus of ![zc_1](//upload.wikimedia.org/math/d/2/e/d2ed3fadf859732d7a0f0d6cc880ef0a.png) is not ∞, then it is most likely a finite attracting cycle that is not super-attracting, and if not, there can be a fault in the colour of the pixel, but this is without significance in practice. However, in our just mentioned case where _g(z, c)_ comes from Newton iteration, _all_ the iterations (or rather, all the Fatou domains) outside the Mandelbrot set are super-attracting, therefore we must correct the formulas for the real iteration number and for the distance function by introducing log in the formulas.

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Juliasetsdkpictgirl.jpg/120px-Juliasetsdkpictgirl.jpg)

The Mandelbrot set for ![-icz^5 + 1](//upload.wikimedia.org/math/c/8/7/c87f6bd8ce96f9343b4fd5a621888e8b.png)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Juliasetsdkpictfourman.jpg/120px-Juliasetsdkpictfourman.jpg)

The Mandelbrot set for _(i(c - 1/c)/√2)_![z^2](//upload.wikimedia.org/math/7/d/b/7db5e3ec92f18b8e39aa043575959617.png) \+ _(i(c + 1/c)/√2)_

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/1/12/Juliasetsdkpictnewman.jpg/120px-Juliasetsdkpictnewman.jpg)

The Mandelbrot set for Newton iteration for ![\(z - 1\)\(z^2 - c\)](//upload.wikimedia.org/math/6/d/c/6dce1d537170546ae032e914b5e08705.png)

### The drawing Mandelbrot and Julia sets in practice

A Julia set for a rational complex function is so well-defined and natural that, like with some other mathematical concepts, we are inclined to say that it belongs to nature: if they have computers in another world, they will also definitely have Julia sets. Also the definition of a Mandelbrot set is simple and obvious, and the drawing procedure must necessarily be in this way: we enter the coefficients of the two polynomials in some way, and then either some pairs of critical points are found automatically or a pair is chosen graphically by clicking in a picture where all the critical points are shown. Hereafter the Mandelbrot set appears, and we can zoom in and alter the colouring. We go to the Julia sets by pressing a key so that the point in the centre of the window can be moved by the arrows, and when we have chosen a point (usually on the boundary of the Mandelbrot set), the procedure for the Julia set is exactly the same as that for the Mandelbrot set.

When you draw a large picture, you ought to draw it at least twice as large as intended, and then reduce it so that the boundary is no longer only one colour. This will lessen the often sharp character of the boundary and it will remove dots arising from impossible calculations.

  


# Julia and Mandelbrot sets for transcendental functions

For a transcendental complex function, such as ![sin\(z\), cos\(z\), exp\(z\), ...](//upload.wikimedia.org/math/a/7/3/a734999014fbbf2379be6eaf9f5f04f6.png), which must be assigned degree ∞ and which has ∞ as an attracting fixed point, the potential function for the Fatou domain containing ∞ does not exist, and therefore the colouring cannot be made smooth in the usual way. Besides this, it is possible that the status of ∞ as an attracting fixed point is ambiguous.

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Juliasetsdkpictjulsin1.jpg/220px-Juliasetsdkpictjulsin1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Julia set for ![sin\(z\) + c](//upload.wikimedia.org/math/3/0/d/30d266e47d40ddab1e8d5b7860e2a3b9.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Juliasetsdkpictmansin1.jpg/220px-Juliasetsdkpictmansin1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

In the Sea Horse Valley of a mini-mandelbrot of the Mandelbrot set for ![sin\(z\) + c](//upload.wikimedia.org/math/3/0/d/30d266e47d40ddab1e8d5b7860e2a3b9.png)

This is the case for ![sin\(z\)](//upload.wikimedia.org/math/5/9/4/594386a22c7ded74fe2ea2e121276765.png) and ![cos\(z\)](//upload.wikimedia.org/math/b/b/6/bb68e1398e05b1ce8b11111eb2670b62.png). ![Sin\(z\)](//upload.wikimedia.org/math/7/2/4/7241ca7630536721133b4b2811907432.png) can be defined by ![sin\(x + iy\) = sin\(x\)cosh\(y\) + icos\(x\)sinh\(y\)](//upload.wikimedia.org/math/2/8/7/287164451116e3d381f13127f898e280.png), and we see from this formula, that if we go towards ∞ along a vertical line, the value grows (exponentially) to ∞, but if we go towards ∞ along a horizontal line, the value remains bounded. As an iteration of _z_ by ![sin\(z\) + c](//upload.wikimedia.org/math/3/0/d/30d266e47d40ddab1e8d5b7860e2a3b9.png) can be small when _z_ has an arbitrarily high _y_-value (namely if ![cos\(x\)](//upload.wikimedia.org/math/7/5/9/759d7dcba776dac9e4bbe3866998e4e5.png) is near 0), the inner Fatou domains extend towards ∞ in the vertical direction, and also in the horizontal direction, because of the periodicity. The same applies therefore for the Julia set. The Fatou domain containing ∞ must here be defined as the Fatou domain containing points having arbitrarily large _y_-values, but this Fatou domain is not an open set: it has no interior points. In the colouring it is therefore inseparable from the Julia set, which consists of infinitely dense lying threads. So, if there are no inner Fatou domains, the Julia set is lying densely in the plane, implying that the whole plane should be coloured as the boundary. Nevertheless, the computer gives us a non-trivial picture (top picture).

The reason is that we are forced to use a relatively small radius of the large circle determining the stopping of the iteration, owing to the exponential growth of ![sin\(z\)](//upload.wikimedia.org/math/5/9/4/594386a22c7ded74fe2ea2e121276765.png) in the _y_-direction. Therefore the sequences of iteration stop after only few iterations, and we colour on the basis of the number of iterations. As the colour of a point _c_ outside the Mandelbrot set is the colour of the (second) critical point of the Fatou domain for _c_ containing ∞, the domain outside the Mandelbrot set is, like the outer Fatou domain, without interior points: it is interwoven with infinitely lying threads. This wire mesh makes up a continuation of the usual boundary, which is unaffected by the phenomenon, as the distance function is unaffected by the nature of the function. For a rational function, the boundary consists of the points such that the associated Julia set contains the (second) critical point. However, for a transcendental function this set can be larger than the boundary constructed from the distance function, and in our case it lies densely in the domain outside the interior of the Mandelbrot set. Nevertheless we get a colouring, because the iterations stop early. We are here in the Sea Horse Valley of a mini-mandelbrot of the Mandelbrot set for ![sin\(z\) + c](//upload.wikimedia.org/math/3/0/d/30d266e47d40ddab1e8d5b7860e2a3b9.png) (middle picture).

For iteration towards finite cycles, the Julia sets look like those for rational functions. But it can happen that there are small circles in the picture of only one colour, because it is impossible here, at a specific step in the iteration, to calculate the next value of the transcendental function in the formula.

The Mandelbrot set for ![\(1 - z^2\)/\(z - z^2cos\(z\)\) + c](//upload.wikimedia.org/math/a/8/4/a848edeaff6013c61c4b781cf609913e.png) has a look that is typical for the rational functions where the iterations are towards finite cycles (first picture below). This Mandelbrot set is constructed from two conjugate critical points, and if we let _z1_ and _z2_ be the images of these by ![\(1 - z^2\)/\(z - z^2cos\(z\)\)](//upload.wikimedia.org/math/d/4/0/d4022906f373b50e0a527472a173d91c.png), we have that if _c_ is real and numerical large and belonging to the Mandelbrot set, then _z1 + c_ and _z2 + c_ belong to different Fatou domains for ![\(1 - z^2\)/\(z - z^2cos\(z\)\) + c](//upload.wikimedia.org/math/a/8/4/a848edeaff6013c61c4b781cf609913e.png), therefore ![1/cos\(z1 + c\) + c](//upload.wikimedia.org/math/7/f/3/7f310decc9610c4e233245160e738bc0.png) and ![1/cos\(z2 + c\) + c](//upload.wikimedia.org/math/1/b/a/1ba7a9afc3bced4238af11d7e0fdeeef.png) belong to different Fatou domains, and if we add a multiple of ![2 \\pi](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png) to _c_ (so that the result still is numerically large), then these two numbers will belong to different Fatou domains. Therefore we can say: it is _possible_ that the Mandelbrot set extends towards infinity in the horizontal direction. It seems really to be the case, as we can see if we draw the Mandelbrot set and zoom out.

The two following pictures show sections of the Julia set for _c_ = -1. The point _z_ = -1 is a fixed point for this iteration, and as the derivative of the function in this point is numerically larger than 1, _z_ = -1 is repelling and belongs therefore to the Julia set. If _x_ is real and numerically very large, the iteration of _x_ is near ![1/cos\(x\) - 1](//upload.wikimedia.org/math/3/c/4/3c48675ae91db3cb5fc00ff6d8ca968d.png). Therefore, if _x*_ is a real point of the Julia set such that _x*_ \- (-1) > 1, we can find a real point of large numerical value that iterates into this point of the Julia set, and this indicates that the Julia set extends towards infinity in the horizontal direction. And as _cos(z)_ grows exponentially in the vertical direction, the iteration of a point _z_ of large numerical y-value is very near -1, therefore we can find points of arbitrary large y-values that iterate into -1, so that the Julia set extends towards infinity in the vertical direction.

As ![cos\(z\)](//upload.wikimedia.org/math/b/b/6/bb68e1398e05b1ce8b11111eb2670b62.png) has power series expansion ![1 - z^{2}/2! + z^{4}/4! - z^{6}/6! + z^{8}/8! - ...](//upload.wikimedia.org/math/1/f/f/1fffed67b9966d7151d8c8c088562f3c.png) (where _n! = 1×2×...×n_), we can get rational approximations to the Mandelbrot set and the Julia sets by restricting this series.

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Juliasetsdkpictmancos.jpg/120px-Juliasetsdkpictmancos.jpg)

The Mandelbrot set for ![\(1 - z^2\)/\(z - z^2cos\(z\)\) + c](//upload.wikimedia.org/math/a/8/4/a848edeaff6013c61c4b781cf609913e.png)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/d/df/Juliasetsdkpictjulcos1.jpg/120px-Juliasetsdkpictjulcos1.jpg)

The Julia set for ![\(1 - z^2\)/\(z - z^2cos\(z\)\) - 1](//upload.wikimedia.org/math/6/d/a/6dafe2724211967f91cca3f5f3f375d4.png)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/0/04/Juliasetsdkpictjulcos2.jpg/120px-Juliasetsdkpictjulcos2.jpg)

The Julia set for ![\(1 - z^2\)/\(z - z^2cos\(z\)\) - 1](//upload.wikimedia.org/math/6/d/a/6dafe2724211967f91cca3f5f3f375d4.png)

  


# Julia and Mandelbrot sets for non-complex functions

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ee/Juliasetsdkpictreal1.jpg/220px-Juliasetsdkpictreal1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The distorted Sea Horse Valley

That our mapping ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) from the plane into itself is differentiable as a complex function, means that it is differentiable as a real function - that is, that its two components ![f_x\(x, y\)](//upload.wikimedia.org/math/5/7/d/57dad6be12faf8a981b06621a703858b.png) and ![f_y\(x, y\)](//upload.wikimedia.org/math/c/3/4/c34d0eb97ba2e673645766a870dc77bd.png) are differentiable - and that these two components satisfy the _Cauchy-Riemann differential equations_:

    ![\\frac{\\partial}{\\partial{x}}f_x = \\frac{\\partial}{\\partial{y}}f_y](//upload.wikimedia.org/math/f/3/9/f39d86a326f8b14f51d36d4fcdac1074.png) and ![\\frac{\\partial}{\\partial{y}}f_x = -\\frac{\\partial}{\\partial{x}}f_y](//upload.wikimedia.org/math/5/1/1/511920ce23c68bc21abc9dd36860b2e4.png)

if so, these two numbers are the real and imaginary part of ![f'\(z\)](//upload.wikimedia.org/math/2/8/1/28102ad46542ff3d2cb5caefa7011773.png), respectively.

It is this condition that causes the characteristic features of the Mandelbrot and Julia sets for complex iteration. The usual family of iterations ![z^{2} + c](//upload.wikimedia.org/math/c/2/d/c2d9e7d195b10b43be48af4db7f274bd.png) can (in coordinate form) be written ![\(x, y\)](//upload.wikimedia.org/math/9/0/c/90cbc22edf225adf8a68974f51227f05.png) → ![\(x^{2} - y^{2}, 2xy\) + \(u, v\)](//upload.wikimedia.org/math/3/c/1/3c13fee6858773e8c6b9cb692e8f7dcf.png) (if _c = u + iv_), and if we here replace the _y_-coordinate of the function, that is _2xy_, by _1.95×xy_, the shapes in the Sea Horse Valley become distorted.

This thread-like and tattered look is typical for the _real_ \- or _non-complex_ \- fractals. For a function which is not, as in this case, the result of a mild interference in a complex function, the picture is often very chaotic, and the colouring can be impossible at most places, because our method of colouring presupposes that the sequences of iteration converge to a finite cycle, and for a non-complex iteration the terminus need not be a finite set. The terminal set is now called an _attractor_, and attractors can have very surprising shapes. Because of this, such an attractor is known as a _strange attractor_.

The fact that the two coordinate functions are not presupposed to be connected (by the Cauchy-Riemann equations) implies partly that a point of a Julia set is no longer necessarily a point of accumulation for _each_ of the Fatou domains, and partly that a Julia set can have different character of connectedness along two directions orthogonal to one another. For instance the Julia set can consist of a system of threads lying infinitely close. If so, it is connected when one goes along the threads, and disconnected when one goes across this direction. Within each of the Fatou domains the sequences of iteration will converge to - be attracted by - one and the same attractor. The interesting attractors are relatively rare and most attractors are - as in the complex case - only finite cycles, or they consist merely of a number of separated pieces of curves, or they are quite the opposite and completely confused, filling up almost all the Fatou domain.

### The Mandelbrot set

In order to find interesting Julia sets and attractors, we must construct a Mandelbrot set. We assume here that our function ![f\(x, y\)](//upload.wikimedia.org/math/3/b/a/3baf1600ae50930a155f58ae172b51bd.png) is composed of two real second-degree polynomials ![p\(x, y\)](//upload.wikimedia.org/math/3/7/4/374caa6fc5bcf5b0106543cd2e7876ef.png) and ![q\(x, y\)](//upload.wikimedia.org/math/9/8/8/98871b4b4ae9c70d1f8960d17c77570d.png): ![f\(x, y\) = p\(x, y\) + iq\(x, y\)](//upload.wikimedia.org/math/c/8/a/c8ac6756dffcc2f981e39f50a5d9701c.png). We have first to choose two critical points. In the complex case, these are the solutions to the equation ![f'\(z\) = 0](//upload.wikimedia.org/math/9/9/0/9907568f1330e4375cca91f96fb76c28.png) (or _z_ = ∞), and _if_ our mapping (being composed of second-degree polynomials) were complex differentiable, there would only have been a single (finite) critical point, which could be calculated automatically. But if the function is not complex differentiable, there can be an infinity of points satisfying the condition of being a critical point.

For a general differentiable mapping ![g\(x, y\)](//upload.wikimedia.org/math/c/3/2/c323331da632254e00b022a7529533ff.png) from the plane into itself, the derivative ![g'\(x, y\)](//upload.wikimedia.org/math/5/7/6/57633a1fb2fb24d3a300f257710a40d2.png) is a 2x2 matrix (see the section _Terminology_), namely composed of these four numbers:

    ![\\frac{\\partial}{\\partial{x}}g_x\(x, y\)](//upload.wikimedia.org/math/2/9/c/29cf74f07162eda6ef0911502089baa3.png)   ![\\frac{\\partial}{\\partial{y}}g_x\(x, y\)](//upload.wikimedia.org/math/3/e/a/3eabf49fc1115f82a6aa8094a811f00a.png)

    ![\\frac{\\partial}{\\partial{x}}g_y\(x, y\)](//upload.wikimedia.org/math/4/c/b/4cb7060c8e7251eabf2f5256c92c7173.png)   ![\\frac{\\partial}{\\partial{y}}g_y\(x, y\)](//upload.wikimedia.org/math/5/9/5/5958286c3352e55622ba5bfc969e31e5.png)

That the Cauchy-Riemann equations are satisfied, means that this matrix corresponds to multiplication by a complex number, namely ![g'\(z\)](//upload.wikimedia.org/math/d/3/d/d3d470c2fbe087d2f75a125fae7057d8.png). That ![g'\(x, y\)](//upload.wikimedia.org/math/5/7/6/57633a1fb2fb24d3a300f257710a40d2.png) is regarded as degenerated, means that its determinant ![|g'\(x, y\)|](//upload.wikimedia.org/math/c/4/1/c41ffa2c4958c0f8af917088c82f2d99.png) vanishes:

![\(\\partial g_x\(x, y\)/\\partial{x}\)\(\\partial g_y\(x,y\)/\\partial{y}\) - \(\\partial g_x\(x,y\)/\\partial{y}\)\(\\partial g_y\(x,y\)/\\partial{x}\) = 0](//upload.wikimedia.org/math/1/8/1/18177e0b24fb5c4e74ce3c23fc4d9ccd.png).

For our function ![f\(x, y\)](//upload.wikimedia.org/math/3/b/a/3baf1600ae50930a155f58ae172b51bd.png), composed of two second-degree polynomials, ![|g'\(x, y\)|](//upload.wikimedia.org/math/c/4/1/c41ffa2c4958c0f8af917088c82f2d99.png) is a second-degree polynomial, and therefore its zeros form a conic section: an ellipse, a parabola or a hyperbola. Besides this curve of critical points, the point ∞ also satisfies the condition of being a critical point. We choose ∞ as the first of the critical points, and a point ![\(zc_x, zc_y\)](//upload.wikimedia.org/math/9/d/6/9d6b03e378e00ac90b5bd1de2fd0c744.png) on the conic section as the other.

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Juliasetsdkpictmanreal.jpg/220px-Juliasetsdkpictmanreal.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Non-complex Mandelbrot set

The Mandelbrot set for the family of iterations _(x, y) → f(x, y) + (u, v)_ is the set of points _(u, v)_ such that if we iterate ![\(zc_x, zc_y\)](//upload.wikimedia.org/math/9/d/6/9d6b03e378e00ac90b5bd1de2fd0c744.png), the sequence does not grow towards ∞. The domain outside the Mandelbrot set can be coloured in the same way as before. In this simple case, where the iterations are towards a fixed point (namely ∞), we can (by means of matrix calculations) colour smoothly and draw the boundary. Let us set ![p\(x, y\) = xy](//upload.wikimedia.org/math/e/0/1/e012b9cf2a61d3e9ea6fcd4b961fc640.png) and ![q\(x, y\) = y - x^{2}](//upload.wikimedia.org/math/6/9/b/69bdb8981123c58abe9bbd01e2dd5708.png), then the determinant of the derivative is ![y + 2x^{2}](//upload.wikimedia.org/math/f/0/e/f0e15ade0cbc290ffea3c4473f8df682.png), so that the critical system is the parabola ![y = -2x^{2}](//upload.wikimedia.org/math/d/0/e/d0e6bd97b333e7f0b520c7e134aa7819.png). If we choose ![\(zc_x, zc_y\) = \(0, 0\)](//upload.wikimedia.org/math/9/7/b/97b35574807c1258cf0c64b6d3128b1c.png), the Mandelbrot set looks like this:

### The Julia sets

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/02/Juliasetsdkpictjulreala.jpg/220px-Juliasetsdkpictjulreala.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Julia set with attractor

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Juliasetsdkpictjulrealb.jpg/220px-Juliasetsdkpictjulrealb.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Intersection with the parabola

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6c/Juliasetsdkpictjulrealc.jpg/220px-Juliasetsdkpictjulrealc.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Still connected in the one direction

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/82/Juliasetsdkpictstrstratt.jpg/220px-Juliasetsdkpictstrstratt.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A _strange_ strange attractor

In our simple case, where ∞ is a critical point, the colouring of the Fatou domain containing ∞ is, like the colouring outside the Mandelbrot set, without problems, and we can also draw the boundary of this Fatou domain. But besides this Fatou domain, there can now be an infinity of Fatou domains and these are not necessarily open sets. A Fatou domain is a set of points having the same attractor, and each Fatou domain contains a critical point. If we therefore iterate all the points of the conic section, we get all the attractors.

If the attractor of a Fatou domain is not a finite cycle, we cannot colour the domain in a natural way, we colour it black and draw its attractor. This is done by iterating each point of the Fatou domain: first a large number of times without drawing, and then a large number of times where the pixel is coloured white, for instance. As the attractors for the different points in the same Fatou domain are the same, we can stop this drawing after the attractors for few points are drawn.

If in the above Mandelbrot set we choose a point in the upper part a good distance from the centre line and a little bit inside the Mandelbrot set, we get this Julia set (first picture).

The Julia set is the complement to the union of the Fatou domains. In the complex case we have that if there are only few critical points in the Fatou domains, this indicates that the Julia set is "most possible" connected. This rule is also valid for a non-complex iteration: the character of the intersection of the Julia set with the critical system indicates the character of the connectedness of the Julia set. Therefore, when the Julia set and the Fatou domains run as threads, we have that the nearer the angle of intersection with the Julia set is to a right angle, the more regular is the course of the Fatou domains at that locality.

If in the above Mandelbrot set we choose a point near the centre line and just outside the Mandelbrot set, the Julia set becomes disconnected, but as it intersects the critical system in angles that are near the right angle, it does not become a cloud of dust, as in the complex case, but it becomes only disconnected in the one direction, in the other it runs as connected threads (second picture). Even the most disconnected Julia sets consist of threads in this simple case (third picture).

When we have found a usable locality in the Mandelbrot set, it is still rather difficult to find a point whose inner Fatou domain has a fine attractor. The point must not lie too near the boundary, for then the attractor is too chaotic and difficult to draw, and when the point is too far inside the black, the attractor will be more or less trivial. It is only at few places and at a certain distance from the boundary that you can find attractive attractors, and their forms vary swiftly when the point is moved.

If we choose trivial functions, for instance ![p\(x, y\) = x^{2}](//upload.wikimedia.org/math/9/d/2/9d20863a263cb85715335f417d4b510c.png) and ![q\(x, y\) = y^{2}](//upload.wikimedia.org/math/5/f/c/5fc7c654da42b599f82fc80f19835040.png), we can find trivial Julia sets and extraordinary (strange?) attractors (fourth picture).

### Rational functions

If the components of our function are _rational_ (real) functions and if ∞ is not a super-attracting fixed point, there can be serious "faults" in the colouring outside the Mandelbrot set, and we can be forced to abstain from colouring the Fatou domains and thus only draw the attractors. But on the other hand, we can find very nice attractors. In the first picture below is the function of the form ![\(p\(x, y\) + iq\(x, y\)\)/r\(x^2, y^2\)](//upload.wikimedia.org/math/e/9/7/e97f1e40c8ac3711b7fea19e00aca50f.png), with ![p\(x, y\) = \(x^4 - y^4\)/10](//upload.wikimedia.org/math/c/0/e/c0e7549b6fa5f3792b109d8373396ded.png), ![q\(x, y\) = x - y](//upload.wikimedia.org/math/3/d/e/3def6a563482afac5fd757d101fe869b.png) and ![r\(x ,y\) = 1 - \(x - y\)/5 + \(\(x + y\)/10\)\)^2](//upload.wikimedia.org/math/6/1/d/61d41655883d85b5a5b64fde2dcd3e73.png).

At a locality where the colouring of the Mandelbrot set is tolerable, we can try and draw the Julia set, and instead of drawing the attractor, we can draw the critical system. For such functions the critical system can be as simple or complicated as it pleases us, and in the cases where the Fatou domain can be coloured fairly faultlessly, and where the Julia set intersects the critical system under nearly right angles, we can by sketching the critical system create decorative patterns. In the second and third picture below are the functions of the above form with respectively ![p\(x, y\) = 1 - xy^3](//upload.wikimedia.org/math/4/a/a/4aaa3e98d726466f32f3df26301042ef.png), ![q\(x, y\) = x^2y^2 + y^4](//upload.wikimedia.org/math/1/4/e/14e7a3260a1f96f9c4f5c54ebd50ed64.png), ![r\(x ,y\) = 1 + x^2 + xy + y^2](//upload.wikimedia.org/math/f/e/2/fe24a18de7d8a6ac7bc5f68818c0ca2c.png) and ![p\(x, y\) = x^3 - y^3 + x^2y^2](//upload.wikimedia.org/math/1/e/a/1eadb47bddd585a1ef70bcff4bb73309.png), ![q\(x, y\) = x - y + x^2y^2](//upload.wikimedia.org/math/c/e/0/ce0365722a8d0c5cc59788bb9392e5ff.png), ![r\(x ,y\) = 1 + x^2 + y^2](//upload.wikimedia.org/math/a/b/b/abbcde317e7dc34eca1b60da37bb6cd1.png).

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Juliasetsdkpictratatt.jpg/120px-Juliasetsdkpictratatt.jpg)

Attractor for a rational function

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Juliasetsdkpictratcri1.jpg/120px-Juliasetsdkpictratcri1.jpg)

Julia set and critical system for a rational function

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Juliasetsdkpictratcri2.jpg/120px-Juliasetsdkpictratcri2.jpg)

Julia set and critical system for a rational function

### The formula for the distance function

We can only colour a Fatou domain faultless, when it is associated to a finite attracting cycle, and when this is the case, the procedure is the same as for complex iteration.

Also the formula for the distance estimation used to draw the boundary, presupposes that the iterations are towards finite cycles. However, we ought to have the procedure in the program - at least for iterations towards infinity.

We have defined the distance function by ![\\delta\(z\) = \\phi\(z\)/|\\phi'\(z\)|](//upload.wikimedia.org/math/3/9/c/39cb45c17d28116620b5550011e43e83.png) (where ![\\phi\(z\)](//upload.wikimedia.org/math/6/b/f/6bf906ca163fa54c0433ff4c5af8ea82.png) is the potential function), and as ![\\phi\(z\)](//upload.wikimedia.org/math/6/b/f/6bf906ca163fa54c0433ff4c5af8ea82.png) is a real function defined on the Fatou domain, its derivative ![\\phi'\(z\)](//upload.wikimedia.org/math/0/a/8/0a8a80c247f995f16a34905492c6e973.png) (or gradient) is a vector function, namely

    (![\\part \\phi\(z\)/\\part{x}](//upload.wikimedia.org/math/7/8/1/781634433e294448d658b18de60aeb68.png), ![\\part \\phi\(z\)/\\part{y}](//upload.wikimedia.org/math/7/a/b/7ab06491786cb00fc7cac91d5a3a31d2.png))

(see the section _Terminology_). If the iteration function ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is complex (differentiable), an element of the sequence ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) is complex differentiable as function of _z_, and therefore ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) is a complex number. But this is not the case for a non-complex iteration function, for then ![f'\(z\)](//upload.wikimedia.org/math/2/8/1/28102ad46542ff3d2cb5caefa7011773.png) must be replaced by the 2x2-matrix ![Df\(z\)](//upload.wikimedia.org/math/c/f/3/cf3cb3e2836bf35cba9738a25c036ebf.png) =

    ![\\begin{bmatrix}
\\part f_x/\\part{x} & \\part f_x/\\part{y} \\\\
\\part f_y/\\part{x} & \\part f_y/\\part{y} \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/3/0/f/30f811a439d79c0bab723c6a01e189a7.png)

And ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) is a 2x2-matrix, namely:

    ![\\begin{bmatrix}
\\part x_k/\\part{x} & \\part x_k/\\part{y} \\\\
\\part y_k/\\part{x} & \\part y_k/\\part{y} \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/2/c/5/2c569bc4af0d33d589b04201e11fd9fd.png)

which we denote by

    ![\\begin{bmatrix}
xx_k & xy_k \\\\
yx_k & yy_k \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/1/4/e/14ea5b572b55d49e9f23f02228ae41a1.png)

It is calculated successively by ![z'_{k+1} = Df\(z_k\)z'_k](//upload.wikimedia.org/math/e/2/e/e2eabf7ffc035c7c5aa690222e489bb0.png), with start in the unit-matrix: ![z'_0 = I](//upload.wikimedia.org/math/8/6/6/866a42d9dd3664c7aa7cec2190688ba2.png).

The formulas for the vector function ![\\phi'\(z\)](//upload.wikimedia.org/math/0/a/8/0a8a80c247f995f16a34905492c6e973.png) in the three cases are:

    ![\\phi'\(z\) = ](//upload.wikimedia.org/math/6/4/b/64bf3ba955e1dd417319557e82863cdb.png)limk→∞{![x* - x_{kr}, y* - y_{kr}](//upload.wikimedia.org/math/7/d/c/7dc0d0560e0c5244e051224eb4e74cd0.png)}![z'_{kr}/\(|z_{kr} - z*|^3\\alpha^k\)](//upload.wikimedia.org/math/1/5/f/15fd8582b0de57f2dc71e15b038cdf37.png) (non-super-attraction)
    ![\\phi'\(z\) = ](//upload.wikimedia.org/math/6/4/b/64bf3ba955e1dd417319557e82863cdb.png)limk→∞{![x* - x_{kr}, y* - y_{kr}](//upload.wikimedia.org/math/7/d/c/7dc0d0560e0c5244e051224eb4e74cd0.png)}![z'_{kr}/\(|z_{kr} - z*|^2\\alpha^k\)](//upload.wikimedia.org/math/8/6/5/865b014c6082c29fe10e9e9a1a1a9b93.png) (super-attraction)
    ![\\phi'\(z\) = ](//upload.wikimedia.org/math/6/4/b/64bf3ba955e1dd417319557e82863cdb.png)limk→∞{![x_k, y_k](//upload.wikimedia.org/math/6/a/6/6a602aabed92b60893e109a678f40ffd.png)}![z'_k/\(|z_k|^2d^k\)](//upload.wikimedia.org/math/d/2/f/d2f4cb0aa10350a6fba0fa45fa5442f5.png) (_d_ ≥ 2 and _z*_ = ∞)

The matrix product {![x_k, y_k](//upload.wikimedia.org/math/6/a/6/6a602aabed92b60893e109a678f40ffd.png)}![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png) (for instance) is the row-matrix (vector) {![x_k xx_k + y_k yx_k](//upload.wikimedia.org/math/4/9/2/492a052fdf9586bb36fae9832bbbad03.png), ![x_k xy_k + y_k yy_k](//upload.wikimedia.org/math/c/c/f/ccf55519bb8feb956d7db5aca5e5e3e3.png)}. In the derivation we have used that the derivative (gradient) of the real function |_z_| is the vector function {_x/|z|, y/|z|_}.

To find the formula for ![\\delta\(z\) = \\phi\(z\)/|\\phi'\(z\)|](//upload.wikimedia.org/math/3/9/c/39cb45c17d28116620b5550011e43e83.png), we shall divide the expression for ![\\phi\(z\)](//upload.wikimedia.org/math/6/b/f/6bf906ca163fa54c0433ff4c5af8ea82.png) by the norm of the corresponding expression for ![\\phi'\(z\)](//upload.wikimedia.org/math/0/a/8/0a8a80c247f995f16a34905492c6e973.png), and we see, that we in the former expressions for ![\\delta\(z\)](//upload.wikimedia.org/math/3/e/1/3e1ba9c3052842170e80b767442a1329.png) only have to replace ![|z'_k|](//upload.wikimedia.org/math/d/5/0/d50911fa4ea08f350fd711b76119ac3c.png) by _√|det(z'k)|_.

For the Julia sets, we need only calculate the determinant of ![Df\(z\)](//upload.wikimedia.org/math/c/f/3/cf3cb3e2836bf35cba9738a25c036ebf.png), because ![det\(z'_{k+1}\) = det\(Df\(z_k\)\)det\(z'_k\)](//upload.wikimedia.org/math/f/e/6/fe690b2669f76f5457432d336eeb83fd.png). Therefore we calculate the sequence of real numbers ![det\(z'_k\)](//upload.wikimedia.org/math/6/4/d/64d97578bc31051eb1cee8c62e71cafe.png), starting in ![det\(z'_0\) = 1](//upload.wikimedia.org/math/6/9/3/693122173352ca8b43fc14ea902ca41b.png).

For the Mandelbrot set, where the derivative is with respect to _c_, the number 1 in the recursion formula must be replaced by the unit-matrix _I_: ![z'_{k+1} = Df\(z_k\)z'_k + I](//upload.wikimedia.org/math/c/a/d/cada19d4090ee095eab71a9b412870bb.png), starting in the zero-matrix: ![z'_0 = 0](//upload.wikimedia.org/math/8/9/6/8961cffec12dd33cd7c3002bdffc8a59.png).

### Precise calculation of the critical point

We choose a point on the critical system in the same way as in the complex case: we draw the curve(s) and choose a point with the mouse or the arrows. And then we use Newton iteration to find the nearest point on the curve. For a real function ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) on the plane (which in our case is _det(g'(x, y))_), this Newton iteration is given by _z_ → ![z - f\(z\)Df\(z\)*/|Df\(z\)|^2](//upload.wikimedia.org/math/b/f/f/bffd62902d3606585f131b34698724e4.png), where ![Df\(z\)](//upload.wikimedia.org/math/c/f/3/cf3cb3e2836bf35cba9738a25c036ebf.png) is the gradient of ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png), that is, the vector function

    {![\\partial f\(z\)/\\partial{x}, \\partial f\(z\)/\\partial{y}](//upload.wikimedia.org/math/7/1/c/71c1470d6c2962166c60e77ee1a6d423.png)}

and where the corresponding column-matrix ![Df\(z\)*](//upload.wikimedia.org/math/f/a/c/fac6d89effa194844a3e65f43135fb88.png) is identified with the complex number formed by these two real numbers.

In our case of the polynomial function, where ![f\(z\) = det\(g'\(x, y\)\) = 2x^2 + y](//upload.wikimedia.org/math/f/8/8/f88f4fa0603181eb0635c27583151b34.png), we have that the Newton iteration is given by:

    _(x + iy)_ → ![\(x + iy\) - \(2x^2 + y\)\(4x + i\)/\(16x^2 + 1\)](//upload.wikimedia.org/math/c/b/f/cbf5b159b73e8ed111bb77cd600990fc.png)

  


# Landscapes

If, in a three-dimensional coordinate system, we imagine the plane with the Mandelbrot or the Julia set as the _x,y_-plane and plot the distance function in the _z_-direction, we have a surface looking like a landscape, and we can see it from the side. Such a picture has to be drawn from the top and downwards (on the screen), and from the far distance towards the near (in the landscape), so that something will grow and hide what was previously drawn.

The distance function can have singularities, which means that the surface has points in which it grows towards infinity. As these vigorous rises are unaesthetic if they are numerous and dominant, we must modify the distance function (third picture). We can also modify it in order to create a more interesting landscape (second picture).

We can let the light be "natural", like the light from the sun. Then we imagine the rays are parallel (and given by two angles), and we let the colour of a point on the surface be determined by the angle between this direction and the slope of the surface at the point. The intensity (on the earth) is independent of the distance, but the light grows whiter because of the atmosphere, and sometimes the ground looks as if it is enveloped in a veil of mist (second picture). We can also let the light be "artificial", as if it issues from a lantern held by the observer. In this case the colour must grow darker with the distance (third picture).

We look at the landscape in a direction inclining downward from the eye, and the drawing window has this line as normal in its centre. A vertical line (of pixels) in the drawing window corresponds to a line in the base plane with the fractal. And for each of these lines, we start in the point farthest back and go towards the observer colouring pixels in the corresponding vertical line of the window in the following way: If p is a point on the line in the base plane, we calculate the value of the distance function in p. If the line from this point on the surface to the eye intersects the window, we shall colour this pixel. We calculate the slope of the surface in the point, by calculating the distance function in two points very near p in the x- and y-direction. The little triangle spanned by the three values lies on the surface. We take the scalar product of the normal (unit) vector of the triangle and the direction (unit) vector of the light - in case of artificial light this is the direction vector from the eye to the point.

This number (multiplied by the density) can be combined with other factors determining the colour: the height over the ground or the distance to the observer, for instance.

From the scalar product of the normal (unit) vector of the surface and the direction vector to the observer, we can approximately calculate the distance we must go towards the observer in order to colour the adjacent pixel above or below the just coloured pixel (for rise or fall of the landscape in the direction towards the observer, respectively). As this calculation cannot be exact, the steps must possibly be diminished by a factor. We stop the drawing for this line, when we are so near the observer that the bottom pixel of this vertical line of the window is coloured - possibly we do continue the drawing, if something grows up nearer the observer and we want this to be seen. Instead of finishing a vertical line before we go to the next, we can make the drawing looking more fascinating by going to the next vertical line for each step towards the observer, so that the drawing looks like a wave motion from the top and downwards.

The surface is primary constructed from a function proportional to the distance function, but the program should be made so that this function can be worked up. In the first turn the singularities should be made finite by choosing a relative maximum height _hm0_. This number times the width of the section is the maximum height _hm_ in the landscape, and we can replace the height _h_ by _hm * arctan(h/hm)_, for instance. The (constant) number _hm_ should however be made varying, by dividing it by a number proportional to the exponential function of the real iteration number, in order to lower the maximum height near the boundary. Instead of making the singularities finite, we can simply cut them down by replacing _h_ by _hm_ when _h_ > _hm_. We can also regulate _h_ by dividing it by ![1 + \(h/hm\)^2](//upload.wikimedia.org/math/9/0/1/9015dc23e8eba943ad066072e37fe194.png), for instance, or we can convert the singularities to craters by replacing _h_ by ![hm^2/h](//upload.wikimedia.org/math/2/0/a/20a9eaea32577660df84fc8d285b79dd.png) when _h_ > _hm_.

Furthermore, the surface can be smoothed out by multiplying _h_ by (for instance) the number ![1 - arctan\(a*s^b\)/\(\\pi/2\)](//upload.wikimedia.org/math/a/4/5/a4503b9ca7627fdd9955eb3faa275918.png), where _s_ is the slope of the surface and _a_ and _b_ are parameters determining the effect.

For natural light, we can get the colour growing whiter (mist) or darker with the distance and the height, by mixing the colour with grey or black, respectively, according to this number (in the interval [0, 1]): ![arctan\(a * \(dist/maxdist\)^b + c/\(1 + d*h\)\)/\(\\pi/2\)](//upload.wikimedia.org/math/e/4/c/e4c4abd5df4654acc050475c535a01d2.png), where _a, b, c_ and _d_ are parameters determining the effect.

For artificial light, we can get the colour growing darker with the distance, by mixing with black according to the number ![arctan\(l*s*\(width/dist\)^e\)/\(\\pi/2\)](//upload.wikimedia.org/math/f/1/0/f105bdb3228bbf994f31618bf89b5c2c.png), where _s_ is the scalar product of the direction vector from the eye and the slope (unit) vector, and _l_ and _e_ are parameters determining the effect.

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/2/21/Juliasetsdkpictlandman1.jpg/120px-Juliasetsdkpictlandman1.jpg)

In the Sea Horse Valley of the usual Mandelbrot set with natural light

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/4/41/Juliasetsdkpictlandjul1.jpg/120px-Juliasetsdkpictlandjul1.jpg)

Julia set for ![z^2/2 + 1/z + c](//upload.wikimedia.org/math/f/e/3/fe3f80fa4addcc3bf990928658ca7722.png) with natural light and mist

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Juliasetsdkpictlandman2.jpg/120px-Juliasetsdkpictlandman2.jpg)

Section of the Mandelbrot set for ![z^2/2 + 0.95z^4/4 + c](//upload.wikimedia.org/math/1/0/4/10478f73bfb30b2537dcf8679a5d680c.png) with artificial light

### The Drawing in More Details

We must start by choice of a scale which we apply for both the window and the landscape, namely by assigning a distance _gg_ to the width _ww_ (in pixels) of the window (or the picture). Then the width of a pixel is _hh = gg/ww_, and in the coordinate system in the window having the centre as origo, the line _i_ pixels from the left border has abscissa _xs = -gg/2 + i×hh_.

The landscape is seen from a point on the _z_-axis having _z_-coordinate _z0_, along a line _lc_ in the direction of the (positive) _y_-axis which intersects this in a point having ordinate _yc_. The fractal motif is displaced such that this point (0, _yc_) in the base plane becomes the centre of the fractal motif: if the real centre of the fractal motif is (_x1_, _y1_), we add (_x1_, _y1_) to the coordinate set in the _x-y_-system when we calculate the height and the slope.

The line (in the _y-z_-plane) from _z0_ orthogonal to _lc_, intersects the _y_-axis in a point having _y_-coordinate -_yv_ (_yv_ positive), this point is the _vanishing point_ (seeming infinitely far away from the observer). We let _d_ (= _yc+yv_) be the distance from the vanishing point to the base point _yc_. If _m_ is the distance _lc_ (from the observer to the base point) divided by the distance from the observer to the window, the vertical line in the window having abscissa _xs_, corresponds to the line in the base plane going through the vanishing point (0, -_yv_) and the point (_m×xs_, _yc_). And the point on this line having ordinate _y_, has abscissa _m×xs×(d + y - yc)/d_.

Now we choose a vertical line in the window (lying _i_ pixels from the left and thus having abscissa _xs = -gg/2 + i×hh)_, and we will colour this line by going along the corresponding line in the base plane from the distant towards the near. Assume that we on this line have reached the point having ordinate _y_. This point has abscissa _m×xs×(d + y - yc)/d_, and we shall calculate the height _z_ and the slope _s_ of the surface at the point having abscissa _x1 + m×xs×(d + y - yc)/d_ and ordinate _y1 + y - yc_. In the _y-z_-plane we have the line segment _lz_ from the observer (0, _z0_) to (_y_, _z_). The pixel in the window to be coloured (lying _i_ pixels from the left), lies _j_ pixels from the top, where _j_ is the integral part of the number _wh/2 - wj×tan(acz)_, here _wh_ is the height of the window (in pixels), _wj_ is the distance from the observer to the window also measured in pixels, and _acz_ is the angle from _lc_ to _lz_.

After this pixel have been coloured, we must estimate the ordinate _dy_ of step we shall go forward (in the direction of the negative _y_-axis) in order to colour the next (adjacent) pixel (above or below). In the _y-z_-plane we have the line segment _ly_ from the observer (0, _z0_) to (_y_, 0). We let _ay_ be the angle from the (negative) _z_-axis to _ly_ and let _ayz_ be the angle from _ly_ to _lz_. If we set

    

    ![p = \(1 + tan\(ayz\)/tan\(ay\)\)cos\(ay\)/ly + abs\(sin\(ay\)\)\(s - z\(y - s\(z0 - z\)\)/lz^2\)/\(cos\(ayz\)lz\)](//upload.wikimedia.org/math/6/0/3/6032b350afe59c280f59e92bc11b3e3c.png),

_dy_ is given by

    

    ![dy = cos\(acz\)^2/\(wh p\)](//upload.wikimedia.org/math/f/6/b/f6b0cf8fb86bb236c54b1d16e84ef7d4.png),

that is, the new _y_ is _y - dy_.

As this is only an estimation (found by differential calculus), we must arrange the program so that we can multiply the steps _dy_ by a factor _r_ < 1.

The drawing of the vertical line in the window is finished when the last pixel is drawn (number _wh_ from the top) _and_ when the new _y_ is smaller than a certain _y_ value depending on the situation of the lower border of the window, on the visual angle and on whether the landscape is turned upwards or downwards (when the surface is below the base plane and the visual angle is small, this _y_ value can lie rather far behind the lower border of the window).

### Gaps Between the Iteration Bands

There is a circumstance which can make it necessary to move forward in smaller steps, namely the tendency for gaps to develop between iteration bands, especially if a largish power appears in the formula. At the moving towards the boundary, the value of the distance function becomes smaller and smaller, but at the curves where the iteration number is increased by 1, there is a tendency towards that the calculated distance is a little smaller than it should be. The reason is, that the iteration number used in the calculation of the distance estimation must be very large, and this presupposes that the bail out radius is very small (- or very large for iteration towards infinity), but _if_ the bail out radius is as small as it ought to be, the colouring between the iteration bands becomes unclean, because the calculation of the slope is uncertain - in the same way as a fractal picture always becomes unclean when we zoom in sufficiently many times: the precision of the computer is no more enough.

### Interpolation

We can solve the problem with gaps between the iteration bands by applying interpolation: if (in the downward drawing, that is, the drawing of the visual side of the surface) the next pixel drawn is not the pixel next below, we can fill the gap by applying interpolation of the colour values. With this technique we can always produce a picture which is without perceptible faults. Furthermore, the technique means that if we let the reducing factor _r_ be larger than 1, we can draw a picture which is good enough for choice of motif and colouring very fast (faster than usual fractal pictures, because the fine fractal pattern is lesser discernible).

### Drawing Pixel for Pixel

The above drawing method is rather effective because we estimate beforehand the situation of the next pixel to be drawn. However, every time something grows up and hide the previous drawn, pixels are drawn again. Furthermore, the irregular way of drawing means that a well working program can be rather complicated (interpolation and calculation of the place in the landscape where to start at the top and stop at the bottom). It is possible to make a simpler program where the picture is drawn regularly from pixel to pixel, implying that each pixel is coloured only one time, but then several calculations are necessary for each pixel. For a given pixel on the screen we go in steps along the line from the observer through this pixel, and we stop when the calculations show that we are below the surface. In principle we could let the steps have one and the same size, but then this size had to be very small and the number of calculations would consequently be very large. Fortunately we have a tool by which we can adjust the steps so that they at first are rather large and then become smaller in the right rate, namely the distance estimation by which the landscape is constructed. But this method presupposes (or rather, works best) when the landscape is turned downwards, that is, formed below instead of above the base plane, because we then can start the stepwise approximation at the point where the line from the observer intersects the base plane and because we can let (the horizontal extent of) all the steps be ruled by the distance estimation.

From the point where the line from the observer intersects the base plane, we go successively forward in steps whose projection on the base plane is half of the estimated distance, for instance. At each step we calculate the height of the step point (on the line) and the height of the surface (below or above this point), and continue as long as the first is smaller than the later. When this is no more the case, we are below the surface, and then we must go backwards and possibly again forwards. Also these steps must be ruled by the distance estimation, because they must be smaller near the boundary. We can let step be _e×d×dist_, where _dist_ is the distance estimation and _e_ = ±1 for the step point above/below the surface, and where _d_ is a factor which is at first fixed to a given small number (e.g. 0.5) and which is divided by 2 every time _e_ alters sign. We perform the stepwise approximation until the difference between the two heights is smaller than a given smal number, _or_ until the maximum iteration number or the boundary is reached, or the number of performed operations is larger than a given large number in order to ensure that the procedure stops. If the found point on the surface corresponds to the complex number _z_ (in the base plane), we calculate the height of the surface at two points very near _z_ in the _x_\- and _y_-direction, in order to find the slope of the surface.

### Shade effect

We can (as the pictures below show) get the landscape to look more realistic by drawing shades (in the case of natural light or light not coming from the observer): a point on the surface is in shade, and thus made darker, if the line from the point in the direction of the light source has a point below the surface. The method is most profitable in the case of a turned downwards landscape, but even in this case it can be necessary to perform calculations for points outside the visible part of the landscape (unless the light source is above the visible part of the landscape):

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/8/84/Juliasetsdkpictfhf_121a.jpg/120px-Juliasetsdkpictfhf_121a.jpg)

Turned downwards landscape for ![z^2](//upload.wikimedia.org/math/7/d/b/7db5e3ec92f18b8e39aa043575959617.png)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Juliasetsdkpictfhf_239as.jpg/120px-Juliasetsdkpictfhf_239as.jpg)

The Julia set for Newton iteration for solving ![z^5 = 1](//upload.wikimedia.org/math/4/d/f/4dfa5fa7d2954f0767f57b3d69766746.png) with shade effect

  


# Quaternions

## Using More Dimensions

Julia and Mandelbrot sets can, of course, be constructed in spaces of higher dimension than two, but there is not very much gained with this, if we let the picture be a two-dimensional cut coloured in the usual way. We ought to let the cut be three-dimensional and let the set be seen as a body or a surface coloured in the same way as we have coloured a fractal landscape. We will here let the figure be white and let the light be artificial (with parallel rays), so that the picture becomes in grey-tone the nuance growing darker with the distance.

As to the function, we could let it be a mapping from the space into itself, but if it does not satisfy something corresponding to the Cauchy-Riemann differential-equations, the structure will be as in the non-complex case. These equations cannot be generalized to the three-dimensional space, but they can be generalized to the four-dimensional space, because in the four-dimensional space (in contrast to the three-dimensional space) we can introduce operations of calculation that are a natural extension of the operations of the complex numbers.

## Properties of Quaternions

The extension of complex numbers to four dimensions was discovered in 1843 by the Irish mathematician _W.R. Hamilton_ (1805-65). Hamilton called his new numbers _[quaternions](//en.wikipedia.org/wiki/Quaternions)_. The quaternions are the numbers of the form _x + yi + uj + vk_, where _x_, _y_, _u_ and _v_ are real numbers and where the two new symbols _j_ and _k_, like _i_, satisfy ![j^2 = k^2](//upload.wikimedia.org/math/e/2/9/e2984902981e2f7ef430cba8ea0d5f9c.png) = -1, and where the three symbols are connected by _ij = k_.

Of these relations it follows that _jk = i_ and _ki = j_, but also that _ji = -k_, that is, _ji = -ij_. This means that the multiplication for the quaternions is not commutative. But apart from this, the quaternions, like the real numbers and the complex number, make up a _field_: you can operate with them exactly as you operate with real and complex numbers. The _skew-field_ of quaternions is an extension of the field of complex numbers, and the quaternions have the same nice and simple properties as the complex numbers. For instance: for a polynomial p(z) of degree n, the equation p(z) = 0 has exactly n roots (some possibly multiple), and if a quaternion function f(z) is differentiable at every point of an open domain (in the quaternions), then it is differentiable any number of times.

Therefore we can without problems generalize the theory of the Julia and Mandelbrot sets to the quaternions: all we have said (critical points, cycles, potential and distance function, ...) is valid almost without modifications - only the field lines need a comment.

## Choices in Rendering Quaternion Fractals

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/17/Juliasetsdkpictquatman.jpg/220px-Juliasetsdkpictquatman.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Quaternion Mandelbrot set

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7b/Juliasetsdkpictquatjul.jpg/220px-Juliasetsdkpictquatjul.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Quaternion Julia set

We need a startegy to get from 4 dimensional patterns to 2 dimensions. We assume that our function ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) (_z_ quaternion) is a polynomial with real coefficients, and that it only contains powers of even degree (e.g. ![f\(z\) = pz^2 + qz^4](//upload.wikimedia.org/math/a/b/c/abc6ca56cc8b8d5c085b4f7dfb85ad80.png)), for then the three-dimensional subspace spanned by 1, _i_ and _j_ is left invariant by the iterations, and therefore we can restrict ourselves to this space. The critical points are complex numbers lying symmetrically around the x-axis, and we construct the Mandelbrot set from a finite critical point and ∞. A Julia set is a fractal surface, and we ought to have two ways of drawing: the filled-in Julia set, which is the complement to the Fatou domain containing ∞, and a Julia set with field lines in the inner Fatou domains (partly because there is nothing to see in an inner Fatou domain, and that the field lines are very decorative, partly because the picture is drawn faster when the domain is filled with field lines, because these lines stop the drawing procedure).

In the space we imagine a plane parallel with the _x,y_-plane with which we intersect the fractal and look at the part of it lying back (or "below") the plane. The intensity of the light is determined by the distance "down" to the fractal. The intersection plane parallel with the base plane (the _x,y_-plane) is given by a height _h_. For the Mandelbrot set the height must be positive, as we are not interested in the part lying under the _x,y_-plane (because the Mandelbrot set is symmetric around the base plane and abates on the opposite side). The nuance of the colour is calculated by consecutive estimations of the distance to the boundary and, on the basis of these estimations, approximations in steps becoming smaller and smaller. If the boundary is too thin, the sequence of approximation may jump past the fractal (giving a black dot).

### Technical Detail of Calculation

We can let the next step down be half of the estimated distance, but we must arrange the program so that we can make the steps smaller if there are faults in the picture. We must choose a little number _stepmin_, so that if the calculated step _u_ is smaller than this number, we set _u = stepmin_. For each step, we add the calculated step to a number starting with 0, and when we have reached the boundary (or the interior of the Mandelbrot set or a filled-in Julia set or a field line), we divide the distance by the highest allowable distance, which in case of a Mandelbrot set is the height _h_ of the plane, and in case of a Julia set is _h_ \+ the maximum distance we can go below the base plane (e.g. 2). The result is a number in the interval [0, 1], and we construct a grey-tone scale indexed by the numbers t in this interval, such that 0 corresponds to white and 1 to black. We can, for instance, let the colour have (equal) RGB-values that are the integral part of the number ![255/\(1+turndown+tan\(t \\pi/2\)/intensity\)^{exponent}](//upload.wikimedia.org/math/8/9/1/89190462ecc5c5893e268ecc06d19630.png), with three parameters to adjust the nuance.

For the Mandelbrot set the iteration stops when the maximum number of iterations is reached or when the iterated point is outside a sphere of a very large radius. In the latter case we calculate the distance to the boundary, and let this number determine the next step down. The same applies to a filled-in Julia set. For an inner Fatou domain, the iteration stops when a point in the sequence is within a given little distance from a (given) point in the cycle. As we do not calculate the real iteration number, we need not calculate the attraction of the cycle, but we must know the order of the cycle and (on account of the field lines) the unit-quaternion corresponding to the angle of rotation in the complex case.

## Relation between Quaternion and Complex Fractals

The intersection of the Mandelbrot set with the complex plane (that is, the base plane) is the corresponding complex Mandelbrot set, and this lies symmetrically around the x-axis (because the coefficients in our formula are real). The quaternion-Mandelbrot set (in the 3-dimensional space) is obtained by rotating the complex Mandelbrot set around the x-axis. The boundary of the Mandelbrot set is thus a rotary symmetric fractal surface with the x-axis as generator, and it consists consequently of circles around the x-axis. The Julia set associated to a point in the complex plane (that is, of height 0) also consists of circles around the x-axis. But for a point outside the complex plane the Julia set consists of closed curves or segments of curves lying askew in relation to the x-axis. In these fractal surfaces the structure is only fractal in one direction: in the direction orthogonal to this it will have the true character of a curve - a phenomenon we have seen in the non-complex fractals.

## The Field Lines

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Juliasetsdkpictquatfield1.jpg/220px-Juliasetsdkpictquatfield1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Field lines

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Juliasetsdkpictquatfield2.jpg/220px-Juliasetsdkpictquatfield2.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Field lines

The norm of the quaternion _z = x + yi + uj + vk_ is the real number |_z_| = ![\\sqrt{x^2 + y^2 + u^2 + v^2}](//upload.wikimedia.org/math/8/1/c/81cd78967cc32c45b1dbaa8c973c10ac.png), and _z_ can be written as the product of the norm and a unit-quaternion (quaternion of norm 1), this unit-quaternion is the _argument_ of _z_.

In our case where the fourth coordinate is 0, the argument is a point on the unit-sphere. And the little circle around one of the points in the cycle, which in the complex case stops the iteration, must now be replaced by a little sphere, and the field lines are constructed on the basis of regularly situated domains on this sphere. As such, we can choose the domains that result from a regularly decomposition of the equator circle and from the projection onto this.

### Technical Detail of Calculation

The technique used to draw the field lines is, however, a little complicated. Drawing is done by working our way down in as large steps as possible, but now it must be examined if a field line is hit. As the steps initially are large, we risk jumping past the field line, therefore we must (by a trial iteration) examine if a field line is in our way, and if so, alter the further procedure. If a field line is in our way, we must go forward in smaller steps, and when it is hit, we must go backwards and forwards in smaller and smaller steps, in order to find the precise point of intersection with the field line. The steps we go down are usually (that is, when we disregard field lines) half of the estimated distance, and we may now have to reduce the steps.

If we set ![g\(z\) = f\(z\) + c](//upload.wikimedia.org/math/e/8/3/e83d78623957e5ffe2b3b02643af71b5.png), and if the order of the attracting cycle is _r_ and if _z*_ is a point in the cycle, then _z*_ is a fixed point for ![g\(g\(...g\(z\)\)\)](//upload.wikimedia.org/math/4/7/0/470a9279baa1443bb61353348b06f869.png) (the _r_-fold composition), and near _z*_ this map has (in connection with field lines) character of a _rotation_ with the argument ![\\beta](//upload.wikimedia.org/math/0/7/1/071997f13634882f823041b057f90923.png) of the quaternion ![\(d\(f\(f\(...f\(z\)\)\)\)/dz\)_{z*}](//upload.wikimedia.org/math/7/8/2/78259c1b8c95b8f7099a7bb1b220b053.png) = the product of the quaternions ![f'\(z_i\)](//upload.wikimedia.org/math/2/e/e/2ee35d6ca6712e8e5dced4aff3839ffa.png), for the _r_ points in the cycle.

A given direction ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) (= quaternion of norm 1) outgoing from _z*_ determines a field line, and this consists of the points _z_ such that if the argument of ![z_k - z*](//upload.wikimedia.org/math/d/2/2/d2205de443996242c3196a05dcadad12.png) is ![\\psi](//upload.wikimedia.org/math/1/9/d/19df1c2726ed43128440c1157f72a937.png) (![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) = the last point in the iteration), then ![\\psi \\beta^{-k} = \\theta](//upload.wikimedia.org/math/2/0/c/20cc74d65e816a6c94acd19f64aa1db2.png). Therefore we must know the _k'_th power of a unit-quaternion, and this can be calculated by this formula:

    ![\\displaystyle \(x, y, u, v\)^k = \(cos\(k \\kappa\), ty, tu, tv\)](//upload.wikimedia.org/math/b/9/9/b991b540361f8657b17c156ed55230c1.png)

where ![\\kappa](//upload.wikimedia.org/math/c/7/8/c78f6d0f108bd13554e62804d0790f42.png) is an angle such that ![x = cos\(\\kappa\)](//upload.wikimedia.org/math/1/b/e/1be84864d31554a8a139dc561cb37f7e.png) and where t is calculated recursively by the following operation performed _k_ times and starting with _t_ = 0 and _i_ = 0:

    ![\\displaystyle t = cos\(i \\kappa\) + tx](//upload.wikimedia.org/math/0/b/2/0b25708967a0b39cdc28900f5a4b4166.png) and ![\\displaystyle i = i + 1](//upload.wikimedia.org/math/8/f/3/8f3ee33057c53e99ee1b7cdbf7d89464.png).

Let _n_ be the number of field lines and let _t_ be their relative thickness (a number in the interval [0, 1]). For the point _z_, we have calculated ![\\psi \\beta^{-k}](//upload.wikimedia.org/math/0/7/2/07284a4900245a17c1144dd20df5874b.png), which is a unit-quaternion and therefore corresponds to a point on the unit sphere. As the domains of this determining the field lines are chosen such that they result from a regular decomposition of the equator circle, the condition depends only on the argument of the projection of this quaternion on the complex plane. If _v_ is this angle (chosen in the interval [0, 2![\\pi](//upload.wikimedia.org/math/5/2/2/522359592d78569a9eac16498aa7a087.png)[) divided by 2![\\pi](//upload.wikimedia.org/math/5/2/2/522359592d78569a9eac16498aa7a087.png), then _z_ belongs to a field line if _|v - i/n| < t/(2n)_, for one of the integers _i_ = 0, 1, ..., _n_.

However, as we want to know if a field line is in our way, we do first perform a pre-calculation which calculates the distance to the boundary and determines the field line in question, and this is the one having the number _i_ such that _|v - i/n| < 1/(2n)_. We calculate the number _d = 2n|v - i/n| - t_. If d is negative, the point _z_ actually belongs to the field line, and the point is coloured white. Otherwise, we regard _d_ as a measure for the distance to the field line, and we multiply the calculated step by _d_, so that the steps become smaller when we are near a field line.

We must find the precise point in our way down where the field line is hit. Therefore we go backwards and forwards in smaller and smaller steps. We call the actual height _h1_ and the old height _h2_. When we for the first time are inside a field line, we set _h3 = h1_ and _h1 = (h1 + h2)/2_, and calculate again if we are inside the field line. If no, we set _h2 = h1_ and _h1 = (h1 + h3)/2_, if yes we set _h3 = h1_ and _h1 = (h1 + h2)/2_. We do this until _h2 - h1 < stepmin_. The distance to the field line is then _h - h1_ (_h_ is the height of the plane).

  


# History

## Newton

Already in the antiquity it was known, that if the fraction ![x_0](//upload.wikimedia.org/math/0/b/2/0b21a666a81629962ade8afd967826ed.png) is near _√a_, then the fraction ![x_1 = \(x_0 + a/x_0\)/2](//upload.wikimedia.org/math/d/0/5/d05eca55ee631a308301d599946dda2a.png) is a better approximation to _√a_. For if ![x_0](//upload.wikimedia.org/math/0/b/2/0b21a666a81629962ade8afd967826ed.png) is an approximation to _√a_ that is smaller than _√a_, then ![a/x_0](//upload.wikimedia.org/math/6/7/9/67951b15fd6b7e9a1086e0b3555472f9.png) is an approximation to _√a_ that is larger than _√a_, and conversely, therefore ![x_1 = \(x_0 + a/x_0\)/2](//upload.wikimedia.org/math/d/0/5/d05eca55ee631a308301d599946dda2a.png) is a better approximation to _√a_ than both ![x_0](//upload.wikimedia.org/math/0/b/2/0b21a666a81629962ade8afd967826ed.png) and ![a/x_0](//upload.wikimedia.org/math/6/7/9/67951b15fd6b7e9a1086e0b3555472f9.png). We can, of course, repeat the procedure, and it is very effective: you get an approximation to _√a_ with ten correct digits, if you start with ![x_0](//upload.wikimedia.org/math/0/b/2/0b21a666a81629962ade8afd967826ed.png) = 1.5 and apply the procedure three times.

To find the square root of ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png), is to solve the equation ![x^2 - a = 0](//upload.wikimedia.org/math/5/f/4/5f4d3f0342dce70868830f13caa6adf1.png), and we have solved this equation by the _iteration_ ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) → ![\(x + a/x\)/2](//upload.wikimedia.org/math/c/6/b/c6b43b254bfe424299b2d85b5221725c.png). And it is this method we must apply for solving an equation, if we do not have a formula, or if this - after the invention of the computer - seems too laborious to use.

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Juliasetsdkpicthist1.jpg/220px-Juliasetsdkpicthist1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Newton iteration

It was _Newton_ who described the general procedure: if ![f\(x\)](//upload.wikimedia.org/math/5/0/b/50bbd36e1fd2333108437a2ca378be62.png) is a (continuous) differentiable function which intersects the x-axis near ![x = x_0](//upload.wikimedia.org/math/4/3/5/4354047bfb538af878fb79fb1fd72899.png), and we apply the iteration ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) → ![x - f\(x\)/f'\(x\)](//upload.wikimedia.org/math/6/c/5/6c5c5ecda9140b4d827c1e6022fa9765.png) a number of times starting in ![x_0](//upload.wikimedia.org/math/0/b/2/0b21a666a81629962ade8afd967826ed.png), then we get a good approximation to a solution _x*_ of the equation ![f\(x\)](//upload.wikimedia.org/math/5/0/b/50bbd36e1fd2333108437a2ca378be62.png) = 0 (because we have assumed that ![f\(x\)](//upload.wikimedia.org/math/5/0/b/50bbd36e1fd2333108437a2ca378be62.png) intersects the x-axis, ![f'\(x\)](//upload.wikimedia.org/math/7/4/c/74caf4d1ec90d3a36ea7c7bbfe65b516.png) <> 0 near the point _x*_ where ![f\(x*\)](//upload.wikimedia.org/math/9/7/d/97d5d6eae4678d1ca64bbb6737d8705a.png) = 0).

The method can be generalized, so that it works for ![f'\(x*\)](//upload.wikimedia.org/math/3/4/f/34f7d257e8d111bac325523d314d6da4.png) = 0, but if ![f'\(x\)](//upload.wikimedia.org/math/7/4/c/74caf4d1ec90d3a36ea7c7bbfe65b516.png) converges to ∞ for _x_ converging to _x*_, as it is the case for ![f\(x\) = x^{1/3}](//upload.wikimedia.org/math/a/a/6/aa6b940b583df53803c6ab394a6d5c44.png) and _x*_ = 0, then the procedure leads away from the solution.

There are situations where a solution cannot be found by this method, and there can be points whose sequence of iteration either converges towards a cycle of points (containing more than one point) or does not converge. This question ought to be studied more closely, advertised the English mathematician _Arthur Cayley_ in 1879 in a paper of only one page. He was aware, that the Newton procedure could as well be applied for solving a complex equation ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) = 0, and he proposed that we "look away from the realities" and examine what can happen when the iteration does not lead to a solution. But this proposal was his only contribution to the theory.

## Julia and Fatou

Thirty years passed before anyone took up this question. But then the two french mathematicians _Gaston Julia_ (1893-1978) and _Pierre Fatou_ (1878-1929) published papers where they examined iteration of general complex rational functions, and they proved all the facts about "Julia" sets and "Fatou" domains we have used here. Julia and Fatou were of course not able to produce detailed pictures showing the Julia set for Newton iteration for solving the equation ![z^3](//upload.wikimedia.org/math/8/c/8/8c88da3328d76ff9f022d1a17c8a9f2c.png) = 1, for instance, but they knew that the Julia set in this case is not a curve. Cayley certainly imagined that the plane would be divided up by geometrical curves, and if he did so, it was not unforgivable, for this is namely the case for the so-called weak Newton procedure: this leads more slowly but more safe to a solution.

We have intimated, that our mean results regarding Julia sets, were known to Julia and Fatou. This is not quite true, for the fact that the sequences of iteration in the neutral case can go into _annular_ shaped revolving movements, was first discovered in 1942 by the German mathematician _C.L. Siegel_. We have said that these revolving movements can be either polygon or annular shaped, that they are lying concentrically and that there is a finite cycle which is _centre_ for the movements. And possibly the reader has wondered: this centre cycle, does it belongs to the Fatou domain or to the Julia set? We will now answer this question. In the section about field lines we have defined a complex number ![\\alpha](//upload.wikimedia.org/math/b/c/c/bccfc7022dfb945174d9bcebad2297bb.png) which in the attracting case has norm smaller than 1, but which in the neutral case has norm 1 and therefore corresponds to an angle (its argument). When this angle is rational (with respect to ![2\\pi](//upload.wikimedia.org/math/4/6/a/46a6c4d715584adb3e6681ee351d1df6.png)), the terminal movements are finite (polygonal, the _parabolic_ case), and the centre cycle belongs to the Julia set, when the angle is irrational, the terminal movements are infinite (annular, the _Siegel-disc_ case), and the centre cycle belongs to the Fatou domain.

## Mandelbrot

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Juliasetsdkpicthist2.jpg/220px-Juliasetsdkpicthist2.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The Mandelbrot set for ![\\lambda z\(1 - z\)](//upload.wikimedia.org/math/8/2/4/8245f587c162833e02a8802d3cfba9d5.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/75/Juliasetsdkpicthist3.jpg/220px-Juliasetsdkpicthist3.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Section of the above Mandelbrot set

But apart for such few results, not very much happened in this theory before _Benoit B. Mandelbrot_ (1924-2010) in the late 1970s began his serious study of Julia sets by using computer. It is Mandelbrot who has coined the word _fractal geometry_. He had had Julia as teacher (at _École Polytechnique_), and around 1964 he began his "varied forays into unfashionable and lonely corners of the Unknown". But the fractal patterns he first studied were self-similar in the strict sense of this word, namely invariant under _linear_ transformation. It was first in 1978-79 he began his study of Julia sets for rational complex functions. He made some print-outs and he studied _families_ of rational complex functions, formed by _multiplying_ the function by a complex parameter ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png). His intention was to let the computer draw a set M of parameters ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) for which the Julia set is not (totally) disconnected (a "fractal dust"). Such a program could be made very simple: he found two critical points for the function, and plotted the points ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) for which the two critical points did not iterate towards the same cycle. For then there would be at least two Fatou domains, and therefore the Julia set would not be a dust cloud. He chose functions for which he knew a real parameter value ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) such that the iteration behaved chaotically on some real interval, for then this ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) might belong to his set M.

He began (in 1979) with the family ![\\lambda \(1 + z^2\)^2/\(z\(z^2 - 1\)\)](//upload.wikimedia.org/math/e/f/0/ef0bee1dc1207152e35c6dae9ab6bc1a.png) (having four real and two imaginary critical points). For ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) = 1/4 it behaves chaotically on an interval, and he "felt that in order to achieve a set having a rich structure, it was best to pick a complicated map (every beginner I have since then watched operate has taken the same tack)". The picture where ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) varied over the complex plane, showed a highly structured but very fuzzy "shadow" of the set. A very blotchy version, but "it sufficed to show that the topic was worth pursuing, but had better be persued in an easier context".

Then (in 1980) he studied the family ![\\lambda z\(1 - z\)](//upload.wikimedia.org/math/8/2/4/8245f587c162833e02a8802d3cfba9d5.png) (having critical points 1/2 and ∞), which for ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) = -2 and 4 behaves chaotically on the interval [-2, 2]. He saw two discs of radius 1 and centres in 0 and 2: "Two lines of algebra confirmed that these discs were to be expected here, and that the method was working. We also saw, on the real line to the right and left of the above discs, the crude outlines of round blobs which I call "atoms" today. They appeared to be bisected by intervals known in the Myrberg theory, which encoraged us to go on to increasing bold computations. For a while, every investment in computation yielded increasing sharply focussed pictures. Helped by imagination, I saw the atoms fall into a hierarchy, each carrying smaller atoms attached to it".

"After that, however, our luck seemed to break; our pictures, instead of becoming increasingly sharp, seemed to become increasingly messy. Was this the fault of the faltering Textronix [cathode ray tube ("worn out and very faint")]?". Mandelbrot ran the program on another computer: "The mess had failed the vanish! In fact, as you can check, it showed signs of being systematic. We promptly took a much closer look. Many specks of dirt duly vanished after we zoomed in. But some specks failed to vanish; in fact, they proved to solve into complex structures endowed with "sprouts" very similar to those of the whole set M. Peter Moldave and I could not contain our excitement. Some reasons made us redo the whole computation using the equivalent map _z_ → ![z^2 - c](//upload.wikimedia.org/math/2/b/f/2bf617403120a3d1f1b1ffd51ad0e19e.png), and here the main continent of the set M proved to be shaped like each of the islands! Next, we focussed on the sprouts corresponding to different orders of bifurcation, and we compared the corresponding off-shore islands. They proved to lie on the intersection of stellate patterns of logarithmic spirals! (...) We continued to flip in this fashion between the set M and selected Julia sets J, and made an exciting discovery. I saw that the set M goes beyond being a numerical record of numbers of points in limit cycles. It also has uncanny "hieroglyphical" character: including within itself a whole deformed collection of reduced-size versions of all the Julia sets".

_References_

Mandelbrot, B.B.: Fractals and the Rebirth of Iteration Theory. In: Peitgen & Richter: _The Beauty of Fractals_ (1986), pp 151-160 (in this article you can see Mandelbrots first two print-outs of the last picture).

Mandelbrot, B.B.: Fractal aspects of the iteration of z → ![\\lambda z\(1 - z\)](//upload.wikimedia.org/math/8/2/4/8245f587c162833e02a8802d3cfba9d5.png) for complex ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) and _z_. In: Nonlinear Dynamics, Annals New York Acad. Sciences 357 (1980), pp 249-259.

  


# Postscript

## Julia and Mandlebrot sets broke new ground in 1980s

The Julia and Mandelbrot sets were the first fractals that really amazed the world when they appeared in the 1980s. These pictures displayed patterns that differed entirely from anything previously known and beyond anyone's imagination. They could furthermore possess real beauty. The hitherto known fractal patterns were sets that had more or less interesting mathematical properties, and when they could be visualized, they could exhibit thought-provoking shapes, but they were not as impressive as the new types.

## Popularity of Fractal Art

Because of the Julia and Mandelbrot sets - not least the simplicity of the software for drawing them - the concept of fractal became very popular. This concept has since become extremely widespread leading on to many varieties of _fractal art_. This development has revealed an extreme variation in possible patterns. Pictures and animations have been made of great artistic value or displaying an elaborate piece of mathematical work. However, all the serious work has been on other things than improving the basic presentation of the Julia and Mandelbrot sets. Pictures of fractal sets in their "pure" form, without artistic elaboration, do not seem to appeal to people as much today as they did in the 1980's and work on improving the basics has slid into the background.

## Lack of Awareness of flaws in 'standard' Renderings

Until early 2000 there was little or no progress as regards the basic drawing technique. Until 2003 not a single picture had been made where the boundary was drawn, apart from some pictures of the usual Mandelbrot set and its Julia sets[1]. Also the colouring based on the real iteration number only really works when the cycle is a fixed point, and even there leads to avoidable 'banding' effects, yet this colouring is in almost universal use, even when the cycle is not a fixed point. Furthermore, until early 2000, not a single Mandelbrot set had been constructed from two finite and different critical points.

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Juliasetsdkpostex1.jpg/333px-Juliasetsdkpostex1.jpg)

Mandelbrot set constructed from one point that is not a critical point; rendered without boundary and with jumps in the colouring

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/4/46/Juliasetsdkpostex2.jpg/333px-Juliasetsdkpostex2.jpg)

Mandelbrot set constructed using two different critical points; shows boundary in the upper half part and continuous colouring

The two images above show the opportunity for a more mathematically correct and more aesthetically pleasing way to render fractals than the method commonly used. The right hand image shows the boundary correctly and it does not exhibit the banding effects. Can this opportunity for improvement really be true? Can it be true, that twenty years after the Julia and Mandelbrot sets first saw the light of day, only now are technically perfect pictures beginning to turn up?

### A possible explanation

The most influential book about Mandelbrot and Julia sets is probably Peitgen & Richter: _The Beauty of Fractals_ from 1986. In this book you can see the first _real_ pictures of the Mandelbrot set, because they were drawn by distance estimation and in black-and-white. Mandelbrot saw exciting patterns when he zoomed down into his set - stellate patterns of logarithmic spirals and uncanny and "hieroglyphical" reduced-size versions of the Julia sets - but he only see all this, because his maximum iteration number was low. The right hand picture below, with boundary and maximum iteration number 10,000 shows how the Mandlebrot set should look. The left picture is less mathematically precise, using 1,000 iterations, and is not calculating the boundary. If the left picture were drawn with the same maximum iteration number of 10,000, but still without the boundary calculation, we would only have seen the mini-mandelbrot visible in the centre of the right image. The other detail would be 'too fine' to see.

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Juliasetsdkpictpost2.jpg/333px-Juliasetsdkpictpost2.jpg)

Without boundary calculation and with max iteration number 1,000

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/6/68/Juliasetsdkpictpost1.jpg/333px-Juliasetsdkpictpost1.jpg)

With boundary calculation and with max iteration number 10,000

### Misconceptions from a Flawed Example Program

_The Beauty of Fractals_ gives an almost correct computer program for the distance estimation shown in the right image. A possible reason that that method did not gain ground is that the procedure in this program is seriously flawed: The calculation of ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) is performed (and completed) before the calculation of ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png), and not after as it ought to be (![z'_{k+1}](//upload.wikimedia.org/math/a/9/c/a9c294b830ae86d8921190d8174bb9f3.png) uses ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png), not ![z_{k+1}](//upload.wikimedia.org/math/3/0/b/30b8b4a5bc3a9ff577f89fafc53158bb.png)). For the successive calculation of ![z'_k](//upload.wikimedia.org/math/b/8/7/b870e6472588009ef636529e5c07162a.png), we must know ![f'\(z_k\)](//upload.wikimedia.org/math/f/d/a/fda203de16b982b93f4ec2ed8981952e.png) (which in this case is 2![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png)). In order to avoid the calculation of ![z_k](//upload.wikimedia.org/math/6/8/9/68971407c637f6163d40770cc048e5de.png) (_k_ = 0, 1, 2, ...) again, this sequence is saved in an array. Using this array, ![z'_{k+1} = 2z_kz'_k + 1](//upload.wikimedia.org/math/0/5/1/051923695e22d0d9ab314fc882ed9c1e.png) is calculated up to the last iteration number, and it is stated that overflow can occur. If overflow occurs the point is regarded as belonging to the boundary (the bail-out condition). If overflow does not occur, the calculation of the distance can be performed. Apart from it being untrue that overflow can occur, the method makes use of an unnecessary storing and repetition of the iteration, making it unnecessarily slower and less attractive. The following remark in the book is nor inviting either: "It turns out that the images depend very sensitively on the various choices" (bail-out radius, maximum iteration number, overflow, thickness of the boundary and blow-up factor). Is it this nonsense that has got people to lose all desire for using and generalizing the method?

## References

  1. ↑ Boundary set renderings, [juliasets.dk](http://www.juliasets.dk/Fractals.htm) (started 2003 and completed 2009)

  


# References

Almost all the theorems and formulas in this Wikibook can be found in:

  * Peitgen & Richter: _The Beauty of Fractals_, Springer-Verlag 1986 ([ISBN 0-387-15851-0](/wiki/Special:BookSources/0387158510)).

See also these Wikipedia articles:

  * [Julia set](//en.wikipedia.org/wiki/Julia_set)
  * [Mandelbrot set](//en.wikipedia.org/wiki/Mandelbrot_set)
  * [Attractor](//en.wikipedia.org/wiki/Attractor)

For the statement in the Postscript, see this article:

  * [The Sad Fate of the Fractals](http://www.juliasets.dk/FractalsAndArt.htm)

  


# Terminology

All the definitions are for points, functions, subsets, ... of _the plane_. We identify the points of the plane with the complex numbers and with vectors.

**accumulation point** (or _cluster_, or _limit point_) for a set: a point _z_ such that each neighbourhood of _z_ contains points of the set

**boundary** of a set: the set of points that are point of accumulation for the set as well as for the complement of the set

**Cauchy-Riemann equations** for a differentiable function ![f\(x, y\) = f_x\(x, y\) + if_y\(x, y\)](//upload.wikimedia.org/math/b/2/e/b2ea0d609390487cc2f52c0aa9631a4b.png) of the plane into itself: the two equations

    ![\\frac{\\partial}{\\partial{x}}f_x = \\frac{\\partial}{\\partial{y}}f_y](//upload.wikimedia.org/math/f/3/9/f39d86a326f8b14f51d36d4fcdac1074.png) and ![\\frac{\\partial}{\\partial{y}}f_x = -\\frac{\\partial}{\\partial{x}}f_y](//upload.wikimedia.org/math/5/1/1/511920ce23c68bc21abc9dd36860b2e4.png),

if they are satisfied, the function is differentiable as a complex function

**cardioid**: a heart-shaped curve (generated by a fixed point on a circle as it rolls round another circle of equal radius)

**closed set**: a set whose complement is an open set

**complex number**: a "two-dimensional" number, a number of the form _(x, y)_, where x and y are real numbers, such a pair is usually written _x+iy_, where _x_ and _y_ are separated by the **imaginary unit** _i_, satisfying ![i^2 = -1](//upload.wikimedia.org/math/6/8/5/685245741281622a3f11315dfd81cd98.png)

**convergence**: a sequence ![z_i](//upload.wikimedia.org/math/b/7/2/b72ebeb95f4bb3e84afd94141a57b13b.png) (_i_ = 0, 1, 2, ...) converges to the point _z*_, if for each neighbourhood _U_ of _z*_, there exists a number N such that ![z_i](//upload.wikimedia.org/math/b/7/2/b72ebeb95f4bb3e84afd94141a57b13b.png) belongs to _U_ for i > N. The sequence converges to the finite cycle _C_ of order _r_, if for each point _z*_ of the cycle the sequence ![z_{n+ir}](//upload.wikimedia.org/math/7/6/0/7605e9d462511b953933a6c2c41357bc.png) (for some n) converges to _z*_

**countabel set**: a set that can be put into a ono-to-one correspondance with the natural numbers, the rational numbers is a countabel set

**critical point** of a complex differentiable function f(z): a zero for the derivative f'(z)

**cycle**: a finite set of points in the plane, it can contain the point _infinity_, its number of elements is called its **order**

**derivative** (or _differential quotient_) of the complex function _f(z)_ in the point _z*_: the number

    ![f'\(z*\) = \(df\(z\)/dz\)_{z=z*} = \\lim_{h \\to 0}\(f\(z*+h\) - f\(z*\)\)/h](//upload.wikimedia.org/math/b/f/a/bfa2fba3fd4770568efa773c9f3b8e04.png)

(h complex) if it exists

**determinant** of the 2x2 matrix {![a_{ij}](//upload.wikimedia.org/math/5/f/e/5fe0de05a0584639c658a0815efccce9.png)}: the real number |{![a_{ij}](//upload.wikimedia.org/math/5/f/e/5fe0de05a0584639c658a0815efccce9.png)}| = ![a_{11}a_{22} - a_{12}a_{21}](//upload.wikimedia.org/math/a/5/1/a51637c71fe082074159c01dabdf2298.png)

**holomorphic** (or _analytic_) function: a complex function defined on an open set of the plane, that is complex differentiable in every point of the open set, such a function possesses derivatives of all orders

**interior point** of a set: a point _z_ such that a neighbourhood of _z_ is contained in the set

**iteration**: repeated operation with the same function f(z): ![z_1 = f\(z_0\), z_2 = f\(z_1\), z_3 = f\(z_2\), ...](//upload.wikimedia.org/math/1/2/7/127dd45eaa6503149e223df478068c87.png)

**lim**: if the sequence ![a_n](//upload.wikimedia.org/math/9/d/e/9ded7825070b255e7bc092cdc2c8e98a.png) (_n_ = 0, 1, 2, ...) converges to the number _a_, we write _limn → ∞ an = a_, if the value of the function _f(z)_ converges to _a_ for _z_ converging to _z*_, we write _limn → ∞ f(z) = a_

**matrix**: a rectangular array of numbers {![a_{ij}](//upload.wikimedia.org/math/5/f/e/5fe0de05a0584639c658a0815efccce9.png)} (_i = 1, ..., m, j = 1, ..., n_)

**neighbourhood** of a point _z_: a set containing a (small) circle with centre _z_

**Newton iteration** for an equation _g(z)_ = 0: the iteration function ![f\(z\) = z - g\(z\)/g'\(z\)](//upload.wikimedia.org/math/d/b/0/db0e22b24e87502038b16a5faa90e4f6.png), if the sequence of iteration generated by a point converges to a fixed point, then this point is a solution to the equation _g(z) = 0_

**norm** of a complex number _z = x+iy_: the real number _|z| = √(x2 \+ y2)_ ≥ 0

**open set** a set all points of which are interior points

**partial derivative with respect to x** of the function _f(z)_ in the point _z_: the number

    ![\\partial f\(z\)/\\partial{x} = lim_{h \\to 0}\(f\(z+h\) - f\(z\)\)/h](//upload.wikimedia.org/math/d/e/e/deea8b3d33c04c131c2f0f7f0ae87745.png)

where h is real (if it exists)

**partial derivative with respect to y** of the function _f(z)_ in the point _z_: the number

    ![\\partial f\(z\)/\\partial{y} = lim_{h \\to 0}\(f\(z+ih\) - f\(z\)\)/h](//upload.wikimedia.org/math/a/2/9/a2967657a7d9a8b9c698bd4e114b55c3.png)

where h is real (if it exists)

**polynomial** of degree n: a function of the form ![a_0 + a_1z + a_2z^{2} + ... + a_nz^{n}](//upload.wikimedia.org/math/8/8/8/888c878212631450bcca430a3f212d75.png)

**rational function**: a function of the form _p(z)/q(z)_, where _p(z)_ and _q(z)_ are polynomials

**scalar product** of the two vectors ![v_1](//upload.wikimedia.org/math/1/7/5/175fb02dc71571bb97cf42967a26105c.png) = {![x_1](//upload.wikimedia.org/math/f/9/a/f9a3b8e9e501458e8face47cae8826de.png), ![y_1](//upload.wikimedia.org/math/f/7/b/f7b4a9a272539da17df482a540896746.png)} and ![v_2](//upload.wikimedia.org/math/4/3/0/43078bbe67ed8d55801deec58a70f40b.png) = {![x_2](//upload.wikimedia.org/math/8/f/4/8f43fce8dbdf3c4f8d0ac91f0de1d43d.png), ![y_2](//upload.wikimedia.org/math/8/9/f/89f771207ffb39300acb88dff8bae241.png)}: the real number ![v_1*v_2 = x_1x_2 + y_1y_2 = |v_1||v_2|cos\(\\theta\)](//upload.wikimedia.org/math/3/2/b/32b9c18c91144f0f6a06ad1a215f812c.png), where ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) is the angle between ![v_1](//upload.wikimedia.org/math/1/7/5/175fb02dc71571bb97cf42967a26105c.png) and ![v_2](//upload.wikimedia.org/math/4/3/0/43078bbe67ed8d55801deec58a70f40b.png)

**transcendental function**: a function that cannot be constructed in a finite number of steps from elementary functions and their inverses, e.g. ![sin\(z\) = z - z^{3}/3! + z^{5}/5! - z^{7}/7! + ...](//upload.wikimedia.org/math/2/4/b/24b22a02124ebe69231916d4b3ceafe6.png), where n! = 1x2x3x...xn

**uncountabel set**: a set that is not countable, such a set (belonging to the plane) can be put into a one-to-one correspondance with the real numbers

  


**Rules for operation with complex numbers**

    _i2 = -1_
    _(x1 \+ iy1) + (x2 \+ iy2) = (x1 \+ x2) + i(y1 \+ y2)_
    _(x1 \+ iy1)(x2 \+ iy2) = (x1x2 \- y1y2) + i(x1y2 \+ x2y1)_
    _(x1 \+ iy1)/(x2 \+ iy2) = ((x1x2 \+ y1y2) + i(-x1y2 \+ x2y1))/ (x22 \+ y22)_

The **conjugate** number to ![z = x+iy](//upload.wikimedia.org/math/c/a/2/ca2af66001a5f8f08a940e0de92fccdb.png) is ![z^- = x-iy](//upload.wikimedia.org/math/3/9/6/396024f437793835ed56f9df96849ea9.png), that is, the reflection of _z_ in the x-axis. The **norm** of _z_ is the real number _|z| = √(x2 \+ y2)_. We have ![|z|^2 = zz^-](//upload.wikimedia.org/math/d/f/9/df9447a0728c7660b41524dd7bb748f7.png). From this, we can derive the rule for division: ![z/w = zw^-/\(ww^-\) = zw^-/|w|^2](//upload.wikimedia.org/math/2/d/c/2dc25d24cc5b95e935e554222edd2b1d.png).

A complex number _z = x + iy_ can be written

    ![z = r\(sin\(\\theta\) + icos\(\\theta\)\)](//upload.wikimedia.org/math/a/6/3/a63ddef5099706a3f2a6490a094a2b2d.png)

where _r_ is the norm of _z_:

    _r = |z| = √(x2 \+ y2)_

and where the angle ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) is the **argument** _arg(z)_ of _z_:

    ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) = _arctan(y/x) for x > 0_
    ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) = _arctan(y/x) + ![\\pi](//upload.wikimedia.org/math/5/2/2/522359592d78569a9eac16498aa7a087.png) for x < 0_

_arg(z)_ is multivalued: _arg(z)_ = ![\\theta + n2\\pi i](//upload.wikimedia.org/math/0/f/d/0fd51018aed773a1a2d9fa93054c24b6.png), for every integer _n_.

The point ![sin\(\\theta\) + i cos\(\\theta\)](//upload.wikimedia.org/math/b/c/3/bc3785c134ee61fa6b9fe973cfc7d96b.png) (lying on the unit circle) is also denoted ![e^{i\\theta}](//upload.wikimedia.org/math/d/8/d/d8d6f8466e46b0d087286a91cc71e739.png), and we define the **exponential function** ![exp\(z\)](//upload.wikimedia.org/math/6/7/0/6700cc9ef740efc5b76dc2386a57017a.png) by

    ![exp\(z\) = e^z = e^{x+iy} = e^x e^{iy}](//upload.wikimedia.org/math/b/e/1/be1c23aa592a6ffd10dbd20337baaf33.png)

The _sinus and cosinus relations_ can be written

    ![cos\(\\theta_1+\\theta_2\) + i sin\(\\theta_1+\\theta_2\) = \(cos\\theta_1 + i sin\\theta_1\)\(cos\\theta_2 + i sin\\theta_2\)](//upload.wikimedia.org/math/f/e/6/fe647c7654f270eac2607b67903edad3.png)

and from this we see that ![e^z](//upload.wikimedia.org/math/5/5/d/55da574462bedb4e146729b59e82ecda.png) has the exponential property for _z_ imaginary:

    ![e^{i\(\\theta_1 + \\theta_2\)} = e^{i\\theta_1}e^{i\\theta_2}](//upload.wikimedia.org/math/1/d/6/1d6dc0d3255e8ad1308f6b34b2394322.png)

The **logarithm function** _log(z)_ is defined as the inverse function to _exp(z)_: _log(z) = w_ if _exp(w) = z_. We have _log(z) = log|z| + i arg(z)_. _log(z)_ is multivalued: ![log\(z\) = w + n2\\pi i](//upload.wikimedia.org/math/3/f/3/3f35ee3e93f08a21a367108783842e36.png), for every integer _n_.

For a positive real number _a_ and a complex number _z_, we define ![a^z = e^{log\(a\)z}](//upload.wikimedia.org/math/4/c/3/4c35aa86f5a6247d43d3c4db683a8b8e.png). For a complex number _z_, the power ![z^n](//upload.wikimedia.org/math/b/6/c/b6c7f3a06257d72e6dfc4590da36688b.png) is only defined when the exponent _n_ is an integer.

  
**Differentiable complex function**

A complex function defined on an open domain of the plane is called **holomorphic** (or _analytic_), if it is differentiable in every point of this domain. If that is so, the derived function f'(z) is also differentiable in every point (this theorem is not true for real functions). We have the usual rules for differentation:

![d\(f\(z\) + g\(z\)\)/dz = df\(z\)/dz + dg\(z\)/dz](//upload.wikimedia.org/math/c/3/a/c3a0f7e2d1496e7ee867624537f251d6.png)

![d\(f\(z\)g\(z\)\)/dz = \(df\(z\)/dz\)g\(z\) + f\(z\)\(dg\(z\)/dz\)](//upload.wikimedia.org/math/c/e/8/ce89ed960e3d6ccb54290668340b4783.png)

![\(d\(f\(g\(z\)\)/dz\)_{z*} = \(df\(z\)/dz\)_{g\(z*\)}\(dg\(z\)/dz\)_{z*}](//upload.wikimedia.org/math/c/1/4/c147399a9d02a05fcdb4b464857cf66f.png)

![d z^n/dz = nz^{n-1}](//upload.wikimedia.org/math/5/5/a/55a245872df9f21764689254f15d8f43.png) (_n_ integer)

![d a^z/dz = log\(a\)a^z](//upload.wikimedia.org/math/7/4/9/74901523f3628d4c03c1e0c23426944a.png) (_a_ positive real number)

![d\(exp\(z\)\)/dz = exp\(z\)](//upload.wikimedia.org/math/7/0/5/7059c5dfa91ea77fd1b26b801d588899.png)

![d\(log\(z\)\)/dz = 1/z](//upload.wikimedia.org/math/5/3/4/534a81c8112897d731c1dbb7f2e1122f.png)

From these rules, we can derive all we need, for instance:

![d\(f\(z\)^{-1}\)/dz = -f'\(z\)/f\(z\)^2](//upload.wikimedia.org/math/0/7/8/07869d4146baa9c8168eb2bac659fb03.png)

![d\(log\(f\(z\)\)\)/dz = f'\(z\)/f\(z\)](//upload.wikimedia.org/math/0/e/b/0eb4311fb07162b92d672bf27ea1ba63.png)

For the computer it is easy to find _f'(z)_: _f'(z) = (f(z+h) - f(z))/h_ for ![h = 10^{-9}](//upload.wikimedia.org/math/c/3/3/c33e4e26ae54f7ef2be91608863ca3b5.png), for instance.

  
**The derivative of a function into the real numbers**

The real function _f(z)_ on a domain of the plane, is differentiable in the point _z_, if

    _limt → 0 (f(z + th) - f(z))/t_

(t real) exists for every complex number h, and if the hereby defined function ![Df\(z\)\(h\)](//upload.wikimedia.org/math/e/7/3/e739b24722111cee0bcfc0bd13c2a1c5.png) from the complex numbers (h) into the real numbers satisfies ![Df\(z\)\(h_1 + h_2\) = Df\(z\)\(h_1\) + Df\(z\)\(h_2\)](//upload.wikimedia.org/math/3/0/2/30284e4ca6cc52f802a4034241a6b35e.png). As we also have ![Df\(z\)\(th\) = t Df\(z\)\(h\)](//upload.wikimedia.org/math/c/a/6/ca68e8d1dadb7efa2d16c1bf7433c236.png), for t real, this mapping is _linear_. It is called the derivative of f(z) in the point z.

The linearity means that ![Df\(z\)](//upload.wikimedia.org/math/c/f/3/cf3cb3e2836bf35cba9738a25c036ebf.png) is determined by the two real numbers ![Df\(z\)\(1\)](//upload.wikimedia.org/math/2/a/6/2a6da603b35a3e6253f1e4f36ad5eafc.png) and ![Df\(z\)\(i\)](//upload.wikimedia.org/math/6/9/4/6945763f9c088c24eb8b53f578821460.png). These are denoted by _∂f(z)/∂x_ and _∂f(z)/∂y_, respectively, and are called the _partial derivatives_ with respect x and y. We have for ![h = h_x + ih_y](//upload.wikimedia.org/math/7/4/e/74e31caf7d812c106f19eab40a53a213.png):

    _Df(z)(hx \+ ihy) = (∂f(z)/∂x)hx \+ (∂f(z)/∂y)hy_

This number is the scalar product of the vectors _(∂f(z)/∂x, ∂f(z)/∂y)_ and (![h_x, h_y](//upload.wikimedia.org/math/0/1/4/0146d91e1f13083ea0f8c65dcf398352.png)), so, if we regard _Df(z)_ and _h_ as vectors, we can write:

    _Df(z)(h) = Df(z)*h_.

The vector _Df(z)_ is called the **gradient** of _f(z)_ in the point _z_: the direction of _Df(z)_ is the direction of the most rapid growth and the length of _Df(z)_ is the growth of _f(z)_ in this direction.

If _∂f(z)/∂x_ and _∂f(z)/∂y_ exist in a neighbourhood of _z*_ and are continuous in _z*_, then _f(z)_ is differentiable in _z*_.

  
**The derivative of a mapping into the plane**

If _f(z)_ is a mapping from a domain of the plane into the plane, we can write ![f\(z\) = f_x\(z\) + if_y\(z\)](//upload.wikimedia.org/math/0/a/d/0adb15677520fe8fed181bb5845b2327.png), where ![f_x\(z\)](//upload.wikimedia.org/math/f/a/b/faba70a77fe5b634c32ad49100620f02.png) and ![f_y\(z\)](//upload.wikimedia.org/math/f/9/4/f947a8f1421e28e1ed914054cb5b963b.png) are real functions. _f(z)_ is called differentiable in the point _z_ (as real function), if both ![f_x\(z\)](//upload.wikimedia.org/math/f/a/b/faba70a77fe5b634c32ad49100620f02.png) and ![f_y\(z\)](//upload.wikimedia.org/math/f/9/4/f947a8f1421e28e1ed914054cb5b963b.png) are differentiable in _z_. If that is so, we have a linear mapping _Df(z)_ from the complex plane into itself given by ![Df\(z\)\(h\) = Df_x\(z\)\(h\) + iDf_y\(z\)\(h\)](//upload.wikimedia.org/math/e/c/c/ecc2257e488ff36252d1349ff60c6ddb.png). This linear mapping is called the derivative of _f(z)_ in the point _z_.

The linearity means that _Df(z)_ is determined by the two complex numbers _Df(z)(1) (= ∂fx/∂x + i∂fy/∂x)_ and _Df(z)(i) (= ∂fx/∂y + i∂fy/∂y)_, and we have:

    _Df(hx \+ ihy) = ((∂fx/∂x)hx \+ (∂fx/∂y)hy) + i((∂fy/∂x)hx \+ (∂fy/∂y)hy)_

In matrix notation, this means that _Df(z)_ is the linear mapping from the plane into itself given by

    ![\\begin{bmatrix}
\\part f_x/\\part{x} & \\part f_x/\\part{y} \\\\
\\part f_y/\\part{x} & \\part f_y/\\part{y} \\\\
\\end{bmatrix}
\\times
\\begin{bmatrix}
h_x \\\\
h_y \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/7/0/2/702252a24c3bb49f262e41f8e88747ff.png)

That _f(z)_ is differentiable as a complex function, means that this multiplication corresponds to multiplication by the complex number _f'(z)_, and this is the case precisely when the Cauchy-Riemann equations

    ![\\frac{\\partial}{\\partial{x}}f_x = \\frac{\\partial}{\\partial{y}}f_y](//upload.wikimedia.org/math/f/3/9/f39d86a326f8b14f51d36d4fcdac1074.png) and ![\\frac{\\partial}{\\partial{y}}f_x = -\\frac{\\partial}{\\partial{x}}f_y](//upload.wikimedia.org/math/5/1/1/511920ce23c68bc21abc9dd36860b2e4.png)

are satisfied - these two number are the real and the imaginary part of _f'(z)_.

  
**Matrix calculus**

A **matrix** is a rectangular array of real numbers. We will only need matrices of side 1 or 2. That is, either a 2x2-matrix (quadratic matrix):

    ![
\\begin{bmatrix}
a & b \\\\
c & d \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/1/7/b/17b7488b24e1c2b0d289e5de7c6d1b5f.png)

or a 1x2-matrix (a row-matrix): {_a, b_}, or a 2x1-matrix (a column-matrix):

    ![
\\begin{bmatrix}
a \\\\
b \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/f/f/4/ff4629a4096079e25161be795a1103c7.png)

or a 1x1-matrix: {_a_}, identified with the number _a_.

The **transpose** of a matrix, is the matrix formed by reflection in the diagonal. This operation is denoted by *, and it means that we can denote a column-matrix by {_a, b_}* - the transpose of the row-matrix {_a, b_}.

Two matrices _A_ and _B_ of the same type can be added by adding the number on the corresponding places. We multiply a matrix by a real number by multiplying each of its elements by this number.

Two matrices _A_ og _B_, where the width of _A_ is equal to the height of _B_ can be multiplied: the result is a matrix _AB_ whose height is the height of _A_ and whose width is the width of _B_:

    ![\\begin{bmatrix}
a & b \\\\
c & d \\\\
\\end{bmatrix}
\\times
\\begin{bmatrix}
\\alpha & \\beta \\\\
\\gamma & \\delta \\\\
\\end{bmatrix}=
\\begin{bmatrix}
a \\alpha + b \\gamma & a \\beta + b \\delta \\\\
c \\alpha + d \\gamma & c \\beta + d \\delta \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/7/6/f/76f700fb4716233ec76f5a672c8471b2.png)

    ![\\begin{bmatrix}
a & b \\\\
c & d \\\\
\\end{bmatrix}
\\times
\\begin{bmatrix}
\\alpha \\\\
\\beta \\\\
\\end{bmatrix}=
\\begin{bmatrix}
a \\alpha + b \\beta \\\\
c \\alpha + d \\beta \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/b/f/1/bf1c4c1ed233f88e7cd49c0a1f18e01a.png)

The product {_a, b_}{![\\alpha, \\beta](//upload.wikimedia.org/math/4/3/1/431cef7e6de4eaf4478a41cc1d58ee00.png)}* is the number ![a \\alpha + b \\beta](//upload.wikimedia.org/math/5/c/1/5c10e23248e75617fbe6b4c677330606.png) (the scalar product of the vectors {_a, b_} and {![\\alpha, \\beta](//upload.wikimedia.org/math/4/3/1/431cef7e6de4eaf4478a41cc1d58ee00.png)}) and the product {_a, b_}*{![\\alpha, \\beta](//upload.wikimedia.org/math/4/3/1/431cef7e6de4eaf4478a41cc1d58ee00.png)} is the 2x2-matrix

    ![
\\begin{bmatrix}
a \\alpha & a \\beta \\\\
b \\alpha & b \\beta \\\\ 
\\end{bmatrix}
](//upload.wikimedia.org/math/b/c/2/bc24d2b0fb8ae0b53b8e0ecbd4fc270d.png)

The **determinant** of the quadratic matrix _A_ =

    ![
\\begin{bmatrix}
a & b \\\\
c & d \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/1/7/b/17b7488b24e1c2b0d289e5de7c6d1b5f.png)

is the real number _det(A) = |A| = ad - bc_. The **unit-matrix** _I_ is

    ![
\\begin{bmatrix}
1 & 0 \\\\
0 & 1 \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/3/e/f/3ef0b8fd86c10806059c31b280caa7df.png)

The **inverse matrix** to the 2x2-matrix _A_, is the 2x2-matrix ![A^{-1}](//upload.wikimedia.org/math/2/d/f/2df6de2695ac81125ca6212fe6ce3999.png) satisfying ![AA^{-1} = A^{-1}A = I](//upload.wikimedia.org/math/d/2/9/d29976631f997c73cfa601f41a6d3e0c.png). It is given by:

    ![
\\begin{bmatrix}
d & -b \\\\
-c & a \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/2/2/7/227fc7e1797680cbfaeeb78eca7c81ff.png)

divided by |_A_| - it does therefore only exist for |_A_| <> 0.

The points of the plane can be identified with the column matrices {_x, y_}*. Therefore, a 2x2-matrix _A_ determines a linear mapping of the plane into itself: {_x, y_}* → A{_x, y_}*. It is injective (and then also bijective) if |_A_| <> 0\. If that is so, the number |_A_| is the area of the image of the unit-square (if |_A_| is negative, the mapping changes orientation). Likewise, the vectors of the plane can be identified with the row-matrices {_a, b_}. A row-matrix {_a, b_} determines a linear mapping of the plane into the real numbers: {_x, y_}* → {_a, b_}{_x, y_}* = _ax + by_ (the scalar product of the vectors {_a, b_} and {_x, y_}). The complex number _z = x + iy_ can be identified with the column-matrix {_x, y_}* and with the 2x2-matrix

    ![
\\begin{bmatrix}
x & -y \\\\
y & x \\\\
\\end{bmatrix}
](//upload.wikimedia.org/math/4/6/7/467ca64dede7412f7b89b2396157e6a5.png)

The mapping of the plane into itself given by this matrix, is the multiplication by the complex number _z_.

  


# Computer programs

We will show two ways of making a program that can draw a Mandelbrot set where the iterations are towards ∞: a program where all is done from the ground, but which does nothing more than drawing a single picture, and a program where you can do all you desire (zoom, alter colouring and render as file), but where these facilities are handed over to another program, namely _Ultra Fractal_.

## A single picture

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/24/Juliasetsdkpictcomp1.jpg/220px-Juliasetsdkpictcomp1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Section of the Mandelbrot set for ![z^2 + 0.009/z + c](//upload.wikimedia.org/math/2/e/7/2e7335c59fb61210863fe6f0ce02e06f.png)

Let us make a program that is as simple as possible: it draws a single picture, and does nothing more (when it has done its work it closes). It was originally written in assembly language, but here we write it in pseudo-code. It consists of two parts: the drawing procedure and the colour scale.

We draw a section of the Mandelbrot set for the family ![f\(z\) = z^2 + \\frac{p}{z} + c \\,](//upload.wikimedia.org/math/8/4/c/84c1bd66bdbedbbec573843e792eac62.png), for p = 0.009. We let the size of the window be 800x600 pixels, and we imagine that the section has its lower left corner in the point with coordinates (ax, ay) and that is has width h. We have ![f'\(z\) = 2z - \\frac{p}{z^2} \\,](//upload.wikimedia.org/math/a/5/6/a560a0ff94e9a630588d18bf4ba2b04f.png), so that the finite critical point we need, is solution to the equation ![z^3 = p/2](//upload.wikimedia.org/math/3/2/3/3236c74d7244ffe4f468b35750ea84a2.png). We choose the real solution cri = ![\(p/2\)^{1/3}](//upload.wikimedia.org/math/3/3/4/334cf17bf76abb8af53b855be2f68613.png).

**The drawing procedure**

    p = 0.009
    cri = ![\(p/2\)^{1/3}](//upload.wikimedia.org/math/3/3/4/334cf17bf76abb8af53b855be2f68613.png)
    r = 1.0E200 (square of the bail-out radius)
    u = log(log(r))
    v = 1/log(2) (2 is the degree of the rational function)
    ax = -0.7028233689263 (x-coordinate of lower left corner)
    ay = 0.1142331238418 (y-coordinate of lower left corner)
    h = 0.0092906805859 (width of the section)
    g = h / 800
    m = 850 (maximum iteration number)
    thick = h * 0.0005 (thickness of the boundary)
    dens = 24.9 (density of the colours)
    disp = 432.0 (displacement of the colour scale)

for i = 0 to 799 do

    begin 

    cx = ax + i * g (x-coordinate of pixel (i, j))
    for j = 0 to 599 do 

    begin 

    cy = ay + j * g (y-coordinate of pixel (i, j))
    x = cri
    y = 0
    xd = 0
    yd = 0
    f = 0
    n = 0
    while (n < m) and (f < r) do 

    begin 

    n = n + 1
    x1 = x * x - y * y
    y1 = 2 * x * y
    f = x * x + y * y
    x2 = 2 * x - p * x1 / (f * f)
    y2 = 2 * y + p * y1 / (f * f)
    temp = xd
    xd = x2 * xd - y2 * yd + 1
    yd = x2 * yd + y2 * temp
    fd = xd * xd + yd * yd
    x = x1 + p * x / f + cx
    y = y1 - p * y / f + cy
    f = x * x + y * y
    end
    if (n = m) or (log(f) * sqrt(f) < thick * sqrt(fd)) then 

    setpixel(i, 599 - j, 0)
    else 

    begin 

    s = n - v * (log(log(f)) - u)
    n = round(dens * s + disp) mod 720
    col = paletteRGB(col1[n], col2[n], col3[n])
    setpixel(i, 599 - j, col)
    end
    end
    end

**Explanation**

We have set ![c = cx + icy](//upload.wikimedia.org/math/f/b/8/fb8b052806e26ea64acfa8454309f7ca.png), ![z = x + iy](//upload.wikimedia.org/math/c/a/2/ca2af66001a5f8f08a940e0de92fccdb.png), ![z' = xd + iyd](//upload.wikimedia.org/math/1/0/1/1010a5b794e57a62baeb4afe7c7e8260.png) and ![x1 + iy1 = \(x + iy\)^2](//upload.wikimedia.org/math/8/5/f/85fc34cbd29c733b6a74a0132210fed2.png), and we have used that ![1/z = z^-/|z|^2](//upload.wikimedia.org/math/a/2/c/a2c6a63dbe8c1e721376725267e3a6e5.png).

The successive calculation of the derivative _z'_ is ![xd + iyd = \(x2 + iy2\) * \(xd + iyd\) + 1](//upload.wikimedia.org/math/4/f/1/4f1438f72efbaadc0dc097d27a0d5f61.png), where ![x2 + iy2 = 2 * \(x + iy\) - p * \(x1 - iy1\) / \(f * f\)](//upload.wikimedia.org/math/7/a/3/7a3795fa9743bc86eff66fe5c358fb4c.png) and ![f = x^2 + y^2](//upload.wikimedia.org/math/8/a/1/8a1ff3294419df2f3d10da90ed39b62e.png). The next point in the iteration is ![x + iy = \(x1 + iy1\) + p * \(x - iy\) / f + \(cx + icy\)](//upload.wikimedia.org/math/f/f/6/ff647d3da52046faac0d0bd9d14f0ecb.png). The distance function is

    _log(√f)*√f/√fd   (= log(f)*√f/(2*√fd))_

for the last _z_-value, here ![f = x^2 + y^2](//upload.wikimedia.org/math/8/a/1/8a1ff3294419df2f3d10da90ed39b62e.png) and ![fd = xd^2 + yd^2](//upload.wikimedia.org/math/6/a/b/6ab1505e6482b887008d0ab8b712d5fd.png). The number in the interval [0, 1[ to be subtracted from the iteration number (in order to get the real iteration number), is ![log\(log\(|z|\)/log\(r\)\)/log\(2\) = v * \(log\(log\(f\)\) - u\)](//upload.wikimedia.org/math/c/9/d/c9d3b8865e42904ed9c7388637ccfc30.png), for the last _z_, here ![v = 1/log\(2\)](//upload.wikimedia.org/math/5/b/b/5bb66eafdcea7a9874b7180ca288c185.png) and ![u = log\(log\(r\)\)](//upload.wikimedia.org/math/4/f/6/4f6f1ad53f16a2aa7b5c947c834d284a.png).

paletteRGB(r, g, b) is the integer indexing the colour with RGB-values (r, g, b), 0 gives black. col, col2 and col3 are the arrays from 0 to 719 of integers from 0 to 255 constructed in the next section.

**The colour scale**

A colour is immediately (in the computer) given by its composition of the three primary colours red, green and blue, and their shares are measured in whole numbers between 0 and 255. This triple of numbers is the set of RGB values of the colour. The colours correspond accordingly to the entire points in a cube with side length 256, and we construct our cyclic colour scala by going regularly along an ellipse in this cube. An ellipse in the space is determined by:

    

    a centre with coordinates _(a, b, c)_
    a major axe _rmaj_ and a minor axe _rmin_
    two angles angle _g_ and _h_ determining the direction of the plane of the ellipse
    an angle _q_ determining the direction of the ellipse in this plane

    u = cos(g * pi / 180) * cos(h * pi / 180) {(u,v,w) is a unit vector orthogonal to the plane}
    v = cos(g * pi / 180) * sin(h * pi / 180)
    w = sin(g * pi / 180)
    x = -a {(x,y,z) is a vector _in_ the plane}
    y = -b
    z = a * u / w + b * v / w
    e = sqrt(sqr(x) + sqr(y) + sqr(z))
    x1 = x / e {the unit vector corresponding to (x,y,z)}
    y1 = y / e
    z1 = z / e
    x2 = v * z1 - w * y1 {the unit vector in the plane orthogonal to (x1,y1,z1)}
    y2 = w * x1 - u * z1
    z2 = u * y1 - v * x1
    e = cos(q * pi / 180)
    f = sin(q * pi / 180)
    x1 = e * x1 + f * x2 {the unit vector in the plane in the direction of the angle q}
    y1 = e * y1 + f * y2
    z1 = e * z1 + f * z2
    x2 = v * z1 - w * y1 {the unit vector in the plane orthogonal to this direction}
    y2 = w * x1 - u * z1
    z2 = u * y1 - v * x1
    for i = 0 to 719 do 

    begin 

    e = rmaj * cos(i * pi / 360)
    f = rmin * sin(i * pi / 360)
    col1[i] = round(a + e * x1 + f * x2) {the three coordinates of the point on the ellipse}
    col2[i] = round(b + e * y1 + f * y2)
    col3[i] = round(c + e * z1 + f * z2)
    end

In the picture we have: (a, b, c) = (176, 176, 176), rmaj = rmin = 88, g = 146, h = -32, q = 0.

## Ultra Fractal

Ultra Fractal is a program for drawing fractals where the user to a great extent can write his own formula programs and where the main program performs all that is common for all the fractal procedures, that is, the procedure of going from pixel to pixel, zooming, colouring, production of a large picture as a file. Your effort is reduced to a minimum, and apart from pictures that cannot be drawn regularly from pixel to pixel - attractors and landscapes, for instance - you can do all you desire: non-complex functions, quaternions, ... You can operate directly with complex numbers.

First you should download a free trial-version of the program and learn how it works. Then you should see the article [Make attractive pictures of Mandelbrot and Julia sets with Ultra Fractal](http://www.juliasets.dk/UFP.htm), and download the (free) programs from this site to be run with Ultra Fractal.

For the drawing two programs have to be combined: a formula program and a colouring program. In the formula program is a section called _loop_, and when this loop has done its work, the number of iterations and the last value of the complex number _z_ are transferred to the colouring program, which calculates the colour from these two numbers. However, Ultra fractal is designed to "all" types of fractals, and unfortunately the Julia and Mandelbrot sets do not quite fit into this form: for iterations towards cycles, the iteration has to be continued in order to find the order and the attraction of the cycle, and it is not the last value of _z_ in the sequence we do use for the colour. Therefore we replace this loop by a fictive loop (which only runs one time) and perform all the operations in the section _init_. This implies that we cannot use the default colouring program of Ultra Fractal, we must write a new colouring program.

Another thing you must be aware of, is that in Ultra Fractal the norm |z| of the complex number z is the **square** of its length: |z| = ![x^2 + y^2](//upload.wikimedia.org/math/9/4/b/94bf08e8732747067e12634019d442b4.png).

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/09/Juliasetsdkpictcomp2.jpg/220px-Juliasetsdkpictcomp2.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Section of the Mandelbrot set for ![z^2/2 + 0.26*z^4 + c](//upload.wikimedia.org/math/1/f/3/1f36c7ecf39cf3f259275b55497b4e2e.png)

We will show a program that draws the Mandelbrot set for the family ![f\(z\) + c](//upload.wikimedia.org/math/8/1/d/81db5d69984d815c540a9b10d50e90d0.png), where ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) is a polynomial whose first two terms are zero, so that it begins with ![z^2](//upload.wikimedia.org/math/7/d/b/7db5e3ec92f18b8e39aa043575959617.png) or a larger power of _z_, because we then can take 0 as the finite critical point.

The two programs can be copied and inserted in an empty formula and colouring document, respectively. We have inserted the polynomial ![z^2/2 + p*z^4 + c](//upload.wikimedia.org/math/5/d/8/5d877c4bb0617bbfc526d72d7a02ae06.png) of degree 4, where p is a real parameter. The picture shows a section of the Mandelbrot set for p = 0.26.

**The formula program**

    Mandelbrot {
    global: 

    float p = 0.26  ;parameter
    float deg = 4  ;degree of the polynomial
    float v = 1 / log(deg)
    float g = 10 * log(10)
    float r = exp(g)  ;square of the radius of the bail-out circle
    u = log(g)
    float tb = sqr(@thick / (1000 * #magn))  ;for the thickness of the boundary
    float h = 1 / (1500 * #magn * @width)  ;a very small real number
    init: 

    complex z = 0  ;critical point
    complex zd = 0  ;the sequence of the derivatives
    complex z1 = 0
    float w = 0
    int n = 0
    while n < #maxit && |z| < r 

    n = n + 1
    z1 = z^2/2 + p*z^4
    zd = ((z+h)^2/2 + p*(z+h)^4 - z1) * zd / h + 1
    z = z1 + #pixel
    endwhile
    if n == #maxit || sqr(log(|z|)) * |z| < tb * |zd| 

    w = -1
    else 

    w = n - v * (log(log(|z|)) - u)
    endif
     ;begin fictive loop 

    z = 0
    n = 0
    loop: 

    n = n + 1
    z = z + #pixel
    if n == 1 

    z = w
    endif
    bailout: 

    n < 1
     ;end fictive loop
    default: 

    title = "Mandelbrot"
    maxiter = 100
    param thick 

    caption = "boundary"
    default = 1.0
    endparam
    param width 

    caption = "width"
    default = 640
    endparam
    }

**Explanation**

We have set the square of the radius r of the bail-out circle to ![10^{10}](//upload.wikimedia.org/math/f/3/c/f3c75c54078aadf0d0e85e5ca4890c11.png), and set the thickness of the boundary to "thick/(1000 * #magn)", so that it becomes thinner when we zoom in.

We have calculated the derivative ![f\(z\)](//upload.wikimedia.org/math/b/2/3/b23d8bcdb490736c53d5b677455a8cd2.png) by ![\(f\(z+h\) - f\(z\)\)/h](//upload.wikimedia.org/math/e/1/5/e15b5032db9e995095012123a5ec506b.png) for a small number h, namely "h = 1/(1500*#magn*width)", where "width" is the width of the picture. The default value is the width of the window in pixels (here set to 640), but if you draw a large picture, you should enter the width of this.

The successive calculation of the derivative ![z'_{k+1} = f'\(z_k\)z'_k + 1](//upload.wikimedia.org/math/b/a/5/ba5de6d3a2bc77e2f322073e960db0db.png) is "zd = (f(z+h) - f(z)) * zd / h + 1". The next iteration ![z_{k+1} = f\(z_k\) + c](//upload.wikimedia.org/math/f/5/4/f54495d56ca7304fcee1a10d08b33e0f.png) is "z = f(z) + #pixel". The square of the distance estimation ![log|z_k| * |z_k| / |z'_k|](//upload.wikimedia.org/math/8/6/0/8603959f11e4ead1a917ed02cd30ce22.png) is "sqr(log(|z|)) * |z| / |zd|". The number to be subtracted from the iteration number ![log\(log\(|z_k|\)/log\(r\)\)/log\(deg\)](//upload.wikimedia.org/math/5/a/9/5a9deae77f4e7c4aa67d2a8736ac4fcf.png) is "v * (log(log(|z|)) - u)", where "v = 1/log(deg)" and "u = log(log(r))".

The final complex number _z_ (to be transferred to the colouring program), which here actually is real, is set to -1, when the point belongs to the Mandelbrot set or to the boundary, otherwise it is set to the real iteration number. It is transferred to the colouring program, which we have called _Gradient_, as #z, and is here set equal to the real number s. When s is negative the colour is set to "#solid", otherwise we multiply s by a number "dens" determining the density, and add to this number a number "disp" determining the displacement of the scale, and as we want this displacement to be a per cent, we divide the result by 100: "u = (dens * s + disp) / 100". In Ultra Fractal the colours of the cyclic colour scales are indexed by the real numbers in the interval [0, 1[, and we let this number, "#index", be the non-integral part of the number u: "#index = u - trunc(u)".

**The colouring program**

    Gradient {
    final: 

    float s = real(#z)
    float u = 0
    if s < 0 

    #solid = true
    else 

    u = (@dens * s + @disp) / 100
    #index = u - trunc(u)
    endif
    default: 

    title = "Gradient"
    param disp 

    caption = "displace"
    default = 0
    endparam
    param dens 

    caption = "density"
    default = 1.0
    endparam
    }

  


# Favourite formulas

If you insert a random complex rational function in a fractal program, it is very unlikely that you will find an interesting locality in the Mandelbrot set. But sometimes you will witness a startling spectacle when you zoom in. And this is usually where two domains of different structures meet each other.

If you come across an interesting formula, then let the rest of us see it. You can here write the formula and the coordinates of the locality, and show a picture. You should also state the critical points, however you can neglect this, if you use ∞ and a real point of smallest numerical value, or if you (in case of iterations towards finite cycles) use two conjugate complex numbers of largest distance.

You should fell free to remove formulas that clearly have been surpassed by others.

    ![z^2/2 + z^4/4 + c](//upload.wikimedia.org/math/1/b/f/1bf9edef6280ea1b26d6a9683fe4322a.png) c = (0.7, 1.3)
    ![1 - z^2 + z^5/\(2 + 4z\) + c](//upload.wikimedia.org/math/5/5/1/551cb3f95c65e6976cd09072d9729f5c.png) c = (-0.163, 0.085)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Juliasetsdkpictformula1.jpg/120px-Juliasetsdkpictformula1.jpg)

The Mandelbrot set for ![z^2/2 + z^4/4 + c](//upload.wikimedia.org/math/1/b/f/1bf9edef6280ea1b26d6a9683fe4322a.png)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Juliasetsdkpictformula2.jpg/120px-Juliasetsdkpictformula2.jpg)

The Mandelbrot set for ![1 - z^2 + z^5/\(2 + 4z\) + c](//upload.wikimedia.org/math/5/5/1/551cb3f95c65e6976cd09072d9729f5c.png)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&oldid=1989051](http://en.wikibooks.org/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&oldid=1989051)" 

[Category](/wiki/Special:Categories): 

  * [Pictures of Julia and Mandelbrot Sets](/wiki/Category:Pictures_of_Julia_and_Mandelbrot_Sets)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Pictures+of+Julia+and+Mandelbrot+Sets%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Pictures+of+Julia+and+Mandelbrot+Sets%2FPrint+Version)

### Namespaces

  * [Book](/wiki/Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version)
  * [Discussion](/w/index.php?title=Talk:Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version)
  * [Edit](/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&action=edit)
  * [View history](/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&oldid=1989051)
  * [Page information](/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Pictures_of_Julia_and_Mandelbrot_Sets%2FPrint_Version&id=1989051)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Pictures+of+Julia+and+Mandelbrot+Sets%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Pictures+of+Julia+and+Mandelbrot+Sets%2FPrint+Version&oldid=1989051&writer=rl)
  * [Printable version](/w/index.php?title=Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version&printable=yes)

  * This page was last modified on 3 December 2010, at 14:09.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Pictures_of_Julia_and_Mandelbrot_Sets/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
