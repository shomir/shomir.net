# Understanding Darcs/Print Version

From Wikibooks, open books for an open world

< [Understanding Darcs](/wiki/Understanding_Darcs)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Understanding_Darcs/Print_Version) on _8 June 2010_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&oldid=1832058&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Understanding Darcs](/wiki/Understanding_Darcs)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&action=purge&printable=yes) this page.

## Contents

  * 1 Getting Started
    * 1.1 Anatomy of a darcs repository
    * 1.2 Essential commands
      * 1.2.1 init
      * 1.2.2 add
      * 1.2.3 whatsnew
      * 1.2.4 record
  * 2 Making Changes
    * 2.1 Editing files
      * 2.1.1 record makes new stuff old
      * 2.1.2 replace for renaming tokens
    * 2.2 Playing with files
      * 2.2.1 add tells darcs to pay attention
      * 2.2.2 mv for moving or renaming
      * 2.2.3 you don't need remove
  * 3 Working With Others
    * 3.1 The commands
      * 3.1.1 get
      * 3.1.2 pull/push
      * 3.1.3 send
      * 3.1.4 apply
      * 3.1.5 put
    * 3.2 Dealing with conflicts
  * 4 Reviewing Your Work
    * 4.1 whatsnew
    * 4.2 changes
    * 4.3 diff
  * 5 Undoing Mistakes
    * 5.1 The big three
      * 5.1.1 revert only removes what's new
      * 5.1.2 unrecord makes things new again
      * 5.1.3 obliterate is unrecord + revert
    * 5.2 Other ways to get rid of things
      * 5.2.1 unpull is obliterate
      * 5.2.2 rollback
      * 5.2.3 remove doesn't belong here
    * 5.3 Questions and objections
  * 6 Dealing With Conflicts
    * 6.1 Handle your conflicts at home
    * 6.2 Resolving conflicts
  * 7 Introduction to Patch Theory
    * 7.1 Math and computer science nerds only
    * 7.2 What is the theory of patches?
    * 7.3 Why all this math?
    * 7.4 Context, patches and changes
    * 7.5 Sequential patches
    * 7.6 Inverses
    * 7.7 Commutation
      * 7.7.1 Why not keep our old patches?
      * 7.7.2 The complex undo revisited
      * 7.7.3 Commutation and patches
    * 7.8 Merging
      * 7.8.1 Parallel patches
      * 7.8.2 Performing the merge
      * 7.8.3 Merging is symmetric
      * 7.8.4 The commutation with inverse property
    * 7.9 Definitions and properties
  * 8 Intermediary Patch Theory
    * 8.1 It's all patches
    * 8.2 Merging a sequence of patches
    * 8.3 Sequences of patches
    * 8.4 Permutivity
  * 9 Patch Theory and Conflicts
    * 9.1 Conflicts
      * 9.1.1 How do we know we have a conflict?
    * 9.2 Forced commutation
      * 9.2.1 Effects
    * 9.3 Forced commutation in merging
      * 9.3.1 Marking the conflict
    * 9.4 Darcs 2
      * 9.4.1 The exponential merge problem
      * 9.4.2 Conflictors
      * 9.4.3 Use of Generalised Algebraic Datatypes to improve code safety
    * 9.5 Current research

# Getting Started[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=1)]

## Anatomy of a darcs repository[[edit](/w/index.php?title=Understanding_Darcs/Getting_started&action=edit&section=T-1)]

Understanding how to use the darcs commands can be a lot easier if you have a rough idea how things work. We're not asking you to learn about patch commutation algebra (yet), but one thing you should at least be comfortable with is the anatomy of a darcs repository.

![Anatomy of a darcs repository](//upload.wikimedia.org/wikipedia/commons/6/69/Darcs-repo-anatomy.png)

The idea of the diagram is as follows: the stuff on the left in yellow is you. That's what darcs calls the **working directory**. The stuff in grey, on the other hand, is part of that mysterious `_darcs` directory if you've played around with darcs before. This can be broken down some more. The **pristine tree** (middle) is exactly like your working directory, except only representing the last saved state. It's not essential to darcs's operations, but it makes things run more efficiently, and is perhaps useful for understanding how things work. Finally, the right-most portion is the set of **patches**. Patches are what makes darcs... well... darcs. Darcs thinks in patches. Almost every darcs operation somehow involves (darcs) juggling some patches around behind the scenes. Enthusiastic darcs users find that this makes life easier in a number of ways. For example, accepting patches to your code becomes an extremely natural thing to do - you just darcs apply them and in they go. But before we get to that, let's tackle a small set of essential commands.

## Essential commands[[edit](/w/index.php?title=Understanding_Darcs/Getting_started&action=edit&section=T-2)]

### init[[edit](/w/index.php?title=Understanding_Darcs/Getting_started&action=edit&section=T-3)]

Say you have a directory with some files in it. When you run `darcs init` to initialise the repository, you get an empty new darcs repository. Your working directory might contain files, but darcs does not know about them yet.

![After a darcs init - an empty repository](//upload.wikimedia.org/wikipedia/commons/7/7c/Darcs-repo-init.png)

### add[[edit](/w/index.php?title=Understanding_Darcs/Getting_started&action=edit&section=T-4)]

`darcs add` tells darcs to keep track of a file or directory that was only in your working directory. It creates or adds to a special temporary patch which we call the **pending patch** (will be represented in blue). Note that it does _not_ affect your pristine tree whatsover! The idea is that we haven't saved your work (which is what the pristine tree is for). We've only told darcs that we might conceivably want to save it later on.

![during darcs add](//upload.wikimedia.org/wikipedia/commons/f/fe/Darcs-repo-add-before.png)

Note that the pending patch is different from all the other patches. It is really a representation of (some) things you have not yet converted into a real darcs patch.

### whatsnew[[edit](/w/index.php?title=Understanding_Darcs/Getting_started&action=edit&section=T-5)]

The `darcs whatsnew` compares the working directory against the pristine tree (theoretically, against the set of patches) and displays what has changed between them. If there is anything in the pending patch, it also displays the contents of that.

![Darcs whatsnew](//upload.wikimedia.org/wikipedia/commons/f/f7/Darcs-repo-whatsnew.png)

### record[[edit](/w/index.php?title=Understanding_Darcs/Getting_started&action=edit&section=T-6)]

The `darcs record` command is how you save your work. It copies your chosen changes from the working directory to the pristine tree, and more importantly, creates a new patch representing those changes. Changes can also come from the pending patch, and these changes will also be propagated into the pristine tree.

![during darcs record](//upload.wikimedia.org/wikipedia/commons/e/e7/Darcs-record-before.png)

_Next Page: [Making changes](/wiki/Understanding_Darcs/Making_changes)_

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Making Changes[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=2)]

## Editing files[[edit](/w/index.php?title=Understanding_Darcs/Making_changes&action=edit&section=T-1)]

### `record` makes new stuff old[[edit](/w/index.php?title=Understanding_Darcs/Making_changes&action=edit&section=T-2)]

The **record** command takes the changes which only exist in your working directory (or the pending patch) and updates the pristine tree. The result of a record operation is a new patch.

![The darcs record command](//upload.wikimedia.org/wikipedia/commons/e/e7/Darcs-record-before.png)

### `replace` for renaming tokens[[edit](/w/index.php?title=Understanding_Darcs/Making_changes&action=edit&section=T-3)]

The **replace** command is useful for explictly telling darcs to replace one word with another (for example, a variable name, if you are a programmer).

Note that because of the underlying patch theory, replace only works if the new word doesn't already exist in the file. Darcs will helpfully let you know if you try to replace something you cannot. Also, there is a switch for forcing the replacement, but the resulting patch is not a clean darcs-replace patch, but a combination of that, and what you would have gotten if you had edited the file in a text editor. In short, forcing darcs to replace when it really doesn't want to can lead to counter-intuitive results.

## Playing with files[[edit](/w/index.php?title=Understanding_Darcs/Making_changes&action=edit&section=T-4)]

We saw **add** in the last chapter. What about the other file-related commands?

### `add` tells darcs to pay attention[[edit](/w/index.php?title=Understanding_Darcs/Making_changes&action=edit&section=T-5)]

**add**, unsuprisingly, adds a file or directory to the list of files that darcs is paying attention to.

![The darcs add command](//upload.wikimedia.org/wikipedia/commons/f/fe/Darcs-repo-add-before.png)

### `mv` for moving or renaming[[edit](/w/index.php?title=Understanding_Darcs/Making_changes&action=edit&section=T-6)]

**mv** lets you rename a file or put it in a different directory. This command updates the pending patch with a move command.

### you don't need `remove`[[edit](/w/index.php?title=Understanding_Darcs/Making_changes&action=edit&section=T-7)]

You might think that **remove** gets rid of a file, but actually all it does is to remove it from the list of files that darcs is paying attention to. You probably just want to delete the file instead (eg: with `rm`). Darcs will notice and record the change next time you `darcs record` that file. So what's the remove command good for? It might be handy if you want to just remove the file from darcs, without actually getting rid of your physical copy. This is most useful when you've accidentally used **darcs add** on a file you don't want darcs to pay attention to.

_Next Page: [Working with others](/wiki/Understanding_Darcs/Working_with_others)_ | Previous Page: [Getting started](/wiki/Understanding_Darcs/Getting_started)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Working With Others[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=3)]

## The commands[[edit](/w/index.php?title=Understanding_Darcs/Working_with_others&action=edit&section=T-1)]

### get[[edit](/w/index.php?title=Understanding_Darcs/Working_with_others&action=edit&section=T-2)]

`darcs get` makes a copy of an entire darcs repository. Note that we only get the recorded patches (and pristine tree), not any of the pending stuff.

![during darcs get](//upload.wikimedia.org/wikipedia/commons/0/05/Darcs-repo-get-before.png)

### pull/push[[edit](/w/index.php?title=Understanding_Darcs/Working_with_others&action=edit&section=T-3)]

`darcs pull` copies from some other repository patches that you do not have. The patches are applied to your pristine tree and working directory. This may cause changes to be merged. Note that `darcs push` does the same thing, but in the other direction.

![during darcs pull](//upload.wikimedia.org/wikipedia/commons/4/4f/Darcs-pull-before.png)

### `send`[[edit](/w/index.php?title=Understanding_Darcs/Working_with_others&action=edit&section=T-4)]

Darcs `send` is sort of like `push`, only it doesn't actually apply the patches anywhere. Instead it generates a handy email to the person or people who own the repository. If it can't figure out who owns the repository, it will let you send to any email address you want. Note that you can also pass the `-o` command to "send" into a file, rather than a mail.

### `apply`[[edit](/w/index.php?title=Understanding_Darcs/Working_with_others&action=edit&section=T-5)]

`Apply` is what you do to a patch that somebody darcs `send`s to you. You can also use it for the files you generated via `send -o`. Note: `push` is actually just `apply` in disguise, but with all the boring work of copying files over being done for you.

### `put`[[edit](/w/index.php?title=Understanding_Darcs/Working_with_others&action=edit&section=T-6)]

`Put` enables to copy a local repository to remote location (for instance, via ssh). Think of `put` as the opposite of `get`.

## Dealing with conflicts[[edit](/w/index.php?title=Understanding_Darcs/Working_with_others&action=edit&section=T-7)]

So you pulled a patch and you got a conflict. What do you do? See the chapter [Dealing with conflicts](/wiki/Understanding_Darcs/Dealing_with_conflicts)

_Next Page: [Reviewing your work](/wiki/Understanding_Darcs/Reviewing_your_work)_ | Previous Page: [Making changes](/wiki/Understanding_Darcs/Making_changes)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Reviewing Your Work[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=4)]

### `whatsnew`[[edit](/w/index.php?title=Understanding_Darcs/Reviewing_your_work&action=edit&section=T-1)]

The `whatsnew` command allows you to get an overview of what unrecorded changes you have made on your working copy.

This way you can get an idea of what needs to be saved.

![Darcs whatsnew](//upload.wikimedia.org/wikipedia/commons/f/f7/Darcs-repo-whatsnew.png)

### `changes`[[edit](/w/index.php?title=Understanding_Darcs/Reviewing_your_work&action=edit&section=T-2)]

Changes gives a changelog-style summary of the repo history

![Darcs changes](//upload.wikimedia.org/wikipedia/commons/6/66/Darcs-repo-changes.png)

### `diff`[[edit](/w/index.php?title=Understanding_Darcs/Reviewing_your_work&action=edit&section=T-3)]

Using this command you can get an output like that produced by the `diff` command. Allowing you to save changes in a plain old (yet very common) format.

Note that `darcs` does not depend on the `diff` binary.

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

_Next Page: [Undoing mistakes](/wiki/Understanding_Darcs/Undoing_mistakes)_ | Previous Page: [Working with others](/wiki/Understanding_Darcs/Working_with_others)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Undoing Mistakes[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=5)]

There are many ways to get rid of things: remove, rollback, revert, obliterate, unpull, unrecord... One would almost think too many. Only three of these are very important. In order of gravity, they are `revert`, `unrecord`, `obliterate`. You can also see them as being part of this table of symmetries:

recency task anti-task

more recent
whatsnew  
(i.e: add, remove, mv, editing a file)
revert

recent
record
unrecord

less recent
pull
unpull (aka obliterate)

Don't worry too much about this table. Surely it will make sense later on.

Anyway, here is a brief comparison of all the different ways you can get rid of stuff. Each one has its place, even the weird ones, like `rollback`.

## The big three[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-1)]

### `revert` only removes what's new[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-2)]

_`revert`ed something by mistake? Try `unrevert`_

The simplest of these commands is **revert**. All reverting does is to get rid of stuff you have not recorded yet. You can think of revert as being the "opposite" of whatsnew. Revert gets rid of stuff that is new.

![The darcs revert command](//upload.wikimedia.org/wikipedia/commons/9/91/Darcs-repo-revert.png)

### `unrecord` makes things new again[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-3)]

**Unrecord** does something quite different from revert. Whereas revert gets rid of stuff that is new, unrecord removes a patch, but here's the important part, _makes the stuff in it new again_ so that you can choose to re-record or revert it at your leisure.

Unrecord should only be used if you recorded something, realised you made a mistake, and want to record it differently (note also amend-record). Note: only use unrecord if you are sure that your repository is the only one that has that patch in it!

![The darcs unrecord command](//upload.wikimedia.org/wikipedia/commons/4/4c/Darcs-repo-unrecord.png)

Note that the picture above gives a somewhat more accurate depiction of what unrecord does - it removes a patch and the corresponding modifications from the pristine tree. The fact that something is new again is just a natural consequence of this fact.

### `obliterate` is `unrecord` \+ `revert`[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-4)]

**Obliterate** was deliberately named to be scary. Obliterate can be seen as unrecording a patch (thus making its stuff new again) and then reverting it. In other words, obliterate totally wipes a patch out! Typically: you would use obliterate to go really far back in time. Say, "hmm, all that stuff I've been working on for the past three months was pretty stupid". Obliterate is the answer there.

![The darcs obliterate command](//upload.wikimedia.org/wikipedia/commons/b/b2/Darcs-repo-obliterate.png)

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

It is probably a good idea to `darcs get` a backup copy of your repository before obliterating things. This way, if you accidentally remove something by mistake, you can pull it back in

## Other ways to get rid of things[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-5)]

### `unpull` is `obliterate`[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-6)]

**Unpull** and **obliterate** are exactly the same command and is only named this way to reflect its usefulness for undoing a pull.

### `rollback`[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-7)]

**Rollback** is not a command that you can expect to use very often. The situation is this. You've got a patch you want to get rid of, but people have been telling you that you shouldn't obliterate or unrecord patches that are already in other people's repositories. So what do you do? One solution is to fire up your text editor and make exact opposite changes as the ones in the patch (and then record, etc). Another solution is to generate a rollback patch, which does the same thing. It creates a patch that does exactly the opposite of another patch.

Some users just find it easier to go the text-editor route.

### `remove` doesn't belong here[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-8)]

Despite its getting-rid-of-things style name, `remove` is not really an undo kind of command. Its job is the opposite of `add`'s: it tells darcs not to pay attention to a file any longer. But as we mentioned in the previous chapter, most of the time you don't even need `darcs remove`. Simply telling your computer to get rid of the file in your working directory is good enough for darcs to notice it is gone.

## Questions and objections[[edit](/w/index.php?title=Understanding_Darcs/Undoing_mistakes&action=edit&section=T-9)]

  * But... but... I just want to go back to the state of my repository from two weeks ago! 
    * `obliterate` is probably what you want. See above.

_Next Page: [Dealing with conflicts](/wiki/Understanding_Darcs/Dealing_with_conflicts)_ | Previous Page: [Reviewing your work](/wiki/Understanding_Darcs/Reviewing_your_work)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Dealing With Conflicts[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=6)]

## Handle your conflicts at home[[edit](/w/index.php?title=Understanding_Darcs/Dealing_with_conflicts&action=edit&section=T-1)]

## Resolving conflicts[[edit](/w/index.php?title=Understanding_Darcs/Dealing_with_conflicts&action=edit&section=T-2)]

For the moment, the best place to go for dealing with conflicts is the [conflicts FAQ on darcs wiki](http://darcs.net/FAQ/Conflicts).

_Next Page: [Patch theory](/wiki/Understanding_Darcs/Patch_theory)_ | Previous Page: [Undoing mistakes](/wiki/Understanding_Darcs/Undoing_mistakes)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Introduction to Patch Theory[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=7)]

## Math and computer science nerds only[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-1)]

(The occasional physicist will be tolerated)

Casual users be warned, the stuff you're about to read is not for the faint of heart! If you're a day-to-day darcs user, you probably do not need to read anything from this page on. However, if you are interested in learning how darcs _really_ works, we invite you to roll up your sleeves, and follow us in this guided tour of the growing Theory of Patches.

## What is the theory of patches?[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-2)]

The darcs patch formalism is the underlying "math" which helps us understand how darcs should behave when exchanging patches between repositories. It is implemented in the darcs engine as data structures for representing sequences of patches and Haskell functions equivalent to the operations in the formalism. This section is addressed at two audiences: curious onlookers and people wanting to participate in the development of the darcs core. My aim is to help you understand the intuitions behind all this math, so that you can get up to speed with current conflictors research as fast as possible and start making contributions. You should note that I [myself](/wiki/User:Kowey) am only starting to learn about patch theory and conflictors, so there may be mistakes ahead.

## Why all this math?[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-3)]

One difference between centralized and distributed version control systems is that "merging" is something that we do practically all the time, so it is doubly important that we _get merging right_. Turning the problem of version control into a math problem has two effects: it lets us abstract all of the irrelevant implementation details away, and it forces us to make sure that whatever techniques we come up with are fundamentally sound, that they do not fall apart when things get increasingly complicated. Unfortunately, math can be difficult for people who do not make use of it on a regular basis, so what we attempt to do in this manual is to ease you into the math through the use of concrete, illustrated examples.

A word of caution though, "getting merging right" does not necessarily consist of having clever behaviour with respect to conflicts. We will begin by focusing on successful, non-conflicting merges and move on to the darcs approach to handling conflicts.

![Nuvola apps important yellow.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Nuvola_apps_important_yellow.svg/40px-Nuvola_apps_important_yellow.svg.png)

Note that the notation we use follows that from FOSDEM 2006, and not the darcs patch theory appendix. Namely, patch composition is written left to right. ![AB](//upload.wikimedia.org/math/b/8/6/b86fc6b051f63d73de262d4c34e3a0a9.png) means that B is applied after A

## Context, patches and changes[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-4)]

Let us begin with a little shopping. Arjan is working to build a shopping list for the upcoming darcs hackathon. As we speak, his repository contains a single file _s_list_ with the contents
    
    
    1 apples
    2 bananas
    3 cookies
    4 rice
    

Note:the numbers you see are just line numbers; they are not part of the file contents

As we will see in this and other examples in this book, we will often need to assign a name to the state of the repository. We call this name a **context**. For example, we can say that Arjan's repository is a context ![o](//upload.wikimedia.org/math/d/9/5/d95679752134a2d9eb61dbd7b91c4bcc.png), defined by there being a file s_list with the contents mentioned above.

![the initial context](//upload.wikimedia.org/wikipedia/commons/3/3a/Darcs-ag-initial.png)

Arjan makes a modification which consists of adding a line in _s_list_. His new file looks like this:
    
    
    1 apples
    2 bananas
    3 beer
    4 cookies
    5 rice
    

When Arjan records this **change** (adding beer), we produce a patch which tells us not only what contents Arjan added ("beer") but where he added them, namely to line 3 of _s_list_. We can say that in his repository, we have moved from context ![o](//upload.wikimedia.org/math/d/9/5/d95679752134a2d9eb61dbd7b91c4bcc.png) to context ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) via a **patch** A. We can write this using a compact notation like ![{}^oA^a](//upload.wikimedia.org/math/6/c/3/6c3834207903965b61e5419e2e4d004f.png) or using the graphical representation below:

![patch A](//upload.wikimedia.org/wikipedia/commons/b/bb/Darcs-ag-patchA.png)

## Sequential patches[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-5)]

Starting from this context, Arjan might decide to make further changes. His new changes would be patches that apply to the context of the previous patches. So if Arjan makes a new patch ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png) on top of this, it would take us from context ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) to some new context ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png). The next patch would take us from this context to yet another new context ![c](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png), and so on and so forth. Patches which apply on top of each other like this are called **sequential patches**. We write them in _left to right_ order as in the table below, either representing the contexts explicitly or leaving them out for brevity:

with context sans context (shorthand)

![{}^oA^a](//upload.wikimedia.org/math/6/c/3/6c3834207903965b61e5419e2e4d004f.png)
![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png)

![{}^oA^aB^b](//upload.wikimedia.org/math/e/e/a/eea10d5ba32f293181efdf7fb785131c.png)
![AB](//upload.wikimedia.org/math/b/8/6/b86fc6b051f63d73de262d4c34e3a0a9.png)

![{}^oA^aB^bC^c](//upload.wikimedia.org/math/3/8/7/387f4e0bc3ed40159928b2dd945eec0a.png)
![ABC](//upload.wikimedia.org/math/9/0/2/902fbdd2b1df0c4f70b4a5d23525e932.png)

All darcs repositories are simply sequences of patches as above; however, when performing a complex operation such as an undo or exchanging patches with another user, it becomes absolutely essential that we have some mechanism for rearranging patches and putting them in different orders. Darcs patch theory is essentially about giving a precise definition to the ways in which patches and patch-trees can be manipulated and transformed while maintaining the coherency of the repository.

## Inverses[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-6)]

Let's return to the example from the beginning of this module. Arjan has just added beer to our hackathon shopping list, but in a sudden fit of indecisiveness, he reconsiders that thought and wants to undo his change. In our example, this might consist of firing up his text editor and remove the offending line from the shopping list. But what if his changes were complex and hard to keep track of? The better thing to do would be to let darcs figure it out by itself. Darcs does this by computing an **inverse** patch, that is, a patch which makes the exact opposite change of some other patch:

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

The inverse of patch ![P](//upload.wikimedia.org/math/4/4/c/44c29edb103a2872f519ad0c9a0fdaaa.png) is ![P^{-1}](//upload.wikimedia.org/math/d/0/5/d05449de2df377c20b766d68573b135d.png), which is **the** patch for which the composition ![PP^{-1}](//upload.wikimedia.org/math/f/e/d/fed7da7fc91d5bdc24fb11dedf476f3f.png) makes no changes to the context and for which the inverse of the inverse is the original patch.

So above, we said that Arjan has created a patch ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) which adds beer to the shopping list, passing from context ![o](//upload.wikimedia.org/math/d/9/5/d95679752134a2d9eb61dbd7b91c4bcc.png) to ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png), or more compactly, ![{}^{o}A^{a}](//upload.wikimedia.org/math/e/4/7/e474ab5546a5c1c1a5dcce7d9b8b1898.png). Now we are going to create the inverse patch ![A^{-1}](//upload.wikimedia.org/math/2/d/f/2df6de2695ac81125ca6212fe6ce3999.png), which _removes_ beer from the shopping list and brings us back to context ![o](//upload.wikimedia.org/math/d/9/5/d95679752134a2d9eb61dbd7b91c4bcc.png). In the compact context-patch notation, we would write this as ![{}^{o}A^{a}{A^{-1}}^{o}](//upload.wikimedia.org/math/1/d/8/1d843e183b399dbf076bf56e4977dc98.png). Graphically, we would represent the situation like this:

![An inverse patch makes the opposite change of another patch](//upload.wikimedia.org/wikipedia/commons/3/34/Darcs-ag-inverse.png)

Patch inverses may seem trivial, but as we will see later on in this module, they are a fundamental operation and absolutely crucial to make some of the fancier stuff -- like merging -- work correctly. One of the rules we impose in darcs is that every patch must have an inverse. These rules are what we call **patch properties**. A patch property tells us things which must be true about a patch in order for darcs to work. People often like to dream up new kinds of patches to extend darcs's functionality, and defining these patch properties is how we know that their new patch types will behave properly under darcs. The first of these properties is dead simple:

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

**Patch property**: Every patch must have an inverse

## Commutation[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-7)]

Arjan was lucky to realise that he wanted to undo his change as quickly as he did. But what happens if he was a little slower to realise his mistake? What if he makes some other changes before realising that he wants to undo the first change? Is it possible to undo his first change without undoing all the subsequent changes? It sometimes is, but to do so, we need to define an operation called **commutation**.

Consider a variant of the example above. As usual, Arjan adds beer to the shopping list. Next, he decides to add some pasta on line 5 of the file:

![Beer and pasta](//upload.wikimedia.org/wikipedia/commons/2/20/Darcs-ag-pre-commute.png)

The question is how darcs should behave if Arjan now decides that he does not want beer on the shopping list after all. Arjan simply wants to remove the patch that adds the beer, without touching the one which adds pasta. The problem is that darcs repositories are simple, stupid sequences of patches. We can't just remove the beer patch, because then there would no longer be a context for the pasta patch! Arjan's first patch ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) takes us to context ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) like so: ![{}^{o}A^{a}](//upload.wikimedia.org/math/e/4/7/e474ab5546a5c1c1a5dcce7d9b8b1898.png), and his second patch takes us to context ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png), notably starting from the initial context ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png): ![
{}^{a}B^{b}](//upload.wikimedia.org/math/e/9/4/e94dbd46ad27dcd69962018adbf49c19.png). Removing patch ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) would be pulling the rug out from under patch ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png). The trick behind this is to somehow _change the order_ of patches ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) and ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png). This is precisely what commutation is for:

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

The commutation of patches ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png) and ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png) is represented by ![XY \\leftrightarrow {Y_1}{X_1}](//upload.wikimedia.org/math/9/9/f/99fbb476d8a58465a44d90bdad005f3a.png). ![X_1](//upload.wikimedia.org/math/c/2/6/c264bdb22a754961ef6021b6c1914161.png) and ![Y_1](//upload.wikimedia.org/math/5/6/e/56ee230ff8cc6b2f9b2645ae95f9edf8.png) are intended to perform the same change as ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png) and ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png)

### Why not keep our old patches?[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-8)]

To understand commutation, you should understand why we cannot keep our original patches, but are forced to rely on evil step sisters instead. It helps to work with a concrete example such as the beer and pasta one above. While we could write the sequence ![AB](//upload.wikimedia.org/math/b/8/6/b86fc6b051f63d73de262d4c34e3a0a9.png) to represent adding beer and then pasta, simply writing ![BA](//upload.wikimedia.org/math/5/f/c/5fc810cf62601df84b7923b9964c53e6.png) for pasta and then beer would be a very foolish thing to do.

Put it this way: what would happen if we applied ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png) before ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png)? We add pasta to line 5 of the file:
    
    
    1 apples
    2 bananas
    3 cookies
    4 rice
    5 pasta
    

Does something seem amiss to you? We continue by adding beer to line 3. If you pay attention to the contents of the end result, you might notice that the order of our list is subtly wrong. Compare the two lists to see why:

![BA](//upload.wikimedia.org/math/5/f/c/5fc810cf62601df84b7923b9964c53e6.png) (wrong!) ![AB](//upload.wikimedia.org/math/b/8/6/b86fc6b051f63d73de262d4c34e3a0a9.png) (right)
    
    
    1 apples
    2 bananas
    3 beer
    4 cookies
    5 rice
    6 pasta
    
    
    
    1 apples
    2 bananas
    3 beer
    4 cookies
    5 pasta
    6 rice
    

It might not matter here because it is only a shopping list, but imagine that it was your PhD thesis, or your computer program to end world hunger. The error is all the more alarming because it is subtle and hard to pick out with the human eye.

The problem is one of context, specifically speaking, the context between ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) and ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png). In order for instructions like "add pasta to line 5 of s_list" to make any sense, they have to be in the correct context. Fortunately, commutation is easy to do, it produces two new patches ![B_1](//upload.wikimedia.org/math/6/2/a/62aaced6e784a6a5b344b43850f98398.png) and ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png) which perform the same change as ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) and ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png) but with a different context in between.

Exercises

Patch ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png) is identical to ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png). It adds "beer" to line 3 of the shopping list. But what should patch ![B_1](//upload.wikimedia.org/math/6/2/a/62aaced6e784a6a5b344b43850f98398.png) do?

One more important detail to note though! We said earlier that getting the context right is the motivation behind commutation -- we can't simply apply patches ![AB](//upload.wikimedia.org/math/b/8/6/b86fc6b051f63d73de262d4c34e3a0a9.png) in a different order, ![BA](//upload.wikimedia.org/math/5/f/c/5fc810cf62601df84b7923b9964c53e6.png) because that would get the context all wrong. But context does not have any effect on whether A and B can commute (or how they should commute). This is strictly a local affair. Conversely, the commutation of A and B does not have any effect either on the global context: the sequences ![AB](//upload.wikimedia.org/math/b/8/6/b86fc6b051f63d73de262d4c34e3a0a9.png) and ![B_1A_1](//upload.wikimedia.org/math/e/5/8/e587a2f38faa04ba0fcf13a44911de76.png) (where the latter is the commutation of the former) start from the same context and end in the same context.

### The complex undo revisited[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-9)]

Now that we know what the commutation operation does, let's see how we can use it to undo a patch that is buried under some other patch. The first thing we do is commute Arjan's beer and pasta patches. This gives us an alternate route to the same context. But notice the small difference between ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png) and ![B_1](//upload.wikimedia.org/math/6/2/a/62aaced6e784a6a5b344b43850f98398.png)!

![commutation gives us two ways to get to the same patch](//upload.wikimedia.org/wikipedia/commons/d/d5/Darcs-ag-post-commute.png)

The purpose of commuting the patches is essentially to push patch ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) on to end of the list, so that we could simply apply its inverse. Only here, it is not the inverse of ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) that we want, but the inverse of its evil step sister ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png). This is what applying that inverse does: it walks us back to the context ![b1](//upload.wikimedia.org/math/e/d/b/edbab45572c72a5d9440b40bcc0500c0.png), as if we had only applied the pasta patch, but not the beer one.

![commutation gives us two ways to get to the same patch](//upload.wikimedia.org/wikipedia/commons/4/42/Darcs-ag-commute-inverse.png)

And now the undo is complete. To sum up, when the patch we want to undo is buried under some other patch, we use commutation to squeeze it to the end of the patch sequence, and then compute the inverse of the commuted patch. For the more sequentially minded, this is what the general scheme looks like:

![Using commutation to handle a complex undo](//upload.wikimedia.org/wikipedia/commons/4/47/Darcs-complex-undo.png)

Exercises

Imagine the opposite scenario: Arjan had started by adding pasta to the list, and then followed up with the beer.

  1. If there was no commutation, what concretely would happen if he tried to remove the pasta patch, and not the beer patch?
  2. Work out how this undo would work using commutation. Pay attention to the line numbers.

### Commutation and patches[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-10)]

Every time we define a type of patch, we have to define how it commutes with other patches. Most of time, it is very straightforward. When commuting two hunk patches, for instance, we simply adjust their line offset. For instance, we want to put something on line 3 of the file, but if we use patch ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png) to insert a single line before that, what used to be line 3 now becomes line 4! So patch ![X_1](//upload.wikimedia.org/math/c/2/6/c264bdb22a754961ef6021b6c1914161.png) inserts the line "x" into line 4, much like ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png) inserts it into line 3.

Some patches cannot be commuted. For example, you can't commute the addition of a file with adding contents to it. But for now, we focus on patches which _can_ commute.

## Merging[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-11)]

    _Note: this might be a good place to take a break. We are moving on to a new topic and new (but similar) examples_

We have presented two fundamental darcs operations: patch inverse and patch commutation. It turns out these two operations are almost all that we need to perform a darcs merge.

Arjan and Ganesh are working together to build a shopping list for the upcoming darcs hackathon. Arjan initialises the repository and adds a file _s_list_ with the contents
    
    
    1 apples
    2 bananas
    3 cookies
    4 rice
    

He then records his changes, and Ganesh performs a `darcs get` to obtain an identical copy of his repository. Notice that Arjan and Ganesh are starting from the same **context**

![the initial context](//upload.wikimedia.org/wikipedia/commons/3/3a/Darcs-ag-initial.png)

Arjan makes a modification which consists of adding a line in _s_list_. His new file looks like this:
    
    
    1 apples
    2 bananas
    3 beer
    4 cookies
    5 rice
    

Arjan's patch brings him to a new context ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png):

![patch A](//upload.wikimedia.org/wikipedia/commons/b/bb/Darcs-ag-patchA.png)

Now, in his repository, Ganesh also makes a modification; he decides that _s_list_ is a little hard to decipher and renames the file to _shopping_. Remember, at this point, Ganesh has not seen Arjan's modifications. He's still starting from the original context ![o](//upload.wikimedia.org/math/d/9/5/d95679752134a2d9eb61dbd7b91c4bcc.png), and has moved a new context ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png), via his patch ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png):

![patch B](//upload.wikimedia.org/wikipedia/commons/d/dc/Darcs-ag-patchB.png)

### Parallel patches[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-12)]

At this point in time, Ganesh decides that it would be useful if he got a copy of Arjan's changes. Roughly speaking we would like to pull Arjan's patch A into Ganesh's repository B. But, there is a major problem! Namely, Arjan's patch takes us from context ![o](//upload.wikimedia.org/math/d/9/5/d95679752134a2d9eb61dbd7b91c4bcc.png) to context ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png). Pulling it into Ganesh's repository would involve trying to apply it to context ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png), which we simply do not know how to do. Put another way: Arjan's patch tells us to add a line to file _s_list_; however, in Ganesh's repository, _s_list_ no longer exists, as it has been moved to _shopping_. How are we supposed to know that Arjan's change (adding the line "beer") is supposed to apply to the new file _shopping_ instead?

![Ganesh attempts to pull from Arjan](//upload.wikimedia.org/wikipedia/commons/0/00/Darcs-ag-gpull-unknown.png)

Arjan and Ganesh's patches start from the same context o and diverge to different contexts a and b. We say that their patches are **parallel** to each other, and write it as ![A \\vee B](//upload.wikimedia.org/math/f/5/f/f5f0e7687cefaa33ff9fa15cdcce9413.png). In trying to pull patches from Arjan's repository, we are trying to merge these two patches. The basic approach is to convert the parallel patches into the sequential patches ![BA_1](//upload.wikimedia.org/math/3/1/e/31ec012234f6131c656f295d073bc160.png), such that ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png) does essentially the same change as ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) does, but within the context of b. We want to produce the situation ![{}^o{B^b}{A_1^{c}}](//upload.wikimedia.org/math/3/7/5/375aee0cf2b2d4add30ae261d5b78ee5.png)

### Performing the merge[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-13)]

Converting Arjan and Ganesh's parallel patches into sequential ones requires little more than the inverse and commutation operations that we described earlier in this module:

  1. So we're starting out with just Ganesh's patch. In context notation, we are at ![{}^{o}{B}^{b}](//upload.wikimedia.org/math/b/e/b/bebcaea013c012f048605e5d2910b4c0.png)
  2. We calculate the inverse patch ![B^{-1}](//upload.wikimedia.org/math/e/9/9/e99d52ce029cd19f70938ad4f484eb49.png). The sequence ![BB^{-1}](//upload.wikimedia.org/math/7/8/8/788a13412a05b42ca9cf759e8cc49c3a.png) consists of moving s_list to shopping and then back again. We've walked our way back to the original context: ![{}^{o}{B}^{b}{B^{-1}}^{o}](//upload.wikimedia.org/math/3/9/5/395c1e885a6612050388df1a82513357.png)
  3. Now we can apply Arjan's patch without worries: ![{}^{o}{B}^{b}{B^{-1}}^{o}A^{a}](//upload.wikimedia.org/math/9/5/e/95e9fce1ccf5ca3224d10ec8d5894e0f.png), but the result does not look very interesting, because we've basically got the same thing Arjan has now, not a merge.
  4. All we need to do is commute the last two patches, ![{B}^{-1}{A}](//upload.wikimedia.org/math/2/3/e/23e8363bc715641be3c93a13ca19d142.png), to get a new pair of patches ![{A_1}{B_1}^{-1}](//upload.wikimedia.org/math/9/d/5/9d5722fa6655725e0352e0249bef3710.png). Still, the end result doesn't seem to look very interesting since it results in exactly the same state as the last step: ![{}^{o}{B}^{b}{A_1}^{c}{{B_1}^{-1}}^{a}](//upload.wikimedia.org/math/3/5/a/35ad917e91b293f326c492dfc57c8f12.png)
  5. However, one crucial difference is that the second to last patch produces just the state we're looking for! All we now have to do to get at it is to ditch the ![{B_1}^{-1}](//upload.wikimedia.org/math/6/5/0/650a40176a59394957d17256114049bb.png) patch, which is only serving to undo Ganesh's precious work anyway. That is to say, by simply determining how to produce an ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png) which will commute with ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png), we have determined the version of ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) which will update Ganesh's repository.

![Merging via inverse and commutation](//upload.wikimedia.org/wikipedia/commons/c/ce/Darcs-merging.png)

The end result of all this is that we have the patch we're looking for, ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png) and a successful merge.

![We want a new patch A_1](//upload.wikimedia.org/wikipedia/commons/5/5d/Darcs-ag-gpull.png)

### Merging is symmetric[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-14)]

_Merging is symmetric_

Concretely, we've talked about Ganesh pulling Arjan's patch into his repository, so what about the other way around? Arjan pulling Ganesh's patch into his repository would work the same exact way, only that he is looking for a commuted version of Ganesh's patch ![B_1](//upload.wikimedia.org/math/6/2/a/62aaced6e784a6a5b344b43850f98398.png) that would apply to his repository. If Ganesh can pull Arjan's patch in, then Arjan can pull Ganesh's one too, and the result would be exactly the same:

![Merging is symmetric](//upload.wikimedia.org/wikipedia/commons/f/f2/Darcs-ag-merge-symmetry.png)

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

The result of a merge of two patches ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) and ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png) is one of two patches ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png) and ![B_1](//upload.wikimedia.org/math/6/2/a/62aaced6e784a6a5b344b43850f98398.png), which satisfy the relationship ![A \\vee B \\Longrightarrow B{A_1} \\leftrightarrow A{B_1}](//upload.wikimedia.org/math/2/6/1/261dcaf8cfca33aad9c6c0c22ddb3c93.png)

The merge definition describes what should happen when you combine two parallel patches into a patch sequence. The built-in symmetry is essential for darcs because a darcs repository is defined entirely by its patches. Put another way,

    _To be written_

### The commutation with inverse property[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-15)]

The definition of a merge tells us what we want merging to look like. How did we know how to actually perform that merge? The answer comes out of the following property of commutation and inverse: if you can commute the inverse of a patch ![A^{-1}](//upload.wikimedia.org/math/2/d/f/2df6de2695ac81125ca6212fe6ce3999.png) with some other patch ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png), then you can also commute the patch itself against ![B_1](//upload.wikimedia.org/math/6/2/a/62aaced6e784a6a5b344b43850f98398.png).

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

![B{A_1} \\leftrightarrow A{B_1}](//upload.wikimedia.org/math/3/f/a/3fa508f7589c437b56976c32a3043e38.png) if and only if ![{B_1}{A_1}^{-1} \\leftrightarrow {A^{-1}}B](//upload.wikimedia.org/math/7/9/3/7932526ae928c172c81e7611d617faeb.png), provided both commutations succeed.

Note how the left hand side of this property exactly matches the relationship demanded by the definition of a merge. To see why this all works,

    _To be written_

## Definitions and properties[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory&action=edit&section=T-16)]

definition of inverse
![AA^{-1}](//upload.wikimedia.org/math/1/1/5/115636e04705a50718e11e8de8f01bb4.png) has no effect

inverse of an inverse
![\(A^{-1}\)^{-1} = A](//upload.wikimedia.org/math/c/9/c/c9cca9671c46632356e1b3d3430afc44.png)

inverse composition property
![\(AB\)^{-1} = B^{-1}A^{-1}](//upload.wikimedia.org/math/8/b/0/8b03dc420175e634e854071e09e2ea01.png)

definition of commutation
![AB \\leftrightarrow {B_1}{A_1}](//upload.wikimedia.org/math/3/d/6/3d6067a87759271e0cbaa1dfefb5c4d1.png)

definition of a merge
![A \\vee B \\Longrightarrow B{A_1} \\leftrightarrow A{B_1}](//upload.wikimedia.org/math/2/6/1/261dcaf8cfca33aad9c6c0c22ddb3c93.png)

commutation with inverse property
![B{A_1} \\leftrightarrow A{B_1}](//upload.wikimedia.org/math/3/f/a/3fa508f7589c437b56976c32a3043e38.png) if and only if ![{B_1}{A_1}^{-1} \\leftrightarrow {A^{-1}}B](//upload.wikimedia.org/math/7/9/3/7932526ae928c172c81e7611d617faeb.png)

_Next Page: [More patch theory](/wiki/Understanding_Darcs/More_patch_theory)_ | Previous Page: [Undoing mistakes](/wiki/Understanding_Darcs/Undoing_mistakes)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Intermediary Patch Theory[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=8)]

## It's all patches[[edit](/w/index.php?title=Understanding_Darcs/More_patch_theory&action=edit&section=T-1)]

_Prior to darcs 1.0.6, **changes** were also called **patches**, but we decided it was too confusing._

Before moving on, we would like to make one very minor point clear: in the day to day operation of darcs, we talk about pulling and pushing **patches**, and of recording and reverting **changes**. This is just a user interface convention. In patch theory terms, all of these are just patches. The patches which you pull and push are **named patches**, patches which contain a name and a list of unnamed patches. So in fact, when you pull a single named patch from somebody else's repository, you are pulling a sequence of potentially many primitive patches. What does this mean for merging?

## Merging a sequence of patches[[edit](/w/index.php?title=Understanding_Darcs/More_patch_theory&action=edit&section=T-2)]

In the last chapter, we saw that dealing with simple, non-conflicting merges consists mainly of making an inverse patch and commuting that inverse with the other side's patches. Let us now explore a slightly more complicated scenario, where we have to merge against a non-conflicting sequence of patches. We do this with a variant of the darcs hackathon shopping list. As usual, Arjan and Ganesh are working together to write the shopping list. They both start from a common file _shplst_ containing
    
    
    apples
    bananas
    cookies
    

As before, Arjan inserts "beer" in line 3 of _shplst_ and records the change. He then decides to add another item on the end of the list, this time, "pasta" and records his second change. In darcs notation, Arjan has brought us from an initial context ![o](//upload.wikimedia.org/math/d/9/5/d95679752134a2d9eb61dbd7b91c4bcc.png), to a new context ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) with beer in it, and then to yet another context ![c](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png) with pasta as well..

_FIXME: will be fleshed out: i want to show what happens when Ganesh pulls two patches in_

  


## Sequences of patches[[edit](/w/index.php?title=Understanding_Darcs/More_patch_theory&action=edit&section=T-3)]

## Permutivity[[edit](/w/index.php?title=Understanding_Darcs/More_patch_theory&action=edit&section=T-4)]

_Next Page: [Patch theory and conflicts](/wiki/Understanding_Darcs/Patch_theory_and_conflicts)_ | Previous Page: [Patch theory](/wiki/Understanding_Darcs/Patch_theory)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

# Patch Theory and Conflicts[[edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit&section=9)]

﻿

![Nuvola apps important yellow.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Nuvola_apps_important_yellow.svg/40px-Nuvola_apps_important_yellow.svg.png)

This guide uses notation and terminology developed during FOSDEM 2006, so it will be out of synch with the older notation/terminology from the darcs-conflicts mailing list archive

## Conflicts[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-1)]

Up to now, we have only dealt with merging patches that do not conflict with each other. The next question of interest is how darcs should behave when they do.

Consider the previous darcs hackathon example, where as usual, Arjan decides that the shopping list needs some beer. In this scenario, Ganesh decides that you can't live on apples and cookies alone and records a patch adding "pasta" to the _s_list_ file. Now he wants to know what Arjan is up to, and so pulls the beer patch into his repository, but oh no! Arjan and Ganesh's patches conflict! How should darcs behave here?

![Arjan and Ganesh's patches conflict](//upload.wikimedia.org/wikipedia/commons/c/c7/Darcs-ag-conflict.png)

The darcs answer is that both patches _cancel each other out_ so that neither of them has any effect. The resulting shopping list has neither beer nor pasta. This might sound alarming, but it's not as bad as you might think. Darcs does not silently delete your code. After canceling the two patches out, it adds a third patch into your working directory which indicates both sides of the conflict so that you can select the one that you want. So any resolution you apply is a third patch which depends on the two conflicting ones. If you did `darcs whatsnew` on Ganesh's repository at this point, what you would get is something like this:
    
    
    v v v v v v 
    beer
    -----------
    pasta
    ^ ^ ^ ^ ^ ^ 
    

### How do we know we have a conflict?[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-2)]

It is intuitively obvious that Arjan's patch conflicts with Ganesh's, but intuition is useless if it does not translate into actual Haskell code. The first issue is thus that of knowing that we have a conflict in the first place.

All of this boils down to commutation. We have a conflict if commutation is not defined for the two patches. Let us briefly revisit the merge process described in the [previous chapter](/wiki/Understanding_Darcs/Patch_theory). When Ganesh tries to pull Arjan's patch in, he tries to adapt the patch to his context by performing the following sequence: invert his own patch, apply Arjan's patch ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png), commute the inverted patch with Arjan's patch, and discard the evil step sister of his inverted patch. As we know, inverting patches is easy. Ganesh's patch is inverted into something which remove 'pasta' from line 3 of the s_list file. On the other hand, when we try to commute that against Arjan's patch, we have a failure.

Why? Simply because it is how we define commutation between the two types of patches. For instance, both Ganesh's and Arjan's patches are **hunk patches**. The commutation of two hunk patches of the same file is defined in darcs using Haskell code very similar to the following (simplified from PatchCommute.lhs):
    
    
    commuteHunk :: FileName -> (FilePatchType, FilePatchType) -> Maybe (Patch, Patch)
    commuteHunk f (p1@(Hunk line2 old2 new2), p2@(Hunk line1 old1 new1))
      | line1 + lengthnew1 < line2 = Just ...
      | line1 + lengthnew1 == line2 && nonZero = Just ...
      | line2 + lengthold2 < line1 = Just ...
      | line2 + lengthold2 == line1 && nonZero = Just ...
      | otherwise = Nothing
      where nonZero = lengthold2 /= 0 && lengthold1 /= 0 && lengthnew2 /= 0 && lengthnew1 /= 0 
            lengthnew1 = length new1
            lengthnew2 = length new2
            lengthold1 = length old1
            lengthold2 = length old2
    

Only four cases are defined. The first two cases cover the situation where the `p1` occurs in an earlier part file than `p2` (even bumping up against it as in the second case). The latter two cases cover the reverse situation (`p2` is in earlier part of the file than `p1`). However, the case where `p1` and `p2` overlap simply does not fall into one of these possibilities. Thus we have a conflict on our hands.

## Forced commutation[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-3)]

Now that we know we have a conflict, we now need to deal with this conflict in a sane manner. We not only want to deal with the conflict at hand, but deal with it in a way which allows the conflict to propagate cleanly across an entire sequence of patches. Well, darcs is based on commutation, so in order to keep things running smoothly, we need to make sure that things continue to commute. So, we're going to define a secondary **forced commutation** operation that we only use when there is a conflict.

Recall the definition of commutation from the previous chapter:

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

The commutation of patches ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png) and ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png) is represented by ![XY \\leftrightarrow {Y_1}{X_1}](//upload.wikimedia.org/math/9/9/f/99fbb476d8a58465a44d90bdad005f3a.png). ![X_1](//upload.wikimedia.org/math/c/2/6/c264bdb22a754961ef6021b6c1914161.png) and ![Y_1](//upload.wikimedia.org/math/5/6/e/56ee230ff8cc6b2f9b2645ae95f9edf8.png) are intended to perform the same change as ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png) and ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png)

The forced commutation is going to do something similar, but with a very odd twist. Instead of patches ![Y_1](//upload.wikimedia.org/math/5/6/e/56ee230ff8cc6b2f9b2645ae95f9edf8.png) and ![X_1](//upload.wikimedia.org/math/c/2/6/c264bdb22a754961ef6021b6c1914161.png) performing the same change as their respective ancestors ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png) and ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png); forced commutation is going to give us patches, each of which makes the change that the _other_ patch does. That is, normal commutation wants ![Y_1](//upload.wikimedia.org/math/5/6/e/56ee230ff8cc6b2f9b2645ae95f9edf8.png) to do roughly the same thing as ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png), but forced commutation makes it do the same thing as ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png).

operation effect of ![Y_1](//upload.wikimedia.org/math/5/6/e/56ee230ff8cc6b2f9b2645ae95f9edf8.png) effect of ![X_1](//upload.wikimedia.org/math/c/2/6/c264bdb22a754961ef6021b6c1914161.png)

normal commutation
![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png)
![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png)

forced commutation
![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png)
![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png)

### Effects[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-4)]

As a side note, we're going to need a little terminology to keep ourselves from tripping over our tongues. It's not very convenient to always talk about one patch making the same change as another patch, which is something we will be referring to a lot. So let us compress things a little bit. Instead of saying that patch ![Y_1](//upload.wikimedia.org/math/5/6/e/56ee230ff8cc6b2f9b2645ae95f9edf8.png) makes the same change as ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png), let us simply say that the **effect** of ![Y_1](//upload.wikimedia.org/math/5/6/e/56ee230ff8cc6b2f9b2645ae95f9edf8.png) is ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png). It is the same idea, but with slightly smoother terminology.

## Forced commutation in merging[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-5)]

Let us see what the implications of this are for Ganesh and Arjan. We want to commute the inverse of Ganesh's patch (![B^{-1}](//upload.wikimedia.org/math/e/9/9/e99d52ce029cd19f70938ad4f484eb49.png)) against Arjan's patch. Since the two patches conflict, we have to resort to forced commutation, which produces two patches ![{A_1}](//upload.wikimedia.org/math/9/6/5/965bf64aac98385f931ea3951051aad9.png) and ![{B_1}^{-1}](//upload.wikimedia.org/math/6/5/0/650a40176a59394957d17256114049bb.png) with the following bizarre properties:

  * the effect of ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png) is ![B^{-1}](//upload.wikimedia.org/math/e/9/9/e99d52ce029cd19f70938ad4f484eb49.png); it removes Ganesh's "pasta" from the shopping list.
  * likewise, the effect of ![{B_1}^{-1}](//upload.wikimedia.org/math/6/5/0/650a40176a59394957d17256114049bb.png) is ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png); it adds Arjan's "beer" to the shopping list.

![Merging a conflict through forced commutation](//upload.wikimedia.org/wikipedia/commons/f/ff/Darcs-merging-forced.png)

This is all very convenient, because if I may remind you, what we're really after is cancelling out the patches. If we do the standard merging technique of simply removing ![{B_1}^{-1}](//upload.wikimedia.org/math/6/5/0/650a40176a59394957d17256114049bb.png) (so we don't add the beer after all), we will have succesfully undone Ganesh's pasta patch. The merge is complete!

![Resolving Arjan and Ganesh's conflict](//upload.wikimedia.org/wikipedia/commons/c/c4/Darcs-ag-conflict2.png)

### Marking the conflict[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-6)]

But wait! We can't just leave things undone. How is the poor developer supposed to know if there is a conflict, if darcs handles them by undoing things? The answer is that we're not going to stop here. Undoing the conflict is a very important first step, as we will see in further detail below. Look at it this way. We know there was a conflict, because of the way commutation was defined, and we know which patches were involved in the conflict. So whenever this happens, we _first_ undo everything, and then inspect the contents of the conflicting patches, and use that to create a new conflict-marking patch.

_FIXME:insert image here showing the conflict-marking patch_

## Darcs 2[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-7)]
    
    
    :_TODO: introduce this section_
    
    

### The exponential merge problem[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-8)]

Unfortunately, the darcs 1 merge algorithm has the property that certain merges -- merges that people have experienced in real life -- are exponential in time with respect to the size of conflict (in number of conflicting patches). This leads to the problem that some users have experienced where users would do a `darcs pull` and inexplicably, darcs would just sit there and hang...

So how does the new darcs 2 fix this problem? What's going on under the hood?

### Conflictors[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-9)]

The notion of conflictors is essentially that we would special patches that contain a list of patches they conflict with

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&action=edit).

### Use of Generalised Algebraic Datatypes to improve code safety[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&action=edit).

  * See also [Haskell/GADT](/wiki/Haskell/GADT) and <http://wiki.darcs.net/Ideas/GADTPlan>

## Current research[[edit](/w/index.php?title=Understanding_Darcs/Patch_theory_and_conflicts&action=edit&section=T-11)]

_Next Page: [Conclusion](/w/index.php?title=Understanding_Darcs/Conclusion&action=edit&redlink=1)_ | Previous Page: [More patch theory](/wiki/Understanding_Darcs/More_patch_theory)

Home: [Understanding Darcs](/wiki/Understanding_Darcs)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&oldid=1832058](http://en.wikibooks.org/w/index.php?title=Understanding_Darcs/Print_Version&oldid=1832058)" 

[Categories](/wiki/Special:Categories): 

  * [Understanding Darcs](/wiki/Category:Understanding_Darcs)
  * [Section stubs](/wiki/Category:Section_stubs)

Hidden category: 

  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Understanding+Darcs%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Understanding+Darcs%2FPrint+Version)

### Namespaces

  * [Book](/wiki/Understanding_Darcs/Print_Version)
  * [Discussion](/w/index.php?title=Talk:Understanding_Darcs/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Understanding_Darcs/Print_Version&stable=1)
  * [Latest draft](/w/index.php?title=Understanding_Darcs/Print_Version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Understanding_Darcs/Print_Version&action=edit)
  * [View history](/w/index.php?title=Understanding_Darcs/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Understanding_Darcs/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Understanding_Darcs/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Understanding_Darcs/Print_Version&oldid=1832058)
  * [Page information](/w/index.php?title=Understanding_Darcs/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Understanding_Darcs%2FPrint_Version&id=1832058)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Understanding+Darcs%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Understanding+Darcs%2FPrint+Version&oldid=1832058&writer=rl)
  * [Printable version](/w/index.php?title=Understanding_Darcs/Print_Version&printable=yes)

  * This page was last modified on 8 June 2010, at 13:22.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Understanding_Darcs/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
