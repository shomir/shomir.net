# Python Programming/Print version

From Wikibooks, open books for an open world

< [Python Programming](/wiki/Python_Programming)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Python_Programming/Print_version&stable=1) was [approved](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Python_Programming/Print_version) on _10 August 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Python_Programming/Print_version&oldid=2548842&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Python Programming](/wiki/Python_Programming)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Python_Programming/Print_version&action=purge&printable=yes) this page.

**Python** is a general purpose programming language.

# Table of contents

## Introduction

    [Overview](/wiki/Python_Programming/Overview)
    [Getting Python](/wiki/Python_Programming/Getting_Python)
    [Interactive mode](/wiki/Python_Programming/Interactive_mode)

## Learning to program in Python

    [Creating Python programs](/wiki/Python_Programming/Creating_Python_programs)

## Python concepts

    [Basic syntax](/wiki/Python_Programming/Basic_syntax)

    [Data types](/wiki/Python_Programming/Data_types)

    

    [Numbers](/wiki/Python_Programming/Numbers)
    [Strings](/wiki/Python_Programming/Strings)
    [Lists](/wiki/Python_Programming/Lists)
    [Tuples](/wiki/Python_Programming/Tuples)
    [Dictionaries](/wiki/Python_Programming/Dictionaries)
    [Sets](/wiki/Python_Programming/Sets)

    [Operators](/wiki/Python_Programming/Operators)
    [Flow control](/wiki/Python_Programming/Flow_control)
    [Functions](/wiki/Python_Programming/Functions)
    [Scoping](/wiki/Python_Programming/Scoping)
    [Exceptions](/wiki/Python_Programming/Exceptions)
    [Input and output](/wiki/Python_Programming/Input_and_output)
    [Modules](/wiki/Python_Programming/Modules)
    [Classes](/wiki/Python_Programming/Classes)
    [MetaClasses](/wiki/Python_Programming/MetaClasses)

## Rocking the Python (Modules)

    [Regular Expression](/wiki/Python_Programming/Regular_Expression)
    [Graphical User Interfaces in Python](/wiki/Python_Programming/GUI_Programming)
    [Python Programming/Game Programming in Python](/wiki/Python_Programming/Game_Programming_in_Python)
    [Socket programming](/wiki/Python_Programming/Sockets)
    [Files (I/O)](/wiki/Python_Programming/Files)
    [Databases](/wiki/Python_Programming/Database_Programming)
    [Extracting info from web pages](/wiki/Python_Programming/Web_Page_Harvesting)
    [Threading](/wiki/Python_Programming/Threading)
    [Extending with C](/wiki/Python_Programming/Extending_with_C)
    [Extending with C++](/wiki/Python_Programming/Extending_with_C%2B%2B)
    [WSGI web programming](/wiki/Python_Programming/WSGI_web_programming)

## References

## Authors

    [Authors](/wiki/Python_Programming/Authors)

## License

* * *

# Overview

[Python](/wiki/Python) is a [high-level](/wiki/Computer_programming/Highlevel), [structured](/wiki/Computer_programming/Structured_programming), [open-source](/wiki/Open_Source) programming language that can be used for a wide variety of programming tasks. Python was created by Guido Van Rossum in the early 1990s, its following has grown steadily and interest is increased markedly in the last few years or so. It is named after Monty Python's Flying Circus comedy program.

[Python](/wiki/Python) is used extensively for system administration (many vital components of [Linux](/wiki/Linux) Distributions are written in it), also its a great language to teach programming to novice. NASA has used Python for its software systems and has adopted it as the standard scripting language for its Integrated Planning System. Python is also extensively used by Google to implement many components of its Web Crawler and Search Engine & Yahoo! for managing its discussion groups.

Python within itself is an interpreted programming language that is automatically compiled into bytecode before execution (the bytecode is then normally saved to disk, just as automatically, so that compilation need not happen again until and unless the source gets changed). It is also a dynamically typed language that includes (but does not require one to use) object oriented features and constructs.

The most unusual aspect of Python is that whitespace is significant; instead of block delimiters (braces → "{}" in the C family of languages), indentation is used to indicate where blocks begin and end.

For example, the following Python code can be interactively typed at an interpreter prompt, display the famous "Hello World!" on the user screen:
    
    
     >>> print ("Hello World!")
    Hello World!
    

Another great Python feature is its availability for all Platforms. Python can run on Microsoft Windows, Macintosh & all Linux distributions with ease. This makes the programs very portable, as any program written for one Platform can easily be used at another.

Python provides a powerful assortment of built-in types (e.g., lists, dictionaries and strings), a number of built-in functions, and a few constructs, mostly statements. For example, loop constructs that can iterate over items in a collection instead of being limited to a simple range of integer values. Python also comes with a powerful [standard library](/wiki/Python_Programming/Standard_Library), which includes hundreds of modules to provide routines for a wide variety of services including [regular expressions](/wiki/Python_Programming/Regular_Expression) and TCP/IP sessions.

Python is used and supported by a large [Python Community](http://www.python.org/community/index.html) that exists on the Internet. The [mailing lists and news groups](http://www.python.org/community/lists.html) like the [tutor list](http://mail.python.org/mailman/listinfo/tutor) actively support and help new python programmers. While they discourage doing homework for you, they are quite helpful and are populated by the authors of many of the Python textbooks currently available on the market.

  


# Getting Python

In order to program in Python you need the Python interpreter. If it is not already installed or if the version you are using is obsolete, you will need to obtain and install Python using the methods below:

## Python 2 vs Python 3

In 2008, a new version of Python (version 3) was published that was not entirely backward compatible. Developers were asked to switch to the new version as soon as possible but many of the common external modules are not yet (as of Aug 2010) available for Python 3. There is a program called _2to3_ to convert the source code of a Python 2 program to the source code of a Python 3 program. Consider this fact before you start working with Python.

## Installing Python in Windows

Go to the [Python Homepage](http://www.python.org/download/) or the [ActiveState website](http://activestate.com) and get the proper version for your platform. Download it, read the instructions and get it installed.

In order to run Python from the command line, you will need to have the python directory in your PATH. Alternatively, you could use an Integrated Development Environment (IDE) for Python like DrPython[[1]](http://drpython.sourceforge.net/), eric[[2]](http://www.die-offenbachs.de/eric/index.html), PyScripter[[3]](http://mmm-experts.com/Products.aspx?ProductID=4), or Python's own [IDLE](//en.wikipedia.org/wiki/IDLE_\(Python\)) (which ships with every version of Python since 2.3).

The PATH variable can be modified from the Window's System control panel. The advanced tab will contain the button labelled _Environment Variables_, where you can append the newly created folder to the search path.

If you prefer having a temporary environment, you can create a new command prompt short-cut that automatically executes the following statement:
    
    
    PATH %PATH%;c:\python27
    

If you downloaded a different version (such as Python 3.1), change the "27" for the version of Python you have (27 is 2.7.x, the current version of Python 2.)

### Cygwin

By default, the Cygwin installer for Windows does not include Python in the downloads. However, it can be selected from the list of packages.

## Installing Python on Mac

Users on Apple Mac OS X will find that it already ships with Python 2.3 (OS X 10.4 Tiger) or Python 2.6.1 (OS X Snow Leopard), but if you want the more recent version head to [Python Download Page](http://www.python.org/download/mac) follow the instruction on the page and in the installers. As a bonus you will also install the Python IDE.

## Installing Python on Unix environments

Python is available as a package for some Linux distributions. In some cases, the distribution CD will contain the python package for installation, while other distributions require downloading the source code and using the compilation scripts.

### Gentoo GNU/Linux

Gentoo is an example of a distribution that installs Python by default - the package system _Portage_ depends on Python.

### Ubuntu GNU/Linux

Users of Ubuntu will notice that Python comes installed by default, only it sometimes is not the latest version. If you would like to update it, [click here](http://appnr.com/install/python).

### Arch GNU/Linux

Arch does not install python by default, but is easily available for installation through the package manager to pacman. As root (or using sudo if you've installed and configured it), type:
    
    
    $ pacman -Sy python
    

This will be update package databases and install python. Other versions can be built from source from the Arch User Repository.

### Source code installations

Some platforms do not have a version of Python installed, and do not have pre-compiled binaries. In these cases, you will need to download the source code from the [official site](http://www.python.org/download/). Once the download is complete, you will need to unpack the compressed archive into a folder.

To build Python, simply run the configure script (requires the Bash shell) and compile using make.

### Other Distributions

Python, which is also referred to as [CPython](/w/index.php?title=CPython&action=edit&redlink=1), is written in the [C Programming](/wiki/C_Programming) language. The C source code is generally portable, that means CPython can run on various platforms. More precisely, CPython can be made available on all platforms that provide a compiler to translate the C source code to binary code for that platform.

Apart from CPython there are also other implementations that run on top of a virtual machine. For example, on Java's JRE (Java Runtime Environment) or Microsoft's .NET CLR (Common Language Runtime). Both can access and use the libraries available on their platform. Specifically, they make use of [reflection](http://en.wikipedia.org/wiki/Reflection_\(computer_programming\)) that allows complete inspection and use of all classes and objects for their very technology.

_Python Implementations (Platforms)_

Environment Description Get From

Jython
Java Version of Python
[Jython](http://www.jython.org)

IronPython
C# Version of Python
[IronPython](http://www.ironpython.net)

### Integrated Development Environments (IDE)

CPython ships with IDLE; however, IDLE is not considered user-friendly.[1] For Linux, KDevelop and Spyder are popular. For Windows, PyScripter is free, quick to install, and comes included with [PortablePython](http://www.portablepython.com/).

_Some Integrated Development Environments (IDEs) for Python_

Environment Description Get From

KDevelop
Cross Language IDE for KDE
[KDevelop](http://www.kdevelop.org)

ActivePython
Highly Flexible, Pythonwin IDE
[ActivePython](http://www.activestate.com/)

Anjuta
IDE Linux/Unix
[Anjuta](http://anjuta.sf.net/)

Pythonwin
Windows Oriented Environment
[Pythonwin](http://www.python.org/windows/)

PyScripter
Free Windows IDE (portable)
[PyScripter](http://code.google.com/p/pyscripter/)

VisualWx
Free GUI Builder
[VisualWx](http://visualwx.altervista.org)

Spyder
Free cross-platform IDE
[Spyder](http://code.google.com/p/spyderlib/)

Eclipse (PyDev plugin)
Open Source IDE
[Eclipse](http://www.eclipse.org)

The Python official wiki has a [complete list of IDEs](http://wiki.python.org/moin/IntegratedDevelopmentEnvironments).

There are several commercial IDEs such as Komodo, BlackAdder, Code Crusader, Code Forge, and PyCharm. However, for beginners learning to program, purchasing a commercial IDE is unnecessary.

## Keeping Up to Date

Python has a very active community and the language itself is evolving continuously. Make sure to check [python.org](http://www.python.org) for recent releases and relevant tools. The website is an invaluable asset.

Public Python-related mailing lists are hosted at [mail.python.org](http://mail.python.org). Two examples of such mailing lists are the **Python-announce-list** to keep up with newly released third party-modules or software for Python and the general discussion list **Python-list**. These lists are mirrored to the Usenet newsgroups **comp.lang.python.announce** & **comp.lang.python**.

## Notes

  1. ↑ [The Things I Hate About IDLE That I Wish Someone Would Fix The table below lists some IDLE alternatives](http://inventwithpython.com/blog/2011/11/29/the-things-i-hate-about-idle-that-i-wish-someone-would-fix/).

  


# Interactive mode

Python has two basic modes: normal and interactive. The normal mode is the mode where the scripted and finished `.py` files are run in the Python interpreter. Interactive mode is a command line shell which gives immediate feedback for each statement, while running previously fed statements in active memory. As new lines are fed into the interpreter, the fed program is evaluated both in part and in whole.

To start interactive mode, simply type "python" without any arguments. This is a good way to play around and try variations on syntax. Python should print something like this:
    
    
    $ **python**
    Python 3.0b3 (r30b3:66303, Sep  8 2008, 14:01:02) [MSC v.1500 32 bit (Intel)] on win32
    Type "help", "copyright", "credits" or "license" for more information.
    >>>
    

(If Python doesn't run, make sure your path is set correctly. See [Getting Python](/wiki/Python_Programming/Getting_Python).)

The `>>>` is Python's way of telling you that you are in interactive mode. In interactive mode what you type is immediately run. Try typing `1+1` in. Python will respond with `2`. Interactive mode allows you to test out and see what Python will do. If you ever feel the need to play with new Python statements, go into interactive mode and try them out.

A sample interactive session:
    
    
    >>> **5**
    5
    >>> **print (5*7)**
    35
    >>> **"hello" * 4**
    'hellohellohellohello'
    >>> **"hello".__class__**
    <type 'str'>
    

However, you need to be careful in the interactive environment to avoid confusion. For example, the following is a valid Python script:
    
    
    if 1:
      print("True")
    print("Done")
    

If you try to enter this as written in the interactive environment, you might be surprised by the result:
    
    
    >>> **if 1:**
    ...   **print("True")**
    ... **print("Done")**
      File "<stdin>", line 3
        print("Done")
            ^
    SyntaxError: invalid syntax
    

What the interpreter is saying is that the indentation of the second print was unexpected. You should have entered a blank line to end the first (i.e., "if") statement, before you started writing the next print statement. For example, you should have entered the statements as though they were written:
    
    
    if 1:
      print("True")
     
    print("Done")
    

Which would have resulted in the following:
    
    
    >>> **if 1:**
    ...   **print("True")**
    ...
    True
    >>> **print("Done")**
    Done
    >>>
    

### Interactive mode

Instead of Python exiting when the program is finished, you can use the -i flag to start an interactive session. This can be **very** useful for debugging and prototyping.
    
    
    python -i hello.py
    

  


  


# Creating Python programs

[Previous: Self Help](/wiki/Python_Programming/Self_Help)
[Index](/wiki/Python_Programming)
[Next: Variables and Strings](/wiki/Python_Programming/Variables_and_Strings)

Welcome to Python! This tutorial will show you how to start writing programs.

Python programs are nothing more than text files, and they may be edited with a standard [text editor](//en.wikipedia.org/wiki/Text_editor) program.[1] What text editor you use will probably depend on your operating system: any text editor can create Python programs. It is easier to use a text editor that includes Python [syntax highlighting](//en.wikipedia.org/wiki/Syntax_highlighting), however.

  


## Hello, World!

The first program that every programmer writes is called the "Hello, World!" program. This program simply outputs the phrase "Hello, World!" and then ends. Let's write "Hello, World!" in Python!

Open up your text editor and create a new file called `hello.py` containing just this line (you can copy-paste if you want):
    
    
    print("Hello, world!")
    

This program uses the `print` function, which simply outputs its parameters to the terminal. By default, `print` appends a `newline` character to its output, which simply moves the cursor to the next line.

**Note:**  
In Python 2.x, print is a statement rather than a function. As such, it can be used without parentheses, in which case it prints everything until the end of the line and accepts a standalone comma after the final item on the line to indicate a multi-line statement. In Python 3.x, print is a proper function expecting its arguments inside parentheses. Using print with parentheses (as above) is compatible with Python 2.x and using this style ensures version-independence.

  
Now that you've written your first program, let's run it in Python! This process differs slightly depending on your operating system.

### Windows

  * Create a folder on your computer to use for your Python programs, such as `C:\pythonpractice`, and save your `hello.py` program in that folder.
  * In the Start menu, select "Run...", and type in `cmd`. This will cause the Windows terminal to open.
  * Type `cd \pythonpractice` to **c**hange **d**irectory to your `pythonpractice` folder, and hit Enter.
  * Type `hello.py` to run your program!

If it didn't work, make sure your PATH contains the python directory. See [Getting Python](/wiki/Python_Programming/Getting_Python).

### Mac

  * Create a folder on your computer to use for your Python programs. A good suggestion would be to name it `pythonpractice` and place it in your Home folder (the one that contains folders for Documents, Movies, Music, Pictures, etc). Save your `hello.py` program into this folder.
  * Open the Applications folder, go into the Utilities folder, and open the Terminal program.
  * Type `cd pythonpractice` to **c**hange **d**irectory to your `pythonpractice` folder, and hit Enter.
  * Type `python ./hello.py` to run your program!

### Linux

  * Create a folder on your computer to use for your Python programs, such as `~/pythonpractice`, and save your `hello.py` program in that folder.
  * Open up the terminal program. In KDE, open the main menu and select "Run Command..." to open Konsole. In GNOME, open the main menu, open the Applications folder, open the Accessories folder, and select Terminal.
  * Type `cd ~/pythonpractice` to **c**hange **d**irectory to your `pythonpractice` folder, and hit Enter.
  * Type `python ./hello.py` to run your program!

**Note:**  
If you have both python version 2.6.1 and version 3.0 installed (Very possible if you are using Ubuntu, and ran **sudo apt-get install python3** to have python3 installed), you should run `python3 hello.py`

### Result

The program should print:
    
    
    Hello, world!
    

Congratulations! You're well on your way to becoming a Python programmer.

## Exercises

  1. Modify the `hello.py` program to say hello to a historical political leader (or to [Ada Lovelace](//en.wikipedia.org/wiki/Ada_Lovelace)).
  2. Change the program so that after the greeting, it asks, "How did you get here?".
  3. Re-write the original program to use two `print` statements: one for "Hello" and one for "world". The program should still only print out on one line.

[Solutions](/wiki/Python_Programming/Creating_Python_programs/Solutions)

## Notes

  1. ↑ Sometimes, Python programs are distributed in compiled form. We won't have to worry about that for quite a while.

  


[Previous: Self Help](/wiki/Python_Programming/Self_Help)
[Index](/wiki/Python_Programming)
[Next: Variables and Strings](/wiki/Python_Programming/Variables_and_Strings)

# Basic syntax

[Previous: Tips and Tricks](/wiki/Python_Programming/Tips_and_Tricks)
[Index](/wiki/Python_Programming)
[Next: Data types](/wiki/Python_Programming/Data_types)

There are five fundamental concepts in [Python](/wiki/Python_Programming).

### Case Sensitivity

All variables are case-sensitive. Python treats 'number' and 'Number' as separate, unrelated entities.

### Spaces and tabs don't mix

Because whitespace is significant, remember that spaces and tabs don't mix, so use only one or the other when indenting your programs. A common error is to mix them. While they may look the same in editor, the interpreter will read them differently and it will result in either an error or unexpected behavior. Most decent text editors can be configured to let tab key emit spaces instead.

Python's Style Guideline described that the preferred way is using 4 spaces.

![Crystal Clear action bookmark.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/03/Crystal_Clear_action_bookmark.png/20px-Crystal_Clear_action_bookmark.png)

Tips: If you invoked python from the command-line, you can give -t or -tt argument to python to make python issue a warning or error on inconsistent tab usage.
    
    
    pythonprogrammer@wikibook:~$ python -tt myscript.py
    

This will issue an error if you have mixed spaces and tabs.

  


### Objects

In Python, like all object oriented languages, there are aggregations of code and data called Objects, which typically represent the pieces in a conceptual model of a system.

Objects in Python are created (i.e., instantiated) from templates called [Classes](/wiki/Python_Programming/Classes) (which are covered later, as much of the language can be used without understanding classes). They have "attributes", which represent the various pieces of code and data which comprise the object. To access attributes, one writes the name of the object followed by a period (henceforth called a dot), followed by the name of the attribute.

An example is the 'upper' attribute of strings, which refers to the code that returns a copy of the string in which all the letters are uppercase. To get to this, it is necessary to have a way to refer to the object (in the following example, the way is the literal string that constructs the object).
    
    
    'bob'.upper
    

Code attributes are called "methods". So in this example, upper is a method of 'bob' (as it is of all strings). To execute the code in a method, use a matched pair of parentheses surrounding a comma separated list of whatever arguments the method accepts (upper doesn't accept any arguments). So to find an uppercase version of the string 'bob', one could use the following:
    
    
    'bob'.upper()
    

### Scope

In a large system, it is important that one piece of code does not affect another in difficult to predict ways. One of the simplest ways to further this goal is to prevent one programmer's choice of names from preventing another from choosing that name. Because of this, the concept of scope was invented. A scope is a "region" of code in which a name can be used and outside of which the name cannot be easily accessed. There are two ways of delimiting regions in Python: with functions or with modules. They each have different ways of accessing the useful data that was produced within the scope from outside the scope. With functions, that way is to return the data. The way to access names from other modules lead us to another concept.

### Namespaces

It would be possible to teach Python without the concept of namespaces because they are so similar to attributes, which we have already mentioned, but the concept of namespaces is one that transcends any particular programming language, and so it is important to teach. To begin with, there is a built-in function `**dir()**` that can be used to help one understand the concept of namespaces. When you first start the Python interpreter (i.e., in interactive mode), you can list the objects in the current (or default) namespace using this function.
    
    
    Python 2.3.4 (#53, Oct 18 2004, 20:35:07) [MSC v.1200 32 bit (Intel)] on win32
    Type "help", "copyright", "credits" or "license" for more information.
    >>> dir()
    ['__builtins__', '__doc__', '__name__']
    

This function can also be used to show the names available within a module namespace. To demonstrate this, first we can use the `**type()**` function to show what __builtins__ is:
    
    
    >>> type(__builtins__)
    <type 'module'>
    

Since it is a module, we can list the names within the __builtins__ namespace, again using the `**dir()**` function (note the complete list of names has been abbreviated):
    
    
    >>> dir(__builtins__)
    ['ArithmeticError', ... 'copyright', 'credits', ... 'help', ... 'license', ... 'zip']
    >>>
    

Namespaces are a simple concept. A namespace is a place in which a name resides. Each name within a namespace is distinct from names outside of the namespace. This layering of namespaces is called scope. A name is placed within a namespace when that name is given a value. For example:
    
    
    >>> dir()
    ['__builtins__', '__doc__', '__name__']
    >>> name = "Bob"
    >>> import math
    >>> dir()
    ['__builtins__', '__doc__', '__name__', 'math', 'name']
    

Note that I was able to add the "name" variable to the namespace using a simple assignment statement. The import statement was used to add the "math" name to the current namespace. To see what math is, we can simply:
    
    
    >>> math
    <module 'math' (built-in)>
    

Since it is a module, it also has a namespace. To display the names within this namespace, we:
    
    
    >>> dir(math)
    ['__doc__', '__name__', 'acos', 'asin', 'atan', 'atan2', 'ceil', 'cos', 'cosh', 'degrees', 'e',
    'exp', 'fabs', 'floor', 'fmod', 'frexp', 'hypot', 'ldexp', 'log', 'log10', 'modf', 'pi', 'pow',
    'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh']
    >>>
    

If you look closely, you will notice that both the default namespace, and the math module namespace have a '__name__' object. The fact that each layer can contain an object with the same name is what scope is all about. To access objects inside a namespace, simply use the name of the module, followed by a dot, followed by the name of the object. This allow us to differentiate between the `__name__` object within the current namespace, and that of the object with the same name within the `math` module. For example:
    
    
    >>> print __name__
    __main__
    >>> print math.__name__
    math
    >>> print math.__doc__
    This module is always available.  It provides access to the
    mathematical functions defined by the C standard.
    >>> math.pi
    3.1415926535897931
    

[Previous: Tips and Tricks](/wiki/Python_Programming/Tips_and_Tricks)
[Index](/wiki/Python_Programming)
[Next: Data types](/wiki/Python_Programming/Data_types)

# Data types

[Previous: Basic syntax](/wiki/Python_Programming/Basic_syntax)
[Index](/wiki/Python_Programming)
[Next: Numbers](/wiki/Python_Programming/Numbers)

Data types determine whether an object can do something, or whether it just would not make sense. Other programming languages often determine whether an operation makes sense for an object by making sure the object can never be stored somewhere where the operation will be performed on the object (this [type system](//en.wikipedia.org/wiki/Type_system#Type_checking) is called static typing). Python does not do that. Instead it stores the type of an object with the object, and checks when the operation is performed whether that operation makes sense for that object (this is called dynamic typing).

##### Built-in Data types

Python´s built-in (or standard) data types can be grouped into several classes. Sticking to the hierarchy scheme used in the official Python documentation these are **numeric types, sequences, sets and mappings** (and a few more not discussed further here). Some of the types are only available in certain versions of the language as noted below.

Numeric types:

  * int: Integers; equivalent to C longs in Python 2.x, non-limited length in Python 3.x
  * long: Long integers of non-limited length; exists only in Python 2.x
  * float: Floating-Point numbers, equivalent to C doubles
  * complex: Complex Numbers

Sequences:

  * str: String; represented as a sequence of 8-bit characters in Python 2.x, but as a sequence of Unicode characters (in the range of U+0000 - U+10FFFF) in Python 3.x
  * byte: a sequence of integers in the range of 0-255; only available in Python 3.x
  * byte array: like bytes, but mutable (see below); only available in Python 3.x
  * list
  * tuple

Sets:

  * set: an unordered collection of unique objects; available as a standard type since Python 2.6
  * frozen set: like set, but immutable (see below); available as a standard type since Python 2.6

Mappings:

  * dict: Python dictionaries, also called hashmaps or associative arrays  


Some others, such as type and callables

##### Mutable vs Immutable Objects

In general, data types in Python can be distinguished based on whether objects of the type are mutable or immutable. Objects of the types int, float, long, complex, str, bytes, tuple, and frozen set are all immutable, _i.e._, their content cannot be changed after they are created. Objects of types byte array, list, set and dict are mutable, _i.e._, changes to their content are allowed. Only mutable objects support methods that change the object in place (such as reassignment of a sequence slice, which will work for lists, but raise an error for tuples and strings, for example).  
It is important to understand that variables in Python are really just references to objects in memory. If you assign an object to a variable (as in `a = 1`, `s = 'abc'`, or `l = ['a string', 456, ('a', 'tuple', 'inside', 'a', 'list')]`), all you really do is make this variable (`a`, `s`, or `l`) point to the object (`1`, `'abc'`, `['a string', 456, ('a', 'tuple', 'inside', 'a', 'list')]`), which is kept somewhere in memory, as a convenient way of accessing it. If you reassign a variable (_e.g._, `a = 7`, `s = 'xyz'`, `l = ['a simpler list', 99, 10]`), you make the variable point to a different object (newly created ones in our examples). As stated above, only mutable objects can be changed in place (`l[0] = 1` is ok in our example, but `s[0] = 'a'` raises an error). This becomes tricky, when an operation is not explicitly asking for a change to happen in place, as is the case for the `+=` (increment) operator, for example. When used on an immutable object (as in `a += 1` or in `s += 'qwertz'`), Python will silently create a new object and make the variable point to it. However, when used on a mutable object (as in `l += [1,2,3]`), the object pointed to by the variable will be changed in place. While in most situations, you do not have to know about this different behavior, it is of relevance when several variables are pointing to the same object. In our example, assume you set `p = s` and `m = l`, then `s += 'etc'` and `l += [9,8,7]`. This will change `s` and leave `p` unaffected, but will change both `m` and `l` since both point to the same list object. Python´s built-in `id()` function, which returns a unique object identifier for a given variable name, can be used to trace what is happening under the hood.  
Typically, this behavior of Python causes confusion in functions. As an illustration, consider this code:
    
    
    def append_to_sequence (myseq):
        myseq += (9,9,9)
        return myseq
     
    t=(1,2,3)     # tuples are immutable
    l=[1,2,3]     # lists are mutable
     
    u=append_to_sequence(t)
    m=append_to_sequence(l)
     
    print('t = ', t)
    print('u = ', u)
    print('l = ', l)
    print('m = ', m)
    

This will give the (usually unintended) output:  
`t = (1, 2, 3)`  
`u = (1, 2, 3, 9, 9, 9)`  
`l = [1, 2, 3, 9, 9, 9]`  
`m = [1, 2, 3, 9, 9, 9]`

`myseq` is a local variable of the `append_to_sequence` function, but when this function gets called, `myseq` will nevertheless point to the same object as the variable that we pass in (`t` or `l` in our example). If that object is immutable (like a tuple), there is no problem. The += operator will cause the creation of a new tuple, and `myseq` will be set to point to it. However, if we pass in a reference to a mutable object, that object will be manipulated in place (so `myseq` and `l`, in our case, end up pointing to the same list object).

##### Creating Objects of Defined Types

Literal integers can be entered as in C:

  * decimal numbers can be entered directly
  * octal numbers can be entered by prepending a 0 (0732 is octal 732, for example)
  * hexadecimal numbers can be entered by prepending a 0x (0xff is hex FF, or 255 in decimal)

Floating point numbers can be entered directly.

Long integers are entered either directly (1234567891011121314151617181920 is a long integer) or by appending an L (0L is a long integer). Computations involving short integers that overflow are automatically turned into long integers.

Complex numbers are entered by adding a real number and an imaginary one, which is entered by appending a j (i.e. 10+5j is a complex number. So is 10j). Note that j by itself does not constitute a number. If this is desired, use 1j.

Strings can be either single or triple quoted strings. The difference is in the starting and ending delimiters, and in that single quoted strings cannot span more than one line. Single quoted strings are entered by entering either a single quote (') or a double quote (") followed by its match. So therefore
    
    
    'foo' works, and
    "moo" works as well,
         but
    'bar" does not work, and
    "baz' does not work either.
    "quux'' is right out.
    

Triple quoted strings are like single quoted strings, but can span more than one line. Their starting and ending delimiters must also match. They are entered with three consecutive single or double quotes, so
    
    
    '''foo''' works, and
    """moo""" works as well,
         but
    '"'bar'"' does not work, and
    """baz''' does not work either.
    '"'quux"'" is right out.
    

Tuples are entered in parentheses, with commas between the entries:
    
    
    (10, 'Mary had a little lamb')
    

Also, the parenthesis can be left out when it's not ambiguous to do so:
    
    
    10, 'whose fleece was as white as snow'
    

Note that one-element tuples can be entered by surrounding the entry with parentheses and adding a comma like so:
    
    
    ('this is a stupid tuple',)
    

Lists are similar, but with brackets:
    
    
    ['abc', 1,2,3]
    

Dicts are created by surrounding with curly braces a list of key,value pairs separated from each other by a colon and from the other entries with commas:
    
    
    { 'hello': 'world', 'weight': 'African or European?' }
    

Any of these composite types can contain any other, to any depth:
    
    
    ((((((((('bob',),['Mary', 'had', 'a', 'little', 'lamb']), { 'hello' : 'world' } ),),),),),),)
    

## Null object

The Python analogue of null pointer known from other programming languages is _None_. _None_ is not a null pointer or a null reference but an actual object of which there is only one instance. One of the uses of _None_ is in default argument values of functions, for which see [Python Programming/Functions#Default_Argument_Values](/wiki/Python_Programming/Functions#Default_Argument_Values). Comparisons to _None_ are usually made using _is_ rather than ==.

Testing for None and assignment:
    
    
    if item is None:
      ...
      another = None
     
    if not item is None:
      ...
     
    if item is not None: # Also possible
      ...
    

Using None in a default argument value:
    
    
    def log(message, type = None):
      ...
    

Links:

  * [4\. Built-in Constants](http://docs.python.org/2/library/constants.html?highlight=none#None), docs.python.org
  * [3.11.7 The Null Object](http://docs.python.org/release/2.5.2/lib/bltin-null-object.html), docs.python.org

[Previous: Basic syntax](/wiki/Python_Programming/Basic_syntax)
[Index](/wiki/Python_Programming)
[Next: Numbers](/wiki/Python_Programming/Numbers)

# Numbers

[Previous: Data types](/wiki/Python_Programming/Data_types)
[Index](/wiki/Python_Programming)
[Next: Strings](/wiki/Python_Programming/Strings)

Python 2.x supports 4 numeric types - int, long, float and complex. Of these, the long type has been dropped in Python 3.x - the int type is now of unlimited length by default. You don’t have to specify what type of variable you want; Python does that automatically.

  * _Int:_ The basic integer type in python, equivalent to the hardware 'c long' for the platform you are using in Python 2.x, unlimited in length in Python 3.x.
  * _Long:_ Integer type with unlimited length. In python 2.2 and later, Ints are automatically turned into long ints when they overflow. Dropped since Python 3.0, use int type instead.
  * _Float:_ This is a binary floating point number. Longs and Ints are automatically converted to floats when a float is used in an expression, and with the true-division `//` operator.
  * _Complex:_ This is a complex number consisting of two floats. Complex literals are written as a + bj where a and b are floating-point numbers denoting the real and imaginary parts respectively.

In general, the number types are automatically 'up cast' in this order:

Int → Long → Float → Complex. The farther to the right you go, the higher the precedence.
    
    
    >>> x = 5
    >>> type(x)
    <type 'int'>
    >>> x = 187687654564658970978909869576453
    >>> type(x)
    <type 'long'>
    >>> x = 1.34763
    >>> type(x)
    <type 'float'>
    >>> x = 5 + 2j
    >>> type(x)
    <type 'complex'>
    

The result of divisions is somewhat confusing. In Python 2.x, using the / operator on two integers will return another integer, using floor division. For example, `5/2` will give you 2. You have to specify one of the operands as a float to get true division, e.g. `5/2.` or `5./2` (the dot specifies you want to work with float) will yield 2.5. Starting with Python 2.2 this behavior can be changed to true division by the future division statement `from __future__ import division`. In Python 3.x, the result of using the / operator is always true division (you can ask for floor division explicitly by using the // operator since Python 2.2).

This illustrates the behavior of the / operator in Python 2.2+:
    
    
    >>> 5/2
    2
    >>> 5/2.
    2.5
    >>> 5./2
    2.5
    >>> from __future__ import division
    >>> 5/2
    2.5
    >>> 5//2
    2
    

[Previous: Data types](/wiki/Python_Programming/Data_types)
[Index](/wiki/Python_Programming)
[Next: Strings](/wiki/Python_Programming/Strings)

# Strings

[Previous: Numbers](/wiki/Python_Programming/Numbers)
[Index](/wiki/Python_Programming)
[Next: Lists](/wiki/Python_Programming/Lists)

## String operations

### Equality

Two strings are equal if and only if they have _exactly_ the same contents, meaning that they are both the same length and each character has a one-to-one positional correspondence. Many other languages test strings only for identity; that is, they only test whether two strings occupy the same space in memory. This latter operation is possible in Python using the operator `is`.

Example:
    
    
    >>> a = 'hello'; b = 'hello' # Assign 'hello' to a and b.
    >>> print a == b             # True
    True
    >>> print a == 'hello'       #
    True
    >>> print a == "hello"       # (choice of delimiter is unimportant)
    True
    >>> print a == 'hello '      # (extra space)
    False
    >>> print a == 'Hello'       # (wrong case)
    False
    >>> a is a                   # True
    True
    >>> a is b                   # True, because python caches small strings, thus stores both strings in the same location
    True
    >>> a is 'hello'             # In this case 'hello' uses another cache than variables
    False
    >>> 'hello' is 'hello'       # But all 'hello's use the same cache
    True
    >>> a*2 is a*2               # No caching if operations are applied
    False
    

### Numerical

There are two quasi-numerical operations which can be done on strings -- addition and multiplication. String addition is just another name for concatenation. String multiplication is repetitive addition, or concatenation. So:
    
    
    >>> c = 'a'
    >>> c + 'b'
    'ab'
    >>> c * 5
    'aaaaa'
    

### Containment

There is a simple operator 'in' that returns True if the first operand is contained in the second. This also works on substrings
    
    
    >>> x = 'hello'
    >>> y = 'ell'
    >>> x in y
    False
    >>> y in x
    True
    

Note that 'print x in y' would have also returned the same value.

### Indexing and Slicing

Much like arrays in other languages, the individual characters in a string can be accessed by an integer representing its position in the string. The first character in string s would be s[0] and the nth character would be at s[n-1].
    
    
    >>> s = "Xanadu"
    >>> s[1]
    'a'
    

Unlike arrays in other languages, Python also indexes the arrays backwards, using negative numbers. The last character has index -1, the second to last character has index -2, and so on.
    
    
    >>> s[-4]
    'n'
    

We can also use "slices" to access a substring of s. s[a:b] will give us a string starting with s[a] and ending with s[b-1].
    
    
    >>> s[1:4]
    'ana'
    

None of these are assignable.
    
    
    >>> print s
    >>> s[0] = 'J'
    Traceback (most recent call last):
    File "<stdin>", line 1, in ?
    TypeError: object does not support item assignment
    >>> s[1:3] = "up"
    Traceback (most recent call last):
    File "<stdin>", line 1, in ?
    TypeError: object does not support slice assignment
    >>> print s
    

Outputs (assuming the errors were suppressed):
    
    
    Xanadu
    Xanadu
    

Another feature of slices is that if the beginning or end is left empty, it will default to the first or last index, depending on context:
    
    
    >>> s[2:]
    'nadu'
    >>> s[:3]
    'Xan'
    >>> s[:]
    'Xanadu'
    

You can also use negative numbers in slices:
    
    
    >>> print s[-2:]
    'du'
    

To understand slices, it's easiest not to count the elements themselves. It is a bit like counting not on your fingers, but in the spaces between them. The list is indexed like this:
    
    
    Element:     1     2     3     4
    Index:    0     1     2     3     4
             -4    -3    -2    -1
    

So, when we ask for the [1:3] slice, that means we start at index 1, and end at index 3, and take everything in between them. If you are used to indexes in C or Java, this can be a bit disconcerting until you get used to it.

## String constants

String constants can be found in the standard string module. Either single or double quotes may be used to delimit string constants.

## String methods

There are a number of methods or built-in string functions:

  * **capitalize**
  * **center**
  * **count**
  * decode
  * encode
  * endswith
  * **expandtabs**
  * **find**
  * **index**
  * **isalnum**
  * **isalpha**
  * **isdigit**
  * **islower**
  * **isspace**
  * **istitle**
  * **isupper**
  * **join**
  * **ljust**
  * **lower**
  * **lstrip**
  * **replace**
  * **rfind**
  * **rindex**
  * **rjust**
  * **rstrip**
  * **split**
  * **splitlines**
  * startswith
  * **strip**
  * **swapcase**
  * **title**
  * translate
  * **upper**
  * zfill

Only emphasized items will be covered.

### is*

isalnum(), isalpha(), isdigit(), islower(), isupper(), isspace(), and istitle() fit into this category.

The length of the string object being compared must be at least 1, or the is* methods will return False. In other words, a string object of len(string) == 0, is considered "empty", or False.

  * **isalnum** returns True if the string is entirely composed of alphabetic and/or numeric characters (i.e. no punctuation).
  * **isalpha** and **isdigit** work similarly for alphabetic characters or numeric characters only.
  * **isspace** returns True if the string is composed entirely of whitespace.
  * **islower**, **isupper**, and **istitle** return True if the string is in lowercase, uppercase, or titlecase respectively. Uncased characters are "allowed", such as digits, but there must be at least one cased character in the string object in order to return True. Titlecase means the first cased character of each word is uppercase, and any immediately following cased characters are lowercase. Curiously, 'Y2K'.istitle() returns True. That is because uppercase characters can only follow uncased characters. Likewise, lowercase characters can only follow uppercase or lowercase characters. Hint: whitespace is uncased.

Example:
    
    
    >>> '2YK'.istitle()
    False
    >>> 'Y2K'.istitle()
    True
    >>> '2Y K'.istitle()
    True
    

### title, upper, lower, swapcase, capitalize

Returns the string converted to title case, upper case, lower case, inverts case, or capitalizes, respectively.

The **title** method capitalizes the first letter of each word in the string (and makes the rest lower case). Words are identified as substrings of alphabetic characters that are separated by non-alphabetic characters, such as digits, or whitespace. This can lead to some unexpected behavior. For example, the string "x1x" will be converted to "X1X" instead of "X1x".

The **swapcase** method makes all uppercase letters lowercase and vice versa.

The **capitalize** method is like title except that it considers the entire string to be a word. (i.e. it makes the first character upper case and the rest lower case)

Example:
    
    
    >>> s = 'Hello, wOrLD'
    >>> s
    'Hello, wOrLD'
    >>> s.title()
    'Hello, World'
    >>> s.swapcase()
    'hELLO, WoRld'
    >>> s.upper()
    'HELLO, WORLD'
    >>> s.lower()
    'hello, world'
    >>> s.capitalize()
    'Hello, world'
    

### count

Returns the number of the specified substrings in the string. i.e.
    
    
    >>> s = 'Hello, world'
    >>> s.count('o') # print the number of 'o's in 'Hello, World' (2)
    2
    

Hint: .count() is case-sensitive, so this example will only count the number of lowercase letter 'o's. For example, if you ran:
    
    
    >>> s = 'HELLO, WORLD'
    >>> s.count('o') # print the number of lowercase 'o's in 'HELLO, WORLD' (0)
    0
    

### strip, rstrip, lstrip

Returns a copy of the string with the leading (lstrip) and trailing (rstrip) whitespace removed. strip removes both.
    
    
    >>> s = '\t Hello, world\n\t '
    >>> print s
             Hello, world
     
    >>> print s.strip()
    Hello, world
    >>> print s.lstrip()
    Hello, world
            # ends here
    >>> print s.rstrip()
             Hello, world
    

Note the leading and trailing tabs and newlines.

Strip methods can also be used to remove other types of characters.
    
    
    import string
    s = 'www.wikibooks.org'
    print s
    print s.strip('w')                 # Removes all w's from outside
    print s.strip(string.lowercase)    # Removes all lowercase letters from outside
    print s.strip(string.printable)    # Removes all printable characters
    

Outputs:
    
    
    www.wikibooks.org
    .wikibooks.org
    .wikibooks.
     
    

Note that string.lowercase and string.printable require an import string statement

### ljust, rjust, center

left, right or center justifies a string into a given field size (the rest is padded with spaces).
    
    
    >>> s = 'foo'
    >>> s
    'foo'
    >>> s.ljust(7)
    'foo    '
    >>> s.rjust(7)
    '    foo'
    >>> s.center(7)
    '  foo  '
    

### join

Joins together the given sequence with the string as separator:
    
    
    >>> seq = ['1', '2', '3', '4', '5']
    >>> ' '.join(seq)
    '1 2 3 4 5'
    >>> '+'.join(seq)
    '1+2+3+4+5'
    

map may be helpful here: (it converts numbers in seq into strings)
    
    
    >>> seq = [1,2,3,4,5]
    >>> ' '.join(map(str, seq))
    '1 2 3 4 5'
    

now arbitrary objects may be in seq instead of just strings.

### find, index, rfind, rindex

The find and index methods return the index of the first found occurrence of the given subsequence. If it is not found, find returns -1 but index raises a ValueError. rfind and rindex are the same as find and index except that they search through the string from right to left (i.e. they find the last occurrence)
    
    
    >>> s = 'Hello, world'
    >>> s.find('l')
    2
    >>> s[s.index('l'):]
    'llo, world'
    >>> s.rfind('l')
    10
    >>> s[:s.rindex('l')]
    'Hello, wor'
    >>> s[s.index('l'):s.rindex('l')]
    'llo, wor'
    

Because Python strings accept negative subscripts, index is probably better used in situations like the one shown because using find instead would yield an unintended value.

### replace

Replace works just like it sounds. It returns a copy of the string with all occurrences of the first parameter replaced with the second parameter.
    
    
    >>> 'Hello, world'.replace('o', 'X')
    'HellX, wXrld'
    

Or, using variable assignment:
    
    
    string = 'Hello, world'
    newString = string.replace('o', 'X')
    print string
    print newString
    

Outputs:
    
    
    Hello, world
    HellX, wXrld
    

Notice, the original variable (`string`) remains unchanged after the call to `replace`.

### expandtabs

Replaces tabs with the appropriate number of spaces (default number of spaces per tab = 8; this can be changed by passing the tab size as an argument).
    
    
    s = 'abcdefg\tabc\ta'
    print s
    print len(s)
    t = s.expandtabs()
    print t
    print len(t)
    

Outputs:
    
    
    abcdefg abc     a
    13
    abcdefg abc     a
    17
    

Notice how (although these both look the same) the second string (t) has a different length because each tab is represented by spaces not tab characters.

To use a tab size of 4 instead of 8:
    
    
    v = s.expandtabs(4)
    print v
    print len(v)
    

Outputs:
    
    
    abcdefg abc a
    13
    

Please note each tab is not always counted as eight spaces. Rather a tab "pushes" the count to the next multiple of eight. For example:
    
    
    s = '\t\t'
    print s.expandtabs().replace(' ', '*')
    print len(s.expandtabs())
    

Output:
    
    
     ****************
     16
    
    
    
    s = 'abc\tabc\tabc'
    print s.expandtabs().replace(' ', '*')
    print len(s.expandtabs())
    

Outputs:
    
    
     abc*****abc*****abc
     19
    

### split, splitlines

The **split** method returns a list of the words in the string. It can take a separator argument to use instead of whitespace.
    
    
    >>> s = 'Hello, world'
    >>> s.split()
    ['Hello,', 'world']
    >>> s.split('l')
    ['He', '', 'o, wor', 'd']
    

Note that in neither case is the separator included in the split strings, but empty strings are allowed.

The **splitlines** method breaks a multiline string into many single line strings. It is analogous to split('\n') (but accepts '\r' and '\r\n' as delimiters as well) except that if the string ends in a newline character, **splitlines** ignores that final character (see example).
    
    
    >>> s = """
    ... One line
    ... Two lines
    ... Red lines
    ... Blue lines
    ... Green lines
    ... """
    >>> s.split('\n')
    ['', 'One line', 'Two lines', 'Red lines', 'Blue lines', 'Green lines', '']
    >>> s.splitlines()
    ['', 'One line', 'Two lines', 'Red lines', 'Blue lines', 'Green lines']
    

## External links

  * ["String Methods" chapter](http://docs.python.org/2/library/stdtypes.html?highlight=rstrip#string-methods) \-- python.org
  * [Python documentation of "string" module](http://docs.python.org/2/library/string.html) \-- python.org

[Previous: Numbers](/wiki/Python_Programming/Numbers)
[Index](/wiki/Python_Programming)
[Next: Lists](/wiki/Python_Programming/Lists)

# Lists

[Previous: Strings](/wiki/Python_Programming/Strings)
[Index](/wiki/Python_Programming)
[Next: Tuples](/wiki/Python_Programming/Tuples)

A list in Python is an ordered group of items (or _elements_). It is a very general structure, and list elements don't have to be of the same type. For instance, you could put numbers, letters, and strings all on the same list.

If you are using a modern version of Python (and you should be), there is a class called 'list'. If you wish, you can make your own subclass of it, and determine list behaviour which is different than the default standard. But first, you should be familiar with the current behaviour of lists.

## List creation

There are two different ways to make a list in Python. The first is through assignment ("statically"), the second is using list comprehensions ("actively").

### Plain creation

To make a static list of items, write them between square brackets. For example:
    
    
    [ 1,2,3,"This is a list",'c',Donkey("kong") ]
    

Observations:

  1. The list contains items of different data types: integer, string, and Donkey class.
  2. Objects can be created 'on the fly' and added to lists. The last item is a new instance of Donkey class.

Creation of a new list whose members are constructed from non-literal expressions:
    
    
    a = 2
    b = 3
    myList = [a+b, b+a, len(["a","b"])]
    

### List comprehensions

_See also [Tips and Tricks](/wiki/Python_Programming/Tips_and_Tricks#List_comprehension_and_generators)_

Using list comprehension, you describe the process using which the list should be created. To do that, the list is broken into two pieces. The first is a picture of what each element will look like, and the second is what you do to get it.

For instance, let's say we have a list of words:
    
    
    listOfWords = ["this","is","a","list","of","words"]
    

To take the first letter of each word and make a list out of it using list comprehension, we can do this:
    
    
    >>> listOfWords = ["this","is","a","list","of","words"]
    >>> items = [ word[0] for word in listOfWords ]
    >>> print items
    ['t', 'i', 'a', 'l', 'o', 'w']
    

List comprehension supports more than one for statement. It will evaluate the items in all of the objects sequentially and will loop over the shorter objects if one object is longer than the rest.
    
    
    >>> item = [x+y for x in 'cat' for y in 'pot']
    >>> print item
    ['cp', 'co', 'ct', 'ap', 'ao', 'at', 'tp', 'to', 'tt']
    

List comprehension supports an if statement, to only include members into the list that fulfill a certain condition:
    
    
    >>> print [x+y for x in 'cat' for y in 'pot']
    ['cp', 'co', 'ct', 'ap', 'ao', 'at', 'tp', 'to', 'tt']
    >>> print [x+y for x in 'cat' for y in 'pot' if x != 't' and y != 'o' ]
    ['cp', 'ct', 'ap', 'at']
    >>> print [x+y for x in 'cat' for y in 'pot' if x != 't' or y != 'o' ]
    ['cp', 'co', 'ct', 'ap', 'ao', 'at', 'tp', 'tt']
    

Python's list comprehension does not define a scope. Any variables that are bound in an evaluation remain bound to whatever they were last bound to when the evaluation was completed:
    
    
    >>> print x, y
    r t
    

This is exactly the same as if the comprehension had been expanded into an explicitly-nested group of one or more 'for' statements and 0 or more 'if' statements.

### List creation shortcuts

You can initialize a list to a size, with an initial value for each element:
    
    
    >>> zeros=[0]*5
    >>> print zeros
    [0, 0, 0, 0, 0]
    

This works for any data type:
    
    
    >>> foos=['foo']*3
    >>> print foos
    ['foo', 'foo', 'foo']
    

But there is a caveat. When building a new list by multiplying, Python copies each item by reference. This poses a problem for mutable items, for instance in a multidimensional array where each element is itself a list. You'd guess that the easy way to generate a two dimensional array would be:
    
    
    listoflists=[ [0]*4 ] *5
    

and this works, but probably doesn't do what you expect:
    
    
    >>> listoflists=[ [0]*4 ] *5
    >>> print listoflists
    [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
    >>> listoflists[0][2]=1
    >>> print listoflists
    [[0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 1, 0]]
    

What's happening here is that Python is using the same reference to the inner list as the elements of the outer list. Another way of looking at this issue is to examine how Python sees the above definition:
    
    
    >>> innerlist=[0]*4
    >>> listoflists=[innerlist]*5
    >>> print listoflists
    [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
    >>> innerlist[2]=1
    >>> print listoflists
    [[0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 1, 0]]
    

Assuming the above effect is not what you intend, one way around this issue is to use list comprehensions:
    
    
    >>> listoflists=[[0]*4 for i in range(5)]
    >>> print listoflists
    [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
    >>> listoflists[0][2]=1
    >>> print listoflists
    [[0, 0, 1, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
    

## List Attributes

To find the length of a list use the built in len() method.
    
    
    >>> len([1,2,3])
    3
    >>> a = [1,2,3,4]
    >>> len( a )
    4
    

## Combining lists

Lists can be combined in several ways. The easiest is just to 'add' them. For instance:
    
    
    >>> [1,2] + [3,4]
    [1, 2, 3, 4]
    

Another way to combine lists is with **extend**. If you need to combine lists inside of a lambda, **extend** is the way to go.
    
    
    >>> a = [1,2,3]
    >>> b = [4,5,6]
    >>> a.extend(b)
    >>> print a
    [1, 2, 3, 4, 5, 6]
    

The other way to append a value to a list is to use **append**. For example:
    
    
    >>> p=[1,2]
    >>> p.append([3,4])
    >>> p
    [1, 2, [3, 4]]
    >>> # or
    >>> print p
    [1, 2, [3, 4]]
    

However, [3,4] is an element of the list, and not part of the list. **append** always adds one element only to the end of a list. So if the intention was to concatenate two lists, always use **extend**.

## Getting pieces of lists (slices)

### Continuous slices

Like [strings](/wiki/Python_Programming/Strings), lists can be indexed and sliced.
    
    
    >>> list = [2, 4, "usurp", 9.0,"n"]
    >>> list[2]
    'usurp'
    >>> list[3:]
    [9.0, 'n']
    

Much like the slice of a string is a substring, the slice of a list is a list. However, lists differ from strings in that we can assign new values to the items in a list.
    
    
    >>> list[1] = 17
    >>> list
    [2, 17, 'usurp', 9.0,'n']
    

We can even assign new values to slices of the lists, which don't even have to be the same length
    
    
    >>> list[1:4] = ["opportunistic", "elk"]
    >>> list
    [2, 'opportunistic', 'elk', 'n']
    

It's even possible to append things onto the end of lists by assigning to an empty slice:
    
    
    >>> list[:0] = [3.14,2.71]
    >>> list
    [3.14, 2.71, 2, 'opportunistic', 'elk', 'n']
    

You can also completely change contents of a list:
    
    
    >>> list[:] = ['new', 'list', 'contents']
    >>> list
    ['new', 'list', 'contents']
    

On the right-hand side of assignment statement can be any iterable type:
    
    
    >>> list[:2] = ('element',('t',),[])
    >>> list
    ['element', ('t',), [], 'contents']
    

With slicing you can create copy of list because slice returns a new list:
    
    
    >>> original = [1, 'element', []]
    >>> list_copy = original[:]
    >>> list_copy
    [1, 'element', []]
    >>> list_copy.append('new element')
    >>> list_copy
    [1, 'element', [], 'new element']
    >>> original
    [1, 'element', []]
    

but this is shallow copy and contains references to elements from original list, so be careful with mutable types:
    
    
    >>> list_copy[2].append('something')
    >>> original
    [1, 'element', ['something']]
    

### Non-Continuous slices

It is also possible to get non-continuous parts of an array. If one wanted to get every n-th occurrence of a list, one would use the :: operator. The syntax is a:b:n where a and b are the start and end of the slice to be operated upon.
    
    
    >>> list = [i for i in range(10) ]
    >>> list
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    >>> list[::2]
    [0, 2, 4, 6, 8]
    >>> list[1:7:2]
    [1, 3, 5]
    

## Comparing lists

Lists can be compared for equality.
    
    
    >>> [1,2] == [1,2]
    True
    >>> [1,2] == [3,4]
    False
    

Lists can be compared using a less-than operator, which uses lexicographical order:
    
    
    >>> [1,2] < [2,1]
    True
    >>> [2,2] < [2,1]
    False
    >>> ["a","b"] < ["b","a"]
    True
    

## Sorting lists

Sorting lists is easy with a sort method.
    
    
    >>> list = [2, 3, 1, 'a', 'b']
    >>> list.sort()
    >>> list
    [1, 2, 3, 'a', 'b']
    

Note that the list is sorted in place, and the sort() method returns **None** to emphasize this side effect.

If you use Python 2.4 or higher there are some more sort parameters:

sort(cmp,key,reverse)

cmp : method to be used for sorting key : function to be executed with key element. List is sorted by return-value of the function reverse : sort(reverse=True) or sort(reverse=False)

Python also includes a sorted() function.
    
    
    >>> list = [5, 2, 3, 'q', 'p']
    >>> sorted(list)
    [2, 3, 5, 'p', 'q']
    >>> list
    [5, 2, 3, 'q', 'p']
    

Note that unlike the sort() method, sorted(list) does not sort the list in place, but instead returns the sorted list. The sorted() function, like the sort() method also accepts the reverse parameter.

## Iteration

Iteration over lists:

Read-only iteration over a list, AKA for each element of the list:
    
    
    for item in list:
      print item
    

Writable iteration over a list:
    
    
    list = [1, 2, 3, 4]
    i = 0
    length = len(list)
    while i < length:
      list[i]+=1 # Modify the item at an index as you see fit
      i+=1
    print list
    

From a number to a number with a step:
    
    
    for i in range(1, 13+1, 3): # For i=1 to 13 step 3
      print i
    for i in range(10, 5-1, -1): # For i=10 to 5 step -1
      print i
    

For each element of a list satisfying a condition (filtering):
    
    
    for item in list:
      if not condition(item):
        continue
      print item
    

See also [Python Programming/Loops#For_Loops](/wiki/Python_Programming/Loops#For_Loops).

## Removing

Removing aka deleting an item at an index (see also #pop(i)):
    
    
    list = [1, 2, 3, 4]
    list.pop() # Remove the last item
    list.pop(0) # Remove the first item , which is the item at index 0
    print list
     
    list = [1, 2, 3, 4]
    del list[1] # Remove the 2nd element; an alternative to list.pop(1)
    print list
    

Removing an element by value:
    
    
    list = ["a", "a", "b"]
    list.remove("a") # Removes only the 1st occurrence of "a"
    print list
    

Keeping only items in a list satisfying a condition, and thus removing the items that do not satisfy it:
    
    
    list = [1, 2, 3, 4]
    newlist = [item for item in list if item >2]
    print newlist
    

This uses a list comprehension.

## Aggregates

There are some built-in functions for arithmetic aggregates over lists. These include minimum, maximum, and sum:
    
    
    list = [1, 2, 3, 4]
    print max(list), min(list), sum(list)
    average = sum(list) / float(len(list)) # Provided the list is non-empty
    # The float above ensures the division is a float one rather than integer one.
    print average
    

The max and min functions also apply to lists of strings, returning maximum and minimum with respect to alphabetical order:
    
    
    list = ["aa", "ab"]
    print max(list), min(list) # Prints "ab aa"
    

## Copying

Copying AKA cloning of lists:

Making a shallow copy:
    
    
    list1= [1, 'element']
    list2 = list1[:] # Copy using "[:]"
    list2[0] = 2 # Only affects list2, not list1
    print list1[0] # Displays 1
     
    # By contrast
    list1 = [1, 'element']
    list2 = list1
    list2[0] = 2 # Modifies the original list
    print list1[0] # Displays 2
    

The above does not make a deep copy, which has the following consequence:
    
    
    list1 = [1, [2, 3]] # Notice the second item being a nested list
    list2 = list1[:] # A shallow copy
    list2[1][0] = 4 # Modifies the 2nd item of list1 as well
    print list1[1][0] # Displays 4 rather than 2
    

Making a deep copy:
    
    
    import copy
    list1 = [1, [2, 3]] # Notice the second item being a nested list
    list2 = copy.deepcopy(list1) # A deep copy
    list2[1][0] = 4 # Leaves the 2nd item of list1 unmodified
    print list1[1][0] # Displays 2
    

See also #Continuous slices.

Links:

  * [8.17. copy — Shallow and deep copy operations](http://docs.python.org/2/library/copy.html) at docs.python.org

## List methods

### append(x)

Add item _x_ onto the end of the list.
    
    
    >>> list = [1, 2, 3]
    >>> list.append(4)
    >>> list
    [1, 2, 3, 4]
    

See pop(i)

### pop(i)

Remove the item in the list at the index _i_ and return it. If _i_ is not given, remove the the last item in the list and return it.
    
    
    >>> list = [1, 2, 3, 4]
    >>> a = list.pop(0)
    >>> list
    [2, 3, 4]
    >>> a
    1
    >>> b = list.pop()
    >>>list
    [2, 3]
    >>> b
    4
    

## operators

### in

The operator 'in' is used for two purposes; either to iterate over every item in a list in a for loop, or to check if a value is in a list returning true or false.
    
    
    >>> list = [1, 2, 3, 4]
    >>> if 3 in list:
    >>>    ....
    >>> l = [0, 1, 2, 3, 4]
    >>> 3 in l
    True
    >>> 18 in l
    False
    >>>for x in l:
    >>>    print x
    0
    1
    2
    3
    4
    

## External links

  * [Python documentation, chapter "Sequence Types"](http://docs.python.org/2/library/stdtypes.html?highlight=rstrip#sequence-types-str-unicode-list-tuple-bytearray-buffer-xrange) \-- python.org
  * [Python Tutorial, chapter "Lists"](http://docs.python.org/2/tutorial/introduction.html#lists) \-- python.org

[Previous: Strings](/wiki/Python_Programming/Strings)
[Index](/wiki/Python_Programming)
[Next: Tuples](/wiki/Python_Programming/Tuples)

}}

# Dictionaries

[Previous: Tuples](/wiki/Python_Programming/Tuples)
[Index](/wiki/Python_Programming)
[Next: Sets](/wiki/Python_Programming/Sets)

A dictionary in Python is a collection of unordered values accessed by key rather than by index. The keys have to be hashable: integers, floating point numbers, strings, tuples, and frozensets are hashable, while lists, dictionaries, and sets other than frozensets are not. Dictionaries were available as early as in Python 1.4.

## Overview

Dictionaries in Python at a glance:
    
    
    dict1 = {}                     # Create an empty dictionary
    dict2 = dict()                 # Create an empty dictionary 2
    dict2 = {"r": 34, "i": 56}     # Initialize to non-empty value
    dict3 = dict([("r", 34), ("i", 56)]) # Init from a list of tuples
    dict4 = dict(r=34, i=56)       # Initialize to non-empty value 3
    dict1["temperature"] = 32      # Assign value to a key
    if "temperature" in dict1:     # Membership test of a key AKA key exists
      del dict1["temperature"]     # Delete AKA remove
    equalbyvalue = dict2 == dict3
    itemcount2 = len(dict2)        # Length AKA size AKA item count
    isempty2 = len(dict2) == 0     # Emptiness test
    for key in dict2:              # Iterate via keys
      print key, dict2[key]        # Print key and the associated value
      dict2[key] += 10             # Modify-access to the key-value pair
    for value in dict2.values():   # Iterate via values
      print value
    dict5 = {} # {x: dict2[x] + 1 for x in dict2 } # Dictionary comprehension in Python 2.7 or later
    dict6 = dict2.copy()             # A shallow copy
    dict6.update({"i": 60, "j": 30}) # Add or overwrite
    print dict1, dict2, dict3, dict4, dict5, dict6, equalbyvalue, itemcount2
    

## Dictionary notation

Dictionaries may be created directly or converted from sequences. Dictionaries are enclosed in curly braces, `{}`
    
    
    >>> d = {'city':'Paris', 'age':38, (102,1650,1601):'A matrix coordinate'}
    >>> seq = [('city','Paris'), ('age', 38), ((102,1650,1601),'A matrix coordinate')]
    >>> d
    {'city': 'Paris', 'age': 38, (102, 1650, 1601): 'A matrix coordinate'}
    >>> dict(seq)
    {'city': 'Paris', 'age': 38, (102, 1650, 1601): 'A matrix coordinate'}
    >>> d == dict(seq)
    True
    

Also, dictionaries can be easily created by zipping two sequences.
    
    
    >>> seq1 = ('a','b','c','d')
    >>> seq2 = [1,2,3,4]
    >>> d = dict(zip(seq1,seq2))
    >>> d
    {'a': 1, 'c': 3, 'b': 2, 'd': 4}
    

## Operations on Dictionaries

The operations on dictionaries are somewhat unique. Slicing is not supported, since the items have no intrinsic order.
    
    
    >>> d = {'a':1,'b':2, 'cat':'Fluffers'}
    >>> d.keys()
    ['a', 'b', 'cat']
    >>> d.values()
    [1, 2, 'Fluffers']
    >>> d['a']
    1
    >>> d['cat'] = 'Mr. Whiskers'
    >>> d['cat']
    'Mr. Whiskers'
    >>> 'cat' in d
    True
    >>> 'dog' in d
    False
    

## Combining two Dictionaries

You can combine two dictionaries by using the update method of the primary dictionary. Note that the update method will merge existing elements if they conflict.
    
    
    >>> d = {'apples': 1, 'oranges': 3, 'pears': 2}
    >>> ud = {'pears': 4, 'grapes': 5, 'lemons': 6}
    >>> d.update(ud)
    >>> d
    {'grapes': 5, 'pears': 4, 'lemons': 6, 'apples': 1, 'oranges': 3}
    >>>
    

## Deleting from dictionary
    
    
    del dictionaryName[membername]
    

## External links

  * [Python documentation, chapter "Dictionaries"](http://docs.python.org/2/tutorial/datastructures.html#dictionaries) \-- python.org
  * [Python documentation, The Python Standard Library, 5.8. Mapping Types](http://docs.python.org/2/library/stdtypes.html#typesmapping) \-- python.org

[Previous: Tuples](/wiki/Python_Programming/Tuples)
[Index](/wiki/Python_Programming)
[Next: Sets](/wiki/Python_Programming/Sets)

# Sets

[Previous: Dictionaries](/wiki/Python_Programming/Dictionaries)
[Index](/wiki/Python_Programming)
[Next: Operators](/wiki/Python_Programming/Operators)

Starting with version 2.3, Python comes with an implementation of the mathematical set. Initially this implementation had to be imported from the standard module `set`, but with Python 2.6 the types set and frozenset became built-in types. A set is an unordered collection of objects, unlike sequence objects such as lists and tuples, in which each element is indexed. Sets cannot have duplicate members - a given object appears in a set 0 or 1 times. All members of a set have to be hashable, just like dictionary keys. Integers, floating point numbers, tuples, and strings are hashable; dictionaries, lists, and other sets (except frozensets) are not.

### Overview

Sets in Python at a glance:
    
    
    set1 = set()                   # A new empty set
    set1.add("cat")                # Add a single member
    set1.update(["dog", "mouse"])  # Add several members
    if "cat" in set1:              # Membership test
      set1.remove("cat")
    #set1.remove("elephant") - throws an error
    print set1
    for item in set1:              # Iteration AKA for each element
      print item
    print "Item count:", len(set1) # Length AKA size AKA item count
    isempty = len(set1) == 0       # Test for emptiness
    set1 = set(["cat", "dog"])     # Initialize set from a list
    set2 = set(["dog", "mouse"])
    set3 = set1 & set2             # Intersection
    set4 = set1 | set2             # Union
    set5 = set1 - set3             # Set difference
    set6 = set1 ^ set2             # Symmetric difference
    issubset = set1 <= set2        # Subset test
    issuperset = set1 >= set2      # Superset test
    set7 = set1.copy()             # A shallow copy
    set7.remove("cat")
    print set1, set2, set3, set4, set5, set6, set7, issubset, issuperset
    

### Constructing Sets

One way to construct sets is by passing any sequential object to the "set" constructor.
    
    
    >>> set([0, 1, 2, 3])
    set([0, 1, 2, 3])
    >>> set("obtuse")
    set(['b', 'e', 'o', 's', 'u', 't'])
    

We can also add elements to sets one by one, using the "add" function.
    
    
    >>> s = set([12, 26, 54])
    >>> s.add(32)
    >>> s
    set([32, 26, 12, 54])
    

Note that since a set does not contain duplicate elements, if we add one of the members of s to s again, the add function will have no effect. This same behavior occurs in the "update" function, which adds a group of elements to a set.
    
    
    >>> s.update([26, 12, 9, 14])
    >>> s
    set([32, 9, 12, 14, 54, 26])
    

Note that you can give any type of sequential structure, or even another set, to the update function, regardless of what structure was used to initialize the set.

The set function also provides a copy constructor. However, remember that the copy constructor will copy the set, but not the individual elements.
    
    
    >>> s2 = s.copy()
    >>> s2
    set([32, 9, 12, 14, 54, 26])
    

### Membership Testing

We can check if an object is in the set using the same "in" operator as with sequential data types.
    
    
    >>> 32 in s
    True
    >>> 6 in s
    False
    >>> 6 not in s
    True
    

We can also test the membership of entire sets. Given two sets ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) and ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png), we check if ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) is a [subset](//en.wikipedia.org/wiki/Subset) or a superset of ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png).
    
    
    >>> s.issubset(set([32, 8, 9, 12, 14, -4, 54, 26, 19]))
    True
    >>> s.issuperset(set([9, 12]))
    True
    

Note that "issubset" and "issuperset" can also accept sequential data types as arguments
    
    
    >>> s.issuperset([32, 9])
    True
    

Note that the <= and >= operators also express the issubset and issuperset functions respectively.
    
    
    >>> set([4, 5, 7]) <= set([4, 5, 7, 9])
    True
    >>> set([9, 12, 15]) >= set([9, 12])
    True
    

Like lists, tuples, and string, we can use the "len" function to find the number of items in a set.

### Removing Items

There are three functions which remove individual items from a set, called pop, remove, and discard. The first, pop, simply removes an item from the set. Note that there is no defined behavior as to which element it chooses to remove.
    
    
    >>> s = set([1,2,3,4,5,6])
    >>> s.pop()
    1
    >>> s
    set([2,3,4,5,6])
    

We also have the "remove" function to remove a specified element.
    
    
    >>> s.remove(3)
    >>> s
    set([2,4,5,6])
    

However, removing a item which isn't in the set causes an error.
    
    
    >>> s.remove(9)
    Traceback (most recent call last):
      File "<stdin>", line 1, in ?
    KeyError: 9
    

If you wish to avoid this error, use "discard." It has the same functionality as remove, but will simply do nothing if the element isn't in the set

We also have another operation for removing elements from a set, clear, which simply removes all elements from the set.
    
    
    >>> s.clear()
    >>> s
    set([])
    

### Iteration Over Sets

We can also have a loop move over each of the items in a set. However, since sets are unordered, it is undefined which order the iteration will follow.
    
    
    >>> s = set("blerg")
    >>> for n in s:
    ...     print n,
    ...
    r b e l g
    

### Set Operations

Python allows us to perform all the standard mathematical set operations, using members of set. Note that each of these set operations has several forms. One of these forms, s1.function(s2) will return another set which is created by "function" applied to ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) and ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png). The other form, s1.function_update(s2), will change ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) to be the set created by "function" of ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) and ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png). Finally, some functions have equivalent special operators. For example, s1 & s2 is equivalent to s1.intersection(s2)

#### Union

The [union](//en.wikipedia.org/wiki/union_\(set_theory\)) is the merger of two sets. Any element in ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) or ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png) will appear in their union.
    
    
    >>> s1 = set([4, 6, 9])
    >>> s2 = set([1, 6, 8])
    >>> s1.union(s2)
    set([1, 4, 6, 8, 9])
    >>> s1 | s2
    set([1, 4, 6, 8, 9])
    

Note that union's update function is simply "update" above.

#### Intersection

Any element which is in both ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) and ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png) will appear in their [intersection](//en.wikipedia.org/wiki/intersection_\(set_theory\)).
    
    
    >>> s1 = set([4, 6, 9])
    >>> s2 = set([1, 6, 8])
    >>> s1.intersection(s2)
    set([6])
    >>> s1 & s2
    set([6])
    >>> s1.intersection_update(s2)
    >>> s1
    set([6])
    

#### Symmetric Difference

The [symmetric difference](//en.wikipedia.org/wiki/symmetric_difference) of two sets is the set of elements which are in one of either set, but not in both.
    
    
    >>> s1 = set([4, 6, 9])
    >>> s2 = set([1, 6, 8])
    >>> s1.symmetric_difference(s2)
    set([8, 1, 4, 9])
    >>> s1 ^ s2
    set([8, 1, 4, 9])
    >>> s1.symmetric_difference_update(s2)
    >>> s1
    set([8, 1, 4, 9])
    

#### Set Difference

Python can also find the [set difference](//en.wikipedia.org/wiki/Complement_\(set_theory\)#Relative_Complement) of ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) and ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png), which is the elements that are in ![S_1](//upload.wikimedia.org/math/8/d/c/8dc4eef060814e559aff4c5fac3f51fe.png) but not in ![S_2](//upload.wikimedia.org/math/9/7/a/97a6ae0695c4b2723ff5c8bccdb1e735.png).
    
    
    >>> s1 = set([4, 6, 9])
    >>> s2 = set([1, 6, 8])
    >>> s1.difference(s2)
    set([9, 4])
    >>> s1 - s2
    set([9, 4])
    >>> s1.difference_update(s2)
    >>> s1
    set([9, 4])
    

### Multiple sets

Starting with Python 2.6, "union", "intersection", and "difference" can work with multiple input by using the set constructor. For example, using "set.intersection()":
    
    
    >>> s1 = set([3, 6, 7, 9])
    >>> s2 = set([6, 7, 9, 10])
    >>> s3 = set([7, 9, 10, 11])
    >>> set.intersection(s1, s2, s3)
    set([9, 7])
    

### frozenset

A frozenset is basically the same as a set, except that it is immutable - once it is created, its members cannot be changed. Since they are immutable, they are also hashable, which means that frozensets can be used as members in other sets and as dictionary keys. frozensets have the same functions as normal sets, except none of the functions that change the contents (update, remove, pop, etc.) are available.
    
    
    >>> fs = frozenset([2, 3, 4])
    >>> s1 = set([fs, 4, 5, 6])
    >>> s1
    set([4, frozenset([2, 3, 4]), 6, 5])
    >>> fs.intersection(s1)
    frozenset([4])
    >>> fs.add(6)
    Traceback (most recent call last):
      File "<stdin>", line 1, in <module>
    AttributeError: 'frozenset' object has no attribute 'add'
    

### Reference

  * [Python Tutorial, section "Data Structures", subsection "Sets"](http://docs.python.org/2/tutorial/datastructures.html#sets) \-- python.org
  * [Python Library Reference on Set Types](http://docs.python.org/library/stdtypes.html#set-types-set-frozenset) \-- python.org

[Previous: Dictionaries](/wiki/Python_Programming/Dictionaries)
[Index](/wiki/Python_Programming)
[Next: Operators](/wiki/Python_Programming/Operators)

# Operators

[Previous: Sets](/wiki/Python_Programming/Sets)
[Index](/wiki/Python_Programming)
[Next: Flow control](/wiki/Python_Programming/Flow_control)

## Basics

Python math works like you would expect.
    
    
    >>> x = 2
    >>> y = 3
    >>> z = 5
    >>> x * y
    6
    >>> x + y
    5
    >>> x * y + z
    11
    >>> (x + y) * z
    25
    

Note that Python adheres to the [PEMDAS order of operations](//en.wikipedia.org/wiki/Order_of_operations).

## Powers

There is a built in exponentiation operator **, which can take either integers, floating point or complex numbers. This occupies its proper place in the order of operations.
    
    
    >>> 2**8
    256
    

## Division and Type Conversion

For Python 2.x, dividing two integers or longs uses integer division, also known as "floor division" (applying the [floor function](//en.wikipedia.org/wiki/Floor_function) after division. So, for example, 5 / 2 is 2. Using "/" to do division this way is deprecated; if you want floor division, use "//" (available in Python 2.2 and later).

"/" does "true division" for floats and complex numbers; for example, 5.0/2.0 is 2.5.

For Python 3.x, "/" does "true division" for all types.[1][2]

Dividing by or into a floating point number (there are no fractional types in Python) will cause Python to use true division. To coerce an integer to become a float, 'float()' with the integer as a parameter
    
    
    >>> x = 5
    >>> float(x)
    5.0
    

This can be generalized for other numeric types: int(), complex(), long().

Beware that due to the limitations of [floating point arithmetic](//en.wikipedia.org/wiki/floating_point), rounding errors can cause unexpected results. For example:
    
    
    >>> print 0.6/0.2
    3.0
    >>> print 0.6//0.2
    2.0
    

## Modulo

The modulus (remainder of the division of the two operands, rather than the quotient) can be found using the % operator, or by the divmod builtin function. The divmod function returns a tuple containing the quotient and remainder.
    
    
    >>> 10%7
    3
    

## Negation

Unlike some other languages, variables can be negated directly:
    
    
    >>> x = 5
    >>> -x
    -5
    

## Augmented Assignment

There is shorthand for assigning the output of an operation to one of the inputs:
    
    
    >>> x = 2
    >>> x # 2
    2
    >>> x *= 3
    >>> x # 2 * 3
    6
    >>> x += 4
    >>> x # 2 * 3 + 4
    10
    >>> x /= 5
    >>> x # (2 * 3 + 4) / 5
    2
    >>> x **= 2
    >>> x # ((2 * 3 + 4) / 5) ** 2
    4
    >>> x %= 3
    >>> x # ((2 * 3 + 4) / 5) ** 2 % 3
    1
     
    >>> x = 'repeat this  '
    >>> x  # repeat this
    repeat this
    >>> x *= 3  # fill with x repeated three times
    >>> x
    repeat this  repeat this  repeat this
    

## Boolean

or:
    
    
    if a or b:
        do_this
    else:
        do_this
    

and:
    
    
    if a and b:
        do_this
    else:
        do_this
    

not:
    
    
    if not a:
        do_this
    else:
        do_this
    

## References

  1. ↑ [The Things I Hate About IDLE That I Wish Someone Would Fix The table below lists some IDLE alternatives](http://inventwithpython.com/blog/2011/11/29/the-things-i-hate-about-idle-that-i-wish-someone-would-fix/).

[Previous: Sets](/wiki/Python_Programming/Sets)
[Index](/wiki/Python_Programming)
[Next: Flow control](/wiki/Python_Programming/Flow_control)

# Flow control

[Previous: Operators](/wiki/Python_Programming/Operators)
[Index](/wiki/Python_Programming)
[Next: Functions](/wiki/Python_Programming/Functions)

As with most imperative languages, there are three main categories of program control flow:

  * loops
  * branches
  * function calls

Function calls are covered in the [next section](/wiki/Python_Programming/Functions).

Generators and list comprehensions are advanced forms of program control flow, but they are not covered here.

### Loops

In Python, there are two kinds of loops, 'for' loops and 'while' loops.

#### For loops

A for loop iterates over elements of a sequence (tuple or list). A variable is created to represent the object in the sequence. For example,
    
    
    x = [100,200,300,400]
    for i in x:
        print i
    

This will output
    
    
    100
    200
    300
    400
    

  
The `for` loop loops over each of the elements of a list or iterator, assigning the current element to the variable name given. In the first example above, each of the elements in `l` is assigned to `i`.

A built-in function called range exists to make creating sequential lists such as the one above easier. The loop above is equivalent to:
    
    
    l = range(100, 401,100)
    for i in l:
        print i
    

The next example uses a negative _step_ (the third argument for the built-in range function):
    
    
    for i in range(10, 0, -1):
        print i
    

This will output
    
    
    10
    9
    8
    7
    6
    5
    4
    3
    2
    1
    

or
    
    
    for i in range(10, 0, -2):
        print i
    

This will output
    
    
    10
    8
    6
    4
    2
    

for loops can have names for each element of a tuple, if it loops over a sequence of tuples. For instance
    
    
    l = [(1, 1), (2, 4), (3, 9), (4, 16), (5, 25)]
    for x, xsquared in l:
        print x, ':', xsquared
    

will output
    
    
    1 : 1
    2 : 4
    3 : 9
    4 : 16
    5 : 25
    

#### While loops

A while loop repeats a sequence of statements until some condition becomes false. For example:
    
    
    x = 5
    while x > 0:
        print x
        x = x - 1
    

Will output:
    
    
    5
    4
    3
    2
    1
    

Python's while loops can also have an 'else' clause, which is a block of statements that is executed (once) when the while statement evaluates to false. The break statement inside the while loop will not direct the program flow to the else clause. For example:
    
    
    x = 5
    y = x
    while y > 0:
        print y
        y = y - 1
    else:
        print x
    

This will output:
    
    
    5
    4
    3
    2
    1
    5
    

Unlike some languages, there is no post-condition loop.

#### Breaking, continuing and the else clause of loops

Python includes statements to exit a loop (either a for loop or a while loop) prematurely. To exit a loop, use the break statement
    
    
    x = 5
    while x > 0:
        print x
        break
        x -= 1
        print x
    

this will output
    
    
    5
    

The statement to begin the next iteration of the loop without waiting for the end of the current loop is 'continue'.
    
    
    l = [5,6,7]
    for x in l:
        continue
        print x
    

This will not produce any output.

The else clause of loops will be executed if no break statements are met in the loop.
    
    
    l = range(1,100)
    for x in l:
        if x == 100:
            print x
            break
        else:
            print x," is not 100"
    else:
        print "100 not found in range"
    

  
Another example of a while loop using the break statement and the else statement:
    
    
    expected_str = "melon"
    received_str = "apple"
    basket = ["banana", "grapes", "strawberry", "melon", "orange"]
    x = 0
    step = int(raw_input("Input iteration step: "))
     
    while(received_str != expected_str):
        if(x >= len(basket)): print "No more fruits left on the basket."; break
        received_str = basket[x]
        x += step # Change this to 3 to make the while statement
                  # evaluate to false, avoiding the break statement, using the else clause.
        if(received_str==basket[2]): print "I hate",basket[2],"!"; break
        if(received_str != expected_str): print "I am waiting for my ",expected_str,"."
    else:
        print "Finally got what I wanted! my precious ",expected_str,"!"
    print "Going back home now !"
    

This will output:
    
    
    
    Input iteration step: 2
    I am waiting for my  melon .
    I hate strawberry !
    Going back home now !
    

### Branches

There is basically only one kind of branch in Python, the 'if' statement. The simplest form of the if statement simple executes a block of code only if a given predicate is true, and skips over it if the predicate is false

For instance,
    
    
    >>> x = 10
    >>> if x > 0:
    ...    print "Positive"
    ...
    Positive
    >>> if x < 0:
    ...    print "Negative"
    ...
    

You can also add "elif" (short for "else if") branches onto the if statement. If the predicate on the first “if” is false, it will test the predicate on the first elif, and run that branch if it’s true. If the first elif is false, it tries the second one, and so on. Note, however, that it will stop checking branches as soon as it finds a true predicate, and skip the rest of the if statement. You can also end your if statements with an "else" branch. If none of the other branches are executed, then python will run this branch.
    
    
    >>> x = -6
    >>> if x > 0:
    ...    print "Positive"
    ... elif x == 0:
    ...    print "Zero"
    ... else:
    ...    print "Negative"
    ...
    'Negative'
    

### Conclusion

Any of these loops, branches, and function calls can be nested in any way desired. A loop can loop over a loop, a branch can branch again, and a function can call other functions, or even call itself.

[Previous: Operators](/wiki/Python_Programming/Operators)
[Index](/wiki/Python_Programming)
[Next: Functions](/wiki/Python_Programming/Functions)

# Functions

[Previous: Flow control](/wiki/Python_Programming/Flow_control)
[Index](/wiki/Python_Programming)
[Next: Decorators](/wiki/Python_Programming/Decorators)

### Function calls

A _callable object_ is an object that can accept some arguments (also called parameters) and possibly return an object (often a tuple containing multiple objects).

A function is the simplest callable object in Python, but there are others, such as [classes](/wiki/Python_Programming/Classes) or certain class instances.

#### Defining functions

A function is defined in Python by the following format:
    
    
    def functionname(arg1, arg2, ...):
        statement1
        statement2
        ...
    
    
    
    >>> def functionname(arg1,arg2):
    ...     return arg1+arg2
    ...
    >>> t = functionname(24,24) # Result: 48
    

If a function takes no arguments, it must still include the parentheses, but without anything in them:
    
    
    def functionname():
        statement1
        statement2
        ...
    

The arguments in the function definition bind the arguments passed at function invocation (i.e. when the function is called), which are called actual parameters, to the names given when the function is defined, which are called formal parameters. The interior of the function has no knowledge of the names given to the actual parameters; the names of the actual parameters may not even be accessible (they could be inside another function).

A function can 'return' a value, for example:
    
    
    def square(x):
        return x*x
    

A function can define variables within the function body, which are considered 'local' to the function. The locals together with the arguments comprise all the variables within the scope of the function. Any names within the function are unbound when the function returns or reaches the end of the function body.

#### Declaring Arguments

##### Default Argument Values

If any of the formal parameters in the function definition are declared with the format "arg = value," then you will have the option of not specifying a value for those arguments when calling the function. If you do not specify a value, then that parameter will have the default value given when the function executes.
    
    
    >>> def display_message(message, truncate_after=4):
    ...     print message[:truncate_after]
    ...
    >>> display_message("message")
    mess
    >>> display_message("message", 6)
    messag
    

##### Variable-Length Argument Lists

Python allows you to declare two special arguments which allow you to create arbitrary-length argument lists. This means that each time you call the function, you can specify any number of arguments above a certain number.
    
    
    def function(first,second,*remaining):
        statement1
        statement2
        ...
    

When calling the above function, you must provide value for each of the first two arguments. However, since the third parameter is marked with an asterisk, any actual parameters after the first two will be packed into a tuple and bound to "remaining."
    
    
    >>> def print_tail(first,*tail):
    ...     print tail
    ...
    >>> print_tail(1, 5, 2, "omega")
    (5, 2, 'omega')
    

If we declare a formal parameter prefixed with _two_ asterisks, then it will be bound to a dictionary containing any keyword arguments in the actual parameters which do not correspond to any formal parameters. For example, consider the function:
    
    
    def make_dictionary(max_length=10, **entries):
        return dict([(key, entries[key]) for i, key in enumerate(entries.keys()) if i < max_length])
    

If we call this function with any keyword arguments other than max_length, they will be placed in the dictionary "entries." If we include the keyword argument of max_length, it will be bound to the formal parameter max_length, as usual.
    
    
    >>> make_dictionary(max_length=2, key1=5, key2=7, key3=9)
    {'key3': 9, 'key2': 7}
    

#### Calling functions

A function can be called by appending the arguments in parentheses to the function name, or an empty matched set of parentheses if the function takes no arguments.
    
    
    foo()
    square(3)
    bar(5, x)
    

A function's return value can be used by assigning it to a variable, like so:
    
    
    x = foo()
    y = bar(5,x)
    

As shown above, when calling a function you can specify the parameters by name and you can do so in any order
    
    
    def display_message(message, start=0, end=4):
       print message[start:end]
     
    display_message("message", end=3)
    

This above is valid and start will be the default value of 0. A restriction placed on this is after the first named argument then all arguments after it must also be named. The following is not valid
    
    
    display_message(end=5, start=1, "my message")
    

because the third argument ("my message") is an unnamed argument.

### Closure

A closure, also known as nested function definition, is a function defined inside another function. Perhaps best described with an example:
    
    
    >>> def outer(outer_argument):
    ...     def inner(inner_argument):
    ...         return outer_argument + inner_argument
    ...     return inner
    ...
    >>> f = outer(5)
    >>> f(3)
    8
    >>> f(4)
    9
    

Closures are possible in Python because functions are first-class objects. A function is merely an object of type function. Being an object means it is possible to pass a function object (an uncalled function) around as argument or as return value or to assign another name to the function object. A unique feature that makes closure useful is that the enclosed function may use the names defined in the parent function's scope.

#### lambda

lambda is an anonymous (unnamed) function. It is used primarily to write very short functions that are a hassle to define in the normal way. A function like this:
    
    
    >>> def add(a, b):
    ...    return a + b
    ...
    >>> add(4, 3)
    7
    

may also be defined using lambda
    
    
    >>> print (lambda a, b: a + b)(4, 3)
    7
    

Lambda is often used as an argument to other functions that expects a function object, such as sorted()'s 'key' argument.
    
    
    >>> sorted([[3, 4], [3, 5], [1, 2], [7, 3]], key=lambda x: x[1])
    [[1, 2], [7, 3], [3, 4], [3, 5]]
    

The lambda form is often useful as a closure, such as illustrated in the following example:
    
    
    >>> def attribution(name):
    ...    return lambda x: x + ' -- ' + name
    ...
    >>> pp = attribution('John')
    >>> pp('Dinner is in the fridge')
    'Dinner is in the fridge -- John'
    

note that the lambda function can use the values of variables from the [scope](/wiki/Python_Programming/Scoping) in which it was created (like pre and post). This is the essence of closure.

[Previous: Flow control](/wiki/Python_Programming/Flow_control)
[Index](/wiki/Python_Programming)
[Next: Decorators](/wiki/Python_Programming/Decorators)

# Scoping

[Previous: Decorators](/wiki/Python_Programming/Decorators)
[Index](/wiki/Python_Programming)
[Next: Exceptions](/wiki/Python_Programming/Exceptions)

### Variables

Variables in Python are automatically declared by assignment. Variables are always references to objects, and are never typed. Variables exist only in the current scope or global scope. When they go out of scope, the variables are destroyed, but the objects to which they refer are not (unless the number of references to the object drops to zero).

Scope is delineated by function and class blocks. Both functions and their scopes can be nested. So therefore
    
    
    def foo():
        def bar():
            x = 5 # x is now in scope
            return x + y # y is defined in the enclosing scope later
        y = 10
        return bar() # now that y is defined, bar's scope includes y
    

Now when this code is tested,
    
    
    >>> foo()
    15
    >>> bar()
    Traceback (most recent call last):
      File "<pyshell#26>", line 1, in -toplevel-
        bar()
    NameError: name 'bar' is not defined
    

The name 'bar' is not found because a higher scope does not have access to the names lower in the hierarchy.

It is a common pitfall to fail to lookup an attribute (such as a method) of an object (such as a container) referenced by a variable before the variable is assigned the object. In its most common form:
    
    
    >>> for x in range(10):
             y.append(x) # append is an attribute of lists
     
    Traceback (most recent call last):
      File "<pyshell#46>", line 2, in -toplevel-
        y.append(x)
    NameError: name 'y' is not defined
    

Here, to correct this problem, one must add y = [] before the for loop.

[Previous: Decorators](/wiki/Python_Programming/Decorators)
[Index](/wiki/Python_Programming)
[Next: Exceptions](/wiki/Python_Programming/Exceptions)

# Exceptions

[Previous: Scoping](/wiki/Python_Programming/Scoping)
[Index](/wiki/Python_Programming)
[Next: Input and output](/wiki/Python_Programming/Input_and_output)

Python handles all errors with exceptions.

An _exception_ is a signal that an error or other unusual condition has occurred. There are a number of built-in exceptions, which indicate conditions like reading past the end of a file, or dividing by zero. You can also define your own exceptions.

### Raising exceptions

Whenever your program attempts to do something erroneous or meaningless, Python raises exception to such conduct:
    
    
    >>> 1 / 0
    Traceback (most recent call last):
        File "<stdin>", line 1, in ?
    ZeroDivisionError: integer division or modulo by zero
    

This _traceback_ indicates that the `ZeroDivisionError` exception is being raised. This is a built-in exception -- see below for a list of all the other ones.

### Catching exceptions

In order to handle errors, you can set up _exception handling blocks_ in your code. The keywords `try` and `except` are used to catch exceptions. When an error occurs within the `try` block, Python looks for a matching `except` block to handle it. If there is one, execution jumps there.

If you execute this code:
    
    
    try:
        print 1/0
    except ZeroDivisionError:
        print "You can't divide by zero, you're silly."
    

Then Python will print this:

You can't divide by zero, you're silly.

If you don't specify an exception type on the `except` line, it will cheerfully catch all exceptions. This is generally a bad idea in production code, since it means your program will blissfully ignore _unexpected_ errors as well as ones which the `except` block is actually prepared to handle.

Exceptions can propagate up the call stack:
    
    
    def f(x):
        return g(x) + 1
     
    def g(x):
        if x < 0: raise ValueError, "I can't cope with a negative number here."
        else: return 5
     
    try:
        print f(-6)
    except ValueError:
        print "That value was invalid."
    

In this code, the `print` statement calls the function `f`. That function calls the function `g`, which will raise an exception of type ValueError. Neither `f` nor `g` has a `try`/`except` block to handle ValueError. So the exception raised propagates out to the main code, where there _is_ an exception-handling block waiting for it. This code prints:

That value was invalid.

Sometimes it is useful to find out exactly what went wrong, or to print the python error text yourself. For example:
    
    
    try:
        the_file = open("the_parrot")
    except IOError, (ErrorNumber, ErrorMessage):
        if ErrorNumber == 2: # file not found
            print "Sorry, 'the_parrot' has apparently joined the choir invisible."
        else:
            print "Congratulation! you have managed to trip a #%d error" % ErrorNumber
            print ErrorMessage
    

Which of course will print:

Sorry, 'the_parrot' has apparently joined the choir invisible.

#### Custom Exceptions

Code similar to that seen above can be used to create custom exceptions and pass information along with them. This can be extremely useful when trying to debug complicated projects. Here is how that code would look; first creating the custom exception class:
    
    
    class CustomException(Exception):
        def __init__(self, value):
            self.parameter = value
        def __str__(self):
            return repr(self.parameter)
    

And then using that exception:
    
    
    try:
        raise CustomException("My Useful Error Message")
    except CustomException, (instance):
        print "Caught: " + instance.parameter
    

#### Trying over and over again

### Recovering and continuing with `finally`

Exceptions could lead to a situation where, after raising an exception, the code block where the exception occurred might not be revisited. In some cases this might leave external resources used by the program in an unknown state.

`finally` clause allows programmers to close such resources in case of an exception. Between 2.4 and 2.5 version of python there is change of syntax for `finally` clause.

  * Python 2.4
    
    
    try:
        result = None
        try:
            result = x/y
        except ZeroDivisionError:
            print "division by zero!"
        print "result is ", result
    finally:
        print "executing finally clause"
    

  * Python 2.5
    
    
    try:
        result = x / y
    except ZeroDivisionError:
        print "division by zero!"
    else:
        print "result is", result
    finally:
        print "executing finally clause"
    

### Built-in exception classes

[All built-in Python exceptions](http://docs.python.org/library/exceptions.html)

### Exotic uses of exceptions

Exceptions are good for more than just error handling. If you have a complicated piece of code to choose which of several courses of action to take, it can be useful to use exceptions to jump out of the code as soon as the decision can be made. The Python-based mailing list software Mailman does this in deciding how a message should be handled. Using exceptions like this may seem like it's a sort of GOTO -- and indeed it is, but a limited one called an _escape continuation_. Continuations are a powerful functional-programming tool and it can be useful to learn them.

Just as a simple example of how exceptions make programming easier, say you want to add items to a list but you don't want to use "if" statements to initialize the list we could replace this:
    
    
    if hasattr(self, 'items'):
        self.items.extend(new_items)
    else:
        self.items = list(new_items)
    

Using exceptions, we can emphasize the normal program flow—that usually we just extend the list—rather than emphasizing the unusual case:
    
    
    try:
        self.items.extend(new_items)
    except AttributeError:
        self.items = list(new_items)
    

[Previous: Scoping](/wiki/Python_Programming/Scoping)
[Index](/wiki/Python_Programming)
[Next: Input and output](/wiki/Python_Programming/Input_and_output)

# Input and output

[Previous: Exceptions](/wiki/Python_Programming/Exceptions)
[Index](/wiki/Python_Programming)
[Next: Modules](/wiki/Python_Programming/Modules)

## Input

_Note on Python version: The following uses the syntax of Python 2.x. Some of the following is not going to work with Python 3.x._

Python has two functions designed for accepting data directly from the user:

  * `input()`
  * `raw_input()`

There are also very simple ways of reading a file and, for stricter control over input, reading from stdin if necessary.

### raw_input()

raw_input() asks the user for a string of data (ended with a newline), and simply returns the string. It can also take an argument, which is displayed as a prompt before the user enters the data. E.g.
    
    
    print raw_input('What is your name? ')
    

prints out
    
    
    What is your name? <user input data here>
    

Example: in order to assign the user's name, i.e. string data, to a variable "x" you would type
    
    
    x = raw_input('What is your name?')
    

Once the user inputs his name, e.g. Simon, you can call it as x
    
    
    print 'Your name is ' + x
    

prints out
    
    
    Your name is Simon
    

**Note:**  
in 3.x "...raw_input() was renamed to input(). That is, the new input() function reads a line from sys.stdin and returns it with the trailing newline stripped. It raises EOFError if the input is terminated prematurely. To get the old behavior of input(), use eval(input())."

### input()

input() uses raw_input to read a string of data, and then attempts to evaluate it as if it were a Python program, and then returns the value that results. So entering
    
    
    [1,2,3]
    

would return a list containing those numbers, just as if it were assigned directly in the Python script.

More complicated expressions are possible. For example, if a script says:
    
    
    x = input('What are the first 10 perfect squares? ')
    

it is possible for a user to input:
    
    
    map(lambda x: x*x, range(10))
    

which yields the correct answer in list form. Note that no inputted statement can span more than one line.

input() should not be used for anything but the most trivial program. Turning the strings returned from raw_input() into python types using an idiom such as:
    
    
    x = None
    while not x:
        try:
            x = int(raw_input())
        except ValueError:
            print 'Invalid Number'
    

is preferable, as input() uses eval() to turn a literal into a python type. This will allow a malicious person to run arbitrary code from inside your program trivially.

### File Input

#### File Objects

Python includes a built-in file type. Files can be opened by using the file type's constructor:
    
    
    f = file('test.txt', 'r')
    

This means f is open for reading. The first argument is the filename and the second parameter is the mode, which can be 'r', 'w', or 'rw', among some others.

The most common way to read from a file is simply to iterate over the lines of the file:
    
    
    f = open('test.txt', 'r')
    for line in f:
        print line[0]
    f.close()
    

This will print the first character of each line. Note that a newline is attached to the end of each line read this way.

Because files are automatically closed when the file object goes out of scope, there is no real need to close them explicitly. So, the loop in the previous code can also be written as:
    
    
    for line in open('test.txt', 'r'):
        print line[0]
    

You can read limited numbers of characters at a time like this:
    
    
    c = f.read(1)
    while len(c) > 0:
        if len(c.strip()) > 0: print c,
        c = f.read(1)
    

This will read the characters from f one at a time, and then print them if they're not whitespace.

A file object implicitly contains a marker to represent the current position. If the file marker should be moved back to the beginning, one can either close the file object and reopen it or just move the marker back to the beginning with:
    
    
    f.seek(0)
    

#### Standard File Objects

Like many other languages, there are built-in file objects representing standard input, output, and error. These are in the sys module and are called stdin, stdout, and stderr. There are also immutable copies of these in __stdin__, __stdout__, and __stderr__. This is for IDLE and other tools in which the standard files have been changed.

You must import the sys module to use the special stdin, stdout, stderr I/O handles.
    
    
    import sys
    

For finer control over input, use sys.stdin.read(). In order to implement the UNIX 'cat' program in Python, you could do something like this:
    
    
    import sys
    for line in sys.stdin:
        print line,
    

Note that sys.stdin.read() will read from standard input till EOF. (which is usually Ctrl+D.)

Also important is the sys.argv array. sys.argv is an array that contains the command-line arguments passed to the program.
    
    
    python program.py hello there programmer!
    

This array can be indexed,and the arguments evaluated. In the above example, sys.argv[2] would contain the string "there", because the name of the program ("program.py") is stored in argv[0]. For more complicated command-line argument processing, see the "argparse" module.

## Output

_Note on Python version: The following uses the syntax of Python 2.x. Much of the following is not going to work with Python 3.x. In particular, Python 3.x requires brackets around arguments to "print"._

The basic way to do output is the print statement.
    
    
    print 'Hello, world'
    

To print multiple things on the same line separated by spaces, use commas between them, like this:
    
    
    print 'Hello,', 'World'
    

This will print out the following:
    
    
    Hello, World
    

While neither string contained a space, a space was added by the print statement because of the comma between the two objects. Arbitrary data types can be printed this way:
    
    
    print 1,2,0xff,0777,(10+5j),-0.999,map,sys
    

This will output the following:
    
    
    1 2 255 511 (10+5j) -0.999 <built-in function map> <module 'sys' (built-in)>
    

Objects can be printed on the same line without needing to be on the same line if one puts a comma at the end of a print statement:
    
    
    for i in range(10):
        print i,
    

This will output the following:
    
    
    0 1 2 3 4 5 6 7 8 9
    

To end the printed line with a newline, add a print statement without any objects.
    
    
    for i in range(10):
        print i,
    print
    for i in range(10,20):
        print i,
    

This will output the following:
    
    
    0 1 2 3 4 5 6 7 8 9
    10 11 12 13 14 15 16 17 18 19
    

If the bare print statement were not present, the above output would look like:
    
    
    0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19
    

You can use similar syntax when writing to a file instead of to standard output, like this:
    
    
    print >> f, 'Hello, world'
    

This will print to any object that implements write(), which includes file objects.

### Omitting newlines

To avoid adding spaces and newlines between objects output with subsequent print statements, you can do one of the following:

_Concatenation_: Concatenate the string representations of each object, then later print the whole thing at once.
    
    
    print str(1)+str(2)+str(0xff)+str(0777)+str(10+5j)+str(-0.999)+str(map)+str(sys)
    

This will output the following:
    
    
    12255511(10+5j)-0.999<built-in function map><module 'sys' (built-in)>
    

_Write function_: You can make a shorthand for _sys.stdout.write_ and use that for output.
    
    
    import sys
    write = sys.stdout.write
    write('20')
    write('05\n')
    

This will output the following:
    
    
    2005
    

You may need sys.stdout.flush() to get that text on the screen quickly.

### Examples

Examples of output with _Python 2.x_:

  * print "Hello"
  * print "Hello", "world" 
    * Separates the two words with a space.
  * print "Hello", 34 
    * Prints elements of various data types, separating them by a space.
  * print "Hello " + 34 
    * Throws an error as a result of trying to concatenate a string and an integer.
  * print "Hello " + str(34) 
    * Uses "+" to concatenate strings, after converting a number to a string.
  * print "Hello", 
    * Prints "Hello " without a newline, with a space at the end.
  * sys.stdout.write("Hello") 
    * Prints "Hello" without a newline. Doing "import sys" is a prerequisite. Needs a subsequent "sys.stdout.flush()" in order to display immediately on the user's screen.
  * sys.stdout.write("Hello\n") 
    * Prints "Hello" with a newline.
  * print >> sys.stderr, "An error occurred." 
    * Prints to standard error stream.
  * sys.stderr.write("Hello\n") 
    * Prints to standard error stream.
  * sum=2+2; print "The sum: %i" % sum 
    * Prints a string that has been formatted with the use of an integer passes as an argument.
  * formatted_string = "The sum: %i" % (2+2); print formatted_string 
    * Like the previous, just that the formatting happens outside of the print statement.
  * print "Float: %6.3f" % 1.23456 
    * Outputs "Float: 1.234". The number 3 after the period specifies the number of decimal digits after the period to be displayed, while 6 before the period specifies the total number of characters the displayed number should take, to be padded with spaces if needed.
  * print "%s is %i years old" % ("John", 23) 
    * Passes two arguments to the formatter.

Examples of output with _Python 3.x_:

  * from __future__ import print_function 
    * Ensures Python 2.6 and later Python 2.x can use Python 3.x print function.
  * print ("Hello", "world") 
    * Prints the two words separated with a space. Notice the surrounding brackets, ununsed in Python 2.x.
  * print ("Hello world", end="") 
    * Prints without the ending newline.
  * print ("Hello", "world", sep="-") 
    * Prints the two words separated with a a dash.

### File Output

Printing numbers from 1 to 10 to a file, one per line:
    
    
    file1 = open("TestFile.txt","w")
    for i in range(1,10+1):
      print >>file1, i
    file1.close()
    

With "w", the file is opened for writing. With ">>file", print sends its output to a file rather than standard output.

Printing numbers from 1 to 10 to a file, separated with a dash:
    
    
    with open("TestFile.txt","w") as file1:
      for i in range(1,10+1):
        if i>1:
          file1.write("-")
        file1.write(str(i))
    

Opening a file for appending rather than overwriting:
    
    
    file1 = open("TestFile.txt","a")
    

See also [Files](/wiki/Python_Programming/Files) chapter.

## External Links

  * [7\. Input and Output](http://www.python.org/doc/current/tutorial/inputoutput.html) in The Python Tutorial, python.org
  * [6.6. The print statement](http://docs.python.org/2/reference/simple_stmts.html#print) in The Python Language Reference, python.org
  * [2\. Built-in Functions #open](http://docs.python.org/2/library/functions.html#open) in The Python Standard Library at Python Documentation, python.org
  * [5\. Built-in Types #file.write](http://docs.python.org/2/library/stdtypes.html?highlight=write#file.write) in The Python Standard Library at Python Documentation, python.org
  * [27.1. sys — System-specific parameters and functions](http://docs.python.org/2/library/sys.html) in Python Documentation, python org -- mentions sys.stdout, and sys.stderr
  * [2.3.8 File Objects](http://docs.python.org/release/2.3.5/lib/bltin-file-objects.html) in Python Library Reference, python.org, for "flush"
  * [5.6.2. String Formatting Operations](http://docs.python.org/2/library/stdtypes.html#string-formatting-operations) in The Python Standard Library at Python Documentation, python.org -- for "%i", "%s" and similar string formatting
  * [7.2.2. The string format operator](http://infohost.nmt.edu/tcc/help/pubs/python25/web/str-format.html), in Python 2.5 quick reference, nmt.edu, for "%i", "%s" and similar string formatting

[Previous: Exceptions](/wiki/Python_Programming/Exceptions)
[Index](/wiki/Python_Programming)
[Next: Modules](/wiki/Python_Programming/Modules)

# Modules

[Previous: Input and output](/wiki/Python_Programming/Input_and_output)
[Index](/wiki/Python_Programming)
[Next: Classes](/wiki/Python_Programming/Classes)

Modules are a simple way to structure a program. Mostly, there are modules in the standard library and there are other Python files, or directories containing Python files, in the current directory (each of which constitute a module). You can also instruct Python to search other directories for modules by placing their paths in the PYTHONPATH environment variable.

## Importing a Module

Modules in Python are used by importing them. For example,
    
    
    import math
    

This imports the math standard module. All of the functions in that module are namespaced by the module name, i.e.
    
    
    import math
    print math.sqrt(10)
    

This is often a nuisance, so other syntaxes are available to simplify this,
    
    
    from string import whitespace
    from math import *
    from math import sin as SIN
    from math import cos as COS
    from ftplib import FTP as ftp_connection
    print sqrt(10)
    

The first statement means whitespace is added to the current scope (but nothing else is). The second statement means that all the elements in the math namespace is added to the current scope.

Modules can be three different kinds of things:

  * Python files
  * Shared Objects (under Unix and Linux) with the .so suffix
  * DLL's (under Windows) with the .pyd suffix
  * directories

Modules are loaded in the order they're found, which is controlled by sys.path. The current directory is always on the path.

Directories should include a file in them called __init__.py, which should probably include the other files in the directory.

Creating a DLL that interfaces with Python is covered in another section.

## Creating a Module

### From a File

The easiest way to create a module by having a file called mymod.py either in a directory recognized by the PYTHONPATH variable or (even easier) in the same directory where you are working. If you have the following file mymod.py
    
    
    class Object1:
            def __init__(self):
                    self.name = 'object 1'
    

you can already import this "module" and create instances of the object _Object1_.
    
    
    import mymod
    myobject = mymod.Object1()
    from mymod import *
    myobject = Object1()
    

### From a Directory

It is not feasible for larger projects to keep all classes in a single folder. It is often easier to store all files in directories and load all files with one command. Each directory needs to have a `__init__.py` file which contains python commands that are executed upon loading the directory.

Suppose we have two more objects called `Object2` and `Object3` and we want to load all three objects with one command. We then create a directory called _mymod_ and we store three files called `Object1.py`, `Object2.py` and `Object3.py` in it. These files would then contain one object per file but this not required (although it adds clarity). We would then write the following `__init__.py` file:
    
    
    from Object1 import *
    from Object2 import *
    from Object3 import *
     
    __all__ = ["Object1", "Object2", "Object3"]
    

The first three commands tell python what to do when somebody loads the module. The last statement defining __all__ tells python what to do when somebody executes _from mymod import *_. Usually we want to use parts of a module in other parts of a module, e.g. we want to use Object1 in Object2. We can do this easily with an _from . import *_ command as the following file _Object2.py_ shows:
    
    
    from . import *
     
    class Object2:
            def __init__(self):
                    self.name = 'object 2'
                    self.otherObject = Object1()
    

We can now start python and import _mymod_ as we have in the previous section.

## External links

  * [Python Documentation](http://docs.python.org/tutorial/modules.html)

[Previous: Input and output](/wiki/Python_Programming/Input_and_output)
[Index](/wiki/Python_Programming)
[Next: Classes](/wiki/Python_Programming/Classes)

# Classes

[Previous: Modules](/wiki/Python_Programming/Modules)
[Index](/wiki/Python_Programming)
[Next: MetaClasses](/wiki/Python_Programming/MetaClasses)

Classes are a way of aggregating similar data and functions. A class is basically a scope inside which various code (especially function definitions) is executed, and the locals to this scope become _attributes_ of the class, and of any objects constructed by this class. An object constructed by a class is called an _instance_ of that class.

### Defining a Class

To define a class, use the following format:
    
    
    class ClassName:
        "Here is an explanation about your class"
        pass
    

The capitalization in this class definition is the convention, but is not required by the language. It's usually good to add at least a short explanation of what your class is supposed to do. The pass statement in the code above is just to say to the python interpreter just go on and do nothing. You can remove it as soon as you are adding your first statement.

### Instance Construction

The class is a callable object that constructs an instance of the class when called. Let's say we create a class Foo.
    
    
    class Foo:
        "Foo is our new toy."
        pass
    

To construct an instance of the class, Foo, "call" the class object:
    
    
    f = Foo()
    

This constructs an instance of class Foo and creates a reference to it in f.

### Class Members

In order to access the member of an instance of a class, use the syntax <class instance>.<member>. It is also possible to access the members of the class definition with <class name>.<member>.

#### Methods

A method is a function within a class. The first argument (methods must always take at least one argument) is always the instance of the class on which the function is invoked. For example
    
    
    >>> class Foo:
    ...     def setx(self, x):
    ...         self.x = x
    ...     def bar(self):
    ...         print self.x
    

If this code were executed, nothing would happen, at least until an instance of Foo were constructed, and then bar were called on that instance.

#### Invoking Methods

Calling a method is much like calling a function, but instead of passing the instance as the first parameter like the list of formal parameters suggests, use the function as an attribute of the instance.
    
    
    >>> f = Foo()
    >>> f.setx(5)
    >>> f.bar()
    

This will output
    
    
    5
    

It is possible to call the method on an arbitrary object, by using it as an attribute of the defining class instead of an instance of that class, like so:
    
    
    >>> Foo.setx(f,5)
    >>> Foo.bar(f)
    

This will have the same output.

#### Dynamic Class Structure

As shown by the method setx above, the members of a Python class can change during runtime, not just their values, unlike classes in languages like C or Java. We can even delete f.x after running the code above.
    
    
    >>> del f.x
    >>> f.bar()
    
    
    
    Traceback (most recent call last):
      File "<stdin>", line 1, in ?
      File "<stdin>", line 5, in bar
    AttributeError: Foo instance has no attribute 'x'
    

Another effect of this is that we can change the definition of the Foo class during program execution. In the code below, we create a member of the Foo class definition named y. If we then create a new instance of Foo, it will now have this new member.
    
    
    >>> Foo.y = 10
    >>> g = Foo()
    >>> g.y
    10
    

##### Viewing Class Dictionaries

At the heart of all this is a [dictionary](/wiki/Python_Programming/Dictionaries) that can be accessed by "vars(ClassName)"
    
    
    >>> vars(g)
    {}
    

At first, this output makes no sense. We just saw that g had the member y, so why isn't it in the member dictionary? If you remember, though, we put y in the class definition, Foo, not g.
    
    
    >>> vars(Foo)
    {'y': 10, 'bar': <function bar at 0x4d6a3c>, '__module__': '__main__',
     'setx': <function setx at 0x4d6a04>, '__doc__': None}
    

And there we have all the members of the Foo class definition. When Python checks for g.member, it first checks g's vars dictionary for "member," then Foo. If we create a new member of g, it will be added to g's dictionary, but not Foo's.
    
    
    >>> g.setx(5)
    >>> vars(g)
    {'x': 5}
    

Note that if we now assign a value to g.y, we are not assigning that value to Foo.y. Foo.y will still be 10, but g.y will now override Foo.y
    
    
    >>> g.y = 9
    >>> vars(g)
    {'y': 9, 'x': 5}
    >>> vars(Foo)
    {'y': 10, 'bar': <function bar at 0x4d6a3c>, '__module__': '__main__',
     'setx': <function setx at 0x4d6a04>, '__doc__': None}
    

Sure enough, if we check the values:
    
    
    >>> g.y
    9
    >>> Foo.y
    10
    

Note that f.y will also be 10, as Python won't find 'y' in vars(f), so it will get the value of 'y' from vars(Foo).

Some may have also noticed that the methods in Foo appear in the class dictionary along with the x and y. If you remember from the section on [lambda forms](/wiki/Python_Programming/Functions#lambda), we can treat functions just like variables. This means that we can assign methods to a class during runtime in the same way we assigned variables. If you do this, though, remember that if we call a method of a class instance, the first parameter passed to the method will always be the class instance itself.

##### Changing Class Dictionaries

We can also access the members dictionary of a class using the __dict__ member of the class.
    
    
    >>> g.__dict__
    {'y': 9, 'x': 5}
    

If we add, remove, or change key-value pairs from g.__dict__, this has the same effect as if we had made those changes to the members of g.
    
    
    >>> g.__dict__['z'] = -4
    >>> g.z
    -4
    

### New Style Classes

New style classes were introduced in python 2.2. A new-style class is a class that has a built-in as its base, most commonly object. At a low level, a major difference between old and new classes is their type. Old class instances were all of type `instance`. New style class instances will return the same thing as x.__class__ for their type. This puts user defined classes on a level playing field with built-ins. Old/Classic classes are slated to disappear in Python 3. With this in mind all development should use new style classes. New Style classes also add constructs like properties and static methods familiar to Java programmers.

Old/Classic Class
    
    
    >>> class ClassicFoo:
    ...     def __init__(self):
    ...         pass
    

New Style Class
    
    
    >>> class NewStyleFoo(object):
    ...     def __init__(self):
    ...         pass
    

#### Properties

Properties are attributes with getter and setter methods.
    
    
    >>> class SpamWithProperties(object):
    ...     def __init__(self):
    ...         self.__egg = "MyEgg"
    ...     def get_egg(self):
    ...         return self.__egg
    ...     def set_egg(self, egg):
    ...         self.__egg = egg
    ...     egg = property(get_egg, set_egg)
     
    >>> sp = SpamWithProperties()
    >>> sp.egg
    'MyEgg'
    >>> sp.egg = "Eggs With Spam"
    >>> sp.egg
    'Eggs With Spam'
    >>>
    

and since Python 2.6, with @property decorator
    
    
    >>> class SpamWithProperties(object):
    ...     def __init__(self):
    ...         self.__egg = "MyEgg"
    ...     @property
    ...     def egg(self):
    ...         return self.__egg
    ...     @egg.setter
    ...     def egg(self, egg):
    ...         self.__egg = egg
    

#### Static Methods

Static methods in Python are just like their counterparts in C++ or Java. Static methods have no "self" argument and don't require you to instantiate the class before using them. They can be defined using staticmethod()
    
    
    >>> class StaticSpam(object):
    ...     def StaticNoSpam():
    ...         print "You can't have have the spam, spam, eggs and spam without any spam... that's disgusting"
    ...     NoSpam = staticmethod(StaticNoSpam)
     
    >>> StaticSpam.NoSpam()
    'You can\'t have have the spam, spam, eggs and spam without any spam... that\'s disgusting'
    

They can also be defined using the function decorator @staticmethod.
    
    
    >>> class StaticSpam(object):
    ...     @staticmethod
    ...     def StaticNoSpam():
    ...         print "You can't have have the spam, spam, eggs and spam without any spam... that's disgusting"
    

### Inheritance

Like all object oriented languages, Python provides for inheritance. Inheritance is a simple concept by which a class can extend the facilities of another class, or in Python's case, multiple other classes. Use the following format for this:
    
    
    class ClassName(superclass1,superclass2,superclass3,...):
        ...
    

The subclass will then have all the members of its superclasses. If a method is defined in the subclass and in the superclass, the member in the subclass will override the one in the superclass. In order to use the method defined in the superclass, it is necessary to call the method as an attribute on the defining class, as in Foo.setx(f,5) above:
    
    
    >>> class Foo:
    ...     def bar(self):
    ...         print "I'm doing Foo.bar()"
    ...     x = 10
    ...
    >>> class Bar(Foo):
    ...     def bar(self):
    ...         print "I'm doing Bar.bar()"
    ...         Foo.bar(self)
    ...     y = 9
    ...
    >>> g = Bar()
    >>> Bar.bar(g)
    I'm doing Bar.bar()
    I'm doing Foo.bar()
    >>> g.y
    9
    >>> g.x
    10
    

Once again, we can see what's going on under the hood by looking at the class dictionaries.
    
    
    >>> vars(g)
    {}
    >>> vars(Bar)
    {'y': 9, '__module__': '__main__', 'bar': <function bar at 0x4d6a04>,
     '__doc__': None}
    >>> vars(Foo)
    {'x': 10, '__module__': '__main__', 'bar': <function bar at 0x4d6994>,
     '__doc__': None}
    

When we call g.x, it first looks in the vars(g) dictionary, as usual. Also as above, it checks vars(Bar) next, since g is an instance of Bar. However, thanks to inheritance, Python will check vars(Foo) if it doesn't find x in vars(Bar).

### Special Methods

There are a number of methods which have reserved names which are used for special purposes like mimicking numerical or container operations, among other things. All of these names begin and end with two underscores. It is convention that methods beginning with a single underscore are 'private' to the scope they are introduced within.

#### Initialization and Deletion

##### __init__

One of these purposes is constructing an instance, and the special name for this is '__init__'. __init__() is called before an instance is returned (it is not necessary to return the instance manually). As an example,
    
    
    class A:
        def __init__(self):
            print 'A.__init__()'
    a = A()
    

outputs
    
    
    A.__init__()
    

__init__() can take arguments, in which case it is necessary to pass arguments to the class in order to create an instance. For example,
    
    
    class Foo:
        def __init__ (self, printme):
            print printme
    foo = Foo('Hi!')
    

outputs
    
    
    Hi!
    

Here is an example showing the difference between using __init__() and not using __init__():
    
    
    class Foo:
        def __init__ (self, x):
             print x
    foo = Foo('Hi!')
    class Foo2:
        def setx(self, x):
            print x
    f = Foo2()
    Foo2.setx(f,'Hi!')
    

outputs
    
    
    Hi!
    Hi!
    

##### __del__

Similarly, '__del__' is called when an instance is destroyed; e.g. when it is no longer referenced.

#### Representation

##### __str__

Converting an object to a string, as with the print statement or with the str() conversion function, can be overridden by overriding __str__. Usually, __str__ returns a formatted version of the objects content. This will NOT usually be something that can be executed.

For example:
    
    
    class Bar:
        def __init__ (self, iamthis):
            self.iamthis = iamthis
        def __str__ (self):
            return self.iamthis
    bar = Bar('apple')
    print bar
    

outputs
    
    
    apple
    

##### __repr__

This function is much like __str__(). If __str__ is not present but this one is, this function's output is used instead for printing. __repr__ is used to return a representation of the object in string form. In general, it can be executed to get back the original object.

For example:
    
    
    class Bar:
        def __init__ (self, iamthis):
            self.iamthis = iamthis
        def __repr__(self):
            return "Bar('%s')" % self.iamthis
    bar = Bar('apple')
    bar
    

outputs (note the difference: now is not necessary to put it inside a print)
    
    
    Bar('apple')
    

String Representation Override Functions

Function Operator

__str__
str(A)

__repr__
repr(A)

__unicode__
unicode(x) (2.x only)

#### Attributes

##### __setattr__

This is the function which is in charge of setting attributes of a class. It is provided with the name and value of the variables being assigned. Each class, of course, comes with a default __setattr__ which simply sets the value of the variable, but we can override it.
    
    
    >>> class Unchangable:
    ...    def __setattr__(self, name, value):
    ...        print "Nice try"
    ...
    >>> u = Unchangable()
    >>> u.x = 9
    Nice try
    >>> u.x
    
    
    
    Traceback (most recent call last):
      File "<stdin>", line 1, in ?
    AttributeError: Unchangable instance has no attribute 'x'
    

##### __getattr___

Similar to __setattr__, except this function is called when we try to access a class member, and the default simply returns the value.
    
    
    >>> class HiddenMembers:
    ...     def __getattr__(self, name):
    ...         return "You don't get to see " + name
    ...
    >>> h = HiddenMembers()
    >>> h.anything
    "You don't get to see anything"
    

##### __delattr__

This function is called to delete an attribute.
    
    
    >>> class Permanent:
    ...     def __delattr__(self, name):
    ...         print name, "cannot be deleted"
    ...
    >>> p = Permanent()
    >>> p.x = 9
    >>> del p.x
    x cannot be deleted
    >>> p.x
    9
    

Attribute Override Functions

Function Indirect form Direct Form

__getattr__
getattr(A, B)
A.B

__setattr__
setattr(A, B, C)
A.B = C

__delattr__
delattr(A, B)
del A.B

#### Operator Overloading

Operator overloading allows us to use the built-in Python syntax and operators to call functions which we define.

##### Binary Operators

If a class has the __add__ function, we can use the '+' operator to add instances of the class. This will call __add__ with the two instances of the class passed as parameters, and the return value will be the result of the addition.
    
    
    >>> class FakeNumber:
    ...     n = 5
    ...     def __add__(A,B):
    ...         return A.n + B.n
    ...
    >>> c = FakeNumber()
    >>> d = FakeNumber()
    >>> d.n = 7
    >>> c + d
    12
    

To override the [augmented assignment](/wiki/Python_Programming/Operators#Augmented_Assignment) operators, merely add 'i' in front of the normal binary operator, i.e. for '+=' use '__iadd__' instead of '__add__'. The function will be given one argument, which will be the object on the right side of the augmented assignment operator. The returned value of the function will then be assigned to the object on the left of the operator.
    
    
    >>> c.__imul__ = lambda B: B.n - 6
    >>> c *= d
    >>> c
    1
    

It is important to note that the [augmented assignment](/wiki/Python_Programming/Operators#Augmented_Assignment) operators will also use the normal operator functions if the augmented operator function hasn't been set directly. This will work as expected, with "__add__" being called for "+=" and so on.
    
    
    >>> c = FakeNumber()
    >>> c += d
    >>> c
    12
    

Binary Operator Override Functions

Function Operator

__add__
A + B

__sub__
A - B

__mul__
A * B

__truediv__
A / B

__floordiv__
A // B

__mod__
A % B

__pow__
A ** B

__and__
A & B

__or__
A | B

__xor__
A ^ B

__eq__
A == B

__ne__
A != B

__gt__
A > B

__lt__
A < B

__ge__
A >= B

__le__
A <= B

__lshift__
A << B

__rshift__
A >> B

__contains__
A in B  
A not in B

##### Unary Operators

Unary operators will be passed simply the instance of the class that they are called on.
    
    
    >>> FakeNumber.__neg__ = lambda A : A.n + 6
    >>> -d
    13
    

Unary Operator Override Functions

Function Operator

__pos__
+A

__neg__
-A

__inv__
~A

__abs__
abs(A)

__len__
len(A)

##### Item Operators

It is also possible in Python to override the [indexing and slicing](/wiki/Python_Programming/Strings#Indexing_and_Slicing) operators. This allows us to use the class[i] and class[a:b] syntax on our own objects.

The simplest form of item operator is __getitem__. This takes as a parameter the instance of the class, then the value of the index.
    
    
    >>> class FakeList:
    ...     def __getitem__(self,index):
    ...         return index * 2
    ...
    >>> f = FakeList()
    >>> f['a']
    'aa'
    

We can also define a function for the syntax associated with assigning a value to an item. The parameters for this function include the value being assigned, in addition to the parameters from __getitem__
    
    
    >>> class FakeList:
    ...     def __setitem__(self,index,value):
    ...         self.string = index + " is now " + value
    ...
    >>> f = FakeList()
    >>> f['a'] = 'gone'
    >>> f.string
    'a is now gone'
    

We can do the same thing with slices. Once again, each syntax has a different parameter list associated with it.
    
    
    >>> class FakeList:
    ...     def __getslice___(self,start,end):
    ...         return str(start) + " to " + str(end)
    ...
    >>> f = FakeList()
    >>> f[1:4]
    '1 to 4'
    

Keep in mind that one or both of the start and end parameters can be blank in slice syntax. Here, Python has default value for both the start and the end, as show below.
    
    
    >> f[:]
    '0 to 2147483647'
    

Note that the default value for the end of the slice shown here is simply the largest possible signed integer on a 32-bit system, and may vary depending on your system and C compiler.

  * __setslice__ has the parameters (self,start,end,value)

We also have operators for deleting items and slices.

  * __delitem__ has the parameters (self,index)
  * __delslice__ has the parameters (self,start,end)

Note that these are the same as __getitem__ and __getslice__.

Item Operator Override Functions

Function Operator

__getitem__
C[i]

__setitem__
C[i] = v

__delitem__
del C[i]

__getslice__
C[s:e]

__setslice__
C[s:e] = v

__delslice__
del C[s:e]

#### Other Overrides

Other Override Functions

Function Operator

__cmp__
cmp(x, y)

__hash__
hash(x)

__nonzero__
bool(x)

__call__
f(x)

__iter__
iter(x)

__reversed__
reversed(x) (2.6+)

__divmod__
divmod(x, y)

__int__
int(x)

__long__
long(x)

__float__
float(x)

__complex__
complex(x)

__hex__
hex(x)

__oct__
oct(x)

__index__

__copy__
copy.copy(x)

__deepcopy__
copy.deepcopy(x)

__sizeof__
sys.getsizeof(x) (2.6+)

__trunc__
math.trunc(x) (2.6+)

__format__
format(x, ...) (2.6+)

### Programming Practices

The flexibility of python classes means that classes can adopt a varied set of behaviors. For the sake of understandability, however, it's best to use many of Python's tools sparingly. Try to declare all methods in the class definition, and always use the <class>.<member> syntax instead of __dict__ whenever possible. Look at classes in [C++](/wiki/C%2B%2B_Programming/Classes) and [Java](//en.wikipedia.org/wiki/Class_\(computer_science\)#Java) to see what most programmers will expect from a class.

#### Encapsulation

Since all python members of a python class are accessible by functions/methods outside the class, there is no way to enforce [encapsulation](//en.wikipedia.org/wiki/Information_Hiding) short of overriding __getattr__, __setattr__ and __delattr__. General practice, however, is for the creator of a class or module to simply trust that users will use only the intended interface and avoid limiting access to the workings of the module for the sake of users who do need to access it. When using parts of a class or module other than the intended interface, keep in mind that the those parts may change in later versions of the module, and you may even cause errors or undefined behaviors in the module.since encapulation is private.

#### Doc Strings

When defining a class, it is convention to document the class using a string literal at the start of the class definition. This string will then be placed in the __doc__ attribute of the class definition.
    
    
    >>> class Documented:
    ...     """This is a docstring"""
    ...     def explode(self):
    ...         """
    ...         This method is documented, too! The coder is really serious about
    ...         making this class usable by others who don't know the code as well
    ...         as he does.
    ...
    ...         """
    ...         print "boom"
    >>> d = Documented()
    >>> d.__doc__
    'This is a docstring'
    

Docstrings are a very useful way to document your code. Even if you never write a single piece of separate documentation (and let's admit it, doing so is the lowest priority for many coders), including informative docstrings in your classes will go a long way toward making them usable.

Several tools exist for turning the docstrings in Python code into readable API documentation, _e.g._, [EpyDoc](http://epydoc.sourceforge.net/using.html).

Don't just stop at documenting the class definition, either. Each method in the class should have its own docstring as well. Note that the docstring for the method _explode_ in the example class _Documented_ above has a fairly lengthy docstring that spans several lines. Its formatting is in accordance with the style suggestions of Python's creator, Guido van Rossum in [PEP 8](http://www.python.org/dev/peps/pep-0008/).

#### Adding methods at runtime

##### To a class

It is fairly easy to add methods to a class at runtime. Lets assume that we have a class called _Spam_ and a function cook. We want to be able to use the function cook on all instances of the class Spam:
    
    
    class Spam:
      def __init__(self):
        self.myeggs = 5
     
    def cook(self):
      print "cooking %s eggs" % self.myeggs
     
    Spam.cook = cook   #add the function to the class Spam
    eggs = Spam()      #NOW create a new instance of Spam
    eggs.cook()        #and we are ready to cook!
    

This will output
    
    
    cooking 5 eggs
    

##### To an instance of a class

It is a bit more tricky to add methods to an instance of a class that has already been created. Lets assume again that we have a class called _Spam_ and we have already created eggs. But then we notice that we wanted to cook those eggs, but we do not want to create a new instance but rather use the already created one:
    
    
    class Spam:
      def __init__(self):
        self.myeggs = 5
     
    eggs = Spam()
     
    def cook(self):
      print "cooking %s eggs" % self.myeggs
     
    import types
    f = types.MethodType(cook, eggs, Spam)
    eggs.cook = f
     
    eggs.cook()
    

Now we can cook our eggs and the last statement will output:
    
    
    cooking 5 eggs
    

##### Using a function

We can also write a function that will make the process of adding methods to an instance of a class easier.
    
    
    def attach_method(fxn, instance, myclass):
      f = types.MethodType(fxn, instance, myclass)
      setattr(instance, fxn.__name__, f)
    

All we now need to do is call the attach_method with the arguments of the function we want to attach, the instance we want to attach it to and the class the instance is derived from. Thus our function call might look like this:
    
    
    attach_method(cook, eggs, Spam)
    

Note that in the function add_method we cannot write `instance.fxn = f` since this would add a function called fxn to the instance.

[Previous: Modules](/wiki/Python_Programming/Modules)
[Index](/wiki/Python_Programming)
[Next: MetaClasses](/wiki/Python_Programming/MetaClasses)

# Metaclasses

[Previous: Classes](/wiki/Python_Programming/Classes)
[Index](/wiki/Python_Programming)
[Next: Standard Library](/wiki/Python_Programming/Standard_Library)

In Python, classes are themselves objects. Just as other objects are instances of a particular class, classes themselves are instances of a metaclass.

### Class Factories

The simplest use of Python metaclasses is a class factory. This concept makes use of the fact that class definitions in Python are first-class objects. Such a function can create or modify a class definition, using the [same syntax](/wiki/Python_Programming/Classes#Defining_a_Class) one would normally use in declaring a class definition. Once again, it is useful to use the model of [classes as dictionaries](/wiki/Python_Programming/Classes#Viewing_Class_Dictionaries). First, let's look at a basic class factory:
    
    
    >>> def StringContainer():
    ...     # define a class
    ...     class String:
    ...             content_string = ""
    ...             def len(self):
    ...                     return len(self.content_string)
    ...     # return the class definition
    ...     return String
    ...
    >>> # create the class definition
    ... container_class = StringContainer()
    >>>
    >>> # create an instance of the class
    ... wrapped_string = container_class()
    >>>
    >>> # take it for a test drive
    ... wrapped_string.content_string = 'emu emissary'
    >>> wrapped_string.len()
    12
    

Of course, just like any other data in Python, class definitions can also be modified. Any modifications to attributes in a class definition will be seen in any instances of that definition, so long as that instance hasn't overridden the attribute that you're modifying.
    
    
    >>> def DeAbbreviate(sequence_container):
    ...     sequence_container.length = sequence_container.len
    ...     del sequence_container.len
    ...
    >>> DeAbbreviate(container_class)
    >>> wrapped_string.length()
    12
    >>> wrapped_string.len()
     Traceback (most recent call last):
       File "<stdin>", line 1, in ?
     AttributeError: String instance has no attribute 'len'
    

You can also delete class definitions, but that will not affect instances of the class.
    
    
    >>> del container_class
    >>> wrapped_string2 = container_class()
    Traceback (most recent call last):
      File "<stdin>", line 1, in ?
    NameError: name 'container_class' is not defined
    >>> wrapped_string.length()
    12
    

### The type Metaclass

The metaclass for all standard Python types is the "type" object.
    
    
    >>> type(object)
    <type 'type'>
    >>> type(int)
    <type 'type'>
    >>> type(list)
    <type 'type'>
    

Just like list, int and object, "type" is itself a normal Python object, and is itself an instance of a class. In this case, it is in fact an instance of itself.
    
    
    >>> type(type)
    <type 'type'>
    

It can be instantiated to create new class objects similarly to the class factory example above by passing the name of the new class, the base classes to inherit from, and a dictionary defining the namespace to use.

For instance, the code:
    
    
    >>> class MyClass(BaseClass):
    ...     attribute = 42
    

Could also be written as:
    
    
    >>> MyClass = type("MyClass", (BaseClass,), {'attribute' : 42})
    

### Metaclasses

It is possible to create a class with a different metaclass than type by setting its __metaclass__ attribute when defining. When this is done, the class, and its subclass will be created using your custom metaclass. For example
    
    
    class CustomMetaclass(type):
        def __init__(cls, name, bases, dct):
            print "Creating class %s using CustomMetaclass" % name
            super(CustomMetaclass, cls).__init__(name, bases, dct)
     
    class BaseClass(object):
        __metaclass__ = CustomMetaclass
     
    class Subclass1(BaseClass):
        pass
    

This will print
    
    
    Creating class BaseClass using CustomMetaclass
    Creating class Subclass1 using CustomMetaclass
    

By creating a custom metaclass in this way, it is possible to change how the class is constructed. This allows you to add or remove attributes and methods, register creation of classes and subclasses creation and various other manipulations when the class is created.

### More resources

  * [Wikipedia article on Aspect Oriented Programming](//en.wikipedia.org/wiki/Aspect-oriented_programming)
  * [Unifying types and classes in Python 2.2](http://www.python.org/2.2/descrintro.html)
  * [O'Reilly Article on Python Metaclasses](http://www.onlamp.com/pub/a/python/2003/04/17/metaclasses.html)

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
[Incomplete] (see Putting Metaclasses to Work, Ira R. Forman, Scott H. Danforth?)

[Previous: Classes](/wiki/Python_Programming/Classes)
[Index](/wiki/Python_Programming)
[Next: Standard Library](/wiki/Python_Programming/Standard_Library)

# Reflection

[Previous: Namespace](/wiki/Python_Programming/Namespace)
[Index](/wiki/Python_Programming)
[Next: Tips and Tricks](/wiki/Python_Programming/Tips_and_Tricks)

A Python script can find out about the type, class, attributes and methods of an object. This is referred to as **reflection** or **introspection**. See also [Metaclasses](/wiki/Python_Programming/Metaclasses).

Reflection-enabling functions include type(), isinstance(), callable(), dir() and getattr().

## Type

The type method enables to find out about the type of an object. The following tests return True:

  * type(3) is int
  * type('Hello') is str
  * type([1, 2]) is list
  * type([1, [2, 'Hello']]) is list
  * type({'city': 'Paris'}) is dict

## Isinstance

Determines whether an object is an instance of a class.

The following returns True:

  * isinstance(3, int)
  * isinstance([1, 2], list)

Note that isinstance provides a weaker condition than a comparison using #Type.

## Duck typing

Duck typing provides an indirect means of reflection. It is a technique consisting in using an object as if it was of the requested type, while catching exceptions resulting from the object not supporting some of the features of the class or type.

## Callable

For an object, determines whether it can be called. A class can be made callable by providing a __call__() method.

Examples:

  * callable(2) 
    * Returns False. Ditto for callable("Hello") and callable([1, 2]).
  * callable([1,2].pop) 
    * Returns True, as pop without "()" returns a function object.
  * callable([1,2].pop()) 
    * Returns False, as [1,2].pop() returns 2 rather than a function object.

## Dir

Returns the list of attributes of an object, which includes methods.

Examples:

  * dir(3)
  * dir("Hello")
  * dir([1, 2])

## Getattr

Returns the value of an attribute of an object, given the attribute name passed as a string.

An example:

  * getattr(3, "imag")

The list of attributes of an object can be obtained using #Dir.

## External links

  * [2\. Built-in Functions](http://docs.python.org/2/library/functions.html), docs.python.org
  * [How to determine the variable type in Python?](http://stackoverflow.com/questions/402504/how-to-determine-the-variable-type-in-python), stackoverflow.com
  * [Differences between isinstance() and type() in python](http://stackoverflow.com/questions/1549801/differences-between-isinstance-and-type-in-python), stackoverflow.com
  * [W:Reflection (computer_programming)#Python](//en.wikipedia.org/wiki/Reflection_\(computer_programming\)#Python), Wikipedia
  * [W:Type introspection#Python](//en.wikipedia.org/wiki/Type_introspection#Python), Wikipedia

# Regular Expression

[Previous: Standard Library](/wiki/Python_Programming/Standard_Library)
[Index](/wiki/Python_Programming)
[Next: XML Tools](/wiki/Python_Programming/XML_Tools)

Python includes a module for working with regular expressions on strings. For more information about writing regular expressions and syntax not specific to Python, see the [regular expressions](/wiki/Regular_expressions) wikibook. Python's regular expression syntax is similar to [Perl's](/wiki/Perl_Programming/Regular_Expressions_Reference)

To start using regular expressions in your Python scripts, import the "re" module:
    
    
    import re
    

## Overview

Regular expression functions in Python at a glance:
    
    
    import re
    if re.search("l+","Hello"):        print 1  # Substring match suffices
    if not re.match("ell.","Hello"):   print 2  # The whole string has to match
    if re.match(".ell.","Hello"):      print 3
    if re.match("he..o","Hello",re.I): print 4  # Case-insensitive match
    print re.sub("l+", "l", "Hello")            # Prints "Helo"; replacement AKA substitution
    print re.sub(r"(.*)\1", r"\1", "HeyHey")    # Prints "Hey"; backreference
    for match in re.findall("l+.", "Hello Dolly"):
      print match                               # Prints "llo" and then "lly"
    for match in re.findall("e(l+.)", "Hello Dolly"):
      print match                               # Prints "llo"; match picks group 1
    matchObj = re.match("(Hello|Hi) (Tom|Thom)","Hello Tom Bombadil")
    if not matchObj is None:
      print matchObj.group(0)                   # Prints the whole match disregarding groups
      print matchObj.group(1) + matchObj.group(2) # Prints "HelloTom"
    

## Matching and searching

One of the most common uses for regular expressions is extracting a part of a string or testing for the existence of a pattern in a string. Python offers several functions to do this.

The match and search functions do mostly the same thing, except that the match function will only return a result if the pattern matches at the beginning of the string being searched, while search will find a match anywhere in the string.
    
    
    >>> import re
    >>> foo = re.compile(r'foo(.{,5})bar', re.I+re.S)
    >>> st1 = 'Foo, Bar, Baz'
    >>> st2 = '2. foo is bar'
    >>> search1 = foo.search(st1)
    >>> search2 = foo.search(st2)
    >>> match1 = foo.match(st1)
    >>> match2 = foo.match(st2)
    

In this example, match2 will be `None`, because the string `st2` does not start with the given pattern. The other 3 results will be Match objects (see below).

You can also match and search without compiling a regexp:
    
    
    >>> search3 = re.search('oo.*ba', st1, re.I)
    

Here we use the search function of the re module, rather than of the pattern object. For most cases, its best to compile the expression first. Not all of the re module functions support the flags argument and if the expression is used more than once, compiling first is more efficient and leads to cleaner looking code.

The compiled pattern object functions also have parameters for starting and ending the search, to search in a substring of the given string. In the first example in this section, `match2` returns no result because the pattern does not start at the beginning of the string, but if we do:
    
    
    >>> match3 = foo.match(st2, 3)
    

it works, because we tell it to start searching at character number 3 in the string.

What if we want to search for multiple instances of the pattern? Then we have two options. We can use the start and end position parameters of the search and match function in a loop, getting the position to start at from the previous match object (see below) or we can use the findall and finditer functions. The findall function returns a list of matching strings, useful for simple searching. For anything slightly complex, the finditer function should be used. This returns an iterator object, that when used in a loop, yields Match objects. For example:
    
    
    >>> str3 = 'foo, Bar Foo. BAR FoO: bar'
    >>> foo.findall(str3)
    [', ', '. ', ': ']
    >>> for match in foo.finditer(str3):
    ...     match.group(1)
    ...
    ', '
    '. '
    ': '
    

If you're going to be iterating over the results of the search, using the finditer function is almost always a better choice.

### Match objects

Match objects are returned by the search and match functions, and include information about the pattern match.

The group function returns a string corresponding to a capture group (part of a regexp wrapped in `()`) of the expression, or if no group number is given, the entire match. Using the `search1` variable we defined above:
    
    
    >>> search1.group()
    'Foo, Bar'
    >>> search1.group(1)
    ', '
    

Capture groups can also be given string names using a special syntax and referred to by `matchobj.group('name')`. For simple expressions this is unnecessary, but for more complex expressions it can be very useful.

You can also get the position of a match or a group in a string, using the start and end functions:
    
    
    >>> search1.start()
    0
    >>> search1.end()
    8
    >>> search1.start(1)
    3
    >>> search1.end(1)
    5
    

This returns the start and end locations of the entire match, and the start and end of the first (and in this case only) capture group, respectively.

## Replacing

Another use for regular expressions is replacing text in a string. To do this in Python, use the sub function.

sub takes up to 3 arguments: The text to replace with, the text to replace in, and, optionally, the maximum number of substitutions to make. Unlike the matching and searching functions, sub returns a string, consisting of the given text with the substitution(s) made.
    
    
    >>> import re
    >>> mystring = 'This string has a q in it'
    >>> pattern = re.compile(r'(a[n]? )(\w) ')
    >>> newstring = pattern.sub(r"\1'\2' ", mystring)
    >>> newstring
    "This string has a 'q' in it"
    

This takes any single alphanumeric character (\w in regular expression syntax) preceded by "a" or "an" and wraps in in single quotes. The `\1` and `\2` in the replacement string are backreferences to the 2 capture groups in the expression; these would be group(1) and group(2) on a Match object from a search.

The subn function is similar to sub, except it returns a tuple, consisting of the result string and the number of replacements made. Using the string and expression from before:
    
    
    >>> subresult = pattern.subn(r"\1'\2' ", mystring)
    >>> subresult
    ("This string has a 'q' in it", 1)
    

Replacing without constructing and compiling a pattern object:
    
    
    >>> result = re.sub(r"b.*d","z","abccde")
    >>> result
    'aze'
    

## Splitting

The split function splits a string based on a given regular expression:
    
    
    >>> import re
    >>> mystring = '1. First part 2. Second part 3. Third part'
    >>> re.split(r'\d\.', mystring)
    ['', ' First part ', ' Second part ', ' Third part']
    

## Escaping

The escape function escapes all non-alphanumeric characters in a string. This is useful if you need to take an unknown string that may contain regexp metacharacters like `(` and `.` and create a regular expression from it.
    
    
    >>> re.escape(r'This text (and this) must be escaped with a "\" to use in a regexp.')
    'This\\ text\\ \\(and\\ this\\)\\ must\\ be\\ escaped\\ with\\ a\\ \\"\\\\\\"\\ to\\ use\\ in\\ a\\ regexp\\.'
    

## Flags

The different flags use with regular expressions:

Abbreviation Full name Description

`re.I`
`re.IGNORECASE`
Makes the regexp [case-insensitive](//en.wikipedia.org/wiki/case_sensitivity)

`re.L`
`re.LOCALE`
Makes the behavior of some special sequences (`\w, \W, \b, \B, \s, \S`) dependent on the current [locale](//en.wikipedia.org/wiki/locale)

`re.M`
`re.MULTILINE`
Makes the `^` and `$` characters match at the beginning and end of each line, rather than just the beginning and end of the string

`re.S`
`re.DOTALL`
Makes the `.` character match every character _including_ newlines.

`re.U`
`re.UNICODE`
Makes `\w, \W, \b, \B, \d, \D, \s, \S` dependent on Unicode character properties

`re.X`
`re.VERBOSE`
Ignores whitespace except when in a character class or preceded by an non-escaped backslash, and ignores `#` (except when in a character class or preceded by an non-escaped backslash) and everything after it to the end of a line, so it can be used as a comment. This allows for cleaner-looking regexps.

## Pattern objects

If you're going to be using the same regexp more than once in a program, or if you just want to keep the regexps separated somehow, you should create a pattern object, and refer to it later when searching/replacing.

To create a pattern object, use the compile function.
    
    
    import re
    foo = re.compile(r'foo(.{,5})bar', re.I+re.S)
    

The first argument is the pattern, which matches the string "foo", followed by up to 5 of any character, then the string "bar", storing the middle characters to a group, which will be discussed later. The second, optional, argument is the flag or flags to modify the regexp's behavior. The flags themselves are simply variables referring to an integer used by the regular expression engine. In other languages, these would be constants, but Python does not have constants. Some of the regular expression functions do not support adding flags as a parameter when defining the pattern directly in the function, if you need any of the flags, it is best to use the compile function to create a pattern object.

The `r` preceding the expression string indicates that it should be treated as a raw string. This should normally be used when writing regexps, so that backslashes are interpreted literally rather than having to be escaped.

## External links

  * [Python `re` documentation](http://docs.python.org/library/re.html) \- Full documentation for the re module, including pattern objects and match objects

[Previous: Standard Library](/wiki/Python_Programming/Standard_Library)
[Index](/wiki/Python_Programming)
[Next: XML Tools](/wiki/Python_Programming/XML_Tools)

# GUI Programming

[Previous: Sockets](/wiki/Python_Programming/Sockets)
[Index](/wiki/Python_Programming)
[Next: WSGI web programming](/wiki/Python_Programming/WSGI_web_programming)

There are various GUI toolkits to start with.

## Tkinter

Tkinter, a Python wrapper for [Tcl/Tk](/wiki/Programming:Tcl), comes bundled with Python (at least on Win32 platform though it can be installed on Unix/Linux and Mac machines) and provides a cross-platform GUI. It is a relatively simple to learn yet powerful toolkit that provides what appears to be a modest set of widgets. However, because the Tkinter widgets are extensible, many compound widgets can be created rather easily (e.g. combo-box, scrolled panes). Because of its maturity and extensive documentation Tkinter has been designated as the de facto GUI for Python.

To create a very simple Tkinter window frame one only needs the following lines of code:
    
    
    import Tkinter
     
    root = Tkinter.Tk()
    root.mainloop()
    

From an object-oriented perspective one can do the following:
    
    
    import Tkinter
     
    class App:
       def __init__(self, master):
          button = Tkinter.Button(master, text="I'm a Button.")
          button.pack()
     
    if __name__ == '__main__':
       root = Tkinter.Tk()
       app = App(root)
       root.mainloop()
    

  
To learn more about Tkinter visit the following links:

  * <http://www.astro.washington.edu/users/rowen/TkinterSummary.html> <\- A summary  

  * <http://infohost.nmt.edu/tcc/help/lang/python/tkinter.html> <\- A tutorial  

  * <http://www.pythonware.com/library/tkinter/introduction/> <\- A reference  


## PyGTK

_See also book [PyGTK For GUI Programming](/wiki/PyGTK_For_GUI_Programming)_

[PyGTK](http://www.pygtk.org/) provides a convenient wrapper for the [GTK+](http://www.gtk.org) library for use in Python programs, taking care of many of the boring details such as managing memory and type casting. The bare GTK+ toolkit runs on Linux, Windows, and Mac OS X (port in progress), but the more extensive features — when combined with PyORBit and gnome-python — require a [GNOME](http://www.gnome.org) install, and can be used to write full featured GNOME applications.

[Home Page](http://www.pygtk.org/)

## PyQt

PyQt is a wrapper around the cross-platform [Qt C++ toolkit](http://www.trolltech.com/products/qt). It has many [widgets and support classes](http://www.riverbankcomputing.com/static/Docs/PyQt4/html/classes.html) supporting SQL, OpenGL, SVG, XML, and advanced graphics capabilities. A PyQt hello world example:
    
    
    from PyQt4.QtCore import *
    from PyQt4.QtGui import *
     
    class App(QApplication):
        def __init__(self, argv):
            super(App, self).__init__(argv)
            self.msg = QLabel("Hello, World!")
            self.msg.show()
     
    if __name__ == "__main__":
        import sys
        app = App(sys.argv)
        sys.exit(app.exec_())
    

[PyQt](http://www.riverbankcomputing.co.uk/pyqt/) is a set of bindings for the cross-platform [Qt](/wiki/Qt) application framework. PyQt v4 supports Qt4 and PyQt v3 supports Qt3 and earlier.

## wxPython

Bindings for the cross platform toolkit [wxWidgets](http://www.wxwidgets.org/). WxWidgets is available on Windows, Macintosh, and Unix/Linux.
    
    
    import wx
     
    class test(wx.App):
        def __init__(self):
            wx.App.__init__(self, redirect=False)
     
        def OnInit(self):
            frame = wx.Frame(None, -1,
                             "Test",
                             pos=(50,50), size=(100,40),
                             style=wx.DEFAULT_FRAME_STYLE)
            button = wx.Button(frame, -1, "Hello World!", (20, 20))
            self.frame = frame
            self.frame.Show()
            return True
     
    if __name__ == '__main__':
            app = test()
            app.MainLoop()
    

  * [wxPython](http://wxpython.org/)

## Dabo

Dabo is a full 3-tier application framework. Its UI layer wraps wxPython, and greatly simplifies the syntax.
    
    
    import dabo
    dabo.ui.loadUI("wx")
     
    class TestForm(dabo.ui.dForm):
            def afterInit(self):
                    self.Caption = "Test"
                    self.Position = (50, 50)
                    self.Size = (100, 40)
                    self.btn = dabo.ui.dButton(self, Caption="Hello World",
                          OnHit=self.onButtonClick)
                    self.Sizer.append(self.btn, halign="center", border=20)
     
            def onButtonClick(self, evt):
                    dabo.ui.info("Hello World!")
     
    if __name__ == '__main__':
            app = dabo.ui.dApp()
            app.MainFormClass = TestForm
            app.start()
    

  * [Dabo](http://dabodev.com/)

  


## pyFltk

[pyFltk](http://pyfltk.sourceforge.net/) is a Python wrapper for the [FLTK](http://www.fltk.org/), a lightweight cross-platform GUI toolkit. It is very simple to learn and allows for compact user interfaces.

The "Hello World" example in pyFltk looks like:
    
    
    from fltk import *
     
    window = Fl_Window(100, 100, 200, 90)
    button = Fl_Button(9,20,180,50)
    button.label("Hello World")
    window.end()
    window.show()
    Fl.run()
    

## Other Toolkits

  * [PyKDE](http://www.riverbankcomputing.co.uk/pykde/index.php) \- Part of the kdebindings package, it provides a python wrapper for the KDE libraries.
  * [PyXPCOM](http://developer.mozilla.org/en/docs/PyXPCOM) provides a wrapper around the Mozilla [XPCOM](http://developer.mozilla.org/en/docs/XPCOM) component architecture, thereby enabling the use of standalone [XUL](http://developer.mozilla.org/en/docs/XUL) applications in Python. The XUL toolkit has traditionally been wrapped up in various other parts of XPCOM, but with the advent of [libxul and XULRunner](http://developer.mozilla.org/en/docs/XULRunner) this should become more feasible.

[Previous: Sockets](/wiki/Python_Programming/Sockets)
[Index](/wiki/Python_Programming)
[Next: WSGI web programming](/wiki/Python_Programming/WSGI_web_programming)

# Game Programming in Python

[Previous: numpy](/wiki/Python_Programming/numpy)
[Index](/wiki/Python_Programming)
[Next: PyQt4](/wiki/Python_Programming/PyQt4)

## 3D Game Programming

### 3D Game Engine with a Python binding

  * Irrlicht Engine[[4]](http://irrlicht.sourceforge.net/) (Python binding website: [[5]](http://pypi.python.org/pypi/pyirrlicht) )
  * Ogre Engine [[6]](http://www.ogre3d.org/) (Python binding website: [[7]](http://www.python-ogre.org/) )

Both are very good free open source C++ 3D game Engine with a Python binding.

  * [CrystalSpace](http://www.crystalspace3d.org) is a free cross-platform software development kit for real-time 3D graphics, with particular focus on games. Crystal Space is accessible from Python in two ways: (1) as a Crystal Space plugin module in which C++ code can call upon Python code, and in which Python code can call upon Crystal Space; (2) as a pure Python module named ‘cspace’ which one can ‘import’ from within Python programs. To use the first option, load the ‘cspython’ plugin as you would load any other Crystal Space plugin, and interact with it via the SCF ‘iScript’ interface .The second approach allows you to write Crystal Space applications entirely in Python, without any C++ coding. [CS Wiki](http://en.wikipedia.org/wiki/Crystal_Space)

### 3D Game Engines written for Python

Engines designed for Python from scratch.

  * [Blender](http://www.blender.org/) is an impressive 3D tool with a fully integrated 3D graphics creation suite allowing modeling, animation, rendering, post-production, real-time interactive 3D and game creation and playback with cross-platform compatibility. The 3D game engine uses an embedded python interpreter to make 3D games.
  * [PySoy](http://www.pysoy.org/) is a 3d cloud game engine for Python 3. It was designed for rapid development with an intuitive API that gets new game developers started quickly. The [cloud gaming](//en.wikipedia.org/wiki/Cloud_gaming) design allows PySoy games to be played on a server without downloading them, greatly reducing the complexity of game distribution. [XMPP](//en.wikipedia.org/wiki/XMPP) accounts (such as Jabber or GMail) can be used for online gaming identities, chat, and initiating connections to game servers. PySoy is released under the [GNU AGPL license](//en.wikipedia.org/wiki/GNU_AGPL).
  * [Soya](http://www.soya3d.org/) is a 3D game engine with an easy to understand design. Its written in the [Pyrex](//en.wikipedia.org/wiki/Pyrex_programming_language) programming language and uses Cal3d for animation and [ODE](//en.wikipedia.org/wiki/Open_Dynamics_Engine) for physics. Soya is available under the [GNU GPL license](//en.wikipedia.org/wiki/GNU_GPL).
  * [Panda3D](http://www.panda3d.org/) is a 3D game engine. It's a library written in C++ with Python bindings. Panda3D is designed in order to support a short learning curve and rapid development. This software is available for free download with source code under the BSD License. The development was started by [Disney]. Now there are many projects made with Panda3D, such as [Disney's Pirate's of the Caribbean Online](http://disney.go.com/pirates/online/), [ToonTown](http://www.toontown.com/), [Building Virtual World](http://www.etc.cmu.edu/bvw), [Schell Games](http://www.schellgames.com) and many others. Panda3D supports several features: Procedural Geometry, Animated Texture, Render to texture, Track motion, fog, particle system, and many others.
  * [CrystalSpace](http://www.crystalspace3d.org/) Is a 3D game engine, with a Python bindings, named *[PyCrystal](http://www.crystalspace3d.org/main/PyCrystal), view Wikipedia page of *[CrystalSpace](http://en.wikipedia.org/wiki/Crystalspace).

## 2D Game Programming

  * [Pygame](//en.wikipedia.org/wiki/Pygame) is a cross platform Python library which wraps [SDL](//en.wikipedia.org/wiki/Simple_DirectMedia_Layer). It provides many features like Sprite groups and sound/image loading and easy changing of an objects position. It also provides the programmer access to key and mouse events. A full tutorial can be found in the free book ["Making Games with Python & Pygame"](http://inventwithpython.com/pygame).
  * [Phil's Pygame Utilities (PGU)](http://www.imitationpickles.org/pgu/wiki/index) is a collection of tools and libraries that enhance Pygame. Tools include a tile editor and a [level editor](//en.wikipedia.org/wiki/Level_editor) (tile, isometric, hexagonal). GUI enhancements include full featured GUI, HTML rendering, document layout, and text rendering. The libraries include a sprite and [tile engine](//en.wikipedia.org/wiki/Tile_engine) (tile, isometric, hexagonal), a state engine, a timer, and a high score system. (Beta with last update March, 2007. APIs to be deprecated and isometric and hexagonal support is currently Alpha and subject to change.) [Update 27/02/08 Author indicates he is not currently actively developing this library and anyone that is willing to develop their own scrolling isometric library offering can use the existing code in PGU to get them started.]
  * [Pyglet](http://www.pyglet.org/) is a cross-platform windowing and multimedia library for Python with no external dependencies or installation requirements. Pyglet provides an object-oriented programming interface for developing games and other visually-rich applications for [Windows](//en.wikipedia.org/wiki/Windows), [Mac OS X](//en.wikipedia.org/wiki/Mac_OS_X) and [Linux](//en.wikipedia.org/wiki/Linux). Pyglet allows programs to open multiple windows on multiple screens, draw in those windows with OpenGL, and play back audio and video in most formats. Unlike similar libraries available, pyglet has no external dependencies (such as SDL) and is written entirely in Python. Pyglet is available under a [BSD-Style license](//en.wikipedia.org/wiki/BSD_licenses).
  * [Kivy](http://kivy.org/) Kivy is a library for developing multi-touch applications. It is completely cross-platform (Linux/OSX/Win & Android with OpenGL ES2). It comes with native support for many multi-touch input devices, a growing library of multi-touch aware widgets and hardware accelerated OpenGL drawing. Kivy is designed to let you focus on building custom and highly interactive applications as quickly and easily as possible.
  * [Rabbyt](http://arcticpaint.com/projects/rabbyt/) A fast [Sprite](//en.wikipedia.org/wiki/Sprite_\(computer_graphics\)) library for Python with game development in mind. With Rabbyt Anims, even old graphics cards can produce very fast animations of 2,400 or more sprites handling position, rotation, scaling, and color simultaneously.

  


## See Also

  * [10 Lessons Learned](http://www.gamedev.net/reference/articles/article2259.asp) \- How To Build a Game In A Week From Scratch With No Budget

[Previous: numpy](/wiki/Python_Programming/numpy)
[Index](/wiki/Python_Programming)
[Next: PyQt4](/wiki/Python_Programming/PyQt4)

# Sockets

[Previous: Threading](/wiki/Python_Programming/Threading)
[Index](/wiki/Python_Programming)
[Next: GUI Programming](/wiki/Python_Programming/GUI_Programming)

## HTTP Client

Make a very simple HTTP client
    
    
    import socket
    s = socket.socket()
    s.connect(('localhost', 80))
    s.send('GET / HTTP/1.1\nHost:localhost\n\n')
    s.recv(40000) # receive 40000 bytes
    

## NTP/Sockets

Connecting to and reading an NTP time server, returning the time as follows
    
    
    ntpps       picoseconds portion of time
    ntps        seconds portion of time
    ntpms       milliseconds portion of time
    ntpt        64-bit ntp time, seconds in upper 32-bits, picoseconds in lower 32-bits
    

[Previous: Threading](/wiki/Python_Programming/Threading)
[Index](/wiki/Python_Programming)
[Next: GUI Programming](/wiki/Python_Programming/GUI_Programming)

# Files

[Previous: Modules and how to use them](/wiki/Python_Programming/Modules_and_how_to_use_them)
[Index](/wiki/Python_Programming)
[Next: Text](/wiki/Python_Programming/Text)

## File I/O

Read entire file:
    
    
    inputFileText = open("testit.txt", "r").read()
    print(inputFileText)
    

In this case the "r" parameter means the file will be opened in read-only mode.

Read certain amount of bytes from a file:
    
    
    inputFileText = open("testit.txt", "r").read(123)
    print(inputFileText)
    

When opening a file, one starts reading at the beginning of the file, if one would want more random access to the file, it is possible to use `seek()` to change the current position in a file and `tell()` to get to know the current position in the file. This is illustrated in the following example:
    
    
    >>> f=open("/proc/cpuinfo","r")
    >>> f.tell()
    0L
    >>> f.read(10)
    'processor\t'
    >>> f.read(10)
    ': 0\nvendor'
    >>> f.tell()
    20L
    >>> f.seek(10)
    >>> f.tell()
    10L
    >>> f.read(10)
    ': 0\nvendor'
    >>> f.close()
    >>> f
    <closed file '/proc/cpuinfo', mode 'r' at 0xb7d79770>
    

Here a file is opened, twice ten bytes are read, `tell()` shows that the current offset is at position 20, now `seek()` is used to go back to position 10 (the same position where the second read was started) and ten bytes are read and printed again. And when no more operations on a file are needed the `close()` function is used to close the file we opened.

Read one line at a time:
    
    
    for line in open("testit.txt", "r"):
        print line
    

In this case `readlines()` will return an array containing the individual lines of the file as array entries. Reading a single line can be done using the `readline()` function which returns the current line as a string. This example will output an additional newline between the individual lines of the file, this is because one is read from the file and print introduces another newline.

Write to a file requires the second parameter of `open()` to be "w", this will overwrite the existing contents of the file if it already exists when opening the file:
    
    
    outputFileText = "Here's some text to save in a file"
    open("testit.txt", "w").write(outputFileText)
    

Append to a file requires the second parameter of `open()` to be "a" (from append):
    
    
    outputFileText = "Here's some text to add to the existing file."
    open("testit.txt", "a").write(outputFileText)
    

Note that this does not add a line break between the existing file content and the string to be added.

## Testing Files

Determine whether path exists:
    
    
    import os
    os.path.exists('<path string>')
    

When working on systems such as Microsoft Windows™, the directory separators will conflict with the path string. To get around this, do the following:
    
    
    import os
    os.path.exists('C:\\windows\\example\\path')
    

A better way however is to use "raw", or `r`:
    
    
    import os
    os.path.exists(r'C:\windows\example\path')
    

But there are some other convenient functions in `os.path`, where `path.code.exists()` only confirms whether or not path exists, there are functions which let you know if the path is a file, a directory, a mount point or a symlink. There is even a function `os.path.realpath()` which reveals the true destination of a symlink:
    
    
    >>> import os
    >>> os.path.isfile("/")
    False
    >>> os.path.isfile("/proc/cpuinfo")
    True
    >>> os.path.isdir("/")
    True
    >>> os.path.isdir("/proc/cpuinfo")
    False
    >>> os.path.ismount("/")
    True
    >>> os.path.islink("/")
    False
    >>> os.path.islink("/vmlinuz")
    True
    >>> os.path.realpath("/vmlinuz")
    '/boot/vmlinuz-2.6.24-21-generic'
    

## Common File Operations

To copy or move a file, use the shutil library.
    
    
    import shutil
    shutil.move("originallocation.txt","newlocation.txt")
    shutil.copy("original.txt","copy.txt")
    

To perform a recursive copy it is possible to use `copytree()`, to perform a recursive remove it is possible to use `rmtree()`
    
    
    import shutil
    shutil.copytree("dir1","dir2")
    shutil.rmtree("dir1")
    

To remove an individual file there exists the `remove()` function in the os module:
    
    
    import os
    os.remove("file.txt")
    

## Finding Files

Files can be found using _glob_:
    
    
    glob.glob('*.txt') # Finds files in the currect directory ending in dot txt 
    glob.glob('*\\*.txt') # Finds files in any of the direct subdirectories
                          # of the currect directory ending in dot txt 
    glob.glob('C:\\Windows\\*.exe')
    for fileName in glob.glob('C:\\Windows\\*.exe'):
      print fileName
    

The content of a directory can be listed using _listdir_:
    
    
    filesAndDirectories=os.listdir('.')
    for item in filesAndDirectories:
      if os.path.isfile(item) and item.endswith('.txt'):
        print "Text file: " + item
      if os.path.isdir(item):
        print "Directory: " + item
    

Getting a list of all items in a directory, including the nested ones:
    
    
    for root, directories, files in os.walk('/user/Joe Hoe'):
      print "Root: " + root
      for directory in directories:
        print "Directory: " + directory
      for file in files:
        print "File: " + file
    

## Current Directory

Getting current working directory:
    
    
    os.getcwd()
    

Changing current working directory:
    
    
    os.chdir('C:\\')
    

## External Links

  * [os — Miscellaneous operating system interfaces](http://docs.python.org/2/library/os.html) in Python documentation
  * [glob — Unix style pathname pattern expansion](http://docs.python.org/2/library/glob.html) in Python documentation
  * [shutil — High-level file operations](http://docs.python.org/2/library/shutil.html) in Python documentation
  * [Brief Tour of the Standard Library](http://docs.python.org/2/tutorial/stdlib.html) in The Python Tutorial

[Previous: Modules and how to use them](/wiki/Python_Programming/Modules_and_how_to_use_them)
[Index](/wiki/Python_Programming)
[Next: Text](/wiki/Python_Programming/Text)

# Database Programming

[Previous: Web Page Harvesting](/wiki/Python_Programming/Web_Page_Harvesting)
[Index](/wiki/Python_Programming)
[Next: numpy](/wiki/Python_Programming/numpy)

  


## Generic Database Connectivity using ODBC

The [Open Database Connectivity](//en.wikipedia.org/wiki/Open_Database_Connectivity) (ODBC) API standard allows transparent connections with any database that supports the interface. This includes most popular databases, such as [PostgreSQL](//en.wikipedia.org/wiki/PostgreSQL) or [Microsoft Access](//en.wikipedia.org/wiki/Microsoft_Access). The strengths of using this interface is that a Python script or module can be used on different databases by only modifying the connection string.

There are three ODBC modules for Python:

  1. **PythonWin ODBC Module**: provided by Mark Hammond with the [PythonWin](http://starship.python.net/crew/mhammond/win32/) package for Microsoft Windows (only). This is a minimal implementation of ODBC, and conforms to Version 1.0 of the Python Database API. Although it is stable, it will likely not be developed any further.[3]
  2. **mxODBC**: a commercial Python package (<http://www.egenix.com/products/python/mxODBC/>), which features handling of DateTime objects and prepared statements (using parameters).
  3. **pyodbc**: an open-source Python package (<http://code.google.com/p/pyodbc>), which uses only native Python data-types and uses prepared statements for increased performance. The present version supports the Python Database API Specification v2.0.[4]

### pyodbc

An example using the `pyodbc` Python package with a Microsoft Access file (although this database connection could just as easily be a MySQL database):
    
    
    import pyodbc
     
    DBfile = '/data/MSAccess/Music_Library.mdb'
    conn = pyodbc.connect('DRIVER={Microsoft Access Driver (*.mdb)};DBQ='+DBfile)
    cursor = conn.cursor()
     
    SQL = 'SELECT Artist, AlbumName FROM RecordCollection ORDER BY Year;'
    for row in cursor.execute(SQL): # cursors are iterable
        print row.Artist, row.AlbumName
     
    cursor.close()
    conn.close()
    

Many more features and examples are provided on the pyodbc website.

code create problem shown below. ImportError: DLL load failed: The specified procedure could not be found.

## Postgres connection in Python

-> see [Python Programming/Databases](/wiki/Python_Programming/Databases) code create problem shown below ImportError: DLL load failed: The specified procedure could not be found.

## MySQL connection in Python

-> see [Python Programming/Databases](/wiki/Python_Programming/Databases)

## SQLAlchemy in Action

SQLAlchemy has become the favorite choice for many large Python projects that use databases. A long, updated list of such projects is listed on the SQLAlchemy site. Additionally, a pretty good tutorial can be found there, as well. Along with a thin database wrapper, Elixir, it behaves very similarly to the ORM in Rails, ActiveRecord.

## See also

  * [Python Programming/Databases](/wiki/Python_Programming/Databases)

## References

  1. ↑ [The Things I Hate About IDLE That I Wish Someone Would Fix The table below lists some IDLE alternatives](http://inventwithpython.com/blog/2011/11/29/the-things-i-hate-about-idle-that-i-wish-someone-would-fix/).

## External links

  * [SQLAlchemy](http://www.sqlalchemy.org/)
  * [SQLObject](http://www.sqlobject.org/)
  * [PEP 249](http://www.python.org/dev/peps/pep-0249/) \- Python Database API Specification v2.0
  * [Database Topic Guide](http://www.python.org/doc/topics/database/) on python.org

  


[Previous: Web Page Harvesting](/wiki/Python_Programming/Web_Page_Harvesting)
[Index](/wiki/Python_Programming)
[Next: numpy](/wiki/Python_Programming/numpy)

# Web Page Harvesting

[Previous: WSGI web programming](/wiki/Python_Programming/WSGI_web_programming)
[Index](/wiki/Python_Programming)
[Next: Database Programming](/wiki/Python_Programming/Database_Programming)

  


[Previous: WSGI web programming](/wiki/Python_Programming/WSGI_web_programming)
[Index](/wiki/Python_Programming)
[Next: Database Programming](/wiki/Python_Programming/Database_Programming)

# Threading

[Previous: Email](/wiki/Python_Programming/Email)
[Index](/wiki/Python_Programming)
[Next: Sockets](/wiki/Python_Programming/Sockets)

Threading in python is used to run multiple threads (tasks, function calls) at the same time. Note that this does not mean, that they are executed on different CPUs. Python threads will NOT make your program faster if it already uses 100 % CPU time, probably you then want to look into parallel programming. If you are interested in parallel progamming with python, please see [here](http://wiki.python.org/moin/ParallelProcessing).

Python threads are used in cases where the execution of a task involves some waiting. One example would be interaction with a service hosted on another computer, such as a webserver. Threading allows python to execute other code while waiting; this is easily simulated with the sleep function.

## Examples

### A Minimal Example with Function Call

Make a thread that prints numbers from 1-10, waits for 1 sec between:
    
    
    import threading
    import time
     
    def loop1_10():
        for i in range(1, 11):
            time.sleep(1)
            print(i)
     
    threading.Thread(target=loop1_10).start()
    

### A Minimal Example with Object
    
    
    #!/usr/bin/env python
    import threading
    import time
    from __future__ import print_function
     
    class MyThread(threading.Thread):
        def run(self):
            print("{} started!".format(self.getName()))              # "Thread-x started!"
            time.sleep(1)                                      # Pretend to work for a second
            print("{} finished!".format(self.getName()))             # "Thread-x finished!"
     
    if __name__ == '__main__':
        for x in range(4):                                     # Four times...
            mythread = MyThread(name = "Thread-{}".format(x + 1))  # ...Instantiate a thread and pass a unique ID to it
            mythread.start()                                   # ...Start the thread
            time.sleep(.9)                                     # ...Wait 0.9 seconds before starting another
    

This should output:
    
    
    Thread-1 started!
    Thread-2 started!
    Thread-1 finished!
    Thread-3 started!
    Thread-2 finished!
    Thread-4 started!
    Thread-3 finished!
    Thread-4 finished! 
    

**Note:** this example appears to crash IDLE in Windows XP (seems to work in IDLE 1.2.4 in Windows XP though)

There seems to be a problem with this, if you replace Sleep(1) with (2) ,and change range (4) to range(10). Thread -2 finished is the first line before its even started. in WING IDE, Netbeans, eclipse is fine.

[Previous: Email](/wiki/Python_Programming/Email)
[Index](/wiki/Python_Programming)
[Next: Sockets](/wiki/Python_Programming/Sockets)

# Extending with C

[Previous: pyFormex](/wiki/Python_Programming/pyFormex)
[Index](/wiki/Python_Programming)
[Next: Extending with C++](/wiki/Python_Programming/Extending_with_C%2B%2B)

This gives a minimal Example on how to Extend Python with C. Linux is used for building (feel free to extend it for other Platforms). If you have any problems, please report them (e.g. on the dicussion page), I will check back in a while and try to sort them out.

## Using the Python/C API

On an Ubuntu system, you might need to run
    
    
    $ sudo apt-get install python-dev           // this command ensures that you can use the line #include <Python.h>
    

  * <http://docs.python.org/ext/ext.html>
  * <http://docs.python.org/api/api.html>

### A minimal example

The minimal example we will create now is very similar in behaviour to the following python snippet:
    
    
     def say_hello(name):
         "Greet somebody."
         print "Hello %s!" % name
    

#### The C source code (`hellomodule.c`)
    
    
    #include <Python.h>
     
    static PyObject* say_hello(PyObject* self, PyObject* args)
    {
        const char* name;
     
        if (!PyArg_ParseTuple(args, "s", &name))
            return NULL;
     
        printf("Hello %s!\n", name);
     
        Py_RETURN_NONE;
    }
     
    static PyMethodDef HelloMethods[] =
    {
         {"say_hello", say_hello, METH_VARARGS, "Greet somebody."},
         {NULL, NULL, 0, NULL}
    };
     
    PyMODINIT_FUNC
     
    inithello(void)
    {
         (void) Py_InitModule("hello", HelloMethods);
    }
    

#### Building the extension module with GCC for Linux

To build our extension module we create the file `setup.py` like:
    
    
    from distutils.core import setup, Extension
     
    module1 = Extension('hello', sources = ['hellomodule.c'])
     
    setup (name = 'PackageName',
            version = '1.0',
            description = 'This is a demo package',
            ext_modules = [module1])
    

Now we can build our module with
    
    
    python setup.py build
    

The module `hello.so` will end up in `build/lib.linux-i686-_x_._y_`.

#### Building the extension module with GCC for Microsoft Windows

Microsoft Windows users can use [MinGW](//en.wikipedia.org/wiki/MinGW) to compile this from `[cmd.exe](//en.wikipedia.org/wiki/cmd.exe)` using a similar method to Linux user, as shown above. Assuming `gcc` is in the `PATH` environment variable, type:
    
    
    python setup.py build -cmingw32
    

The module `hello.pyd` will end up in `build\lib.win32-_x_._y_`, which is a Python Dynamic Module (similar to a `DLL`).

An alternate way of building the module in Windows is to build a DLL. (This method does not need an extension module file). From `cmd.exe`, type:
    
    
    gcc -c  hellomodule.c -I/Python_XY_/include
    gcc -shared hellomodule.o -L/Python_XY_/libs -lpython_XY_ -o hello.dll
    

where _XY_ represents the version of Python, such as "24" for version 2.4.

#### Building the extension module using Microsoft Visual C++

With VC8 distutils is broken. We will use cl.exe from a command prompt instead:
    
    
    cl /LD hellomodule.c /Ic:\Python24\include c:\Python24\libs\python24.lib /link/out:hello.dll
    

#### Using the extension module

Change to the subdirectory where the file `hello.so` resides. In an interactive python session you can use the module as follows.
    
    
    >>> import hello
    >>> hello.say_hello("World")
    Hello World!
    

### A module for calculating fibonacci numbers

#### The C source code (fibmodule.c)
    
    
    #include <Python.h>
     
    int _fib(int n)
    {
        if (n < 2)
            return n;
        else
            return _fib(n-1) + _fib(n-2);
    }
     
    static PyObject* fib(PyObject* self, PyObject* args)
    {
        int n;
     
        if (!PyArg_ParseTuple(args, "i", &n))
            return NULL;
     
        return Py_BuildValue("i", _fib(n));
    }
     
    static PyMethodDef FibMethods[] = {
        {"fib", fib, METH_VARARGS, "Calculate the Fibonacci numbers."},
        {NULL, NULL, 0, NULL}
    };
     
    PyMODINIT_FUNC
    initfib(void)
    {
        (void) Py_InitModule("fib", FibMethods);
    }
    

#### The build script (setup.py)
    
    
    from distutils.core import setup, Extension
     
    module1 = Extension('fib', sources = ['fibmodule.c'])
     
    setup (name = 'PackageName',
            version = '1.0',
            description = 'This is a demo package',
            ext_modules = [module1])
    

#### How to use it?
    
    
    >>> import fib
    >>> fib.fib(10)
    55
    

## Using SWIG

Creating the previous example using SWIG is much more straight forward. To follow this path you need to get [SWIG](http://www.swig.org/) up and running first. To install it on an Ubuntu system, you might need to run the following commands
    
    
    $ sudo apt-get install libboost-python-dev 
    $ sudo apt-get install python-dev
    

After that create two files.
    
    
    /*hellomodule.c*/
     
    #include <stdio.h>
     
    void say_hello(const char* name) {
        printf("Hello %s!\n", name);
    }
    
    
    
    /*hello.i*/
     
    %module hello
    extern void say_hello(const char* name);
    

Now comes the more difficult part, gluing it all together.

First we need to let SWIG do its work.
    
    
    swig -python hello.i
    

This gives us the files `hello.py` and `hello_wrap.c`.

The next step is compiling (substitute /usr/include/python2.4/ with the correct path for your setup!).
    
    
    gcc -fpic -c hellomodule.c hello_wrap.c -I/usr/include/python2.4/
    

Now linking and we are done!
    
    
    gcc -shared hellomodule.o hello_wrap.o -o _hello.so
    

The module is used in the following way.
    
    
    >>> import hello
    >>> hello.say_hello("World")
    Hello World!
    

[Previous: pyFormex](/wiki/Python_Programming/pyFormex)
[Index](/wiki/Python_Programming)
[Next: Extending with C++](/wiki/Python_Programming/Extending_with_C%2B%2B)

# Extending with C++

[Previous: Extending with C](/wiki/Python_Programming/Extending_with_C)
[Index](/wiki/Python_Programming)
[Next: Extending with Pyrex](/wiki/Python_Programming/Extending_with_Pyrex)

There are different ways to extend Python:

  * In plain C, using Python.h
  * Using Swig
  * Using Boost.Python, optionally with Py++ preprocessing
  * Using Cython.

This page describes [Boost.Python](http://www.boost.org/libs/python/doc/). Before the emergence of Cython, it was the most comfortable way of writing [C++](/wiki/C%2B%2B) extension modules.

Boost.Python comes bundled with the [Boost C++ Libraries](http://www.boost.org/). To install it on an Ubuntu system, you might need to run the following commands
    
    
    $ sudo apt-get install libboost-python-dev 
    $ sudo apt-get install python-dev
    

## A Hello World Example

### The C++ source code (hellomodule.cpp)
    
    
    #include <iostream>
     
    using namespace std;
     
    void say_hello(const char* name) {
        cout << "Hello " <<  name << "!\n";
    }
     
    #include <boost/python/module.hpp>
    #include <boost/python/def.hpp>
    using namespace boost::python;
     
    BOOST_PYTHON_MODULE(hello)
    {
        def("say_hello", say_hello);
    }
    

### setup.py
    
    
    #!/usr/bin/env python
     
    from distutils.core import setup
    from distutils.extension import Extension
     
    setup(name="PackageName",
        ext_modules=[
            Extension("hello", ["hellomodule.cpp"],
            libraries = ["boost_python"])
        ])
    

Now we can build our module with
    
    
    python setup.py build
    

The module `hello.so` will end up in e.g `build/lib.linux-i686-2.4`.

### Using the extension module

Change to the subdirectory where the file `hello.so` resides. In an interactive python session you can use the module as follows.
    
    
    >>> import hello
    >>> hello.say_hello("World")
    Hello World!
    

## An example with CGAL

Some, but not all, functions of the CGAL library have already Python bindings. Here an example is provided for a case without such a binding and how it might be implemented. The example is taken from the [CGAL Documentation](http://www.cgal.org/Manual/3.3/doc_html/cgal_manual/SearchStructures/Chapter_main.html#Subsection_46.5.1).
    
    
    // test.cpp
    using namespace std;
     
    /* PYTHON */
    #include <boost/python.hpp>
    #include <boost/python/module.hpp>
    #include <boost/python/def.hpp>
    namespace python = boost::python;
     
    /* CGAL */
    #include <CGAL/Cartesian.h>
    #include <CGAL/Range_segment_tree_traits.h>
    #include <CGAL/Range_tree_k.h>
     
    typedef CGAL::Cartesian<double> K;
    typedef CGAL::Range_tree_map_traits_2<K, char> Traits;
    typedef CGAL::Range_tree_2<Traits> Range_tree_2_type;
     
    typedef Traits::Key Key;
    typedef Traits::Interval Interval;
     
    Range_tree_2_type *Range_tree_2 = new Range_tree_2_type;
     
    void create_tree()   {
     
      typedef Traits::Key Key;                
      typedef Traits::Interval Interval;    
     
      std::vector<Key> InputList, OutputList;
      InputList.push_back(Key(K::Point_2(8,5.1), 'a'));
      InputList.push_back(Key(K::Point_2(1.0,1.1), 'b'));
      InputList.push_back(Key(K::Point_2(3,2.1), 'c'));
     
      Range_tree_2->make_tree(InputList.begin(),InputList.end());
      Interval win(Interval(K::Point_2(1,2.1),K::Point_2(8.1,8.2)));
      std::cout << "\n Window Query:\n";
      Range_tree_2->window_query(win, std::back_inserter(OutputList));
      std::vector<Key>::iterator current=OutputList.begin();
      while(current!=OutputList.end()){
          std::cout << "  " << (*current).first.x() << "," << (*current).first.y()
               << ":" << (*current).second << std::endl;
          current++;
        }
      std::cout << "\n Done\n";
    }
     
    void initcreate_tree() {;}
     
    using namespace boost::python;
    BOOST_PYTHON_MODULE(test)
    {
        def("create_tree", create_tree, "");
    }
    
    
    
    // setup.py
    #!/usr/bin/env python
     
    from distutils.core import setup
    from distutils.extension import Extension
     
    setup(name="PackageName",
        ext_modules=[
            Extension("test", ["test.cpp"],
            libraries = ["boost_python"])
        ])
    

We then compile and run the module as follows:
    
    
    $ python setup.py build
    $ cd build/lib*
    $ python
    >>> import test
    >>> test.create_tree()
    Window Query:
     3,2.1:c
     8,5.1:a
    Done
    >>>
    

## Handling Python objects and errors

One can also handle more complex data, e.g. Python objects like lists. The attributes are accessed with the extract function executed on the objects "attr" function output. We can also throw errors by telling the library that an error has occurred and returning. In the following case, we have written a C++ function called "afunction" which we want to call. The function takes an integer N and a vector of length N as input, we have to convert the python list to a vector of strings before calling the function.
    
    
    #include <vector>
    using namespace std;
     
    void _afunction_wrapper(int N, boost::python::list mapping) {
     
        int mapping_length = boost::python::extract<int>(mapping.attr("__len__")());
        //Do Error checking, the mapping needs to be at least as long as N 
        if (mapping_length < N) {
            PyErr_SetString(PyExc_ValueError,
                "The string mapping must be at least of length N");
            boost::python::throw_error_already_set();
            return;
        }
     
        vector<string> mystrings(mapping_length);
        for (int i=0; i<mapping_length; i++) {
            mystrings[i] = boost::python::extract<char const *>(mapping[i]);
        }
     
       //now call our C++ function
       _afunction(N, mystrings);
     
    }
     
    using namespace boost::python;
    BOOST_PYTHON_MODULE(c_afunction)
    {
        def("afunction", _afunction_wrapper);
    }
    

  


[Previous: Extending with C](/wiki/Python_Programming/Extending_with_C)
[Index](/wiki/Python_Programming)
[Next: Extending with Pyrex](/wiki/Python_Programming/Extending_with_Pyrex)

# WSGI web programming

[Previous: GUI Programming](/wiki/Python_Programming/GUI_Programming)
[Index](/wiki/Python_Programming)
[Next: Web Page Harvesting](/wiki/Python_Programming/Web_Page_Harvesting)

# WSGI Web Programming

## External Resources

<http://docs.python.org/library/wsgiref.html>

[Previous: GUI Programming](/wiki/Python_Programming/GUI_Programming)
[Index](/wiki/Python_Programming)
[Next: Web Page Harvesting](/wiki/Python_Programming/Web_Page_Harvesting)

# References

## Language reference

The latest documentation for the standard python libraries and modules can always be found at [The Python.org documents section](http://www.python.org/doc/)

## External links

  * [Python books available for free download](http://www.techbooksforfree.com/perlpython.shtml)
  * [Non-programmers python tutorial](http://www.honors.montana.edu/~jjc/easytut/easytut/) donated to this project. [Wiki version](/w/index.php?title=User:Jrincayc/Contents&action=edit&redlink=1)
  * [Dive into Python](http://www.diveintopython.org/)
  * [How to think Like a Computer Scientist: Learning with Python](http://www.ibiblio.org/obp/thinkCSpy/)
  * [A Byte of Python](http://www.byteofpython.info/)
  * [ActiveState Python Cookbook](http://aspn.activestate.com/ASPN/Python/Cookbook/)
  * [Text Processing in Python](http://gnosis.cx/TPiP/)
  * [Dev Shed's Python Tutorials](http://www.devshed.com/c/b/Python/)
  * [MakeBot](http://stratolab.com/misc/makebot) \- Simple Python IDE designed for teaching game programming to kids.
  * [SPE - Stani's Python Editor](http://pythonide.stani.be)

# Authors

## Authors of Python textbook

  * [Quartz25](/wiki/User:Quartz25)
  * [Jesdisciple](/wiki/User:Jesdisciple)
  * [Hannes Röst](/wiki/User:Hannes_R%C3%B6st)

  


  


# License

# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Python_Programming/Print_version&oldid=2548842](http://en.wikibooks.org/w/index.php?title=Python_Programming/Print_version&oldid=2548842)" 

[Category](/wiki/Special:Categories): 

  * [Python Programming](/wiki/Category:Python_Programming)

Hidden category: 

  * [No references for citations](/wiki/Category:No_references_for_citations)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Python+Programming%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Python+Programming%2FPrint+version)

### Namespaces

  * [Book](/wiki/Python_Programming/Print_version)
  * [Discussion](/w/index.php?title=Talk:Python_Programming/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Python_Programming/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Python_Programming/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Python_Programming/Print_version&action=edit)
  * [View history](/w/index.php?title=Python_Programming/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Python_Programming/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Python_Programming/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Python_Programming/Print_version&oldid=2548842)
  * [Page information](/w/index.php?title=Python_Programming/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Python_Programming%2FPrint_version&id=2548842)

### In other languages

  * [Deutsch](//de.wikibooks.org/wiki/Python-Programmierung:_Funktionen)
  * [Español](//es.wikibooks.org/wiki/Inmersi%C3%B3n_en_Python/Su_primer_programa_en_Python/Declaraci%C3%B3n_de_funciones)
  * [Français](//fr.wikibooks.org/wiki/Programmation_Python/Fonction)
  * [Português](//pt.wikibooks.org/wiki/Python/Conceitos_b%C3%A1sicos/Fun%C3%A7%C3%B5es)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Python+Programming%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Python+Programming%2FPrint+version&oldid=2548842&writer=rl)
  * [Printable version](/w/index.php?title=Python_Programming/Print_version&printable=yes)

  * This page was last modified on 10 August 2013, at 12:17.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Python_Programming/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
