# Nikola Tesla/Print version

From Wikibooks, open books for an open world

< [Nikola Tesla](/wiki/Nikola_Tesla)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

[Biography of Nikola Tesla/Cover](/w/index.php?title=Biography_of_Nikola_Tesla/Cover&action=edit&redlink=1)

  
**[Nikola Tesla](//en.wikipedia.org/wiki/Nikola_Tesla)** (Serbian Cyrillic: Никола Тесла) was of unusual intellectual brilliance. The Serbian-American inventor, physicist, mechanical engineer and electrical engineer had a general mental capability that could reason, plan, and solve problems in his head. He could think abstractly and comprehend ideas without putting pen to paper. His patents (over 225 in the United States) and theoretical work still form the basis for modern alternating current electric power systems (including the polyphase system power distribution system). Tesla helped usher in the Second Industrial Revolution. Tesla is regarded as one of the most important inventors in history. He is also well known for his contributions to the science of electricity and magnetism in the late 19th and early 20th centuries. His legacy can be seen across [modern civilization](//en.wikipedia.org/wiki/Modern_world).

In his early years, he enjoyed widespread fame; he was widely recognized in high society and in culture, and a significant amount of professional material of the publishing industries focuses on Tesla's announcements. He was highly regarded in the [annals of history](//en.wikipedia.org/wiki/history_of_science_and_technology). In the United States, Tesla's fame rivaled that of any other inventor or scientist of his era. After his demonstration of wireless communication in 1893 and after Westinghouse being the victor in the "War of Currents" using Tesla's patents, he was widely respected as America's greatest electrical engineer. Tesla's name became a byword for innovation and practical achievement.His name was one of the most recognizable in the world, a _magician_ who conjured up technical feats. Much of his early work pioneered modern electrical engineering and many of his discoveries were of groundbreaking importance. He later became credited as being the inventor of the radio. Tesla's vision was to find a means to provide humanity the means for [unlimited energy](//en.wikipedia.org/wiki/Free_energy_\(disambiguation\)). He gave his life to make real these plans, while others made fortunes with his [inventions](//en.wikipedia.org/wiki/invention).

In his later years, Tesla was regarded as a _[mad scientist](//en.wikipedia.org/wiki/mad_scientist)_. He became noted for making "bizarre" and misunderstood claims about possible scientific developments. At the end of his life, Tesla was mocked by his contemporaries and lived his remaining years destitute and [forgotten](//en.wikipedia.org/wiki/Historical_revisionism_\(political\)). Never putting a large focus on his finances, Tesla died impoverished at the age of 86. Tesla was ahead of his time; many of Tesla's ideas and concepts are just only recently coming to fruition.

Tesla's legacy can be seen across modern civilization wherever electricity is used. Aside from his work on electromagnetism and engineering, Tesla is said to have contributed in varying degrees to the fields of robotics, ballistics, computer science, nuclear physics, and theoretical physics. Many of his achievements have been used, with some controversy, to support various pseudosciences, UFO theories, and New Age occultism. Many contemporary admirers of Tesla have deemed him the man who invented the twentieth century.

## Relations, friendships, and personal views[[edit](/w/index.php?title=Nikola_Tesla/Introduction&action=edit&section=T-1)]

In his middle life, Nikola Tesla became very close friends with [Mark Twain](//en.wikipedia.org/wiki/Samuel_Clemens). They spent a lot of time together in his lab and elsewhere. He remained bitter in the aftermath of his incident with Edison. The day after Edison died the New York Times contained extensive coverage of Edison's life, with the only negative opinion coming from Edison who was quoted as saying, "He had no hobby, cared for no sort of amusement of any kind and lived in utter disregard of the most elementary rules of hygiene" and that, "His method was inefficient in the extreme, for an immense ground had to be covered to get anything at all unless blind chance intervened and, at first, I was almost a sorry witness of his doings, knowing that just a little theory and calculation would have saved him 90 percent of the labor. But he had a veritable contempt for book learning and mathematical knowledge, trusting himself entirely to his inventor's instinct and practical American sense." In his old age, Edison expressed that his biggest mistake was never respecting Tesla or his work. This did little for their almost non-existent relationship.

Tesla was opposed to [wars](//en.wikipedia.org/wiki/war) but believed it could not be avoided until the cause for its recurrence was removed. He inherited a hatred of war from his parents and homeland, and devised protective measures intended to systematically end warfare. He found exceptions and some justifiable situations where conflict was indeed necessary. He envisioned wars of machines, not of humans, and a future of catastrophic weapons. He sought to reduce distance, such as in communication for better understanding, transportation, and transmission of energy, as a means to ensure friendly international relations. A system for "Projecting Concentrated Non-Dispersive Energy Through Natural Media" known as _[teleforce](/w/index.php?title=Teleforce&action=edit&redlink=1)_ was reportedly developed later in his life. Teleforce was intended to be a type of defensive particle-beam weapon.

Like many of his era he developed a fondness for eugenics. The earliest clear instances of this were after his obsessive-compulsive disorder had been pronounced. In a curious 1926 interview he indicated humanity's future would be run by a "Queen Bee" referring to women who'd mate selectively.[[1]](http://www.tfcbooks.com/tesla/women.htm). By February of 1935 he had a pro-eugenics article in _Liberty_ which was edited by a friend named G. S. Viereck. In a 1937 interview near the end of his life he indicated that "A century from now it will no more occur to a normal person to mate with a person eugenically unfit than to marry a habitual criminal."[[2]](http://www.pbs.org/tesla/res/res_art11.html) Tesla was considered an [eccentric](//en.wikipedia.org/wiki/eccentricity_\(behavior\)), therefore some of his ideas have been overlooked in the traditional eugenicist school of thought.

## Early years[[edit](/w/index.php?title=Nikola_Tesla/Early_years&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Milutin_Tesla.jpg/220px-Milutin_Tesla.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Tesla's father Milutin

Tesla was born "at the stroke of midnight" in [1856](//en.wikipedia.org/wiki/1856) with lightning striking during a summer storm (the first moment of July 10). The midwife commented, "He'll be a child of the storm," to which his mother replied, "No, of light." He was born in [Smiljan](//en.wikipedia.org/wiki/Smiljan) near [Gospić](//en.wikipedia.org/wiki/Gospic) in [Croatia](//en.wikipedia.org/wiki/Coatia), [Lika](//en.wikipedia.org/wiki/Lika), (the [Military Frontier](//en.wikipedia.org/wiki/Military_Frontier) of the [Austria-Hungary](//en.wikipedia.org/wiki/Austria-Hungary), now in [Croatia](//en.wikipedia.org/wiki/Croatia)). (His baptismal name was Николай (_Nikola_). His Baptism Certificate reports that he was born on June 28 ([Julian calendar](//en.wikipedia.org/wiki/Julian_calendar); July 10 in the [Gregorian calendar](//en.wikipedia.org/wiki/Gregorian_calendar)) [1856](//en.wikipedia.org/wiki/1856), and christened by the Serbian orthodox [priest](//en.wikipedia.org/wiki/priest), Toma Oklobdžija. Tesla was [baptised](//en.wikipedia.org/wiki/baptism) in the Old Slavonic Church rite.

His father was [Rev.](//en.wikipedia.org/wiki/Reverend) [Milutin Tesla](//en.wikipedia.org/wiki/Milutin_Tesla), a [Serbian](//en.wikipedia.org/wiki/Serbs) priest in the [Orthodox Metropolitanate of Karlovci](//en.wikipedia.org/wiki/Serb_Orthodox_Church) which gathered the Serbs of the "Greek-rite" as they were legally referred to in [Habsburg Monarchy](//en.wikipedia.org/wiki/Habsburg_Monarchy) at the time (Vlach Orthodox; Metropolitanate of Karlovci). His father's church in [Gospić](//en.wikipedia.org/wiki/Gospic) was destroyed in the [1990s](//en.wikipedia.org/wiki/1990s)[[3]](http://www.eparhija-gornjokarlovacka.hr/Images/Eparhija/Gospic/Gospic4.jpg). His mother was [Đuka Mandić](//en.wikipedia.org/wiki/Duka_Mandic), a housewife talented in making home craft tools. Nikola was one of five children, having one brother and three sisters. His [godfather](//en.wikipedia.org/wiki/godparent), [Jovan Drenovac](//en.wikipedia.org/wiki/Jovan_Drenovac), was a Captain in the Krajina army. His family moved to Gospić in [1862](//en.wikipedia.org/wiki/1862).

## School[[edit](/w/index.php?title=Nikola_Tesla/Early_years&action=edit&section=T-2)]

_Education_:

    **Elementary school**

  * Gospić (Austria-Hungary, now Croatia)
    **Secondary school**

  * Karlovac (Austria-Hungary, now Croatia)

    **Undergraduate studies**

  * Starting Fall term 1875, Studied Physics, Mathematics, Mechanical Engineering, and Electrical Engineering at [Austria Politechnic](//en.wikipedia.org/wiki/Austria_Politechnic), in Graz, Austria, but left in his junior year without graduating or receiving a degree. Devised the idea for his brushless AC induction motot while studying physics there.
  * Studied one summer term at University of Prague (Prague).

    **Honorary degrees**

  * Numerous honorary Doctorates awarded, including from [Austria Politechnic](//en.wikipedia.org/wiki/Austria_Politechnic)

Tesla went to school in [Karlovac](//en.wikipedia.org/wiki/Karlovac) (then Austria-Hungary), then studied electrical engineering at the [Austria Politechnic](//en.wikipedia.org/wiki/Austria_Politechnic) in [Graz](//en.wikipedia.org/wiki/Graz), [Austria](//en.wikipedia.org/wiki/Austria) ([1875](//en.wikipedia.org/wiki/1875)). While there, he studied the uses of alternating current. Today , there is a school dedicated to Nikola Tesla in Zagreb.

## Early employment[[edit](/w/index.php?title=Nikola_Tesla/Early_years&action=edit&section=T-3)]

In [1881](//en.wikipedia.org/wiki/1881) he moved to [Budapest](//en.wikipedia.org/wiki/Budapest) to work for the [telegraph](//en.wikipedia.org/wiki/telegraph) company, [American Telephone Company](//en.wikipedia.org/wiki/American_Telephone_Company). On the opening of the [telephone](//en.wikipedia.org/wiki/telephone) exchange in Budapest, 1881, Tesla became the chief electrician to the company, later engineer to the [Yugoslav](//en.wikipedia.org/wiki/Yugoslavia) government and the country's first telephone system. He also developed a [telephone](//en.wikipedia.org/wiki/telephone) [repeater](//en.wikipedia.org/wiki/repeater) (sometimes called an [amplifier](//en.wikipedia.org/wiki/amplifier)) [ed., this was one of the first wireless telephones]. The device could act as an [audio](//en.wikipedia.org/wiki/audio) [speaker](//en.wikipedia.org/wiki/Loudspeaker) (not an audio [transducer](//en.wikipedia.org/wiki/transducer)).

The device had its [resonance](//en.wikipedia.org/wiki/resonance) tuned to a particular [frequency](//en.wikipedia.org/wiki/frequency) of other repeaters to communicate between each. In [1916](//en.wikipedia.org/wiki/1916), Tesla described the prior developed audio transducers. According to Tesla, it was the "... _simplest ways_ [to detect the [radiant energy](//en.wikipedia.org/wiki/radiant_energy) ...] _the low frequency gave audible notes._ [... in a field, there was] _placed a [conductor](//en.wikipedia.org/wiki/conductor_\(material\)), a wire or a coil, and then Tesla would get a note_ [...] _characteristics of the audible note_". The audible sounds were of the quality of the telephones diaphragms of that period of time. The invention was never patented nor released publicly (till years later by Tesla himself). The device also contained the characteristics of modern wireless telephones.

For a while he stayed in [Maribor](//en.wikipedia.org/wiki/Maribor). He was employed at his first job as an assistant engineer. Tesla suffered a nervous breakdown during this time. In [1882](//en.wikipedia.org/wiki/1882) he moved to [Paris](//en.wikipedia.org/wiki/paris) to work as an engineer for the [Continental Edison Company](//en.wikipedia.org/wiki/Continental_Edison_Company). He worked designing improvements to electric equipment. In the same year, Tesla conceived of the induction motor and began developing various devices that use rotating [magnetic fields](//en.wikipedia.org/wiki/magnetic_field) (for which he received patents in [1888](//en.wikipedia.org/wiki/1888)). Tesla visualized the rotating fields and thereby designed the induction motor.

Tesla was fascinated by the [Crookes radiometer](//en.wikipedia.org/wiki/Crookes_radiometer), believing that it was a most wonderful invention.

Tesla hastened from Paris to his mother's side as she lay dying, arriving hours before her death in [1882](//en.wikipedia.org/wiki/1882). Her last words to him were, "You've arrived, Nidzo, my pride." After her death, Tesla fell ill. He spent two to three weeks recuperating in Gospić and the village of [Tomingaj](//en.wikipedia.org/wiki/tomingaj) near Grač, the birthplace of his mother. All his life, Tesla kept a home-spun embroidered travel bag from his mother.

## Menlo Park[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-1)]

In [1884](//en.wikipedia.org/wiki/1884), Tesla moved to the [United States of America](//en.wikipedia.org/wiki/United_States) to accept a job with the [Edison Company](//en.wikipedia.org/wiki/Edison_Company) in [New York City](//en.wikipedia.org/wiki/New_York_City). He arrived in the US with 4 [cents](//en.wikipedia.org/wiki/cent_\(currency\)) to his name, a book of [poetry](//en.wikipedia.org/wiki/poetry), and a letter of recommendation from [Charles Batchelor](//en.wikipedia.org/wiki/Charles_Batchelor) (his manager in his previous job) to Thomas Edison.

The letter read simply "I know two great men, and you are one of them. This young man is the other". Tesla's work for Edison began with simple electrical engineering. Eventually Tesla earned the respect of Edison and offered to undertake a complete re-design of the Edison company's DC [dynamos](//en.wikipedia.org/wiki/dynamo). After Tesla described the nature of the benefits from his proposed modifications, Edison offered him [US$](//en.wikipedia.org/wiki/US_dollar)50,000 if they were successfully completed.

Tesla worked for nearly a year to redesign them and gave the Edison company several enormously profitable new patents in the process. When Tesla inquired about the $50,000, Edison replied to him, "Tesla, you don't understand our American humor", and reneged on his agreement, offering a raise in Tesla's salary of $10 per week as a compromise - at which rate it would have taken almost 100 years to earn the money Edison had originally promised. Tesla resigned on the spot. In some accounts of the final confrontation, Tesla did not say a single word to Edison but simply turned his back on the inventor and walked off the premises. Edison would receive US patent 328572 for an improved [commutator](//en.wikipedia.org/wiki/commutator_\(electric\)) and, later, would gain US patent 373584 for a [dynamo-electric machine](//en.wikipedia.org/wiki/dynamo) (which includes an _[extra coil](//en.wikipedia.org/wiki/coil)_ and utilizes a _[field of force](//en.wikipedia.org/wiki/force_field)_) among other patents which Tesla may be responsible for.

## Independence[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-2)]

In [1886](//en.wikipedia.org/wiki/1886), Tesla formed his own company, _[Tesla Electric Light & Manufacturing](//en.wikipedia.org/wiki/Tesla_Electric_Light_%26_Manufacturing)_. The initial financial [investors](//en.wikipedia.org/wiki/investor) disagreed with Tesla on his plan for an alternating current motor and eventually relieved him of his duties at the company. Tesla worked in New York as a common laborer from [1886](//en.wikipedia.org/wiki/1886) to [1887](//en.wikipedia.org/wiki/1887) to feed himself and raise capital for his next project.

In [1887](//en.wikipedia.org/wiki/1887), he constructed the initial [brushless](//en.wikipedia.org/wiki/brush#Electrics) alternate-current [induction motor](//en.wikipedia.org/wiki/induction_motor), which he demonstrated to the _American Institute of Electrical Engineers_ (now [IEEE](//en.wikipedia.org/wiki/IEEE)) in [1888](//en.wikipedia.org/wiki/1888). Also in 1887, he developed the principles of his [Tesla coil](//en.wikipedia.org/wiki/Tesla_coil) and began working with [George Westinghouse](//en.wikipedia.org/wiki/George_Westinghouse) at Westinghouse's [Pittsburgh](//en.wikipedia.org/wiki/Pittsburgh) labs. Westinghouse listened to his ideas for [polyphase systems](//en.wikipedia.org/wiki/polyphase_system) which would allow transmission of [AC](//en.wikipedia.org/wiki/alternating_current) electricity over large distances

The first efficient and practical electromechanical generator patented by Nikola Tesla in 1891 was U.S. Patent 447921. This is the first small rotating machine, called the alternator. Nikola Tesla's U.S. Patent 447920, "Method of Operating Arc-Lamps" (March 10, 1891), describes an alternator that produces high frequency current, around 10,000 cycles per second (hertz). His intention was to suppress the disagreeable sound of power-frequency harmonics produced by arc lamps operating on frequencies within the range of human hearing. The produced alterations (or pulsations) was in the longwave broadcasting range (very low frequency band).

## World Columbian Exposition[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-3)]

The International Exposition was held was held in Chicago in 1893 to celebrate the 400th anniversary of Christopher Columbus's discovery of the New World. It was the first to have a large portion of its grounds devoted electrical exhibits. It was an historical moment and the beginning of a revolution, as Nikola Tesla and George Westinghouse introduced the public to electrical power by providing alternating current to illuminate the Exposition. The general public observed firsthand the qualities and abilities of alternating current power. All the exhibits were from commercial enterprises. Thomas Edison, Brush, Western Electric, and Westinghouse had exhibits. General Electric Company (backed by Edison and J.P. Morgan) proposed to power the electric fair with direct current at the cost of one million dollars.

Westinghouse, armed with Tesla's alternating current system, proposed to illuminate the exposition for half that price. Tesla's high-frequency high-voltage lighting produced more efficient light with quantitatively less heat. A two-phase induction motor was driven by current from the main generators to power the system. Edison tried to prevent the use of his light bulbs in Tesla's works. Westinghouse's proposal was chosen over the inferior direct current system to power the fair. General Electric banned the use of Edison's lamps in Westinghouse's plan, in retailiation for losing the bid. Westinghouse's company quickly designed a double-stopper lightbulb (sidestepping Edison's patents) and was able to light the fair.

The Westinghouse Company displayed several polyphase systems. The exhibits included a switchboard, polyphase generators, step-up transformers, transmission line, step-down transformers, commercial size induction motors and synchronous motors, and rotary direct current converters (including an operational railway motor). The working scaled system allowed the public a view of a system of polyphase power which could be transmitted over long distances, and be utilized, including the supply of direct current. Meters and other auxiliary devices were also present.

Tesla displayed his phosphorescent lighting, powered without wires by high-frequency fields. Tesla displayed the first practical phosphorescent lamps (a precursor to fluorescent lamps). Tesla's lighting inventions exposed to high-frequency currents would bring the gases to incandescence. Tesla also displayed the first neon lights. His innovations in this type of light emission were not regularly patented.

Also among the exhibits was Tesla's demonstration, most notably the "Egg of Columbus". This device explains the principles of the rotating magnetic field and his induction motor. The Egg of Columbus consisted of a polyphase field coil underneath a plate with a copper egg positioned over the top. When the sequence of coils were energized, the magnetic field arrangement inductively created a rotation on the egg and made it stand up on end (appearing to resist gravity). On August 25, Elisha Gray introduced Tesla for a delivery of a lecture on mechanical and electrical oscillators. Tesla explained his work for efficiently increasing the work at high frequency of reciprocation. As Electrical Congress members listened, Tesla delineated mechanisms which could produce oscillations of constant periods irrespective of the pressure applied and irrespective of frictional losses and loads. He continued to explain the working mean of the production of constant period electric currents (not resorting to spark gaps or breaks), and how to produce these with mechanisms which are reliable.

The successful demonstration of alternating current lighting at the Exposition dispelled doubts about the usefulness of the polyphase alternating current system developed by Westinghouse and Tesla.

## Colorado Springs[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-4)]

In [1899](//en.wikipedia.org/wiki/1899), Tesla decided to move and began research in [Colorado Springs, Colorado](//en.wikipedia.org/wiki/), where he could have room for his high-voltage high-frequency experiments. He chose this location primarily because of the frequent thunderstorms, the high altitude (where the air, being at a lower pressure, had a lower dielectric breakdown strength, making it easier to ionize), and the dryness of the air (minimizing leakage of electric charge through insulators). Also, the property was free and electric power available from the [El Paso Power Company](//en.wikipedia.org/wiki/). Today, magnetic intensity charts also show that the ground around his lab possesses a denser magnetic field than the surrounding area. Tesla reached Colorado Springs on [May 17](//en.wikipedia.org/wiki/), 1899. Upon his arrival he told reporters that he was conducting experiments transmitting signals from [Pikes Peak](//en.wikipedia.org/wiki/) to [Paris](//en.wikipedia.org/wiki/).

Tesla kept a [diary](//en.wikipedia.org/wiki/diary) of his experiments in the Colorado Springs lab where he spent nearly nine months. It consists of 500 pages of handwritten notes and nearly 200 drawings, recorded chronologically between [June 1](//en.wikipedia.org/wiki/June_1), 1899 and [January 7](//en.wikipedia.org/wiki/January_7), [1900](//en.wikipedia.org/wiki/), as the work occurred, containing explanations of his experiments. He was developing a system for [wireless telegraphy](//en.wikipedia.org/wiki/wireless_telegraphy), telephony and the transmission of power, experimented with high-voltage electricity and the possibility of wireless transmitting and distributing large amounts of electrical energy over long distances. He also conceived a system for geophysical exploration--[seismology](//en.wikipedia.org/wiki/seismology)\--which he called _[telegeodynamics](//en.wikipedia.org/wiki/telegeodynamics)_, based on his reciprocating mechanical oscillator patented in [1894](//en.wikipedia.org/wiki/1894), and explained that a long sequence of small explosions could be used to find [ore](//en.wikipedia.org/wiki/ore) and create [earthquakes](//en.wikipedia.org/wiki/earthquake) large enough to destroy the [Earth](//en.wikipedia.org/wiki/Earth). He did not experiment with this as he felt there would not be "a desirable outcome".

## Laboratory construction[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-5)]

Tesla, a local contractor, and several assistants commenced the construction of the laboratory shortly after arriving in Colorado Springs. The lab was established on [Knob Hill](//en.wikipedia.org/wiki/Knob_Hill), east of the [Colorado School for the Deaf and Blind](//en.wikipedia.org/wiki/Colorado_School_for_the_Deaf_and_Blind) and one mile (1.6 km) east of downtown. Its primary purposes were experiments with high frequency electricity and other phenomena, and secondary--research into wireless transmission of electrical power. Tesla's design of the lab was a building fifty feet by sixty feet (15 by 18 m) with eighty-foot (24 m) ceilings. A one-hundred-forty-two foot (43 m) conducting aerial with a thirty-inch (76 cm) [copper](//en.wikipedia.org/wiki/copper)-[foil](//en.wikipedia.org/wiki/Foil_\(chemistry\)) covered [wooden](//en.wikipedia.org/wiki/wood) [ball](//en.wikipedia.org/wiki/) was erected on the [roof](//en.wikipedia.org/wiki/roof). The roof was rolled back to prevent fire from sparks and other dangerous effects of the experiments. The laboratory had sensitive instruments and equipment.

## Tuned circuits[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-6)]

Tesla also constructed many smaller resonance transformers and discovered the concept of [tuned electrical circuits](//en.wikipedia.org/wiki/tuned_electrical_circuit). He also developed a number of [coherers](//en.wikipedia.org/wiki/coherer) for separating and perceiving electromagnetic waves and designed rotating [coherers](//en.wikipedia.org/wiki/coherer) which he used to detect the unique types of electromagnetic phenomenon he observed. They had a mechanism of geared wheels driven by a coiled spring-drive mechanism which rotated small glass cylinders. These experiments were the final stage of years of work on synchronized tuned electrical circuits.

These [transceivers](//en.wikipedia.org/wiki/transceiver) were constructed to demonstrate how [signals](//en.wikipedia.org/wiki/signal) could be "tuned in". Tesla logged in his diary on [July 3](//en.wikipedia.org/wiki/July_3), [1899](//en.wikipedia.org/wiki/1899) that a separate resonance transformer tuned to the same high frequency as a larger high-voltage resonance transformer would transceive energy from the larger coil, acting as a _transmitter_ of wireless energy, which was used to confirm Tesla's patent for radio during later disputes in the courts. These air core high-frequency resonate coils were the predecessors of systems from radio to [radar](//en.wikipedia.org/wiki/radar) and [medical](//en.wikipedia.org/wiki/medical) [magnetic resonance imaging](//en.wikipedia.org/wiki/magnetic_resonance_imaging) devices.

## Propagation and resonance[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-7)]

On [July 3](//en.wikipedia.org/wiki/July_3), 1899, Tesla discovered [terrestrial](//en.wikipedia.org/wiki/Earth) [stationary waves](//en.wikipedia.org/wiki/Standing_wave) within the earth. He demonstrated that the Earth behaves as a smooth polished conductor and possesses electrical vibrations. He experimented with waves characterized by a lack of vibration at points, between which areas of maximum vibration occur periodically. These standing waves were produced by confining waves within constructed conductive boundaries. Tesla demonstrated that the Earth could respond at predescribed frequencies of electrical vibrations. At this time, Tesla realized that it was possible to transceive power around the globe. A few years later, [George Westinghouse](//en.wikipedia.org/wiki/George_Westinghouse) stopped funding Tesla's research when Tesla showed him that he could offer free electricity to the whole world by simply "ramming a stick in the earth in your backyard". Westinghouse said he would go bankrupt if that happened.

Tesla conducted experiments contributing to the understanding of electromagnetic propagation and the Earth's resonance. It is well documented (from various photos from the time) that he lit hundreds of lamps wirelessly at a distance of up to twenty-five miles (40 km). He transmitted signals several kilometres and lit neon tubes conducting through the ground. He researched ways to transmit energy wirelessly over long distances (utilizing the [ionosphere](//en.wikipedia.org/wiki/ionosphere) and the [ground](//en.wikipedia.org/wiki/ground)'s [telluric currents](//en.wikipedia.org/wiki/telluric_current) via [transverse waves](//en.wikipedia.org/wiki/), to a lesser extent, and, more readily, [longitudinal waves](//en.wikipedia.org/wiki/longitudinal_wave)). He transmitted extremely low frequencies through the ground as well as between the Earth's surface and the [Kennelly-Heaviside layer](//en.wikipedia.org/wiki/Kennelly-Heaviside_layer). He received patents on wireless that developed [standing waves](//en.wikipedia.org/wiki/standing_wave) by this method. In his experiments, he made mathematical calculations and computations based on his experiments and discovered that the resonant frequency of the Earth was approximately 8 Hz ([Hertz](//en.wikipedia.org/wiki/Hertz)). In the [1950s](//en.wikipedia.org/wiki/1950s), researchers confirmed [resonant frequency](//en.wikipedia.org/wiki/resonant_frequency) was in this range (interesting to note, [Theta](//en.wikipedia.org/wiki/Theta) [brain waves](//en.wikipedia.org/wiki/brain_waves) also cycle in this range).

## Cosmic waves[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-8)]

In the Colorado Springs lab, Tesla recorded what he concluded were [extraterrestrial](//en.wikipedia.org/wiki/extraterrestrial) radio signals and announced his findings in some of the scientific journals of the time. [[4]](http://www.teslasociety.com/mars2.htm) His announcements and data were rejected by the scientific community who did not believe him. He notes measurements of repetitive signals from his receiver which are substantially different from the signals he had noted from storms and earth noise. Specifically, he later recalled that the signals appeared in groups of clicks 1, 2, 3, and 4 clicks together. He stated in the article "A Giant Eye to See Round the World", of [25 February](//en.wikipedia.org/wiki/February) [1923](//en.wikipedia.org/wiki/1923), that:

    "_Twenty-two years ago, while experimenting in Colorado with a wireless power plant, I obtained extraordinary experimental evidence of the existence of life on Mars. I had perfected a wireless receiver of extraordinary sensitiveness, far beyond anything known, and I caught signals which I interpreted as meaning 1--2--3--4. I believe the Martians used numbers for communication because numbers are universal_." _Albany Telegram — [25 February](//en.wikipedia.org/wiki/25_February) [1923](//en.wikipedia.org/wiki/1923)_ [[5]](http://www.tesla.hu/tesla/articles/19230225.doc)

Clearly, Tesla felt the signal groups originated on the planet [Mars](//en.wikipedia.org/wiki/Mars_\(planet\)). In 1996 Corum and Corum published an analysis of [Jovian plasma](//en.wikipedia.org/wiki/Jovian_plasma) [torus](//en.wikipedia.org/wiki/torus) signals which indicate that there was a correspondence between the setting of Mars at Colorado Springs, and the cessation of signals from Jupiter in the summer of 1899 when Tesla was there. [[6]](http://www.teslasociety.com/mars.pdf) Further, analysis by the Corums indicate that Tesla's transceiver was sensitive in the 18 kHz gap in the [Kennelly-Heaviside layer](//en.wikipedia.org/wiki/ionosphere) which would have allowed that reception from Jupiter. Therefore, there is evidence the signals Tesla noticed came from [Jupiter](//en.wikipedia.org/wiki/Jupiter_\(planet\)), among other possible sources. Tesla spent the latter part of his life trying to signal Mars.

It is important to recognize that when he says he "recorded" these signals, it is meant that he wrote down the data and his impressions of what he had heard. He did release reports at the time. Tesla’s initial announcement of the existence of extraterrestrial radio signals was in 1899. [[7]](http://www.teslasociety.com/cosmos.htm) In March of 1907, Tesla wrote about signaling to Mars in Harvard Magazine and how it was a problem of electrical engineering. [[8]](http://www.teslasociety.com/signaltomars.htm) Additional descriptions come from remembrances twenty years later. All this was met with resistance and disbelief by his contemporaries.

## Colorado departure[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-9)]

Tesla left Colorado Springs on [January 7](//en.wikipedia.org/wiki/January_7), [1900](//en.wikipedia.org/wiki/1900). The lab was torn down, broken up, and its contents sold to pay debts. The Colorado experiments prepared Tesla for his next project, the establishment of a wireless power transmission facility that would be known as Wardenclyffe.

On [March 21](//en.wikipedia.org/wiki/March_21), [1900](//en.wikipedia.org/wiki/1900), Tesla was granted US685012 [patent](//en.wikipedia.org/wiki/patent) for the means for increasing the intensity of electrical oscillations. The United States Patent Office classification system currently denotes that this patent pretains to superconductivity technology (Class 505/825). Within this patent it describes the increase intensity and duration of electric oscillations of a [low temperature](//en.wikipedia.org/wiki/Cryogenics) [resonating](//en.wikipedia.org/wiki/resonator) circuit. [w:Carl von LindeCarl von Linde](//en.wikipedia.org/wiki/Carl_von_LindeCarl_von_Linde) and [William Hampson](//en.wikipedia.org/wiki/William_Hampson), both commercial researchers, nearly at the same time filed for patents on the Joule-Thomson effect. Linde's patent was the climax of 20 years of systematic investigation of establish facts, using a [regenerative](//en.wikipedia.org/wiki/regeneration) counterflow method. Hampson's designs was also of a regenerative method. It is believed that Tesla had intended that Linde's machine would be used to attain the cooling agents.

## Wardenclyffe Tower[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-10)]

Tesla began planning the [Wardenclyffe Tower](//en.wikipedia.org/wiki/Wardenclyffe_Tower) facility ca. 1898, and in 1901, construction began on the land near Long Island Sound. Architect Stanford White designed the Wardenclyffe facility main building. The tower was designed by W.D. Crow, an associate of White. Funding for Tesla's project was provided by influential industrialists and other venture capitalists. The project was initially backed by the wealthy J. P. Morgan (he had a substantial investment in the facility, initially investing $150,000).

In June 1902, Tesla moved his laboratory operations from his Houston Street laboratory to Wardenclyffe. However, in 1903, when the tower structure was near completion, it was still not yet functional due to last-minute design changes that introduced in an unintentional defect. When Morgan wanted to know "Where can I put the meter?", Tesla had no answer. Tesla's vision of free power did not agree with Morgan's worldview. Construction costs eventually exceeded the money provided by Morgan, and additional financiers were reluctant to come forth. By July 1904, Morgan (and the other investors) finally decided they would not provide any additional financing. Morgan also encouraged other investors to avoid the project. In May 1905, Tesla's patents on alternating current motors and other methods of power transmission expired, halting royalty payments and causing a severe reduction of funding to the Wardenclyffe Tower. In an attempt to find alternative funding, Tesla advertised the services of the Wardenclyffe facility, but he met with little success. By this time, Tesla had also designed the Tesla turbine at Wardenclyffe and produced Tesla coils for sale to various businesses.

By 1905, since Tesla could not find any more backers, most of the site's activity had to be shut down. The main hall continued to be used for blackface minstrel shows until October of that year. Employees were laid off in 1906, but parts of the building remained in use until 1907. In 1908, the property was foreclosed for the first time. Tesla procured a new mortgage from the proprietor of the Waldorf-Astoria Hotel, George C. Boldt. The facility was partially abandoned around 1911, the tower structure eventually becoming deteriorated. Between 1912 and 1915, Tesla's finances unraveled, and when the funders wanted to know how they were going to recapture their investments, Tesla was unable to give satisfactory answers. Newspaper headlines of the time labeled it "Tesla's million-dollar folly." The facility's main building was breached and vandalized around this time. Collapse of the Wardenclyffe project may have contributed to the mental breakdown Tesla experienced during this period. Coupled to the personal tragedy of Wardenclyffe was the earlier 1895 unexplained fire in Tesla's Houston Street laboratory. In this fire, he lost much of his equipment, notes and documents. This produced a state of severe depression for Tesla.

In 1915, legal ownership of the Wardenclyffe property was transferred to George Boldt for a $20,000 debt. Demolition and salvaging of the tower occurred in 1917. However, the main building remains standing to this day. Tesla was not in New York during the tower's destruction. George Boldt wished to make the property available for sale. New York papers reported that the tower had been destroyed by order of the government to prevent its use by foreign agents. In 1917, the United States government may have aided the destruction of the Wardenclyffe Tower, ostensibly because it was believed it could provide a navigational landmark for German submarines. The facts neither support nor discount either claim. On April 20, 1922 Tesla lost an appeal of judgment versus his backers in the second foreclosure. This effectively locked Tesla out of any future development of the facility.

## Fight for radio[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-11)]

In [1904](//en.wikipedia.org/wiki/1904), the US Patent Office reversed its decision and awarded [Guglielmo Marconi](//en.wikipedia.org/wiki/Guglielmo_Marconi) the patent for [radio](//en.wikipedia.org/wiki/radio). Tesla began his fight to re-acquire his radio patent. Later in [1909](//en.wikipedia.org/wiki/1909), Marconi was awarded the [Nobel Prize](//en.wikipedia.org/wiki/Nobel_Prize) for radio. Tesla was deeply resentful. So in [1915](//en.wikipedia.org/wiki/), Tesla filed a [lawsuit](//en.wikipedia.org/wiki/lawsuit) against Marconi.

Tesla always disputed the claim that [Marconi](//en.wikipedia.org/wiki/Guglielmo_Marconi) invented radio and he gave a simple reason for this position. It was that radio is not an invention: "It was evident to me in [1888](//en.wikipedia.org/wiki/1888) that wireless transmission of energy, if it could ever be accomplished, is not an invention; it is an art. Bell's telephone, Edison's phonograph, or my [induction motor](//en.wikipedia.org/wiki/induction_motor) were inventions, but the wireless transmission of energy is an art that requires a great many inventions in combination.", (Nikola Tesla, 1916, in Ed. Anderson, Leland, 'Nikola Tesla On His Work With Alternating Currents And Their Application to Wireless Telegraphy, Telephony, and Transmission of Energy, Published 1992). Seen in this context, some believe that it is Tesla's lecture and patent record from 1888 onwards that contains the fundamental information on the '....great many inventions...' that form the basis for modern radio and wireless technology.

An ongoing lawsuit regarding the patent battle was finally resolved in Tesla's favor in [1944](//en.wikipedia.org/wiki/1944), one year after his death. This decision was based on the facts of the prior work existing before the establishment of Marconi's patent. At the time, the [United States Army](//en.wikipedia.org/wiki/United_States_Army) was involved in a patent infringement lawsuit with Marconi regarding radio, leading some to posit that the government granted Tesla and others the formal recognition in order to nullify any claims Marconi would have to compensation (as the earlier award to Marconi nullified any claims Tesla would have for compensation).

## Nobel rumors[[edit](/w/index.php?title=Nikola_Tesla/Middle_years&action=edit&section=T-12)]

Due to the fact that the [Nobel Prize](//en.wikipedia.org/wiki/) was awarded to Marconi for radio in [1909](//en.wikipedia.org/wiki/1909), it was believed that Tesla and Edison were to share the [Nobel Prize of 1912](//en.wikipedia.org/wiki/Nobel_Prize_in_Physics) (and, later alone, in [Nobel Prize of 1915](//en.wikipedia.org/wiki/Nobel_Prize_in_Physics)). Tesla's rumored nominations for the Nobel Prize in Physics was primarily for his experiments with tuned circuits using high-voltage high-frequency resonant transformers. It was possible that Tesla was told of the plans of the physics award committee and let it be known that he would not share the award with Edison.

## Later years[[edit](/w/index.php?title=Nikola_Tesla/Later_years&action=edit&section=T-1)]

Prior to the [First World War](//en.wikipedia.org/wiki/World_War_I), Tesla looked overseas for investors to fund his research. When the war started, Tesla lost funding he was receiving from his [European](//en.wikipedia.org/wiki/europe) patents. Wardenclyffe Tower was also demolished towards the end of WWI. Tesla had predicted the relevant issues of the post-[World War I](//en.wikipedia.org/wiki/World_War_I) environment (a war which theoretically ended) in a printed article ([December 20](//en.wikipedia.org/wiki/December_20), [1914](//en.wikipedia.org/wiki/1914)). Tesla believed that the [League of Nations](//en.wikipedia.org/wiki/League_of_Nations) was not a remedy for the times and issues. In [1915](//en.wikipedia.org/wiki/1915), Tesla filed a lawsuit against Marconi attempting, unsuccessfully, to obtain a court injunction against the claims of Marconi. Around [1916](//en.wikipedia.org/wiki/1916), Tesla filed for [bankruptcy](//en.wikipedia.org/wiki/bankruptcy) because he owed so much in back taxes. He was living in poverty.

Tesla started to exhibit pronounced symptoms of [obsessive-compulsive disorder](//en.wikipedia.org/wiki/obsessive-compulsive_disorder) in the years following. He became obsessed with the number three. He often felt compelled to walk around a block three times before entering a building, demanded a stack of three folded cloth napkins beside his plate at every meal, etc. The nature of OCD was little understood at the time and no treatments were available, so his symptoms were considered by some to be evidence of partial [insanity](//en.wikipedia.org/wiki/insanity) and this probably hurt what was left of his reputation. This obsessive-compulsive behavior may have originated from the observations over repeated [polyphase systems](//en.wikipedia.org/wiki/polyphase_system) in nature that Tesla researched.

At this time, he was staying at the [Waldorf-Astoria Hotel](//en.wikipedia.org/wiki/Waldorf-Astoria_Hotel), renting in an arrangement for deferred payments. Eventually, the Wardenclyffe deed was turned over to [George Boldt](//en.wikipedia.org/wiki/George_Boldt), proprietor of the Waldorf-Astoria to pay a $20,000 debt. In [1917](//en.wikipedia.org/wiki/1917), around the time that the Wardenclyffe Tower was demolished by Boldt to make the land a more viable real estate asset, Tesla received [AIEE](//en.wikipedia.org/wiki/AIEE)'s highest honor, the [Edison Medal](//en.wikipedia.org/wiki/Edison_Medal). The irony of this honor was probably not lost on Tesla.

## Radar development[[edit](/w/index.php?title=Nikola_Tesla/Later_years&action=edit&section=T-2)]

Tesla, in [August](//en.wikipedia.org/wiki/August) [1917](//en.wikipedia.org/wiki/1917), first established principles regarding frequency and power level for the first primitive [radar](//en.wikipedia.org/wiki/radar) units in [1934](//en.wikipedia.org/wiki/1934). [Emile Girardeau](//en.wikipedia.org/wiki/Emile_Girardeau), working with the first [French](//en.wikipedia.org/wiki/France) radar systems, stated he was building radar systems "_conceived according to the principles stated by Tesla_". By the [twenties](//en.wikipedia.org/wiki/1920), Tesla was reportedly negotiating with the [United Kingdom](//en.wikipedia.org/wiki/United_Kingdom) government under Prime Minister [Chamberlain](//en.wikipedia.org/wiki/Neville_Chamberlain) about a ray system. Tesla had also stated that efforts had been made to steal the "death ray" (though they had failed). The Chamberlain government was removed, though, before any final negotiations occurred. The incoming [Baldwin](//en.wikipedia.org/wiki/Stanley_Baldwin) government found no use for Tesla's suggestions and ended negotiations.

## 1930s[[edit](/w/index.php?title=Nikola_Tesla/Later_years&action=edit&section=T-3)]

On Tesla's seventy-fifth [birthday](//en.wikipedia.org/wiki/birthday) in [1931](//en.wikipedia.org/wiki/1931), [Time magazine](//en.wikipedia.org/wiki/Time_magazine) put him on its cover. [[9]](http://www.teslasociety.com/time.jpg) The cover caption noted his contribution to electrical power generation. In [1935](//en.wikipedia.org/wiki/1935), many of Marconi's patents relating to the radio were declared invalid by the [United States Court of Claims](//en.wikipedia.org/wiki/United_States_Court_of_Claims). The Court of Claims decided that the prior work of Tesla (specifically US645576 and US649621) had anticipated Marconi's later works. Tesla got his last patent in [1928](//en.wikipedia.org/wiki/1928) on [January 3](//en.wikipedia.org/wiki/Januuary_3), an apparatus for aerial transportation which was the first instance of [VTOL](//en.wikipedia.org/wiki/Vertical_take-off_and_landing) [aircraft](//en.wikipedia.org/wiki/aicraft). In [1934](//en.wikipedia.org/wiki/1934), Tesla wrote to consul Janković of his homeland. The letter contained the message of gratitude to [Mihajlo Pupin](//en.wikipedia.org/wiki/Mihajlo_Pupin) who initiated a donation scheme by which American companies could support Tesla. Tesla refused the assistance, and chose to live by a modest pension received from [Kingdom of Yugoslavia](//en.wikipedia.org/wiki/Kingdom_of_Yugoslavia) and to continue researching.

## Field theories[[edit](/w/index.php?title=Nikola_Tesla/Later_years&action=edit&section=T-4)]

When he was eighty-one, Tesla stated he had completed a [Dynamic Theory of Gravity](//en.wikipedia.org/wiki/dynamic_theory_of_gravity). He stated that it was "_worked out in all details_" and hoped to give to the world the theory soon. [[10]](http://www.tesla.hu/tesla/articles/19370710.doc) The theory was never [published](//en.wikipedia.org/wiki/Publishing). At the time of his announcement, it was considered by the scientific establishment to exceed the bounds of reason. Some believe that Tesla never fully developed the Unified Field Theory, nor that any physicist in the years since it was first postulated.

While Tesla had "worked out a dynamic theory of gravity" that he soon hoped to give to the world, he died before he publicized any details. Few details were revealed by Tesla about his theory in the announcement. Tesla's critique in the announcement was the opening clash between him and modern experimental physics. Tesla may have viewed his principles in such a manner as to not be in conflict with other modern theories (besides Einstein's). Tesla's theory is ignored by some [researchers](//en.wikipedia.org/wiki/research) (and mainly disregarded by [physicists](//en.wikipedia.org/wiki/physicist)).

The bulk of the theory was developed between [1892](//en.wikipedia.org/wiki/1892) and [1894](//en.wikipedia.org/wiki/1894), during the period that he was conducting experiments for with [high frequency](//en.wikipedia.org/wiki/high_frequency) and high [potential](//en.wikipedia.org/wiki/potential) electromagnetism and patenting devices for their utilization. It was completed, according to Tesla, by the end of the 1930s. Tesla's theory explained gravity using [electrodynamics](//en.wikipedia.org/wiki/electrodynamics) consisting of [transverse waves](//en.wikipedia.org/wiki/traverse_wave) (to a lesser extent) and [longitudinal waves](//en.wikipedia.org/wiki/longitudinal_wave) (for the majority). Reminiscent of [Mach's principle](//en.wikipedia.org/wiki/Mach%27s_principle), Tesla stated in 1925 that,

    _There is no thing endowed with life - from man, who is enslaving the elements, to the nimblest creature - in all this world that does not sway in its turn. Whenever action is born from force, though it be infinitesimal, the cosmic balance is upset and the universal motion results._

Tesla, concerning [Albert Einstein](//en.wikipedia.org/wiki/Albert_Einstein)'s [relativity theory](//en.wikipedia.org/wiki/Theory_of_relativity), stated that '...the relativity theory, by the way, is much older than its present proponents. It was advanced over 200 years ago by my illustrious countryman [Boskovic](//en.wikipedia.org/wiki/Ruder_Boskovic), the great philosopher, who, not withstanding other and multifold obligations, wrote a thousand volumes of excellent literature on a vast variety of subjects. [Boskovic](//en.wikipedia.org/wiki/Ruder_Boskovic) dealt with relativity, including the so-called time-space continuum...', (1936 unpublished interview, quoted in Anderson, L, ed. Nikola Tesla: Lecture Before the New York Academy of Sciences: The Streams of Lenard and Roentgen and Novel Apparatus for Their Production, [6 April](//en.wikipedia.org/wiki/6_April) [1897](//en.wikipedia.org/wiki/1897), reconstructed 1994).

Tesla was critical of Einstein's relativity work, '...[a] magnificent mathematical garb which fascinates, dazzles and makes people blind to the underlying errors. The theory is like a beggar clothed in purple whom ignorant people take for a king...., its exponents are brilliant men but they are metaphysicists rather than scientists...', (New York Times, [11 July](//en.wikipedia.org/wiki/11_July) [1935](//en.wikipedia.org/wiki/1935), p23, c.8).

Tesla also stated that 'I hold that space cannot be curved, for the simple reason that it can have no properties. It might as well be said that God has properties. He has not, but only attributes and these are of our own making. Of properties we can only speak when dealing with matter filling the space. To say that in the presence of large bodies space becomes curved is equivalent to stating that something can act upon nothing. I, for one, refuse to subscribe to such a view.', (New York Herald Tribune, [11 September](//en.wikipedia.org/wiki/11_September) [1932](//en.wikipedia.org/wiki/1932))

## Death and afterwards[[edit](/w/index.php?title=Nikola_Tesla/Later_years&action=edit&section=T-5)]

Tesla died alone in the hotel [New Yorker](//en.wikipedia.org/wiki/New_Yorker_hotel) of [heart failure](//en.wikipedia.org/wiki/heart_failure), some time between the evening of [January 5](//en.wikipedia.org/wiki/January_5) and the morning of [January 8](//en.wikipedia.org/wiki/January_8), [1943](//en.wikipedia.org/wiki/1943). Despite selling his AC electricity patents, he was essentially destitute and died with significant debts.

At the time of his death, Tesla had been working on some form of _[teleforce](//en.wikipedia.org/wiki/teleforce)_ weapon, or _[death ray](//en.wikipedia.org/wiki/death_ray)_, the secrets of which he had offered to the [United States War Department](//en.wikipedia.org/wiki/United_States_Department_of_Defense) on the morning of [5 January](//en.wikipedia.org/wiki/5_January). It appears that his proposed death ray was related to his research into [ball lightning](//en.wikipedia.org/wiki/ball_lightning) and [plasma](//en.wikipedia.org/wiki/plasma). He was found dead three days later and, after the FBI was contacted by the War Department, his papers were declared to be top secret.

Immediately after Tesla's death became known, the [FBI](//en.wikipedia.org/wiki/Federal_Bureau_of_Investigation) instructed the [Office of Alien Property](//en.wikipedia.org/wiki/Office_of_Alien_Property) to take possession of his papers and property, despite his US citizenship. All of his personal effects were seized on the advice of presidential advisors. [J. Edgar Hoover](//en.wikipedia.org/wiki/J._Edgar_Hoover) declared the case "most secret", because of the nature of Tesla's inventions and patents. Tesla's Serbian-Orthodox family and the Yugoslav embassy struggled with American authorities to gain these items after his death due to the potential significance of some of his research. Eventually, his nephew, Sava Kosanovich, got possession of some of his personal effects (which are now housed in the [wikipedia:Nikola Tesla Museum](//en.wikipedia.org/wiki/Nikola_Tesla_Museum) in [Belgrade, Yugoslavia](//en.wikipedia.org/wiki/Belgrade,_Yugoslavia)). Tesla's [funeral](//en.wikipedia.org/wiki/funeral) took place on [January 12](//en.wikipedia.org/wiki/January_12), [1943](//en.wikipedia.org/wiki/1943) at the [Cathedral of Saint John the Divine](//en.wikipedia.org/wiki/Cathedral_of_Saint_John_the_Divine) in [Manhattan](//en.wikipedia.org/wiki/Manhattan), [wikipedia:New York City](//en.wikipedia.org/wiki/New_York_City).

In [1976](//en.wikipedia.org/wiki/1976), a large [bronze](//en.wikipedia.org/wiki/bronze) statue of Tesla was erected at Niagara Falls State Park. A similar statue was also erected in the Tesla's hometown of Gospic in the 1981. The statue in Gospic was dynamited by the Croatian forces in 1991.

Perhaps because of Tesla's personal eccentricity and the dramatic nature of his demonstrations, [conspiracy theories](//en.wikipedia.org/wiki/conspiracy_theory) about applications of his work persist. The common Hollywood stereotype of the "[mad scientist](//en.wikipedia.org/wiki/mad_scientist)" mirrors Tesla's real-life persona, or at least a caricature of it—which may be no accident considering that many of the earliest such movies (including the first movie version of [Mary Shelley's](//en.wikipedia.org/wiki/Mary_Shelley) [Frankenstein](//en.wikipedia.org/wiki/Frankenstein)) were produced by Tesla's old rival, Thomas Edison. There are at least two films describing Tesla's life. In the first, arranged for TV, Tesla was portrayed by [Rade Šerbedžija](//en.wikipedia.org/wiki/Rade_Serbedzija). In [1980](//en.wikipedia.org/wiki/1980), [Orson Welles](//en.wikipedia.org/wiki/Orson_Welles) produced a [Yugoslavian](//en.wikipedia.org/wiki/Socialist_Federal_Republic_of_Yugoslavia) film named _Tajna Nikole Tesle_ (The Secret of Nikola Tesla), in which Welles himself played the part of Tesla's patron, [George Westinghouse](//en.wikipedia.org/wiki/George_Westinghouse).

## Seized records[[edit](/w/index.php?title=Nikola_Tesla/Later_years&action=edit&section=T-6)]

According to [FBI](//en.wikipedia.org/wiki/FBI) [documents](http://foia.fbi.gov/foiaindex/tesla.htm) acquired via [FOIA](//en.wikipedia.org/wiki/FOIA) request, the sum of Tesla's possessions ("consisting of about two truckloads of material... [and] approximately thirty barrels and bundles") were seized, upon his death in [1943](//en.wikipedia.org/wiki/1942), by agents of the (now defunct) [Office of Alien Property Custodian](//en.wikipedia.org/wiki/Office_of_Alien_Property_Custodian). One document states that "[he] is reported to have some 80 trunks in different places containing transcripts and plans having to do with his experiments..."

## External resources[[edit](/w/index.php?title=Nikola_Tesla/References&action=edit&section=T-1)]

_Tesla writings_

  * Tesla, Nikola, _[My Inventions](http://www.teslaplay.com/autobody.htm)_, Electrical Experimenter magazine, Feb, June, and Oct, 1919. [ISBN 0910077002](/wiki/Special:BookSources/0910077002) (teslaplay.com)
  * Tesla, Nikola, _[My Inventions](http://www.rastko.org.yu/istorija/tesla/ntesla-autobiography.html)_, Electrical Experimenter magazine, Feb, June, and Oct, 1919. (rastko.org)
  * Tesla, Nikola, [The Problem of Increasing Human Energy](http://www.tfcbooks.com/tesla/energy.htm), _Century_ Illustrated Magazine, June 1900. (See also [picture thinking](//en.wikipedia.org/wiki/picture_thinking).)
  * Tesla, Nikola, “Mechanical and Electrical Oscillators,” printed in Nikola Tesla’s Teleforce and Telegeodynamic Proposals_". (ed., L.I. Anderson; Twenty First Century Books, 1998)._
  * Tesla, Nikola, "_A New System of Alternate Current Motors and Transformers_". AIEE Transactions, Vol. 5, 1888, pp. 305-327.
  * Tesla, Nikola, "_[The True Wireless](http://www.tfcbooks.com/tesla/wireless.htm)_". Electrical Experimenter, May 1919. ([also at pbs.org](http://www.pbs.org/tesla/res/res_art06.html))
  * Tesla, Nikola, "_[Talking with Planets](http://earlyradiohistory.us/1901talk.htm)_". Collier's Weekly, February 19, 1901. (EarlyRadioHistory.us)
  * Tesla, Nikola, "_A New System of Alternate Current Motors and Transformers_". AIEE Transactions, Vol. 5, 1888, pp. 305-327. (Reprinted in the Proceedings of the IEEE, Vol. 72, 1984, pp. 165-173.)
  * Tesla, Nikola, "_Improved Apparatus for the Production of Powerful Electrical Vibrations; Novel High Frequency Measurement Techniques_". Nikola Tesla: Lecture Before the New York Academy of Sciences (ed., L.I. Anderson; Twenty First Century Books, 1994).

_Biographical_

  * Martin, Thomas Commerford, ""The Inventions, Researches, and Writings of Nikola Tesla"", reprinted by Barnes & Noble, 1995 [ISBN 0-88029-812-X](/wiki/Special:BookSources/088029812X)
  * Cheney, Margaret & Uth, Robert, ""Tesla, Master of Lightning"", published by Barnes & Noble, 1999 [ISBN 0-7607-1005-8](/wiki/Special:BookSources/0760710058)
  * O'Neill, John J., "_[Prodigal Genius: The Life of Nikola](http://www.rastko.org.yu/istorija/tesla/oniell-tesla.html)_", 1944. [ISBN 0913022403](/wiki/Special:BookSources/0913022403) ([also at uncletaz.com](http://www.uncletaz.com/library/scimath/tesla/); [also other items at the site])
  * Krumme, Katherine, _[Mark Twain and Nikola Tesla: Thunder and Lightning](http://www.nuc.berkeley.edu/dept/Courses/E-24/E-24Projects/Krumme1.pdf)_. December 4, 2000 (PDF)
  * Kelley, Thomas Lee, "_[The enigma of Nikola Tesla](http://www.ajnpx.com/pdf/NaturalPhil/Tesla/TeslaComplete.pdf)_". Arizona State University. [Thesis] (PDF)

_General research_

  * Hoover, John Edgar, et al., [FOIA FBI files](http://foia.fbi.gov/foiaindex/tesla.htm), 1943.
  * Pratt, H., "_Nikola Tesla 1856-1943_", Proceedings of the IRE, Vol. 44, September, 1956.
  * W.C. Wysock, J.F. Corum, J.M. Hardesty and K.L. Corum, "_[Who Was The Real Dr. Nikola Tesla](http://www.ttr.com/Who%20Was%20Dr%20Tesla.pdf)?_ (A Look At His Professional Credentials)". Antenna Measurement Techniques Association, posterpaper, October 22-25, 2001 (PDF)
  * Roguin, Ariel, "_Historical Note: Nikola Tesla: The man behind the magnetic field unit_". J. Magn. Reson. Imaging 2004;19:369-374. © 2004 Wiley-Liss, Inc.
  * Sellon, J. L., "_The impact of Nikola Tesla on the cement industry_". Behrent Eng. Co., Wheat Ridge, CO. Cement Industry Technical Conference. 1997. XXXIX Conference Record., 1997 IEEE/PC. Page(s) 125-133. [ISBN 0-7803-3962-2](/wiki/Special:BookSources/0780339622)
  * Valentinuzzi, M.E., "_Nikola Tesla: why was he so much resisted and forgotten?_" Inst. de Bioingenieria, Univ. Nacional de Tucuman; Engineering in Medicine and Biology Magazine, IEEE. Jul/Aug 1998, 17:4, p 74-75. ISSN 0739-5175

_Cosmic Rays_

  * Waser, André, "_[Nikola Tesla’s Radiations and the Cosmic Rays](http://www.aw-verlag.ch/Documents/TeslasRadiationsAndCosmicRays01.PDF)_". (PDF)

_Views on War_

  * Secor, H. Winfield, "_Tesla's views on Electricity and the War_", Electrical Experimenter, Volume 5, Number 4, August, 1917.
  * Florey, Glen, "_Tesla and the Military_". Engineering 24, December 5, 2000.

_Stationary and scalar waves_

  * Corum, K. L., J. F. Corum, "_Nikola Tesla, Lightning Observations, and Stationary Waves_". 1994.
  * Corum, K. L., J. F. Corum, and A. H. Aidinejad, "_Atmospheric Fields, Tesla's Receivers and Regenerative Detectors_". 1994.
  * Meyl, Konstantin, H. Weidner, E. Zentgraf, T. Senkel, T. Junker, and P. Winkels, "_Experiments to proof the evidence of scalar waves Tests with a Tesla reproduction_". Institut für Gravitationsforschung (IGF), Am Heerbach 5, D-63857 Waldaschaff.

_Radio waves_

  * Anderson, L. I., "_John Stone Stone on Nikola Tesla’s Priority in Radio and Continuous Wave Radiofrequency Apparatus_". The Antique Wireless Association Review, Vol. 1, 1986, pp. 18-41.
  * Anderson, L. I., "_Priority in Invention of Radio, Tesla v. Marconi_". Antique Wireless Association monograph, March 1980.
  * Marincic, A., and D. Budimir, "_Tesla's contribution to radiowave propagation_". Dept. of Electron. Eng., Belgrade Univ. (5th International Conference on Telecommunications in Modern Satellite, Cable and Broadcasting Service, 2001. TELSIKS 2001. pg., 327-331 vol.1) [ISBN 0-7803-7228-X](/wiki/Special:BookSources/078037228X)
  * Page, R.M., "_The Early History of Radar_", Proceedings of the IRE, Volume 50, Number 5, May, 1962, (special 50th Anniversary Issue).

_Induction motor_

  * C Mackechnie Jarvis "_Nikola Tesla and the induction motor_". 1970 Phys. Educ. 5 280-287.

_Other_

  * "_[Giant Eye to See Round the World](http://www.tesla.hu/tesla/articles/19230225.doc)_" (DOC)
  * Nichelson, Oliver, "_Nikola Tesla's Energy Generation Designs_", Eyring, Inc., Provo, Utah.
  * Nichelson, Oliver, "_The Thermodynamics of Tesla's Fuelless Electrical generator_". American Fork, Utah. (American Chemical Society, 1993. 2722-5/93/0028-63)
  * [Grotz, Toby](//en.wikipedia.org/wiki/Toby_Grotz), "_[The Influence of Vedic Philosophy on Nikola Tesla's Understanding of Free Energy](http://www.sumeria.net/free/sanskrit.html)_".
  * Tesla, Nikola, "_[My Inventions](http://www.rastko.org.yu/istorija/tesla/ntesla-autobiography.html) (An Autobiography)_", Electrical Experimenter magazine, Feb, June, and Oct, 1919.
  * O'Neill, John J., "_[Prodigal Genius: The Life of Nikola](http://www.rastko.org.yu/istorija/tesla/oniell-tesla.html)_", 1944. [ISBN 0913022403](/wiki/Special:BookSources/0913022403)
  * W.C. Wysock, J.F. Corum, J.M. Hardesty and K.L. Corum, "[Who Was The Real Dr. Nikola Tesla](http://www.ttr.com/Who%20Was%20Dr%20Tesla.pdf) _? (A Look At His Professional Credentials)". Antenna Measurement Techniques Association, posterpaper, October 22-25, 2001 (PDF)_
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Nikola_Tesla/Print_version&oldid=1513313](http://en.wikibooks.org/w/index.php?title=Nikola_Tesla/Print_version&oldid=1513313)" 

[Category](/wiki/Special:Categories): 

  * [Nikola Tesla](/wiki/Category:Nikola_Tesla)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Nikola+Tesla%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Nikola+Tesla%2FPrint+version)

### Namespaces

  * [Book](/wiki/Nikola_Tesla/Print_version)
  * [Discussion](/w/index.php?title=Talk:Nikola_Tesla/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Nikola_Tesla/Print_version)
  * [Edit](/w/index.php?title=Nikola_Tesla/Print_version&action=edit)
  * [View history](/w/index.php?title=Nikola_Tesla/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Nikola_Tesla/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Nikola_Tesla/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Nikola_Tesla/Print_version&oldid=1513313)
  * [Page information](/w/index.php?title=Nikola_Tesla/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Nikola_Tesla%2FPrint_version&id=1513313)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Nikola+Tesla%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Nikola+Tesla%2FPrint+version&oldid=1513313&writer=rl)
  * [Printable version](/w/index.php?title=Nikola_Tesla/Print_version&printable=yes)

  * This page was last modified on 30 May 2009, at 17:58.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Nikola_Tesla/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
