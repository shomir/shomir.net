# Effective Reasoning/Print version

From Wikibooks, open books for an open world

< [Effective Reasoning](/wiki/Effective_Reasoning)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Effective Reasoning](/wiki/Effective_Reasoning)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Effective_Reasoning/Print_version&action=purge&printable=yes) this page.

Everyone reasons. Humans are reasoning animals. Further, humans reason with words and symbols.

To reason is to use thought to come to some conclusion. Reasoning can be done alone or in groups.

Unfortunately, being human does not assure any of us that we will reason effectively. In other words, reasoning does not have to produce particularly useful results. Productive reasoning is both an art and a science.

I hope to present here information that will allow most to develop both the skill and the knowledge to reason effectively.

Particularly, I will be discussing informal reasoning. For a complete exposition of effective reasoning, see, also, the Wikibooks [Introduction to Moral Reasoning](/wiki/Introduction_to_Moral_Reasoning), [Formal Logic](/wiki/Formal_Logic), and [Systems of Logic](/w/index.php?title=Systems_of_Logic&action=edit&redlink=1).

# Potential Outline:

## Effective Reasoning

Reason is what makes us human human! It is our USP (unique survival process)

Naturally, the human animal is weak, slow and lacking strong jaws or sharp claws. Yet somehow our species has come to dominate the world and everything in it, short of Mother Nature herself. How did this happen?

## Evolutionary Philosophy

This is a controversial topic which proposes that, like our cousins, the great apes, we were once a forest dwelling species that abandoned or was excluded from "the Garden of Eden" and had to survive by eating grass and carrion, which somehow transmuted into wheat, rice and bread along with fishing animal hunting and herding.

The key to this transformation was (allegedly) the mastery of fire and weaponry, both of which are highly dangerous to a social species such as _homo sapiens_. Learning to make controllable fire and reliable tools requires high levels of communication, so emotional responses developed so that language and reason emerged.

To discover more on this, try first the work of the polymath Noam Chomsky, a professor in the Department of Linguistics & Philosophy at Massachusetts Institute of Technology (MIT) USA. He is a linguist, philosopher, cognitive scientist, logician, historian, political critic, and publisher of some very controversial critiques of the modern world.

## Formal reasoning

Formal reasoning is concerned only with the forms of arguments. Certain forms of arguments have been identified which are valid. In other words, if the original statements (or premises) in those arguments are true, then the conclusions must necessarily be true also. Therefore, the form:

All marbles are red. All red things are bright. Therefore, all marbles are bright.

is a valid form.

The truth of the first two statements is not of interest. But, assuming that they are true, the last statement must necessarily be true.

Formal reasoning is deductive in nature. In other words, as said above, the conclusion of a valid formal argument follows necessarily from the premises. Notice that deductive reasoning produces no new information. It simply rearranges what is already known into a new statement of the same information.

Notice also that deductive or formal reasoning does not require any reference to external reality. It can be completely divorced from external reality. Therefore:

All unicorns are white. All white things are virtuous. Therefore, all unicorns are virtuous.

is a perfectly good and valid deductive argument.

Formal reasoning is addressed in other Wikibooks - [Formal Logic](/wiki/Formal_Logic), and [Systems of Logic](/w/index.php?title=Systems_of_Logic&action=edit&redlink=1).

## Informal Reasoning

Informal reasoning includes formal reasoning but it also is concerned with all the other elements of reasoning. It addresses the probability of truth of premises and conclusions. Informal reasoning is common, every-day reasoning.

## Truth

Truth seems obvious enough - we learn to tell the truth at an early age. Unfortunately, one of the features of language is it enables us to imagine future scenarios which are fanciful (which is what fiction writers do). In short it enables us to be untruthful to ourselves as well as others.

Emotionally, we react to situations. Emotions are primitive, quick and dirty survival tools - the sort of thing that makes one jump away from a flame or lash out at an attacker. We could not survive without such tactical tools.

We humans can - uniquely, and because of language - make up stories about what might happen if we did this or that, and so predict the effect of our actions. These are the long-term strategic tools that have made mankind master of the earth.

Our reports and predictions fall along a scale: they may be entirely true, partly true, false or disastrous. Reason draws us to the positive end of this scale. thoughtless blind obedience, stupidity and madness lead to errors, some of which may literally be fatal errors. Effective reasoning is our only hope of survival today and tomorrow (just as it has been for some three million years or whenever it was that our species first emerged)

## Leadership

Individuals who get these stories of the future approximately right (reasonable models, accurate projections), and can marshal available resources become leaders. Those who get it radically wrong are considered mad or insane. Most of us are sometimes leaders and sometimes followers - but this is a recent innovation.

For much of human history human society has been hierarchical: people were raised from infancy to believe that they belonged to an immutable social group such as 'royalty' nobility' or 'serfdom' The Hindu caste system is perhaps the most structured, but it happened (and still happens) everywhere. Director, manager or employee; pope, cardinal or priest; Officer, NCO or private soldier, and so on.

## Thinking allowed

The reformation, the enlightenment and above all the twentieth century wars in Europe came about through reason. Better educated people talking together, writing treatises and printing books broke the shackles of the old order.

The age of reason is accelerating through radio, television, the Internet and mobile phone technologies. It is not important that most of the material is simply entertaining, what matters is that it gives us food for thought. We can use these toys to imagine new products, services, social orders. If human imagination is reasonable, we humans should enjoy happy and fulfilled lives. If not, then crisis, recession and chaos might ensue, so that even medieval lunatic asylums might start to look like attractive places to live!

  


  * **[Return to Effective Reasoning](/wiki/Effective_Reasoning) < \- or - > [Proceed to A History of Reasoning](/wiki/Effective_Reasoning/A_History_of_Reasoning)**

Informal reasoning is intuitive and not reliant on logical thought or debate within a a formal process developed by philosophers such as Confucius, who promoted debate within families and communities in China, Plato, who evolved logical debate between scholars in Greece or Avicenna, who developed these ideas during the Islamic Golden period, from which developed the study of modes of reasoning which might 'prove' or 'disprove' contentious proposals. However, perhaps because of the word informal in the title, the precise definition of informal logic and reasoning is a matter of some dispute!

Most formal methods are _**deductive'**_ which means taking an ideas apart and analyzing the integrity of its components.

The alternative is _**inductive**_ reasoning which means searching for reliable related facts that might support or destroy the proposal.

Reasoning is however much more complicated than a collection of logical proposals. Essentially it is problem solving. Inventing new ways of thinking by both analysis of the problem and synthesis of the solution.

## Problem Solving

One way to do this is to analyze all the _**givens**_ and the _**wanteds**_ to evolve a _**process**_. For example, if one is hungry, then one might reasonably search the memory for all edibles and their probable location, or one could search the locality and list everything - eatable or not. Most of us would use a bit of both, by collecting a larder or store and organizing its contents precisely to avoid being hungry in the future.

## The Reason WHY?

Informal reasoning starts at an early age, 'on Mama's knee' or 'sitting with Nelly'. A wag once said that we humans inherit sanity from our children constantly demanding to know asking "Why?", "Why?", "WHY?". Another suggested we should be careful with wishes in case we got what we wanted.

## The Dispute

Informal reasoning is disputed because, for some, the term does not exclude formal processes, it simply allows intuition, taste and interpretation that goes beyond the 'clinical' logic and the 'habitual' truth.

For example, it is widely held that it is possible to travel too fast in a vehicle, because of the risk of injury or death.

In fact no-one has yet died from speed. What kills people is the rapid deceleration and sudden stop against an immovable obstacle or the arrival of potential energy that becomes kinetic that kills and maims people.

Informal reasoning says - go slowly, leave space, avoid excessive braking, try to predict what those other idiots are doing.... simply because, in accidents, many different vectors are significant, and we rely on previous experience. As Bismark noticed, we don't have time to make every mistake for ourselves - we learn from others: The famous Nelly, mentioned above, our teachers, our friends, our reading.

## Its the economy, stupid!

Once you realize that everything is complicated, and getting more so every day, you also realize that these formal _thinking tools_ have their limits. Philosophers, theologians and business gurus do indeed discover bits of useful 'truths', but really, they have as much effect on human reasoning as do meteorologists on the weather. That is to say, they report rather than control the process of thoughtful reasoning.

We all absorb culture form our families and societies: paternalism versus participation at home, control versus guidance at school, religion versus socialism in our society and so on. But we also have male and female traits, and even our brain in two parts. It is not an absolute truth, but in general, men are better at spatial and functional relationships (maybe because they once had to form teams to hunt woolly mammoths). Women, however excel at verbal skills (probably because they had to stop the men from killing each other - who knows?)

Informal reasoning therefore somewhat colored by the gender, religion and profession of the thinker. But its purpose is not simply to solve problems, it is to rethink 'common sense' and 'reason' and to share those new thoughts by what might perhaps be called 'entrepreneurial skills'.

## Stuff and Junk

As EF Shumaker remarked in his treatise 'Small is beautiful' much of what we do is create 'stuff'. Products, services, beliefs, fears or hopes, all of which are saleable, and most of which are 'junk' - things to throw away, such as the information leaflet in every packet of medicine, or the plastic bags we buy in order to throw away rubbish (which, today, is mostly the pretty packaging).

These unnecessary products and services have always been with us, and are part of our rich human heritage. Without a bored shepherd playing with a reed, maybe we would not have the music of woodwind and brass. It was informal reasoning that made the production of food and shelter a minor concern that ceased to consume all the available 'human resources'.

Thinking is what makes us human. To err is human - maybe to reason is divine? It has been proposed that our intelligence is a survival strategy, our 'unique selling point' in which formal logic has its place alongside education, culture and experience. That language - the medium of thinking - emerged from early tool-making. But the most important tool we ever made is reasoning - thinking things through, however imperfectly me may do that.

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Effective_Reasoning/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

[Effective Reasoning/Forms of Informal Reasoning](/w/index.php?title=Effective_Reasoning/Forms_of_Informal_Reasoning&action=edit&redlink=1)

    Critique/Analysis
    Argumentation
    Problem Solving/Decision Making
    Analogical Reasoning
    Causality and Correlation
    Scientific Reasoning
    Probabilistic Reasoning
    Aesthetic Reasoning
    Moral Reasoning

## Need for Reasoning

    Organizing Information (Deduction)
    Solution of Problems
    Resolution of Controversies
    Discovery of Truth

## Elements of Reasoning

[Effective Reasoning/Assumptions and Conclusions](/w/index.php?title=Effective_Reasoning/Assumptions_and_Conclusions&action=edit&redlink=1)

[Effective Reasoning/Deduction and Induction](/w/index.php?title=Effective_Reasoning/Deduction_and_Induction&action=edit&redlink=1)

[Effective Reasoning/Truth and Falsity](/w/index.php?title=Effective_Reasoning/Truth_and_Falsity&action=edit&redlink=1)

[Effective Reasoning/Validation, Fallacy, Reliability](/w/index.php?title=Effective_Reasoning/Validation,_Fallacy,_Reliability&action=edit&redlink=1)

## Language

[Effective Reasoning/Verbal and Nonverbal Reasoning](/w/index.php?title=Effective_Reasoning/Verbal_and_Nonverbal_Reasoning&action=edit&redlink=1)

[Effective Reasoning/Semantics and Syntax](/w/index.php?title=Effective_Reasoning/Semantics_and_Syntax&action=edit&redlink=1)

[Effective Reasoning/Functions of Language and Forms of Discourse](/w/index.php?title=Effective_Reasoning/Functions_of_Language_and_Forms_of_Discourse&action=edit&redlink=1)

[Effective Reasoning/Content](/w/index.php?title=Effective_Reasoning/Content&action=edit&redlink=1)

[Effective Reasoning/Agreement and Disagreement](/w/index.php?title=Effective_Reasoning/Agreement_and_Disagreement&action=edit&redlink=1)

[Effective Reasoning/Information, Concept, Reality, Virtual Reality](/w/index.php?title=Effective_Reasoning/Information,_Concept,_Reality,_Virtual_Reality&action=edit&redlink=1)

[Effective Reasoning/Fact and Opinion](/w/index.php?title=Effective_Reasoning/Fact_and_Opinion&action=edit&redlink=1)

[Effective Reasoning/Subjective and Objective](/w/index.php?title=Effective_Reasoning/Subjective_and_Objective&action=edit&redlink=1)

## Sources of Appeal

[Effective Reasoning/Empiricism](/w/index.php?title=Effective_Reasoning/Empiricism&action=edit&redlink=1)

[Effective Reasoning/Force](/w/index.php?title=Effective_Reasoning/Force&action=edit&redlink=1)

[Effective Reasoning/Origin and Agreement](/w/index.php?title=Effective_Reasoning/Origin_and_Agreement&action=edit&redlink=1)

[Effective Reasoning/Circumstance](/w/index.php?title=Effective_Reasoning/Circumstance&action=edit&redlink=1)

[Effective Reasoning/Relationship and Relevancy](/w/index.php?title=Effective_Reasoning/Relationship_and_Relevancy&action=edit&redlink=1)

## Definition and Focus

[Effective Reasoning/Definition and Problem Solving](/w/index.php?title=Effective_Reasoning/Definition_and_Problem_Solving&action=edit&redlink=1)

[Effective Reasoning/Definition and Discourse](/w/index.php?title=Effective_Reasoning/Definition_and_Discourse&action=edit&redlink=1)

[Effective Reasoning/Kinds of Definition](/w/index.php?title=Effective_Reasoning/Kinds_of_Definition&action=edit&redlink=1)

[Effective Reasoning/Meaning](/w/index.php?title=Effective_Reasoning/Meaning&action=edit&redlink=1)

[Effective Reasoning/Defining](/w/index.php?title=Effective_Reasoning/Defining&action=edit&redlink=1)

[Effective Reasoning/Ambiguity](/w/index.php?title=Effective_Reasoning/Ambiguity&action=edit&redlink=1)

## Deduction

[Effective Reasoning/Proof, Support, Evidence, and Warrant](/w/index.php?title=Effective_Reasoning/Proof,_Support,_Evidence,_and_Warrant&action=edit&redlink=1)

[Effective Reasoning/Forms of Deduction](/w/index.php?title=Effective_Reasoning/Forms_of_Deduction&action=edit&redlink=1)

## Inductive Reasoning

[Effective Reasoning/Analogical Reasoning](/w/index.php?title=Effective_Reasoning/Analogical_Reasoning&action=edit&redlink=1)

[Effective Reasoning/Causal Connection](/w/index.php?title=Effective_Reasoning/Causal_Connection&action=edit&redlink=1)

[Effective Reasoning/Mill's Methods](/w/index.php?title=Effective_Reasoning/Mill%27s_Methods&action=edit&redlink=1)

[Effective Reasoning/Science](/w/index.php?title=Effective_Reasoning/Science&action=edit&redlink=1)

[Effective Reasoning/The Scientific Method](/w/index.php?title=Effective_Reasoning/The_Scientific_Method&action=edit&redlink=1)

[Effective Reasoning/Experimentation and Ad Hoc Hypothesis](/w/index.php?title=Effective_Reasoning/Experimentation_and_Ad_Hoc_Hypothesis&action=edit&redlink=1)

[Effective Reasoning/Sociological/Anthropological Methods](/w/index.php?title=Effective_Reasoning/Sociological/Anthropological_Methods&action=edit&redlink=1)

[Effective Reasoning/Probability](/w/index.php?title=Effective_Reasoning/Probability&action=edit&redlink=1)

[Effective Reasoning/Probabilistic Method](/w/index.php?title=Effective_Reasoning/Probabilistic_Method&action=edit&redlink=1)

[Effective Reasoning/Expected Value](/w/index.php?title=Effective_Reasoning/Expected_Value&action=edit&redlink=1)

[Effective Reasoning/Intuition and Reasoning](/w/index.php?title=Effective_Reasoning/Intuition_and_Reasoning&action=edit&redlink=1)

## Argumentation

## Literary Criticism

## Aesthetic Criticism

## Moral Reasoning

## Apologetics and Religious Criticism

## Informal and Formal Reasoning

Formal reasoning is concerned only with the forms of arguments. Certain forms of arguments have been identified which are valid. In other words, if the original statements (or premises) in those arguments are true, then the conclusions must necessarily be true also. Therefore, the form:

All marbles are red. All red things are bright. Therefore, all marbles are bright.

is a valid form.

The truth of the first two statements is not of interest. But, assuming that they are true, the last statement must necessarily be true.

Formal reasoning is deductive in nature. In other words, as said above, the conclusion of a valid formal argument follows necessarily from the premises. Notice that deductive reasoning produces no new information. It simply rearranges what is already known into a new statement of the same information.

Notice also that deductive or formal reasoning does not require any reference to external reality. It can be completely divorced from external reality. Therefore:

All unicorns are white. All white things are virtuous. Therefore, all unicorns are virtuous.

is a perfectly good and valid deductive argument.

Formal reasoning is addressed in other Wikibooks - "Formal Logic", and "Systems of Logic".

Informal reasoning includes formal reasoning but it also is concerned with all the other elements of reasoning. It addresses the probability of truth of premises and conclusions. Informal reasoning is common, every-day reasoning.

# License

## GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Effective_Reasoning/Print_version&oldid=967524](http://en.wikibooks.org/w/index.php?title=Effective_Reasoning/Print_version&oldid=967524)" 

[Category](/wiki/Special:Categories): 

  * [Effective Reasoning](/wiki/Category:Effective_Reasoning)

Hidden category: 

  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Effective+Reasoning%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Effective+Reasoning%2FPrint+version)

### Namespaces

  * [Book](/wiki/Effective_Reasoning/Print_version)
  * [Discussion](/w/index.php?title=Talk:Effective_Reasoning/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Effective_Reasoning/Print_version)
  * [Edit](/w/index.php?title=Effective_Reasoning/Print_version&action=edit)
  * [View history](/w/index.php?title=Effective_Reasoning/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Effective_Reasoning/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Effective_Reasoning/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Effective_Reasoning/Print_version&oldid=967524)
  * [Page information](/w/index.php?title=Effective_Reasoning/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Effective_Reasoning%2FPrint_version&id=967524)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Effective+Reasoning%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Effective+Reasoning%2FPrint+version&oldid=967524&writer=rl)
  * [Printable version](/w/index.php?title=Effective_Reasoning/Print_version&printable=yes)

  * This page was last modified on 13 September 2007, at 19:14.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Effective_Reasoning/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
