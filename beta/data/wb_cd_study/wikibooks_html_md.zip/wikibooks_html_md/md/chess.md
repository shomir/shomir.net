# Chess/Print version

From Wikibooks, open books for an open world

< [Chess](/wiki/Chess)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Chess/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Chess/Print_version) on _6 March 2011_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Chess/Print_version&oldid=1266123&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Chess](/wiki/Chess)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Chess/Print_version&action=purge&printable=yes) this page.

Chess is an ancient Indian game of strategy, played by two individuals on an 8x8 grid. The objective is to maneuver one's pieces so as to put the opposing king in "checkmate". This book will cover the basic pieces of chess, before going on to some more advanced topics.

© Copyright 2003–2006 contributing authors, all rights reserved. Permission is granted to copy, distribute and/or modify this document under the terms of the GNU Free Document License, version 1.2. A copy of this is included in the section entitled GNU Free Document License.

# Contents

If you save this file to your computer, you can click on a link below to go to the chapter.

  * Playing The Game
  * Notating The Game
  * Tactics
  * Tactics Exercises
  * Strategy
  * Basic Openings
  * Sample chess game
  * The Endgame
  * Variants
  * Tournaments
  * Optional homework
  * GNU Free Documentation License

# Playing The Game

[Chess/Playing The Game](/wiki/Chess/Playing_The_Game)

# Notating The Game

Notating chess games is important to any chess student, since it allows them to review their strategy and that of their opponent, to read of classic chess encounters, and follow how the game developed. Further, chess puzzles are often set in magazines, newspapers and online, and their solutions are notated; for an example, see [The Times Chess](http://entertainment.timesonline.co.uk/tol/arts_and_entertainment/games_and_puzzles/chess/).

## Algebraic notation

A very common nomenclature for chess games is [algebraic notation](/wiki/Chess/Algebraic_notation). There are several older systems of notation, but these are less common.

In algebraic notation, we use

  * **R** for a rook
  * **N** for a knight
  * **B** for a bishop
  * **K** for a king
  * **Q** for a queen
  * **no letter** for a pawn

Sometimes a pictorial language-independent notation is used, in which a picture of a horse might represent a knight, and so on.

Each square on the chess board is given by a co-ordinate, much like a map. The rows (in chess language, ranks) are labelled with Arabic numerals (i.e., 1, 2, 3,...), and the columns (in chess language, files) are labelled with letters of the English alphabet (i.e., a, b, c,...). A square's co-ordinate is first its column followed by its row. For example, in the board below, black's king is on the square **d5**.

If black moves his king to, say, **d6**, the move is notated as **Kd6**, i.e. the **k**ing has moved to square **d6**.

If more than one piece of the same type could have moved to the square to which the piece was moved, then the file of the piece prior to its move should come in between the piece's symbol and the coordinates of its destination (i.e., **Qee7**.) If necessary, the rank it was on may also be added, (i.e., **Qe6e4**.)

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

8
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
8

7
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
7

6
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
6

5
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Chess_kdt45.svg/26px-Chess_kdt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
5

4
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
4

3
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
3

2
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
2

1
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
1

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

The board's co-ordinates

  


Moves in which a piece is captured, a king put in check, or checkmate have special notations.

  * If a piece is captured, a cross (**x**) is inserted just before the destination square. Thus, if the capture is done by a pawn, the cross is preceded by the column the pawn occupied prior to the capture.
  * If the king is put in check, the move's notation is followed by a plus sign (**+**).
  * If the king is put in checkmate, the move's notation is followed by a hash or double plus signs ('_#_",**++**,) or the word "mate" or "checkmate."

### Annotation shorthand

Annotation shorthand is not a notation system. Rather, it is a system of symbols for the author to add his descriptions or comments. An author notating a game might wish to highlight an excellent move, question a bad one, or indicate which player he thinks has the advantage.

  * If a move is followed by an exclamation mark (**!**), the author is surprised by the move's quality.
  * If a move is followed by a question mark (**?**), the author suspects the move may have been poor.
  * If a move is followed by an exclamation mark and then a question mark (**!?**), the move interests the author, though it may be sub-optimal.
  * If a move is followed by a question mark and then an exclamation mark (**?!**), the author fears that the move may be conclusive.

Repeating a symbol (e.g. **!!** or **??**) adds emphasis.

Results are written as white's score followed by black's score. For example, **1-0** indicates that white won, and **0-1** indicates that black won. In the case of a draw, the result is **½-½**.

There are some additional symbols for the author to note his thoughts on the game in general, rather than on any particular move.

  * An equals sign (**=**) indicates positional equality between the players.
  * A plus-minus sign (**+/–**) indicates that white is considered to have the advantage.
  * A minus-plus sign (**–/+**) indicates that black is considered to have the advantage.

## Ambiguity

Sometimes algebraic notation can be ambiguous - that is, two pieces of the same designation can move to one square. For example, a player might be able to move either of his rooks to the same square. In these cases, it is essential to specify which piece was moved.

The precise move is specified by designating the file (column) that the piece moved from, before the move's final co-ordinate. For example, **Nd2** indicates that a knight moved to **d2**, but **Nbd2** indicates that the knight that was in column **b** moved to **d2**. If a piece's file is not enough to precisely specify the move, then its rank is used instead. If neither is enough on its own, both are used.

### Special moves

Some special moves are tricky to write in algebraic notation, and must have their own notation.

  * Castling king-side is written **0-0**.
  * Castling queen-side is written **0-0-0**.
  * En passant capture is written as if the captured pawn only moved one square. The notation may be followed with _e.p._ or _ep_ to clarify that the capture was done en passant.
  * If a pawn is promoted, the pawn's initial move is written, followed by an equal sign and then the shorthand for the new piece; for instance, e8=Q. Any additional nomenclature or annotation is written after the shorthand for the new piece (such as c8=Q+ if a pawn promoted to a queen on c8 and placed the opposing king in check.)

## Sample game in algebraic notation

If you have familiarized yourself with algebraic notation, consider this short sequence of moves. Try to follow the game by looking at the moves in algebraic notation, and the boards.

The game has begun, and is nearing the end. White is to move.

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

8
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
8

7
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Chess_kdt45.svg/26px-Chess_kdt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
7

6
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
6

5
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
5

4
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black queen](//upload.wikimedia.org/wikipedia/commons/thumb/4/47/Chess_qdt45.svg/26px-Chess_qdt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
4

3
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} white bishop](//upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Chess_blt45.svg/26px-Chess_blt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
3

2
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
2

1
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} white king](//upload.wikimedia.org/wikipedia/commons/thumb/4/42/Chess_klt45.svg/26px-Chess_klt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
1

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

Sample Game

  


  
White decides to move his bishop from **d3** to **c4**, to check black's king. This is white's thirtieth move. So in algebraic notation, we write

  * **30\. Bc4+**

Since only one bishop could move to **c4**, the bishop's initial position was not specified. The **+** indicates the check.

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

8
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
8

7
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Chess_kdt45.svg/26px-Chess_kdt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
7

6
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
6

5
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
5

4
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} white bishop](//upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Chess_blt45.svg/26px-Chess_blt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black queen](//upload.wikimedia.org/wikipedia/commons/thumb/4/47/Chess_qdt45.svg/26px-Chess_qdt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
4

3
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
3

2
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
2

1
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} white king](//upload.wikimedia.org/wikipedia/commons/thumb/4/42/Chess_klt45.svg/26px-Chess_klt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
1

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

Sample Game

  


White's bishop is now, unfortunately, in the queen's line of fire. Black decides to capture it. So for black's 30th move we write

  * **30... Qxc4**

The _x_ signifies that a piece has been captured. When black's move is written separately from white's, an ellipsis (**...**) is placed between the number and the move. The ellipsis indicates that white's move has been omitted.

The board now looks like this:

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

8
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
8

7
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Chess_kdt45.svg/26px-Chess_kdt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
7

6
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
6

5
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
5

4
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black queen](//upload.wikimedia.org/wikipedia/commons/thumb/4/47/Chess_qdt45.svg/26px-Chess_qdt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
4

3
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
3

2
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
2

1
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} white king](//upload.wikimedia.org/wikipedia/commons/thumb/4/42/Chess_klt45.svg/26px-Chess_klt45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
![{{{square}}} black king](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Chess_t45.svg/26px-Chess_t45.svg.png)
1

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)
a
b
c
d
e
f
g
h
![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/Solid_white.svg/18px-Solid_white.svg.png)

Sample Game

  


White is in trouble now, and decides to flee to **f2**. His move is

  * **31\. Kf2**

If black checks white's king, by moving his queen to **c2**, his move is

  * **31... Qc2+**

## Descriptive Notation

An older form of notation you will run into quite frequently is _descriptive notation_. It is useful to know because older books use it.

In this form, instead of the files being a, b, c etc., they are Queen rook (QR), Queen Knight (QN), Queen Bishop (QB), Queen (Q), King (K), King Bishop (KB), King Knight (KN) and King Rook (KR). The ranks are labelled from your point of view so that the square e4 (in algebraic) is White's K4 and Black's K5.

To record the moving of a piece, you write the piece, and to where it moves. 1. P-K4 means move a pawn to the 4th rank in the King's file. N-QB3 means move your Knight to the third rank in the Queen's Bishop file. For a capture, you specify the piece taking, and the piece to be taken. QRPxN means pawn in the Queen Rook file takes Knight. Excessive notation is left out so that if there is only one way a pawn could legally take a Knight, the move is recorded as PxN. Note that if a piece is specified to be on the King's or Queen's side of the board, that is the side it is on now, not the side it started out on.

In order to compare the two systems, we could look at the same game in both algebraic and descriptive notation.

Algebraic Descriptive

  1. e4 e6
  2. d4 d5
  3. Nc3 Bb4
  4. Bb5+ Bd7
  5. Bxd7+ Qxd7
  6. Nge2 dxe4
  7. 0-0

  1. P-K4 P-K3
  2. P-Q4 P-Q4
  3. N-QB3 B-N5 1
  4. B-N5ch B-Q2 2
  5. BxBch QxB
  6. KN-K2 PxP
  7. 0-0

    1.**^** Note here that since only one bishop can move to QN5, it is unnecessary to specify which bishop moved to that square.
    2.**^** Check is indicated by "ch".

## Coordinate Notation

A different type of notation uses only the squares that the pieces were on to denote movements. For example, to denote the earlier 7 moves, the following notes are shown:

  1. e2-e4 e7-e6
  2. d2-d4 d7-d5
  3. b1-c3 f8-b4
  4. f1-b5+ c8-d7
  5. b5xd7+ d8xd7
  6. g1-e2 d5xe4
  7. 0-0

## ICCF numerical notation

1
2
3
4
5
6
7
8

8
![18](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![28](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![38](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![48](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![58](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![68](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![78](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![88](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
8

7
![17](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![27](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![37](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![47](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![57](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![67](//upload.wikimedia.org/wikipedia/commons/thumb/1/17/Chess_tile_kd.svg/24px-Chess_tile_kd.svg.png)
![77](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![87](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
7

6
![16](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![26](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![36](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![46](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![56](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![66](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![76](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![86](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
6

5
![15](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![25](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![35](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![45](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![55](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![65](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![75](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![85](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
5

4
![14](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![24](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![34](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![44](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![54](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![64](//upload.wikimedia.org/wikipedia/commons/thumb/3/31/Chess_tile_qd.svg/24px-Chess_tile_qd.svg.png)
![74](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![84](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
4

3
![13](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![23](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![33](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![43](//upload.wikimedia.org/wikipedia/commons/thumb/5/50/Chess_tile_bl.svg/24px-Chess_tile_bl.svg.png)
![53](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![63](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![73](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![83](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
3

2
![12](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![22](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![32](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![42](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![52](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![62](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![72](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![82](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
2

1
![11](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![21](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![31](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![41](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![51](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Chess_tile_kl.svg/24px-Chess_tile_kl.svg.png)
![61](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![71](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
![81](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Chess_tile_.svg/24px-Chess_tile_.svg.png)
1

1
2
3
4
5
6
7
8

Sample Game

A move is denoted by the file (1 to 8) and rank (1 to 8) of its starting square followed by its destination square (from 11 at the White queen’s rook square to 88 at the Black king’s rook square). "1. e4" is denoted as "1. 5254" in ICCF notation. Unlike other notations, ICCF notation does not make apparent when castling, check, checkmate, and capture took place (castling king side is 5171 for white and 5878 for black). Pawn promotion necessitates a fifth number specifying the new piece (1=queen, 2=rook, 3=bishop, 4=knight). This notation is considered to be international in that there is no dependency on piece names or specific alphabets. However this notation still depends on Arabic numerals.

# Tactics

[Chess/Tactics](/wiki/Chess/Tactics)

# Tactics

[Chess/Tactics Exercises](/wiki/Chess/Tactics_Exercises)

# Strategy

[Chess/Strategy](/wiki/Chess/Strategy)

# Basic Openings

[Chess/Basic Openings](/wiki/Chess/Basic_Openings)

# Sample chess game

[Chess/Sample chess game](/wiki/Chess/Sample_chess_game)

# The Endgame

[Chess/The Endgame](/wiki/Chess/The_Endgame)

# Variants

[Chess/Variants](/wiki/Chess/Variants)

# Tournaments

[Chess/Tournaments](/wiki/Chess/Tournaments)

# Optional homework

These optional homework problems will test your ability to apply chess concepts. Try them and learn!

# Homework 1

[Chess/Optional homework/1](/wiki/Chess/Optional_homework/1)

# Homework 2

[Chess/Optional homework/2](/wiki/Chess/Optional_homework/2)

# Homework 3

[Chess/Optional homework/3](/wiki/Chess/Optional_homework/3)

# Homework 4

[Chess/Optional homework/4](/wiki/Chess/Optional_homework/4)

# Solutions

[Chess/Optional homework/Solutions](/wiki/Chess/Optional_homework/Solutions)

# GNU Free Documentation License

[GNU Free Documentation License](/wiki/GNU_Free_Documentation_License)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Chess/Print_version&oldid=1266123](http://en.wikibooks.org/w/index.php?title=Chess/Print_version&oldid=1266123)" 

Hidden category: 

  * [Pages where template include size is exceeded](/wiki/Category:Pages_where_template_include_size_is_exceeded)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Chess%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Chess%2FPrint+version)

### Namespaces

  * [Book](/wiki/Chess/Print_version)
  * [Discussion](/w/index.php?title=Talk:Chess/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Chess/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Chess/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Chess/Print_version&action=edit)
  * [View history](/w/index.php?title=Chess/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Chess/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Chess/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Chess/Print_version&oldid=1266123)
  * [Page information](/w/index.php?title=Chess/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Chess%2FPrint_version&id=1266123)

### In other languages

  * [Español](//es.wikibooks.org/wiki/Manual_de_Ajedrez/Anotando_un_juego)
  * [Italiano](//it.wikibooks.org/wiki/Scacchi/Annotazioni_di_gioco)
  * [Bahasa Melayu](//ms.wikibooks.org/wiki/Catur/Mencatat_permainan)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Chess%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Chess%2FPrint+version&oldid=1266123&writer=rl)
  * [Printable version](/w/index.php?title=Chess/Print_version&printable=yes)

  * This page was last modified on 3 September 2008, at 11:50.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Chess/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
