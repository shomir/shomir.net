# VCE Specialist Mathematics/Print Version

From Wikibooks, open books for an open world

< [VCE Specialist Mathematics](/wiki/VCE_Specialist_Mathematics)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [VCE Specialist Mathematics](/wiki/VCE_Specialist_Mathematics)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&action=purge&printable=yes) this page.

# Preface

The purpose of this text is to produce a reliable and free textbook, specifically tailored toward the needs of students studying VCE Specialist Mathematics in an attempt to gain the Victorian Certificate of Education (VCE). The eventual aim is to provide a practical alternative to standard textbooks, complete with exercises and worked examples.

## Authors

  * There are 1 registered users who have contributed to this wiki textbook since 2010-03-28 08:57
  * Please feel free to add yourself to the author list, when you contribute
  * List and edit counts are correct as of 2010-04-02 08:06

  


    **[Adrignola](/wiki/User:Adrignola)**

    First authorship: 2010-03-28 15:03

    Contributions: (_ edits, _ pages)

# Units 1 and 2: Specialist Mathematics

## Overview

### Assessment

Internally assessed by the institution for an N mark.

# Units 3 and 4: Specialist Mathematics

## Overview

### Assessment

#### Totals

  * 14% of of Study Score: Unit 3 SACS
  * 20% of of Study Score: Unit 4 SACS
  * 66% of of Study Score: End of Year Exams (2)

#### Unit 3 SACS

##### Outcome 1: 5.25% of Study Score

  * Analysis task 1: 2.45% of Study Score
  * Analysis task 2: 2.8% of Study Score

##### Outcome 2: 5.25% of Study Score

  * Analysis task 1: 2.8% of Study Score
  * Analysis task 2: 2.45% of Study Score

##### Outcome 3: 3.5% of Study Score

  * Analysis task 1: 1.75% of Study Score
  * Analysis task 2: 1.75% of Study Score

#### Unit 4 SACS

##### Outcome 1: 10% of Study Score

  * Application Task: 5% of Study Score
  * Tests: 5% of Study Score

##### Outcome 2: 6.7% of Study Score

  * Application Task: 6.7% of Study Score

##### Outcome 3: 3.3% of Study Score

  * Application task: 1.7% of Study Score
  * Tests: 1.6% of Study Score

#### End of Year Exams

##### Exam 1: Tech-Free: 22% of Study Score

  * 1 hr: 22% of Study Score

##### Exam 2: Tech-Active: 44% of Study Score

  * 2 hrs: 44% of Study Score

## Coordinate Geometry

## Preface

**Formal Definition:** Coordinate (algebraic) geometry is a branch of mathematics which combines techniques of abstract algebra, especially commutative algebra, with the language and the problems of geometry.

**Translation:** Understanding the math behind the various features that appear on a graph, allowing one to rapidly, and accurately, draw complex graphs (with points of interest).

## Properties of Graphs

### Asymptotes

#### Definition

Asymptotes are values which the graph approaches but does not touch. An asymptote is itself a graph and is categorized as follows:

  * Vertical; A constant value (graph) on the horizontal axis (e.g. ![x=1](//upload.wikimedia.org/math/a/2/5/a255512f9d61a6777bd5a304235bd26d.png)).
  * Horizontal; A constant value (graph) on the vertical axis (e.g. ![y = 1](//upload.wikimedia.org/math/6/a/2/6a267007228f9f654a0d28dec6932c31.png)).
  * Oblique (i.e. not Vertical or Horizontal); A non-constant graph (e.g. ![y=x^2](//upload.wikimedia.org/math/c/e/4/ce4c5f6d73b27625159be3b151541788.png)).

#### Comprehension

  1. Take a function ![y=ax^m+ \\frac{1}{bx^n}\\ +c](//upload.wikimedia.org/math/a/5/7/a573f971da5a0ffe10a04a413ca16495.png).
  2. As ![x\\to0, \\frac{1}{bx^n}\\ \\to \\infty, ax^m+c \\to c](//upload.wikimedia.org/math/6/5/c/65c508a3d73fc33fc326a442e551a95d.png)
  3. The numerator (a function or a number, as is shown here: ![1](//upload.wikimedia.org/math/c/4/c/c4ca4238a0b923820dcc509a6f75849b.png)) is divided by an extremely small number. Hence making the fraction an extremely large number.
  4. To understand why this happens grab any number, and divide it by an extremely small number (e.g. ![10^{-30}](//upload.wikimedia.org/math/f/4/b/f4b26043296ee031b94cd2909ff9f9ec.png))
  5. The value of ![\\frac{1}{bx^n}\\ \\to \\infty](//upload.wikimedia.org/math/8/2/3/823497233361edd3341d6e64a8047915.png) overshadows the rest of the graph, namely the ![ax^m+c \\to c](//upload.wikimedia.org/math/3/5/4/3549a2a8d2f3edc32c3959f2395a1434.png).
  6. Hence making ![\\frac{1}{bx^n}\\ ](//upload.wikimedia.org/math/7/8/6/786ed6013289305c5851db5851dcd392.png) an oblique (non-constant) asymptote, as it is approached by, but never actually touched by the graph due to the addition of ![ax^m+c](//upload.wikimedia.org/math/c/8/4/c8440dd2684d129b1ec5c7631202254f.png) to every y value. This is in addition to the limit provided when ![x=1](//upload.wikimedia.org/math/a/2/5/a255512f9d61a6777bd5a304235bd26d.png) which is not included in this graph, but must be if it exists on others (e.g. after polynomial division).
  7. As ![x \\to \\infty, \\frac{1}{bx^n}\\ \\to 0, ax^m+c \\to \\infty](//upload.wikimedia.org/math/e/2/6/e2642bfa96b6f5ed26540db6b867e1d2.png)
  8. The numerator (a function or a number, as is shown here:![1](//upload.wikimedia.org/math/c/4/c/c4ca4238a0b923820dcc509a6f75849b.png)) is divided by an extremely large number. Hence making the fraction an extremely small number.
  9. To understand why this happens grab any number, and divide it by an extremely large number (e.g. ![10^{30}](//upload.wikimedia.org/math/7/7/1/771a692fb4f6ac6ef7c74e5d1c67f880.png))
  10. The value of ![ax^m+c \\to \\infty](//upload.wikimedia.org/math/d/e/f/def6ac859687743abc0079ffd53194a6.png) overshadows the rest of the graph, namely the ![\\frac{1}{bx^n}\\ \\to 0 ](//upload.wikimedia.org/math/c/b/d/cbd0e38b9cdaf1941913f3f3448caa36.png).
  11. Hence making ![ax^m+c ](//upload.wikimedia.org/math/c/8/4/c8440dd2684d129b1ec5c7631202254f.png) the oblique (non-constant) asymptote, as it is approached by, but never actually touched by the graph due to the addition of ![\\frac{1}{bx^n}\\ ](//upload.wikimedia.org/math/7/8/6/786ed6013289305c5851db5851dcd392.png) to every y value.

### Circles, Ellipses and Hyperbolas

#### Definition

##### Ellipses

**General formula:**

  * ![\\frac{\(x-h\)^2}{a^2} + \\frac{\(y-k\)^2}{b^2} = 1](//upload.wikimedia.org/math/a/9/c/a9ce1392a08f8795bd12ecfccd68c66b.png)

**General Notes:**

  * Point ![\(h,k\)](//upload.wikimedia.org/math/6/d/9/6d97efba171c113b80a8d43e78249b46.png) defines the ellipses center.
  * Points ![\(\\pm a + h,k\)](//upload.wikimedia.org/math/6/6/5/665715214f640147e59573f5543adcf2.png) defines the ellipses domain, and horizontal endpoints - i.e. horizontal stretch.
  * Points ![\(h,\\pm b + k\)](//upload.wikimedia.org/math/0/1/7/017010324aab42387c337d390db3a803.png) defines the ellipses range, and vertical endpoints - i.e. vertical stretch.

##### Circles

**General formula:**

  * ![\(x-h\)^2 + \(y-k\)^2 = r^2](//upload.wikimedia.org/math/0/1/f/01fe026cb49c1188469f9b17cebb41a9.png)

**General Notes:**

  * Point ![\(h,k\)](//upload.wikimedia.org/math/6/d/9/6d97efba171c113b80a8d43e78249b46.png) defines the circles center.
  * Points ![\(\\pm r + h,k\)](//upload.wikimedia.org/math/f/4/f/f4f45d874d752d3c6b5b97bcf5e93d4d.png) defines the circles domain - i.e. stretch.
  * Points ![\(h,\\pm r + k\)](//upload.wikimedia.org/math/4/8/3/483b07f8844447b555da9637d34cb082.png) defines the circles range - i.e. stretch.
  * A circle is a subset of an ellipse, such that ![a = b = r](//upload.wikimedia.org/math/7/6/b/76b45b1cd17289a5edf1cc727c53a5a7.png).

##### Hyperbolas

**General formulae:**

  * ![\\frac{\(x-h\)^2}{a^2} - \\frac{\(y-k\)^2}{b^2} = 1](//upload.wikimedia.org/math/9/3/6/9360ecd574ab3bc5074ef6fdf61a1318.png)
  * ![\\frac{\(y-k\)^2}{b^2} - \\frac{\(x-h\)^2}{a^2} = 1](//upload.wikimedia.org/math/4/f/8/4f8d5c6d0e8001de40c1558486581c59.png)

**General Notes:**

  * Point ![\(h,k\)](//upload.wikimedia.org/math/6/d/9/6d97efba171c113b80a8d43e78249b46.png) defines the hyperbolas center.
  * Points ![\(\\pm a + h,k\)](//upload.wikimedia.org/math/6/6/5/665715214f640147e59573f5543adcf2.png) defines the hyperbolas domain, ![\[\\pm a + h, \\pm \\infty\)](//upload.wikimedia.org/math/7/c/4/7c43ee31e47950ac5401eaed325e1228.png).
  * The switch in positions of the fractions containing x and y, indicate the type of hyperbola - i.e. vertical or horizontal. The hyperbola is horizontal in the first, and negative in the second of the General hyperbolic formulae above.
  * Graphs ![y=\\pm \(\\pm a + h,k\)](//upload.wikimedia.org/math/6/d/7/6d73d3636eb9f588e31466106d806f07.png) defines the hyperbolas domain ![\[\\pm a + h, \\pm \\infty\)](//upload.wikimedia.org/math/7/c/4/7c43ee31e47950ac5401eaed325e1228.png).

#### Comprehension

Is unnecessary for these types of graphs, as the rules listed above are all that are needed. However the ability to recognize these graphs, in varying forms, is required and can be achieved via practice or can be found in [Coordinate Geometry](/w/index.php?title=VCE_Specialist_Mathematics/Units_3_and_4:_Specialist_Mathematics/Common_Math_Hacks/Coordinate_Geometry&action=edit&redlink=1) section of [Common Math Hacks](/wiki/VCE_Specialist_Mathematics/Units_3_and_4:_Specialist_Mathematics/Common_Math_Hacks).

### Partial Fractions

#### Definition

#### Comprehension

#### Graphing Examples

##### General Steps

  1. Note the limits caused by a divide by 0.
  2. If possible (check the highest power of bottom and top), break up the complex function via polynomial division or partial fractions.
  3. If numerator's power is ![<](//upload.wikimedia.org/math/5/2/4/524a50782178998021a88b8cd4c8dcd8.png) the denominators power, utilize partial fractions.
  4. Otherwise if the numerator's power is ![\\ge](//upload.wikimedia.org/math/8/f/b/8fbe2a506fe3db0835548e1b648ec977.png) the denominators power, utilise polynomial division.
  5. Add the resultant graphs, through the addition of ordinates method, to quickly determine what the graph looks like.
  6. Determine the asymptotes (Vertical, Horizontal, Oblique (i.e. a graph)).
  7. Determine other points of interest (Turning points (differentiation), Intercepts (let ![y=0](//upload.wikimedia.org/math/f/a/b/fab37d6c4a697fe660387d3ff8e889a4.png), or ![x=0](//upload.wikimedia.org/math/e/1/1/e11729b0b65ecade3fc272548a3883fc.png))).
  8. Draw the Graph using the above properties.

##### Partial Fractions

  1. Take a function: ![y=\\frac{3x+7}{x^2-2x-3}\\ ](//upload.wikimedia.org/math/b/1/6/b16193cdd1fa757817e94efa705ee34c.png)
  2. Notice that if ![x^2-2x-3=0](//upload.wikimedia.org/math/0/3/f/03ffb14d17994b391ff9e7487ffb8c59.png), hence ![\(x+1\)\(x-3\)=0](//upload.wikimedia.org/math/a/e/f/aef4839eb397d06f21afba4cd23544da.png), you get a divide by 0. Hence ![ x\\ne -1](//upload.wikimedia.org/math/e/a/0/ea010fb48948e2adfc234e121562907e.png) or ![ x\\ne 3](//upload.wikimedia.org/math/0/b/4/0b46acfe1b4af26d88888202d0a03ce4.png).
  3. Break up the function into partial fractions, and you arrive at ![y=\\frac{-1}{\(x+1\)}\\ + \\frac{4}{\(x-3\)}\\ ](//upload.wikimedia.org/math/a/4/3/a4367e8c173e148b022a8c1aa667cb03.png).
  4. Add the resultant graphs, through the addition of ordinates method, to quickly determine what the graph looks like.
  5. Notice that as ![x\\to -1, \\frac{-1}{\(x+1\)}\\ \\to - \\infty, \\frac{4}{\(x-3\)}\\ \\to -1 ](//upload.wikimedia.org/math/f/2/0/f20096893e45884a6ffe65d4fc79a3e5.png). The fractional part, ![\\frac{-1}{\(x+1\)}\\ ](//upload.wikimedia.org/math/8/4/2/842de552a6cfba6278dce0ed55f0cd66.png), overshadows the rest of the equation, namely ![\\frac{4}{\(x-3\)}\\ ](//upload.wikimedia.org/math/7/5/6/7568c22d5146f4cc3305f3d4f1e1c0f2.png). Hence a horizontal asymptote occurs when ![x=-1](//upload.wikimedia.org/math/d/3/2/d3289a96da4c1cf6ce57b2b76b80b965.png).
  6. Notice that as ![x\\to 3, \\frac{4}{\(x-3\)}\\ \\to \\infty, \\frac{-1}{\(x+1\)}\\ \\to \\frac{-1}{4}\\ ](//upload.wikimedia.org/math/3/c/6/3c69475d37f9491233fc2e3047cf4086.png). The fractional part, ![\\frac{4}{\(x-3\)}\\ ](//upload.wikimedia.org/math/7/5/6/7568c22d5146f4cc3305f3d4f1e1c0f2.png), overshadows the rest of the equation, namely ![\\frac{-1}{4}\\ ](//upload.wikimedia.org/math/e/1/9/e19279cdde05e90af1b6ef321b8b2bdd.png). Hence a horizontal asymptote occurs when ![x=3](//upload.wikimedia.org/math/5/8/7/5870bb658ee9e8a6900c138365d64c80.png).
  7. Notice that as ![x\\to\\infty, \\frac{-1}{\(x+1\)}\\ + \\frac{4}{\(x-3\)}\\  \\to 0, y \\to 0](//upload.wikimedia.org/math/7/7/c/77c7fdfde96df232dc89769c7d695597.png). Now the oblique (i.e. graph), ![y=0](//upload.wikimedia.org/math/f/a/b/fab37d6c4a697fe660387d3ff8e889a4.png), overshadows the rest of the equation, namely ![\\frac{-1}{\(x+1\)}\\ + \\frac{4}{\(x-3\)}\\ ](//upload.wikimedia.org/math/c/8/c/c8c8a34fe9a978dd40edcf41e717bb9d.png). Hence the oblique asymptote occurs when ![y=0](//upload.wikimedia.org/math/f/a/b/fab37d6c4a697fe660387d3ff8e889a4.png).
  8. Determine points of interest: 
    1. When ![y=0, x = \\frac{-7}{3}\\ ](//upload.wikimedia.org/math/9/9/d/99dce34b1058eebf32a2e8666e92a572.png), hence there are no x-intercepts (C is the complex field) in the real plane.
    2. When ![x=0, y = \\frac{-7}{3}\\ ](//upload.wikimedia.org/math/5/0/f/50fcd899b06bc0059bfab6ec6518d90b.png).
    3. When ![y'=0, x=-5 or x=\\frac{1}{3}\\ , y= \\frac{-1}{4}\\ or \\frac{-9}{4}\\ ](//upload.wikimedia.org/math/8/5/5/85567e85c74e149980a7a84ba861c025.png)
  9. Draw the graph.

##### Polynomial Division

  1. Take a function: ![y=3x+7 + \\frac{x^3 + 19x^2 + 116x +224}{x\(x+4\)\(x+7\)}\\ ](//upload.wikimedia.org/math/2/7/9/2796722c6f65602bbeff5970e6295dbe.png)
  2. Notice that if ![x\(x+4\)\(x+7\)=0](//upload.wikimedia.org/math/0/c/d/0cdd005056be3c3ef2a7b1b459b5f6b4.png), you get a divide by 0. Hence ![ x\\ne 0](//upload.wikimedia.org/math/4/3/c/43cd1f01fc40ff198193084a874be8ab.png) or ![ x\\ne -4](//upload.wikimedia.org/math/5/7/a/57a128af9792ce18378093e36628a4bd.png) or ![ x\\ne -7](//upload.wikimedia.org/math/c/3/6/c366809760804d3b8b497b161f702c20.png)
  3. Break up the function, and divide through, using polynomial division, and you arrive at ![y=3x+7 + \\frac{x+8}{x}\\ ](//upload.wikimedia.org/math/f/f/b/ffb565cdfc10860c243d4e57b86229f0.png).
  4. Add the resultant graphs, through the addition of ordinates method, to quickly determine what the graph looks like.
  5. Notice that as ![x\\to0, \\frac{x+8}{x}\\ \\to \\infty, 3x+7 \\to 7 ](//upload.wikimedia.org/math/f/4/e/f4e1bec392b66fcf121784c7773351ac.png). The fractional part, ![\\frac{x+8}{x}\\ ](//upload.wikimedia.org/math/8/0/b/80b5589a8542cc699ef1bcc157c44ad1.png), overshadows the rest of the equation, namely ![3x+7](//upload.wikimedia.org/math/d/2/2/d22a153f07d37c88389632aff4c5cdc3.png). Hence the horizontal asymptote occurs when ![x=0](//upload.wikimedia.org/math/e/1/1/e11729b0b65ecade3fc272548a3883fc.png).
  6. Notice that as ![x\\to\\infty, \\frac{x+8}{x}\\ \\to 0, y \\to 3x+7](//upload.wikimedia.org/math/6/1/1/611e40886e1edf28ee0ed93a4fe7fee0.png). Now the oblique (i.e. graph), ![3x+7](//upload.wikimedia.org/math/d/2/2/d22a153f07d37c88389632aff4c5cdc3.png), overshadows the rest of the equation, namely ![\\frac{x+8}{x}\\ ](//upload.wikimedia.org/math/8/0/b/80b5589a8542cc699ef1bcc157c44ad1.png). Hence the oblique asymptote occurs when ![y=3x+7](//upload.wikimedia.org/math/6/4/7/647fd64d6a028203b8f3749e11114a9f.png).
  7. Determine points of interest: 
    1. When ![y=0, x \\in \\mathbb{C} ](//upload.wikimedia.org/math/5/6/4/5644bb0153e5dd49a6d419f903d4cccb.png), hence there are no x-intercepts (C is the complex field) in the real plane.
    2. When ![x=0, y \\uparrow ](//upload.wikimedia.org/math/1/8/8/1889d0551e8881d3820a1c56cc00a880.png), hence there are no y-intercepts (![\\uparrow](//upload.wikimedia.org/math/f/0/4/f045028b3e31841b22efbbb9a0911dc0.png) indicates that the previous statement is undefined.)
    3. When ![y'=0, x=\\pm \\frac{2\\sqrt{6}}{3}\\ , y=8\\pm4\\sqrt{6}](//upload.wikimedia.org/math/b/e/f/bef36f91d82e00fdaf7e3aa4aa6c4524.png)
  8. Draw the graph.

## Circular Functions

## Preface

**Formal Definition:** In mathematics, the trigonometric functions (also called circular functions) are functions of an angle. They are used to relate the angles of a triangle to the lengths of the sides of a triangle.

**Translation:** Understanding the various functions that can be applied to and taken from (graphs) the unit circle, and includes recognizing and using the various algebraic identities to manipulate trigonometric functions and equations.

## Graphing Functions

### Sin

General formula:

  * ![y = a\\sin\(n\(x-b\)\) + c](//upload.wikimedia.org/math/1/5/e/15e04e437962c6b6a6d67677e162d85a.png)

General Notes:

  * General formula achieved isolating the coefficient of x (n), i.e. the "lonely x rule".
  * A period is equal to ![\[\\frac{2\\pi}{n}\]](//upload.wikimedia.org/math/4/5/1/451ecc27ca220dd7271da2baef4c6925.png)
  * The domain, unless restricted, is ![x \\in \\mathbb{R}](//upload.wikimedia.org/math/2/3/d/23da9a2f7a5a89587a2101b2113a1455.png)
  * The range is equal to ![\[\\pm a +c\]](//upload.wikimedia.org/math/b/c/e/bce63dad1eac864317773a6b942f6f95.png), as the range of ![y = \\sin\(x\), y \\in \[-1,1\]](//upload.wikimedia.org/math/d/7/4/d74909a6e836008abce390f9314a9a6a.png), see unit circle.
  * The horizontal translation of ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) is reflected in the x-intercepts.
  * Easily sketched by applying graphic transformations, from [VCE Mathematical Methods](/wiki/VCE_Mathematical_Methods)

### Cos

General formula:

  * ![y = a\\cos\(n\(x-b\)\) + c](//upload.wikimedia.org/math/c/8/d/c8d5a5b6cb0eee584d420c4530151249.png)

General Notes:

  * General formula achieved isolating the coefficient of x (n), i.e. the "lonely x rule".
  * The domain, unless restricted, is ![x \\in \\mathbb{R}](//upload.wikimedia.org/math/2/3/d/23da9a2f7a5a89587a2101b2113a1455.png), as ![y = \\cos\(x\), x \\in \\mathbb{R}](//upload.wikimedia.org/math/d/d/b/ddb1b06f33c04e266763f6a018ff73e1.png)
  * A period is equal to ![\[\\frac{2\\pi}{n}\]](//upload.wikimedia.org/math/4/5/1/451ecc27ca220dd7271da2baef4c6925.png), as the factor of n
  * The range is equal to ![\[\\pm a +c\]](//upload.wikimedia.org/math/b/c/e/bce63dad1eac864317773a6b942f6f95.png), as the range of ![y = \\cos\(x\), y \\in \[-1,1\]](//upload.wikimedia.org/math/5/a/f/5aff3594a6959d91b341c60a74c2a498.png), see unit circle.
  * The horizontal translation of ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) is reflected in the x-intercepts.
  * Easily sketched by applying graphic transformations, from [VCE Mathematical Methods](/wiki/VCE_Mathematical_Methods)

### Tan

General formula:

  * ![y = a\\tan\(n\(x-b\)\) + c](//upload.wikimedia.org/math/c/6/9/c69f3645ce07f135ce3d8e12ae37db30.png)

General Notes:

  * General formula achieved isolating the coefficient of x (n), i.e. the "lonely x rule".
  * A period is equal to ![\[\\frac{\\pi}{n}\]](//upload.wikimedia.org/math/6/1/4/61436cc9f3de3a2aa93e02bf369a696a.png)
  * The domain, ![x \\in \\mathbb{R} \\setminus \\frac{k\\pi}{2n}, k \\in \\mathbb{N} ](//upload.wikimedia.org/math/7/6/4/7645f4bdfd641afb6bb2d8b0224625e0.png), as ![ y = \\tan\(x\), x \\in \\mathbb{R} \\setminus \\frac{k\\pi}{2}, k \\in \\mathbb{N}](//upload.wikimedia.org/math/6/4/0/640a1bfd556a7f101f00fcd17bc4cf63.png), indicating the asymptotes.
  * The range, unless restricted, is ![y \\in \\mathbb{R}](//upload.wikimedia.org/math/b/4/8/b48c13c36e260b323b55a8b99ada274d.png), as the range of ![y = \\tan\(x\), y \\in \\mathbb{R}](//upload.wikimedia.org/math/a/0/c/a0cf82b3b3ddb47d6b66aed284ae59da.png), see unit circle.
  * The horizontal translation of ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) is reflected in the x-intercepts.
  * Easily sketched by applying graphic transformations, from [VCE Mathematical Methods](/wiki/VCE_Mathematical_Methods)

### Arcsin

Also known as ![Sin^-1](//upload.wikimedia.org/math/1/0/4/1047d46492325c27bab00589e36d7b41.png) or ![sin^-](//upload.wikimedia.org/math/1/c/9/1c989d7138470e478453d601b41c3930.png)

### Arccos

Also known as ![Cos^-1](//upload.wikimedia.org/math/8/6/f/86f52b06bcb6f85d21c2455cf3520e13.png) or ![cos^-](//upload.wikimedia.org/math/3/3/f/33fece48f4e61f46a93dcf1bf0bdd077.png)

### Arctan

Also known as ![Tan^-1](//upload.wikimedia.org/math/7/b/e/7be0830783bb0c42bee152d99de55181.png) or ![tan^-](//upload.wikimedia.org/math/0/b/d/0bd0fb9b9138813f3d18c21582f6a906.png)

## Examples

### Graphing Functions

#### General Method

##### Trigonometric Functions Method

##### Reciprocal Trigonometric Functions Method

##### Inverse Trigonometric Functions Method

### Sin

### Cos

### Tan

### Arcsin

### Arccos

### Arctan

## Complex Numbers

## Preface

**Formal Definition:** A complex number is a number comprising a real and imaginary part (![ z = x +yi ](//upload.wikimedia.org/math/3/0/5/3056520516e89b2432994e51bed5445e.png)), where x and y are real numbers, and i is the standard imaginary unit with the property ![i^2 = -1, i = \\pm \\sqrt{-1}](//upload.wikimedia.org/math/6/9/f/69feeea4e3e64a8e0bba76cde6ea01f4.png), a property that has led the the discovery of the fundamental theorem of algebra. The complex number field (![\\mathbb{R} \\in \\mathbb{C}](//upload.wikimedia.org/math/b/7/d/b7d7f11ebd184bcaf7c3de6faa9d30b9.png)) is a superset of the real number field.

**Translation:** i represents numbers that don't exist, and acts as a convenient placeholder, thus allowing one to get the roots of any polynomial. The fundamental theorem of algebra states that any polynomial as the same number of roots, as its highest power. All complex numbers are examples of vectors on a different plane, commonly called an Argand diagram.

## Relations and Regions in the Complex Plane

## Preface

**Formal Definition:** In mathematics, the complex plane, z-plane, Argand diagrams are a geometric representation of the complex numbers established by the real axis and the orthogonal imaginary axis. It can be thought of as a modified Cartesian plane, with the real part of a complex number represented by a displacement along the x-axis, and the imaginary part by a displacement along the y-axis.

**Translation:** All complex numbers are vectors, they have direction, magnitude, and can be displayed using Cartesian-like coordinates on a modified Cartesian plane, or can be manipulated in polar form. Common formations are rays (angles), circles, ellipses, and other common Cartesian graphs.

## Differential Calculus

## Preface

**Formal Definition:** In mathematics, differential calculus is a subfield of calculus concerned with the study of how functions change when their inputs change. The primary object of study in differential calculus is the derivative. A closely related notion is the differential. The derivative of a function at a chosen input value describes the behavior of the function near that input value. For a real-valued function of a single real variable, the derivative at a point equals the slope of the tangent line to the graph of the function at that point. In general, the derivative of a function at a point determines the best linear approximation to the function at that point.

**Translation:** Its all about gradients, tangents, normals, finding turning points, and the nature of turning points - fast.

## Integral Calculus

## Preface

**Formal Definition:** Integration is an important concept in mathematics and, together with differentiation, is one of the two main operations in calculus. Given a function ƒ of a real variable x and an interval [a, b] of the real line, the definite integral is defined informally to be the net signed area of the region in the xy-plane bounded by the graph of ƒ, the x-axis, and the vertical lines x = a and x = b.

    ![\\int_a^b \\! f\(x\)\\,dx \\,](//upload.wikimedia.org/math/1/8/4/1845918e723ad0b5874fa2fb77870925.png)

**Translation:** Its all about finding the equation of higher level graphs and the areas of lower level ones - fast.

## Differential Equations

## Preface

**Formal Definition:**

**Translation:**

## Kinematics

## Preface

**Formal Definition:**

**Translation:**

## Vectors

## Preface

**Formal Definition:**

**Translation:**

## Vector Calculus

## Preface

**Formal Definition:**

**Translation:**

## Mechanics

## Preface

**Formal Definition:**

**Translation:**

# Appendices: Units 3 and 4

## Formulae

## Preface

This is a list of all formulae needed for [Units 3 and 4: Specialist Mathematics](/wiki/VCE_Specialist_Mathematics/Units_3_and_4:_Specialist_Mathematics).

## Formulae

### Ellipses, Circles and Hyperbolas

#### Ellipses

**General formula:**

  * ![\\frac{\(x-h\)^2}{a^2} + \\frac{\(y-k\)^2}{b^2} = 1](//upload.wikimedia.org/math/a/9/c/a9ce1392a08f8795bd12ecfccd68c66b.png)

**General Notes:**

  * Point ![\(h,k\)](//upload.wikimedia.org/math/6/d/9/6d97efba171c113b80a8d43e78249b46.png) defines the ellipses center.
  * Points ![\(\\pm a + h,k\)](//upload.wikimedia.org/math/6/6/5/665715214f640147e59573f5543adcf2.png) defines the ellipses domain, and horizontal endpoints - i.e. horizontal stretch.
  * Points ![\(h,\\pm b + k\)](//upload.wikimedia.org/math/0/1/7/017010324aab42387c337d390db3a803.png) defines the ellipses range, and vertical endpoints - i.e. vertical stretch.

#### Circles

**General formula:**

  * ![\(x-h\)^2 + \(y-k\)^2 = r^2](//upload.wikimedia.org/math/0/1/f/01fe026cb49c1188469f9b17cebb41a9.png)

**General Notes:**

  * Point ![\(h,k\)](//upload.wikimedia.org/math/6/d/9/6d97efba171c113b80a8d43e78249b46.png) defines the circles center.
  * Points ![\(\\pm r + h,k\)](//upload.wikimedia.org/math/f/4/f/f4f45d874d752d3c6b5b97bcf5e93d4d.png) defines the circles domain - i.e. stretch.
  * Points ![\(h,\\pm r + k\)](//upload.wikimedia.org/math/4/8/3/483b07f8844447b555da9637d34cb082.png) defines the circles range - i.e. stretch.
  * A circle is a subset of an ellipse, such that ![a = b = r](//upload.wikimedia.org/math/7/6/b/76b45b1cd17289a5edf1cc727c53a5a7.png).

#### Hyperbolas

**General formulae:**

  * ![\\frac{\(x-h\)^2}{a^2} - \\frac{\(y-k\)^2}{b^2} = 1](//upload.wikimedia.org/math/9/3/6/9360ecd574ab3bc5074ef6fdf61a1318.png)
  * ![\\frac{\(y-k\)^2}{b^2} - \\frac{\(x-h\)^2}{a^2} = 1](//upload.wikimedia.org/math/4/f/8/4f8d5c6d0e8001de40c1558486581c59.png)

**General Notes:**

  * Point ![\(h,k\)](//upload.wikimedia.org/math/6/d/9/6d97efba171c113b80a8d43e78249b46.png) defines the hyperbolas center.
  * Points ![\(\\pm a + h,k\)](//upload.wikimedia.org/math/6/6/5/665715214f640147e59573f5543adcf2.png) defines the hyperbolas domain, ![\[\\pm a + h, \\pm \\infty\)](//upload.wikimedia.org/math/7/c/4/7c43ee31e47950ac5401eaed325e1228.png).
  * The switch in positions of the fractions containing x and y, indicate the type of hyperbola - i.e. vertical or horizontal. The hyperbola is horizontal in the first, and negative in the second of the General hyperbolic formulae above.
  * Graphs ![y=\\pm \(\\pm a + h,k\)](//upload.wikimedia.org/math/6/d/7/6d73d3636eb9f588e31466106d806f07.png) defines the hyperbolas domain ![\[\\pm a + h, \\pm \\infty\)](//upload.wikimedia.org/math/7/c/4/7c43ee31e47950ac5401eaed325e1228.png).

### Trignometric Functions

#### Sin

General formula:

  * ![y = a\\sin\(n\(x-b\)\) + c](//upload.wikimedia.org/math/1/5/e/15e04e437962c6b6a6d67677e162d85a.png)

General Notes:

  * General formula achieved isolating the coefficient of x (n), i.e. the "lonely x rule".
  * A period is equal to ![\[\\frac{2\\pi}{n}\]](//upload.wikimedia.org/math/4/5/1/451ecc27ca220dd7271da2baef4c6925.png)
  * The domain, unless restricted, is ![x \\in \\mathbb{R}](//upload.wikimedia.org/math/2/3/d/23da9a2f7a5a89587a2101b2113a1455.png)
  * The range is equal to ![\[\\pm a +c\]](//upload.wikimedia.org/math/b/c/e/bce63dad1eac864317773a6b942f6f95.png), as the range of ![y = \\sin\(x\), y \\in \[-1,1\]](//upload.wikimedia.org/math/d/7/4/d74909a6e836008abce390f9314a9a6a.png), see unit circle.
  * The horizontal translation of ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) is reflected in the x-intercepts.

#### Cos

General formula:

  * ![y = a\\cos\(n\(x-b\)\) + c](//upload.wikimedia.org/math/c/8/d/c8d5a5b6cb0eee584d420c4530151249.png)

General Notes:

  * General formula achieved isolating the coefficient of x (n), i.e. the "lonely x rule".
  * The domain, unless restricted, is ![x \\in \\mathbb{R}](//upload.wikimedia.org/math/2/3/d/23da9a2f7a5a89587a2101b2113a1455.png), as ![y = \\cos\(x\), x \\in \\mathbb{R}](//upload.wikimedia.org/math/d/d/b/ddb1b06f33c04e266763f6a018ff73e1.png)
  * A period is equal to ![\[\\frac{2\\pi}{n}\]](//upload.wikimedia.org/math/4/5/1/451ecc27ca220dd7271da2baef4c6925.png), as the factor of n
  * The range is equal to ![\[\\pm a +c\]](//upload.wikimedia.org/math/b/c/e/bce63dad1eac864317773a6b942f6f95.png), as the range of ![y = \\cos\(x\), y \\in \[-1,1\]](//upload.wikimedia.org/math/5/a/f/5aff3594a6959d91b341c60a74c2a498.png), see unit circle.
  * The horizontal translation of ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) is reflected in the x-intercepts.

#### Tan

General formula:

  * ![y = a\\tan\(n\(x-b\)\) + c](//upload.wikimedia.org/math/c/6/9/c69f3645ce07f135ce3d8e12ae37db30.png)

General Notes:

  * General formula achieved isolating the coefficient of x (n), i.e. the "lonely x rule".
  * A period is equal to ![\[\\frac{\\pi}{n}\]](//upload.wikimedia.org/math/6/1/4/61436cc9f3de3a2aa93e02bf369a696a.png)
  * The domain, ![x \\in \\mathbb{R} \\setminus \\frac{k\\pi}{2n}, k \\in \\mathbb{N} ](//upload.wikimedia.org/math/7/6/4/7645f4bdfd641afb6bb2d8b0224625e0.png), as ![ y = \\tan\(x\), x \\in \\mathbb{R} \\setminus \\frac{k\\pi}{2}, k \\in \\mathbb{N}](//upload.wikimedia.org/math/6/4/0/640a1bfd556a7f101f00fcd17bc4cf63.png), indicating the asymptotes.
  * The range, unless restricted, is ![y \\in \\mathbb{R}](//upload.wikimedia.org/math/b/4/8/b48c13c36e260b323b55a8b99ada274d.png), as the range of ![y = \\tan\(x\), y \\in \\mathbb{R}](//upload.wikimedia.org/math/a/0/c/a0cf82b3b3ddb47d6b66aed284ae59da.png), see unit circle.
  * The horizontal translation of ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) is reflected in the x-intercepts.

#### Arcsin

Also known as ![Sin^-1](//upload.wikimedia.org/math/1/0/4/1047d46492325c27bab00589e36d7b41.png) or ![sin^-](//upload.wikimedia.org/math/1/c/9/1c989d7138470e478453d601b41c3930.png)

#### Arccos

Also known as ![Cos^-1](//upload.wikimedia.org/math/8/6/f/86f52b06bcb6f85d21c2455cf3520e13.png) or ![cos^-](//upload.wikimedia.org/math/3/3/f/33fece48f4e61f46a93dcf1bf0bdd077.png)

#### Arctan

Also known as ![Tan^-1](//upload.wikimedia.org/math/7/b/e/7be0830783bb0c42bee152d99de55181.png) or ![tan^-](//upload.wikimedia.org/math/0/b/d/0bd0fb9b9138813f3d18c21582f6a906.png)

## Practice SACS

## Preface

This page serves to collate and organize as many content-released SACs as possible, in addition to their solutions.

## 2006

2006

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2007

2007

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2008

2008

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2009

2009

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2010

2010

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## Practice Exams

## Preface

This page serves to collate and organize as many content-released practice exams as possible, in addition to their solutions.

## 2006

2006

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2007

2007

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2008

2008

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2009

2009

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## 2010

2010

Author(s) Institution(s) Paper(s) Paper Solution(s)

Author
Institution
Paper
Solution

Author
Institution
Paper
Solution

## Common Math Hacks

## Preface

This page serves to categorize and organize commonly used mathematical hacks, which allow their users to complete questions faster, and with a greater deal of accuracy.

## Units 3 and 4: Specialist Mathematics

### Coordinate Geometry

#### Ellipses, Hyperbolas

The values ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) and ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) can be fractional, as can be seen by taking the following equation:

  * ![\\frac{4\(x\)^2}{1} + \\frac{16\(y\)^2}{1} = 1](//upload.wikimedia.org/math/5/4/d/54dffd294fc06f63fcb889289b3a8677.png) where ![ a = \\frac{1}{2}, b = \\frac{1}{4}](//upload.wikimedia.org/math/0/9/2/0925d702be9e491e351af3f29da9c2c6.png)

Equations found in questions may not be in the general form, and may need to be transformed via the complete the square method::

#### Circles

Equations found in questions may not be in the general form, and may need to be transformed via the complete the square method, in conjunction with extricating all variables from under root symbols; an example follows:

  


### Circular Functions

### Complex Numbers

### Relations and Regions in the Complex Plane

### Differential Calculus

### Integral Calculus

### Differential Equations

### Kinematics

### Vectors

### Vector Calculus

### Mechanics

## Common Exam Mistakes

## Preface

This page serves to categorize and organize common exam mistakes, found in both the assessors reports, and in general usage.

## Units 3 and 4: Specialist Mathematics

### Coordinate Geometry

### Circular Functions

### Complex Numbers

### Relations and Regions in the Complex Plane

### Differential Calculus

### Integral Calculus

### Differential Equations

### Kinematics

### Vectors

### Vector Calculus

### Mechanics

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&oldid=1749514](http://en.wikibooks.org/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&oldid=1749514)" 

[Category](/wiki/Special:Categories): 

  * [VCE Specialist Mathematics](/wiki/Category:VCE_Specialist_Mathematics)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=VCE+Specialist+Mathematics%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=VCE+Specialist+Mathematics%2FPrint+Version)

### Namespaces

  * [Book](/wiki/VCE_Specialist_Mathematics/Print_Version)
  * [Discussion](/w/index.php?title=Talk:VCE_Specialist_Mathematics/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/VCE_Specialist_Mathematics/Print_Version)
  * [Edit](/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&action=edit)
  * [View history](/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/VCE_Specialist_Mathematics/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/VCE_Specialist_Mathematics/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&oldid=1749514)
  * [Page information](/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=VCE_Specialist_Mathematics%2FPrint_Version&id=1749514)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=VCE+Specialist+Mathematics%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=VCE+Specialist+Mathematics%2FPrint+Version&oldid=1749514&writer=rl)
  * [Printable version](/w/index.php?title=VCE_Specialist_Mathematics/Print_Version&printable=yes)

  * This page was last modified on 2 April 2010, at 10:25.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/VCE_Specialist_Mathematics/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
