# College Survival Guide/Print version

From Wikibooks, open books for an open world

< [College Survival Guide](/wiki/College_Survival_Guide)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=College_Survival_Guide/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=College_Survival_Guide/Print_version) on _27 April 2009_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=College_Survival_Guide/Print_version&oldid=1482859&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


## Contents

  * 1 Is going to college worth my time
    * 1.1 Is it really?
      * 1.1.1 The Artist
      * 1.1.2 The Scientist
      * 1.1.3 'Yes' and 'No' Summary
    * 1.2 Recommended Reading
  * 2 Preparing for College
  * 3 Introduction
    * 3.1 What is College like?
    * 3.2 Choosing a School
      * 3.2.1 External Links
    * 3.3 The Entrance Exam
    * 3.4 Picking your Major and Minor
    * 3.5 Talking to a Counselor
      * 3.5.1 Choosing Transferable Courses
      * 3.5.2 Making a Wise Choice
        * 3.5.2.1 Experiences
  * 4 Testing for College Credit
  * 5 The CLEP
  * 6 Portfolio/ Life experience
  * 7 Improving Writing Skills
  * 8 Introduction
  * 9 The Philosophy of Language
  * 10 Linguistics
  * 11 Grammar
    * 11.1 Websites to Visit for Grammar
    * 11.2 Obtaining Grammar Books
  * 12 Rhetoric
    * 12.1 Content and Form
      * 12.1.1 Practicing Writing Skills
    * 12.2 Style and Rhetoric
  * 13 Writing in General
    * 13.1 Coherence
    * 13.2 Proofreading
    * 13.3 My Favorite Way to Save Files
    * 13.4 Writing Workshops
      * 13.4.1 Writing Communities
  * 14 Types of Papers
    * 14.1 Essay
    * 14.2 Thesis Paper
      * 14.2.1 Paragraph One
      * 14.2.2 Body
    * 14.3 Argumentative Research Paper
      * 14.3.1 History of Argumentation
        * 14.3.1.1 Suggested Readings and other Media
      * 14.3.2 Why should people argue?
      * 14.3.3 What are you proving?
      * 14.3.4 The Technical side of Argumention
      * 14.3.5 Argumentation in Media
      * 14.3.6 Sources
      * 14.3.7 More Reading
        * 14.3.7.1 Books
        * 14.3.7.2 Websites
  * 15 Improving Reading Skills
  * 16 Improving Reading Skills
    * 16.1 Read the Course Books Before the Semester Starts
    * 16.2 Write Down What You Don't Understand
    * 16.3 Highlight what you don't understand
  * 17 Improving Research Skills
  * 18 Research
    * 18.1 Internet Research
    * 18.2 Library Research
    * 18.3 Field Research
    * 18.4 Library vs. Internet
  * 19 Resources
    * 19.1 Books
    * 19.2 Databases
    * 19.3 Magazines
    * 19.4 Newspapers
  * 20 Taking notes of Resources
    * 20.1 Citing Resources
    * 20.2 Copying Resources
    * 20.3 Organizing Resources
    * 20.4 Photographing Resources
  * 21 Learning at the College level
  * 22 Introduction
    * 22.1 Choosing your topic of study
  * 23 The College Bookstore is your friend
  * 24 The Library is your friend
    * 24.1 The Librarian is your friend
    * 24.2 The Databases are your friend
    * 24.3 Email is your friend
  * 25 Rotating Books is your Friend
  * 26 Choosing Supplies
  * 27 Supplies for College
  * 28 Laptop or Desktop?
    * 28.1 **Do I need a laptop?**
    * 28.2 About Alternatives
      * 28.2.1 More External Links
    * 28.3 MS Office or...?
      * 28.3.1 Notes about the Jumpdrive
    * 28.4 Learn FTP
  * 29 Choosing a Class
  * 30 Introduction
    * 30.1 Don't Choose a Class you Hate
    * 30.2 College and Hobbies
  * 31 Creating a Planner
  * 32 Introduction
    * 32.1 Creating a Class Schedule
    * 32.2 Preparing to avoid the planning fallacy
    * 32.3 Setting up a Reading Schedule
      * 32.3.1 Sources
  * 33 Going to Class
    * 33.1 Reasons
    * 33.2 Lack of Sleep
  * 34 Studying
    * 34.1 Going to the Library
    * 34.2 See Also
  * 35 Etiquette
    * 35.1 Your position as a student
    * 35.2 Your rights as a student
    * 35.3 Talking in Class
    * 35.4 Not Talking in Class

# Is going to college worth my time

## Is it really?

I could cut to the chase and say in many ways that it is not worth your time. However, college and universities are academic institutions that have been around since the late 1700s in the United States. These places were once a place people sent their children to obtain an "education," which was to help them be successful for the future. Yet this education was mediocre at best and didn't help prepare students of early-America. However, colleges have impacted the way of America and continues to impact its future.

Yet you have colleges of today that are built to guide students, or so they say. In reality, however, college is an academic 'institution' that has been around enough to have an impact on society. Some members of society hold college educated people in high regard. Although this somewhat conflicts with egalitarian views along with other views, the "reality" remains that a college education affects the way people perceive the degree-holder.

Some people believe a college education gives a person a background, a track record if you will. These could also lead to a person having credentials and credibility. In other words, college gives a person experience which can be shown to the world on a resume. It is the realization that people hold this background in high regard that creates a situation for college students. Those who don't have a background may encounter scrutiny from employers, and college gives a person a background. College builds someone a status and a background. Most people are not allowed into an institution (business or other) without a background. Some people would call this "institution conflict." If you don't have recognition from one, you won't be recognized by the other.

Many people wish to destroy this institution conflict by destroying the institutions. However, some people believe the best way to do that is through espionage or becoming one of the collective. You've got various things that have changed since the 1700s. Most of all, you have the Internet. Yet the Internet has many people who were college educated. It is these people who are guiding others to knowledge. As time goes on, the amount of accurate information will present itself to people; and the possibility of a truly free education may become a reality. However, experience is the thing that colleges offer that the Internet does not. Unless a person does experiments, keeps logs, and gets certification through exams and testing, proving you've got experience is a very difficult task.

* * *

Interestingly, however, is that experience can be gained in many different ways:

* * *

### The Artist

Some people say artists ought learn in college. College gives an artist a knowledge background as to methods, materials, art history, aesthetics, and other aspects of art. Some people would call this a 'formal' education in art. However, some artists don't need to go to college. These people are artists. They create art, and their ability to create art comes from talent and so forth. Whether or not these people are considered artists is up to aesthetics and debate, but a person doesn't need a college degree to be considered an artist. Artists draw, paint, sculpt, and do many other things with resources and mediums. Some artists graduate college and don't find a job right away. In other words, the ability to create art is more about experience, less about formal knowledge. Although, formal knowledge allows the artist to understand techniques, but such things can be learned out of various art books.

Artists show experience through a portfolio. However, the artist may want to take into consideration a type of formal education. This formal education may come from a freelance art teacher or through various art books.

### The Scientist

On the other end of a spectrum you've got the scientist. This is the kind of person that finds graduating from college a necessity. The reason college is a necessity for this kind of person is for various reasons. One would be ethics, which discuss how science is to act in the future according to society. Another is a formal education in lab work, which often a group of persons doing experimentation. In whole, the scientist often goes to college in order to receive a formal education and work with a group of persons toward a common goal.

### 'Yes' and 'No' Summary

Yes and no. This all depends on a few factors. One of the factors is what you want to accomplish in the long run.

Want to be a computer scientist/mathematician/physicist/linguist/translator?

    Go to college and make the best grades you can.

Want to be a biologist/chemist?

    Go to college, because ethical concerns exist when employing people without proper training.

Want to be a scientist/doctor/neuroscientist?

    Same as above.

Want to be an artist/actor?

    You probably don't need to go. Most artists only need a portfolio to prove to others they are the cream of the crop. Colleges and universities don't really help these type of people. Many artists from earlier days rejected the schools and became famous. Salvador Dali was an artist who saw himself better than the teachers and later worked with Picasso.

Want to be a graphic designer/businessman or -woman?

    You need training. Who is going to hire an interior decorator with no experience? The easiest place to get experience is college. And to get a job in the business world, unless you want to stay in an entry-level position, a degree is required.

In all reality, if someone holds a four-year-degree, he or she should be able to find a job somewhere. So college is your best bet for job security!

## Recommended Reading

Bird, Caroline: _[The Case Against College_](http://www.amazon.com/gp/product/0679505199/sr=8-1/qid=1144943820/ref=sr_1_1/103-7250417-4046242?%5Fencoding=UTF8) (1972)

  


# Preparing for College

# Introduction

Knowing how college works ahead of time will lead to great success. The more prepared one is for college, the more likely he or she is going to succeed.

## What is College like?

College is a place of confusion. If you don't have parents or siblings with a PhD or other degree, many of your decisions are going to be out in the dark. Even if you do, they may have been out of the "system" so long that they have forgotten how it works. When going into college the first time, being misguided often happens. Many people keep quiet about the truth of college. To keep quiet will only keep people nescient. The choices to make, actions to take, and the many habits one must break are often not known. College is place for those who want a higher education or who want to obtain a certain profession.

College can be seen as a different world in its own. For those who are academically rigorous, they may not get outside often enough. Sometimes friendships are put on hold with people to finish an assignment. To compensate for these effects of college, many join a school club.

It is often said the food around a college is not great at all. People are sometimes left with the choice of having a coffee and donut. Other times, people will have to eat pizza (which is very common) but will get sick after eating pizza everyday for a few months. If not pizza, then a very expensive meal costing way above normal could be a healthy choice. The smart choice is to make a meal yourself.

Malnutrition and antisocial behavior is common at college, despite the vision media gives it. Many scientific and sociological studies conclude that college students aren't eating properly. Malnutrition is one of the worst things for the brain when acquiring knowledge and using it.

The professors at college are not to be called teachers. There is a general misconception that professors are teachers. No; a professor is an expert in his or her field of study. Professors in many college and university institutions do not need to pass a teaching course or exam.

Professors are not teachers; however, they try to teach material. This is where college is different than high school (secondary education) in North America. In North America, teachers-to-be must pass exams and courses to become a certified teacher. In college, however, there are no exams or courses needed to teach someone. There is a prerequisite that people hold a Master's Degree or higher to "teach" in post-secondary education.

Many academic students frown upon this as college is a learning environment. Sadly, it is a place where people show their skills in a study, more than they learn. Sometimes, there are professors that will actually teach more than make someone do hard work. To compensate for the good and the bad, one must learn to adjust to prepare for the paradox of college.

## Choosing a School

### External Links

  * [What is a good school?](http://www2.studentsreview.com/articles/what-is-a-good-school.php3)
  * [College and University Info](http://college-university.infodiv.com) Lots of Free Information and Resources on College and University

## The Entrance Exam

The exams usually focus on your Literature and Science skills. Some tests focus on your English and Math skills. Some tests focus on foreign language skills. Either way, a person will take an entrance exam test. What a person should do is before taking the exam, learn as much as he or she can about it. Some colleges only allow a person to take the exam twice. This is why learning about the test is important. Study and review some of the math you already know for about five days.

After taking the exam, if a person doesn't do as well as he or she hoped the first time, then he or she could try again. However, some people believe the entrance exam is how colleges make their money. Students who have a high level of math understanding will often be placed down to a lesser math level. Even though the student may know the math, the exam scores may say a person must take "Intermediate Algebra and Geometry".

Some people will try to study the course material by getting a few books, studying them, and retesting. Being that the author has tried this, long ago, the author recommends you try to learn _everything_ in the course book in 16 days. After 16 days, take the test and try to test out. If you can't, just take the course. Although, many people despise this exam system, is better to take the course and get over with it than wasting three months studying the book, taking the test, and again, not passing. Summer courses often last about one month, and if a person already knows the material, and he or she really does know the material, he or she should be able to pass the course easily. It's better to take a course and be over with it than to try and beat the system. Remember, 16 days of full devotion.

## Picking your Major and Minor

**What is a major?**

A major is the type of career you want to obtain. You are largely focusing on certain types of courses so you can get that career. The majority of courses in your course schedule are going to help you get that career.

**What is a minor?**

If you find out years later you don't like your major, you could switch to your minor. A minor is the type of career you want to fall back on. You are slightly focusing on certain types of courses as a fall-back career. The minority of courses in your course schedule will lead you towards that fall-back career.

## Talking to a Counselor

When talking to a counselor, a person needs to know his or her long-term and short-term goals.

**Questions to ask yourself:**

  * 1\. What do I want for a career?
  * 2\. How much do I _really_ know about the career?
  * 3\. Have I researched the career in depth?
  * 4\. What type of things does a person in that career field know?

    

    Psychology? Sociology? Chemistry? Physics? Biology? Other?

  * 5\. What courses do I need to take to get that career?

Number five becomes the most important question once you understand what type of career you want. This will be one of the questions you will focus on when talking to a counselor. Write the question down to ask later.

**More questions to ask:**

  * 6\. Do the courses I take here for that career--transfer to a different school?
  * 7\. What school do I want to transfer to?
  * 8\. What courses transfer to that school?

Oftentimes, counselors are very busy with many other people. Sometimes, they don't care to help people as much as they can. This isn't always the case, though. Counselors are not the Internet; therefore, they do not know everything that is accepted by every college and university. They try their best, but often they don't have the answers.

Before going to a counselor, a person should study what courses transfer to a college or university. Make a call to the school, go visit the school, or locate the school's website on the Internet and inquire what courses transfer. Many universities and college have a website directory that tells what courses are similar to others. If you are completely clueless to the school's website, you could go to the counselor and ask for them to help you find the information on the website.

The main concept to keep here is this:

I want a certain career. I need to take certain types of courses to get that career. If my current school does not have all of those courses, but they have a few, what courses transfer to another school? How can I be assured these courses transfer? I need proof these courses transfer.

  * 9\. How many courses can I transfer.

Ah, the really tricky of questions. This is often a situation that many college students become annoyed with. In this wikibook I recommend someone take a few years of a modern language and mathematics. There is a grand logic to this, which I will explain in the next section.

### Choosing Transferable Courses

When transferring to a different college or university, many students notice a large amount of credits/hours do not transfer.

Why is this?

Well, simply put, colleges are like businesses: They want you to retake a course and they want to earn more money from students. Many colleges and universities would not talk about college being a business.

Also, the teaching curriculum and standards of one school may be different than another school. In other words, the learning material in a different school may be more rigorous, complex, detailed, in depth, or etc.

Talk with one college's counsler, and get that counsler to talk about courses being transferable or not. You want courses that can transfer from one college to the next. Sometimes you will have to call someone, write to someone, or meet with someone at a different college to obtain information about credits/hours that are accepted.

### Making a Wise Choice

For many careers, taking English and Mathematics to a certain extent is required. Often, if a person is going to a local college, then he or she can take Mathematics and English courses for a lower price. The first two years of college for many are filled with taking courses that don't relate to their major. The wise who want to transfer to a different college may not take those unrelated courses right away.

Some Liberal Arts (Non-fiction writing 120, Shakespeare 101, etc.) courses do not transfer as well as Mathematics and Foreign language. Many universities require someone to have at least four years of foreign language from a high school. If not that, they require someone to have at least two years of foreign language from a college. Many also like the idea of students having four years of high school Mathematics. To have four years of mathematics would mean someone has taken Calculus before he or she graduates high school.

  * 1 college semester = 1 high school year
  * 4 years H.S. = 2 years college.

    

    College goes twice as fast as regular high school.

#### Experiences

One of the things I've learned in college is that a few courses exist that have a better chance than others to transfer. Taking math and language courses are the best choice for an undergraduate.

**Modern Language:**

  * Spanish
  * German
  * French

    In the United States, Spanish is the most common language for college transfer.

**Mathematics:**

  * Calculus and above

If a college were to be shrewd and not accept these courses, a person could simply test out; the nice thing about choosing this type of courses is its ease to be quickly reviewed to pass a test. The test usually will quiz someone on his or her current knowledge of the class material.

As long as someone takes a modern language and mathematics, it is likely the courses will transfer to a public university. If not, then someone could most likely test out.

  


# Testing for College Credit

This part of the book is directed more toward United States students. However, there may be tests in which other students of different regions may take.

# The CLEP

  * <http://www.collegeboard.com/student/testing/clep/about.html>

# Portfolio/ Life experience

Obtain credits from accredited institutions

Long-distance/online

  * [Charter Oak State College](http://www.charteroak.edu/programs/portfolio/index.cfm) In-state tuition for Connecticut residents
  * Many others (stub)

(I am not related to the institution(s).)

  


# Improving Writing Skills

# Introduction

Some people ignored English while growing up; some people weren't taught correctly; and others didn't understand what was going on. Whether you fit those group of people or not, this guide is to excel your learning in the English language. However, before we hit head-on to becoming a great writer, I'm going to cover some basic steps. I can't make you a great writer in this wikibook, nor am I a "great" writer myself. I can, however, show you the paths to walk. I'm being semi-modest. Also, there's another wikibook working on that.

A person will not survive post-secondary education very long if he or she does not have proper usage of the English language.

Grammar and writing are essential parts to creating a paper in an institution of higher learning. In a college or university, writing papers is a common task students must undertake. A typical college paper will be about five pages in length; and within that length, some grammar and spelling mistakes could be made. Some professors grade on grammar, while others do not. The grading of a paper depends on many factors: course level, course, paper requirements, etc. As someone goes into higher level courses, grammar becomes a concern to professors. Not only is it a concern, but being at a higher level means you are to become more of a professional. Thus, you will need to write like a professional. Some people might think this is too much trouble. Don't think learning this stuff is too much trouble. If you don't learn it, _you'll be in trouble_.

We've got four basic hierarchies of writing:

  1. **The Philosophy of Language**: The building blocks of linguistics and more
  2. **Linguistics**: The building blocks of language
  3. **Grammar**: The building blocks of a language's linguistic usage
  4. **Rhetoric**: The building blocks of presenting and identifying grammar, linguistics, and philosophical ideas in language.

The reason all of these should be studied is simple: They all have something to do with each other. It is suggest that a person starts from number one and goes up toward rhetoric. When people understands each rung of the ladder, they will be able to understand and analyze the way material is presented. Also, understanding each level will help a person present information. If you're new to college, you're going to be typing papers for the next two or more years. It's better to start now by understanding language. It may be difficult, but my advice is this: _Learn faster_.

* * *

By the time you're done learning this stuff, you ought to be able to diagram a sentence, make corrections in Wikipedia projects, and make a coherent paragraph with style. Hopefully, you'll be a little bit more of a bibliophile. If you don't have one, you might even go out to buy a bookshelf.

Also, by the time you're done, you ought to be a novice philosopher, linguist, grammarian, and rhetorician. You may be thinking this is a lot of effort, and this is a lot of effort. But the more energy you direct toward a cause that will effect your writing abilities is a good thing. I wanted to create a systemized way of becoming a decent writer through this webpage. By having a pathway, you won't be wasting too much energy scrambling for information in different directions. If you still think this is too much work, then I will give you my most powerful philosophy:

Power = work/time

\- Learn faster - Work harder - And take the efficient pathway to least resistance

* * *

# The Philosophy of Language

I remember throughout high school that my teachers would banter about a "well-rounded education"; however, I don't quite remember them talking about [philosophy](http://en.wikipedia.org/wiki/Philosophy). Some people don't teach philosophy in high school because it would give students [critical thinking](http://en.wikipedia.org/wiki/Critical_thinking) skills. And people don't want young students to [argue](http://en.wikipedia.org/wiki/Argumentation) against those who may have critical thinking skills. In other words, philosophy enables a person to think about the way the universe, the world, its society, and the way a individuals work. As much as it would anger other philosophers to give my own definition of philosophy, I'm going to say it is the thing that enables a person to have a well-rounded education. Without a ground in philosophy, a person will never obtain a well-rounded education. Teachers and faculty have been stating things, but they haven't been explaining things.

Let's explain:

Philosophy is the groundwork for science, art, math, neuroscience, psychology, sociology, etc. You name it, you've probably got philosophy in there, somewhere. Whether its the arguable aspects of a single point in space being a circle or a questionable, metaphysical theory about the mind's energy states and [dissociative identity disorder](http://en.wikipedia.org/wiki/Dissociative_Identity_Disorder), you've got philosophy to argue about it and have people establish its groundwork. Although the latter may seem like a pseudo-scientific claim, it related to the philosophy of mind; and you've got philosophy that determines how language works, is represented, and is presented.

Philosophy is the foundation. If you ever have trouble understanding a topic, you could always search for the "Philosophy of _____."

    The Philosophy of Psychology
    The Philosophy of Rhetoric
    The Philosophy of Education
    etc.

  * Here's an example of the philosophy of language: <http://forums.philosophyforums.com/thread/22078>
  * Here's another example: <http://forums.philosophyforums.com/thread/20848>

Yet again, I'm going to ask you to cross a bridge and walk a path designed by local villagers. Some have an idea of what makes a good pathway, but others aren't too sure. Regardless of their efforts, they tried their best to represent their ideal pathway:

  * <http://en.wikipedia.org/wiki/Philosophy_of_language>

Every term you ever read from these philosophy webpages is very important; however, remembering them all is daunting. Therefore, it is suggested that you look over these things at least one hour a day and try to memorize and understand them.

Also, before you go to college or if you're already there, I suggest you rent a book from your local library. You're going to be reading a lot of books in college. And you might as well learn that fact by stepping up your knowledge of language. Just about every book uses language, and the book I suggest you grab will, too. The book you grab would be about the philosophy of language. Although some people may have their own views of the way the philosophy of language works, it will establish a groundwork for you. Afterwards, you can move onto linguistics. You can, however, mix and match the hierarchal things listed in the introduction if you you're bored with one. Doing this will enable you to have a better view of how they connect to each other.

# Linguistics

Here's a overview of linguistics: <http://en.wikipedia.org/wiki/Linguistics>

Again, try to understand the terms used. You don't need to--although it would be great to--memorize all the terms right away. However, remembering the terms allows you to identify the way language is used. Identification of language is a very important skill in becoming a writer.

  
(This section is being worked on)

# Grammar

Grammar can be descriptive or prescriptive. However, the kind of grammar emphasized will be of the descriptive flavor.

  * Read this: <http://en.wikipedia.org/wiki/Prescription_and_description>
  * Review this: <http://en.wikipedia.org/wiki/Prescription_and_description#Prescription_and_description>
  * Read this: <http://en.wikipedia.org/wiki/Descriptive_linguistics>

Note: Because this Wikibook is slanted and written mostly in English, it will be focusing on English grammar. However, many of the same principles could be applied to foreign languages.

## Websites to Visit for Grammar

  * [How to Speak and Write Correctly by Joseph Devlin](http://www.gutenberg.org/etext/6409)
  * [English Usage, Style & Composition](http://www.bartleby.com/usage/)
  * [Guide to Grammar & Writing](http://grammar.ccc.commnet.edu/grammar/)

## Obtaining Grammar Books

Grammar is an essential part to writing (typing) a paper. Sometimes, a person must relearn grammar and practice his or her English skills. An affordable way to do this is to go to a local library and pick up grammar books and grammar exercise books. If your local library doesn't suit you or have the materials, you could go to a college library. An interesting thing about a college library is that you don't need to be a student to actually walk around and read the books; a college library, sometimes, offers more books than a local library. In this situation, you would walk through the library, find the book catalogue, grab some grammar books, and finally sit down somewhere to read them. For those intellectuals out there, you could look for multiple science books, take them to a desk, and start reading.

Practicing grammar on one's own is very questionable. How does one know he or she is using correct grammar? In this situation, one of the best things to do is consult a grammar book. If one grammar book does not provide the answer you are seeking, then look in another grammar book. There are also forums online for people who are learning English. These forums often provide people who are helpful toward those learning ESL and refreshing their English skills. Whenever you write something, type something, or say something, check to see if you're using proper grammar. Grab a style usage and grammar book. Think about how you presented things. Were they correct? The way the author learned to have better English was to constantly grab for a style usage manual. If you don't have one, it is suggested that you buy one.

  * Recommended Books:
  1. [The Cambridge Grammar of the English Language](http://www.cambridge.org/uk/linguistics/cgel/). (A large 1500+ page book.)

    

    If you read that whole book, you'll understand more about grammar than most people understand; you'll probably understand more about grammar than most professors. It's expensive (Around $100 USD), but it's something to put on the shelf. Some libraries offer it on their shelves. If you can, constantly check it out and read it all the way through. (You'll save money that way.) Afterwards, rent it out to have it as a reference book on your own bookshelf. As with most books, write down all terms you don't understand; research those terms to gain a better understanding of them. When you're done with the whole book, you can flip through it as if it were a reference book. You can look in its index for "commas" or other things in relation to grammar.

# Rhetoric

You may or may not have heard this term, but it will be a valuable term. Some people argue about the definition, and that's why many students have no clue whatsoever as to what the word means. Nonetheless, most people like to define a word by its criteria, abilities, or things that revolve around it to make it define itself. These, of course, are the many things that create definitional arguments. Regardless of the decades of controversey, I could give you my definition:

_Rhetoric is the act of presenting information and manipulating the way an audience interprets that information. The underlying principle of rhetoric would be philosophical and psychological aspects. These psychological aspects relate to a person's interpretation of the information and reaction due to cognitive influences. The philosophical aspects relate to the information being logical, sound, and valid: making sense instead of babble. Of course this could be argued, because many philosophers determine that rhetoric does not involve much Truth seeking; it doesn't seek truth but to sway an audience. However, rhetoric isn't suppose to be trick the audience into being sway, but it is to grab the audience's attention and have them pay attention to what is being said. Afterwards, it is used to influence the philosophical and psychological aspects of a person._

  


  * Some people could say rhetoric has a lot to do with prescriptive grammar: <http://en.wikipedia.org/wiki/Prescriptive_grammar>
  * Some people think of it as a school of thought: <http://humanities.byu.edu/rhetoric/Pedagogy/Pedagogy.htm>

To make up another definition off-hand, rhetoric is breaking style into bits and pieces and creating a term for each way style is presented. It is also about how style (rhetoric) is used within different contexts (rhetorical situations). Nonetheless, there seems to be an underlying principle that style is used to influence an audience. I may have done better to say I defined rhetoric's influence. It's all up for debate, but at least you've got an idea.

It's always good to know a bit about history:

  1. <http://en.wikipedia.org/wiki/Rhetoric>
  2. [Classical Rhetoric](http://web.archive.org/web/20050307155313/http://web.utk.edu/~gwynne/classical.html)
  3. <http://plato.stanford.edu/entries/aristotle-rhetoric/>

I'm not going to ask you to read all of Aristotle's Rhetoric. But it would be nice if you knew what it was about.

  1. <http://oak.cats.ohiou.edu/~kt367198/arrhres.htm>

Now you may be wondering, "How's this going to help me?" Well, it's going to give you a writing style and method. The style, however, will be a mix of rhetorical figures, and their usage will very depending on the way and time (kairos) you wish to present them. Rhetoric is the formal way of writing style. It seems very systematic, and it doesn't allow people to say, "Writing is a natural talent!"

You could, of course, be skeptical about all of this. "Wouldn't that mean I'm copying a style?" No. Rhetoric is about analyzing style throughout languages and learning how they are implemented. It's about analyzing style, see how it's used, and applying its concepts, not making up a style. You make a "style" by changing your usage of rhetoric. The style of language has been systematically analyzed into bunches of terms, which represent items, ideas, and the way things are. _Rhetoric is the style and method of all styles and methods._ Rhetoric allows for the study and usage of language, grammar, and linguistics in presentation.

By using rhetorical figures in different situations, and throwing them around like spices in a dish, you'll be working toward that perfect meal that earns 5 stars on presentation and taste.

Going into every detail about rhetoric would be elongating, and I don't have time to walk down the path with you, as Gandalf might have said in _The Hobbit._ I can, however, give you information and hope that you will stay on the path.

  * [The Forest of Rhetoric](http://humanities.byu.edu/rhetoric/silva.htm)

    

    This website is bookmarked by over 1000 people on [Del.icio.us](http://Del.icio.us), an Internet bookmark saving website. It has a detailed discussion about rhetoric, rhetorical figures, and the way rhetoric is used. I would pay attention to the left frame of the website and follow discussed links.

However, we're going to focus on a few main parts of that website (Silva Rhetoricae):

  1. Content/Form
  2. Natural Ability or Talent ("natura" "ingenium")
  3. Theory or Art ("doctrina" "ars")
  4. Practice ("exercitatio" "imitatio")

(These were taken from this part of that website: <http://humanities.byu.edu/rhetoric/Rhetorical%20Ability/ABILITY.HTM>)

## Content and Form

You ever hear about a person analyzing a text? You ever wonder how the heck that's done correctly? Well, it takes some practice, but understanding rhetoric is a good start, mainly because rhetoric is about understanding terminology and applying it. What you'll be doing is analyzing the way people used rhetoric and identifying the style and parts of style within a text. This may seem like a very annoying task to the megalomaniac who doesn't have the time to screw around; however, it is one of the many things that build up power and enable her or him to write better. Tough luck.

This analyzation draws on theory and practice more than natural ability. I'm going to summarize natural ability as a person without apathy. A person who has the will to wield style and slice through the audience while leaving a brilliant scar of amazement and awe on it will have the ability to gain "talent." Also, rhetorical pedagogy tries not to believe in natural ability.

The best thing you can do is grab a paper from a newspaper and identity rhetorical figures in it. Choose Newsweek, Times, USA Today, or some other popular magazine. You may want to grab Psychology Today or some other stylish magazine that implements witty banter/style. Your job is to identity the parts of style. Afterwards, you job is to write a paper, restate the thesis, and change the usage of rhetorical figures. Don't make it look the same; make it look different, but say the same thing using rhetoric.

The idea is to analyze the content, its style, and the form it takes. Afterwards, reword the content, and reshape the form of style. By doing this, you will gain practice and experience in rhetoric. Also, if you type up blogs or journal entries, implement rhetoric into each blog you type. You might give the appearance of a modern day Shakespeare.

  * See Also:

    \- <http://infotrac.thomsonlearning.com/infowrite/critical.html>
    \- <http://www.unizar.es/departamentos/filologia_inglesa/garciala/hypercritica/01.Classical/Classical.1.9.html>

### Practicing Writing Skills

Many people question how to improve their writing skills. Improving writing skills takes dilligent work; however, it is not a hard thing, in terms of academic writing, to master. It is suggested that a person has an online journal or "blog" to write his or her thoughts. These journals/diaries can be made private. Many writers believe in using LiveJournal (LiveJournal.com) for their writings. They use this website because the website will delete any articles or writings created when the writer wishes to delete the journal. In other words, when the writer wants all of his or her writings to disappear, then they disappear. The cause for this behavior is because of copyright infringement and other legal mumbo-jumbo. In other words, the writers are paranoid that someone will steal their work. And it does happen. Of course there are tons of computer science and forensic issues at work, but they can't be done without judicial or executive request; yet most writers feel writing on a private journal is one of the most secure ways to write articles, papers, and other academic things.

As a person continues to write his or her thoughts in a journal, he or she will (usually) comes across spelling and grammar errors. Looking for these key things and correcting them is what helps establish a decent writer. Good writing comes with consistent proofreading and revision. In such a writing dilemma, a person could consult a style usage book--or he or she could use the Internet to find answers. Sometimes people will use Internet forums and talk to writers when they cannot find an remedy to a specific writing problem. Sometimes a person will not know how to type something out, such as dialogue, within an entry. One should not fall into despair when he or she cannot find an answer to his or her writing dilemma; Band-Aid remedies do exist: A person could revise his or her word, sentence, paragraph, etc. Although for the silent writer who lurks behind corners and in the basement, he or she may consider going to the local library and looking for books on dialogue. Is the person wants to know more about non-fiction writing, he or she may looking for a book on non-fiction writing. One of the best ways to fix a writing dilemma, such as dialogue, is to read a book on how dialogue is used.

Good writing is not something that is achieved over-night.

    A person must first work on spelling, grammar, and understanding rhetoric. 

    Of course, if you can read 3000 pages in a 24-hour period, you may be able to become a great writer over-night.

## Style and Rhetoric

Although this may be a simple commentary I created in light of style and rhetoric, it may be of use to some people:

Social psychology holds this belief that there are a few ways to distract a person and persuade him or her. A person is easier to persuade when he or she is distracted; however, this distraction must not foreshadow manipulation. That's what tropes and schemes do in rhetoric. They allow a person to manipulate the psychology of the reader and distract his or her cognition.

In a kind of scenario, a reader may be enjoying prose and admiring it. This distracts the person, and allows him or her to be persuaded more efficiently.

In other words, changing and twisting the emotions of a person changes the cognition and processing capabilities of the person. Style's objective within rhetoric is to twist and change a person's emotions, thus to change the way a person perceives an argument.

The ways in which to use tropes and schemes differ depending on the kairos. When a writer in noticing that conflict may occur when showing alternate argument, that may be the write time to inflict style and good prose in order to change the cognition of the reader. Also, certain prose at certain times could influence and lead the person to continue with the argument instead of gaining a distaste for it.

A possible usage for it is the same cognitive route that movies use: Build a person up for a climax. A person could use style to lead to the bridge, then he or she could use emotionally charged words to build a climax. Afterwards, the person could throw in a witty line with style and brings things back down to Earth.

Much of this has a lot to do with social engineer, social psychology, cognitive behavior, cognition, and psychology.

The ability of a writer to create prose could have an influence on ethos and pathos. People may perceive the writer to be an intelligent writer because of his or her ability to create stylish prose, thus building [ethos](http://en.wikipedia.org/wiki/Ethos). Also, the prose may have a cognitive effect on the reader, thus affecting [pathos](http://en.wikipedia.org/wiki/Pathos). The trick is to make the prose seem logical and reasonable.

An analogy is a perfect example where cognition of the reader takes place. The writer must use intelligence and style when creating them. However, they must be clear to the reader and understanable. This is why many people like analogies: Analogies allow a person to grasp a concept better.

# Writing in General

## Coherence

Make one sentence link to the next. Afterwards, you could use transitions to go from that sentence to this sentence. However, this sentence may not be as apparent as the last sentence. Of course, one could make an argument about that statement... Do you notice the coherence? That's why you need to start practicing coherence before you write a college paper.

Sites to view:

  * <http://exchanges.state.gov/forum/vols/vol40/no3/p32.htm>

## Proofreading

Proofreading is the most important part of any paper. NEVER turn in a college paper without proofreading it more than four times. And after you do that, do it again. Proofreading can be difficult if one does not have a full comprehension of grammatical rules: That is just one problem when it comes to proofreading. This is why this part of the wikibook suggests people read through the Internet texts recommended in the previous section. When proofreading, one of the most important parts is making everything grammatically correct, coherent, and easy to read.

Many people speak outloud while proofreading their paper: This is highly suggested. Sometimes, when a person is proofreading, he or she may not notice any grammar or spelling mistakes while speaking outloud. This is why a [Text-To-Speech program](http://en.wikipedia.org/wiki/Text-to-speech) (TTS) is recommended. This author uses [Readplease](http://www.readplease.com/) for convenience and flexibility. By using a program such as this, a person can listen to the text version of the paper spoken aloud. Listening closely, a person can find mistakes in the paper when a word is spoken incorrectly. This is one of the many handy tools for proofreading. However, if you've proofread with a TTS method, then you will want to proofread with your eyes, a dictionary, a style manual, and a grammar book. Proofreading can be annoying, but at least you'll get a decent grade.

  


## My Favorite Way to Save Files

* * *

  * ((Source: <http://www.writingforums.com/showthread.php?t=64789>))

    

    Thread was created by Cyberman (Kamisama), this Wikibook's creator.

* * *

Although I'm not the best of writers, I have a new trick in my arsenal.

But first a story:

When I was in college last semester, I lost a lot of my work. I had it saved to the hard drive and the hard drive broke. I wasn't able to save my work in time. And I had to hustle and move very quickly to recover from this disaster. However, I somewhat gained a new trick out of it all.

I was looking for alternatives, and I know many are you thinking "Use a jumpdrive." But I lost my jumpdrive; and even though those things are fun to use, they can be lost, too. After a jumpdrive is lost, then the saved data is not recoverable until one finds the jumpdrive. And floppy disks are still a hot thing among many people. Yet those can fail, too. I've seen it happen. Hell, I'm a 1990's kid. I know data loss happens. I think the major thing that set me back, however, was when my AC adapater for my laptop broke. Those things cost a lot of money. And I couldn't get ahold of a new one right away. I didn't have three weeks to wait for something to get to my mailbox. The papers were due soon.

So what was I to do from that day forward? What could I possibly do?

And then I decided to use my computer experience and Internet knowledge. I haven't tried to do anything nifty in a while. I thought about this predicament; I didn't want it to happen again. I was getting sick of the trouble. After enough hard thinking, I came up with a solution: GMail.

Yeah, GMail is a really great tool. Matter of fact, I won't type anything in MSWord or Openoffice.org anymore. Seriously. Want to know why? Because GMail constantly saves whatever I'm writing. The best thing is that it is online. Yes, online. It's an online program that saves whatever a person is typing online. It doesn't constantly save, but it saves about every 30 seconds as long as a person keeps typing. I emphasize typing because it recognizes the fact that a person is typing and decides to save that "email" as a draft. Yet the writer isn't really making an email. The writer is saving everything as a draft.

Here's the procedure for those who like a layout:

  1. Compose a letter to yourself
  2. Start typing
  3. Keep typing
  4. Notice that GMail has saved your email as a draft (takes about 45 seconds after continuous typing.)
  5. Keep typing.
  6. When you're done typing, hit "Save..."
  7. Recognize that if your computer had crashed, the hard drive had broken, or some bat out of hell came from nowhere, that your GMail has saved your email. And you can access it in the drafts folder.

When a person wishes to gain access to that file, all he or she has to do is go into the drafts folder and edit the file. If someone wants that copy to be written in stone, then all one has to do is click "send." Afterwards, if the person wants to do more to the file, then he or she can copy and paste the information into a new composed draft. I find it fairly nice to use. And the neat thing is that everything is time-stamped.

This is not to say that you shouldn't save another copy to a jumpdrive, floppy disk, or other storage medium. Matter of fact, I advise that you do when you're done for the day.

But the important thing here is that GMail saves something. It saves it while you type. And the file does not get destroyed. Of course, there may be circumstances when Google's corporation goes to hell and the servers crash; but I think a billion dollar company would make backups or have precautions.

For these reasons, I have been using GMail whenever I have something important to type up. It seems much better than using an FTP server. However, there are times when Google Mail is not accessible; it rarely happens. This is why saving something to a different storage medium is advised.

And if I do use Openoffice.org or MSWord, then it's for doing margin work, footnotes, spelling, and other specific word processing applications.

## Writing Workshops

Some colleges offer community courses or courses that do not earn college credit. All who do not fully understand grammar should take a writing workshop and improve their grammar. Grammar is of the utmost importance when writing a paper for college. Writing workshops not only help with grammar, they also help with the structure of a paper. By structure, I mean the way everything fits together in a smooth transition: this smooth transition is also known as style.

These writing workshops do cost money, but they are worth it if a person comes out with improved writing. The best thing about taking a writing workshop is that a person does not have to take a college/university course that impacts his or her GPA. Another good reason to take a writing workshop is because many English professors expect someone to already know grammar and style. Depending on one's educational background, he or she may not remember how to use a semicolon or a colon; that person may not even remember the difference between a semicolon and a colon. Albeit that many early (before 1900 A.D.) writers used colons and semicolons in a fashionable way, it is recommended that someone flip through a grammar and style book for a definite way of writing with colons and semicolons. Although the semicolon may seem to be presented in a mediocre way, at least it will be used correctly.

### Writing Communities

  * <http://www.englishforums.com/>
  * <http://writingforums.com/>

# Types of Papers

## Essay

## Thesis Paper

Read this: <http://en.wikipedia.org/wiki/Thesis>

### Paragraph One

What kind of bullets are you putting in your gun?

When you create a first paragraph, you have to notice that each sentence is a bullet. However, it's a certain type of bullet. Each bullet has its own property and effect on the individual you shoot it at. Nonetheless, the bullet is going to whiz through your paper and have an affect on the reader. If you've ever seen Outlaw Star, you understand that each bullet Gene Starwind has will have a different property. Some bullets are more unique than others, yet they all have a purpose. You have to notice that each sentence in the first paragraph has a purpose. The thesis sentence could be seen as the gun that you load all the bullets into. This thesis sentence is typically the last sentence of the first paragraph. Imagine that each previous sentence is a bullet being loaded into the thesis chamber. The thesis sentence is the most important sentence in the paper. It is the controlling sentence that allows you to shoot the bullets. Otherwise, you might as well throw the bullets at your reader, and that won't do you any good.

Each time you type a sentence into your first paragraph, imagine that you're loading the chamber. Each bullet needs to slide into the chamber with relative ease. Imagine what each sentence sounds like as it's slided into the thesis. The words and thoughts need to connect to each other. Otherwise, when you shoot the gun, it might become jammed. The gun wouldn't be of any use to you.

### Body

  * **How** are you going to shoot your gun?

When you shoot each sentence, it begins to have its own environment. Each environment takes shape, reason, and adjusts to its surroundings. In a way, a bullet in the first paragraph is shot and creates a paragraph environment of its own. This bullet creates a world of physics, details, examples, and facts. However, as the bullet begins to make contact, the environment is aware, impacted, and changes because of the bullet's presence. You want each word, sentence, and thought to ricochet inside the person's mind. Each thought in the paper bounces around in the reader. However, it all has to make sense. It all has to be rational. It all has to have a motive, a reason to be there.

  * What are you talking about?
  * What are these things connected to?
  * Why should I care about what you're saying?
  * Why are you talking about this?

You have to address a thought. These thoughts need something to connect to. These thoughts would be connected to the thesis. Of course the bullets came from the thesis. However, if the bullets don't come from the gun, the reader is going to think God is flicking pieces of rock at him or her at amazing speeds. The person being shot at can't make any sense of what's going on. They'll question why they are in this environment, and they'll want to get out of this odd and absurd predicament. However, if you can show that the sentences are bullet, they come from the thesis chamber, then the person being shot at can understand what's going on. You have a motive, and that motive gives cause to the chamber and bullets. Although this might seem a bit macrabe, it serves a good example.

## Argumentative Research Paper

"It's not what you know, it's what you can prove." - Alonzo from Training Day.

Argumentation become a common aspect of post-secondary education, yet so many people don't understand it. There are many reasons why people don't understand it, but perhaps the best reason is because it is philosophically rooted. Many people believe philosophy can be hard to grasp without correct guidance. It can often be the failure of those who teach argumentation to teach its history and philosophical side. In this sense, understanding who created argumentation, what they intended it to be, and how it works will allow someone to better understand argumentation.

You say you know something, but can you really say it? I'm not so sure until you can **prove** it.

#### History of Argumentation

Argumentation is deeply rooted in philosophy, and yet it has adapted to be part of communication, and those who study communication adapated argumentation to their field. Argumentation has a large history preceding Aristotle.

Argumentation Theory, as many people call it, had a large amount to do with formal logic. Aristotle was one of many people to contribute to argumentation with the ideas of logos, ethos, and pathos. Logos would be the logical side of the argument; ethos would be the ethics, character, or type of person the arguer present him- or herself to be; and pathos would be the emotional, yet revelant, side of the argument.

Aristotle was also responsible for bringing out the idea of "enthymeme": An argument with one conclusion, one premise, and one unstated premise.

A person must keep in mind that Aristotle is who most persons refer to when they are studying argumentation. Throughout the history of argumentation, people such as [Scholars](http://en.wikipedia.org/wiki/Scholasticism) have used Aristotle's reasoning in hopes to become better arguers.

##### Suggested Readings and other Media

This section is broken into two part:

  1. Books that a person ought to read with explanation and/or details.
  2. A list of books and other media.

If there is an earlier version of the book, you might be able to use that version instead. Sometimes older versions are better than newer versions. If you can't buy a book, you might be able to loan it from another library through something called _interlibrary loan_. Ask your librarian about _interlibrary loan_ or borrowing books from another library.

All of these have been listed because they are very relevant to the study of argumentation. Of those that should be studied first are listed:

1\. Fundamentals of argumentation theory: a handbook of historical backgrounds and contemporary developments

    This part of argumentation has been negelected in post-secondary education. However, it will give you a brief introduction to what this topic is all about. I really suggest you read this first. Plus you'll love the cover of the book. You might be able to view that on google images.

2\. A Rulebook for Arguments

    This short book is somewhat of a quick intro/reference guide. If you've read the previous book, you'll be able to understand what's discussed in this book. The book is very systematic and allows a person to flip from section to section. I'd have to say the author perceived the writer's needs when he created it long ago.

3\. Argumentation analysis, evaluation, presentation

    This is more of a scholary book that gives a decently detailed view at argumentatin. It includes exercises which a person should do, type out, and practice with.

4\. Fallacies: Classical and Contemporary Readings

    If you have one or more fallacies in your argument, educated people are going to criticize and frown upon your argument. Your grade will probably get knocked down, too. A lot of books discuss fallacies, but sometimes the way they describe them is not very detailed. This book helps give a detailed view toward fallacies.

5\. Writing argumentative essays

    This is another media that helps a person focus on writing argumentative papers.

6\. Ethical Argumentation

    A lot of ethical concerns exist when people are going further into the future. This book will allow you to understand ethics and values when stepping into the realm of argumentation.

7\. An exploratory study of junior college students' response to teacher feedback in argumentative essays.

    It's always neat to get the view of a professor using students as guinea pigs. Although the previous book and other books might help help you scrutinize such a person, this research will help you get a better grasp to what's expected of you as a student.

8\. In defense of informal logic

    Some people think argumentation is stupid because it has little formal logic and many people argue with emotions and values. This book was created to help defend against views like that.

Another possible book to look into would be _Argumentation and Critical Decision Making_ by Rieke and others.

* * *

Books

* * *

  * A Rulebook for Arguments (By Weston) (Year 2000)
  * A Systematic Theory of Argumentation: The Pragma-dialectical Approach (By Eemeren and Grootendorst) (Year 2004)
  * Argumentation analysis, evaluation, presentation (By Eemeren, Grootendorst, and Snoeck-Henkemans) (Year 2002)
  * Argumentation, communication, and fallacies: A pragma-dialectical perspective (By Eemeren and Grootendorst) (Year 1992)
  * Ethical Argumentation (By Walton) (Year 2003)
  * Fallacies: Classical and Contemporary Readings (By Hansen and Pinto) (Year 1995)
  * Fundamentals of argumentation theory: a handbook of historical backgrounds and contemporary developments (By Eemeren, Grootendorst, and Snoeck)
  * In defense of informal logic (By Levi) (Year 2000)
  * Rhetorical argumentation in biblical texts: Essays from the Lund 2000 conference (By Eriksson and Olbricht) (Year 2002)
  * Teachers' perceptions of coherence in student argumentative essays at the department of Basic English of Middle East Technical University (By Feyza Konyali) (Year 2003)
  * Warranting assent: Case studies in argument evaluation (By Edward Schiappa) (Year 1995)
  * Writing argumentative essays (By Nancy V. Wood) (Year 2001)

* * *

Dissertations

* * *

  * An exploratory study of junior college students' response to teacher feedback in argumentative essays. (By Dorothy Cheng Suan) (Year 2000)
  * Argumentative essays written by native speakers of Chinese and English: a study in contrastive rhetoric (By Cheryl Ann Eason) (Year 1995)
  * Rhetorical/cognitive strategies evidenced in information and argumentative essays of high school and college undergraduate students: a descriptive study (By Deborah Apy Odell) (Year 1986)
  * The impact of scaffolding via online asynchronous discussions on students' thinking skills in writing argumentative essays (By Yuen Choo Koh) (Year 2004)

* * *

Movies

* * *

  * Critiquing the argumentative essay (By Kathleen Clower) (Year 1991) (VHS tape)

    **Abstract:** Seminar session with students and instructor critiquing student essays for elements of good argumentative writing; thesis statements are examined and strengthened.

#### Why should people argue?

Although a person can remain skeptical of Truth, justice, and the ways people should go about things, these are the things that are often argued. Yet some people might take an egoist view of argumentation along with a pragmatic view. If a person thinks, "This doesn't effect me, so why should I care?" Ah, but decisions might affect you. The idea is that the history of a person allowed him or her to arrive at a point in time. This history has so far allowed the person to live and read these words. It is this history that enables a person to argue.

However, were the person a skeptic, then he or she might say, "I'm skeptical about the things you say, the conclusions you reach, and the reasons you use. A person cannot know anything until he or she is that thing. Therefore, I'm not going to argue." Yet the irony is that for a person to be a skeptic, he or she must give reasons for being skeptical. Along with these reasons comes out the conclusion, "Therefore, I'm not going to argue." The skeptic has just argued.

In both of these scenarios, it is shown that argumentation is required in many cases. Argumentation allows a person to fight for his or her own views. That does not necessarily mean he or she is wrong, but it means simply that the person is arguing with others and presenting views. These views must be supported with reasons (premises) and at least a concusion. As a person understands argumentation more and more, he or she will begin to notice argumentation in many places.

To bring us back to an argument already present:

  * Reason 1: This doesn't affect me.
  * Reason 2: Things that don't affect me do not matter in my life. (Unstated assumption.)
  * Conclusion: Therefore, I don't care.

One way to attack an argument is to attack one of its stated reasons (also called premises), which in this case would be reason 1. I have stated that things do affect you. Things in this physical world are dependent on something else. Nothing is independent in this universe. Therefore, you are affected by something one way or another.

  * Premise 1: Things in this physical world are dependent on other things.
  * Premise 2: Nothing is independent in this universe.
  * Conclusion: Therefore, you are affected by something in one way or another.

If you can somehow prove to me that you are independent of this universe, then maybe I'll accept your conclusion. Of course, I'll need evidence of this.

#### What are you proving?

  * What am I trying to prove and how am I trying to prove it?

Pick a weapon:

  1. Formal Logic
  2. Informal Logic

If you're taking a philosophy course, you will probably be doing formal logic. If you're taking an English course, you will probably be doing informal logic. Yet even choosing your weapon for arguing depends on an audience. Some audiences in pure reason and logic will accept formal logic. However, this ideal audience rarely, if ever, exists. Such an audience that accepts formal logic might be one person who studies it in depth or an audience of logicians and philosophers. The point of this is that your audience will be the ones to either accept or dismiss your argument.

Things to read:

  1. <http://jac.gsu.edu/jac/4/Articles/9.htm>

#### The Technical side of Argumention

  1. Premise
  2. Warrant
  3. Conclusion (Claim)
  4. Enthymeme
  5. Evidence (Grounds)
  6. Backing (Backup evidence)
  7. Rebuttal
  * An argument must include one premise and one conclusion.

A **premise** (reason) is used to reach a **conclusion** (claim).

* * *

Words to remember:

  1. Premise (reason)
  2. Conclusion (claim)

* * *

An argument with one premise and one conclusion is called an enthymeme. An enthymeme is an "incomplete argument" that is missing one premise. This one premise, called an unstated assumption, is unprovided by the arguer.

  * Person 1: You're car is broke (conclusion) _because_ someone blew up its engine (premise).

In formal writing, people often place the conclusion and premise(s) next to each other. However, some implied arguments do not make the conclusion and premises so obvious.

  * Person 2 thinks, "I guess so. A blown up engine cannot process gas or other things required for it to run." (unstated assumption)

The unstated assumption (also known as "warrant") is provided by the audience, in this case Person 2. In other words, the audience assumes a premise and fills in the gap for the enthymeme; the audience mentally provides another premise without the arguer providing it.

  * Arguer: Hitting people is wrong.
  * Random person walking by: Why do you think that?
  * Arguer: Hurting people causes suffering. (Major Premise / Major Reason).
  * Random person: I agree.

If you haven't figured it out yet: If someone doesn't offer you premises and only a conclusion, it's difficult to argue with him or her. As you start to learn argumentation more, you might see people only stating conclusions and giving no reasons. If you would like to start an argument with someone, you simply need to ask, "Why do you think that?" From there, you can draw out a person's reasons and argue against or for them.

But the question is, Why do these people agree?

  1. Enthymeme (Argument with unstated assumption not included)
  2. Big Thesis (Claim or Conclusion)
  3. Small Theses (Premises / Reasons)
  * Major Premise
  * Minor Premise
  1. Evidence (or Grounds)

#### Argumentation in Media

In the movie Training Day, the protagonist encounters the antagonist, Alonzo, played by Danzel Washington. Alonzo is a cop gone bad, and the protagonist needs a way to prove it. Although the protagonist knows very well that Alonzo is a bad cop involved with drugs and crime, there is little evidence to support the protagonist's claim (also called a conclusion). Eventually the protagonist meets Alonzo at his apartment and finds Alonzo preparing money to give to a Russian gangster that Alonzo angered. Alonzo needs to pay a "debt of respect," which in this case is a large sum of money, to the Russian gangster. The protagonist encounters Alonzo and they both go through a dialogue about the protagonist not being able to prove that Alonzo is a bad cop. Alonzo than recites the line, "It's not what you know, it's what you can prove." The protagonist sees the large bag of money and Alonzo notices that the protagonist is going to use the bag of money as evidence to support that claim that Alonzo is a bad cop. Eventually after Alonzo and the protagonist get into a long and dangerous fight, the protagonist obtains the bag of money and says that it will be used as evidence. The bag, of course, would have Alonzo's fingerprints and could be tested by forensics.

The movie Training Day includes many things that revolve around argumentation and is a recommended watch. If you've seen it already, you may want to watch it again.

Possible Argument:

  * Claim: Alonzo is a corrupt cop.
  * Reason 1: He is involved with drugs and crime.
  * Reason 2: He has people killed.
  * Reason 3: He searches houses without a warrant.
  * Reason 4: Bad cops don't do these things. (unstated assumption)

#### Sources

  * "Between a rock and a hard place: Argumentation Theory between rationalistic and interpretivist standpoints." Oct. 18 2006 <<http://www.cs.ucl.ac.uk/staff/S.Stumpf/Reports/argdes.html>>
  * Long, Richard. "THE ROLE OF AUDIENCE IN CHAIM PERELMAN’S NEW RHETORIC." Oct. 18 2006 <<http://jac.gsu.edu/jac/4/Articles/9.htm>>

#### More Reading

##### Books

  * [Basic Writing](/wiki/Basic_Writing)
  * [Creative Writing](/wiki/Creative_Writing)

##### Websites

  1. [THE ARGUMENTATIVE PAPER](http://people.eku.edu/williamsf/RhetSum/default.htm)
  2. <http://en.wikipedia.org/wiki/Argumentation>
  3. <http://bss.sfsu.edu/kassiola/writing.htm>
  4. <http://en.wikipedia.org/wiki/Scholasticism>
  5. <http://en.wikipedia.org/wiki/Doublethink>
  6. <http://www.unc.edu/depts/wcweb/handouts/argument.html>
  7. <http://www.unc.edu/depts/wcweb/handouts/evidence_use.html>
  8. <http://en.wikipedia.org/wiki/Essentially_contested_concept>
  9. <http://en.wikipedia.org/wiki/Dialectician>
  10. <http://www.yorku.ca/gilbert/argthry/>
  11. <http://www.philosophy.eku.edu/Williams/RhetSum/default.htm>

  


# Improving Reading Skills

# Improving Reading Skills

### Read the Course Books Before the Semester Starts

Many college students have this policy after learning "the system" to read the course books ahead of time. Of course, this proposes many questions:

  * What am I suppose to be learning from this book?

**Author's Answer:** Whatever is covered in the book. Sometimes there is a lot of gibberish in college books; this gibberish is put there to elongate things that could have been defined in three sentences instead of three paragraphs. All things covered that relate to the course are important. _Remember as much as you can about a book, while knowing which gibberish to ignore_. Often, when reading a book with a lot of information, much of the information to remember belongs to specific people/objects, events, actions, results, locations, concepts, and problems. This "_thing to remember logic_" applies to multiple academic disciplines.

  * When the class starts, you can ask your professor about what is to remembered and what is not.

Either way, _most "good" college students come out of a course remembering about 50% of the material covered in a course book_.

Here's something to remember: _read as much of a/the book(s) as you can, as soon as you can_. Read a/the book(s) before the semester starts.

**"Reading before the semester starts" technique:** Say, you have five books and one book for each course.

Read at least 10 pages from each book. When you are done with 10 pages from one book, switch to the next book; keep this 10 page revolving system going, until classes start or read a chapter and then switch books. Usually, reading one chapter from a book and switching to the next does well for covering the book(s) of each class. Some people get annoyed with studying one thing, so they'll switch to the next book after a certain amount of pages. If you have a certain major, say psychology, you'll probably be able to retain and read more pages than from other books: This may or may not be a good idea.

By keeping up a certain pattern of reading each book, you will be able know what the books cover and what the class topics are about.

_Try to read as much of each book as you can before classes start_. **You will** have an advantage if you read the books ahead of time.

### Write Down What You Don't Understand

When a person reads a book he or she may have trouble understanding the concepts of the things presented. Often, a person wants to read a chapter, but he or she may continue to try and understand a concept before moving to the next page.

_The best thing to do in this situation is to write down the concept you do not understand_. After you write down what you do not understand, present what you don't understand to the professor.

_Before presenting, find a way to ask about what you don't understand_. Write a question about the concept in question form on a piece of paper. This way, when you talk to the professor, you can ask him or her the question about the topic you don't understand, that is on the piece of paper.

**Example:**

You read a paragraph about RNA, introns, and extrons. Yet you don't understand how introns are cut out from RNA before becoming mRNA.

  * _Write down:_ introns, RNA, and extrons
  * _Make a question:_ How are introns cut out from RNA before RNA becomes mRNA?

After doing so, you may move onto the next page and hopefully understand more as you continue to read. Sometimes as a person moves on, he or she will find different material that is unrelated, so he or she can focus on that material, and later on the part he or she did not understand. With the part someone did not understand he or she would present that question to the professor.

This is a technique used to cover the rest of the chapter, and _read the chapter instead of having a point in which someone becomes stuck on a page before moving on_.

### Highlight what you don't understand

If you have a problem reading something but you can absorb the other information, you might want to highlight certain sections that are giving you problems. Otherwise, you could type these things in a word-processor. Afterwards, you could print them out and later highlight the things you don't understand. Afterwards, you could print another sheet of these things out and highlight the things you still don't understand. _Highlighting allows a person to focus on material that is not understood. It allows a person to skip portions of a text that are understood, thus eliminating the need to reread things_.

  


# Improving Research Skills

# Research

## Internet Research

  1. Relevancy: Is it relevant?
  2. Authority: Does it have an author? Can an author be found?
  3. Credibility: Is the author credible?
  4. Accuracy: Is the information accurate?
  5. Currency: How current is the information?
  6. Accessibility: How easily can it be accessed?
  7. Reading level: What is the reading level? Ph.D reading level? College? High school? Middle school? Grade school reading level?

    What needs to be known in order to read the information? Knowledge of statistics? Knowledge of cognitive science and various parts of the brain? Any technical jargon or lingo?

## Library Research

## Field Research

  1. What is field research?
  2. Before you start: Ask permission.
  3. Supplies for field research?

## Library vs. Internet

It is often faster to use a library than it is to use the internet. Being that I've been on the web a decade or more now, I've learned many interesting things.

For one, the Internet offers a lot of knowledge--a lot of diverse knowledge. Matter of fact, the Internet over the years has become so diverse, searching through the web is like looking through the garbage for something you accidentally threw away. Finding things on the Internet has become very complex these days, and many people rant about having better information to offer than the competitor.

With Internet searching skills, a person will get better at finding materials. Sometimes, people take a shortcut and go to a web forum to ask people a question or where to locate information. The truth is, searching, asking, and locating on the Internet becomes very time consuming. I’ve found that it becomes more time consuming than looking around in a library.

The library often has many resources to choose from. Learning where everything is in a library is important. The more you know about every nook and cranny in a library, the more you can prepare to find materials to do research. Professors usually want book sources when a student is doing a paper. Libraries also have a physical search engine called a librarian. This person is better than an Internet search engine, because you can describe what you need to research, what you are looking for, and ask where it is and how you can find more information.

It is often better to search through a library than through the Internet. This can be disputed, but if you start using a lot of time to research something you could have researched in the library, then maybe you might want to try using the library.

# Resources

### Books

### Databases

### Magazines

### Newspapers

# Taking notes of Resources

## Citing Resources

  1. MLA
  2. APA
  3. Chicago

## Copying Resources

  1. Obtain resources.
  2. Copy down publisher, author, and other information.
  3. If you want, you can use a scanner bed to copy that information from a book.
  4. Copying pages from a book is faster than writing information:
  * Copy cover pages.
  * Copy publisher, author, and LOC page.

## Organizing Resources

  1. Print out a physical copy of resources
  2. Put copy into folder(s)
  3. Store information somewhere safe
  4. Store digital data on a digital medium
  5. CDs and DVDs
  6. Upload to the Internet

## Photographing Resources

  1. Documenting artifacts, items, and other physical objects in research.
  2. Reprography: A camera and a copy stand.
  3. Buying supplies: A camera and a copy stand.
  4. Post-image processing.

  


# Learning at the College level

# Introduction

Sometimes people who want to learn are impatient. These impatient yet strongly motivated people are the kind of who people who often end up successful in life. In the world of the physical, knowledge is power. Baconites who recognize this might often find themselves asking the question, "How do I obtain the knowledge I want to learn?" Although the definition of knowledge can change from person to person, the idea of knowing what one considers to be knowledge can help him or her quickly access that information. Yet the question still remains, "How do I obtain the knowledge I want to learn?"

## Choosing your topic of study

Awesome question with a decent answer: Books.

Books are the things that allow a person to learn information, practice knowledge before taking a college course, and stay ahead of the game. Many college students like reading their course books before the college semester starts. Reading ahead of others puts many college students ahead of the game. It allows college students to readily process the information professors might discuss in class. Also, if a person already knows the information, he or she probably has a better chance of understanding it when discussed with a professor.

Yet most professors choose a certain course book. You need to find out which book that is.

Yet the next question appears:

  * Where do I get these books?
  * Books are expensive!

Answer:

  1. Find out which book you're going to be using.
  2. Go to the library and find that book.

# The College Bookstore is your friend

You want to study something at the college level.

Things you need to know:

  1. College course topic
  2. What book that college course is using

If there is a topic in college that you want to learn, that probably means you are motivated to learn. If this course is listed in a college catalogue, you may be able to figure out what course book that course is using. A course book is the book the course uses for the semester. Sometimes professors change what books the class is using each semester.

To find out these things do the following:

  1. Email a professor and ask him or her which course book he or she is using for a certain course.

OR

  1. Grab paper and pencil
  2. Go to the college bookstore
  3. Look for the course book that you want to read
  4. Write down the name of that course book; write down the name of the author(s); and write down the edition of the book and the ISBN if there is one. It will also do you some good to write down what the cover looks like: Does it have people? What color is the cover? Is there a picture of a butterfly or etc.?

Now that you have that information, you can go to the library.

# The Library is your friend

You might be thinking, "The library only has so many books. It doesn't have the books I want."

It might not have those book in the shelves, but it might be able to get those books for you.

Why buy books when the library loans them for free or a feasible fee? If you give information to the librarian, he or she can help you find the book. If you go through an database or catalogue to find the book or media, you might be able to track it down and check it out.

## The Librarian is your friend

You walk into the library with the information about a book on hand. You walk toward the librarian and say to her, "Hi. I'd like to find this book and read it," as you point to the piece of paper.

The librarian turns to you, looks at the paper, and says, "Alright. Let's see if we can find it."

Librarians, in a general sense, are geniuses who decided to become the gatekeepers of knowledge instead of teachers. Those who earn a two-year or four-year degree in library science often have a general knowledge of history, science, language, math, etc. Many librarians took these topics and college and regular school. When you talk to them, they'll most likely have a good idea of what you're talking about. Also, they'll have a general idea of what you are looking for. If you have a book title and author, they'll know that you are looking for that book and author. Of course, the important thing to note is the edition of the book. There could be different editions of a book. That is why noting which edition you are looking for is important.

Those who are well-versed in library science can understand the cataloguing and direct you to a shelf of books that relate to the topic you are studying. Otherwise, they can look through an online card catalogue; or they can look through an electronic catalogue.

Librarians can be seen as the gatekeepers of knowledge. They keep a cognitive map of where things are located in the library. Many have an idea of where things are located throughout libraries in a nation. A thing a person must remember is that there are different types of people in the library: pages, assistants, and librarians. Librarians are those who have a degree in library science, and they'll probably be more capable of helping you than a page could.

  1. The librarian as a researcher
  2. The librarian as a physical library catalogue

## The Databases are your friend

Many libraries have books. However, not all libraries have all books. Because not all libraries have all books, many libraries have joined together so that they can exchange books with each other. Therefore, if one library doesn't have a book that someone is looking for, then the person could ask his or her library to borrow the book from a different library. This borrowing of books is also known as interlibrary loan.

If someone can't find a certain book at his or her library, he or she could look through a catalogue that lists where that certain book might be. These catalogues, also called databases, often list one or more libraries that offer a book someone is looking for. Databases, such as WorldCat, allow a person to see if a library has a book. If one of these libraries has the book you are looking for, you can fill out a request for your library to obtain that book from a different library. As a last resort, you may be able to request a book from the Library of Congress. However, the Library of Congress will not loan a book to someone through interlibrary loan unless no other library has that book.

If you don't understand the idea of interlibrary loan in this wikibook, go up to a librarian and ask them all about interlibrary loan. Keeping asking the librarians questions about interlibrary loan and the databases.

  1. How to use a database.

## Email is your friend

  1. Why email is good.
  2. How it helps you track down books.
  3. How it allows you to keep track of books.

# Rotating Books is your Friend

Getting a book through interlibrary loan can become a simple task once someone uses it enough. If a person damages a book in a "noticable way," however, that person could encounter severe fines. Also, if the book is not returned in time after the loan period is over, the person could encounter severe fines. These aren't the typical nickel and dime type fines; these are the ones that can go up to $100. These fines are serious business. That's why it's a good idea to return a book on time, keep it at home, and don't drink or eat near the book. SERIOUSLY.

However, sometimes a person still wants to use the same book. Well, that's where the idea of "rotating" comes into play.

Imagine you recently filled out a request for a book. It often takes about two to four weeks to receive a book through interlibrary loan. After the two week period, you could put in another request for that same book, but you'll want to obtain it from a different library. Hence, the main idea is that you're getting the same type of book but from a different library.

  1. Put in request for book (book 1).
  2. Wait two weeks.
  3. Put in request for the same book with the same title but from a different library (book 2).
  4. You eventually receive book 1.
  5. Two to three weeks later, you have to turn in book 1.
  6. However, book 2 arrives shortly before or after the turn in of book 1.

Notice that you are rotating books. Also, if you want to keep up this cycle, you'll get book 3, too. However, _each consequtive book **must** be from a different library_. When the book you had recently rented out gets back to its original library, you might be able to check it out again.

You will be able to keep reading the same book title over and over until you're done with that book. It's a nice trick if you're low on cash and want to learn stuff.

Note: It's not that easy to do this same thing with current college books used in college courses. I'm not trying to be pessimisitic here. Many universities have college-level books. And you'll probably have 75% chance of getting the book you want. Some people already know this "system," so they'll check out current editions of college books. However, an older edition often works just as well as the newer edition. A college book which was created before 1990 is typically an out-of-date book. I wouldn't recommend getting a book made before 1990 unless it's for research.

  


# Choosing Supplies

# Supplies for College

Suggested Supplies:

  * 5 Subject notebook
  * Multiple mechanical pencils
  * Bic 4-Color Pen
  * Eraseable blue pens
  * Jumpdrive (chain it to yourself or you WILL lose it)
  * Calculator [Texas Instruments]

# Laptop or Desktop?

## **Do I need a laptop?**

This question is rhetorical and primarily philosophical due to the word 'need'. Take away all that and you ask yourself, "**Do I _want_ a laptop?**" That's a good question!

What does a laptop offer?

Well, that's easy to answer: a [laptop](//en.wikipedia.org/wiki/Laptop) offers almost as much as a [desktop computer](//en.wikipedia.org/wiki/Desktop_computer). Desktop computers have an equivalent degree of power and hardware that a laptop would have, but the desktop computer's parts cost about half as much as a laptop. Yet some students will choose the laptop because of its ability to be transported. Desktop computers are often neglected because they can't be transported. Since desktop computers lack the ability to be transported, many students choose laptops as their scholarly device. Furthermore, desktop computers are sometimes found around the school a student attends. A student can connect to the Internet and write reports while using the school's computer. Therefore, the idea of buying a desktop computer gets neglected more and more.

If there are already computers at school, then why does a person need a laptop? Does a person really want a laptop when other alternatives are around? After all, laptops are clunky, expensive, and can weigh around 5 lbs. The number one answer typically boils down to the ability to transport the device. Nonetheless, most students have this preconceived idea that a laptop will solve all of their problems. In other words, laptops seem like the holy grail when surfing the Internet and writing reports. Yet the "surfing the Internet" part seems contradicting. Unless a student is [wardriving](//en.wikipedia.org/wiki/wardriving) or the school has wireless Internet, then he or she will be sitting at a stationary location to be on the Internet. A student would be walking around the school, go into the cafeteria, and start using his or her laptop. However, the student would be in a stationary location to use the laptop. The student could have saved hundreds of dollars by going to a room with school computers and using those computers. With this incidence, laptops seem to be a convenience and most importantly _a want_.

During class some students may want to connect to the Internet. Some colleges and universities have cable ports located in different places; these outlets (also known as ports) allow a student to connect his or her laptop to the school's Internet server. Yet again, some of this seems contradicting. Hopefully, students wouldn't be searching the Internet in class, unless researching something. But most students research things after class; therefore, researching in class is quite odd and rare. Using the Internet in class could be seen as rude to some professors. In other words, it could be seen as deviant by some social norms. It all depends on the situation, location, time, etc. But nonetheless, most students don't use the Internet while in class. Therefore, a student could most likely use the school's computers for Internet research. Thus, a school computer would be a stationary one. Being that a stationary computer is most likely a desktop, then a student would save money if she or she doesn't buy a laptop.

Like cell-phones, a person could always go to a payphone. Then again, payphones aren't everywhere, but schools do have computers. Therefore, if a student is forced to be at a stationary location to use the Internet at school, then he or she ought to consider using the school's computer and getting a desktop computer for the home.

Now that the reasons for using a laptop for Internet usage have been eliminated (or to a degree), there is still one problem: writing.

Writing reports, notes, and other little tidbits that become important for class make a student choose the laptop. But hold up, other devices can do that too. These other devices can be transported, carried around like a laptop, are smaller than a laptop, and cost less than a laptop. Some of these devices can connect to the Internet and send email.

## About Alternatives

**So why do people buy laptops when there are alternatives?**

I don't know, but I do know there are multiple alternatives: [palm pilot](//en.wikipedia.org/wiki/palm_pilot), [tablet PCs](//en.wikipedia.org/wiki/Tablet_pc), [PDAs](//en.wikipedia.org/wiki/Personal_digital_assistant), [calculators](//en.wikipedia.org/wiki/Voyage_200) with QWERTY keyboard, etc. If you're looking for a computer to transport, these would be your the type of thing. They are small and versatile. An example of the Texas Instruments keyboard can be seen at this external link: [click here to view.](http://education.ti.com/educationportal/sites/US/productDetail/us_ti_keyboard.html)

For a student looking forward to take notes in class and very little else, then he or she would do fine with a calculator and keyboard. A problem with choosing a calculator, however, would be the amount of Kilobytes and storage space on the calculator.

_Math time!_

A calculator, such as the TI-89, has about 700 Kilobytes of memory set aside for the user. A kilobyte is comprised of 1024 bytes. Therefore, 700*1024=716800 bytes. But it takes 8 bits (8 bits = 1 byte) to create a letter on a computer--a letter such as the letter A or B or a semicolon. And some people say an elementary word is made of five letters. Therefore, the calculator can hold approximately 143360 words or less. The complaint I've seen from people who use the TI calculators is that the calculators don't have an adequate amount of memory. This article section of Wikibooks (Laptop or Desktop?), however, has about 9000 characters.

That's

  * (9000 characters) * (8 bits) = 72000 bytes

or

  * (72000 bytes) / (1024 bytes in a kilobyte) = 70 kilobytes taken up = (1/10 of the memory set aside on a TI-89)

**In other words, a person may not be able to type of the next literary novel to shake the world based on its ethical and scientific revolutions on a Texas Instrument calculator, but it will do for an English paper or notes.**

For a student who would like to take notes with a laptop, some people have been turning to keyboards that connect to PDAs. ([external link](http://freedominput.com/mainsite/index.php))

This method is often more versatile, affordable, and convenient. Laptop batteries can cost above $100 USD to replace, and the laptop batteries take a long time to recharge. The reason people have been turning to freedom keyboards and PDAs is because batteries can be bought at a store at a more affordable price. Finding a powersource for a PDA with keyboard attachment is easier than a laptop.

After having my own experience of "laptop vs. a desktop computer," I would have to say a laptop is futile compared to the keyboard and PDA setup. My laptop has saved me at times, but the amount of time the batteries offer has depleted. I find that using a keyboard with a PDA setup is more efficient and easier to deal with. Depending on the type of laptop someone buys, it can be heavy or light. Usually, the lighter a laptop, the more expensive it is.

With the PDA and keyboard setup, a person gets a very light setup for an affordable price. Laptops are nice, but I would highly suggest someone buys a very light and inexpensive one.

Desktops are easier to deal with, and they are often hard to steal without the thief being noticed. For a person living in a dorm, having a laptop stolen is a great expense compared to a desktop.

I have become more annoyed with laptops as new portable technology comes out. Laptops are good for viewing PDF files, webpages, and other materials in privacy, but a person can find ways to save money and view those things on a desktop computer at home or at campus.

If money was no object, I would probably choose the PDA keyboard console setup over a very light laptop. Getting batteries are charging a laptop can be annoying. The amount of power a laptop battery can hold over time depletes as the owner keeps recharging it; thus, the owner would most likely be using an AC adapter all the time for the laptop. Finding a power outlet in a college classroom isn't easy. Otherwise, go with a tablet pc.

A tablet PC is nice because of its ability to be transferred from one place to another. However, it does require an external powersource if it is being used for long periods of time. This can be a problem for students that do not have the ability to sit next to a power outlet in a classroom.

The other alternative that is like the PDA and keyboard setup is the TI-Keyboard by Texas Instruments. This keyboard hooks up to a TI-Calculator (certain series only) and can be an affordable choice. TI-Calculators can range from $30 USD to $100 and above. The keyboard costs around $40 USD and comes to a total cost of around $80 USD for a keyboard and calculator. The benefit of using the keyboard and calculator is that both will be necessary tools to the math student. A student that takes math courses can use the calculator for math, and he or she could use it when taking notes in a different course.

Both things end up being keepers in the long run and have many uses. However, the alternatives that take household batteries can be the better than other alternatives. Household batteries can be bought almost anywhere, and the lithium batteries give more power than alkaline batteries.

### More External Links

  * [Freedom Input Freedom Keyboard Review](http://www.mobileburn.com/review.jsp?Page=1&Id=1490)
  * [Bluetooth Keyboard Shoot-Out](http://www.mobileburn.com/story.jsp?Id=1491&source=RELATED)

## MS Office or...?

If you bought a desktop computer or laptop, then a good office suite would be [Openoffice.org](http://en.wikipedia.org/wiki/Openoffice.org)

Openoffice.org is more affordable than [Microsoft Office](/wiki/Microsoft_Office). Actually, it's totally FREE. This program can be used on Windows, Linux, and Macintosh computers.

It differs from Microsoft Office and can be a little complex to get use to at first. The controls are a bit different than MS Office but a person can find help documentation for that. Overall, learning how to use openoffice.org is a very valuable skill.

  * Openoffice.org allows a person to save in .doc format.

If a person is willing to use Openoffice.org for home use, but wants to manipulate files at school that have MS Office, then this is how a person would go about it.

  1. Compile a file on Openoffice.org
  2. Save the file on a floppy disk, jump drive, or other storage medium.
  3. Bring the file to school and load it into MS Office
  4. Manipulate the file with MS Office until you are satisfied.

### Notes about the Jumpdrive

I've known people to lose these things extraordinarily quick. These things need to be chained around the neck or around keys. Either way, these things are the best thing around when it comes to transporting a storage medium. I love the things. I like the ability to store Pocket Firefox and other programs so I don't have to deal with the hassle of downloading programs the lazy administrators don't want to upgrade. If a person were to get the PDA console setup, he or she could put all the drivers and programs on the jumpdrive instead of carrying the original setup CD around. That way, a person can upload files from the PDA onto a computer and then onto the jumpdrive.

## Learn FTP

FTP will save you a lot of grief. Learn to work on files and save them to multiple storage mediums: email, jumpdrive, CD, FTP server, etc.

Being able to upload to an FTP is a valuable skill. If a person were to lose a disk with schoolwork on it at the last moment, he or she could go onto the FTP server, download the document he or she uploaded, and then put it on a disk or send it to the professor's email.

Websites that offer FTP are free. I suggest all college students learn how to use FTP.

It's a lot more simple than the complexity people show.

  1. Go to a website that offers free webspace and FTP access
  2. Search around that website for information on how to use FTP for it
  3. Download an FTP program
  4. Start playing around with the FTP program, uploading, and downloading.
  * [Recommended Site](http://0catch.com/) (I've used this since the early 2000s.)

    <http://info.0catch.com/ftp>
    [http://info.0catch.com/searchtech.pl?code=giveanswer&answer=27](http://info.0catch.com/searchtech.pl?code=giveanswer&answer=27)

  


# Choosing a Class

# Introduction

## Don't Choose a Class you Hate

Like high school, college is full of classes people must take in order to earn a degree. Many students don't like taking these courses because they do not relate to their major. Students, nonetheless, have to take courses that don't relate to their major most of the time.

How do you choose a class that doesn't relate to your major?

**Do not choose a course you are NOT good at.**

If you didn't do very well at history growing up, then don't take a history course. College history is very different than high school history.

If you ever found the names of people, geographical regions and developments, battles, and other information to become an overload, then maybe history isn't your thing.

If you are interested in becoming a biologist, but you've always had an interest in abnormal behavior of people such as cutters, drunkards, and schizophrenics, then maybe Psychology would be a course you would like and be interested in.

There may be courses you are interested in taking, but how do you know it is the right course to take? Is psychology the right course to take to learn about people who are cutters and drunkards? It was stated that those people may be linked to psychology, but how do you know the author was correct? How is Psychology different than Sociology? Is Psychology the right course to take? Before choosing a course, make sure you know what the topic is about.

  * Sociology studies society as a whole and how it all things combine.
  * Psychology studies the behavior of an individual.

A rule to remember in college is to take courses that you like. You pay for the courses, you have the ability to choose the courses; take the courses you like. When you have fun with courses, then you'll be able to enjoy what you are doing more. Stressful and dull courses often lead to dull grades.

If no courses are offered that you like per se, then there may be courses you are good at. For example, let's say you know Japanese but Japanese is not offered. Do you consider yourself an expert at mastering languages? Have you studied the Spanish language before? Did you do well in Spanish? Then maybe Spanish will be an ok alternative, for now.

By choosing courses you are good at or are deeply interested in, you find a sure-fire way to keep your grades top notch. People may say this is cheating yourself of learning things in college; however, the paradox exists where doing homework and studying for tests happens more often than learning for fun in college. College after all, is a beginning place for people to go to a university. If a person wants to go to a university, then he or she has to have decent grades.

College has a lot to do with understanding your capabilities and skills. Many of the things "taught" in college can be learned on your own time. Some people don't go to college because they wish to study independently and practice chemistry or foreign languages on their own time.

## College and Hobbies

The interesting thing to remember here is that some people study things outside of college that don't earn them a grade. Focus only on the courses you are taking in college and don't spend extra time dabbling in hobbies. Of course, most people who dabble in hobbies find student clubs around the campus to join for fun.

The lesson here is many people will study courses, earn their degree, and then later on take courses that relate to a hobby of theirs. While in college, focus only on class material. Do not dabble in building computers, welding, or etc. unless it is part of the class material. What is not part of college work should be put off until you earn your degree unless they are house chores or part of your paycheck.

Those who like to dabble in hobbies will try to find a college course that relates to that hobby. For example, if someone likes to build cars, then he or she could find an auto mechanic course in school. Why spend time outside of school dabbling when you could be in college earning college credit for it?

Now, some people take courses at college for fun, because they relate to a hobby of theirs. Another important lesson to remember here is that not all courses transfer. Sometimes courses people take out of interest and fun do not transfer; therefore, people become angry that they wasted money and time on a course that does not transfer.

The central idea of going to college is that it builds credentials. College creates a status for a person. It's better to--study the course materials, review and discuss them, and finish them before the course is over--than to dabble efforts in something, watch your grades go down because you were side-tracked, and then think you ought to have spent more time on school than on hobbies.

  


# Creating a Planner

# Introduction

Whenever starting a new semester, it's always a good idea to have your events planned out. If you have every detail of your day planned out, you'll become less susceptible to the planning fallacy.(1)

Supplies needed:

  1. Watch (Wristwatch or clock)
  2. Writing instrument.
  3. Paper or other surface for writing on.
  4. Grasp of division. Ex: [(140/7) = 20]
  5. Computer
  6. A spreadsheet program: Openoffice.org, Microsoft Excel, Google account, etc..

## Creating a Class Schedule

  1. Obtain your class schedule.
  2. Create a spreadsheet document.
  3. Wikibook not complete.....

## Preparing to avoid the planning fallacy

The planning fallacy occurs when you think you know how long something will take. However, a more mathematical approach to planning out your day would be better than an assumption. Typically the best way to figure out how long it will take to read 20 pages of a textbook is to time one's self. If a person were to stay keep the environment around her or him consistent, maintain the same speed of reading and comprehension, and keep on task, then he or she would have variables to help determine how long it took to read 20 pages. This may not be the best statistical way to prepare, but it is better than nothing or assuming.

Ex:

You sit in a quiet library with a pair of AoSafety headphones on. You keep your eyes on the book and maintain a steady rate of reading. In two hours you have read 20 pages of your textbook. If you were to continue going through your textbook--proceeding to a different text after the 20 pages and returning back to the preceding text--and reading 20 more pages, then you can view how long it took you to read 20 pages again.

Analyzed version:

  1. Read 20 pages of a book. (Book 1)
  2. Log the amount of time it took to read 20 pages.
  3. Read 20 pages of a different book. (Book 2)
  4. Log the amount of time it took to read 20 pages.
  5. Read 20 pages of a different book. (Book 3)
  6. Log the amount of time it took to read 20 pages.
  7. Read 20 pages of a different book. (Book 4)
  8. Log the amount of time it took to read 20 pages.
  9. Read 20 pages of a different book. (Book 5)

* * *

    

  * If you have fewer than five books, go back to book 1.
  * If you have greater than five books, alternate the time accordingly to whatever heuristic thought you have.

Ex:

  1. Read 15 pages of a different book. (Book 5)
  2. Log the amount of time it took to read 15 pages.
  3. Read 15 pages of a different book. (Book 6)

* * *

Continue reading and logging time for a week (7 days).

By the end of a week, you should have the amount of time it took you to read 20 pages of each book per day.

Example: Book 1 (Su: 2 hours; M: 1 hour 30 mins; T: 2 hours 15 minuts; ...) Add up the amount of time from each day for book 1; divide by 7.

  * This is typically how long it takes you to read 20 pages of book 1.

Do the same for every other book.

  * This is typically how long it takes you to read 20 pages of that book.

There may be problems with the first few days in which you become acquainted with a textbook. These problems should be totalled into the equation.

After doing this for a week, you have a better understanding of how long it takes you to read a certain book. It is advised that you switch between books.

## Setting up a Reading Schedule

### Sources

  1. <http://en.wikipedia.org/wiki/Planning_fallacy>

  


# Going to Class

Attendance can be an issue when going to college. There comes a time in the career of most college students where they may feel the need to miss class. However, missing class is unadvised as it is an integral part of the learning experience.

## Reasons

There are several reasons one should go to class.

One reason is that many courses, especially lecture courses, are designed in such a way that information is not repeated between different class meetings, and missing a certain day means that you miss a day to learn new material. This can be hazardous and hurt one's grade.

## Lack of Sleep

If a student hasn't been sleeping well or hasn't slept within the past 24 hours, he or she could use a voice recorder as a secondary "remembering device". When a person is fatigued, he or she typically can not remember as much as he or she would when awake. However, the voice recorder can retain 100% of what the brain can not. All a student has to do is pull out a voice recorder, set it up on a desk or table, and start recording. Afterwards, the student can nod off and the device records the lecture. Then, the student can listen to it later when he or she is more awake.

  


# Studying

## Going to the Library

Going to school and staying out of the house is the best possible thing to do if you want to study. Being inside the house, a person may be tempted to turn on the television or play around on the Internet. This is why going to a library is recommended. Make sure you make a meal for yourself so you can study for a few hours there.

Of course, a library is not the quietest place around, if the surroundings are not controlled. Cell phones are the demons of today's world that wishes to have silence. Colleges are also not without their chatty valley girls with similes committing suicide. This is why I recommend getting the type of **ear muffs** a person wears when shooting a gun. Don't buy a gun, or use a gun in school; buy the ear muffs used. The ear muffs, at times, are better than noise canceling headphones. Ear muffs greatly reduce the sound level of your surroundings.

Also, unless you really, really have to use it, **stay away** from the Internet and a computer. Sometimes, when a person gets on the Internet, he or she dabbles time in listening to music, reading a blog, or etc. instead of doing school work. Staying away from a computer is best when studying in a library.

When inside the library, find a quiet place to sit. Make sure this area has ample lighting; lighting has an effect on the circadian system of the human body and keeps the mind awake and active.

## See Also

<http://en.wikibooks.org/wiki/How_to_pass_a_course>

  


# Etiquette

## Your position as a student

  1. Improve the society with your acquired knowledge.

## Your rights as a student

## Talking in Class

  1. Volunteer.
  2. Be an inspiration to the class.
  3. Avoid unacademic behaviour.

## Not Talking in Class

Rules of Thumb:

  1. If you don't know something, ask the professor a question.
  2. If talking in class is not required, try to not talk too much.
  3. If you are angry at the professor, email the professor or talk to the professor outside of class.
  4. If the class is behind on lectures and covering new material, it is considerate at times to let class conversations die down for a few days.
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=College_Survival_Guide/Print_version&oldid=1482859](http://en.wikibooks.org/w/index.php?title=College_Survival_Guide/Print_version&oldid=1482859)" 

[Category](/wiki/Special:Categories): 

  * [College Survival Guide](/wiki/Category:College_Survival_Guide)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=College+Survival+Guide%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=College+Survival+Guide%2FPrint+version)

### Namespaces

  * [Book](/wiki/College_Survival_Guide/Print_version)
  * [Discussion](/w/index.php?title=Talk:College_Survival_Guide/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=College_Survival_Guide/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=College_Survival_Guide/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=College_Survival_Guide/Print_version&action=edit)
  * [View history](/w/index.php?title=College_Survival_Guide/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/College_Survival_Guide/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/College_Survival_Guide/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=College_Survival_Guide/Print_version&oldid=1482859)
  * [Page information](/w/index.php?title=College_Survival_Guide/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=College_Survival_Guide%2FPrint_version&id=1482859)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=College+Survival+Guide%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=College+Survival+Guide%2FPrint+version&oldid=1482859&writer=rl)
  * [Printable version](/w/index.php?title=College_Survival_Guide/Print_version&printable=yes)

  * This page was last modified on 27 April 2009, at 13:31.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/College_Survival_Guide/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
