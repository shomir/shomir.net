# Drafting

From Wikibooks, open books for an open world

< [Drafting](/wiki/Drafting)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Drafting/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Drafting/Print_version) on _15 November 2011_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Drafting/Print_version&oldid=2211367&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Drafting](/wiki/Drafting)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Drafting/Print_version&action=purge&printable=yes) this page.

_At sea aboard USS Kearsarge, Illustrator Draftsman 1st Class Steven Rodgers designs a training slide_  
![US Navy 030209-N-2972R-079 Illustrator Draftsman designs a training slide with the assistance of a light table.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/c/cf/US_Navy_030209-N-2972R-079_Illustrator_Draftsman_designs_a_training_slide_with_the_assistance_of_a_light_table.jpg/400px-US_Navy_030209-N-2972R-079_Illustrator_Draftsman_designs_a_training_slide_with_the_assistance_of_a_light_table.jpg)  
_Welcome to the Wikibook on_  
  
**Drafting**  


  
**The Objectives of Drafting as an Explanatory Practical Arts Course**

The general objectives of drafting as an explanatory practical arts course are as follows:

  1. To acquire essential skills in freehand drawing and lettering, in creating simple structural and decorative designs, in sketching pictorial drawings, and in making orthographic working sketches
  2. To get acquainted with the technical and related general knowledge concerning the general drafting trade
  3. To be able to read and interpret working sketches and working drawings
  4. To develop one's power of observation and visualization
  5. To form good habits of work such as cleanliness, accuracy, neatness, orderliness, speed and industry
  6. To appreciate good draftsmanship

**Tools and Materials Needed**

The following tools and materials are needed in freehand drawing and in technical sketching:

  * Drawing pencils (F, HB, B and 6B) are generally used in sketching all required drawing plates
  * Soft rubber eraser
  * Ruler (metric)
  * Drawing and lettering pens with a pen holder (e.g., Gillott, Staedtler, Speedball)
  * Drawing papers, 23 cm x 30 cm, 23 kg (50 lb) book or Oslo paper and bristol board (cartolina)
  * Sketch book, 23 cm x 30 cm (9" x 12"), with cross-perpendicular lines
  * Pocket knife or NT knife and sharpening pad
  * Flexible steel measuring tape 2 m long
  * Large envelope, 30 cm x 40 cm (12" x 16")
  * Lecture notebook
  * India ink, 22 cc (3/4 oz) bottle
  * Water color set with pointed sable brush (Prang or equivalent)
  * Tempera colors (6 bottles to a set)
  * Wax crayons (16 colors)
  * Tracing paper, 1/2 m long

## Contents

  * 1 Contents
  * 2 Appendices
  * 3 Introduction
  * 4 Freehand Drawing
  * 5 Designing
  * 6 Lettering
  * 7 Orthographic Sketching
  * 8 Pictorial Drawings
  * 9 Dimensioning
  * 10 Working Sketches
  * 11 Blueprint Reading
  * 12 Commercial Art
  * 13 Bibliography
  * 14 Glossary
  * 15 Appendices
    * 15.1 Other Blueprint Reading Problems
    * 15.2 List of Operations or Skills to be Learned
    * 15.3 Metric / Imperial Conversion Tables
    * 15.4 Table I Inches To Meter
    * 15.5 Table II Feet To Meters
    * 15.6 Table III Inches To Millimeters
    * 15.7 Table IV Miscellaneous Lengths

## Contents

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

A _****printable version****_ of Drafting is available. ([edit it](//en.wikibooks.org/w/index.php?title=Drafting/Print_version&action=edit))

![Wikiversity-logo.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/40px-Wikiversity-logo.svg.png)

[Wikiversity](//en.wikiversity.org/wiki/) has learning materials about _**[Technical Drawing](//en.wikiversity.org/wiki/Technical_Drawing)**_

  1. [Introduction](/w/index.php?title=Drafting/Print_version/Introduction&action=edit&redlink=1)
  2. [Freehand Drawing](/w/index.php?title=Drafting/Print_version/Freehand_Drawing&action=edit&redlink=1)
  3. [Designing](/w/index.php?title=Drafting/Print_version/Designing&action=edit&redlink=1)
  4. [Lettering](/w/index.php?title=Drafting/Print_version/Lettering&action=edit&redlink=1)
  5. [Orthographic Sketching](/w/index.php?title=Drafting/Print_version/Orthographic_Sketching&action=edit&redlink=1)
  6. [Pictorial Drawings](/w/index.php?title=Drafting/Print_version/Pictorial_Drawings&action=edit&redlink=1)
  7. [Dimensioning](/w/index.php?title=Drafting/Print_version/Dimensioning&action=edit&redlink=1)
  8. [Working Sketches](/w/index.php?title=Drafting/Print_version/Working_Sketches&action=edit&redlink=1)
  9. [Representation of Materials](/w/index.php?title=Drafting/Print_version/Representation_of_Materials&action=edit&redlink=1)
  10. [Blueprint Reading](/w/index.php?title=Drafting/Print_version/Blueprint_Reading&action=edit&redlink=1)
  11. [Commercial Art](/w/index.php?title=Drafting/Print_version/Commercial_Art&action=edit&redlink=1)
  12. [Bibliography](/w/index.php?title=Drafting/Print_version/Bibliography&action=edit&redlink=1)
  13. [Glossary of Technical Terms](/w/index.php?title=Drafting/Print_version/Glossary_of_Technical_Terms&action=edit&redlink=1)

## Appendices

  1. [Other Blueprint Reading Problems](/w/index.php?title=Drafting/Print_version/Other_Blueprint_Reading_Problems&action=edit&redlink=1)
  2. [List of Operations or Skills to be Learned](/w/index.php?title=Drafting/Print_version/List_of_Operations_or_Skills_to_be_Learned&action=edit&redlink=1)
  3. [Conversion Table of English Linear Measurements into Metric](/w/index.php?title=Drafting/Print_version/Conversion_Table_of_English_Linear_Measurements_into_Metric&action=edit&redlink=1)

  
**Please add {{[alphabetical](/wiki/Template:Alphabetical)}} only to book title pages.**

  


![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/24px-00%25.svg.png)

# Introduction[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=1)]

Two sources of beauty are commonly recognized—nature and art. Natural beauties exist like the rainbow, mountains, lakes, plants, human beings, birds, and other animals. Nature is considered the Mother of all arts.

Art, on the other hand, is made by persons. Collins and Riley say that "Art is anything made or done by man that affects or moves us so that we see or feel beauty in it." Art is anything created by persons for their comfort and enjoyment, using materials, sounds, or body movements for its expression.

Two classifications of art are generally made—the fine arts and the practical arts. The _fine arts_, purposely created by persons for their own pleasure and appreciation, include music, painting, sculpture, architecture, literature, drama, and dance. The _practical arts_ are also called useful, functional or manual arts since those arts were created by people for use in their daily lives. Architecture is not only functional but aesthetic as well.

**The Practical Arts**

The practical arts are of six general types: industrial arts, agricultural arts, business or commercial arts, home economic or homemaking arts, fishery arts and distributive arts. _Industrial arts_ refer to activities by which a person creates or produces objects in industrial plants or home shops, such as general metal work, general automotive, drafting and graphic arts, general woodworking, general electricity, ceramics and home industries.

In the Philippines, the trade or vocational courses offered in the trade or technical schools are commonly called industrial education or trade courses and not industrial arts. These courses prepare the students for entrance into the occupations or trades.

The industrial or manual arts in the elementary schools are simpler and their main goal is not to prepare the pupils for employment but rather to explore their interests and aptitudes and to train them in good citizenship. Some of the industrial arts in the grades are bamboo craft, toy craft, shell craft, coir and fiber craft, leather craft, wire and sheet-metal craft, elementary electricity, elementary woodworking, and bookbinding.

The manual arts offered in the secondary schools are generally called _practical arts_. The main objective of offering practical arts in the first and second years is the same as the objective of industrial arts in the elementary schools. In the third and fourth years, however, the practical arts are chiefly offered to prepare the students for "initial gainful employment" in these arts.

_Agricultural arts_ include farming, vegetable gardening, horticulture, swine and poultry raising, dairy farming and planting of ornamental plants.

_Business arts_ refer to retail merchandising, lunchcounter work, typewriting, stenography, and bookkeeping.

_Homemaking arts_ include dressmaking, crocheting, food preparation and preservation, interior decoration, nutrition, child care, hair science, and embroidery work.

In the high schools, the term _home economics_ refers to advanced homemaking arts. _Fishery arts_ are offered in schools located near rivers and seas. They include net weaving, shallow-water fishing, deep-sea fishing, and fish preservation. The _distributive arts_ involve packaging, marketing, warehousing, advertising and shipping of manufactured goods.

**Drafting Areas**

Drafting is the process of representing an object or idea by means of lines having various thicknesses and makeups. Drafting is an industrial art because it helps in the production of economically useful articles. Practically all modern home appliances, automobiles, buildings, radio and television sets, space satellites, rockets, etc., start on the drawing or drafting board. They are first designed and laid out on paper before being made in the factories.

The major kinds of drafting are furniture drafting, architectural drafting, mechanical or machine drafting, electrical and electronics drafting, topographical drafting, airplane drafting, ship or naval drafting, structural drafting and sheet-metal drafting. _Furniture drafting_ includes not only the making of working drawings of the various types of furniture but also the designing of them. _Architectural drafting_ pertains to the making of working plans for buildings for residential, business, manufacturing, religious, recreational and storage purposes. _Machine drafting_ is the preparation of detail and assembly working drawings of machines and their parts. _Electrical and electronics drafting_ produces schematic wiring diagrams for either house wiring connections and radio and television receivers and transmitters or the installation of electrically-operated machines. _Topographical drafting_ is the making of plots or maps for various purposes. _Airplane drafting_ concerns the preparation of working drawings of aircraft, including helicopters, planes, rockets and spaceships. _Ship drafting_ is the making of working plans for all types of ship and for either commercial or naval purposes. _Structural drafting_ refers to the making of working drawings of steel buildings, bridges, towers, dams and so forth. _Sheet-metal drafting_ is the development of surfaces of various objects made of galvanized iron, steel aluminum or copper sheets. It includes pattern development for chimneys, downspouts, water tanks and air-conditioning ducts, among many others.

**Drafting Occupations**

The occupations which a drafting student can apply for after graduation depend on the type of drafting area he specialized in at school. He can be a mechanical or machine draftsman, furniture designer, architectural draftsman, topographical draftsman, structural draftsman, electrical draftsman, or naval draftsman. A new drafting graduate is usually first employed either as an assistant draftsman, tracer, blueprinter, checker, or computer before becoming a full-fledged draftsman.

**Allied Drafting Trades**

Drafting work is also needed by craftsman in other occupations like the commercial artist, layout-stripper, and lithographic artist in printing establishments, textile designer and silk-screen printer.

A _commercial artist_ manufactures signs, commercial posters and advertisements for the newspapers and magazines and on billboards. He also makes promotion pictures for theaters and car cards. A commercial artist can also be a _lithographic artist_, one whose job is to make pictures and pages of text from engraved zinc or aluminum plates because of the similarity in the nature of his work to that of the latter.

A _layout-stripper_ is a skilled worker who prepares layouts and strips negatives or positives on goldenrod paper or vinyl sheet, respectively, preparatory to the making of the lithographic printing plate for offset printing. A _textile designer_ designs motifs and all-over patterns appropriate for printing on textiles.

A _silk-screen printer_ draws and prepares stencils out of lacquer-coated paper(called Nu-film or Blu-film in the market), which is made to adhere to a silk-screen frame for printing purposes.

# Freehand Drawing[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=2)]

This chapter deals with two types of freehand drawing. One pertains to artists' drawings and the other to drawings done by technical men and skilled industrial workers. Artists' drawings are generally _freehand drawings_; that is, drawings made without the use of drawing instruments or straightedges. Such drawings are made in perspectives; that is, pictorial drawings as seen by the artist's eyes. As his art medium he uses either a lead pencil, charcoal or carbon pencil, black ink, pastel, oil paint, water color, or crayon.

Technical men and industrial workers, on the other hand, make working sketches which are also freehand drawings but are shown in a special type of drawing called orthographic projection. Generally, an object is shown in three orthographic views—top, front, and side views.

A synonym for freehand drawing is _sketch_. All technical sketches are freehand drawings, but not all freehand drawings are technical sketches.

**Pencil Techniques**

In both freehand drawing and technical sketching, the techniques in drawing or sketching lines are the same. _Horizontal lines_, for instance, are drawn from left to right. Horizontal lines are lines parallel to the lower edge of the drawing paper. _Vertical lines_ are sketched from the top downward, and inclined lines are also generally sketched from left to right. _Short lines_ are drawn with finger movement while _long lines_ are made with arm movement. Long lines, however, may be drawn in segments with very small spaces or gaps between segments. Those gaps are so small that the lines appear at arm's length as single line.

_Perpendicular lines_ are lines which make an angle of 90 degrees with each other. Horizontal and vertical lines can be drawn perpendicular to one another. But not all perpendicular lines are horizontal.

_Parallel lines_ are lines which never meet even if they are prolonged or extended to any desired length. Parallel lines may be vertical, horizontal, or inclined.

Lines may be drawn in various thicknesses or weights with a soft pencil. This is done by varying the pressure of the pencil against the drawing paper. It is this feeling of pressure exerted by the fingers on the pencil that must be developed in order to acquire the "feel" of the pencil. These varying kinds of line can also be drawn by using different grades of drawing pencil.

_Curved lines_, or curves, are regular or irregular. A regular curve is either a circle, an arc(part of the circumference of a circle), or an ellipse. Irregular curves are those which have no definite direction.

In sketching circles, the radii and the two-stroke method are often used. For an ellipse, the beginners should use the parallelogram method. The other two methods of sketching an ellipse should be attempted only after one has acquired the "feel" of the drawing pencil.

**Drawing Pencils**

Drawing pencils are available in various grades of hardness or softness. Hard pencils range from grades H, 2H, . . . , to 9H(the hardest). Soft pencils range from grades B, 2B, . . . , to 6B(the softest). Between H and B pencils are the HB and F. All of these pencils are available in the market. With HB, 2B, and H pencils, the student can easily make variations in the lightness or darkness of his lines even if the pressure of the pencil on the paper is the same for each grade pencil.

Pencil points may be sharpened into three different shapes: the conical, the chisel, and the elliptical. For sketching purposes, the first two are recommended.

The conical pointed soft pencil can make different thicknesses of lines by varying the pressure of the pencil against the paper surface. A hard pencil with a similar point can make different thicknesses of lines by varying the shape of its point. A dull point makes a broad line while a fine point makes a fine line. This is why soft pencils are preferred to hard pencils in sketching. The chisel point, on the other hand, makes wide lines depending on the width of the point. It is generally used in shading a penciled outline drawing.

Pencil points are usually sharpened on a sandpaper pad. The wooden part of the pencil is first cut off with a pocket knife or razor or stripping blade, thus exposing the lead about one centimeter long. The pencil point is then shaped on the sandpaper pad by rubbing the point while at the same time turning it.

# Designing[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=3)]

[Drafting/Designing](/w/index.php?title=Drafting/Designing&action=edit&redlink=1)

# Lettering[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=4)]

Lettering is a dying art that presents text, dimensions and notes that are hand written in a standard form. Lettering is typically all upper case without slant or formatting but the creator of a drawing will often put their own personality into the lettering. All caps on an engineering drawing is not "yelling" but is good practice and facilitates clear communication. Slanted lettering may be used for emphasis of a particular point or idea.

Letters are all block letters generally of equal width and 1/8 inch tall. The use of a mechanical guide or construction lines to control height is recommended for consistency. Unless an inked drawing is lettered using a Leroy scriber (now obsolete) lettering is done freehand. All letters are upper case only unless in a long paragraph of more than 2 sentences. Letters of a word will be close to each other without touching. Space between words is about the same as the letter H or W. Numbers are the same size as letters. Fraction numbers are slightly smaller than 1/8 inch, stacked and symmetrical to the line it is in. Multiple lines of text should leave space between each line of about half the height of a normal letter.

Special cases of lettering may be smaller or larger than the standard height. Title block lettering may be larger. Section view identifiers and cutting plane labels may also be larger.

Each letter is generally created from top to bottom and left to right. At the end of each straight leg or line of a letter, the pen or pencil is picked up and relocated for the next line. For example the letter 'A' consists of a stroke down and to the left, down and to the right and a final stroke left to right half way up the height connecting the two legs together. Rounded letters such as 'O' start at the top and go down and around to the left to the bottom, pencil up, then another stroke from the top then down and to the right closing the O at the bottom. Shortcuts are often taken making these letters with one stroke. Letters are generally sans-serif though using she serif form of 'I' as the word I is accepted.

Notes on special letters and numbers:  
The letter 'W' has both outside legs slanted outward and are not vertical.  
The letter 'M' outside legs are vertical and not slanted. 'M' is not an upside down 'W' and vice versa.  
The number '0' (zero) and '7' do not have a slash.  
The number '4' comes to a point and is not open.  
The number '8' is made of two small circles of two to four strokes and not a single figure eight stroke.  
The number '9' is similar to the number '6' being made of curved strokes and no straight lines.  


# Orthographic Sketching[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=5)]

An orthographic sketch is a drafting term for the standard layout of an object by using three views, such as top, front, and side.

# Pictorial Drawings[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=6)]

[Drafting/Pictorial Drawings](/w/index.php?title=Drafting/Pictorial_Drawings&action=edit&redlink=1)

# Dimensioning[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=7)]

Dimensioning is the process of measuring the cubic space that a package or object occupies. It is the method of calculating dimensional weight for the storage, handling, transporting and invoicing of goods. Vehicles and storage units have both volume and weight capacity limits and can easily become full in terms of volume before they reach their capacity in weight. By dimensioning objects, parcels and pallets, shipping companies and warehouses can make optimal use of space and charge for services accordingly.

**_The background behind dimensioning_** In 1985 a Norwegian company called Cargoscan, which officially became part of the Mettler Toledo group in 2000, began supplying dimensioners and data capture solutions to transport and logistics companies around the world. The aim was to provide the industry with a system for revenue recovery and protection. It seemed that if carriers were to take both weight and volume into consideration when invoicing, they could charge customers more fairly according to services provided and make better use of resources.

# Working Sketches[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=8)]

[Drafting/Working Sketches](/w/index.php?title=Drafting/Working_Sketches&action=edit&redlink=1)

# Blueprint Reading[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=9)]

[Drafting/Blueprint Reading](/w/index.php?title=Drafting/Blueprint_Reading&action=edit&redlink=1)

# Commercial Art[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=10)]

[Drafting/Commercial Art](/w/index.php?title=Drafting/Commercial_Art&action=edit&redlink=1)

# Bibliography[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=11)]

Bradley, Charles B. _Design in the Industrial Arts_. Peoria. Ill.: The Manual Art Press, 1940.

Carlson, Charles X. _Water Color Painting_. N.Y.: Melior Book Co., 1942.

Collins, Rose M., and Riley Olive. _Art: Appreciation for Junior and Senior High Schools_. N.Y.: Harcourt, Brace & Co., 1937.

Downer, Marion. _Discovering Design_. N.Y.: Lothrop, Lee & Shephard Co., 1947.

Edel, Henry D. _Introduction to Creative Design_. N.J.: Prentice-Hall, Inc., 1967.

Fabry, Alois. _Water Color Painting Is Fun_. N.Y.: Viking Press, 1960.

Feirer, John L. _Drawing and Planning for Industrial Arts_. Peoria, Ill.: Chas A. Bennett Co., Inc., 1956.

French, Thomas E., and Vierck, Charles J. _A Manual of Engineering Drawing for Students and_ Draftsmen_. 9th ed. N.Y.: McGraw-Hill Book Co., Inc., 1963._

——————. _Engineering Drawing and Graphic Technology_. N.Y.: McGraw-Hill Book Co., Inc., 1969.

——————; Sevensen, Carl L. et al. _Mechanical drawing_. N.Y.: McGraw-Hill Book Co., Inc., 1974.

Giachino, J.W., and Beukema, Henry J. _American Technical Society's Drafting_. Chicago: American Technical Society, 1960.

Giesecke, Frederick E.; Mitchell, Alva; and Spencer, Henry C. _Technical Drawing_. 6th ed. N.Y.: Macmillan Co., 1974.

——————. _Engineering Graphics_. N.Y.: Macmillan Co., 1969.

Goldstein, Harriet, and Goldstein, Vetta. _Art in Everyday Life_. 4th ed. N.Y.: Macmillan Co., 1954

Hornilla, Cesar et al. _Theory of Technical Drawing, Part I_. Manila: UST Press, 1976.

Jervis, William. _General Mechanical Drawing_. N.J.: D. Van Nostrand Co., Inc., 1950.

Katz, Hyman H. _Handbook of Layout and Dimensioning for Production_. N.Y.: Macmillan Co., 1957.

——————. _Technical Sketching and Visualization for Engineers_. N.Y.: Macmillan Co., 1949.

Lighte, Paul R. _Blueprint Reading and Sketching_. N.Y.: McKnight and McKnight, 1950.

Luzadder, Warren. _Fundamentals of Engineering Drawing_. N.J.: Prentice-Hall, Inc., 1977.

McGee, R.A., and Sturtevant, W.W. _General Mechanical Drawing_. N.Y.:Bruce Publishing Co., 1941

Manaois, German M. _A Manual of Art Education and Appreciation_. Manila: National Book Store, 1977.

Matasek, Ray J. _Commercial Art and Design_. N.Y.: Bruce Publishing Co., 1931.

Pare, E.G. et al. _Descriptive Geometry_. N.Y.: Macmillan Co., 1971.

Pawelek, Stanley J., and Otto, William E. _Introduction to Industrial Drafting_. N.Y.:Benziger Bruce & Glencoe, Inc., 1973.

Rogers, William W., and Welton, Paul L. _Blueprint Reading at Work_. N.J.: Silver Burdett Co., 1956

Rotmans, Elmer A. _Drafting Simplified_. N.Y.: Delmar Publishing, 1967.

Rotmans, Elmer A., and Norton, Homer L. _Drafting Technology_. N.Y.: Delmar Publishing, 1967.

Ross, George F. _Speedball Text Book_. Camden, N.J.: Hunt Pen Co., 1948.

Ross, Robert. _Commercial Art_. Penn.: International Textbook Co., 1963.

Shaeffer, Glenn N., and Spielman, Patrick E. _Basic Mechanical Drawing_. N.Y.: Benziger Bruce & Glencoe, Inc., 1974.

Spencer, William P. _Drafting Technology and Practice_. Peoria, Ill.: Chas A. Bennett Co., Inc., 1973

Stephenson, George E. _Drawing for Product Planning_. Peoria, Ill.: Chas A. Bennett Co., Inc., 1970

Steinike, Otto. _Blueprint Reading, Checking, Testing_. Ill.: McKnight and McKnight, 1956.

Thayer, H.R. _Blueprint Reading and Sketching_. N.Y.: McGraw-Hill Book Co., Inc., 1942.

Wallace, C.E. _Commercial Art_. N.Y.: McGraw-Hill Book Co., Inc., 1939.

Varnum, William. _Industrial Arts Design_. Peoria, Ill.: Manual Arts Press, 1933.

Victoria, Pablo. _Art in the Elementary Schools_. Quezon City: Phoenix Publishing House, Inc., 1959.

Zipprich, Anthony E. _Freehand Drafting for Technical Sketching_. N.J.: D. Van Nostrand Co., Inc., 1954.

# Glossary[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=12)]

[Drafting/Glossary of Technical Terms](/w/index.php?title=Drafting/Glossary_of_Technical_Terms&action=edit&redlink=1)

# Appendices[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=13)]

## Other Blueprint Reading Problems[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=14)]

[Drafting/Other Blueprint Reading Problems](/w/index.php?title=Drafting/Other_Blueprint_Reading_Problems&action=edit&redlink=1)

## List of Operations or Skills to be Learned[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=15)]

**Freehand Drawing**

  1. Sharpen a pencil (conical, chisel, elliptical).
  2. Lay out the border line (continuous and in segments).
  3. Sketch long straight lines (light and heavy).
  4. Sketch short straight lines (light and heavy).
  5. Sketch parallel lines (short and long).
  6. Sketch perpendicular lines (at various positions).
  7. Sketch arcs and circles (large and small).
  8. Sketch an ellipse by the parallelogram method.
  9. Sketch common plane geometrical figures (triangles, rectangles, square, regular polygons, etc.).
  10. Sketch common solid geometrical figures (cylinder, cone, pyramid, prism, cube, etc.).
  11. Sketch objects in outline form (with lead pencil or ball pen).
  12. Accent an outline drawing (lead or carbon pencil).
  13. Sketch a color chart (Prang 12 color).
  14. Color an outline drawing (crayon or water color).
  15. Shade an outline drawing (lead or carbon pencil).
  16. Erase pencil lines.
  17. Lay out a value scale (7 steps).
  18. Lay out a color-value scale (tints and shades of a color).

**Designing**

  1. Create a naturalistic motif or design.
  2. Create a conventional motif or design.
  3. Create a geometrical motif or design.
  4. Create an abstract motif or design.
  5. Create a center motif.
  6. Create a corner motif.
  7. Create a border design.
  8. Create an all over pattern.
  9. Create simple structures (chair leg, flower vase, molding, etc.).
  10. Create simple articles (coat hanger, medicine cabinet, bookend, bric-a-brac, etc.).
  11. Design a simple iron fence and gate.

**Lettering**

  1. Draw guide lines for lettering (horizontal and inclined).
  2. Print or letter single-stroke Gothic capital letters (alphabet and numbers).
  3. Print single-stroke Gothic small letters (alphabet and numbers).
  4. Print words and sentences (single-stroke Gothic).
  5. Print paragraphs (single-stroke Gothic).
  6. Center a title by the trial-and-error method.
  7. Center a title by the scratch-paper method.
  8. Print Roman letters and numbers by using a Speedball pen, Style C-3.
  9. Print Text or Old English letters and numbers by using the same pen.

**Orthographic Sketches**

  1. Sketch the alphabet of lines.
  2. Block in the views.
  3. Sketch orthographic views of objects with horizontal and vertical surfaces.
  4. Sketch orthographic views of objects with inclined surfaces.
  5. Sketch orthographic views of objects with regular curved surfaces.
  6. Sketch orthographic views of objects with irregular curved surfaces.
  7. Sketch orthographic views from given pictorial views.
  8. Draw a detail working sketch.
  9. Draw an assembly working sketch.

**Pictorial Drawings**

  1. Sketch isometric axes (boxing method).
  2. Sketch cavalier and cabinet axes.
  3. Sketch isometric views of objects with horizontal and vertical surfaces.
  4. Sketch isometric views of objects with inclined surfaces.
  5. Sketch isometric views of objects with regular curved surfaces.
  6. Sketch isometric views of objects with irregular curved surfaces.
  7. Sketch isometric views form given orthographic views.
  8. Sketch cavalier pictorial views.
  9. Sketch cabinet pictorial views.
  10. Sketch semi-artist's parallel perspective.
  11. Sketch semi-artist's angular perspective.
  12. Sketch isometric views of objects having many inclined surfaces (offset method).

**Dimensioning**

  1. Measure objects by use of the metric system.
  2. Print or write metric measurements on the drawing.
  3. Convert metric measurements into English and vice versa.
  4. Stagger dimensions.
  5. Sketch dimension and projection lines.
  6. Sketch continuous dimensions.
  7. Dimension circles or holes (of various sizes) and locate them.
  8. Dimension arcs and angles of various sizes.
  9. Dimension irregular curves by the square method.
  10. Dimension irregular curves by base-line dimensioning method.
  11. Dimension a drawing using the nondirectional method.
  12. Dimension turned pieces.
  13. Dimension an isometric view.
  14. Dimension an oblique view (cavalier or cabinet).
  15. Dimension a tapped hole.
  16. Dimension chambers and tapers.
  17. Dimension large arcs by the radial dimensioning method.
  18. Correct dimensions on working sketches.

**Working Sketches**

  1. Make a working sketch of a detail part.
  2. Make a working sketch of assembled parts.
  3. Sketch the title block.
  4. Check a working sketch.

**Blueprint Reading**

  1. Supply a missing orthographic view.
  2. Supply missing dimensions.
  3. Supply missing visible and hidden lines.
  4. Sketch an isometric view from given orthographic views.
  5. Sketch orthographic views from given isometric views.
  6. Match corners of the object drawn in an isometric view with those of the orthographic views.
  7. Match the lines or edges of the object drawn in an isometric view with those of the orthographic views.
  8. Correct sketches made by other students.
  9. Identify drawing symbols and abbreviations.
  10. Sketch an oblique view (cavalier or cabinet) from given orthographic views.
  11. Sketch a perspective view from given orthographic views (parallel or angular).

**Commercial Art**

  1. Design a monogram.
  2. Invert and transfer design on surface of a linoleum or rubber block.
  3. Engrave and mount the block.
  4. Print an all over pattern with the block.
  5. Draw a poster with a given wording or lettering.
  6. Redesign or improve a given newspaper advertisement.
  7. Hand-letter a table design on glass and mount glass on a triangular wooden base.
  8. Hand-letter a door sign on a wooden board.
  9. Lay out a title page on tracing paper.
  10. Lay out the letterings for a book cover.
  11. Lay out a letterhead.
  12. Make a sign painting for a store.

## Metric / Imperial Conversion Tables[[edit](/w/index.php?title=Drafting/Print_version&action=edit&section=16)]

The metric is now the official system of measurements for sizes and weights in the Philippines. At this writing, however, lumber, shoes, paper, and machine parts are still measured by the English system. Since it will take time to metricize all existing English measurements, the conversion table is provided below to help students adjust themselves to the transition.

The metric equivalent of the English linear measurements are printed in decimal figures and are mostly in fractions of a meter. To read these fractional measurements which are given in decimal figures, it is suggested that the following simple rule be followed:

All numbers at the left side of the decimal point are in meters; the first two numbers to the right of the decimal point are in centimeters; the third number to the right of that is in millimeters; and the rest of the numbers to the right of the third number are a fraction of a millimeter.

For example, 1.016 reads: one meter, one centimeter, and 6 millimeters. Similarly, 5.55525 is read as 5 meters, 55 centimeters, and 5 1/4 millimeters. The last two numbers, or 25, is 1/4 of a millimeter.

To find the equivalent of 3 1/8", for instance, just add the fractional metric equivalent of 1/8" to the metric equivalent of 3 inches. In this case, we have

1/8" = 0.0032 3" = 0.0762 0.0794 which reads: seven centimeters, nine millimeters, and 4/10, or 2/5, of a millimeter

## Table I Inches To Meter[[edit](/w/index.php?title=Drafting/Conversion_Table_of_English_Linear_Measurements_into_Metric&action=edit&section=T-1)]

Inch/Inches Meter Inches Meter

1/32
0.0008
13
0.3202

1/16
0.0016
14
0.3556

1/8
0.0032
15
0.381

3/16
0.0047
16
0.4064

1/4
0.0063
17
0.4318

5/16
0.0079
18
0.4572

3/8
0.0095
19
0.4826

7/16
0.0112
20
0.508

1/2
0.0127
21
0.5334

9/16
0.0142
22
0.5588

5/8
0.0158
23
0.5842

11/16
0.0174
24(2'-0")
0.6096

3/4
0.019
25
0.635

13/16
0.0205
26
0.6604

7/8
0.022
27
0.6858

15/16
0.0237
28
0.7112

1
0.0254
29
0.7366

2
0.0508
30
0.762

3
0.0762
31
0.7874

4
0.1016
32
0.8128

5
0.127
33
0.8382

6
0.1524
34
0.8636

7
0.1778
35
0.889

8
0.2032
36(3'-0")
09144

9
0.2286
37
0.9398

10
0.254
38
0.9652

11
0.2794
39
0.9906

12(1'-0")
0.3048
40
1.016

  


## Table II Feet To Meters[[edit](/w/index.php?title=Drafting/Conversion_Table_of_English_Linear_Measurements_into_Metric&action=edit&section=T-2)]

Feet Meters Feet Meters

1
0.3048
14
4.2672

2
0.6096
15
4.5720

3
0.9144
16
4.8768

4
1.2192
17
5.1816

5
1.5240
18
5.4864

6
1.8288
19
5.7912

7
2.1336
20
6.0960

8
2.4384
21
6.40

9
2.7432
22
6.71

10
3.0480
23
7.01

11
3.3528
24
7.32

13
3.9624

  


## Table III Inches To Millimeters[[edit](/w/index.php?title=Drafting/Conversion_Table_of_English_Linear_Measurements_into_Metric&action=edit&section=T-3)]

Inch/Inches Millimeters Inch/Inches Millimeters

1/32
0.8
21/32
16.7

1/16
1.6
11/16
17.5

3/32
2.4
23/32
18.3

1/8
3.2
3/4
19.1

5/32
4.0
25/32
19.9

3/16
4.8
13/16
20.7

7/32
5.6
27/32
21.5

1/4
6.4
7/8
22.3

9/32
7.1
29/32
23.1

5/16
7.9
15/16
23.9

11/32
8.7
31/32
24.7

3/8
9.5
1
25.4

13/32
10.3
2
50.8

7/16
11.1
3
76.2

15/32
11.9
4
101.6

1/2
12.7
5
127.0

17/32
13.5
6
152.4

9/16
14.3
7
177.8

19/32
15.1
8
203.2

5/8
15.9
9
228.6

10
254.0

11
279.4

12
304.8

13
320.2

14
355.6

15
381

16
406.4

17
431.8

18
457.2

19
482.6

20
508

21
533.4

22
558.8

23
584.2

24
609.6

  


## Table IV Miscellaneous Lengths[[edit](/w/index.php?title=Drafting/Conversion_Table_of_English_Linear_Measurements_into_Metric&action=edit&section=T-4)]

English Metric

1 mile
1.609 kilometers

1 yard(3 ft)
0.9144 meter

3.28 ft
1 meter

39.37 inches
1 meter

1 inch
2.54 centimeters
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Drafting/Print_version&oldid=2211367](http://en.wikibooks.org/w/index.php?title=Drafting/Print_version&oldid=2211367)" 

[Category](/wiki/Special:Categories): 

  * [Drafting](/wiki/Category:Drafting)

Hidden category: 

  * [Books with print version](/wiki/Category:Books_with_print_version)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Drafting%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Drafting%2FPrint+version)

### Namespaces

  * [Book](/wiki/Drafting/Print_version)
  * [Discussion](/w/index.php?title=Talk:Drafting/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Drafting/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Drafting/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Drafting/Print_version&action=edit)
  * [View history](/w/index.php?title=Drafting/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Drafting/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Drafting/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Drafting/Print_version&oldid=2211367)
  * [Page information](/w/index.php?title=Drafting/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Drafting%2FPrint_version&id=2211367)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Drafting%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Drafting%2FPrint+version&oldid=2211367&writer=rl)
  * [Printable version](/w/index.php?title=Drafting/Print_version&printable=yes)

  * This page was last modified on 15 November 2011, at 08:17.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Drafting/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
