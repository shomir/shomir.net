# Accordion/Print Version

From Wikibooks, open books for an open world

< [Accordion](/wiki/Accordion)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Accordion/Print_Version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Accordion/Print_Version) on _16 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Accordion/Print_Version&oldid=2502384&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Accordion](/wiki/Accordion)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Accordion/Print_Version&action=purge&printable=yes) this page.

# Preface[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=1)]

The accordion is a portable box-shaped musical instrument of the hand-held bellows-driven free-reed aerophone family, colloquially referred to as a squeezebox. A person who plays the accordion is called an accordionist.

The instrument is played by compressing or expanding its bellows, while pressing buttons or keys, causing valves called pallets to open which allow air to flow across strips of metal called reeds that vibrate to produce sound inside the body, which then escapes through grilles.

There are three major types of accordion: the diatonic button accordion, the chromatic button accordion (sometimes called a bayan), and the unisoric chromatic piano accordion.

Although the accordion has a reputation in some circles of being cheap, wheezy instruments capable of playing only polkas and folk music, this is not always the case! A full-sized, properly-maintained accordion in the right hands can play almost any type of music, ranging from classical music like Bach and Chopin all the way to jazz and pop, and quite convincingly too. Indeed, many European conservatories and universities regard it as a serious concert instrument, and allow it to be studied at the same level as a piano or string instrument.

This book is currently only about playing the Piano Accordion, although there are many similarities in function to similar instruments, so playing skills such as Bellows, Stradella Bass and Register Switches will transfer to other instruments.

Not all parts will be introduced at first, only sufficient to get you started playing tunes.

# Brief History of the Accordion[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=2)]

The accordion is one of several European inventions of the early 19th century that used free reeds driven by a bellows; notable among them were:

  * The Aeoline, by German Bernhard Eschenbach (and his cousin, Caspar Schlimbach), 1810. 
    * Was a piano with added aeoline register.
    * Aeoline Harmonika and Pysharmonika are very similar names at that time. 
      * Aeoline and Aura ware first without bellows or keyboard. This originals eventually evolved in Harmonica
  * The Hand Physhamonika Anton Haeckel 1818 Hand type mentioned in music newspaper 1821.
  * The flutina, by Pichenot Jeune, ca. 1831
  * The concertina, patented in two forms (perhaps independently): 
    * Carl Friedrich Uhlig, 1834.
    * Sir Charles Wheatstone, examples built after 1829, but not patented until 1844

An instrument called **accordion** was first patented in 1829 by Cyrill Demian in Vienna. (Interestingly, the original patent shows the name "eoline" crossed out and replaced with "accordion" in different handwriting). Demian's instrument bore little resemblance to modern instruments: It only had a left hand keyboard; the right hand simply operated the bellows. One key feature for which Damian sought the patent was the sounding of an entire chord by depressing one key. His instrument also could sound two different chords with the same key: one for each bellows direction (press, draw); this is called a _bisonoric_ action.

At that time in Vienna, mouth harmonicas with "Kanzellen" (chambers) had already been available for many years, along with bigger instruments driven by hand bellows. The diatonic key arrangement was also already in use on mouth-blown instruments. Demian's patent thus covered an accompanying instrument: an accordion played with the left hand, opposite to the way that contemporary chromatic hand harmonicas were played, small and light enough to for travellers to take with them and use to accompany singing. The patent also described instruments with both bass and treble sections, although Demian preferred the bass-only instrument owing to its cost and weight advantages.

The musician Adolph Müller described a great variety of instruments in his 1833 "Schule für Accordion". At the time, Vienna and London had a close musical relationship, with musicians often performing in both cities in the same year, so it is possible that Wheatstone was aware of this type of instrument and may have used them to put his key-arrangement ideas into practice.

Jeune's flutina resembles Wheatstone's concertina in internal construction and tone colour, but it appears to complement Demian's accordion functionally. The flutina is a one-sided bisonoric melody-only instrument whose keys are operated with the right hand while the bellows is operated with the left. When the two instruments are combined, the result is quite similar to diatonic button accordions still manufactured today.

Further innovations followed and continue to the present: Various keyboard systems have been developed; voicings (the combination of multiple tones at different octaves) have been developed, with mechanisms to switch between different voices during performance; different methods of internal construction to improve tone, stability and durability, and so on.

# Introducing the Piano Accordion[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=3)]

## Introducing the Piano Accordion[[edit](/w/index.php?title=Accordion/Introducing_the_Piano_Accordion&action=edit&section=T-1)]

_This module currently draws heavily on text from the Wikipedia [Accordion](//en.wikipedia.org/wiki/Accordion) article._

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/08/Accordion.jpg/250px-Accordion.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A piano accordion

The **piano accordion** is the instrument most often indicated by the term "accordion", but it is one of the most recent inventions among accordion types, appearing late in the 19th century and not accepted worldwide until the early 20th century. It has a right-hand keyboard similar to a piano. This is great news for you if you ever took piano lessons!

The left hand keyboard is usually configured in the Stradella system, a combination of chords and single notes, arranged in a uniform series by harmonic relationship. This is the system we'll be focusing on throughout this book.

Occasionally, a _free bass_ left hand is used, which has a series of single buttons in an arrangement similar to the chromatic button accordion. The free bass system facilitates the playing of bass melodies and counterpoint over a melodic span greater than one octave. It also allows for chord inversion and invention of chords not present in the Stradella system, although the Stradella system also allows creation of extra chords and inversions using simultaneous multiple chord buttons.

_Converter_ bass systems allow an instrument to be readily converted from a Stradella system to a free-bass system with a switch.

# Technique[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=4)]

As with any instrument, technique varies between those who play the accordion. Technique is what makes accordionists stand out between one another. Bad technique will logically create a bad player. Though there are no rules "set in stone" on what should and shouldn't be done, the following techniques and positions are accepted by the general public of accordionists. Consider it "accordion common-sense".

# Body Position[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/ab/Accordion_%28PSF%29.png/220px-Accordion_%28PSF%29.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

How to hold the accordion standing up.

Since your left arm is moving horizontally and vertically, and your right hand is moving vertically, body position is very important. The main goal is to be comfortable yet exercise as much control as possible over the motions of the instrument. Some players prefer sitting, while others like to stand (although this can be easily tiring, especially with a big instrument).

When playing the accordion, the shoulder straps should be fairly tight so that the instrument doesn't shift around as you reach for notes. Don't slouch - it looks ugly and causes you to lose control. Your left arm should be between the bellow-strap and the board; tighten that strap (usually via a notch on top of the bellows mechanism, very rarely Velcro might be used) so that it won't cut off your arm circulation, but not so loose that your hand slips as you change directions with the bellows.

Resist the temptation to bend your right wrist and play with your elbow close to the side of your body. Instead, try to hold your entire arm, from the elbow to the wrist, more or less parallel with the keyboard. Though this may seem awkward at first, in the long run it will help you achieve better accuracy because the circulation to your hand is unimpeded. Note that none of this applies to the left arm.

If playing standing up, stand with good posture and adjust the shoulder straps so that the bottom of the accordion is more or less parallel with the floor and the back of the keyboard portion is against your chest. This will help keep it from shifting too much while you play.

If playing seated, adjust the straps so that the instrument rests lightly on your left leg but doesn't hang loosely from your body. The bottom of the keyboard should be between the legs, and not moved too far to one side. You might need to move your right leg out of the way a little bit so the right hand can reach the bottom keys on the accordion unimpeded. Sit up straight in your chair - don't lean backwards against the back of the chair or slump; it looks bad and can results in poorer accuracy.

You might want to consider investing in a _backstrap_, a small hook-and-eye device that connects the two shoulder straps from behind when you're wearing the instrument. It's useful for bigger instruments because it stops the straps from slipping off your shoulders.

# Operating the Bellows[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=6)]

The bellows are the engine for making the sound in an accordion. They are the lungs of the instrument - depending on how hard the bellows are pulled, the sound will be softer or louder. A well-maintained accordion can have a good dynamic range from _pianissimo_ to around a _forte_. When totally stationary, the instrument is silent. With accordions that also have inbuilt electronic synthesizers, the electronic sound will continue as long as keys are depressed (but this is beyond the scope of this book).

The bellows should be operated with your left hand. Bellows can be somewhat fragile, so don't pull them too hard or too far out. When pulling or pushing, avoid jerky motions and move them cleanly.

Eventually you'll need to change direction and move the bellows back in to keep playing. This can be a bit tricky to do correctly. When changing direction, try to move smoothly yet quickly so avoid a break in the melody or make the dynamics change suddenly. Resist the temptation to jerk the accordion. It's advisable not to pull the bellows out too far, because it's uncomfortable for the left hand to be extended like that and it affects accuracy.

If you're finding you have to move your bellows a lot, check to see if they aren't leaking by letting the bellows fall open on your lap without touching them or depressing any keys. If they move quickly (or you hear a "whoosh" noise), there's likely a leak, which means the instrument consumes more air than is necessary. (If they just creep out slowly, that's okay. Most accordions naturally let out very small amounts of air.) Find a reputable accordion repairman and have it fixed - you can't play properly with leaking bellows!

# Keyboard[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=7)]

The top of the keyboard where the bellows join should be roughly in the centre of the body. Too far either side of that interferes with the comfort and the ability to play properly.

# How to Handle the Accordion[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=8)]

Many accordions have a reputation for being manufactured exceedingly well, and with proper maintenance and preventative measures, it can last decades. Aside from the cost of repairs, you might have difficulty finding someone skilled enough to repair the instrument! A little bit of care goes a long way.

  * When lifting up and putting down your accordion, always be careful; hold the instrument with both hands (by the straps, if they are sturdy). Dropping an accordion even from a small height can be disastrous. When transporting the instrument, it is advisable to lock the bellows straps on the top and bottom (usually found on all but the oldest accordions) so the bellows don't come out. Be careful not to push in the bass buttons when carrying your accordion; it can damage the bass mechanisms.
  * Always store your accordion in a case if you can. This helps keep it away from humidity and other things that might damage the instrument. Try to keep it out of too much heat, cold, or humidity. The reeds inside the accordion might bend out of tune if there's too much humidity.

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/08/Accordion.jpg/300px-Accordion.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

How to store the accordion properly on a table.

  * If you can't store the accordion in a case, then **always place it on a hard flat surface** (like a table), with the keyboard facing up perpendicular to the floor. (The bass side of the instrument usually little protrusions at the corners so you and put it down safely.) Make sure to **always** store it the right way up. An accordion is constructed with leather flaps (valves) that seal the back pressure from the reed that is not sounding in the current direction of bellows movement. Storing the instrument upright allows the valves to be preserved. Storing in other orientations will cause one set of valves to be bent under gravity, ruining the tone and needing more early refurbishment.
  * **Avoid extreme temperatures.** If you would be uncomfortable in the room, so would your accordion. Parts of your accordion are held together by wax or glue joints that can melt in heat. Don't leave the instrument near a ventilator, heater, or near a sunny window, and especially don't leave it in the trunk of a car, because the temperature is uncontrollable and unstable. Also, the accordion may suffer from jolts while in the trunk, especially if not stored the correct way up.
  * If you've just taken the accordion in from from the cold, take it out of its case and let it "warm up" before playing for at least half an hour. Moisture may collect on the reeds from the sudden temperature change, and you want to give it time to dissipate or else the water might harm the reeds.
  * **Avoid moisture.** Do not play your accordion in the rain, or take it to the beach. The salty air can cause the reeds to rust rapidly.
  * **Don't store in an attic or basement.** Be aware that older accordions found in attics may contain harmful mould in the bellows. When played, the mould is propelled towards the player's face.

# Right hand (Chromatic button accordion)[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=9)]

![](//upload.wikimedia.org/wikipedia/commons/7/72/ButtonAccordeon.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A button accordion.

A chromatic button accordion is a type of button accordion where the right side keyboard has rows of buttons arranged chromatically. They have three to five (rarely, some Serbian accordions have six) diagonal rows. Each row can play successive chromatic notes.

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1c/C-Griff.svg/150px-C-Griff.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Chromatic button system (C system)

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/83/B-Griff.svg/150px-B-Griff.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Chromatic button system (type system)

Chromatic accordions are most popular in Europe and in Russia. In Russia, this instrument is usually called a "bayan" (in Russian: баян).

There are two main types of button accordions. In both types, the further away from the top of the keyboard you go, the higher the notes; the closer to the top, the lower.

Both systems are mirrors of each other, as you can see by the chart to the left. In the "C system" accordion, the middle "C" is on the row furthest to the right. In the "B system", the "C" is located on the third row from the right. The B system is primarily played in eastern Europe and Russia, while the C system is played

Most chromatic accordions have two extra rows located to the left of the main rows. They play the same notes as the same buttons of the 1st and 2nd rows. This can be helpful when playing a difficult melody, because you do not have to change fingerings when playing in a different key, but only move your hand to the left a row or two and play with the same fingering.

Chromatic accordions have a much larger range than their piano equivalents (they generally go a seventh higher and up to an octave lower). Also, it is possible to use the same fingering for playing almost any melody in any key - whereas on the keyboard you have to learn twelve individual fingerings for each key. Because the notes are positioned much closer together, large leaps and stretches are easier (you can easily stretch two octaves, compared to about a tenth or twelfth on a piano accordion). For these reasons, many professionals prefer playing button instruments. However, depending on where you live, they may be hard to find (in Australasia and North America, they are particularly rare, and even then usually only available in "C system"). Note that this book does not currently cover playing on the button accordion.

# Right hand (Diatonic button accordion[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Accord%C3%A9on_diatonique.jpg/250px-Accord%C3%A9on_diatonique.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A diatonic button accordion

A **diatonic button accordion** is a type of button accordion where the right keyboard only has the notes of diatonic scales in a small number of keys. The left, or bass side, usually contains the main chords of the instrument's key and their root notes.

Because diatonic accordions have only a few keys they can play in, and usually cannot play accidentals, they are very restricted in what they can play. Usually they can only play folk music and classical music that doesn't contain many accidentals or changes of key signature.

# Right hand (Piano accordion)[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=11)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Klaviatur-3-en.svg/300px-Klaviatur-3-en.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

This is how a piano accordion keyboard looks.

The right hand of a piano accordion is played the same way as you would play a piano, with usually the same fingerings. You can use all fingers, including the thumb, to play on this keyboard.

On a standard, full-sized, the range of the keyboard goes from the "F" below the middle "C", all the way up to the third "A" above middle "C" (41 notes). Some large instruments have 44 or even 45 keys, going from an "E" or "F" to a high "C".

# Left hand[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=12)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/69/96_button_Stradella_bass_upload_%28physical%29.jpg/250px-96_button_Stradella_bass_upload_%28physical%29.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A 96-button Stradella bass layout on an accordion

The **Stradella bass system** (also called the _standard bass_ sometimes) is a type of button layout you find on the left (or bass) side of almost all accordions. It uses columns of buttons arranged in a circle of fifths.

Each diagonal column has, in order from the innermost to outermost buttons:

  * The major third above (or minor sixth below, depending on which note) the root ("counter-bass")
  * The root note
  * The root note's major chord
  * The root note's minor chord
  * The root note's dominant seventh chord
  * The root note's diminished seventh chord

Small accordions sometimes lack some of these rows, but for the purposes of this guide, we'll assume you have the full complement of buttons.

This is a chart of how a standard, 120-button bass layout will look like:

![120-button Stradella chart.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/8c/120-button_Stradella_chart.svg/750px-120-button_Stradella_chart.svg.png)

**Tip:** _Consider printing out this chart and referring to it as you continue with this guide. You might find it helpful to have a visual representation of the directions described._

The middle "C" usually has a bump or hole in it for you to feel, to make it easier to find your way around the left buttons without looking at them. The A flat and E will also have some sort of marking sometimes.

Horizontal columns are arranged in a different order: every column goes up a fifth as you move up the bass board. So a "G" would be below middle "C", and a "F" would be above the middle "C", a "D" would be above the "G", and so on.

Most full-size accordion basses have either 120, or, less commonly, 96 buttons. All notes in an octave are covered by both systems, so you can play in any key.

When playing with the bass buttons, you use all fingers but your thumb, which should stay on the board on the side of the accordion.

Most accordions also have an _air button_ on the side of the instrument that doesn't play any notes, but instead lets air in and out of the instrument.

If you have a large enough instrument, chances are there will be one or more switches next to the innermost row of buttons (near to the bellows). By pressing these, you can control which reeds in the left hand manual are sounding to create different timbres appropriate for the music you're playing, similar to the switches on the right hand.

In the next few pages, we'll learn the basics of playing either a simple accompaniment or melody on the basses. Just use the navigation below to go backward or forward.

# Free Bass[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=13)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/25/Melodiebass.jpg/200px-Melodiebass.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Three systems

The **free-bass** is a type of keyboard system that is found on some accordions. Unlike the Stradella-bass system, all of the buttons on a free-bass keyboard play single notes, not chords. The free-bass also has a bigger range of notes than the Stradella system, and it is easier to play out a tune with it. Due to this, the free bass system is used more often to play serious classical music with less transcription involved.

Most bass systems can switch between the Stradella and free-bass systems, while some accordions have free-bass only or auxiliary free-bass rows in addition to the Stradella buttons (sometimes called a _bassetti_).

There are two common free-bass systems: one is the _chromatic free bass_, where the notes move in a chromatic pattern upwards or downwards (see chart at right). The other is the _quint bass_ system, which has a note system similar to the Stradella bass layout, but spread over several octaves. The former system gives you around five octaves of range in the left hand, and the latter about three. Usually, only big and expensive accordions have free-bass and it is still a relatively new concept; chances are the instrument you have, or are looking to buy, does not have it. As a beginning accordionist, you should not be too worried about it.

The study of free bass is currently beyond the scope of this module, although it may be covered at a later date. Knowing the free-bass system is not essential to becoming a professional accordionist; many pieces can be played just as well on the Stradella system, although free bass is useful for complex pieces like piano music or three/four voice counterpoint (which can frequently be played note-for-note without any transcription even necessary).

# Reed Ranks and Switches[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=14)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Accordion_right_hand_timbre_switches.jpg/195px-Accordion_right_hand_timbre_switches.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A few right-hand manual register switches on a piano accordion. This one has three different voices.

A **reed rank** inside an accordion is a full set of the reeds that are used to make different timbres. These reed ranks are located in the reed chamber. Most accordions usually have two to four reed blocks in the treble and four or five in the left.

They can be used by themselves or in different combinations to make different sounds by allowing or shutting off the flow of air to certain ranks. These combinations are sometimes classified by the instruments they imitate, for instance the clarinet, oboe, and bassoon stops.

The reed ranks can be changed by pressing buttons usually found on the side of the accordion. A full-sized instrument usually will also have a "master" or "palm bar" on the right side of the instrument that can be depressed with the palm to turn on all the reed blocks for the fullest accordion sound.

Large instruments might also rarely have chin switches, which are positioned on top of the instrument and can be changed with the performer's chin. This is useful for if you want to change the timbre without having to take your hand off the keyboard.

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/9/91/Accordion_registers.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Listen to a simple scale played with five different reed combinations. This accordion has three treble reed ranks and has _musette_ tuning (note the "French"-type flavour on the second scale).

In a full-sized, four-reed-rank accordion, you will usually have these reeds:

  * Two eight-foot (8') or _clarinet_ reeds, or reeds that sound at pitch. They are sometimes tuned differently from each other to create a European, French-style sound (sometimes called _musette_ or _wet_ tuning in accordion parlance). Sometimes they are tuned at the same pitch for a sound more appropriate for classical music (called _dry_ tuning).
  * A sixteen-foot (16') or _bassoon_ reed, which sounds an octave below the eight-foot reeds.
  * A four-foot (4') or _piccolo_ reed, which sounds an octave above the eight-foot reeds.

Smaller, three-reed accordions are usually missing either the piccolo reed or one of the clarinet reeds.

Sometimes, instead of a four-foot reed there will be a third eight-foot reed that is tuned differently from the other two clarinet reeds. This creates an even more out-of-tune, French-styled sound, but gives you fewer sound possibilities.

On an average instrument, you can use almost any combination of the reeds to produce different sounds suitable for what you're playing.

Following is a table of all eleven possible combinations on a four-voice accordion as well as their names and a short description of their sound quality. Depending on the size of your instrument, you may not have all of these reeds available.

Reed name Image Description

Bassoon
![Accordionstops bassoon.svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/42/Accordionstops_bassoon.svg/90px-Accordionstops_bassoon.svg.png)
16': Rich, meaty sound, especially in the lowest octave. Good for jazz.

Bandoneon
![Accordionstops bandoneon.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/84/Accordionstops_bandoneon.svg/90px-Accordionstops_bandoneon.svg.png)
16', 8': Like Bassoon, but a little more powerful because of the octave doubling.

Accordion
![Accordionstops accordion.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Accordionstops_accordion.svg/90px-Accordionstops_accordion.svg.png)
16', 8', 8': Like Bandoneon, but a bit thicker.

Harmonium
![Accordionstops harmonium.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/de/Accordionstops_harmonium.svg/90px-Accordionstops_harmonium.svg.png)
16', 8', 4': Like Bandoneon, but brighter due to the high piccolo reed.

Organ
![Accordionstops organ.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Accordionstops_organ.svg/90px-Accordionstops_organ.svg.png)
16', 4': Bright tone, imitative of an organ in its middle range.

Master
![Accordionstops master.svg](//upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Accordionstops_master.svg/90px-Accordionstops_master.svg.png)
16', 8', 8', 4': Loudest and fullest accordion sound.

Musette
![Accordionstops musette.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Accordionstops_musette.svg/90px-Accordionstops_musette.svg.png)
8', 8', 4': Pleasant, bright sound. If you have a _wet_ tuned accordion, this will have a French flavour.

Violin
![Accordionstops violin.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Accordionstops_violin.svg/90px-Accordionstops_violin.svg.png)
8', 8': Pleasant, medium-volume sound. If you have a _wet_ tuned accordion, this will have a French flavour.

Oboe
![Accordionstops oboe.svg](//upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Accordionstops_oboe.svg/90px-Accordionstops_oboe.svg.png)
8', 4': Like Violin, but a touch softer and brighter.

Clarinet
![Accordionstops clarinet.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/db/Accordionstops_clarinet.svg/90px-Accordionstops_clarinet.svg.png)
8': Soft, pure tone free of harmonics.

Piccolo
![Accordionstops piccolo.svg](//upload.wikimedia.org/wikipedia/commons/thumb/0/01/Accordionstops_piccolo.svg/90px-Accordionstops_piccolo.svg.png)
4': Shrill sound, rarely used by itself except for special effects.

# Getting Ready to Play Your First Song[[edit](/w/index.php?title=Accordion/Print_Version&action=edit&section=15)]

## Picking Up The Accordion[[edit](/w/index.php?title=Accordion/Getting_Ready_to_Play_Your_First_Song&action=edit&section=T-1)]

You may lift the accordion by the straps, but do not carry the accordion by the straps. If the strap breaks, your accordion will fall. While falling will not damage your accordion, the sudden stop after it hits the ground may. You put it on like a reverse backpack. The _treble keyboard_ (the one that looks like a piano) will be played with your right hand. The _bass keyboard_ (the one with rows of buttons) will be played with your left hand.

## A Word About Notes[[edit](/w/index.php?title=Accordion/Getting_Ready_to_Play_Your_First_Song&action=edit&section=T-2)]

An octave goes from a C note to the next C note and contains 8 notes: C, D, E, F, G, A, B, C. Since you only have five fingers, you will only be able to play five notes without moving your hand. (Don't worry, our first lesson won't require you to do that.) If you happen to have more than five fingers, congratulations! Many great musicians have made use of their extra digits to play pieces that would be difficult or even impossible for those with only five.

## Fingering[[edit](/w/index.php?title=Accordion/Getting_Ready_to_Play_Your_First_Song&action=edit&section=T-3)]

For the time being, each finger on your hand will strike one and only one key in a given song. Later in the course, you will learn how to smoothly move your hands across the keys to play a greater range of notes.

To help you play these early songs accurately, each note in the song will be numbered. Starting with your _right_ hand, count from your thumb to your pinkie. Your thumb will be "1", and your pinkie will be "5". Any "1" note will be played by your thumb, and "5" note by your pinkie, and any "3" note by your middle finger.

We'll do the same thing on your left hand. Your thumb will be a "1" and your pinkie will be a "5".

_**Note: More advanced musicians do not refer to notes this way. Starting from the "1" note, the notes would be C, D, E, F, and G. After you get more practice, we'll phase out the use of this numbering system. Our main concern right now is to get your fingers moving and making music!**_

Look on the _treble keyboard_ (right hand) for the first grouping of two black keys. Place your thumb on the white key to the left of the first black key. The remaining fingers should be placed on the adjacent white keys.

Look on the _bass keyboard_ (left hand). You want to place your "4" finger on C. (Some people prefer to use "3".) The C key will have a jewel, bump, or indentation on it so you can feel it, instead of looking for it. If you have a large accordion, you may have a few keys like this. The one in the middle is usually C. Don't feel daunted by the number of keys on the bass keyboard! Most songs we will be playing will only use a few that will be easy to reach.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Accordion/Print_Version&oldid=2502384](http://en.wikibooks.org/w/index.php?title=Accordion/Print_Version&oldid=2502384)" 

[Category](/wiki/Special:Categories): 

  * [Accordion](/wiki/Category:Accordion)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Accordion%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Accordion%2FPrint+Version)

### Namespaces

  * [Book](/wiki/Accordion/Print_Version)
  * [Discussion](/w/index.php?title=Talk:Accordion/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Accordion/Print_Version&stable=1)
  * [Latest draft](/w/index.php?title=Accordion/Print_Version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Accordion/Print_Version&action=edit)
  * [View history](/w/index.php?title=Accordion/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Accordion/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Accordion/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Accordion/Print_Version&oldid=2502384)
  * [Page information](/w/index.php?title=Accordion/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Accordion%2FPrint_Version&id=2502384)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Accordion%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Accordion%2FPrint+Version&oldid=2502384&writer=rl)
  * [Printable version](/w/index.php?title=Accordion/Print_Version&printable=yes)

  * This page was last modified on 16 March 2013, at 09:54.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Accordion/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
