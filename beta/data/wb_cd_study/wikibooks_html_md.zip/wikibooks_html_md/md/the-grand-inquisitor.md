# The Grand Inquisitor/Print version

From Wikibooks, open books for an open world

< [The Grand Inquisitor](/wiki/The_Grand_Inquisitor)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=The_Grand_Inquisitor/Print_version&action=purge&printable=yes) this page.

  
[The Grand Inquisitor/Cover](/w/index.php?title=The_Grand_Inquisitor/Cover&action=edit&redlink=1)  


  
This book is an annotated text for 3 noteworthy chapters from Fyodor Dostoevsky's book **The Brothers Karamazov**. The three chapters considered here are **The Grand Inquisitor**, **Rebellion**, and **The Devil**, which are considered to be some of the most powerful chapters from the book, and some of the most influential chapters in the canon of western literature. Eventually this book could be expanded to include other chapters from this book, although it is unlikely that the entire book will ever be annotated here.

These three chapters revolve around Ivan Karamazov, an educated intellectual and admitted atheist in Russia. The first two chapters also include Alyosha Karamazov, a counter-point to Ivan, who is a monk in training, and is well known for his qualities of compassion, unconditional love, strong faith, and trustworthyness.

  


# Introduction

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## The Grand Inquisitor

## Who Is This Book For?

## What Will This Book Cover?

This book will cover three chapters from the book **The Brothers Karamazov**: **Rebellion**, **The Grand Inquisitor**, and **The Devil**. These three chapters center around the character Ivan, and represent some of the most powerful critiques of organized religion. Of particular interest here is Roman Catholicism.

It may be possible for this annotated text to eventually be expanded to cover additional chapters from the book. However, considering its size, it is unlikely that the entire book will ever be annotated here. Besides the three covered initially, there are several other important chapters worth annotating.

## How Will This Book Be Arranged?

The three chapters presented in this annotation are not subdivided into sections. However, for the sake of clarity, this book will divide the chapters into individual component pieces, at places where there is a logical breaking point.

The first section of the book will contain some basic information about **The Brothers Karamazov**, including information about the author, information about the plot, and information about the characters. The second section of the book will contain the annotations, complete with the full text of the passages. The full text will appear in shaded boxes on the left of the page, and discussion and annotation will appear in plane text on the right side of the page.

## Where To Go From Here?

Readers who have not yet read _The Brothers Karamazov_ are encouraged to read it in its entirety. The full text can be found at wikisource: [Wikisource:The Brothers Karamazov](//en.wikisource.org/wiki/The_Brothers_Karamazov).

  


# History

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

The Brothers Karamazov was intended to be the first part of a trilogy of books, but Dostoevsky died shortly after the first installment was published. The three chapters described here, **The Grand Inquisitor**, **Rebellion**, and **The Devil** have also been published as a stand-alone reader.

  


# Fyodor Dostoevsky

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Fyodor Dostoevsky**_](//en.wikipedia.org/wiki/Fyodor_Dostoevsky)

![Dostoevsky.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Dostoevsky.jpg/500px-Dostoevsky.jpg)

...a short biography of the author

  


# The Brothers Karamazov

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[The Brothers Karamazov**_](//en.wikipedia.org/wiki/The_Brothers_Karamazov)

Here we are going to briefly explain some of the plot of this book. Parts that bear no strong influence on the three chapters we will be annotating will be omited.

## History

Fyodor Karamazov, the father of the house, is a crude character. He is married twice, and pays little in the way of love or respect to either wife. From his first marriage, he has a child named Dimitri. From his second wife he has two children, Ivan (the older), and Alyosha (the younger).

Fyodor pays little attention to any of his children. After his wives die, the children are brought up by the servant Grigory and his wife Marfa. The children are then separated, and sent out to live with relatives of their respective mothers.

Fyodor, on a bet, makes love to a retarded girl in town, named Stinking Lizaveta. Lizaveta bears a child named Smerdyakov, and dies during the birth. Smerdyakov is also raised by Grigory, and eventually grows up to become a servant of Fyodor. It is assumed by many that Smerdyakov is the biological son of Fyodor, but this fact is never proven. As with his other children, Fyodor largely ignores Smerdyakov, and does not treat him like a son.

Through a series of events, all three brothers return to the house of their father. Dimitri and Fyodor have been quarreling over Dimitri's inheritance (of which Fyodor claims there is none left).

## Religion

Alyosha is a monk in training at the local monastery, while Ivan is a well-educated and influential atheist. Despite their strong differences in the area of religion, the two brothers seem to get along fine and respect each other. The two brothers have not seen each other much before arriving at Fyodor's house, so they spend time talking at a local bar. Their conversation, which inevitably turns to the topic of religion, is recounted in the chapter on _Rebellion_. After this conversation, Ivan relates to Alyosha a "poem" he has been working on, known as _The Grand Inquisitor_.

## Love

Dimitri, a military service man, has captured the heart of a young woman, Katerina Ivanova, the daughter of a military commander. Katerina feels some amount of love and loyalty to Dimitri, but Dimitri does not return the feelings. While on duty in the military, Dimitri learns that Katerina's father is in debt and is at risk of losing his rank and doing time in jail for it. Dimitri gives the money to Katerina, and asks nothing from Katerina in return. It is because of this event that Katerina feels bound to Dimitri, and constantly refers to herself as being in his debt.

While Katarina feels hopelessly bound to Dimitri, who does not return her affections, Ivan has fallen for Katerina. Katerina has fallen for Ivan as well, but because of her debt to Dimitri she does not allow a relationship to form between them. The conflict between his love for Katerina and his loyalty to his brother is a major stressor for Ivan.

Dimitri is not in love with Katerina primarily because he is in love with another woman, Grushenka. Fyodor also has a romantic interest in Grushenka so father and son begin competing for her attention. Combined with the financial problems between them, the fight over Grushenka is a a major source of contention.

## Murder

Ivan, upset about his own relationship with his father, and also upset about his relationship with Katerina, decides to leave town for Moscow. Smerdyakov says a few surprising things that catch Ivan off guard. First Smerdyakov says that without Ivan around, there were no strong men in the house to protect the father from Dimitri. Smerdyakov has told Dimitri the secret code of knocks that will cause Fyodor to open the lock on his bedroom door at night. Also, Smerdyakov mentions that he is planning to "have a seizure" the following night when Ivan is absent, thus leaving the entire house empty, except for Fyodor.

Ivan, not understanding the correlation between all these facts, or making some conscious effort to ignore them, leaves for Moscow the next morning. Predictably, things go the way Smerdyakov had anticipated: He had a seizure the following night, Dimitri used the secret signal to gain entry to Fyodor's bedroom, and Fyodor is found murdered the next day. Ivan, having been summoned to attend the funeral and the trial, questions Smerdyakov about the strange things he said in their last conversation. Smerdyakov admits to killing Fyodor, and framing Dimitri for the crime. More troubling then this, is the fact that Smerdyakov blames Ivan for the whole event. Smerdyakov told Ivan the plan, albeit in a circuitous way, and made it clear that if Ivan leaves for Moscow, Fyodor will get murdered. Ivan did go to Moscow, and therefore Smerdyakov took this as permission to murder Fyodor.

Ivan, upset about this new revelation, and desperate to save Dimitri from being wrongly punished for the murder develops a brain fever and begins having hallucinations.

## Trial

  


# Characters

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## Fyodor Karamazov

## Dimitri and Alyosha

## Grushenka

The problems between Dimitri and Fyodor escalate when they both fall in love with the same woman: Grushenka. The quarrel becomes physical, and Dimitri storms out of the house. Ivan asks to meet Alyosha at a local bar to talk. They talk briefly about Dimitri (which is what Alyosha is concerned about), but then Ivan recites the "poem" that he has written, "The Grand Inquisitor".

## Smerdyakov and Ivan

Ivan is a respected intellectual, but Smerdyakov is revealed to be highly intellegent in his own right. Smerdyakov has a high about of respect for Ivan, although that respect is rarely returned. Smerdyakov is an epileptic, and is prone to occasional, debilitating seizures which can last for long periods of time. He also hints occasionally that he is capable of pretending to have such a seizure, and is very convincing at it.

  


# Rebellion

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## Rebellion

In this chapter, Ivan relates several news stories that he has collected over the years. Each story is about a child that has been abused, or murdered, or otherwise made to suffer. Ivan claims that if god allows these children to suffer, Ivan will not accept any invitation into God's kingdom. After this, Alyosha says "That's rebellion!".

## Part 1

     "I MUST make one confession" Ivan began. "I could never understand how one can love one's neighbours. It's just one's neighbours, to my mind, that one can't love, though one might love those at a distance. I once read somewhere of John the Merciful, a saint, that when a hungry, frozen beggar came to him, he took him into his bed, held him in his arms, and began breathing into his mouth, which was putrid and loathsome from some awful disease. I am convinced that he did that from 'self-laceration,' from the self-laceration of falsity, for the sake of the charity imposed by duty, as a penance laid on him. For anyone to love a man, he must be hidden, for as soon as he shows his face, love is gone."

Ivan here is referring to a passage from the book of Matthew, 22:35:

    _Then one of them, which was a lawyer, asked him a question, tempting him, and saying, Master, which is the great commandment in the law? Jesus said unto him, Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind. This is the first and great commandment. And the second is like unto it, Thou shalt love thy neighbour as thyself. On these two commandments hang all the law and the prophets._

Jesus claimed that "love thy neighbor" was the second most important law of god. It is by claiming to not be able to follow this law (and providing some justification against it) that Ivan starts this discussion.

  


     "Father Zossima has talked of that more than once," observed Alyosha; "he, too, said that the face of a man often hinders many people not practised in love, from loving him. But yet there's a great deal of love in mankind, and almost Christ-like love. I know that myself, Ivan."

Father Zossima is Alyosha's mentor at the monestary, and a well-respected local figure.

  


## Part 2

     "Well, I know nothing of it so far, and can't understand it, and the innumerable mass of mankind are with me there. The question is, whether that's due to men's bad qualities or whether it's inherent in their nature. To my thinking, Christ-like love for men is a miracle impossible on earth. He was God. But we are not gods. Suppose I, for instance, suffer intensely. Another can never know how much I suffer, because he is another and not I. And what's more, a man is rarely ready to admit another's suffering (as though it were a distinction). Why won't he admit it, do you think? Because I smell unpleasant, because I have a stupid face, because I once trod on his foot. Besides, there is suffering and suffering; degrading, humiliating suffering such as humbles me- hunger, for instance- my benefactor will perhaps allow me; but when you come to higher suffering- for an idea, for instance- he will very rarely admit that, perhaps because my face strikes him as not at all what he fancies a man should have who suffers for an idea. And so he deprives me instantly of his favour, and not at all from badness of heart. Beggars, especially genteel beggars, ought never to show themselves, but to ask for charity through the newspapers. One can love one's neighbours in the abstract, or even at a distance, but at close quarters it's almost impossible. If it were as on the stage, in the ballet, where if beggars come in, they wear silken rags and tattered lace and beg for alms dancing gracefully, then one might like looking at them. But even then we should not love them."

When Ivan says "Christ-like love" he is referring to unconditional love towards your neightbors and your enemies. Ivan here is claiming that people in general are incapable of this kind of love by their nature, and are therefore incapable of following the laws of Jesus.

  


"But enough of that. I simply wanted to show you my point of view. I meant to speak of the suffering of mankind generally, but we had better confine ourselves to the sufferings of the children. That reduces the scope of my argument to a tenth of what it would be. Still we'd better keep to the children, though it does weaken my case. But, in the first place, children can be loved even at close quarters, even when they are dirty, even when they are ugly (I fancy, though, children never are ugly). The second reason why I won't speak of grown-up people is that, besides being disgusting and unworthy of love, they have a compensation- they've eaten the apple and know good and evil, and they have become 'like gods.' They go on eating it still. But the children haven't eaten anything, and are so far innocent. "

This is an important point in the narrative. Here, Ivan turns the focus of the conversation squarely onto the issue of children, and not on man-kind in general. He does this for two reasons: he says that restricting his conversation to children will limit his argument, but also because people are compassionate towards children.

  


"Are you fond of children, Alyosha? I know you are, and you will understand why I prefer to speak of them. If they, too, suffer horribly on earth, they must suffer for their fathers' sins, they must be punished for their fathers, who have eaten the apple; but that reasoning is of the other world and is incomprehensible for the heart of man here on earth. The innocent must not suffer for another's sins, and especially such innocents! You may be surprised at me, Alyosha, but I am awfully fond of children, too. And observe, cruel people, the violent, the rapacious, the Karamazovs are sometimes very fond of children. Children while they are quite little- up to seven, for instance- are so remote from grown-up people they are different creatures, as it were, of a different species. I knew a criminal in prison who had, in the course of his career as a burglar, murdered whole families, including several children. But when he was in prison, he had a strange affection for them. He spent all his time at his window, watching the children playing in the prison yard. He trained one little boy to come up to his window and made great friends with him.... You don't know why I am telling you all this, Alyosha? My head aches and I am sad."

"the apple" here refers to the fruit from the tree of knowledge of good and evil, from the garden of eden. When Adam and Eve ate the fruit (which later came to be identified with an apple) they committed what is now known as "original sin". Saint Augustine first wrote about the concept of original sin, a fallen state of humanity that is inherited by children from their parents.

Ivan starts by saying that it is "incomprehensible" that children should be made to suffer because of their original sin. If an innocent person should not suffer for the sins of another person, then children should not suffer for the sins of their ancestors.

Ivan goes on to talk about how even the most cruel and evil people still love children. He justifies this by saying that children are so small in stature that they are essentially different creatures from regular adult humans. When Ivan is talking about the affection or love that adults generally feel towards children, he is talking about a patronly love, not a sexual or romantic kind.

  


## Part 2

     "You speak with a strange air," observed Alyosha uneasily, "as though you were not quite yourself."

     "By the way, a Bulgarian I met lately in Moscow," Ivan went on, seeming not to hear his brother's words, "told me about the crimes committed by Turks and Circassians in all parts of Bulgaria through fear of a general rising of the Slavs. They burn villages, murder, outrage women and children, they nail their prisoners by the ears to the fences, leave them so till morning, and in the morning they hang them- all sorts of things you can't imagine. People talk sometimes of bestial cruelty, but that's a great injustice and insult to the beasts; a beast can never be so cruel as a man, so artistically cruel. The tiger only tears and gnaws, that's all he can do. He would never think of nailing people by the ears, even if he were able to do it. These Turks took a pleasure in torturing children, -too; cutting the unborn child from the mothers womb, and tossing babies up in the air and catching them on the points of their bayonets before their mothers' eyes. Doing it before the mothers' eyes was what gave zest to the amusement. Here is another scene that I thought very interesting. Imagine a trembling mother with her baby in her arms, a circle of invading Turks around her. They've planned a diversion: they pet the baby, laugh to make it laugh. They succeed, the baby laughs. At that moment a Turk points a pistol four inches from the baby's face. The baby laughs with glee, holds out its little hands to the pistol, and he pulls the trigger in the baby's face and blows out its brains. Artistic, wasn't it? By the way, Turks are particularly fond of sweet things, they say."

Here Ivan mentions, almost without explanation stories he has heard of cruelties commited by the Turks against the Bulgarians. He uses these stories to illustrate the fact that men can be much more cruel then any animal can be, thus elliminating a possible model for the devil. If the devil was an invention, he must have been based off other men, and not off some cruel animal.

  


## Part 3

     "Brother, what are you driving at?" asked Alyosha.

     "I think if the devil doesn't exist, but man has created him, he has created him in his own image and likeness."

     "Just as he did God, then?" observed Alyosha.

     "'It's wonderful how you can turn words,' as Polonius says in Hamlet," laughed Ivan. "You turn my words against me. Well, I am glad. Yours must be a fine God, if man created Him in his image and likeness. You asked just now what I was driving at. You see, I am fond of collecting certain facts, and, would you believe, I even copy anecdotes of a certain sort from newspapers and books, and I've already got a fine collection."

Driving to the heart of the matter, Ivan says that man has created the Devil "in his own image and likeness." Alyosha immediately likens this to the theory that man has created God in a similar fashion.

It's at this point that Ivan first mentions his "collection" of stories. These stories, as we shall see, have a particular focus that has Ivan very troubled.

  


"The Turks, of course, have gone into it, but they are foreigners. I have specimens from home that are even better than the Turks. You know we prefer beating-rods and scourges- that's our national institution. Nailing ears is unthinkable for us, for we are, after all, Europeans. But the rod and the scourge we have always with us and they cannot be taken from us. Abroad now they scarcely do any beating. Manners are more humane, or laws have been passed, so that they don't dare to flog men now. But they make up for it in another way just as national as ours. And so national that it would be practically impossible among us, though I believe we are being inoculated with it, since the religious movement began in our aristocracy."

This passage is a little bit obscure, and it is difficult to understand all of Ivan's context-sensitive references. However, the point of this passage is quite clear: every society has manners of harming other people. Also, the ways that one society hurt people may seem to be barbaric to other societies, but all the methods are essentially equivalent.

  


"I have a charming pamphlet, translated from the French, describing how, quite recently, five years ago, a murderer, Richard, was executed- a young man, I believe, of three and twenty, who repented and was converted to the Christian faith at the very scaffold. This Richard was an illegitimate child who was given as a child of six by his parents to some shepherds on the Swiss mountains. They brought him up to work for them. He grew up like a little wild beast among them. The shepherds taught him nothing, and scarcely fed or clothed him, but sent him out at seven to herd the flock in cold and wet, and no one hesitated or scrupled to treat him so. Quite the contrary, they thought they had every right, for Richard had been given to them as a chattel, and they did not even see the necessity of feeding him. Richard himself describes how in those years, like the Prodigal Son in the Gospel, he longed to eat of the mash given to the pigs, which were fattened for sale. But they wouldn't even give that, and beat him when he stole from the pigs. And that was how he spent all his childhood and his youth, till he grew up and was strong enough to go away and be a thief. The savage began to earn his living as a day labourer in Geneva. He drank what he earned, he lived like a brute, and finished by killing and robbing an old man. He was caught, tried, and condemned to death. They are not sentimentalists there. And in prison he was immediately surrounded by pastors, members of Christian brotherhoods, philanthropic ladies, and the like. They taught him to read and write in prison, and expounded the Gospel to him. They exhorted him, worked upon him, drummed at him incessantly, till at last he solemnly confessed his crime. He was converted. He wrote to the court himself that he was a monster, but that in the end God had vouchsafed him light and shown grace. All Geneva was in excitement about him- all philanthropic and religious Geneva. All the aristocratic and well-bred society of the town rushed to the prison, kissed Richard and embraced him; 'You are our brother, you have found grace.' And Richard does nothing but weep with emotion, 'Yes, I've found grace! All my youth and childhood I was glad of pigs' food, but now even I have found grace. I am dying in the Lord.' 'Yes, Richard, die in the Lord; you have shed blood and must die. Though it's not your fault that you knew not the Lord, when you coveted the pigs' food and were beaten for stealing it (which was very wrong of you, for stealing is forbidden); but you've shed blood and you must die.'And on the last day, Richard, perfectly limp, did nothing but cry and repeat every minute: 'This is my happiest day. I am going to the Lord.' 'Yes,' cry the pastors and the judges and philanthropic ladies. 'This is the happiest day of your life, for you are going to the Lord!' They all walk or drive to the scaffold in procession behind the prison van. At the scaffold they call to Richard: 'Die, brother, die in the Lord, for even thou hast found grace!' And so, covered with his brothers' kisses, Richard is dragged on to the scaffold, and led to the guillotine. And they chopped off his head in brotherly fashion, because he had found grace. Yes, that's characteristic. That pamphlet is translated into Russian by some Russian philanthropists of aristocratic rank and evangelical aspirations, and has been distributed gratis for the enlightenment of the people. The case of Richard is interesting because it's national. Though to us it's absurd to cut off a man's head, because he has become our brother and has found grace, yet we have our own speciality, which is all but worse."

Here Ivan recounts the story of a man named Richard, who was raised as an animal, and grew up to become a thief and a murderer. In prison, awaiting death, Richard is converted into a christian and educated in reading and writing. On the day of his execution, Richard is actually celebrating his own death as a holy act.

  


"Our historical pastime is the direct satisfaction of inflicting pain. There are lines in Nekrassov describing how a peasant lashes a horse on the eyes, 'on its meek eyes,' everyone must have seen it. It's peculiarly Russian. He describes how a feeble little nag has foundered under too heavy a load and cannot move. The peasant beats it, beats it savagely, beats it at last not knowing what he is doing in the intoxication of cruelty, thrashes it mercilessly over and over again. 'However weak you are, you must pull, if you die for it.' The nag strains, and then he begins lashing the poor defenceless creature on its weeping, on its 'meek eyes.' The frantic beast tugs and draws the load, trembling all over, gasping for breath, moving sideways, with a sort of unnatural spasmodic action- it's awful in Nekrassov. But that only a horse, and God has horses to be beaten. So the Tatars have taught us, and they left us the knout as a remembrance of it."

Here, Ivan discusses the story of a master and a horse. The horse is tired from pulling "too heavy a load", and stops pulling. The master, in a rage, lashes the horse and beats it repeatedly and for some time. Finally, having no untouched skin left to beat, the master lashes the horse on it's eyes. This finally motivated the horse to pull the load.

Ivan uses this story as an example that people experience satisfaction from inflicting pain, thus reinforcing his thesis that the Devil was created in the image of evil men.

  


"But men, too, can be beaten. A well-educated, cultured gentleman and his wife beat their own child with a birch-rod, a girl of seven. I have an exact account of it. The papa was glad that the birch was covered with twigs. 'It stings more,' said he, and so be began stinging his daughter. I know for a fact there are people who at every blow are worked up to sensuality, to literal sensuality, which increases progressively at every blow they inflict. They beat for a minute, for five minutes, for ten minutes, more often and more savagely. The child screams. At last the child cannot scream, it gasps, 'Daddy daddy!' By some diabolical unseemly chance the case was brought into court. A counsel is engaged. The Russian people have long called a barrister 'a conscience for hire.' The counsel protests in his client's defence. 'It's such a simple thing,' he says, 'an everyday domestic event. A father corrects his child. To our shame be it said, it is brought into court.' The jury, convinced by him, give a favourable verdict. The public roars with delight that the torturer is acquitted. Ah, pity I wasn't there! I would have proposed to raise a subscription in his honour! Charming pictures."

In the same vein of the previous story, Ivan recounts now the story of a man and his wife beat their seven-year-old daughter with a birch rod. The beating lasted for more then 10 minutes, and grew harder and more savage as time went on.

When brought to court, instead of being punished for abusing their daughter, the couple is praised for properly correcting their child. As we shall see later, Ivan has a special place in his heart for abused children, and the stories he relates later focus more on them.  
  


# Rebellion (Part 2)

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## Part 4

     "But I've still better things about children. I've collected a great, great deal about Russian children, Alyosha. There was a little girl of five who was hated by her father and mother, 'most worthy and respectable people, of good education and breeding.' You see, I must repeat again, it is a peculiar characteristic of many people, this love of torturing children, and children only. To all other types of humanity these torturers behave mildly and benevolently, like cultivated and humane Europeans; but they are very fond of tormenting children, even fond of children themselves in that sense. it's just their defencelessness that tempts the tormentor, just the angelic confidence of the child who has no refuge and no appeal, that sets his vile blood on fire. In every man, of course, a demon lies hidden- the demon of rage, the demon of lustful heat at the screams of the tortured victim, the demon of lawlessness let off the chain, the demon of diseases that follow on vice, gout, kidney disease, and so on."

Ivan's collection is a set of stories, accounts, and anecdotes of evilness. Predominantly, his collection focuses on the stories of tortured and abused children. Throughout this discussion Ivan never cites or refers to any of his sources, although he does employ a few quotes in his monologue that the reader can assume came from one of these stories. His knowledge of quotes from these stories is indicative perhaps that he has spent some time studying these stories.

Ivan mentions here that the people who are the most evil towards children are often viewed as being perfectly respectable to other adults. These people appear to just be normal, although they have a certain penchant for torturing children. Notice that these people stand in stark contrast to the people that Ivan discussed earlier, the prisoners and criminals who showed love to children. The way people act towards children is often far different from the way people act towards other adults. Often, as Ivan will discuss below, it is easier for people to be cruel towards children than it is to be cruel to other adults.

  


     "This poor child of five was subjected to every possible torture by those cultivated parents. They beat her, thrashed her, kicked her for no reason till her body was one bruise. Then, they went to greater refinements of cruelty- shut her up all night in the cold and frost in a privy, and because she didn't ask to be taken up at night (as though a child of five sleeping its angelic, sound sleep could be trained to wake and ask), they smeared her face and filled her mouth with excrement, and it was her mother, her mother did this. And that mother could sleep, hearing the poor child's groans! Can you understand why a little creature, who can't even understand what's done to her, should beat her little aching heart with her tiny fist in the dark and the cold, and weep her meek unresentful tears to dear, kind God to protect her? Do you understand that, friend and brother, you pious and humble novice? Do you understand why this infamy must be and is permitted? Without it, I am told, man could not have existed on earth, for he could not have known good and evil. Why should he know that diabolical good and evil when it costs so much? Why, the whole world of knowledge is not worth that child's prayer to dear, kind God'! I say nothing of the sufferings of grown-up people, they have eaten the apple, damn them, and the devil take them all! But these little ones! I am making you suffer, Alyosha, you are not yourself. I'll leave off if you like."

Ivan discusses the story of a young girl who is tortured and abused by her parents. The abuse started out as physical abuses: beating, thrashing, and kicking. However, the abuse generally graduated to "more refined" abuse. Ivan says this line, which he will reference several times again:

    _Can you understand why a little creature, who can't even understand what's done to her, should beat her little aching heart with her tiny fist in the dark and the cold, and weep her meek unresentful tears to dear, kind God to protect her?_

The child does not even understand the abuse, and may not even realize that this treatment is not normal treatment. Ivan even refers to her tears as being "unresentful", indicating that the child does not even fault her abusers. Ivan also makes another statement that is going to serve as the basis for much of his future discussions:

    _Do you understand why this infamy must be and is permitted? Without it, I am told, man could not have existed on earth, for he could not have known good and evil._

Without knowledge of good and evil, man would not have been on earth as we know it, but instead would be living in the paradise of Eden for all eternity. With the knowledge of good and evil, however, evils such as the abuse of young children are not only possible but actually inevitable.

  


## Part 5

     "Nevermind. I want to suffer too," muttered Alyosha.

     "One picture, only one more, because it's so curious, so characteristic, and I have only just read it in some collection of Russian antiquities. I've forgotten the name. I must look it up. It was in the darkest days of serfdom at the beginning of the century, and long live the Liberator of the People! There was in those days a general of aristocratic connections, the owner of great estates, one of those men- somewhat exceptional, I believe, even then- who, retiring from the service into a life of leisure, are convinced that they've earned absolute power over the lives of their subjects. There were such men then. So our general, settled on his property of two thousand souls, lives in pomp, and domineers over his poor neighbours as though they were dependents and buffoons. He has kennels of hundreds of hounds and nearly a hundred dog-boys- all mounted, and in uniform. One day a serf-boy, a little child of eight, threw a stone in play and hurt the paw of the general's favourite hound. 'Why is my favourite dog lame?' He is told that the boy threw a stone that hurt the dog's paw. 'So you did it.' The general looked the child up and down. 'Take him.' He was taken- taken from his mother and kept shut up all night. Early that morning the general comes out on horseback, with the hounds, his dependents, dog-boys, and huntsmen, all mounted around him in full hunting parade. The servants are summoned for their edification, and in front of them all stands the mother of the child. The child is brought from the lock-up. It's a gloomy, cold, foggy, autumn day, a capital day for hunting. The general orders the child to be undressed; the child is stripped naked. He shivers, numb with terror, not daring to cry.... 'Make him run,' commands the general. 'Run! run!' shout the dog-boys. The boy runs.... 'At him!' yells the general, and he sets the whole pack of hounds on the child. The hounds catch him, and tear him to pieces before his mother's eyes!... I believe the general was afterwards declared incapable of administering his estates. Well- what did he deserve? To be shot? To be shot for the satisfaction of our moral feelings? Speak, Alyosha!

     "To be shot," murmured Alyosha, lifting his eyes to Ivan with a pale, twisted smile.

Alyosha is the perfect literary counter-point to Ivan. While Ivan is educated and atheistic, Alyosha is compassionate and religious. When Ivan offers to stop telling these stories about children, Alyosha responds "Nevermind. I want to suffer too". To caring and compassionate Alyosha, even hearing stories about tortured children is tantamount to suffering.

This story is about a military man and an owner of some land who retires from the service. He is convinced of his own power over his own subjects, and hunts with his team of dogs. One day, a child throws a stone and injures the paw of one of the man's hunting dogs. In response, the man strips the child naked, and let's his dogs tear the child apart in front of his mother.

Ivan asks, almost rhetorically, "What did he deserve?" To which Alyosha replied "To be shot." Even though Alyosha blurts this out without thinking, it is uncharacteristic of someone who is supposed to embody christ-like love.

  


## Part 6

     "Bravo!" cried Ivan delighted. "If even you say so... You're a pretty monk! So there is a little devil sitting in your heart, Alyosha Karamazov!"

     "What I said was absurd, but-"

     "That's just the point, that 'but'!" cried Ivan. "Let me tell you, novice, that the absurd is only too necessary on earth. The world stands on absurdities, and perhaps nothing would have come to pass in it without them. We know what we know!"

     "What do you know?"

     "I understand nothing," Ivan went on, as though in delirium. "I don't want to understand anything now. I want to stick to the fact. I made up my mind long ago not to understand. If I try to understand anything, I shall be false to the fact, and I have determined to stick to the fact."

     "Why are you trying me?" Alyosha cried, with sudden distress. "Will you say what you mean at last?"

     "Of course, I will; that's what I've been leading up to. You are dear to me, I don't want to let you go, and I won't give you up to your Zossima."

Ivan is happy about Alyosha's statement, because it does serve as some justification to his arguments. Even with an argument restricted to children, he has gotten Alyosha to abandon Jesus's second commandment.

Ivan's statement "I understand nothing" is very reminiscent of Socrates, and helps to serve as an example both of Ivan's learning, and of his arrogance.

When Ivan says "I won't give you up to your Zossima", he is saying that he wants to prevent Alyosha from becoming a full monk at the monestary.  


## Part 7

     Ivan for a minute was silent, his face became all at once very sad.

     "Listen! I took the case of children only to make my case clearer. Of the other tears of humanity with which the earth is soaked from its crust to its centre, I will say nothing. I have narrowed my subject on purpose. I am a bug, and I recognise in all humility that I cannot understand why the world is arranged as it is. Men are themselves to blame, I suppose; they were given paradise, they wanted freedom, and stole fire from heaven, though they knew they would become unhappy, so there is no need to pity them. With my pitiful, earthly, Euclidian understanding, all I know is that there is suffering and that there are none guilty; that cause follows effect, simply and directly; that everything flows and finds its level- but that's only Euclidian nonsense, I know that, and I can't consent to live by it! What comfort is it to me that there are none guilty and that cause follows effect simply and directly, and that I know it?- I must have justice, or I will destroy myself. And not justice in some remote infinite time and space, but here on earth, and that I could see myself. I have believed in it. I want to see it, and if I am dead by then, let me rise again, for if it all happens without me, it will be too unfair. Surely I haven't suffered simply that I, my crimes and my sufferings, may manure the soil of the future harmony for somebody else. I want to see with my own eyes the hind lie down with the lion and the victim rise up and embrace his murderer. I want to be there when everyone suddenly understands what it has all been for. All the religions of the world are built on this longing, and I am a believer."

  


"But then there are the children, and what am I to do about them? That's a question I can't answer. For the hundredth time I repeat, there are numbers of questions, but I've only taken the children, because in their case what I mean is so unanswerably clear. Listen! If all must suffer to pay for the eternal harmony, what have children to do with it, tell me, please? It's beyond all comprehension why they should suffer, and why they should pay for the harmony. Why should they, too, furnish material to enrich the soil for the harmony of the future? I understand solidarity in sin among men. I understand solidarity in retribution, too; but there can be no such solidarity with children. And if it is really true that they must share responsibility for all their fathers' crimes, such a truth is not of this world and is beyond my comprehension. Some jester will say, perhaps, that the child would have grown up and have sinned, but you see he didn't grow up, he was torn to pieces by the dogs, at eight years old. Oh, Alyosha, I am not blaspheming! I understand, of course, what an upheaval of the universe it will be when everything in heaven and earth blends in one hymn of praise and everything that lives and has lived cries aloud: 'Thou art just, O Lord, for Thy ways are revealed.'"

  


"When the mother embraces the fiend who threw her child to the dogs, and all three cry aloud with tears, 'Thou art just, O Lord!' then, of course, the crown of knowledge will be reached and all will be made clear. But what pulls me up here is that I can't accept that harmony. And while I am on earth, I make haste to take my own measures. You see, Alyosha, perhaps it really may happen that if I live to that moment, or rise again to see it, I, too, perhaps, may cry aloud with the rest, looking at the mother embracing the child's torturer, 'Thou art just, O Lord!' but I don't want to cry aloud then. While there is still time, I hasten to protect myself, and so I renounce the higher harmony altogether. It's not worth the tears of that one tortured child who beat itself on the breast with its little fist and prayed in its stinking outhouse, with its unexpiated tears to 'dear, kind God'! It's not worth it, because those tears are unatoned for. They must be atoned for, or there can be no harmony. But how? How are you going to atone for them? Is it possible? By their being avenged? But what do I care for avenging them? What do I care for a hell for oppressors? What good can hell do, since those children have already been tortured? And what becomes of harmony, if there is hell?"

  


"I want to forgive. I want to embrace. I don't want more suffering. And if the sufferings of children go to swell the sum of sufferings which was necessary to pay for truth, then I protest that the truth is not worth such a price. I don't want the mother to embrace the oppressor who threw her son to the dogs! She dare not forgive him! Let her forgive him for herself, if she will, let her forgive the torturer for the immeasurable suffering of her mother's heart. But the sufferings of her tortured child she has no right to forgive; she dare not forgive the torturer, even if the child were to forgive him! And if that is so, if they dare not forgive, what becomes of harmony? Is there in the whole world a being who would have the right to forgive and could forgive? I don't want harmony. From love for humanity I don't want it. I would rather be left with the unavenged suffering. I would rather remain with my unavenged suffering and unsatisfied indignation, even if I were wrong. Besides, too high a price is asked for harmony; it's beyond our means to pay so much to enter on it. And so I hasten to give back my entrance ticket, and if I am an honest man I am bound to give it back as soon as possible. And that I am doing. It's not God that I don't accept, Alyosha, only I most respectfully return him the ticket." 

     "That's rebellion," murmered Alyosha, looking down.

  


## Part 8

     "Rebellion? I am sorry you call it that," said Ivan earnestly. "One can hardly live in rebellion, and I want to live. Tell me yourself, I challenge your answer. Imagine that you are creating a fabric of human destiny with the object of making men happy in the end, giving them peace and rest at last, but that it was essential and inevitable to torture to death only one tiny creature- that baby beating its breast with its fist, for instance- and to found that edifice on its unavenged tears, would you consent to be the architect on those conditions? Tell me, and tell the truth."

     "No, I wouldn't consent," said Alyosha softly.

     "And can you admit the idea that men for whom you are building it would agree to accept their happiness on the foundation of the unexpiated blood of a little victim? And accepting it would remain happy for ever?"

     "No, I can't admit it. Brother," said Alyosha suddenly, with flashing eyes, "you said just now, is there a being in the whole world who would have the right to forgive and could forgive? But there is a Being and He can forgive everything, all and for all, because He gave His innocent blood for all and everything. You have forgotten Him, and on Him is built the edifice, and it is to Him they cry aloud, 'Thou art just, O Lord, for Thy ways are revealed!'

     "Ah! the One without sin and His blood! No, I have not forgotten Him; on the contrary I've been wondering all the time how it was you did not bring Him in before, for usually all arguments on your side put Him in the foreground. Do you know, Alyosha- don't laugh I made a poem about a year ago. If you can waste another ten minutes on me, I'll tell it to you."

     "You wrote a poem?"

     "Oh, no, I didn't write it," laughed Ivan, and I've never written two lines of poetry in my life. But I made up this poem in prose and I remembered it. I was carried away when I made it up. You will be my first reader- that is listener. Why should an author forego even one listener?" smiled Ivan. "Shall I tell it to you?"

     "I am all attention." said Alyosha.

     "My poem is called The Grand Inquisitor; it's a ridiculous thing, but I want to tell it to you.

  
  


# The Grand Inquisitor

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## The Grand Inquisitor

_The Grand Inquisitor_ is Ivan's "poem", which he recites after **Rebellion**. In part, the discussion from _Rebellion_ is Ivan's way of judging whether Alyosha is ready to hear the poem. Ivan determines that Alyosha is ready to hear it, and so tells the story, with occasional questions from Alyosha to break the narrative. It is important to note that while Ivan refers to it as a "poem", that the tale itself is prose.

In the story, Jesus (referred to by Ivan only as "He", or "Him", with a capital H) returns to earth during the Spanish Inquisition. He brings a dead girl back to life, and performs other miracles among the wounded, sick, and dying people in town. The Grand Inquisitor, riding through town with his procession, sees Him, and has Him arrested. The remainder of the story involves the "conversation" that the Grand Inquisitor has with Jesus. The word "conversation" in the previous sentence is a bit of a misnomer, because throughout the rest of the story, The Grand Inquisitor speaks to Him, and He listens silently.

He never speaks, but his silence is applauded by the Inquisitor, who says "Thou hast no right to add anything to what Thou hadst said of old." Aloysha asks whether He is completely silent throughout the conversation, to which Ivan replies:

    _"That's inevitable in any case, the old man has told Him He hasn't the right to add anything to what He has said of old. One may say it is the most fundamental feature of Roman Catholicism, in my opinion at least. 'All has been given by The to the Pope,' they say, 'and all, therefore, is still in the Pope's hands, and there is no need for Thee to come now at all."_

Another point that the Inquisitor makes frequently is that He has given humanity a certain amount of freedom, and that any additional messages from Him would encroach upon that freedom. Also, continues the Inquisitor, that freedom that was given to humanity by Jesus' original message was actually a penalty, and that the church has needed to remove those freedoms from the people.

## Part 1

     "EVEN this must have a preface- that is, a literary preface," laughed Ivan, "and I am a poor hand at making one. You see, my action takes place in the sixteenth century, and at that time, as you probably learnt at school, it was customary in poetry to bring down heavenly powers on earth. Not to speak of Dante, in France, clerks, as well as the monks in the monasteries, used to give regular performances in which the Madonna, the saints, the angels, Christ, and God Himself were brought on the stage. In those days it was done in all simplicity. In Victor Hugo's Notre Dame de Paris an edifying and gratuitous spectacle was provided for the people in the Hotel de Ville of Paris in the reign of Louis XI in honour of the birth of the dauphin. It was called Le bon jugement de la tres sainte et gracieuse Vierge Marie, and she appears herself on the stage and pronounces her bon jugement. Similar plays, chiefly from the Old Testament, were occasionally performed in Moscow too, up to the times of Peter the Great. But besides plays there were all sorts of legends and ballads scattered about the world, in which the saints and angels and all the powers of Heaven took part when required. In our monasteries the monks busied themselves in translating, copying, and even composing such poems- and even under the Tatars. There is, for instance, one such poem (of course, from the Greek), The Wanderings of Our Lady through Hell, with descriptions as bold as Dante's. Our Lady visits hell, and the Archangel Michael leads her through the torments. She sees the sinners and their punishment. There she sees among others one noteworthy set of sinners in a burning lake; some of them sink to the bottom of the lake so that they can't swim out, and 'these God forgets'- an expression of extraordinary depth and force. And so Our Lady, shocked and weeping, falls before the throne of God and begs for mercy for all in hell- for all she has seen there, indiscriminately. Her conversation with God is immensely interesting. She beseeches Him, she will not desist, and when God points to the hands and feet of her Son, nailed to the Cross, and asks, 'How can I forgive His tormentors?' she bids all the saints, all the martyrs, all the angels and archangels to fall down with her and pray for mercy on all without distinction. It ends by her winning from God a respite of suffering every year from Good Friday till Trinity Day, and the sinners at once raise a cry of thankfulness from hell, chanting, 'Thou art just, O Lord, in this judgment.' Well, my poem would have been of that kind if it had appeared at that time. He comes on the scene in my poem, but He says nothing, only appears and passes on. Fifteen centuries have passed since He promised to come in His glory, fifteen centuries since His prophet wrote, 'Behold, I come quickly'; 'Of that day and that hour knoweth no man, neither the Son, but the Father,' as He Himself predicted on earth. But humanity awaits him with the same faith and with the same love. Oh, with greater faith, for it is fifteen centuries since man has ceased to see signs from heaven.

      No signs from heaven come to-day

      To add to what the heart doth say.

     There was nothing left but faith in what the heart doth say. It is true there were many miracles in those days. There were saints who performed miraculous cures; some holy people, according to their biographies, were visited by the Queen of Heaven herself. But the devil did not slumber, and doubts were already arising among men of the truth of these miracles. And just then there appeared in the north of Germany a terrible new heresy. 'A huge star like to a torch' (that is, to a church) 'fell on the sources of the waters and they became bitter.' These heretics began blasphemously denying miracles. But those who remained faithful were all the more ardent in their faith. The tears of humanity rose up to Him as before, awaited His coming, loved Him, hoped for Him, yearned to suffer and die for Him as before. And so many ages mankind had prayed with faith and fervour, 'O Lord our God, hasten Thy coming'; so many ages called upon Him, that in His infinite mercy He deigned to come down to His servants. Before that day He had come down, He had visited some holy men, martyrs, and hermits, as is written in their lives. Among us, Tyutchev, with absolute faith in the truth of his words, bore witness that

      Bearing the Cross, in slavish dress,

      Weary and worn, the Heavenly King

      Our mother, Russia, came to bless,

      And through our land went wandering. And that certainly was so, I assure you.

  


## Part 2

     "And behold, He deigned to appear for a moment to the people, to the tortured, suffering people, sunk in iniquity, but loving Him like children. My story is laid in Spain, in Seville, in the most terrible time of the Inquisition, when fires were lighted every day to the glory of God, and 'in the splendid auto da fe the wicked heretics were burnt.' Oh, of course, this was not the coming in which He will appear, according to His promise, at the end of time in all His heavenly glory, and which will be sudden 'as lightning flashing from east to west.' No, He visited His children only for a moment, and there where the flames were crackling round the heretics. In His infinite mercy He came once more among men in that human shape in which He walked among men for thirty-three years fifteen centuries ago. He came down to the 'hot pavements' of the southern town in which on the day before almost a hundred heretics had, ad majorem gloriam Dei, been burnt by the cardinal, the Grand Inquisitor, in a magnificent auto da fe, in the presence of the king, the court, the knights, the cardinals, the most charming ladies of the court, and the whole population of Seville.

      "He came softly, unobserved, and yet, strange to say, everyone recognised Him. That might be one of the best passages in the poem. I mean, why they recognised Him. The people are irresistibly drawn to Him, they surround Him, they flock about Him, follow Him. He moves silently in their midst with a gentle smile of infinite compassion. The sun of love burns in His heart, and power shine from His eyes, and their radiance, shed on the people, stirs their hearts with responsive love. He holds out His hands to them, blesses them, and a healing virtue comes from contact with Him, even with His garments. An old man in the crowd, blind from childhood, cries out, 'O Lord, heal me and I shall see Thee!' and, as it were, scales fall from his eyes and the blind man sees Him. The crowd weeps and kisses the earth under His feet. Children throw flowers before Him, sing, and cry hosannah. 'It is He- it is He!' repeat. 'It must be He, it can be no one but Him!' He stops at the steps of the Seville cathedral at the moment when the weeping mourners are bringing in a little open white coffin. In it lies a child of seven, the only daughter of a prominent citizen. The dead child lies hidden in flowers. 'He will raise your child,' the crowd shouts to the weeping mother. The priest, coming to meet the coffin, looks perplexed, and frowns, but the mother of the dead child throws herself at His feet with a wail. 'If it is Thou, raise my child!' she cries, holding out her hands to Him. The procession halts, the coffin is laid on the steps at His feet. He looks with compassion, and His lips once more softly pronounce, 'Maiden, arise!' and the maiden arises. The little girl sits up in the coffin and looks round, smiling with wide-open wondering eyes, holding a bunch of white roses they had put in her hand.

  


## Part 3

     "There are cries, sobs, confusion among the people, and at that moment the cardinal himself, the Grand Inquisitor, passes by the cathedral. He is an old man, almost ninety, tall and erect, with a withered face and sunken eyes, in which there is still a gleam of light. He is not dressed in his gorgeous cardinal's robes, as he was the day before, when he was burning the enemies of the Roman Church- at this moment he is wearing his coarse, old, monk's cassock. At a distance behind him come his gloomy assistants and slaves and the 'holy guard.' He stops at the sight of the crowd and watches it from a distance. He sees everything; he sees them set the coffin down at His feet, sees the child rise up, and his face darkens. He knits his thick grey brows and his eyes gleam with a sinister fire. He holds out his finger and bids the guards take Him. And such is his power, so completely are the people cowed into submission and trembling obedience to him, that the crowd immediately makes way for the guards, and in the midst of deathlike silence they lay hands on Him and lead him away. The crowd instantly bows down to the earth, like one man, before the old Inquisitor. He blesses the people in silence and passes on' The guards lead their prisoner to the close, gloomy vaulted prison- in the ancient palace of the Holy, inquisition and shut him in it. The day passes and is followed by the dark, burning, 'breathless' night of Seville. The air is 'fragrant with laurel and lemon.' In the pitch darkness the iron door of the prison is suddenly opened and the Grand Inquisitor himself comes in with a light in his hand. He is alone; the door is closed at once behind him. He stands in the doorway and for a minute or two gazes into His face. At last he goes up slowly, sets the light on the table and speaks.

     "'Is it Thou? Thou?' but receiving no answer, he adds at once. 'Don't answer, be silent. What canst Thou say, indeed? I know too well what Thou wouldst say. And Thou hast no right to add anything to what Thou hadst said of old. Why, then, art Thou come to hinder us? For Thou hast come to hinder us, and Thou knowest that. But dost thou know what will be to-morrow? I know not who Thou art and care not to know whether it is Thou or only a semblance of Him, but to-morrow I shall condemn Thee and burn Thee at the stake as the worst of heretics. And the very people who have to-day kissed Thy feet, to-morrow at the faintest sign from me will rush to heap up the embers of Thy fire. Knowest Thou that? Yes, maybe Thou knowest it,' he added with thoughtful penetration, never for a moment taking his eyes off the Prisoner."

  


## Part 4

     "I don't quite understand, Ivan. What does it mean?" Alyosha, who had been listening in silence, said with a smile. "Is it simply a wild fantasy, or a mistake on the part of the old man- some impossible quid pro quo?"

     "Take it as the last," said Ivan, laughing, "if you are so corrupted by modern realism and can't stand anything fantastic. If you like it to be a case of mistaken identity, let it be so. It is true," he went on, laughing, "the old man was ninety, and he might well be crazy over his set idea. He might have been struck by the appearance of the Prisoner. It might, in fact, be simply his ravings, the delusion of an old man of ninety, over-excited by the auto da fe of a hundred heretics the day before. But does it matter to us after all whether it was a mistake of identity or a wild fantasy? All that matters is that the old man should speak out, that he should speak openly of what he has thought in silence for ninety years."

     "And the Prisoner too is silent? Does He look at him and not say a word?"

     "That's inevitable in any case," Ivan laughed again. "The old man has told Him He hasn't the right to add anything to what He has said of old. One may say it is the most fundamental feature of Roman Catholicism, in my opinion at least. 'All has been given by Thee to the Pope,' they say, 'and all, therefore, is still in the Pope's hands, and there is no need for Thee to come now at all. Thou must not meddle for the time, at least.' That's how they speak and write too- the Jesuits, at any rate. I have read it myself in the works of their theologians. 'Hast Thou the right to reveal to us one of the mysteries of that world from which Thou hast come?' my old man asks Him, and answers the question for Him. 'No, Thou hast not; that Thou mayest not add to what has been said of old, and mayest not take from men the freedom which Thou didst exalt when Thou wast on earth. Whatsoever Thou revealest anew will encroach on men's freedom of faith; for it will be manifest as a miracle, and the freedom of their faith was dearer to Thee than anything in those days fifteen hundred years ago. Didst Thou not often say then, "I will make you free"? But now Thou hast seen these "free" men,' the old man adds suddenly, with a pensive smile. 'Yes, we've paid dearly for it,' he goes on, looking sternly at Him, 'but at last we have completed that work in Thy name. For fifteen centuries we have been wrestling with Thy freedom, but now it is ended and over for good. Dost Thou not believe that it's over for good? Thou lookest meekly at me and deignest not even to be wroth with me. But let me tell Thee that now, to-day, people are more persuaded than ever that they have perfect freedom, yet they have brought their freedom to us and laid it humbly at our feet. But that has been our doing. Was this what Thou didst? Was this Thy freedom?'"

  


## Part 5

     "I don't understand again." Alyosha broke in. "Is he ironical, is he jesting?"

     "Not a bit of it! He claims it as a merit for himself and his Church that at last they have vanquished freedom and have done so to make men happy. 'For now' (he is speaking of the Inquisition, of course) 'for the first time it has become possible to think of the happiness of men. Man was created a rebel; and how can rebels be happy? Thou wast warned,' he says to Him. 'Thou hast had no lack of admonitions and warnings, but Thou didst not listen to those warnings; Thou didst reject the only way by which men might be made happy. But, fortunately, departing Thou didst hand on the work to us. Thou hast promised, Thou hast established by Thy word, Thou hast given to us the right to bind and to unbind, and now, of course, Thou canst not think of taking it away. Why, then, hast Thou come to hinder us?'"

     "And what's the meaning of 'no lack of admonitions and warnings'?" asked Alyosha.

     "Why, that's the chief part of what the old man must say.

  


     "'The wise and dread spirit, the spirit of self-destruction and non-existence,' the old man goes on, great spirit talked with Thee in the wilderness, and we are told in the books that he "tempted" Thee. Is that so? And could anything truer be said than what he revealed to Thee in three questions and what Thou didst reject, and what in the books is called "the temptation"? And yet if there has ever been on earth a real stupendous miracle, it took place on that day, on the day of the three temptations. The statement of those three questions was itself the miracle. If it were possible to imagine simply for the sake of argument that those three questions of the dread spirit had perished utterly from the books, and that we had to restore them and to invent them anew, and to do so had gathered together all the wise men of the earth- rulers, chief priests, learned men, philosophers, poets- and had set them the task to invent three questions, such as would not only fit the occasion, but express in three words, three human phrases, the whole future history of the world and of humanity- dost Thou believe that all the wisdom of the earth united could have invented anything in depth and force equal to the three questions which were actually put to Thee then by the wise and mighty spirit in the wilderness? From those questions alone, from the miracle of their statement, we can see that we have here to do not with the fleeting human intelligence, but with the absolute and eternal. For in those three questions the whole subsequent history of mankind is, as it were, brought together into one whole, and foretold, and in them are united all the unsolved historical contradictions of human nature. At the time it could not be so clear, since the future was unknown; but now that fifteen hundred years have passed, we see that everything in those three questions was so justly divined and foretold, and has been so truly fulfilled, that nothing can be added to them or taken from them.

The "temptations" the Inquisitor is referring to here are the three temptations of Jesus, described in [Matthew chapter 4](//en.wikisource.org/wiki/Bible_\(King_James\)/Matthew) in the Bible:

_And when the tempter came to him, he said, If thou be the Son of God, command that these stones be made bread. But he answered and said, It is written, Man shall not live by bread alone, but by every word that proceedeth out of the mouth of God. Then the devil taketh him up into the holy city, and setteth him on a pinnacle of the temple, And saith unto him, If thou be the Son of God, cast thyself down: for it is written, He shall give his angels charge concerning thee: and in their hands they shall bear thee up, lest at any time thou dash thy foot against a stone. Jesus said unto him, It is written again, Thou shalt not tempt the Lord thy God. Again, the devil taketh him up into an exceeding high mountain, and sheweth him all the kingdoms of the world, and the glory of them; And saith unto him, All these things will I give thee, if thou wilt fall down and worship me. Then saith Jesus unto him, Get thee hence, Satan: for it is written, Thou shalt worship the Lord thy God, and him only shalt thou serve. Then the devil leaveth him, and, behold, angels came and ministered unto him._

The same passage is described in [Luke chapter 4](//en.wikisource.org/wiki/Bible_\(King_James\)/Luke#Chapter_4):

_And the devil said unto him, If thou be the Son of God, command this stone that it be made bread. And Jesus answered him, saying, It is written, That man shall not live by bread alone, but by every word of God. And the devil, taking him up into an high mountain, shewed unto him all the kingdoms of the world in a moment of time. And the devil said unto him, All this power will I give thee, and the glory of them: for that is delivered unto me; and to whomsoever I will I give it. If thou therefore wilt worship me, all shall be thine. And Jesus answered and said unto him, Get thee behind me, Satan: for it is written, Thou shalt worship the Lord thy God, and him only shalt thou serve. And he brought him to Jerusalem, and set him on a pinnacle of the temple, and said unto him, If thou be the Son of God, cast thyself down from hence: For it is written, He shall give his angels charge over thee, to keep thee: And in their hands they shall bear thee up, lest at any time thou dash thy foot against a stone. And Jesus answering said unto him, It is said, Thou shalt not tempt the Lord thy God. And when the devil had ended all the temptation, he departed from him for a season._

Even though the two accounts differ in the ordering, the same three temptations are given by the devil to Jesus:

  1. Turn stones to bread.
  2. Worship the Devil in exchange for worldly power.
  3. Attempt to hurt yourself, to prove that you are protected by God.

The Inquisitor goes on to say that these three temptations are profound, which he will describe later.

  


## Part 6

     "Judge Thyself who was right- Thou or he who questioned Thee then? Remember the first question; its meaning, in other words, was this: "Thou wouldst go into the world, and art going with empty hands, with some promise of freedom which men in their simplicity and their natural unruliness cannot even understand, which they fear and dread- for nothing has ever been more insupportable for a man and a human society than freedom. But seest Thou these stones in this parched and barren wilderness? Turn them into bread, and mankind will run after Thee like a flock of sheep, grateful and obedient, though for ever trembling, lest Thou withdraw Thy hand and deny them Thy bread." But Thou wouldst not deprive man of freedom and didst reject the offer, thinking, what is that freedom worth if obedience is bought with bread? Thou didst reply that man lives not by bread alone. But dost Thou know that for the sake of that earthly bread the spirit of the earth will rise up against Thee and will strive with Thee and overcome Thee, and all will follow him, crying, "Who can compare with this beast? He has given us fire from heaven!" Dost Thou know that the ages will pass, and humanity will proclaim by the lips of their sages that there is no crime, and therefore no sin; there is only hunger? "Feed men, and then ask of them virtue!" that's what they'll write on the banner, which they will raise against Thee, and with which they will destroy Thy temple. Where Thy temple stood will rise a new building; the terrible tower of Babel will be built again, and though, like the one of old, it will not be finished, yet Thou mightest have prevented that new tower and have cut short the sufferings of men for a thousand years; for they will come back to us after a thousand years of agony with their tower. They will seek us again, hidden underground in the catacombs, for we shall be again persecuted and tortured. They will find us and cry to us, "Feed us, for those who have promised us fire from heaven haven't given it!" And then we shall finish building their tower, for he finishes the building who feeds them. And we alone shall feed them in Thy name, declaring falsely that it is in Thy name. Oh, never, never can they feed themselves without us! No science will give them bread so long as they remain free. In the end they will lay their freedom at our feet, and say to us, "Make us your slaves, but feed us." They will understand themselves, at last, that freedom and bread enough for all are inconceivable together, for never, never will they be able to share between them! They will be convinced, too, that they can never be free, for they are weak, vicious, worthless, and rebellious. Thou didst promise them the bread of Heaven, but, I repeat again, can it compare with earthly bread in the eyes of the weak, ever sinful and ignoble race of man? And if for the sake of the bread of Heaven thousands shall follow Thee, what is to become of the millions and tens of thousands of millions of creatures who will not have the strength to forego the earthly bread for the sake of the heavenly? Or dost Thou care only for the tens of thousands of the great and strong, while the millions, numerous as the sands of the sea, who are weak but love Thee, must exist only for the sake of the great and strong? No, we care for the weak too. They are sinful and rebellious, but in the end they too will become obedient. They will marvel at us and look on us as gods, because we are ready to endure the freedom which they have found so dreadful and to rule over them- so awful it will seem to them to be free. But we shall tell them that we are Thy servants and rule them in Thy name. We shall deceive them again, for we will not let Thee come to us again. That deception will be our suffering, for we shall be forced to lie.

  


## Part 7

     "'This is the significance of the first question in the wilderness, and this is what Thou hast rejected for the sake of that freedom which Thou hast exalted above everything. Yet in this question lies hid the great secret of this world. Choosing "bread," Thou wouldst have satisfied the universal and everlasting craving of humanity- to find someone to worship. So long as man remains free he strives for nothing so incessantly and so painfully as to find someone to worship. But man seeks to worship what is established beyond dispute, so that all men would agree at once to worship it. For these pitiful creatures are concerned not only to find what one or the other can worship, but to find community of worship is the chief misery of every man individually and of all humanity from the beginning of time. For the sake of common worship they've slain each other with the sword. They have set up gods and challenged one another, "Put away your gods and come and worship ours, or we will kill you and your gods!" And so it will be to the end of the world, even when gods disappear from the earth; they will fall down before idols just the same. Thou didst know, Thou couldst not but have known, this fundamental secret of human nature, but Thou didst reject the one infallible banner which was offered Thee to make all men bow down to Thee alone- the banner of earthly bread; and Thou hast rejected it for the sake of freedom and the bread of Heaven. Behold what Thou didst further. And all again in the name of freedom! I tell Thee that man is tormented by no greater anxiety than to find someone quickly to whom he can hand over that gift of freedom with which the ill-fated creature is born. But only one who can appease their conscience can take over their freedom. In bread there was offered Thee an invincible banner; give bread, and man will worship thee, for nothing is more certain than bread. But if someone else gains possession of his conscience- Oh! then he will cast away Thy bread and follow after him who has ensnared his conscience. In that Thou wast right. For the secret of man's being is not only to live but to have something to live for. Without a stable conception of the object of life, man would not consent to go on living, and would rather destroy himself than remain on earth, though he had bread in abundance. That is true. But what happened? Instead of taking men's freedom from them, Thou didst make it greater than ever! Didst Thou forget that man prefers peace, and even death, to freedom of choice in the knowledge of good and evil? Nothing is more seductive for man than his freedom of conscience, but nothing is a greater cause of suffering. And behold, instead of giving a firm foundation for setting the conscience of man at rest for ever, Thou didst choose all that is exceptional, vague and enigmatic; Thou didst choose what was utterly beyond the strength of men, acting as though Thou didst not love them at all- Thou who didst come to give Thy life for them! Instead of taking possession of men's freedom, Thou didst increase it, and burdened the spiritual kingdom of mankind with its sufferings for ever. Thou didst desire man's free love, that he should follow Thee freely, enticed and taken captive by Thee. In place of the rigid ancient law, man must hereafter with free heart decide for himself what is good and what is evil, having only Thy image before him as his guide. But didst Thou not know that he would at last reject even Thy image and Thy truth, if he is weighed down with the fearful burden of free choice? They will cry aloud at last that the truth is not in Thee, for they could not have been left in greater confusion and suffering than Thou hast caused, laying upon them so many cares and unanswerable problems.

  
  


# The Grand Inquisitor (Part 2)

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## Part 8

     "'So that, in truth, Thou didst Thyself lay the foundation for the

destruction of Thy kingdom, and no one is more to blame for it. Yet what was offered Thee? There are three powers, three powers alone, able to conquer and to hold captive for ever the conscience of these impotent rebels for their happiness those forces are miracle, mystery and authority. Thou hast rejected all three and hast set the example for doing so. When the wise and dread spirit set Thee on the pinnacle of the temple and said to Thee, "If Thou wouldst know whether Thou art the Son of God then cast Thyself down, for it is written: the angels shall hold him up lest he fall and bruise himself, and Thou shalt know then whether Thou art the Son of God and shalt prove then how great is Thy faith in Thy Father." But Thou didst refuse and wouldst not cast Thyself down. Oh, of course, Thou didst proudly and well, like God; but the weak, unruly race of men, are they gods? Oh, Thou didst know then that in taking one step, in making one movement to cast Thyself down, Thou wouldst be tempting God and have lost all Thy faith in Him, and wouldst have been dashed to pieces against that earth which Thou didst come to save. And the wise spirit that tempted Thee would have rejoiced. But I ask again, are there many like Thee? And couldst Thou believe for one moment that men, too, could face such a temptation? Is the nature of men such, that they can reject miracle, and at the great moments of their life, the moments of their deepest, most agonising spiritual difficulties, cling only to the free verdict of the heart? Oh, Thou didst know that Thy deed would be recorded in books, would be handed down to remote times and the utmost ends of the earth, and Thou didst hope that man, following Thee, would cling to God and not ask for a miracle. But Thou didst not know that when man rejects miracle he rejects God too; for man seeks not so much God as the miraculous. And as man cannot bear to be without the miraculous, he will create new miracles of his own for himself, and will worship deeds of sorcery and witchcraft, though he might be a hundred times over a rebel, heretic and infidel. Thou didst not come down from the Cross when they shouted to Thee, mocking and reviling Thee, "Come down from the cross and we will believe that Thou art He." Thou didst not come down, for again Thou wouldst not enslave man by a miracle, and didst crave faith given freely, not based on miracle. Thou didst crave for free love and not the base raptures of the slave before the might that has overawed him for ever. But Thou didst think too highly of men therein, for they are slaves, of course, though rebellious by nature. Look round and judge; fifteen centuries have passed, look upon them. Whom hast Thou raised up to Thyself? I swear, man is weaker and baser by nature than Thou hast believed him! Can he, can he do what Thou didst? By showing him so much respect, Thou didst, as it were, cease to feel for him, for Thou didst ask far too much from him- Thou who hast loved him more than Thyself! Respecting him less, Thou wouldst have asked less of him. That would have been more like love, for his burden would have been lighter. He is weak and vile. What though he is everywhere now rebelling against our power, and proud of his rebellion? It is the pride of a child and a schoolboy. They are little children rioting and barring out the teacher at school. But their childish delight will end; it will cost them dear. Mankind as a whole has always striven to organise a universal state. There have been many great nations with great histories, but the more highly they were developed the more unhappy they were, for they felt more acutely than other people the craving for world-wide union. The great conquerors, Timours and Ghenghis-Khans, whirled like hurricanes over the face of the earth striving to subdue its people, and they too were but the unconscious expression of the same craving for universal unity. Hadst Thou taken the world and Caesar's purple, Thou wouldst have founded the universal state and have given universal peace. For who can rule men if not he who holds their conscience and their bread in his hands? We have taken the sword of Caesar, and in taking it, of course, have rejected Thee and followed him. Oh, ages are yet to come of the confusion of free thought, of their science and cannibalism. For having begun to build their tower of Babel without us, they will end, of course, with cannibalism. But then the beast will crawl to us and lick our feet and spatter them with tears of blood. And we shall sit upon the beast and raise the cup, and on it will be written, "Mystery." But then, and only then, the reign of peace and happiness will come for men. Thou art proud of Thine elect, but Thou hast only the elect, while we give rest to all. And besides, how many of those elect, those mighty ones who could become elect, have grown weary waiting for Thee, and have transferred and will transfer the powers of their spirit and the warmth of their heart to the other camp, and end by raising their free banner against Thee. Thou didst Thyself lift up that banner. But with us all will be happy and will no more rebel nor destroy one another as under Thy freedom. Oh, we shall persuade them that they will only become free when they renounce their freedom to us and submit to us. And shall we be right or shall we be lying? They will be convinced that we are right, for they will remember the horrors of slavery and confusion to which Thy freedom brought them. Freedom, free thought, and science will lead them into such straits and will bring them face to face with such marvels and insoluble mysteries, that some of them, the fierce and rebellious, will destroy themselves, others, rebellious but weak, will destroy one another, while the rest, weak and unhappy, will crawl fawning to our feet and whine to us: "Yes, you were right, you alone possess His

mystery, and we come back to you, save us from ourselves!"

  


## Part 9

     "'Receiving bread from us, they will see clearly that we take

the bread made by their hands from them, to give it to them, without any miracle. They will see that we do not change the stones to bread, but in truth they will be more thankful for taking it from our hands than for the bread itself! For they will remember only too well that in old days, without our help, even the bread they made turned to stones in their hands, while since they have come back to us, the very stones have turned to bread in their hands. Too, too well will they know the value of complete submission! And until men know that, they will be unhappy. Who is most to blame for their not knowing it?-speak! Who scattered the flock and sent it astray on unknown paths? But the flock will come together again and will submit once more, and then it will be once for all. Then we shall give them the quiet humble happiness of weak creatures such as they are by nature. Oh, we shall persuade them at last not to be proud, for Thou didst lift them up and thereby taught them to be proud. We shall show them that they are weak, that they are only pitiful children, but that childlike happiness is the sweetest of all. They will become timid and will look to us and huddle close to us in fear, as chicks to the hen. They will marvel at us and will be awe-stricken before us, and will be proud at our being so powerful and clever that we have been able to subdue such a turbulent flock of thousands of millions. They will tremble impotently before our wrath, their minds will grow fearful, they will be quick to shed tears like women and children, but they will be just as ready at a sign from us to pass to laughter and rejoicing, to happy mirth and childish song. Yes, we shall set them to work, but in their leisure hours we shall make their life like a child's game, with children's songs and innocent dance. Oh, we shall allow them even sin, they are weak and helpless, and they will love us like children because we allow them to sin. We shall tell them that every sin will be expiated, if it is done with our permission, that we allow them to sin because we love them, and the punishment for these sins we take upon ourselves. And we shall take it upon ourselves, and they will adore us as their saviours who have taken on themselves their sins before God. And they will have no secrets from us. We shall allow or forbid them to live with their wives and mistresses, to have or not to have children according to whether they have been obedient or disobedient- and they will submit to us gladly and cheerfully. The most painful secrets of their conscience, all, all they will bring to us, and we shall have an answer for all. And they will be glad to believe our answer, for it will save them from the great anxiety and terrible agony they endure at present in making a free decision for themselves. And all will be happy, all the millions of creatures except the hundred thousand who rule over them. For only we, we who guard the mystery, shall be unhappy. There will be thousands of millions of happy babes, and a hundred thousand sufferers who have taken upon themselves the curse of the knowledge of good and evil. Peacefully they will die, peacefully they will expire in Thy name, and beyond the grave they will find nothing but death. But we shall keep the secret, and for their happiness we shall allure them with the reward of heaven and eternity. Though if there were anything in the other world, it certainly would not be for such as they. It is prophesied that Thou wilt come again in victory, Thou wilt come with Thy chosen, the proud and strong, but we will say that they have only saved themselves, but we have saved all. We are told that the harlot who sits upon the beast, and holds in her hands the mystery, shall be put to shame, that the weak will rise up again, and will rend her royal purple and will strip naked her loathsome body. But then I will stand up and point out to Thee the thousand millions of happy children who have known no sin. And we who have taken their sins upon us for their happiness will stand up before Thee and say: "Judge us if Thou canst and darest." Know that I fear Thee not. Know that I too have been in the wilderness, I too have lived on roots and locusts, I too prized the freedom with which Thou hast blessed men, and I too was striving to stand among Thy elect, among the strong and powerful, thirsting "to make up the number." But I awakened and would not serve madness. I turned back and joined the ranks of those who have corrected Thy work. I left the proud and went back to the humble, for the happiness of the humble. What I say to Thee will come to pass, and our dominion will be built up. I repeat, to-morrow Thou shalt see that obedient flock who at a sign from me will hasten to heap up the hot cinders about the pile on which I shall burn Thee for coming to hinder us. For if anyone has ever deserved our fires, it is Thou. To-morrow I shall burn

Thee. Dixi.'"

Dixi
    I have spoken (latin)

  


## Part 10

     Ivan stopped. He was carried away as he talked, and spoke with excitement; when he had finished, he suddenly smiled.

     Alyosha had listened in silence; towards the end he was greatly moved and seemed several times on the point of interrupting, but restrained himself. Now his words came with a rush.

     "But... that's absurd!" he cried, flushing. "Your poem is in praise of Jesus, not in blame of Him- as you meant it to be. And who will believe you about freedom? Is that the way to understand it? That's not the idea of it in the Orthodox Church.... That's Rome, and not even the whole of Rome, it's false-those are the worst of the Catholics the Inquisitors, the Jesuits!... And there could not be such a fantastic creature as your Inquisitor. What are these sins of mankind they take on themselves? Who are these keepers of the mystery who have taken some curse upon themselves for the happiness of mankind? When have they been seen? We know the Jesuits, they are spoken ill of, but surely they are not what you describe? They are not that at all, not at all.... They are simply the Romish army for the earthly sovereignty of the world in the future, with the Pontiff of Rome for Emperor... that's their ideal, but there's no sort of mystery or lofty melancholy about it.... It's simple lust of power, of filthy earthly gain, of domination-something like a universal serfdom with them as masters-that's all they stand for. They don't even believe in God perhaps. Your suffering Inquisitor is a mere fantasy."

     "Stay, stay," laughed Ivan. "how hot you are! A fantasy you say, let it be so! Of course it's a fantasy. But allow me to say: do you really think that the Roman Catholic movement of the last centuries is actually nothing but the lust of power, of filthy earthly gain? Is that Father Paissy's teaching?"

     "No, no, on the contrary, Father Paissy did once say something rather the same as you... but of course it's not the same, not a bit the same," Alyosha hastily corrected himself.

     "A precious admission, in spite of your 'not a bit the same.' I ask you why your Jesuits and Inquisitors have united simply for vile material gain? Why can there not be among them one martyr oppressed by great sorrow and loving humanity? You see, only suppose that there was one such man among all those who desire nothing but filthy material gain-if there's only one like my old Inquisitor, who had himself eaten roots in the desert and made frenzied efforts to subdue his flesh to make himself free and perfect. But yet all his life he loved humanity, and suddenly his eyes were opened, and he saw that it is no great moral blessedness to attain perfection and freedom, if at the same time one gains the conviction that millions of God's creatures have been created as a mockery, that they will never be capable of using their freedom, that these poor rebels can never turn into giants to complete the tower, that it was not for such geese that the great idealist dreamt his dream of harmony. Seeing all that he turned back and joined- the clever people. Surely that could have happened?"

  


## Part 11

     "Joined whom, what clever people?" cried Alyosha, completely

carried away. "They have no such great cleverness and no mysteries and secrets.... Perhaps nothing but Atheism, that's all their secret. Your

Inquisitor does not believe in God, that's his secret!" 

     "What if it is so! At last you have guessed it. It's perfectly true, it's true that that's the whole secret, but isn't that suffering, at least for a man like that, who has wasted his whole life in the desert and yet could not shake off his incurable love of humanity? In his old age he reached the clear conviction that nothing but the advice of the great dread spirit could build up any tolerable sort of life for the feeble, unruly, 'incomplete, empirical creatures created in jest.' And so, convinced of this, he sees that he must follow the counsel of the wise spirit, the dread spirit of death and destruction, and therefore accept lying and deception, and lead men consciously to death and destruction, and yet deceive them all the way so that they may not notice where they are being led, that the poor blind creatures may at least on the way think themselves happy. And note, the deception is in the name of Him in Whose ideal the old man had so fervently believed all his life long. Is not that tragic? And if only one such stood at the head of the whole army 'filled with the lust of power only for the sake of filthy gain'- would not one such be enough to make a tragedy? More than that, one such standing at the head is enough to create the actual leading idea of the Roman Church with all its armies and Jesuits, its highest idea. I tell you frankly that I firmly believe that there has always been such a man among those who stood at the head of the movement. Who knows, there may have been some such even among the Roman Popes. Who knows, perhaps the spirit of that accursed old man who loves mankind so obstinately in his own way, is to be found even now in a whole multitude of such old men, existing not by chance but by agreement, as a secret league formed long ago for the guarding of the mystery, to guard it from the weak and the unhappy, so as to make them happy. No doubt it is so, and so it must be indeed. I fancy that even among the Masons there's something of the same mystery at the bottom, and that that's why the Catholics so detest the Masons as their rivals breaking up the unity of the idea, while it is so essential that there should be one flock and one shepherd.... But from the way I defend my idea I might be an author impatient of your criticism. Enough of it."

     "You are perhaps a Mason yourself!" broke suddenly from Alyosha. "You don't believe in God," he added, speaking this time very sorrowfully. He fancied besides that his brother was looking at him ironically. "How does your poem end?" he asked, suddenly looking down. "Or was it the end?"

  


## Part 12

     "I meant to end it like this. When the Inquisitor ceased

speaking he waited some time for his Prisoner to answer him. His silence weighed down upon him. He saw that the Prisoner had listened intently all the time, looking gently in his face and evidently not wishing to reply. The old man longed for him to say something, however bitter and terrible. But He suddenly approached the old man in silence and softly kissed him on his bloodless aged lips. That was all his answer. The old man shuddered. His lips moved. He went to the door, opened it, and said to Him: 'Go, and come no more... come not at all, never, never!' And he let Him out into the dark alleys of the

town. The Prisoner went away." 

     "And the old man?"

     "The kiss glows in his heart, but the old man adheres to his idea."

     "And you with him, you too?" cried Alyosha, mournfully.

     Ivan laughed.

     "Why, it's all nonsense, Alyosha. It's only a senseless poem of a senseless student, who could never write two lines of verse. Why do you take it so seriously? Surely you don't suppose I am going straight off to the Jesuits, to join the men who are correcting His work? Good Lord, it's no business of mine. I told you, all I want is to live on to thirty, and then... dash the cup to the ground!"

     "But the little sticky leaves, and the precious tombs, and the blue sky, and the woman you love! How will you live, how will you love them?" Alyosha cried sorrowfully. "With such a hell in your heart and your head, how can you? No, that's just what you are going away for, to join them... if not, you will kill yourself, you can't endure it!"

     "There is a strength to endure everything," Ivan said with a cold smile.

     "The strength of the Karamazovs- the strength of the Karamazov baseness."

     "To sink into debauchery, to stifle your soul with corruption, yes?"

     "Possibly even that... only perhaps till I am thirty I shall escape it, and then-"

     "How will you escape it? By what will you escape it? That's impossible with your ideas."

     "In the Karamazov way, again."

     "'Everything is lawful,' you mean? Everything is lawful, is that it?"

     Ivan scowled, and all at once turned strangely pale.

     "Ah, you've caught up yesterday's phrase, which so offended Muisov- and which Dmitri pounced upon so naively and paraphrased!" he smiled queerly. "Yes, if you like, 'everything is lawful' since the word has been said, I won't deny it. And Mitya's version isn't bad."

  


## Part 13

     Alyosha looked at him in silence.

     "I thought that going away from here I have you at least," Ivan said suddenly, with unexpected feeling; "but now I see that there is no place for me even in your heart, my dear hermit. The formula, 'all is lawful,' I won't renounce- will you renounce me for that, yes?"

     Alyosha got up, went to him and softly kissed him on the lips.

     "That's plagiarism," cried Ivan, highly delighted. "You stole that from my poem. Thank you though. Get up, Alyosha, it's time we were going, both of us."

     They went out, but stopped when they reached the entrance of the restaurant.

     "Listen, Alyosha," Ivan began in a resolute voice, "if I am really able to care for the sticky little leaves I shall only love them, remembering you. It's enough for me that you are somewhere here, and I shan't lose my desire for life yet. Is that enough for you? Take it as a declaration of love if you like. And now you go to the right and I to the left. And it's enough, do you hear, enough. I mean even if I don't go away to-morrow (I think I certainly shall go) and we meet again, don't say a word more on these subjects. I beg that particularly. And about Dmitri too, I ask you specially, never speak to me again," he added, with sudden irritation; "it's all exhausted, it has all been said over and over again, hasn't it? And I'll make you one promise in return for it. When at thirty, I want to 'dash the cup to the ground,' wherever I may be I'll come to have one more talk with you, even though it were from America, you may be sure of that. I'll come on purpose. It will be very interesting to have a look at you, to see what you'll be by that time. It's rather a solemn promise, you see. And we really may be parting for seven years or ten. Come, go now to your Pater Seraphicus, he is dying. If he dies without you, you will be angry with me for having kept you. Good-bye, kiss me once more; that's right, now go."

     Ivan turned suddenly and went his way without looking back. It was just as Dmitri had left Alyosha the day before, though the parting had been very different. The strange resemblance flashed like an arrow through Alyosha's mind in the distress and dejection of that moment. He waited a little, looking after his brother. He suddenly noticed that Ivan swayed as he walked and that his right shoulder looked lower than his left. He had never noticed it before. But all at once he turned too, and almost ran to the monastery. It was nearly dark, and he felt almost frightened; something new was growing up in him for which he could not account. The wind had risen again as on the previous evening, and the ancient pines murmured gloomily about him when he entered the hermitage copse. He almost ran. "Pater Seraphicus- he got that name from somewhere- where from?" Alyosha wondered. "Ivan, poor Ivan, and when shall I see you again?... Here is the hermitage. Yes, yes, that he is, Pater Seraphicus, he will save me- from him and for ever!"

     Several times afterwards he wondered how he could, on leaving Ivan, so completely forget his brother Dmitri, though he had that morning, only a few hours before, so firmly resolved to find him and not to give up doing so, even should he be unable to return to the monastery that night.

  
  


# The Devil

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## Part 1: Ivan's Condition

     I AM NOT a doctor, but yet I feel that the moment has come when I must inevitably give the reader some account of the nature of Ivan's illness. Anticipating events I can say at least one thing: he was at that moment on the very eve of an attack of brain fever. Though his health had long been affected, it had offered a stubborn resistance to the fever which in the end gained complete mastery over it. Though I know nothing of medicine, I venture to hazard the suggestion that he really had perhaps, by a terrible effort of will, succeeded in delaying the attack for a time, hoping, of course, to check it completely. He knew that he was unwell, but he loathed the thought of being ill at that fatal time, at the approaching crisis in his life, when he needed to have all his wits about him, to say what he had to say boldly and resolutely and "to justify himself to himself."

     He had, however, consulted the new doctor, who had been brought from Moscow by a fantastic notion of Katerina Ivanovna's to which I have referred already. After listening to him and examining him the doctor came to the conclusion that he was actually suffering from some disorder of the brain, and was not at all surprised by an admission which Ivan had reluctantly made him. "Hallucinations are quite likely in your condition," the doctor opined, 'though it would be better to verify them... you must take steps at once, without a moment's delay, or things will go badly with you." But Ivan did not follow this judicious advice and did not take to his bed to be nursed. "I am walking about, so I am strong enough, if I drop, it'll be different then, anyone may nurse me who likes," he decided, dismissing the subject.

The person narrating the story is a man from the town who speaks of all the events from **The Brothers Karamazov** with a certain amount of omniscience. For instance, the narrator is able to recount this story although it is obvious that Ivan is alone. However in other situations, the narrator does not know everything, especially concerning the murder of Fyodor Karamazov. the opening line of this chapter is illustrative of this point:

    _I AM NOT a doctor, but yet I feel that the moment has come when I must inevitably give the reader some account of the nature of Ivan's illness._

The narrator admits a certain shortcoming in his literary omniscience, but yet he is able to speak frankly about events that he did not witness.

  


## Part 2: Ivan's Guest

     And so he was sitting almost conscious himself of his delirium and, as I have said already, looking persistently at some object on the sofa against the opposite wall. Someone appeared to be sitting there, though goodness knows how he had come in, for he had not been in the room when Ivan came into it, on his return from Smerdyakov. This was a person or, more accurately speaking, a Russian gentleman of a particular kind, no longer young, qui faisait la cinquantaine, as the French say, with rather long, still thick, dark hair, slightly streaked with grey and a small pointed beard. He was wearing a brownish reefer jacket, rather shabby, evidently made by a good tailor though, and of a fashion at least three years old, that had been discarded by smart and well-to-do people for the last two years. His linen and his long scarf-like neck-tie were all such as are worn by people who aim at being stylish, but on closer inspection his linen was not overclean and his wide scarf was very threadbare. The visitor's check trousers were of excellent cut, but were too light in colour and too tight for the present fashion. His soft fluffy white hat was out of keeping with the season.

     In brief there was every appearance of gentility on straitened means. It looked as though the gentleman belonged to that class of idle landowners who used to flourish in the times of serfdom. He had unmistakably been, at some time, in good and fashionable society, had once had good connections, had possibly preserved them indeed, but, after a gay youth, becoming gradually impoverished on the abolition of serfdom, he had sunk into the position of a poor relation of the best class, wandering from one good old friend to another and received by them for his companionable and accommodating disposition and as being, after all, a gentleman who could be asked to sit down with anyone, though, of course, not in a place of honour. Such gentlemen of accommodating temper and dependent position, who can tell a story, take a hand at cards, and who have a distinct aversion for any duties that may be forced upon them, are usually solitary creatures, either bachelors or widowers. Sometimes they have children, but if so, the children are always being brought up at a distance, at some aunt's, to whom these gentlemen never allude in good society, seeming ashamed of the relationship. They gradually lose sight of their children altogether, though at intervals they receive a birthday or Christmas letter from them and sometimes even answer it.

     The countenance of the unexpected visitor was not so much good-natured, as accommodating and ready to assume any amiable expression as occasion might arise. He had no watch, but he had a tortoise-shell lorgnette on a black ribbon. On the middle finger of his right hand was a massive gold ring with a cheap opal stone in it.

     Ivan was angrily silent and would not begin the conversation.

qui faisait la cinquantaine
    Fiftyish (french)

While sitting and staring at the far wall, a person simply "appeared to be sitting there". Notice that the narrator does not claim the stranger appeared from thin air, but almost says that the person had been there all along, unnoticed. Notice again the absurdity of the narrator: he can recount the events of this night, although even he seems to be somewhat confused by the presence of this new man in the room. Ivan also does not appear to be alarmed or startled by this person. He never inquires where the visitor came from, and does not greet him the way a proper gentleman would have greeted a new visitor.

The passage starts out with the words _And so he was sitting almost conscious himself of his delirium_, again pointing out that Ivan was somehow expecting to have a problem with "brain fever". Multiple stresses had been piling up: the murder of his father, the imprisonment of his brother, and the fact that he has been pursuing Katerina Ivanova, who was desperately in love with Dimitri (love only strengthened because Dimitri was wrongfully accused and in jail).

The stranger in the room is described in a particular way, as a Russian gentlemen who was reasonably fashionable although dated. His clothing is described as being nice but old and generally "shabby". The first line of the second paragraph pushes the idea home, that the man had _every appearance of gentility on straitened means_. At the time of writing **The Brothers Karamazov**, Russia had only recently abolished serfdom, and it is in the terms of the feudal system that the visitor is described. Notice the following descriptions, specifically:

    _He had unmistakably been, at some time, in good and fashionable society, had once had good connections, had possibly preserved them indeed, but, after a gay youth, becoming gradually impoverished on the abolition of serfdom, he had sunk into the position of a poor relation of the best class, wandering from one good old friend to another and received by them for his companionable and accommodating disposition and as being, after all, a gentleman who could be asked to sit down with anyone, though, of course, not in a place of honour_

Look at this description as a metaphore for the devil: The rise of atheism or agnosticism among the educated creates a poorness for supernatural beings, where the dark ages only years before had been a boon. He is also being described as having "good connections" which have been preserved, and that he could sit down with anybody. The devil, representative of sin, certainly is nobody's stranger.

  


## Part 3: Truth

     The visitor waited and sat exactly like a poor relation who had come down from his room to keep his host company at tea, and was discreetly silent, seeing that his host was frowning and preoccupied. But he was ready for any affable conversation as soon as his host should begin it. All at once his face expressed a sudden solicitude.

     "I say," he began to Ivan, "excuse me, I only mention it to remind you. You went to Smerdyakov's to find out about Katerina Ivanovna, but you came away without finding out anything about her, you probably forgot-"

     "Ah, yes." broke from Ivan and his face grew gloomy with uneasiness. "Yes, I'd forgotten... but it doesn't matter now, never mind, till to-morrow," he muttered to himself, "and you," he added, addressing his visitor, "I should have remembered that myself in a minute, for that was just what was tormenting me! Why do you interfere, as if I should believe that you prompted me, and that I didn't remember it of myself?"

     "Don't believe it then," said the gentleman, smiling amicably, "what's the good of believing against your will? Besides, proofs are no help to believing, especially material proofs. Thomas believed, not because he saw Christ risen, but because he wanted to believe, before he saw. Look at the spiritualists, for instance.... I am very fond of them... only fancy, they imagine that they are serving the cause of religion, because the devils show them their horns from the other world. That, they say, is a material proof, so to speak, of the existence of another world. The other world and material proofs, what next! And if you come to that, does proving there's a devil prove that there's a God? I want to join an idealist society, I'll lead the opposition in it, I'll say I am a realist, but not a materialist, he he!"

The visitor is now described in terms of being a personal relation, where previously he was described as being everybody's acquaintance.

Ivan had gone to Smerdyakov's house to inquire about Katerina Ivanova. However the two talked about Fyodor almost exclusively, and forgot entirely about Katerina. This passage, presented two chapters before **The Devil** explains the situation:

    _When, after his conversation with Alyosha, Ivan suddenly decided with his hand on the bell of his lodging to go to Smerdyakov, he obeyed a sudden and peculiar impulse of indignation. He suddenly remembered how Katerina Ivanovna had only just cried out to him in Alyosha's presence: "It was you, you, persuaded me of his" (that is, Mitya's) "guilt!" Ivan was thunderstruck when he recalled it. He had never once tried to persuade her that Mitya was the murderer; on the contrary, he had suspected himself in her presence, that time when he came back from Smerdyakov. It was she, she, who had produced that "document" and proved his brother's guilt. And now she suddenly exclaimed: "I've been at Smerdyakov's myself!" When had she been there? Ivan had known nothing of it. So she was not at all so sure of Mitya's guilt! And what could Smerdyakov have told her? What, what, had he said to her? His heart burned with violent anger. He could not understand how he could, half an hour before, have let those words pass and not have cried out at the moment. He let go of the bell and rushed off to Smerdyakov. "I shall kill him, perhaps, this time," he thought on the way._

Katerina claims that she has been convinced by Ivan that Dimitri is guilty of the crime. However, Katerina also went to see Smerdyakov about the issue, which indicated to Ivan that perhaps Katerina was not convinced about Dimitri at all. Ivan went to Smerdyakov's apartment to ask about why Katerina had gone to see Smerdyakov, and what she had said to him. However, during the meeting, Smerdyakov admitted to killing Fyodor, with the statement:

    _"Aren't you tired of it? Here we are face to face; what's the use of going on keeping up a farce to each other? Are you still trying to throw it all on me, to my face? You murdered him; you are the real murderer, I was only your instrument, your faithful servant, and it was following your words I did it."_

Notice how even though Smerdyakov admits to killing Fyodor, he still blames Ivan for the murder. Smerdyakov claims he was only acting as Ivan's "instrument". The guilt that he had convinced Katerina against Dimitri, and the guilt that somehow he had persuaded Smerdyakov to murder Fyodor are weighing on Ivan, and it is because of this weight that he could not remember about Katerina. However, there was the persistant feeling that he had forgotten something, that even though he had gone to see Smerdyakov, and did get answers to some of his questions, he still hadn't concluded all his business.

It is the man across the room who reminds Ivan about the contents of his subconscious. This man knows that Ivan is trying to remember what precisely he was forgetting, and he also knows precisely what was forgot. And when he brings it up, Ivan has a most unusual response:

    _"Ah, yes." broke from Ivan and his face grew gloomy with uneasiness. "Yes, I'd forgotten... but it doesn't matter now, never mind, till to-morrow," he muttered to himself, "and you," he added, addressing his visitor, "I should have remembered that myself in a minute, for that was just what was tormenting me! Why do you interfere, as if I should believe that you prompted me, and that I didn't remember it of myself?"_

There is almost some measure of familiarity between Ivan and his guest, which prompts the question whether Ivan has seen this man before, and if not, was Ivan expecting him.

  
  


## Part 4: Ivan's Realization

     "Listen," Ivan suddenly got up from the table. "I seem to be delirious... I am delirious, in fact, talk any nonsense you like, I don't care! You won't drive me to fury, as you did last time. But I feel somehow ashamed... I want to walk about the room.... I sometimes don't see you and don't even hear your voice as I did last time, but I always guess what you are prating, for it's I, I myself speaking, not you. Only I don't know whether I was dreaming last time or whether I really saw you. I'll wet a towel and put it on my head and perhaps you'll vanish into air."

     Ivan went into the corner, took a towel, and did as he said, and with a wet towel on his head began walking up and down the room.

     "I am so glad you treat me so familiarly," the visitor began.

     "Fool," laughed Ivan, "do you suppose I should stand on ceremony with you? I am in good spirits now, though I've a pain in my forehead... and in the top of my head... only please don't talk philosophy, as you did last time. If you can't take yourself off, talk of something amusing. Talk gossip, you are a poor relation, you ought to talk gossip. What a nightmare to have! But I am not afraid of you. I'll get the better of you. I won't be taken to a mad-house!"

     "C'est charmant, poor relation. Yes, I am in my natural shape. For what am I on earth but a poor relation? By the way, I am listening to you and am rather surprised to find you are actually beginning to take me for something real, not simply your fancy, as you persisted in declaring last time-"

     "Never for one minute have I taken you for reality," Ivan cried with a sort of fury. "You are a lie, you are my illness, you are a phantom. It's only that I don't know how to destroy you and I see I must suffer for a time. You are my hallucination. You are the incarnation of myself, but only of one side of me... of my thoughts and feelings, but only the nastiest and stupidest of them. From that point of view you might be of interest to me, if only I had time to waste on you-"

Ivan is aware of his own delirium, and also seems to be aware that the person in the room is a figment. Ivan also refers to "last time", when the stranger put Ivan into a "fury". This is clearly not Ivan's first encounter with this stranger, which helps to explain the ease with which Ivan speaks to him.

  


## Part 5: Aloysha

     "Excuse me, excuse me, I'll catch you. When you flew out at Alyosha under the lamp-post this evening and shouted to him, 'You learnt it from him! How do you know that he visits me?' You were thinking of me then. So for one brief moment you did believe that I really exist," the gentleman laughed blandly.

     "Yes, that was a moment of weakness... but I couldn't believe in you. I don't know whether I was asleep or awake last time. Perhaps I was only dreaming then and didn't see you really at all-"

     "And why were you so surly with Alyosha just now? He is a dear; I've treated him badly over Father Zossima."

     "Don't talk of Alyosha! How dare you, you flunkey!" Ivan laughed again.

     "You scold me, but you laugh- that's a good sign. But you are ever so much more polite than you were last time and I know why: that great resolution of yours-"

     "Don't speak of my resolution," cried Ivan, savagely.

     "I understand, I understand, c'est noble, c'est charmant, you are going to defend your brother and to sacrifice yourself... C'est chevaleresque."

The stranger is referring to a conversation several chapters previously, where Alyosha confronts Ivan in the street at night. With Aloysha speaking first:

    _"No, Ivan. You've told yourself several times that you are the murderer."_
    _"When did I say so? I was in Moscow.... When have I said so?" Ivan faltered helplessly._
    _"You've said so to yourself many times, when you've been alone during these two dreadful months," Alyosha went on softly and distinctly as before._

Ivan has been blaming himself, although he does not quite know why. There has only been one time when Ivan ever mentioned it out loud, and refers to that incident next:

    _"You've been in my room!" he whispered hoarsely. "You've been there at night, when he came.... Confess... have you seen him, have you seen him?"_
    _"Whom do you mean- Mitya?" Alyosha asked, bewildered._
    _"Not him, damn the monster!" Ivan shouted, in a frenzy, "Do you know that he visits me? How did you find out? Speak!"_
    _"Who is he? I don't know whom you are talking about," Alyosha faltered, beginning to be alarmed._
    _"Yes, you do know. or how could you- ? It's impossible that you don't know."_

Ivan is talking about previous meetings with this stranger, and assumes that Alyosha must be aware of it because Alyosha is a monk in training, a holy man.

When the stranger mentions Alyosha again, Ivan becomes petulant. It's interesting to note how Ivan is both aware that this stranger is a delusion, but also treats him as a separate entity. His insults, referring to the visitor as a "flunky", are self-deprecating because this visitor his really Ivan.

  
  


## Part 6: One and the Same

     "Hold your tongue, I'll kick you!"

     "I shan't be altogether sorry, for then my object will be attained. If you kick me, you must believe in my reality, for people don't kick ghosts. Joking apart, it doesn't matter to me, scold if you like, though it's better to be a trifle more polite even to me. 'Fool, flunkey!' what words!"

     "Scolding you, I scold myself," Ivan laughed again, "you are myself, myself, only with a different face. You just say what I am thinking... and are incapable of saying anything new!"

     "If I am like you in my way of thinking, it's all to my credit," the gentleman declared, with delicacy and dignity.

     "You choose out only my worst thoughts, and what's more, the stupid ones. You are stupid and vulgar. You are awfully stupid. No, I can't put up with you! What am I to do, what am I to do?" Ivan said through his clenched teeth.

     "My dear friend, above all things I want to behave like a gentleman and to be recognised as such," the visitor began in an access of deprecating and simple-hearted pride, typical of a poor relation. "I am poor, but... I won't say very honest, but... it's an axiom generally accepted in society that I am a fallen angel. I certainly can't conceive how I can ever have been an angel. If I ever was, it must have been so long ago that there's no harm in forgetting it. Now I only prize the reputation of being a gentlemanly person and live as I can, trying to make myself agreeable. I love men genuinely, I've been greatly calumniated! Here when I stay with you from time to time, my life gains a kind of reality and that's what I like most of all. You see, like you, I suffer from the fantastic and so I love the realism of earth. Here, with you, everything is circumscribed, here all is formulated and geometrical, while we have nothing but indeterminate equations! I wander about here dreaming. I like dreaming. Besides, on earth I become superstitious. Please don't laugh, that's just what I like, to become superstitious. I adopt all your habits here: I've grown fond of going to the public baths, would you believe it? and I go and steam myself with merchants and priests. What I dream of is becoming incarnate once for all and irrevocably in the form of some merchant's wife weighing eighteen stone, and of believing all she believes. My ideal is to go to church and offer a candle in simple-hearted faith, upon my word it is. Then there would be an end to my sufferings. I like being doctored too; in the spring there was an outbreak of smallpox and I went and was vaccinated in a foundling hospital- if only you knew how I enjoyed myself that day. I subscribed ten roubles in the cause of the Slavs!... But you are not listening. Do you know, you are not at all well this evening? I know you went yesterday to that doctor... well, what about your health? What did the doctor say?"

     "Fool!" Ivan snapped out.

  


## Part 7: The Two are Different

     "But you are clever, anyway. You are scolding again? I didn't

ask out of sympathy. You needn't answer. Now rheumatism has come in

again-" 

     "Fool!" repeated Ivan.

     "You keep saying the same thing; but I had such an attack of rheumatism last year that I remember it to this day."

     "The devil have rheumatism!"

     "Why not, if I sometimes put on fleshly form? I put on fleshly form and I take the consequences. Satan sum et nihil humanum a me alienum puto."

     "What, what, Satan sum et nihil humanum... that's not bad for the devil!"

     "I am glad I've pleased you at last."

     "But you didn't get that from me." Ivan stopped suddenly, seeming struck. "That never entered my head, that's strange."

     "C'est du nouveau, n'est-ce pas?" This time I'll act honestly and explain to you. Listen, in dreams and especially in nightmares, from indigestion or anything, a man sees sometimes such artistic visions, such complex and real actuality, such events, even a whole world of events, woven into such a plot, with such unexpected details from the most exalted matters to the last button on a cuff, as I swear Leo Tolstoy has never invented. Yet such dreams are sometimes seen not by writers, but by the most ordinary people, officials, journalists, priests.... The subject is a complete enigma. A statesman confessed to me, indeed, that all his best ideas came to him when he was asleep. Well, that's how it is now, though I am your hallucination, yet just as in a nightmare, I say original things which had not entered your head before. So I don't repeat your ideas, yet I am only your nightmare, nothing more."

     "You are lying, your aim is to convince me you exist apart and are not my nightmare, and now you are asserting you are a dream."

_Satan sum et nihil humanum a me alienum puto_
    I am Satan, and deem nothing human alien to me. (latin)

C'est du nouveau, n'est-ce pas?
    It's new, isn't it? (french)

  
  
  
  


# The Devil (Part 2)

**[The Grand Inquisitor](/wiki/The_Grand_Inquisitor)**

* * *

_[The Brothers Karamazov_](//en.wikisource.org/wiki/The_Brothers_Karamazov) (at Wikisource) — _[The Grand Inquisitor_](//en.wikipedia.org/wiki/The_Grand_Inquisitor) (at Wikipedia) — _[The Brothers Karamazov_](//en.wikipedia.org/wiki/The_Brothers_Karamazov) (at Wikipedia)

## Part 8

     "Just so. But hesitation, suspense, conflict between belief and

disbelief- is sometimes such torture to a conscientious man, such as you are, that it's better to hang oneself at once. Knowing that you are inclined to believe in me, I administered some disbelief by telling you that anecdote. I lead you to belief and disbelief by turns, and I have my motive in it. It's the new method. As soon as you disbelieve in me completely, you'll begin assuring me to my face that I am not a dream but a reality. I know you. Then I shall have attained my object, which is an honourable one. I shall sow in you only a tiny grain of faith and it will grow into an oak-tree- and such an oak-tree that, sitting on it, you will long to enter the ranks of 'the hermits in the wilderness and the saintly women,' for that is what you are secretly longing for. You'll dine on locusts, you'll

wander into the wilderness to save your soul!" 

     "Then it's for the salvation of my soul you are working, is it, you scoundrel?"

     "One must do a good work sometimes. How ill-humoured you are!"

  


## Part 9

     "Fool! did you ever tempt those holy men who ate locusts and

prayed seventeen years in the wilderness till they were overgrown with

moss?" 

     "My dear fellow, I've done nothing else. One forgets the whole world and all the worlds, and sticks to one such saint, because he is a very precious diamond. One such soul, you know, is sometimes worth a whole constellation. We have our system of reckoning, you know. The conquest is priceless! And some of them, on my word, are not inferior to you in culture, though you won't believe it. They can contemplate such depths of belief and disbelief at the same moment that sometimes it really seems that they are within a hair's-breadth of being 'turned upside down,' as the actor Gorbunov says."

     "Well, did you get your nose pulled?"

     "My dear fellow," observed the visitor sententiously, "it's better to get off with your nose pulled than without a nose at all. As an afflicted marquis observed not long ago (he must have been treated by a specialist) in confession to his spiritual father- a Jesuit. I was present, it was simply charming. 'Give me back my nose!' he said, and he beat his breast. 'My son,' said the priest evasively, 'all things are accomplished in accordance with the inscrutable decrees of Providence, and what seems a misfortune sometimes leads to extraordinary, though unapparent, benefits. If stern destiny has deprived you of your nose, it's to your advantage that no one can ever pull you by your nose.' 'Holy father, that's no comfort,' cried the despairing marquis. 'I'd be delighted to have my nose pulled every day of my life, if it were only in its proper place.' 'My son,' sighs the priest, 'you can't expect every blessing at once. This is murmuring against Providence, who even in this has not forgotten you, for if you repine as you repined just now, declaring you'd be glad to have your nose pulled for the rest of your life, your desire has already been fulfilled indirectly, for when you lost your nose, you were led by the nose.'

  


## Part 10

     "Fool, how stupid!" cried Ivan.

     "My dear friend, I only wanted to amuse you. But I swear that's the genuine Jesuit casuistry and I swear that it all happened word for word as I've told you. It happened lately and gave me a great deal of trouble. The unhappy young man shot himself that very night when he got home. I was by his side till the very last moment. Those Jesuit confessionals are really my most delightful diversion at melancholy moments. Here's another incident that happened only the other day. A little blonde Norman girl of twenty- a buxom, unsophisticated beauty that would make your mouth water- comes to an old priest. She bends down and whispers her sin into the grating. 'Why, my daughter, have you fallen again already?' cries the priest: 'O Sancta Maria, what do I hear! Not the same man this time, how long is this going on? Aren't you ashamed!' 'Ah, mon pere,' answers the sinner with tears of penitence, 'Ca lui fait tant de plaisir, et a moi si peu de peine!'* Fancy, such an answer! I drew back. It was the cry of nature, better than innocence itself, if you like. I absolved her sin on the spot and was turning to go, but I was forced to turn back. I heard the priest at the grating making an appointment with her for the evening- though he was an old man hard as flint, he fell in an instant! It was nature, the truth of nature asserted its rights! What, you are turning up your nose again? Angry again? I don't know how to please you-"

     Ah, my father, this gives him so much pleasure, and me so little pain!

     "Leave me alone, you are beating on my brain like a haunting nightmare," Ivan moaned miserably, helpless before his apparition. "I am bored with you, agonisingly and insufferably. I would give anything to be able to shake you off!"

  


## Part 11

     "I repeat, moderate your expectations, don't demand of me

'everything great and noble,' and you'll see how well we shall get on," said the gentleman impressively. "You are really angry with me for not having appeared to you in a red glow, with thunder and lightning, with scorched wings, but have shown myself in such a modest form. You are wounded, in the first place, in your asthetic feelings, and, secondly, in your pride. How could such a vulgar devil visit such a great man as you! Yes, there is that romantic strain in you, that was so derided by Byelinsky. I can't help it, young man, as I got ready to come to you I did think as a joke of appearing in the figure of a retired general who had served in the Caucasus, with a star of the Lion and the Sun on my coat. But I was positively afraid of doing it, for you'd have thrashed me for daring to pin the Lion and the Sun on my coat, instead of, at least, the Polar Star or the Sirius. And you keep on saying I am stupid, but, mercy on us! I make no claim to be equal to you in intelligence. Mephistopheles declared to Faust that he desired evil, but did only good. Well, he can say what he likes, it's quite the opposite with me. I am perhaps the one man in all creation who loves the truth and genuinely desires good. I was there when the Word, Who died on the Cross, rose up into heaven bearing on His bosom the soul of the penitent thief. I heard the glad shrieks of the cherubim singing and shouting hosannah and the thunderous rapture of the seraphim which shook heaven and all creation, and I swear to you by all that's sacred, I longed to join the choir and shout hosannah with them all. The word had almost escaped me, had almost broken from my lips... you know how susceptible and aesthetically impressionable I am. But common sense- oh, a most unhappy trait in my character- kept me in due bounds and I let the moment pass! For what would have happened, I reflected, what would have happened after my hosannah? Everything on earth would have been extinguished at once and no events could have occurred. And so, solely from a sense of duty and my social position, was forced to suppress the good moment and to stick to my nasty task. Somebody takes all the credit of what's good for Himself, and nothing but nastiness is left for me. But I don't envy the honour of a life of idle imposture, I am not ambitious. Why am I, of all creatures in the world, doomed to be cursed by all decent people and even to be kicked, for if I put on mortal form I am bound to take such consequences sometimes? I know, of course, there's a secret in it, but they won't tell me the secret for anything, for then perhaps, seeing the meaning of it, I might bawl hosannah, and the indispensable minus would disappear at once, and good sense would reign supreme throughout the whole world. And that, of course, would mean the end of everything, even of magazines and newspapers, for who would take them in? I know that at the end of all things I shall be reconciled. I, too, shall walk my quadrillion and learn the secret. But till that happens I am sulking and fulfil my destiny though it's against the grain- that is, to ruin thousands for the sake of saving one. How many souls have had to be ruined and how many honourable reputations destroyed for the sake of that one righteous man, Job, over whom they made such a fool of me in old days! Yes, till the secret is revealed, there are two sorts of truths for me- one, their truth, yonder, which I know nothing about so far, and the other my own. And there's no knowing which will turn out the better.... Are you

asleep?"

  


## Part 12

     "I might well be," Ivan groaned angrily. "All my stupid ideas-

outgrown, thrashed out long ago, and flung aside like a dead carcass

you present to me as something new!" 

     "There's no pleasing you! And I thought I should fascinate you by my literary style. That hosannah in the skies really wasn't bad, was it? And then that ironical tone a la Heine, eh?"

     "No, I was never such a flunkey! How then could my soul beget a flunkey like you?"

     "My dear fellow, I know a most charming and attractive young Russian gentleman, a young thinker and a great lover of literature and art, the author of a promising poem entitled The Grand Inquisitor. I was only thinking of him!"

     "I forbid you to speak of The Grand Inquisitor," cried Ivan, crimson with shame.

     "And the Geological Cataclysm. Do you remember? That was a poem, now!"

  


## Part 13

     "Hold your tongue, or I'll kill you!"

     "You'll kill me? No, excuse me, I will speak. I came to treat myself to that pleasure. Oh, I love the dreams of my ardent young friends, quivering with eagerness for life! 'There are new men,' you decided last spring, when you were meaning to come here, 'they propose to destroy everything and begin with cannibalism. Stupid fellows! they didn't ask my advice! I maintain that nothing need be destroyed, that we only need to destroy the idea of God in man, that's how we have to set to work. It's that, that we must begin with. Oh, blind race of men who have no understanding! As soon as men have all of them denied God- and I believe that period, analogous with geological periods, will come to pass- the old conception of the universe will fall of itself without cannibalism, and, what's more, the old morality, and everything will begin anew. Men will unite to take from life all it can give, but only for joy and happiness in the present world. Man will be lifted up with a spirit of divine Titanic pride and the man-god will appear. From hour to hour extending his conquest of nature infinitely by his will and his science, man will feel such lofty joy from hour to hour in doing it that it will make up for all his old dreams of the joys of heaven. Everyone will know that he is mortal and will accept death proudly and serenely like a god. His pride will teach him that it's useless for him to repine at life's being a moment, and he will love his brother without need of reward. Love will be sufficient only for a moment of life, but the very consciousness of its momentariness will intensify its fire, which now is dissipated in dreams of eternal love beyond the grave'... and so on and so on in the same style. Charming!"

  


## Part 14

     Ivan sat with his eyes on the floor, and his hands pressed to his ears, but he began trembling all over. The voice continued.

     "The question now is, my young thinker reflected, is it possible that such a period will ever come? If it does, everything is determined and humanity is settled for ever. But as, owing to man's inveterate stupidity, this cannot come about for at least a thousand years, everyone who recognises the truth even now may legitimately order his life as he pleases, on the new principles. In that sense, 'all things are lawful' for him. What's more, even if this period never comes to pass, since there is anyway no God and no immortality, the new man may well become the man-god, even if he is the only one in the whole world, and promoted to his new position, he may lightheartedly overstep all the barriers of the old morality of the old slaveman, if necessary. There is no law for God. Where God stands, the place is holy. Where I stand will be at once the foremost place... 'all things are lawful' and that's the end of it! That's all very charming; but if you want to swindle why do you want a moral sanction for doing it? But that's our modern Russian all over. He can't bring himself to swindle without a moral sanction. He is so in love with truth-"

     The visitor talked, obviously carried away by his own eloquence, speaking louder and louder and looking ironically at his host. But he did not succeed in finishing; Ivan suddenly snatched a glass from the table and flung it at the orator.

     "Ah, mais c'est bete enfin,"* cried the latter, jumping up from the sofa and shaking the drops of tea off himself. "He remembers Luther's inkstand! He takes me for a dream and throws glasses at a dream! It's like a woman! I suspected you were only pretending to stop up your ears."

     * But after all, that's stupid.

  


## Part 15

     A loud, persistent knocking was suddenly heard at the window. Ivan jumped up from the sofa.

     "Do you hear? You'd better open," cried the visitor; "it's your brother Alyosha with the most interesting and surprising news, I'll be bound!"

     "Be silent, deceiver, I knew it was Alyosha, I felt he was coming, and of course he has not come for nothing; of course he brings 'news,'" Ivan exclaimed frantically.

     "Open, open to him. There's a snowstorm and he is your brother. Monsieur sait-il le temps qu'il fait? C'est a ne pas mettre un chien dehors."

     Does the gentleman know the weather he's making? It's not weather for a dog.

     The knocking continued. Ivan wanted to rush to the window, but something seemed to fetter his arms and legs. He strained every effort to break his chains, but in vain. The knocking at the window grew louder and louder. At last the chains were broken and Ivan leapt up from the sofa. He looked round him wildly. Both candles had almost burnt out, the glass he had just thrown at his visitor stood before him on the table, and there was no one on the sofa opposite. The knocking on the window frame went on persistently, but it was by no means so loud as it had seemed in his dream; on the contrary, it was quite subdued.

     "It was not a dream! No, I swear it was not a dream, it all happened just now!" cried Ivan. He rushed to the window and opened the movable pane.

     "Alyosha, I told you not to come," he cried fiercely to his brother. "In two words, what do you want? In two words, do you hear?"

     "An hour ago Smerdyakov hanged himself," Alyosha answered from the yard.

     "Come round to the steps, I'll open at once," said Ivan, going to open the door to Alyosha.

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=The_Grand_Inquisitor/Print_version&oldid=1314809](http://en.wikibooks.org/w/index.php?title=The_Grand_Inquisitor/Print_version&oldid=1314809)" 

[Category](/wiki/Special:Categories): 

  * [The Grand Inquisitor](/wiki/Category:The_Grand_Inquisitor)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=The+Grand+Inquisitor%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=The+Grand+Inquisitor%2FPrint+version)

### Namespaces

  * [Book](/wiki/The_Grand_Inquisitor/Print_version)
  * [Discussion](/w/index.php?title=Talk:The_Grand_Inquisitor/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/The_Grand_Inquisitor/Print_version)
  * [Edit](/w/index.php?title=The_Grand_Inquisitor/Print_version&action=edit)
  * [View history](/w/index.php?title=The_Grand_Inquisitor/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/The_Grand_Inquisitor/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/The_Grand_Inquisitor/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=The_Grand_Inquisitor/Print_version&oldid=1314809)
  * [Page information](/w/index.php?title=The_Grand_Inquisitor/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=The_Grand_Inquisitor%2FPrint_version&id=1314809)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=The+Grand+Inquisitor%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=The+Grand+Inquisitor%2FPrint+version&oldid=1314809&writer=rl)
  * [Printable version](/w/index.php?title=The_Grand_Inquisitor/Print_version&printable=yes)

  * This page was last modified on 24 October 2008, at 00:02.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/The_Grand_Inquisitor/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
