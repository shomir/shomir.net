# Probability/Print version

From Wikibooks, open books for an open world

< [Probability](/wiki/Probability)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

  


## Contents

  * 1 Introduction
    * 1.1 Types of probability
      * 1.1.1 Classical theory of probability
      * 1.1.2 Emperial or Statistical Probabilty or Frequency of occurrence
      * 1.1.3 Axiomatic probability theory
    * 1.2 About This Book
  * 2 The Counting Principle
    * 2.1 The Counting Principle
      * 2.1.1 Independent Events
        * 2.1.1.1 Practice Problems
        * 2.1.1.2 Answers
      * 2.1.2 Dependent Events
      * 2.1.3 Independent Or Dependent?
      * 2.1.4 Review Of The Counting Principle
    * 2.2 Counting Rules
  * 3 Probability Spaces
    * 3.1 Concept
    * 3.2 Formal Theory
      * 3.2.1 Set of Outcomes
      * 3.2.2 Probability Space Definition
      * 3.2.3 Explanation
      * 3.2.4 Other Definitions
      * 3.2.5 Further Concepts in Set Theory
      * 3.2.6 Permutations and Combinations
      * 3.2.7 Counting Rules
    * 3.3 Consequences
      * 3.3.1 Theorem 1
    * 3.4 **Axioms of Probability**
  * 4 Mathematical Review
    * 4.1 Elementary Set Operations
    * 4.2 Rules of Set Theory
    * 4.3 Cartesian Products
    * 4.4 Summary of Probability & Set Theory
  * 5 Combinatorics
    * 5.1 The Counting Principle
    * 5.2 Permutations
      * 5.2.1 Stirling's Formula
      * 5.2.2 k-Permutations
    * 5.3 Combinations
    * 5.4 Partitions
    * 5.5 Computing Probabilities
  * 6 Conditional Probability
    * 6.1 Examples
    * 6.2 Definition
  * 7 Random Variables
    * 7.1 Random Variables: Definitions
      * 7.1.1 Discrete variables
      * 7.1.2 Continuous variables
      * 7.1.3 Cumulative Distribution Function
      * 7.1.4 Independent variables
  * 8 Important Distributions
    * 8.1 Uniform Distribution
    * 8.2 Binomial Distribution
    * 8.3 The Poisson Distribution
    * 8.4 Normal Distribution
  * 9 Links

# Introduction

[Probability](/wiki/Probability) theory mathematically formulates incomplete knowledge pertaining to the likelihood of an occurrence. For example, a meteorologist might say there is a 60% chance that it will rain tomorrow. This means that in 6 of every 10 times when the world is in the current state, it will rain.

A _probability_ is a real number ![p \\in \[0,1\]](//upload.wikimedia.org/math/5/5/0/550abf67410399d394e58560a62f657a.png). In everyday speech, the number is usually expressed as a percentage (between 0% and 100%) rather than a decimal (i.e., a probability of 0.25 is expressed as 25%). A probability of 100% means that an event is certain. In everyday speech, probability of 0% is taken to mean that the event is impossible, but (usually in where there are an infinity of possible outcomes) an event originally ascribed a probability of 0% MAY be the one that occurs. In some situations, it is CERTAIN that the event which occurs will be one that originally was ascribed zero probability (for example, in selecting a number uniformly between 0 and 1, the probability of selecting any given number is zero, but it is certain that one such number will be selected).

Another way of referring to probability of an outcome is by its _odds_: the ratio of the probability of "success" (event occurs) to the probability of "failure" (event does not occur). In the gambling world (where "odds" evolved) odds are expressed as the ratio of the STAKES risked by each participant in a wager. For instance: a bookmaker offering odds of 3/1 "against" a horse will pay a punter three times their stake (if the horse wins). In fact, the bookmaker (ignoring factors such as his potential need to "lay off" bets which are exposing him to the possibility of an unacceptable overall loss) is announcing that he thinks the horse has a 1/4 chance of winning. Using the mathematical definition of odds, "chance of winning" : " chance of not winning" = 1/4 : 3/4 = 1:3 or 1/3. So an event with a probability of 25% has odds of 33%. This disparity is even more clear where an event has a probability of 50% (e.g., the ODDS of a coin showing heads is 50%:50% = 1:1 or 1).

## Types of probability

There are basically four types of probabilities, each with its limitations. None of these approaches to probability is wrong, _per se_, but some are more useful or more general than others.

In everyday speech, we express our beliefs about likelihoods of events using the same terminology as in probability theory. Often, this has nothing to do with any formal definition of probability, rather it is an intuitive idea guided by our experience, and in some cases statistics.

Consider the following examples:

  * Bill says "Don't buy the avocados here; about half the time, they're rotten". Bill is expressing his belief about the probability of an event — that an avocado will be rotten — based on his personal experience.
  * Lisa says "I am 95% certain the capital of Spain is Barcelona". Here, the belief Lisa is expressing is only a probability from her point of view, because only she does not know that the capital of Spain is Madrid (from our point of view, the probability is 100%). However, we can still view this as a subjective probability because it expresses a measure of uncertainty. It is as though Lisa is saying "in 95% of cases where I feel as sure as I do about this, I turn out to be right".
  * Susan says "There is a lower chance of being shot in Omaha than in Detroit". Susan is expressing a belief based (presumably) on statistics.
  * Dr. Smith says to Christina, "There is a 75% chance that you will live." Dr. Smith is basing this off of his research.

Probability can also be expressed in vague terms. For example, someone might say it will probably rain tomorrow. This is subjective, but implies that the speaker believes the probability is greater than 50%.

Subjective probabilities have been extensively studied, especially with regards to gambling and securities markets. While this type of probability is important, it is not the subject of this book. A good reference is "Degrees of Belief" By Steven Vick (2002).

There are two standard approaches to conceptually interpreting probabilities. The first is known as the long run (or the relative frequency approach) and the subjective belief (or confidence approach). In the Frequency Theory of Probability, probability is the limit of the relative frequency with which an event occurs in repeated trials (note that trials must be independent).

Frequentists talk about probabilities only when dealing with experiments that are random and well-defined. The probability of a random event denotes the relative frequency of occurrence of an experiment's outcome, when repeating the experiment. Frequentists consider probability to be the relative frequency "in the long run" of outcomes.

Physical probabilities, which are also called objective or frequency probabilities, are associated with random physical systems such as roulette wheels, rolling dice and radioactive atoms. In such systems, a given type of event (such as the dice yielding a six) tends to occur at a persistent rate, or 'relative frequency', in a long run of trials. Physical probabilities either explain, or are invoked to explain, these stable frequencies. Thus talk about physical probability makes sense only when dealing with well defined random experiments. The two main kinds of theory of physical probability are frequentist accounts (such as Venn) and propensity accounts.

Relative frequencies are always between 0% (the event essentially never happens) and 100% (the event essentially always happens), so in this theory as well, probabilities are between 0% and 100%. According to the Frequency Theory of Probability, what it means to say that "the probability that A occurs is p%" is that if you repeat the experiment over and over again, independently and under essentially identical conditions, the percentage of the time that A occurs will converge to p. For example, under the Frequency Theory, to say that the chance that a coin lands heads is 50% means that if you toss the coin over and over again, independently, the ratio of the number of times the coin lands heads to the total number of tosses approaches a limiting value of 50% as the number of tosses grows. Because the ratio of heads to tosses is always between 0% and 100%, when the probability exists it must be between 0% and 100%.

In the Subjective Theory of Probability, probability measures the speaker's "degree of belief" that the event will occur, on a scale of 0% (complete disbelief that the event will happen) to 100% (certainty that the event will happen). According to the Subjective Theory, what it means for me to say that "the probability that A occurs is 2/3" is that I believe that A will happen twice as strongly as I believe that A will not happen. The Subjective Theory is particularly useful in assigning meaning to the probability of events that in principle can occur only once. For example, how might one assign meaning to a statement like "there is a 25% chance of an earthquake on the San Andreas fault with magnitude 8 or larger before 2050?" (See Freedman and Stark, 2003, for more discussion of theories of probability and their application to earthquakes.) It is very hard to use either the Theory of Equally Likely Outcomes or the Frequency Theory to make sense of the assertion.

Bayesians, however, assign probabilities to any statement whatsoever, even when no random process is involved. Probability, for a Bayesian, is a way to represent an individual's degree of belief in a statement, given the evidence.

Evidential probability, also called Bayesian probability, can be assigned to any statement whatsoever, even when no random process is involved, as a way to represent its subjective plausibility, or the degree to which the statement is supported by the available evidence. On most accounts, evidential probabilities are considered to be degrees of belief, defined in terms of dispositions to gamble at certain odds. The four main evidential interpretations are the classical interpretation, the subjective interpretation, the epistemic or inductive interpretation, and the logical interpretation.

### Classical theory of probability

The classical approach to probability is to count the number of _favorable outcomes_, the number of _total outcomes_ (outcomes are assumed to be mutually exclusive and equiprobable), and express the probability as a ratio of these two numbers. Here, "favorable" refers not to any subjective value given to the outcomes, but is rather the classical terminology used to indicate that an outcome belongs to a given event of interest. What is meant by this will be made clear by an example, and formalized with the introduction of axiomatic probability theory.

Classical definition of probability

If the number of outcomes belonging to an event ![E](//upload.wikimedia.org/math/3/a/3/3a3ea00cfc35332cedf6e5e9a32e94da.png) is ![N_{E}](//upload.wikimedia.org/math/4/3/d/43d03255169b79cbb07abd8173bcf14d.png), and the total number of outcomes is ![N](//upload.wikimedia.org/math/8/d/9/8d9c307cb7f3c4a32822a51922d1ceaa.png), then the _probability_ of event ![E](//upload.wikimedia.org/math/3/a/3/3a3ea00cfc35332cedf6e5e9a32e94da.png) is defined as ![p_{E} = \\frac{N_{E}}{N}](//upload.wikimedia.org/math/2/8/f/28f4043ad636b09eda7f7287a8bea18b.png).

For example, a standard deck of cards (without jokers) has 52 cards. If we randomly draw a card from the deck, we can think of each card as a possible outcome. Therefore, there are 52 total outcomes. We can now look at various events and calculate their probabilities:

  * Out of the 52 cards, there are 13 clubs. Therefore, if the event of interest is drawing a club, there are 13 favorable outcomes, and the probability of this event is ![\\frac{13}{52} = \\frac{1}{4}](//upload.wikimedia.org/math/9/8/9/9894aaefb11ab596ab67d821daf71368.png).
  * There are 4 kings (one of each suit). The probability of drawing a king is ![\\frac{4}{52} = \\frac{1}{13}](//upload.wikimedia.org/math/b/f/9/bf9dddc1576b2537bfa734a157676713.png).
  * What is the probability of drawing a king OR a club? This example is slightly more complicated. We cannot simply add together the number of outcomes for each event separately (![4 + 13 = 17](//upload.wikimedia.org/math/a/7/e/a7eff58bf1445ea2cad5130062e1a7fe.png)) as this inadvertently counts one of the outcomes twice (the king of clubs). The correct answer is ![\\frac{16}{52}](//upload.wikimedia.org/math/2/7/3/273ec459469232bef5e3c10e860ca6b7.png) from ![\\frac{13}{52}+\\frac{4}{52}-\\frac{1}{52}](//upload.wikimedia.org/math/9/b/3/9b3b5edf54e79627a836e543fd18494b.png) where this is essentially ![p\(\\textrm{club}\)+p\(\\textrm{king}\)-p\(\\textrm{king\\ of\\ clubs}\)](//upload.wikimedia.org/math/8/a/f/8af9128431cc2bf558af4f9d9374ed83.png).

Classical probability suffers from a serious limitation. The definition of probability implicitly defines all outcomes to be equiprobable. While this might be useful for drawing cards, rolling dice, or pulling balls from urns, it offers no method for dealing with outcomes with unequal probabilities.

This limitation can even lead to mistaken statements about probabilities. An often given example goes like this:

    I could be hit by a meteor tomorrow. There are two possible outcomes: I will be hit, or I will not be hit. Therefore, the probability I will be hit by a meteor tomorrow is ![\\frac{1}{2} = 50%](//upload.wikimedia.org/math/a/2/5/a25112225cb3b18518706cd2e110c17f.png).

Of course, the problem here is not with the classical theory, merely the attempted application of the theory to a situation to which it is not well adapted.

This limitation does not, however, mean that the classical theory of probability is useless. At many points in the development of the axiomatic approach to probability, classical theory is an important guiding factor.

### Emperial or Statistical Probabilty or Frequency of occurrence

This approach to probability is well-suited to a wide range of scientific disciplines. It is based on the idea that the underlying probability of an event can be measured by repeated trials.

Emperial or Statistical Probability as a measure of frequency

Let ![n_{A}](//upload.wikimedia.org/math/b/a/a/baac39c7d1aa05bbdf9d5990259eb6da.png) be the number of times event ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) occurs after ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) trials. We define the _probability_ of event ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png) as 

![p_{A} = \\lim_{n\\to \\infty}\\frac{n_{A}}{n}](//upload.wikimedia.org/math/7/c/a/7ca9d9f2d37f2c7ac5e976b31182f0dc.png)

It is of course impossible to conduct an infinite number of trials. However, it usually suffices to conduct a large number of trials, where the standard of large depends on the probability being measured and how accurate a measurement we need.

A note on this definition of probability: How do we know the sequence ![\\frac{n_{A}}{n}](//upload.wikimedia.org/math/3/e/e/3ee8831aac1b8e8fa6cd7b3fa30dc65f.png) in the limit will converge to the same result every time, or that it will converge at all? The unfortunate answer is that we don't. To see this, consider an experiment consisting of flipping a coin an infinite number of times. We are interested in the probability of heads coming up. Imagine the result is the following sequence:

    _HTHHTTHHHHTTTTHHHHHHHHTTTTTTTTHHHHHHHHHHHHHHHHTTTTTTTTTTTTTTTT_...

with each run of ![k](//upload.wikimedia.org/math/8/c/e/8ce4b16b22b58894aa86c421e8759df3.png) heads and ![k](//upload.wikimedia.org/math/8/c/e/8ce4b16b22b58894aa86c421e8759df3.png) tails being followed by another run twice as long. For this example, the sequence ![\\frac{n_{A}}{n}](//upload.wikimedia.org/math/3/e/e/3ee8831aac1b8e8fa6cd7b3fa30dc65f.png) oscillates between roughly ![\\frac{1}{3}](//upload.wikimedia.org/math/e/3/c/e3c84416f9085bb72f7db037d93dce15.png) and ![\\frac{2}{3}](//upload.wikimedia.org/math/c/d/1/cd1820f286fec69f1c54a381d8fa7d93.png) and doesn't converge.

We might expect such sequences to be unlikely, and we would be right. It will be shown later that the probability of such a run is 0, as is a sequence that converges to anything other than the underlying probability of the event. However, such examples make it clear that the limit in the definition above does not express convergence in the more familiar sense, but rather some kind of convergence in probability. The problem of formulating exactly what this means belongs to axiomatic probability theory.

### Axiomatic probability theory

Axiomatic probability theory, although it is often frightening to beginners, is the most general approach to probability, and has been employed in tackling some of the more difficult problems in probability. We start with a set of axioms, which serve to define a **probability space**. Although these axioms may not be immediately intuitive, be assured that the development is guided by the more familiar classical probability theory.

Let S be the sample space of a random experiment. The probability P is a real valued function whose domain is the power set of S and range is the interval [0,1] satisfying the following axioms:

(i) For any event E, P (E) ≥ 0

(ii) P (S) = 1

(iii) If E and F are mutually exclusive events, then P(E ∪ F) = P(E) + P(F).

It follows from (iii) that P(φ) = 0. To prove this, we take F = φ and note that E and φ are disjoint events. Therefore, from axiom (iii), we get P (E ∪ φ) = P (E) + P (φ) or P(E) = P(E) + P (φ) i.e. P (φ) = 0. Let S be a sample space containing outcomes ω1 , ω2 ,...,ωn , i.e., S = {ω1, ω2, ..., ωn}

It follows from the axiomatic definition of probability that:

(i) 0 ≤ P (ωi) ≤ 1 for each ωi ∈ S

(ii) P (ω1) + P (ω2) + ... + P (ωn) = 1

(iii) For any event A, P(A) = Σ P(ωi ), ωi ∈ A.

## About This Book

This book is going to discuss the topic of **mathematical probability** using [Calculus](/wiki/Calculus) and [Abstract Algebra](/wiki/Abstract_Algebra). Readers of this book should have a good understanding of both those topics before attempting to read and understand this book completely.

  


# The Counting Principle

## The Counting Principle

Before we can delve into the properties of probability and odds, we need to understand the **Counting Principle**. We use the Counting Principle to determine how many different ways one can choose/do certain events. It is easier to define the Principle through examples:

### Independent Events

Let's say that John is at a deli sub restaurant. There are 3 different breads, 3 different cheeses, 3 different condiments, and 3 different vegetables he can place on his sandwich, assuming that he can only place one from each category on to his sandwich. How many different ways can he set up his sandwich?

Since choosing a cheese doesn't affect the amount of choices of vegetables, condiments, or bread, these events are called **independent events**. For this problem, we will multiply 3 by 3 by 3 by 3, so ![3^4](//upload.wikimedia.org/math/1/1/7/11763f599762489923cb4bee6a8da30a.png), which is 81. So there are 81 different possible combinations to form this sandwich.

#### Practice Problems

1) Thomas goes to a McDonalds' restaurant and chooses to create his own burger. He has 2 different kinds of cheese, 3 different breads, and 3 different sauces he can choose from, but he can only choose one of each category. How many different ways can he create this burger?

2) Diane is ordering pizza for her family. There are 4 different possible sizes of the pizza. Also, she has to choose one of 5 toppings to place on the pizza and one of 3 different types of cheese for the pizza. In addition, she must choose one of 3 different kinds of crust. How many different ways can she have her pizza?

3)a) How many 3-digit numbers can be formed from the digits 2, 3, 4, 5, 7 and 9?

b) How many of these numbers are less than 400?

#### Answers

1) ![\(2\)\(3\)\(3\) = 18](//upload.wikimedia.org/math/c/0/3/c03b731676a086592a56ebcad2998db0.png)

2) ![\(4\)\(5\)\(3\)\(3\) = 180](//upload.wikimedia.org/math/d/b/7/db77d06907dd35770092b7976f35416f.png)

3) a) Since there are six available digits, the answer is ![ \(6\)\(6\)\(6\) = 216 ](//upload.wikimedia.org/math/f/c/d/fcdb11c4539ee6fa26650f335612ef8d.png)

b) For the value of the 3-digit number to be less than 400, we only have two choices for the first digit, namely 2 or 3. After that we can choose the other two digits freely. The answer is thus ![ \(2\)\(6\)\(6\) = 72 ](//upload.wikimedia.org/math/7/e/b/7eb5e464c6b87ae509c5a0edcb24578a.png).

### Dependent Events

Assume that John is now working at a library. He must put 5 books on a shelf in any order. How many different ways can he order the books on the shelf? Unlike the independent events, when John puts a book on the shelf, that eliminates one book from the remaining choices of books to put next on the shelf; thus these are referred to as **dependent events**. At first, he has 5 different choices, so our first number in the multiplication problem will be 5. Now that one is missing, the number is reduced to 4. Next, it's down to 3, and so on. So, the problem will be

![\(5\)\(4\)\(3\)\(2\)\(1\)](//upload.wikimedia.org/math/a/2/d/a2d01398e7dca64d00a1223ceef83d6a.png)

However, there is a symbol for this very idea. A _!_ represents the term _factorial_. So, for example, ![3! = \(3\)\(2\)\(1\)](//upload.wikimedia.org/math/3/c/f/3cffca668c2523b100acdb7787de6f91.png). Factorials are very useful in statistics and probability.

Therefore, the problem can be rewritten as 5!, which ends up being equal to 120.

However, not all dependent event problems are that simple. Let's say that there are 10 dogs at a dog competition. How many different ways can one select the Champion AND the Runner-Up? This problem could actually be considered simpler than the last one, but it doesn't involve a factorial. So, how many different ways can the judge determine the Champion? Of course, there are 10 different dogs, so 10 different ways. Next, how many dogs are left to select the Runner-Up from? Well, you removed one, so it's down to 9. Instead of placing a factorial, though, you will only multiply 10 and 9, resulting in 90.

### Independent Or Dependent?

To help you differentiate between the two, we will do a few more examples, but we will have to decide if it is dependent or independent before solving the problem.

Let's say that you are creating a 5-digit garage door opener code (the digits would include 0-9). If there were absolutely no restrictions, would the events be independent of each other or dependent on each other? Of course, there are no restrictions, since you could have five 4's for the code, so to solve the problem, you multiply 10 by itself 5 times, resulting in 100000.

Alternatively, suppose that the first number of the code cannot be 0, and that there can be no repeated numbers whatsoever. Obviously these events are dependent on each other, because there cannot be any repetitions. Let's look at this problem one number at a time.

The first number can be all the numbers except 0, reducing the possible amount to 9. The second number **can** be 0 this time, so the possible amount returns to 10. However, it cannot be a repeat of the previous number, so there are 9 possible choices again. After that, the numbers will reduce by one each time, due to the fact that there cannot be repeats, so the problem would look like this

![\(9\)\(9\)\(8\)\(7\)\(6\) = \(9\)\(9!\)/\(5!\) = 27216](//upload.wikimedia.org/math/d/f/e/dfe19b6a07691ed501c4e418f4e11fdc.png)

Now, just one more example. Let's say that you were choosing your schedule for school. There are 8 periods each day, and there are 7 classes to choose from. Nonetheless, you must have a lunch period during the 4th period. We can think of 4th period as non existent because it is in a constant position and therefore does not affect the possible choices. With 7 slots and 7 options, the answer is simply 7!.

![\(7!\) = 5040](//upload.wikimedia.org/math/c/3/4/c3477cc62751c910c6e153b12b85cec5.png)

### Review Of The Counting Principle

So, we use the Counting Principle to determine the different unique ways we can do something, such as a sandwich or a selection of classes. Sometimes, these events will affect each other, such as when you can't choose the same number twice for your garage door code, so they are dependent events. However, other times, one event has no effect on the next event, such as when you have different cheeses and breads to choose for your sandwich, so they are independent events. The Counting Principle is a fundamental mathematical idea and an essential part of probability.

## Counting Rules

**Rule 1:** If any one of _K_ mutually exclusive and exhaustive events can occur on each of _N_ trials, there are _K^N_ different sequences that may result from a set of such trials. Example: Flip a coin three times, finding the number of possible sequences. N=3, K=2, therefore, K^N =2^3=8

**Rule 2:** If K1, K2, ....KN are the numbers of distinct events that can occur on trials 1,...._N_ in a series, the number of different sequences of _N_ events that can occur is (K1)(K2)...(KN). Example: Flip a coin and roll a die, finding the number of possible sequences. Therefore, (K1)(K2) = (2)(6) = 12

**Rule 3:** The number of different ways that _N_ distinct things may be arranged in order is N! = (1)(2)(3)....(N-1)(N), where 0! = 1. An arrangement in order is called a permutation, so that the total number of permutations of _N_ objects is N! (the symbol N! Is called N-factorial). Example: Arrange 10 items in order, finding the number of possible ways. Therefore, 10! = 10x9x8x7x6x5x4x3x2x1 = 3,628,800

**Rule 4:** The number of ways, _N_, of selecting and arranging _r_ objects from among _N_ distinct objects is: N!/(N-r)!, or as seen on calculators, [nPr]. Example: pick 3 things from 10 items, and arrange them in order. Therefore N=10, r=3, so 10!/(10-3)! = 10!/7! = 720

**Rule 5:** The total number of ways of selecting _r_ distinct combinations of _N_ objects, irrespective of order (ie order NOT important), is: N!/r!(N-r)! or as seen on calculators, [nCr]. Example: Pick 3 items from 10 in any order, where N=10, r=3. Therefore, 10!/3!(7!) = 720/6 = 120

  


# Probability Spaces

## Concept

Although we came up with a basic definition of probability in the previous chapter, we will now proceed to develop a more axiomatic theory. Our theory will avoid the ambiguities of probability, and allow for a simpler mathematical formalism. We shall proceed by developing the concept of probability space, which will allow us to harness many theorems in mathematical analysis.

## Formal Theory

### Set of Outcomes

The set of all possible outcomes is called the sample space, denoted by Ω. For every problem, you must pick an appropriate sample space. This is important because we can´t make any conclusions about the probability of an event if we don´t know the exact size of the sample space. In a coin toss the states could be “Heads” and “Tails”. For a die there could be one state for each side of the die. We have a probability function that specifies the probability of each state. Events are sets of states. In the die example an event could be rolling an even number.

### Probability Space Definition

A _Probability Space_ consists of (Ω,S,P) where ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png) is a non-empty set, called the _sample space_, its elements are called the _outcomes_, ![S \\subset \\mbox{Power}\(\\Omega\)](//upload.wikimedia.org/math/b/8/0/b809041e22707d38980e35f629cf298b.png), containing the _events_, and P is a function ![S \\rightarrow \\R](//upload.wikimedia.org/math/2/a/d/2adf6bd91820b20f5797cb5c13f8e1c9.png), called _probability_, satisfying the following axioms

  1. S is such that combining events, even an infinite number, will result in an event, i.e. stay within S (formally S should be a σ-algebra);
  2. For all ![E\\in S](//upload.wikimedia.org/math/5/8/a/58a4389e21f0cb4ee585c1ba28c7bc86.png), ![0\\le P\(E\)\\le 1](//upload.wikimedia.org/math/2/2/e/22eea7dd4db25827152938bbb9bc1520.png) This states that for every event E, the probability of E occurring is between 0 and 1 (inclusive).
  3. ![P\(\\Omega\)=1](//upload.wikimedia.org/math/5/0/5/5059c4b44edc70592ad6f44b8fa32fb3.png) This states that the probability all the possible outcomes in the sample space is 1. (P is a normed measure.)
  4. If ![ \\{ E_1,E_2, \\ldots \\} ](//upload.wikimedia.org/math/2/5/4/25445d845a3969a5b1bad3df837eae23.png) is countable and ![ i\\ne j\\ \\Rightarrow E_i \\cap E_j = \\empty](//upload.wikimedia.org/math/4/5/d/45d5d8a5d6a121491985e6304d6fa6eb.png), then ![ P\(\\bigcup E_i\)=\\sum P\(E_i\)](//upload.wikimedia.org/math/4/c/b/4cba920d7b9a98f9f7a7db6c2b6d690a.png). This states that if you have a group of events (each one denoted by E and a subscript), you can get the probability that some event in the group will occur by summing the individual probabilities of each event. This holds if and only if the events are disjoint.

### Explanation

Ω is called the sample space, and is a set of all the possible outcomes. Outcomes are all the possibilities of what can occur, where only one occurs. S is the set of events. Events are sets of outcomes, and they occur when any of their outcomes occur. For example rolling an even number might be an event, but it will consist of the outcomes 2,4, and 6. The probability function gives a number for each event, and the probability that something will occur is 1.

E.g, when tossing a single coin Ω is {H,T} and possible events are {}, {H}, {T}, and {H,T}. Intuitively, the probability of each of these sets is the chance that one of the events in the set will happen; P({H}) is the chance of tossing a head, P({H,T}) = 1 is the chance of the coin landing either heads or tails, P{} = 0 is the probability of the coin landing **neither** heads **nor** tails, etc.

### Other Definitions

Mutually exclusive
    two or more events that can NOT occur at the same time; have no outcomes in common. Events are mutually exclusive if they cannot both occur simultaneously. Events are said to be mutually exclusive if the occurence of any one event automatically implies the non-occurence of the remaining n-1 events. Mutually exclusive events have the property in which Pr(A ∩ B) = 0. Also, when A and B are mutually exclusive events, P(A or B) = P(A) + P(B). In short, this implies that at most, one of the events may occur. In terms of statistics, the definition of mutually exclusive is: A property of a set of categories such that an individual or object is included in only one category. The occurrence of one event means that none of the other events can occur at the same time.

(Collectively) Exhaustive
    events are said to be collectively exhaustive, which means that at least one of the events must occur. A set is jointly or exhaustive if at least one of the events must occur. Another way to describe collectively exhaustive events, is that their union must cover all the events within the entire sample space. For example, events A and B are said to be collectively exhaustive if where S is the sample space.

Test of Independence
    If for two events A and B, p(A ∩ B) is not equal to p(A)p(B), then A and B are said to be associated or dependent. If p(A ∩ B) > p(A)p(B), so that p(A|B) > p(A) and p(B|A) > p(B), then the events are said to be positively associated (answer to question #2 above). If, however, p(A ∩ B) < p(A)p(B), so that p(A|B) <p(A) and p(B|A) < p(B), one says that the events are negatively associated.

Simple Random Sampling
    In a simple random sample, one person must take a random sample from a population, and not have any order in which one chooses the specific individual. In statistics, a simple random sample is a subset of individuals (a sample) chosen from a larger set (a population). Each individual is chosen randomly and entirely by chance, such that each individual has the same probability of being chosen at any stage during the sampling process, and each subset of k individuals has the same probability of being chosen for the sample as any other subset of k individuals. Simple random sampling can be done with or without replacement, though it is typically done without, i.e., one deliberately avoids choosing any member of the population more than once. When the sample is drawn with replacement, the same individual can be chosen more than once. When the sample is drawn without replacement, the same individual can be chosen no more than once in a given sample. Therefore, random sampling of one individual at a time means that every possible individual in the large group has an equal probability of being drawn.

Independence of random variables
    If X is a real-valued random variable and a is a number then the event {X ≤ a} is the set of outcomes that correspond to X being less than or equal to a. Since these are sets of outcomes that have probabilities, it makes sense to refer to events of this sort being independent of other events of this sort.

Why are the p and q Bernoulli trial probabilities multiplied together in the binomial formula? The probability of an event can be expressed as a binomial probability if its outcomes can be broken down into two probabilities p and q, where p and q are complementary (i.e. p + q = 1). Binomial probability typically deals with the probability of several successive decisions, each of which has two possible outcomes. The binomial distribution is the discrete probability distribution of the number of successes in a sequence of n independent yes/no experiments, each of which yields success with probability p. Such a success/failure experiment is also called a Bernoulli experiment or Bernoulli trial. In fact, when n = 1, the binomial distribution is a Bernoulli distribution. Bernoulli process is a discrete-time stochastic process consisting of a sequence of independent random variables taking values over two symbols. Prosaically, a Bernoulli process is coin flipping several times, possibly with an unfair coin. A variable in such a sequence may be called a Bernoulli variable. In other words, a Bernoulli process is a sequence of independent identically distributed Bernoulli trials. Independence of Bernoulli trials implies memorylessness property: past trials do not provide any information regarding future outcomes. From any given time, future trials is also a Bernoulli process independent of the past (fresh-start property). a sequence or other collection of random variables is independent and identically distributed (i.i.d.) if each random variable has the same probability distribution as the others and all are mutually independent. Two events A and B are independent if and only if Pr(A ∩ B) = Pr(A)Pr(B). Here A ∩ B is the intersection of A and B, that is, it is the event that both events A and B occur. This is called the multiplication rule for independent events.

Universal Set
    all the elements for any specific discussion, and is symbolized by the symbol U.
    Example: U = {A,E,I,O,U}

Intersection
    the elements 2 or more sets and is denoted by the symbol, ∩.

Union
    elements in two or more sets and is denoted by the symbol, ∪.

Complement
    all the elements in the universal set that not the original set and is denoted by the symbol, ′. Sometimes represented also by the symbol, ~, meaning "not" (i.e. p(AU~B) denotes "A union NOT B".
    Example: 

    U = {1,2,3,4,5,6,7,8,9,0}; A= {1,2,3,}; B = {2,3,4,5,6}
    A ∩ = {2,3,}
    A ∪ = {1,2,3,4,5,6}
    A′ = {4,5,6,7,8,9,0} B′={1,7,8,9,0}

Empty or Null Set
    a set that contains no elements and are denoted by the symbols { }, ∅. This means that the event probability in question is impossible and thus, cannot occur.

### Further Concepts in Set Theory

Union and intersection: We can indicate the union and intersection of two sets with the symbols ∪ ∩, respectively. If two sets, then ∪ the set “”―the set that consists of all the elements that are either in set in set . Similarly, ∩ read “”, which is the set of all elements that are in both .

Set difference. We can “subtract” one set from another using the symbol “－”. If sets, then － the set consisting of all the elements that are members of are not members of . This is a little different from the subtraction you may be used to in arithmetic.

Whole numbers: 1. Non-negative integers (aka real numbers) – {0, 1, 2, 3...} 2. Positive integers – {1, 2, 3, 4....} 3. All possible integers – {-3, -2, -1, 0, 1, 2, 3...}

AND --> 2 or more things/events happen. Therefore, we MULTIPLY (product) probabilities together -- INTERSECTION OR --> 1 of the 2 events/things occur. Therefore we ADD (sum) probabilities together -- UNION

Events that are NOT mutually exclusive means we could draw them both (for example, we want to draw a 2 OR an 'M'...these events are NOT mutually exclusive, because they cannot occcur together at the same time).

Events that are NOT mutually exclusive, but rather are independent, we must subtract: 1-p(A∩B) from p(A) + p(B). So that, p(A) + p(B) -1 p(A∩B).

Probabilities for independent events often involve exponents, and probabilities for dependent events (conditional probability) often involve factorials.

### Permutations and Combinations

Permutations
    arrangement of objects without repetition where order is important. Permutations using all the objects: n objects, arranged into group size of n without repetition, and order being important – P(n, n) = N!
    Example: Find all permutations of A, B, C.

Permutations of some of the objects: n objects, group size r, order is important. P(n, r) = N!/(n-r)! Example: Find all 2-letter combinations using letters A, B, C.

Distinguished permutations
    if a word has n letters, k of which are unique, let n (n1, n2, n3....nk) be the frequency of each of the k letters. N!/(n1!)(n2!)(n3!)

Combinations
    arrangement of objects without repetition, where order is NOT important. A combination of n objects, arranged in groups of size r, without repetition, and order being important. C(n, r) = N!/r!(n-r)!

Another way to write a combination of n things, r at a time, is using the Binomial notation (Binomial Distribution), sometimes described as "n choose r".

### Counting Rules

Rule 1
    If any one of K mutually exclusive and exhaustive events can occur on each of N trials, there are KN different sequences that may result from a set of such trials
    Example: Flip a coin three times, finding the number of possible sequences. N=3, K=2, therefore, KN =23=8

Rule 2
    If K1, K2, ....KN are the numbers of distinct events that can occur on trials 1,....N in a series, the number of different sequences of N events that can occur is (K1)(K2)...(KN)
    Example: Flip a coin and roll a die, finding the number of possible sequences. Therefore, (K1)(K2) = (2)(6) = 12

Rule 3
    The number of different ways that N distinct things may be arranged in order is N! = (1)(2)(3)....(N-1)(N), where 0! = 1. An arrangement in order is called a permutation, so that the total number of permutations of N objects is N! (the symbol N! Is called N-factorial)
    Example: Arrange 10 items in order, finding the number of possible ways. Therefore, 10! = 10x9x8x7x6x5x4x3x2x1 = 3628800

Rule 4
    The number of ways of selecting and arranging r objects from among N distinct obejects is: N!/(N-r)! [nPr]
    Example: pick 3 things from 10 items, and arrange them in order. Therefore N=10, r=3, so 10!/(10-3)! = 10!/7! = 720

Rule 5
    The total number of ways of selecting r distinct combinations of N objects, irrespective of order (ie order NOT important), is: N!/r!(N-r)! [nCr]
    Example: Pick 3 items from 10 in any order, where N=10, r=3. Therefore, 10!/3!(7!) = 720/6 = 120

## Consequences

We can now give some basic theorems using our axiomatic probability space.

### Theorem 1

Given a probability space (Ω,S,P), for events ![A,B\\in S](//upload.wikimedia.org/math/b/b/8/bb89d2c6f9a31b237dfd4155d1135308.png):

    ![P\(A\\cup B\)=P\(A\)+P\(B\)-P\(A\\cap B\)](//upload.wikimedia.org/math/3/3/0/330f93fe8ccc450d0a84f92189ebca2e.png)

  


## **Axioms of Probability**

A probability function has to satisfy the following three basic axioms or constraints: To each event a a measure (number) P(a) which is called the probability of event a is assigned. P(a) is subjected to the following three axioms:

  1. P(a) ≥ 0
  2. P(S) = 1
  3. If a∩b = 0 , then P(a∪b) = P(a)+ P(b)

Corollaries

  * P(0) = 0
  * P(a) = 1－ P(a)≤ 1
  * If a ∩b ≠ 0 , then P(a ∪ b) = P(a)+ P(b) － P(a ∩ b)
  * If b ⊂ a , P(a) = P(b)+ P(a ∩ b)≥ P(b)

  


# Mathematical Review

The review of set theory contained herein adopts a naive point of view. We assume that the meaning of a set as a collection of objects is intuitively clear. A rigorous analysis of the concept belongs to the foundations of mathematics and mathematical logic. Although we shall not initiate a study of these fields, the rules we follow in dealing with sets are derived from them. A _set_ is a collection of objects, which are the _elements_ of the set.

![Basicset.png](//upload.wikimedia.org/wikibooks/en/7/76/Basicset.png)

If an element x belongs to a set S, we express this fact by writing ![x \\in S](//upload.wikimedia.org/math/a/d/9/ad92626fcd8accdf2864b83d1e37ee64.png). If x does not belong to S, we write ![x \\notin S](//upload.wikimedia.org/math/5/7/d/57da6751556c646418e796f197da73be.png). We use the equality symbol to denote _logical identity_. For instance, x = y means that x and y are symbols denoting the same object. Similarly, the equation S = T states that S and T are two symbols for the same set. In particular, the sets S and T contain precisely the same elements. If x and y are different objects then we write ![x \\neq y](//upload.wikimedia.org/math/7/3/c/73c7070fbc887c38daea22738774c01c.png). Also, we can express the fact that S and T are different sets by writing ![S \\neq T](//upload.wikimedia.org/math/6/d/5/6d557dbd0bdc2bf9fafdb3a101b55c5f.png).

A set S is a _subset_ of T if every element of S is also contained in T. We express this relation by writing ![S \\subset T](//upload.wikimedia.org/math/b/0/a/b0abdb4fabde68b531cfa6d9b6f490c2.png). Note that this definition does not require S to be different from T. In fact, S = T if and only if ![S \\subset T](//upload.wikimedia.org/math/b/0/a/b0abdb4fabde68b531cfa6d9b6f490c2.png) and ![T \\subset S](//upload.wikimedia.org/math/b/c/8/bc8d66b4f9d8b9ce9e7632a20b7a072b.png). If ![S \\subset T](//upload.wikimedia.org/math/b/0/a/b0abdb4fabde68b531cfa6d9b6f490c2.png) and S is different from T, then S is a _proper subset_ of T and we write ![S \\subsetneq T](//upload.wikimedia.org/math/d/a/c/dacb56284751bd43cb8aa309b0232e44.png).

There are many ways to specify a set. If the set contains only a few elements, one can simply list the objects in the set;

![
S = \\{ x_1, x_2, x_3 \\} .
](//upload.wikimedia.org/math/4/a/8/4a888f79781fcd263958cfe29edea50b.png)

The content of a set can also be enumerated whenever S has a countable number of elements,

![
S = \\{ x_1, x_2, \\ldots \\} .
](//upload.wikimedia.org/math/8/8/f/88ffa59237da1ab41506953c952f1a7e.png)

Usually, the way to specify a set is to take some collection S of objects and some property that elements of S may or may not possess, and to form the set consisting of all elements of S having that property. For example, starting with the integers ![\\mathbb{Z}](//upload.wikimedia.org/math/0/b/1/0b100eeff3848a15dbb46291e7fe52ad.png), we can form the subset of S consisting of all even numbers

![
S = \\{ x \\in \\mathbb{Z} | x \\mbox{ is an even number} \\}.
](//upload.wikimedia.org/math/3/9/a/39acefdab3dcd70038238cf0021016cb.png)

More generally, we denote the set of all elements that have a certain property P by

![
S = \\{ x | x \\mbox{ satisfies } P \\} .
](//upload.wikimedia.org/math/b/d/7/bd73d3fbe00032c3c44cf4eadfbefdce.png)

The braces are to be read as the words "the set of" whereas the symbol | stands for the words "such that."

It is convenient to introduce two special sets. The _empty set_, denoted by ![\\emptyset](//upload.wikimedia.org/math/4/d/f/4df085f70a97244c977b6ff20b1952b4.png), is a set that contains no elements. The _universal set_ is the collection of all objects of interest in a particular context, and it is denoted by ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png). Once a universal set ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png) is specified, we need only consider sets that are subsets of ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png). In the context of probability, ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png) is often called the _sample space_.

The _complement_ of a set S, with respect to the universal set ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png), is the collection of all objects in ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png) that do not belong to S,

![
S^c = \\{ x \\in \\Omega | x \\notin S \\}.
](//upload.wikimedia.org/math/a/b/1/ab1a74c29db4166f86e09fec077e18f3.png)

We note that ![\\Omega^c = \\emptyset](//upload.wikimedia.org/math/d/f/9/df92ff555846f5e5d4872d9cb5e8bdea.png).

  


## Elementary Set Operations

Probability theory makes extensive use of elementary set operations. Below, we review the ideas of set theory, and establish the basic terminology and notation. Consider two sets, S and T.

![Sets.png](//upload.wikimedia.org/wikibooks/en/a/ad/Sets.png)

The _union_ of sets S and T is the collection of all elements that belong to S or T (or both), and it is denoted by ![
S \\cup T](//upload.wikimedia.org/math/5/4/5/545729dafa26f1b07450750349afde56.png). Formally, we define the union of these two sets by

![
S \\cup T = \\{ x | x \\in S \\mbox{ or } x \\in T \\} .
](//upload.wikimedia.org/math/2/f/a/2fa77925b3f3e908abfe9aa8d138fb6b.png)

![Set Union.png](//upload.wikimedia.org/wikipedia/commons/0/0f/Set_Union.png)

The _intersection_ of sets S and T is the collection of all elements that belong to S and T. It is denoted by ![S \\cap T](//upload.wikimedia.org/math/a/e/0/ae036810a5f608c14e76c6448e6bd756.png), and it can be expressed mathematically as

![
S \\cap T = \\{ x | x \\in S \\mbox{ and } x \\in T \\} .
](//upload.wikimedia.org/math/6/a/5/6a5af8a8655b12d09bbb2c651dcb1683.png)

![Set Intersection.png](//upload.wikimedia.org/wikibooks/en/c/c4/Set_Intersection.png)

When S and T have no elements in common, we write ![S \\cap T = \\emptyset](//upload.wikimedia.org/math/c/f/8/cf87a1d8296359d2255a608b42f64ee4.png). We also express this fact by saying that S and T are _disjoint_. More generally, a collection of sets is said to be disjoint if no two sets have a common element. A collection of sets is said to form a _partition_ of S if the sets in the collection are disjoint and their union is S.

![Set Partition.png](//upload.wikimedia.org/wikibooks/en/4/46/Set_Partition.png)

The _difference_ of two sets, denoted by S - T, is defined as the set consisting of those elements of S that are not in T,

![
S - T = \\{ x | x \\in S \\mbox{ and } x \\notin T \\} .
](//upload.wikimedia.org/math/9/3/1/9311c771e421fecd6dd07cfdfe853e91.png)

This set is sometimes called the complement of T relative to S, or the complement of T in S.

![Set Difference.png](//upload.wikimedia.org/wikibooks/en/b/bb/Set_Difference.png)

We have already looked at the definition of the union and the intersection of two sets. We can also form the union or the intersection of arbitrarily many sets. This is defined in the obvious way,

![
\\bigcup_{\\alpha \\in I} S_{\\alpha}
= \\{ x | x \\in S_{\\alpha} \\mbox{ for some } \\alpha \\in I \\}
](//upload.wikimedia.org/math/d/d/9/dd997e1c3192fc939e3dbb0614c8443c.png)

![
\\bigcap_{\\alpha \\in I} S_{\\alpha}
= \\{ x | x \\in S_{\\alpha} \\mbox{ for all } \\alpha \\in I \\} .
](//upload.wikimedia.org/math/3/3/7/337f7211a7c843d9b449e0a4f106159f.png)

The index set I can be finite or even infinite.

## Rules of Set Theory

Given a collection of sets, it is possible to form new ones by applying elementary set operations to them. As in algebra, one uses parentheses to indicate precedence. For instance, ![R \\cup \(S \\cap T\)](//upload.wikimedia.org/math/a/e/b/aeb4c86183d2f2662053490204a82f41.png) denotes the union of two sets R and ![S \\cap T](//upload.wikimedia.org/math/a/e/0/ae036810a5f608c14e76c6448e6bd756.png), while ![\(R \\cup S\) \\cap T](//upload.wikimedia.org/math/3/1/d/31d5423376c1dda19d8a87c15c3cef66.png) represents the intersection of two sets ![R \\cup S](//upload.wikimedia.org/math/5/0/e/50e3fbc6bfb04a497c5f2c6da8c315d7.png) and ![T](//upload.wikimedia.org/math/b/9/e/b9ece18c950afbfa6b0fdbfa4ff731d3.png). The sets thus formed are quite different.

![Triple.png](//upload.wikimedia.org/wikibooks/en/b/be/Triple.png)

Sometimes different combinations of operations lead to the same set. For instance, we have the two distributive laws

![
R \\cap \(S \\cup T\) = \(R \\cap S\) \\cup \(R \\cap T\)
](//upload.wikimedia.org/math/6/b/c/6bcaed51fb8309cc149ccfd8509a2f30.png)

![
R \\cup \(S \\cap T\) = \(R \\cup S\) \\cap \(R \\cup T\).
](//upload.wikimedia.org/math/9/2/9/929f68e4ce453b2ee8bd45cecc1195fb.png)

Two particularly useful equivalent combinations of operations are given by _De Morgan's laws_, which state that

![
R - \(S \\cup T\) = \(R - S\) \\cap \(R - T\)
](//upload.wikimedia.org/math/0/b/5/0b5be9a3443d88f25905617084c9eaa1.png)

![
R - \(S \\cap T\) = \(R - S\) \\cup \(R - T\).
](//upload.wikimedia.org/math/6/e/8/6e87d5d40942b8561d87d901026b5fc9.png)

These two laws can be generalized to

![
\\left\( \\bigcup_{\\alpha \\in I} S_{\\alpha} \\right\)^c
= \\bigcap_{\\alpha \\in I} S_{\\alpha}^c
](//upload.wikimedia.org/math/f/e/7/fe73441512c25d34f1bc8c2d22e84768.png)

![
\\left\( \\bigcap_{\\alpha \\in I} S_{\\alpha} \\right\)^c
= \\bigcup_{\\alpha \\in I} S_{\\alpha}^c
](//upload.wikimedia.org/math/4/5/3/453044ce8858c9e0045af65c83c29171.png)

when multiple sets are involved. To establish the first equality, suppose that x belongs to ![\\left\( \\bigcup_{\\alpha \\in I} S_{\\alpha} \\right\)^c](//upload.wikimedia.org/math/a/9/8/a98c95dbfdf43fed23e37efeecfa11b5.png). Then x is not contained in ![\\bigcup_{\\alpha \\in I} S_{\\alpha}](//upload.wikimedia.org/math/6/b/3/6b3eaebbb1d41fdabd109ff8baf4c5da.png). That is, x is not an element of ![S_{\\alpha}](//upload.wikimedia.org/math/f/b/7/fb78db7947732275c768f6f73a8446c6.png) for any ![\\alpha \\in I](//upload.wikimedia.org/math/b/a/3/ba319da3734404ce838411ab728d6b7f.png). This implies that x belongs to ![S_{\\alpha}^c](//upload.wikimedia.org/math/b/4/6/b46765c8c8e097891f8269c567576d47.png) for all ![\\alpha \\in I](//upload.wikimedia.org/math/b/a/3/ba319da3734404ce838411ab728d6b7f.png), and therefore ![x \\in \\bigcap_{\\alpha \\in I} S_{\\alpha}^c](//upload.wikimedia.org/math/7/7/0/770c5499d25665f78cdceab6c3c2402e.png). We have shown that ![\\left\( \\bigcup_{\\alpha \\in I} S_{\\alpha} \\right\)^c \\subset \\bigcap_{\\alpha \\in I} S_{\\alpha}^c](//upload.wikimedia.org/math/3/d/a/3da41fbe676f3ce2825089e766bfcdcc.png). The converse inclusion is obtained by reversing the above argument. The second law can be obtained in a similar fashion.

  


## Cartesian Products

There is yet another way to create new sets form existing ones. It involves the notion of an _ordered pair_ of objects. Given sets S and T, the _cartesian product_ S x T is the set of all ordered pairs (x, y) for which x is an element of S and y is an element of T,

![
S \\times T = \\{ \(x, y\) | x \\in S \\mbox{ and } y \\in T \\} .
](//upload.wikimedia.org/math/3/f/c/3fc6676bfadb5d8704d1ac7c89ba7541.png)

  
![Cartesianproduct.png](//upload.wikimedia.org/wikibooks/en/6/69/Cartesianproduct.png)

  


## Summary of Probability & Set Theory

  * A = P(A) ∑[0, 1]
  * NOT A = P(A') = 1 – P(A)
  * A OR B = P(AUB) = P(A) + P(B) – P(A∩B) = P(A) + P(B) [*if and only if A and B are mutually exclusive]
  * A AND B = P(A∩B) = P(A/B)*P(B) = P(A)*P(B) [* if and only if A and B are independent]
  * A GIVEN B = P(A|B) = P(A∩b)/P(B) [*conditional]

**Basic Set Theory**

**UNION:** combined area of set A and B, known as AUB. The set of all items which are members of either A or B

  * Union of A and B are added together
  * Some basic properties of unions:
  * AUB = BUA
  * AU(BUC) = (AUB)UC
  * A c (AUB)
  * AUA = A
  * AU0 = A, where 0 = null, empty set
  * A c B, if and only if AUB = B

**INTERSECTION**: area where both A and B overlap, known as A∩B. It represents which members the two sets A and B have in common

  * If A∩B = 0, then A and B are said to be **DISJOINT**.
  * Some basic properties of intersections:
  * A∩B = B∩A
  * A∩(B∩C) = (A∩B)∩C
  * A∩B cA
  * A∩A = A
  * A∩0 = 0
  * A cB, if and only if A∩B = A
  * UNIVERSAL SET: space of all things possible, which contains ALL of the elements or elementary events.
  * U/A is called the absolute complement of A

**Complement (set)**: 2 sets can be subtracted. The relative complement (set theoretic difference of B and A). Denoted by B/A (or B – A) is the set of all elements which are members of B, but not members of A

Some basic properties of complements (~A, or A'):

  * AUA' = U
  * A∩A' = 0
  * (A')' = A
  * A/A = 0
  * U' = 0, and 0 = U
  * A/B = 'A∩B'

**Summary**

  * Intersection (A∩B) --> AND – both events occur together at the same time
  * Union (AUB) --> OR – everything about both events, A and B
  * Complement (~A) --> NOT A – everything else except A (or the event in question)
  * AU~A = S (sample space)
  * A∩~A = 0 (impossible event)

Union and Intersection are:

**Commutative:**

  * AUB = BUA
  * A∩B = B∩A

**Associative:**

  * AU(BUC) = (AUB)UC
  * A∩(B∩C) = (A∩B)∩C

**Distributive:**

  * AU(B∩C) = (AUB)∩(AUC)
  * A∩(BUC) = (A∩B)U(A∩C)

  


# Combinatorics

Often, in experiments with finite sample spaces, the outcomes are equiprobable. In such cases, the probability of an event amounts to the number of outcomes comprising this event divided by the total number of outcomes in the sample space. While counting outcomes may appear straightforward, it is in many circumstances a daunting task. For example, consider the number of distinct subsets of the integers {1, 2, ... , n} that do not contain two consecutive integers. This number is equal to

![
\\frac{ \\phi^{n+2} - \(1 - \\phi\)^{n+2} }{ \\sqrt{5} } ,
](//upload.wikimedia.org/math/f/f/4/ff4a3ebfab2835aed1c209d00d5f6773.png)

where ![\\phi = \(1 + \\sqrt{5}\) / 2](//upload.wikimedia.org/math/a/8/7/a8781d00486c8bf887e50875c812a1fd.png) is the _golden ratio_. It can also be obtained recursively through the _Fibonacci_ recurrence relation.

Calculating the number of ways that certain patterns can be formed is part of the field of _combinatorics_. In this section, we introduce useful counting techniques that can be applied to situations pertinent to probability theory.

## The Counting Principle

**The Fundamental Rule of Counting** If a set of choices or trials, T1, T2, T3, …, Tk, could result, respectively, in n1, n2, n3, …,nk possible outcomes, the entire set of k choices or trials has n1×n2×n3× … ×nk possible outcomes. (The numbers n1, n2, n3, …, nk cannot depend on which outcomes actually occur.)

By the Fundamental Rule of Counting, the total number of possible sequences of choices is 5×4×3×2×1 = 120 sequences. Each sequence is called a permutation of the five items. A permutation of items is an ordering of the items. More generally, by the Fundamental Rule of Counting, in ordering n things, there are n choices for the first, (n-1) choices for the second, etc., so the total number of ways of ordering a total of n things is n × (n-1) × (n-2) × . . . × 1. This product, n×(n-1)×(n-2)× . . . ×1, is written n!, which is pronounced "n factorial." By convention, 0! = 1

The counting principle is the guiding rule for computing the number of elements in a cartesian product as well.

![
S \\times T = \\{ \(x, y\) | x \\in S \\wedge y \\in T \\} .
](//upload.wikimedia.org/math/8/4/a/84ad63d420dad90fd8d797e6563790d9.png)

The number of elements in the cartesian product S x T is equal to mn. Note that the total number of outcomes does not depend on the order in which the experiments are realized.

![Countingprinciple.png](//upload.wikimedia.org/wikibooks/en/a/a9/Countingprinciple.png)

**Example:** Consider an experiment consisting of flipping a coin and rolling a die. There are two possibilities for the coin, heads or tails, and the die has six sides. The total number of outcomes for this experiment is 2 x 6 = 12. That is, there are twelve outcomes for the roll of a die followed by the toss of a coin: 1H, 1T, 2H, 2T, 3H, 3T, 4H, 4T, 5H, 5T, 6H, 6T.

  
The counting principle can be extended to compute the number of elements in the cartesian product of multiple sets. Consider the finite sets ![S_1, S_2, \\ldots, S_r](//upload.wikimedia.org/math/2/1/9/2191e659fcf062fdb4ddbbce0272cf29.png) and their cartesian product

![
S_1 \\times S_2 \\times \\cdots \\times S_r
= \\left\\{ \(s_1, s_2, \\ldots, s_r\) | s_p \\in S_p \\right\\} .
](//upload.wikimedia.org/math/4/9/9/4991f3b1206dce6ba8b9f4cf2a1ea465.png)

If we denote the cardinality of ![S_p](//upload.wikimedia.org/math/b/5/5/b55475851be96adf8871f794b2c8a642.png) by ![n_p = | S_p |](//upload.wikimedia.org/math/7/d/d/7ddc20af9f48fba6691a73a8caf0e2f0.png), then the number of distinct ordered r-tuples of the form ![\(s_1, s_2, \\ldots, s_r\)](//upload.wikimedia.org/math/2/4/9/249814f5ac65244f8d7bd7770ef1dd67.png) is ![n = n_1 n_2 \\cdots n_r](//upload.wikimedia.org/math/7/5/4/754705d12119bbed8ae620513df1660e.png).

**Example - Sampling with Replacement and Ordering:** An urn contains n balls numbered 1 through n. A ball is drawn from the urn, and its number is recorded on an ordered list. The ball is then replaced in the urn. This procedure is repeated k times. We wish to compute the number of possible sequences that results from this experiment. There are k drawings and n possibilities per drawing. Using the counting principle, we conclude that the number of distinct sequences is ![n^k](//upload.wikimedia.org/math/0/0/e/00e6eb59d4a992f432cce060b9acfb91.png).

**Example:** The power set of S, denoted by ![2^S](//upload.wikimedia.org/math/c/0/e/c0e2f8c3e6e485948f3cc5e23e1ad2a5.png), is the set of all subsets of S. In set theory, ![2^S](//upload.wikimedia.org/math/c/0/e/c0e2f8c3e6e485948f3cc5e23e1ad2a5.png) represents the set of all functions from S to {0, 1}. By identifying a function in ![2^S](//upload.wikimedia.org/math/c/0/e/c0e2f8c3e6e485948f3cc5e23e1ad2a5.png) with the corresponding preimage of one, we obtain a bijection between ![2^S](//upload.wikimedia.org/math/c/0/e/c0e2f8c3e6e485948f3cc5e23e1ad2a5.png) and the subsets of S. In particular, each function in ![2^S](//upload.wikimedia.org/math/c/0/e/c0e2f8c3e6e485948f3cc5e23e1ad2a5.png) is the characteristic function of a subset of S.

Suppose that S is finite with n = |S| elements. For every element of S, a characteristic function in ![2^S](//upload.wikimedia.org/math/c/0/e/c0e2f8c3e6e485948f3cc5e23e1ad2a5.png) is either zero or one. There are therefore ![2^n](//upload.wikimedia.org/math/9/a/a/9aa0ec0374c89d2f7f3d9cd2e05a4bc5.png) distinct characteristic functions from S to {0, 1}. Hence, the number of distinct subsets of S is given by ![2^n](//upload.wikimedia.org/math/9/a/a/9aa0ec0374c89d2f7f3d9cd2e05a4bc5.png).

**Formulae** The formula for counting combinations has special cases that are worth memorizing: _nC0 = nCn = 1_ (There is only one way to pick no thing and only one way to pick all n things.) _nC1 = nCn-1 = n_ (there are n ways to pick one thing or to leave one thing out) _nCk = nCn-k_ (There are the same number of ways of picking k of n things as there are of leaving out k of n things)

![Powerset.png](//upload.wikimedia.org/wikibooks/en/b/b3/Powerset.png)

## Permutations

**Permutation:** an arrangement of objects without repetition where order is important. Permutations using all the objects: _n_ objects, arranged into group size of _n_ without repetition, and order being important. P(n, n) = N! Example: Find all permutations of A, B, C

Permutations of some of the objects: _n_ objects, group size _r_, order is important. P(n, r) = N!/(n-r)! Example: Find all 2-letter combinations using letters A, B, C **Distinguished permutation:** if a word has _n_ letters, _k_ of which are unique, let _n_ (n1, n2, n3....nk) be the frequency of each of the _k_ letters: N!/(n1!)(n2!)(n3!).

Consider the integer set S = {1, 2, ... , n}. A _permutation_ of S is an ordered arrangement of its elements, a list without repetitions. The number of permutations of S can be computed as follows. The number of distinct possibilities for the first item is n. The number of possibilities for the second item is n-1, namely all the integers in S except the first element in the list. Similarly, the number of distinct possibilities for the m-th item is n - m + 1. This pattern continues until all the elements in S are listed. Summarizing, we find that the total number of permutations of S is n _factorial,_ n! = n (n-1) ... 1 .

**Example:** We wish to compute the number of permutations of S = {1, 2, 3}. Since the set S contains three elements, it has 3! = 6 permutations. They can be listed as 123, 132, 213, 231, 312, 321.

![Permutation.png](//upload.wikimedia.org/wikibooks/en/7/79/Permutation.png)

### Stirling's Formula

The number n! grows very rapidly as a function of n. A good approximation for n! when n is large is given by Stirling's formula,

![
n! \\sim n^n e^{-n} \\sqrt{ 2 \\pi n}
](//upload.wikimedia.org/math/6/9/d/69d8658d37f97bd4942558ed65b2e05f.png)

as ![n \\rightarrow \\infty](//upload.wikimedia.org/math/e/f/4/ef448529bb0fd823fa4aa6239bbab922.png). The notation ![a\(n\) \\sim b\(n\)](//upload.wikimedia.org/math/1/0/c/10ccc3353e144869af343c4b6aec97da.png) signifies that the ratio a(n)/b(n) approaches one as n tends to infinity.

### k-Permutations

Suppose that we list only k elements out of the set S = {1, 2, ... , n}, where ![k \\leq n](//upload.wikimedia.org/math/b/0/9/b099daeebeecf21a03f26e3edb233a19.png). We wish to count the number of distinct k-permutations of S. Following our previous argument, we can choose one of n elements to be the first item listed, one of n-1 elements for the second item, and so on. The procedure terminates when k items have been listed. The number of possible sequences is

![
\\frac{n!}{\(n-k\)!} = n \(n-1\) \\cdots \(n-k+1\) .
](//upload.wikimedia.org/math/4/5/8/458be04243b689b0e19de5c37dce5c2b.png)

**Example:** A recently formed music group has four original songs they can play. They are asked to perform two songs at a music festival. We wish to compute the number of song arrangements the group can offer in concert. Abstractly, this is equivalent to computing the number of 2-permutations of four songs. Thus, the number of distinct arrangements is 4!/2! = 12.

![Kpermutation.png](//upload.wikimedia.org/wikibooks/en/f/f1/Kpermutation.png)

**Example - Sampling without Replacement, with Ordering:** An urn contains n balls numbered one through n. A ball is picked from the urn, and its number is recorded on an ordered list. The ball is not replaced in the urn. This procedure is repeated until k balls are selected from the urn, where ![k \\leq n](//upload.wikimedia.org/math/b/0/9/b099daeebeecf21a03f26e3edb233a19.png). We wish to compute the number of possible sequences that results from this experiment. The number of possibilities is equivalent to the number of k-permutations of n elements, which is given by n!/(n-k)!.

## Combinations

**Combinations**: arrangement of objects without repetition, where order is NOT important. A combination of _n_ objects, arranged in groups of size _r_, without repetition, and order being important. C(n, r) = n!/r!(n-r)! Another way to write a combination of _n_ things, _r_ at a time, is using the Binomial notation (**Binomial Distribution**). Combinations of this type are referred to verbally as "n choose r".

Consider the integer set S = {1, 2, ... , n}. A _combination_ is a subset of S. We emphasize that a combination differs from a permutation in that elements in a combination have no specific ordering. The 2-element subsets of S = {1, 2, 3, 4} are {1, 2}, {1, 3}, {1, 4}, {2, 3}, {2, 4}, {3, 4} , whereas the 2-permutations of S are more numerous with (1, 2), (1, 3), (1, 4), (2, 1), (2, 3), (2, 4), (3, 1), (3, 2), (3, 4), (4, 1), (4, 2), (4, 3) . There are therefore fewer 2-element subsets of S than 2-permutations of S.

![Combination.png](//upload.wikimedia.org/wikibooks/en/3/3b/Combination.png)

We can compute the number of k-element combinations of S = {1, 2, ... , n} as follows. First, we note that a k-permutation can be formed by first selecting k objects from S and then ordering them. There are k! distinct ways of ordering k objects. The number of k-permutations must then equal the number of k-element combinations multiplied by k!. Since the total number of k-permutations of S is n! / (n-k)!, the number of k-element combinations is found to be

![
\\frac{n!}{k! \(n-k\)!} = \\frac{ n \(n-1\) \\cdots \(n-k+1\) }{ k! } .
](//upload.wikimedia.org/math/1/6/b/16b41cde081d753524adfc74f21adce4.png)

This expression is called a _binomial coefficient_. Observe that selecting a k-element subset of S is equivalent to choosing the n-k elements that belong to its complement.

**Example - Sampling without Replacement or Ordering:** An urn contains n balls numbered one through n. A ball is drawn from the urn and placed in a jar. This process is repeated until the jar contains k balls, where ![k \\leq n](//upload.wikimedia.org/math/b/0/9/b099daeebeecf21a03f26e3edb233a19.png). We wish to compute the number of distinct combinations the jar can hold after the completion of this experiment. Because there is no ordering in the jar, this amounts to counting the number of k-element subsets of a given n-element set, which is given by

![
\\frac{n!}{k! \(n-k\)!}.
](//upload.wikimedia.org/math/4/4/b/44be97cf81eb32bef63d6e4bbb99dabc.png)

Again, let S = {1, 2, ... , n}. Since a combination is also a subset and the number of k-element combinations of S is ![\\frac{n!}{k! \(n-k\)!}](//upload.wikimedia.org/math/e/e/d/eed76baaa00cf639ad1c1cecd11247f1.png), the sum of the binomial coefficients over all values of k must be equal to the number of elements in the power set of S. Thus, we get

![
\\sum_{k=0}^n \\frac{n!}{k! \(n-k\)!} = 2^n.
](//upload.wikimedia.org/math/8/7/4/8748cac52d10826e751137f0073d63e4.png)

## Partitions

Abstractly, a combination is equivalent to partitioning a set into two subsets, one containing k objects and the other containing the n-k remaining objects. In general, the set S = {1, 2, ... , n } can be partitioned into r subsets. Let ![n_1, n_2, \\ldots, n_r](//upload.wikimedia.org/math/9/c/8/9c8c7b9300d7b2421d3b730f47cb422d.png) be nonnegative integers such that ![
\\sum_{p = 1}^r n_p = n.
](//upload.wikimedia.org/math/8/e/e/8ee3e12837f6894f1afa7333fe7154f0.png)

Consider the following iterative algorithm that leads to a partition of S. First, we select a subset of ![n_1](//upload.wikimedia.org/math/c/a/2/ca28d2957bcfd844805dfd1c339dfc2f.png) elements from S. Having chosen the first subset, we select a second subset containing ![n_2](//upload.wikimedia.org/math/2/7/e/27e7b1346e011cf2896a04df87832534.png) elements from the remaining ![n - n_1](//upload.wikimedia.org/math/2/f/0/2f0c5e33b6358f81478d9bcb9e9d492d.png) elements. We continue this procedure by successively choosing subsets of ![n_p](//upload.wikimedia.org/math/d/2/4/d241fb30a61c3708d7909db5442d08ed.png) elements from the remaining ![n - n_1 - \\cdots - n_{p-1}](//upload.wikimedia.org/math/d/3/b/d3b7a26e7c59644d6baf23adcba1915b.png) elements, until no element remains. This algorithm yields a partition of S into r subsets, with the p-th subset containing exactly ![n_p](//upload.wikimedia.org/math/d/2/4/d241fb30a61c3708d7909db5442d08ed.png) elements.

We wish to count the number of such partitions. We know that there are ![\\frac{n!}{n_1!\(n-n_1\)!}](//upload.wikimedia.org/math/c/b/f/cbfbe7cdd1ea7f199c400041b510925f.png) ways to form the first subset. Examining our algorithm, we see that there are

![
\\frac{\(n - n_1 - \\cdots - n_{p-1}\)!}{n_p!\(n - n_1 - \\cdots - n_p\)!}
](//upload.wikimedia.org/math/4/9/3/493cfec13a9b2793546eee8f4fcbb043.png)

ways to form the p-th subset. Using the counting principle, the total number of partitions is then given by

![
\\frac{n!}{n_1! n_2! \\cdots n_r!} .
](//upload.wikimedia.org/math/b/c/5/bc525b5e14db31ac7aab67e7dbe69ffa.png)

This expression is called a _multinomial coefficient_.

**Example:** A die is rolled nine times. We wish to compute the number of outcomes for which every odd number appears three times. The number of distinct sequences in which one, three, and five each appear three times is equal to the number of partitions of {1, 2, ... , 9} into three subsets of size three, namely

![
\\frac{9!}{3! 3! 3!} = 1680 .
](//upload.wikimedia.org/math/d/7/a/d7ab6fe3996190619e5e87d4d7e31a4b.png)

In the above analysis, we assume that the size of each subset is fixed, three subsets of size three. Suppose instead that we are interested in counting the number of ways of picking the sizes of the subsets, r subsets of ![n_1, n_2, \\ldots, n_r](//upload.wikimedia.org/math/9/c/8/9c8c7b9300d7b2421d3b730f47cb422d.png) size, where the sum of the sizes is a constant. Specifically, we wish to compute the number of ways integers ![n_1, n_2, \\ldots, n_r](//upload.wikimedia.org/math/9/c/8/9c8c7b9300d7b2421d3b730f47cb422d.png) can be selected such that every integer is nonnegative and

![\\sum_{p = 1}^r n_p = n](//upload.wikimedia.org/math/d/c/4/dc42caa326b9616ede292a7745dd0538.png).

We can visualize the number of possible assignments as follows. Picture n balls spaced out on a straight line and consider r-1 vertical markers, each of which can be put between two consecutive balls, before the first ball, or after the last ball. For instance, if there are five balls and two markers then one possible assignement is illustrated below.

![Partitioning.png](//upload.wikimedia.org/wikibooks/en/7/7e/Partitioning.png)

The number of objects in the first subset corresponds to the number balls before the first marker. Similarly, the number of objects in the p-th subset is equal to the number of balls between the p-th marker and the preceding one. Finally, the number of objects in the last subset is simply the number of balls after the last marker. In the figure, the integer assignment is

![
\(n_1, n_2, n_3\) = \(0,2,3\).
](//upload.wikimedia.org/math/d/f/a/dfaf907e2bc14c24c2bc14b0d0383977.png)

![Partitioning2.png](//upload.wikimedia.org/wikibooks/en/5/55/Partitioning2.png)

Two consecutive markers imply that the corresponding subset is empty. There is a natural bijection between an integer assignment and the graphical representation depicted above. To count the number of possible integer assignments, it then suffices to compute the number of ways to position the markers and the balls. In particular, there are n + r - 1 positions, n balls, and r - 1 markers. The number of ways to assign the markers is equal to the number of n-combinations of n + r - 1 elements,

![
\\frac{\(n + r - 1\)!}{n!\(r-1\)!} .
](//upload.wikimedia.org/math/5/c/3/5c30ee682b90421abbebde33ace83554.png)

**Example - Sampling with Replacement, without Ordering:** An urn contains r balls numbered one through r. A ball is drawn from the urn and its number is recorded. The ball is then returned to the urn. This procedure is repeated a total of n times. The outcome of this experiment is a table that contains the number of times each ball has come in sight. We are interested in computing the number of distinct outcomes. This is equivalent to counting the ways a set with n elements can be partitioned into r subsets. The number of possible outcomes is therefore given by

![
\\frac{\(n + r - 1\)!}{n!\(r-1\)!} .
](//upload.wikimedia.org/math/5/c/3/5c30ee682b90421abbebde33ace83554.png)

## Computing Probabilities

In this section, we present two straightforward applications of combinatorics to computing the probability of winning the lottery.

**Example - Pick 3 Texas Lottery:** The Texas Lottery game _Pick 3_ is easy to play. A player must pick three numbers from zero to nine, and choose how to play them: exact order, or any order. The Pick 3 balls are drawn using three air-driven machines. These machines use compressed air to mix and select each ball.

The probability of winning while playing the exact order is

![
\\frac{1}{10} \\frac{1}{10} \\frac{1}{10}
= \\frac{1}{1000} .
](//upload.wikimedia.org/math/d/0/6/d062088d264032b2cbf3c1206f99da0b.png)

The probability of winning while playing any order depends on the numbers selected. If three distinct numbers are selected then the probability of winning is 3/500. If a number is repeated twice, the probability of winning is 3/1000. While, if the same number is selected three times, the probability of winning becomes 1/1000.

**Example - Mega Millions Texas Lottery:** To play the Mega Millions game, a player must select five numbers from 1 to 56 in the upper white play area of the play board, and one Mega Ball number from 1 to 46 in the lower yellow play area of the play board. All drawing equipment is stored in a secured on-site storage room. Only authorized drawings department personnel have keys to this door. Upon entry of the secured room to begin the drawing process, a lottery drawing specialist examines the security seal to determine if any unauthorized access has occurred. For each drawing, the Lotto Texas balls are mixed by four acrylic mixing paddles rotating clockwise. High speed is used for mixing and low speed for ball selection. As each ball is selected, it rolls down a chute into an official number display area. We wish to compute the probability of winning the Mega Millions Grand Prize, which require the correct selection of the five white balls plus the gold Mega ball. The probability of winning the Mega Millions Grand Prize is

![
\\frac{51!5!}{56!} \\frac{1}{46}
= \\frac{1}{175 711 536} .
](//upload.wikimedia.org/math/d/2/7/d27a01ab2d70aa4815f9995462198b07.png)

  


# Conditional Probability

In some situations we need a new kind of probability.

### Examples

We shall throw two dice: the probability of getting double six is 1/36. We have thrown the dice, but they are still under the cup: the probability of double six still is considered to be 1/36. Now we have someone else look under the cup at the result, and they tell us that at least one of the dice is a 6. What will the probability be of double six? Although we ask for the "probability" of double six, it's not the original probability we're talking about. It's a new kind of probability of the event "double six" under the condition that we know that another event has occurred, i.e. the event that one of the dice shows six. We call it "conditional probability". It indicates how likely the event "double six" is amongst all events in which (at least) one of the dice shows six. In 11 of the 36 possibilities at least one of the dice shows six. Thus, the probability of one of the dice showing six is 11/36 and the probability of double six is 1/36. Hence, the conditional probability of double six, given one die shows six is (1/36)/(11/36) = 1/11. We write this conditional probability as:

    P( "double six" | "at least one six" ),

using the same letter P as for the original probability, and separating the event of which the conditional probability is indicated from the event that states the condition by a vertical line ("|").

As another example we pick at random an inhabitant of the UK. The probability of the chosen person to be a woman (W) is 1/2, it's nothing else than the fraction women amongst the British. What if we are informed that the chosen person is working in a hospital (H)? It now comes down to the fraction of women amongst hospital staff, let's say 0.7. So we have:

    P(W) = 0.5

and

    P(W|H) = 0.7.

From these examples we learn:

## Definition

The conditional probability of an event A, given the (occurrence of) the event B, is defined as:

    ![P\(A|B\) = \\frac{P\(A \\cap B\)}{P\(B\)}](//upload.wikimedia.org/math/8/6/9/8694e4193ba45b55403595096b7d23c5.png),

provided P(B) > 0\. In the case where P(B) = 0, the conditional probability of A given B is meaningless, but for completeness we define P(A|B) = 0 for P(B) = 0

  
It follows from this formula that P(A|B)P(B) = P(A and B).

**Independent events** Intuitively, we would like two events, A and B, to be independent if P(A|B) = P(A), that is, if A is as likely to occur whether or not B has occurred. In this case, the occurrence of A is independent of the occurrence of B.

  
However, P(A|B) = P(A) ![\\iff](//upload.wikimedia.org/math/6/6/c/66c71a989b24a9eae7158be73e2b45cd.png) P(A and B)/P(B) = P(A) ![\\iff](//upload.wikimedia.org/math/6/6/c/66c71a989b24a9eae7158be73e2b45cd.png) P(A and B) = P(A)P(B).

  
Therefore, A is independent from B ![\\iff](//upload.wikimedia.org/math/6/6/c/66c71a989b24a9eae7158be73e2b45cd.png) B is independent from A ![\\iff](//upload.wikimedia.org/math/6/6/c/66c71a989b24a9eae7158be73e2b45cd.png) P(A and B) = P(A)P(B).

  


# Random Variables

## Random Variables: Definitions

Formally, a _random variable_ on a probability space ![\(\\Omega,\\Sigma,P\)](//upload.wikimedia.org/math/6/2/4/6240fed89c880b031cc7280209b6f972.png) is a measurable real function _X_ defined on ![\\Omega](//upload.wikimedia.org/math/b/9/d/b9d99db8626de63193c7fe96273a6cae.png) (the set of possible outcomes)

    ![X: \\Omega\\ \\to \\ \\mathbb{R}](//upload.wikimedia.org/math/2/0/4/2048ccdac7506126f4235d69029327a1.png),

where the property of measurability means that for all real _x_ the set

    ![\\{X \\le x\\} := \\{\\omega\\in \\Omega|X\(\\omega\) \\le x\\} \\in \\Sigma](//upload.wikimedia.org/math/f/6/2/f625516f17a554fcb54eb79dd718756b.png), i.e. is an event in the probability space.

### Discrete variables

If X can take a finite or countable number of different values, then we say that X is a _discrete random variable_ and we define the _mass function_ of X, p(![x_i](//upload.wikimedia.org/math/0/5/e/05e42209d67fe1eb15a055e9d3b3770e.png)) = P(X = ![x_i](//upload.wikimedia.org/math/0/5/e/05e42209d67fe1eb15a055e9d3b3770e.png)), which has the following properties:

  * p(![x_i](//upload.wikimedia.org/math/0/5/e/05e42209d67fe1eb15a055e9d3b3770e.png)) ![\\ge](//upload.wikimedia.org/math/8/f/b/8fbe2a506fe3db0835548e1b648ec977.png) 0
  * ![\\sum_{i} p\(x_i\) = 1](//upload.wikimedia.org/math/f/4/e/f4e3063a3f3605c9b47c97d60f0456d7.png)

Any function which satisfies these properties can be a mass function.

Variables
    We need some way to talk about the objects of interest. In set theory, these objects will be sets; in number theory, they will be integers; in functional analysis, they will be functions. For these objects, we will use lower-case letters: a, b, c, etc. If we need more than 26 of them, we’ll use subscripts.

Random Variable
    an unknown value that may change everytime it is inspected. Thus, a random variable can be thought of as a function mapping the sample space of a random process to the real numbers. A random variable has either a associated probability distribution (discrete random variable) or a probability density function (continuous random variable).

Random Variable "X"
    formally defined as a measurable function (probability space over the real numbers).

Discrete variable
    takes on one of a set of specific values, each with some probability greater than zero (0). It is a finite or countable set whose probability is equal to 1.0.

Continuous variable
    can be realized with any of a range of values (ie a real number, between negative infinity and positive infinity) that have a probability greater than zero (0) of occurring. Pr(X=x)=0 for all X in R. Non-zero probability is said to be finite or countably infinite.

### Continuous variables

If X can take an uncountable number of values, and X is such that for all (measurable) _A_:

    ![P\(X \\in A\) = \\int_A f\(x\) dx ](//upload.wikimedia.org/math/1/c/3/1c39ea025ee3614bedc556290eff1fc7.png),

we say that X is a _continuous variable_. The function f is called the _(probability) density_ of _X_. It satisfies:

  * ![f\(x\)\\ge\\ 0\\ \\forall x \\in\\ \\mathbb{R} ](//upload.wikimedia.org/math/c/5/0/c50dc81c2e34bfda8dd7b7ea875180c9.png)
  * ![\\int_{-\\infty}^{\\infty} f\(x\) dx = 1](//upload.wikimedia.org/math/a/6/3/a633461b5c1bbd54f5c64d4b16fb9712.png)

### Cumulative Distribution Function

The _(cumulative) distribution function_ (c.d.f.) of the r.v. X, ![F_X](//upload.wikimedia.org/math/0/9/9/0992e6c5d03e0288e80e5856b0bc0ce7.png) is defined for any real number x as:

    ![F_X \(x\) = P\(X \\le  x\)=\\begin{cases} \\sum_{i: x_i \\le\\ x} p\(x_i\), & \\mbox{if }X\\mbox{ is discrete} \\\\ \\, \\\\ \\int_{-\\infty}^{x} f\(y\) dy, & \\mbox{if }X\\mbox{ is continuous} \\end{cases} ](//upload.wikimedia.org/math/9/5/8/958b0f6a9f60e2942a4b2dea2ea38bc6.png)

The distribution function has a number of properties, including:

  * ![\\lim_{x\\to-\\infty} F\(x\) = 0](//upload.wikimedia.org/math/7/f/3/7f385bf67c2dadff85d5a0cbf1271dd0.png) and ![\\lim_{x\\to\\infty} F\(x\) = 1](//upload.wikimedia.org/math/d/1/6/d16fc424d3fe6ca7862c7be405406040.png)
  * if x < y, then F(x) ≤ F(y) -- that is, F(x) is a non-decreasing function.
  * F is right-continuous, meaning that F(x+h) approaches F(x) as h approaches zero from the right.

### Independent variables

  


# Important Distributions

## Uniform Distribution

The **uniform distribution** is a model for "no preference". For example if we roll a fair dice numbered from 1 to 6, each side has equal probability of facing up, and the probability of each number would be 1/6. For the continuous analogon of such a distribution, there is an equal probability of picking any range of a given size. For example for a uniform distribution from 0 to 10, the probability of picking a real number between 1 and 2 is 1/10, the same as for picking a real number between 5.43 and 6.43.

This simple distribution forms the basis of much of the study of probability. It mirrors the type of activity observed from rolling a fair dice, or flipping a coin. This intuitively relates to many standard problems. A number of other distributions derive from this distribution. For instance, while any one roll of a dice has a uniform distribution, summing up the totals of rolling a dice lots of time, or taking their average, does not have a uniform distribution, but approximates a Gaussian distribution, which we will discuss later.

The uniform distribution on the interval [a,b] is a continuous distribution with probability density _f_ given by:

    ![
  f\(x\)=\\left\\{\\begin{matrix}
  \\frac{1}{b - a} & \\ \\ \\ \\mbox{for }a < x < b, \\\\  \\\\
  0 & \\mathrm{for}\\ x<a\\ \\mathrm{or}\\ x>b, \\\\  \\\\
  \\mathrm{see}\\ \\mathrm{below} & \\ \\ \\ \\mbox{for }x=a \\mbox{ or }x=b.
  \\end{matrix}\\right.
](//upload.wikimedia.org/math/9/0/2/902cbee17fd651bee5a026f558a6e813.png)

The value of the density at a or b can be 0, ![\\frac{1}{b-a}](//upload.wikimedia.org/math/9/b/8/9b880238fa21712551ea5f3ffa30a204.png), or any other finite value without changing finite probabilities. For a more complete discussion of this point and for more information on the uniform distribution, see the [Uniform distribution (continuous)](//en.wikipedia.org/wiki/en:Uniform_distribution_\(continuous\)) page at Wikipedia.

A random variable _X_ with this distribution is called a _random number_ between _a_ and _b_.

  


## Binomial Distribution

Many random experiments are of the type where one counts the number of successes in a series of a fixed number of independently repeated trials which may result in either success or failure. The distribution of the number of successes is a **binomial distribution**. It is a discrete probability distribution with two parameters, traditionally indicated by _n_, the number of trials, and _p_, the probability of success.

A well known example of such an experiment is the repeated tossing of a coin and counting the number of times "heads" comes up.

One says that the random variable _X_ follows the binomial distribution with parameters _n_ and _p_, and writes _X_ ~ B(_n_, _p_) if the probability of getting exactly _k_ successes is given by the probability mass function:

    ![p\(k\)={n\\choose k}p^k\(1-p\)^{n-k}\\,](//upload.wikimedia.org/math/2/5/f/25f740454e09b5913a159d266fbb12f5.png)

for ![k=0,1,2,\\dots,n](//upload.wikimedia.org/math/3/9/c/39c8f3b9b53ab72174243f8b3d972b39.png) and where

    ![{n\\choose k}=\\frac{n!}{k!\(n-k\)!}](//upload.wikimedia.org/math/c/2/d/c2d02458d8c35f11e465c639ba62f081.png)

is the binomial coefficient.

The formula is easily derived from the fact that from _n_ trials _k_ should be successfull, having probability ![p^k](//upload.wikimedia.org/math/0/3/6/036903273adb00aafa6763054f66b4eb.png) and _n_ − _k_ failures, with probability ![\(1-p\)^{n-k}](//upload.wikimedia.org/math/d/1/0/d10412f9a2434222211674ea9922f517.png). This gives a specific outcome a probability of ![p^k \(1-p\)^{n-k}](//upload.wikimedia.org/math/e/8/1/e81e13d093fced9fd0019626005e9f7c.png) An outcome with exactly _k_ successes, however, may occur in a number of specific orders, i.e. one has to choose _k_ of the _n_ outcomes to be successful. This leads to the binomial coefficient as factor to be multiplied.

For more information see the [binomial distribution](//en.wikipedia.org/wiki/en:Binomial_distribution) article at Wikipedia.

## The Poisson Distribution

The **Poisson distribution** with parameter ![\\lambda > 0\\,](//upload.wikimedia.org/math/f/3/a/f3ab97ac90224e2373f173bc804e3c86.png) is a discrete probability distribution with mass function given by:

    ![
p\(k\) = \\frac{\\lambda^k}{k!} e^{- \\lambda}
](//upload.wikimedia.org/math/b/5/e/b5e8abc6c86be440f5c2382f156a99d1.png)

where k is a nonnegative integer.

The Poisson distribution is sometimes called: "the distribution of rare events", meaning it indicates the distribution of the number of events occurring in a fixed time interval, or fixed spatial area, where the occurrence of an event is "rare" in the sense that no two events may happen together.

The random variable X indicating this number of occurrences is called a _Poisson random variable_. The Poisson random variable is of fundamental importance in communication and queuing theory.

  
It is possible to obtain the Poisson distribution as the limit of a sequence of binomial distributions.

Let ![\\lambda](//upload.wikimedia.org/math/e/0/5/e05a30d96800384dd38b22851322a6b5.png) be fixed and consider the binomial distributions with parameters _n_ and ![\\lambda /n](//upload.wikimedia.org/math/a/1/3/a13917a38723ab5e65c303d634e79f11.png):

  


    ![
p_n \(k\)
= \\frac{n!}{k!\(n-k\)!} \\left\( \\frac{\\lambda}{n} \\right\)^k
\\left\( 1 - \\frac{\\lambda}{n} \\right\)^{n-k}
= \\frac{n!}{n^k \(n-k\)!} \\frac{\\lambda^k}{k!}
\\left\( 1 - \\frac{\\lambda}{n} \\right\)^{n-k} .
](//upload.wikimedia.org/math/e/8/2/e82a534e8a73769fec3347aa93444608.png)

In the limit, as _n_ approaches infinity, the binomial probabilities tend to a Poisson probability with parameter λ:

    ![
\\lim_{n \\rightarrow \\infty} p_n \(k\)
= \\lim_{n \\rightarrow \\infty} \\frac{n!}{n^k \(n-k\)!} \\frac{\\lambda^k}{k!}
\\left\( 1 - \\frac{\\lambda}{n} \\right\)^{n-k}
= \\frac{\\lambda^k}{k!} e^{- \\lambda}.
](//upload.wikimedia.org/math/f/a/7/fa7eb596956a012708f59f04e113656c.png)

  
This result shows that the Poisson PMF can be used to approximate the PMF of a binomial distribution. Suppose that _Y_ is a binomial random variable with parameters _n_ and _p_. If _n_ is large and _p_ is small, the probability that _Y_ equals _k_ is not easily calculated, but may be approximated by a Poisson probability with parameter _np_:

    ![
P\(Y=k\) = {n \\choose k}p^k \\left\( 1 - p \\right\)^{n-k}
\\approx \\frac{\(np\)^k}{k!} e^{- np} ,
](//upload.wikimedia.org/math/c/7/5/c75f03f18dfa1961bd79feebcfe25753.png).

The above mentioned limiting process may be illustrated with the following example. Count the yearly number X of car accidents on an important roundabout. Let us assume on the average 8 accidents happen yearly. To calculate the distribution, we consider the 12 months and count a success when an accident has happened that month and else a failure. The number of successes will constitute a binomial random variable ![X_{12}](//upload.wikimedia.org/math/0/7/7/07774cb417c3e3e12f880ffded7b45f5.png) with parameters n=12 and p=8/12. As the average number is 8, it is still likely some months will meet more than one accident, so we consider weeks and count the number of weeks with an accident as successful. This number ![X_{52}](//upload.wikimedia.org/math/0/1/f/01fd2957f553529b3aa570154fe37c3b.png) may be considered binomial distributed with parameters n=52 and p=8/52. While there may still be weeks with two accidents, we turn to days. The number ![X_{365}](//upload.wikimedia.org/math/e/a/9/ea9e233132cd28c229b9e1e9001575ea.png) of days with success may be considered binomial distributed with parameters n=365 and p=8/365. The limiting distribution by considering hours, minutes, seconds, etc. gives the Poisson distribution of _X_ with parameter 8. We also note an important condition on the occurrence of the events (accidents): we only count them correctly if in the end we may separate them in disjoint time intervals. So it is not allowed that two accidents happen the same moment.

  


## Normal Distribution

The normal or Gaussian distribution is a thing of beauty, appearing in many places in nature. This probably is a result of the normal distribution resulting from the law of large numbers, by which a sum of many random variables (with finite variance) becomes a normally distributed random variable according to the central limit theorem.

Also known as the bell curve, the normal distribution has been applied to many social situations, but it should be noted that its applicability is generally related to how well or how poorly the situation satisfies the property mentioned above, whereby many finitely varying, random inputs result in a normal output.

The formula for the density f of a normal distribution with mean ![\\mu](//upload.wikimedia.org/math/b/7/2/b72bb92668acc30b4474caff40274044.png) and standard deviation ![\\sigma](//upload.wikimedia.org/math/9/d/4/9d43cb8bbcb702e9d5943de477f099e2.png) is

    ![
f\(x\)
=
\\frac{1}{\\sigma\\sqrt{2\\pi}} \\, e^{ -\\frac 12 \\left\( \\frac{x- \\mu}{\\sigma}\\right\)^2 }](//upload.wikimedia.org/math/5/4/3/543d8076d375111fe00105c36f3c8f83.png).

A rather thorough article in Wikipedia could be summarized to extend the usefulness of this book: [Normal distribution from Wikipedia](//en.wikipedia.org/wiki/en:Normal_distribution).

  


# Links

Hyperlinks to external resources on probability:

  * [Probability and Statistics EBook](http://wiki.stat.ucla.edu/socr/index.php/EBook)
  * [Grinstead, Snell: Introduction to Probability](http://www.dartmouth.edu/~chance/teaching_aids/books_articles/probability_book/book.html), 520 pages PDF, licensed under GNU FDL
  * [Lectures on Probability and Statistics](http://www.statlect.com)
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Probability/Print_version&oldid=2071790](http://en.wikibooks.org/w/index.php?title=Probability/Print_version&oldid=2071790)" 

[Category](/wiki/Special:Categories): 

  * [Probability](/wiki/Category:Probability)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Probability%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Probability%2FPrint+version)

### Namespaces

  * [Book](/wiki/Probability/Print_version)
  * [Discussion](/w/index.php?title=Talk:Probability/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Probability/Print_version)
  * [Edit](/w/index.php?title=Probability/Print_version&action=edit)
  * [View history](/w/index.php?title=Probability/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Probability/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Probability/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Probability/Print_version&oldid=2071790)
  * [Page information](/w/index.php?title=Probability/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Probability%2FPrint_version&id=2071790)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Probability%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Probability%2FPrint+version&oldid=2071790&writer=rl)
  * [Printable version](/w/index.php?title=Probability/Print_version&printable=yes)

  * This page was last modified on 20 March 2011, at 07:33.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Probability/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
