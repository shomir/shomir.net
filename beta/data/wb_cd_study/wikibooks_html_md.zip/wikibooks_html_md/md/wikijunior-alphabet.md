# Wikijunior:Alphabet/All pages

From Wikibooks, open books for an open world

< [Wikijunior:Alphabet](/wiki/Wikijunior:Alphabet)

![Edits to this page require review.](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/doc-magnify.png)![This is a reviewed version of this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/2.png)This is the [latest reviewed version](/wiki/Wikibooks:REVIEW), [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Wikijunior:Alphabet/All_pages) on _4 September 2012_.(+)

 **Quality**: minimal  

Jump to: navigation, search

![Featured book en.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/ee/Featured_book_en.svg/50px-Featured_book_en.svg.png)

_Wikijunior:Alphabet_ is a [featured book](/wiki/Wikibooks:Featured_books) on Wikibooks because it contains substantial content, it is well-formatted, and the Wikibooks community has decided to feature it on the [main page](/wiki/Main_Page) or in other places. Please continue to improve it and thanks for the great work so far! A {{[Featured Wikijunior book](/wiki/Template:Featured_Wikijunior_book)}} template should be created to [advertise it](//en.wikibooks.org/w/index.php?title=Template:Featured_Wikijunior_book/Alphabet/All_pages&action=edit&preload=Template:Featured_Wikijunior_book/Blank&editintro=Template:Featured_Wikijunior_book/Editintro).

This book is a project within [Wikijunior](/wiki/Wikijunior), produced at the [Pre-Reading](/wiki/Wikibooks:Reading_Levels) level. This book is intended to be read by a parent/guardian or teacher to a child so that they can become familiar with the letters of the alphabet and the sounds that letters make.

  


**The Alphabet**

  


![TransMilenio Estacion A Caracas.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/12/TransMilenio_Estacion_A_Caracas.svg/200px-TransMilenio_Estacion_A_Caracas.svg.png) ![TransMilenio Estacion B Autonorte.svg](//upload.wikimedia.org/wikipedia/commons/thumb/7/73/TransMilenio_Estacion_B_Autonorte.svg/200px-TransMilenio_Estacion_B_Autonorte.svg.png) ![TransMilenio Estacion C Suba.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/11/TransMilenio_Estacion_C_Suba.svg/200px-TransMilenio_Estacion_C_Suba.svg.png)

**A** is for **A**pple

  


![Fuji apple.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Fuji_apple.jpg/500px-Fuji_apple.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[A is for apple](/wiki/File:A_is_for_apple.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/3/37/A_is_for_apple.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**B** is for **B**all

![Generic football.png](//upload.wikimedia.org/wikipedia/commons/7/7f/Generic_football.png)

— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

**C** is for **C**at

  


![Black hills cat-tochichi.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/d/da/Black_hills_cat-tochichi.jpg/500px-Black_hills_cat-tochichi.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[C is for cat](/wiki/File:C_is_for_cat.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/7/76/C_is_for_cat.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**D** is for **D**uck

  


![Coin-img 2219.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/9/94/Coin-img_2219.jpg/500px-Coin-img_2219.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


**E** is for **E**gg

  


![Cowbird egg.JPG](//upload.wikimedia.org/wikipedia/commons/2/29/Cowbird_egg.JPG)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[E is for egg](/wiki/File:E_is_for_egg.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/f/fc/E_is_for_egg.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**F** is for **F**ish

  


![Lemin u0.gif](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Lemin_u0.gif/500px-Lemin_u0.gif)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[F is for fish](/wiki/File:F_is_for_fish.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/9/9a/F_is_for_fish.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**G** is for **G**ate

  


![Hargimont 051030 \(5\).JPG](//upload.wikimedia.org/wikipedia/commons/thumb/1/15/Hargimont_051030_%285%29.JPG/500px-Hargimont_051030_%285%29.JPG)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[G is for gate](/wiki/File:G_is_for_gate.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/1/1f/G_is_for_gate.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**H** is for **H**orse

  


![Bess2.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/7/72/Bess2.jpg/500px-Bess2.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[H is for horse](/wiki/File:H_is_for_horse.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/1/11/H_is_for_horse.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**I** is for **I**gloo

  


![Igloo outside.jpg](//upload.wikimedia.org/wikipedia/commons/9/99/Igloo_outside.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[I is for igloo](/wiki/File:I_is_for_igloo.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/a/a8/I_is_for_igloo.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**J** is for **J**am

  


![Confituur.JPG](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Confituur.JPG/300px-Confituur.JPG)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[J is for jam](/wiki/File:J_is_for_jam.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/8/89/J_is_for_jam.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**K** is for **K**angaroo

  


![Kangaroo1.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Kangaroo1.jpg/400px-Kangaroo1.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[K is for kangaroo](/wiki/File:K_is_for_kangaroo.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/b/b3/K_is_for_kangaroo.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**L** is for **L**ion

  


![Lion-1.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Lion-1.jpg/400px-Lion-1.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[L is for lion](/wiki/File:L_is_for_lion.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/9/91/L_is_for_lion.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**M** is for **M**ouse

  


![Apodemus sylvaticus bosmuis.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Apodemus_sylvaticus_bosmuis.jpg/500px-Apodemus_sylvaticus_bosmuis.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[M is for mouse](/wiki/File:M_is_for_mouse.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/9/97/M_is_for_mouse.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**N** is for **N**est

  


![Hausrotschwanz Brutpflege 2006-05-24 211.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Hausrotschwanz_Brutpflege_2006-05-24_211.jpg/500px-Hausrotschwanz_Brutpflege_2006-05-24_211.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[N is for nest](/wiki/File:N_is_for_nest.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/4/49/N_is_for_nest.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**O** is for **O**ctopus

  


![Wonder octopus.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/4/41/Wonder_octopus.jpg/500px-Wonder_octopus.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[O is for octopus](/wiki/File:O_is_for_octopus.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/1/14/O_is_for_octopus.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**P** is for **P**ig

  


![Pig USDA01c0116.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/d/db/Pig_USDA01c0116.jpg/300px-Pig_USDA01c0116.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[P is for pig](/wiki/File:P_is_for_pig.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/d/d9/P_is_for_pig.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**Q** is for **Q**ueen

  


![Queen Victoria 1887.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Queen_Victoria_1887.jpg/300px-Queen_Victoria_1887.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[Q is for queen](/wiki/File:Q_is_for_queen.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/3/36/Q_is_for_queen.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**R** is for **R**oad

  


![Road in Norway.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Road_in_Norway.jpg/500px-Road_in_Norway.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[R is for road](/wiki/File:R_is_for_road.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/f/fa/R_is_for_road.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**S** is for **S**un

  


![April dawn.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/7/7c/April_dawn.jpg/500px-April_dawn.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[S is for sun](/wiki/File:S_is_for_sun.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/e/ec/S_is_for_sun.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**T** is for **T**urtle

  


![Sea Turtle.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Sea_Turtle.jpg/500px-Sea_Turtle.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[T is for turtle](/wiki/File:T_is_for_turtle.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/d/dc/T_is_for_turtle.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**U** is for **U**mbrella

  


![Umbrella.png](//upload.wikimedia.org/wikipedia/commons/0/06/Umbrella.png)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[U is for umbrella](/wiki/File:U_is_for_umbrella.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/a/ae/U_is_for_umbrella.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**V** is for **V**olcano

  


![Augustine Volcano Jan 12 2006.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/1/18/Augustine_Volcano_Jan_12_2006.jpg/500px-Augustine_Volcano_Jan_12_2006.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[V is for volcano](/wiki/File:V_is_for_volcano.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/9/96/V_is_for_volcano.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**W** is for **W**indow

  


![Gordijnen aan venster.JPG](//upload.wikimedia.org/wikipedia/commons/thumb/6/6a/Gordijnen_aan_venster.JPG/400px-Gordijnen_aan_venster.JPG)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[W is for window](/wiki/File:W_is_for_window.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/3/37/W_is_for_window.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**X** is for **X**ylophone

  


![Kulintang a Kayo 01.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/5/52/Kulintang_a_Kayo_01.jpg/500px-Kulintang_a_Kayo_01.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[X is for xylophone](/wiki/File:X_is_for_xylophone.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/2/2d/X_is_for_xylophone.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**Y** is for **Y**o-yo

  


![Wooden yo-yo.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/9/92/Wooden_yo-yo.jpg/300px-Wooden_yo-yo.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[Y is for yo-yo](/wiki/File:Y_is_for_yoyo.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/d/d5/Y_is_for_yoyo.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

**Z** is for **Z**ebra

  


![Zebra rownikowa Equus burchelli boehmi RB3.jpg](//upload.wikimedia.org/wikipedia/commons/5/53/Zebra_rownikowa_Equus_burchelli_boehmi_RB3.jpg)

  


— [A](/wiki/Wikijunior:Alphabet/A) [B](/wiki/Wikijunior:Alphabet/B) [C](/wiki/Wikijunior:Alphabet/C) [D](/wiki/Wikijunior:Alphabet/D) [E](/wiki/Wikijunior:Alphabet/E) [F](/wiki/Wikijunior:Alphabet/F) [G](/wiki/Wikijunior:Alphabet/G) [H](/wiki/Wikijunior:Alphabet/H) [I](/wiki/Wikijunior:Alphabet/I) [J](/wiki/Wikijunior:Alphabet/J) [K](/wiki/Wikijunior:Alphabet/K) [L](/wiki/Wikijunior:Alphabet/L) [M](/wiki/Wikijunior:Alphabet/M) [N](/wiki/Wikijunior:Alphabet/N) [O](/wiki/Wikijunior:Alphabet/O) [P](/wiki/Wikijunior:Alphabet/P) [Q](/wiki/Wikijunior:Alphabet/Q) [R](/wiki/Wikijunior:Alphabet/R) [S](/wiki/Wikijunior:Alphabet/S) [T](/wiki/Wikijunior:Alphabet/T) [U](/wiki/Wikijunior:Alphabet/U) [V](/wiki/Wikijunior:Alphabet/V) [W](/wiki/Wikijunior:Alphabet/W) [X](/wiki/Wikijunior:Alphabet/X) [Y](/wiki/Wikijunior:Alphabet/Y) [Z](/wiki/Wikijunior:Alphabet/Z) —

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[Z is for zebra](/wiki/File:Z_is_for_zebra.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/2/2a/Z_is_for_zebra.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Wikijunior:Alphabet/All_pages&oldid=2403858](http://en.wikibooks.org/w/index.php?title=Wikijunior:Alphabet/All_pages&oldid=2403858)" 

[See also](/wiki/Special:Categories): 

  * [Wikijunior:Alphabet](/wiki/Category:Wikijunior:Alphabet)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3AAlphabet%2FAll+pages&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3AAlphabet%2FAll+pages)

### Namespaces

  * [Wikijunior](/wiki/Wikijunior:Alphabet/All_pages)
  * [Discussion](/w/index.php?title=Wikijunior_talk:Alphabet/All_pages&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Wikijunior:Alphabet/All_pages)
  * [Edit](/w/index.php?title=Wikijunior:Alphabet/All_pages&action=edit)
  * [View history](/w/index.php?title=Wikijunior:Alphabet/All_pages&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Wikijunior:Alphabet/All_pages)
  * [Related changes](/wiki/Special:RecentChangesLinked/Wikijunior:Alphabet/All_pages)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Wikijunior:Alphabet/All_pages&oldid=2403858)
  * [Page information](/w/index.php?title=Wikijunior:Alphabet/All_pages&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Wikijunior%3AAlphabet%2FAll_pages&id=2403858)

### In other languages

  * [Français](//fr.wikibooks.org/wiki/Wikijunior:Alphabet)
  * [עברית](//he.wikibooks.org/wiki/%D7%A1%D7%A4%D7%A8_%D7%90%D7%9C%D7%A3_%D7%91%D7%99%D7%AA)
  * [Türkçe](//tr.wikibooks.org/wiki/Viki%C3%A7ocuk:Alfabe)
  * [Azərbaycanca](//az.wikibooks.org/wiki/Vikiu%C5%9Faq:%C6%8Flifba/A)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Wikijunior%3AAlphabet%2FAll+pages)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Wikijunior%3AAlphabet%2FAll+pages&oldid=2403858&writer=rl)
  * [Printable version](/w/index.php?title=Wikijunior:Alphabet/All_pages&printable=yes)

  * This page was last modified on 4 September 2012, at 19:11.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Wikijunior:Alphabet/All_pages)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
