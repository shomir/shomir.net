# Physical Activity/Print version

From Wikibooks, open books for an open world

< [Physical Activity](/wiki/Physical_Activity)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

  


## Contents

  * 1 Aerobic Exercise
    * 1.1 What Happens to the Body During Aerobic Exercise?
    * 1.2 Types of exercises
    * 1.3 Method: Using heart rate as guide
      * 1.3.1 Energy output analysis
    * 1.4 Warming up and cooling down
    * 1.5 Specific exercise tips
      * 1.5.1 Treadmill
      * 1.5.2 Bicycling (Biking)
        * 1.5.2.1 Tips about buying a bike and accessories
        * 1.5.2.2 Benefits of bicycling
  * 2 Strength Training
    * 2.1 Types of exercises
    * 2.2 Overload and overtraining
    * 2.3 What is adequate rest?
  * 3 Sports
  * 4 Injury
    * 4.1 Major possible Injuries
    * 4.2 Injury prevention and stretching
    * 4.3 Treating injuries
    * 4.4 See Also
  * 5 Nutrition
  * 6 Aerobic Exercises
  * 7 Back Exercises
    * 7.1 Exercise One
  * 8 Improving Your Vertical Jump
    * 8.1 Exercises
    * 8.2 Tips
  * 9 Muscle Building
  * 10 Pulldown Exercise
  * 11 Running a Marathon
    * 11.1 Welcome!
    * 11.2 Getting Off The Couch
    * 11.3 Plotting Your Course
      * 11.3.1 Choosing your marathon
    * 11.4 Starting Out
      * 11.4.1 Creating a Training Plan
    * 11.5 Tapering
    * 11.6 Preparing for Your Race
    * 11.7 After Your Marathon

# Aerobic Exercise

Aerobic exercise is generally exercise that is done over a long period of time, typically 20 minutes or more. It is used to tone the body, make it leaner, and improve endurance by keeping the cardiovascular system healthy. Although getting any exercise is healthy, getting at least 20 minutes of sustained aerobic exercise about 3 times a week, along with a good diet, will generally keep a person healthy.

Technically, aerobic exercise is exercise that mainly uses energy from the cells in the muscles of the body doing aerobic respiration. Aerobic respiration of a cell is when the cell uses oxygen to burn energy (aerobic means "requiring air (or oxygen)"), unlike anaerobic respiration where the cell does not use oxygen when it burns energy. Cellular aerobic respiration can potentially be 18 times more efficient than anaerobic respiration, and aerobic respiration produces less toxins in the cell. Because of this, the cell will try to do aerobic respiration whenever it can, but it will do anaerobic respiration to get energy when it lacks oxygen.

Exercises that are less intense but last longer allow the body to give the muscles oxygen as they are using it up, and keep them doing aerobic respiration. More intense exercises use up the oxygen in the cells faster than it can be replaced, so the cells divert to anaerobic respiration to get the energy they need.

## What Happens to the Body During Aerobic Exercise?

A lot of energy is not used during aerobic exercise, so the body will burn fat by converting it into sugar for the cells to use as energy. If aerobic exercise is sustained for more than 20 minutes, it is especially healthy because the body will continue to burn fat for several hours afterward.

Aerobic exercise requires a lot of oxygen, so many things in the body do change. The heart rate increases, and the volume of blood per heart beat increases, to circulate the oxygen in the blood to the muscles faster, and remove toxins from the cell faster. This increases the blood pressure. To get more oxygen into the bloodstream, and get toxins out, the breathing rate increases, and the lungs expand and contract more.

Lactic acid is produced and will cause a burning sensation in the muscles. The body will try to get oxygen to the muscles as fast as it can, but it is not always able to give the muscles all the oxygen they need. When this happens, the muscles will shift to anaerobic respiration until they can get the oxygen they need. This usually happens during any aerobic workout, if the person is trying to push him or herself. When it does happen, the muscles will produce many toxins that are created during anaerobic respiration, and then the cardiovascular system will try to cleanse those toxins as fast as it can. When the cardiovascular system cannot remove the toxins as fast as they are created, they build up. When a person experiences pain in their muscles because of working out, it is usually because of lactic acid building up (unless the person has pulled a muscle or damaged something).

One good benefit of getting aerobic exercise is the release of endorphins, which are chemicals in the brain that reduce the feeling of pain and make a person feel better. They are sort of like the body's natural pain medicine, and they make a person feel good. Sustained aerobic exercise for a long period of time, like during a marathon, can be euphoric because of endorphins. They are released to reduce the pain a person feels during aerobic exercise.

A person who regularly does aerobic exercise will develop a healthier and stronger body. Their heart will be stronger, and pump more blood per heartbeat, making it more efficient, to handle the increased blood circulation required for aerobic exercise. This will allow the person to have a lower heart rate when resting, and make them feel better. The lung capacity and efficiency at transferring material between the air and the bloodstream will increase to handle the extra oxygen required during aerobic exercise. This will allow the person to breathe less when resting, making them feel better. The arteries, veins, and capillaries will become more efficient to handle the increased blood circulation. The muscles will increase their efficiency and more blood vessels will be created in the muscles. Coordination will increase. The person will feel better because of having more endorphins in their brain. The muscles, bones, organs, and other tissue will become stronger to handle the impact that exercise will give to them. Burning more energy will require eating more, but even if a person eats more, the person can more easily lose fat by working out.

## Types of exercises

  * Swimming
  * Dancing
  * Walking
  * Running
  * Climbing Stairs (sustained for 20 minutes or more)
  * Team Sports
  * Rollerblading
  * Rowing
  * Chopping Wood (sustained for 20 minutes or more)
  * Cross Country Skiing
  * Hiking
  * Jogging
  * Cycling
  * Calisthenics

## Method: Using heart rate as guide

![Nuvola apps important yellow.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Nuvola_apps_important_yellow.svg/40px-Nuvola_apps_important_yellow.svg.png)

Use at your own discretion. This is **NOT** medical advice. Any change in lifestyle involving massive change in physical activity should be under doctors supervision.

When we start conditioning, at first, our heart beat goes up to high levels even with very moderate forms of exercise. The reason for this is that our cardiovascular system and our respiratory system are not conditioned. In other words, they are not very effective for a person who has not exercised for years. But once we start exercising, these systems keep on becoming more and more effective and conditioned. Our heart becomes stronger and our lungs become stronger. Our body is able to supply more oxygen to the muscles in an easier fashion.

Similary, the muscular system becomes more efficient. Our muscles are able to produce more work by using more energy. A fit and conditioned individual can work more through his muscles than a deconditioned person. His muscles are stronger and better adapt at working.

So, as we train, our body can supply more oxygen, more easily, and the muscles can use that extra oxygen to do more work more easily.

Therefore, no matter if you are a fit individual or some one who has been living a sedentary lifestyle for the past many years, you can use heart rate as an effective guide line for your exercise intensity. Your heart rate will tell you how comfortable your body is while exercising. It is one measure that is tailored to your body's ability to perform. Other methods like your speed or inclination or resistance etc. are not tailored to your ability. An unconditioned individual might be struggling at a speed, at which a trained individual is barely breaking a sweat. However, the heartbeat will tell a different story.

Here is the theory behind using heart beat as a guide:

The maximum heart rate is your heart's response to increased oxygen demand and your body's attempt to oxygenate (meaning supply your body with oxygen). It declines with age variably and there is an interindividual variability as well. Here is a rough approximation for the maximum heart rate for an individual:

Maximum Heart Beats Per Minute = 220 - (age in years)

This is a very raw approximation but it doesn't matter that much. Better approximation can be achieved for an individual by putting on a good heart rate monitor and running as fast as possible for at least 2 minutes in an untrained individual to see how high his/her heart beat goes.

Now, by exercising at heart beat about 70% - 80% of maximum heart beat, a person successfully improves his body, while remaining in a comfortable zone.

Even 65% - 70% bpm of max, is a good conditioning zone that is very comfortable and produces constant bodily improvement.

There is no need to push too much. Remain at 70% - 80% : it is very comfortable and gives huge improvements.

For example, I am 25. My maximal heart beat is ~195 (220 - 25).

For me:

    70% of maximal heart beat is 136 bpm.
    75% of maximal heart beat is 146 bpm.
    80% of maximal heart beat is 156 bpm.
    85% of maximal heart beat is 166 bpm.
    (These are all approximations).

During exercise, if I keep my heart beat at about 70% - 80%, I will have significant benefits. If I want, I can push it to 75% - 85% (85% is the upper limit). It is usually sufficient to remain around 70-75%. As an alternative to measure the heart rate run and try to talk at the same time. If you can do this without significant shortness to breath will have reached approximately 70% of your maximal heart beat.

Note that, for an untrained individual, even very moderate exercise will bring his/her heart beat pumping really fast. That means that they can easily remain very comfortable and get significant health improvements. Very soon they will find that their heart beat does not rise that sharply.

Invest in a good heart rate monitor. I think, polar makes excellent heart rate monitors. Buy the ones that have a chest strap. Many professional treadmills can read the heart rate readings from the chest strap - so you don't need to carry the wrist watch with you (that comes with the chest strap). I found the chest strap heart rate monitors to be much more accurate.

### Energy output analysis

    Deconditioned individual - maximum energy output = 6-7 times resting energy expense
    Conditioned individal - max. energy output = 10 - 12 times resting energy expense

A person can only sustain about 20% of maximum energy output throughout the day, without getting fatigued over time.

Therefore,

    Deconditioned Individual can spend about 20% of 7 = 1.4 times what he would spend sitting/lying whole day.
    Conditioned Individual can spend about 20% of 10 = 2 times what he would spend sitting/lying whole day.

Considering that sitting/lying whole day (basal metabolic rate) is about 2000-3000 calories for most people, a difference of .6 (2 - 1.4) times basal metabolic rate is

    1200 - 1800 extra calories per day that a fit individual can spend compared to a deconditioned individual. Do you have any idea how much difference these 1200-1800 calories can make!

Base line - become fit.

Aerobic exercise, Running for example, is a pleasure and it gives the best feeling in the world to run. Don't overdo it and give your body time to slowly increase in efficiency and capacity.

As heart and respiratory systems become stronger, the body's peak capacity as well as endurance increase. As muscles become stronger and more effective, body's peak capacity and endurance increase further. The whole body becomes more powerful and stronger.

## Warming up and cooling down

It is very important to warm up before suddenly increasing the intensity of your exercise. It is equally (if not more) important to slowly cool off. These two things prevent injury. When warming up, you slowly bring your body into the correct state for more intense exercise, without this warm-up phase the body's muscles and tendons are tight and prone to injury thus it's important to warm up to prevent injury. The cool down is important for recuperation of your body. If you don't allow for a proper cool down, lactic acid more readily and easily builds and stays in your muscles. This acid slows down the healing process and makes you sore. Generally, 5-10 minutes to warm up and about 5 minutes to cool down is sufficient. During the cool down, it is a good idea to write down your daily exercises.

After both the cool down and warm up phase, 5-10 minutes of stretching should follow. This also prevents injury, helps in recuperation, and helps to alleviate lactic acid buildup.

## Specific exercise tips

### Treadmill

I found treadmill to be an excellent machine for aerobic exercise. I have always loved running and treadmill makes it so easy.

Running on a treadmill, lessens chances of injury. This is because you don't need to be careful of the terrain (road, bumps on the road, foot path etc.), or vehicles or other things. No problems with weather. Also, most good treadmills absorb the shock, making the running more comfortable for your legs.

Also, most treadmills have excellent programs built into them. These programs have been designed by experts and use contemporary exercise theories. Programs like heart rate based programs, can use your heart rate monitors to adjust the inclination etc.

One thing to note is to accurately simulate running outside, you should set the treadmill at at least a 1% grade or higher. With the higher grade, you will be pushing more against the treadmill than the treadmill will be pushing your feet along.

Important Tip: Don't ever forget to clip the stop button to your self. You never know when you might lose a step or something and end up falling. The last thing you want is the belt burning your back or increasing your injury by throwing you around. Always, clip that stop button to your clothes. This is extremely important if you are going to run at a fast pace.

Heart Rate Monitor Guide: I think most treadmill heart rate monitors lack precision. A good heart rate monitor would be a good investment if you plan on exercising seriously.

### Bicycling (Biking)

Biking is another excellent aerobic exercise, besides being immensely entertaining.

#### Tips about buying a bike and accessories

Shoes 
    Get special biking shoes. If your pedals have the lock-in mechanism, get matching shoes. The shoes can be "clipped" into the pedals. The term 'clipless' refers to the older mechanism that locked your foot, which was a cage like system, the clip. Pedals without this system but that offer the possibility to lock your foot are called clipless. That allows you to pull the pedals up in addition to the usual push down. That allows you to complete a full rotation instead of each leg just completing a partial rotation. In addition to using more muscle groups you can, with practice, develop a smoother pedal cycle with greater stability and thus allowing higher cadence. Higher cadence is essential for cardiovascular stress and training. Note that, some basic practice is needed to be able to easily unlock and lock your feet and to immediately unlock your feet in case of emergency.

Cost 
    Don't buy a very expensive bike. I made this mistake and I don't think that my bike justifies the expenditure. It does not matter that you bike is 1 lb. lighter. It will pinch you for long if you belong to the category that most of us belong to.

Pump 
    Tire pressure is essential for optimum performance. Correct tire pressure will yield a sufficiently low rolling resistance of the tire and a minimal risk of flats. Under-inflating will result in a softer ride but also increases the risk of 'pinch flats' caused by squeezing the tire between the ground and the rims when hard cornering. Also, rolling resistance is significantly increased resulting in less then optimal speeds. Over-inflation only reduces the rolling resistance marginally but creates some other issues such as easy puncture flats and bouncing behavior, compromising bike stability. The pressure required is a variable depending on driver weight, the kind of tire and ride circumstances.

Tires 
    The choice depends on the kind of bike. There are specific tires for each kund of bike. The difference is in tire width and profile. The wider the tire, the higher the rolling resistance because of larger contact area, but also the higher the grip on the surface. Profile refers to the tire surface, this can be smooth (slicks) or heavy profile like on mountain bikes. The heavier the profile the more drag and grip it has on loose surfaces such as mud and sand. There is absolutely no point in any profile when the only surface you ride on is asphalt (road). With this in mind, a road bike has a thin smooth tire with the lowest rolling resistance and a mountain bike will have a wide tire with heavy profile for optimum grip on rough surfaces. City bikes, cyclo-cross bikes or other models may choose for something intermediate.

Other Accessories 
    Accessories are optional but can be useful. The use of a helmet is heavily debated and a little out of the scope of this article. Cycling gloves may offer protection against RSI (repetitive stress injuries) from leaning on the handlebars by means of the padding in them. They can also offer extra comfort when riding rough surfaces. Most professional cyclists wear them but the choice remains your. Glasses provide you with cover for dust and bugs but may also provide a hinder during heavy weather. Cycle clothing has several uses but may dramatically improve riding comfort, especially when riding for greater distances. Cycling shorts are essential in preventing shearing injuries from leg action under sweaty circumstances. The jerseys are in a fabric that allows sweating while still keeping warm. Basically the lycra allows for a more optimal thermoregulation, in addition they provide back pockets. Another good accessory - heart rate monitor. Its fun to see your heart rate once in a while. Another good accessory - an electronic speedometer, mileage computer. They are cheap and it's a pleasure to see how many miles you did today and the total number of miles so far.

#### Benefits of bicycling

  * Very Entertaining - Biking is probably one of the most entertaining exercises out there. Although, every exercise gives pleasure and has a unique fun attached to it, riding a bike is like gliding. You feel the fresh air brushing your face and body. You get to see many places. Biking is really fun.
  * Fresh Air - Cycling is something that gives you an opportunity to catch a breath of fresh air, literally.
  * Low Impact - Cycling is easier on your bones than running.
  * Hiking while Biking! You can literally go places on your bike. It is not too hard to bike 30 miles in a day (even if you are not very trained, although, your muscles might be a bit sore the next day). You can see parks, cities, neighborhoods on your bike.
  * Practical - You can commute to work / school on a bike to save money on gas.

  


# Strength Training

There are two important concepts when considering strength training. First, strength training does not necessarily mean that your body will get huge and bulky with muscle. Second, strength training, if done appropriately is important in preventing injury, but if done irresponsibly can cause injury.

Strength is a subject measure. There are many types of strength, such as endurance, pushing, holding, throwing, snapping, and pulling. These strengths are trained for in different ways. For strength irregardless of speed, slow and heavy weight training is the most effective. While, for speed strength fast, high-intensity, exercise is the most effective. It is very difficult to become both fast and extremely strong, they are usually incompatible for the muscles to handle given strength usually increases muscle bulk. Fortunately, the human body can handle being very fast and moderately strong as well as very strong and moderately fast.

The first concentration is building pure strength regardless of speed or muscular endurance. The most effective way to do this is by free weight training. This is one of the main objectives in both body building and powerlifting. The main principle is to set goals to slowly increase the amount of weight your body can lift.

For example, I have a goal to bench press 200 lbs with 8 repetitions for 3 sets and I can only bench press 140 lbs with 8 repetitions and 3 sets. I might start off by increasing the weight of my bench press by 5 lbs. When increasing the weight, I may only be able to bench press 6 repetitions. The next time I am at the gym, I will set the goal to do 7 repetitions with 145 lbs, and the next time 8. After I reach 8, I can increase it another 5 lbs, and so on until I reach my goal of 200 lbs.

Whereas, with muscle endurance training, you train your muscle to constantly work. For this type of training, increasing the total amount of repetitions or sets is a good way to increase muscle endurance. In fact, good muscle endurance is important for muscle strength. Many professionals recommend alternating weeks of strength training and muscular endurance training in a strength training regimen.

For speed training, slowly lifting weights simply won't work. You have to use explosive exercises, like sprints, jumps, and pushes. Explosiveness is especially important in sports. A few examples are in baseball explosive strength is used when swinging a bat; in hockey, when taking a shot; in boxing, when throwing a punch; even in surfing, explosive strength is used to balance on a wave.

This brings me to my next point in strength training: setting sub-goals to your main goal. Basically, you didn't learn to run right away you had to learn your first step, then your first walk, until finally, you trained your body to run. It other words, you need to create small successive steps to reach your goal. It makes a daunting task like increasing your bench press by 60 lbs into a doable endeavor. It is important to set doable sub-goals as well, and when you accomplish those sub-goals it gives you motivation to continue working toward your main goal. In fact, the more sub-goals you set for yourself, the more effective training you will have since you will feel accomplished more often than feeling a failure which keeps self-esteem high.

Goal setting is important in anything, and especially important in building strength, but there are specific things to weight training that should be adhered too. First, don't worry if you are weak at first. In reality, everyone has to start off and most of the time, people are weak when they start and even the massively strong people understand what it's like to just start off which makes them encouraging and non-judgmental. Second, strength building is a slow process and requires hard work. If you push yourself too hard you could injure your muscles, joints, and tendons for life. It's not worth being stupid and lifting more than your body can handle, just take it slow and your gains will come in time.

## Types of exercises

  * Benchpress
  * Pushups
  * Chinups
  * Bicep curls
  * Tricep press

## Overload and overtraining

Our body is capable of performing at much higher intensities than what it can sustain for long. This is called peak energy output. When lifting weights, for example, we can sometimes lift weights that are almost at dangerous levels for our present state. We might not realize that we are pushing ourselves to those high levels because the body seems to be able to do it.

It happened many years back, I was doing wrist curls. I was lifting almost 100 Lbs. When I look back at it now, I say to myself "how foolish that was?". That day I tore a ligament (or tendon - don't know the exact technical term) in my wrist. It has been years from that day but I still can't lift 20 lbs. using my wrists without pain.

Sometimes it is too easy to push ourselves and we don't realize that we are crossing the delicate line.

It is better to remain moderate. One injury can cast a huge setback for years. It is better to gain slow and steady - from my own experience.

Another hindrance to health is overtraining. Overtraining occurs when you literally exercise too much, or too hard. This happens often with people who weight train. This is because they will lift weights on the same part of the body two or more days in a row, without giving time for the muscles to rest and recuperate. This isn't limited to weight trainers, since an intense exercise can overwork the human body. It is important to give your body adequate rest.

Overtraining harms your body so much that it makes you weaker, takes time to heal, and lowers your immune system. It is counterproductive! Overtraining often happens because people think that they must "feel the pain" to accomplish their exercise goals. This simply isn't true, if you exercise appropriately you should not feel pain, in fact, some professionals recommend not even working out when sore. Although, others think that you shouldn't work out as hard when sore, but, working out is beneficial since it helps to move lactic acid out of the muscles.

## What is adequate rest?

Adequate rest differs from person to person given differences in metabolism and genetics. One person may be able to curl dumbbells every two days without overtraining the muscles, while another person can only train them once a week. Usually, the longer a person has been training and the younger they are, the less time they need between training sessions. As well, the harder you work during a training session, the longer you will need to rest before training again. It is important to remember that the resting period is reduced by proper nutrition and sleep.

Generally, if weight training, a person should, at minimum, wait 48 hours before working out the same muscle group and if body building, the wait should be extended to 72 hours. Cardio exercise can be performed every 24-hours for most people. With both, one day a week should be used to rest without any exercise at all.

The best way to figure out your training threshold is to start off with light training and slowly increase the amount each successive training session. This will allow you to figure it out without the worry of injury or overtraining.

  


# Sports

Fundamentals/Techniques of Casting

Stand directly facing the target or slightly sidewise, with the right side (if right handed) towards the target and the right foot slightly advanced. The arms should be held in a relaxed "natural" position with the elbow at or near the side. The target should be aligned by looking at it through the top of the tip. When the rod and target are properly "ligned up", the tip of the rod brought in and up sharply to a vertical position and stopped suddenly the instant the backward motion of the tip stops. In order to control the line, it is necessary to thumb the spool when using the conventional reel. The tip of the thumb may be placed entirely on the line and partially on the flange of the spool. The thumb should apply firm pressure as the rod is brught back for the cast and held until the rod cmpltes its forward movement. The pressure is eased on the forward cast at about ten 'clck position, allwing the line to run, and then increase again just before the bait hits the target. As the rod reaches the vertical position, the grip of the three fingers is relaxed thst the rod breaks away from the palm. Beginning downward movement, they should be closed again. To bring the rod down, one must be careful to pass again through the "aiming zone" sighted at the beginning of the cast. The eyes should be "pick up" the plug soon after it is released, keeping the rod, line and target in alignment. The rod must be shifted to the left hand. The right hand grasps the handle of the reel and begins to reel in the line.

  


# Injury

## Major possible Injuries

One of the common kinds of sports and fitness-related injuries (non major) are strains, depending on the kind of fitness you are practicing, these can be localised in the arms or legs (most commonly) but also in the back area (not uncommon). It is important to watch back strain and possible injury very closely as it can become a long-term problem or conceal other medical problems.

It is not uncommon for strains and other minor injuries to not be obvious at the time of injury, usually developing later during the same day or the next morning (this may be caused by the body still being full of anti-pain chemicals that prevent the body unfit for activity that may increase its survival).

## Injury prevention and stretching

One of the best ways to decrease the amount of injuries you encounter in sports and fitness are uses of proper stretching and warm up/cool downs. warming up is the activity of preparing your body for the fitness activity and cooling down is the end part of a physical activity. A key part of both of this process is stretching, during this activity light movements are undertaken that increase your flexibility and decrease the likelihood of strain injuries

More major injuries are often course by lack of care being taken during proper short and fitness activities, it is vital that you read information available to you and make sure you are using the equipment (including safety gear correctly)

Stretching exercises usually take the form of extending a muscle (see Static and Dynamic) through a slow movement arch that exercises and prepares the muscles for training, it is important that a large group of muscles that are going to be used in the main exercises are stretched prior to it, stretching is also generally more effective after a short warm up.

  * A simple work out plain that might be followed: 
    * 10-20min warm up aerobic exercise gradual rising intensity.
    * Stretching program of 5-10min (depending on results wanted).
    * Strength training or other form of activity.
    * 10-20min cool down aerobic exercise with gradual lowering intensity.
    * Reverse stretching program.

## Treating injuries

![Nuvola apps important yellow.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Nuvola_apps_important_yellow.svg/40px-Nuvola_apps_important_yellow.svg.png)

None of this advice should ever replace real medical help!

Firstly it is a recommended that you delay any further fitness activities, most often minor strains and injuries will fade after a few days of decreased over all activity.

Usually of effective use are the commonly on sale at most supermarkets are topical jells that can ether numb pain in that area (such as UK product ibuprofen jell) or ‘heat’ the area to ease strains (UK product ‘deep heat’) these are useful products but are best used only as directed and not over used if the pain is worse, they are short term treatments for temporary pains only.

## See Also

[yoga](http://en.wikipedia.org/wiki/yoga) \- a useful canon of stretching techniques

[Static stretching](http://en.wikipedia.org/wiki/Static_stretching)

[Dynamic stretching](http://en.wikipedia.org/wiki/Dynamic_stretching)

  


# Nutrition

These are just general nutritional guidelines. Since there is variation between individuals, there are individual needs. These suggestions should create a healthier life for most people; however, some people will have to consult a nutritionist for a diet to fit their needs. Also, it should be noted that being in good health does not equal being the media's image of beauty. Most people cannot fullfill the Super-Model or Super-Ripped image that's often seen in advertisements or on TV. In fact, some people are most healthy when they are carrying a higher-than-average level of body fat recent scientific evidence suggests that being slightly over-weight (not over-fat) may, in fact, be more healthy than being average weight or underweight.

Please remember, these nutritional guidelines are not a weight loss guide, although many people will lose weight if they are followed. These are guidelines for more healthy living, and that means eating this way should improve your energy levels, your immune system, your ability to heal, and your mood! It is all to important to emphasize this point: eating and exercising correctly will do you no good for being healthy if you are not happy with the genetics you were born with, in other words, you may carry additional body fat naturally and it's unhealthy to try and lose it. Since mental health is as important as physical health it is vital to realize that you need to be happy with yourself! While exercise is very important to good health, to get into optimal shape a proper nutrition regimen must be mantained. As the old cliche goes, "You are what you eat" more specifically, your body is fueled by what you eat, and your body is built and repaired by the macronutrients you eat. Like any responsible car owner knows, if you put dirty lead-based fuel into your car or build it with bad parts it runs less smoothly, and the car is more prone to failure than if you use unleaded fuel or good parts. This is a great analogy to the human body, if you eat dirty foods, your body will not perform as well as it could and it will be prone to illness and injury.

The human body is designed, or has evolved to run well on certain fuels. Unfortunately, McDonald's french fries are not it. When considering the evironment which our ancestors lived in, it is easy to see what types of foods our bodies are meant to be fed. For example, the carbohydrates that they ate were mostly berries, nuts, beans and legumes. All of these are very high in fiber and low in sugars. In contrast, the typical western diet is low in fiber and high in sugars. Low-fiber diet is believed to cause many health problems, including chronic constipation, hiatal hernias, intestinal infections, colon cancer, and digestion problems. High sugar diets are believed to be the leading cause of adult onset diabetes as well as obesity. These problems are almost entirely absent in "hunting and gathering" cultures that eat much like our ancestors ate.

Our ancestors also hunted or fished for meat. Unlike farm raised animals, hunted animals and fish are much more lean, or have less fat. Fat is not necessarily a bad thing and the human body needs a certain amount, and recent research suggests that plant fat (oils) and fish fats are extremely healthy; however, animal fat or saturated fat is unhealthy in large quantities and is one of the leading factors in heart disease and obesity.

In fact, our ancestors most likely got their fat intake mostly from plants. The unsaturated fats in plants have been found to increase metabolism, and improve the efficiency of food as a fuel source. This is much like what an octane booster does in a car, it helps to break down the fuel into a usable source while wasting less of it.

Like a car, the human body needs many things to run well. The engine in the car needs to have clean oil, it lubricates the engine and allows it to use fuel more efficiently. In the human body, water does much the same thing. Adequate water intake (hydration) is vital for the human body to use its fuel. For all useful purposes, hydration specifically refers to drinking water and no other liquid. Other liquids contain impurities that can intefere with water intake, they can also be consumed, but drinking water alone is vital. A good rule of thumb in water consumption is to have 1 cup of water per 15 lbs of body weight. The water intake should also be spread throughout the day, and is easy to attain if you drink a glass or two of water with every meal.

It is a good idea to eat at least 5 meals a day. These shouldn't be the standard sized meals, but smaller meals. Eating about as much calories as you eat in 3 meals spread over 5 or more meals a day keeps the body fueled. Unlike a car, the body runs better when it is constantly fueled. This is because our body is more advanced than a car, and it will store the energy as fat instead of using it, depending on the conditions it is given. That happens to be (not counting the time asleep), for the average male, more than 4 hours without a meal, and for females, more than 3 hours without a meal.

All meals do not have to be created equal. A meal can consist of a 120 calorie energy bar, or it can be a 400 calorie sandwich. The important thing is to stop eating when you feel satiated (no longer hungry) instead of stuffed (full), and to eat the right kinds of food.

The right kinds of food are conveniently provided by the US Department of Agriculture in their recent revision of the food pyramid. In this revision, the different food types are better separated. Such as, whole wheats (high fiber, low sugar) are separated from white grains (low fiber, high sugar), and lean meats (poultry, tuna, lean beef) are separated from fatty meats (most red meats, bacon).

In the new food pyramid nutritional intake is as follows:

  * Whole Grains - Eat at most meals, no limit
  * Plant Oils - No limit
  * Vegetables - In abundance
  * Fruits, 2-3 times daily
  * Nuts and Legumes, 1-3 times daily
  * Poultry, Eggs, Fish, 0-2 times daily
  * Dairy or Calcium, 1-2 times daily
  * Red Meat - Eat sparingly
  * White Pastas, Potatoes, White Rice, Sweets and White Breads - Eat sparingly

As you can see, the new food pyramid covers many of the principles covered in the "body as a car" section. First, it emphasizes whole grains and vegetables which are high in fiber and low in sugars (aka complex carbohydrates). It also suggests our octane booster, or the plant oils. It shows to rarely eat starchy foods, like white pastas; this is because they contain a lot of sugars (aka simple carbohydrates) which are correlated with diabetes and obesity. As with most things, there are some exceptions in the food pyramid left out most likely for simplicity. For example, it focuses on high-fat, high-calorie nuts as protein sources, ignoring the use of leaner cuts red meat of which contain less fat than poultry and for which no health problems have been proven, and suggests that the consumption of no non-dairy animal products is healthy, when in fact such a diet tends to be lacking in iron

Ideally one should not aim to lose weight (lowing your BMI) but rather to create an ideal body fat percentage (see table below) based on there age, build and individual needs. Aside from fatty tissue, the majority of one's weight comes from muscle tissue(s), bones, and organs (body composition is the percentage of "other stuff" to fat within the body). Losing muscle mass is not a very good idea especially when trying to reduce body fat percentage. If one is trying to become healthy the more muscle mass you have, the more energy you expend even while resting, as well, muscle mass helps to protect your body from injury, thusly having adequate muscle mass can assist in maintaining a healthy body composition. As a positive side-effect, requiring more energy to sustain, which, in turn the body can draw from stored body fat and give you a "thinner" look. It is important to remember that safe fat loss should not involve the loss of more than 1-2 pounds (0.5-1kg) per week. In most cases, if one is losing weight very rapidly (more than 2 pounds or 1kg per week), then most the lost weight is due to lost water. In this case, the lost weight is very easily replaced once you rehydrate yourself.

As well, losing more than 1-2 lbs per week is counter-productive. In addition to the fat that's lost is atrophy of muscle (losing protein within the muscle fibers thus decreasing the mass of muscles), and losing muscle mass lowers your metabolism and causes the body to go into "starvation mode" in which it stores food as fat more easily. This might result in weight loss, but it will also result in a higher percentage of body fat and worse overall health. It will also be temporary, and will most likely result in greater fat and weight gains.

It should be mentioned again though: weight loss should not be an important factor in a healthy lifestyle. The only concern should be good health and being happy. Being in good health requires proper exercise and nutrition of the body and the mind. To achieve this is to change your lifestyle which is not just "going on a diet". It requires learning about nutrition and exercising, making goals and a plan for those goals, and following through with them.

One last thing to wrap up the basics about nutrition: sunshine. Sunshine is a must: it has been proven to improve mood, prevent depression, and produce vitamin D! In fact, there is no way to get an adequate amount of vitamin D from food alone, you must be out in the sun to produce it. Sunlight chemically reacts with your skin to make vitamin D.

Though contrary to popular belief, being outside in the sun "unprotected" is healthy for you in small doses. These doses range from between 10 and 45 minutes a day, depending on your skin tone and UV index. The rule of thumb is, the darker your skin tone, the more time you need to spend in the sun for adequate vitamin D production. Of course, remember that prolonged exposure to the sun unprotected is dangereous, and for anything longer than this time period you should wear sunscreen.

  


# Aerobic Exercises

[Physical Activity/Aerobic Exercises](/w/index.php?title=Physical_Activity/Aerobic_Exercises&action=edit&redlink=1)
    
    
    (To be merged)
    

# Back Exercises

Maintaining a strong back will reduce pain and injury to people with back problems

Exercises should have the tingling sensation of a stretch, but shooting or painful burning indicate that you should stop the exercise. While a personal trainer is useful, it is good enough if you use common sense and exercise with a friend. A personal trainer is not a doctor, if you hurt yourself, the personal trainer cannot snap you back into place. They will do exactly what an exercise partner or friend would do, call for help. But these exercises are not dangerous, and if you mind your conditions and be cautious, they are completely safe.

## Exercise One

Get on your hands and knees. Now, lift your right arm and your left leg. Straighten them up in the air. Hold for 2 seconds or as long as you are comfortable holding. Get back on all fours, then lift your left arm and your right leg. Repeat this process always using opposite sides of legs and arms. If you are tense, you might not be able to completely extend your leg or arm, in this case do not push it, just go as far as you comfortably can and repeat the exercise. Over many repetitions over several days, you should be able to get closer to extending those arms and legs straight. Also, do not forget to breathe. Either because of the difficulty of the activity, or because of the percieved difficulty of it, some people hold their breath, sometimes out of a habit of holding breath or not breathing naturally when exercising. In general, it is a good idea to breathe through your nose if you can. This will be less tiring than breathing through your mouth.

If you like, you can do this exercise on top of a towel, or a stiff foam mat. It is important not to do exercises like this on a bed or other springy, non solid surface. But it can irritate your knees to be on all fours, so you can do this exercise on a blanket, towel or camping mat.

  


# Improving Your Vertical Jump

Whatever your game or sport, there's a good chance that increasing your vertical jump will improve your game. Having a good vertical jump is very useful in almost every sport today because more and more athletes are spending more time in the air. Here are a few exercises that helped me increase my vertical by six inches. I went from barely grabbing the rim, to being able to dunk with one hand off of the dribble and catching alley hoops with two hands.

## Exercises

  1. Find a place where there are a lot of stairs and run them until your legs burn. Find a certain number of repetitions that are challenging and gradually increase them over time. This will also help with your conditioning.
  2. Stack those aerobics boxes and platform things against a wall for support. Start with light weights (5 lb.) and then jump with your right foot facing the box and then jump off. Then alternate with your left foot, then two feet. Repeat for another repetition starting with your right foot again. Then start the entire process over only this time you jump sideways onto the box. This will help your vertical jump even more because it hits your muscles from a different angle.
  3. Jump rope for quickness and explosion

## Tips

You do not have to use heavy weights. In fact, they will increase your risk of getting injured.(do not exceed 10 lb.) When you land, make sure you are balanced and there is a slight bend at your knee.

  


# Muscle Building

[Physical Activity/Muscle Building](/w/index.php?title=Physical_Activity/Muscle_Building&action=edit&redlink=1)
    
    
    (To be merged)
    

# Pulldown Exercise

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A Wikibookian has nominated this page for cleanup.**  
You can [help make it better](//en.wikibooks.org/w/index.php?title=Physical_Activity/Print_version&action=edit). Please review any [relevant discussion](/w/index.php?title=Talk:Physical_Activity/Print_version&action=edit&redlink=1).

The lat pulldown is an excellent exercise for working the Lattissimus Dorsi. When doing this exercise there are several things to focus on.

  * Begin by sitting in an upright position with the thigh pad set snug against the thighs.
  * Next, the grip of the bar should be outside shoulder width (wide grip).
  * Now grip the bar with palms pronated (facing away from you).
  * Once you have the proper grip, slightly recline while maintaining the arch in your back. This allows for a better angle and better clearance during the ROM (range of motion).
  * The important factor here is to maintain this angle by keeping proper posture. NO SWINGING OF THE BODY - to help think of pulling your belly button towards your spine and continue keeping your core contracted. This is your starting point.
  * Now the most important factor when working the lats: 

    Your first motion should begin by pulling the scapula (shoulder blade) down without bending the elbows. This first motion is so important because the movement is being initiated by the lats and not the biceps. The biceps are only an assistant muscle during this and other back exercises. Keep in mind this is a very small movement - only about an inch. You should immediately feel the lats contract right below the arm pit area.
  * Continue pulling till the bar reaches the top of the chest. Keeping your posture, slowly raise the bar back to the beginning position and repeat.

This may take a few times before getting familiar with the first movement occurring at the shoulder. The reason for this is that it’s natural for the body to want the elbows to bend first which recruits the biceps much more than needed. There is no way to eliminate the biceps; what you are trying to negotiate is the degree of assistance. You may have experienced with using too much biceps after finishing a set and feeling the arms being fatigued and nothing in the lats. Please keep in mind this is not always the case, however, it’s much more common than not. So once again the two main factors to focus on are: 1. Keep your body position slightly reclined, not allowing any movement at any time; and 2. Initiate the movement with the shoulders not the elbows.

  


# Running a Marathon

## Welcome!

As legend has it, the ancient Greek messenger Pheidippides ran from the plains of Marathon, Greece, to deliver the good news that the Greek army had successfully defended Athens from the invading Persian army. He successfully delivered his message, but at the cost of his life, collapsing no sooner than he had uttered, "Rejoice! We conquer!"

Since the first modern-day marathon race was run in the 1896 Athens Olympics, the marathon has earned an air of mystique. It's the classic distance, and the ultimate test of endurance (although some runners run even longer than that). Before the running boom of the 1970s, only the truly athletic or foolhardy would dare take on the 26.2 mile marathon course. But since then, the sport has truly grown, and marathons that drew only a few hundred runners in the early 1970s draw tens of thousands today.

And now, as more people complete marathons, many people make it a goal to run one at least once in their lifetime. That you're reading this Wikibook means that you've decided to take it on, or are considering it. What's stopping you?

In this Wikibook you'll learn the basics of how to plan for and complete a marathon, learn time-tested tips that will keep you going to the finish line. If you're a seasoned veteran, this book will also outline some tips for getting faster, so that your next marathon can be your best.

Once you cross the finish line of your first marathon, there's no turning back. So, prepare to go on the journey of your life. Rejoice! You're about to conquer!

## Getting Off The Couch

  1. Stick both legs out.
  2. Rise from seat.
  3. Go up to your bedroom.
  4. Stick on some kit.
  5. Open front door.
  6. And off you go...

Wasn't hard, was it?

## Plotting Your Course

It's worth it to give some thought as to what you want to accomplish in your first marathon. Making a plan gives you something to aim for as you train.

### Choosing your marathon

When choosing your first marathon, you'll probably want to take several things into account.

  * **Size.** Marathons generally range in size from a few thousand to about 40,000 runners. Some are so popular that there is either a first-come-first-served limit on entries (in the case of the Chicago Marathon and many others), or even a lottery (in the case of New York and a few others). Running in a small marathon may appeal to many people, but in general, many first-time marathons choose larger marathons with full amenities and crowd support. When doing your first marathon, crowd support will prove to be critical.
  * **Climate and season.** In general, choose a marathon in a climate that you're used to. In general, warmer courses are more difficult than cooler courses. Also take in to account the season. Most marathons are held in the spring and fall when temperatures are moderate; running a summer marathon may not be a good first choice.
  * **Lead time.** As you'll see, you cannot just jump into a marathon and expect to be successful. You'll need about four to six months to train for a marathon.
  * **Homecourse advantage.** If your local marathon is a large marathon that meets all these requirements, it probably would be an ideal choice. The Honolulu Marathon is a warm tropical course with several hills making it rather difficult. But a resident of Honolulu who knows the city and is fully acclimated is likely to be at an advantage over a mainlander, all other things being equal.

## Starting Out

While much attention is devoted (understandably) to the actual running of the marathon, the training and preparation before the race is even more important for a runner to successfully complete a marathon. The training for a marathon can be broken down into three stages:

  * **Base Training** Base training, also known as pre-training, involves building solid fitness. As the name implies, base training is the building of an athletic base that leads to the actual marathon training. Often overlooked, it is important because it makes prepares the body for additional training and lowers the likelyhood of injuries.
  * **Marathon Training** The marathon training is the actual training regimen that prepares a runner to run 26.2 miles. It involves increased mileage, long runs and speedwork, to name a few components. This is the heart of the training, and it generally lasts from 15 to 25 weeks. This stage can be further broken down into additional parts: 
    * **Long Runs** Long runs are runs, generally done weekly or bi-weekly, that prepare the runner for 26.2 hard miles by building endurance. The longest long runs in a training plan generally range from 18 to 26 miles, though for elite marathoners, they may be over 30 miles.
    * **Easy/Recovery Runs** Though training is done by repeatedly stressing the body, runners must allow themeselves to recover and heal. This is done by either taking complete rest, or by doing short runs of only a couple miles.
    * **Speedwork** Though the marathon is certainly an endurance event, many runners will benefit from doing speedwork, that is short, high intensity intervals.
  * **The Taper** The taper lasts from approximately 3 weeks before race day to the race itself. It involves a deliberate decrease in training volume to allow the body to recover from training and become stronger, a process known as "peaking". The goal of a taper is to peak on race day.

The first action an marathoner must take is to announce to their family and friends that they intend to run a certain marathon. Not only does this let them know that they should be supportive and encouraging, but it also commits the marathoner to complete their training and the race.

### Creating a Training Plan

Be careful not to increase your mileage more than 10-15% Per week during training.

Having chosen a marathon and made the commitment to run it, the runner should create an organized, written plan that defines their training, in detail. Though this doesn't have to define every daily workout in advance, it should, at minimum, give weekly mileages for the three stages of training, the distances of each long run and the duration of each stage.

## Tapering

## Preparing for Your Race

Be sure to go to the toilet (and do both types of business) before the race. Eat lots of carbohydrates which will add energy needed during the race.

## After Your Marathon

Be happy! But also be cautious, your body is going to be extremely exhausted after running 26.2 miles. Make sure to stretch out and drink a ton of water/sports drink. The most effective way to recover after a run like this is to have a big glass of chocolate milk, it will help you muscles recover much faster.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Physical_Activity/Print_version&oldid=1633705](http://en.wikibooks.org/w/index.php?title=Physical_Activity/Print_version&oldid=1633705)" 

[Category](/wiki/Special:Categories): 

  * [Physical Activity](/wiki/Category:Physical_Activity)

Hidden category: 

  * [Pages needing attention](/wiki/Category:Pages_needing_attention)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Physical+Activity%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Physical+Activity%2FPrint+version)

### Namespaces

  * [Book](/wiki/Physical_Activity/Print_version)
  * [Discussion](/w/index.php?title=Talk:Physical_Activity/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Physical_Activity/Print_version)
  * [Edit](/w/index.php?title=Physical_Activity/Print_version&action=edit)
  * [View history](/w/index.php?title=Physical_Activity/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Physical_Activity/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Physical_Activity/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Physical_Activity/Print_version&oldid=1633705)
  * [Page information](/w/index.php?title=Physical_Activity/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Physical_Activity%2FPrint_version&id=1633705)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Physical+Activity%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Physical+Activity%2FPrint+version&oldid=1633705&writer=rl)
  * [Printable version](/w/index.php?title=Physical_Activity/Print_version&printable=yes)

  * This page was last modified on 22 September 2009, at 21:58.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Physical_Activity/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
