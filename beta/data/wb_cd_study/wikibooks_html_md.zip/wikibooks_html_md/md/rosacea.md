# Rosacea/Print version

From Wikibooks, open books for an open world

< [Rosacea](/wiki/Rosacea)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Rosacea](/wiki/Rosacea)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Rosacea/Print_version&action=purge&printable=yes) this page.

  1. [What Is Rosacea?](/wiki/Rosacea/What_Is_Rosacea%3F) ![25%.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/34/25%25.svg/9px-25%25.svg.png)
  2. [Basic Skin Care](/wiki/Rosacea/Basic_Skin_Care) ![25%.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/34/25%25.svg/9px-25%25.svg.png)
  3. [Treatments](/wiki/Rosacea/Treatments) ![25%.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/34/25%25.svg/9px-25%25.svg.png)
    1. [Intense Pulsed Light and Laser](/wiki/Rosacea/Intense_Pulsed_Light_and_Laser) ![50%.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c2/50%25.svg/9px-50%25.svg.png)
  4. [Insurance](/wiki/Rosacea/Insurance) ![50%.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c2/50%25.svg/9px-50%25.svg.png)
  5. [Researching](/wiki/Rosacea/Researching) ![25%.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/34/25%25.svg/9px-25%25.svg.png)
  6. [Resources](/wiki/Rosacea/Resources) ![75%.svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/49/75%25.svg/9px-75%25.svg.png)
  7. [Glossary](/wiki/Rosacea/Glossary)

# What Is Rosacea?

Rosacea ([IPA](//en.wikipedia.org/wiki/IPA):ɹəʊ.ˈzeɪ.ʃə) is a common but often misunderstood condition that is estimated to affect over 45 million people worldwide. Most often, it begins as flushing and redness on the central face and across the cheeks, nose, or forehead but can also less commonly affect the neck, chest, scalp or ears. As rosacea progresses, other symptoms can develop such as permanent redness, red bumps (some with pus), red gritty eyes, burning and stinging sensations, small blood vessels visible near the surface of the skin, and in some advanced cases a bulbous nose. The disorder can be confused and co-exist with acne vulgaris and/or seborrheic dermatitis. People that are fair-skinned are disproportionately affected. Rosacea affects both men and women of all ages, but middle-aged women are more susceptible because of hot flushes caused by menopause.

### Subtypes and symptoms

There are four identified rosacea subtypes[1] and patients may have more than one subtype present.

  1. _Erythematotelangiectatic rosacea:_ Permanent redness (erythema) with a tendency to flush and blush easily. It is also common to have small blood vessels visible near the surface of the skin (telangiectasias) and possibly burning or itching sensations.
  2. _Papulopustular rosacea:_ Some permanent redness with red bumps (papules) with some pus filled (pustules) (which typically last 1-4 days but sometimes as long as a month or more); this subtype can be easily confused with acne.
  3. _Phymatous rosacea:_ This subtype is most commonly associated with rhinophyma, an enlargenent of the nose. Symptoms include thickening skin, irregular surface nodularities, and enlargement. Phymatous rosacea can appear on the nose, chin, forehead, cheeks, and ears. Small blood vessels visible near the surface of the skin (telangiectasias) may be present.
  4. _Ocular rosacea:_ Red, dry and irritated eyes and eyelids. Some other symptoms include foreign body sensations, itching and burning.

Rosacea sufferers often report periods of depression stemming from cosmetic disfigurement, painful burning sensations, and decreases in quality of life.[2]

### Causes

The precise pathogenesis of rosacea still remains unknown, but most experts believe that rosacea is a disorder where the blood vessels become damaged when repeatedly dilated by stimuli. The damage causes the vessels to dilate too easily and stay dilated for longer periods of time or remain permanently dilated, resulting in flushing and redness. Immune cells and inflammatory mediators can leak from the microvascular bed causing inflammatory pustules and papules, especially with those with papulopustular rosacea.

Rosacea has a hereditary component and those that are fair-skinned of European or Celtic ancestry have a higher genetic predisposition to developing it. Women are more commonly affected but when men develop rosacea it tends to be more severe. People of all ages can get rosacea but there is a higher instance in the 30-50 age group. The first signs of rosacea are said to be persisting redness due to exercise, changes in temperature, and cleansing.

Triggers that cause episodes of flushing and blushing play a part in the development of rosacea. Exposure to temperature extremes can cause the face to become flushed as well as strenuous exercise, heat from sunlight, severe sunburn, stress, cold wind, moving to a warm or hot environment from a cold one such as heated shops and offices during the winter. There are also some foods and drinks that can trigger flushing, these include alcohol, foods high in histamine and spicy food.

Certain medications and topical irritants can quickly progress rosacea. If redness persists after using a treatment then it should be stopped immediately. Some acne and wrinkle treatments that have been reported to cause rosacea include microdermabrasion, chemical peels, high dosages of isotretinoin, benzoyl peroxide and tretinoin. _Steroid induced rosacea_ is the term given to rosacea caused by the use of topical or nasal steroids. These steroids are often prescribed for seborrheic dermatitis. Dosage should be slowly decreased and not immediately stopped to avoid a flare up.

Studies of rosacea and demodex mites have revealed that some people with rosacea have increased numbers of the mite, especially those with steroid induced rosacea.[3] When large numbers are present they may play a role along with other triggers.

It has also been suggested that rosacea might be a neurological disorder resulting from hypersensitization of sensory neurons following activation of the plasma kakllikrein-kinin system by exposure to intestinal bacteria in the digestive tract.[4]

## Incidence

### Age

There has never been a thorough study on the incidence of age and rosacea. The National Rosacea Society and their Canadian affiliate the Rosacea Awareness Program report in their 'Standard classification of rosacea' that "Rosacea occurs in both men and women and, although it may occur at any age, the onset typically begins at any time after age 30". This statement is believed to be based on a large mail in survey which the results are summerised in _Figure 1_. This can be compared to an Internet survey _Figure 2_ that reported different results. Both surveys are considered to be inaccurate as both methods used to survey have inherent flaws and large bias.

Figure 1: NRS mail survey with 2,000 respondents

###
0-29

#########
30-49

#########
50+

  


Figure 2: Rosacea-support online poll with 378 respondents

###
Teens

########
20-30

#####
31-40

##
41-50

#
51+

### Sex

A 1989 study of 809 office employees found that 14% of the women and 5% of the men were diagnosed as having rosacea[5].

## References

  1. ↑ Wilkin J, Dahl M, Detmar M, Drake L, Liang MH, Odom R, Powell F (2004). "Standard grading system for rosacea: report of the National Rosacea Society Expert Committee on the classification and staging of rosacea". _J Am Acad Dermatol_ **50** (6): 907-12. [PMID 15153893](//www.ncbi.nlm.nih.gov/pubmed/15153893?dopt=Abstract). 
  2. ↑ Panconesi, E. (1984). "Psychosomatic dermatology". _Clin Dermatol_ **2**: 94-179. [PMID 6242532](//www.ncbi.nlm.nih.gov/pubmed/6242532?dopt=Abstract). 
  3. ↑ Erbagcaronci Z, Özgöztascedili O (June 1998). "The significance of Demodex folliculorum density in rosacea". _Int J Dermatol._ **37** (6): 421-5. [PMID 9646125](//www.ncbi.nlm.nih.gov/pubmed/9646125?dopt=Abstract). 
  4. ↑ Kendall SN (May 2004). "Remission of rosacea induced by reduction of gut transit time.". _Clin Exp dermatol._ **29** (3): 297-9. [PMID 15115515](//www.ncbi.nlm.nih.gov/pubmed/15115515?dopt=Abstract). 
  5. ↑ Berg M, Liden S. _An epidemiological study of rosacea._Acta Derm Venereol. 1989;69(5):419-23.

# Basic Skin Care

Prior to beginning any new rosacea treatment, one needs to prepare the skin, and allow the skin to heal from the effects of previous treatments, which may have left the skin damaged or overly sensitive. We often hear people tell us that the rosacea treatments they had been using left their skin so sensitive that “even water hurts their skin” which can be very true. If one then uses a harsh acidic or invading rosacea treatment such as laser, skin rejuvenation or anti-wrinkle treatment, or retinoids, then obviously the rosacea sufferer is going further down the wrong rosacea treatment pathway.

So many times rosacea or the worsening of rosacea from a mild stage to a more severe stage is the result of treatments that we have used in the past or are currently using. Use of acne treatments containing ingredients such as salicylic acid or benzoyl peroxide cause increased redness to the facial skin; often we overuse these products because we feel they are not working. For instance you have more pimples so you use more of the acne treatment. When you do this, the skin reacts by trying to form a barrier of more oil to protect itself from the harmful effects of the offending treatment. So you tend to use more to counteract this effect and in doing so the pores tighten and close resulting in clogged pores, pimples and papules.

While coping with Rosacea, a way to successful skin care is to avoid doing anything to irritate your skin which may cause a flare up and worsen the condition. Anything that makes your skin (more)red is just worsening the problem. When selecting a skin care regimen, it is important to avoid ingredients that may irritate the skin. Alcohol, alpha-hydroxys, glycolic acid, should generally be avoided. Additionally, exfoliation should be avoided, particularly in affected areas. The key to managing skin with Rosacea is recognizing that the skin is suffering an inflammatory response.

Rosacea is very often associated with sun exposure, so protection of the skin with sunscreens is important.

## Cleansing

Experts agree that a gentle cleansing regime is very important. Avoiding chemicals that aggravate the rosacea, but will clean and moisturise the skin is a step in the right direction. Routine everyday care of skin is an essential part of optimal patient management. Common problems such as xerosis, dermatitis, eczema, psoriasis, acne, rosacea, and photodamage leave the skin vulnerable to external insults, partly as a result of varying levels of barrier dysfunction. Cosmetic surgery procedures also typically damage the stratum corneum (SC) and leave skin with a very weak barrier during recovery phase. Cleansing is an important aspect of any skin care, since it not only removes unwanted dirt, soil, and bacteria from skin, but also removes dead surface cells, preparing skin to better absorb topically applied drugs/medication. Care must be taken to minimize any further weakening of the SC barrier during cleansing. Cleansers based on mild synthetic surfactants and/or emollients that cause minimal barrier perturbation are ideal for these patients.

Absolutely no way should harsh cleansers and toners be used. The natural oils on the skin must be regulated to allow the skin to form it’s own defenses against any harmful bacteria or environmental distress. Stick with mild cleansers targeted at sensitive skin. Cetaphil is one of the mildest cleansers out there and an ideal choice for delicate, irritable skin. Avoid cleansers that are heavily perfumed or contain detergents, alcohol, or other known irritants. Just because a cleanser says it provides "mild cleansing" doesn't mean it will be kind to rosacea skin. When looking for a cleanser, look for "Sensitive Skin Tested" on the label. The bottom line: If it stings, don't use it. It's as simple as that. Return it, throw it out, or give it away and start again.

After using the cleaner, the face will be rinsed with plentifulness of water and smudge with a soft towel in order not to irritate your skin. Because the skin touched of rosacea is very dry, you should avoid using coppices or rough towels to rub your face skin. When washing your face you should utilise lukewarm water instead of hot water.

## Basic Skin Care

Never rub the skin. This can be difficult rule to follow, particularly when applying makeup, shave, or dry the skin after cleansing, but it is important. All these activities should be done in a way that does not move the skin. Use a very light touch at all times. An alternative to using a cleanser is to use a warm water rinse. Let your skin air dry as much as possible, and if needed blot very lightly with a soft towel.

Use a moisturizer free of fragrance, dyes, and other known irritants. As with washing and drying, do not rub the product into your skin. Rub the product between your hands before applying very gently and use more product than may seem needed, as this will prevent friction, If you find it easier, simply blot the moisturizer onto your skin after you have rubbed it onto your hands. Any extra product can be removed by placing a tissue over your face and neck and blotting it off. Lay it flat and lightly press and peel off. This method should be used by those who wear a foundation to cover redness. Also of course, pay attention to ingredients in your makeup as well.

## Sunscreen

An unexpected day out at the beach or a sport game in the back yard in the searing heat will leave a rosacea sufferer red all over. The heat from the sunlight can cause flushing and the sunburn cause extra redness. Even when not out in the sun wearing a sunscreen is reccommended.

UV light is of a shorter wavelenght than visible light and is subdivided into three bands UVA, UVB and UVC. UVA light penetrates deeply and contributes to ageing, UVB causes burning and redness. Very little UVC light makes it past the atmosphere.

The SPF (sun protection factor) of a sunscreen is a laboratory measure of its effectiveness against UVB light that causes sunburn. SPF 15 means that a user can nominally remain in the sun 15 times longer than would otherwise cause them to have sunburn, but this varies with a number of factors. The SPF is not a linear measure of the amount of Ultraviolet blocked. A sunscreen rated 15 blocks 93.3% of UV, and an SPF 30 sunscreen blocks 96.7%. The SPF does not measure a sunscreens effectiveness agaings UVA light.

Sunlight was identified as the most common trigger by a survey by the national rosacea society. In many studies it has been found beneficial for rosacea patients to use sunscreen everyday to reduce their symptoms. Sunscreen is also highily reccommended for patients taking treatments that cause photo sensitivity such as various antibiotics and isotretoin.

Find a broad sprectrum sunscreen preferably with zinc oxide or titanium dioxide as the main active ingredient that is also noncomedogenic and nonirritating skin. zinc oxide and titanium dioxide both block UV light instead of absorb then like most sunscreens. They also work immediately after application while other sunscreens need to be applied 30 minutes beforehand.

It is important to have sun protection while in the sun, but it is also important to use a sunscreen that will not cause irritation. Select a sunscreen target towarde those for rosacea or sunscreens that have good reviews by rosaceans.

## Shaving

Shaving will always cause some irritation but it can be minimised.

Get a good rotary head electric razor, a wet/dry one if possible so you can use it in the shower. You can use a shaving lotion to allow the shaver to glide easily over your face. Recommended lotions are jojoba oil, an aloe-based shaving cream or Edge Gel for Sensitive skin. Don't use anything with alcohol in it. You can shave before bed time, in the shower or after having a shower. Shave with light, short strokes in the direction of hair growth. Shaving with the grain helps prevent ingrown hairs, razor burn, and cuts. Instead of shaving against the grain to get a close shave, shave twice. If you use a blade, make sure that your face is coated with a thin stream of hot water before applying shaving cream. Give the cream a few minutes to settle in. Use a sharp razor that has a double blade attached to it. Take your time and rinse with cold water, not hot. Allowing the steam of a shower or hot towel to soften the follicles of a tough beard can be a better preparation.

Do not forget to shave gently and shaving too frequent shaving will irritate skin.

## Concealers and makeup

Both men and women can benefit from the vast range of rosacea friendly makeup products. Give yourself the edge by testing the impact that correctly applied makeup can have. We hope that in reading this, you're armed with the information you need to make this a success.

Make yourself familiar with ingredients which may aggravate or irritate rosacea skin. Some find that they are only able to use mineral makeup. Ingredients to various brands of mineral makeup can be found at the Mineral Powder Foundation Ingredients List website (<http://people.delphiforums.com/tracikenyon/IngredList22405.html>). Many of the main stream commercial brands may include ingredients that may irritate. Sometimes the only way to know is to try so it's a good idea to do a bit of research in regards to ingredients. Lots of great brand name foundations out there though. No one product will work for everyone! If you wanted a more sheer look, find a liquid foundation that matches your skin tone and doesn't irritate and mix a few drops into your daily moisturiser. It will give sheer coverage, natural and it may be all you need. Lighter, oil free foundations are better for those with oily skin, and more emollient products are better for dry skin.

Always go for a foundation with a yellow base. Some opt for a green makeup base or primer. Some use concealers with a green tint. For the most part, this is just an added step, with more products now on your skin. Most people find that once they find the appropriate foundation, using green based products isn't necessary.

### Application

Open your mouth when applying foundation to expose the neck area and eliminate an obvious line at the jaw line. When testing, apply a sample to the jawline and then go outside with a small mirror. If you can't see where the foundation is, then you've got the right colour.

Buy 2 different shades of the same foundation, one lighter and one darker, so that as the seasons change you can mix the colours to accommodate any changes in your natural skin colour. Some find that this is not necessary.

As far as application, always apply your makeup in natural daylight. And for novices, spend time at how perfecting application. Always start with less as it is easier to add more as you go along if needed. Put a little foundation on the hand (add a complimentary tone if necessary). Dot it over the face-on the nose, the cheeks, the chin and the temples and in between the brows. Using the tips of two fingers or a small clean, dampened sponge(from which excess water has been removed) blend the foundation. Always work from the face outwards, to avoid an accumulation of the foundation around the hairline-move from the cheeks to the ears, from between the brows down over the nose, from the chin out towards the jaw, then onto the neck. Work quickly, carefully and lightly. Blend well around the hairline, on the neck, below the eyes and behind the ears. Also take the foundation over the eyelids. Finally blot the face with a clean dry tissue, pressing it lightly over the skin. Apply a little powder to set the foundation if necessary. Go lightly the first time and go back to focus on certain areas the second time. Try to make everything look better, not look perfect. Whatever isn't covered by your first application/subsequent spot treating (very light spot treating) you might want to just leave alone. It has to match exactly. Even if you get "Wow, this is nearly invisible", try to see if you can get to the point where you say "Wow, this is invisible." It's absolutely critical it matches. If you try something and for whatever reason this brand doesn't offer you a good enough match, don't buy it just because. Try a different brand, first. When testing, apply a sample to the jawline and then go outside with a small mirror. If you can't see where the foundation is, then you've got the right colour. But, don't judge your match in blinding sunlight, this light will "blend" almost anything seamlessly and will not be accurate.

### Extra bit For Men

Although the above information applies to everyone, I figured I'd touch on this subject further. Don't gravitate to products that say "For Men" on them. The color selections are almost always horrible and they are either too expensive or lacking in formulation. Or both. In short: The men who want to buy this stuff have already bought it and don't care if something is designated "For Men." The difference is in the packaging. "For Men" is for the men with fragile egos. Stick with bigger brands, they have more color selection, better formulations, you name it. MAC, Clinique, Estee Lauder, Armani, Becca, etc. You can do some browsing online for products you might want to try but just jot down the names of the products, don't bother remembering the name of the color. They're usually far off base in person. If going to a counter makes you uncomfortable, you might want to go in the morning when there are less people. Remember: You're not the only guy they've done this for! Sometimes sales associates will try to sell you things you don't need, so in case you didn't already know: you don't need primer, you don't need seperate cleansers, etc. While you're learning, sponges and brushes are not necessary. Tell them you'll stick to using your fingers for now. (Unless of course you want to buy them.) Ask them for samples! Even if they have to put them in a little jar or something. Most if not all counters/stores do this. Keep in mind you will need a cleanser that is able to remove makeup. Lastly, if you're going to worry all the time that you have makeup on, always running to the mirror, being self conscious, etc, it defeats the purpose of wearing it. Don't feel forced into this. This should be something to help you feel better about yourself. Not worse.

### Introduction links

  * About-Rosacea.com "A Daily Skin Care Program" (<http://www.about-rosacea.com/lifestyle2.htm#Further%20Reading>)
  * Rosacea-Ltd International News "Rosacea Treatment And Skin Care" (<http://www.bassandboney.com/news/rosacea-ltd/?p=7>)
  * Cosmetic Connection "Rosacea 101: Basic guide" (<http://www.cosmeticconnection.com/rosacea101.html>)

### Cleansing links

  * Frequently Asked Rosacea Questions v.1.15 (<http://www.faqs.org/faqs/medicine/rosacea/>)
  * Rosacea Support "Mild cleanser is important" (<http://rosacea-support.org/mild-cleanser-is-important.html>)
  * Cosmetic Connection "Rosacea 101: Basic guide" (<http://www.cosmeticconnection.com/rosacea101.html>)
  * Journal a day "How to Take Care of a Rosacea Skin?" (<http://www.journal-a-day.com/Health_And_Fitness/394969-how-to-take-care-of-a-rosacea-skin.html>)

### Makeup links

  * Rosacea Support archives msg:11538 - Article on foundations (<http://health.groups.yahoo.com/group/rosacea-support/message/11538>)

# Treatments

## Antibiotics

Oral antibiotics are usually the first line of defence prescribed by doctors to relieve papules, pustules, inflammation and some redness. There are two families of antibiotics normally used, traditionally the tetracycline family and now macrolide families[[3]](http://www.ncbi.nlm.nih.gov/sites/entrez?cmd=Retrieve&db=PubMed&list_uids=15562139&dopt=AbstractPlus) have been proven to help treat rosacea. Antibiotics are used for their anti-inflammatory properties rather than their ability to kill micro-organisms. Generally they are prescribed in quantities too small for them to be effective at stopping the growth of micro-organisms.

The Tetracyclines family include: Aureomycin, Demeclocycline, Doxycycline, Minocycline, Oxytetracycline and Tetracycline.

Tetracycline use should be avoided during pregnancy and in the very young (less than 6 years) because it will result in permanent staining of teeth causing an unsightly cosmetic result.

Doxycycline is commonly prescribed by medical doctors for infections and to treat acne. It may also be used to treat urinary tract infections, gum disease, and other bacterial infections such as gonorrhea and chlamydia. Doxycycline is also used commonly as a prophylactic treatment for infection by Bacillus anthracis (anthrax). It is also effective against Yersinia pestis and malaria. At subantimicrobial doses, doxycycline is an inhibitor of matrix metalloproteinases, and has been used in various experimental systems for this purpose.

Oracea is a 40mg modified-release formulation of doxycycline that is taken once daily for the treatment of rosacea and is patented by Collagenex Pharmaceuticals. Oracea works by reducing inflammation.

Minocycline hydrochloride, also known as minocycline, is an antibiotic of the tetracycline class. It is marketed under several trade names, including Minomycin, and Dynacin. It is primarily used to treat acne.

Metronidazole can be taken orally or as a gel or cream. It is sold as MetroLotion®, Metrocream® and **Metrogel®** by Galderma Laboratories]] and as Noritate® by Dermik.

Metronidazole tastes very bitter, and can cause headaches. Long term or high dosage administration of metronidazole can lead to peripheral neuropathy, which often manifests itself as a tingling or numbness in the fingers or toes. Patients who experience neuropathy should stop taking the drug and immediately contact their physician. Patients taking metronidazole must avoid consuming alcohol in any form (including cough syrup), as it will react badly with the medication, leading to severe nausea and cramping. Another common side effect is the darkening of the urine. Patients should drink plenty of water to avoid constipation. Patients taking metronidazole have also reported loss of appetite and mild nausea. Forcing oneself to eat, despite lack of appetite and fatigue, may reduce the nausea.

## Clonidine

Flushing and blushing can be reduced with a centrally-acting alpha-2 agonist Clonidine. Clonidine has side effects of drowsiness and lowered blood pressure. Moxonidine can be used as an alternative to Clonidine as it has less side effects but most people find Clonidine more effective. Beta-Blockers like Propanol are similar to alpha-2 agonists and work better for anxiety and chronic social blushing. More information about Clonidine can be found at the following page (<http://www.angelfire.com/journal2/sadhelp/clonidine.htm>).

## Beta blockers

Beta blockers or beta-adrenergic blocking agents are a class of drugs used to treat a variety of cardiovascular conditions and some other diseases.

There are two types of beta receptors: β1-receptors located mainly in the heart, and β2-receptors located all over the body, but mainly in the lungs, muscles and arterioles.

Drugs that block beta 2 receptors generally have a relaxing effect and are prescribed for anxiety, migraine, esophageal varices and alcohol withdrawal syndrome, among others. Many beta blockers affect both type 1 and type 2 receptors; these are termed _non-selective_ blockers. Some non-cardio selective beta blockers are Nadolol, Oxprenolol, Propranolol, Pindolol and Sotalol.

  * [Wikipedia](http://en.wikipedia.org/wiki/Beta_blocker) \- Full Beta blocker article
  * [Rosacea Support archives msg:9717](http://health.groups.yahoo.com/group/rosacea-support/message/9717) \- A patient talks about their experiences with taking atenolol.

## Isotretinoin

Isotretinoin is a powerful medication normally used for the treatment of acne but in low dosage can be used to treat rosacea. It is a retinoid, meaning it is derived from Vitamin A and is found naturally in the body, produced by the liver in small quantities. Isotretinoin is sold under many brand names, including **Accutane®** and **Roaccutane®** by Roche. It is also marketed as **Accure®** (Alphapharm), **Oratane®** (Douglas Pharmaceuticals), **Isohexal®** (Hexal Australia), **Amnesteem®** (Bertek) and **Claravis®** (Barr).

Isotretinoin is effective at treating rosacea but because of the many side effects it is normally prescribed after other treatments such as antibiotics have been tried. Isotretinoin is typically prescribed at between 0.5 mg/kg/day to 2.0 mg/kg/day for severe acne. For rosacea it is normally prescribed at a dose of 0.5 mg/kg/day to 1.0 mg/kg/day or lower.

17 of a study of 20 patents in a follow up one year after stopping treatment had no relapses showing a long-lasting favourable effect in rosacea.[1]

Dr. Richard B. Odom in a article for Skin & Allergy News suggests using 10 mg of oral isotretinoin two or three times a week or 20 mg twice a week.[2]

There is some anecdotal evidence that high dosages of isotretinoin caused or contributed to the development of rosacea[3][4].

## Topicals

There are many acne treatments topicals which are used by mistake for rosacea. A lot of the time the acne products can have a drying effect which can further irritate the redness. A [a popular rosacea treatment](http://www.zenmed.com/skincare/rosacea)

## External links

  * Rosacea Treatment Overview - Dr. Geoffrey Nase - Rosacea Researcher (<http://www.drnase.com>)
  * Yahoo! Health - Antibiotics for rosacea (<http://health.yahoo.com/ency/healthwise/tr6025>)
  * Rosacea Support archives - "Accutane is the only drug that helps reduce all of my rosacea symptoms". (<http://health.groups.yahoo.com/group/rosacea-support/message/73790>)
  * Focus on low-dose accutane - Collection of recent papers and articles on low dose accutane and rosacea. (<http://rosacea.ii.net/news/2006/01/focus-on-low-dose-accutane.html>)

## References

  1. ↑ Turjanmaa K, Reunala T. _Isotretinoin treatment of rosacea._ Acta Derm Venereol. 1987;67(1):89-91. [Abstract](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=pubmed&dopt=Abstract&list_uids=2436425&query_hl=1)
  2. ↑ Barbara Baker. _Low-Dose, Pulsed Oral Isotretinoin May Clear Resistant Rosacea._ Skin & Allergy News 30(12):23. [Full article](http://rosacea.ii.net/hl/11537.html)
  3. ↑ [[1]](http://groups-beta.google.com/group/rosacea/msg/c1189b11cc017c97)
  4. ↑ [[2]](http://www.esfbchannel.com/cgi-bin/yabb/YaBB.pl?board=Rosacea&action=display&num=1119518713)
  * Erdogan FG, Yurtsever P, Aksoy D, Eskioglu F. _Efficacy of low-dose isotretinoin in patients with treatment-resistant rosacea._ Arch Dermatol. 1998 Jul;134(7):884-5. [Full article](http://web.archive.org/web/20030201112031/http://archderm.ama-assn.org/issues/v134n7/ffull/dlt0798-10.html)
  * Hoting E, Paul E, Plewig G. _Treatment of rosacea with isotretinoin._ Int J Dermatol. 1986 Dec;25(10):660-3. [Abstract](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=pubmed&dopt=Abstract&list_uids=2948928&query_hl=1)
  * Frucht-Pery J, Sagi E, Hemo I, Ever-Hadani P. _Efficacy of doxycycline and tetracycline in ocular rosacea._ Am J Ophthalmol. 1993 Jul 15;116(1):88-92. [Abstract](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=8328549&dopt=Citation)
  * Dahl MV, Katz HI, Krueger GG, Millikan LE, Odom RB, Parker F, Wolf JE Jr, Aly R, Bayles C, Reusser B, Weidner M, Coleman E, Patrignelli R, Tuley MR, Baker MO, Herndon JH Jr, Czernielewski JM. _Topical Metronidazole Maintains Remissions of Rosacea_. Arch Dermatol. 1998 Jun;134(6):679-83. [Abstract](http://archderm.ama-assn.org/cgi/content/abstract/134/6/679)

## Intense Pulsed Light (IPL)

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Lumenis_One_IPL.JPG/210px-Lumenis_One_IPL.JPG)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

IPL handpiece on a Lumenis One

Intense Pulsed Light (IPL) is a treatment where a broad spectrum of light is applied to the skin. IPL differs to dermatological lasers in that they emit a large spectrum of light while lasers emit a single wavelength, but in practice they are quite similar. IPL machines are expensive and the treatments are normally only available from dermatologists and beauty salons. Using different settings IPL machines can be used for treating vascular lesions, fine wrinkles and also for hair removal. For vascular treatments the goal is to destroy blood vessels in the inner layers of the skin by heating them to 70 °C. Although blood vessels are targeted, the light energy is also absorbed by other structures in the skin such as melanin (pigment for skin and hair) and water. IPL has only been around since 1995 and new research to maximise effectiveness while reducing side effects and new technologies and procedures are still being developed.

### IPL Machine

IPL machines are powered using a xenon flash lamp. Xenon, which is also used for camera flashes produces a flat spectrum of light from 400nm to 1200nm when excited with electricity. Different filters can be used to filter out lower wavelengths depending on the treatment performed. The size of the glass prism (spot size) varies between machines but at ~4.5x1cm they are much larger than typical lasers at ~1cm circle. A light pulse can be triggered by the operator using the hand piece. There is a delay between pulses while the capacitors recharge and the flash lamp cools down.

### Settings

  * _Wavelength or Filter:_ A Xenon flash lamp produces a wavelength from 400nm to 1200nm. For vascular/rosacea treatments the light is filtered generally at the lower end. A 590nm filter would reduce the wavelength from 400-1200nm to 590-1200nm. Lower wavelengths penetrate lower and higher wavelengths penetrate more deeply into the skin.
  * _Fluence or energy level:_ The amount of energy applies over the whole pulse generally ranges from 20-60 joules per square centimetre (J/cm2) and may be spread over a series of short pulses. A joule is equal to 1 W·s (watt second).
  * _Pulse width:_ The duration of each pulse. Can be a single pulse or three short pulses.
  * _Repetition rate:_ The delay between the short pulses.

For the Matrix system of Medical Assist the settings are: 380nm-1800nm / upto 15 pulses times two. maximum 80 joules per square centimeter. This is the most powerfull IPL system in the world with the best effect. The machines are available in two different types, the first is a salon equipment and the other is a hospital use. Both are very reliable machines with high quality.

### How it works

Selective photothermolysis. The absorption of haemoglobin is significantly higher than the absorption by melanin the skins natural pigment. The haemoglobin absorb the light heating up causing the blood vessel walls to heat up causing coagulation of the blood vessels which are eventually reabsorbed by the body and replaced by scar tissue. Their are two systems. The first one is a ELOS system, which is working only for 70% for black or dark hair with a white skin. It wont work for blond, red or grey hair. Also it is not safe to use on dark skin. The second system is a Matrix system from Medical Assist. This system works on a thin part of the hair follicle which is effective for all colours of hair and is safe for every type of skin.

### Cost

Generally treatments are sold as single treatments or as discounted packages of five treatments with a period of 3-4 weeks or 6 weeks with the Matrix system, between each treatment. Prices per treatment are usually between US$300-700 (€230-500) but can vary depending on country, IPL machine type and the qualifications and skill of the operator.

### Treatment procedure

Topical anaesthesia can be applied 10-30 minutes before the treatment. Eye protection is generally worn by the patient and the operator. The operator selects the settings based on the skin type and similar characterisitcs and proceeds with the treatment. Each pulse of the IPL feels like having a rubber band snapped against the face. The skin will be redder and painful after the treatment and improves over the day continues to improve for months after the treatment. Newer procedures include pre flushing using a heating pad on the back of the neck and macrolide antibiotics because of their anti-angiogenesis properties which stop the regrowth of blood vessels shortly after treatments. [1]

### Risks/parameters that affect outcome

  * For men if the area of facial hair growth is treated then it could result in temporary stunted hair growth and possible hair loss.
  * If the patient has dark skin or has a tan or sunburn then this will reduce the effectiveness of the treatment, this is not for the Matrix system from Medical Asist which can treat all skin types and skin colors.
  * If the operator presses too hard with the handpiece on your skin, the effectiveness of the treatment will be reduced because the blood will be pushed out of the area being treated.
  * If the energy levels are too high then purpura or bruising can result. Purpura is the appearance of purple discolourations on the skin caused by bleeding underneath the skin. Purpura can last up to 2 weeks.
  * Blisters
  * Alcohol, isotretinoin

### Effectiveness

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Rosacea/Print_version&action=edit).

In a study of 63 patents with telangiectasia owing to rosacea that were treated with IPL concluded that IPL is an effective tool in achieving meaningful and lasting rosacea clearance. The study found a mean clearance of 77.8% was achieved and was maintained for a follow-up period averaging 51.6 months (range 12-99 months).[2]>

Another study was performed in order to detect the effect of IPL application with simultaneous topical antibiotics in inflammatory rosacea and to assess the efficacy of IPL therapy in routine treatment of rosacea. Twenty patients aged between 34 and 70 with papulopustular rosacea (14 female and 7 male) were included in the study. Ten patients (group I) were treated for 21 weeks with topical metronidazole. The other ten patients (group II) received an additional 3 sessions with IPL 515-755 nm Photoderm VL technology over 4 weeks. Treatment effectiveness was recorded by digital visualisation and patient satisfaction scale before each IPL session. In all patients, significant reductions in papulopustular elements were observed. Eight out of 10 patients (group I) still showed permanent erythema and telangiectasias despite topical treatment. In 3/10 patients a few telangiectasias remained following the treatment in contrast to 5/10 satisfied group I patients. MD Ferdinand Bisselink did a study on 116 patients for the treatment rosacea and found out that 103 from the 116 patients see that there whas a reduction of more as 70% after four treatments with the Medical Assist Matrix IPL system.

### Trademarks and procedures

  * Photoderm®: ESC Medical (now Lumenis) first introduced IPL machines for dermatological use in 1995. The Photoderm VL machine for vascular lesions was among the line-up and the treatments were often marketed as "Photoderm".
  * Photofacial™: A trade secret procedure developed by Dr. Patrick Bitter Sr. M.D. and Dr. Patrick Bitter Jr, who train IPL operators in their protocols for a fee.
  * FotoFacial™: Dr. Patrick Bitter Jr later developed the Fotofacial protocol and the FotofacialRF using Syneron ELOS technology.
  * Photorejuvenation is not trademarked.
  * Intens Pulsed Light Matrix system is developed by Medical Assist (medicalassist@hotmail.com)

## Laser

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Dermatological_laser.JPG/200px-Dermatological_laser.JPG)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Dermatological laser

Dermatological Lasers can be used to treat rosacea and work by applying a high energy single wavelength beam to the skin to target blood vessels. This heats them up, damaging them and they are then removed by the body's defence mechanism.

## External links

  * [IPL treatment updates](http://www.drnase.com) Dr. Geoffrey Nase
  * [IPL treatment reviews](http://www.rosacea.co.uk) at Rosacea.co.uk
  * [Rosacea Support archives](http://health.groups.yahoo.com/group/rosacea-support/message/72879) \- 10 pointers to a good IPL treatment
  * [Rosacea Support archives](http://health.groups.yahoo.com/group/rosacea-support/message/20870) \- Text of article: _Nonablative laser, IPL source both shown to stimulate dermal proteins_
  * [Article abstract at PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=1828257&dopt=Citation) \- _Flash lamp pumped dye laser for rosacea-associated telangiectasia and erythema._
  * [Article abstract at PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=15389196&dopt=Citation) \- _Pulsed dye laser treatment of rosacea improves erythema, symptomatology, and quality of life._

## References

  1. ↑ Dr. Geoffrey Nase, PhD. _Latest Advances: Triple-pass laser tx._ Dermatology Times, 1 March 2005 Issue. [Full text](http://www.drnase.com/rosacea_photoderm.htm)
  2. ↑ Schroeter CA, Haaf-von Below S, Neumann HA. _Effective treatment of rosacea using intense pulsed light systems._ Dermatol Surg. 2005 Oct;31(10):1285-9. [Abstract](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=pubmed&dopt=Abstract&list_uids=16188180&query_hl=2).
  * Angermeier MC. _Treatment of facial vascular lesions with intense pulsed light._ J Cutan Laser Ther. 1999 Apr;1(2):95-100. [Abstract](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=11357295&dopt=Abstract)
  * Mark K.A.; Sparacio R.M.; Voigt A.; Marenus K.; Sarnoff D.S. _Objective and Quantitative Improvement of Rosacea-Associated Erythema After Intense Pulsed Light Treatment_. Dermatologic Surgery, June 2003, vol. 29, no. 6, pp. 600-604(5).
  * MD Ferdinand Bisselink, Medical Assist. IPL and Rosacea Study 2011.
  * Christian Raulin, Bärbel Greve, Hortensia Grema. _IPL technology: A review_. Lasers in Surgery and Medicine, Volume 32, Issue 2, 2003. Pages 78-87. [Full text link (PDF)](http://www.laserklinik.de/cms/modules.php?name=Bib&bibcmd=visit&bibparam=29).

## Candela

Candela corporation (<http://www.candelalaser.com/>) was founded in 1970 and produce and sell laser systems. Their current lineup of laser systems include the GentleLASE® for hair removal, C-beam™ for psoriasis, Smooth beam™ for acne scars and wrinkles and the Vbeam® for vascular lesions (including rosacea). Candela have recently announced a distribution agreement with Danish Dermatologic Development to sell Intense Pulsed Light (IPL) machines in the U.S.

### Vbeam®

The Vbeam® is a pulsed dye 595nm laser and is commonly used for treating rosacea. The Vbeam features an integrated Dynamic Cooling Device™ that sprays the top layer of skin with cryogen milliseconds before each laser pulse. This reduces purpura normally associated with laser treatments.

### Ellipse I2PL

Candela branded IPL machine manufactured by Danish Dermatologic Development.

## Lumenis

[File:Lumenis one.JPG](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Lumenis_one.JPG)

Lumenis One.

Lumenis (<http://www.aesthetic.lumenis.com/>) formed after the merger of ESC™ Medical Systems and Coherent Medical Group and are based in Israel.

### PhotoDerm VL

### Lumenis One

All in one machine with 3 modules; an IPL module, Nd:YAG laser module and a LightSheer module. The IPL module incorporates Optimal Pulse Technology (OPT) which results in a more even distribution of energy within each pulse, this makes it more effective and a lower energy levels can be used to achieve the same results.

### VascuLight

Combination machine with coooled Nd:Yag laser head and IPL head.

### D-Light SR

Cheaper IPL machine.

### IPL Quantum SR

IPL machine dedicated to skin photorejuvenation treatments.

## Danish Dermatologic Development

[File:Ellipselight cmyk.jpg](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Ellipselight_cmyk.jpg)

Ellipse Light

Danish Dermatologic Development A/S (DDD) (<http://www.ellipse.org>) manufacturer and sell Intense Pulsed Light (IPL) machines. They developed _Dual Mode Filtering_, a method of using two filters to filter out wavelengths both shorter and longer than the optimal range. DDD entered into an agreement with Candela corporation where Candela will distribute the Ellipse systems in the U.S.

### Ellipse Light

The Ellipse Light is designed for beauticians and is used for the treatment of unwanted hair or sun-damaged skin (including diffuse redness). The Ellipse Light calculates the treatment parameters automatically using information about your skin inputted by the machine operator.

[File:Ellipseflex cmyk.jpg](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Ellipseflex_cmyk.jpg)

Ellipse Flex

### Ellipse Flex

The Ellipse Flex is designed for physicians and treats a larger number of conditions including facial telangiectasias, vascular malformations and rosacea.

## Laserscope

Laserscope (<http://www.laserscope.com/>) are a US based company that manufacturer and sell medical laser systems primarily for urology and aesthetic surgery.

List of machines indicated for rosacea:

  * Gemini - A combination 1064nm Nd:YAG laser and 532nm KTP laser
  * Aura-i - Frequency doubled Nd:YAG (532nm)
  * Lyra-i - 1064 Nd:YAG laser

## Syneron

Syneron Medical Ltd. (<http://www.syneron.com/>) is a rapidly expanding company founded in 2000. Syneron use their patented ELOS system that combines Bi-Polar Radio Frequency (RF) and optical energies. Syneron sell a number of platforms with the Aurora, Galaxy and Pitanga being suitable for vascular and pigmented lesions including rosacea.

### Galaxy

The Galaxy is a all-in-one platform with an Intense Pulsed Light (IPL) head and a 900nm diode laser head. Physicians using this device are trained using the FotoFacial RF™ procedure.

### Aurora

Combined Intense Pulsed Light (IPL) and Bi-Polar Radio Frequency (elos). Physicians using this device are trained using the FotoFacial RF™ procedure.

### Pitanga

## Cynosure

Cynosure, inc (<http://www.cynosurelaser.com/>) was founded in 1991 and produce and sell medical laser systems.

## Cutera

Cutera (<http://www.cutera.com>) manfacturer and sell the CoolGlide family of Laser and IPL machines for aesthetic treatments

List of machines indicated for rosacea:

  * CoolGlide Xeo - has both a long-pulse Nd:YAG laser and a IPL module
  * CoolGlide Genesis Plus - has both a long-pulse Nd:YAG laser and a IPL module
  * CoolGlide Vantage - long-pulse Nd:YAG Laser
  * CoolGlide Excel - long-pulse Nd:YAG Laser

## Bio-Derm Medical, Inc

## Sciton

Sciton Inc., (Palo Alto, CA) is a privately owned medical device company formed in 1997 to provide advanced lasers and light sources to the aesthetic medical markets. Their BBL (Broadband Light) system is a specialized version of IPL with two flashlamps and swappable filters.

## Palomar

Palomar Medical Technologies, Inc. (Palomar) designs, manufactures, markets and sells lasers and other light-based products and related disposable items and accessories for use in medical and cosmetic procedures. It offers a range of products based on its technologies that include, but are not limited to hair removal; removal of vascular lesions, such as rosacea, spider veins, port wine stains and hemangiomas...

### EsteLux

During 2001, Palomar received United States Food and Drug Administration (FDA) clearance to market and sell the Palomar EsteLux Pulsed Light System. In 2002, and 2003, the Company offered six hand pieces for the EsteLux system: LuxY, LuxG, LuxR, LuxRs, LuxB and LuxV. These hand pieces emit pulses of intense light to treat unwanted hair, solar lentigo (sunspots), rosacea, actinic bronzing, spider veins, birthmarks, telangiectasias and acne.

### MediLux

In March 2003, the Company launched the Palomar MediLux Pulsed Light System with the six hand pieces also available on the EsteLux. The MediLux provides a snap-on connector enabling it to switch among hand pieces and provide treatments tailored to each individual being treated.

### StarLux

In February 2004, Palomar launched the StarLux Pulsed Light System. The StarLux has a single power supply capable of operating both lasers and lamps. The StarLux operates five of the EsteLux/MediLux hand pieces: LuxY, LuxG, LuxR, LuxRs, and LuxV.

### StarLux 500

In February 2007, Palomar launched the StarLux 500 Laser and Pulsed Light System, and began shipping in March 2007.

## Energist

## McCue Corporation, Inc

## External links

  * [Vbeam treatment responses](http://rosacea.co.uk/?treatmenttype=VBeam) at Rosacea.co.uk
  * [Rosacea Support archive msg:12966](http://health.groups.yahoo.com/group/rosacea-support/message/12966) \- A patients experiences with a Vbeam treatment.
  * [Lumenis - Find a practitioner](http://www.skinandhealth.com/details/practitioner)

# Insurance

There are still many insurance companies that refuse to cover Laser/IPL treatments because they view rosacea as a "cosmetic concern". Here are some simple steps taken by previous rosacea sufferers to get insurance to reimburse both fully or partly.

Ring up your insurer and ask if it will be covered. Even if your insurance company will cover the procedures, they usually require pre-certification outlining the number of treatments and type of laser. Prepare a submission outlying your rosacea symptoms and how they affect and limit your lifestyle. Get photos of your severe flushing so the insurance company can see what you are really dealing with. Include peer-reviewed articles photocopied from books or medical journals or printed from the Internet.

The following symptoms are viewed as cosmetic (less important): Papules, pustles, redness and visible telangiectasias. The following are not cosmetic (more important): Flushing, blushing, burning, itching, facial swelling and pain.

Other major points to include:

  * A letter of medical necessity from a physician in your plan including the CPT code for the procedure. (It was 17108 in 2003)
  * A list of all other remedies you have tried (antibiotics, prescription topicals, diet and lifestyle changes, etc)
  * In your letter explain that when lasers are used for cosmetic purposes the settings are different than when treating rosacea.
  * As of 2004 many Laser/IPL machines are approved by the Food and Drug Administration (FDA) of the United States[1].
  * If it is not treated it will progress into more advances stages
  * You may be able to stop taking current rosacea medications after the Laser/IPL treatments

Be persistent. Fax your request and then send it with signature verification of the recipient. Call in a few days to confirm receipt, find out when the review committee will be meeting, follow up the day after that and keep on top of your request. Document the names and dates of people you speak with, it may be beneficial if you need to appeal a rejection. If your claim is rejected, ask why your claim was rejected then refute those claims with evidence. Ask at one of the online support groups for help if you need it.

## Sample Letter

Below is a sample letter that was used by Adam to convince his insurance company to provide full coverage.

> Dear Committee Members:  
  
My name is Adam. I am 19 years old. Dr. xxxxxx xxxxxxxx , M.D., my dermatologist, submitted a request for Photoderm device coverage to alleviate my disabling rosacea. Dr. xxxxxx's request on my behalf was denied based on your determination that this procedure would be a cosmetic one. I believe you have made a mistake.  
  
I have a tentative appointment set up to have my first Photoderm treatment on December 6, 2001 at Dr. xxxxxx's (different doc, this is the one who im actually getting the procedures done by) Office based on your decision after reading this letter. I am not doing this for cosmetic reasons - I am doing this for reasons that are medically necessary. My Rosacea is accompanied by severe flushing, swelling, inflammation, and worst of all a disabling burning pain. My condition is worsened by almost everything imaginable. Most foods, sun exposure, hot weather, warm rooms, cold weather, wind, humidity, exercise, embarrassment, anger, mental concentration, stress, facial movements such as chewing and smiling, certain medications, most topicals, lotions, sunscreens, soaps, cleansers, showering, shaving, daily physical activities (walking up a flight of stairs), cuddling up with someone, my head touching my pillow, and the heat from talking on the phone, are just SOME of the things that I run into each and every day that cause my facial pain to get substantially worse.  
  
I have tried numerous creams, lotions and oral medications in an effort to alleviate the severe discomfort caused by my facial rosacea. The cost before insurance of all the prescription medications I have used in connection with my condition since the beginning of this calendar year totals over $2,500. In recent weeks I have begun experimenting with different antihistamines in an attempt to reduce the swelling, inflammation, and pain associated with the majority of foods I eat. This has not helped much, and I will soon be looking into adding a Cox-2 inhibitor such as Celebrex into my daily regimen.  
  
The physical pain I live with every day, which is worsened by almost any movement I make, has become extremely debilitating. This disabling pain has caused me to become very depressed. My condition impairs my ability to function normally in society. I am unable to work, and have come close to dropping out of school more than once. I need to be able to get rid of the pain I live with every day so that I will be able to function normally once again.  
  
This condition continues to be extremely costly for all parties involved. The insurance portion alone of the payment for the Psychiatrist I have begun seeing as a result of the depression this pain causes me, is $160 every month. Additional costs include doctor and dermatologist visits that I have needed as a result of my condition. In addition, I have already gone through one month of outpatient hospitalization at a substantial cost, because of the depression my Rosacea has caused me. By eliminating the need for most of these, five to ten treatments with Photoderm (which would cost a total of $1200-$1950) would be substantially less expensive than my current course of therapy has been. Payment for these five to ten treatments would be an extreme hardship for me, as my condition leaves me unable to seek employment. I have also begun to develop early-stage Rhynophymia as a direct result of my Rosacea, which if left untreated may eventually require an even more costly medically necessary surgery. Photoderm will prevent this aspect of my condition from getting worse, eliminating the possible need for more costly surgery in the future. It is important to remember that Rosacea is a progressive disease. Every symptom I have mentioned will more than likely continue to become more and more debilitating in the future without proper treatment.  
  
My condition and the constant, debilitating pain it causes has left me unable to work. Since developing this condition I have been unable to maintain a steady job. The pain caused by simply placing my face against my pillow at night has left me unable to sleep properly. I usually am finally able to fall asleep around 4 A.M. with the help of powerful prescription sleep aids such as Ambien. Basically, my condition has left me unable to live a normal life. As you may or may not know, Photoderm has many different settings associated with it. The shallow filters are used to remove superficial, cosmetic redness from a person's skin. These are used for many cosmetic procedures. The deeper filters, which the doctor who would be performing the procedure has assured me will be used almost exclusively in my treatment, can be used to treat the underlying vascular reactivity, permanently decreasing my facial swelling, inflammation, and burning. This is why I require treatment with Photoderm.  
  
I am asking you to please reconsider your decision. I am not having these treatments done for cosmetic reasons. I am having these treatments done because nothing else has worked. In my case, this is anything BUT a cosmetic problem. I have submitted supporting documentation from Dr. xxxxxx (my derm) with my request that you reconsider your original determination. Thank you for your review."  
  


## References

  1. ↑ [Lumenis 510(k) submission](http://www.fda.gov/cdrh/pdf3/k030527.pdf). URL accessed on 23 February 2006.

# Researching

There are many places to find information on Internet, but most people do not know where and how to access them. Large amounts of information are not even available on the Internet such as books and specialised medical journal articles. Search engines such as Google or Yahoo! are the main way to search for information but still many sites are only partly indexed and many database repositories are not even indexed by search engines.

The first thing anyone with rosacea is spend a few hours reading various resources, this will give you a basic knowledge of the disorder and what treatments are available. A list of general information websites follows:

  * Australian Sciences - Free Rosacea Booklet, explains heat regulation and flushing in rosacea. (<http://www.ausci.com/rosacea.htm>)
  * DermIS - Information in Français, Portugues, Español, English and Deutsch. (<http://dermis.multimedica.de/>)
  * DermnetNZ - Has a page of rosacea information that is up to date and with photos. (<http://www.dermnetnz.org/>)
  * Dr. Geoffrey Nase, PhD - Rosacea Specialist details rosacea causes, rosacea treatments, rosacea FAQs, and lots more information. (<http://drnase.com/>)
  * National Rosacea Society - lots of basic information for patients and physicians. (<http://www.rosacea.org/>)
  * Rosacea Support - Rosacea FAQ and the list highlights. (<http://rosacea.ii.net/>)
  * Rosaceans - Lots of links and some information on alternative treatments. Also see the rosacea 101. (<http://www.rosaceans.com/>)
  * Wikipedia - Basic rosacea info with hyperlinks to much more reference information. (<http://en.wikipedia.org/wiki/Rosacea>)

People not familiar with search engines should refer to the reference book [How To Search](/wiki/How_To_Search) for particular information about each search engine. In 2005 The Rosacea Search Engine (<http://rosacea-archive.com/search.php>) was set up to search only rosacea related websites. It is considered the most in depth search engine for rosacea. Other search engines such as Google or Yahoo! Index more sites and are also useful for boarder searches especially for searches not directly related to rosacea.

## Books

You are unlikely to find anything about rosacea in your local library, but there are a few books that can be ordered over the Internet. Althrough you probably won't find a copy at your library it is probably a good option to check anyway to save yourself a bit of money. Most books will be of a high quality but they do date and you have to make sure you fit the targeted audience otherwise you will find yourself over your head with medical jargon. A list of rosacea books follow, if they can be ordered from the authors website than the website will be listed otherwise you will have to find a bookstore to order the book from such as amazon (<http://www.amazon.com/>):

  * Ann-Marie Lindstrom, L. E. Mills - "The Rosacea Handbook: A Self-Help Guide".
  * Dr. Geoffrey Nase, PhD - "Beating Rosacea - vascular, ocular and acne forms". (<http://drnase.com/>)
  * Gerd Plewig, Albert M. Kligman - "Acne and Rosacea".
  * Icon Health Publications - "Rosacea - A Medical Dictionary, Bibliography, and Annotated Research Guide to Internet References".
  * James N. Parker, Philip M. Parker - "The Official Patient's Sourcebook on Acne Rosacea".
  * PM Medical Health News - "21st Century Complete Medical Guide to Rosacea and Related Disorders, Authoritative Government Documents, Clinical References, and Practical Information for Patients and Physicians (CD-ROM)".
  * Brady Barrows - "Rosacea 101: Includes the Rosacea Diet". (<http://www.rosacea-101.com>)
  * Brady Barrows - "Rosacea Diet - A Simple Method to Control Rosacea Vegetarian and Omnivore Friendly". (<http://www.rosacea-diet.com/html/diet.html>)
  * Rosacea Support - Book reviews by David Pascoe (<http://rosacea.ii.net/reviews.html>)
  * Arlen Brownstein, M.S., N.D., Donna Shoemaker, C.N. - "Rosacea - Your self help guide". (<http://www.rosaceaworld.com/>)

# Resources

## Support Groups

  * <http://rosacea-support.org> \- Provides a blog and forum for visitors to connect with others with rosacea since 1998.
  * <http://www.rosazea.net> \- German support group with information pages and a forum.
  * <http://health.groups.yahoo.com/group/rosaceans/>
  * <http://health.groups.yahoo.com/group/rosacea-support/> moderated.
  * <http://rosaceagroup.org/> \- FAQs, a review database, a user contributed book, and a discuss forum put together by volunteers in 2004.
  * <http://rosacea-archive.com> \- Archived postings and emails of all rosacea related groups. An aggregator shows latest posts.

## Organizations

  * <http://www.rosacea.org> \- National Rosacea Society is a US based non-profit organization to educate physicians, patents and the public.
  * <http://irosacea.org/> \- A non-profit corporation that has been researching rosacea since 2004. All board members have rosacea.
  * <http://www.rosaceainfo.com> \- Rosacea Awareness Program, a Canadian organization funded by an educational grant from Galderma Canada.

## Information

  * <http://rosacea.co.uk> \- Blog with current news and a database of detailed reports of responses to various treatments.
  * <http://www.rosacea.md> \- Information on new breakthroughs and treatments, and summaries of the latest studies.

## Books

  * [Rosacea 101: Includes the Rosacea Diet](http://www.rosacea-101.com) \- A comprehensive book on the conventional and alternative treatments for rosacea.
  * [A practical understanding of Rosacea](http://www.ausci.com/ROSACEA%20BOOKLET%202009.pdf) \- Explains heat regulation and overcoming the warm room flush phenomenon, by Colin Dahl, Australian Sciences.

  


# Glossary

Contents:
Top \- 0–9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z

## A

## B

  * Blushing:

    A relatively short-term extra redness due to various mental causes such as embarrassment, shame, modesty; often accompanied by warm/hot sensations.

## C

## D

## E

  * Erythema

    Abnormal redness of the skin.

## F

  * Flushing:

    A prolonged (extra)redness of the face(and neck) caused by cutaneous vasodilation often due to physical causes, such as cold weather/wind, sunshine, heat etc. Flushing often includes a burning sensation.

## G

## H

## I

  * IPL:

    Intense Pulsed Light — A treatment to remove blood vessels from the skin.

## J

## K

## L

## M

## N

  * Nd-YAG

    Neodymium-doped Yttrium Aluminium Garnet — A compound that is used as the lasing medium for certain solid-state lasers.

  * NRS

    National Rosacea Society — A U.S. organisation for patients and doctors.

## O

  * Ocular / Occular:

    Of, or relating to the eye, or the sense of sight.

## P

  * Pustule:

    A raised lesion that contains pus and sometimes water.

  * Papule:

    A small, solid and usually conical elevation of the skin which does not contain pus.

## Q

## R

  * RRDI

    Rosacea Research & Development Institute — A worldwide organisation devoted to funding research.

  * RLT

    Red Light Therapy — A certain phototherapy that improves skin and can be beneficial to rosacea.

  * Rhinophyma:

    A large, bulbous and ruddy appearance of the nose caused by (advanced)phymatous rosacea.

## S

  * SR

    Skin Rejuvenation — A term used for specific types of Intense Pulsed Light and Laser treatments.

## T

  * Telangiectasia:

    Small dilated blood vessels near the surface of the skin, also known as spider veins.

## U

## V

  * VL

    Vascular Lesions — A term used for specific types of Intense Pulsed Light and Laser treatments that treat vascular lesions.

## W

## X

## Y

## Z

# Authors and Contributors

Listed alphabetically as their contributions appear in the wikibooks edit summary

  * [Warren](/w/index.php?title=User:Warren&action=edit&redlink=1)

# License

## GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Rosacea/Print_version&oldid=2255664](http://en.wikibooks.org/w/index.php?title=Rosacea/Print_version&oldid=2255664)" 

[Categories](/wiki/Special:Categories): 

  * [Rosacea](/wiki/Category:Rosacea)
  * [Section stubs](/wiki/Category:Section_stubs)

Hidden category: 

  * [Pages with broken file links](/wiki/Category:Pages_with_broken_file_links)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Rosacea%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Rosacea%2FPrint+version)

### Namespaces

  * [Book](/wiki/Rosacea/Print_version)
  * [Discussion](/w/index.php?title=Talk:Rosacea/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Rosacea/Print_version)
  * [Edit](/w/index.php?title=Rosacea/Print_version&action=edit)
  * [View history](/w/index.php?title=Rosacea/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Rosacea/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Rosacea/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Rosacea/Print_version&oldid=2255664)
  * [Page information](/w/index.php?title=Rosacea/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Rosacea%2FPrint_version&id=2255664)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Rosacea%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Rosacea%2FPrint+version&oldid=2255664&writer=rl)
  * [Printable version](/w/index.php?title=Rosacea/Print_version&printable=yes)

  * This page was last modified on 22 January 2012, at 22:55.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Rosacea/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
