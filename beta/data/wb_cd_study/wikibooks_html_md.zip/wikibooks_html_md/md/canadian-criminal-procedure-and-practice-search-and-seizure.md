# Canadian Criminal Procedure and Practice/Search and Seizure/Print version

From Wikibooks, open books for an open world

< [Canadian Criminal Procedure and Practice](/wiki/Canadian_Criminal_Procedure_and_Practice) | [Search and Seizure](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version) on _18 August 2012_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&oldid=2395611&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Canadian Criminal Procedure and Practice/Search and Seizure](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=purge&printable=yes) this page.

# _Search and Seizure_[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit&section=1)]

# I - Privacy Rights[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit&section=2)]

# Search and Seizure/Rights against Search and Seizure[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-1)]

The relevant Charter provision states under the heading of "legal rights":

> 8\. Everyone has the right to be secure against unreasonable search or seizure.

Privacy is "at the heart of liberty in a modern state".[1] It is "essential for the well-being of the individual" and has a profound significance for the public order."[2] It is also a “protean concept”, meaning that it tends to be highly variable and change.[3]

The purpose of the right under s. 8 is to protect "the citizen's right to a reasonable expectation of privacy" [4] and to "prevent unreasonable intrusions on privacy, not to sort them out from unreasonable intrusions on an ex post facto analysis". [5] It is for this reason that the principle of reasonable expectation of privacy is a "normative rather than a descriptive standard".[6]

The right is concerned with balancing the state's interest in law enforcement and privacy interests of persons.[7] It is only when the state can "demonstrate the superiority of its interest to that of the individual" that a search can be valid.[8] This point exists where there is reasonable and probable cause which lies at the point where "point where credibly-based probability replaces suspicion".[9]

Under this section police are prohibited from "unreasonable" searches. The inquiry of the lawfulness of a search is based on whether the search was "reasonable" in the circumstances. The circumstances include the nature of the duty performed as well as the purpose of the search.[10]

A search is only subject to Constitutional review where the search intrudes on a reasonable expectation of privacy of the accused. [11] Only where the privacy right exists that there is an inquiry into the reasonableness of the search.[12]

A lawful search must be (a) authorized by law; (b) the law itself must be reasonable; and (c) the manner in which the search was carried out must be reasonable.[13]

A search consists of any state interference of a person's privacy interests.[14] As such, there is little distinction between the initial intrusion itself and the search subsequent to intrusion. [15]

  1. ↑ R v Edwards, [1996] 1 SCR 128
  2. ↑ R v Edwards at 61
  3. ↑ R v Tessling 2004 SCC 67 at para. 25
  4. ↑ R. v. Colarusso, 1994 CanLII 134 (SCC), [1994] 1 S.C.R. 20 at [70](http://canlii.ca/t/1frw6#par70)
  5. ↑ R. v. Feeney, [1997] 2 S.C.R. 13 at 47
  6. ↑ R v Tessling at para. 42
  7. ↑ R. v. Tessling, 2004 SCC 67, [2004] 3 S.C.R. 432 at 17  

  8. ↑ Hunter et al. v. Southam Inc., [1984 CanLII 33](http://canlii.ca/t/1mgc1) (SCC), [1984] 2 SCR 145 at p.160
  9. ↑ Hunter et al. v. Southam Inc at p. 114, 115
  10. ↑ R. v. Nicolosi 1998 CanLII 2006 (ON C.A.) [[1]](http://www.canlii.org/en/on/onca/doc/1998/1998canlii2006/1998canlii2006.html)
  11. ↑ R. v. Edwards 1996 CanLII 255 (SCC), [1996] 1 S.C.R. 128 at para. 45
  12. ↑ R. v. Edwards, [1996] 1 S.C.R. 126 [[2]](http://www.canlii.org/en/ca/scc/doc/1996/1996canlii255/1996canlii255.html); Hunter v. Southam Inc., 1984 CanLII 33 (S.C.C.), [1984] 2 S.C.R. 145.
  13. ↑ R. v. S.A.B., [2003 SCC 60](http://www.canlii.org/en/ca/scc/doc/2003/2003scc60/2003scc60.html); R v Collins, 1987 CanLII 84 (SCC)
  14. ↑ R. v. Law, 2002 SCC 10, [2002] 1 S.C.R. 227, at para 15
  15. ↑ R. v. McCormack, [2000] B.C.J. No. 143 (B.C.C.A.) at para 5

## Meaning of a "Search"[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-2)]

Any police conduct interfering with a reasonable expectation of privacy is a "search".[1]

Any "inspection is a search" where where a "person has a reasonable privacy interest in the object or subject matter of the state action and the information to which it gives access".[2]

Knocking at the door for a investigative purpose is not a search.[3]

However, going onto private property and peering into windows while attempting to detect odours of marijuana can constitute a search.[4]

Merely peering into a car windows at night using a flash-light while the car in on a public highway is not a search.[5]

Detection of an odour of marijuana from a bag, by an officer using his own senses, while performing other duties does not constitute a search.[6] This is distinct from detection with the use of technology, such as a sniffer dog or a FLIR device.[7]

However, police observations of stains on a shirt visible to the public is not a search.[8]

  1. ↑ Hunter v. Southam Inc., 1984 CanLII 33 (SCC), [1984] 2 S.C.R. 145  
R. v. Edwards, 1996 CanLII 255 (SCC), [1996] 1 S.C.R. 128  
R. v. Law, 2002 SCC 10, [2002] 1 S.C.R. 227 at para. 15  
R. v. Wise, 1992 CanLII 125 (SCC), [1992] 1 S.C.R. 527 at 533 (only “[i]f the police activity invades a reasonable expectation of privacy, [that] the activity is a search”)
  2. ↑ R. v. Cole, [2012 SCC 53](http://canlii.ca/t/ft969) (CanLII), at para. 34
  3. ↑ See R v MacDonald, 2012 NSCA 50 at 19  
R. v. Hope, 2007 NSCA 103 at para. 27  
R. v. Evans, [1996] 1 S.C.R. 8 at para. 8  

  4. ↑ R. v. Kokesch 1990 CanLII 55 (SCC), (1990), 61 C.C.C. (3d) 207 (S.C.C.)
  5. ↑ See R. v. Mellenthin 1992 CanLII 50 (SCC), (1992), 76 C.C.C. (3d) 481 (S.C.C.) at 486-87
  6. ↑ R. v. Rajaratnam, 2006 ABCA 333, 2006 ABCA 333, 67 Alta. L.R. (4th) 22
  7. ↑ e.g. R v Tessling [2004] 3 S.C.R. 432, 2004 SCC 67
  8. ↑ R. v. Hamadeh, [2011 ONSC 1241](http://canlii.ca/t/2fw3p) at 132 to 145  


## Meaning of "Seizure"[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-3)]

A "seizure" in essence is the "taking of a thing from a person by a public authority without that person's consent".[1] An individual who gives something to an officer does not constitute a seizure. Rather it is merely the receipt of a thing.[2]

Any "taking is a seizure" where "a person has a reasonable privacy interest in the object or subject matter of the state action and the information to which it gives access".[3]

A seizure does not have to be connected to a search.[4]

Valid consent in this context is determined based on indicia such as:[5]

  1. there was a consent, express or implied;
  2. the giver of the consent had the authority to give the consent in question;
  3. the consent was voluntary in the sense that that word is used in Goldman, supra, and was not the product of police oppression, coercion or other external conduct which negated the freedom to choose whether or not to allow the police to pursue the course of conduct requested;
  4. the giver of the consent was aware of the nature of the police conduct to which he or she was being asked to consent;
  5. the giver of the consent was aware of his or her right to refuse to permit the police to engage in the conduct requested; and,
  6. the giver of the consent was aware of the potential consequences of giving the consent.

Taking of a photograph by police has been considered a search or seizure.[6]

  1. ↑ R. v. Dyment, 1988 CanLII 10, [1988] 2 S.C.R. 417 at para. 26  
R. v. Law, 2002 SCC 10, [2002] 1 S.C.R. 227 at para. 15  

  2. ↑ R. v. Wills, [1992 CanLII 2780](http://canlii.ca/t/1npnl) (ON CA) at p. 347-348  
Illinois v. Rodrigues, 110 S. Ct 2793 (1999)  

  3. ↑ R v Cole at para. 34
  4. ↑ R. v. D.L.W., [2012 BCSC 1700](http://canlii.ca/t/fts53) (CanLII) at para. 63
  5. ↑ R. v. Wills, [1992 CanLII 2780](http://canlii.ca/t/1npnl) (ON CA) at p. 353  
adopted in R. v. Borden, 1994 CanLII 63 (SCC), [1994] 3 S.C.R. 145, at p. 162  

  6. ↑ R. v. Abbey, [2006] O.J. No. 4689 (S.C.J.); reversed on other grounds, 97 O.R. (3d) 330 (C.A.), [2010] S.C.C.A. No. 125: police took a photo of the accused's t-shirt after removing it from his body

## Zones of Protection[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-4)]

The Charter right protects a person's reasonable expectation of privacy. This is a protection of persons _not_ places.[1]

The right manifests itself in protecting the zones of the person, territory, and information.[2]

  1. ↑ See Katz v US, 389 US 347 (1967) at p. 351
  2. ↑ R. v. Tessling, [2004 SCC 67](http://canlii.ca/t/1j0wb) (CanLII), [2004] 3 SCR 432  
R. v. Gomboc, [2010 SCC 55](http://canlii.ca/t/2dhlk), [2010] 3 SCR 211 at para. 19

### Personal Privacy[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-5)]

Personal privacy "protects bodily integrity, and in particular not to have our bodies touched or explored to disclose objects or matters we wish to conceal."[1] It is for that reason that it is considered the strongest of the forms of privacy.[2]

This form of privacy is most often considered in a strip search[3] or a warrantless seizure of a bodily sample.[4]

  1. ↑ R v Tessling, [2004] 3 SCR 432 at para 21
  2. ↑ ibid.
  3. ↑ e.g. R v Golden, [2001] 3 SCR 679
  4. ↑ e.g. R v Stillman, [1997] 1 SCR 607  
R v Colarusso, [1994] 1 SCR 20

### Territorial Privacy[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-6)]

Privacy over personal territory traces back to the English common law with the maxim that "the house of everyone is to him as his castle and fortress".[1] This has since been adopted into the common law of Canada and the Canadian Charter of Rights and Freedoms.[2]

  1. ↑ Semayne's Case at para. 1
  2. ↑ Adopted in common law in Eccles v. Bourque et al., [1974 CanLII 191](http://canlii.ca/t/1z1gw) (SCC), [1975] 2 SCR 739,  
Adopted as applicable to Charter in Colet v. The Queen, [1981 CanLII 11](http://canlii.ca/t/1lpb2) (SCC), [1981] 1 SCR 2  


### Informational Privacy[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-7)]

The right protects the "biographical core of personal information" that includes "information which tends to reveal intimate details of the lifestyle and personal choices of the individual."[1]

  1. ↑ R. v. Plant, [1993 CanLII 70](http://canlii.ca/t/1fs0w) (SCC), [1993] 3 SCR 281

## Purpose of Search[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-8)]

The purpose of the search is a relevant to the analysis of the search. The most frequent form of search is a search for evidence of a commission of an offence, criminal or otherwise. Secondarily, there will be searches for the purpose of officer safety. Each type of search will have different scope of powers of search.

## Party Performing the Search[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-9)]

Section 8 of the Charter governs searches by government and its agents. The scope and degree of privacy is always with respect to a particular party.

An employee of a private company become an agent of the state when they are directed to perform a task by the police.[1] However, where the actions of the employee, company, or person, were strictly voluntary then they are not agents of the state.[2]

A police informer wearing a wire is an agent of the state.[3]

Employees of government agencies, such as social workers, who discover or investigate possible offences are agents of the state.[4] Similarly, a private citizen performing a citizen's arrest and searching a person in anticipation of the arrival of the police is an agent of the state.[5]

An Internet Service Provider forwarding information on the discovery of child pornography is acting as an agent of the state.[6]

  1. ↑ R. v. Liang, [2007 YKTC 18](http://canlii.ca/t/1r3nj) at para 241  
R. v. Dorfer, [1996 CanLII 10214](http://canlii.ca/t/2326g) (BC CA) at para. 39  

  2. ↑ R v Gomoboc [2010 SCC 55](http://canlii.ca/t/2dhlk), [2010] 3 SCR 211  
c.f. R. v. Poh, [2011 MBQB 214](http://canlii.ca/t/fn5qs)
  3. ↑ R. v. Broyles, [1991 CanLII 15](http://canlii.ca/t/1fshb) (SCC), [1991] 3 SCR 595  

  4. ↑ R. v. Choy, [2008 ABQB 737](http://canlii.ca/t/21qxs) at para 28 - social worker discovering bruising  
R. v. Westrageer et al, [2005 BCSC 1558](http://canlii.ca/t/1lwwm) at para 43: social working investigating child welfare complaint  
R. v. Chang, [2003 ABCA 293](http://canlii.ca/t/4s1h) : private security guard seizing property for police c.f. R. v. Allen, [2010 CanLII 73011](http://canlii.ca/t/2dvjl) (NL PC)
  5. ↑ R. v. Lerke, [1986 ABCA 15](http://canlii.ca/t/1nnwz)
  6. ↑ R. v. Weir, [2001 ABCA 181](http://canlii.ca/t/5rdq) at para. 11

## See also[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure&action=edit&section=T-10)]

  * [Canadian Criminal Procedure and Practice/Search and Seizure/Seizure of Property](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property)

  


# Search and Seizure/Reasonable Expectation of Privacy[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Introduction[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-1)]

A search can be unreasonable where it intrudes on a person's reasonable expectation of privacy.[1]

An "expectation of privacy is a normative rather than a descriptive standard"[2]

The determination of privacy rights is made "from the independent perspective of the reasonable and informed person who is concerned about the long-term consequences of government action for the protection of privacy."[3]

The rights are intended to protect "biographical core of personal information which individuals in a free and democratic society would wish to maintain and control from dissemination to the state." It further "include[s] information which tends to reveal intimate details of the lifestyle and personal choices of the individual."[4]

Courts interpret privacy in a "broad and liberal manner". [5]

Section 8 protects persons not places.[6] The Charter does not recognize regions of immunity.[7] Solicitor-client meeting rooms, for example, or confessionals are given no heightened expectation of privacy due to their intended use.

Privacy is held with respect to different parties. A person will hold a different expectation of privacy from an employer than from the police.[8]

A person cannot have a reasonable expectation of privacy in what they knowingly expose to part or all of the public or abandons in a public place.[9]

The accused must begin by establishing the existence of a s.8 right by showing there is was reasonable expectation of privacy.

  1. ↑ see R. v. Edwards, 1996 CanLII 255 (SCC), [1996] 1 S.C.R. 128, at paras. 33 and 39
  2. ↑ R v Tessling, [2004 SCC 67](http://canlii.ca/t/1j0wb) at para. 42
  3. ↑ R. v. Patrick, [2009 SCC 17](http://canlii.ca/t/231wj) (CanLII), [2009] 1 SCR 579 at para. 14
  4. ↑ R. v. Plant, [1993 CanLII 70](http://canlii.ca/t/1fs0w) (SCC), [1993] 3 SCR 281
  5. ↑ R. v. Dyment, 1988 CanLII 10 (SCC), [1988] 2 S.C.R. 417
  6. ↑ Hunter v Southam Inc., 1984 CanLII 33 (SCC), [1984] 2 SCR 145 at pp. 158-9
  7. ↑ Hunter v Southam Inc. at pp. 158-9
  8. ↑ e.g. R v Buhay, [2003] 1 S.C.R. 631, 2003 SCC 30: owner of locker allowed in locker but not police  
maid in a hotel can come into room but not the police  
bank clerk has a master key to safety deposit box  

  9. ↑ R. v. Tessling, [2004 SCC 67](http://canlii.ca/t/1j0wb) (CanLII), [2004] 3 SCR 432 at para. 40  
R. v. Boersma, 1994 CanLII 99 (SCC), [1994] 2 S.C.R. 488  
R v Stillman, [1997] 1 S.C.R. 607, at para. 62, 226  
R. v. Evans, [1996 CanLII 248](http://canlii.ca/t/1frf4) (SCC), [1996] 1 SCR 8, at para. 50 (dissent)  
Baron v. Canada, 1993 CanLII 154 (SCC), [1993] 1 S.C.R. 416, at p. 453  
R v Dyment, [1988 CanLII 10](http://canlii.ca/t/1ftc6) (SCC), [1988] 2 SCR 417, at p. 435  
R. v. Monney, 1999 CanLII 678 (SCC), [1999] 1 S.C.R. 652, at para. 45

## Factors[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-2)]

Factors considered in R. v. Edwards[1]:

  1. A reasonable expectation of privacy is to be determined on the basis of the totality of the circumstances.[2]
  2. The factors to be considered in assessing the totality of the circumstances may include, but are not restricted to, the following: 
    1. presence at the time of the search; 
    2. possession or control of the property or place searched; 
    3. ownership of the property or place; 
    4. historical use of the property or item; 
    5. the ability to regulate access, including the right to admit or exclude others from the place; 
  3. the existence of a subjective expectation of privacy; and 
    1. the objective reasonableness of the expectation. 

When in the context of "informational privacy", the Edwards criteria were amended to include other considerations and factors:[3]

  1. What was the nature or subject matter of the evidence gathered by the police?
  2. Did the appellant have a direct interest in the contents?
  3. Did the appellant have a subjective expectation of privacy in the informational content of the evidence?
  4. If so, was the expectation objectively reasonable? In this respect, regard must be had to: 
    1. the place where the alleged “search” occurred
    2. whether the informational content of the subject matter was in public view;
    3. whether the informational content of the subject matter had been abandoned;
    4. whether such information was already in the hands of third parties; if so, was it subject to an obligation of confidentiality?
    5. whether the police technique was intrusive in relation to the privacy interest;
    6. whether the use of this evidence gathering technique was itself objectively unreasonable;
    7. whether the informational content exposed any intimate details of the appellant’s lifestyle, or information of a biographic nature.

  1. ↑ 1996 CanLII 255 (SCC), [1996] 1 S.C.R. 128 at para. 45
  2. ↑ See also R v Cole 2012 SCC 53 at para. 39
  3. ↑ R v Tessling 2004 SCC 67 and R. v. Patrick, [2009 SCC 17](http://www.canlii.org/en/ca/scc/doc/2009/2009scc17/2009scc17.html) at para. 27, per Binnie

## Established Zones of Privacy[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-3)]

### Vehicles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-4)]

A driver has a reasonable expectation of privacy for the contents of his motor vehicle.[1] The reasonable expectation of privacy for a vehicle is low.[2] It is considered more limited than locations such as houses.[3]

Passengers however do not generally have a reasonable expectation of privacy.[4] However, in some cases they can. It will depend on the totality of the circumstances including the passenger's connection with the vehicle, the vehicle's owner, the passenger's use of the vehicle, and ability to control access to it.[5]

  1. ↑ R. v. Belnavis 1996 CanLII 4007, 107 C.C.C. (3d) 195 (Ont. C.A.); appeal dismissed [1997 CanLII 320](http://canlii.org/en/on/onca/doc/1996/1996canlii4007/1996canlii4007.html), [1997] 3 S.C.R. 341 [[3]](http://canlii.org/en/ca/scc/doc/1997/1997canlii320/1997canlii320.html) at 19
  2. ↑ R. v. Alkins, [2007] O.J. No. 1348 (Ont. C.A.)  
R. v. Shankar, [2007] O.J. No. 1406 (Ont. C.A.)  
R. v. Rebelo, [2007] O.J. No. 1468 (Ont. C.A.)  

  3. ↑ R. v. Wise, 1992 CanLII 125, [1992] 1 S.C.R. 527; R. v. Belnavis, 1997 CanLII 320, [1997] 3 S.C.R. 341
  4. ↑ See [Canadian_Criminal_Procedure_and_Practice/Pre-Trial_Matters/Applications_and_Motions_Procedure#Standing](/wiki/Canadian_Criminal_Procedure_and_Practice/Pre-Trial_Matters/Applications_and_Motions_Procedure#Standing)
  5. ↑ R v Belnavis at 22  
R. v. Madore & Madeira, [2012 BCCA 160](http://canlii.ca/t/fqzrs) at 55  


### Residences[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-5)]

There is a high expectation of privacy in a house. Unlawful entry will be a serious intrusion on the person's privacy rights.[1]

It can "be presumed unless the contrary is shown in a particular case that information about what happens inside the home is regarded by the occupants as private".[2]

A search of a dwelling is considered an invasion of a place with the "highest degree of privacy".[3]

A person will have a diminished expectation of privacy where legislation authorizes police intrusion.[4]

Police intrusion upon private property can only be permitted "only by powers granted in clear statutory language"[5]

  1. ↑ see R. v. Silveira 1995 CanLII 89 (SCC) at 463-4, 495-6 (the “historic inviolability of a dwelling-place”)  
R. v. Dhillon, [2010] O.J. No. 3749 (C.A.)  
R. v. Tessling, [2004 SCC 67](http://canlii.ca/t/1j0wb) (CanLII), [2004] 3 S.C.R. 432, 189 C.C.C. (3d) 129 at 139  

  2. ↑ R v Tessling 2004 SCC 67 at para. 144
  3. ↑ R. v. Sutherland 2000 CanLII 17034 (ON CA), (2000), 150 C.C.C. (3d) 231 (Ont. C.A.) at para 239 ("search of a dwelling house must be approached with the degree of responsibility appropriate to an invasion of a place where the highest degree of privacy is expected")
  4. ↑ R. v. D.L.W., [2012 BCSC 1700](http://canlii.ca/t/fts53) (CanLII) at para. 38  
("A person has a restricted objective expectation of privacy when legislation authorizes the police’s intrusion into that person’s privacy.")
  5. ↑ R. v. Kokesch, 1990 CanLII 55 (SCC), [1990] 3 S.C.R. 3, 61 C.C.C. (3d) 207 at p. 218 per Dickson C.J.C. ("... This court consistently has held that the common law rights of the property holder to be free of police intrusion can be restricted only by powers granted in clear statutory language.")

### Non-dwelling Residences[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-6)]

Provided an expectation of privacy exists in a non-dwelling residence, the accused's standing may invoked where he has "an ownership interest in the premises" absence countervailing evidence.[1]

  1. ↑ e.g. R. v. Fankhanel, [1999 CanLII 19075](http://canlii.ca/t/2bqs6) (AB QB)  
c.f. R v Pugliese (1992) 71 CCC (3d) 295 (ONCA) - no standing for owner of building who did not live in it  


### Person[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-7)]

An individual who attends a hospital for medical treatment is entitled to expect that his clothing will be held by the facility until discharged. Hospitals have been identified as an area of concern for the protection of privacy. [1]

**Bodily Samples**  
DNA samples taken as part of a previous sentence is not protected by a reasonable expectation of privacy.[2]

**Fingerprints**  
Fingerprints taken as part of a previous sentence is not protected by a reasonable expectation of privacy.[3]

**Photographs**  
Photographs taken as part of a previous sentence is not protected by a reasonable expectation of privacy.[4]

**Body Cavity**  
Strip searches can be humiliating, embarrassing, and degrading for the accused.[5] It is also one of the most extreme forms of search available to police.[6]

  1. ↑ R v Pickton, 2006 BCSC 1098 at para 38 citing R v Calarusso, 1994 CanLII 134 (SCC) at para 70
  2. ↑ R. v. DeJesus, [2010 ONCA 581](http://canlii.ca/t/2ch4l) (CanLII)
  3. ↑ R. v. Jackpine (2006), 207 C.C.C. (3d) 225 (S.C.C.), at para. 43 - anything taken under the Identification of Criminals Act has no REP
  4. ↑ R. v. Jackpine (2006), 207 C.C.C. (3d) 225 (S.C.C.), at para. 43 - anything taken under the Identification of Criminals Act has no REP
  5. ↑ R v Golden 2001 SCC 83 at 89
  6. ↑ R. v. Flintoff, 1998 CanLII 632 at 24

### Storage[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-8)]

School lockers have a reduced expectation of privacy with respect to teaching staff.[1]

  1. ↑ R. v. M. (M.R.), [1998 CanLII 770](http://canlii.ca/t/1fqq9) (SCC), [1998] 3 SCR 393  
see also <http://en.wikipedia.org/wiki/R._v._M._(M.R.)>

### Business Records[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-9)]

Telephone records detailing contact between various persons has a reduced expectation of privacy, in comparison to personal medical records[1]

Several lines of cases have developed on the issue of whether there is a reasonable expectation of privacy in subscriber information associated with business accounts, in particular IP addresses. Generally they have sided on there not being privacy rights in "tombstone" information of a person since it is freely available to the public.[2] In certain cases this will turn on the service contract. Where a contract is not in evidence a court is more likely to find in favour of there being a expectation of privacy.[3]

Whether a person has a bank account with a particular bank does not have a reasonable expectation of privacy because that information does not reveal any core biographical information.[4]

  1. ↑ R. v. M.(B.) 1998 CanLII 13326 (ON CA), (1998), 42 O.R. (3d) 1 (C.A.), at para. 62  
See also, R. v. Hutchings 1996 CanLII 703 (BC CA), (1996), 111 C.C.C. (3d) 215 (B.C.C.A.), at para. 25  
R. v. Mahmood, 2011 ONCA 693 at 98
  2. ↑ No REP: R. v. Ward, [2008] O.J. No. 3116 (Ct. Jus.)  
R v Caza [2012 BCSC 525](http://canlii.ca/t/fqzgm)  
R. v. Friers, [2008] O.J. No. 5646 (Ct. Jus.)  
R. v. Verge, [2009] O.J. No. 6300 (Ct. Jus.)  
R. v. Vasic, [2009 CanLII 23884](http://canlii.ca/t/23jrk) (ON SC)  
R. v. Wilson, [2009] O.J. No. 1067 (Sup. Ct.)  
R. v. Spencer, [2009] S.J. No. 798 (Q.B.)  
R. v. McNeice, [2010 BCSC 1544](http://canlii.ca/t/2d5dp)  
R. v. Brousseau, [2010 ONSC 6753](http://canlii.ca/t/2fcf5)  
R. v. Ballendine, [2011 BCCA 221](http://canlii.ca/t/fl8xf)  
Yes, REP: R v Trapp, [2011 SKCA 143](http://canlii.ca/t/fp3n3) R. v. Cuttell, [2009 ONCJ 471](http://canlii.ca/t/25z7h)
  3. ↑ e.g. in R. v. Cuttell, [2009 ONCJ 471](http://canlii.ca/t/25z7h) at 57
  4. ↑ R v Quinn 2006 BCCA 255 - police were allowed to speak to bank to find out if accused had an account there and used that information for a search warrant.

## Garbage[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-10)]

Generally speaking, there is no expectation of privacy is materials found in a dumpster.[1]

  1. ↑ R. v. Sipes, 2008 BCSC 1500 and [2012 BCSC 1948](http://canlii.ca/t/fvfd1) (CanLII)

### Computers and Electronic Devices[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-11)]

Home and personal computers are imbued with a high degree of privacy due to the frequency that it contains intimate correspondence, financial, medical, or personal information. In addition to our personal interests and tastes.[1] According to the Morelli court, the level of privacy does not get much higher.[2]

Generally, all personal electronic devices similar to home computers have a high level of privacy.[3]

Any electronic device (computer, cell phone, etc) will contain information detailing a persons life that can be "deeply personal". Personal information can be found in: [4]

  * Contact Information (detailing names, addresses, phone numbers, e-mail addresses and similar information);
  * Internet Browsing (history of websites, log-in information, passwords, form data);
  * Calendars;
  * Photographs and videos;
  * Messages (emails, texts, voicemails);
  * Phone Call Logs (dialled/received/missed calls, caller identification);

It is suggested that the degree of privacy is lessened where a personal computer has been brought to a repair shop.[5] In some cases, there is no expectation of privacy. In R. v. Piette,[2009 QCCQ 14499](http://canlii.ca/en/qc/qccq/doc/2009/2009qccq14499/2009qccq14499.html) a computer repairman makes copy of child abuse images found on computer onto a CD and gives it to police. The court found no REP on CD so no need for warrant.

There is conflicting case law on instances where a third party examines a computer system and discovers evidence of a criminal offence on it. In R. v. Cole, [2008 ONCJ 278](http://canlii.ca/en/on/oncj/doc/2008/2008oncj278/2008oncj278.html) the school supervisor finds child abuse images on network directory of employee, he tells police who seize computer and send for a forensic analysis. The court found section 8 violated for search without warrant.

An accused loses their reasonable expectation of privacy to a household computer once they move out.[6]

The search of a computer cannot always be precise. An investigating officer looking for a particular piece of evidence may need to diverge into several areas of the hard drive in the same way as a person searching a house would look into a number of draws of a bedroom before finding evidence.[7]

Workplace computers are considered to have limited or no expectation of privacy. [8] This will turn on the employer's privacy policy on whether the employees can keep personal things on work computers.[9]

A computer seized as under plain view under s. 489 during the execution of a general residential search warrant is permissible. However, the search of its contents may require a warrant.[10]

  1. ↑ R. v. Morelli, [2010 SCC 8](http://canlii.org/en/ca/scc/doc/2010/2010scc8/2010scc8.html) at 105
  2. ↑ Morelli at para 2: (“It is difficult to imagine a search more intrusive, extensive, or invasive of one's privacy than the search and seizure of a personal computer.”
  3. ↑ R. v. Choudry, [2009] O.J. No 84 (ONSC) R. v. Little, [2009 CanLII 41212](http://canlii.ca/t/2509x) (ONSC) R. v. Polius, [2009] O.J. No 3074 (ONSC)
  4. ↑ see discussion in R. v. Polius, [2009] O.J. No. 3074 (Sup. Ct.)
  5. ↑ R. v. Graham, [2010] O.J. No. 146 (Sup. Ct.): ( Defence argued a high degree of privacy in the computer at the repair shop, the judge said "I agree that in other factual situations that a court may have to consider, those other concerns [of Defence] might have a more prominent place. I do not have those facts before me.")  
R. v. Winchester, [2010 ONSC 652](http://canlii.ca/t/27qm8), [2010] O.J. No. 281 (Sup. Ct.) at para. 36: (“while I am not prepared to find that the applicant had no expectation of privacy in the contents of the computer when he left it at the store, I do find that this expectation was significantly reduced.”)
  6. ↑ R. v. Pommer (2008), 58 C.R. (6th) 319, 2008 CarswellBC 1181, 2008 BCSC 423, (B.C. S.C.)
  7. ↑ R. v. Stemberger, 2012 ONCJ 31 (CanLII), <<http://canlii.ca/t/fpqjb>> at 99, 110
  8. ↑ R. v. Cole, [2009] CanLII 20699 (Sup. Ct.) rev'd 2011 ONCA 0218  
R. v. Ritter (2006), 402 A.R. 249 (Prov. Ct.)  

  9. ↑ R v Cole, supra
  10. ↑ R. v. Little, [2009 CanLII 41212](http://canlii.ca/t/2509x) (ON SC)

### Peer-to-Peer Software[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-12)]

Software installed on a computer that enables other persons on a network to access information and files on a computer, such as Peer-to-Peer software, is relevant to the courts usually in a child pornography cases.

Some US cases have considered whether there is a privacy right in the computer's shareable files. Courts have concluded that files found on a computer that are accessible and transferable over a peer-to-peer do not have a reasonable expectation of privacy due to the [1]

In Canada, there is a slow adoption of the same view. In R v Caza, [2012 BCSC 525](http://canlii.ca/t/fqzgm), the court noted that the shared directory in a peer-to-peer network is much less private than a dwelling. It is not the same as a search through the entire hard drive of an entire computer because it is more restrictive. The search of shared files on peer-to-peer network does not engage s. 8 of the Charter.[2]

  


  1. ↑ US v. Ganoe, 538 F.3d 1117 (2008) ("although as a general matter an individual has an objectively reasonable expectation of privacy in his personal computer…we fail to see how this expectation can survive Ganoe’s decision to install and use file-sharing software, thereby opening his computer to anyone one else with the same freely available program.")  
State v. Mahan, 2011 WL 4600044: the police internet investigation program "simply automated the ability to search information that had been placed in the public domain")  
US v. Sawyer, 786 F. Supp. 2d 1352 (2011) suggested that once access is given to a “friend” the owner is giving up their right to privacy over those shareable files, simply because the police are not identifying themselves does not change things
  2. ↑ R. v. Caza [2012 BCSC 525](http://canlii.ca/t/fqzgm) at 90 to 97, 113

#### Memory Sticks[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-13)]

In R. v. Tuduce, 2011 ONSC 2749, the court said that a search of a memory stick has a REP and so requires a search warrant.[1]

  


  1. ↑ R. v. Tuduce, [2011 ONSC 2749](http://canlii.ca/t/flfj1) at 41-45

#### Cell phones[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-14)]

There is a division in the case law on the level of privacy there is for cell phones.

A smart cellphone, as a digital device, is said to have a high expectation of privacy. It is like "an archive of social, family and business activities".[1]

Several cases have stated that a complete forensic analysis of a cell phone, a so-called "data dump", without a warrant is impermissible.[2]

There is limited authority stating no search of phones is permitted.[3]

A limited warrantless search is permitted incident to arrest when the search is connected with the investigation. On arrest for drugs, the police may search the calling records on the cell phone.[4]

In Giles, 2007 BCSC 1147, the court stated the police can search and download copies of emails on a blackberry incident to arrest.[5]

  


  1. ↑ R. v. Sheck, [2012 BCPC 39](http://canlii.ca/t/fqcl3) (CanLII) at 17
  2. ↑ R v Schira, [2011 SKPC 140](http://canlii.ca/t/fncbn) (CanLII) at 57 to 59  
R. v. Hiscoe, [2011 NSPC 84](http://canlii.ca/t/fnv9d) (CanLII), at para 7  
R. v. Dorey, [2011 NSPC 85](http://canlii.ca/t/fnvbd) (CanLII) at 8 (follows Hiscoe)  

  3. ↑ R. v. Sheck, [2012 BCPC 39](http://canlii.ca/t/fqcl3) at 20
  4. ↑ R. v. Hiscoe, [2011 NSPC 84](http://canlii.ca/t/fnv9d) at para 7, 8  
R. v. Otchere-Badu, [2010 ONSC 1059](http://canlii.ca/t/28fsj) at para 83  

  5. ↑ R. v. Giles, [2007 BCSC 1147](http://canlii.ca/t/1w8ms) (CanLII) at para 72

### Prisons[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy&action=edit&section=T-15)]

An inmate in a correctional facility has a very limited expectation of privacy over their phone calls.[1]

  1. ↑ R v Drader, 2012 ABQB 168  
R. v. McIsaac, 2005 BCSC 385  


# II - Warrantless Searches[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit&section=3)]

## Types of Search[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches&action=edit&section=T-1)]

An individual alleging a breach of his or her _Charter_ rights bears the burden of proving that violation on a balance of probabilities. That being said, if the individual can demonstrate that a police search was conducted without a warrant, that search will be presumed to be unreasonable unless shown to be justified.[1] The Crown then must prove the reasonableness of the search on a balance of probabilities. [2] Reasonableness of a search has both a subjective an objective and subjective component.[3]

The Police cannot enter into a private dwelling without a warrant, consent, or exigent circumstances.[4]

There are four types of warrantless searches:

  1. [Search by Consent](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search);
  2. [Search Incident to Detention](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Detention);
  3. [Search Incident to Arrest](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest);
  4. [Search of Abandoned Property](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Abandoned_Property);
  5. [Search in Plain View](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Plain_View);
  6. [Exigent Circumstances](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Exigent_Circumstances)

  


  1. ↑ Hunter v. Southam Inc., [1984] 2 S.C.R. 145 [1984 CanLII 33](http://canlii.org/en/ca/scc/doc/1984/1984canlii33/1984canlii33.html);  
R. v. Golden, [2001] 3 S.C.R. 679, [2001 SCC 83](http://www.canlii.org/en/ca/scc/doc/2001/2001scc83/2001scc83.html);  
R. v. Mann, [2004 SCC 52](http://www.canlii.org/en/ca/scc/doc/2004/2004scc52/2004scc52.html)  
R. v. Feeney, [1997] 2 S.C.R. 13 at para. 54  

  2. ↑ see R. v. Caslake, [1988] 1 S.C.R 51 at para. 11 [1998 CanLII 838](http://canlii.org/en/ca/scc/doc/1998/1998canlii838/1998canlii838.html)
  3. ↑ R v Bernshaw, 1995 CanLII 150 (SCC)
  4. ↑ R. v. Feeney, [1997] 2 SCR 13, [1997 CanLII 342](http://canlii.ca/t/1fr1w) (SCC) at 44

# Search and Seizure/Warrantless Searches/Abandoned Property[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Abandoned_Property&action=edit&section=T-1)]

A person gives up their reasonable expectation to privacy when their property becomes abandoned.[1]

The main issue is whether the claimant "acted in relation to the subject matter of his privacy claim in such a manner as to lead a reasonable and independent observer to conclude that his continued assertion of a privacy interest is unreasonable in the totality of the circumstances." This is found as a matter of fact.[2]

A main point of litigation is over whether the officer had grounds to believe that the property was abandoned. This is particularly true where the information is based on hearsay or assumptions.

## Case Digests[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Abandoned_Property&action=edit&section=T-2)]

  * R. v. Stevens, [2012 ONCA 307](http://canlii.ca/t/fr96q) \- Throwing a firearm out the window into a neighbour's yard is a form of abandonment

## References[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Abandoned_Property&action=edit&section=T-3)]

  1. ↑ R. v. Patrick, [2003 SCC 17 at para. 22-23, 25](http://canlii.ca/t/231wj#par22)
  2. ↑ Patrick at 25

  


# Search and Seizure/Warrantless Searches/Consent Search[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search&action=edit&section=T-1)]

A search conducted with valid consent is lawful.[1]

Valid consent exists where the following is present:[2]

  1. There was a consent, either express or implied;
  2. The consenting party has the authority to give the consent;
  3. Consent was voluntary and not the product of police oppression, coercion or other external conduct negating freedom to choose not to consent;
  4. The consenting party knew of the nature of the police conduct to which he or she was being asked to consent;
  5. The consenting party knew they had the ability to refuse the search;
  6. The consenting party was aware of the potential consequences of giving the consent, including a general understanding of the jeopardy resulting from the police conduct about which the consent was being sought.

  
For consent to be valid it must be voluntary and informed. Voluntary search requires that the consent to be given without coercion.[3]

Informed consent to a search requires the accused to be aware of the right to refuse the search and the consequences of consenting to the search.[4]The party expressing "consent must be possessed of the requisite informational foundation for a true relinquishment of the right. A right to choose requires not only the volition to prefer one option over another, but also sufficient available information to make the preference meaningful.”[5]

The cases are divided on whether the police need to give clear instructions on the right to refuse. In R v Rutten 2006 SKCA 17 at 39 to 44, the court stated that permission to enter to search a dwelling must include information on the person's right to refuse. While elsewhere it is said that the standard of informed consent is less than the informational component of s. 10(b). The police need not tell the accused of the right to refuse consent. However, a failure to do so may result in a lack of informed consent.[6]

The Crown must establish that the accused right to be searched was waived clearly and unequivocally.[7] However, where the accused is given access to counsel there is a presumption of informed consent unless the accused shows otherwise.[8]

Once consent is given there is no future expectation of privacy.[9]

The "occupier of a dwelling gives implied licence to any member of the public, including a police officer, on legitimate business to come on to the property” [10]

Consent to enter a home does not include a blanket right to search the whole house including the basement.[11]

  


  


  1. ↑ R. v. Chang, [2003 ABCA 293 at 28](http://canlii.ca/t/4s1h#par28)
  2. ↑ R. v. Wills, [1992 CanLII 2780 (ON CA)](http://canlii.ca/t/1npnl), (1992), 70 C.C.C. (3d) 529 at 69  
R. v. Cooper, [2011 ABQB 17 at 35-41](http://canlii.ca/t/2f7rc#par35)  
R v Borden [1994 CanLII 63](http://canlii.ca/t/1frrd) [1994] 3 SCR 145  

  3. ↑ R v Bergauer-Free 2009 ONCA 610 at 57  
See also R v Goldman, [1979 CanLII 60](http://canlii.ca/t/1tx9c) (SCC), [1980] 1 SCR 976 at p. 1005
  4. ↑ R. v. Wills (1992), 12 C.R. (4th) 58 at 78 (Ont. C.A.)[1992 CanLII 2780](http://www.canlii.org/en/on/onca/doc/1992/1992canlii2780/1992canlii2780.html)  
R. v. Borden [1994 CanLII 63](http://www.canlii.org/en/ca/scc/doc/1994/1994canlii63/1994canlii63.html) (S.C.C.), (1994), 33 C.R. (4th) 147 at 158  
R v S.S. 2008 ONCA 578 at 48, 52  
c.f. R v Lupien 1995 68 QAC 253 (CA)  
R v Blackstock (1997) 10 CR 5th 385 (ONCA)  
US v Drayton 536 US 194 (2002) - police need not inform of right as long as there was no coercion, intimidation, or confrontation  

  5. ↑ R. v. Borden, [1994 CanLII 63](http://canlii.ca/t/1frrd) (SCC), [1994] 3 S.C.R. 145
  6. ↑ R v Lewis (1998) 122 CCC 3d 481 (ONCA)  

  7. ↑ R v Collins [1987] 1 SCR 265
  8. ↑ R v Williams (1992) 76 CCC 385 (BCSC)  
R v Deprez (1994) 95 CCC 29 (MBCA)  

  9. ↑ R v Arp [1998] 3 SCR 339 at 90
  10. ↑ R. v. Evans, [1996] 1 SCR 8, at para. 13 [[4]](http://www.canlii.org/en/ca/scc/doc/1996/1996canlii248/1996canlii248.html), citing R. v. Tricker 1995 CanLII 1268 (ON CA), (1995), 21 O.R. (3d) 575, at p. 579
  11. ↑ R v Smith (1998) 128 CCC 3d 62 (ABCA)

## Who has authority to give consent and Third Party Consent[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search&action=edit&section=T-2)]

An "authorized occupant" of a residence may give consent to a search.[1]

A homeowner can authorize a search.[2]

A landlord or neighbour does not constitute an "authorized occupant".[3]

Guests can have the authority to consent to a search of a home, however, the authorization can be revoked by the homeowner.[4]

  
For all searches the police must have a subjective belief that they have consent to conduct the search and it must be an objectively reasonable belief in the circumstances. Where the policer wrongly relied upon consent of a third party, the reasonableness of their belief will go to the section 24(2) analysis.[5]

  1. ↑ R v Duarte 1987 38 CCC 3d 1 (ONCA) at p11  
R v Currie 2008 ABCA 374  

  2. ↑ R v Smith [1998 ABCA 418 at 5](http://canlii.ca/t/5scs#par5)
  3. ↑ R v. Mercer (1992) 70 CCC 180 (ONCA) - landlord  
R v Blinch 1993 83 CCC 3d 158 (BCCA)  

  4. ↑ R v Thomas [1991 CanLII 2736 (NL CA)](http://canlii.ca/t/1p8vs) aff'd at SCC
  5. ↑ R. v. DiPalma, [2008 BCCA 342](http://canlii.ca/t/20k8k) (CanLII)

## Mandatory Consent[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search&action=edit&section=T-3)]

A court order, such as a probation order, can in certain circumstances require an offender to consent to random searches.[1]

  1. ↑ R v Unruh, 2012 SKCA 72

## Consent by Organizations Holding Personal Information[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search&action=edit&section=T-4)]

Privacy of personal information within private companies is governed by the Personal Information Protection and Electronic Documents Act (PIPEDA).

Section 7(3) permits the disclosure of personal information without the subject's knowledge or consent:

> **Disclosure without knowledge or consent**  
(3) For the purpose of clause 4.3 of Schedule 1, and despite the note that accompanies that clause, an organization may disclose personal information without the knowledge or consent of the individual only if the disclosure is
> 
> ...
> 
>     (c.1) made to a government institution or part of a government institution that has made a request for the information, identified its lawful authority to obtain the information and indicated that 
> 
>     (i) it suspects that the information relates to national security, the defence of Canada or the conduct of international affairs,
>     (ii) the disclosure is requested for the purpose of enforcing any law of Canada, a province or a foreign jurisdiction, carrying out an investigation relating to the enforcement of any such law or gathering intelligence for the purpose of enforcing any such law, or
>     (iii) the disclosure is requested for the purpose of administering any law of Canada or a province;
> 
> ...
> 
>     (d) made on the initiative of the organization to an investigative body, a government institution or a part of a government institution and the organization 
> 
>     (i) has reasonable grounds to believe that the information relates to a breach of an agreement or a contravention of the laws of Canada, a province or a foreign jurisdiction that has been, is being or is about to be committed, or
>     (ii) suspects that the information relates to national security, the defence of Canada or the conduct of international affairs;
> 
> ...
> 
>     (h.2) made by an investigative body and the disclosure is reasonable for purposes related to investigating a breach of an agreement or a contravention of the laws of Canada or a province; ...
> 
> – [PIPEDA](http://www.canlii.org/en/ca/laws/stat/sc-2000-c-5/latest/sc-2000-c-5.html)

Under this section a peace officer may make a Law Enforcement Request (LER) requesting particular information of an accused person without their consent. A proper LER should identify the person requesting the information, what information is being requested, the purpose of the request for the information (presumably to obtain evidence to an offence). The organization is permitted but not required to provide the information requested.

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search&action=edit&section=T-5)]

  * [Waiver of Charter Rights](/wiki/Canadian_Criminal_Procedure_and_Practice/Waiver_of_Charter_Rights)

  


# Search and Seizure/Warrantless Searches/Exigent Circumstances[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Exigent_Circumstances&action=edit&section=T-1)]

Where there are "exigent circumstances", a police officer may forego the requirement of a search warrant.

The Courts have long recognized that the protections of s. 8 are "circumscribed by the existence of the potential for serious and immediate harm." Exigent circumstances "inform the reasonableness of the search...and may justify the absence of prior judicial authorization".[1]

This rule has been codified in s. 487.11 of the Criminal Code:

> **Where warrant not necessary**  
487.11 A peace officer, or a public officer who has been appointed or designated to administer or enforce any federal or provincial law and whose duties include the enforcement of this or any other Act of Parliament, may, in the course of his or her duties, exercise any of the powers described in subsection 487(1) or 492.1(1) without a warrant if the conditions for obtaining a warrant exist but by reason of exigent circumstances it would be impracticable to obtain a warrant.
> 
> 1997, c. 18, s. 46.
> 
> – [CCC](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec487.11)

In the context of a drug offence s. 11(7) of the Controlled Drugs and Substances Act provides that:

> (7) A peace officer may exercise any of the powers described in subsection (1), (5) or (6) [the subsections setting out the powers of a peace officer having a search warrant] without a warrant if the conditions for obtaining a warrant exist but by reason of exigent circumstances it would be impracticable to obtain one.

Generally, "exigent circumstances" exists where "there is an imminent danger of the loss, removal, destruction or disappearance of the evidence if the search or seizure is delayed."[2]

In the context of police responding to 911 calls, the police have a duty to protect life which may result in a permissible encroachment on otherwise protected privacy rights. This right to protect life is "engaged whenever it can be inferred that the 911 caller is or may be in some distress, including cases where the call is disconnected before the nature of the emergency can be determined." [3]

The Crown must present an "evidentiary basis" to establish the underlying police safety concerns.[4]

  1. ↑ R. v. Tse, 2012 SCC 16 (CanLII), 2012 SCC 16
  2. ↑ R. v. Grant, 1993 CanLII 68 (SCC), [1993] 3 S.C.R. 223 ar para 32, Sopinka, J.
  3. ↑ R. v. Godoy, 1999 CanLII 709 (SCC), [1999] 1 S.C.R. 311
  4. ↑ R. v. Davis, [2012] A.J. No. 488 (P.C.) at para. 23

## Entry of residences[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Exigent_Circumstances&action=edit&section=T-2)]

The Supreme Court of Canada in R v Feeney held that s. 8 of the Charter requires a warrant to enter a residence to arrest unless it falls into the common law doctrine of "hot pursuit".[1]

Sections between 529 to 529.5 were added subsequent to the Feeney decision.

> **Authority to enter dwelling without warrant**  
529.3 (1) Without limiting or restricting any power a peace officer may have to enter a dwelling-house under this or any other Act or law, the peace officer may enter the dwelling-house for the purpose of arresting or apprehending a person, without a warrant referred to in section 529 or 529.1 authorizing the entry, if the peace officer has reasonable grounds to believe that the person is present in the dwelling-house, and the conditions for obtaining a warrant under section 529.1 exist but by reason of exigent circumstances it would be impracticable to obtain a warrant.
> 
> **Exigent circumstances**  
(2) For the purposes of subsection (1), exigent circumstances include circumstances in which the peace officer
> 
>     (a) has reasonable grounds to suspect that entry into the dwelling-house is necessary to prevent imminent bodily harm or death to any person; or
>     (b) has reasonable grounds to believe that evidence relating to the commission of an indictable offence is present in the dwelling-house and that entry into the dwelling-house is necessary to prevent the imminent loss or imminent destruction of the evidence.
> 1997, c. 39, s. 2. 
> 
> – [CCC](http://canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec529.3)

Section 529.3 "relieves against the requirement for a warrant to arrest where exigent circumstances make it impractical to obtain one."[2]

Exigent circumstances are "generally found to exist where the police have reasonable grounds to be concerned that prior announcement would: (i) expose those executing the warrant to harm and/or (ii) result in loss or destruction of evidence and/or (iii) expose the occupants to harm."[3]

Where police respond to a dropped 911 call they can enter the home if they have reasonable grounds to believe an offence has been committed. (R. v. Godoy [1999] 1 SCR 311, [1999 CanLII 709](http://www.canlii.org/en/ca/scc/doc/1999/1999canlii709/1999canlii709.html))

Searches of surrounding property is treated much in the same way as residences themselves. The police cannot search the perimeter of a residence without a warrant.[4]

On a warrantless entry into a residence the courts should look at factors including:[5]

  1. what information did the officers have?
  2. what information could they infer?
  3. what were their alternate courses of action?
  4. what was the reasonableness of the action they took?

Search of a rental room even with the consent of the building owner will generally require a warrant.[6]

  
At common law, the doctrine of **hot pursuit** permits a peace officer "to enter a private premises to make an arrest in hot pursuit".[7]

### Hot Pursuit Exception[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Exigent_Circumstances&action=edit&section=T-3)]

A "hot pursuit" requires a "fresh pursuit" that is a "continuous pursuit conducted with reasonable diligence, so that pursuit and capture along with the commission of the offence may be considered as forming part of a single transaction."[8]

Before the doctrine applies, the police must "already have the power and grounds to arrest without a warrant" before entering the residence.[9]

However, the police officer does not have to have personal knowledge to form the grounds. An officer continuing the pursuit from another officer can be sufficient.[10]

This exception is considered "narrow" and presumes the police are "literally at the heels of a suspect at the moment the suspect enters a dwelling-house"[11]

  1. ↑ R. v. Feeney, 1997 CanLII 342 (SCC), [1997] 2 S.C.R. 13
  2. ↑ R. v. Knelsen, [2012 MBQB 242](http://canlii.ca/t/ft4rc) (CanLII)
  3. ↑ R. v. DeWolfe 2007 NSCA 79 (CanLII), (2007), 222 C.C.C. (3d) 491  
R. v. Knelsen, [2012 MBQB 242](http://canlii.ca/t/ft4rc) (CanLII) (Exigent circumstances "include circumstances in which the police officer has reasonable grounds to suspect that entry is necessary to prevent imminent bodily harm or death to any person.")
  4. ↑ R. v. Kokesch, [1990] 3 SCR 3, [1990 CanLII 55](http://www.canlii.org/en/ca/scc/doc/1990/1990canlii55/1990canlii55.html)
  5. ↑ R. v. Jamieson, [2002 BCCA 411 at 24](http://canlii.ca/t/5kct#par24)
  6. ↑ R. v. Kenny (1992) 52 OAC 70
  7. ↑ R. v. Macooh, 1993 CanLII 107 (SCC), [1993] 2 S.C.R. 802 at para. 13
  8. ↑ Macooh at para. 24  
see also R. v. Hope, [2007] N.S.J. No. 433 (C.A.), at para 30  
R. v. Clarke, [2005] O.J. No. 1825 (C.A.), at para 29
  9. ↑ see R. v. Van Puyenbroek 2007 ONCA 824 at para 21
  10. ↑ see also R. v. Haglof, 2000 BCCA 604 (CanLII), 149 C.C.C. (3d) 248 and Van Puyenbroek
  11. ↑ Van Puyenbroek

## Wiretap[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Exigent_Circumstances&action=edit&section=T-4)]

See [Emergency_Wiretaps](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps#Emergency_Wiretap)

  


# Search and Seizure/Warrantless Searches/Incident to Arrest[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest&action=edit&section=T-1)]

    See also [Warrantless Arrest](/wiki/Canadian_Criminal_Procedure_and_Practice/Arrest_and_Detention#Arrest_without_Warrant) for details on arrest powers

In the situation of an arrest, it is generally permitted that upon lawful arrest, police have the power to search a person for officer safety reasons as well where there is "some reasonable prospect of securing evidence of the offence for which the accused is being arrested" and to secure that evidence. [1] A peace officer may also take property from a person which the officer reasonably believes is connected with the offence charged, or which may be used as evidence against the person arrested. [2] This power is derived from the common law. [3] This common law power is an exception to the usual requirement of "reasonable grounds" for a search. The Officer must subjectively believe that person is committing or has committed an indictable offence and their belief is based on objectively reasonable grounds.[4] The lawfulness of a search incident to arrest flows from the lawfluness of the arrest itself and so does not require independent reasonable grounds. [5]

Search incident to arrest is an exception to the rule that a warrantless search is _prima facie_ unreasonable.[6]

Further, an accused has no expectation of privacy with respect to his personal belongings seized upon arrest.[7]

Searches incidental to arrest are required to follow a number of principles stated in _R. v. Caslake_:[8]

  1. Officers undertaking a search incidental to arrest do not require reasonable and probable grounds; a lawful arrest provides that foundation and the right to search derives from it (Caslake at paras. 13 and 17);
  2. The right to search does not arise out of a reduced expectation of privacy of the arrested person, but flows out of the need for the authorities to gain control of the situation and the need to obtain information (Caslake at para. 17);
  3. A legally unauthorized search to make an inventory is not a valid search incidental to arrest (Caslake at para. 30);
  4. The three main purposes of a search incidental to arrest are: (1) to ensure the safety of the police and the public; (2) to protect evidence; (3) to discover evidence (Caslake at para. 19);
  5. The categories of legitimate purposes are not closed: while the police have considerable leeway, a valid purpose is required that must be “truly incidental” to the arrest (Caslake at paras. 10, 20 and 25);
  6. If the justification for the search is to find evidence, there must be a reasonable prospect the evidence will relate to the offence for which the person has been arrested (Caslake at para. 22);
  7. The police undertaking a search incidental to arrest subjectively must have a valid purpose in mind, the reasonableness of which must be considered objectively.

The police are obliged to safeguard items they have seized.[9]

  1. ↑ R. v. Caslake [1998] SCR 51 at 22
  2. ↑ R. v. Morrison 1987 CanLII 182 (ON C.A.), (1987), 35 C.C.C. (3d) 437
  3. ↑ Cloutier v. Langlois, [1990] S.C.J. No. 10 [[5]](http://canlii.org/en/ca/scc/doc/1990/1990canlii122/1990canlii122.html)
  4. ↑ R. v. Rajaratnam, 2006 ABCA 333 at para. 20 [[6]](http://www.canlii.org/en/ab/abca/doc/2006/2006abca333/2006abca333.html)
  5. ↑ R. v. Caslake, 1998 1 SCR 51 at 13
  6. ↑ R. v. Golden [2001] 3 SCR 679 at para 23
  7. ↑ R. v. Blais 2004 CanLII 8466 (ON C.A.) [[7]](http://www.canlii.org/en/on/onca/doc/2004/2004canlii8466/2004canlii8466.html))There is no "blanket authority" to search a car incident to arrest. (R. v. Bulmer, 2005 SKCA 90 [[8]](http://www.canlii.org/en/sk/skca/doc/2005/2005skca90/2005skca90.html)
  8. ↑ R. v. Caslake, [1998] 1 S.C.R. 51[[9]](http://www.canlii.org/en/ca/scc/doc/1998/1998canlii838/1998canlii838.html)
  9. ↑ R v Strilec, [2010 BCCA 198](http://canlii.ca/t/29d54); R v Wint [2009 ONCA 52](http://canlii.ca/t/225zz)

## Person Arrested[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest&action=edit&section=T-2)]

Searches conducted in the normal practice creating an inventory of items on a person who is being lodged in cells for an offence is a permissible search.[1]

  1. ↑ R v Unaru, [1994] BCJ No 1731 at 15

## Motor vehicles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest&action=edit&section=T-3)]

The common law power of police to search incident to arrest can include the accused's motor vehicle.[1] An officer may search a vehicle incidental to arrest where it is for a valid purpose related to the offence and where the officer reasonably believed that the search would be only to achieved that legitimate purpose.[2] There is no heightened expectation of privacy justifying an exemption from the usual common law principles of search incident to arrest.[3] For example, a search of a brief case found in a stolen vehicle incident to arrest is justified.[4] The presumption of unreasonableness of a warrantless search is rebutted upon proof that the arrest was lawful and the search was reasonable.[5]

When a vehicle is impounded lawfully, the officers have a duty to keep the property safe and take reasonable steps to do so. This will require entering the vehicle for itemizing the property of apparent value. [6]

  1. ↑ R. v. Polashek [1999 CanLII 3714](http://canlii.ca/t/1f9ff) (ON CA), (1999), 134 C.C.C. (3d) 187 (Ont. C.A.)  
R. v. Alkins [2007 ONCA 264](http://canlii.ca/t/1r4fd)
  2. ↑ R. v. Parchment, [2007 BCCA 326](http://canlii.ca/en/bc/bcca/doc/2007/2007bcca326/2007bcca326.html); Caslake at para. 19.
  3. ↑ R. v. Caslake, [1998 CanLII 838](http://canlii.ca/t/1fqww), [1998] 1 S.C.R. 51; R. v. Stillman, 1997 CanLII 384 (S.C.C.), [1997] 1 S.C.R. 607
  4. ↑ R. v. Mohamad, [2004 CanLII 9378](http://canlii.ca/t/1gblj) (ON C.A.), 182 C.C.C.(3d) 97 (Ont. C.A.)
  5. ↑ R. v. Klimchuk (1991), 67 C.C.C. (3d) 385 (B.C.C.A.) [[10]](http://www.canlii.org/en/bc/bcca/doc/1991/1991canlii3958/1991canlii3958.html)
  6. ↑ R v Nicolosi, [1998 CanLII 2006](http://canlii.ca/t/6h03) (ONCA) at 30

## Passengers of Vehicles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest&action=edit&section=T-4)]

A passenger in a motor vehicle generally does not have a reasonable expectation of privacy.[1] However, there is an expectation of privacy to the limited area underneath the passenger.[2]

  1. ↑ R. v. Belnavis, [1997] 3 S.C.R. 341 [1997 CanLII 320](http://www.canlii.org/en/ca/scc/doc/1997/1997canlii320/1997canlii320.html)
  2. ↑ R. v. Dreyer, [2008 BCCA 89](http://www.canlii.org/en/bc/bcca/doc/2008/2008bcca89/2008bcca89.html)

## Computers[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest&action=edit&section=T-5)]

A search memory stick without warrant upon arrest for credit card fraud has been found to violate s. 8.[1]

  1. ↑ R. v. Tuduce, [2011 ONSC 2749](http://canlii.ca/en/on/onsc/doc/2011/2011onsc2749/2011onsc2749.html)

## Cell phones[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest&action=edit&section=T-6)]

The law regarding the warrantless search of cell phone is a developing issue.

A warrantless search of a cell phone incidental to arrest has been held valid where it is for a valid purpose related to the offence.[1] For example, a cursory search of a cell phone incidental to arrest was lawful where it was used to determine identity and whether the phone was stolen.[2]

The search has to be somehow connected to he investigation. A search of a cell phone during an arrest for curfew breach, for example, was found to be a violation of s.8.[3]

## Other Scenarios[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Arrest&action=edit&section=T-7)]

Where the police seize a vehicle for the purpose of removing it from the road, there is a lessened expectation of privacy. Thus, any contents of the vehicle in plain view upon entering the vehicle can be seized.[4]

Police may search a vehicle to determine whether there are weapons found in the vehicle.[5]

A request by a police officer for a driver's licence and insurance is not a search.[6]

  1. ↑ R. v. Giles, [2007 BCSC 1147](http://canlii.ca/en/bc/bcsc/doc/2007/2007bcsc1147/2007bcsc1147.html)  
R. v. Lanning, [2012 ABPC 171](http://canlii.ca/t/frslr) following R v Franko, [2012 ABQB 282](http://canlii.ca/t/fr8f7)
  2. ↑ R. v. Manley, [2011 ONCA 128](http://canlii.ca/en/on/onca/doc/2011/2011onca128/2011onca128.html)
  3. ↑ R. v. Terry Hull, [2011 ONSC 3139](http://canlii.ca/en/on/onsc/doc/2011/2011onsc3139/2011onsc3139.html)
  4. ↑ R. v. Nicolisi [1998 CanLII 2006](http://canlii.ca/t/6h03) (ON C.A.)
  5. ↑ R. v. Majedi [2009 BCCA 276](http://www.canlii.org/en/bc/bcca/doc/2009/2009bcca276/2009bcca276.html) \-- incident to arrest
  6. ↑ R. v. Hufsky, [1988] 1 S.C.R. 621 at p.637 [1988 CanLII 72](http://www.canlii.org/en/ca/scc/doc/1988/1988canlii72/1988canlii72.html)

  


# Search and Seizure/Warrantless Searches/Incident to Detention[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Detention&action=edit&section=T-1)]

    _See [Investigative Detention](/wiki/Canadian_Criminal_Procedure_and_Practice/Arrest_and_Detention/Investigative_Detention) for further details_

There is a common law power to search incident to detention where "the officer … believe[s] on reasonable grounds that his or her own safety, or the safety of others, is at risk."[1] If the search goes beyond the purpose of officer safety and becomes investigative then a lawful search can become unlawful.[2]

There is no general power to search bags or vehicles incident to detention.[3]

  1. ↑ R. v. Mann [2004 SCC 52](http://canlii.org/en/ca/scc/doc/2004/2004scc52/2004scc52.html), [2004] 3 S.C.R. 59 at para. 40  
See also R. v. Clayton, [2007] 2 S.C.R. 725 [2007 SCC 32](http://canlii.org/en/ca/scc/doc/2007/2007scc32/2007scc32.html)
  2. ↑ R. v. Calderon, [2004 CanLII 7569 (ON C.A.)](http://www.canlii.org/en/on/onca/doc/2004/2004canlii7569/2004canlii7569.html)  
R. v. Logan, [2005 ABQB 321](http://www.canlii.org/en/ab/abqb/doc/2005/2005abqb321/2005abqb321.html)  
R. v. Byfield, [2005 CanLII 1486 (ON C.A.)](http://www.canlii.org/en/on/onca/doc/2005/2005canlii1486/2005canlii1486.html)  
R. v. Cooper, [2005 NSCA 47](http://www.canlii.org/en/ns/nsca/doc/2005/2005nsca47/2005nsca47.html)  

  3. ↑ R. v. Plummer, [2011 ONCA 350](http://www.canlii.org/en/on/onca/doc/2011/2011onca350/2011onca350.html)

## Vehicle Searches[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Detention&action=edit&section=T-2)]

A warrantless search of a vehicle may be reasonable where there are reasonable grounds to believe the vehicle contained illegal items.[1] This however is limited to situations in which the vehicle could be moved "quickly" and there is a risk that the evidence may be lost if an attempt was made to get a search warrant first.[2]

In R. v. D. (I.D.), [1987 CanLII 206 (SK C.A.)](http://www.canlii.org/en/sk/skca/doc/1987/1987canlii206/1987canlii206.html), the Court suggested the following requirements for a warrantless search:

  1. that the vehicle be stopped or the occupants be detained lawfully;
  2. that the officer conducting the search have reasonable and probable grounds to believe that an offence has been, is being or is about to be committed and that a search will disclose evidence relevant to that offence;
  3. that exigent circumstances, such as imminent loss, removal or destruction of the evidence, make it not feasible to obtain a warrant;
  4. that the scope of the search itself bear a reasonable relationship to the offence suspected and the evidence sought.

  1. ↑ R. v. McComber, (1988), 44 C.C.C. (3d) 241 (Ont. C.A.);  
Johnson v. Ontario (Minister of Revenue), (1990), 75 O.R. (2d) 558 (Ont. C.A.).  
See also R. v. Ruiz, [1991 CanLII 2410 (NB C.A.)](http://www.canlii.org/en/nb/nbca/doc/1991/1991canlii2410/1991canlii2410.html) ;  
R. v. McKarris, [1996] 2 S.C.R. 287 [1996 CanLII 205](http://www.canlii.org/en/ca/scc/doc/1996/1996canlii205/1996canlii205.html) ;  
R. v. Damianakos Regina v. Klimchuk, [1991 CanLII 3958 (BC C.A.)](http://www.canlii.org/en/bc/bcca/doc/1991/1991canlii3958/1991canlii3958.html) ;  
R. v. Lee, [1995 CanLII 1135 (BC C.A.)](http://www.canlii.org/en/bc/bcca/doc/1995/1995canlii1135/1995canlii1135.html)  
R. v. Caslake, [1998] 1 S.C.R. 51 [[11]](http://www.canlii.org/en/ca/scc/doc/1998/1998canlii838/1998canlii838.html) ;  
R. v. Nicolosi, [1998 CanLII 2006 (ON C.A.)](http://www.canlii.org/en/on/onca/doc/1998/1998canlii2006/1998canlii2006.html)  

  2. ↑ R. v. Klimchuk (1991), 67 C.C.C. (3d) 385 (B.C.C.A.); see also R. v. Rao (1984), 12 C.C.C. (3d) 97 (Ont. C.A.);R. v. Debot, (1986), 30 C.C.C. (3d) 207 (Ont. C.A.)[1986 CanLII 113](http://canlii.org/en/on/onca/doc/1986/1986canlii113/1986canlii113.html)

## Roadside Stops[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Incident_to_Detention&action=edit&section=T-3)]

Even if the police have lawful grounds to stop a vehicle this does not allow a search of the vehicle unless there are "reasonable grounds".[1]

Check stop programs aimed to check for sobriety, licences, ownership, insurance and the mechanical fitness of cars cannot be used by the police to search beyond its aims.[2] However, roadblocks set-up to search vehicles in order to catch suspects fleeing an armed robbery was considered a lawful search given the existence of a basis for investigative detention and the relative seriousness of the offence.[3]

Several provincial acts permit searching of vehicles without a warrant:

Section 107 of Alberta’s Gaming and Liquor Act, RSA 2000, c G-1 permits search where there is reasonable probable grounds are established that the act has been violated.

  1. ↑ R. c. Higgins, [1996 CanLII 5774 (QC C.A.)](http://www.canlii.org/fr/qc/qcca/doc/1996/1996canlii5774/1996canlii5774.html)
  2. ↑ R. v. Mellenthin, [1992 CanLII 50](http://canlii.ca/t/1fs79) (S.C.C.), [1992] 3 S.C.R. 615.
  3. ↑ R. v. Stephens, [1993] B.C.J. No. 3017 (B.C.S.C.); R. v. Jacques, [1996 CanLII 174](http://canlii.org/en/ca/scc/doc/1996/1996canlii174/1996canlii174.html), [1996] 3 S.C.R. 312  
R. v. Murray, 136 C.C.C. (3d) 197 (Que. C.A.)[1999 CanLII 13750](http://canlii.org/en/qc/qcca/doc/1999/1999canlii13750/1999canlii13750.html)

  


# Search and Seizure/Warrantless Searches/Plain View[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Plain_View&action=edit&section=T-1)]

A person has no reasonable expectation of privacy in what he knowingly exposes to the public or abandons in a public place.[1]

A peace officer may seize any evidence which he observes by use of one or more of his senses from a lawful vantage point.[2] If an officer is on a premises lawfully and observes items believed to be illegal, it is lawful for him to seize the items. [3]

For example, police may enter into a house on the basis of preserving property and the public peace, and if on entering they discover stolen property in the household, it may be considered evidence under the plain view doctrine. [4] Without a lawful search or lawful entrance, there can be no basis for the doctrine.[5]

There are generally three requirements for the plain view doctrine:[6]

  1. the police officer must lawfully make an initial intrusion or otherwise properly be in a position from which he can view a particular area;
  2. the officer must discover incriminating evidence inadvertently, which is to say, he may not know in advance the location of certain evidence and intend to seize it, relying on the plain view doctrine only as a pretext;
  3. it must be immediately apparent to the police that the items they observe may be evidence of a crime, contraband, or otherwise subject to seizure. These requirements having been met, when police officers lawfully engaged in an activity in a particular area perceive a suspicious object, they may seize it immediately:

Lands accessible to the public--i.e. "open fields"--do not have a reasonable expectation of privacy and so are not protected by the Charter where illegal items are found in it.[7] However, the "open fields" doctrine does not encompass all open air private properties.[8]

Observations should be made without violation of the law. Police making observations by trespassing at night is not permitted.[9]

It does not stretch so far as to include a bag found in a locker at a public bus station.[10]

Under s.489(2), where an officer is in the execution of their duties, may without a warrant, seize anything that the officer has reasonable grounds to believe is obtained by, used for, or will afford evidence towards an offence. This power is separate and apart from the common law doctrine of plain view seizure.[11]

See [Canadian Criminal Procedure and Practice/Search and Seizure/Seizure of Property](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property) for more on seizure.

  1. ↑ R. v. Tessling, [2004 SCC 67](http://canlii.org/en/ca/scc/doc/2004/2004scc67/2004scc67.html), [2004] 3 S.C.R. 432 at para. 40  
R. v. Boersma, [1994 CanLII 99](http://canlii.org/en/ca/scc/doc/1994/1994canlii99/1994canlii99.html) (S.C.C.), [1994] 2 S.C.R. 488
  2. ↑ R. v. Fitt, [1995 CanLII 4342](http://www.canlii.org/en/ns/nsca/doc/1995/1995canlii4342/1995canlii4342.html) (NS C.A.)  
R. v. Lauda, [1998] 2 S.C.R. 683, [1998 CanLII 804](http://www.canlii.org/en/ca/scc/doc/1998/1998canlii804/1998canlii804.html)  
R. v. Jackson, [2005 ABCA 430](http://www.canlii.org/en/ab/abca/doc/2005/2005abca430/2005abca430.html)
  3. ↑ The Queen v. Shea (1982), 142 D.L.R. (3d) 419 (Ont. S.C.)  
R. v. Hébert (1990), 60 C.C.C. (3d) 422 (Que. C.A.)  
R. v. Grenier (1991), 65 C.C.C. (3d) 76 (Que. C.A.)
  4. ↑ R. v. Dreysko (1990), 110 A.R. 317 (Alta. C.A.)  
R. v. Hern (1994), 149 A.R. 75 (Alta. C.A.)
  5. ↑ R. v. Nielsen [1988 CanLII 213](http://canlii.org/en/sk/skca/doc/1988/1988canlii213/1988canlii213.html), 43 C.C.C. (3d) 548 (Sask. C.A.)
  6. ↑ R. v. Ruiz [1991 CanLII 2410](http://canlii.org/en/nb/nbca/doc/1991/1991canlii2410/1991canlii2410.html) (NB C.A.), (1991), 10 C.R. (4th) 34 (N.B.C.A.)  
R. v. Belliveau and Losier [1986 CanLII 88](http://www.canlii.org/en/nb/nbca/doc/1986/1986canlii88/1986canlii88.html) (NB C.A.), (1986), 75 N.B.R.(2d) 18  
R. v. Jones, [2011 ONCA 632](http://canlii.ca/t/fncds) (CanLII) at para. 54 - describes 4 requirements
  7. ↑ R. v. Boersma, [1994 CanLII 99](http://canlii.org/en/ca/scc/doc/1994/1994canlii99/1994canlii99.html) (S.C.C.)  
R. v. Patriquen [1994 CanLII 3963](http://canlii.ca/t/1mqbn), (1994), 36 C.R. (4th) 363 (N.S.C.A.); appeal dismissed on other grounds, 1995 CanLII 77, [1995] 4 S.C.R. 42
  8. ↑ R. v. Kelly, [1999 CanLII 13120](http://canlii.org/en/nb/nbca/doc/1999/1999canlii13120/1999canlii13120.html) (NB C.A.)
  9. ↑ R. v. Hok 2005 BCCA 132
  10. ↑ R. v. Buhay, [2003 SCC 30](http://canlii.ca/t/1g6p7)
  11. ↑ R v Makhmudov, 2007 ABCA 248 at para. 19

## Technological Detection[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Plain_View&action=edit&section=T-2)]

### FLIR[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Plain_View&action=edit&section=T-3)]

The use of thermal imaging known as Forward Looking Infared Radar (FLIR) is not a form of search. The heat radiating from the house provides limited information about what is going on inside and virtually no information about the person core biographical information. The emanations exist on the outside of the house and so are exposed to the public.[1]

  1. ↑ see R. v. Tessling, [2004 SCC 67](http://canlii.ca/t/1j0wb), [2004] 3 SCR 432

### Sniffer Dogs[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Plain_View&action=edit&section=T-4)]

The use of a sniffer dog amounts to a "search" in law. The use of the sniffer dog is almost exclusively in the realm of drug investigations.

For a sniffer dog search to be valid, the court must ask itself:[1]

  1. did the officer subjectively believe that there were reasonable grounds to suspect that the accused was in possession of the drugs?
  2. were there sufficient grounds to reasonably suspect the accused was in possession of drugs?

Reasonable suspicion in this circumstances requires an "expectation" that the accused is "possibly engaged in some criminal activity. As well, the suspicion must be supported by facts that can be subject to review.

As part of the determination of reasonable suspicion it includes the presence of a "masking agent" such as perfumes, colognes or other odour producing products. [2]

See also: R v Navales [2011 ABQB 404](http://canlii.ca/t/fm392); R v Loewen [2010 ABCA 255](http://canlii.ca/t/2cfs8); R v Calderon 2004 ONCA 7569.

  1. ↑ R v Kang-Brown [2008 SCC 18](http://canlii.ca/t/1wnbc)
  2. ↑ R v Nguyen 2012 ABQB 199 at 97

# III - Warrant Searches[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit&section=4)]

## Introduction[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-1)]

A Search Warrant is an Order issued by a Justice of the Peace under statute that authorizes a person to enter into a location and seize specified evidence that is relevant and material to an offence.[1] The warrant is a substitute for consent to enter a private premises or any other places with reasonable expectations of privacy.[2]

The criminal code provides for several types of search warrants:

  * General Search Warrant ( [s. 487](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec487))[3]
  * Firearms warrant ( [s.117.04](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec117))
  * Obscene materials (s. 164)
  * Consent wiretap (s. 184.2)
  * Wiretap (s. 186)
  * Impaired Driving Blood Samples ([s.256](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec256))

  * Proceeds of Crime (s. 462.32)
  * DNA Sample ( [s. 487.05](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec487))
  * Tracking (s.492.1)
  * Number recordings (s. 492.2)
  * Telephone records ( [s. 492.2(2)](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec492))
  * Bodily impressions (s. 487.091)

  * Drug offences (s. 11 CDSA)
  * Telewarrants ( 487.1)
  * Explosives Warrant (492)
  * Entry for Arrest (529, 529.1)
  * Production Order (.s 487.011-013)

There are other search and seizure powers found under a variety of other federal Acts that are not directly criminal in nature.[4]

  1. ↑ Nova Scotia v. MacIntyre, [1982] 1 S.C.R. 175 at p.179[1982 CanLII 14](http://www.canlii.org/en/ca/scc/doc/1982/1982canlii14/1982canlii14.html)
  2. ↑ R. v. Pugliese (1992), 71 CCC 295 (Ont.CA)[1992 CanLII 2781](http://www.canlii.org/en/on/onca/doc/1992/1992canlii2781/1992canlii2781.html)
  3. ↑ R. v. Multiform Manufacturing Co, , [1990] 2 S.C.R. 624 [1990 CanLII 79](http://www.canlii.org/en/ca/scc/doc/1990/1990canlii79/1990canlii79.html); R. v. Grant [1993] 3 S.C.R. 223 [1993 CanLII 68](http://www.canlii.org/en/ca/scc/doc/1993/1993canlii68/1993canlii68.html);
  4. ↑ See Income Tax Act, Excise Act, Bankruptcy and Insolvency Act, Fisheries Act

## Purpose of a warrant[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-2)]

The purpose of a search warrant is to allow investigators to "locate, examine and preserve all the evidence relevant to events which may have given rise to criminal liability."[1]

A search warrant can be used not only for collecting evidence supporting a criminal charge but also as an investigative tool for alleged criminal activity.[2]

The items sought need not necessarily afford evidence of the actual commission of the offence under investigation. Rather it "must be something either taken by itself or in relation to other things, that could be reasonably believed to be evidence of the commission of the crime." [3]

  
A search warrant makes valid act which would otherwise be considered trespass.[4]

  1. ↑ R. v. Vu, 2011 BCCA 536 at para. 30 citing CanadianOxy Chemicals Ltd. v. Canada (Attorney General), 1999 CanLII 680 (SCC), [1999] 1 S.C.R. 743 at 20-22
  2. ↑ Descôteaux v. Mierzwinski, [1982 CanLII 22](http://canlii.ca/t/1lpc6) (SCC), [1982] 1 S.C.R. 860 at 891 and R. v. Vu [2011 BCCA 536](http://canlii.ca/t/fpfws) at [para 29](http://canlii.ca/t/fpfws#par29)
  3. ↑ R v Vu at para. 31 citing R. v. Canadian Broadcasting Corp. reflex, (1992), 77 C.C.C. (3d) 341 at 351 (Ont. Ct. (G.D.))
  4. ↑ R. v. Pugliese, 1992 CanLII 2781 (ON CA), <<http://canlii.ca/t/1npnm>> ("entry upon private lands by officials of the state was a trespass unless there was a lawful authorization for the entry.")

## Procedure for Obtaining a Warrant[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-3)]

An application for a search warrant consists of an "Information to Obtain" (ITO) and usually a draft warrant that presented to a justice of the peace or judge. An ITO consists of a statement under oath or an affidavit of an informant detailing the facts known (both first hand or second hand) that would provide basis to issue a warrant.[1]

An application for a warrant is an _ex parte_ motion and as such must "make full, fair and frank disclosure of all material facts".[2]

  1. ↑ R. v. Debot (1986) 30 CCC 207 (Ont.CA)  
R. v. Richard (1996) 150 NSR 232 (NSCA)
  2. ↑ R. v. Araujo, 2000 SCC 65 (CanLII), 2000 SCC 65, [2000] 2 S.C.R. 992, at para. 46

## Issuing of Warrant: Reasonable and Probable Grounds[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-4)]

The Charter requires that for all warrants police must provide "reasonable and probable grounds, established upon oath, to believe that an offence has been committed and that there is evidence to be found at the place of the search"[1] These requirements set out the "minimum standard, consistent with s. 8 of the Charter, for authorizing search and seizure"[2]

In more recent times the standard is called "reasonable grounds to believe". [3]

The standard of reasonable grounds to believe is greater than mere suspicion but less than on a balance of probabilities when the totality of the circumstances are considered.[4] It is a standard of reasonable probability and is credibility based. It must be more than mere possiblity or suspicion.[5] It is a standard of "credibly-based probability" [6]

The key elements to credibility-based probability includes:[7]

  1. The Information to obtain the warrant must set out sworn evidence sufficient to establish reasonable grounds for believing that an offence has been committed, that the things to be searched for will afford evidence and that the things in question will be found at a specked place[8]
  2. The Information to obtain as a whole must be considered and peace officers, who generally will prepare these documents without legal assistance, should not be held to the “specificity and legal precision expected of pleadings at the trial stage.”[9]
  3. The affiant’s reasonable belief does not have to be based on personal knowledge, but the Information to obtain must, in the totality of circumstances, disclose a substantial basis for the existence of the affiant’s belief: R. v. Yorke 1992 CanLII 2521 (NS CA), (1992), 115 N.S.R. (2d) 426 (C.A.); affd 1993 CanLII 83 (SCC), [1993] 3 S.C.R. 647.

The court may consider the experience of a police officer when assessing whether the officer's subjective belief was objectively reasonable.[10]

The Justice of the Peace may draw reasonable inferences from the information found in the ITO.[11]

The approving justice must be satisfied that there is a connection between the grounds for belief of the offence and that evidence of or information related to the offence will be found on the premises to be searched.[12]

The Information to Obtain the search warrant (ITO) does not need to state every step a police officer takes in obtaining information.[13]

An ITO can be read in a practical, non-technical, common-sense fashion.[14]

The officer’s are not held to the same drafting quality as counsel.[15]

The document should be reliable, balanced and material. It should also be clear, concise, legally and factually sufficient, but it need not include “every minute detail of the police investigation”. [16]

The ITO cannot be based on any information that was learned through an warrantless search of an agent of the state.

Where the basis of the warrant relies on a confidential informer, the requirement from R v Debot must be considered.[17] Generally, the requirement will increase "the level of verification required" where "credibility cannot be assessed", "fewer details are provided", and "the risk of innocent coincidence is greater". [18]

Generally, an approving justice should be satified that:[19]

  1. that the items specified exist;
  2. that the items specified will be found in the place to be searched at the time of the search;
  3. that the offence alleged has been, or will be, (depending on the type of search warrant being sought) committed;
  4. that the items specified will afford evidence of the offence alleged; and
  5. that the place to be searched is the location where the items will be located.

The document should be reliable, balanced and material. It should also be clear, concise, legally and factually sufficient, but it need nto include “every minute detail of the police investigation” [20]

  1. ↑ Hunter v. Southam Inc., 1984 CanLII 33 (SCC), 1984 CanLII 33 (SCC), [1984] 2 S.C.R. 145, at p. 168  
See also R. v. Vella (1984) 14 CCC 513  
R. v. Harris, [1987 CanLII 181 (ON CA)](http://www.canlii.org/en/on/onca/doc/1987/1987canlii181/1987canlii181.html)  

  2. ↑ Hunter v Southam at p. 168
  3. ↑ Mugesera v. Canada (Minister of Citizenship and Immigration), 2005 SCC 40[[12]](http://www.canlii.org/en/ca/scc/doc/2005/2005scc40/2005scc40.html#para114) at para. 114
  4. ↑ ibid.; R. v. Le [2006 BCCA 298](http://www.canlii.org/en/bc/bcca/doc/2006/2006bcca298/2006bcca298.html); [2006 BCCA 463](http://www.canlii.org/en/bc/bcca/doc/2006/2006bcca463/2006bcca463.html)
  5. ↑ Hunter et al v. Southam Inc., 1984 CanLII 33 (SCC), [1984] 2 S.C.R. 145  
Baron v. Canada, 1993 CanLII 154 (SCC), [1993] 1 S.C.R. 416)  

  6. ↑ R. v. Hosie [1996] O.J. No. 2175 (ONCA) at para. 11; Hunter v. Southam Inc., 1984 CanLII 33 (SCC), [1984] 2 S.C.R. 145 at p. 167
  7. ↑ R. v. Morris 1998 CanLII 1344 (NS CA), (1998), 173 N.S.R. (2d) 1 (C.A.) at para. 31
  8. ↑ R. v. Sanchez 1994 CanLII 5271 (ON SC), (1994), 93 C.C.C. (3d) 357 (Ont. Ct. Gen. Div.) at 365
  9. ↑ Sanchez, supra, at 364
  10. ↑ R v. MacKenzie 2011 SKCA 64 at para. 27, see also R v. Navales 2011 ABQB 404  
R. v. Sanchez (1994), 93 C.C.C. (3d) 537 (Ont.Gen. Div.)
  11. ↑ See R. v. Durling, 2006 NSCA 124 (CanLII) at paras. 27-28; R. v. Vu at para. 40
  12. ↑ R. v. Turcotte 1987 CanLII 984 (SK CA), (1987), 39 C.C.C. (3d) 193 (Sask.C.A)
  13. ↑ R. v. Sanchez, [1994] OJ No. 2260 at para. 20
  14. ↑ R. v. Whitaker, 2008 BCCA 174 at 41-42
  15. ↑ Re Lubell and the Queen (1973), 11 C.C.C. (2d) 188 (Ont. H.C.), at p.190;  
R. v. Durling 2006 NSCA 124 , (2006), 214 C.C.C. (3d) 49 (N.S.C.A.), at para. 19;  
R. v. Sanchez 1994 CanLII 5271 (ON SC), (1994), 93 C.C.C. (3d) 357 (Ont. Ct. Gen. Div.), at p. 364;  
Re Chapman and the Queen, (1983), 6 C.C.C. (3d) 296 (Ont. H.C.), at p. 297.  

  16. ↑ C.B.C. v. A.-G. for New Brunswick 1991 CanLII 50 (SCC), (1991), 67 C.C.C. (3d) 544 (S.C.C.), at p. 562  
R. v. Araujo [2000 SCC 65](http://canlii.ca/t/5231), (2000), 149 C.C.C. (3d) 449 (S.C.C.), at p. 470;  
R. v. Ling [2009 BCCA 70](http://canlii.ca/t/22jfr), (2009), 241 C.C.C. (3d) 409 (B.C.C.A.), at para. 43 (leave to appeal refused, [2009] S.C.C.A. No. 165)  

  17. ↑ R. v. Hosie [1996] O.J. No. 2175 (ONCA) at para. 12  
See R. v. Debot 1989 CanLII 13 (SCC), 1989 CanLII 13 (SCC), (1989), 52 C.C.C. (3d) 193 at page 215 (S.C.C.)
  18. ↑ R v Debot, at page 218
  19. ↑ R v Adams [2004 CanLII 12093](http://canlii.ca/t/1grg4) (NL PC) at para. 24
  20. ↑ C.B.C. v. A.-G. for New Brunswick 1991 CanLII 50 (SCC), (1991), 67 C.C.C. (3d) 544 (S.C.C.), at p. 562  
R. v. Araujo 2000 SCC 65 (CanLII), (2000), 149 C.C.C. (3d) 449 (S.C.C.), at p. 470  
R. v. Ling 2009 BCCA 70 (CanLII), (2009), 241 C.C.C. (3d) 409 (B.C.C.A.), at para. 43 (leave to appeal refused, [2009] S.C.C.A. No. 165)

## Standard of Review: The Garofoli Application[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-5)]

A "Garofoli Application" refers to the defence motion to exclude evidence collected under a search warrant.

Before a party can make such an application, they must have standing, which requires that there be an established [Reasonable Expectation of Privacy](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Reasonable_Expectation_of_Privacy).

**Presumptions and Burdens**  
A warrant is presumed valid. The applicant bears the burden to establish that there was insufficient basis for issuing the warrant. [1] This presumption applies not only to the warrant but the ITO as well.[2]

**Degree of Deference**  
The reviewing judge is not examining police conduct with great attention to minor details or dissection. [3] Rather the judge must look at whether there is sufficient evidence for the warrant.[4]

The test on review is not whether the reviewing judge would have granted the warrant but whether there was "reliable evidence that might reasonably be believed" on which the warrant could have been issued.[5]

The reviewing judge should not "substitute his or her own view for that of the authorizing judge."[6]

A search of a private premises "is a derogation from common law rights of ownership. The necessary formalities in the execution of the warrant must, therefore, be strictly observed".[7]

**Quality of Drafting**  
Flaws are to be expected. [8]Inaccuracies or material facts not disclosed does not necessarily detract from the existence of statutory preconditions.[9]

Errors in the information, "whether advertent or even fraudulent, are only factors to be considered in deciding to set aside the authorization and do not by themselves lead to automatic vitiation of the ... authorization."[10]

The ITO is examined on the the whole, and not piecemeal. [11]

**Exercised Portions of ITO**  
Inaccurate or omitted information in an ITO does not necessarily render it invalid.

Inaccurate information can be excised from the ITO, and re-evaluated without the offending information.[12]

**Amplification Evidence**  
Where information was omitted from an ITO or where information has been excised for other reasons, it is possible to remedy it by adducing amplification evidence.

This form of evidence can be adduced to correct innocent, minor or technical errors.

  1. ↑ R. v. Campbell, [2010 ONCA 558](http://canlii.ca/t/2c4pf), at para. 45. (aff’d, 2011 SCC 32)  
R v Shier, [1998] OJ No 5751 at para. 48  
Quebec (Attorney General) v. Laroche, [2002 SCC 72](http://canlii.ca/t/50d5) (CanLII), [2002] 3 S.C.R. 708  

  2. ↑ R v Collins (1989) 48 CCC (3d) 343 at p. 356
  3. ↑ R. v. Grant [1999 CanLII 3694](http://canlii.ca/t/1f973) (ON CA), (1999), 132 C.C.C. (3d) 531 (Ont. C.A.) at 543 (leave to appeal refused [1999] S.C.C.A. No. 168 (Q.L.), 150 C.C.C. (3d) vi); R. v. Chan, [1998] O.J. No. 4536 (Q.L.) at para. 4, 40 W.C.B. (2d) 143 (C.A.)  
R. v. Melenchuk and Rahemtulla, [1993] B.C.J. No. 558 at para. 15-18  
Simonyi Gindele et al. v. British Columbia (Attorney General) (1991), 2 B.C.A.C. 73 (C.A.) at 79.
  4. ↑ R. v. Nguyen, 2011 ONCA 465 at 57
  5. ↑ R. v. Araujo, [2000 SCC 65](http://canlii.ca/t/5231) (CanLII), [2000] 2 SCR 992 at para. 54  
See also R. v. Witaker [2008 BCCA 174](http://canlii.ca/t/1wqgl)  
R. v. Garofoli, [1990 CanLII 52](http://canlii.ca/t/1fss5) (SCC), [1990] 2 SCR 1421 at para. 56  
R. v. Grant, [1993 CanLII 68](http://canlii.ca/t/1fs0r) (SCC), [1993] 3 SCR 223 at para. 49  
R v. Veinot (1995), 144 N.S.R. (2d) 388 (C.A.) at p. 391, [1995 CanLII 4262](http://www.canlii.org/en/ns/nsca/doc/1995/1995canlii4262/1995canlii4262.html)  
R v Morelli, [2010 SCC 8](http://canlii.ca/t/28mrg) at para. 40  

  6. ↑ R v Garofoli 1990 CanLII 52 (SCC)
  7. ↑ R. v. B.(J.E.), (1989), 52 C.C.C. (3d) 224 (N.S.C.A.)
  8. ↑ Nguyen, at 58
  9. ↑ R v Pires [2005 SCC 66 at 30](http://canlii.ca/t/1m021#par30)
  10. ↑ R. v. Bisson, [1994 CanLII 46](http://canlii.ca/t/1frp6) (S.C.C.), [1994] 3 S.C.R. 1097; (1995), 94 C.C.C. (3d) 94 at p. 1098
  11. ↑ R. v. Whitaker, [2008 BCCA 174](http://canlii.ca/t/1wqgl)  
R. v. Brachi, 2005 BCCA 461  
Re Church of Scientology & the Queen (No. 6) 1987 CanLII 122 (ON CA), (1987), 31 C.C.C. (3d) 449 (Ont. C.A.))  

  12. ↑ See R v Bisson [1994 CanLII 46](http://canlii.ca/t/1frp6) (SCC), [1994] 3 SCR 1097, (1994) 94 CCC (3d) 94 at pp. 95-96  
R. v. Budd, [2000 CanLII 17014](http://canlii.ca/t/1fbj8) (ON CA) at para. 20-23  
R. v. Agensys International Inc., [2004 CanLII 17920](http://canlii.ca/t/1hd0h) (ON CA) at para. 32  


## Contents of an ITO[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-6)]

### Basic elements[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-7)]

It was suggested by Justice Hill in R. v. Chhan, [1996 CanLII 7025 (SK QB)](http://canlii.ca/t/1nsh1) that there are five basic questions that all ITO's must address at a minimum:

  1. What are the grounds for believing the things to be searched for exist?
  2. What are the grounds for saying that the things to be searched for are at the place to be searched?
  3. What are the grounds for saying the offence has been committed as described?
  4. How will the things to be searched for afford evidence of the commission of the offence alleged?
  5. What are the grounds for saying that the place to be searched is at the location identified?

It has also been suggested the justice must be satisfied:[1]

  1. that an offence has been committed or is suspected of being committed;
  2. that the location of the search is a building, receptacle or place;
  3. that the item sought will provide evidence of the commission of the offence or that the possession thereof is an offence of itself;
  4. that the grounds stated are current so as to lead credence to the reasonable and probable grounds;
  5. that there is a nexus between the various considerations set out.

A search warrant must specify the premises that is to be searched.[2]

The ITO must specify a particular offence that is being investigated.[3] As well, it must not simply include "conclusory" statements but rather the factual grounds for the conclusions.[4]

An unsigned affidavit supporting a wiretap warrant is not necessarily fatal to the appliation.[5]

  1. ↑ R. v. Turcotte, [1987 CanLII 984](http://canlii.ca/t/1prwx)(SK CA) at p. 14
  2. ↑ s. 487(1)[[13]](http://canlii.ca/t/7vf2#sec487)  
R v McGregor 1985 23 CCC 266 (QB)
  3. ↑ R. v. Dombrowski (1985) 18 CCC 164
  4. ↑ R. v. Stockton Financial Services Co. (1990) 60 CCC 527 (Man CA); R. v. Harris (1987) 35 CCC 1 (Ont.CA)
  5. ↑ R. v. Dixon, 2012 ONSC 181

### Drafting Practices[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-8)]

A properly drafted warrant, as a best practice, should generally involve the following elements:

  1. identify the _type_ of warrant sought as well as relevant sections.
  2. the judicial authority the request is made to (JP, Superior Court Justice, Provincial Court Judge)
  3. detail the identity of the affiant 
    1. name, title, rank, length of employment,
    2. working group, mandate, my role in ground, type of offences investigated
    3. personal relevant experence
  4. sources of information 
    1. databases relied upon
    2. personal sources (name, age, residence, criminal record)
  5. persons of interest (name, age, residences, charges, criminal record)
  6. property at issue: (if forfeiture or seizure) 
    1. describe it (location, size, who is in possession of item, all information on ownership/owners)
    2. avoid over-breadth, vagueness
  7. location to be searched 
    1. address, region, description of location
  8. summary of investigation
  9. previous applications
  10. reasons for any special requests (telewarrant, night-time search)
  11. conclusion / requested order

Tips for contents:

  * make the source of information clear for each statement of fact
  * if any evidence was obtained unconstitutionally, indicate what amount if any that evidence formed the basis of the warrant
  * make sure to sign the document

### Full, Frank and Fair Disclosure[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-9)]

The affiant must make "full, frank and fair" disclosure of all information known to the officer relevant to the matter before the authorizing justice.[1] This obligation arises due to the _ex parte_ nature of the application.[2]

This does not require disclosing every fact that might possibly be relevant.[3]

  1. ↑ R. v. Moore [1993 CanLII 17](http://canlii.ca/t/1d9w9) (BC CA), (1993), 81 C.C.C. (3d) 161 (B.C.C.A.) aff'd on appeal  
R. v. Kensington Income Tax, [1917] 1 K.B. 486 (C.A.)  
Church of Scientology and The Queen (No. 6), Re, [1987 CanLII 122](http://canlii.ca/t/1npn2) (ON CA)  
United States of America v. Friedland, [1996] O.J. No. 4399 (Gen.Div.), at paras. 26-29  

  2. ↑ Araujo at para. 46-47  

  3. ↑ R. v. Chambers [1983 CanLII 245](http://canlii.ca/t/23m18) (BC CA), (1983), 9 C.C.C. (3d) 132 (B.C.C.A.) at p. 143 aff'd 1986 CanLII 22 (SCC), (1986), 26 C.C.C. (3d) 353 (S.C.C.)  
R. v. Concepcion (1994), 48 B.C.A.C. 44 (B.C.C.A)  


### Procedure[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-10)]

A judge or justice of the peace rejecting a search warrant application can provide the applicant with a list of errors or omissions that make the warrant deficient without losing their responsibility as a neutral arbiter.[1]

  1. ↑ R. v. Truong, 2012 ABQB 182

### Description of the Place to be Searched[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-11)]

A warrant of a premises must accurately describe the location to be searched. If it fails to do so the warrant will be invalid.[1]

The sufficiency of the description of the place must be assessed based on the face of the warrant, separately from the contents of the ITO or the manner it was executed.[2] Failure to name a place on the warrant "is not a mere matter of procedural defect, but so fundamental as to render the document of no legal effect."[3]

  1. ↑ Re McAvoy (1970) 12 C.R.N.S. 56 (NWTSC) at para. 57 ("To avoid search warrants becoming an instrument of abuse it has long been understood that if a search warrant ... fails to accurately describe the premises to be searched ... then it will be invalid")
  2. ↑ R. v. Parent, [1989 CanLII 217](http://canlii.ca/t/1p1h5) (YK CA) - no address whatsoever on warrant, but address present in ITO
  3. ↑ Parent

#### Error in Addresses[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-12)]

If the address in the warrant is wrong, the search becomes warrantless.[1]

For a search of an apartment building, the warrant must specify the unit number.[2]

A warrant is still valid where the address is wrong or vague in one section of the ITO but valid in another section.[3]

Where the ITO is inconsistent with the warrant some level of error is permissible as long as the location remains sufficient clear.[4]

  1. ↑ see R. v. Krammer, [2001 BCSC 1205](http://canlii.ca/t/4wxn) (CanLII), [2001] B.C.J. No. 2869 (S.C.)  
R. v. Silvestrone [1991 CanLII 5759](http://canlii.ca/t/23276) (BC CA), (1991), 66 C.C.C. (3d) 125 (B.C.C.A.), at pp. 130-132
  2. ↑ R. v. Wisdom, [2012 ONCJ 54](http://canlii.ca/t/fpvkb) (CanLII) at para. 44 ("The warrant fails to specifically authorize a search of apartment 303 which is where the applicants resided")  

  3. ↑ R. v. Sexton, [2011 NBCA 97](http://canlii.ca/t/fnl3l) (CanLII) at paras 4-9
  4. ↑ R. v. Parker, [2006 NBPC 38](http://canlii.ca/t/1q6fs) (CanLII) - address on warrant varied from address in ITO. ITO address was correct. Warrant found valid.  
R. v. Jacobson, [2009 ONCA 130](http://canlii.ca/t/22fnp) (CanLII) - correct address in ITO, error in warrant address. Warrant valid to search car only, lower expectation of privacy in car  


### Description of Thing(s) to be Seized[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-13)]

The warrant's description of things to be seized "operates as a guide for the officers conducting the search."[1]

The justice of the peace loses jurisdiction where the description is over-broad or too vague such that it essentially allows the officer to conduct a "carte blanche" search for any evidence within the premises.[2]

It has been recommended the following principles be considered:[3]

  1. peace officers should be given some latitude in describing things as they are still at the investigative stage;
  2. the description may be limited to classes of documents if it is sufficiently limited to the crime for which they are alleged to afford evidence;
  3. the Information sworn to obtain the Search Warrant must be read together with the Search Warrant;
  4. the nature of the offence(s) must be considered;
  5. in considering all of the factors, appropriate inferences may be made;
  6. there need not always be a time limit set out with respect to the documents sought;
  7. overly broad or vague descriptions can be severed leaving validly described things remaining;
  8. each case must be considered on its own facts.

see also R. v. Church of Scientology, supra; Re: Lubell and The Queen (1973), 11 C.C.C. (2d) 188 (Ont. H.C.J.); R. v. Silverstar Energy Inc., [2004] B.C.J. No. 1767 (B.C.S.C.); R. v. Sanchez and Sanchez [1994 CanLII 5271](http://canlii.ca/t/1p79n) (ON SC), 1994 CanLII 5271 (ON SC), (1994), 93 C.C.C. (3d) 357 (Ont. Ct. Gen. Div.); R. v. PSI Mind Development Institute Ltd. (1977), 37 C.C.C. (2d) 263 (Ont. H.C.))

  1. ↑ R. v. Du, [2004 ABQB 849](http://canlii.ca/t/1j9ff) (CanLII) at para. 12
  2. ↑ Du at para. 12
  3. ↑ Du at para. 12

## Types of Evidence Used[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-14)]

### Statement by Accused[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-15)]

Where the ITO contains a statement from the accused, the document must also show that the accused was properly cautioned and given a right to counsel. [1]

The statement cannot be involuntary.[2]

  1. ↑ R. v. Allen, [1995 ABCA 384](http://canlii.ca/t/2dcd3) at para. 5  
R. v. Campbell, [2003 MBCA 76](http://canlii.ca/t/55zz) at para. 49-51  
R. v. Sonne, [2012 ONSC 140](http://canlii.ca/t/fqmdt) at para. 17
  2. ↑ R. v. Ye, [2011 ONSC 2278](http://canlii.ca/t/fl0wm) at para. 40  


### Criminal Records[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-16)]

A copy of the informer's criminal record should be included in the ITO except where it may tend to reveal the identity of the informer.[1]

Where the ITO states that the informer has a criminal record when in fact the informer was merely charged, it may be sufficient ot void the warrant.[2]

There is no added value in including charges that have been stayed or withdrawn. The prejudicial effect is too great. [3]

  1. ↑ R. v. Johnston, [2009 ABPC 315 at 44](http://www.canlii.org/en/ab/abpc/doc/2009/2009abpc315/2009abpc315.html#par44)]
  2. ↑ R. v. Sismey, [1990 CanLII 1483 (BC CA)](http://canlii.ca/t/1d7fr)
  3. ↑ R v Johnson [2005 BCPC 432 at 8](http://canlii.ca/t/1lsw6#par8)

### Hearsay[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-17)]

The applicant should always indicate whether they are relying on hearsay or direct knowledge.[1]

An ITO relying upon hearsay does does not exclude it from establishing "probable cause".[2]

An ITO may contain hearsay as long as it is sourced and details are given about the source so the Justice can review the source's reliability and weigh its evidentiary value. [3]

Details on the source should be used to distinguish the information from rumor or gossip.[4]

Where the hearsay source is not set out the part of the ITO may be defective.[5]

It has been recommended that where the source is the notes or reports of other officers there should be detail on how it was obtained and why it is reliable.[6] It has been considered in appropriate to paraphrase or edit the notes of the other officers in materials ways.[7]

It has been further suggested that where it is from a written statement of a witness, details of identity and their involvement should be provided.[8]

Whether the confidential informant was paid should be provided as well.[9]

Debot factors are to be applied when considering hearsay.

  1. ↑ e.g. see R. v. Nightingale, [2006 ABPC 79](http://canlii.ca/t/1mw8j) (CanLII) at para. 65 to 67 - officer failed to specify
  2. ↑ Eccles v. Bourque, [1974 CanLII 191](http://canlii.ca/t/1z1gw) (SCC), [1975] 2 SCR 739 at p. 746 ( "That this information was hearsay does not exclude it from establishing probable cause")
  3. ↑ R v. KP, [2011 NUCJ 27](http://canlii.ca/t/fn3tk) at para. 83  
see also R. v. Philpott, [2002 CanLII 25164](http://canlii.ca/t/1cc4p) (ON SC) at para. 40  
R. v. Bryan, [2008 CanLII 2595](http://canlii.ca/t/1vk9r) (ON SC) at para. 81
  4. ↑ R. v. Allain, [1998 CanLII 12250](http://canlii.ca/t/1lrj9) (NB CA) at pp. 12-13 ("As a rule, sources of hearsay information must be identified in the supporting Information. This rule is designed to enable the issuing judge to satisfy himself or herself that the information is more than rumour or gossip")
  5. ↑ R. v. Bui and Do, [2005 BCPC 210](http://canlii.ca/t/1kwsn) (CanLII) at para. 57
  6. ↑ Bui and Do at para. 57
  7. ↑ R. v. Liang, Yeung, Zhu, Zhai, Wen, Zhou, Jiang, Cheung and Xu, [2007 YKTC 18](http://canlii.ca/t/1r3nj) (CanLII)
  8. ↑ ibid.
  9. ↑ Buid and Do at para. 57

### Expert Evidence[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-18)]

For expert evidence to be used in an ITO, it must contain details on the expert's qualifications and experience as well as show the methods the expert used to come to their conclusion.[1]

  1. ↑ Criminal Code s. 487.01, Application of General Warrant, [2002 SKPC 11](http://canlii.ca/t/5j96)  
R. v. Morelli, [2008 SKCA 62](http://canlii.ca/t/1x08k) at para. 122  
R. v. Agensys International Inc. 2004 CanLII 17920 (ON CA), (2004), 187 C.C.C. (3d) 481 at para. 44  


## Frequent Errors[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-19)]

### Omissions, mischaracterizations, Material Non Disclosure[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-20)]

It is improper for the warrant to contain incomplete, misleading or misrepresented information on the investigation.

This can occur where the affiant is deliberately kept out of the investigation and only given favourable information to support the warrant. [1]

The warrant will typically be invalid if the misstatement or omission was deliberate or a finding of bad faith. [2] The quashing is necessary to avoid corruption of the process.[3]

However, where the justice "could have" granted the warrant regardless of the deception, it may still be valid.[4]

However, at times a poorly drafted and misleading warrant will, on its own, invalidate the warrant.[5]

  


  1. ↑ e.g. R. v. Morelli at para. 58  
R. v. M(NN) 2007 CanLII 31570 (ON SC), (2007), 223 C.C.C. (3d) 417 (Ont. Sup. Ct. of Jus.) at para. 354 (“... as a straw man affiant apparently deliberately kept in the dark ...”)
  2. ↑ R. v. Melenchuk (1993), 24 B.C.A.C. 97 (BCCA)  
R. v. Donaldson 1990 CanLII 630 (BC CA), (1990), 58 C.C.C. (3d) 294 (B.C.C.A.) - police deliberated withheld information from the JP  
R. v. Sismey 1990 CanLII 1483 (BC CA), (1990), 55 C.C.C.(3d) 281 at p. 285  
R. v. Innocente 1992 CanLII 2449 (NS CA), (1992), 113 N.S.R. (2d) 256 (S.C.)  
R. v. Silvestrone 1991 CanLII 5759 (BC CA), (1991), 66 C.C.C. (3d) 125 (B.C.C.A.) at p. 136  
R. v. Brassard, (1992), 77 C.C.C. (3d) 285 (Sask.Q.B.)  
R. v. Dellapenna (1995), 62 B.C.A.C. 32 (B.C.C.A.)  
R. v. Fletcher 1994 CanLII 4169 (NS SC), (1994), 140 N.S.R. (2d) 254
  3. ↑ R. v. Maton, [2005 BCSC 330](http://canlii.ca/t/1k2jq) (CanLII) at para. 26  
R. v. Morris 1998 CanLII 1344 (NS CA), (1998), 134 C.C.C. (3d) 539 (N.S.C.A.) at para. 44
  4. ↑ R. v. Bisson 1994 CanLII 46 (SCC), (1994), 94 C.C.C. (3d) 94 (S.C.C.) upholding Proulx J.A. in 1994 CanLII 5328 (QC CA), (1994), 87 C.C.C. (3d) 440 (Que.C.A.)
  5. ↑ e.g. R. v. Norris (1993), 35 B.C.A.C. 133 (B.C.C.A.)

### Nexus between Offence Evidence and Premises[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-21)]

The informant must pledge that the items not simply "could" be found but would be found. [1]

  1. ↑ R. v. Kelly 2010 NBCA 89 at para. 39

### Overbroad Authority[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-22)]

It is essential that the warrant not be overly broad. The description of the targets of the search should not be so vague as to give the police the ability to rummage through the premises. [1]

  1. ↑ Church of Scientology and The Queen (No. 6), Re, [1987 CanLII 122](http://canlii.ca/t/1npn2) (ON CA): ("The description of what is to be searched for must not be so broad and vague as to give the searching officers carte blanche to rummage through the premises of the target. The things must be described in such a way as to guide the officer or officers carrying out the search and assist them in identifying the object.")

## Special Issues[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-23)]

### Computer Investigations[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-24)]

The connection of an IP address with an ISP account can form reasonable grounds to believe that a computer will be present at the address, but will often need something more.[1]

Where a warrant permits the police to search a residence and seize computers, the police are permitted to complete full forensic analysis on the computer without any additional warrants needed.[2]

The searching officer may draw the inference upon learning of the download of suspected child pornography that the files may remain on the computer well after download and even where efforts to delete the materials have been made.[3]

The searching officer may in some cases also rely upon their experience "of individuals who access and possess child pornography on their computers" which tells them that "often these individuals kept images for “long periods of time” and “rarely deleted collections”." [4]

  1. ↑ see R. v. Weir (2001), 156 C.C.C. (3d) 188 (ABCA): ("While it is possible that the computer may have been at a different location than the billing address, it was not unreasonable to conclude that something as sensitive as child pornography would be kept on a computer in a person’s home.")
  2. ↑ R. v. Ballendine, [2011 BCCA 221](http://canlii.ca/t/fl8xf) (CanLII)
  3. ↑ R. v. Ward, [2012 ONCA 660](http://canlii.ca/t/ft0ft) (CanLII) at para. 114"...extensive technical evidence to the effect that files downloaded by the appellant on the computer could be recovered by police technicians even if the appellant had made efforts to delete those files. This evidence offered some basis for an inference that the prohibited material remained on the computer long after it was downloaded and could be recovered if the police were given access to the computer"
  4. ↑ Ward at para. 115

### Law Offices[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-25)]

A justice of the peace should follow the following principles when considering a search of a law office os that [solicitor-client privilege](/wiki/Canadian_Criminal_Evidence/Privilege#Solicitor_Client_Privilege) is protected:[1]

  1. No search warrant can be issued with regards to documents that are known to be protected by solicitor-client privilege.
  2. Before searching a law office, the investigative authorities must satisfy the issuing justice that there exists no other reasonable alternative to the search.
  3. When allowing a law office to be searched, the issuing justice must be rigorously demanding so to afford maximum protection of solicitor-client confidentiality.
  4. Except when the warrant specifically authorizes the immediate examination, copying and seizure of an identified document, all documents in possession of a lawyer must be sealed before being examined or removed from the lawyer’s possession.
  5. Every effort must be made to contact the lawyer and the client at the time of the execution of the search warrant. Where the lawyer or the client cannot be contacted, a representative of the Bar should be allowed to oversee the sealing and seizure of documents.
  6. The investigative officer executing the warrant should report to the justice of the peace the efforts made to contact all potential privilege holders, who should then be given a reasonable opportunity to assert a claim of privilege and, if that claim is contested, to have the issue judicially decided.
  7. If notification of potential privilege holders is not possible, the lawyer who had custody of the documents seized, or another lawyer appointed either by the Law Society or by the court, should examine the documents to determine whether a claim of privilege should be asserted, and should be given a reasonable opportunity to do so.
  8. The Attorney General may make submissions on the issue of privilege, but should not be permitted to inspect the documents beforehand. The prosecuting authority can only inspect the documents if and when it is determined by a judge that the documents are not privileged.
  9. Where sealed documents are found not to be privileged, they may be used in the normal course of the investigation.
  10. Where documents are found to be privileged, they are to be returned immediately to the holder of the privilege, or to a person designated by the court.

A "law office" includes "any place where privileged documents may reasonably be expected to be located".[2]

A search warrant of law office must impose conditions to protect potential privilege "as much as possible". Without proper protections the warrant is invalid.[3]

Section 488.1 concerning search of law offices was found to be unconstitutional.[4]

  1. ↑ Lavallee, Rackel & Heintz v. Canada 2002 SCC 61 at para. 49
  2. ↑ Festing v. Canada (Attorney General), [2003 BCCA 112](http://canlii.ca/t/5d31) (CanLII) at para. 24
  3. ↑ R. v. Piersanti & Company, [2000 CanLII 17032](http://canlii.ca/t/1fbjv) (ON CA)
  4. ↑ Lavallee, Rackel & Heintz v. Canada (Attorney General); White, Ottenheimer & Baker v. Canada (Attorney General); R. v. Fink, [2002 SCC 61](http://canlii.ca/t/51rj) (CanLII), [2002] 3 SCR 209

## Sealing and Unsealing of Warrants[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-26)]

Once a warrant is executed, it and the ITO must be made available to the public unless the warrant is placed under a sealing order.[1]

Under s. 487.3(1), an application to seal a warrant and ITO can be made prohibiting disclosure of any information related to the warrant on the basis that access to it would subvert the ends of justice or the information would be put to an improper purpose.

Under s. 487.3(2), set out the basis of how the ends of justice would be subverted.

The applicant must be specific on the grounds of sealing, there must be "particularized grounds". Generalized assertions are not enough.[2]

Under s. 487.3(4), the sealing order may be varied or terminated.

  1. ↑ Toronto Star Newspaper Ltd. v Ontario, 2005 SCC 41
  2. ↑ Toronto Star v Ontario, 2005 SCC 41 at 36 to 42

### Vetting Procedure[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-27)]

Where unsealing an unvetted ITO, the court should follow the procedure set out in Garofoli:[1]

  1. Upon opening of the packet, if the Crown objects to disclosure of any of the material, an application should be made by the Crown suggesting the nature of the matters to be edited and the basis therefor. Only Crown counsel will have the affidavit at this point.
  2. The trial judge should then edit the affidavit as proposed by Crown counsel and furnish a copy as edited to counsel for the accused. Submissions should then be entertained from counsel for the accused. If the trial judge is of the view that counsel for the accused will not be able to appreciate the nature of the deletions from the submissions of Crown counsel and the edited affidavit, a form of judicial summary as to the general nature of the deletions should be provided.
  3. After hearing counsel for the accused and reply from the Crown, the trial judge should make a final determination as to editing, bearing in mind that editing is to be kept to a minimum and applying the factors listed above.
  4. After the determination has been made in (3), the packet material should be provided to the accused.
  5. If the Crown can support the authorization on the basis of the material as edited, the authorization is confirmed.
  6. If, however, the editing renders the authorization insupportable, then the Crown may apply to have the trial judge consider so much of the excised material as is necessary to support the authorization. The trial judge should accede to such a request only if satisfied that the accused is sufficiently aware of the nature of the excised material to challenge it in argument or by evidence. In this regard, a judicial summary of the excised material should be provided if it will fulfill that function. It goes without saying that if the Crown is dissatisfied with the extent of disclosure and is of the view that the public interest will be prejudiced, it can withdraw tender of the wiretap evidence.

  1. ↑ R. v. Garofoli, [1990 CanLII 52](http://canlii.ca/t/1fss5) (SCC), [1990] 2 SCR 1421

## Topics[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-28)]

  * [Execution of Warrants](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches/Execution)
  * Specific Types of Warrant 
    * [General Warrants](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/General_Warrants)
    * [Bodily Samples](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples) (including s.256, s. 487.05, s. 487.091)
    * [Wiretaps](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps)
    * [Tracking Warrant](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Tracking_Warrant) (492.1)
    * [CDSA Warrants](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/CDSA_Warrants)
    * [Foreign Warrants](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Foreign_Warrants)
    * [Telewarrants](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Telewarrants)
    * [Production Orders](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches/Production_Orders)

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrant_Searches&action=edit&section=T-29)]

  * [Case law](/wiki/Canadian_Criminal_Procedure_and_Practice/Cases/Warrant_Searches)
  * [Seizure of Property](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property)
  * [Search Warrant Chart](/wiki/Canadian_Criminal_Procedure_and_Practice/Appendix/Search_Warrant_Chart)

# Search and Seizure/Bodily Samples[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Introduction[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples&action=edit&section=T-1)]

Bodily samples cannot be taken without a warrant where the subject does not consent.[1]

There are several methods of obtaining bodily samples:

  * general warrant (s.487);
  * DNA Sample (s.487.05);
  * blood sample demand (s.254(3));
  * DRE blood sample (s.254(3.4));
  * blood sample warrant (s.256)

A bodily sample can also be obtained by consent.[2]

  1. ↑ R. v. Tomaso, (1989), 70 CR (3d) 152 (Ont. CA)
  2. ↑ See [Canadian Criminal Procedure and Practice/Search and Seizure/Warrantless Searches/Consent Search](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search)

## DNA Sample (s.487.05)[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples&action=edit&section=T-2)]

> **Information for warrant to take bodily substances for forensic DNA analysis**  
487.05 (1) A provincial court judge who on ex parte application made in Form 5.01 is satisfied by information on oath that there are reasonable grounds to believe
> 
>     (a) that a designated offence has been committed,
>     (b) that a bodily substance has been found or obtained 
> 
>     (i) at the place where the offence was committed,
>     (ii) on or within the body of the victim of the offence,
>     (iii) on anything worn or carried by the victim at the time when the offence was committed, or
>     (iv) on or within the body of any person or thing or at any place associated with the commission of the offence,
>     (c) that a person was a party to the offence, and
>     (d) that forensic DNA analysis of a bodily substance from the person will provide evidence about whether the bodily substance referred to in paragraph (b) was from that person and who is satisfied that it is in the best interests of the administration of justice to do so may issue a warrant in Form 5.02 authorizing the taking, from that person, for the purpose of forensic DNA analysis, of any number of samples of one or more bodily substances that is reasonably required for that purpose, by means of the investigative procedures described in subsection 487.06(1).
> 
> **Criteria**  
(2) In considering whether to issue the warrant, the provincial court judge shall have regard to all relevant matters, including
> 
>     (a) the nature of the designated offence and the circumstances of its commission; and
>     (b) whether there is 
> 
>     (i) a peace officer who is able, by virtue of training or experience, to take samples of bodily substances from the person, by means of the investigative procedures described in subsection 487.06(1), or
>     (ii) another person who is able, by virtue of training or experience, to take, under the direction of a peace officer, samples of bodily substances from the person, by means of those investigative procedures.
> **Telewarrant**  
(3) Where a peace officer believes that it would be impracticable to appear personally before a judge to make an application for a warrant under this section, a warrant may be issued under this section on an information submitted by telephone or other means of telecommunication and, for that purpose, section 487.1 applies, with such modifications as the circumstances require, to the warrant. 
> 
> 1995, c. 27, s. 1; 1997, c. 18, s. 44; 1998, c. 37, s. 16; 2005, c. 25, s. 2(F).
> 
> – [CCC](http://canlii.ca/t/7vf2#sec487.05)

This provision is only one of several ways to seize an item for the purpose of obtaining DNA. An item that contains a bodily substance can likewise be obtained through other means such as a warrant under s.487.[1]

This section authorizing the taking of the sample is constitutional. [2]

**Validity**  
The ITO must contain sufficient details to be valid.[3]

Basis for warrant:

  * the applicable designated offence that is being investigated (s.487.04)
  * belief that a bodily substance was found or obtained at the scene
  * belief that accused was party to the offence

The warrant must include:

  * appropriate terms and conditions of sampling (s. 487.06(2)
  * special requirements must comply with s. 487.07

**Execution of the warrant**  
The sample must be taken by a peace officer with the necessary training to take bodily samples. The peace officers are permitted to use reasonable force to extract the sample if the accused resists or refuses to submit to the taking of the sample.

**Use of DNA**  
The sample may only be used with respect to the offence under investigation.[s. 487.08]

  1. ↑ R. v. Kaba 2008 QCCA 116; R. v. Gettin ,[2003] OJ No. 4758 (Ont. CA.) R. v. Dofer ,[1996] BCJ No. 332 (BCCA).
  2. ↑ R. v. Rodgers, [2006 SCC 15](http://canlii.ca/t/1n3br), [2006] 1 SCR 554 at para. 5
  3. ↑ R. v. Brighteyes, 1998 3 WWR 276 [[14]](http://www.canlii.org/en/ab/abqb/doc/1997/1997canlii14864/1997canlii14864.html)

## Blood sample demand (s.254 (3))[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples&action=edit&section=T-3)]

> 254.
> 
> ...
> 
> **Samples of breath or blood**  
(3) If a peace officer has reasonable grounds to believe that a person is committing, or at any time within the preceding three hours has committed, an offence under section 253 as a result of the consumption of alcohol, the peace officer may, by demand made as soon as practicable, require the person
> 
>     (a) to provide, as soon as practicable, 
> 
>     (i) samples of breath that, in a qualified technician’s opinion, will enable a proper analysis to be made to determine the concentration, if any, of alcohol in the person’s blood, or
>     (ii) if the peace officer has reasonable grounds to believe that, because of their physical condition, the person may be incapable of providing a sample of breath or it would be impracticable to obtain a sample of breath, samples of blood that, in the opinion of the qualified medical practitioner or qualified technician taking the samples, will enable a proper analysis to be made to determine the concentration, if any, of alcohol in the person’s blood; and
>     (b) if necessary, to accompany the peace officer for that purpose.
> 
> ...
> 
> **Condition**  
(4) Samples of blood may be taken from a person under subsection (3) or (3.4) only by or under the direction of a qualified medical practitioner who is satisfied that taking the samples would not endanger the person’s life or health.
> 
> ... R.S., 1985, c. C-46, s. 254; R.S., 1985, c. 27 (1st Supp.), s. 36, c. 1 (4th Supp.), ss. 14, 18(F), c. 32 (4th Supp.), s. 60; 1999, c. 32, s. 2(Preamble); 2008, c. 6, s. 19.
> 
> – [CCC](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec254)

If the investigating officer has reasonable grounds to believe that the person is impaired by drugs and could be charged for operation or control of a vehicle while impaired, they may make a demand for either urine sample or blood sample. A blood sample must be done by a medical practitioner.[1] However, a urine or oral fluid sample seems to be taken by any individual.

  1. ↑ s. 254(4)

## DRE Blood sample demand (s.254 (3.4))[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples&action=edit&section=T-4)]

> s.254...  
**Samples of bodily substances**  
(3.4) If, on completion of the evaluation, the evaluating officer has reasonable grounds to believe, based on the evaluation, that the person’s ability to operate a motor vehicle, a vessel, an aircraft or railway equipment is impaired by a drug or by a combination of alcohol and a drug, the evaluating officer may, by demand made as soon as practicable, require the person to provide, as soon as practicable,
> 
>     (a) a sample of either oral fluid or urine that, in the evaluating officer’s opinion, will enable a proper analysis to be made to determine whether the person has a drug in their body; or
>     (b) samples of blood that, in the opinion of the qualified medical practitioner or qualified technician taking the samples, will enable a proper analysis to be made to determine whether the person has a drug in their body.
> 
> **Condition**  
(4) Samples of blood may be taken from a person under subsection (3) or (3.4) only by or under the direction of a qualified medical practitioner who is satisfied that taking the samples would not endanger the person’s life or health.
> 
> ... R.S., 1985, c. C-46, s. 254; R.S., 1985, c. 27 (1st Supp.), s. 36, c. 1 (4th Supp.), ss. 14, 18(F), c. 32 (4th Supp.), s. 60; 1999, c. 32, s. 2(Preamble); 2008, c. 6, s. 19.
> 
> – [CCC](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec254)

See also [Canadian_Criminal_Law/Offences/Impaired_Driving_and_Over_80/Proof_of_Impairment#Proof_of_Impairment_by_Drugs](/wiki/Canadian_Criminal_Law/Offences/Impaired_Driving_and_Over_80/Proof_of_Impairment#Proof_of_Impairment_by_Drugs)

## Blood sample warrant (s. 256)[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples&action=edit&section=T-5)]

> **Warrants to obtain blood samples**  
256\. (1) Subject to subsection (2), if a justice is satisfied, on an information on oath in Form 1 or on an information on oath submitted to the justice under section 487.1 by telephone or other means of telecommunication, that there are reasonable grounds to believe that
> 
>     (a) a person has, within the preceding four hours, committed, as a result of the consumption of alcohol or a drug, an offence under section 253 and the person was involved in an accident resulting in the death of another person or in bodily harm to himself or herself or to any other person, and
>     (b) a qualified medical practitioner is of the opinion that 
> 
>     (i) by reason of any physical or mental condition of the person that resulted from the consumption of alcohol or a drug, the accident or any other occurrence related to or resulting from the accident, the person is unable to consent to the taking of samples of his or her blood, and
>     (ii) the taking of samples of blood from the person would not endanger the life or health of the person, the justice may issue a warrant authorizing a peace officer to require a qualified medical practitioner to take, or to cause to be taken by a qualified technician under the direction of the qualified medical practitioner, the samples of the blood of the person that in the opinion of the person taking the samples are necessary to enable a proper analysis to be made in order to determine the concentration, if any, of alcohol or drugs in the person’s blood.
> 
> **Form**  
(2) A warrant issued pursuant to subsection (1) may be in Form 5 or 5.1 varied to suit the case.
> 
> **Information on oath**  
(3) Notwithstanding paragraphs 487.1(4)(b) and (c), an information on oath submitted by telephone or other means of telecommunication for the purposes of this section shall include, instead of the statements referred to in those paragraphs, a statement setting out the offence alleged to have been committed and identifying the person from whom blood samples are to be taken.
> 
> **Duration of warrant**  
(4) Samples of blood may be taken from a person pursuant to a warrant issued pursuant to subsection (1) only during such time as a qualified medical practitioner is satisfied that the conditions referred to in subparagraphs (1)(b)(i) and (ii) continue to exist in respect of that person.
> 
> **Copy or facsimile to person**  
(5) When a warrant issued under subsection (1) is executed, the peace officer shall, as soon as practicable, give a copy of it — or, in the case of a warrant issued by telephone or other means of telecommunication, a facsimile — to the person from whom the blood samples are taken.
> 
> R.S., 1985, c. C-46, s. 256; R.S., 1985, c. 27 (1st Supp.), s. 36; 1992, c. 1, s. 58; 1994, c. 44, s. 13; 2000, c. 25, s. 3; 2008, c. 6, s. 22.[CCC](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec256)

This method of obtaining a blood sample requires the following :

  1. the application be made to a JP within _4 hours_ of an offence under s. 253
  2. the offence involved bodily harm or death to the accused or another person
  3. a qualified medical practitioner is of the opinion that: 
    1. the person is unable to consent to the taking of a sample
    2. the taking of the sample would not endanger the life or health of the person

This method is not frequently seen as the requirements under s. 487 are simpler.

## Body Print Impression Warrant (487.092)[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples&action=edit&section=T-6)]

Section 487.092 was enacted on June 16, 1997 through Bill C-17.

> **Information for impression warrant**  
487.092 (1) A justice may issue a warrant in writing authorizing a peace officer to do any thing, or cause any thing to be done under the direction of the peace officer, described in the warrant in order to obtain any handprint, fingerprint, footprint, foot impression, teeth impression or other print or impression of the body or any part of the body in respect of a person if the justice is satisfied
> 
>     (a) by information on oath in writing that there are reasonable grounds to believe that an offence against this or any other Act of Parliament has been committed and that information concerning the offence will be obtained by the print or impression; and
>     (b) that it is in the best interests of the administration of justice to issue the warrant.
> 
> **Search or seizure to be reasonable**  
(2) A warrant issued under subsection (1) shall contain such terms and conditions as the justice considers advisable to ensure that any search or seizure authorized by the warrant is reasonable in the circumstances.
> 
> ...
> 
> 1997, c. 18, s. 45; 1998, c. 37, s. 23.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec487.092)

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Bodily_Samples&action=edit&section=T-7)]

  


# Search and Seizure/Wiretaps[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Generally[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-1)]

Wiretaps are governed by Part VI of the Criminal Code.

There are three categories of wiretap:

  * a general wiretap authorized under s. 185 and 186.
  * a wiretap with consent under s. 184.2
  * an emergency wiretap under s. 184.4 and 188

The consent wiretap and emergency wiretap does not require full judicial authorization.

A wilful interception of "a private communication" without authorization is a indictable offence under s. 184 with a maximum penalty of 5 years. This offence does not include situations where one of the parties consents (s.184(2)).

### Private Communication[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-2)]

Under s.183, a "private communication" refers to any "oral communication or any telecommunication, that is made by an originator thereof who is in Canada or is intended by the originator to be received by a person who is in Canada and that is made under circumstances where the originator expects that it will not be intercepted by any other person other than the person intended by the originator to receive it".

The following has been found not to be a "private communication":

  * Electronic signals captured by a digital number recorder (DNR)[1]
  * a prayer to God as God does not meet the legal definition of a person.[2]

### Interception[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-3)]

The interception must be done by way of an "electromagnetic, acoustic, mechanical or other device" (s.183). Consequently, simply to use one's human senses without technological aids does not invoke Part VI.[3]

## Grounds for Application[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-4)]

Wiretaps are investigative tools. All that is needed is a reasonble belief to grant the authorization. The fact that the belief turns out to be false is not relevant to the application.[4]

Before a Judge can grant the wiretap warrant, he must be satisifed that the applicant has "reasonable and probable grounds to believe that a specific offence has been, is being, or is about to be committed."[5] The police must also "have reasonable and probable grounds to think that the target of the authorization will in fact be at a particular place, or be communicating in a particular manner" that will give evidence towards to investigation.[6] A fishing expidition is not a proper basis to authorize the wiretap.[7]

Where defence counsel has demonstrated sufficient basis, the court can order the affiant to be subject to cross-examination on the affidavit authorizing the warrant.[8]

## Sealing of Authorization[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-5)]

## Unsealing of Authorization[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-6)]

Defence counsel may apply to the court under s. 187(1.4) to unseal to authorization. The section states:

> (1.4) A judge or provincial court judge before whom a trial is to be held and who has jurisdiction in the province in which an authorization was given may order that the sealed packet be opened and its contents removed for the purpose of copying and examining the documents contained in the packet if
> 
>     (a) any matter relevant to the authorization or any evidence obtained pursuant to the authorization is in issue in the trial; and
>     (b) the accused applies for such an order for the purpose of consulting the documents to prepare for trial.
> 
> – [[15]](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec187)

## Review of Authorization[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-7)]

The review of a wire tap is the same standard as a review of any warrant.

The test to be applied on the review of a wiretap warrant is whether there were "reasonable grounds to believe that the interception of communications may assist in the investigation of the offence.[9] It is not a question of whether there is reasonable grounds to lay changes.[10]

An affiant should be not only full and frank but also ‘clear and concise’”[11]

## Interception with Consent[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-8)]

Under 184.2, a person may intercept any private communication where one party consents to the interception.

> 184.2 (1) A person may intercept, by means of any electro-magnetic, acoustic, mechanical or other device, a private communication where either the originator of the private communication or the person intended by the originator to receive it has consented to the interception and an authorization has been obtained pursuant to subsection (3).
> 
> ...
> 
> (3) An authorization may be given under this section if the judge to whom the application is made is satisfied that
> 
>     (a) there are reasonable grounds to believe that an offence against this or any other Act of Parliament has been or will be committed;
>     (b) either the originator of the private communication or the person intended by the originator to receive it has consented to the interception; and
>     (c) there are reasonable grounds to believe that information concerning the offence referred to in paragraph (a) will be obtained through the interception sought.
> 
> – [CCC](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec184.2)

This section was added to the Code in 1993 in response to the decision of R v Duarte [1990] 1 SCR 30 which held that there can be a violation of s.8 when an interception occurs with the consent of one of the parties.

Section 184.2 does not violate s. 8 of the Charter for not requiring "investigative necessity" before authorizing a search.[12]

### Prevent Bodily Harm[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-9)]

Under s. 184.1 a peace officer may intercept a private communication without judicial authorization:

> **Interception to prevent bodily harm**  
184.1 (1) An agent of the state may intercept, by means of any electro-magnetic, acoustic, mechanical or other device, a private communication if
> 
>     (a) either the originator of the private communication or the person intended by the originator to receive it has consented to the interception;
>     (b) the agent of the state believes on reasonable grounds that there is a risk of bodily harm to the person who consented to the interception; and
>     (c) the purpose of the interception is to prevent the bodily harm.
> 
> **Admissibility of intercepted communication**  
(2) The contents of a private communication that is obtained from an interception pursuant to subsection (1) are inadmissible as evidence except for the purposes of proceedings in which actual, attempted or threatened bodily harm is alleged, including proceedings in respect of an application for an authorization under this Part or in respect of a search warrant or a warrant for the arrest of any person.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec184.1)

This requires that:

  1. consent of one of the parties to the interception;
  2. the interceptor reasonably believes there is a risk of bodily harm to the consenting party;
  3. the purpose of the interception is to prevent bodily harm (such as to an undercover peace officer making a drug buy).

Wiretaps under 184.2 do not require the affiant to establish "investigative necessity" for the wiretap.

## Emergency Wiretap[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-10)]

Section 164.4 permits warrantless wiretaps in exceptional circumstances. The section states:

> **Interception in exceptional circumstances**  
184.4 A peace officer may intercept, by means of any electro-magnetic, acoustic, mechanical or other device, a private communication where
> 
>     (a) the peace officer believes on reasonable grounds that the urgency of the situation is such that an authorization could not, with reasonable diligence, be obtained under any other provision of this Part;
>     (b) the peace officer believes on reasonable grounds that such an interception is immediately necessary to prevent an unlawful act that would cause serious harm to any person or to property; and
>     (c) either the originator of the private communication or the person intended by the originator to receive it is the person who would perform the act that is likely to cause the harm or is the victim, or intended victim, of the harm.
> 
> 1993, c. 40, s. 4.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec184.4)

This section, in its current form, was determined to be unconstitutional due to a lack of safeguards, including a lack of a notice requirement, reporting requirements to Parliament, record-keeping requirement; and restrictions on the use that can be made of the interceptions.[13]

## References[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Wiretaps&action=edit&section=T-11)]

  1. ↑ R. v. Fegan (1993), 80 C.C.C. (3d) 356
  2. ↑ R. v. Davie (1980), 54 C.C.C. (2d) 216
  3. ↑ R. v. Beckner (1978), 43 C.C.C. (2d) 356 -- officer overhears conversation between accused and a friend; R. v. Kopinsky, [1985 CanLII 1191](http://canlii.ca/t/27t7j) (AB QB)
  4. ↑ R. v. Pires; R. v. Lising [2005 SCC 66](http://canlii.ca/t/1m021) at [para 41](http://canlii.ca/t/1m021#par41)
  5. ↑ R. v. Madrid, 1994 BCCA _, [1994] BCJ No 1786 at 82
  6. ↑ R. v Thompson, [1990 CanLII 43](http://canlii.ca/t/1fsrk) (SCC), [1990] 2 SCR 1111 at p. 1139
  7. ↑ see R. v. Finlay and Grelette [1985 CanLII 117](http://canlii.ca/t/1npmr) (ON CA), (1985), 52 O.R. (2d) 632 (C.A.)
  8. ↑ R. v. Della Penna, [2012 BCCA 3](http://canlii.ca/t/fpl3t) at [para 26](http://canlii.ca/t/fpl3t#par26)
  9. ↑ R. v. Finlay and Grellette 1985 CanLII 117 (ON CA), 1985 CanLII 117 (ON C.A.) (1985), 52 O.R. (2d) 632 (C.A.), at p. 656; R. v. Schreinert 2002 CanLII 44932 (ON CA), 2002 CanLII 44932 (ON C.A.) (2002), 165 C.C.C. (3d) 295 (Ont. C.A.), at para. 43, R. v. Ebanks, 2009 ONCA 851 at 33
  10. ↑ Supra
  11. ↑ R. v. Araujo, 2000 SCC 65 (CanLII), 2000 SCC 65, [2000] 2 S.C.R. 992 at para. 46
  12. ↑ R. v. Largie [2010 ONCA 548](http://canlii.ca/t/2c14p) (CanLII) under appeal to SCC
  13. ↑ R. v. Tse, 2012 SCC 16

  


# Search and Seizure/CDSA Warrants[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/CDSA_Warrants&action=edit&section=T-1)]

Section 11(1) of the Controlled Drugs and Substances Act concerns warrants relating to drug offences:

> 11\. (1) A justice who, on ex parte application, is satisfied by information on oath that there are reasonable grounds to believe that:
> 
>     (a) a controlled substance or precursor in respect of which this Act has been contravened,
>     (b) anything in which a controlled substance or precursor referred to in paragraph (a) is contained or concealed,
>     (c) fence-related property, or
>     (d) anything that will afford evidence in respect of an offence under this Act.
> 
> – [CDSA](http://canlii.ca/t/lgn8)

A CDSA search warrant can be issued by a justice of the peace, provincial court judge or superior court judge.[1]

The requirements for a CDSA search warrant are the same as those under a General Warrant.[2]

  1. ↑ R. v. Agecoutay, [2009 SKCA 100](http://canlii.ca/t/25hdt) at para. 15
  2. ↑ R. v. Law, [2002 BCCA 594](http://canlii.ca/t/5fmb) at para. 6

  


# Search and Seizure/Foreign Warrants[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Search warrants coming from outside of the province[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Foreign_Warrants&action=edit&section=T-1)]

Section 487.03 governs the execution of warrants from outside of the province:

> **Execution in another province**  
487.03 (1) If a warrant is issued under section 487.01, 487.05 or 492.1 or subsection 492.2(1) in one province, a judge or justice, as the case may be, in another province may, on application, endorse the warrant if it may reasonably be expected that it is to be executed in the other province and that its execution would require entry into or on the property of any person, or would require that an order be made under section 487.02 with respect to any person, in that province.
> 
> **Endorsement**  
(1.1) The endorsement may be made on the original of the warrant or on a copy of the warrant that is transmitted by any means of telecommunication and, once endorsed, the warrant has the same force in the other province as though it had originally been issued there.
> 
> (2) [Repealed, 2007, c. 22, s. 7]
> 
> 1993, c. 40, s. 15; 1995, c. 27, s. 1; 2000, c. 10, s. 13; 2007, c. 22, s. 7; 2008, c. 18, s. 12.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec487.03)

## Search warrants coming from outside of Canada[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Foreign_Warrants&action=edit&section=T-2)]

Sections 10 to 16 of the The Mutual Legal Assistance in Criminal Matters Act, [R.S.C. 1985, c. 30 (4th Supp.)](http://canlii.ca/en/ca/laws/stat/rsc-1985-c-30-4th-supp/latest/rsc-1985-c-30-4th-supp.html) govern the use of foreign search warrants applicable to matters within the jurisdiction of Canada.

## Search warrants going outside of Canada[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Foreign_Warrants&action=edit&section=T-3)]

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Foreign_Warrants&action=edit&section=T-4)]

  * [Mutual Legal Assistance Treaty (MLAT) between the US and Canada](http://www.lexum.com/ca_us/en/cts.1990.19.en.html)

## References[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Foreign_Warrants&action=edit&section=T-5)]

  


# Search and Seizure/General Warrants[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/General_Warrants&action=edit&section=T-1)]

Section 487(1) provides police with a general power to "use any device or investigative technique, or procedure" or otherwise do any thing described in the warrant which would constitute an unreasonable search or seizure.

The section states:

> 487.01(1) A provincial court judge…may issue a warrant in writing authorizing a peace officer to, subject to this section, use any device or investigative technique or procedure or do any thing described in the warrant that would, if not authorized, constitute an unreasonable search or seizure in respect of a person or a person’s property if
> 
>     (a) the judge is satisfied by information on oath in writing that there are reasonable grounds to believe that an offence against this or any other Act of Parliament has been or will be committed and that information concerning the offence will be obtained through the use of the technique, procedure or device or the doing of the thing;
>     (b) the judge is satisfied that it is in the best interests of the administration of justice to issue the warrant; and
>     (c) there is no other provision in this or any other Act of Parliament that would provide for a warrant, authorization or order permitting the technique, procedure or device to be used or the thing to be done.
> 
> (2) Nothing in subsection (1) shall be construed as to permit interference with the bodily integrity of any person.
> 
> (3) A warrant issued under subsection (1) shall contain such terms and conditions as the judge considers advisable to ensure that any search or seizure authorized by the warrant is reasonable in the circumstances.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec487.01)

A warrant under this section requires:[1]

  1. reasonable and probable grounds that, 
    1. offence has been or will be committed or
    2. information concerning the offence will be obtained; and,
  2. it is in the best interests of the administration of justice; and,
  3. there is no other statutory authority permitting peace officers to do this search or seizure

  1. ↑ see also R. v. Ha, [2009 ONCA 340](http://canlii.ca/t/23b68)

## Purpose of Search[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/General_Warrants&action=edit&section=T-2)]

A general warrant can only be used to seize tangible objects. This means that intangibles, such as money, are not applicable.[1]

Such a warrant however cannot be used to search a person or seize anything on a person.

Finger prints cannot be taken with a 486 warrant.[2]

A bullet found inside an accused person cannot be included.[3]

  1. ↑ R v Bank du Royal Du Canada (1985) 18 C.C.C. (3d) 44
  2. ↑ R. c. Bourque, [1995 CanLII 4764](http://canlii.ca/t/1nkc7) (QC CA)
  3. ↑ R v Laporte (1972) 8 C.C.C. (2d) 343

## Manner of Search[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/General_Warrants&action=edit&section=T-3)]

A 487 warrant may authorize an "covert" search. [1]

  


### Video surveillance[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/General_Warrants&action=edit&section=T-4)]

A warrant is only needed when video surveillance is set-up in such a way that it collects information for which there is a reasonable expectation of privacy. So a camera in a public place such as a street does not need a warrant,[2] but a camera filming the inside of a dwelling would need one.

A video camera requires a warrant where filming:

  * a hotel room [3]
  * a washroom stall [4]

  1. ↑ R. v. Ha, [2009 ONCA 340](http://canlii.ca/t/23b68)
  2. ↑ R. v. Esfahanian Ershad, [1991 CanLII 281](http://canlii.ca/t/1cqqr) (BC SC)  
R. v. Bryntwick, [2002 CanLII 10941](http://canlii.ca/t/1cnm0) (ON SC)
  3. ↑ R. v. Wong, [1990] 3 S.C.R. 36
  4. ↑ R v Silva, 1995 CanLII 7242 (ON SC)

### Lawyer's Office[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/General_Warrants&action=edit&section=T-5)]

When searching a lawyer's office, the police have a duty to minimize which requires:[1]

  1. that a search not be authorized unless there is no other reasonable solution and,
  2. that the authorization be given in terms that, to the extent possible, limit the impairment of solicitor-client privilege

  


# Search and Seizure/Telewarrants[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Telewarrants&action=edit&section=T-1)]

A telewarrant is a warrant that is requested by telephone or other means of telecommunication to a designated justice. This circumvents the requirement that a peace officer appear in person before a justice of the peace to obtain the warrant.

Under s. 487.1(1), a peace officer may only apply for a telewarrant where he believes an indictable offence has been committed and it would be “impractical to appear personally”.[2]

The applicant must be a "peace officer" as defined in s. 2 of the Code.[3]

The information sworn to must include:[4]

  1. description of the circumstances that make it impractical for the informant to appear personally to obtain the warrant;
  2. a description of the indictable offence that is alleged
  3. a description of the place to be searched;
  4. a description of the item(s) to be seized;
  5. the grounds for believing t hat the item(s) will be located within the place;
  6. details on any prior applications with respect to the same matter.

  1. ↑ Maranda v. Richer, [2003 SCC 67](http://canlii.ca/t/1rz) (CanLII), [2003] 3 SCR 193
  2. ↑ [s.487.1(1)](http://canlii.ca/t/7vf2#sec487.1)
  3. ↑ Timberwolf Log Trading Ltd. v. British Columbia, [2011 BCSC 142](http://canlii.ca/t/2fmmh) (CanLII) - applicant not a peace officer  

  4. ↑ [487.1(4)](http://canlii.ca/t/7vf2#sec487.1)

## Impracticable to Attend in Person[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Telewarrants&action=edit&section=T-2)]

The applicant must state the reasons it is "impracticable" to make an application in person before either a judge or justice of the peace. This includes what reasonable efforts were made to make personal appearance possible.[1]

It is often expected that the applicant will verify that a local JP is not available.[2] It has been suggested that where there is a "possibility" that a judge may be available, then the applicant should make an enquiry.[3]

Where the applicant does not state the reasons or efforts made, it may invalidate the warrant.[4] This will be seen, for example, where the police are found to be hiding the real reason of timeliness in seeking a nighttime warrant.[5]

The term "practicable" in this context "means something less than impossible and imports a large measure of practicality, what may be termed common sense."[6]

  1. ↑ e.g. R. v. Adansi, [2008 ONCJ 144](http://canlii.ca/t/1wbr0) (CanLII) at para. 74  
R. v. Breland, [2000 ABPC 110](http://canlii.ca/t/5r07) (CanLII)  
R. v. Brick (Alta. Q.B.) 98 A.R. 208  
R. v. Sattelberger, [1995] 105 Man. R. (2d) 252 (Q.B.) at para. 36  
R. v. Le, [2009 BCCA 14](http://canlii.ca/t/228td) (CanLII) - failed to give reason for not checking on avail. of JP
  2. ↑ R. v. Mui Thi Nguyen, [2006 BCPC 398](http://canlii.ca/t/1p5rw) (CanLII) at para. 97
  3. ↑ R. v. Koprowski, [2005 BCPC 657](http://canlii.ca/t/1mql3) (CanLII) at para. 13
  4. ↑ e.g. See R. v. Ling, [2009 BCCA 70](http://canlii.ca/t/22jfr) (CanLII)  
Adansi -- warrant invalidated  
Ling 2009 BCCA 70 at para. 26, 27 Le at para. 26  

  5. ↑ e.g. Le at para. 26
  6. ↑ R. v. Erickson, [2003 BCCA 693](http://canlii.ca/t/1g5mg) (CanLII) at para. 33  


## Accepted Reasons[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Telewarrants&action=edit&section=T-3)]

Acceptable reasons for applying for a telewarrant:

  * distance to reach the Judge or Justice of the Peace;[1]
  * application to be made outside court hours;[2]
  * short time limit to obtain the warrant. (e.g. when 4 hour time limit on blood sample)[3]

  1. ↑ R. v. Martens, [2004 BCSC 1450](http://canlii.ca/t/1j2gw) (CanLII) at para. 221  
R. v. Phillips, [2004 BCSC 1797](http://canlii.ca/t/1kf1g) (CanLII) at para. 24  

  2. ↑ R. v. Bui and Trac, [2004 BCPC 277](http://canlii.ca/t/1hq82) (CanLII) at para. 20  
Martens at para. 221  
R. v. Murphy, [2010 ONSC 595](http://canlii.ca/t/27nmj) (CanLII) at para. 23-39  

  3. ↑ R. v. Pedersen, [2004 BCCA 64](http://canlii.ca/t/1gdxb) (CanLII) at para. 23  


# IV - Remedy, Waiver and Other Issues[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit&section=5)]

# Exclusion of Evidence[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-1)]

Where there has been a finding of a breach of any right under the _Charter_, the applicant may apply to have evidence excluded from the trial under s. 24(2) of the _Charter_ which states:

> **Exclusion of evidence bringing administration of justice into disrepute**  
(2) Where, in proceedings under subsection (1), a court concludes that evidence was obtained in a manner that infringed or denied any rights or freedoms guaranteed by this Charter, the evidence shall be excluded if it is established that, having regard to all the circumstances, the admission of it in the proceedings would bring the administration of justice into disrepute.

The Supreme Court of Canada made a complete revision of the analytical approach in R. v. Grant, 2009 SCC 32[1]. Under Grant, there are "three avenues of inquiry" that a court must consider:[2]

“

...when faced with an application for exclusion under s. 24(2), a court must assess and balance the effect of admitting the evidence on society's confidence in the justice system having regard to:

    (1) the seriousness of the Charter-infringing state conduct (admission may send the message the justice system condones serious state misconduct),
    (2) the impact of the breach on the Charter-protected interests of the accused (admission may send the message that individual rights count for little), and
    (3) society's interest in the adjudication of the case on its merits.  


The court's role on a s. 24(2) application is to balance the assessments under each of these lines of inquiry to determine whether, considering all the circumstances, admission of the evidence would bring the administration of justice into disrepute...

”

In balancing these factors, the judge should consider all the circumstances of the case.[3]

This analysis should focus on the "long-term, prospective and societal" effect of the violations.[4]

The analysis should be from an objective view and ask "whether a reasonable person, informed of all relevant circumstances and the values underlying the Charter, would conclude that the admission of the evidence would bring the administration of justice into disrepute"[5]

There is no rule requiring the automatic exclusion of a statement obtained by Charter violations.[6]

A appellate court should give a discretionary decision of a judge, such as in a 24(2) analysis, high deference. The judge should only interfere where "the judge did not give weight to all relevant considerations". [7]

  1. ↑ R. v. Grant, [2009 SCC 32](http://canlii.ca/t/24kwz)
  2. ↑ R v Grant per McLachlin, C.J. and Charron, J., at para. 71
  3. ↑ See R. v. Morelli, [2010 SCC 8](http://canlii.ca/t/28mrg) (CanLII), [2010] 1 S.C.R. 253  
R. v. Côté, [2011 SCC 46](http://canlii.ca/t/fndv8) (CanLII), [2011] 3 S.C.R. 215, at para. 45-48  

  4. ↑ see R. v. Mahmood, [2011 ONCA 693](http://canlii.ca/t/fnr5s) (CanLII)  
R. v. Dhillon, [2012] B.C.J. No. 1158 (C.A.), at para 78  
Grant at para. 69 and 70  

  5. ↑ Grant at para. 68
  6. ↑ R. v. N.Y., [2012 ONCA 745](http://canlii.ca/t/ftlsv) (CanLII) at para. 56, 57
  7. ↑ R. v. Bacon, [2012 BCCA 323](http://canlii.ca/t/fs5sn) at para. 14

## Seriousness of police misconduct[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-2)]

This factor considers the effect of the police misconduct on the reputation of the justice system. Effectively, considering whether the courts are "condoning" the deviation from the rule of law by failing to disassociate themselves from the fruits of the misconduct.[1]

However, an over-readiness to exclude for "fleeting and technical violation[s]" is likely "to be seen as symptom of systemic impotency which would breed public contempt for the criminal justice system"[2]

Factors the court must consider include:[3]

  * Was the breach “inadvertent or minor” or a result of willful or reckless or deliberate disregard for the Charter?
  * Did the police act in good faith?
  * Were there “extenuating circumstances”?

The gravity of the conduct depends on the degree of intention of the officer, ranging from inadvertent or minor violations to wilful or reckless disregard for Charter rights.[4]

Flagrant disregard of Charter right are to be treated differently than breaches arising out of conduct that is in accordance with the law.[5]

The Court should consider "what the police did and their attitude when they did it".[6]

The presence of ignored lesser intrusive options to chosen the method of investigation will have an aggravating effect on the seriousness of the Charter breach.[7]

A "cavalier" attitude to the use of police powers will also aggravate the breach.[8]

Whether the conduct was an isolated incident or part of a larger pattern of police disregard of Charter rights will affect the seriousness of the breach.[9] This can usually come out through voir dire evidence of whether the officer was acting on an established practice.

The seriousness can be mitigated by factors such as "good faith" on the part of the officer or extenuating circumstances that may warrant quick action to avoid losing evidence.[10]

Good faith, if established, will favour admission because it will "reduce the need for the court to disassociate itself from police conduct".[11]

The presence of reasonable and probable grounds for the police conduct will lessen the seriousness of the violation.[12]

Entry into a residence with an invalid warrant or without any warrant is considered a serious violation of the accused's rights and tends to lean towards exclusion.[13]

  1. ↑ R. v. Ngai, [2010] A.J. No. 96 (C.A.), ("court's first stage of inquiry requires it to assess whether the admission of the evidence would bring the administration of justice into disrepute by sending a message to the public that the courts effectively condone state deviation from the rule of law by failing to disassociate themselves from the fruit of that unlawful conduct." )
  2. ↑ see R. v. Shinkewski, [2012] S.J. No. 376 (C.A.), at para 33  
R. v. Giulioni, [2011] N.J. No. 322 (S.C.)  
R. v. Hart, 2012 NLCA 61  

  3. ↑ R. v. Loewen 2010 ABCA 255 at para. 83
  4. ↑ R. v. Grant at para. 74
  5. ↑ see R. v. Beaulieu, 2010 SCC 7 (CanLII), [2010] 1 S.C.R. 248  
R. v. Loewen, [2011] S.C.J. No. 100)
  6. ↑ see R. v. Ramage, 2010 ONCA 488 (CanLII), at para 48
  7. ↑ R v Brown, [2012 ONCA 225](http://canlii.ca/t/fqx32) (CanLII)
  8. ↑ R v Brown, [2012 ONCA 225](http://canlii.ca/t/fqx32) (CanLII)
  9. ↑ R. v. Greffe, 1990 CanLII 143 (SCC), [1990] 1 S.C.R. 755, at para. 50
  10. ↑ R. v. Silveira, 1995 CanLII 89 (S.C.C.), [1995] 2 S.C.R. 297
  11. ↑ R. v. Grant, at para. 75
  12. ↑ R. v. Caslake, 1998 CanLII 838 (SCC), [1998] 1 S.C.R. 51  
R. v. Belnavis, 1997 CanLII 320 (SCC), [1997] 3 S.C.R. 341  

  13. ↑ R. v. Maton, [2005 BCSC 330](http://canlii.ca/t/1k2jq) (CanLII) at para. 56-64

## Impact on personal interests[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-3)]

The impact on the personal interests is a two part inquiry. First, the interest engaged must identified, and then the degree to which the violation impacted this interest must be considered.

The impact can range from fleeting and technical to profoundly intrusive.[1]

Being stopped and searched without justification impacts liberty and privacy in more than a trivial manner. [2]

Stopping a vehicle creates a lesser impact on personal interests than a search of a residence.[3]

The older test under Collins placed emphasis on the discoverability of the evidence, inquiring whether the evidence would have been otherwise discovered during the investigation. Under the new model, the discoverability is still relevant to the first two branches of the analysis but less crucial to the analysis.[4]

In the context of an roadside screening demand, it has been said that only the breaching event is to be considered in determining the impact on personal interests. The judge should not consider the events that follow including the subsequent arrest, personal consequences, or employment consequences.[5]

The "more likely that the evidence would have been obtained even without [the impugned statment of the accused] the lesser the impact of the breach on the accused’s underlying interest against self-incrimination".[6]

  1. ↑ R v Grant, supra
  2. ↑ R v Harrison, [2009 SCC 34](http://canlii.ca/t/24kx5) at para. 31 "being stopped and subjected to a search by the police without justification impacts on the motorist's rightful expectation of liberty and privacy in a way that is much more than trivial.”)
  3. ↑ see R. v. Bacon, [2012] B.C.J. No. 1571 (C.A.), at para 34  
R. v. Loewen, [2011] S.C.J. No. 100, at para 12 and 13  
R v Harrison, [2009] 2 S.C.R. 494 at para 31  

  4. ↑ R. v. Côté, [2011] S.C.J. 46 at 70
  5. ↑ R v. Booth, [2010 ABQB 797](http://canlii.ca/t/2f1c1)
  6. ↑ R. v. Grant, 2009 SCC 32 at 122

## Interest in Trying Case on Merits[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-4)]

The third step considers the "truth-seeking function" of the trial process.[1]It is presumed that society has an interest in adjudicating matters on the merits. A balance must be made between the effect of its exclusion to the effect of its inclusion.

The "reliability" of the evidence is an important inquiry. If the breach brings the reliability into question it will favour exclusion.[2]

The importance of the evidence on the Crown's case is also important. [3] Where the exclusion would effectively "gut" the case, it will be a factor in favour of admission.[4]

The seriousness of the offence has some importance,[5] but can "cut both ways".[6] The importance of the short-term desire to convict for serious offences is balanced against the need for fair conduct where the penalty is so great.

There will be cases where the seriousness of the offence is considered "neutral".[7]

  1. ↑ R v Grant
  2. ↑ R. v. Grant at para. 83  
R. v. Atkinson, [2012] O.J. No. 2520 (C.A.), at para 93
  3. ↑ R. v. Grant at para. 83
  4. ↑ see R. v. MacDonald, [2012] O.J. No. 3210 (C.A.), at para 37
  5. ↑ R. v. Reddy, 2010 BCCA 11 (CanLII), at para 94  
R. v. Stevens, 2011 ONCA 504 (CanLII), at para 62  

  6. ↑ R. v. Grant at para. 84
  7. ↑ see R. v. Martin, [2010] N.B.J. No. 198 (C.A.), at para 96

## Interests for specific offences[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-5)]

### Motor Vehicle Offences[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-6)]

Cases have addressed society's interest screening of impaired drivers to reduce the carnage on our highways prefers the inclusion of evidence.[1]

The ASD procedure has been described as a "non-invasive" and "does not undermine bodily integrity or dignity".[2]

  1. ↑ see R. v. Elias; R. v. Orbanski 2005 SCC 37, (2005), 196 C.C.C. (3d) 481 (S.C.C.) at paras. 3, 24-27; 49; 55 and 58
  2. ↑ R. v. Vandenberg [2010 ABQB 261](http://canlii.ca/t/29cph)

### Weapons Offences[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-7)]

In consideration under s.24(2) of the Charter, courts have commented on the public interest with respect to gun cases:[1]

    Offences involving handguns is a “serious and growing societal danger”.[2] There is a strong emphasis on the need to denounce and deter the use of firearms in public places.[3] There has been judicial notice that as of 2007 there has been a national increase in gun violence and gun-related offences.[4]

It has been said that "the exclusion of firearms would more negatively impact the administration of justice than their admission."[5]

  1. ↑ See R v Campbell [2009] OJ 4132
  2. ↑ R v Clayton 2005 CaLII 16569 (ONCA) at 41
  3. ↑ R v Danvers [2005] OJ 3532 ONCA at 77  
R. v. Bellamy,2008 CanLII 26259 (ON SC), [2008] 175 C.R.R. (2d) 241, at para. 76  
R. v. Brown, [2006] O.J. No. 4681 (Ont. S.C.J.) at para. 9  

  4. ↑ R v. Clayton [2007 SCC 32](http://canlii.ca/t/1rxzv) at 110
  5. ↑ R. v. Mpamugo, [2009] O.J. No. 953 (S.C.), at para. 48  
R v Harrison, 2009 SCC 34 at 82  


## Pre-Grant Analysis[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-8)]

### Collins/Stillman Analysis[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-9)]

Under the Collins test, the administration of justice is brought into "disrepute" where a combination of three factors weight in favour of exclusion of evidence. These sets of factors consist of:[1]

  1. factors affecting the fairness of the trial,
  2. factors relevant to the seriousness of the violation; and
  3. factors relevant to the effect of excluding the evidence.

The Stillman test considers the first set of factors. It examines the nature of the evidence and alternatives to its discovery.[2] The Stillman test directs the following analysis:

  1. Classify the evidence as conscriptive or non-conscriptive based on the manner in which the evidence was obtained. If the evidence is non-conscriptive, its admission will not render the trial unfair and the Court will proceed to consider the seriousness of the breach and the effect of exclusion on the repute of the administration of justice.
  2. If the evidence is conscriptive and the Crown fails to demonstrate on a balance of probabilities that the evidence would have been discovered by alternative non-conscriptive means, then its admission will render the trial unfair. The Court, as a general rule, will exclude the evidence without considering the seriousness of the breach or the effect of exclusion on the repute of the administration of justice. This must be the result since an unfair trial would necessarily bring the administration of justice into disrepute.
  3. If the evidence is found to be conscriptive and the Crown demonstrates on a balance of probabilities that it would have been discovered by alternative non-conscriptive means, then its admission will generally not render the trial unfair. However, the seriousness of the Charter breach and the effect of exclusion on the repute of the administration of justice will have to be considered.

  1. ↑ R. v. Collins [1987] 1 S.C.R. 265
  2. ↑ R. v. Stillman [1997] 1 S.C.R. 607, 1997 SCC 32

### Conscriptive Evidence[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-10)]

Evidence that is conscriptive is a factor against the admission of evidence obtained by a Charter violation.

Conscriptive evidence affects the trial fairness factor.

Conscriptive evidence is evidence that arises from any of the following:[1]

  1. statements
  2. use of the accused's body
  3. taking of bodily sample
  4. evidence derived from the above (derivative evidence)

Evidence that is conscriptive and not otherwise discoverable will tend to be excluded.

A voluntary statement cannot be conscriptive.[2]

Conscriptiveness must be proven by the Accused on a balance of probabilities.

Discoverable evidence is evidence that 1) can be proven by other non-conscriptive means or 2) would inevitably be discovered.[3]

Discoverability must be proven by the Crown on a balance of probabilities.

  1. ↑ Watt, Manual of Criminal Evidence at 41.03  
Stillman - lists the first three factors
  2. ↑ Watt at 41.03
  3. ↑ Stillman

## Relevant Charter Rights[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Exclusion_of_Evidence&action=edit&section=T-11)]

  * [Rights against Search and Seizure](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Rights_against_Search_and_Seizure)
  * [Right to Counsel](/wiki/Canadian_Criminal_Procedure_and_Practice/Arrest_and_Detention/Right_to_Counsel)
  * [Right against Arbitrary Detention](/wiki/Canadian_Criminal_Procedure_and_Practice/Arrest_and_Detention/Investigative_Detention)

  


# Waiver of Charter Rights[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Waiver_of_Charter_Rights&action=edit&section=T-1)]

The waiver of any Charter right must be done clearly and unequivocally with full knowledge of the scope of the right and effect of the waiver.[1]

It is necessary for the Crown to prove waiver of an accused right under s.8.[2]

An express or implied invitation, such as at the attendance of police at the door of a residence or being invited into the house, results in the waiving of privacy.[3]

  1. ↑ R v Korponay v Attorney General of Canada, [1992] 1 SCR 41 at p. 49 ("the validity of such a waiver, and I should add that that is so of any waiver, is dependent upon it being clear and unequivocal that the person is waiving the procedural safeguard and is doing so with full knowledge of the rights the procedure was enacted to protect and of the effect the waiver will have on those rights in the process.")
  2. ↑ See: R. v. Neilson 1988 CanLII 213 , (1988), 43 C.C.C. (3d) 548 (SKCA)
  3. ↑ See R v Evans [1996] 1 SCR 8 at 12-13 implied invitation  
R v Roy, 2010 BCCA 448 express invitation  


## See Also[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Waiver_of_Charter_Rights&action=edit&section=T-2)]

  * [Consent Search](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Warrantless_Searches/Consent_Search)

  


# Search and Seizure/Seizure of Property[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Seizure of Things Not Specified[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-1)]

Section 489 authorizes police officers to seize certain property. It specifically addresses the situation where police seek to seize property other than what is specified in the warrant.

> **Seizure of things not specified**  
489\. (1) Every person who executes a warrant may seize, in addition to the things mentioned in the warrant, any thing that the person believes on reasonable grounds
> 
>     (a) has been obtained by the commission of an offence against this or any other Act of Parliament;
>     (b) has been used in the commission of an offence against this or any other Act of Parliament; or
>     (c) will afford evidence in respect of an offence against this or any other Act of Parliament.
> 
> **Seizure without warrant**  
(2) Every peace officer, and every public officer who has been appointed or designated to administer or enforce any federal or provincial law and whose duties include the enforcement of this or any other Act of Parliament, who is lawfully present in a place pursuant to a warrant or otherwise in the execution of duties may, without a warrant, seize any thing that the officer believes on reasonable grounds
> 
>     (a) has been obtained by the commission of an offence against this or any other Act of Parliament;
>     (b) has been used in the commission of an offence against this or any other Act of Parliament; or
>     (c) will afford evidence in respect of an offence against this or any other Act of Parliament.
> 
> R.S., 1985, c. C-46, s. 489; R.S., 1985, c. 27 (1st Supp.), s. 72, c. 42 (4th Supp.), s. 3; 1993, c. 40, s. 16; 1997, c. 18, s. 48.
> 
> – [CCC](http://www.canlii.ca/t/7vf2#sec489)

Under s. 489, a peace officer in lawful execution of their duty may seize anything without a warrant that they reasonably believe to be:

  1. obtained by crime;
  2. used in a crime; or
  3. affords evidence of a crime.

All items that are seized must be reported to a justice of the peace pursuant to s. 489.1. The justice of the peace will grant a detention order for a period of time. The property must be returned on the expiration of the order unless the justice grants an extension under s. 490(1) or if charges are laid.

This section does not codify or incorporate any part of the common law doctrine of "plain view".[1]

  1. ↑ R. v. Bottineau, [2011 ONCA 194](http://canlii.ca/t/fkgld) (CanLII)

## Procedure Upon Seizure of Property[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-2)]

Section 489.1 governs the procedure to be followed by the police upon seizing property, whether under warrant, warrantless, or otherwise under an Act of Parliament including s. 489. This applies to seizure on search incident to arrest as well as seizure incidental to a search warrant.[1]

> 489.1 (1) Subject to this or any other Act of Parliament, where a peace officer has seized anything under a warrant issued under this Act or under section 487.11 or 489 or otherwise in the execution of duties under this or any other Act of Parliament, the peace officer shall, as soon as is practicable,
> 
>     (a) where the peace officer is satisfied, 
> 
>     (i) that there is no dispute as to who is lawfully entitled to possession of the thing seized, and
>     (ii) that the continued detention of the thing seized is not required for the purposes of any investigation or a preliminary inquiry, trial or other proceeding,
> 
> return the thing seized ... to the person lawfully entitled to its possession and report to the justice who issued the warrant ... or, if no warrant was issued, a justice having jurisdiction in respect of the matter, that he has done so; or
> 
>     (b) where the peace officer is not satisfied as described in subparagraphs (a)(i) and (ii), 
> 
>     (i) bring the thing seized before the justice referred to in paragraph (a), or
>     (ii) report to the justice that he has seized the thing and is detaining it or causing it to be detained
> 
> to be dealt with by the justice in accordance with subsection 490(1). ...
> 
> **Form**  
(3) A report to a justice under this section shall be in the form set out as Form 5.2 in Part XXVIII, varied to suit the case...
> 
> R.S., 1985, c. 27 (1st Supp.), s. 72; 1993, c. 40, s. 17; 1997, c. 18, s. 49.
> 
> – [CCC](http://www.canlii.ca/t/7vf2#sec489.1)

Under s. 489.1(1)(b)(ii), where the police seize property either in execution of a warrant or otherwise in execution of their duties, they must file a Report to Justice that is filed with the justice of the peace.

This will permit the officer to hold onto the property for a period of 90 days without laying charges. Where further time is needed the officer must apply for a further detention order under s. 490.

  1. ↑ R. v. Backhouse, [2005 CanLII 4937](http://canlii.ca/t/1jvwn) (ON CA)

### Inventory Searches[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-3)]

Seizure of property will create an authority to perform a warrantless search the items seized for the purpose itemizing them and ensuring safe keeping. It cannot be searched for the purpose of advancing an investigation.[1]

  1. ↑ R v Adam [2012 ABPC 77](http://canlii.ca/t/fr1p8)  
R v Wint [2009 ONCA 52](http://canlii.ca/t/225zz)

## Detention Order[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-4)]

Section 490 governs the procedure for detaining property seized under s. 489 or 489.1, including obtaining the approval of justice to detain the property for a period of time.

An order can be made by a justice of the peace to allow the police to detain property under s.490(1):

> **Detention of things seized**  
490\. (1) Subject to this or any other Act of Parliament, where, pursuant to paragraph 489.1(1)(b) or subsection 489.1(2), anything that has been seized is brought before a justice or a report in respect of anything seized is made to a justice, the justice shall,
> 
>     (a) where the lawful owner or person who is lawfully entitled to possession of the thing seized is known, order it to be returned to that owner or person, unless the prosecutor, or the peace officer or other person having custody of the thing seized, satisfies the justice that the detention of the thing seized is required for the purposes of any investigation or a preliminary inquiry, trial or other proceeding; or
>     (b) where the prosecutor, or the peace officer or other person having custody of the thing seized, satisfies the justice that the thing seized should be detained for a reason set out in paragraph (a), detain the thing seized or order that it be detained, taking reasonable care to ensure that it is preserved until the conclusion of any investigation or until it is required to be produced for the purposes of a preliminary inquiry, trial or other proceeding.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec490)

Section 489.1 and 490, together set out an administrative scheme for managing detained property in the course of a criminal investigation as well as returning property.[1]

These provisions establish "a predictable, fair, efficient, and orderly procedure for the detention, retention, return, and forfeiture of seized items, consistent with the interests of justice." Non-compliance is not to be translated into "substantive trial remedies" such as a stay of proceedings. Failure to comply may result in the return of the property. However, "may not make such an order if it is not in the interests of justice to do so." [2]

Other courts have suggested that a failure to comply with the provisions, in particular, make a filing under s.489.1, will render the search unlawful.[3]

Still other courts have been reluctant to provide trial remedies.[4]

The obligations imposed by s. 489.1 and 490 are mandatory.[5]

These provisions "safeguard in the balance between the state’s jurisdiction to invade the privacy rights of citizens and the high value that Parliament and the courts have seen fit to ascribe to those rights".[6]

The onus is on the applicant to prove on a balance of probabilities that the provisions were not complied with.[7]

Once property has been detained under s. 490, it is considered "under the control of the court, not the Crown or anyone else." Thus, can only be disposed of pursuant to an order of the court. [8]

  1. ↑ R. v. Mann, [2012 BCSC 1247](http://canlii.ca/t/fsdzc) (CanLII) at para. 71 and 83
  2. ↑ R. v. Mann, [2012 BCSC 1247](http://canlii.ca/t/fsdzc) (CanLII) at para. 83  
see also R. v. Arason (1992), 21 B.C.A.C. 20 (Report to Justice is “an administrative procedure to be carried out after the completion of a search. Non compliance with it ought not to affect the validity of the search itself."  
R. v. Berube [1999 CanLII 13241](http://canlii.ca/t/1mvr2) (QC CA), (1999), 139 C.C.C. (3d) 304 (Que.C.A.) : late filing was a technicality and not enough to invalidate search  
R. v. Karim, [2012 ABQB 470](http://canlii.ca/t/fs5p1) ("I can think of no [...] situation in our criminal law where a lawful act that meets the requirements of the Charter, ...can subsequently become non Charter compliant because of another action separated by time.")
  3. ↑ R. v. Guiller, (1985) 25 CRR 273 (Ont. Dist.Ct.): evidence excluded under s.24(2)  
R. v. Noseworthy, [1995] O.J. No. 1759, [1995 CanLII 7425](http://canlii.ca/t/1wctm) (ON SC) (Ont. Ct. Jus G.D.)  
R. v. Macneil [1994 CanLII 4314](http://canlii.ca/t/1nh1d) (NS SC), (1994), 130 N.S.R. (2d) 202 (N.S.S.C)  

  4. ↑ R. v. Martens, [2004 BCSC 1450](http://canlii.ca/t/1j2gw) (CanLII) at para. 264  
R. v. Valiquette, [2010 BCSC 1423](http://canlii.ca/t/2d4b8) (CanLII)  
R. v. Patterson, [2011 BCSC 1728](http://canlii.ca/t/fqcwl) (CanLII)
  5. ↑ R. v. Pickton, [2006 BCSC 1098](http://canlii.ca/t/2c72m) at para 60
  6. ↑ R. v. Pickton, [2006 BCSC 1098](http://canlii.ca/t/2c72m) at para 60
  7. ↑ R. v. Mann, [2012 BCSC 1247](http://canlii.ca/t/fsdzc) (CanLII) at para. 75
  8. ↑ R. v. Bellefleur, [1992] S.J. No. 473 (Q.B.)

## Extending Time Period of Detention[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-5)]

Under [s. 490(2)](http://canlii.ca/t/7vf2#sec490), all property that is seized by police must be released after the detention period. That is, unless there are proceedings "instituted in which the thing detained may be required." (s. 490(2)(b)) This would include criminal charges where the thing may be part of the evidence for trial.

Under s. 490(2)(a), the party may apply to have property seized pursuant to s. 490(1) detained past the time limit where "a justice, on the making of a summary application to him after three clear days notice thereof to the person from whom the thing detained was seized, is satisfied that, having regard to the nature of the investigation, its further detention for a specified period is warranted and the justice so orders"

## Release and Return of Property[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-6)]

A Superior Court Justice has inherent jurisdiction to order the return of property seized by the police where the items are not needed for trial and otherwise not needed to be held by the police. [1]

  1. ↑ see Butler v. Canada (Attorney General), [1981 CanLII 373](http://canlii.ca/t/23m2v) (BC SC)

## Access to Exhibits[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-7)]

### Release of Exhibits for Testing[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-8)]

All objects that are put in as exhibits before the court may be released for the purpose of testing on application of a party.

Section 605 states:

> **Release of exhibits for testing**  
605\. (1) A judge of a superior court of criminal jurisdiction or a court of criminal jurisdiction may, on summary application on behalf of the accused or the prosecutor, after three days notice to the accused or prosecutor, as the case may be, order the release of any exhibit for the purpose of a scientific or other test or examination, subject to such terms as appear to be necessary or desirable to ensure the safeguarding of the exhibit and its preservation for use at the trial.
> 
> **Disobeying orders**  
(2) Every one who fails to comply with the terms of an order made under subsection (1) is guilty of contempt of court and may be dealt with summarily by the judge or provincial court judge who made the order or before whom the trial of the accused takes place.
> 
> R.S., 1985, c. C-46, s. 605; R.S., 1985, c. 27 (1st Supp.), s. 203.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec605)

The application may be made before either a superior court judge or a provincial court judge on three days notice.

Once the proceedings are complete and all avenues of appeal are exhausted this section no longer applies to exhibits.[1]

  1. ↑ e.g. R. v. Horne, [1999 ABQB 754](http://canlii.ca/t/5nts) (CanLII) at para. 34  


### Media Access to Exhibits[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-9)]

The right to access to exhibits flows from the "open court principle". [1]

Dagenais/Mentuck test should apply to requests of third-parties to access exhibits.[2]

The test requires the party opposing access to show that it is "necessary to prevent a serious risk to the proper administration of justice and that the salutary effects of the order sought outweigh the deleterious effects on the rights and interests of the parties and the public."[3]

  1. ↑ R. v. Canadian Broadcasting Corporation, [2010 ONCA 726](http://canlii.ca/t/2d4c5) (CanLII)
  2. ↑ Canadian Broadcasting Corporation
  3. ↑ Canadian Broadcasting Corporation

## Special Seizure Powers[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-10)]

### Firearms[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-11)]

#### Exigent Circumstances[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-12)]

Under [s.117.02](http://canlii.ca/t/7vf2#sec117.02), an officer believes that a firearm or related item[1] "was used in the commission of an offence" or where there was, or is ongoing, an offence where the subject-matter is a firearm or related item[2] and the officer believes the item "is likely to be found on a person, in a vehicle or in any place or premises other than a dwelling-house", then the officer may search the premises or person without a warrant, so long as it under exigent circumstances where it "would not be practicable to obtain a warrant".[3]

  1. ↑ a prohibited device, any ammunition, any prohibited ammunition or an explosive substance
  2. ↑ firearm, an imitation firearm, a cross-bow, a prohibited weapon, a restricted weapon, a prohibited device, ammunition, prohibited ammunition or an explosive substance
  3. ↑ see also s 487, 487.11

#### Failure to Produce Authorization[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-13)]

Under [s. 117.03](http://canlii.ca/t/7vf2#sec117.03), where a person is found in possession of a firearm or related items and cannot produce the appropriate documents authorizing them to possess it, an officer may seize the items. If the proper documentation is produced within 14 days, the officer must return the items seized. If 14 days pass without producing the authorization, the officer may apply to the court to have the firearm forfeited.

#### Danger to self or public[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-14)]

Under s.117.04, an officer may seize a firearm from someone in lawful possession of it where the officer believes he may pose a danger to themselves or the public. A warrant is required unless there are exigent circumstances such that "by reason of a possible danger to the safety of that person or any other person, it would not be practicable to obtain a warrant".(s. 117.04(2))

Under s.117.05, the officer may apply to forfeit the firearm after 30 days where it can be established that forfeiture is in the "interests of the safety of the person". (see [Canadian_Criminal_Sentencing/Ancillary_Orders/Forfeiture#interests_of_the_safety](/wiki/Canadian_Criminal_Sentencing/Ancillary_Orders/Forfeiture#interests_of_the_safety))

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Seizure_of_Property&action=edit&section=T-15)]

  * [Canadian Criminal Sentencing/Forfeiture](/wiki/Canadian_Criminal_Sentencing/Forfeiture)
  * [Canadian Criminal Procedure and Practice/Disclosure#Lost Evidence](/wiki/Canadian_Criminal_Procedure_and_Practice/Disclosure#Lost_Evidence)

  


# _Digests_[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit&section=6)]

# Cases/Warrantless Searches[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Detention and Search: Generally[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-1)]

Case Citation s.8 s.9 s.24 Summary

R. v. Ahmed-Kadir and McFadyen
[2011 BCPC 250](http://www.canlii.org/en/bc/bcpc/doc/2011/2011bcpc250/2011bcpc250.html)
N
Y
N

R. v. Brown
[2011 ONSC 6250](http://www.canlii.org/en/on/onsc/doc/2011/2011onsc6250/2011onsc6250.html)
-
N
N
vehicle pulled over after chase; alleged detained by police pursuit

R. v. Ryan
2010 NJ No. 173
N
Y
Y
breath test

R. v. G.C.
2010 NSPC 10 [[16]](http://www.canlii.org/en/ns/nspc/doc/2010/2010nspc10/2010nspc10.html)
N
N
N
while executing search warrant, pat-down search of accused for weapons; finds drugs

R. v. Cunsolo
[2009 CanLII 60775 (ON S.C.)](http://www.canlii.org/en/on/onsc/doc/2009/2009canlii60775/2009canlii60775.html)
N
Y
N
premature arrest of fraudster

R. v. N.O.
[2009 ABCA 75](http://www.canlii.org/en/ab/abca/doc/2009/2009abca75/2009abca75.html)
N
Y
Y
police observe hand-to-hand, search accused, find drugs

R. v. Harada
2008 BCSC 1346
N
N
N
pull over car; patdown search of driver

R. v. Nesbeth
[2008] O.J. No. 3086 (C.A.)
-
Y
Y

R. v. Peters
[2007 ABCA 181](http://www.canlii.org/en/ab/abca/doc/2007/2007abca181/2007abca181.html)
N
N
N
police see accused matching description of person with gun; searched backpack twice, found gun

R. v. Chambers
[2007 ABQB 712](http://www.canlii.org/en/ab/abqb/doc/2007/2007abqb712/2007abqb712.html)
N
N
N
after seeing signs of drug transaction, accused is strip searched, and searched vehicle

R. v. Y.(S.)
[2006 ONCJ 403](http://www.canlii.org/en/on/oncj/doc/2006/2006oncj403/2006oncj403.html)
N
N
N
person standing near car registered to person with warrant; several minor reasons for pull-over

R. v. Ngo
[2005 ONCJ 217](http://www.canlii.org/en/on/oncj/doc/2005/2005oncj217/2005oncj217.html)
arbitrary detention

R. v. B.A.D.G.
[2005 BCPC 504](http://www.canlii.org/en/bc/bcpc/doc/2005/2005bcpc504/2005bcpc504.html)
N
N
N
police get report of B&E suspects, see accused shortly after; patdown search reveals knife

R. v. Sepulveda
[2005 BCPC 236](http://www.canlii.org/en/bc/bcpc/doc/2005/2005bcpc236/2005bcpc236.html)
N
N
N
pat-down search of woman known to police; accused spit on officer

R. v. K.W.
2004 O.J. No.5327 (OCJ)
Y
police officers had no grounds to suspect that the accused was connected to any criminal activity; he “must be doing something” because of the very general surrounding circumstances.

R. v. Power
[2003 SKQB 334](http://www.canlii.org/en/sk/skqb/doc/2003/2003skqb334/2003skqb334.html)

R. v. Burke
[1997 CanLII 10867 (NL C.A.)](http://www.canlii.org/en/nl/nlca/doc/1997/1997canlii10867/1997canlii10867.html)
N
N
N
overturn s.9 breach; officer had sufficient reason to pull over accused

  * R. v. Dauda, 2011 ONCJ 799 || s.8 and 9 violation, exlcuded under 24(2); seen avoiding police, threw something away; found <4 g cocaine

## Vehicle Stops[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-2)]

  * R v Vulic, [2012 SKQB 221](http://canlii.ca/t/frn9r) \- violated s.9, drugs excluded
  * R. v. McCammon, [2012 MBQB 154](http://canlii.ca/t/frj67) \- violated s. 9, evidence excluded

## Personal Search[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-3)]

Case Citation s.8 s.9 s.24 Summary

R. v. Rose
[2012 ONSC 350](http://www.canlii.org/en/on/onsc/doc/2012/2012onsc350/2012onsc350.html)
 ?
Y
Y
arrested accused based on finding marijuana on co-accused.

R. v. Osolky
[2009 ONCJ 445](http://www.canlii.org/en/on/oncj/doc/2009/2009oncj445/2009oncj445.html)
Y
N
Y
patdown search; evidence excluded

R. v. F. (C.J.)
[2008 SKPC 51](http://www.canlii.org/en/sk/skpc/doc/2008/2008skpc51/2008skpc51.html)
N
N
N
officer responds to mischief complaint; sees youths; accused run away; searches him and finds weapon;

R. v. Ferdinand
2004 O.J. No. 3209 (SCJ)
Y
Y
officer’s hunch about the actions of the accused, (based on his “Spidey sense,”) was insufficient basis

## Vehicle Search[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-4)]

Case Citation s.8 s.9 s.24 Evidence at issue Summary

R v Turpin
[2012 SKCA 50](http://canlii.ca/t/fr8tt)
Y
Y
Y
drugs

R. v. Forster
[2009 ABPC 278](http://canlii.ca/t/261jz)
Y
-
Y
drugs
search of vehicle incident to arrest was improper. The officer cannot have reasonably expected to find evidence in vehicle from an offence 6 months prior.(para. 18-19). Excluded under s. 24(2), police were careless.

R. v. Anderson
[2011 ABPC 326](http://www.canlii.org/en/ab/abpc/doc/2011/2011abpc326/2011abpc326.html)
Y
N
Y
crack cocaine
drugs found in vehicle

R. v. Ruddock
[2011 ABPC 105](http://www.canlii.org/en/ab/abpc/doc/2011/2011abpc105/2011abpc105.html)
Y
N
Y
also found breach of s.10(a) and 10(b)

R v Savage
[2011 SKCA 65](http://canlii.ca/t/flmz9)
N
N
N
use of sniffer dog;

R. v. Chubak
[2009 ABCA 8](http://canlii.ca/en/ab/abca/doc/2009/2009abca8/2009abca8.html)
N
-
-
drugs
Officers respond to report of stabbing/beating—see vehicle with D inside with bear spray- D searched and find knife on him; police search car for more weapons; police find weapons, drugs, and ringing cell phone; trial judge says police can’t search for drugs; appeal court says they can; search for multiple reasons is valid as long as objectively justified (para. 18)

R. v. Arabi
[2007 ABQB 303](http://www.canlii.org/en/ab/abqb/doc/2007/2007abqb303/2007abqb303.html)
Y
Y
Y
search of person and vehicle after seeing possible drug transaction

R. v. Dykhuizen
[2007 ABQB 489](http://www.canlii.org/en/ab/abqb/doc/2007/2007abqb489/2007abqb489.html)
Y
-
 ?
mistaken ID of accused for a kidnapping suspect; found licence was expired; searched

R. v. Calder
[2006 ABCA 307](http://www.canlii.org/en/ab/abca/doc/2006/2006abca307/2006abca307.html)
Y
Y
Y
gun
sees possible drug transaction; searches backpack, finds gun

R. v. T.T.H.
[2006 ABPC 320](http://www.canlii.org/en/ab/abpc/doc/2006/2006abpc320/2006abpc320.html)
Y
-
N
search vehicle based on unsafe driving and suspicious comments from driver

R. v. Batzer
[2005 CanLII 33026](http://canlii.ca/t/1lm3g) (ON C.A.)
Y
N
Y
search of glovebox of car after detaining accused on rough description

R. v. Cox
[1999 CanLII 13119 (NB C.A.)](http://www.canlii.org/en/nb/nbca/doc/1999/1999canlii13119/1999canlii13119.html)
Y
Y
Y
plainclothes officer searched car at roadblock due to smell of "bulk" tobacco

R. v. Keshane
[1995 CanLII 4054 (SK C.A.)](http://www.canlii.org/en/sk/skca/doc/1995/1995canlii4054/1995canlii4054.html)
Y
-
N
warrantless search of a trunk of accused's car

R. v. D. (I.D.)
[1987 CanLII 206 (SK C.A.)](http://www.canlii.org/en/sk/skca/doc/1987/1987canlii206/1987canlii206.html)
Y
-
 ?
search of vehicle on spotting it stopped in ditch and detect smell of alcohol

### Smell of marijuana[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-5)]

Case s.8 s.9 s.24 Summary

R. v. Fierro, [2012 ABPC 1](http://canlii.ca/t/fpn4t)
N
N
N
detailed review of law

R. v. Grunwald, [2010 BCCA 288](http://www.canlii.org/en/bc/bcca/doc/2010/2010bcca288/2010bcca288.html)
N
N
N
traffic check set-up; stops accused's vehicle, smells marijuana, sees large bags in back of truck; no expectation of privacy

R. v. Harding, [2010 ABCA 180](http://www.canlii.org/en/ab/abca/doc/2010/2010abca180/2010abca180.html)
N
N
N
police stop car, obscured plates, rental car, two large bags in the back, smell marijuana -- search incident to arrest finds drugs -- no breach of s.10(b)

R. v. Pearson, [2009 ABQB 382](http://canlii.ca/t/245g7)
Y
-
N
breach found but evidence admitted

R. v. Hood, [2008 BCPC 217](http://www.canlii.org/en/bc/bcpc/doc/2008/2008bcpc217/2008bcpc217.html)
Y
?
Y

R. v. Rosa, [2008 ABQB 723](http://www.canlii.org/en/ab/abqb/doc/2008/2008abqb723/2008abqb723.html)

R. v. Webster, [2008 BCCA 458](http://canlii.ca/t/21ls8)
N
N
N

R. v. Favorite, [2008 CanLII 13364](http://canlii.ca/t/1wb3h)
N
N
N

R. v. Charles, [2007 CanLII 39760](http://canlii.ca/t/1t13k) (ON SC)
Y
?
Y

R. v. Huynh, [2005 ABPC 238](http://www.canlii.org/en/ab/abpc/doc/2005/2005abpc238/2005abpc238.html)
N
-
-
no s.8 breach found

R. v. Calderon, [2004 CanLII 7569](http://canlii.ca/t/1hpvs)
Y
Y
Y

R. v. Ladouceur, [2002 SKCA 73](http://canlii.ca/t/5k1p)
?
Y
Y

R. v. Sewell, [2003 SKCA 52](http://www.canlii.org/en/sk/skca/doc/2003/2003skca52/2003skca52.html)
N
-
-

R. v. Power, [2003 SKQB 334](http://canlii.ca/t/56v9)
N
N
N

R. v. Yan & Chan, [2002 BCPC 574](http://www.canlii.org/en/bc/bcpc/doc/2002/2002bcpc574/2002bcpc574.html)
Y
-
Y
pull over on basis of broad search for cat burglar; smells marijuana from car ; breach of s. 8 found -- evidence excluded

R. v. Duong, [2002 BCCA 43](http://www.canlii.org/en/bc/bcca/doc/2002/2002bcca43/2002bcca43.html)
N
no s.8 breach -- smell of marijuana coming out front door of house

R. v. Zagar, [1998 ABPC 59](http://www.canlii.org/en/ab/abpc/doc/1998/1998abpc59/1998abpc59.html)
Y
-
Y

R. v. Lawrence, [1994] O.J. No. 3272
N
N
N
smell fresh burnt marijuana; allowed search down pants of accused

R. v. Iturriaga, [1993 CanLII 2517](http://canlii.ca/t/1dblb) (BC CA)
Y
?
Y

## Informers/Tips[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-6)]

Case s.8 s.9 s.24 Summary

Hewlett v. R., [2012 CanLII 46405](http://canlii.ca/t/fsdd1) (NL SCTD)
N
-
N
search warrant

R. v. Gorman and Gorman, [2012 ONSC 4605](http://canlii.ca/t/fs99l)
N
-
N
search warrant

R v Franko, [2012 ABQB 282](http://canlii.ca/t/fr8f7)
N
-
N
confidential source reports drug dealers activities

R v Perpeluk, [2012 SKQB 189](http://canlii.ca/t/frdgx)
Y
-
Y
two confidential informers give tips

R. v. Quach, 2012 ABPC 57
N
N
N
evidence admitted, judge had no issue with motive of informer

R. v. Soto, [2011 ONCA 828](http://canlii.ca/t/fpf39)
N
N
N
informer reports dealing out of a house; police corroborate with observations of house

R. v. Bick, [2011 ONCJ 503](http://www.canlii.org/en/on/oncj/doc/2011/2011oncj503/2011oncj503.html)
N
N
N
search of house based on tip

R. v. Hillgardener, [2010 ABCA 80](http://www.canlii.org/en/ab/abca/doc/2010/2010abca80/2010abca80.html)
N
N
N
anonymous informer was reliable

R. v. Jir, [2010 BCCA 497](http://www.canlii.org/en/bc/bcca/doc/2010/2010bcca497/2010bcca497.html)
Y
N
N

R. v. Safi, [2010 ABCA 151](http://www.canlii.org/en/ab/abca/doc/2010/2010abca151/2010abca151.html)
N
N
N

R. v. Raphael, [2010] O.J. No. 5916, 2010 ONSC 5709
Y
Y
Y

Bjornson, [2009 BCSC 1779](http://www.canlii.org/en/bc/bcsc/doc/2009/2009bcsc1779/2009bcsc1779.html)
N
N
N

R. v. Tetreault, 2007 BCSC 1624
N
-
N

R. v. Wing, [2007 BCSC 1959](http://www.canlii.org/en/bc/bcsc/doc/2007/2007bcsc1959/2007bcsc1959.html)
Y
?
N

McCallum, [2006 SKQB 287](http://www.canlii.org/en/sk/skqb/doc/2006/2006skqb287/2006skqb287.html)
N
N
N

Goodine v. R., 2006 NBCA 109
N
?
N

R. v. Layton, 2006 BCPC 655
N
?
?

R. v. Murphy, [2006 CanLII 12417 (ON CA)](http://www.canlii.org/en/on/onca/doc/2006/2006canlii12417/2006canlii12417.html)
N
N
N
confidential informer gave sufficient details to form grounds of arrest

R. v. Bracchi, 2005 BCCA 461 [[17]](http://www.canlii.org/en/bc/bcca/doc/2005/2005bcca461/2005bcca461.html)
N
N
N

R. v. Campbell, 2003 MBCA 76 (CanLII) [[18]](http://www.canlii.org/en/mb/mbca/doc/2003/2003mbca76/2003mbca76.html)
Y
-
N

R. v. Myers, [2003 CanLII 36859 (ON SC)](http://www.canlii.org/en/on/onsc/doc/2003/2003canlii36859/2003canlii36859.html)
Y
N
N

R. v. Ungaro, [2003 BCPC 137](http://www.canlii.org/en/bc/bcpc/doc/2003/2003bcpc137/2003bcpc137.html)
Y
?
Y

R. v. Philpott [2002] O.J. No. 4872
search warrant

R. v. Jones, [2001 CanLII 28336 (ON SC)](http://www.canlii.org/en/on/onsc/doc/2001/2001canlii28336/2001canlii28336.html)
Y
-
Y
warrant to search apartment

R. v. Warford, [2001 NFCA 64](http://www.canlii.org/en/nl/nlca/doc/2001/2001nfca64/2001nfca64.html)
N
N
N

R. v. Lewis, [1998 CanLII 7116 (ON CA)](http://www.canlii.org/en/on/onca/doc/1998/1998canlii7116/1998canlii7116.html)
Y
-
N

R. v. Smellie, [1994 CanLII 1612 (BC CA)](http://www.canlii.org/en/bc/bcca/doc/1994/1994canlii1612/1994canlii1612.html)
N
N
N
multiple informers

R. v. Zammit, [1993 CanLII 3424 (ON CA)](http://www.canlii.org/en/on/onca/doc/1993/1993canlii3424/1993canlii3424.html)
Y
-
Y

R. v. Lamy, [1993 CanLII 3368 (MB CA)](http://www.canlii.org/en/mb/mbca/doc/1993/1993canlii3368/1993canlii3368.html)
Y
-
Y

R. v. Charlton, [1992 CanLII 367 (BC CA)](http://www.canlii.org/en/bc/bcca/doc/1992/1992canlii367/1992canlii367.html)
N
N
N

R. v. Cheecham, (1989) 51 C.C.C. (3d) 498
Y
?
Y

R. v. Pastro [1988 CanLII 214 (SK C.A.)](http://www.canlii.org/en/sk/skca/doc/1988/1988canlii214/1988canlii214.html)
Y
?
Y

## Search Incident to Arrest[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-7)]

Case s.8 s.9 s.24 Summary

R v Schira, [2011 SKPC 140](http://canlii.ca/t/fncbn)
Y
N
Y
breach of s.10(b) as well; contents of blackberry messages excluded

R. v. Ward, [2010 BCCA 1](http://www.canlii.org/en/bc/bcca/doc/2010/2010bcca1/2010bcca1.html)
Y
?
N
search incident to arrest -- found crack

R. v. Tosczak, [2010 SKCA 10](http://www.canlii.org/en/sk/skca/doc/2010/2010skca10/2010skca10.html)
N
?
N
pat-down search incident to arrest for possession of marijuana

R. v. Goodwin, [2009 ABQB 710](http://www.canlii.org/en/ab/abqb/doc/2009/2009abqb710/2009abqb710.html)
Y
?
?
arrest invalid

R. v. Chubak, [2009 ABCA 8](http://www.canlii.org/en/ab/abca/doc/2009/2009abca8/2009abca8.html)
?
?
?

R. v. Lamour, [2007 CanLII 15242 (ON S.C.)](http://www.canlii.org/en/on/onsc/doc/2007/2007canlii15242/2007canlii15242.html)
Y
?
N
arrested accused from impaired driving; did inventory search that included non-plain view items

R. v. Roberts, [2007 CanLII 39895 (ON S.C.)](http://www.canlii.org/en/on/onsc/doc/2007/2007canlii39895/2007canlii39895.html)
N
N
N
search vehicle incident to arrest for firearm lawful

R. v. Kitaitchik, [2002 CanLII 45000 (ON C.A.)](http://www.canlii.org/en/on/onca/doc/2002/2002canlii45000/2002canlii45000.html)
Y
?
N
warrantless seizure of clothing worn by accused in murder investigation

## Search of residence[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-8)]

Case s.8 s.9 s.24 Summary

R. v. Latham and Ryan, 2012 BCPC 78
Y
-
Y
warrantless search of basement apartment

R v Helary, 2012 SKPC 15
Y
?
Y

R v Laliberte, [2011 SKPC 190](http://www.canlii.org/en/sk/skpc/doc/2011/2011skpc190/2011skpc190.html)
Y
-
N
source info brings police to house; they are invited into vestibule; smell marijuana; enter into reminder of house after accused runs away. No consent to enter.

R. v. Got, [2011 BCPC 328](http://www.canlii.org/en/bc/bcpc/doc/2011/2011bcpc328/2011bcpc328.html)
Y
?
?
warrantless entry into residence found in violation of s.8

R. v. Stevens, 2011 ONCJ 794
Y
-
Y
police enter home without warrant and search house

R. v. Thompson, [2010 ONSC 2862](http://www.canlii.org/en/on/onsc/doc/2010/2010onsc2862/2010onsc2862.html)
Y
-
N
search of home found drugs

R. v. Watson, 2010 ONSC 448
Y
Y
pat-down search finds drugs; followed by search of residence

## Breath sample[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-9)]

See [Canadian_Criminal_Law/Appendix/Case_Law#Impaired_Driving](/wiki/Canadian_Criminal_Law/Appendix/Case_Law#Impaired_Driving)

## Cell phones[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-10)]

Case Summary

R. v. Mann, [2012 BCSC 1247](http://canlii.ca/t/fsdzc) (CanLII)

R. v. Munro & Munro, [2012 ONSC 43](http://canlii.ca/t/fphhc)
cell phone search indicent to arrest -- admitted

R. v. Groves, [2011 ONCJ 350](http://canlii.ca/t/fm7j4)

R. v. Dorey, [2011 NSPC 85](http://canlii.ca/t/fnvbd)

R. v. Hiscoe, [2011 NSPC 84](http://canlii.ca/t/fnv9d)

R. v. Manley, [2011 ONCA 128](http://canlii.ca/t/2fpgj)

R. v. Fearon, [2010 ONCJ 645](http://canlii.ca/t/2f869)

R. v. Zahrebelny, [2010 NSPC 91](http://canlii.ca/t/2ftfr)

R. v. Finnikin, [2009 CanLII 82187](http://canlii.ca/t/29jjs) (ON SC)

## Location Tracker[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrantless_Searches&action=edit&section=T-11)]

Case Summary

R. v. Bacon, [2012 BCCA 323](http://canlii.ca/t/fs5sn)
warrantless tracker violated s.8 but saved under 24(2)

  


# Cases/Warrant Searches[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Generally[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrant_Searches&action=edit&section=T-1)]

Case Citation s.8 s.24 Summary

R. v. Dowling
[2011 ABQB 790](http://www.canlii.org/en/ab/abqb/doc/2011/2011abqb790/2011abqb790.html)
N
N
search warrant of house with suspicious traffic

R. v. Mahmood
[2011 ONCA 693](http://www.canlii.org/en/on/onca/doc/2011/2011onca693/2011onca693.html)
N
-
warrant for cell phone number log upheld

R. v. Ngo
[2011 ONSC 6676](http://www.canlii.org/en/on/onsc/doc/2011/2011onsc6676/2011onsc6676.html)
N
-
search warrant upheld on s. 8 challenge

R. v. Lee
[2011 ABCA 310](http://www.canlii.org/en/ab/abca/doc/2011/2011abca310/2011abca310.html)
warrant to enter home upheld

R. v. Nguyen
[2011 ONCA 465](http://canlii.ca/t/flxb7)
search warrant challenged; no violation

R. v. Pike
[2010 NLTD 97](http://www.canlii.org/en/nl/nlsctd/doc/2010/2010nltd97/2010nltd97.html)
Y
?
secured blood samples prior to warrant being issued

R. v. Nguyen
[2002 BCPC 12](http://www.canlii.org/en/bc/bcpc/doc/2002/2002bcpc12/2002bcpc12.html)
N
-
search warrant executed to search house; police also searched parked car

R. v. Puskas
[1997 CanLII 1159](http://www.canlii.org/en/on/onca/doc/1997/1997canlii1159/1997canlii1159.html)
Y
N
Search warrant to house based on anonymous tip upheld trial level acquitted; overturned on issue of s.24(2) analysis

R. v. Nguyen and Nguyen
[2010 ONSC 1520](http://www.canlii.org/en/on/onsc/doc/2010/2010onsc1520/2010onsc1520.html)
Y
Y

R. v. Parasiris
[2008 QCCS 2460](http://www.canlii.org/en/qc/qccs/doc/2008/2008qccs2460/2008qccs2460.html)
Y
?

  * R. v. Watts, [2012 ONSC 1865](http://canlii.ca/t/fqpzk) \-- no s.8 violation—ITO search warrant for hard entry into house looking for guns and drugs—warrant based on confidential informer—contained errors—upheld
  * R. v. Darby, [2012 ABCA 27](http://canlii.ca/t/fps2j) || ITO upheld anonymous informer
  * R. v. Dionisi, [2012 ABCA 20](http://canlii.ca/t/fprmp) || ITO upheld, based on anonymous informer
  * R. v. Morgan, [2012 ONCA 28](http://canlii.ca/t/fpmhg) \-- ITO found valid despite errors in affidavit

## Tele-warrants[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrant_Searches&action=edit&section=T-2)]

  * R v Lendzion [2012 ABPC 59](http://canlii.ca/t/fqr7j) \-- upheld

## Wire taps[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrant_Searches&action=edit&section=T-3)]

R. v Bulatci, 2012 NWTCA 6 -- wiretap of accused in prison violated s.8 but admissible

  * R. v. Martin, 2010 NBCA 41 [[19]](http://www.canlii.org/en/nb/nbca/doc/2010/2010nbca41/2010nbca41.html) || breach of s.8 found, evidence NOT excluded under s. 24(2)
  * R. v. Della Penna, [2012 BCCA 3](http://canlii.ca/t/fpl3t) || wiretap allowed on appeal

## Bodily sample[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrant_Searches&action=edit&section=T-4)]

  * R. v. Ramage, [2010 ONCA 488](http://www.canlii.org/en/on/onca/doc/2010/2010onca488/2010onca488.html) \-- breach s. 8; saved under s.24(2)
  * R. v. Emshey, [2010 ABPC 237](http://www.canlii.org/en/ab/abpc/doc/2010/2010abpc237/2010abpc237.html) \-- s.8 violation; admitted under s.24(2)

## Computers[[edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Cases/Warrant_Searches&action=edit&section=T-5)]

  * R v Spencer, [2011 SKCA 144](http://canlii.ca/t/fp3pb) \-- search warrant for ISP information upheld
  * R v Trapp, [2011 SKCA 143](http://canlii.ca/t/fp3n3) \-- search warrant for ISP seeking account info attached to IP address upheld
  * R. v. Lo, [2011 ONSC 6532](http://canlii.ca/t/fnpzl) \-- no s.8 violation—production order by police was validly granted for login records of Facebook account
  * A search warrant authorizing a search for "records and documentation" can include materials found on a cell phone and desktop computer.(see R. v. Vu, [2011 BCCA 536](http://canlii.ca/t/fpfws))
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&oldid=2395611](http://en.wikibooks.org/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&oldid=2395611)" 

[Categories](/wiki/Special:Categories): 

  * [Canadian Criminal Procedure and Practice](/wiki/Category:Canadian_Criminal_Procedure_and_Practice)
  * [Criminal Case Digests](/wiki/Category:Criminal_Case_Digests)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Canadian+Criminal+Procedure+and+Practice%2FSearch+and+Seizure%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Canadian+Criminal+Procedure+and+Practice%2FSearch+and+Seizure%2FPrint+version)

### Namespaces

  * [Book](/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version)
  * [Discussion](/w/index.php?title=Talk:Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=edit)
  * [View history](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&oldid=2395611)
  * [Page information](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Canadian_Criminal_Procedure_and_Practice%2FSearch_and_Seizure%2FPrint_version&id=2395611)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Canadian+Criminal+Procedure+and+Practice%2FSearch+and+Seizure%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Canadian+Criminal+Procedure+and+Practice%2FSearch+and+Seizure%2FPrint+version&oldid=2395611&writer=rl)
  * [Printable version](/w/index.php?title=Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version&printable=yes)

  * This page was last modified on 18 August 2012, at 17:17.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Canadian_Criminal_Procedure_and_Practice/Search_and_Seizure/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
