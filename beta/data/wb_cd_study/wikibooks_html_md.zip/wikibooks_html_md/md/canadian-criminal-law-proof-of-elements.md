# Canadian Criminal Law/Proof of Elements/Print version

From Wikibooks, open books for an open world

< [Canadian Criminal Law](/wiki/Canadian_Criminal_Law) | [Proof of Elements](/wiki/Canadian_Criminal_Law/Proof_of_Elements)

Jump to: navigation, search

## Contents

  * 1 _Proof of Offences_
    * 1.1 General
    * 1.2 Eyewitness identification
      * 1.2.1 Weighing Identity Evidence
      * 1.2.2 Line-ups
      * 1.2.3 Video identification
      * 1.2.4 Docket identification
    * 1.3 Recognition
    * 1.4 See Also
    * 1.5 Introduction
    * 1.6 Jurisdiction
    * 1.7 Time
    * 1.8 Intent
    * 1.9 Knowledge
      * 1.9.1 Wilful Blindness
    * 1.10 Introduction
    * 1.11 Interpretation of Possession
      * 1.11.1 Actual/Personal Possession
      * 1.11.2 Constructive Possession
      * 1.11.3 Joint Possession
      * 1.11.4 Innocent Possession
    * 1.12 Elements
      * 1.12.1 Knowledge
      * 1.12.2 Consent and Intent
      * 1.12.3 Control
    * 1.13 Specific scenarios
      * 1.13.1 Items found in a Vehicle
      * 1.13.2 Items Found in a Residence
      * 1.13.3 Other
    * 1.14 See Also
    * 1.15 Proof of Ownership
    * 1.16 Case Digests
    * 1.17 Introduction
    * 1.18 Duty of Care
    * 1.19 Standard of Care
    * 1.20 General Principles
    * 1.21 Offences where causation is an essential element
    * 1.22 Causation in Homicide
      * 1.22.1 Intervening Acts
    * 1.23 See Also
    * 1.24 Introduction
    * 1.25 Proof of Criminal Organization
    * 1.26 Effect
    * 1.27 See Also
    * 1.28 References
    * 1.29 General Principles
    * 1.30 Bodily Harm
    * 1.31 Aggravated Assault
    * 1.32 General Principles
    * 1.33 Offer to Sell
    * 1.34 Opinion Evidence on Trafficking
    * 1.35 Evidence of Intent
    * 1.36 Dial-a-Dope operations
    * 1.37 See Also
  * 2 _Doctrines of Liability_
    * 2.1 Generally
      * 2.1.1 Section 21(1)(a): Commits
      * 2.1.2 Section 21(1)(b), (c): Aiding and Abetting
      * 2.1.3 Section 21(2): Common Intention
    * 2.2 Counselling (s.22)
      * 2.2.1 Where offence is not committed
    * 2.3 Organizations as Parties
    * 2.4 Cases on Parties
    * 2.5 See Also
    * 2.6 Generally
    * 2.7 Cases
    * 2.8 Lesser included offences
    * 2.9 Examples
    * 2.10 References
    * 2.11 General Principles
    * 2.12 Legislation
    * 2.13 Proof of the Offence
    * 2.14 Principles
      * 2.14.1 Agreement
      * 2.14.2 Participation
      * 2.14.3 Evidence
    * 2.15 See Also
    * 2.16 References
  * 3 Interpretation
    * 3.1 Principles of Statutory Interpretation
    * 3.2 Charter Interpretation
    * 3.3 Amendments
      * 3.3.1 Meaning
      * 3.3.2 Effect on Previous Ongoing Proceedings
    * 3.4 Stare Decisis
    * 3.5 Ratio Decidendi and Obiter
    * 3.6 See Also
  * 4 Offence Chart
    * 4.1 Violence-related offences
    * 4.2 Theft-related offences
    * 4.3 Property damage Offences
    * 4.4 Break and Enter
    * 4.5 Robbery
    * 4.6 Weapons Offences
    * 4.7 Sexual Offences
    * 4.8 Motor Vehicle Offences
    * 4.9 Administration of Justice Offences
    * 4.10 Controlled Substances Offences
    * 4.11 Key
    * 4.12 Jurisdiction
    * 4.13 DNA Orders s. 487.051
    * 4.14 SOIRA Orders
    * 4.15 Driving Prohibition
  * 5 Motions Chart
  * 6 Re-Election Chart

# _Proof of Offences_[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit&section=1)]

## General[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-1)]

Identity of the accused person is always a required element to be proven for a given offence. As with all essential elements, it must be proven beyond a reasonable doubt.

It can be proven by way of the following methods, none of which are necessarily determinative:

  * an eye-witness who IDs the accused as person seen committing the offence
  * exclusive opportunity
  * security system photographs/video
  * voice identification
  * finger prints
  * foot prints
  * DNA

## Eyewitness identification[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-2)]

Courts are very cautious of eyewitness evidence as it is considered “inherently unreliable”[1] as there are “dangers inherent in eyewitness testimony”.[2] It is “well-established” that the frailties of eyewitness identification has “lead to wrongful convictions, even in cases where multiple witnesses have identified the same accused”[3] Even honest witnesses may misidentify individuals.[4] Consequently, identification evidence is treated differently than other evidence and special care and caution should be taken. [5] Judges are required to given special cautions when considering identification evidence.[6] This includes instructing himself and bearing in mind the guidelines when considering evidence of identification.[7]

A court of appeal "will be subject findings [on identity] to closer scrutiny than is generally the case with findings of fact”. [8]

  1. ↑ R v Goran, [2008 ONCA 195 <http://canlii.ca/t/1w6gw>], [2008] OJ No. 1069 (ONCA) at 19
  2. ↑ R v Miaponoose [1996 CanLII 1268](http://canlii.ca/t/6hz0) (ONCA), (1996), 30 O.R. (3d) 419 at p.421
  3. ↑ R v FA [2004 CanLII 10491](http://canlii.ca/t/1grgd) (ONCA) at para 39
  4. ↑ R. v. Quercia [1990 CanLII 2595](http://canlii.ca/t/1npnc) (ONCA) at 389
  5. ↑ e.g., R. v. Trochym, [2007 SCC 6](http://canlii.ca/t/1qbvh) [2007] S.C.J. No. 6, at para. 46;  
R. v. Burke, [1996 CanLII 229](http://canlii.ca/t/1frb7), [1996] S.C.J. No. 27, at para. 52;  
R. v. Spatola, [1970] 3 O.R. 74 (C.A.), at 82,  
R. v. Miaponoose [1996 CanLII 1268](http://canlii.ca/t/6hz0) (ON CA), (1996), 110 C.C.C. (3d) 445 (Ont. C.A), at 450-1;  
R. v. Tat and Long [1997 CanLII 2234](http://canlii.ca/t/6hgr) (ON CA), (1997), 117 C.C.C. (3d) 481 (Ont. C.A.), at 516;  
R. v. F.A., [2004 CanLII 10491](http://canlii.ca/t/1grgd) [2004] O.J. No. 1119, at para. 39 (C.A.)
  6. ↑ R. v. Hersi, [2000 CanLII 16911](http://canlii.ca/t/1fbdr), [2000] O.J. No. 3995 (C.A.) at para. 14  
R. v. Tat [1997 CanLII 2234](http://canlii.ca/t/6hgr) (ON CA), (1997), 117 C.C.C. (3d) 481 (Ont. C.A.), at pp. 515-16
  7. ↑ R. v. Turnbull et al (1976), 63 Cr. App. R. 132  
see also:  
R. v. Sophonov (No.2), [1996 CanLII 104](http://canlii.ca/t/1npjz), (1986), 25 C.C.C. (3d) 415 (Man. C.A.)  
R. v. Shermetta, [1995 CanLII 4193](http://canlii.ca/t/1mpx1) [1995] N.S.J. No. 195 (C.A.),  
R. v. Atwell (1983), 25 Alta. L.R. (2d) 97 (Alta. C.A.)  
R. v. Nikolovski [1996 CanLII 158](http://canlii.ca/t/1fr59), (1996), 111 C.C.C. (3d) 403 (S.C.C.)  

  8. ↑ R v Goran [2008 ONCA 195 <http://canlii.ca/t/1w6gw>] at para. 20  
R. v. Harvey [2001 CanLII 24137](http://canlii.ca/t/1f3k6) (ON CA), (2001), 160 C.C.C. (3d) 52 (Ont. C.A.), at para. 19

### Weighing Identity Evidence[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-3)]

Bald assertions of identity by witnesses should be given little weight. The court should consider the foundation of the statement including the opportunity and ability to observe. [1]

It has been recommended that cases resting entirely on eyewitness testimony should require the judge to do the following: [2]

  1. recognize the danger of convicting based on eyewitness identification only;
  2. note the significant factors which may have affected the identification; and
  3. address those factors.

It is "incumbent upon Crown counsel to ensure that all relevant circumstances surrounding pretrial eyewitness identification procedures be fully disclosed to the defence and be made available for scrutiny by the trier of fact."[3]

The fundamental factors affecting the weight of eyewitness evidence are: [4]

  1. opportunity to observe
  2. light conditions
  3. the distance from the witness to the suspect
  4. the eyesight of the witness
  5. colour perception
  6. previous acquaintance with the accused
  7. focus of attention or distraction
  8. presence or absence of distinctive features or appearance of the suspect/accused

Extra caution should be taken where the witnesses had a limited opportunity to observe and the confirmative opportunity occurred while the accused was under arrest.[5]

Absent supporting evidence, a judge cannot say that stress upon the witness is a neutral factor in accuracy of observations.[6]

  1. ↑ R. v. Tatham [2002 MBQB 241](http://canlii.ca/t/5jch), [2002] M. J. No. 370, 167 Man. R. (2d) 152 at 9
  2. ↑ R. v. Bigsky, [2006 SKCA 145](http://canlii.ca/t/1qfkn), 217 C.C.C. (3d) 441, at para. 70
  3. ↑ R v Miaponoose [1996 CanLII 1268](http://canlii.ca/t/6hz0) (ON CA)
  4. ↑ R. v. Wilband, [2011 ABPC 298](http://canlii.ca/t/fp2x4) at [para 16](http://canlii.org/en/ab/abpc/doc/2011/2011abpc298/2011abpc298.html#par16)  
R v Miaponoose [1996 CanLII 1268](http://canlii.ca/t/6hz0) (ON CA)  
Mezzo v. The Queen, [1986 CanLII 16](http://canlii.ca/t/1ftrq) (SCC), [1986] 1 SCR 802 at 24  

  5. ↑ R. v. Hume, [2011 ONCJ 535](http://canlii.ca/t/fnnnx) (CanLII) at 14  
R. v. Smierciak (1946), 87 C.C.C. 175 (Ont. C.A.)
  6. ↑ R. v. Francis, [2002 CanLII 41495](http://canlii.ca/t/1ck6q) (ON CA)

### Line-ups[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-4)]

The key rule in giving a photo line-up is that the procedure is fair.[1]

It was recommended in the Sophonow Inquiry that in order to avoid false identification through line-ups the procedure should include the following:[2]

  * The photo pack should contain at least 10 subjects.
  * The photos should resemble as closely as possible the eyewitnesses' description. If that is not possible, the photos should be as close as possible to the suspect.
  * Everything should be recorded on videotape, or failing that, audiotape. In addition, or as a minimum alternative, all comments of the witness should be recorded verbatim on the form accompanying the line-up and signed by both the officer and the witness.
  * The line-up should be presented by an officer who is not involved in the investigation and does not know who the suspect is.
  * The officer showing the line-up should advise the witness that he does not know who the suspect is or whether there is a suspect in the line-up. The officer should also tell the witness that it is just as important to clear the innocent as it is to identify the subject.
  * The photopack should be presented sequentially, not all together.
  * Police officers should not speak to the witness after the line-up regarding his ability or inability to identify anyone.

Several cases have adopted these requirements or something similar.[3]

Other factors considered include:

  * evidence of distinguishing features linking the accused and the perpetrator identified by the line-up photograph. [4]
  * opportunity for the witnesses to see the perpetrator;
  * familiarity with the accused prior to court;

The Sophonow guidelines for line-ups are not legally binding and so failure to follow them will not necessarily be fatal to the identification evidence.[5]

The prior familiarity of the witness to the accused is a factor that goes to weight.[6]

  


  1. ↑ R. v. Shermetta (1995), 141 N.S.R. (2nd) 186 - leading case on procedure in NS
  2. ↑ Peter deCory, The Inquiry Regarding Thomas Sophonow: The Investigation, Prosecution and Entitlement to Compensation at pp. 31-34 (2001))
  3. ↑ R. v. MacKenzie, [2003 NSPC 51](http://www.canlii.org/en/ns/nspc/doc/2003/2003nspc51/2003nspc51.html)
  4. ↑ e.g. R. v. Smith (1952), 103 C.C.C. 58 (Ont. C.A.)
  5. ↑ R v Doyle, [2007 BCCA 587](http://canlii.ca/t/1txxl) at 10 to 15  
R. v. Gonsalves 2008 CanLII 17559 (ON SC), (2008), 56 C.R. (6th) 379, [2008] O.J. No. 2711 (Ont. Sup. Ct.), at paras. 44, 45 and 53  
R. v. Le, 2011 MBCA 83, 270 Man. R. (2d) 82, at paras. 132 to 135  

  6. ↑ See R. v. Cachia (1953), 107 C.C.C. 272 (Ont. C.A.)  
R. v. Todish, (1985), 18 C.C.C. (3d) 159 (Ont. C.A.)  
R. v. Leaney 1987 ABCA 206 (CanLII), (1987), 38 C.C.C. (3d) 263

### Video identification[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-5)]

A witness can testify to the contents of a video establishing identity of the accused without showing the video. It is generally considered akin to actual observations. [1]

A witness who is familiar with the appearance and idiosyncrasies of the accused that is not apparent to the trier of fact, may testify to identity where the witness can 1) state the particularities of the idiosyncrasies; and 2) can show where the idiosyncrasies are revealed on the video.[2] A voir dire must be held to determine whether the person, such as a police officer, can testify to the likeness of the video image to the suspect.[3]

A person who is not familiar with the appearance of the accused cannot testify on identification of the accused in a video.[4]

  1. ↑ Taylor v. Chief Constable of Cheshire (1987) 84 Cr. App. R. 191
  2. ↑ R. v. Leaney [1987 ABCA 206](http://canlii.ca/t/2dkv9) (CanLII), (1987) 38 CCC 263 Alta. C.A.
  3. ↑ R. v. Briand, [2008 ONCJ 777](http://www.canlii.org/en/on/oncj/doc/2008/2008oncj777/2008oncj777.html)
  4. ↑ R. v. Leaney, [1989 CanLII 28](http://canlii.ca/t/1ft3h), [1989] 2 S.C.R. 393

### Docket identification[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-6)]

Identification of an accused in the docket is generally undesirable and unsatisfactory, and so adds very little weight to the proof of identity.[1]

  1. ↑ F.A., [2004 CanLII 10491](http://canlii.ca/t/1grgd) at para. 47  
R. v. Izzard, (1990), 54 C.C.C. (3d) 252 (Ont. C.A.), at pp. 255-6

## Recognition[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-7)]

Courts have generally made a distinction between identity evidence and recognition evidence. The difference being that identity involves a witness matching a previously observed stranger with that of the accused. Recognition is where the observer knew the person being observed and the issue is not simply identifying a person by description, but rather recognizing the person through their acquaintanceship.

Recognition, however, is not a distinct category from identification.[1] Rather they are at different points on a spectrum of reliability.[2]

In admitting recognition evidence, there must be sufficient indicia for a threshold degree of familiarity which depends on[3]

  1. the length of the prior relationship between the witness and the accused;
  2. the circumstances of the prior relationship between the witness and the accused; and,
  3. the recency of the contact between the witness and the accused prior to the event where the witness recognized the accused.

These indicia go to the weight of the evidence along with "the cumulative effect of recognition evidence provided by more than one witness and the circumstances under which the witness recognized the accused."[4]

Before a person can claim to recognize a person they must establish that they had a prior opportunity to personally observe the accused and become acquaintenced with him.[5]

Recognition simply means that "the witness's evidence is based in part on his or her dealings with the accused before the crimes were committed"[6]

Recognition evidence is considered more reliable and has more weight than identification evidence.[7]

Resemblance without anything more is not sufficient to establish identification. Other inculpatory evidence is needed.[8]

  1. ↑ R v Smith 2011 BCCA 362
  2. ↑ R. v. Mclsaac, [1991] B.C.J. No. 3617 (C.A.)
  3. ↑ R. v. Anderson et al., [2005 BCSC 1346](http://canlii.ca/t/1p7jd) (CanLII) at paras. 20 and 25-26 (S.C.)
  4. ↑ Anderson at para. 25
  5. ↑ R. v. P.T.C., 2000 BCSC 342 (CanLII)at para. 22, 67
  6. ↑ R v Smith 2011 BCCA 362
  7. ↑ R. v. Bob (C.C.), [2008 BCCA 485](http://canlii.ca/t/22078), 263 B.C.A.C. 42 at para. 13  
R. v. Aburto (M.E.), [2008 BCCA 78](http://canlii.ca/t/1vsdx) at para. 22  
R. v. Affleck (A.), [2007 MBQB 107](http://canlii.ca/t/1vkmt)  
R. v. R.R.I., [2012 MBQB 59](http://canlii.ca/t/fqncg)  

  8. ↑ R. v. Rybak [2008 ONCA 354 at para. 121](http://canlii.ca/t/1wsq6#par121)

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Identity&action=edit&section=T-8)]

  * [Canadian Criminal Law/Cases/Identity](/wiki/Canadian_Criminal_Law/Cases/Identity)

## Introduction[[edit](/w/index.php?title=Canadian_Criminal_Law/Jurisdiction_and_Time&action=edit&section=T-1)]

The elements of jurisdiction and time are essential elements for _all_ offences that must be proven beyond a reasonable doubt. While they are usually trivial to the case as a whole, they are still necessary in any case.

These elements establish that the court has both geographic and temporal authority over the matter and that the evidence is specific enough to meet the described offence found in the charging document--the information or indictment.

## Jurisdiction[[edit](/w/index.php?title=Canadian_Criminal_Law/Jurisdiction_and_Time&action=edit&section=T-2)]

The charging document will state a geographic region in which the alleged offence is to said to have been committed. For the court to be convinced beyond a reasonable doubt that it has authority over the matter, there must be evidence establishing that the offence alleged "occurred" in a specific county/region and province.

In a simple case, this can be accomplished by having the eye-witness to the offence or the investigating officer testify to their presence in the county, region, and province at the time of their investigations or observations.

See: [Canadian Criminal Procedure and Practice/Jurisdiction and Election#Jurisdiction](/wiki/Canadian_Criminal_Procedure_and_Practice/Jurisdiction_and_Election#Jurisdiction)

## Time[[edit](/w/index.php?title=Canadian_Criminal_Law/Jurisdiction_and_Time&action=edit&section=T-3)]

The charging document will state a specific date or range of dates in which the offence is said to have occurred. For the court to be convinced beyond a reasonable doubt that the offence occurred within the specific date(s), there must be evidence establishing the date. Since the charging documents never get so specific as mentioning the actual time, in terms of hours and minutes, of the alleged offence, it is not required to be that specific.

In a simple case, this can be accomplished by having the eye-witness to the offence or the investigating officer testify to the date and time of their investigations or observations.

## Intent[[edit](/w/index.php?title=Canadian_Criminal_Law/Intent_and_Knowledge&action=edit&section=T-1)]

"Intent" refers to the mental state of the individual consisting of the desire or purpose to achieve a particular consequence, or where the consequences the person sees as certain, "substantially", or "practically" certain.[1]

Intent is often proven by way of inference.

Inferences are factual findings based on common sense.[2]

There is the long-standing inference that a person intends the natural consequences of one’s actions applies to many situations.[3]

The inference will be made in most any circumstances except where there may be evidence to the contrary. Doubt may be raised as to the specific intent of the person where they suffer from mental illness or where intoxicated.[4]

Generally speaking, the inference requires the assumption that the accused has the capacity to form intent.[5]

The presence of the word "wilfully" in an provision for an criminal code offence "generally signals a subjective mens rea requirement, but the appropriate meaning of the term ‘wilfully’ will depend on the context in which it is found."[6] In context of a probation order, "wilful" denotes "a legislative concern for a relatively high level of mens rea" that requires a intent to breach and have a purpose in doing so.[7]

  1. ↑ R. v. W.(A.), [2012 ONCJ 472](http://canlii.ca/t/fs4dz) (CanLII) includes a very detailed consideration of the history of intent
  2. ↑ see R. v. Daley, [2007 SCC 53](http://canlii.ca/t/1v5dr) at paras 103 and 104; R v EB [2006] OJ No 1864 aff'd at [2011 ONCA 194](http://canlii.ca/t/fkgld), at para 66 (context of murder)
  3. ↑ R. v. Missions, [2005 NSCA 82 at 21](http://canlii.org/en/ns/nsca/doc/2005/2005nsca82/2005nsca82.html#par21)  
R. v. Starratt (1971), 5 C.C.C. (2d) 32 (ONCA) at para 3  
See R. v. Giannotti (1956), 115 C.C.C. 203 (Ont. C.A.)  
R. v. Hilson (1958), 121 C.C.C. 139 (Ont. C.A.)  
R. v. Berger (1975), 27 C.C.C. (2d) 357 (B.C.C.A.), leave to appeal to S.C.C. refused [1975] S.C.R. vii  
R. v. Borque, [1969] 4 C.C.C. 358, 7 C.R.N.S. 189 (B.C.C.A.)  
R. v. Theroux, [1993] S.C.J. No. 42, [1993 CanLII 134](http://canlii.ca/t/1fs40) (SCC), [1993] 2 SCR 5,79 C.C.C. (3d) 449 at 458 per McLachlin J.  
R. v Gill, 2012 ONCJ 326 (Ont. C.J.), per Ready J.  

  4. ↑ R v Robinson, [2010 BCSC 368](http://canlii.ca/t/28rlb) at para 107 cited in R v Damin, [2011 BCSC 723](http://canlii.ca/t/flq2w) at para 33  
R v McConnell, [2012 ABQB 263](http://canlii.ca/t/fr25r)
  5. ↑ See R. v. Bird (1973), 13 C.C.C. (2d) 73 (Sask C.A.)
  6. ↑ R. v. A.D.H., [2011] S.J. No. 5 (C.A.)
  7. ↑ R v Docherty, 1989 CanLII 45 (SCC), [1989] 2 SCR 941 at para. 13

## Knowledge[[edit](/w/index.php?title=Canadian_Criminal_Law/Intent_and_Knowledge&action=edit&section=T-2)]

### Wilful Blindness[[edit](/w/index.php?title=Canadian_Criminal_Law/Intent_and_Knowledge&action=edit&section=T-3)]

Wilful blindness refers to the accused's state of mind. The doctrine attributes "knowledge to a party whose strong suspicions have been aroused but who refrains from making inquiries to have those suspicions confirmed. The doctrine serves to override attempts to self-immunize against criminal liability by deliberately refusing to acquire actual knowledge."[1]

It is not enough that there be a suspicion in the mind of the accused. Rather, the accused must have "virtually knew the critical fact, and intentionally declined to secure that knowledge."[2]

The determination inquires into whether "the accused shut his ... eyes because he .. knew or strongly suspected that looking would fix him ... with knowledge?”[3]

The doctrine is not premised on "what a reasonable person would have done, but requires a finding that the accused, with actual suspicion, deliberately refrained from making inquiries because he or she did not want his or her suspicions confirmed."[4] To put it another way, it is not a form of "constructive knowledge" by way of a standard of reasonableness..[5]

Where wilful blindness is established, "the knowledge imputed is the equivalent of actual, subjective knowledge." [6]

In certain circumstances, "where an accused made some or basic inquiries, but still harboured suspicions, it remains open to the trier of fact to find wilful blindness".[7]

  1. ↑ R. v. Briscoe, [2008 ABCA 327](http://canlii.ca/t/20x54) (CanLII) at para. 19
  2. ↑ Briscoe at para. 20  
c.f. R. v. Lagace 2003 CanLII 30886 (ON CA), (2003), 181 C.C.C. (3d) 12 (Ont. C.A.), at paras. 25-6 There must be “a real suspicion” causing the need for further inquiry
  3. ↑ R v Jorgensen, 1995 CanLII 85 (SCC), [1995] 4 S.C.R. 55 at para. 103
  4. ↑ Briscoe at para. 21
  5. ↑ R. v. Callejas, 2011 ONCA 393 (CanLII), at para. 8  
R. v. Laronde, 2010 BCCA 430 (CanLII), at paras. 28-35  
R. v. Smith, 2008 ONCA 101 (CanLII), at paras. 5-6  
R. v. Malfara, [2006] O.J. No. 2069 (C.A.) at para. 2 (“Where wilful blindness is in issue, the question is not whether the accused should have been suspicious, but whether the accused was in fact suspicious”)  

  6. ↑ Briscoe at para. 21
  7. ↑ R. v. Rashidi-Alvije, [2007 ONCA 712](http://canlii.ca/t/1tbq6) (CanLII), at para. 24  
Lagace, [2003 CanLII 30886](http://canlii.ca/t/1q3) (ON CA) at paras. 27-29  
Niemi, [2006 CanLII 13949](http://canlii.ca/t/1n543) (ON CA) at para. 77

## Introduction[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-1)]

There are three types of possession:[1]

  * personal / actual possession
  * constructive possession
  * joint possession

Possession can be proven through both direct or circumstantial evidence.[2]

These forms of possession are outlined in s.4 of the Criminal Code.

> **Possession**  
4\. (3) For the purposes of this Act,
> 
>     (a) a person has anything in possession when he has it in his personal possession or knowingly 
> 
>     (i) has it in the actual possession or custody of another person, or
>     (ii) has it in any place, whether or not that place belongs to or is occupied by him, for the use or benefit of himself or of another person; and
>     (b) where one of two or more persons, with the knowledge and consent of the rest, has anything in his custody or possession, it shall be deemed to be in the custody and possession of each and all of them.
> 
> – [CCC](http://canlii.ca/t/7vf2#sec4)

Possession under s. 2 the Controlled Drugs and Substances Act adopts the same definition as the Criminal Code:

> **Definitions**  
2\. (1) In this Act,  
...  
**“possession”**  
“possession” means possession within the meaning of subsection 4(3) of the Criminal Code;
> 
> – [CCC](http://www.canlii.org/en/ca/laws/stat/sc-1996-c-19/latest/sc-1996-c-19.html#sec2)

At common law, possession requires control[3] as well as knowledge[4].

Likewise, the statutory requirements of s.4(3), require that the totality of evidence establish beyond a reasonable doubt that the accused had knowledge and control.[5]

  


  1. ↑ R v. Anderson [1995] 29 W.C.B. (2d) 357 (B.C.C.A)
  2. ↑ Warner v. Metropolitan Police Commissioner (1968), 52 Cr. App. R. 373 (H.L.)
  3. ↑ R v Terrance 1982 1 SCR 357
  4. ↑ R v Kocsis 2001 157 CCC 3d 564 (ONCA)
  5. ↑ R. v. Anderson (1995), 67 B.C.A.C. 311>  
R. v. Fisher, 2005 BCCA 444  


  


## Interpretation of Possession[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-2)]

### Actual/Personal Possession[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-3)]

“Personal possession” requires that “the accused must be aware that he or she has physical custody of the thing in question, and must be aware as well of what that thing is. Both elements must co-exist with an act of control (outside of public duty)”[1] Thus, actual/Personal possession requires that:[2]

  1. there be an actual physical custody of the object
  2. a knowledge of the nature of the object while with custody.[3]

  


### Constructive Possession[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-4)]

Constructive possession requires the following:[4]

  1. _knowledge_ of the item
  2. _intent/consent_ to have possession of the item
  3. _control_ over the item

The crown must prove knowledge extending beyond "quiescent knowledge" that discloses some degree of control of the item[5]

Possession can still be established even if it considered the property of some third party.[6]

Constructive possession of drugs found in a suite or house can be established where the accused is shown to have control over a property searched and knowledge that the items were in the place.[7] Even where the accused did not have exclusive control over the place, he can still be found in joint possession of the items.[8]

  1. ↑ R. v. Beaver, 1957 CanLII 14 (SCC), [1957] S.C.R. 531 at pp. 541-42  
R. v. Morelli, 2010 SCC 8 (CanLII), 2010 SCC 8, [2010] 1 S.C.R. 253 at para. 16
  2. ↑ R. v. Franks (G.G.), [2003] S.J. No. 455; 238 Sask.R. 1; 305 W.A.C. 1 (C.A.)
  3. ↑ R. v. Beaver (1957), 118 C.C.C. 129 (S.C.C.)[1957 CanLII 14](http://www.canlii.org/en/ca/scc/doc/1957/1957canlii14/1957canlii14.html)
  4. ↑ R v Kocsis, [2001 CanLII 3593](http://canlii.ca/t/1fbwt) (ONCA), (2001), 157 C.C.C. (3d) 564
  5. ↑ R. v. Pham 2005 CanLII 44671 (ON CA), (2005), 36 C.R. (6th) 200 (affirmed by the Supreme Court of Canada, 2006 SCC 26 (CanLII), [2006] 1 S.C.R. 940)
  6. ↑ R v Pham
  7. ↑ R. v. Basarowich (C.J.), 2010 MBQB 4 (CanLII), 2010 MBQB 4, 249 Man.R. (2d) 64 at para. 10
  8. ↑ R v Basarowich, para. 11

### Joint Possession[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-5)]

Joint possession amounts to a form of possession wherein multiple people can be deemed to be in possession or custody of the object. To establish joint possession there must be:

  1. knowledge of the object,
  2. consent of the accused,
  3. and a degree of control over it[1]

### Innocent Possession[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-6)]

There is some suggestion that where the sole intent at all times of possession is to destroy or removing the accused's control over the contraband is not criminal.[2]

  


  1. ↑ R. v. Terrence [1983] 1 SCR 357 [[1]](http://www.canlii.org/en/ca/scc/doc/1983/1983canlii51/1983canlii51.html);  
R. v. Williams, 1998 CanLII 2557 (ON C.A.) [[2]](http://www.canlii.org/en/on/onca/doc/1998/1998canlii2557/1998canlii2557.html);  
R. v. Pham 2005 CanLII 44671, (2005), O.R. (3d) 401, 203 C.C.C. (3d) 326 (Ont.C.A.) at paras. 15-17 [[3]](http://www.canlii.org/en/on/onca/doc/2005/2005canlii44671/2005canlii44671.html);  
R. v. Bjornson, 2009 BCSC 1780 at para. 18 [[4]](http://www.canlii.org/en/bc/bcsc/doc/2009/2009bcsc1780/2009bcsc1780.html);  
R. v. Quach, 2008 SKPC 62 [[5]](http://www.canlii.org/en/sk/skpc/doc/2008/2008skpc62/2008skpc62.html)  
R. v. Franks, [2003] S.J. No. 455  
Re Chambers and The Queen, 1985 CanLII 169 (ON C.A.) [[6]](http://www.canlii.org/en/on/onca/doc/1985/1985canlii169/1985canlii169.html)  

  2. ↑ R. v. Glushek (1978), 41 C.C.C. (2d) 380 (Alta. S.C. App. Div.)  
R. v. Christie (1978), 41 C.C.C. (2d) 282 (N.B. S.C. App. Div.)  
R. v. York 2005 BCCA 74 (CanLII), (2005), 193 C.C.C. (3d) 331 (B.C.C.A.)  
See also R. v. Loukas, [2006] O.J. No. 2405 (Ont. C.J.)

## Elements[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-7)]

Proof of possession cannot be established by looking at the evidence individually, but rather the court must look at the evidence as a whole.[1]

The onus remains on the crown throughout. Even where the evidence "cries out for an explanation by the accused", it will simply create an evidential onus or even create a prima facie case, however, it will not require the accused to testify or prohibit from arguing that the crown failed to prove the element.[2]

  1. ↑ R. v. Brar (G.), 2008 MBQB 133 (CanLII), 2008 MBQB 133, 234 Man.R. (2d) 1 at para. 37, 38
  2. ↑ R v Brar, 2008 MBQB 133 at para. 38

### Knowledge[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-8)]

There cannot be possession without knowledge of the nature of the object.[1] Knowledge requires that an accused have knowledge of “the criminal character of the item in issue”[2] It must be proven beyond mere “quiescent knowledge” that disclosed some degree of control over the items in question.[3]

Knowledge can be established by circumstantial evidence.[4] It can also be established by direct or circumstantial evidence, or a combination of both.[5]

However, it will often depend on the visibility of the object as well as the accused's connection with the location.[6]

For example, where drugs are found in a vehicle or house the courts consider the control the accused had over the location as well as the likelihood of the accused being aware of where the items were found.[7]

Occupancy does not automatically infer knowledge of the items within the dwelling.[8]

  1. ↑ R. v. Beaver (1957), 118 C.C.C. 129 (S.C.C.) and  
R. v. Martin (1948), 92 C.C.C. 257 at p.266 (Ont. C.A.)
  2. ↑ R. v. Chalk [2007 ONCA 815](http://canlii.org/en/on/onca/doc/2007/2007onca815/2007onca815.html) at para. 18
  3. ↑ R. v. Traimany [2011 MBQB 15](http://canlii.ca/t/2fk7r) at 34
  4. ↑ R. v. Sparling, [1988] O.J. No. 107 (Ont. H.C.) at p. 6 :  
"There is no direct evidence of the applicant’s knowledge of the presence of narcotics in the residence. It is not essential that there be such evidence for as with any other issue of fact in a criminal proceeding, it may be established by circumstantial evidence. In combination, the finding of narcotics in plain view in the common areas of the residence, the presence of a scale in a bedroom apparently occupied by the applicant, and; the applicants apparent occupation of the premises may serve to found an inference of the requisite knowledge"
  5. ↑ R. v. Pham, [2005 CanLII 44671](http://canlii.ca/t/1m459) (ON CA), at para. 18
  6. ↑ R. v. Grey, [1996 CanLII 35](http://www.canlii.org/en/on/onca/doc/1996/1996canlii35/1996canlii35.html) (ON C.A.)
  7. ↑ R. v. Gordon, [2011 ONSC 5650](http://canlii.ca/t/fn7f5) \- acquittal - drugs found in vent of car
  8. ↑ R. v. Grey [1996 CanLII 35](http://canlii.ca/t/6jd5) (ON CA), (1996), 28 O.R. (3d) 417 (Ont. C.A.), per Laskin J.A. at p. 423 (“I would not prescribe a firm rule for inferring knowledge from occupancy”)

### Consent and Intent[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-9)]

The element of consent to possess an object requires that the accused consent to the object remaining in place after he or she has knowledge of its existence. This is not limited to those who approve of the custody of the drugs. A person who discovers drugs and spends time maintaining custody of it while considering what to do with it may be found to consent to possessing it.[1]

  


  1. ↑ R. v. Christie (1978), 41 C.C.C.(2d) 282 (N.B.C.A.) -- woman held onto discovered drugs in car for 1 hour

### Control[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-10)]

The element of control over the object is established by showing that the accused had an _intention_ to exercise control. Where the person is shown to have control over the area where the object is stored, they can be found to exercise control over the object itself.[1]

It is not necessary that the accused actually examine or look at the item to be in possession of it. [2]

Control requires that the Crown "prove is that an accused had the ability to exercise some power (i.e., some measure of control) over the item in issue. It is not necessary for the Crown to prove that such power was in fact exercised."[3]

A trier-of-fact may conclude that "someone living in premises in which marihuana plants or other illegal drugs are openly located is in a position to exercise some measure of control over those drugs."[4]

  1. ↑ R. v. Marshall, [1969] 3 C.C.C. (3d) 149 (Alta. C.A.) -- acquitted of drug possession as he had no control over drugs in vehicle he was in See also:R. v. Pham (K.T.), [2005] O.J. No. 5127; 204 O.A.C. 299 (C.A.)
  2. ↑ R. v. Daniels 2004 NLCA 73 (CanLII), (2004), 191 C.C.C. (3d) 393 at para. 12 (Nfld. C.A.)
  3. ↑ R v Wu, [2010 BCCA 589](http://canlii.ca/t/2f3r5) \- three adults lived in a house with a grow-op on the upper floor. No evidence of active involvement in grow-op.
  4. ↑ Wu

## Specific scenarios[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-11)]

### Items found in a Vehicle[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-12)]

There are differing lines of cases on whether finding of an item within a motor vehicle owned and operated by an accused is _prima facie_ proof of possession by the accused. [1]

"[M]ere passive acquiescence in the transportation of the drugs" is not sufficient [2]

A sole occupant and driver in close proximity to drugs in plain view allows the inference of knowledge and control. (R v Mulligan-Brum, 2011 BCCA 410 at para 13)

The Crown must prove the accused knew of the presence of the drug in the vehicle and that that he had a measure of control over it.[3]

However, "where one of two persons has opium in his custody or possession, another who knows that fact, even though he has no measure of control over it, but nevertheless co‑operates with the person who has such custody in an effort to prevent detection" that person has possession. [4]

  1. ↑ Gallant v The Queen (1960), 128 CCC 129 (NB SCAD) per Ritchie J.A. at p 131 - presumption exists  
c.f. R. v. Lincoln, [2012 ONCA 542](http://canlii.ca/t/fsdh5) \- no presumption  
R. v. Watson, 2011 ONCA 437 (CanLII), at paras. 11-13
  2. ↑ R. v. Williams 1998 CanLII 2557 (ON CA), (1998), 125 C.C.C. (3d) 552 (Ont. C.A.), at page 558
  3. ↑ R. v. Grey, [1996] O.J. No. 1106 (C.A.), at para. 15
  4. ↑ In R. v. Lou Hay Hung (1946), 85 C.C.C. 308 (Ont. C.A.)

### Items Found in a Residence[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-13)]

Generally, personal papers are to be found in a location where a person has access and control. It is a valid inference to infer that where documents such as “income tax forms, invoices, cancelled cheques, leases, insurance papers and the like” are found in a residence that the person identified in the documents is an occupant with “a significant level of control”.[1]

Mere presence in a residence and knowledge of the presence of contraband in the room or residence is not sufficient to establish possession, evidence must show control.[2]

  1. ↑ R v Emes 2001 CanLII 3973 (ONCA) at 8  
R v Basarowich, 2010 MBQB 4 at para. 26
  2. ↑ R. v. Colvin and Gladue (1942), 78 C.C.C. 282 (B.C.C.A.) both accused persons were found visiting a premise where narcotics were present, found not in possession of the drugs  
R. v. Edwards, [2012 ONCJ 422](http://canlii.ca/t/fs0j4) at para 23  


### Other[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-14)]

Knowledge may be inferred from physical possession of a receptacle containing concealed contraband, however, it cannot create a presumption.[1]

A passenger may be in possession of a stolen car. It depends on the number of factors suggesting knowledge and control. Suggested factors include:[2]

  1. recency of theft
  2. driver fled once there was a collision
  3. actions, demeanour and utterances of passenger suggesting knowledge and control
  4. fleeing from the car with the driver and attempt to dispose of evidence
  5. the passengers ability to see the damage to the ignition from starting without a key

  1. ↑ R. v. Lincoln, [2012 ONCA 542](http://canlii.ca/t/fsdh5) (CanLII), at paras. 2-3
  2. ↑ R. v. T.A.K., [2005 BCCA 293](http://canlii.ca/t/1kw1b) (CanLII)

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Possession&action=edit&section=T-15)]

  * [Canadian Criminal Law/Recent Possession](/wiki/Canadian_Criminal_Law/Recent_Possession) \- extends liability where possession is recent in time to an index offence

## Proof of Ownership[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Ownership&action=edit&section=T-1)]

Under s. 380, "property" does not relate to ownership. It concerns the lawful possession of some thing which is transferred by some deceitful act.[1]

Any property that is required for a preliminary inquiry or trial for an offence under section 334, 344, 348, 354, 355.2, 355.4, 362 or 380 that has been returned, may by photographed by police. ([491.2(1)](http://canlii.ca/t/7vf2#sec491.2))

Photograph "includes a still photograph, a photographic film or plate, a microphotographic film, a photostatic negative, and X-ray film, a motion picture and a videotape." (491.2 (8))

Photographs taken under s. 491.2 that are accompanied by a certificate containing the statements are admissible with the same "probative force" as the property was proved the ordinary way absence evidence to the contrary. (491.2(2))

Under s. 491.2(3), the certificate should contain a statement outlining that:

  1. the person took the photograph under the authority of 491.2(1)
  2. the person is a peace officer or took the photograph under the direction of a peace officer, and
  3. the photograph is a true photograph

There must also be an affidavit or solemn declaration that "the property was not altered in any manner before the photograph". (491.2(4))

The Crown must give "reasonable notice of intention to produce it in evidence" before any photos can be admitted into evidence "unless the court orders otherwise". (491.2 (5))

The Court may require the attendance of the officers who gave the statements for examination. (491.2(6)) The court may also require the returned property be re-acquired to be brought to court for examination. (491.2(7))

Under [s. 657.1](http://canlii.ca/t/7vf2#sec657.1), evidence regarding the property, such as value and ownership, can be given by way of affidavit or solemn affirmation from the lawful owner absent evidence to the contrary.

The affidavit must state:

  1. that the person is the lawful owner of, or is lawfully entitled to possession of, the property, or otherwise has specialized knowledge of the property or of property of the same type as that property;
  2. the value of the property;
  3. in the case of a person who is the lawful owner of or is lawfully entitled to possession of the property, that the person has been deprived of the property by fraudulent means or otherwise without the lawful consent of the person;
  4. in the case of proceedings in respect of an offence under section 342, that the credit card had been revoked or cancelled, is a false document within the meaning of section 321 or that no credit card that meets the exact description of that credit card was ever issued; and
  5. any facts within the personal knowledge of the person relied on to justify the statements referred to in paragraphs (a) to (c.1).

Parties must be given "reasonable notice of intention to produce" this evidence by affidavit.(657.1(3)) The court may still order that the affiant attend court to be examined.

See also [[rules of civil procedure in proving exhibits](http://nslaw.nsbs.org/nslaw/ruleSection.do;jsessionid=F06572BCE3BA842EAE6E342FDD84F662?id=380)].

  1. ↑ R. v. Vallillee (1974), 15 C.C.C. (2d) 409 (CA) - accused rented a car using stolen ID and Credit Card

## Case Digests[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Ownership&action=edit&section=T-2)]

  * R. v. Savage, [2003] O.J. No. 4052
  * R. v. Botha, [2011 ONCJ 326](http://canlii.ca/t/fm24v) \-- acquitted; unable to make inference of intent; ID not made out
  * [Canadian Criminal Law/Offences/Theft and Possession](/wiki/Canadian_Criminal_Law/Offences/Theft_and_Possession)

## Introduction[[edit](/w/index.php?title=Canadian_Criminal_Law/Duty_of_Care&action=edit&section=T-1)]

Much of the foundation of criminal law lies in the premise that the accused had a requisite "mens rea" (or guilty state of mind) when committing the offence. In principle a person should only be convicted of an offence for which they had some degree of awareness or intention when committing the criminal act. This is closely tied to the theory of moral culpability which is what criminal law is attempting to address and as such is constitutionally required under s. 7 of the Charter.

The criminal law generally does not include offences for which the accused was not subjectively aware to some degree of the offence. Further, there is no duty of precaution upon an individual to ensure that they do not perform the illegal act without their intent or knowledge. This is in contrast to regulatory offences and other forms of civil liability which generally require only an objective standard of responsibility. This is known as a "duty of care" and "standard of care". The duty of care is the legal obligation to maintain a certain standard. The standard of care is the specific standard of conduct that is imposed by law upon an individual which, if violated, could result in liability of some sort or another.

## Duty of Care[[edit](/w/index.php?title=Canadian_Criminal_Law/Duty_of_Care&action=edit&section=T-2)]

Certain criminal offences create a duty of care, where, if the standard of care is violated, will result in a criminal act. The offences that impose a duty of care include:

  1. [unsafe storage of a firearm](/wiki/Canadian_Criminal_Law/Offences/Unsafe_Storage_of_a_Firearm) (86)
  2. [Criminal negligence](/wiki/Canadian_Criminal_Law/Offences/Criminal_Negligence) (219)
  3. [dangerous operation of a motor vehicle](/wiki/Canadian_Criminal_Law/Offences/Dangerous_Operation_of_a_Motor_Vehicle) 249

## Standard of Care[[edit](/w/index.php?title=Canadian_Criminal_Law/Duty_of_Care&action=edit&section=T-3)]

The modern foundation of duty of care in criminal law originated from the case of R v Hundal [1993 CanLII 120](http://canlii.ca/t/1fs58) (SCC), [1993] 1 S.C.R. 867. The case stated that to determine whether an act violated a standard of care requires a "modified objective test"[1]

For any offence where the standard of care involves objectively dangerous conduct, the conduct must be shown to be a "marked departure" from the the norm. Wherein a "reasonable person in the position of the accused would have been aware of the risk" and "would not have undertaken the activity".[2] The assessment, then, is of a "reasonably prudent person in the circumstances" the accused found himself when the events occurred.[3]

Thus, if the accused actions' show a marked departure from the standard of care described in the offence provision, he still cannot be convicted if a reasonably prudent person in the position of the accused would not have been aware of the risk or would not have been able to avoid the creating the risk.[4]

This standard was determined to be constitutionally acceptable.[5]

  1. ↑ see R. v. Hundal, [1993 CanLII 120](http://canlii.ca/t/1fs58) (SCC), [1993] 1 S.C.R. 867, at page 887
  2. ↑ R. v. Beatty, [2008 SCC 5](http://canlii.ca/t/1vrp5), [2008] 1 S.C.R. 49
  3. ↑ R. v. Beatty, [2008 SCC 5](http://canlii.ca/t/1vrp5), [2008] 1 S.C.R. 49 at 40
  4. ↑ R. v. Tayfel (M.), 2009 MBCA 124 (CanLII), <<http://canlii.ca/t/273wk>> at 51
  5. ↑ Trilogy cases on Duty of care: R. v. Hundal [1993 CanLII 120](http://canlii.ca/t/1fs58), [1993] 1 S.C.R. 867  
R. v. DeSousa [1992 CanLII 80](http://canlii.ca/t/1fsb0), [1992] 2 S.C.R. 944, 1992 SCC 77  
R. v. Tutton and Tutton, [1989 CanLII 103](http://canlii.ca/t/1ft5f), [1989] 1 S.C.R. 1392

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Law/Causation&action=edit&section=T-1)]

Certain offences in the criminal code require not only that the offender do a prohibited act along with the requisite mens rea, but also that the act caused a particular result. Criminal responsibility for causation must be established in fact and in law.[1] This makes a distinction between the physical, biological, or medical cause a particular result and the legal boundary that would attribute responsibility to the accused for the result.

The standard to prove causation is the same as between all homicide offences, including murder, manslaughter, operation of a motor vehicle causing death.[2] Likewise, the standard applies equally to offences involving bodily harm.

The criminal standard of causation in criminal matters is that the "accused's conduct be at least a contributing cause of the [result], outside the de minimis range"[3]

Criminal law does not include any issues of contributory negligence nor does it apportion responsibility for harm caused outside of sentencing.[4]

The inference of foreseeability can be rebutted with evidence of intoxication.[5]

  


  1. ↑ R. v. Nette, [2001 SCC 78](http://canlii.ca/t/51x9), [2001] 3 S.C.R. 488, at para. 44
  2. ↑ R v K.L., [2009 ONCA 141](http://canlii.ca/t/22h4n) at [17](http://canlii.ca/t/22h4n#par17)
  3. ↑ R v K.L., [2009 ONCA 141](http://canlii.ca/t/22h4n) at 17 citing:  
R. v. Smithers, [1977 CanLII 7](http://canlii.ca/t/1mk9r) (SCC), [1978] 1 S.C.R. 506 at p. 519  
R. v. Nette, [2001 SCC 78](http://canlii.ca/t/51x9) (CanLII), [2001] 3 S.C.R. 488 at paras. 71 and 72  

  4. ↑ R v Nette [2001 SCC 78](http://canlii.ca/t/51x9) at para. 49  
R. v. K. L., [2009 ONCA 141](http://canlii.ca/t/22h4n) at 18
  5. ↑ R. v. Seymour, [1996 CanLII 201](http://canlii.ca/t/1fr9z), [1996] 2 SCR 252 at para. 23  
See R. v. Daley, [2007 SCC 53](http://canlii.ca/t/1v5dr), [2007] 3 SCR 523 for details on the law of intoxication  


## Offences where causation is an essential element[[edit](/w/index.php?title=Canadian_Criminal_Law/Causation&action=edit&section=T-2)]

  * [Murder](/wiki/Canadian_Criminal_Law/Offences/Murder)
  * [Manslaughter](/wiki/Canadian_Criminal_Law/Offences/Manslaughter)
  * [Assault causing bodily harm](/wiki/Canadian_Criminal_Law/Offences/Assault_Causing_Bodily_Harm) (267)
  * [Aggravated Assault](/wiki/Canadian_Criminal_Law/Offences/Aggravated_Assault) (268)
  * [Sexual Assault causing bodily harm](/wiki/Canadian_Criminal_Law/Offences/Sexual_Assault_Causing_Bodily_Harm)
  * [Aggravated Sexual Assault](/wiki/Canadian_Criminal_Law/Offences/Aggravated_Sexual_Assault)
  * [Dangerous Driving Causing Bodily Harm](/wiki/Canadian_Criminal_Law/Offences/Dangerous_Operation_of_a_Motor_Vehicle)
  * [Dangerous Driving Causing Death](/wiki/Canadian_Criminal_Law/Offences/Dangerous_Operation_of_a_Motor_Vehicle)
  * [Fraud](/wiki/Canadian_Criminal_Law/Offences/Fraud) (380)

## Causation in Homicide[[edit](/w/index.php?title=Canadian_Criminal_Law/Causation&action=edit&section=T-3)]

Homicide is defined in s.222(1) as occurring where a person "directly or indirectly, by any means, ... causes the death of a human being.". Culpable Homicide (i.e. murder, manslaughter, or infanticide) is defined in section 222(5) as "when [a person] causes the death of a human being...by means of an unlawful act".

Causation is explicitly identified as existing where the death might have been otherwise "been prevented by resorting to proper means"(s. 224) or where the immediate cause of death is proper or improper treatment applied in good faith (s.225) or where the victim is already suffering from a terminal condition. (s 226)

The "Smithers test" for causation applies to all types of homicide. The test requires that the accused's act be a "significant contributing cause" of death beyond something trifling or minor. Thus, the unlawful act remains the legal cause of death even where the act by itself would not have cause death as long as it was beyond the de minimus. [1]

By implication, causation is in no way limited to a direct, an immediate, or the most significant cause.[2]

Where the offence is "constructive murder" under s. 231(5), that there is an added requirement.[3]

A distinction is made between factual causation and legal causation.[4] The former being the broader of the two.

  * _Factual causation_ requires "an inquiry about how the victim came to his or her death, in a medical, mechanical, or physical sense, and with the contribution of the accused to that result" (Nette, at para. 44) To put it simply, the question is "but for" the act would death have arose? [5]
  * _Legal Causation_ addresses the moral element of whether the accused "should be held responsible in law for the death"[6]

  


  1. ↑ R v Smithers, [1977 CanLII 7](http://canlii.ca/t/1mk9r), [1978] 1 SCR 506 - defines manslaughter as “a contributing cause of death, outside the de minimis range” (p. 519)  
R v Nette [2001 SCC 78](http://canlii.ca/t/51x9) at 71-72
  2. ↑ R. v. Maybin, [2012 SCC 24](http://canlii.ca/t/frczg) at para 20
  3. ↑ R v Nette at 73
  4. ↑ R. v. Kippax, [2011 ONCA 766](http://canlii.ca/t/fp7n6), [2011] O.J. 5494 at 22 to 27
  5. ↑ R. v. Maybin, [2012 SCC 24](http://canlii.ca/t/frczg) at para 15
  6. ↑ Nette at para. 45

### Intervening Acts[[edit](/w/index.php?title=Canadian_Criminal_Law/Causation&action=edit&section=T-4)]

The doctrine of intervening acts can limit the scope of legal causation. The law recognizes an intervening cause that "'break the chain of causation' between the accused's acts and the death" which results in the "accused’s actions not being a significant contributing cause of death" [1]

  


  1. ↑ R v Tower [2008 NSCA 3](http://canlii.ca/t/1vn7l) at para 25

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Causation&action=edit&section=T-5)]

  * R. v. Kippax, [2011 ONCA 766](http://canlii.ca/t/fp7n6) at 21-28

## Introduction[[edit](/w/index.php?title=Canadian_Criminal_Law/Criminal_Organization&action=edit&section=T-1)]

A criminal organization is defined in s. 467.1 of the Criminal Code:

> 467.1 (1)
> 
> ...
> 
> “criminal organization” means a group, however organized, that
> 
>     (a) is composed of three or more persons in or outside Canada; and
>     (b) has as one of its main purposes or main activities the facilitation or commission of one or more serious offences that, if committed, would likely result in the direct or indirect receipt of a material benefit, including a financial benefit, by the group or by any of the persons who constitute the group.
> 
> It does not include a group of persons that forms randomly for the immediate commission of a single offence.
> 
> – [[10]](http://canlii.ca/t/7vf2#sec467.1)

## Proof of Criminal Organization[[edit](/w/index.php?title=Canadian_Criminal_Law/Criminal_Organization&action=edit&section=T-2)]

Evidence must establish that the group is a criminal organization. It must be established on a case-by-case basis.[1] Proof of direct control of the organization is a high standard.[2]

Factors to consider whether the group is a criminal organization include: [3]

  1. rules between the men,
  2. defined roles and structure,
  3. communication between the participants,
  4. actual or pending material benefit to the parties,
  5. an organizational structure that promotes the commission of offences.

The courts should not be rigid in applying the definition and must use a purposive approach. Criminal organizations have no incentive to have a formal structure and tend to be flexible. However, "some form of structure and degree of continuity are required".[4]

  1. ↑ R v Ciarniello 2006 BCSC 1671  
R v Kirton 2007 MBCA 38  
See also Riley, 2009 CanLII 15450 (ON S.C.)
  2. ↑ R v Giles, 2008 BCSC 367
  3. ↑ R v. Lindsay, 2005 CanLII 24240 (ON SC)
  4. ↑ R. v. Venneri, [2012 SCC 33](http://canlii.ca/t/frxxp) (CanLII) at para. 28 to 29

## Effect[[edit](/w/index.php?title=Canadian_Criminal_Law/Criminal_Organization&action=edit&section=T-3)]

Several offences require there is a criminal organization:[1]

  1. Enhancing a criminal organization (s. 467.11)
  2. Committing for the benefit of a criminal organization (s.467.12)[2]
  3. Instruct the commission of an offence for a criminal organization (s.467.13)

Others are modified by the existence of a criminal organization:

  1. Conspiracy (s.465)
  2. Counselling (s.22)
  3. Accessory after the fact (s.23)
  4. Possessing explosives for a criminal organization (s.82(2))
  5. Intimidating the justice system and journalists (s.423.1)

Where an offence is found to be a criminal organization offence (s.2):

  * the penalties will be consecutive (s.467.14)
  * the wiretap powers are expanded[3]
  * there is a reverse onus on bail (s. 515(6)(a)(ii)
  * presumption of 1st degree murder in a murder charge (s.231(6.1))

  


## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Criminal_Organization&action=edit&section=T-4)]

## References[[edit](/w/index.php?title=Canadian_Criminal_Law/Criminal_Organization&action=edit&section=T-5)]

  1. ↑ see s. 2 "criminal organization offences"
  2. ↑ Drecic, 2011 ONCA 118
  3. ↑ longer authorization (s.186.1 and 196), no need for "investigative necessity" (s. 185(1.1) and 186(1.1)

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Law/Continuity&action=edit&section=T-1)]

The Crown has the duty to prove an exhibit's integrity beyond a reasonable doubt. It must be shown that the items in evidence before the court in trial were the same items seized during the investigation. So for example, the Crown must prove that the drugs presented in court are the same that were seized at the scene of the investigation. Where the proof of the item is part of an essential element of the case, such as in a drug possession case, then it should be proven beyond a reasonable doubt. Gaps in continuity are not fatal unless they raise a reasonable doubt about the exhibit’s integrity.[1]

However, it has been said that generally speaking, "continuity of an exhibit goes to weight, not to admissibility."[2] A party who cannot "prove absolute continuous possession...would not preclude admissibility".[3]

There is no specific requirement to that the crown lead continuity evidence. Nor does every person in the chain of possession need to testify.[4] The evidence of continuity should be lead where there is potential evidence before the court, by direct or circumstantial evidence or by inference, that may raise doubt as to the continuity. Even where gaps may raise a reasonable doubt about the item in court is the same seized initially by police, it may still be admissible and the doubt will simply go do weight. [5] For example, problems with continuity and integrity of recordings generally goes to their weight not the admissibility of the contents of the recordings.[6]

The evidence seized by police will be catalogued and given identifying numbers. These numbers should remain consistent throughout the case. So whether the items are sent to a lab for analysis, they will always be identifiable as the same once they are presented in court. Any changes of the numbering system should be recorded and explained in court. Failure to properly track the exhibits by their identifying numbers may raise doubt as to their continuity.[7]

  1. ↑ R v Oracheski, (1979) 48 CCC (2d) 217 (ABCA)  
R v DeGraaf [1981 CanLII 343](http://www.canlii.org/en/bc/bcca/doc/1981/1981canlii343/1981canlii343.html), (1981), 60 CCC (2d) 315 (BCCA)  
c.f. R v Murphy 2011 NSCA 54 at para. 41 citing R v Jeffrey [1993] AJ. 639  

  2. ↑ R v West, 2010 NSCA 16 at para. 130  
see also R v Krole 1975 CarswellMan 119 at para. 27
  3. ↑ Krole at para. 27
  4. ↑ R. v. Adam [2006 BCSC 1430](http://canlii.ca/t/1pmdd) at page 7
  5. ↑ R. v. Adam [2006 BCSC 1430](http://canlii.ca/t/1pmdd) (2007) BCWLD 1987 at page 7  
R. v. Andrade, (1985), 6 O.A.C. 345, 18 C.C.C. (3d) 41 (Ont. C.A.)  

  6. ↑ R. v. Meer, [2010] A.J. No. 1123 (Q.B.), [2010 ABQB 617](http://canlii.ca/t/2ct1t) at 16
  7. ↑ e.g. R. v. Martin, [2008 ONCJ 601](http://canlii.ca/t/21lbq) at 16

## Bodily Harm[[edit](/w/index.php?title=Canadian_Criminal_Law/Injuries&action=edit&section=T-1)]

Section 2 of the Criminal Code defines "bodily harm" as:

> s.
> 
> ...
> 
> **“bodily harm”**  
...
> 
> “bodily harm” means any hurt or injury to a person that interferes with the health or comfort of the person and that is more than merely transient or trifling in nature;

## Aggravated Assault[[edit](/w/index.php?title=Canadian_Criminal_Law/Injuries&action=edit&section=T-2)]

See also: [Canadian Criminal Law/Offences/Aggravated Assault](/wiki/Canadian_Criminal_Law/Offences/Aggravated_Assault) and [Canadian Criminal Law/Offences/Aggravated Sexual Assault](/wiki/Canadian_Criminal_Law/Offences/Aggravated_Sexual_Assault)

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Law/Trafficking&action=edit&section=T-1)]

Section 2 of the Controlled Drugs and Substances Act states:

> **Definitions**  
2\. (1) In this Act,
> 
> ...
> 
> “traffic” means, in respect of a substance included in any of Schedules I to IV,
> 
>     (a) to sell, administer, give, transfer, transport, send or deliver the substance,
>     (b) to sell an authorization to obtain the substance, or
>     (c) to offer to do anything mentioned in paragraph (a) or (b), otherwise than under the authority of the regulations.
> 
> – [CDSA](http://canlii.ca/t/7vtc#sec2)

## Offer to Sell[[edit](/w/index.php?title=Canadian_Criminal_Law/Trafficking&action=edit&section=T-2)]

Trafficking by offer under s. 2(2)(c) only requires that the crown prove an intent to make the offer. It is not necessary to prove that the accused had an intent to follow through with the offer.[1] As such, there is no need to prove that the accused had drugs on themselves at the time or was capable of fulfilling the request.[2]

  1. ↑ R v Mamchur, [1978] 3 WWR 481 (SKCA) at p. 483  
R v Jones, (1988) 74 Sask R. 4 (SKCA) at 10  
R. v. Campbell, [1999 CanLII 676](http://canlii.ca/t/1fqp4) (SCC), [1999] 1 S.C.R. 565 at 25  
R. v. Murdock [2003 CanLII 4306](http://canlii.ca/t/6mdj) (ON CA), (2003), 176 C.C.C. (3d) 232 at 14  
R v Crain, [2012 SKCA 8](http://canlii.ca/t/fpw5n)  

  2. ↑ e.g. R. v. Petrie, [1947] O.W.N. 601 (C.A.) -- drugs offered weren’t available;  
R. v. Murdock, supra -- offer was withdrawn  
R. v. Sherman, [1977] 5 W.W.R. 283 (B.C.C.A.) -- offer was made for purpose of ripping buyer off  
R. v. Reid [1996 CanLII 5213](http://canlii.ca/t/1mmhl), (1996), 155 N.S.R. (2d) 368 (NSCA) -- no evidence that drugs were even available to seller  
R. v. Brown (1953), 9 W.W.R. (N.S.) 701 (B.C.C.A.) -- drugs not on the seller  


## Opinion Evidence on Trafficking[[edit](/w/index.php?title=Canadian_Criminal_Law/Trafficking&action=edit&section=T-3)]

To prove that someone was in possession of a controlled substance _for the purpose of trafficking_, the Crown must call expert evidence to given an opinion that the circumstances allow for the inference that the possessor intended to traffick.

See also: [Canadian Criminal Evidence/Opinion/Expert Evidence](/wiki/Canadian_Criminal_Evidence/Opinion/Expert_Evidence) for details on the law of expert evidence.

## Evidence of Intent[[edit](/w/index.php?title=Canadian_Criminal_Law/Trafficking&action=edit&section=T-4)]

**Amount of drugs**  
Trafficking can be inferred where the quantity/purity/value of drugs in high.[1]

Where an accused is a user of drugs, there may be evidence suggestive that the drugs found in their possession may be consistent with personal use as opposed to trafficking. The amounts required to maintain the addiction and the habits of typical users are relevant. Either party is permitted to lead evidence concerning typical use, however, this usually takes the form of expert evidence.[2]

The amount of drugs _alone_ cannot be used to establish trafficking.[3]

Marijuana amounts in the range of 3 pounds have been found to be unreasonable to be considered consumable for personal use. [4]

**Money**  
Large quantities of unexplained wealth can allow a judge to lead to the conclusion of trafficking. This is particularly true where cash is in small denominations and is found near drugs.[5]

**Packaging**  
Where packaging is found this may allow a judge to infer an intent to traffick. Packaging in numerous quantities, such as numerous small baggies, can create such an inference. [6]

  1. ↑ R. v. Le, [2001 BCCA 658](http://www.canlii.org/en/bc/bcca/doc/2001/2001bcca658/2001bcca658.html)  
R. v. Adelberg, [2001 BCCA 637](http://www.canlii.org/en/bc/bcca/doc/2001/2001bcca637/2001bcca637.html)  
R. v. L'Huillier, [1997 CanLII 9606 (NB Q.B.)](http://www.canlii.org/en/nb/nbqb/doc/1997/1997canlii9606/1997canlii9606.html)  
R. v. Falahatchian, [1995 CanLII 941 (ON C.A.)](http://www.canlii.org/en/on/onca/doc/1995/1995canlii941/1995canlii941.html)  
R. v. Naugler, [1994 ABCA 110](http://www.canlii.org/en/ab/abca/doc/1994/1994abca110/1994abca110.html)  

  2. ↑ R. v. Petavel, [2006 BCSC 1931](http://www.canlii.org/en/bc/bcsc/doc/2006/2006bcsc1931/2006bcsc1931.html)
  3. ↑ R. v. McCallum [2006 SKQB 287](http://canlii.ca/t/1nw48) (CanLII), (2006), 281 Sask.R. 272 at 28  
R. v. Mehari, [2009 ABPC 217](http://canlii.ca/t/25039) at 7
  4. ↑ R. v. Brophy (W.) (1971), 3 N.B.R.(2d) 594 (CA)
  5. ↑ R. v. Alberts, [1999 CanLII 2246](http://canlii.ca/t/1f9d9) (ON C.A.)  
R. v. Le, [2001 BCCA 694](http://www.canlii.org/en/bc/bcca/doc/2001/2001bcca694/2001bcca694.html)
  6. ↑ R. v. Scott, [2003 CanLII 27446 (ON S.C.)](http://www.canlii.org/en/on/onsc/doc/2003/2003canlii27446/2003canlii27446.html)  
R. v. Kwok, [2002 BCCA 177](http://www.canlii.org/en/bc/bcca/doc/2002/2002bcca177/2002bcca177.html)  
R. v. Petavel, [2006 BCSC 1931](http://www.canlii.org/en/bc/bcsc/doc/2006/2006bcsc1931/2006bcsc1931.html)

## Dial-a-Dope operations[[edit](/w/index.php?title=Canadian_Criminal_Law/Trafficking&action=edit&section=T-5)]

A Dial-a-Dope operation is the manner in which drugs are often distributed to their customers. The seller and buyer will contact each other by phone and arrange to make an exchange at a pre-determined location.

The Crown will often adduce evidence to argue that the evidence suggests that such an operation was undertaken. This is determined by expert opinion of the evidence suggestive of such an operation.

Several cases have considered the methods of a dial-a-dope operation.[1]

  1. ↑ R. v. Franklyn, [2001 BCSC 706](http://www.canlii.org/en/bc/bcsc/doc/2001/2001bcsc706/2001bcsc706.html)  
R. v. Tran, [2007 BCCA 613](http://www.canlii.org/en/bc/bcca/doc/2007/2007bcca613/2007bcca613.html)  
R. v. Tetreault, [2008 BCSC 412](http://www.canlii.org/en/bc/bcsc/doc/2008/2008bcsc412/2008bcsc412.html) \-- Acquitted  


## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Trafficking&action=edit&section=T-6)]

  * [Canadian Criminal Law/Offences/Drug Trafficking](/wiki/Canadian_Criminal_Law/Offences/Drug_Trafficking)

# _Doctrines of Liability_[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit&section=2)]

## Generally[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-1)]

> **Parties to offence**  
21\. (1) Every one is a party to an offence who
> 
>     (a) actually commits it;
>     (b) does or omits to do anything for the purpose of aiding any person to commit it; or
>     (c) abets any person in committing it.  

> **Common intention**  
(2) Where two or more persons form an intention in common to carry out an unlawful purpose and to assist each other therein and any one of them, in carrying out the common purpose, commits an offence, each of them who knew or ought to have known that the commission of the offence would be a probable consequence of carrying out the common purpose is a party to that offence.  
R.S., c. C-34, s. 21. 
> 
> – [CCC](http://canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec21)

Section 21 outlines four ways in which a person can be criminally liable for an act. A person can be a principal, an aider, an abettor, or have common intention to commit an offence.

In any of the circumstances, a party to an offence must have both knowledge and intent.[1]

Where a person provides directions or instructions to a potential buyer to make a purchse of drugs from a seller, that can amount to aiding and abetting in trafficking arising from the eventual sale. [2]

  1. ↑ R v Briscoe, [2010 SCC 13](http://canlii.ca/t/29280), [2010] 1 S.C.R. 411 at paras. 14 to 16
  2. ↑ R. v. Frayne, [2011 ONCJ 557](http://canlii.ca/t/fnslr)

### Section 21(1)(a): Commits[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-2)]

A person "actually commits" an offence when he does some act "towards the commission of the offence" with requisite mens rea or uses an agent to commit it.

This means that where there is multiple people all doing some act together towards the shared achievement of the offence, each is actually committing the offence as a "joint principle offender".[1]

This means that where it is proven that where it is proven that multiple people acted with an intention to commit murder, it is "legally irrelevant" to determine who pulled the trigger.[2]

  


  1. ↑ E. G. Ewaschuk in Criminal Pleadings & Practice in Canada, looseleaf, 2nd ed., Vol. 1 (Aurora: Canada Law Book, 2007) at 15:1010
  2. ↑ R v Devon Trent Gerald Paskimin, [2012 SKCA 35 at 23](http://canlii.ca/t/fqs4z#par23)  
R. v. H.(L.I.), [2003 MBCA 97 at 20](http://canlii.ca/t/5878#par20)

### Section 21(1)(b), (c): Aiding and Abetting[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-3)]

The _actus reus_ of aiding or abetting is "doing (or, in some circumstances, omitting to do) something that assists or encourages the perpetrator to commit the offence. While it is common to speak of aiding and abetting together, the two concepts are distinct, and liability can flow from either one. Broadly speaking, "[t]o aid under s. 21(1)(b) means to assist or help the actor... . To abet within the meaning of s. 21(1)(c) includes encouraging, instigating, promoting or procuring the crime to be committed"[1]

  


  1. ↑ R. v. Briscoe, [2010 SCC 13](http://canlii.ca/t/29280), [2010] 1 S.C.R. 411 [at 14](http://www.canlii.org/en/ca/scc/doc/2010/2010scc13/2010scc13.html#par14)

### Section 21(2): Common Intention[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-4)]

A common intention is whether two or more persons "have in mind the same unlawful purpose." The common intention may form "in the instant of the offence being committed, the mutual intention to pursue unlawful purpose and to assist each other therein being formed at the very moment of carrying it out." [1]

So for example, where a second party joins in on an assault by a primary party, there will be a common intention formed.

**Murder**  
A girlfriend of the principal was an abettor of first degree murder under s. 21(1)(c) by standing by during the murder and yelled "kill him Georgie".[2]

The girlfriend of a principal was an abettor of manslaughter where she gave the principal a weapon _for the purpose of_ attack the victim. However, without the formed intent in giving the weapon, there will be no conviction.[3] Unless there is some duty to act, a bystander who is present and watches a murder cannot be found guilty of any offence connected to the murder.[4]

  1. ↑ R. v. Vang 1999 CanLII 2310 (ON CA), (1999), 132 C.C.C. (3d) 32 at para. 24  
See Rose, Parties to an Offence (1982) at pages 67 - 68
  2. ↑ R. v. Rochon, [2003 CanLII 9600](http://canlii.ca/t/1br9f) (ON CA)
  3. ↑ R. v. Quinn, [2009 BCCA 267](http://canlii.ca/t/23xc0) (CanLII)
  4. ↑ R. v. Davy, [2000 CanLII 16859](http://canlii.ca/t/1fbbx) (ONCA)

## Counselling (s.22)[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-5)]

> **Person counselling offence**  
22\. (1) Where a person counsels another person to be a party to an offence and that other person is afterwards a party to that offence, the person who counselled is a party to that offence, notwithstanding that the offence was committed in a way different from that which was counselled.  
**Idem**  
(2) Every one who counsels another person to be a party to an offence is a party to every offence that the other commits in consequence of the counselling that the person who counselled knew or ought to have known was likely to be committed in consequence of the counselling.  
**Definition of “counsel”**  
(3) For the purposes of this Act, “counsel” includes procure, solicit or incite.  
R.S., 1985, c. C-46, s. 22; R.S., 1985, c. 27 (1st Supp.), s. 7.
> 
> – [CCC](http://canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec22)

"Counsel" under this section is more that simply advising, it has the "meaning of actively inducing" (R v Sharpe, [2001 SCC 2](http://canlii.ca/t/523f))

The mens rea of counselling requires evidence that “an accused either intended that the offence counseled be committed, or knowingly counseled the commission of the offence while aware of the unjustified risk that the offence counseled was in fact likely to be committed as a result of the accused’s conduct" [1]

Where a threat allegedly counsels murder the test to be applied is whether 1) an ordinary person would view the statement objectively would take it as an invitation to kill and 2) the accused either intended or knowingly counselling the victim's murder while aware of the unjustified risk that murder would likely be committed. [2]

  1. ↑ R. v. Abou Al-Rashta and Pirouzi, [2012 ONSC 1957](http://canlii.ca/t/fqs9w) citing Hamilton, [2005 SCC 47](http://canlii.ca/t/1l86s), [2005] 2 SCR 432 at para.29 and Root, [2008] O.J. No. 5214 (ONCA), at para.84
  2. ↑ see R. v. Jeffers, [2012 ONCA 1](http://canlii.ca/t/fpgx3)

### Where offence is not committed[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-6)]

> **Counselling offence that is not committed**  
464\. Except where otherwise expressly provided by law, the following provisions apply in respect of persons who counsel other persons to commit offences, namely,
> 
>     (a) every one who counsels another person to commit an indictable offence is, if the offence is not committed, guilty of an indictable offence and liable to the same punishment to which a person who attempts to commit that offence is liable; and
>     (b) every one who counsels another person to commit an offence punishable on summary conviction is, if the offence is not committed, guilty of an offence punishable on summary conviction.
>   
R.S., 1985, c. C-46, s. 464; R.S., 1985, c. 27 (1st Supp.), s. 60. 
> 
> – [CCC](http://www.canlii.ca/t/7vf2#sec464)

## Organizations as Parties[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-7)]

> **Offences of negligence — organizations**  
22.1 In respect of an offence that requires the prosecution to prove negligence, an organization is a party to the offence if
> 
>     (a) acting within the scope of their authority 
> 
>     (i) one of its representatives is a party to the offence, or
>     (ii) two or more of its representatives engage in conduct, whether by act or omission, such that, if it had been the conduct of only one representative, that representative would have been a party to the offence; and
>     (b) the senior officer who is responsible for the aspect of the organization’s activities that is relevant to the offence departs — or the senior officers, collectively, depart — markedly from the standard of care that, in the circumstances, could reasonably be expected to prevent a representative of the organization from being a party to the offence.  

> 2003, c. 21, s. 2.  
**Other offences — organizations**  
22.2 In respect of an offence that requires the prosecution to prove fault — other than negligence — an organization is a party to the offence if, with the intent at least in part to benefit the organization, one of its senior officers 
> 
>     (a) acting within the scope of their authority, is a party to the offence;
>     (b) having the mental state required to be a party to the offence and acting within the scope of their authority, directs the work of other representatives of the organization so that they do the act or make the omission specified in the offence; or
>     (c) knowing that a representative of the organization is or is about to be a party to the offence, does not take all reasonable measures to stop them from being a party to the offence.  

> 2003, c. 21, s. 2. 
> 
> – [CCC](http://www.canlii.ca/t/7vf2#sec22.1)

## Cases on Parties[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-8)]

  * R. v. Briscoe, [2012 ABQB 239](http://canlii.ca/t/fr16t) \-- accused not party to a murder
  * R. v. Opio, [2011 ABPC 392](http://canlii.ca/t/fpg7s) \-- guilty as party to trafficking
  * R. v. Mohamed, [2011 ABCA 350](http://canlii.ca/t/fp54k) || convicted as driver; D argued that he was not aware of what was going on
  * R. v. Crowchild, [2011 ABPC 299](http://www.canlii.org/en/ab/abpc/doc/2011/2011abpc299/2011abpc299.html) \-- guilty aggravated assault; not guilty robbery
  * R. v. Laurencelle, [1999 BCCA 511](http://canlii.ca/t/1tkl1)
  * R. v. Sparrow (1979) 51 C.C.C. (2d) 443, 12 C.R. (3d) 158 (Ont. C.A.) -- guilty
  * R. v. Thatcher [1987] 1 S.C.R. 652 -- guilty
  * R. v. McMaster, [1996] 1 S.C.R. 740. -- guilty
  * R. v. Dunlap and Sylvester, [1979] 2 S.C.R. 881.

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Parties&action=edit&section=T-9)]

  * [Canadian Criminal Law/Offences/Accessory After the Fact](/wiki/Canadian_Criminal_Law/Offences/Accessory_After_the_Fact)
  * [Canadian Criminal Law/Conspiracy](/wiki/Canadian_Criminal_Law/Conspiracy)

## Generally[[edit](/w/index.php?title=Canadian_Criminal_Evidence/Recent_Possession&action=edit&section=T-1)]

The doctrine of recent possession permits the court to make the inference that the possessor of the property had knowledge that the property was obtained in the commission of the offence, and in certain circumstances was also a party to the initial offence.[1]

When considering whether to make the inference of recent possession, the trier-of-fact must take into account all the circumstances.[2] This includes common sense factors such as the amount of time that passed between possession and the offence.[3]

Recency is a matter of circumstances such as type and size of the items.[4] In certain cases recency can include periods longer than a month.[5]

  
To permit the inference, the Crown must establish 1) that the accused was found in possession of the item and 2) that the item was recently stolen. Where it can be said that the accused was found in recent possession without explanation to trier of fact _may_, but not necessarily, draw the inference regarding the accused's role in the the theft or related offences.[6]

Factors to consider whether the possession was "recent" includes:[7]

  1. the nature of the object;
  2. the rareness of the object;
  3. the readiness with which the object can, and is likely to, pass to another; and
  4. the ease of identification.

Where the doctrine has been invoked, the Defence can counter the presumption by way of a reasonable explanation.[8]

It is not necessary to go beyond the test for recent possession to determine the accused's degree of participation. That is, whether the accused was a principle or accomplice.[9]

  1. ↑ see s. 2 "criminal organization offences"
  2. ↑ Drecic, 2011 ONCA 118
  3. ↑ longer authorization (s.186.1 and 196), no need for "investigative necessity" (s. 185(1.1) and 186(1.1)

## Cases[[edit](/w/index.php?title=Canadian_Criminal_Evidence/Recent_Possession&action=edit&section=T-2)]

  * R. v. Palaga, [2008 SKCA 36](http://canlii.ca/t/1w8z6) \-- acquitted of B&E
  * R. v. Goulet, [2005 SKPC 104](http://canlii.ca/t/1m1xj) \-- convicted of B&E
  * R. v. Harris, [1995 CanLII 4187](http://canlii.ca/t/1mpwt) (NS CA) -- convicted of B&E
  * R. v. J.R.L.J., [1994 CanLII 7617](http://canlii.ca/t/1zxgd) \-- convicted of B&E

## Lesser included offences[[edit](/w/index.php?title=Canadian_Criminal_Law/Included_Offences&action=edit&section=T-1)]

A judge must consider, where the evidence does not make out a particular charged offence, whether it makes out an "included" offence. This is, a secondary offence which underlies the actual charge.

The test for whether an offence is “included” in another offence is "if its elements are embraced in the offence charged (as described in the enactment creating it or as charged in the count) or if it is expressly stated to be an included offence in the Criminal Code itself. The test is strict. It must “necessarily” be included..."[10]

There are three ways in which an offence can be included in a charge:[11]

  1. offence included by statute, e.g., those offences specified in s.662(2) to (6), and attempt provided for in s.660;
  2. offences included in the enactment creating the offence charged, e.g., common assault in a charge of sexual assault;
  3. offences which become included by the addition of apt words of description in the principle charge.

## Examples[[edit](/w/index.php?title=Canadian_Criminal_Law/Included_Offences&action=edit&section=T-2)]

  * mischief is not included in break and enter (R. v. Robitaille, [2012 ONCJ 155](http://canlii.ca/t/fqqvl))

## References[[edit](/w/index.php?title=Canadian_Criminal_Law/Included_Offences&action=edit&section=T-3)]

  1. ↑ see s. 2 "criminal organization offences"
  2. ↑ Drecic, 2011 ONCA 118
  3. ↑ longer authorization (s.186.1 and 196), no need for "investigative necessity" (s. 185(1.1) and 186(1.1)

## General Principles[[edit](/w/index.php?title=Canadian_Criminal_Law/Attempts&action=edit&section=T-1)]

A person attempting to commit an offence can be criminally liable for the attempt. For any attempt to be made out, the person's actions must be more than "mere preparation":[12]

> **Attempts**  
24\. (1) Every one who, having an intent to commit an offence, does or omits to do anything for the purpose of carrying out the intention is guilty of an attempt to commit the offence whether or not it was possible under the circumstances to commit the offence.  
**Question of law**  
(2) The question whether an act or omission by a person who has an intent to commit an offence is or is not mere preparation to commit the offence, and too remote to constitute an attempt to commit the offence, is a question of law.  
R.S., c. C-34, s. 24.
> 
> – [CCC](http://canlii.org/en/ca/laws/stat/rsc-1985-c-c-46/latest/rsc-1985-c-c-46.html#sec24)

There is no general criterion to distinguish between mere preparation and actual attempt.[13]

There is however a "qualitative" distinction that can be made:[14]

    "...the distinction between preparation and attempt is essentially a qualitative one, involving the relationship between the nature and quality of the act in question and the nature of the complete offence, although consideration must necessarily be given, in making that qualitative distinction, to the relative proximity of the act in question to what would have been the completed offence, in terms of time, location and acts under the control of the accused remaining to be accomplished. I find that view to be compatible with what has been said about the actus reus of attempt in this Court and in other Canadian decisions that should be treated as authoritative on this question."

The trial judge should consider the "relative proximity of that conduct to the conduct required to amount to the completed substantive offence. Relevant factors would include time, location and acts under the control of the accused yet to be accomplished.”[15]

  1. ↑ see R. v. Terrence, [1983] 1 S.C.R. 357 [[7]](http://www.canlii.org/en/ca/scc/doc/1983/1983canlii51/1983canlii51.html) and R. v. Kowlyk, [1988] 2 S.C.R. 59[[8]](http://www.canlii.org/en/ca/scc/doc/1988/1988canlii50/1988canlii50.html)
  2. ↑ R v Abernathy 2002 BCCA 8
  3. ↑ R v Gagnon, 2006 MBCA X at 13
  4. ↑ R. v. Killam, [1973] 5 W.W.R. 3 at para. 45
  5. ↑ e.g. R. v. Rimmer, [2011 BCCA 411](http://www.canlii.org/en/bc/bcca/doc/2011/2011bcca411/2011bcca411.html)
  6. ↑ R. v. Gagnon, [2006 MBCA 125](http://canlii.ca/t/1pxb5) (CanLII)
  7. ↑ Gagnon
  8. ↑ R. v. Graham, [1974] SCR 206, [1972 CanLII 72](http://www.canlii.org/en/ca/scc/doc/1972/1972canlii172/1972canlii172.html)  
R. v. Nickerson (1977) 37 CCC (2d) 337 (NSCA);  
R. v. Newton, [1977] 1 S.C.R. 312 [1976 CanLII 57](http://www.canlii.org/en/ca/scc/doc/1976/1976canlii157/1976canlii157.html)  
R. v. L'Heureux, [1985] 2 S.C.R. 159, [1985 CanLII 49](http://www.canlii.org/en/ca/scc/doc/1985/1985canlii49/1985canlii49.html)  
R. v. Kowlyk, [1988] 2 S.C.R. 59, [1988 CanLII 50](http://www.canlii.org/en/ca/scc/doc/1988/1988canlii50/1988canlii50.html)
  9. ↑ R. v. Thatcher [1987 CanLII 53](http://canlii.ca/t/1ftkz) (SCC), (1987), 57 C.R. (3d), 97
  10. ↑ R. v. G.R., 2005 SCC 45, at para. 25 [[9]](http://www.canlii.org/en/ca/scc/doc/2005/2005scc45/2005scc45.html#par25)
  11. ↑ R v GR at para 29
  12. ↑ R. v. Sarrazin, [2010] O.J. No. 3748 (C.A.), at para 54
  13. ↑ R. v. Root [2008 ONCA 869](http://canlii.ca/t/2200k), (2008), 241 C.C.C. (3d) 125 (“authorities have yet to develop a satisfactory general criterion to assist trial judges in making the crucial distinction between mere preparation, on the one hand, and an attempt on the other.”)  
R. v. Deutsch, [1986 CanLII 21](http://canlii.ca/t/1fts2) (SCC) ("the application of this distinction to the facts of a particular case must be left to common sense judgment.")
  14. ↑ R. v. Deutsch, [1986 CanLII 21 at 27](http://canlii.ca/t/1fts2#par27)
  15. ↑ R v Root, [2008 ONCA 869](http://canlii.ca/t/2200k)

## Legislation[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-1)]

> **Conspiracy**  
465\. (1) Except where otherwise expressly provided by law, the following provisions apply in respect of conspiracy:
> 
>     (a) every one who conspires with any one to commit murder or to cause another person to be murdered, whether in Canada or not, is guilty of an indictable offence and liable to a maximum term of imprisonment for life;
>     (b) every one who conspires with any one to prosecute a person for an alleged offence, knowing that he did not commit that offence, is guilty of an indictable offence and liable 
> 
>     (i) to imprisonment for a term not exceeding ten years, if the alleged offence is one for which, on conviction, that person would be liable to be sentenced to imprisonment for life or for a term not exceeding fourteen years, or
>     (ii) to imprisonment for a term not exceeding five years, if the alleged offence is one for which, on conviction, that person would be liable to imprisonment for less than fourteen years;
>     (c) every one who conspires with any one to commit an indictable offence not provided for in paragraph (a) or (b) is guilty of an indictable offence and liable to the same punishment as that to which an accused who is guilty of that offence would, on conviction, be liable; and
>     (d) every one who conspires with any one to commit an offence punishable on summary conviction is guilty of an offence punishable on summary conviction.
> 
> (2) [Repealed, 1985, c. 27 (1st Supp.), s. 61]
> 
> **Conspiracy to commit offences**  
(3) Every one who, while in Canada, conspires with any one to do anything referred to in subsection (1) in a place outside Canada that is an offence under the laws of that place shall be deemed to have conspired to do that thing in Canada.
> 
> **Idem**  
(4) Every one who, while in a place outside Canada, conspires with any one to do anything referred to in subsection (1) in Canada shall be deemed to have conspired in Canada to do that thing.
> 
> **Jurisdiction**  
(5) Where a person is alleged to have conspired to do anything that is an offence by virtue of subsection (3) or (4), proceedings in respect of that offence may, whether or not that person is in Canada, be commenced in any territorial division in Canada, and the accused may be tried and punished in respect of that offence in the same manner as if the offence had been committed in that territorial division.
> 
> **Appearance of accused at trial**  
(6) For greater certainty, the provisions of this Act relating to
> 
>     (a) requirements that an accused appear at and be present during proceedings, and
>     (b) the exceptions to those requirements,
> 
> apply to proceedings commenced in any territorial division pursuant to subsection (5).
> 
> **Where previously tried outside Canada**  
(7) Where a person is alleged to have conspired to do anything that is an offence by virtue of subsection (3) or (4) and that person has been tried and dealt with outside Canada in respect of the offence in such a manner that, if the person had been tried and dealt with in Canada, he would be able to plead autrefois acquit, autrefois convict or pardon, the person shall be deemed to have been so tried and dealt with in Canada.
> 
> R.S., 1985, c. C-46, s. 465; R.S., 1985, c. 27 (1st Supp.), s. 61; 1998, c. 35, s. 121.
> 
> – [CCC](http://www.canlii.ca/t/7vf2#sec465)

## Proof of the Offence[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-2)]

  1. **[identity](/wiki/Canadian_Criminal_Law/Identity)** of accused
  2. **[date and time](/wiki/Canadian_Criminal_Law/Jurisdiction_and_Time)** of incident
  3. **[jurisdiction](/wiki/Canadian_Criminal_Law/Jurisdiction_and_Time)** (incl. region and province)
  4. **the words communicated in the conspiracy**
  5. **there was an agreement made between the parties**
  6. **the parties had an intention to agree to put a "common design into effect"** and did in fact agree
  7. **the parties did not change their minds or intention to put common design into effect**

## Principles[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-3)]

A conspiracy is an agreement between two or more persons to do an unlawful act.[1]

There must be an "intention to agree, the completion of an agreement and a common design."[2] The Crown needs only prove that there was "a meeting of the minds with regard to a common design to do something unlawful".[3]

To prove conspiracy the facts must satisfy a three-part test from R. v. Carter, [1982] 1 S.C.R. 938 [1982 CanLII 35](http://www.canlii.org/en/ca/scc/doc/1982/1982canlii35/1982canlii35.html):

  1. has the Crown proven beyond a reasonable doubt the existence of the conspiracy?
  2. has the Crown proven that the accused was probably a member of the conspiracy?
  3. considering all of the evidence, is the accused guilty beyond a reasonable doubt of being a member of the conspiracy?

A conspiracy must include (1) an agreement and (2) the unlawful objective or "common design".[4]

As well, unlawful objective does not need to come about. It is the planning that is the criminal act.[5]

An conspiracy made over the telephone will occur within the jurisdiction of both calling parties.[6]

It is not relevant whether "from an objective point of view, commission of the offence may be impossible."[7]

  1. ↑ R v O'Brien >[ 1954 CanLII 42](http://canlii.ca/t/21v9k), [1954] SCR 666 at pp.668-9
  2. ↑ United States of America v. Dynar, [1997 CanLII 359](http://canlii.ca/t/1fr0t), [1997] 2 SCR 462 at para.86 and R. v. Root, [2008] O.J. No. 5214 (OCA) at para. 66
  3. ↑ Dynar, at para. 87
  4. ↑ R v O'Brien [1954] SCR 666 at para. 2-3, per Taschereau J. ("It is of course, essential that the conspirators have the intention to agree, and this agreement must be complete ... there must exist an intention to put the common design into effect.")
  5. ↑ R. v. O'Brien, at 4 ("The law punishes conspiracy so that the unlawful object is not attained. It considers that several persons who agree together to commit an unlawful act, are a menace to society, and even if they do nothing in furtherance of their common design, the state intervenes to exercise a repressive action, so that the intention is not materialized, and does not become harmful to any one.")
  6. ↑ R. v. Doucette, 2003 PESCAD 7
  7. ↑ United States v. Dynar, [1997] 2 S.C.R. 462 at para. 105

### Agreement[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-4)]

An agreement can be implied or tacit. It requires a meeting of the minds to create a common intention to commit an offence. The parties must have knowledge of a common goal and agreement to achieve it.[1]

It is not enough that there be a common intention.[2] Nor is passive acquiescence to a criminal plan sufficient[3], knowledge of the plan[4], or nor wilful blindness.

It is not a "formal agreement" and may be implicit.[5]

There must be a "a common plan with a common objective".[6]

Where there is a pre-existing conspiracy, the accused must have adopted it or consented to participate in achieving the goal.[7]

A conditional agreement can still be an agreement.[8]

The charge must identify the crime(s) planned.[9] And it should generally identify the co-conspirators.[10]

It is a valid defence to establish that the accused pretended to agree to the conspiracy.[11]

  1. ↑ Atlantic Sugar Refineries Co. v. Canada (Attorney General), 54 C.C.C. (2d) 373, [1980] 2 S.C.R. 644
  2. ↑ O'Brien
  3. ↑ R v McNamara (1981), 56 C.C.C. (2d) 193 at 452 (Ont. C.A.) ("Mere knowledge of, discussion of or passive acquiescence in a plan of criminal conduct is not, of itself, sufficient")
  4. ↑ Goode, Criminal Conspiracy in Canada (1975), p. 16
  5. ↑ Goode, Criminal Conspiracy in Canada (1975), p. 16
  6. ↑ R. v. Cotroni, (sub nom. Papalia v. R.) [1979] 2 S.C.R. 256
  7. ↑ R. v. Lamontagn (1999), 142 C.C.C. (3d) 561 (Que. C.A.)
  8. ↑ R. v. Root, 2008 ONCA 869 (Ont. C.A.) at para. 70
  9. ↑ R. v. Saunders, [1990] 1 S.C.R. 1020
  10. ↑ R. v. B. (T.L.) (1989), 52 C.C.C. (3d) 72 (NSCA)  
R. v. Root, 2008 ONCA 869 at para. 69
  11. ↑ R. v. Delay (1976), 25 C.C.C. (2d) 575 (Ont. C.A.)

### Participation[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-5)]

A member of a conspiracy who refuses to execute the plan is still guilty.[1]

Involvement in only part of a whole plan will still be found guilty.[2]

An accused cannot be convicted for attempted conspiracy.[3]

  1. ↑ R. v. O'Brien, at para 4
  2. ↑ R. v. Shirose, [1999] 1 S.C.R. 565
  3. ↑ R c Dery 2006 SCC 53

### Evidence[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-6)]

Words of the co-conspirator are admissible against the accused. They are not hearsay and are rather the actus reus.[1]

Further, the co-conspirators exception to hearsay makes statements admissible against the accused.[2]

Statements by the co-conspirator that are not related to the conspiracy are not admissible against the accused.[3]

  1. ↑ R. v. Cook (1984), 39 C.R. (3d) 300 (ONCA) aff'd in [1986] 1 S.C.R. 144
  2. ↑ R. v. Gassyt (1998), 127 C.C.C. (3d) 546 (ONCA)  
R. v. Perciballi (2001), 154 C.C.C. (3d) 481 (Ont. C.A.) aff'd in 2002 SCC 51  
R. v. Gagnon (2000), 147 C.C.C. (3d) 193 (ONCA)
  3. ↑ R. v. Henke (1989), 72 C.R. (3d) 395 (Alta C.A.)  
R. v. Maugey (2000), 146 C.C.C. (3d) 99 (Ont. C.A.)  


## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-7)]

  * [Canadian Criminal Law/Parties#Counselling](/wiki/Canadian_Criminal_Law/Parties#Counselling)

## References[[edit](/w/index.php?title=Canadian_Criminal_Law/Conspiracy&action=edit&section=T-8)]

  1. ↑ see s. 2 "criminal organization offences"
  2. ↑ Drecic, 2011 ONCA 118
  3. ↑ longer authorization (s.186.1 and 196), no need for "investigative necessity" (s. 185(1.1) and 186(1.1)

# Interpretation[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit&section=3)]

## Principles of Statutory Interpretation[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-1)]

The fundamental principle of statutory interpretation is that "the words of a statute be read in their entire context and in their grammatical and ordinary sense harmoniously with the scheme of the Act, the object of the Act, and the intention of the legislature"[1]

It is understood that legislators choose to adopt “language which accurately conveys the effect of the law without in itself imposing an unnecessary burden of translation and explanation”.[2]

The principle of legality requires that legislation provide a degree of certainty, and should reflect “the overall need to use the criminal law with restraint”[3]

No provision in an act "should be interpreted so as to render it mere surplusage.”[4]

Under s. 12 of the Interpretation Act, "[e]very enactment is deemed remedial, and shall be given such fair, large and liberal construction and interpretation as best ensures the attainment of its objects."[5]

It is a principle that "Parliament does not speak in vain".[6]

"[A]bsent express language to the contrary, the same words in two subsections of the same provision should be treated alike... Giving the same words the same meaning throughout a statute is a basic principle of statutory interpretation".[7]

  1. ↑ Rizzo & Rizzo Shoes Ltd. (Re), 1998 CanLII 837 (SCC), [1998] 1 S.C.R. 27, at para. 21  
Bell Expressive Limited Partnership v. Rex, 2002 SCC 42, [2002] 2 S.C.R. 559, at para.26  
R v Brode, 2012 ONCA 140, (“direct that the words of a statute be read in their entire context and in their grammatical and ordinary sense harmoniously with the scheme of the Act, the object of the Act, and the intention of the legislature.”)
  2. ↑ Howard’s Criminal Law (5th ed. 1990), at p. 11
  3. ↑ see D. Stuart, Canadian Criminal Law: A Treatise (5th ed. 2007), at p. 86
  4. ↑ R. v. Proulx [2000 SCC 61 at 25](http://canlii.ca/t/527b#par25)
  5. ↑ R.S., c. I-23, s. 11.
  6. ↑ Attorney General of Quebec v. Carrières Ste-Thérèse Ltée, 1985 CanLII 35 (SCC), [1985] 1 S.C.R. 831, at p. 838
  7. ↑ R. v. Charette, [2009 ONCA 310](http://canlii.ca/t/234f1) at para. 38 citing R. v. Zeolkowski, 1989 CanLII 72 (SCC), [1989] 1 S.C.R. 1378 at p. 1387

## Charter Interpretation[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-2)]

A judge must interpret a Charter right using a "purposive approach"[1] or "purposive analysis".[2]

  1. ↑ R v Brydges [1990] 1 S.C.R. 190
  2. ↑ Hunter v. Southam Inc., 1984 CanLII 33 (SCC), [1984] 2 S.C.R. 145  
R. v. Big M Drug Mart Ltd., 1985 CanLII 69 (SCC), [1985] 1 S.C.R. 295  


## Amendments[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-3)]

### Meaning[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-4)]

Amendments generally only have retrospective effect in exceptional circumstances. As there is a presumption against retrospectivity where a vested or substantive right is affected.[1]

Where an amendment to legislation effects a constitutional right, it generally means that the legislation will not be retrospective.[2]

An amendment that has an effect on the content or existence of an available defence suggests is an indicator that it affects substantive rights, and so is not retrospective.[3]

An increase in a maximum penalty is a "clear indication to sentencing courts of the seriousness which the criminal conduct addressed by the changes is viewed by contemporary society."[4]However, the increase of minimum penalties should not be read into "too much".[5]

  1. ↑ R. v. Dineley [2012 SCC 58](http://canlii.ca/t/ftl1j)
  2. ↑ R. v. Dineley [2012 SCC 58](http://canlii.ca/t/ftl1j) (CanLII)
  3. ↑ Dineley - removal of Carter defence creates presumption against retrospectivity
  4. ↑ R v Richardson [2006] EWCA Crim 3186 at para. 4
  5. ↑ R v WE (2010) 251 CCC (3d) 213 (NLCA)

### Effect on Previous Ongoing Proceedings[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-5)]

Where the law is changed in a manner that is procedural in nature, it applies to all matters regardless of the offence date. A change in the law that removes or adds a right will only apply to offences that post-date the amendment.[1]

It is "not generally in the public interest to delay trials simply on the basis that a pending action in the higher courts might have some effect on the trial".[2]

  1. ↑ R v Wildman (1984) 14 CCC (3d) 321  
See also: R v Bickford (1989) 51 CCC (3d) 181 (ONCA)
  2. ↑ R v Baker [1994] NSJ 135 (NSCA)

## Stare Decisis[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-6)]

The principle of _stare decisis_ refers to the requirement that when a legal issue has been determined and decided other courts should follow the decision.

The principle is the "glue that holds together the various levels of Canadian courts and it is the principle that elevates the rule of law above the rule of individual judges."[1] It is considered "essential to law" and a "central pillar" to our system of law. It ensures predictability without which differing results would be unjust.[2]

English common law sets out three exceptions of the principles of stare decisis.[3]

  1. "The court is entitled and bound to decide which of two conflicting decisions of its own it will follow"
  2. "The court is bound to refuse to follow a decision of its own which, though not expressly overruled, cannot, in its opinion, stand with a decision of the House of Lords";
  3. "The court is not bound to follow a decision of its own if it is satisfied that the decision was given per incuriam, for example, where a statute or rule having statutory effect which would have affected the decision was not brought the attention of the earlier court"

When considering overruling a precedent from the Supreme Court, the Court should balance the importance of correctness and certainty, considering whether it is more important to maintain certainty with the precedent or ensure correctness by changing it. The Court should be satisfied that there are compelling reasons the precedent should be overruled. [4]

  1. ↑ R. v. Hummel, (1987), 36 C.C.C. (3d) 8 at para 7
  2. ↑ R. v. Arcand, [2010 ABCA 363](http://canlii.ca/t/2dnsp) (CanLII) at para. 182
  3. ↑ Young v. Bristol Aeroplane Co., [1944] K.B. 718  
Cross and Harris, Precedent in English Law, (4d) (Clarendon Press, Oxford, 1991) at p. 143
  4. ↑ Canada v. Craig, [2012 SCC 43](http://canlii.ca/t/fs6sb) (CanLII) at para. 27

## Ratio Decidendi and Obiter[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-7)]

Each statement of a judge should not be treated as if it were legislation.[1]

Ratio decidendi ("ratio") and obiter dicta ("obiter") are the terms used to distinguish between binding statements of law and commentary within a decision.

Any judicial comment in a decision that forms part of the rationale to reach his decision is considered part of the ratio and is binding upon lower courts.

A comment by a judge in a decision that does not form part of the rationale to reach his decision is considered obiter. Judicial comments that are obiter do not have binding authority on lower courts. Obiter can have persuasive authority, however.

This distinction between ratio and obiter can be fluid.

The degree of weight the obiter has is proportionate to its proximity to the ratio decidendi.[2]

Stated negatively, the statements of a higher court are not binding where the words are "sufficiently tangential to the disposition of the case".[3]

On the outer edge from the ratio consists of "commentary, examples or exposition that are intended to be helpful, but are certainly not 'binding'". [4]

The purpose of this distinction is to both promote certainty in the law as well as permit "growth and creativity".[5]

  1. ↑ R. v. Henry, 2005 SCC 76 ("The notion that each phrase in a judgment of this Court should be treated as if enacted in a statute is not supported by the cases and is inconsistent with the basic fundamental principle that the common law develops by experience.")
  2. ↑ R. v. Henry, 2005 SCC 76 at paras. 52-59 ("All obiter do not have, and are not intended to have, the same weight. The weight decreases as one moves from the dispositive ratio decidendi to a wider circle of analysis which is obviously intended for guidance and which should be accepted as authoritative. ")
  3. ↑ Canada (Attorney General) v. Bedford, 2012 ONCA 186 (CanLII) at para. 69  
R. v. Prokofiew, 2010 ONCA 423 (CanLII), aff’d 2012 SCC 49 (CanLII)  
Henry
  4. ↑ Henry
  5. ↑ Henry

## See Also[[edit](/w/index.php?title=Canadian_Criminal_Law/Principles_of_Interpretation&action=edit&section=T-8)]

  * [Interpretation Act, RSC 1985, c I-21](http://www.canlii.org/en/ca/laws/stat/rsc-1985-c-i-21/latest/rsc-1985-c-i-21.html)

[v](/wiki/Template:Canadian_Criminal_Law) • [d](/w/index.php?title=Template_talk:Canadian_Criminal_Law&action=edit&redlink=1) • [e](//en.wikibooks.org/w/index.php?title=Template:Canadian_Criminal_Law&action=edit)

 

Canadian Criminal Law

I - [Introduction](/wiki/Canadian_Criminal_Law/Introduction) · II - [Proof of Elements](/wiki/Canadian_Criminal_Law/Proof_of_Elements) · III - [Doctrine of Liability](/wiki/Canadian_Criminal_Law/Doctrines_of_Liability) · IV - [Principles of Interpretation](/wiki/Canadian_Criminal_Law/Principles_of_Interpretation) · V - [Offences](/wiki/Canadian_Criminal_Law/Offences) · VI - [Defences](/wiki/Canadian_Criminal_Law/Defences) · VII - [Appendix](/wiki/Canadian_Criminal_Law/Appendix)

Books: **[Canadian Criminal Law](/wiki/Canadian_Criminal_Law) \- [Canadian Criminal Evidence](/wiki/Canadian_Criminal_Evidence) \- [Canadian Criminal Procedure and Practice](/wiki/Canadian_Criminal_Procedure_and_Practice) \- [Canadian Criminal Sentencing](/wiki/Canadian_Criminal_Sentencing)**

# Offence Chart[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit&section=4)]

This chart currently does not include all changes to offences that occurred during 2012.

## Violence-related offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-1)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)

[Causing a Disturbance](/wiki/Canadian_Criminal_Sentencing/Offences/Causing_a_Disturbance)
175
Summary
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
18 months jail or $5,000 fine
N/A

[Criminal Harassment](/wiki/Canadian_Criminal_Sentencing/Offences/Criminal_Harassment)
264
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
10 years jail

[Threat to cause harm or death](/wiki/Canadian_Criminal_Sentencing/Offences/Uttering_Threats)
264.1 (1)(a)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
18 months jail or $5,000 fine
5 years jail

[Threat to cause damage property or injure animal](/wiki/Canadian_Criminal_Sentencing/Offences/Uttering_Threats)
264.1(1)(b),(c)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Assault](/wiki/Canadian_Criminal_Sentencing/Offences/Common_Assault)
266
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
5 years jail

[Assault with a weapon](/wiki/Canadian_Criminal_Sentencing/Offences/Assault_with_a_Weapon)
267(1)(a)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
18 months jail or $5,000 fine
10 years jail

[Assault causing bodily harm](/wiki/Canadian_Criminal_Sentencing/Offences/Assault_Causing_Bodily_Harm)
267(1)(b)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
18 months jail or $5,000 fine
10 years jail

[Aggravated Assault](/wiki/Canadian_Criminal_Sentencing/Offences/Aggravated_Assault)
268
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / <s>CSO</s>
N/A
N/A
14 years jail

[Assault Peace Officer](/wiki/Canadian_Criminal_Sentencing/Offences/Assault_Peace_Officer)
270
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
5 years jail

## Theft-related offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-2)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)

[Theft under $5,000](/wiki/Canadian_Criminal_Sentencing/Offences/Theft_Under_$5,000)
334(b)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Theft over $5,000](/wiki/Canadian_Criminal_Sentencing/Offences/Theft_Over_$5,000)
334(a)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
10 years jail

[Possession stolen prop. under $5,000](/wiki/Canadian_Criminal_Sentencing/Offences/Possession_of_Stolen_Property)
355(b)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Possession stolen prop. over $5,000](/wiki/Canadian_Criminal_Law/Offences/Possession_of_Stolen_Property)
355(a)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
10 years jail

[Fraud under $5,000](/wiki/Canadian_Criminal_Sentencing/Offences/Fraud_Under_$5,000)
380(1)(b)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Fraud over $5,000](/wiki/Canadian_Criminal_Sentencing/Offences/Fraud_Over_$5,000)
380(1)(a)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
14 years jail

## Property damage Offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-3)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)
Mandatory Orders
Discretionary Orders

[Mischief under $5,000](/wiki/Canadian_Criminal_Sentencing/Offences/Mischief)
430(4)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Mischief over $5,000](/wiki/Canadian_Criminal_Sentencing/Offences/Mischief)
430(3)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
10 years jail

[Arson (disregard for human life)](/wiki/Canadian_Criminal_Sentencing/Offences/Arson)
433
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
life
109(1)(d) / 491
110(1)(b) / 462.37 / 486(4.1) / 738 / SDO

[Arson (damage to property)](/wiki/Canadian_Criminal_Sentencing/Offences/Arson)
434 / 434.1
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
14 years jail
109(1)(d) / 491
110(1)(b) / 462.37 / 486(4.1) / 738 / SDO

[Arson (fraudulent purpose)](/wiki/Canadian_Criminal_Sentencing/Offences/Arson)
435
Indictable
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
10 years jail

[Arson (negligence)](/wiki/Canadian_Criminal_Sentencing/Offences/Arson)
436(1)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
5 years jail

[Possession of Incendiary Materials](/wiki/Canadian_Criminal_Sentencing/Offences/Arson)
436.1
Indictable
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
5 years jail

## Break and Enter[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-4)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)
Mandatory Orders
Discretionary Orders

[Break and enter with intent (dwelling)](/wiki/Canadian_Criminal_Sentencing/Offences/Break_and_Enter)
348
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
life
109 / 491
SDO

[Break and enter with intent (not dwelling)](/wiki/Canadian_Criminal_Sentencing/Offences/Break_and_Enter)
348
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
10 years
N/A
SDO

[Being unlawfully in a dwelling-house](/wiki/Canadian_Criminal_Sentencing/Offences/Break_and_Enter)
349
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
10 years

Possession of Break-in Instruments
351
Indictable
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
10 years

## Robbery[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-5)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)

Robbery (with firearm)
344(a)
Indictable
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
4 years
N/A
life

[Robbery](/wiki/Canadian_Criminal_Sentencing/Offences/Robbery)
344(b)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
life

## Weapons Offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-6)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)
Mandatory Orders
Discretionary Orders

[Unsafe storage of a firearm](/wiki/Canadian_Criminal_Sentencing/Offences/Unsafe_Storage_of_a_Firearm)
86
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail (1st offence)  
5 years jail (subsequent)
109; 491
110; 738

[Pointing a firearm](/wiki/Canadian_Criminal_Sentencing/Offences/Pointing_a_Firearm)
87
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
5 years jail
109(1)(d); 491
110; 486(4.1)

[Possession of a weapon for a dangerous purpose](/wiki/Canadian_Criminal_Sentencing/Offences/Possession_of_a_Weapon_for_a_Dangerous_Purpose)
88
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
10 years jail
s.109 (if on prohibition at the time) / s.491
s.110

[Carrying concealed weapon](/wiki/Canadian_Criminal_Sentencing/Offences/Carrying_a_Concealed_Weapon)
90
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
5 years jail
s.109 (if on prohibition at the time) / s.491
s.110

[Unauthorized possession of firearm](/wiki/Canadian_Criminal_Sentencing/Offences/Unauthorized_Possession_of_a_Firearm)
91
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
5 years jail
109(1)(d); 491
110; 486(4.1)

[Possn. of firearm knowing possn. unauthorized](/wiki/Canadian_Criminal_Sentencing/Offences/Possession_of_Unauthorized_Firearm)
92
Indictable
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Possn. of restricted weapon with ammunition](/wiki/Canadian_Criminal_Sentencing/Offences/Possession_of_a_Restricted_or_Prohibited_Firearm)
95
Hybrid
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
3 years jail (1st); 5 years jail (2nd) (by indictment)
12 months jail or $5,000 fine
10 years jail

## Sexual Offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-7)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)
Mandatory Orders
Discretionary Orders

[Sexual Interference](/wiki/Canadian_Criminal_Sentencing/Offences/Sexual_Interference)
151
Hybrid
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
15 days jail (summ.) or 45 days jail (Indic.)
6 months jail or $5,000 fine
14 years jail
SOIRA (10 Summ./20 Indict.) ...

[Making Child Pornography](/wiki/Canadian_Criminal_Sentencing/Offences/Child_Pornography)
163.1(2)
Hybrid
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
90 days (S) / 1 year (I)
18 months
10 years
SOIRA (10 Summ./20 Indict.)

[Distribution of Child Pornography](/wiki/Canadian_Criminal_Sentencing/Offences/Child_Pornography)
163.1(3)
Hybrid
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
90 days (S) / 1 year (I)
18 months
10 years
SOIRA (10 Summ./20 Indict.)

[Possession of Child Pornography](/wiki/Canadian_Criminal_Sentencing/Offences/Child_Pornography)
163.1(4)
Hybrid
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
14 days (S) / 45 days (I)
18 months
5 years
SOIRA (10 Summ./20 Indict.)

[Accessing of Child Pornography](/wiki/Canadian_Criminal_Sentencing/Offences/Child_Pornography)
163.1(4.1)
Hybrid
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
14 days (S) / 45 days (I)
18 months
5 years
SOIRA (10 Summ./20 Indict.)

[Child Luring](/wiki/Canadian_Criminal_Sentencing/Offences/Child_Luring)
172.1
Hybrid
<s>Dis</s>* / <s>SS</s>* / <s>F</s>* / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>* [limited]
90 days (S) / 1 year (I)
18 months
10 years
SOIRA (10 Summ./20 Indict.); forfeiture (164.1); DNA (primary); 161 Order

[Indecent Act](/wiki/Canadian_Criminal_Sentencing/Offences/Indecent_Act)
173
Summary
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
N/A
SOIRA (10yrs)...

[Sexual Assault](/wiki/Canadian_Criminal_Sentencing/Offences/Sexual_Assault)
271
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
18 months jail / $2,000 fine
10 years jail
SOIRA (10yrs Summ. / 20yrs Indict.) ...

[Sexual Assault with a weapon](/wiki/Canadian_Criminal_Sentencing/Offences/Sexual_Assault_with_a_Weapon)
272(1)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
14 years jail

[Sexual Assault with a weapon (firearm)](/wiki/Canadian_Criminal_Sentencing/Offences/Sexual_Assault_with_a_Weapon)
272(1)
Indictable
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / Im+Pb / F+Im / <s>CSO</s>
4 years jail
N/A
14 years jail
SOIRA (20yrs) ...

[Aggravated Sexual Assault](/wiki/Canadian_Criminal_Sentencing/Offences/Aggravated_Sexual_Assault)
273
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / <s>CSO</s>
N/A
N/A
Life
SOIRA (life) ...

[Aggravated Sexual Assault (with Weapon)](/wiki/Canadian_Criminal_Sentencing/Offences/Aggravated_Sexual_Assault)
273(1), 273(2)(a)
Indictable
<s>Dis</s> / <s>SS</s> / <s>F</s> / <s>F+Pb</s> / Im / <s>Im+Pb</s> / F+Im / <s>CSO</s>
4 years jail
N/A
Life
SOIRA (life)

## Motor Vehicle Offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-8)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)
Mandatory Orders
Discretionary Orders

[Dangerous Driving (no injury)](/wiki/Canadian_Criminal_Law/Offences/Dangerous_Operation_of_a_Motor_Vehicle)
249(1)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
5 years jail

[Dangerous Driving (injury)](/wiki/Canadian_Criminal_Sentencing/Offences/Dangerous_Operation_of_a_Motor_Vehicle)
249(3)
Indictable
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
10 years jail

[Flight from Police](/w/index.php?title=Canadian_Criminal_Sentencing/Offences/Flight_from_Police&action=edit&redlink=1)
249.1
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
5 years jail

[Driving while Impaired and Over 80 /  
Driving while BAC over 80mg](/wiki/Canadian_Criminal_Sentencing/Offences/Impaired_Driving_and_Over_80)
253(a) / 253(b)
Hybrid
Dis / <s>SS</s> / F / F+Pb / Im / Im+Pb / F+Im / <s>CSO</s>
$1,000 fine (1st time) / 30 days jail (2nd time) / 120 days jail (3rd time)
18 months jail
5 years jail

[Refusal or failure to provide a breath/blood sample](/wiki/Canadian_Criminal_Sentencing/Offences/Refusal)
254(5)
Hybrid
<s>Dis</s> / <s>SS</s> / F / F+Pb / Im / Im+Pb / F+Im / <s>CSO</s>
$1,000 fine (1st time) / 30 days jail (2nd time) / 120 days jail (3rd time)
18 months jail
5 years jail

[Driving while disqualified](/wiki/Canadian_Criminal_Sentencing/Offences/Driving_while_Disqualified)
259(4)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

## Administration of Justice Offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-9)]

Offence Code Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)
Mandatory Orders
Discretionary Orders

[Breach of Release conditions](/wiki/Canadian_Criminal_Law/Offences/Breach_of_Undertaking,_Recognizance,_or_Probation)
145(3)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail
s. 109; 491
s. 110; 738; 486(4.1)

[Breach of undertaking under 499(2) or 503(2.1)](/wiki/Canadian_Criminal_Sentencing/Offences/Breach_of_Undertaking,_Recognizance,_or_Probation)
145(5.1)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail
s. 109; 491
s. 110; 738; 486(4.1)

[Breach of Probation conditions](/wiki/Canadian_Criminal_Sentencing/Offences/Breach_of_Undertaking,_Recognizance,_or_Probation)
733.1(1)
Hybrid (Absolute)
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Failure to Attend Court (recog / undertaking)](/wiki/Canadian_Criminal_Sentencing/Offences/Failure_to_Attend_Court_or_Appear)
145(2)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail
N/A
s. 486(4.1)

[Failure to Attend Court (summons)](/wiki/Canadian_Criminal_Sentencing/Offences/Failure_to_Attend_Court_or_Appear)
145(4)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail
N/A
s. 486(4.1); 738; SDO?

[Obstruct a Peace Officer](/wiki/Canadian_Criminal_Sentencing/Offences/Obstruction_of_a_Peace_Officer)
129
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail

[Perjury](/wiki/Canadian_Criminal_Sentencing/Offences/Perjury)
131, 132
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
14 years jail
N/A
s. 486(2.101) / 486(4.1) / 738 / SDO?

[Fabricating Evidence with Intent to Mislead](/wiki/Canadian_Criminal_Sentencing/Offences/Fabricating_Evidence)
137
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
14 years jail
N/A
s. 486(2.101) / 486(4.1) / 738 / SDO?

Giving Contradictory Evidence with Intent to mislead [1]
136
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
14 years jail
N/A
s. 486(2.101) / 486(4.1) / 738 / SDO?

[Intimidation of a Justice System Participant](/wiki/Canadian_Criminal_Sentencing/Offences/Intimidation_of_a_Justice_System_Participant)
423.1
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
14 years jail
s. 109 / 491 / PDO
s. 486(2.101) / 486(4.1) / 738

[Breach of Recognizance](/wiki/Canadian_Criminal_Sentencing/Offences/Breach_of_Undertaking,_Recognizance,_or_Probation)
811
Hybrid (Absolute)
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
6 months jail or $5,000 fine
2 years jail
N / A

## Controlled Substances Offences[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-10)]

Offence CDSA Section Election
Dispositions
Minimum
Maximum (Summary)
Maximum (Indictable)
Mandatory Orders
Discretionary Orders

[Possession of marijuana (=< 30g)  
Possession of hashish (=< 1g)](/wiki/Canadian_Criminal_Sentencing/Offences/Drug_Possession)
4(1)
Summary
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
$1,000 and 6 months jail
N/A
N/A

[Possession of marijuana](/wiki/Canadian_Criminal_Sentencing/Offences/Drug_Possession) (> 30g)  
[Possession of hashish](/wiki/Canadian_Criminal_Law/Offences/Drug_Possession) (> 1g)
4(1)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
$1,000 and 6 months jail (first); $2,000 and 1 year jail (second or more)
5 years less a day jail

[Possession of Cocaine or Heroin](/wiki/Canadian_Criminal_Sentencing/Offences/Drug_Possession)
4(1)
Hybrid
Dis / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
$1,000 and 6 months jail (first); $2,000 and 1 year jail (second or more)
7 years jail

[Possn. for Purpose of Trafficking in Marijuana](/wiki/Canadian_Criminal_Sentencing/Offences/Drug_Trafficking) /  
[Trafficking in Marijuana](/wiki/Canadian_Criminal_Law/Offences/Drug_Trafficking)
5(2) / 5(1)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
5 years less a day  
Life in jail (>30kg)

[Possn. for Purpose of Trafficking in Cocaine or Heroin](/wiki/Canadian_Criminal_Sentencing/Offences/Drug_Trafficking) /  
[Trafficking in Cocaine or Heroin](/wiki/Canadian_Criminal_Law/Offences/Drug_Trafficking)
5(2) / 5(1)
Indictable
<s>Dis</s> / SS / F / F+Pb / Im / Im+Pb / F+Im / CSO
N/A
N/A
Life in jail

## Key[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-11)]

Dispositions:

  * AD = absolute discharge (s. 730)
  * CD = conditional discharge with probation
  * SS = suspended sentence (s. 731(1)(a))
  * F = fine (s. 734)
  * I = imprisonment (s. 718.3, 787)
  * FP = fine and probation (s. 731(1)(b))
  * IP = imprisonment and probation (s. 731(1)(b))

Orders:

  * PDO = Primary Designated Offences (Mandatory DNA order)
  * SDO = Secondary Designated Offences (discretionary DNA order)
  * SOIRA = Sex Offender Registry Act
  * 462.37 = forfeiture of proceeds
  * 490.1 = forfeiture of property related to the offence
  * 491 = mandatory firearms/weapons forfeiture order
  * 486(4.1) = discretionary publication ban
  * 738 = discretionary restitution order
  * 739 = return of property

  1. ↑ s. 136(4) needs consent of AG before prosecution

## Jurisdiction[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-12)]

    _See also [Jurisdiction](/wiki/Canadian_Criminal_Procedure_and_Practice/Jurisdiction)_

Absolute Jurisdiction (s. 553) Exclusive Jurisdiction (s. 469)

  * theft, other than theft of cattle (value =< $5,000)
  * obtaining money or property by false pretences, (value =< $5,000)
  * possess stolen property (value =< $5,000)
  * fraud (value =< $5,000)
  * mischief under subsection 430(4) (value =< $5,000)
  * Gaming and betting-related offences (s. 201 - 210)
  * fraud in relation to fares
  * breach of recognizance
  * failure to comply with probation order
  * paragraph 4(4)(a) of the Controlled Drugs and Substances Act
  * subsection 5(4) of the Controlled Drugs and Substances Act.

  * treason (s. 47)
  * alarming Her Majesty (s. 49)
  * intimidating Parliament or a legislature (s. 51)
  * inciting to mutiny (s. 53)
  * seditious offences (s. 61)
  * piracy (s. 74) and piratical acts (s. 75)
  * attempts of any of the above listed
  * murder (s. 235) and conspiracy to commit murder
  * offences under any of sections 4 to 7 of the Crimes Against Humanity and War Crimes Act;
  * the offence of being an accessory after the fact to high treason or treason or murder;
  * bribery of a holder of a judicial office (s. 119)

## DNA Orders s. 487.051[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-13)]

    _See also [DNA Orders](/wiki/Canadian_Criminal_Sentencing/Ancillary_Orders/DNA_Orders)_

Primary Designated Offences s. 487.04 Secondary Designated Offences s. 487.04

current Code (a)

  * (i) subsection 212(2.1) (aggravated offence in relation to living on the avails of prostitution of a person under the age of eighteen years),
  * (ii) section 235 (murder),
  * (iii) section 236 (manslaughter),
  * (iv) section 239 (attempt to commit murder),
  * (v) section 244 (discharging firearm with intent),
  * (vi) section 244.1 (causing bodily harm with intent — air gun or pistol),
  * (vi.1) section 244.2 (discharging firearm — recklessness),
  * (vii) paragraph 245(a) (administering noxious thing with intent to endanger life or cause bodily harm),
  * (viii) section 246 (overcoming resistance to commission of offence),
  * (ix) section 267 (assault with a weapon or causing bodily harm),
  * (x) section 268 (aggravated assault),
  * (xi) section 269 (unlawfully causing bodily harm),
  * (xi.1) section 270.01 (assaulting peace officer with weapon or causing bodily harm),
  * (xi.2) section 270.02 (aggravated assault of peace officer),
  * (xii) section 272 (sexual assault with a weapon, threats to a third party or causing bodily harm),
  * (xiii) section 273 (aggravated sexual assault),
  * (xiv) section 279 (kidnapping),
  * (xv) section 344 (robbery), and
  * (xvi) section 346 (extortion),

current Code (a.1)

  * (i) section 75 (piratical acts),
  * (i.01) section 76 (hijacking),
  * (i.02) section 77 (endangering safety of aircraft or airport),
  * (i.03) section 78.1 (seizing control of ship or fixed platform),
  * (i.04) subsection 81(1) (using explosives),
  * (i.05) section 83.18 (participation in activity of terrorist group),
  * (i.06) section 83.19 (facilitating terrorist activity),
  * (i.07) section 83.2 (commission of offence for terrorist group),
  * (i.08) section 83.21 (instructing to carry out activity for terrorist group),
  * (i.09) section 83.22 (instructing to carry out terrorist activity),
  * (i.1) section 83.23 (harbouring or concealing),
  * (i.11) section 151 (sexual interference),
  * (ii) section 152 (invitation to sexual touching),
  * (iii) section 153 (sexual exploitation),
  * (iii.1) section 153.1 (sexual exploitation of person with disability),
  * (iv) section 155 (incest),
  * (iv.1) subsection 163.1(2) (making child pornography),
  * (iv.2) subsection 163.1(3) (distribution, etc., of child pornography),
  * (iv.3) subsection 163.1(4) (possession of child pornography),
  * (iv.4) subsection 163.1(4.1) (accessing child pornography),
  * (iv.5) section 172.1 (luring a child),
  * (v) subsection 212(1) (procuring),
  * (v.1) subsection 212(2) (procuring),
  * (v.2) subsection 212(4) (offence — prostitution of person under eighteen),
  * (vi) section 233 (infanticide),
  * (vii) section 271 (sexual assault),
  * (vii.1) section 279.01 (trafficking in persons),
  * (vii.11) section 279.011 (trafficking of a person under the age of eighteen years),
  * (viii) section 279.1 (hostage taking),
  * (ix) paragraph 348(1)(d) (breaking and entering a dwelling-house),
  * (x) section 423.1 (intimidation of a justice system participant or journalist),
  * (xi) section 431 (attack on premises, residence or transport of internationally protected person),
  * (xii) section 431.1 (attack on premises, accommodation or transport of United Nations or associated personnel),
  * (xiii) subsection 431.2(2) (explosive or other lethal device),
  * (xiv) section 467.11 (participation in activities of criminal organization),
  * (xv) section 467.12 (commission of offence for criminal organization), and
  * (xvi) section 467.13 (instructing commission of offence for criminal organization),
  * (xvi.1) to (xx) [Repealed, 2005, c. 25, s. 1]

Code pre-1983 (b) ...<omitted>...  
Code pre-1988 (c) and (c.1) ...<omitted>...  


(d) an attempt to commit or, other than for the purposes of subsection 487.05(1), a conspiracy to commit an offence referred to in any of paragraphs (a) to (c);

(a) an offence under this Act that may be prosecuted by indictment — or, for section 487.051 to apply, is prosecuted by indictment — for which the maximum punishment is imprisonment for five years or more,

(b) an offence under any of the following provisions of the Controlled Drugs and Substances Act that may be prosecuted by indictment — or, for section 487.051 to apply, is prosecuted by indictment — for which the maximum punishment is imprisonment for five years or more:

  * (i) section 5 (trafficking in substance and possession for purpose of trafficking),
  * (ii) section 6 (importing and exporting), and
  * (iii) section 7 (production of substance),

(c) an offence under any of the following provisions of this Act:

  * (i) section 145 (escape and being at large without excuse),
  * (i.1) section 146 (permitting or assisting escape),
  * (i.2) section 147 (rescue or permitting escape),
  * (i.3) section 148 (assisting prisoner of war to escape),
  * (i.4) subsection 160(3) (bestiality in pres­ence of or by child),
  * (ii) section 170 (parent or guardian procuring sexual activity),
  * (iii) section 173 (indecent acts),
  * (iv) section 252 (failure to stop at scene of accident),
  * (v) section 264 (criminal harassment),
  * (vi) section 264.1 (uttering threats),
  * (vii) section 266 (assault),
  * (viii) section 270 (assaulting a peace officer),
  * (ix) paragraph 348(1)(e) (breaking and entering a place other than a dwelling-house),
  * (x) section 349 (being unlawfully in dwelling-house), and
  * (xi) section 423 (intimidation),

(d) an offence under any of the following provisions of the Criminal Code, as they read from time to time before July 1, 1990:

  * (i) section 433 (arson), and
  * (ii) section 434 (setting fire to other substance), and

(e) an attempt to commit or, other than for the purposes of subsection 487.05(1), a conspiracy to commit

  * (i) an offence referred to in paragraph (a) or (b) — which, for section 487.051 to apply, is prosecuted by indictment, or
  * (ii) an offence referred to in paragraph (c) or (d);

## SOIRA Orders[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-14)]

    _See also [SOIRA Orders](/wiki/Canadian_Criminal_Sentencing/Ancillary_Orders/SOIRA_Orders)_

Pursuant to s. 490.012(2), offences under s. 490.011(1)(b) require a SOIRA order if it is proven beyond a reasonable doubt that there was an intent to commit an offence under s. 490.011(1)(a).

s.490.011(1)(a) Offences s.490.011(1)(b) Offences

  * subsection 7(4.1) (offence in relation to sexual offences against children),
  * section 151 (sexual interference),
  * section 152 (invitation to sexual touching),
  * section 153 (sexual exploitation),
  * section 153.1 (sexual exploitation of person with disability),
  * section 155 (incest),
  * subsection 160(3) (bestiality in presence of or by a child),
  * section 163.1 (child pornography),
  * section 170 (parent or guardian procuring sexual activity),
  * section 172.1 (luring a child by means of a computer system),
  * subsection 173(2) (exposure),
  * paragraph 212(1)(i) (stupefying or overpowering for the purpose of sexual intercourse),
  * subsection 212(2) (living on the avails of prostitution of a person under age of eighteen),
  * subsection 212(2.1) (aggravated offence — living on the avails of prostitution of a person under age of eighteen),
  * subsection 212(4) (obtaining prostitution of person under age of eighteen),
  * section 271 (sexual assault),
  * section 272 (sexual assault with a weapon, threats to a third party or causing bodily harm),
  * paragraph 273(2)(a) (aggravated sexual assault — use of a restricted firearm or prohibited firearm or any firearm in connection with criminal organization),
  * paragraph 273(2)(a.1) (aggravated sexual assault — use of a firearm),
  * paragraph 273(2)(b) (aggravated sexual assault), and
  * subsection 273.3(2) (removal of a child from Canada);

  * subsection 173(1) (indecent acts),
  * section 177 (trespassing at night),
  * section 230 (murder in commission of offences),
  * section 234 (manslaughter),
  * paragraph 246(b) (overcoming resistance to commission of offence),
  * section 264 (criminal harassment),
  * section 279 (kidnapping),
  * section 279.01 (trafficking in persons),
  * section 280 (abduction of a person under age of sixteen),
  * section 281 (abduction of a person under age of fourteen),
  * paragraph 348(1)(d) (breaking and entering a dwelling house with intent to commit an indictable offence),
  * paragraph 348(1)(d) (breaking and entering a dwelling house and committing an indictable offence),
  * paragraph 348(1)(e) (breaking and entering a place other than a dwelling house with intent to commit an indictable offence), and
  * paragraph 348(1)(e) (breaking and entering a place other than a dwelling house and committing an indictable offence);

## Driving Prohibition[[edit](/w/index.php?title=Canadian_Criminal_Sentencing/Appendix/Offence_Charts&action=edit&section=T-15)]

    _[Driving Prohibition Orders](/wiki/Canadian_Criminal_Sentencing/Ancillary_Orders/Driving_Prohibition_Orders)_

Section 259 requires a **mandatory Order of prohibition** from driving for offences under s.253 or 254. The length is as follows:

  * First offence: 1 to 3 years (s.259(1)(a))
  * Second offence: 2 to 5 years (s. 259(1)(b))
  * All subsequent offences: 3 years or more (s. 259(1)(c))

**Interlock program** is available after:

  * First offence: 3 months from sentence (s.259(1.2)(a)(i))
  * Second offence: 6 months from sentence (s.259(1.2)(a)(ii))
  * All subsequent offences: 12 months from sentence (s.259(1.2)(a)(iii))
  * Or any later time as set by the judge (s.259(1.2)(b))

Section 259(2) allows a **discretionary order of prohibition** from driving for offences under s. 220, 221, 236, 249, 249.1, 250, 251 or 252 or 255(2) to (3.2). The length is as follows:

  * Offences with max of life sentence or actual life sentence: any duration (s. 259(2)(a), (a1))
  * Offences with max of 10 years: up to 5 years (s.259(2)(b))
  * Any other offences: up to 3 years (s. 259(2)(c))

**Street racing mandatory prohibitions** in addition to other mandatory orders:

  * First offence: 1 to 3 years (s. 259(3.1)(a))
  * Second offence: 2 to 5 years (s. 259(3.1)(b))
  * Any subsequent offences: 3 years or more (s. 259(3.1)(c))

**Bodily harm offences** under s. 249.3 or 249.4(3), the **mandatory orders** are as follows:

  * First Offence: 1 to 10 years
  * Second Offence: 2 to 10 years
  * Any subsequent offences: 3 years or more

**Death offences** under s. 249.2 or 249.4(4), the **mandatory orders** are as follows:

  * s.249.2 Offences: 1 year or more
  * s. 249.4(4) offences: 1 to 10 years
  * Any second conviction is life (s. 259(3.4))

# Motions Chart[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit&section=5)]

Motion/Application/Order

(Publication) Code Section

Exclusion of Public
486

Publication Ban (ID of Complainant)
486

Publication Ban (Show Cause Hearing)
517

Publication Ban (Preliminary Inq.)
539, 542(2)

Publication Ban (276 application)
276.3

(Election/Plea) Code Section

Re-Election
561

Waive P.I.
549

(Warrants) Code Section

Accused Warrant
524(1)

Witness Warrant
626(2), 698(2), 705

Included Offences
606(4), 662

(Admissions) Code Section

Admission of Facts in Trial
655

(Forfeiture) Code Section

Forfeiture
462.37, 490.1, 491, 16(CDSA)

(Mental Health) Code Section

Psych. Assessment
672.11

Psych. Remand
537 [I], 803(5)[S]

(Bail) Code Section

Bail Variation/Review
523/520

Bail Revocation
523, 524

Release Pending Appeal
679

No contact while remanded
515(12)

Release Pending Appeal
679

(Sentence) Code Section

DNA Order
487.05

SOIRA Order
490.012

Intermittent Time
732

Curative Discharge
255

Probation Order
731, 732.1

Fine
734, 734.1

Victim Fine Surcharge
737

Restitution (stand-alone)
738

Conditional Sentence
742.1

Wiretap disclosure
487.3

# Re-Election Chart[[edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit&section=6)]

Initial Election Final Election Timing Sections Crown Consent Notice

SC Judge-alone or  
SC Judge and Jury
Provincial Court
Before the end of Preliminary
561(1)(a), 561(3)
Consent
Prelim. Judge

SC Judge-alone or  
SC Judge and Jury
Provincial Court
After the end of Preliminary
561(1)(a), 561(5)
Consent
Supreme Court Judge

SC Judge and Jury
SC Judge-alone
Less than 15 days after Prelim.
561(1)(b), 561(5)
No Consent
Supreme Court Judge

SC Judge and Jury
SC Judge-alone
15 days after Prelim. or more
561(1)(c), 561(5)
Consent
Supreme Court Judge

SC Judge and Jury (direct indictment)
SC Judge-alone
After the Indictment is Preferred
565(2), 565(3)
No Consent
Supreme Court Judge

SC Judge and Jury (s. 469)
SC Judge-alone
After the Indictment is preferred
473
Consent
Supreme Court Judge

SC Judge-alone
SC Judge and Jury
before end of prelim.
561(1)(b), 561(3)
No Consent
Prelim. Judge

SC Judge-alone
SC Judge and Jury
less than 15 days after prelim.
561(1)(b), 561(5)
No Consent
Supreme Court Judge

SC Judge-alone
SC Judge and Jury
15 days after prelim. or more
561(1)(c), 561(5)
Consent
Supreme Court Judge

Provincial Court
SC Judge-alone or Judge and Jury
More than 14 days before trial
561(2), 561(4)
No Consent
Provincial Court Judge

Provincial Court
SC Judge-alone or Judge and Jury
14 days before trial or less
561(2)
Consent
Provincial Court Judge
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&oldid=2394478](http://en.wikibooks.org/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&oldid=2394478)" 

[Category](/wiki/Special:Categories): 

  * [Canadian Criminal Law](/wiki/Category:Canadian_Criminal_Law)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Canadian+Criminal+Law%2FProof+of+Elements%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Canadian+Criminal+Law%2FProof+of+Elements%2FPrint+version)

### Namespaces

  * [Book](/wiki/Canadian_Criminal_Law/Proof_of_Elements/Print_version)
  * [Discussion](/w/index.php?title=Talk:Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Canadian_Criminal_Law/Proof_of_Elements/Print_version)
  * [Edit](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=edit)
  * [View history](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Canadian_Criminal_Law/Proof_of_Elements/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Canadian_Criminal_Law/Proof_of_Elements/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&oldid=2394478)
  * [Page information](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Canadian_Criminal_Law%2FProof_of_Elements%2FPrint_version&id=2394478)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Canadian+Criminal+Law%2FProof+of+Elements%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Canadian+Criminal+Law%2FProof+of+Elements%2FPrint+version&oldid=2394478&writer=rl)
  * [Printable version](/w/index.php?title=Canadian_Criminal_Law/Proof_of_Elements/Print_version&printable=yes)

  * This page was last modified on 15 August 2012, at 20:59.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Canadian_Criminal_Law/Proof_of_Elements/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
