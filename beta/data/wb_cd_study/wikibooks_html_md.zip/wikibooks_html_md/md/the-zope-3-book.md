# The Zope 3 Book/Print version

From Wikibooks, open books for an open world

< [The Zope 3 Book](/wiki/The_Zope_3_Book)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

  


![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [The Zope 3 Book](/wiki/The_Zope_3_Book)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=The_Zope_3_Book/Print_version&action=purge&printable=yes) this page.

  
  


# Preface

This book is about [Zope 3](//en.wikipedia.org/wiki/Zope_3), a [Python](//en.wikipedia.org/wiki/Python_Programming) framework for web application development. Zope 3 was developed by the Zope community with the leadership of Jim Fulton, the creator of [original Zope](//en.wikipedia.org/wiki/Zope). Zope 3 consists of a number of small frameworks and libraries written in Python programming language and it is usable in pieces or in whole. These frameworks and libraries can be put together to build any kind of web application. Most of of the Zope 3 packages are built on top of a [component architecture](http://wiki.zope.org/zope3/ComponentArchitecture) which helps to separate presentation code from the problem domain code and to create reusable components.

The goal for this project is to create a complete, free, open-content, well-organized book for Zope 3. The target audience of this book are Python programmers looking for developing web applications. However, the book doesn't assume you are familiar with any other web framework. This book will require prior knowledge Python programming language and at least some exposure to the basics of HTML, CSS and JavaScript.  


# Table of Contents

![Warning icon WikiBooks.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Warning_icon_WikiBooks.svg/40px-Warning_icon_WikiBooks.svg.png)

This book is intended for **[intermediate](/wiki/Wikibooks:Reading_Levels)** readers.

This book is about [Zope 3](//en.wikipedia.org/wiki/Zope_3), a [Python](//en.wikipedia.org/wiki/Python_Programming) framework for web application development. Zope 3 was developed by the Zope community with the leadership of Jim Fulton, the creator of [original Zope](//en.wikipedia.org/wiki/Zope). Zope 3 consists of a number of small frameworks and libraries written in Python programming language and it is usable in pieces or in whole. These frameworks and libraries can be put together to build any kind of web application. Most of of the Zope 3 packages are built on top of a [component architecture](http://wiki.zope.org/zope3/ComponentArchitecture) which helps to separate presentation code from the problem domain code and to create reusable components.

The goal for this project is to create a complete, free, open-content, well-organized book for Zope 3. The target audience of this book are Python programmers looking for developing web applications. However, the book doesn't assume you are familiar with any other web framework. This book will require prior knowledge Python programming language and at least some exposure to the basics of HTML, CSS and JavaScript.

## Table of Contents

  * [Introduction](/w/index.php?title=The_Zope_3_Book/Print_version/Introduction&action=edit&redlink=1)
  * [Getting Started](/w/index.php?title=The_Zope_3_Book/Print_version/Getting_Started&action=edit&redlink=1)
  * [Interfaces](/w/index.php?title=The_Zope_3_Book/Print_version/Interfaces&action=edit&redlink=1)
  * [Component Architecture](/w/index.php?title=The_Zope_3_Book/Print_version/Component_Architecture&action=edit&redlink=1)
  * [Unit Testing](/w/index.php?title=The_Zope_3_Book/Print_version/Unit_Testing&action=edit&redlink=1)
  * [Content Components](/w/index.php?title=The_Zope_3_Book/Print_version/Content_Components&action=edit&redlink=1)
  * [Functional Testing](/w/index.php?title=The_Zope_3_Book/Print_version/Functional_Testing&action=edit&redlink=1)
  * [Resources](/w/index.php?title=The_Zope_3_Book/Print_version/Resources&action=edit&redlink=1)
  * [Browser Views](/w/index.php?title=The_Zope_3_Book/Print_version/Browser_Views&action=edit&redlink=1)
  * [Skins and Layers](/w/index.php?title=The_Zope_3_Book/Print_version/Skins_and_Layers&action=edit&redlink=1)
  * [Advanced Views](/w/index.php?title=The_Zope_3_Book/Print_version/Advanced_Views&action=edit&redlink=1)
  * [Basic Security](/w/index.php?title=The_Zope_3_Book/Print_version/Basic_Security&action=edit&redlink=1)
  * [Schemas](/w/index.php?title=The_Zope_3_Book/Print_version/Schemas&action=edit&redlink=1)
  * [Forms](/w/index.php?title=The_Zope_3_Book/Print_version/Forms&action=edit&redlink=1)
  * [Authentication](/w/index.php?title=The_Zope_3_Book/Print_version/Authentication&action=edit&redlink=1)
  * [Annotations](/w/index.php?title=The_Zope_3_Book/Print_version/Annotations&action=edit&redlink=1)
  * [Traversers](/w/index.php?title=The_Zope_3_Book/Print_version/Traversers&action=edit&redlink=1)
  * [Events](/w/index.php?title=The_Zope_3_Book/Print_version/Events&action=edit&redlink=1)
  * [Catalogs and Indices](/w/index.php?title=The_Zope_3_Book/Print_version/Catalogs_and_Indices&action=edit&redlink=1)

## Appendices

  * [Setuptools and eggs](/w/index.php?title=The_Zope_3_Book/Print_version/Setuptools_and_eggs&action=edit&redlink=1)
  * [Buildout](/w/index.php?title=The_Zope_3_Book/Print_version/Buildout&action=edit&redlink=1) ![0% developed  as of August 18 2008](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  * [Virtualenv](/w/index.php?title=The_Zope_3_Book/Print_version/Virtualenv&action=edit&redlink=1)

## Appendices

  * [Resources](/w/index.php?title=The_Zope_3_Book/Print_version/Resources&action=edit&redlink=1)
  * [Glossary](/w/index.php?title=The_Zope_3_Book/Print_version/Glossary&action=edit&redlink=1)

  
  


# Introduction

 
[Index](/wiki/The_Zope_3_Book)
[Next: Getting Started](/wiki/The_Zope_3_Book/Getting_Started)

## Overview

[Zope 3](//en.wikipedia.org/wiki/Zope_3) consists of a number of small frameworks and libraries written in [Python programming language](//en.wikipedia.org/wiki/Python_Programming) and it is usable in pieces or in whole. These frameworks and libraries can be put together to build any kind of web application. Normally, Zope 3 applications are developed using a Python based build system called [Buildout](http://pypi.python.org/pypi/zc.buildout). Zope 3 is built on top of a component architecture to separate presentation code from the problem domain code and to create reusable components (_zope.component_).

Zope 3 has an object publisher (_zope.publisher_), web server (_zope.server_), transactional object database (_ZODB_), XML-configuration language for registering components (_zope.configuration_), flexible security architecture with pluggable security policies (_zope.security_), unit and functional testing frameworks (_zope.testing_, _zope.testbrowser_), XHTML-compliant templating language (_zope.pagetemplate_), schema engine and automatic form generation machinery (_zope.schema_, _z3c.form_) and many more core and third-party packages.

Originally, the term _ZOPE_ was used as an acronym for _Z Object Publishing Environment_ (the _Z_ doesn't really mean anything in particular). However, now-a-days _ZOPE_ is simply written as _Zope_.

Zope 3 is a ZPL (BSD like, GPL compatible license) licensed free/open source software. It was developed by the Zope community with the leadership of Jim Fulton. A brief history is given in the next section.

The main aim of this book is to create a free online book about Zope 3. This book will cover how to develop web applications using Zope 3 components. You suggestions and edits are always welcome.

## Scope of the book

The intension of this book is not to cover how to use Zope 3 packages independently or with other Python applications/frameworks. Rather, this book focus on developing web applications using Zope 3 packages. More specifically, this book is not going to cover using Zope 3 technology in Zope 2, Plone, Grok or any plain Python application/framework. WSGI is also not a current focus of this book. This book is not going to cover using zopeproject to bootstrap application (it's very easy, look at the PyPI page for zopeproject). This book use Buildout for setting up an isolated development environment for building applications. Setuptools and vitualenv also will be covered.

## Audience

The target audience of this book are Python programmers looking for developing web applications. However, the book doesn't assume you are familiar with any other web framework.

## Prerequisites

This book will require prior knowledge Python programming language and at least some exposure to the basics of HTML, CSS and JavaScript.

## Brief history

The beginning of Zope’s story goes something like this, in 1996, Jim Fulton (CTO of Zope Corporation) was drafted to teach a class on common gateway interface (CGI) programming, despite not knowing very much about the subject. CGI programming is a commonly-used web development model that allows developers to construct dynamic websites. On his way to the class, Jim studied all the existing documentation on CGI. On the way back, Jim considered what he didn’t like about traditional, CGI-based programming environments. From these initial musings, the core of Zope was written while flying back from the CGI class.

Zope Corporation (then known as Digital Creations) went on to release three open-source software packages to support web publishing: Bobo, Document Template, and BoboPOS. These packages were written in a language called Python, and provided a web publishing facility, text templating, and an object database, respectively. Digital Creations developed a commercial application server based on their three opensource components. This product was called Principia. In November of 1998, investor Hadar Pedhazur convinced Digital Creations to open source Principia. These packages evolved into what are now the core components of Zope 2.

In 2001, the Zope community began working on a component architecture for Zope, but after several years they ended up with something much more: Zope 3. While Zope 2 was powerful and popular, Zope 3 was designed to bring web application development to the next level. This book is about this Zope 3, which is not really a new version of Zope 2.

Most recently, in 2007 the Zope community created yet another framework based on Zope 3 called Grok. The original Zope which is now known as Zope 2 is also widely used.

## Organization of the book

This book has divided into multiple chapters. Summary of each chapter is given below.

### Introduction

This chapter introduce Zope 3 with an overview and scope of the book, then briefly go through the history of Zope 3. Later discuss organization of the book. And finish with a _thanks_ section.

### Getting Started

This chapter begins with installation details of Python and Zope 3. Then introduce _Buildout_, the build system we use to setup an isolated Python working environment and its configurations. Later, it explore setting up development sandbox using Buildout. A simple application is developed further and it ends with a _Hello world_ page. During the application development we see how to use ZMI (Zope Management Interface) briefly. This chapter also provides a brief overview of important packages and installation of additional packages.

### Interfaces

This chapter introduce the concept of interfaces.

## Thanks

This book would not be possible if Zope 3 did not exist. For that, the authors would like to thank all developers of Zope 3. Thanks to wikibooks for providing this space for book. Thanks to all editors of this book.

 
[Index](/wiki/The_Zope_3_Book)
[Next: Getting Started](/wiki/The_Zope_3_Book/Getting_Started)

  


# Getting Started

[Previous: Introduction](/wiki/The_Zope_3_Book/Introduction)
[Index](/wiki/The_Zope_3_Book)
[Next: Interfaces](/wiki/The_Zope_3_Book/Interfaces)

## Python installation

The Zope community has always recommended using a custom built Python for development and deployment. Python 2.4 is the recommended version for Zope 3, although Python 2.5 will also work, but it is not yet officially supported.

### GNU/Linux

To install Python, you will be required to install gcc, g++ and other development tools in your system. A typical installation of Python can be done like this:
    
    
    $ wget -c http://www.python.org/ftp/python/2.4.5/Python-2.4.5.tar.bz2
    $ tar jxvf Python-2.4.5.tar.bz2
    $ cd Python-2.4.5
    $ ./configure --prefix=/home/guest/usr
    $ make
    $ make install
    

As given above, you can provide an option, _\--prefix_ to install Python in a particular location. The above steps install Python inside _/home/guest/usr_ directory.

After installation, you can invoke the Python interpreter like this (~ is an alias to _/home/guest_):
    
    
    $ ~/usr/bin/python2.4
    >>> print "Hello, world!"
    Hello, world!
    

If you are not getting old statements in Python interactive prompt when using up-arrow key, try installing _libreadline_ development libraries (Hint: apt-cache search libreadline). After installing this library, you should install Python again. You also will be required to install _zlib_ (Hint: apt-cache search zlib compression library) to properly install Zope 3.

### MS Windows

* * *

**FIXME**: Write about installation of Python in MS Windows with few screen shots.

* * *

## Buildout

### Introduction

We are going to use a build tool called Buildout for developing Zope 3 applications from multiple parts. Buildout will give you an isolated working environment for developing applications. The Buildout package, named _zc.buildout_ is available for [download from PyPI](http://pypi.python.org/pypi/zc.buildout). This section briefly goes through the usage of Buildout for developing applications.

Buildout has a _boostrap.py_ script for initializing a buildout based project for development or deployment. It will download and install _zc.buildout_, _setuptools_ and other dependency modules in a specified directory. Once bootstrapped it will create a _buildout_ executable script inside _bin_ directory at the top of your project source. The default configuration for each project is _buildout.cfg_ file at the top of your project source. Whenever you run the _buildout_ command it will look into the default configuration file and will do actions based on it. Normally, the configuration file and boostrap script will be bundled with the project source itself. Other than the default configuration file along with the project source, you may also create a system wide default configuration file at _~/.buildout/default.cfg_.

Buildout creator Jim Fulton recommend a custom built clean Python installation, i.e., there should not be any Python modules installed in your _site-packages_ (ideally, a fresh Python installation). When you boostrap your project using Buildout's _boostrap.py_ script, it will download and install all necessary packages in a specified directory. So, for an ideal project you only required a _custom built clean Python_ and the project source with proper _Buildout configuration_ and _bootstrap script_ along with the source package.

### Buildout configuration

These days, most of the Python packages are available in [egg](http://peak.telecommunity.com/DevCenter/PythonEggs) format. Buildout will download and install the eggs in directory and the location can be changed from the configuration file. It is better to give a system-wide location for eggs directory. And this configuration can be added to your system-wide configuration file. The default configuration file for Buildout is _~/.buildout/default.cfg_. We are going to use _eggs_ directory inside your home directory to keep all eggs downloaded, so first create those directories and file:
    
    
    $ cd $HOME
    $ mkdir .buildout
    $ mkdir eggs
    $ touch .buildout/default.cfg
    

You can add the following to your _~/.buildout/default.cfg_ file:
    
    
    [buildout]
    newest = false
    eggs-directory = /home/baiju/eggs
    find-links = http://download.zope.org/ppix
    

The _eggs-directory_ is where Buildout stores the eggs that are downloaded. The last option, _find-links_ points to a reliable mirror of the Python Package Index (PyPI). The default configurations given above will be available to all buildouts in your system.

### MS Windows notes

* * *

**FIXME**: Add any specific things required for MS Windows here.

* * *

## Setting up development sandbox

To demonstrate the concepts, tools and techniques, we are going to develop a simple ticket/issue tracking application named _Ticket Collector_. To begin the work, first create a directory for the project. After creating the directory, create a _buildout.cfg_ file as given below. To bootstrap this application checkout _bootstrap.py_ and run it inside that directory.
    
    
    $ mkdir ticketcollector
    $ cd ticketcollector
    $ echo "#Buildout configuration" > buildout.cfg
    $ svn co svn://svn.zope.org/repos/main/zc.buildout/trunk/bootstrap
    $ ~/usr/bin/python2.4 bootstrap/bootstrap.py
    

You can see a _buildout_ script created inside _bin_ directory. Now onwards, you can run this script when changing Buildout configuration.

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

You can save _bootstrap.py_ in a local repository. If you are using svn for managing repository, create an svn:external to the svn URL given above.

Our application is basically a Python package. First we will create an _src_ directory to place our package. Inside the _src_ directory, you can create _ticketcollector_ Python package. You can create the _src_ and the _ticketcollector_ package like this:
    
    
    $ mkdir src
    $ mkdir src/ticketcollector
    $ echo "#Python package" > src/ticketcollector/__init__.py
    

To start building our package you have to create a _setup.py_ file. The _setup.py_ should have the minimum details as given below:

We have included bare minimum packages required for installation here: _zope.app.zcmlfiles_, _zope.app.twisted_, _zope.app.securitypolicy_ and _setuptools_.
    
    
    from setuptools import setup, find_packages
     
    setup(
        name='ticketcollector',
        version='0.1',
     
        packages=find_packages('src'),
        package_dir={'': 'src'},
     
        install_requires=['setuptools',
                          'zope.app.zcmlfiles',
                          'zope.app.twisted',
                          'zope.app.securitypolicy',
                          ],
        include_package_data=True,
        zip_safe=False,
        )
    

Modify _buildout.cfg_ as given below:
    
    
    [buildout]
    develop = .
    parts = py
     
    [py]
    recipe = zc.recipe.egg
    eggs = ticketcollector
    interpreter = python
    

Now run _buildout_ script inside _bin_ directory. This will download all necessary eggs and install it. So installing Zope is nothing but just setting up a _buildout_ with _setup.py_ with required packages _install_requires_ for installation. Unless you specified a _parts_ section which use _ticketcollector_ in some way, buildout will not download dependency packages.

## A simple application

### Configuring application

We are going to continue the _Ticket Collector_ application in this section. In the last section when you run _./bin/buildout_ command all necessary Zope 3 packages required for running our application is downloaded inside _~/eggs_ directory. Now to run the bare minimum Zope 3, we have to create _Zope Configuration Markup Language_ (ZCML) file and extend the _buildout.cfg_ with appropriate Buildout recipes. We are going to use _zc.zope3recipes:app_,_zc.zope3recipes:instance_ and _zc.recipe.filestorage_ recipes for setting up our application. Here is our modified _buildout.cfg_ (inside the _ticketcollector_ project directory):
    
    
    [buildout]
    develop = .
    parts = ticketcollectorapp instance
     
    [zope3]
    location =
     
    [ticketcollectorapp]
    recipe = zc.zope3recipes:app
    site.zcml = 
      <include package="ticketcollector" file="application.zcml" />
    eggs = ticketcollector
     
    [instance]
    recipe = zc.zope3recipes:instance
    application = ticketcollectorapp
    zope.conf = ${database:zconfig}
     
    [database]
    recipe = zc.recipe.filestorage
    

Then we will create _application.zcml_ inside _src/ticketcollector_ directory with the following text. Consider it as boiler plate code now, we will explain this in details later:
    
    
    <configure
      xmlns="http://namespaces.zope.org/zope"
      >
     
      <include package="zope.app.securitypolicy" file="meta.zcml" />
     
      <include package="zope.app.zcmlfiles" />
      <include package="zope.app.authentication" />
      <include package="zope.app.securitypolicy" />
      <include package="zope.app.twisted" />
     
      <securityPolicy 
        component="zope.app.securitypolicy.zopepolicy.ZopeSecurityPolicy" />
     
      <role id="zope.Anonymous" title="Everybody"
        description="All users have this role implicitly" />
      <role id="zope.Manager" title="Site Manager" />
      <role id="zope.Member" title="Site Member" />
     
      <grant permission="zope.View"
        role="zope.Anonymous" />
      <grant permission="zope.app.dublincore.view"
        role="zope.Anonymous" />
     
      <grantAll role="zope.Manager" />
     
      <unauthenticatedPrincipal
        id="zope.anybody"
        title="Unauthenticated User" />
     
      <unauthenticatedGroup
        id="zope.Anybody"
        title="Unauthenticated Users" />
     
      <authenticatedGroup
        id="zope.Authenticated"
        title="Authenticated Users" />
     
      <everybodyGroup
        id="zope.Everybody"
        title="All Users" />
     
      <principal
        id="zope.manager"
        title="Manager"
        login="admin"
        password_manager="Plain Text"
        password="admin"
        />
     
      <grant
        role="zope.Manager"
        principal="zope.manager" />
     
    </configure>
    

### Running application

Now you can run the application by running _./bin/buildout_ command followed by _./bin/instance_ command.
    
    
    $ ./bin/buildout
    $ ./bin/instance fg
    

So, to run a Zope 3 application we have to use _buildout_ recipes with proper configurations.

### Using ZMI

After running your instance, If you open a web browser and go to _<http://localhost:8080>_ you'll see the ZMI (_Zope Management Interface_).

Go ahead and click the _Login_ link at the upper right. Enter the user name and password as _admin_, which is given in _applications.zcml_. Now click on _[top]_ under Navigation on the right. Play around with adding some content objects (the Zope 3 name for instances that are visible in the ZMI). Note how content objects can be arranged in a hierarchy by adding _folders_ which are special content objects that can hold other content objects.

There is nothing special about the ZMI, it is just the default skin for Zope 3. You can modify it to your liking, or replace it entirely.

When you're done exploring with the ZMI, go back to the window where you typed _./bin/instance fg_ and press Control-C to stop Zope 3.

### Hello world

Now you can begin your development inside _src/ticketcollector_ directory. Create a _browser.py_ with following content:
    
    
    from zope.publisher.browser import BrowserView
     
    class HelloView(BrowserView):
     
        def __call__(self):
            return """
            <html>
            <head>
              <title>Hello World</title>
            </head>
            <body>
              Hello World
            </body>
            </html>
            """
    

Now append the following text just above the last line of _application.zcml_:
    
    
    <browser:page
      for="*"
      name="hello"
      permission="zope.Public"
      class="ticketcollector.browser.HelloView"
    />
    

As you can see above, we are using _page_ attribute from the _browser_ namespace. So, you have to include that namespace in the beginning ZCML as shown below:
    
    
    <configure
       xmlns="http://namespaces.zope.org/zope"
       xmlns:browser="http://namespaces.zope.org/browser"
       >
    

After restarting Zope, open _<http://localhost:8080/hello>_, you can see that it displaying _Hello World_ !.

## Overview of packages

## Installing additional packages

## Summary

## See also

## Discussions

[Previous: Introduction](/wiki/The_Zope_3_Book/Introduction)
[Index](/wiki/The_Zope_3_Book)
[Next: Interfaces](/wiki/The_Zope_3_Book/Interfaces)

  


# Interfaces

[Previous: Getting Started](/wiki/The_Zope_3_Book/Getting_Started)
[Index](/wiki/The_Zope_3_Book)
[Next: Component Architecture](/w/index.php?title=The_Zope_3_Book/Component_Architecture&action=edit&redlink=1)

## Introduction

Interfaces are objects that specify (document) the external behavior of objects that "provide" them. An interface specifies behavior through:

  * Informal documentation in a doc string
  * Attribute definitions
  * Invariants, which are conditions that must hold for objects that provide the interface

Some of the motivations for using interfaces are:

  * Avoid monolithic design by developing small, exchangeable pieces
  * Model external responsibility, functionality, and behavior
  * Establish contracts between pieces of functionality
  * Document the API

The classic software engineering book [Design Patterns](//en.wikipedia.org/wiki/Design_Patterns) by the _Gang of Four_ recommends that you _Program to an interface, not an implementation_. Defining a formal interface is helpful in understanding a system. Moreover, interfaces bring you all the benefits of Zope Component Architecture.

In some modern programming languages: Java, C#, VB.NET etc, interfaces are an explicit aspect of the language. Since Python lacks interfaces, Zope implements them as a meta-class to inherit from.

## Types of Contract

"I can do X"
    Describing the ability to do something is the classical definition of an API. Those abilities are defined and implemented as methods.

"I have X"
    This statement declares the availability of data, which is classically associated with schemas. The data is stored in attributes and properties.

"You can do X with me"
    Here we describe the behavior of an object. Classically there is no analog. However, MIME-types are great example of behavior declaration. This is implemented using empty "marker interfaces" as they describe implicit behavior.

The distinction between those three types of contracts was first pointed out in this form by Philipp von Weitershausen.

Understanding those distinctions is very important, since other programming languages do not necessarily use all three of these notions. In fact, often only the first one is used.

## Defining Interfaces

  * Python has no concept of interfaces
  * Not a problem
  * Interfaces are just objects
  * "Abuse" the class statement to create an interface
  * Syntax proposed in PEP 245

Jim Fulton does not see this as a problem, since it makes interfaces first class citizens. In Java, for example, interfaces are special types of objects that can only serve as interfaces in their intended, limited scope.

An interface from the zope.interface package, on the other hand, defines the interface by implementing a meta-class, a core concept of Python. Thus, interfaces are merely using an existing Python pattern.

## An example

Here is a classic hello world style example:
    
    
    >>> class Host(object):
    ...
    ...     def goodmorning(self, name):
    ...         """Say good morning to guests"""
    ...
    ...         return "Good morning, %s!" % name
    

In the above class, you defined a goodmorning method. If you call the goodmorning method from an object created using this class, it will return Good morning, ...!
    
    
    >>> host = Host()
    >>> host.goodmorning('Jack')
    'Good morning, Jack!'
    

Here host is the actual object your code uses. If you want to examine implementation details you need to access the class Host, either via the source code or an [API](//en.wikipedia.org/wiki/Application_programming_interface) documentation tool.

Now we will begin to use the Zope interfaces. For the class given above you can specify the interface like this:
    
    
    >>> from zope.interface import Interface
     
    >>> class IHost(Interface):
    ...
    ...     def goodmorning(guest):
    ...         """Say good morning to guest"""
    

As you can see, the interface inherits from zope.interface.Interface. This use (abuse?) of Python's class statement is how Zope defines an interface. The I prefix for the interface name is a useful convention.

## Declaring interfaces

You have already seen how to declare an interface using zope.interface in previous section. This section will explain the concepts in detail.

Consider this example interface:
    
    
    >>> from zope.interface import Interface
    >>> from zope.interface import Attribute
     
    >>> class IHost(Interface):
    ...     """A host object"""
    ...
    ...     name = Attribute("""Name of host""")
    ...
    ...     def goodmorning(guest):
    ...         """Say good morning to guest"""
    

The interface, IHost has two attributes, name and goodmorning. Recall that, at least in Python, methods are also attributes of classes. The name attribute is defined using zope.interface.Attribute class. When you add the attribute name to the IHost interface, you don't set an initial value. The purpose of defining the attribute name here is merely to indicate that any implementation of this interface will feature an attribute named name. In this case, you don't even say what type of attribute it has to be!. You can pass a documentation string as a first argument to Attribute.

The other attribute, goodmorning is a method defined using a function definition. Note that self is not required in interfaces, because self is an implementation detail of class. For example, a module can implement this interface. If a module implements this interface, there will be a name attribute and goodmorning function defined. And the goodmorning function will accept one argument.

Now you will see how to connect interface-class-object. So object is the real living thing, objects are instances of classes. And interface is the actual definition of the object, so classes are just the implementation details. This is why you should program to an interface and not to an implementation.

Now you should familiarize yourself with two more terms to understand other concepts. The first one is "provide" and the other one is "implement". Object _provides_ interfaces and classes _implement_ interfaces. In other words, objects provide interfaces that their classes implement. In the above example, host (object) provides IHost (interface), and Host (class) implements IHost (interface). One object can provide more than one interface; also one class can implement more than one interface. Objects can also provide interfaces directly, in addition to what their classes implement.

Note
    Classes are the implementation details of objects. In Python, classes are callable objects, so why can't other callable objects implement an interface? Yes, it is possible. For any callable object you can declare that it produces objects that provide some interfaces by saying that the callable object implements the interfaces. The callable objects are generally called "factories". Since functions are callable objects, a function can be an implementer of an interface.

## Implementing interfaces

To declare a class implements a particular interface, use the function zope.interface.implements in the class statement.

Consider this example, here Host implements IHost:
    
    
    >>> from zope.interface import implements
     
    >>> class Host(object):
    ...
    ...     implements(IHost)
    ...
    ...     name = u''
    ...
    ...     def goodmorning(self, guest):
    ...         """Say good morning to guest"""
    ...
    ...         return "Good morning, %s!" % guest
    

Note
    If you wonder how implements function works, refer the blog post by James Henstridge (<http://blogs.gnome.org/jamesh/2005/09/08/python-class-advisors/>) . In the adapter section, you will see an adapts function, it is also working similarly.

Since Host implements IHost, instances of Host provide IHost. There are some utility methods to introspect the declarations. The declaration can write outside the class also. If you don't write interface.implements(IHost) in the above example, then after defining the class statement, you can write like this:
    
    
    >>> from zope.interface import classImplements
    >>> classImplements(Host, IHost)
    

## Marker interfaces

An interface can be used to declare that a particular object belongs to a special type. An interface without any attribute or method is called marker interface.

Here is a marker interface:
    
    
    >>> from zope.interface import Interface
     
    >>> class ISpecialGuest(Interface):
    ...     """A special guest"""
    

This interface can be used to declare an object is a special guest.

[Previous: Getting Started](/wiki/The_Zope_3_Book/Getting_Started)
[Index](/wiki/The_Zope_3_Book)
[Next: Component Architecture](/w/index.php?title=The_Zope_3_Book/Component_Architecture&action=edit&redlink=1)

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=The_Zope_3_Book/Print_version&oldid=1254202](http://en.wikibooks.org/w/index.php?title=The_Zope_3_Book/Print_version&oldid=1254202)" 

[Category](/wiki/Special:Categories): 

  * [The Zope 3 Book](/wiki/Category:The_Zope_3_Book)

Hidden category: 

  * [Intermediate reading level](/wiki/Category:Intermediate_reading_level)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=The+Zope+3+Book%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=The+Zope+3+Book%2FPrint+version)

### Namespaces

  * [Book](/wiki/The_Zope_3_Book/Print_version)
  * [Discussion](/w/index.php?title=Talk:The_Zope_3_Book/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/The_Zope_3_Book/Print_version)
  * [Edit](/w/index.php?title=The_Zope_3_Book/Print_version&action=edit)
  * [View history](/w/index.php?title=The_Zope_3_Book/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/The_Zope_3_Book/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/The_Zope_3_Book/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=The_Zope_3_Book/Print_version&oldid=1254202)
  * [Page information](/w/index.php?title=The_Zope_3_Book/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=The_Zope_3_Book%2FPrint_version&id=1254202)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=The+Zope+3+Book%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=The+Zope+3+Book%2FPrint+version&oldid=1254202&writer=rl)
  * [Printable version](/w/index.php?title=The_Zope_3_Book/Print_version&printable=yes)

  * This page was last modified on 18 August 2008, at 11:17.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/The_Zope_3_Book/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
