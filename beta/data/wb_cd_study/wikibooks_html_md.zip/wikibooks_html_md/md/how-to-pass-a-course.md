# How to Pass a Course/Print Version

From Wikibooks, open books for an open world

< [How to Pass a Course](/wiki/How_to_Pass_a_Course)(Redirected from [How to pass a course/Print Version](/w/index.php?title=How_to_pass_a_course/Print_Version&redirect=no))  


![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [How to Pass a Course](/wiki/How_to_Pass_a_Course)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=How_to_Pass_a_Course/Print_Version&action=purge&printable=yes) this page.

Many have constant problems with different courses, despite the effort put in. This short guide will show some basic steps on how to pass a course.

This is not meant to be a full treatise on study methods, but rather a practical guide of various techniques.

Also, please remember that study technique effectiveness is a most personal question - this wikibook is concentrating mostly on the techniques that commonly work well. Some people who will find that a personal technique, sometimes unconventional, works better.

  


# Going to classes

**[How to Pass a Course](/wiki/How_to_Pass_a_Course)**

* * *

[Introduction](/wiki/How_to_Pass_a_Course/Introduction) — [Going to classes](/wiki/How_to_Pass_a_Course/Going_to_classes) — [Assignments](/wiki/How_to_Pass_a_Course/Assignments) — [Studying](/wiki/How_to_Pass_a_Course/Studying) — [Taking notes](/wiki/How_to_Pass_a_Course/Taking_notes) — [If You Must Cram](/wiki/How_to_Pass_a_Course/If_you_must_cram) — [Exams](/wiki/How_to_Pass_a_Course/Exams) — [Practice](/wiki/How_to_Pass_a_Course/Practice) — [Resources](/wiki/How_to_Pass_a_Course/Resources) — [Licensing](/w/index.php?title=How_to_Pass_a_Course/Licensing&action=edit&redlink=1)

Attending class is essential to pass a course. If possible, you should go to every single class. Sit as close to the front as possible, and most importantly, pay attention. This might seem obvious, but many people go to class and don't really pay attention because they are busy doing something else: taking notes.

## Limiting notes to better understand concepts

To get the most out of class, you need to try to form an understanding of what the lecturer is attempting to teach. It is worthwhile jotting down the key ideas that are being presented in each lecture, to jog your memory later. Trying to write down verbatim what the lecturer says, however, will stop you from actually understanding what they mean. In addition, course material is usually provided (and often this includes lecture transcripts), either from your lecturer, their department, or in a textbook or the Internet. Many students write a large amount of notes during classes, but have to go back and read the notes to understand what the material is about. It's not uncommon to have a student write some information more than once, since they are not processing what they are writing. If you've just written down the key ideas, however, you can still pay attention to the lecturer, and can quickly plan for exams and other assessments without needing to re-digest it at a later date. Try to limit yourself, normally one page of notes per three hour lecture should be enough. Find the level that is right for you- listening and thinking critically may mean writing down questions or ideas that come to mind.

Forming an understanding of the ideas behind each lecture requires active thinking. Try to think ahead of the professor: "What is he going to say next?". If the professor asks someone else a question, answer it in your head. If you answer wrong, try to think why it was wrong.

Your approach to getting the most out of each class should be catered to the style of the lecture (or discussion). While some lecturers will help their students avoid feverishly writing down every fact and number covered by handing out lecture guides, others will not. It is crucial that you determine whether it is better to get all the notes written down, or to pick your head up and pay more attention to the larger picture. To best make this decision (and to do so early on), think about the type of evaluation the teacher is going to be giving. Classes with multiple choice exams typically require more note-taking, or the assistance of a lecture pamphlet handed out by the professor. On the other hand, classes where the student is graded on papers or written answer questions require more of a macro-idea approach (i.e. don't scribble, think). Above all, participation is key. The more questions you ask, the more you will learn. Speaking during class will keep you awake and involved, especially if you are asking the professor in front of a lot of people.

## Taking notes constantly from a tirade of new vocabulary

Cruel exceptions are present to these suggestions. There are always lecturers that quickly dictate long, complex processes and terms that are not in the course book. Many professors want to be concept based, but are so far into the ivory tower that they can't think outside of lists and definitions of terms. If this is the case, write down terms in ways that help you remember them, paraphrasing and rephrasing. If you can't paraphrase something, you don't understand it. In that situation, raise your hand and ask for clarification. In a class size under 30, this is class participation, and necessary. In a class size of 100-500, the professor does not know your name, and cannot associate your face with it, so you can politely interrupt all the time. This will encourage others to do so, giving everyone a chance to write things down.

## Seating suggestions for college

In high school, for the most part, the good kids sat in the front, the bad kids in the back. In college, the story changes slightly. After the first midterm in a difficult course, or just a course with a lot of freshmen, the front is a bad place to sit. People who did very poorly on the test got up this morning and said to themselves, 'today, I'm going to sit at the front of the class'. They find an influx of students coming much earlier than usual, and all sitting right up front. Unfortunately, their conviction to sit up front doesn't always go as far as being quiet into the lecture; after all, they're surrounded by their friends. There is no reason to put up with this just to maintain some kind of good student stereotype. Moreover, there are more important considerations. College classrooms can be just as inadequate as high school ones, just possibly much larger. So you think about where to sit in terms of ability to hear the professor, ability to see the displays, distance from people you don't like, ability to not strain your neck, and ability to get out of the classroom comfortably. Don't let the need to get out scare you to the back of the class, most large classrooms have an exit in the front.

  


# Assignments

**[How to Pass a Course](/wiki/How_to_Pass_a_Course)**

* * *

[Introduction](/wiki/How_to_Pass_a_Course/Introduction) — [Going to classes](/wiki/How_to_Pass_a_Course/Going_to_classes) — [Assignments](/wiki/How_to_Pass_a_Course/Assignments) — [Studying](/wiki/How_to_Pass_a_Course/Studying) — [Taking notes](/wiki/How_to_Pass_a_Course/Taking_notes) — [If You Must Cram](/wiki/How_to_Pass_a_Course/If_you_must_cram) — [Exams](/wiki/How_to_Pass_a_Course/Exams) — [Practice](/wiki/How_to_Pass_a_Course/Practice) — [Resources](/wiki/How_to_Pass_a_Course/Resources) — [Licensing](/w/index.php?title=How_to_Pass_a_Course/Licensing&action=edit&redlink=1)

Sometimes the amount of assignments is overwhelming, however, it's vital to turn in every single assignment. Any credit that can be accumulated, even if it's partial credit, can be helpful at the end. Learn to use the 80-20 rule: 20 percent of your effort will give you 80 percent of the credit. For example, if an assignment would take you 10 hours for an A worthy paper, 2 hours will most likely yield a B worthy paper. Make sure you go for that B, and if time permits, polish it to make it an A. However, an assignment that's not turned in will give you no credit at all. It is also important to turn the assignments in on time in order to avoid losing credit for simply turning in something late.

## The Outline

Fire up your favorite word processor and start with the outline. Write down every single heading that you will need. Basically each heading should correspond to each point that the paper should have. Your professor might have given you a list of points that the paper must contain, if that's the case, then that should be your outline. Take each point, in order, and turn it into a heading. Make sure to use the "Style" feature to format the headings as "Heading 1", "Heading 2", and "Heading 3" as appropriate. Also, if possible, use the "Outline View" mode available in most modern word processors. This can help you visualize the whole paper in a single screen. This can normally be done in half an hour.

## Creating the content

Once you have the outline, start filling each heading with the corresponding information. If you need information sources, try to find them before and have them on hand. Set yourself a time frame to have a very rough draft. Normally two to four hours should be enough from start to finish.

Under each heading you should have an introductory paragraph, introducing the issue that is going to be developed. This paragraph should be quite general. Each subsequent paragraph in the section must deal with a single idea. State this idea in the first one or two sentences, then provide details, an example, or a quote. Follow each quote with a **simple** opinion.

Things to have in mind:

  * Stay on topic, and try to fill the requirements of the paper. That's the objective, nothing more, nothing less.
  * Be objective, avoid controversial opinions unless you have very strong arguments to support your opinion.
  * Write your statements with confidence. Attitude is half of the game.

## Wrapping up the paper

After you have finished your paper, go back to the top. Some readers might have noticed that one of the most important parts of a paper was neglected: the thesis statement. Normally this is written first. However, that's under the assumption that you have a clear idea of what you are writing, and where you want to get to. This assumption is not valid in the context of the book. Rather, the focus is that you don't have a clear idea about what you are writing. However, while writing the paper you will get to know what you are writing about. By the end you should know where you got to: that should be your thesis statement. Of course, make sure it looks like it was made before writing the paper.

## Final details

Make sure that you include a few details to make your paper look more polished:

  * A table of contents: Remember that it was suggested to use the "Heading" styles available in your word processor? They will come in handy to create a nice looking table of contents in less than a minute. Every modern word processor will make it for you.
  * Page numbers: You have table of contents, add the page numbers to go along. Again, use you word processor feature to make the page number.
  * Sources cited: There's a very thin line between research and plagiarism. And this line can be described as citing your sources. Make sure you do it, even if it seems obvious.
  * Cover page: Make a nice yet simple cover page, and save it as template to be reused in all of your assignments. Make sure it has all of the important information: 
    * Course name
    * Assignment name
    * Date
    * Your name
    * An ID number should it be required
    * Name of the professor
    * Name of the institution

  


# Studying

**[How to Pass a Course](/wiki/How_to_Pass_a_Course)**

* * *

[Introduction](/wiki/How_to_Pass_a_Course/Introduction) — [Going to classes](/wiki/How_to_Pass_a_Course/Going_to_classes) — [Assignments](/wiki/How_to_Pass_a_Course/Assignments) — [Studying](/wiki/How_to_Pass_a_Course/Studying) — [Taking notes](/wiki/How_to_Pass_a_Course/Taking_notes) — [If You Must Cram](/wiki/How_to_Pass_a_Course/If_you_must_cram) — [Exams](/wiki/How_to_Pass_a_Course/Exams) — [Practice](/wiki/How_to_Pass_a_Course/Practice) — [Resources](/wiki/How_to_Pass_a_Course/Resources) — [Licensing](/w/index.php?title=How_to_Pass_a_Course/Licensing&action=edit&redlink=1)

## Study Techniques

Different subjects call for different studying techniques. There are the subjects that require the student to absorb information, and regurgitate it on demand, the social sciences for example, and those that require solving problems, mathematics for obvious reasons. The type of textbook used varies depending on the subject, but there are two basic types - chapter with study questions and guides, and chapter with practice problems.

For subjects that require absorbing information there is a five step study technique that works well if it is followed faithfully. The basic design for textbooks follow a certain pattern - chapters broken down into sections, with objectives at the beginning of the sections or chapters, supplemental information throughout the main text, and study guide and questions at the end of the section or chapter.

## Steps to study

If there are lectures, do Steps 1 and 2 before the lecture on the topic. Make no attempt to understand the material, just read it to get the vocabulary into your brain. When the professor mentions a concept, you will be surprised at how much more sense it makes. Do Steps 2 (again) and Steps 3 and 4 shortly after the lectures, concentrating on the material that was presented in the lectures. Periodically throughout the course, do Steps 1 and 5 for all of the material that has already been presented. Short reviews, at intervals of a week or so, are better than an 8-hour cram session the day before a test. There is a biological reason for this that is too complex to explain here, but students that "study early and study often" will learn more and remember it better.

Step 1
    Scan or skim through the section or chapter of the textbook being studied. Included should be reading all information in the margins, as well as sidebar information set off from the rest of the text in their own sections. Look at all the pictures and graphs, and read their titles. This will give you a basic idea of the information the section is trying to convey.

Step 2
    Read and understand all the objectives at the beginning of the chapter. Read all study questions and study guide material at the end of the chapter. This may seem unreasonable at first, to look at the questions being asked before reading the text, but it helps to focus the mind on the material that needs to be gleaned from reading the text. One cannot, after all, absorb everything verbatim. Knowing what is in the guides, and the knowing the questions being asked, gives the student an idea of what to focus on as the text is read.

Step 3
    The hardest part, READ THE TEXT!!! It has to be done. Passive reading alone is not adequate if the student is to get anything at all from the text. Active reading is needed, which involves focusing on the material, using the information in the study questions and guides at the end as a clue to what exactly should be learned. Furthermore, if time permits, taking notes will be extremely helpful. When taking notes writing down concepts verbatim as they appear in the text book will help to an extent, but paraphrasing the concepts in your own words will force you to think about the concepts, and thus increase your retention rate. There may be concepts that you cannot be sure you understand well even with careful re-readings, write down these questions for later.
    Being over fastidious and reading pages not assigned has varying success. For novels and journals it is obviously helpful, as it is for classes with a discussion component. However, if you discover that the pages outside assigned reading refer to terms with different names than are used in class or are entirely irrelevant, it can be a mistake to try to live up to any promise to yourself to read more than the assigned pages in the book.

Step 4
    Answer the study questions. Do them without referring to the text, and write them down. Thinking the answers through is not enough, the mind is too prone to fooling the student into thinking the material has taken hold when it hasn't. If there are questions that the student cannot answer, the student should guess. A wrong answer helps the student focus on the right answer when it comes along, and the right answers will come along in the next step.

Step 5
    Review the text, using the answers to the study questions as a guide. This is where the student finds the correct information to answer the questions they didn't know, or refines the answers that they did know. It is important to re-read any passages that contain information that was unclear to the student, which will be indicated by how well the student answered the questions in the previous step.

This process is very helpful if questions at the end of the section are assigned as homework to be turned in, for obvious reasons. If the student is fastidious about following these steps, absorbing and retaining the information will come.

For the subjects where problem solving is the skill to be acquired, nothing can replace practice. Do problems over and over again. Do them alone, do them with other students, do them with tutors. Do them again and again, and when those problems are mastered, find more to do.

## Creating lasting connections

To really remember and understand a topic, it is important to see the information in different contexts and to apply the information in a practical setting. The best way to do this is to check and edit Wikipedia articles on the subject. You will have to explain topics both in laymens terms and using technical terms. Justify your changes in the discussion page. You will have to think about the concepts carefully to decide which category and article your information belongs in. Reading all of these related pages will let you see the same information presented in a different context, which is the best way to study. If you have the time, finding outside references to justify yourself or to give an outside reference to a page that has none, find a page on Google. That will give you even more of the subject written in a different context. In a developed subject on wikipedia, such as chemistry or geology, you may not have as many opportunities to write concepts out fully yourself. After your edits on Wikipedia, you can usually start or contribute to a large body of needed information on a wikibook. Even in a developed wikibook you can add chapter questions or anything you think would help someone understand the topic.

  


# Taking notes

**[How to Pass a Course](/wiki/How_to_Pass_a_Course)**

* * *

[Introduction](/wiki/How_to_Pass_a_Course/Introduction) — [Going to classes](/wiki/How_to_Pass_a_Course/Going_to_classes) — [Assignments](/wiki/How_to_Pass_a_Course/Assignments) — [Studying](/wiki/How_to_Pass_a_Course/Studying) — [Taking notes](/wiki/How_to_Pass_a_Course/Taking_notes) — [If You Must Cram](/wiki/How_to_Pass_a_Course/If_you_must_cram) — [Exams](/wiki/How_to_Pass_a_Course/Exams) — [Practice](/wiki/How_to_Pass_a_Course/Practice) — [Resources](/wiki/How_to_Pass_a_Course/Resources) — [Licensing](/w/index.php?title=How_to_Pass_a_Course/Licensing&action=edit&redlink=1)

Taking notes is an extremely important aspect of studying that is often neglected, despite the fact that it can make the difference between a moderate grade and an excellent one. Taking notes can involve more cognitive or "thought work" than the common alternative of merely highlighting important terms or phrases in a text, but it also produces better learning. Its benefits happen by focusing attention on the material in two ways: initially at the time of reading it, and later at the time of reviewing the notes.

## Why Take Notes?

Takings notes provides a person with a way to review material learned. Reviewing and reading notes allows a person a chance to know what is on an exam, test, or pop quiz. One of the more important reasons to take notes, is to create a placemark. This placemark allows the note taker to know when the lecturer stopped giving a lecture for the day.

**For example:** _Did the teacher stop midway between Chapter 10.. or are we on Chapter 11 now?_

In this make-believe situation: You _review the notes_ and notice how the ending material of the notes are similar to the material seen before the ending part of Chapter 10. Therefore, you figure the teacher did not lecture on Chapter 11 yet... or else you dazed out really bad the last half of class.

Knowing this gives you a chance to read ahead or study certain materials, and place emphasis on studying a particular section of notes and book reading.

Notes are also a way of reviewing what you have learned in the lecture. During the lecture, a teacher may put emphasis on a particular term or word. These particular terms or words may be found on an oncoming test or quiz. Studying materials on notes gives a person a chance to know what the teacher expects you to know, now that the teacher has presented you with that material.

If the material is on the notes, the teacher expects you to know the material is on the notes.

    Therefore, there is a good chance the material will be on a test.

## The Voice Recorder

Besides the obvious paper and pencil, many technological additions of the past decades allow for someone to take notes with deadly accuracy.

  * Digital Voice Recorder
  * OR Analog Voice Recorder (recorders that use casette tapes)

These additions save effort (and reduce writers' cramp) at the time of listening to a lecture, but they also have two kinds of limitations. One kind is practical--getting good quality sound (see below for more discussion of this challenge).

Another kind of limitation is the time needed, sooner or later, to listen to recorded notes. Since speech proceeds at a relatively fixed rate, it is hard to do "speed listening" equivalent to "speed reading" of notes that are written. This fact of life puts a premium on abbreviating voice recordings of notes--though it should also be noted that the physical work of writing puts a premium on abbreviating written as well. Since taking notes is work either by writing or by recording, the best advice is to use whichever medium feels most comfortable. [Learning recorder](http://ijam.com.au/)

  


### Buying a Voice Recorder

The voice recorder is essential to any student who wants to take accurate notes. More importantly is a voice recorder with the ability to upload voice files to a computer console. Often when looking into buying a voice recorder, the choice can be complicated and indefinite. Fore, one must buy and try before deciding on one to buy. However, due to the technical limitations provided by manufacturers and stores, reviews and other word of mouth advice seems to be the supplies provided in obtaining a decent voice recorder.

**Many things should be considered when buying a voice recorder.**

  * How long does the voice recorder record?

    * Can it record for two hours or more? 

    Some classes last two hours and thirty minutes (2:30 hours)
    A recorder that can record for this long is essential.

  * Can the batteries be replaced or do the batteries need to be recharged?

    * What type of batteris does the recorder take? 

    Many devices "eat up" battery electrolytes (power) quickly.
    Getting a recorder with easy to replace batteries found in common stores is suitable for replenishing the supply of power.

  * Can the recordings be saved to a computer?

    

    Being able to put files on a computer allows for a person to sort lectures according to dates.

### Using the Voice Recorder

Getting a voice recorder saves a person a lot of time taking notes. If a teacher is mostly lecture, as in, the teacher rarely writes on the chalkboard/whiteboard, then it would be best to get a voice recorder to save your hand from developing arthritis.

#### Positioning inside a Class Room

The typical area of a placement is one of the greatest factors to consider when using a voice recorder. Observation is the key to finding a good place to set the recorder.

If you notice that a teacher does not past a certain line of boundary, say past his or her desk, then you could possibly put the recorder on his or her desk. (ask if you may first)

However, if the teacher walks around the room this creates problems. If a teacher walks past the desk, and his or her back is facing towards the desk, then the teacher's voice will not reach the voice recorder as effective--and the voice may not be recorded at all.

Often placing the recorder one's own desk is suitable if better positioning cannot be found elsewhere.

However, to have a recorder sitting on a desk while jotting down notes can cause interference when voice and other sounds are being recorded. Often the writings and scribbles cause a sound of scratching on the paper which will be picked up on the recorder. At other times, the sound of flipping a page on a binder--to go to the next clean sheet for writing notes--will be picked up on the recorder. Another thing to consider is the sound of the arm moving against a desk, while the hand goes downwards on a sheet of paper, as notes are being written. Often the rubbing sound of an arm against a desk and the hand against the paper will be recorded.

_The remedies recommended for these problems are as follows:_

  * Use an inkpen.

    Inkpens glide on paper. Also, pencil writings tend to fade with time.
    Pencil is often a bad writing utensil for notes. This is why I suggest an erasable pen.

  * Wear long sleeves

    Human skin is like leather at times. Clothing will create less friction on the desk.

  * Use an ID card under your hand.

    This is an art technique I learned long ago. It allows the hand to be placed on the ID, as the ID easily slides on paper. Sometimes it works; sometimes it does not.

  * Listen carefully to the person giving a lecture.

    I've found that professors at times go off at a tangent. The best thing to do is notice when there is a break in his or her logic being conversated, and quickly flip the page. It is at times best to bring the notebook off the desk, away from the recorder, and then flip the page to reduce recorded noise.

#### Uploading the Files

I personally like to upload all files to a computer. With one or more file belong to a particular date, say Feb-26-07, I put those files in a computer folder labeled: Feb-26-07 From there, I make a backup copy of the files inside the folders and put them on a CD.

  * CD-Drives are more common to find around schools than DVD-Drives. Therefore, a CD is more suitable than a DVD storage medium.

Also, I create a backup of that CD.

  * Take the files inside the CD and put those onto a storage medium: considerably another CD.
  * After burning a CD, make a backup on a DVD (if possible -- if not, then a CD) and then store that disc somewhere safe. I like to put things in my top dresser drawer. Always make backups of a lecture, this is very important. Backups are gravely important!
  * Another thing to consider is if you use a program to listen to the audio files. If you use a program to listen to the audio files, it would be best to find the setup program of that recorder. Take the setup program and put the program on the CD that you will carry around with you. Also, put a copy of the audio listening setup program on the backup to always have the setup program on hand.
  * Sometimes the setup programs can be found on the installation CD that comes with a voice recorder.

    Other times, a person could call Technical Help to help them find the program from the Internet and download it.

Never take the original with you! Always take the Backup.

Take the backup with you around the campus and listen to the audio files at a campus computer when you want to study/review.

#### Uploading with an Analog Recorder

This is a guide if someone wishes to create a backup. Otherwise, a person could simply find a safe place to store his or her cassette tape and access when he or she wishes to listen to it.

Make a backup of the cassette tape recording.

Typically one uses the Line Out feature of a recorder and plugs a wire into the Line Out hole.

The wire then extends to the Line In hole of another device (computers, boombox, etc.) and then inserts that part of the wire into the Line In.

(Recorder) Line Out <\----> Line In (Boombox)

Typically one pushes play on the analog voice recorder and pushes record on the boombox. Label the cassette tape with the date of the recording and set that somewhere safe.

You don't technically need to make a backup, however, I always like the idea of making backups.

I could be wrong, if I am, please someone correct this entry.

#### Getting the teacher to repeat something

Often times a person in the classroom will cough harshly. Coughs are typically very loud and will block out any voice coming into the recorder. Many times, other students could not hear what the teacher said during the time someone in the class coughed. In consideration, what a person should do is ask the teacher to repeat what he or she said. Do not fear asking the teacher the question, "Could you please repeat that?" because many other students may not have heard the teacher over the other student's sneeze, cough, or disruptive movements.

#### Hybrid Voice Recorder and Note Taking

##### With the Chalkboard

A method that is very well used when taking notes and using a voice recorder can help a person backtrack and review notes. Often times a teacher will give lectures and write on the board rarely. When a teacher writes on the board, it is best to look at the voice recorder and take note of how much time has expired and write the current recording time on the note page.

For example:

Let's say the teacher has been talking about studies in psychology without writing anything on the board for a while.

Finally, the teacher writes something on the board.

  * _Phallic Stage and male idea of swords_

The recorder has been on for about one hour and thirty minutes. The recorder displays (1:30:15) with :15 being 15 seconds.

  * Write the time displayed on the notepage. **(1:30:15)**
  * Then, copy the material on the chalkboard onto the notepage.

##### Without the Chalkboard

Sometimes the teacher doesn't even use the chalkboard. However insane that may be, some may not. In that situation, a voice recorder would be highly regarded as necessary.

As the teacher talks, you need to find placemarks that help you backtrack to certain parts of the lecture.

For instance, the teacher breaks the class lecture into three parts:

  * Intro to baskets
  * how to choose weaving material
  * weaving the basket

Subparts are included, however, he or she does not describe them to you. Thus, as the lecture goes on, you'll need to find a way to backtrack to certain material that he or she has spoken about.

If you don't want to listen to the whole recording again, it would be wise write that time down. That way, you can backtrack and review that material.

_Let's say the teacher talks about Native American weaving techniques._ You know this part is going to be on the test.

You look at the voice recorder displaying (1:45:19)

You jot down on your notebook

  * (1:45:19) Native American Techniques.

### Problems with recording Lectures

There are many disadvantages to using a recorder. When recording a lecture, one must re-listen to the entire lecture. This means using another 2 and 1/2 hours. However, you could use a tape recorder if you intend to re-use a small clip in you're private study.

## Taking notes while reading the text book

Taking notes while reading your text can be the most critical part of passing a class. In most classes the majority of information learned is taken from the text book, thus it is critical you retain as much of the information as possible. The mechanics of taking notes while reading a text book can be broken down further into various techniques.

### Type or write?

Typing your notes or writing your notes is a matter of personal preference. If you can type faster than you write, you might prefer typing over writing. Also typing your notes makes sure that they are legible. However if you do plan to type your notes make sure that you have your book, monitor, and keyboard in a comfortable position to avoid neck or back cramps while note taking. Writing out your notes has the advantage of allowing free-form drawing. Something that is possible when typing, but can be cumbersome.

### The Bookmark Technique

Often words/terms in bold--or words/terms that are important--are read. The best thing a person can do is take a sheet of writing paper and fold it up until it forms a makeshift bookmark. Then, when coming across terms, write the word found in bold on the bookmark writing line with the page number. Sometimes putting down names read and the page number the information about the person is on--does well.

This way, a person can track what page he or she is on. Also, it provides a way for someone to glance quickly at the bookmark and try to remember what the term means. If he or she does not remember what the word/term means, he or she can simply turn back to the page and regrasp the material.

The best part of this technique is that you can fold the bookmark up and put it in your pocket while going from place to place. All someone has to do is take the bookmark out of his or her pocket, look at it, and think hard about the terms and words on the bookmark. This is a great way to quickly review.

### Copying the text verbatim

Copying text from the text book verbatim is the least perferred method of taking notes, but it can be somewhat helpful if it is the only option avaliable.

### Copying definitions verbatim

When reading a Math or Science text, copying definitions verbatim is appropriate, and required. Science and Math are build upon precise definitions, so modifying in any way will distort key concepts. The definitions are so important that copying them to flash cards for memorization is encouraged if time permits.

### Paraphrasing concepts and paragraphs

Paraphrasing concepts is the ideal way to take notes. It will force you to actually think about what you read. For Math and Science texts, extract **ALL** definitions and relevant theorems from paragraphs, and organize them into lists and sublists. This will make sure you know they exist. When reading all other texts, try to summarize **ALL** concepts. Summarizing paragraphs will help too, but isn't as effective because the author of the text has already done some of the organization for you. You may think that summarizing all concepts is a bit extreme, but often in a class you don't know what will be on the test and what won't, so if you want a high grade, this is the only way to be sure.

#### What if I don't understand something in the text?

The following is just a partial list of what you can do in this situation.

  1. Ask your instructor for clarification. You can call or email your instructor before the next time class meets, or just wait until class. This is usually a very good option if you only have a small number of questions. Unfortunatly instructors tend to be very busy and are difficult to get in touch with.
  2. Ask a friend or class mate. This is a good option only if your friend knows the material better than you do. If not then you will have a situation of the blind leading the blind.
  3. Get another text book from the library that covers the same subject. This is an excellent option because text book explanations are usually well thought out, and there are often many text books in the library on the same subject, which all describe the same concepts, but from different points of view, and in different wording.

### Asking yourself, and answering questions

This is an **EXTREMELY** good technique. Once you read a section of text, ask your self as many questions as time allows about what you have read. Try to answer them based on the content of the book. It is good to do this as you go along, because it will make sure that your truly understood read before you go on to the next section. This technique is essential if you are reading from texts that don't have a lot of questions in them, or have questions that don't have answers in the back.

## Taking notes during lecture

Shorthand can be helpful. Following along in the derivation of a solution to a math problem is a very good way to stay focused.

### Helpful Links

  * [Notemaking Tools](http://www.englishcompanion.com/Tools/notemaking.html)
  * [Study Skills Library California Polytechnic State University, San Luis Obispo](http://www.sas.calpoly.edu/asc/ssl/notetaking.systems.html)

  


# If you must cram

**[How to Pass a Course](/wiki/How_to_Pass_a_Course)**

* * *

[Introduction](/wiki/How_to_Pass_a_Course/Introduction) — [Going to classes](/wiki/How_to_Pass_a_Course/Going_to_classes) — [Assignments](/wiki/How_to_Pass_a_Course/Assignments) — [Studying](/wiki/How_to_Pass_a_Course/Studying) — [Taking notes](/wiki/How_to_Pass_a_Course/Taking_notes) — [If You Must Cram](/wiki/How_to_Pass_a_Course/If_you_must_cram) — [Exams](/wiki/How_to_Pass_a_Course/Exams) — [Practice](/wiki/How_to_Pass_a_Course/Practice) — [Resources](/wiki/How_to_Pass_a_Course/Resources) — [Licensing](/w/index.php?title=How_to_Pass_a_Course/Licensing&action=edit&redlink=1)

## Cramming for a test

Cramming is the worst way to study, and you are unlikely to retain anything you read during cramming very far beyond the actual exam. That being said, sometimes cramming is the only option for a time-constrained student, or one that has spent insufficient time with the material during the semester. It can be also quite useful if you simply don't understand the material that well.

The following technique has been used by the author in many technical and mathematical classes. Some parts may also be useful in other classes, but some/most parts will obviously not apply.

Step 1
    Go over every homework assignment that was given during the course of the class, even review the assignments you failed to complete. You should complete EVERY problem up to the point where the remainder is "busy work"; where that point is is up to you. Repeat this step until you can figure out the right technique to solve a problem without getting bogged down in pondering. The point here is NOT to memorize the homework problems, it is to ensure you can solve them without hesitation. While most exam problems are far beyond the level of homework problems, most exam questions can be broken down into chunks that will resemble homework. You need to be able to recognize the chunks and solve them quickly, or you will never finish.

Step 2
    Many professors will have previous exams on file in the library. You should go through a similar process as you did in Step 1. In this step, it is not out of the question for you to encounter problems were you just don't understand how the solution was achieved. Fear not, and consult Steps 4 and 5.

Step 3
    Some kind of professors will even hand out suggested study questions prior to the exam. This is a gift, as the professor could not supply you with a clearer hint as to what he/she expects you to know. You should go over these in the same manner as Steps 1 and 2.

Step 4
    Many classes will have review sessions prior to the exam. (At the author's school, they were required to be held.) This is an excellent opportunity to have questions about the more difficult problems answered. If you still do not understand a professor's explanation for the solution to a problem (or if you don't think you could replicate it on the fly during an exam), simply copy the solution down verbatim and proceed to Step 5.

Step 5
    Many kind of professors will let students take notecards/sheets into the exam. The intent of your professors is to let you write down long formulas ahead of time so you don't have to engage in rote memorization of several pages of nasty formulas. (Naturally, you should go ahead and put these on your formula sheet.) At this point, you have already learned all you are going to learn, your focus now is on passing the exam. To that end, take the solutions to problems you didn't understand from Steps 1 to 3, use a scanner or copy machine to reduce them down to the smallest legible size, and simply staple or tape them to your "formula" sheet/card. You would be shocked to realize how often those problem will appear on the exam, with only minor variations. If you are allowed a calculator on your test (only if it applies), go on to Step 6.

Step 6
    If you're using a standard scientific calculator, learn all the functions ahead of time. If your calculator runs on batteries, make sure they will last you through the exam. There's not much else to put here, since your calculator probably cannot be programmed. If you're using a graphing calculator, proceed to Step 7.

Step 7
    If you're using a graphing calculator, and your course becomes noticeably easier with it (a fact that can only be noticed if you're reasonable competent with your calculator), you should spend some time making/finding small programs to make your computing time shorter on the exam. With adequate practice, you should be able to let the calculator know your requirement in a very short period of time. In my engineering experience, the ratio of input time to calculator processing time should ideally be around 3:10, but ratios up to 1:2 are acceptable. Finding programs for your calculator should ideally be done ahead of time, but even if that is not possible, [Google](/w/index.php?title=Google&action=edit&redlink=1) is your friend. There are also some major sites dedicated to popular calculators like the [Ti-89](/w/index.php?title=Ti-89&action=edit&redlink=1). Make sure your programs work under strained conditions, as troubleshooting is not to be done on the exam. If your program doesn't work on the exam, do not waste more than three attempts on it; proceed, instead, to work out the problem with hand.

  


# Exams

**[How to Pass a Course](/wiki/How_to_Pass_a_Course)**

* * *

[Introduction](/wiki/How_to_Pass_a_Course/Introduction) — [Going to classes](/wiki/How_to_Pass_a_Course/Going_to_classes) — [Assignments](/wiki/How_to_Pass_a_Course/Assignments) — [Studying](/wiki/How_to_Pass_a_Course/Studying) — [Taking notes](/wiki/How_to_Pass_a_Course/Taking_notes) — [If You Must Cram](/wiki/How_to_Pass_a_Course/If_you_must_cram) — [Exams](/wiki/How_to_Pass_a_Course/Exams) — [Practice](/wiki/How_to_Pass_a_Course/Practice) — [Resources](/wiki/How_to_Pass_a_Course/Resources) — [Licensing](/w/index.php?title=How_to_Pass_a_Course/Licensing&action=edit&redlink=1)

## Going to the exam

Before you do your first test, take a break. You must be a good mental condition before going into an exam. Avoid studying two hours or less before the exam. Arrive on time to the exam, make sure you have as much time as you need. Make sure you have all needed materials, such as pen, pencil, or calculator. Put on a positive attitude, and go in, you are ready to pass the examination, you just have to do some paperwork. Make sure you're adequately rested, and don't consume caffeine unless to stay conscious. Caffeine will scatter your thought, but also keep your eyes open if needed.

## Let's begin

If it's a small class and the professor is proctoring the exam, sit as close to him as possible, you'll see why later. Once you get the exam, read it over completely before you begin. Identify the easier questions, and the harder ones. Start with the easier ones. Pay attention to the content that each question is evaluating. Most tests try to cover the material evenly, so this might give you a clue about how solve some of the questions on which you are not sure how to solve.

For example, let's take a Calculus exam where you need to solve several integrals. If you solved one using using substitution, most likely the other ones will require different methods, such as integration by parts. Don't rule out any possibility, but having a mental checklist of material that has been evaluated by the different questions might give you a clue.

## Asking questions

If you have a doubt, don't ask a classmate, try to ask the professor directly. That's the one person from whom you can get a reliable answer. Some professors answer questions, some don't; but it's worth a try. In order to get the best possible answer, do as much of the question as possible, even if wrong, and then ask. That will increase your chances of a useful clue. If you are sitting next to the professor, you might be able to hear some answers to other students' questions. Again, that's best source of information.

Don't copy from somebody else. Even if you don't get caught, the person you are copying might be more confused than you. It's not a good chance to take. In the worst case, the person next to you might have a similar but different test. And you might find out only after you get your test back.

## Scope out the location

Always scope out the exam location. If it is the room that you take your class in, then this step is probably already done. However, if your college exam is in a different building, it's important to go there, find you seat and see if there's anything wrong with it. If you don't do this you could be taking a final in a broken seat or under a broken light, or simply on a wrong-handed desk. This will help you find your seat on exam day, and familiarizes you with challenges that you might panic about otherwise, like tiny desks or temperature issues.

## Practice on the Internet

Depending on your course material, often online tests can be found if you search the web a little. Keywords are _U.S. history quizzes_ or _U.S. History tests_ or _Practice Calculus problems_. Finding these quizzes online take some time.

If you're interested in U.S. History quizzes: :<http://www.funtrivia.com/quizzes/history/us_history.html> Other quizzes in different subjects can be found online.

Many people create websites for AP student to practice his or her knowledge on a quiz. Many of these quizzes can be found online. The Internet is a goldmine.

## Specific tips and hints

There are several tips that apply to specific types of exams:

  * [Number based tests](/wiki/How_to_Pass_a_Course/Number_based_tests)
  * [Essay based tests](/w/index.php?title=How_to_Pass_a_Course/Essay_based_tests&action=edit&redlink=1)

  


# Practice

**[How to Pass a Course](/wiki/How_to_Pass_a_Course)**

* * *

[Introduction](/wiki/How_to_Pass_a_Course/Introduction) — [Going to classes](/wiki/How_to_Pass_a_Course/Going_to_classes) — [Assignments](/wiki/How_to_Pass_a_Course/Assignments) — [Studying](/wiki/How_to_Pass_a_Course/Studying) — [Taking notes](/wiki/How_to_Pass_a_Course/Taking_notes) — [If You Must Cram](/wiki/How_to_Pass_a_Course/If_you_must_cram) — [Exams](/wiki/How_to_Pass_a_Course/Exams) — [Practice](/wiki/How_to_Pass_a_Course/Practice) — [Resources](/wiki/How_to_Pass_a_Course/Resources) — [Licensing](/w/index.php?title=How_to_Pass_a_Course/Licensing&action=edit&redlink=1)

The old adage says practice makes perfect. That´s true of everything in life, so too for a student. Too often it happens that we study hard for some time, attain a peak level of mastery and feel we have attained it once and for all. Then we stop practicing confident that we have it. Sadly that´s not true for anything. Things have a tendency of slipping away if you don't practice. So practice, revise in case of changes in theory. Keep solving repeatedly in case of problems.

Once we have practiced something a sufficient number of times, it seems that our bodies remember the correct responses much better than our minds do. This is what makes us able to, for example, drive a car and carry on a conversation at the same time.

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=How_to_Pass_a_Course/Print_Version&oldid=1624405](http://en.wikibooks.org/w/index.php?title=How_to_Pass_a_Course/Print_Version&oldid=1624405)" 

[Category](/wiki/Special:Categories): 

  * [How to Pass a Course](/wiki/Category:How_to_Pass_a_Course)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=How+to+Pass+a+Course%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=How+to+Pass+a+Course%2FPrint+Version)

### Namespaces

  * [Book](/wiki/How_to_Pass_a_Course/Print_Version)
  * [Discussion](/w/index.php?title=Talk:How_to_Pass_a_Course/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/How_to_Pass_a_Course/Print_Version)
  * [Edit](/w/index.php?title=How_to_Pass_a_Course/Print_Version&action=edit)
  * [View history](/w/index.php?title=How_to_Pass_a_Course/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/How_to_Pass_a_Course/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/How_to_Pass_a_Course/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=How_to_Pass_a_Course/Print_Version&oldid=1624405)
  * [Page information](/w/index.php?title=How_to_Pass_a_Course/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=How_to_Pass_a_Course%2FPrint_Version&id=1624405)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=How+to+Pass+a+Course%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=How+to+Pass+a+Course%2FPrint+Version&oldid=1624405&writer=rl)
  * [Printable version](/w/index.php?title=How_to_Pass_a_Course/Print_Version&printable=yes)

  * This page was last modified on 4 September 2009, at 18:06.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/How_to_Pass_a_Course/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
