# Jeep Liberty/Print version

From Wikibooks, open books for an open world

< [Jeep Liberty](/wiki/Jeep_Liberty)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

  


  


# Table of Contents

    [Cover](/w/index.php?title=Jeep_Liberty/Cover&action=edit&redlink=1)
    [Authors](/wiki/Jeep_Liberty/Authors)
    [History](/wiki/Jeep_Liberty/History) ![25 percents developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)

## Suspension

    [Suspension](/wiki/Jeep_Liberty/Suspension) ![25 percents developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)

## Drivetrain

    [Engines](/wiki/Jeep_Liberty/Engines) ![50 percents developed  as of Oct 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    [Transmissions](/wiki/Jeep_Liberty/Transmissions) ![25 percents developed  as of Oct 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
    [Transfer Cases](/wiki/Jeep_Liberty/Transfer_Cases) ![25 percents developed  as of Oct 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
    [Tires & Rims](/wiki/Jeep_Liberty/Tires_%26_Rims) ![50 percents developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    [Performance](/wiki/Jeep_Liberty/Performance) ![50 percents developed  as of Oct 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)

### Axles

    [Dana 30a](/wiki/Jeep_Liberty/Dana_30a) ![50 percents developed  as of Nov 20, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    [Chrysler 8.25"](/wiki/Jeep_Liberty/Chrysler_8.25%22) ![75 percents developed  as of Nov 20, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    [Dana 35C](/wiki/Jeep_Liberty/Dana_35C) ![0% developed  as of Nov 20, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
    [Gearing](/wiki/Jeep_Liberty/Gearing) ![50 percents developed  as of Nov 20, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    [Limited Slips](/wiki/Jeep_Liberty/Limited_Slips) ![50 percents developed  as of Nov 20, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    [Lockers](/wiki/Jeep_Liberty/Lockers) ![50 percents developed  as of Nov 20, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)

## Misc

    [Armor](/wiki/Jeep_Liberty/Armor) ![0% developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
    [Recovery](/wiki/Jeep_Liberty/Recovery) ![0% developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
    [Electrical](/wiki/Jeep_Liberty/Electrical) ![50 percents developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    [Accessories](/wiki/Jeep_Liberty/Accessories) ![0% developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)

## Appendices

    [Abbreviations & Terms](/wiki/Jeep_Liberty/Abbreviations_%26_Terms) ![50 percents developed  as of Sep 10, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    [Resources](/wiki/Jeep_Liberty/Resources) ![0% developed  as of Oct 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)

# Cover

[Jeep Liberty/Cover](/w/index.php?title=Jeep_Liberty/Cover&action=edit&redlink=1)

# Authors

  * [unixxx](/wiki/User:Unixxx)
  * [JeepKJ02](http://www.cardomain.com/ride/453391)

  


  * [AdamIsAdam](http://www.cardomain.com/ride/325889/10)
  * [Kevin](http://home.comcast.net/~corwyyn/firewall-penetration.html)
  * [Tokyojoe](http://www.cardomain.com/ride/718416)
  * [Kugellager](http://www.lostkjs.com/forum/phpBB2/viewtopic.php?t=5363)

# History

The Jeep Liberty (KJ), or Jeep Cherokee (KJ) outside North America, was introduced in 2002 to replace its predecessor the Jeep Cherokee (XJ). The Liberty comes with Jeep's distinctive 7-slot grille and round headlights. On April 12, 2002, the Liberty was lowered one inch. In 2003, the rear drum brakes were replaced with disc brakes. In mid-2003, the automatic transmission was changed from the 45RFE to the 42RLE. In 2005, Jeep redesigned the front end and added a diesel model (available for export outside the US since 2002). In 2004, a passenger seat airbag sensor was added. In 2006, ESP and VLP were added and ABS became standard. The Liberty has come in four trim levels: Sport, Latitude, Renegade, and Limited and two special models: CRD and Rocky Mountain Edition. The Sport, Latitude, and Limited are the only versions still in production.

## Sport

The Sport edition Liberty is recognized by its gray fender flares and bumpers.

## Limited

The Limited edition Liberty is recognized by its color-matched fender flares/bumper and chrome grille surround/side strips. A narrow-spoke 17" wheel and tire combination became the standard in 2005, with an optional 5-spoke chrome wheel available exclusively for the Limited models.

  
The interior has options for an in-dash navigation system, and is appointed with leather seats and a premium sound system.

## Renegade

In 2005, Jeep redesigned the Renegade with the flat hood to give it the rugged look. Jeep also added bumper mounted fog lights. It still had all the features the 2002-2004 Renegade came with, such as the roof mounted lightbar, pocket-style flares, and Renegade emblems.

## Rocky Mountain Edition

The Rocky Mountain Edition is a special edition Liberty based on the Renegade X package. Special features include painted exterior pieces, interior accents, a power sunroof, upgraded wheels, seats embroidered with the Jeep logo, and a Rocky Mountain Edition badge. In 2004 Columbia Sportswear teamed up with Jeep and offered a Columbia Edition. This was offered prior to The Rocky Mountain Edition. A coupon for a free Columbia Bug A Boo parka came with the vehicle. 26,000 units were manufactured.

# Suspension

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Jeep_Liberty_Springs_2005.jpg/220px-Jeep_Liberty_Springs_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

2005 Gasoline Jeep Liberty Rear Springs

## General

The front suspension of the Jeep Liberty is an [a-arm/wishbone](http://en.wikipedia.org/wiki/Wishbone_suspension) [IFS](http://en.wikipedia.org/wiki/Suspension_%28vehicle%29#Independent_suspensions). The rear is a live tri-link [trailing arm](http://en.wikipedia.org/wiki/Trailing_arm) [solid axle](http://en.wikipedia.org/wiki/Suspension_%28vehicle%29#Dependent_suspensions). Both the front and rear suspensions use coil springs.

  * [Shocks & Struts](/w/index.php?title=Jeep_Liberty/Print_version/Shocks_%26_Struts&action=edit&redlink=1)

### Pre-Lowered vs. Lowered

On April 12, 2002, DaimlerChrysler lowered the ride height of the Jeep Liberty suspension by 22mm (7/8") in the front and 19mm (3/4") in the rear. This change was made to improve road handling and perceived safety concerns. Many speculate that this is in response to the Autoweek Magazine Slalom test in which a Liberty rolled. Libertys built prior to April 2, 2002 are considered "pre-lowered", because they were made previous to the time when DaimlerChrysler lowered the Liberty. Libertys built after April 2, 2002 is considered "lowered", because they have a lower ride height than the pre-lowered. While a spacer lift will maintain the difference between lowered and pre-lowered, a spring replacement lift will render whether the Jeep was lowered or pre-lowered from the factory irrelevant.

## Lift Kits

### OTT

OTT stands for "Over the Top" which means instead of placing the spacer underneath the coil/strut assembly it is placed on top of the assembly.

There are three OTT lifts on the aftermarket for the Jeep Liberty:

  * [Rocky's](/wiki/Jeep_Liberty/Suspension/Rocky_Road_Outfitters) 2-1/8" Combo Lift
  * [Rocky's](/wiki/Jeep_Liberty/Suspension/Rocky_Road_Outfitters) 2.5" Budget Lift
  * [Rusty's](/wiki/Jeep_Liberty/Suspension/Rusty%27s_Offroad) 2.5" Spacer Lift

While no spacer lift will give you a superior ride over a full coil lift, each of the spacer lifts listed above has its own pros and cons. Rocky's budget lift has known problems, but their combo lift is of much higher quality. Rocky's combo lift is not a full OTT lift. It combines the spacer lift and the OTT lift to give you the full 2-1/8" in the front. In the rear it's a straight spacer lift. Rusty's OTT lift is similar to Rocky's budget lift, but is known to have fewer problems. The front is a full OTT lift and the rear a spacer lift. Rusty's OTT lift will give you a total of 2.5 inches of lift. None of the Daystar lifts are OTT. Daystar's lift product is superior to both Rusty and Rocky's spacer lifts. Go cougars!

### Spacer Lifts

  * [Daystar](/w/index.php?title=Jeep_Liberty/Print_version/Daystar&action=edit&redlink=1)
  * [Rocky Road Outfitters](/w/index.php?title=Jeep_Liberty/Print_version/Rocky_Road_Outfitters&action=edit&redlink=1)
  * [Rusty's Offroad](/w/index.php?title=Jeep_Liberty/Print_version/Rusty%27s_Offroad&action=edit&redlink=1)
  * [Skyjacker](/w/index.php?title=Jeep_Liberty/Print_version/Skyjacker&action=edit&redlink=1)

  
Saying that daystar is far superior to ott lifts is a very opinionated statement. daystar put extra undue stress on the already weak stock coils.

### Full Coil Spring Lifts

  * [BDS](/w/index.php?title=Jeep_Liberty/Print_version/BDS&action=edit&redlink=1)
  * [Frankenlift](/w/index.php?title=Jeep_Liberty/Print_version/Frankenlift&action=edit&redlink=1)
  * [Rocky Road Outfitters](/w/index.php?title=Jeep_Liberty/Print_version/Rocky_Road_Outfitters&action=edit&redlink=1)
  * [Rusty's Offroad](/w/index.php?title=Jeep_Liberty/Print_version/Rusty%27s_Offroad&action=edit&redlink=1)
  * [Skyjacker](/w/index.php?title=Jeep_Liberty/Print_version/Skyjacker&action=edit&redlink=1)

### Other Lifts

  * [Clevis Lift](/w/index.php?title=Jeep_Liberty/Print_version/Clevis_Lift&action=edit&redlink=1)
  * [Spring Isolator Lift](/w/index.php?title=Jeep_Liberty/Print_version/Spring_Isolator_Lift&action=edit&redlink=1)

# Drivetrain

## Engines

## 2.4L PowerTech I4

The 2.4L [PowerTech](//en.wikipedia.org/wiki/Chrysler_PowerTech_engine) I4 was available from 2002 to 2005. It was most likely discontinued as a result of lack of demand.

## 3.7L PowerTech V6

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/33/Jeep_Liberty_Gas_Intake_2005.jpg/220px-Jeep_Liberty_Gas_Intake_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

2005 Jeep Liberty 3.7L PowerTech V6

The 3.7L PowerTech V6 has been available in the Liberty from 2002 to present.

Two different PCMs (Powertrain Control Modules) have been coupled with the PowerTech. The JTEC was the older controller and the NGC is the newer controller. The JTEC PCM had three connectors on it and used a separate TCM (Transmission Control Module), while the NGC has four because it integrates the TCM. 2006-2007 Libertys use a hybrid bus system in which the PCM, gas TCM, and ABM (ABS and ESP) use the CAN Bus and everything else uses the PCI Bus. The BCM (Body Control Module) then acts as a bridge between the PCI Bus and CAN Bus.

## 2.8L VM Motori I4

The 2.8L [VM Motori](//en.wikipedia.org/wiki/VM_Motori) Turbodiesel was available in the CRD Liberty from 2005 to 2006. The CRD was eventually discontinued in the US as a result of stricter emissions regulations. It's still available overseas.

## Specifications

2.4L 3.7L 2.8L

Style
I4
V6
I4 Turbo Diesel

Displacement
2.4L (148ci)
3.7L (226ci)
2.8L (171ci)

Horsepower
150 HP @ 5,600 RPM
210 HP @ 5,200 RPM
160 HP @ 3,800 RPM

Torque
165 ft. lbs. of torque @ 4,000 RPM
235 ft. lbs. of torque @ 4,000 RPM
295 ft. lbs. of torque @ 1,800 RPM

Cam
Double Overhead Cam (DOHC)
Single Overhead Cam (SOHC)
Double Overhead Cam (DOHC)

Fuel Injection
Sequential Fuel Injection (SFI)
Sequential Fuel Injection (SFI)
Direct Fuel Injection (DFI)

Bore
3.44 inches - 87.5mm
3.66 inches - 93mm
3.70 inches - 94mm

Stroke
3.98 inches - 101mm
3.57 inches - 90.8mm
3.94 inches - 100mm

Compression Ratio
9.5:1
9.6:1
17.5:1

## Cooling

Jeep Liberty CRDs with the 2.8L diesel engine have an intercooler behind the combination transmission cooler & A/C condenser and before the engine radiator.

## Engine Swap

The Chrysler 4.7L PowerTech V8, also known as the Dodge 4.7L Magnum V8, is the most compatible candidate for a larger displacement engine swap.

  * [4.7L PowerTech V8 Engine Swap](/w/index.php?title=Jeep_Liberty/Print_version/4.7L_PowerTech_V8_Engine_Swap&action=edit&redlink=1)

## External Links

  * [The 2.4 liter four-cylinder Chrysler-Dodge engine](http://www.allpar.com/mopar/24.html)
  * [Allpar presents the Dodge/Jeep 3.7 liter V-6](http://www.allpar.com/mopar/37.html)
  * [Jeep Horizons Engine Specs](http://www.jeephorizons.com/tech/2005kj_specs.html)

## Transmissions

## Automatics

The 42RLE is a 4-speed overdrive automatic transmission. The 42RLE comes in 2003.5+ Jeep Libertys. The 45RFE is a 4-speed overdrive automatic transmission, with an alternative 2nd gear ratio for downshifting. The 45RFE was replaced by the 42RLE in 2003.5+ Libertys. The 545RFE is a 5-speed overdrive automatic transmission. The 545RFE was the only transmission available in Liberty CRD models. The Liberty's maximum tow rating with an automatic transmission is Class III 5,000#. Mechanically, the 42RLE has 13 bolts and a straight crossmember, while the 45RFE and 545RFE have 15 bolts and a backwards angled crossmember. Electronically, vehicles equipped with the 42RLE have a 4 connector NGC PCM (Powertrain Control Module) with an integrated TCM (Transmission Control Module), while those equipped with the 45RFE have a 3 connector JTEC PCM and a separate TCM.

**Gear Ratio Table**

42RLE 45RFE 545RFE

1st
2.84
3.00
3.00

2nd Up
1.57
1.67
1.67

2nd Down
1.57
1.50
1.50

3rd
1.00
1.00
1.00

4th
0.69
0.75
0.75

5th
N/A
N/A
0.67

Rev
2.21
3.00
3.00

## Manuals

The NSG370 is a 6-speed overdrive manual transmission. The NSG370 comes in 2005+ Jeep Libertys. The NV3500 is a 5-speed overdrive manual transmission. The NV3500 was replaced by the NSG370 in 2005+ Libertys. The NV1500 is 5-speed overdrive manual transmission with an unsynchronized first gear. The Liberty's maximum tow rating with a manual transmission is Class II 3,500#. The clutch design of the manuals results in a lower tow rating than that of the automatics. A driver skilled in towing with manuals may be able to safely tow more than Class II.

**Gear Ratio Table**

NSG370 NV1500 NV3500

1st
4.46
3.96
4.01

2nd
2.61
2.37
2.32

3rd
1.72
1.49
1.40

4th
1.25
1.00
1.00

5th
1.00
0.83
0.73

6th
0.84
N/A
N/A

Rev
4.06
3.54
3.55

## Cooling

Jeep Libertys with the 42RLE transmission have an auxiliary transmission cooler in front of the engine radiator. Libertys with the 45RFE transmission have a cooler built into the engine radiator. Liberty CRDs with the 545RFE have a combination transmission cooler & A/C condenser in front of the intercooler and engine radiator. Libertys with the NSG370, NV1500, and NV3500 manual transmissions don't have a cooler because manual transmissions lack a fluid pump.

  
**Standard Coolers (3.7L Auto):**

2002 2003 2004 2005 2006 2007 2008 2009

**Auxiliary Transmission**
No
Yes

**Integrated Transmission**
Yes

**Power Steering**
Yes
No
Yes (Manual)

## Off-Roading

An automatic transmission is more popular than a manual for off-roading. It removes the distraction, water leakage, and clutch wear associated with off-road manual shifting. These benefits come at a price, as an automatic is always heavier than an equivalent manual.

  


## External Links

  * [List of Chrysler Transmissions](http://en.wikipedia.org/wiki/List_of_DaimlerChrysler_transmissions)
  * [Chrysler 42RLE Transmission](http://en.wikipedia.org/wiki/Chrysler_42RLE_transmission)
  * [Chrysler 45RFE Transmission](http://en.wikipedia.org/wiki/Chrysler_45RFE_transmission)
  * [Chrysler 545RFE Transmission](http://en.wikipedia.org/wiki/Chrysler_545RFE_transmission)

## Transfer Cases

[Transfer cases](//en.wikipedia.org/wiki/Transfer_case) for the Jeep Liberty are built by [New Venture Gear](//en.wikipedia.org/wiki/New_Venture_Gear), hence the NV prefix. New Venture inherited New Process Gear from Chrysler, therefore the older transfer cases are prefixed with NP. Whether prefixed with NV or NP, parts are interchangeable between the same transfer case model.

Full-time 4WD can be used on pavement because it utilizes the differential in the transfer case. Part-time 4WD Lo and 4WD Hi can't be used on pavement because they lock the axles together in the transfer case. While the 2WD, full-time 4WD, and part-time 4WD Hi modes support the maximum vehicle speed, the part-time 4WD Lo mode does not. Part-time 4WD Hi should not be engaged over 55mph. Essentially, part-time 4WD should be used for off-road, full-time 4WD for maximum traction on-road, and 2WD for everything else.

## NV231J

The NV231J, utilized in the Command-Trac system, is a mechanically shifted part-time transfer case. Its chain-driven aluminum construction makes it weaker than gear-driven iron transfer cases.

Mode Gear Ratio

2WD
1.00:1

4-HI Part Time
1.00:1

N
N/A

4-LO
2.72:1

## NV241J

The NV241J, also known as Command-Trac HD, is sometimes incorrectly referred to as an "NV231J-HD". It was available in the 2005-2007 Jeep Liberty (KJ) with the 6-spd transmission in any package. The transfer case is tagged "241J" in these applications and uses the same gear ratios as the NV231J. This is not the limited production NV241OR found in the Wrangler Rubicon models.

## NV242

The NV242, also known as Select-Trac, is a mechanically shifted full time tranfer case.

Mode Gear Ratio

2WD
1.00:1

4-HI Part Time
1.00:1

4-HI Full Time
1.00:1

N
N/A

4-LO
2.72:1

## Slip Yoke Eliminator

A slip yoke eliminator replaces the slip yoke in the rear of the transfer case with a fixed yoke. Primarily this allows for the installation of double cardon joints and reduces the driveshaft angle by increasing the driveline length. These two changes help cut down on vibration caused by lifting the Jeep. As an added benefit, it prevents the transfer case from spilling fluid everywhere if the driveshaft gets pulled out. When installing a slip yoke eliminator, a drive shaft with an integrated slip yoke and double cardon joints must also be installed.

## Tires & Rims

## General Information

The Jeep Liberty has an Independent Front Suspension (IFS) which prevents installing a suspension lift greater than 2.5" without major and costly modifications. Without a major overhaul a lift of over 2.5" will cause your CV axles and ball joints to possibly fail. With the currently available lifts, the Jeep Liberty can be fitted with up to 265/75R16 (32"x10.5") tires. Tires larger than 265/75R16 will require extensive modification of the vehicle and cause major rubbing which will detract from offroadability. The Liberty comes from the factory without locking lug nuts on the wheels, so many owners replace one lug on each wheel with a Mopar locking lug. 245/75R16 (30"x9.7") is the most popular size used with a 2 1/2" lift; this size requires minimal trimming. 265/75R16 is the largest possible tire size; this size requires trimming the plastic wheel well insert and flattening the pinch weld.

## Stock Liberty Wheel Specs

### 16x7

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Jeep_Liberty_Renegade_Wheels_2005.jpg/220px-Jeep_Liberty_Renegade_Wheels_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

16" Jeep Liberty Renegade wheel

**Bolt Pattern:** _5x4.5"_

**Backspacing:** _5.5"_

**Offset:** _38mm_

\--[65.13.29.102](/wiki/Special:Contributions/65.13.29.102) ([discuss](/w/index.php?title=User_talk:65.13.29.102&action=edit&redlink=1)) 16:03, 1 July 2013 (UTC)=== 17x9" ===

**Bolt Pattern:** _5x4.5"_

**Backspacing:**

**Offset:**

## 15" vs. 16" Wheels

With a 17" wheel there is a limited selection of all-terrain tires available. A popular upgrade for the lifted Liberty is stock 16x8" Jeep Wrangler Rubicion wheels (Moab Wheels) with 5" of backspacing and 245/75R16 Goodyear MTR Tires. The Liberty's stock 16x7" wheel can fit a 10.5" wide tire with no problems. Only a few 15" wheels can fit on the Liberty without interfering with the brake caliper. Some other choices are the Rock Crawler Xtreme Steel Wheels with a backspacing of 4.5" or 3.75" or Cragar Wheels with 4-4.5" of backspacing. A backspacing of under 4" will work, but is not recommended because rubbing on suspension components may occur.

## Backspacing and Wheel Spacers

Backspacing is a measurement of the distance from the mounting point on the wheel to the back of the rim. The greater the backspacing the closer the wheel to the Jeep and the more likely the wheel will rub on suspension components. The smaller the backspacing the more the wheel sticks out from the wheel well and the more likely the tires will throw mud up the side of the Jeep. A good rule of thumb is to keep the tires within the fender flares but far enough from the suspension components that they don't rub. Putting larger tires on the Liberty will often require decreasing the backspacing in order to eliminate tire rub on the sway bar. This is where spacers come in. A smaller backspacing can be simulated by installing a wheel spacer to push the wheel out and away from the suspension components. Spidertrax is a reputable cast aluminum spacer manufacturer/dealer whose spacers are plenty safe to install on the Liberty. Just remember that in many states wheel spacers are illegal.

[List of States Where Wheel Spacers are Illegal](/w/index.php?title=Jeep_Liberty/Print_version/List_of_States_Where_Wheel_Spacers_are_Illegal&action=edit&redlink=1)

## Tire/Lift Chart

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/64/Goodyear_Wrangler_SR-A_P23570R16.jpg/220px-Goodyear_Wrangler_SR-A_P23570R16.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Goodyear Wrangler SR-A 235/70R16 tire from Jeep Liberty Renegade

Tire Diameter Tire Width Tire Size Rubbing with 2.5" Lift

28.7"
8.7"
215/75R16*
No Rubbing w/o Lift

29"
9.3"
235/65R17*
No Rubbing w/o Lift

29.3"
8.9"
225/75R16*
No Rubbing w/o Lift

29"
9.3"
235/70R16*
No Rubbing w/o Lift

30.3"
8.8"
225/75R17
Minor Rubbing w/o Lift

29.5"
9.7"
245/70R16
Minor Rubbing w/o Lift

29.9"
9.3"
235/75R16
Minor Rubbing w/o Lift

30.1"
10.2"
255/70R16
Minor Rubbing w/ Lift

30.5"
9.7"
245/75R16
Minor Rubbing w/ Lift

30.5"
10.5"
31x10.5x15
Minor Rubbing w/ Lift

30.6"
10.7"
265/70R16
Minor Rubbing w/ Lift

31.2"
11.0"
275/70R16
Moderate Rubbing w/ Lift

31.8"
9.3"
235/85R16
Moderate Rubbing w/ Lift

31.6"
10.5"
265/75R16
Moderate Rubbing w/ Lift

*_Note: These tire sizes come standard or optional from the factory._

## Tire Load Ranges

Every letter increase indicates two additional plys.

  * **P** \- Passenger tire with little sidewall protection. The stock Goodyears that come on the Liberty from the factory fall into this load range. These tires are definitely not recommended for off road as they are street tires with no sidewall protection.
  * **LT (C)** \- 6 ply Light Truck tire with a good balance of sidewall protection and flex. These tires are recommended for off roading the Liberty because they are both moderately well armored and fit the ground better.
  * **LT (D)** \- 8 ply Light Truck tire that's in between C and E. Many tires such as the Bridgestone Dueler A/T Revos don't have this load range as an option
  * **LT (E)** \- 10 ply Light Truck tire with maximum sidewall protection and minimum flex. These tires are very heavy and don't flex very much, as a result they will decrease your gas mileage and are less suited for off road use. The extra sidewall plys that cause the increase in stiffness also will increase the sidewall puncture resistance. Because of this higher resistance to puncture you may want to consider these tires if you spend a lot of time in rocky areas.

## Common Tire Choices

  * [BFGoodrich All-Terrain T/A KO](http://www.bfgoodrichtires.com/overview/all-terrain-t-a-ko/44.html)
  * [Goodyear Wrangler MT/R](http://www.goodyeartires.com/goodyeartireselector/display_tire.jsp?prodline=Wrangler+MT%2FR+%28P%29&mrktarea=Light%20Truck)
  * [Bridgestone Dueler A/T Revo](http://www.bridgestonetire.com/tireselector/GlamourIndex_BS_EN.aspx?ProductID=1055)
  * [Firestone Destination M/T](http://www.bridgestonetire.com/tireselector/GlamourIndex_BS_EN.aspx?ProductID=1058)
  * [General Grabber AT2](http://www.generaltire.com/tires/T5/Grabber-ATsup2-sup)
  * [Kumho Road Venture MT KL71](http://www.kumhousa.com/Tire.aspx?id=f8656bd8-0a87-4166-82b5-0df52d4ac17e&cat=25)

  
**Tire Reviews**

  * [On/Off-Road All-Terrain A/T Tire Comparison chart](http://www.tirerack.com/tires/surveyresults/surveydisplay.jsp?type=ORAT)
  * [Off-Road Maximum Traction M/T Tire Comparison Chart](http://www.tirerack.com/tires/surveyresults/surveydisplay.jsp?type=ORMT)

## External Links

  * [Jeep KJ Country - Tires / Wheels](http://www.jeepkj.com/forum/forumdisplay.php?f=200)
  * [L.O.S.T KJ - Tires, Tyres, Meats, Donuts](http://www.lostkjs.com/forum/phpBB2/viewforum.php?f=8)
  * [HOW TO: Display 5 bolts on your full size spare tire](http://www.jeepkj.com/forum/showthread.php?t=27073)
  * [How to Measure Wheel Backspace](http://www.rsracing.com/tech-wheel.html#backspace)
  * [Tire & Speedometer Calculator](http://www.tacomaworld.com/forum/tirecalc.php)
  * [DML Tire and Wheel Calculator](http://www.dakota-truck.net/TIRECALC/tirecalc.html)
  * [Speedometer Check Calculator](http://www.4lo.com/calc/gearspeedo.htm)
  * [Gear Ratio & Tire Size Chart](http://www.4lo.com/calc/geartable.htm)
  * [Gearing and Gearing Math for Jeeps](http://www.novak-adapt.com/knowledge/gearing.htm)
  * [Jeepin in Indiana forum for all Jeep related discussions](http://bbb.jeepininin.com)

## Performance

## Computers

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/76/Jeep_Liberty_Gas_PCM_2005.jpg/220px-Jeep_Liberty_Gas_PCM_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

2005 Jeep Liberty Gasoline NGC PCM w/ integrated TCM

Computer modifications are needed to realize to full potential of any performance upgrades. The Jeep Liberty computer can be reprogrammed with a different flash image, tricked with a different intake temperature sensor, or tricked with a performance chip. The B&G Jeep Liberty Flash (JTEC-NGC) permanently changes the timing and fuel tables, raises the rev limit and speed limit, and removes torque management. A different intake temperature sensor tricks the engine into adjusting the fuel mixture. Performance chips make various changes, but all suffer from short-lived gains.

The 3.7L gas and 2.8L diesel are very different engines with very different computer modifications. SP Diesel makes a chip for the diesel engine. The ECU on the 2.8L CRD is made by Bosch, and at this time there are two companies offering a re-flash for the CRD ECU, [Green Diesel Engineering](http://www.greendieselengineering.com) and [INMOTION TUNING](http://www.inmotionusa.com). Both vendors offer choices between ECO (economy) and Performance tuning programs.

## Mufflers and Headers

Many different companies manufacture cat-back [exhaust systems](//en.wikipedia.org/wiki/Exhaust_system) for the Jeep Liberty. Borla makes a split pipe dual exhaust system. The Borla single side and [Gibson Performance](/w/index.php?title=Gibson_Performance&action=edit&redlink=1) systems aren't preferable for off-roading because their larger [mufflers](//en.wikipedia.org/wiki/Muffler) hang more vulnerably below the lower control arm mounts. Rusty's Offroad offers a [Flowmaster](//en.wikipedia.org/wiki/Flowmaster_Mufflers) Delta Flow based system with a 2.5" clamped mandrel bent tail pipe.

A good off-road or muffler shop should be able to fabricate an off-road friendly exhaust system around a universal aftermarket muffler. Just remember, it's illegal to remove the [catalytic converter](//en.wikipedia.org/wiki/Catalytic_converter). The Flowmaster 40 and 50 SUV mufflers are common choices, the latter being more quiet and durable. Flowmaster has also released a strengthened diamond plate off-road muffler. Generally, MagnaFlow mufflers offer more performance but less aggressive sound than Flowmasters. MagnaFlows are built from stainless steel while Flowmasters are built from rust susceptible aluminized steel. Aeroturbine and Gibson also manufacturer exhaust options. A 2.5" center in/side out muffler works well with the stock 2.5" mandrel bent tubing. A short restriction in the tubing, immediately upstream of the stock muffler flange, can be removed to increase flow. A new muffler can be welded in its place or, if disassembly is required, a DynoMax flange adapter. Increasing tail pipe diameter will deepen tone and most mufflers will get louder as they break-in. Exposed tail pipe tips should be avoided in off-road applications.

Contrary to popular belief, increasing backpressure will not increase low-end torque. On the other hand, decreasing pipe diameter will increase low-end torque. Decreasing pipe diameter increases velocity and thus the [scavenging effect](//en.wikipedia.org/wiki/Scavenging). The scavenging effect is most pronounced at lower RPMs where it affects low-end torque, but is negligible when using forced induction. The goal is to eliminate as much backpressure as possible while still maintaing sufficient velocity.

JBA manufactures stainless steel short-tube [headers](//en.wikipedia.org/wiki/Manifold_\(automotive_engineering\)) for the Jeep Liberty. Ceramic coated stainless steel versions, colored silver or titanium, are also available. These headers only work with 2005-2007 Libertys because other years have a different catalytic converter connection. Short-tube headers don't create as much scavenging effect because they don't pulse as well as equal length long-tube headers. On the other hand, short-tube headers pass emmisions testing, keep the catalytic converters, and are easier to install. The JBA short-tube headers include the "Firecone," which JBA claims increases scavenging. Regardless, all good aftermarket headers remove restrictions and increase efficiency.

## Filters and Intakes

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/33/Jeep_Liberty_Gas_Intake_2005.jpg/220px-Jeep_Liberty_Gas_Intake_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

2005 Jeep Liberty Gasoline Air Intake

There are a number of different drop-in air filters and replacement intakes available for the Jeep Liberty. The most popular aftermarket filters are made by K&N, who makes both drop-ins and a FIPK replacement intake. AEM Induction Systems and aFe also make a replacement intakes and filters. Since the replacement intakes draw air from the engine compartment, their performance can be increased by installing a ram-air hood that forces cool air into the engine compartment. The CRD's turbo charger makes performance intakes and filters less advantageous for it than its gas counterpart. There is currently no FIPK available for the CRD. While most aftermarket filters allow greater airflow, they also allow more dust and dirt to enter the engine. For this reason performance filters like the K&N aren't recommended if the Liberty will be taken off road in dusty conditions. Another alternative is to install a snorkel, which by raising the air intake to roof height will keep dust out and allow for river crossings at the same time . At this time there are snorkels being manufactured for the Liberty.

## Superchargers

Kenne Bell discontinued its [supercharger](//en.wikipedia.org/wiki/Supercharger) for the Jeep Liberty's 3.7L engine. The relatively high piston rings in the 3.7L caused piston land weakness and failure, a problem correctable with forged pistons. A 4.7L supercharger can be installed onto the 3.7L, without issue, if a new tube and upgraded pistons are installed.

## Throttle Bodies

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/8a/ChryslerPowerTechV6_ThrottleBodies_Stock-Fastman.jpg/220px-ChryslerPowerTechV6_ThrottleBodies_Stock-Fastman.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Stock (left) vs The Fastman (right) Throttle Body

The Fastman ported [throttle body](//en.wikipedia.org/wiki/Throttle_body) allows better flow than the stock PowerTech throttle body. Simple throttle body spacers should be avoided as they provide absolutely no performance increase when installed on the Liberty.

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0a/ChryslerPowerTechV6_ThrottleBody_Stock.jpg/120px-ChryslerPowerTechV6_ThrottleBody_Stock.jpg)

Stock Throttle Body

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/7/70/ChryslerPowerTechV6_ThrottleBody_Fastman.jpg/120px-ChryslerPowerTechV6_ThrottleBody_Fastman.jpg)

The Fastman Throttle Body

## Transmissions and Torque Converters

The TransGo Shift Kit causes the Jeep Liberty's [automatic transmission](//en.wikipedia.org/wiki/Automatic_transmission) to shift more quickly. The same 45RFE PSK kit works with both 45RFE and 545RFE. The kit corrects the soft 1-2 and heavy throttle long 2-3 shifts and provides a firmer 4th and lockup.

The APS High Stall Torque Converter is an efficient [torque converter](//en.wikipedia.org/wiki/Torque_converter) that allows more power to be transferred from the engine to the transmission. It features additional stall, firmer lockup, increased torque multiplication, and 6% more efficiency than stock. It's only available for the 45RFE and not the more common 42RLE.

Suncoast Converters also has a 1200 RPM stall heavy-duty torque converter for the 2.8L CRD. This converter improves fuel economy and power delivery.

## See Also

  * [Engine tuning](//en.wikipedia.org/wiki/Engine_tuning)

## External Links

  * [Advanced Engine Management (AEM Electronics)](http://www.aempower.com/)
  * [AEM Induction Systems (AEM Air Intakes)](http://www.aemintakes.com/)
  * [advanced FLOW engineering (aFe)](http://www.afefilters.com/)
  * [APS Precision Mfg.](http://www.apsprecision.com/)
  * [B&G Chrysler Specialists](http://www.bgchrysler.com/index.html)
  * [Borla Performance Industries](http://www.borla.com/)
  * [The Fastman](http://www.thefastman.com/)
  * [Flowmaster](http://www.flowmastermufflers.com/)
  * [Green Diesel Engineering](http://www.greendieselengineering.com/)
  * [INMotion Tuning USA](http://www.inmotiontuning.com/)
  * [JBA Headers](http://www.jbaheaders.com/)
  * [K&N High Performance Filters](http://www.knfilters.com/)
  * [MagnaFlow Performance Exhaust](http://www.magnaflow.com/)
  * [Rusty's Offroad Products](http://www.rustysoffroad.com/)
  * [TransGo](http://www.transgoperformance.com/)
  * [Gibson Performance Exhaust](http://www.gibsonperformance.com/)
  * [Exhaust system backpressure](http://www.mustangforums.com/archive/threads/exhaust-system-backpressure-9765-1.html)
  * [The straight scoop on backpressure](http://www.dsmtuners.com/forums/showthread.php?t=168578)
  * [Backpressure and the Flowmaster exhaust system](http://www.flowmastermufflers.com/backpressure.html)

## Axles

### Dana 30a

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Jeep_Liberty_Front_Diff_D30a_2005.jpg/220px-Jeep_Liberty_Front_Diff_D30a_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

2005 Jeep Liberty Dana 30a Front Axle Housing and Differential Cover

The 27 spline Dana 30a, also know by Chrysler as the 186FIA, has always been the only front axle available in the Jeep Liberty. It's an IFS axle with an aluminum housing as indicated by the 'FI' and 'A'/'a' respectively. Essentially, it's an aluminum version of the Dana 30 with a longer pinion shaft. Unfortunately, the light weight aluminum construction makes it weaker than the D30 and the longer pinion shaft means pinion related D30 parts won't fit it. The D30a requires a 1-1/8" socket to remove and install the pinion nut.

CRD Libertys have a different front cradle that lowers and leftward shifts the differential to provide more clearance for the diesel engine. The lowering results in better half-shaft constant velocity joint angles but too little clearance for a differential collar. The leftward shift requires different length half-shafts than those used in the gas Liberty. Due to the shorter left side half shaft CRD models cannot be lifted as high before the CV joints begin to bind.

## Traction Aiding Devices

The axle housing's aluminum construction is weak and installing a locker in the front differential could cause it to crack. It is recommended that an LSD be installed in place of a locker. It should be noted that installing any traction aiding device in the front will make steering slightly stiffer and cause the steering wheel to spring back to center more quickly than usual.

## Gear Lube

The gear lube in the Dana 30a should be changed every 12,000 miles. Off-roading and towing subject the differential to increased torque, dirt, and water. If the Liberty isn't off-roaded, isn't used for towing, and follows the Schedule A maintenance plan, it may be possible to stretch this interval. The differential housing requires 2.6 pints (1.24 liters) of lube. Since the Dana 30a doesn't have a removable differential cover that could allow to clean it, 75W-140 synthetic lube should be used for either light duty applications or heavy duty off-roading.

## Gearing

Mopar is the only manufacturer of the longer pinion gears required by the Dana 30a. As a result, there are only three sources of 4.10 gears for the Liberty's front differential: wrecked I4 Libertys, online stores that sell discounted Mopar parts, and Jeep dealerships.

## External Links

  * [AMSOIL](http://www.amsoil.com/)
  * [Chrysler Parts Direct - Dana 30a Ring & Pinion Gears](http://www.chryslerpartsdirect.com/)
  * [World Parts Express - Cheap Dana 30a Ring & Pinion Gears](http://www.worldpartsexpress.com/)

### Chrysler 8.25"

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/12/Jeep_Liberty_Rear_Diff_8.25_2005.jpg/220px-Jeep_Liberty_Rear_Diff_8.25_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

2005 Jeep Liberty Chrysler 8.25" Rear Axle Housing and Differential Cover

The Chrysler 8.25", also known as the Corporate 8.25", is the 29 spline steel rear axle found in most Jeep Libertys. In 2003, the rear drum brakes were replaced with discs. Strength wise, the Chrysler 8.25" fits between the Dana 35 and Dana 44. The axle has two more splines than the Dana 35 and one less spline than the Dana 44. It also uses the larger 6508 bearings, while the Dana 35 uses smaller 5707 bearings. Unlike the Dana 44 and like the Dana 35 it has the weaker c-clips. The Chrysler 8.25" requires a Chrysler Bearing Preload Wrench, Miller# C-4164 or OTC# 6602, to set the carrier bearing preload. It also requires either a 1-1/8", 1-1/4", or 1-5/16" socket to remove and install the pinion nut.

## Axle Shafts

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Chrysler825_C-Clips.JPG/220px-Chrysler825_C-Clips.JPG)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Chrysler 8.25" C-Clips

The Chrysler 8.25" uses c-clips to hold the axle shafts into the differential side gears. Limited clearance between the axle shaft c-clip grooves and side gears can make c-clip installation and removal difficult. When c-clip installation is difficult, selecting thinner c-clips should allow easier future removal. ARB Air Lockers actually come with multiple c-clip thicknesses from which the installer can choose.

Removal of the c-clips is greatly eased by removing the spider gear pinion shaft. Rotate the carrier until the pinion shaft pin is exposed and remove the pin, pinion shaft, and small spider gears. The axle shafts can now be pushed in further to allow the c-clips to fall out with little effort. Re-install everything in the reverse order, being sure to retain the thrust washers on all four spider gears. Lock-Tite is used on the pinion shaft pin from factory and should also be used during re-assembly.

Yukon manufactures 30-7/8" 29-spline c-clip axle shafts, specifically designed for the Jeep Liberty's Chrysler 8.25" rear axle. Made of 1541H steel, they are 25% stronger than the OEM shafts.

Superior also manufactures 30-7/8" 29-spline c-clip axle shafts, for the Jeep Liberty's Chrysler 8.25" rear axle. They are made of 4340 chromoly steel and are 35% stronger than OEM shafts.

## Differential Covers

The Blue Torch Fabworks 8.25" Differential Cover is constructed of 1/4" plate steel with a 3/8" plate steel ring. It's built to resist peel up and features a protected fill plug.

Moe's Metalworks 8.25" Differential Cover

The PML 8.25" Differential Cover is constructed of aluminum, features both a threaded fill plug and a threaded drain plug, and holds 3/4 quart more oil than stock. The cover also comes with heatsinking fins, but they must be ground off if the cover's to be used in conjunction with a fuel tank skid plate.

The Ruff Stuff Specialties Chrysler 8.25" .375 One Piece Diff Cover is currently the only fabricated cover constructed of 3/8" plate steel with a 1/2" plate steel ring. It features a 1" fill plug with optional drain plug and/or countersunk holes. Many companies make 1/4" covers but Ruffstuff is the only company known for a 3/8" thick cover.

## Gear Lube

The gear lube in the Chrysler 8.25" should be changed every 12,000 miles. Off-roading and towing subject the differential to increased torque, dirt, and water. If the Liberty isn't off-roaded, isn't used for towing, and follows the Schedule A maintenance plan, it may be possible to stretch this interval. The differential housing requires 4.4 pints (2.08 liters) of lube and, if a limited slip is present, 4 ounces (118 milliliters) of limited slip additive. Aftermarket differential covers will change the required lube volume. 75W-90 dino lube should be used for light duty applications and 75W-140 synthetic for heavy duty off-roading and towing.

## Ring & Pinion Gears

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/Yukon_825_410_RingGear.jpg/220px-Yukon_825_410_RingGear.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Yukon Gear & Axle Chrysler 8.25" 4.10 Ring Gear

The following companies sell ring and pinion gear sets for the 8.25":

  * Genuine Gear - considered the worst among off-roaders
  * Motive Gear
  * Richmond
  * Sierra Gear & Axle - re-branded by West Coast Differential
  * Superior Axle & Gear
  * US Gear - considered the best among off-roaders
  * Yukon Gear & Axle - Best Warranty in the Industry

## External Links

  * [AllJeep.com - Yukon Gear & Axle](http://www.alljeep.com/oscommerce/advanced_search_result.php?keywords=8.25&search_in_description=1/)
  * [Blue Torch Fabworks](http://www.bluetorchfab.com/)
  * [Crane Hi Clearance](http://www.cranehiclearance.com/)
  * [Motive Gear](http://www.motivegear.com/)
  * [PML](http://www.yourcovers.com/)
  * [Randy's Ring & Pinion - Yukon Gear & Axle](http://www.ringpinion.com/)
  * [Richmond](http://www.richmondgear.com/)
  * [Ruffstuff Specialties](http://www.ruffstuffspecialties.com/)
  * [Rusty's Offroad - Superior Axle & Gear](http://www.rustysoffroad.com/)
  * [Sierra Gear & Axle](http://www.sierragear.com/)
  * [Superior Axle & Gear](http://www.superioraxle.com/)
  * [US Gear](http://www.usgear.com/)
  * [West Coast Differentials - Sierra Gear & Axle](http://www.differentials.com/)
  * [Yukon Gear & Axle](http://www.yukongear.com/)

### Dana 35C

The Dana 35C is a steel rear axle found in some 2002 Jeep Libertys. Strength wise, it's weaker than the more common Chrysler 8.25" rear axle. The Dana 35C is different from the Dana 35. The "C" in the model number refers to _custom_, not _complete_. It indicates that Dana Corporation ships their Dana 35 to DiamlerChrysler who then builds it.

### Gearing

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/06/Ring%26Pinion_Pattern_Drive.jpg/220px-Ring%26Pinion_Pattern_Drive.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Yukon 4.10 Chrysler 8.25" Ring & Pinion Drive Pattern

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Ring%26Pinion_Pattern_Coast.jpg/220px-Ring%26Pinion_Pattern_Coast.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Yukon 4.10 Chrysler 8.25" Ring & Pinion Coast Pattern

While larger tires give the Jeep Liberty more ground clearance they also regear it to a numerically lower gear. Therefore, it is often a good idea to eventually regear the differentials to a numerically higher gear in order to compensate for the increase in tire size. When chaning gear ratios, both the front and rear differentials need to be regeared simulatnaeously. Generally, as long as the front are rear ratios are within two tenths of each other there won't be any problems. To break in the new gears the Liberty should be run at low speeds for five hundred miles and then the differential lube should be changed. See each axle's specific page for more information on regearing it. To identify your rear axle and gear ratio check the ID tag on the driver's side axle tube near the brake rotor.

**Stock Gear Ratio Table**

2.4L (2002-2004) 3.7L (2002-2004) 3.7L (2005-2006) 2.8L (2005-2006)

Automatic
4.10
3.73
3.73
3.73

Manual
4.10
3.73
3.55
N/A*

*A manual transmission wasn't available in North American 2.8L diesel models

## External Links

  * [Gear Ratio & Tire Size Chart](http://www.4lo.com/calc/geartable.htm)
  * [Gearing and Gearing Math for Jeeps](http://www.novak-adapt.com/knowledge/gearing.htm)

### Limited Slips

Limited Slip is a traction aiding differential that will supply a percentage of torque to the tire with the most traction. It works by binding the two side gears of the differential against the carrier when a set speed difference is reached between the two gears. Essentially, if one wheel starts spinning faster than the other by a substantial amount the clutches will step in and prevent any further spin. Unfortunately, the clutches in limited slips aren't especially strong and are overcome if the slip becomes too great. For this reason, many people opt for a locker instead because it provides 100% lock up.

Posi is a slang term for the limited slip differential. Named after GM' "Posi-Traction" unit, which was built by Eaton.

## Front Dana 30a

  * [Detroit TrueTrac](/w/index.php?title=Jeep_Liberty/Print_version/Detroit_TrueTrac&action=edit&redlink=1)

## Rear Chrysler 8.25"

  * [Trac-Loc LSD](/w/index.php?title=Jeep_Liberty/Print_version/Trac-Loc_LSD&action=edit&redlink=1)
  * [Auburn High Performance](/w/index.php?title=Jeep_Liberty/Print_version/Auburn_High_Performance&action=edit&redlink=1)
  * [Detroit TrueTrac](/w/index.php?title=Jeep_Liberty/Print_version/Detroit_TrueTrac&action=edit&redlink=1)

## See also

  * [Limited Slip Differential](http://en.wikipedia.org/wiki/Limited_slip_differential)

## External Links

  * [Eaton (Detriot TrueTrac)](http://www.detroitlocker.com)
  * [Auburn](http://www.auburngear.com)
  * [Ring Pinion (Auburn and Dura Grip)](http://www.ringpinion.com/b2c/PartCats.aspx?SearchMode=Brand&BrandID=3)

### Lockers

A locker works by locking the two side gears of the differential to the carrier. In a manual selectable locker the two wheels are in 100% lock until the locker is disengaged. In an automatic locker the two wheels are always locked together until one needs to spin faster than the other, as is the case when cornering. Automatic lockers work in the reverse of limited slips in that they're normally locked and only unlock during turns, rather than being normally unlocked and only resisting wheel speed difference during slip. A locker is better than a limited slip because it will give the driver 100% lock and won't give out when a large amount of slip is encountered.

## Front Dana 30a

  * [ARB Air Locker](/w/index.php?title=Jeep_Liberty/Print_version/ARB_Air_Locker&action=edit&redlink=1)
  * [Aussie Locker](/w/index.php?title=Jeep_Liberty/Print_version/Aussie_Locker&action=edit&redlink=1)

## Rear Chrysler 8.25"

  * [ARB Air Locker](/w/index.php?title=Jeep_Liberty/Print_version/ARB_Air_Locker&action=edit&redlink=1)
  * [PowerTrax No-Slip](/w/index.php?title=Jeep_Liberty/Print_version/PowerTrax_No-Slip&action=edit&redlink=1)
  * [Detroit Locker](/w/index.php?title=Jeep_Liberty/Print_version/Detroit_Locker&action=edit&redlink=1)

## See also

  * [Locking Differential](http://en.wikipedia.org/wiki/Locking_differential)

## External Links

  * [ARB 4x4 Accessories](http://www.arb.com.au/)
  * [Eaton - Detriot Locker](http://www.eatonperformance.com/)
  * [Richmond Gear - Powertrax](http://www.richmondgear.com/)
  * [Torq Masters Technology - Aussie Locker](http://www.offroadlockers.com/)

# Armor

## Skid Plates

The skids should be installed in the following order: transfer case skid, transmission skid, engine skid. This rear to front ordering prevents the skid overlap from catching obstacles when driving forward.

### Engine

The Jeep Liberty's OEM engine skid plate is strong but scrapes up a lot of dirt when off roading. The Skid Row Front skid plate, constructed of 3/16" steel, is a good replacement. The Skid Row skid fits all 2002-present Libertys, including the CRD, and includes an engine oil filter drain hole.

### Gas Tank

The Jeep Liberty's OEM gas tank skid plate is strong, but sometimes bends, causing the gas tank to crack. The Skid Row Gas Tank skid plate, constructed of 3/16" steel, is a good replacement. The Skid Row skid is compatible with most hitch receivers and differential guards and includes a heat shield to protect the plastic gas tank from exhaust heat. The Skid Row skid fits all 2002-present Libertys. Rusty's Offroad also makes a gas tank skid for the Liberty.

### Transfer Case

The Jeep Liberty's transfer case has an aluminum body and needs protection. Fortunately, the OEM transfer case skid plate is plenty strong enough and probably won't need replacement. The Skid Row Front Skid Plate and Rusty's Off Road Transfer Case Skid, both constructed of 3/16" steel, are possible replacements. The Skid Row skid fits all 2002-present Liberty's, including those with the NV242 transfer case, and includes a transfer case oil drain hole.

### Transmission

The OEM transmission skid plate is the weakest of the Jeep Liberty's skids and should be replaced first. The All J Products Super Skid, constructed of 1/4" steel with formed sides, reinforcing ribs, and outriggers, is a very durable replacement. Currently, the Super Skid comes in two different models: the Super Skid I fits 2002-2003 gas Libertys and all CRD Libertys, while the Super Skid II fits 2004-2006 Libertys. The Skid Row Engine & Transmission Skid Plate and Rusty's Offroad Engine Tranny Skid, both constructed of 3/16" steel, are also good replacements. The Skid Row skid fits all 2002-present Libertys, including the CRD, and includes an engine oil drain hole.

## Rock Rails

### All J Products Boulder Bars

### Carolina Rock Shop Rock Rails

Carolina Rock Shop makes rock rails for the Jeep Liberty. The CRS rock rails bolt to the unibody in three separate places, but do not bolt to the pinchweld. For added strength and lower maintenance the rails can be welded rather than bolted directly to the unibody. There is some concern as to whether these rails could be easily torn off as they don't have pinchweld bolts, but there is no evidence to confirm this.

### Mopar Rock Rails

### Rock Lizard Skink Sliders

Rock Lizard Fabrications produces the Standard Skink Slider and two different variations of it. The Standard Skink Slider is the base rock rail without any extra features. The Skink Step Slider extends three inches further from the body, thus allowing it to function as a step. The Skink Super Slider has an added tube to protect the doors from trees and rocks. The tube extends from the base rail to just past the plastic door trim. All the Sliders bolt to the Liberty with two dual-arm three-bolt unibody mounts and one large seven-bolt pinch weld mount. The arms extend from unibody mounts in a triangular fashion to reinforce the entire rail. The rails are shipped bare and should be painted with a rust preventer before installation. Powder coat is not recommended because it's more expensive and will only chip off when the rails come into contact with obstacles off road.

### Rocky Road Outfitters Rock Rails

### Rusty's Offroad - Rocker Panel Skids

## Bumpers

### ARB Bull Bar

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ec/ARB_Bullbar_JeepLiberty_2005.JPG/220px-ARB_Bullbar_JeepLiberty_2005.JPG)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

ARB 2005-2007 Jeep Liberty Bullbar

ARB manufactures the most popular bull bar for the Jeep Liberty. It features air bag approval, ventilation, recessed lamp and Hi-Lift provisions, tow points, and a grey powdercoat. Inside, it supports a winch and factory foglights. Outside, it supports lights, antennas, and off-road flags via four pre-drilled holes. While the bull bar weighs less than 100 lbs, spacers or stiffer springs should be used in the front struts to counteract spring sag. There are two versions, one for 2002-2004 Libertys and one for 2005-2007 Libertys. The 2002-2004 model uses the factory turn signals, requires fender flare trimming, and supports the Warn HS9500, XD9000, M8000, and M6000 winches. The 2005-2007 model uses new turn signals, doesn't require fender flare trimming, and supports the Warn XD9000, M8000, M6000, and 9.5XP winches.

### Rock Lizard Monitor Lizard Front Bumper

### Rock Lizard Komodo Dragon Rear Bumper

## Differential Guards

  * Poison Spyder - Rock Ring
  * Four X Doctor - Diff Guard
  * Rusty's Offroad - Diff Guard
  * Rocky Road Outfitters - Diff Guard

## External Links

  * [All J Products](http://www.boulderbars.com/)
  * [ARB 4x4 Accessories](http://www.arbusa.com/)
  * [Carolina Rock Shop](http://www.carolinarockshop.com/)
  * [Four X Doctor](http://www.fourxdoctor.com/)
  * [JParts.com](http://www.jparts.com/)
  * [Mopar](http://www.mopar.com/)
  * [Poison Spyder](http://www.spydercustoms.com/)
  * [Rock Lizard Fabrications](http://www.rocklizardfabrications.com/)
  * [Rocky Road Outfitters](http://www.rocky-road.com/)
  * [Rusty's Off-road Products](http://www.rustysoffroad.com/)
  * [Skid Row Offroad](http://www.skidplates.com/)

# Recovery

There is a factory recovery option available for the Jeep Liberty that includes three Mopar tow hooks; two front and one rear. A cheaper and more versatile option is a front or rear [hitch receiver](/wiki/Jeep_Liberty/Accessories/Towing_Hitches) accompanied by a hitch clevis or winch. Yet another option is to replace the front tow hooks with a bumper or bullbar with integrated recovery provisions. All of these alternatives require removal of an existing hooks.

## Mopar Hooks

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/18/Jeep_Liberty_Tow_Hook_Front_2005.jpg/220px-Jeep_Liberty_Tow_Hook_Front_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

OEM Front Tow Hook MY2005

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/af/Jeep_Liberty_Tow_Hook_Rear_2005.jpg/220px-Jeep_Liberty_Tow_Hook_Rear_2005.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

OEM Rear Tow Hook MY2005

Each front tow hook sandwiches the unibody bumper between the hook base and an m-bolt/clip-nut combination. The clip-nut on both the front and rear hooks is a common automotive fastener which may be available at well stocked hardware stores. The m-bolt used with the front tow hooks is not a common fastener and will need to be purchased from a dealer.

## Electric Winches

The ARB bullbar for the Liberty KJ is designed accommodate the Warn M8000 winch.

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/JeepLiberty_Winch_SelfRecovery.JPG/220px-JeepLiberty_Winch_SelfRecovery.JPG)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Liberty (KJ) recovering itself with a Warn M8000 winch

# Electrical

  * [Auxiliary Lights](/w/index.php?title=Jeep_Liberty/Print_version/Auxiliary_Lights&action=edit&redlink=1)
  * [Batteries](/w/index.php?title=Jeep_Liberty/Print_version/Batteries&action=edit&redlink=1)
  * [CB Radio](/w/index.php?title=Jeep_Liberty/Print_version/CB_Radio&action=edit&redlink=1)
  * [ESP](/w/index.php?title=Jeep_Liberty/Print_version/ESP&action=edit&redlink=1)
  * [Head Units](/w/index.php?title=Jeep_Liberty/Print_version/Head_Units&action=edit&redlink=1)
  * [Firewall Penetration](/w/index.php?title=Jeep_Liberty/Print_version/Firewall_Penetration&action=edit&redlink=1)
  * [Overhead Consoles](/w/index.php?title=Jeep_Liberty/Print_version/Overhead_Consoles&action=edit&redlink=1)
  * [PCI Bus](/w/index.php?title=Jeep_Liberty/Print_version/PCI_Bus&action=edit&redlink=1)
  * [Satellite Radios](/w/index.php?title=Jeep_Liberty/Print_version/Satellite_Radios&action=edit&redlink=1)

## External Links

  * [L.O.S.T KJ - Electronics...Stereo...GPS...CBs](http://www.lostkjs.com/forum/phpBB2/viewforum.php?f=45)
  * [Jeep KJ Country - Electronics](http://www.jeepkj.com/forum/forumdisplay.php?f=201)
  * [Basic Car Audio Electronics](http://www.bcae1.com/)

# Accessories

### Towing and Cargo

  * [Rack Systems](/w/index.php?title=Jeep_Liberty/Print_version/Rack_Systems&action=edit&redlink=1)
  * [Towing Hitches](/w/index.php?title=Jeep_Liberty/Print_version/Towing_Hitches&action=edit&redlink=1)

### Suspension

  * [Control Arms](/w/index.php?title=Jeep_Liberty/Print_version/Control_Arms&action=edit&redlink=1)
  * [Sway Bar Disconnects](/w/index.php?title=Jeep_Liberty/Print_version/Sway_Bar_Disconnects&action=edit&redlink=1)
  * [Ball Joints](/w/index.php?title=Jeep_Liberty/Print_version/Ball_Joints&action=edit&redlink=1)
  * [Tie Rods](/w/index.php?title=Jeep_Liberty/Print_version/Tie_Rods&action=edit&redlink=1)

### Other

  * [Onboard Air](/w/index.php?title=Jeep_Liberty/Print_version/Onboard_Air&action=edit&redlink=1)

  


## External Links

# Abbreviations & Terms

**0-9**

  * 2WD = Two Wheel Drive
  * 4WD = Four Wheel Drive

**A**

  * ABS = Anti-Lock Braking System
  * A/T = Auto Transmission
  * A/T = All-Terrain
  * ATF = Automatic Transmission Fluid
  * AWD = All Wheel Drive

**B**

  * BCM = Body Control Module
  * BFG = BF Goodrich
  * BHP = Brake Horsepower
  * BJ = Ball Joint
  * BJC = Ball Joint Contact
  * BS = Backspacing

**C**

  * CA = Control Arm
  * CEL = Check Engine Light
  * CG = Center of Gravity
  * CID = Cubic Inch Displacement
  * COG = Center of Gravity
  * CPS = Crankshaft Positioning Censor
  * CRD = Common Rail Diesel
  * CV = Constant Velocity

**D**

  * DC (DCX) = Daimler-Chrysler Corporation
  * DFI = Direct Fuel Injection
  * DOHC = Double Overhead Cam

**E**

  * ECM = Engine Control Module
  * EFI = Electronic Fuel Injection
  * EGR = Exhaust Gas Recirculation
  * ESP = Electronic Stability Program
  * EJS = Easter Jeep Safari
  * EVIC = Electronic Vehicle Information Center

**F**

  * FWD = Front Wheel Drive
  * FT. LBS. = Foot Pound
  * FIPK = Fuel Injection Performance Kit (K&N's Air Intake)
  * FSM = Factory Service Manual

**G**

  * GVW = Gross Vehicle Weight
  * GVWR = Gross Vehicle Weight Rating

**H**

  * HP = Horsepower

**I**

  * IAC = Idle Air Control
  * IAT = Intake Air Temperature
  * IFS = Independent Front Suspension

**J**

  * JK = Jeep Wrangler (2007+)
  * JBA = Jeepin' By Al

**K**

  * KJ = Jeep Liberty (2002-2007)
  * KK = Jeep Liberty (2008+)
  * KS = Knock Sensor
  * KPL = Kilometers per Liter
  * KPH = Kilometers per Hour

**L**

  * LWB = Long Wheel Base (SJ, XJ, ZJ, WJ, KJ)
  * LCA = Lower Control Arm
  * LBJ = Lower Ball Joint
  * LSD = Limited Slip Differential
  * LBS-FT = Pounds Foot of Torque

**M**

  * MAP = Manifold Absolute Pressure
  * MAT = Manifold Air Temperature
  * MFI = Multi-Port Fuel Injection
  * MIL = Malfunction Indicator Light
  * M/T = Manual Transmission or Mud-Terrain
  * MPFI = Multi Point Fuel Injection
  * MPG = Miles Per Gallon
  * MPH = Miles Per Hour
  * MPI = Multi Port Injection
  * MPV = Multi-Purpose Vehicle

**N**

  * NP = New Process
  * NV = New Venture
  * NVG = New Venture Gear

**O**

  * O2S (OS) = Oxygen Sensor
  * OC = Open Circuit
  * OEM = Original Equipment Manufacturer
  * OME = Old Man Emu
  * OBA = On Board Air
  * OBD = On Board Diagnostic

**P**

  * P/N (PN) = Part Number
  * PCM = Powertrain Control Module
  * PCV = Positive Crankcase Ventilation
  * PSI = Pounds per Square Inch

**Q**

**R**

  * RE = Rubicon Express
  * RPM = Revolution Per Minute
  * RWD = Rear Wheel Drive
  * RWHP = Rear Wheel Horsepower

**S**

  * SFI = Sequential Fuel Injection
  * SFA = Solid Front Axle
  * SRA = Solid Rear Axle
  * SAS = Solid Axle Swap
  * SOHC = Single Overhead Cam
  * SRS = Supplemental Restraint System
  * SWB = Short Wheel Base (CJ, YJ, TJ, JK)
  * SS = Speed Sensor

**T**

  * TB = Throttle Body
  * TBI = Throttle Body Injection
  * TC = Tire Carrier or Transfer Case
  * TD = Turbo Diesel
  * TDC = Top Dead Center
  * TDI = Turbo Direct Injection
  * TPS = Throttle Position Sensor
  * TPMS = Tire Pressure Monitoring System
  * TSB = Technical Service Bulletin

**U**

  * UCA = Upper Control Arm
  * UBJ = Upper Ball Joint
  * UBJC = Upper Ball Joint Contact

**V**

  * VIN = Vehicle Identification Number

**W**

  * WOT = Wide Open Throttle

**X**

**Y**

**Z**

# Resources

This page contains a collection of links that the authors of this WikiBook have found to be useful for further information about the Jeep Liberty. Much of our own knowledge came from these sources, therefore we'd like to acknowledge them here and pass on their usefulness to the reader.

## Information

  * [L.O.S.T. KJ](http://www.lostkjs.com/forum/phpBB2/index.php)
  * [Jeep KJ Country](http://www.jeepkj.com/forum/index.php)

## Parts

  * [AutoTruckToys.com - Jeep Liberty Accessories and Jeep Liberty Parts](http://www.autotrucktoys.com/liberty/)
  * [Drivewire.com - Jeep Liberty Parts Catalog](http://www.drivewire.com/jeepparts/jeeplibertyparts.html)
  * [Junk Yard Dog - Used Auto Parts Junkyard Search](http://www.junkyarddog.com/cgi-bin/requester/requester.cgi)
  * [Just For Jeeps - Mopar Jeep Accessories and Jeep Parts](http://www.justforjeeps.com/)
  * [Mopar - Original Equipment Parts and Accessories](http://mopar.com/)
  * [NewMoparParts.com - New Original Equipment Parts](http://www.newmoparparts.com/mopar-parts.htm)
  * [PartsTrain.com - Hard to Find Auto Parts and Truck Parts](http://www.partstrain.com/)
  * [CarId.com - Automotive Aftermarket Accessories](http://www.carid.com/)
  * [Savage Jeep Parts - Original Equipment Parts](http://jparts.com/)
  * [Troy's KJ Links and Parts](http://www.youngs.org/kjparts/default.asp)
  * [World Parts Express - New OEM Parts](http://www.worldpartsexpress.com)
  * [Car Parts and Accessories - Info to buy and find the cheapest components](http://carpartsinfobuy.com/)
  * [Thread on L.O.S.T. listing even more places to buy parts](http://www.lostkjs.com/forum/phpBB2/viewtopic.php?t=6020)

# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Jeep_Liberty/Print_version&oldid=1362739](http://en.wikibooks.org/w/index.php?title=Jeep_Liberty/Print_version&oldid=1362739)" 

[Category](/wiki/Special:Categories): 

  * [Jeep Liberty](/wiki/Category:Jeep_Liberty)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Jeep+Liberty%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Jeep+Liberty%2FPrint+version)

### Namespaces

  * [Book](/wiki/Jeep_Liberty/Print_version)
  * [Discussion](/wiki/Talk:Jeep_Liberty/Print_version)

### 

### Variants

### Views

  * [Read](/wiki/Jeep_Liberty/Print_version)
  * [Edit](/w/index.php?title=Jeep_Liberty/Print_version&action=edit)
  * [View history](/w/index.php?title=Jeep_Liberty/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Jeep_Liberty/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Jeep_Liberty/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Jeep_Liberty/Print_version&oldid=1362739)
  * [Page information](/w/index.php?title=Jeep_Liberty/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Jeep_Liberty%2FPrint_version&id=1362739)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Jeep+Liberty%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Jeep+Liberty%2FPrint+version&oldid=1362739&writer=rl)
  * [Printable version](/w/index.php?title=Jeep_Liberty/Print_version&printable=yes)

  * This page was last modified on 19 December 2008, at 06:14.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Jeep_Liberty/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
