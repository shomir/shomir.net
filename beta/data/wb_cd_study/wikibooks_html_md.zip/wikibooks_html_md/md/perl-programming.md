# Perl Programming/Print version

From Wikibooks, open books for an open world

< [Perl Programming](/wiki/Perl_Programming)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Perl_Programming/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Perl_Programming/Print_version) on _1 December 2012_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Perl_Programming/Print_version&oldid=2451693&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

## Section 1: [Beginning Perl](/wiki/Perl_Programming/TOC)[[edit](/w/index.php?title=Perl_Programming/Print_version&action=edit&section=1)]

## Getting Started[[edit](/w/index.php?title=Perl_Programming/Getting_Started&action=edit&section=T-1)]

This book assumes that you know absolutely nothing about programming at all and that Perl is your first language. However, basic operations such as making text files are outside of the realm of this tutorial.

### Obtaining Perl[[edit](/w/index.php?title=Perl_Programming/Getting_Started&action=edit&section=T-2)]

To find out if you already have Perl installed on your computer, go into the command line and type:
    
    
    perl -v
    

This will display which version of Perl you have installed on your computer, if it is installed.

There are at least two easy ways to install Perl on Windows: the [ActiveState](http://activestate.com/Products/ActivePerl/?_x=1) distribution, and the [Strawberry Perl](http://strawberryperl.com) distribution. Both are downloadable as native Windows installers. ActivePerl has a prebuilt package repository and is supported by a corporation, while Strawberry Perl includes a compiler (gcc) so that perl modules can be installed "on the fly" and is community-supported.

Most Unix-like operating systems will include Perl by default, and Linux Standard Base mandates that all compliant Linuxes ship with Perl installed. However, if for some reason you don't have perl, you can explore the options available to you at the [main Perl download page](http://www.perl.com/download.csp), which will provide links to source and binaries.

### Writing programs[[edit](/w/index.php?title=Perl_Programming/Getting_Started&action=edit&section=T-3)]

#### A Sample Program[[edit](/w/index.php?title=Perl_Programming/Getting_Started&action=edit&section=T-4)]

Perl is an _interpreted_ language, which means you will always need the Perl interpreter which will _compile_ and _execute_ your program each time you run it. Instead of compiling your program into bytecode like in [Pascal](/wiki/Pascal) or [C++](/wiki/C%2B%2B) and then executing it, you can simply copy your program's source code to a different computer (that has the perl interpreter) and run it.

For our first example, run your favorite text editor, and type something like this:
    
    
    #!/usr/bin/perl
    use strict;
    use warnings;
     
    print "Hello World";
    

If you don't understand this yet, don't worry; This will be explained in more depth later.

Save the file as **myprog.pl** and you have a perl program ready to run.

### Running programs[[edit](/w/index.php?title=Perl_Programming/Getting_Started&action=edit&section=T-5)]

#### Windows[[edit](/w/index.php?title=Perl_Programming/Getting_Started&action=edit&section=T-6)]

To run a perl program with a modern version of [ActivePerl](http://www.activestate.com/Products/Download/Download.plex?id=ActivePerl) installed, you simply click on it. If the screen flashes and you can't see the output you might have to execute the file from within the windows shell (ie. cmd.exe or PowerShell). With [Strawberry Perl](http://strawberryperl.com/), you'll have to execute a perl program from the command line as shown below.

From a windows command-line interface, you can run the program thusly:
    
    
    C:\> perl path\to\foo\myprog.pl
    

or, if perl.exe is not in your path:
    
    
    C:\> c:\perl\bin\perl.exe myprog.pl
    

_Note: You may have to specify the full path to your program unless you are running the command prompt in that directory._

#### UNIX-like Systems[[edit](/w/index.php?title=Perl_Programming/Getting_Started&action=edit&section=T-7)]

You can run a perl program by running perl itself, and telling the shell the name of the file:
    
    
    perl myprog.pl
    

Usually, perl programs are made executable on their own. This involves two changes to the sample program. First, edit it and put the following [shebang line](//en.wikipedia.org/wiki/Shebang_\(Unix\)) at the top of the file:
    
    
    #!/usr/bin/perl
    

Then, at a command prompt, make your program executable by using chmod.
    
    
    chmod +x myprog.pl
    

Your program is now executable and ready to run, just like any other file. To execute, type:
    
    
    ./myprog.pl
    

By convention, .pl identifies a perl script, and .pm a perl library. The .pl file extension isn't needed for either of these examples; it's just a useful way of identifying files. The only time the convention _should_ be violated is if the program is to be installed outside of the current working directory, and there runs a chance you might want to some day rewrite them in a different language.

  


  


## A First Taste of Perl[[edit](/w/index.php?title=Perl_Programming/First_Programs&action=edit&section=T-1)]

Here's a simple program written in Perl to get us started:
    
    
    #!/usr/bin/perl
     
    # Outputs Hello world to the screen.
     
    print "Hello world!\n";
    

Let's take a look at this program line by line:

  * `#!/usr/bin/perl`

    On Unix systems this tells the Operating System to execute this file with the program located at `/usr/bin/perl`. This is the default Unix location for the perl interpreter, on Windows `#!C:\Perl\bin\perl.exe` or `#!C:\strawberry\perl\bin\perl.exe` (depending on whether ActivePerl or Strawberry Perl was installed) should be used instead.

**Shebang:** A line at the start of a file, beginning with #!, that gives instructions to the operating system.

  * `# Outputs ...`

    This line is a comment - it is ignored by the perl interpreter, but is very useful. It helps you to debug and maintain your code, and explain it to other programmers.

**Comment:** A line of plain text ignored by the interpreter in a file of code.

  * `print "Hello world!\n";`

    The **print** instruction writes whatever follows it to the screen. The `\n` at the end of the _string_ puts a new line to the screen. The semicolon at the end of the line tells the perl interpreter that the instruction is finished; you must put a semicolon at the end of **every** instruction in Perl code.

**String:** A sequence of characters used as data by a program.

### Exercises[[edit](/w/index.php?title=Perl_Programming/First_Programs&action=edit&section=T-2)]

  * Change the program so it says hello to _you_.
  * Change the program so that after greeting you, it asks how you are doing, _on the next line_. The output should look like this:
    
    
    Hello _your_name_!
    How are you?
    

  * Experiment with the `\n` character, what happens when you take it away? What happens if you put two in a row?

**Remember:** if you add another `print` instruction you will need to put a semicolon after it.

  


  


## Strings[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-1)]

Any sequence of characters put together as one unit, is a string. So, the word `the` is a string. This sentence is a string. Even this entire paragraph is a string. In fact, you could consider the text of this entire book as one string.

Strings can be of any length and can contain any characters, numbers, punctuation, special characters (like _!_ _#_, and _%_), and even characters in natural languages besides English. In addition, a string can contain special whitespace formatting characters like newline, tab, and the _bell_ character. We will discuss special characters more later on. For now, we will begin our consideration of strings by considering how to insert literal strings into a Perl program.

To begin our discussion of strings in Perl, we will consider how to work with _string literals_ in Perl. The word **literal** here refers to the fact that these are used when you want to type a string directly to Perl. This can be contrasted with storing a string in a **variable**.

Any string literal can be used as an expression. We will find this useful when we want to store string literals in variables. However, for now, we will simply consider the different types of string literals that one can make in Perl. Later, we will learn how to assign these string literals to variables in the [Scalar Variables section](/wiki/Perl_Programming/Scalar_Variables).

## Single Quoted Strings[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-2)]

String literals can be represented in primarily three ways in Perl. We have already used one type in the simple programming examples, using double quote marks. Using double or single quote marks in Perl each has a special meaning.

Single quotes can be thought of as literal strings. In the previous examples, you may have noticed that variable names were included inside the strings with double quotes. When the results were printed, the value of the variable was placed in the printed line, not the name of the variable. If single quote marks were used, the actual variable name would have been printed because nearly all special characters that might be interpreted differently are taken at _face value_ when using single quotes.

To see what is meant by this, try this simple program:
    
    
     my $name = "Fred";
     print "Hello $name\n";
     print 'Hello $name\n';
    

You should see "Hello Fred" on the first line and "Hello $name\n" on the second (without a newline after it). Putting the _value_ of `$name` into the string in the first print statement is called "interpolation." If you don't need interpolation, you should use single quotes, because it makes your intent clearer.

### Special Characters in Single-quoted Strings[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-3)]

There are two characters in single quoted strings that do not always represent themselves. This is due to necessity, since single-quoted strings start and end with the `'` character. We need a way to express inside a single-quoted string that we want the string to contain a `'` character.

The solution to this problem is to preceded any `'` characters we actually want to appear in the string itself with the backslash (`\` character). Thus we have strings like this:
    
    
      'xxx\'xxx';  # xxx, a single-quote character, and then xxx
    

We have in this example a string with 7 characters exactly. Namely, this is the string: `xxx'xxx`. It can be difficult at first to become accustomed to the idea that two characters in the input to Perl actually produce only one character in the string itself. (C programmers are already probably used to this idea.) However, just keep in mind the rules and you will probably get used to them quickly.

Since we have used the `\` character to do something special with the `'` character, we must now worry about the special cases for the backslash character itself. When we see a `\` character in a single-quoted string, we must carefully consider what will happen.

Under most circumstances, when a `\` is in a single-quoted string, it is simply a backslash, representing itself, as most other characters do. However, the following exceptions apply:

  * The sequence `\'` yields the character `'` in the actual string. (This is the exception we already discussed above).
  * The sequence `\\\` yields the character `\` in the actual string. In other words, two backslashes right next to each other actually yield only one backslash.
  * A backslash, by itself, cannot be placed at the end of a the single-quoted string. This cannot happen because Perl will think that you are using the `\` to escape the closing `'`.

The following examples exemplify the various exceptions, and use them properly:
    
    
      'I don\'t think so.';          # Note the ' inside is escaped with \
      'Need a \\ (backslash) or \?'; # The \\ gives us \, as does \
      'You can do this: \\';         # A single backslash at the end 
      'Three \\\'s: "\\\\\"';        # There are three \ chars between ""
    

In the last example, note that the resulting string is `Three \'s: "\\\\\"`. If you can follow that example, you have definitely mastered how single-quoted strings work!

Instead of unreadable backslash escapes, Perl offers [other ways](http://perldoc.perl.org/perlop.html#Quote-and-Quote-like-Operators) of quoting strings. The first example above could be written as:
    
    
      q{I don't think so};            # No \ needed to escape the '
    

### Newlines in Single-quoted Strings[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-4)]

Note that there is no rule against having a single-quoted string span several lines. When you do this, the string has _newline_ characters embedded in it.

A newline character is a special ASCII character that indicates that a new line should be started. In a text editor, or when printing output to the screen, this usually indicates that the cursor should move from the end of the current line to the first position on the line following it.

Since Perl permits the placement of these newline characters directly into single quoted strings, we are permitted to do the following:
    
    
      'Time to
      start anew.';   # Represents the single string composed of:
                      # 'Time to' followed by a newline, followed by
                      # 'start anew.'
    

This string has a total of twenty characters. The first seven are `Time to`. The next character following that is a newline. Then, the eleven characters, `start anew.` follow. Note again that this is **one string**, with a newline as its eighth character.

Further, note that we are not permitted to put a comment in the middle of the string, even though we are usually allowed to place a `#` anywhere on the line and have the rest of the line be a comment. We cannot do this here, since we have yet to terminate our single-quoted string with a `'`, and thus, any `#` character and comment following it would actually become part of the single-quoted string! Remember that single-quotes strings are delimited by `'` at the beginning, and `'` at the end, and everything in between is considered part of the string, included newlines, `#` characters and anything else.

### Examples of Invalid Single-quoted Strings[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-5)]

In finishing our discussion of singled-quoted strings, consider these examples of strings that are **not** legal because they violate the exceptions we talked about above:
    
    
      'You cannot do this: \'; # INVALID: the ending \ cannot be alone
      'It is 5 o'clock!'       # INVALID: the ' in o'clock should be escaped
      'Three \\\'s: \\\\\';      # INVALID: the final \ escapes the ', thus
                               #          the literal is  not terminated
      'This is my string;      # INVALID: missing close quote
    

Sometimes, when you have invalid string literals such as in the example above, the error message that Perl gives is not particularly intuitive. However, when you see error messages such as:
    
    
     (Might be a runaway multi-line _ string starting on line X)_
     Bareword found where operator expected
     Bareword "foo" not allowed while "strict subs" in use
    

It is often an indication that you have runaway or invalid strings. Keep an eye out for these problems. Chances are, you will forget and violate one of the rules for single-quoted strings eventually, and then need to determine why you are unable to run your Perl program.

## Brief Digression from Strings Alone: The `print` Function[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-6)]

Before we move on to our consideration of double-quoted strings, it is necessary to first consider a small digression. We know how to represent strings in Perl, but, as you may have noticed, the examples we have given thus far do not do anything interesting. If you try placing the statements that we listed as examples in Single Quoted Strings, into a full Perl program, like this:
    
    
     #!/usr/bin/perl
     
     use strict;
     use warnings;
     
     'Three \\\'s: "\\\\\"'; # There are three \ chars between ""
     'xxx\'xxx';             # xxx, a single-quote character, and then xxx
     'Time to
     start anew.';
    

you probably noticed that nothing of interest happens. Perl gladly runs this program, but it produces no output.

Thus, to begin to work with strings in Perl beyond simple hypothetical considerations, we need a way to have Perl display our strings for us. The canonical way of accomplishing this in Perl is to use the `print` function.

The `print` function in Perl can be used in a variety of ways. The simplest form is to use the statement `print STRING;`, where `STRING` is any valid Perl string.

So, to reconsider our examples, instead of simply listing the strings, we could instead print each one out:
    
    
     #!/usr/bin/perl
     
     use strict;
     use warnings;
     
     print 'Three \\\'s: "\\\\\"'; # Print first string
     print 'xxx\'xxx';             # Print the second  
     print 'Time to
     start anew.
     ';    # Print last string, with a newline at the end
    

This program will produce output. When run, the output goes to what is called the _standard output_. This is usually the terminal, console or window in which you run the Perl program. In the case of the program above, the output to the standard output is as follows:
    
    
     Three \'s: "\\\"xxx'xxxTime to
     start anew.
    

Note that a newline is required to break up the lines. Thus, you need to put a newline at the end of every valid string if you want your string to be the last thing on that line in the output.

Note that it is particularly important to put a newline on the end of the last string of your output. If you do not, often times, the command prompt for the command interpreter that you are using may run together with your last line of output, and this can be very disorienting. So, **always** remember to place a newline at the end of each line, particularly on your last line of output.

Finally, you may have noticed that formatting your code with newlines in the middle of single-quoted strings hurts readability. Since you are inside a single-quoted string, you cannot change the format of the continued lines within the print statement, nor put comments at the ends of those lines because that would insert data into your single-quoted strings. To handle newlines more elegantly, you should use double-quoted strings, which are the topic of the next section.

## Double Quoted Strings[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-7)]

Double-quoted strings are another way of representing scalar string literals in Perl. Like single-quoted strings, you place a group of ASCII characters between two delimiters (in this case, our delimiter is `"`). However, something called _interpolation_ happens when you use a double-quoted string.

### Interpolation in Double-quoted Strings[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-8)]

Interpolation is a special process whereby certain special strings written in ASCII are replaced by something different. In Single-quoted strings section, we noted that certain sequences in single-quoted strings (namely, `\\\` and `\'`) were treated differently - these are called _backslash escape sequences_. This is very similar to what happens with interpolation.

For example, in interpolated double-quoted strings, various sequences preceded by a `\` character act differently according to the chart below:

String
Interpolated As

`\\\`
an actual, single backslash character

`\$`
a single $ character

`\@`
a single @ character

`\"`
a single double-quote character

`\t`
tab

`\n`
newline

`\r`
hard return

`\f`
form feed

`\b`
backspace

`\a`
alarm (bell)

`\e`
escape

`\056`
character represented by octal value, 056 (same as`.`)

`\x2E`
character represented by hexadecimal value, 2E (same as `.`)

As you may have noticed in the previous chapter, you can put the name of a variable within a string with its leading dollar sign. This form of interpolation replaces the name of the variable in the string with the content of the variable.

### Examples of Interpolation[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-9)]

Let us consider an example that uses a few of these characters:
    
    
     #!/usr/bin/perl
     
     use strict;
     use warnings;
     
     print "A backslash: \\\n";
     print "Tab follows:\tover here\n";
     print "Ring! \a\n";
     print "Please pay someone\@example.org \$20.\n";
    

This program, when run, produces the following output on the screen:
    
    
     A backslash: \
     Tab follows:   over here
     Ring!
     Please pay someone@example.org $20.
    

  
In addition, when running, you should hear the computer beep. That is the output of the `\a` character, which you cannot see on the screen. However, you should be able to hear it.

Notice that the `\n` character ends a line. `\n` should always be used to end a line. Those students familiar with the C language will be used to using this sequence to mean _newline_. When writing Perl, the word _newline_ and the `\n` character are roughly synonymous.

### String Operators[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-10)]

_Operators_ manipulate two or more strings in some way.

#### The Concatenation Operator[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-11)]

Perl uses the `.` operator to concatenate or connect two strings together, like this:
    
    
    "Hello" . "World"  # This is the same as "HelloWorld"
    

If you want to make the string have a space between Hello and World you could write it like this:
    
    
    "Hello" . " " . "World"  # This is the same as "Hello World"
    

Or like this:
    
    
    "Hello" . " World" # This is the same as "Hello World"
    

#### The `x` Operator[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-12)]

This is called the _string repetition_ operator and is used to repeat a string. All you have to do is put a string on the left side of the `x` and a number on the right side. Like this:
    
    
    "Hello" x 5 # This is the same as "HelloHelloHelloHelloHello"
    

If you wish to insert a line break after each output of the string, use:
    
    
    "Hello\n" x 5
    

### Exercises[[edit](/w/index.php?title=Perl_Programming/Strings&action=edit&section=T-13)]

  * Write a program that uses the `.` operator to print "Hello Sir!".
  * Write another program which uses the `x` operator to print "HelloHelloHelloHello". Put comments in this program that explain how it works
  * Remember to take some time to play with single and double quoted strings, the more practice you get, the better you will be.

  


## Numbers[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-1)]

Numbers in Perl do not have to be enclosed in any kind of punctuation; they can be written as straight numbers.

### Floating Point Numbers[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-2)]

Here are some acceptable floating point numbers:

0.1, -3.14, 2.71828...

### Integers[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-3)]

_Integers_ are all whole numbers and their negatives (and 0): {... -3, -2, -1, 0, 1, 2, 3 ...}.  
  
Here are a few examples of integers:
    
    
    12, -50, 20, 185, -6654, 6654
    

The following examples are **not** integers:
    
    
    15.5, -3.458, 3/2, 0.5
    

### Non-decimal Numbers[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-4)]

I'll dwell on this topic for a little longer than the other types of numbers. In Perl you can specify not only decimal numbers, but also numbers in hex, octal, and binary. If you are not familiar with how these systems work, you can try these Wikipedia articles:

  * [Hexadecimal](//en.wikipedia.org/wiki/Hexadecimal)
  * [Octal](//en.wikipedia.org/wiki/Octal)
  * [Binary](//en.wikipedia.org/wiki/Binary_numeral_system)

  
In Perl you have to specify when you are going to write a non-decimal number. Binary numbers start with an 0b, so here are some possible binary numbers:
    
    
    0b101011101
    
    0b10
    

Octal numbers start with 0 ("zero"), so here are some possible octal numbers:
    
    
    015462
    
    062657
    
    012
    

Hexadecimal numbers start with 0x, so here are some possible hexadecimal numbers:
    
    
    0xF17A
    
    0xFFFF
    

### Number Operators[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-5)]

Just like strings, numbers have operators. These operators are quite obvious so I'll just give a quick example of each one.

#### The +, - , /, and * Operators[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-6)]

These operators are pretty obvious, but here are some examples:
    
    
    100 + 1 # That's 101
    100 - 1 # That's 99
    100 / 2 # That's 50
    100 * 2 # That's 200
    

Perl also has the familiar increment, decrement, plus-equals, and minus-equals operators from C:
    
    
    $a++    # evaluate, then increment
    ++$a    # increment, then evaluate
    $a--    # evaluate, then decrement
    --$a    # decrement, then evaluate
    $a += 5 # plus-equals operator, adds 5 to $a. Equivalent to $a = $a + 5
    $a -= 2 # minus-equals operator, subtracts 2 from $a. Equivalent to $a = $a-2
    

Now let's look at one more operator that's a little less obvious.

#### The `**` Operator[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-7)]

The `**` operator is simply the exponentation operator. Here's another example:
    
    
    2**4  # That's 16, same as 24
    4**3**2 # that's 4**(3**2), or 49, or 262144
    

**Extra!**  
The modulus operator (`%`) can be used to find the remainder when dividing two numbers.  
If that doesn't make sense now, that's fine, it's not that important. 

(Note, this returns 0 when used on floating point numbers)

### Exercises[[edit](/w/index.php?title=Perl_Programming/Numbers&action=edit&section=T-8)]

  * Remember the `x` operator? Use a mathematical expression as the number of times to repeat the string, see what happens.
  * Write a program like our original hello world program except make it print a mathematical expression.

  


In Perl, there are five types of variables: $calars, @rrays, %hashes, &subroutines, and *typeglobs.

## Simple variables[[edit](/w/index.php?title=Perl_Programming/Variables&action=edit&section=T-1)]

Variables, called scalars, are identified with the $ character, and can contain nearly any type of data. For example:
    
    
    $my_variable = 3;                              # integers
    $my_variable = 3.1415926;                      # floating point
    $my_variable = 3.402823669209384634633e+38;    # exponents
    $my_variable = $another_variable + 1;          # mathematical operation
    $my_variable = 'Can contain text';             # strings
    $my_variable = \$another_variable;             # scalar reference
    $my_variable = \@array_variable;               # array reference
     
    print $my_variable;
    

### Case sensitivity[[edit](/w/index.php?title=Perl_Programming/Variables&action=edit&section=T-2)]

Note that the perl interpreter is [case sensitive](/w/index.php?title=Perl_Programming/Print_version/case_sensitivity&action=edit&redlink=1). This means that identifier names containing lowercase letters will be treated as being different and separate from those containing uppercase letters.

## Arrays[[edit](/w/index.php?title=Perl_Programming/Variables&action=edit&section=T-3)]

Arrays in Perl use the @ character to identify themselves.
    
    
    @my_array = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10);     # numeric list
    @my_array = (1 .. 10);                           # same as above
    @my_array = ('John', 'Paul', 'Kanai', 'Mahenge'); # strings
    @my_array = qw/John Paul Kanai Mahenge/;          # the same - one-word strings, with less typing
    @my_array = qw/red blue 1 green 5/;              # mixed types
    @my_array = (\@Array1, \@Array2, \@Array3);      # array of arrays
     
    foreach my $Item (@my_array) {
        print "Next item is $Item \n";
    }
    

However, when you deal with just one element of the array (using square brackets so it's not confused), then that element of the array is considered a scalar which takes the $ sigil:
    
    
    $my_array[0] = 1;
    

As in the C programming language, the number of the first element is 0 (although as with all things in Perl, it's possible to change this if you want). Array subscripts can also use variables:
    
    
    $my_array[$MyNumber] = 1;
    

## Associative arrays[[edit](/w/index.php?title=Perl_Programming/Variables&action=edit&section=T-4)]

Associative arrays, or "hashes," use the % character to identify themselves.
    
    
    %my_hash = ('key1' => 'value1', 'key2' => 'value2');
    

When using the `=>` the left side is assumed to be quoted. For long lists, lining up keys and values aids readability.
    
    
    %my_hash = (
        key1    => 'value1',
        key2    => 'value2',
        key3    => 'value3',
    );
    

However, when you deal with just one element of the array (using braces), then that element of the array is considered a scalar and takes the $ identifier:
    
    
    $my_hash{'key1'} = 'value1';
    

Associative arrays are useful when you want to refer to the items by their names.

## Subroutines[[edit](/w/index.php?title=Perl_Programming/Variables&action=edit&section=T-5)]

Subroutines are defined by the `sub` function, and used to be called using `&` (using `&` is now deprecated). Here's an example program that calculates the Fibonnaci sequence:
    
    
    sub fib {
        my $n = shift;
        return $n if $n < 2;
        return fib( $n - 1 ) + fib( $n - 2 );
    }
     
    print fib(14);
    

  


The `if` statement is the primary conditional structure in Perl. The syntax is as follows:
    
    
    if (''boolean expression'') {
        ''statement'';
    }
    

If the _boolean expression_ evaluates to true, the statements between the two braces will be executed. The braces around statements are mandatory, even if there is only one statement (unlike C or Java).

An alternative syntax to the `if` statement may be used on a single statement. This involves putting the conditional at the end of the statement rather than before, and does not include braces:
    
    
    ''statement'' if (''boolean expression'') ;
    

The following statements are synonymous:
    
    
    if ( $x == 20 ) { print "hello"; }
    print "hello" if ( $x == 20 );
    

You should choose whichever one is clearer in a given situation. For example, the following is legal, but unclear:
    
    
    foreach my $word (@words) {
        if ($word eq 'end') { last; }
        print "$word\n";
    }
    

This _hides_ the `last` (which is like `break`, and ends the loop) over at the right. Instead use a postfix `if`:
    
    
    foreach my $word (@words) {
        last if $word eq 'end';
        print "$word\n";
    }
    

The _boolean expression_ conditional can contain any one of the comparison operators covered in the next section.

Multiple conditions can be checked together using the boolean expression operators:

  * `&&` \- logical and, C style; used for most conditionals
  * `and` \- logical and, but with a lower precedence; used for flow control
  * `||` \- logical or, C style; used for most conditionals
  * `or` \- logical or, but with a lower precedence; used for flow control
  * `!` \- logical not, C style
  * `not` \- logical not, but with a lower precedence
    
    
    if ( ($x == 20) || ( ($x > 0)&&($x < 10)&& !($x == 5) ) ){
        print "x is equal to 20 or either between 0 and 10 but not 5.\n";
    }
    

Conditional statements can also be extended with the `elsif` and `else` structures:
    
    
     if (''boolean expression 1'') {
         ''statement 1;''
     }
     elsif (''boolean expression 2'') {
         ''statement 2;''
     }
     else {
         ''statement 3;''
     }
    

Note that an `if` statement is followed by any number (including zero) of `elsif` statements, and finally an optional `else` statement. The statements of an `elsif` will be executed if its boolean expression is true, and no preceding `(els)if` statement's boolean expression is true. The trailing `else` (if present) is executed if none of the preceding statements' boolean expressions are true.

  


# Introduction[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-1)]

Perl's set of operators borrows extensively from the [C programming language](/wiki/C_programming_language). Perl expands on this by infusing new operators for string functions (`.=`, `x`, `eq`, `ne`, etc.). C by contrast delegates its subset of Perl functionality to a library _strings.h_, and _ctype.h_, and includes no such functionality by default compilation. Perl also includes a highly flexible [Regex](/wiki/Perl_Programming/Regular_Expressions) engine inspired by Sed with improvements to standard POSIX regexes, most notably the support of Unicode.

# The operators[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-2)]

## Arithmetic[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-3)]

Most arithmetic operators are _binary_ operators; this means they take two arguments. _Unary_ operators only take one argument. Arithmetic operators are very simple and often transparent.

### Binary[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-4)]

All the basic arithmetic operators are present: addition (`+`), subtraction (`-`), multiplication (`*`), and division (`/`).

The modulus operator is `%`. Modulus returns the remainder of a division (`/`) operation.
    
    
    # 3 goes into 4, 1 time  with 1 left over.
    print 4 % 3;   # prints 1
     
    # 2 goes into 4, 2 times with 0 left over.
    print 4 % 2;   # prints 0
     
    # 3 goes into -4, -2 times with 2 left over.
    print -4 % 3;   # prints 2
    

The exponentiation operator is `**`. It allows you to raise one value to the power of another. If you raise to a fraction you will get the root of the number. In this example the second result when raised to the power of 2 should return 2 (`( 2 ** (1/2) ) ** 2 = 2` ).
    
    
    # Four squared:
    print 4 ** 2; # prints 16
     
    # Square root of 2
    print 2 ** (1/2); # prints 1.4142135623731
    

The function `sqrt` is provided for finding a Square Root. Other fractional powers (i.e., (1/5), (2/13), (7/5), and similar) are suitably found using the `**` operator.

### Unary[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-5)]

The auto-decrement (`\--`), and auto-increment (`++`) operators are unary operators. They alter the scalar variable they operate on by one logical unit. On numbers, they add or subtract one. On letters and strings, only the auto-increment shift one up in the alphabet, with the added ability to roll-over. Operators that come in post- and pre- varieties can be used two ways. The first way returns the value of the variable _before_ it was altered, and the second way returns the value of the variable _after_ it was altered.
    
    
    my $foo = 1;
     
    # post decrement (printed and then decremented to 0)
    print $foo--; # prints 1
    print $foo;   # prints 0
    
    
    
    my $foo = 1;
     
    # pre-decrement (decremented to 0 then printed)
    print --$foo;  # prints 0
    print $foo;    # prints 0
    
    
    
    my $foo = 'd';
     
    # pre-increment (incremented to e then printed)
    print ++$foo;  # prints e
    print $foo;    # prints e
    
    
    
    my $foo = 'Z';
     
    # post-increment (printed the incremented to AA)
    print $foo++;  # prints Z
    print $foo;    # prints AA
    

## Assignment[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-6)]

The basic assignment operator is "=" which sets the value on the left side to be equal to the value on the right side. It also returns the value. Thus you can do things like $a = 5 + ($b = 6), which will set $b to a value of 6 and $a to a value of 11 (5 + 6). Why you would want to do this is another question.

The assignment update operators from C, "+=", "-=", etc. work in perl. Perl expands on this basic idea to encompass most of the binary operators in perl.

operator name

+=
add assign, plus-equals

-=
subtract assign, minus-equals

*=
multiply assign

/=
divide assign

 %=
modulo assign

**=
exponent assign

.=
concatenate assign

x=
repeat assign

&&=
logical AND assign

||=
logical OR assign

&=
bitwise AND assign

|=
bitwise OR assign

^=
bitwise XOR assign

~=
bitwise NOT assign

<<=
left shift assign

>>=
right shift assign
    
    
    my $foo = 'Hello';
    $foo .= ', world'; 
    print $foo; # prints 'Hello, world';              
     
    my $bar = '+';
    $bar x= 6;
    print $bar; # prints '++++++';
    

## Comparison[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-7)]

Perl uses different operators to compare numbers and strings. This is done because in most cases, Perl will happily _stringify_ numbers and _numify_ strings. In most cases this helps, and is consistent with Perl's _DWIM Do-What-I-Mean_ theme. Unfortunately, one place this often does not help, is comparison.

name numeric string

equal
==
eq

not equal
 !=
ne

less than
<
lt

greater than
>
gt

less or equal
<=
le

greater or equal
>=
ge

compare
<=>
cmp

## Logical[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-8)]

Perl has two sets of logical operators, just like the comparison operators, however not for the same reason.

The first set (sometimes referred to as the C-style logical operators because they are borrowed from C) is `&&`, `||`, and `!`. They mean logical AND, OR, and NOT respectively. The second set is `and`, `or`, and `not`.

The only difference between these two sets is the precedence they take (See Precedence). The symbolic operators take a much higher precedence than the textual.

### Conditionals[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-9)]

Most of the time, you will be using logical operators in conditionals.
    
    
     # Only prints "I like cookies\n" if both $a is 5 and $b is 2
     if($a == 5 && $b == 2){        
         print "I like cookies\n";
     }
    

In this case, you could safely substitute `and` for `&&` and the conditional would still work as expected, however, this is not always the case.
    
    
     #True if $a is 5, and either $b, $c, or both are 2
     if($a == 5 and $b == 2 || $c == 2){
         print "I like cookies\n";
     }
     #Using brackets, the order is made more clear.
     #This conditional acts in the same way as the last. 
     if($a == 5 and ($b == 2 || $c == 3)){
         print "I like cookies\n";
     }
    

This, however, is completely different.
    
    
     if($a == 5 && $b == 2 or $c == 3){
         print "I like cookies\n";
     }
     #Equivalent and easier to understand with brackets
     if(($a == 5 && $b == 2) or $c == 3){
         print "I like cookies\n";
     }
    

Most people prefer to use C-style logical operators and use brackets to enforce clarity rather than using a combination of textual and C-style operators (when possible), which can be very confusing at times.

### Partial evaluation[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-10)]

Partial evaluation (or "short circuiting") is the property of logical operators that the second expression is only evaluated if it needs to be.
    
    
     ($a, $b) = (5, 2);
     #$b < 3 is not evaluated at all because when the interpreter
     #finds that $a == 4 is false, there is no need to evaluate $b < 3
     #because the conditional is automatically false
     if($a == 4 && $b < 3){
         print "I like cookies\n";
     }
    

This also works with logical OR statements. If the first expression evaluates as true, then the second is never evaluated because the conditional is automatically true.

This becomes useful in a case like this:
    
    
     sub foo {
     #returns a true or false value
     }
     foo() or print "foo() failed\n";
    

Here, if the foo() subroutine returns false, then "foo() failed\n" is printed. However, if it returns true, then "foo() failed\n" is not printed, because the second expression (`print "foo() failed\n"`) does not need to be evaluated.

## Bitwise[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-11)]

These operators perform the same operation as the logical operators, but instead of being performed on the true/false value of the entire expressions, it is done on the individual respective bits of their values.

  * "&" (bitwise AND)
  * "|" (bitwise OR)
  * "^" (bitwise XOR)
  * "~" (bitwise NOT)

The left and right shift operators move the bits of the left operand (e.g. $a in the case of $a << $b) left or right a number of times equal to the right operand ($b). Each move to the right or left effectively halves or doubles the number, except where bits are shifted off the left or right sides. For example, $number << 3 returns $number multiplied by 8 (2**3).

  * "<<" (left shift)
  * ">>" (right shift)

## String[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-12)]

The string concatenation operator is `.`, not `+` which some other languages use.
    
    
    print 'Hello' . ' world'; # prints "Hello world" without a newline at the end
    

There is a repeat operator for strings (x) which repeats a string a given number of times.
    
    
    my $str = "hi";
    my $repeated_str = $str x 5;
    print "$repeated_str\n"; # prints "hihihihihi" with a newline at the end
    

## Comparing strings[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-13)]

To compare strings, use `eq` and `ne` instead of `==` or `!=` respectively. You can also look for a substring with `substr()`, or pattern-match with regular expressions.

## File Test[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-14)]

    See [Perl Programming/Function Reference#-X](/wiki/Perl_Programming/Function_Reference#-X)

## Other[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-15)]

The range operator (..) returns a list of items in the range between two items; the items can be characters or numbers. The type of character is determined by the _first_ operand; the code:
    
    
    print ('A'..'Z');
    print ('a'..'z');
    print ('A'..'z');
    print (1..'a');
    print (1..20);
    print ('&'..'!');
    print (10..-10);
    print "$_\n" foreach (1..10);
    

Outputs (Newlines added for readability):
    
    
    ABCDEFGHIJKLMNOPQRSTUVWXYZ
    abcdefghijklmnopqrstuvwxyz
    ABCDEFGHIJKLMNOPQRSTUVWXYZ
    
    1234567891011121314151617181920
    &
    
    1
    2
    3
    4
    5
    6
    7
    8
    9
    10
    

Note that the case is defined by the first operand, and that the `1..'a'` and `(10..-10)` operations don't return anything.

## Precedence[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-16)]

Precedence is a concept that will be familiar to anyone who has studied algebra or coded in C/C++. Each operator has its place in a hierarchy of operators, and are executed in order. The precedence of perl operators is strict and should be overridden with parentheses, both when you are knowingly going against precedence and when you aren't sure of the order of precedence. For a complete listing of the order, check [perlop](http://www.perl.com/doc/manual/html/pod/perlop.html#SYNOPSIS).

## The smart match operator (`~~`)[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-17)]

The **smart match operator** is new in perl 5.10. To use it, you'll need to explicitly say that you're writing code for perl 5.10 or newer:
    
    
    #!/usr/bin/perl
    use strict;
    use warnings;
    use 5.10.0; # We will be using the smart match operator
     
    my $scalar = 'hi';
    my @array = qw(one two three);
    my %hash = (
        hi  => 1,
        ho  => 2,
        he  => 3,
    );
     
    if ($scalar ~~ @array) { print "1\n"; } # Doesn't print; 'hi' isn't an element in @array
    if ($scalar ~~ %hash)  { print "2\n"; } # Does print; 'hi' is a key in %hash
    if (@array ~~ %hash)   { print "3\n"; } # Doesn't print; none of the elements of @array match a key in %hash
    

The smart match operator is versatile and _fast_ (often faster than the equivalent comparison without `~~`). See [smart matching in detail](http://perldoc.perl.org/perlsyn.html#Smart-matching-in-detail) for the comparisons it can do. `~~` is also used in the `given/when` switch statement new in 5.10, which will be covered elsewhere.

## Dereferencing[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-18)]

### The doubledollar[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-19)]

A variable, previously referenced with the reference operator can be dereferenced by using a doubledollar symbol prefix:
    
    
    $number = 12;
    $refnum = \$number; # backslash is the reference operator
    $$refnum = 13; # $$ is used as a dereference to the original variable
    $($refnum) = 11; # This is an alternative syntax using brackets
    print $number; # the original variable has changed
    

### The arrow operator[[edit](/w/index.php?title=Perl_Programming/Operators&action=edit&section=T-20)]

If the left hand operand of the arrow operator is an array or hash reference, or a subroutine that produces one, the arrow operator produces a look up of the element or hash:
    
    
    $result = $hashreference -> {$key}; # look up a hash key from a reference variable
    @arrayslice = $arrayreference -> [3 .. 5]; # obtain a slice from an array reference
    

  


  
Perl has four fundamental [data types](//en.wikipedia.org/wiki/data_type): scalars, lists, hashes, and typeglobs.

scalar 
    is a funny way of saying a single value; it may be a number, a string, or a [reference](//en.wikipedia.org/wiki/Reference_\(computer_science\)).

list 
    is an ordered collection of scalars. A variable that holds a list is called an _array_. Items in a list or array can be accessed by their position in the list; programs can retrieve the first, second, third, etc. item in a list.

hash 
    is like an array, in that a hash holds many values, but the values are identified by a unique "key", rather than an ordinal index position.

typeglob 
    is a variable representing an entry within the internal symbol table. It is used to manipulate file handles, and to create references or aliases.

All variables are marked by a leading [sigil](//en.wikipedia.org/wiki/Sigil_\(computer_programming\)), which identifies the data type. The same name may be used for variables of different types, without conflict.
    
    
      $foo   # a scalar
      @foo   # a list
      %foo   # a hash
      *foo   # a typeglob
    

  


## Scalar Variables[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-1)]

### Introduction to Scalar Variables[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-2)]

Now that you understand how to use strings and numbers in Perl, you need to start learning how to use variables. The best way to learn about scalar variables - Perl talk for a single variable, as against a group or list of values - is to look at an example.
    
    
     #!/usr/bin/perl
     
     use warnings;
     
     $my_scalar_variable = "Hello, Sir!\n";
     print $my_scalar_variable;
    

Now let's break this program down:

  * The first two lines you already know, `#!/usr/bin/perl` and `use warnings;`
  * The third line is more interesting, it contains a scalar variable. There are a few important things to point out: 
    1. In case you haven't figured this out, the scalar variable in this line is `$my_scalar_variable`
    2. Notice the `$` before the name _my_scalar_variable_, in order to define a scalar variable, this sign must appear before the name.
  * Now let's look at the last line. This is just the familiar print function being told to print the value of `$my_scalar_variable`.

**Try it!**  
Type in the program mentioned above and run it.

### Assigning and Using Scalar Variables[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-3)]

In the course of writing a program, you will most likely use a variable. What is a variable? A variable is something that stores data. A _scalar_ variable holds a single value.

#### Naming Conventions[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-4)]

  * All scalar variables names must start with a `$` symbol. You can remember this by thinking `$`calar.
  * Variable names can be comprised of alphanumeric characters and underscores.
  * Numeric characters are allowed in names of variables, but not as the first character after the `$`.

#### Using Scalar Variables[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-5)]

##### Scalar Variables and Strings[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-6)]

You may recall that earlier in the book, I said that whether you use `"` or `'` in strings makes a big difference in the interaction of strings and variables. Well now I am going to explain what I meant.

Now that you know what a variable is, what if you wanted to put a variable in a string? Here's the difference:

  * With a double quoted string, this program:
    
    
     #/usr/bin/perl
     
     use warnings;
     
     $variable = 4;
     print "I saw $variable lions!";
    

Would return "I saw 4 lions!"

  * With a single quoted string, this program:
    
    
     #/usr/bin/perl
     
     use warnings;
     
     $variable = 4;
     print 'I saw $variable lions!';
    

Would return "I saw $variable lions!"

**Try it!**  
Type in the programs mentioned above and run them.

This effect is because of what I said before, [single quoted strings](/wiki/Perl_Programming/Strings#Single_Quoted_Strings) are interpreted literally.

### Comparison Operators[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-7)]

    _Main article: [Perl Programming/Operators](/wiki/Perl_Programming/Operators)_

There are operators that are used for comparing numbers and strings. This can be very useful when you get to more advanced programming. Both numbers and strings have their own set of operators which test for a condition such as equal or not equal and return either true or false.

#### Numeric Comparison Operators[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-8)]

Here is the list of numeric comparison operators:

  * `==` \- Equal to
  * `!=` \- Not equal to
  * `<` \- Less than
  * `>` \- Greater than
  * `<=` \- Less than or equal to
  * `>=` \- Greater than or equal to
  * `<=>` \- Numeric Comparison

#### String Comparison Operators[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-9)]

Here is the list of string comparison operators:

  * `**eq**` \- Equal to
  * `**ne**` \- Not equal to
  * `**lt**` \- Less than
  * `**gt**` \- Greater than
  * `**le**` \- Less than or equal to
  * `**ge**` \- Greater than or equal to
  * `**cmp**` \- String Comparison

**Note**  
_The two 'Comparison' operators_ `<=>` _and_ `**cmp**` _are slightly different from the rest. Rather than returning only true or false, these operators return 1 if the left argument is greater than the right argument, 0 if they are equal, and -1 if the right argument is greater than the left argument._

### Exercises[[edit](/w/index.php?title=Perl_Programming/Scalar_Variables&action=edit&section=T-10)]

  * Try writing a program like the Hello World program except elaborate it by storing `"Hello, world!\n"` in a variable and then printing the variable.
  * Play around with all the things we have learned so far. Try to create a program that has an example of everything we have learned so far.

  


Perl syntax includes both lists and arrays.

## Lists[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-1)]

A _list_ in perl is an ordered set of scalar values. It is represented in your code as a comma-separated sequence of values, which may or may not be contained in scalar variables. Lists can be used to make multiple assignments at once, and can be passed as arguments to several built-in and user-defined functions:
    
    
    #!/usr/bin/perl
    use strict;
    use warnings;
     
    my ($length, $width, $depth) = (10, 20, 15);
     
    print "The values are: ", $length, $width, $depth;
    

**Note**  
_Parentheses are_ not _required in the construction of a list. They are used only for precedence._

### Alternate List Construction[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-2)]

When creating a list of several strings that do not include spaces, Perl provides a shortcut to get around typing multiple quotes and commas. Instead of
    
    
    ($name1, $name2, $name3, $name4) = ('Paul', 'Michael', 'Jessica', 'Megan');
    

you can use the `qw//` operator. This operator uses any non-alpha-numeric character as a delimiter (typically the / character), and encloses a space-separated sequence of barewords. A delimeter separates the command with the arguments. The above line is identical to the following:
    
    
    ($name1, $name2, $name3, $name4) = qw/Paul Michael Jessica Megan/;
    

and both are equal to this:
    
    
    ($name1, $name2, $name3, $name4) = qw(Paul Michael Jessica Megan);
    

The last example uses the open and close parenthesis as a different delimeter. If there is an open and close version of the delimiter you choose, you need to use them both. Otherwise just repeat the same symbol twice. For example, you cannot type `qw<Paul Michael<` you have to type `qw<Paul Michael>`.

You can also abuse the glob syntax, when the strings do not include shell metacharacters:
    
    
    ($name1, $name2, $name3, $name4) = <Paul Michael Jessica Megan>;
    

**Note**  
_The resulting strings from the `qw//` operator are_ single-quoted_, meaning no interpolation happens in the set. If you need to include a variable in your list, you cannot use this method._

### List Assignments[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-3)]

As shown above, lists can be used to make several assignments at once. If the number of variables on the left is the same as the number of values on the right, all variables are assigned to their corresponding values, as expected.

If there are fewer variables on the left than values on the right, the 'extra' values are simply ignored:
    
    
    #!/usr/bin/perl
     
    ($length, $width) = (10, $w, 15);  #$length gets 10, $width gets the value of $w.  15 is ignored
    

If there are more variables on the left than values on the right, the 'extra' variables are assigned the default `undef` value:
    
    
    #!/usr/bin/perl
     
    ($length, $width, $depth) = (10, $w); #$length gets 10, $width gets the value of $w.  $depth is undef
    

The existence of list assignment creates the ability to 'swap' two variables' values without the need of an intermediary temporary variable:
    
    
    #!/usr/bin/perl
     
    $foo = 10;
     
    $bar = 5;
     
    ($foo, $bar) = ($bar, $foo);  #$foo now equals 5, while $bar equals 10;
    

## Arrays[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-4)]

An array in Perl is a variable which contains a list. An array can be modified, have elements added and removed, emptied, or reassigned to an entirely different list. Just as all scalar variables start with the `$` character, all array variables start with the `@` character.

**Note**  
_It is a common and frequent mistake in Perl to use the terms 'list' and 'array' interchangeably. They do not have the same meaning.  
A decent analogy is that a list (such as `qw/foo bar baz/`) is to an array (such as `@values`) as a string (such as `'Paul'`) is to a scalar variable (such as `$name`)._

### Array Assignment[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-5)]

Arrays are assigned lists of values. The list of values can be arbitrarily large or small (it can even contain 0 elements).
    
    
     #!/usr/bin/perl
     
     @nums = (1,2,3,4,5);
     
     @more = 6..1000; #using the 'range' operator
     
     @none = ();  # empty array.
     
     @names = qw/Paul Michael Jessica Megan/;
     
     @all = (@nums, @more);  #@all contains all integers from 1 to 1000
    

That last example exemplifes a feature of Perl known as 'array flattening'. When an array is used in a list, it is the array's **elements** that populate the list, not the array itself. As stated above, a list is a set of **scalar** values only. Therefore, the `@all` array contains 1000 elements, not 2.

**Note**  
_Although this implies you cannot create an 'array of arrays', or 'two-dimensional arrays', such things do exist in Perl. They are simulated by using [references](/wiki/Perl_Programming/References_and_Data_Structures)._

### Arrays in Scalar context[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-6)]

When an array is used in scalar context - either by assigning a scalar variable to the array's value, or using it in an operation or function that expects a scalar - the array returns its size. That is, it returns the number of elements it currently contains
    
    
     #!/usr/bin/perl
     
     @names = ('Paul','Michael','Jessica','Megan');
     
     $how_many = @names;
     
     print "I have a total of $how_many names\n";
    

**Note**  
_A common misconception is that a **list** in scalar context will also return its size. This is untrue. In fact, there is no such thing as a list in scalar context: using the comma operator in a scalar context does not create a list, instead it evaluates each of its arguments, left to right, and returns the last one:_  
  

    
    
    $name = ('Paul','Michael','Jessica','Megan');
     print "The last name in my list is $name\n";
    

### Printing an Array[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-7)]

There are two general ways of printing the values of an array. You can either print the list of items in the array directly, or you can interpolate the array in a double-quoted string.
    
    
     @names = qw/Paul Michael Jessica Megan/;
     print "My names are: ", @names, ".\n";
     print "My names are: @names.\n";
    

In the first example, the `print` function is being given a list of 6 arguments: the string 'My names are: ', each of the four values in `@names`, and the string ".\n". Each argument is printed separated by the value of the `$,` variable (which defaults to the empty string), resulting in the values from the array being 'squished' together:
    
    
    My names are: PaulMichaelJessicaMegan.
    

In the second example, the `print` function is being given exactly one argument: a string that contains an interpolated array. When Perl interpolates an array, the result is a string consisting of all values in the array separated by the value of the `$"` variable (which defaults to a single space):
    
    
    My names are: Paul Michael Jessica Megan.
    

**Note**  
_Both the `$,` and `$"` variables can be changed to any string you like. For example, to separate the array's items with a comma and a space instead of just a space:_
    
    
    $" = ', ';
     print "My names are: @names.\n";
    
    
    
    My names are: Paul, Michael, Jessica, Megan.
    

_You generally do not want to do that as this may cause problems in other parts of your program depending on the default values of those variables though! A safer way to print your arrays with custom separator will be explained later._

### Accessing Elements of an Array[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-8)]

The elements of an array are accessed using a numerical reference within square brackets. Because each item within an array is a scalar value, you need to use $ when referencing a value. The first element of an array is number 0 and all the others count up from there.

A negative number will count down from the right side of the array. This means that -1 references the last element of the array and -3 references the third to last element. Let's see some examples:
    
    
     @array = (1, 2, 3, 4, 5);
     print $array[0];   # Prints 1
     print $array[3];   # Prints 4
     print $array[-1];  # Prints 5
    

What if you need to know the last index? `$#array` will return it for you:
    
    
     @array = (1, 2, 3, 4, 5);
     print $array[4];         # Prints 5
     print $array[-1];        # Same as above
     print $array[ $#array ]; # Also prints 5
    

A common mistake is to do this:  

    
    
     print @array[0];  # Also prints 1, but for the wrong reasons
    

In fact `@array[0]` is a _slice_ (that is, a sub-array of an array) that contains one element, whereas `$array[0]` is a scalar which contains the value 1.

### Common Array Functions[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-9)]

## Command line arguments[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-10)]

As you may wonder, Perl scripts support command line arguments. The entire list of parameters is stored in the array @ARGV, with the first entry containing the first command line argument. If no command line parameters were passed, @ARGV is an empty array.

The array functions and operators listed above can easily be used to detect the passed command line arguments and to detect the number of arguments provided.

## Related Articles[[edit](/w/index.php?title=Perl_Programming/Array_Variables&action=edit&section=T-11)]

  * [Data Structures/Arrays](/wiki/Data_Structures/Arrays)
  * [List Functions](/wiki/Perl_Programming/Function_Reference#List_functions)
  * [Array Functions](/wiki/Perl_Programming/Function_Reference#Array_functions)
  * [Perl Arrays](http://www.programmingbulls.com/perl-array)

  


A Perl hash is similar to an ordinary array, but instead of using integer indexes, a hash uses "keys" that can take on any scalar value. These are usually strings or numbers.

Syntax: instead of the `@` operator, associative arrays use the `%` symbol, and rather than square brackets `[]`, as in `$myarray[0]`, hash elements are referenced using curly brackets `{}`, as in `$myhash{"george"}`.

Hashes are one of the most powerful and commonly used features in Perl. A typical use would be to build a hash that contains a "dictionary", with each key being a word in the dictionary, and the corresponding values being the definitions of those words.

A hash containing the sounds various household pets make is below
    
    
    my %petsounds = ("cat" => "meow",
                     "dog" => "woof",
                     "snake" => "hiss");
    

'=>' and ',' are actually interchangeable, so the right side could look exactly like an array. This means that you can assign an array to a hash. In such an assignment, each element with an even index (starting from 0) in the array becomes a key in the hash. The following statements create the same hash as the previous one does
    
    
    my @array = ("cat", "meow", "dog", "woof", "snake", "hiss");
    my %petsounds = @array;
    

But the first style is more preferred because it makes the statement more readable.

To access a hash element, use the curly brackets:
    
    
     print STDOUT "The cat goes " . $petsounds{"cat"} . ".\n";
    

will print the following to STDOUT
    
    
    The cat goes meow.
    
    

To add a new sound item to a hash
    
    
    $petsounds{"mouse"} = "squeak!";
    

To overwrite an existing element, just reassign it
    
    
    $petsounds{"dog"} = "arf!";  # The dog now goes "arf!"
    

To remove an item from a hash, use `delete`. Setting the value to `undef` does not delete the item; using `exists` on a key that has been set to `undef` will still return true.
    
    
    delete($petsounds{"cat"});  # will remove "cat" from our hash
    

## "Associative Arrays"[[edit](/w/index.php?title=Perl_Programming/Hash_Variables&action=edit&section=T-1)]

Originally, a "hash" was called an "associative array", but this term is a bit outdated (people just got sick and tired of using seven syllables). Although it isn't intuitive for newcomers to programming, "hash" is now the preferred term. The name is derived from the computer science term, [hashtable](//en.wikipedia.org/wiki/Hashtable).

## Working with hashes[[edit](/w/index.php?title=Perl_Programming/Hash_Variables&action=edit&section=T-2)]

### Printing hash contents[[edit](/w/index.php?title=Perl_Programming/Hash_Variables&action=edit&section=T-3)]

If you know PHP, you may have thought by now of some convenient way to print the contents of your array the way `print_r` does...
    
    
    use Data::Dumper;
     
    print Dumper(\%hash);
    

### Counting the number of entries in a hash[[edit](/w/index.php?title=Perl_Programming/Hash_Variables&action=edit&section=T-4)]

To get the size of the hash, simply find the size of the result of the `keys` function, by evaluating it in scalar context:
    
    
    my %hash = (
       'key1' => 1,
       'key2' => 2
    );
     
    print "Hash has " . keys(%hash) . " elements\n";
    my $num_elements = scalar(keys(%hash));
    

## Hash of Hashes of Hashes[[edit](/w/index.php?title=Perl_Programming/Hash_Variables&action=edit&section=T-5)]

You can define multidimensional hash array variables. An example may look like this:
    
    
    #!/usr/bin/perl
     
    use Data::Dumper;
     
    my %a=();
     
    $a{1}{"a"}{"A"}="FIRST";
    $a{1}{"c"}{"B"}="THIRD";
    $a{1}{"b"}{"C"}="SECOND";
     
    foreach my $k1 ( sort keys %a ) {
      foreach my $k2 ( sort keys %{$a{$k1}} ) {
        foreach my $k3 ( sort keys %{$a{$k1}{$k2}} ) {
          print "$k1\t$k2\t$k3\t$a{$k1}{$k2}{$k3}\n";
        }
      }
    }
     
    print Dumper(\%a);
    

This code will produce:
    
    
     1       a       A       FIRST
     1       b       C       SECOND
     1       c       B       THIRD
     $VAR1 = {
               '1' => {
                        'c' => {
                                 'B' => 'THIRD'
                               },
                        'a' => {
                                 'A' => 'FIRST'
                               },
                        'b' => {
                                 'C' => 'SECOND'
                               }
                      }
             };
    

  


  
Input/Output or **IO**, is an all-encompassing term that describes the way your program interacts with the user. IO comes in two forms, or _stream_ types: the program's stimuli are collectively referred to as _input,_ while the medium that the program uses to communicate back, write logs, play sounds, etc. is known as _output._ Both types of streams can be redirected either at a lower level than Perl, as is the case when done through the operating system by the shell; or, in Perl itself, as is the case when you reopen the file handles associated with the stream.

## Output[[edit](/w/index.php?title=Perl_Programming/User_Input-Output&action=edit&section=T-1)]

You have already learned how to output with the `print` statement. A simple reference is provided:
    
    
    print "Hello World";
    

What this `print` statement is actually doing is printing to _STDOUT_, which stands for _standard output_. Standard output is the default destination for all output. If you wish to print anywhere else you must be explicit. We will revisit this later.

## Input[[edit](/w/index.php?title=Perl_Programming/User_Input-Output&action=edit&section=T-2)]

As you may have imagined, it's very hard to write a good program without any type of input; here is an example program to teach you these concepts:
    
    
    #!/usr/bin/perl
    use strict;
    use warnings;
     
    print "What is your name?\n";
     
    ## Get the users $name from Standard In
    my $name = <STDIN>;
     
    print "Your name is $name\n";
    

Standard input is usually the keyboard though this can be changed at a lower level than your program. For now we will assume it isn't changed. However, this might not be an assumption you wish to make in production code.

# Unit Exercise[[edit](/w/index.php?title=Perl_Programming/User_Input-Output&action=edit&section=T-3)]

  * Write a program which prompts the user for a number and then returns the number multiplied by four (or any other number).

  


  


## Advanced Output Overview[[edit](/w/index.php?title=Perl_Programming/Advanced_Output&action=edit&section=T-1)]

In many situations, especially for web programming, you will find that you want to put certain things, such as backslashes or quotes, in your text that aren't allowed in a traditional print statements. A statement such as
    
    
    print "I said "I like mangos and bananas". ";
    

will not work because the interpreter would think that the quotes mark the end of the string. As with all things in Perl, there are many solutions to this problem.

## Use other quotes[[edit](/w/index.php?title=Perl_Programming/Advanced_Output&action=edit&section=T-2)]

The quickest solution to this problem would be to use single quotes to surround the string, allowing the use of double quotes in the middle.
    
    
    # I said "I like mangos and bananas".
    print 'I said "I like mangos and bananas".';
    

This is obviously not the best solution, as it is conceivable that you are trying to print a string containing both kinds of quote:
    
    
    # I said "They're the most delicious fruits".
    print 'I said "They're the most delicious fruits".';
    

## Escape characters[[edit](/w/index.php?title=Perl_Programming/Advanced_Output&action=edit&section=T-3)]

For situations like the above where only a short amount of text is being quoted, a common solution is to _escape_ any quotes in the string. By preceding any quotes with a backslash they are treated as literal characters.
    
    
     print 'I said "They\'re the most delicious fruits".';
     print "I said \"They\'re the most delicious fruits\".";
    

Using single quotes, the characters that require escaping are `\'`.

Using double quotes, the characters that need escaping are the variable sigils, (i.e. `$@%*`) in addition to `\"`

Using `\` to escape reserved characters of course implies that you also need to escape any backslashes you want to use in your string. To print the second line literally using perl, you would need to write:
    
    
     print " print \"I said \\\"They\\\'re the most delicious fruits\\\".\";"
    

Luckily perl provides us with another way of quoting strings that avoids this problem.

## Custom Quotes[[edit](/w/index.php?title=Perl_Programming/Advanced_Output&action=edit&section=T-4)]

Perl provides the operators `q` and `qq` that allows you to decide which characters are used to quote strings. Most punctuation characters can be used. Here are a few examples:
    
    
     print qq{ I said "They're the most delicious fruits!". };
     print q! I said "They're the most delicious fruits\!". !;
    

The only symbols I have found that cannot be used for these quotes are `$ ` /`

## Block Output[[edit](/w/index.php?title=Perl_Programming/Advanced_Output&action=edit&section=T-5)]

As can be seen, while the custom quotes option works for short strings, it can run into problems if a lot of text containing a lot of punctuation is output. For this situation, a technique called Block quoting can be used.
    
    
     print <<OUTPUT
      I said "They're the most delicious fruits!".
     OUTPUT
    

Any string of characters can be used instead of OUTPUT in the example above. Using this technique anything can be output no matter what characters it contains. The one caveat of this method is that the closing OUTPUT must be the first character on the line, there cannot be any space before it.
    
    
     print <<EverythingBetween
      ...
      ...
     EverythingBetween
    

## Variable Output[[edit](/w/index.php?title=Perl_Programming/Advanced_Output&action=edit&section=T-6)]

It is possible to output variables within strings when you use some of these methods:
    
    
    my $one = 'mangoes';
     
    print "I like $one.";    # I like mangoes.
    print 'I like $one.';    # I like $one.
    print qq@ I love $one.@; #  I love mangoes.
    print q#I love $one.#;   # I love $one.
     
    print <<OUT
     I love $one
    OUT
    ;                        #  I love mangoes
     
    print <<'OUT'
     I love $one
    OUT
    ;                        #  I love $one
    

Perl will figure out where your variable ends if the character after it is neither a letter, number nor an underscore. If that is not your case, put your variable inside curly braces:
    
    
    my $one = 'lemon';
     
    print "A $one is too sour; ";   # A lemon is too sour;
    print "${one}ade is better.\n"; # lemonade is better.
     
    print <<OUT
     I love ${one}s in $one souffle.
    OUT
    ;                        #  I love lemons in lemon souffle.
    

## Caveats[[edit](/w/index.php?title=Perl_Programming/Advanced_Output&action=edit&section=T-7)]

The single quote `' q{` and double quote `" qq <<A` operators, behave differently. Whereas when using double quotes, you can include variables and escape any characters, when you use single quotes you can only escape single quotes and you cannot include variables.

  


  


## Control structures[[edit](/w/index.php?title=Perl_Programming/Control_Flow&action=edit&section=T-1)]

The basic control structures do not differ greatly from those used in the [C](/wiki/Programming:C) programming language or [Java](/wiki/Programming:Java) programming language:

### Loops[[edit](/w/index.php?title=Perl_Programming/Control_Flow&action=edit&section=T-2)]
    
    
    while ($boolean) {
        # do something
    }
     
    until ($boolean) {
        # do something
    }
    

Note that the statements in a `while` (or `until`) loop are not executed if the Boolean expression evaluates to false (or true, respectively) on the first pass.
    
    
    do {
        # something
    } while ($boolean);
     
    do {
        # something
    } until ($boolean);
    

The `do {} while` and the `do {} until` loops are technically [statement modifiers](/wiki/Perl_Programming/Modifiers) and not actual control structures. The statements will be executed at least once.
    
    
    for (my $i=0 ; $i<10 ; $i++) { # for (initialization; termination condition; incrementing expr) { ... }
        print "$i\n";
    }
     
    foreach my $variable (@list) {
        print "$variable\n";
    }
    

`$variable` is an alias to each element of the `@list`, starting at the first element on the first pass through the loop. The loop is exited when all the elements in the list have been exhausted. Since `$variable` is an alias, changing the value will change the value of the element in the _list_. This should generally be avoided to enhance maintainability of the code.

If `$variable` is omitted, the default variable `$_` will be used.

Note that `for` and `foreach` are actually synonyms and can be used interchangeably.

### If-then statements[[edit](/w/index.php?title=Perl_Programming/Control_Flow&action=edit&section=T-3)]
    
    
    if ($boolean_expression) {
        # do something
    }
     
    unless ($boolean_expression) {
        # do something
    }
    

Statements with `else` blocks (these also work with `unless` instead of `if`)
    
    
    if ($boolean) {
        # do something
    }
    else {
        # do something else
    }
     
    if ($boolean) {
        # do something
    }
    elsif ($boolean) {
        # do something else
    }
    

Control statements can also be written with the conditional following the statements (called "postfix"). This syntax functions (nearly) identically to the ones given above.
    
    
    _statement_ if _Boolean expression_;
    _statement_ unless _Boolean expression_;
    _statement_ while _Boolean expression_;
    _statement_ until _Boolean expression_;
    _statement_ foreach _list_;
    

## See Also[[edit](/w/index.php?title=Perl_Programming/Control_Flow&action=edit&section=T-4)]

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Perl control structures**_](//en.wikipedia.org/wiki/Perl_control_structures)

  


# Read files[[edit](/w/index.php?title=Perl_Programming/Filehandles&action=edit&section=T-1)]

## Procedural Interface[[edit](/w/index.php?title=Perl_Programming/Filehandles&action=edit&section=T-2)]

### By slurping file[[edit](/w/index.php?title=Perl_Programming/Filehandles&action=edit&section=T-3)]

This method will read the whole file into an array. It will split on the special variable `$/`
    
    
    # Create a read-only file handle for foo.txt
    open ( my $fh, '<', 'foo.txt' );
     
    # Read the lines into the array @lines
    my @lines=<$fh>;
     
    # Print out the whole array of lines
    print @lines;
    

### By line processing[[edit](/w/index.php?title=Perl_Programming/Filehandles&action=edit&section=T-4)]

This method will read the file one line at a time. This will keep memory usage down, but the program will have to poll the input stream on each iteration.
    
    
    # Create a read-only file handle for foo.txt
    open ( my $fh, '<', 'foo.txt' );
     
    # Iterate over each line, saving the line to the scalar variable $line
    while ( my $line = <$fh> ) {
     
      # Print out the current line from foo.txt
      print $line;
     
    }
    

## Object Oriented Interface[[edit](/w/index.php?title=Perl_Programming/Filehandles&action=edit&section=T-5)]

Using IO::File you can get a more modern object-oriented interface to a perl file handle.
    
    
    # Include IO::File which will give you the interface
    use IO::File;
     
    # Create a read-only file handle for foo.txt
    my $fh = IO::File->new( 'foo.txt', 'r' );
     
    # Iterate over each line, saving the line to the scalar variable $line
    while ( my $line = $fh->getline ) {
     
      # Print out the current line from foo.txt
      print $line;
     
    }
    
    
    
    # Include IO::File which will give you the interface
    use IO::File;
     
    # Create a read-only file handle for foo.txt
    my $fh = IO::File->new( 'foo.txt', 'r' );
     
    my @lines = $fh->getlines;
     
    # Print out the current line from foo.txt
    print @lines;
    

  


In addition to the basic control structures, Perl allows the use of statement modifiers. The statement modifier is placed at the end of the statement that it modifies. Note that the do {} until and do {} while loop constructs are actually statement modifiers. The complete list of modifiers is:

  * _statement_ **if** _expression_
  * _statement_ **unless** _expression_
  * _statement_ **while** _expression_
  * _statement_ **until** _expression_
  * _statement_ **foreach** _list_

Unlike BASIC-PLUS, statement modifiers in Perl cannot be stacked.

  


## String functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-1)]

### chomp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-2)]

#### Action[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-3)]

Removes the last characters from a string only if they're recognized as a record separator (e.g. a newline character)

#### Returns[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-4)]

?

#### Syntax[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-5)]

chomp($String = $_);

#### Example[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-6)]
    
    
    chomp; # removes the last character from $_ if it is a record separator
    chomp(); # (same)
    chomp($String); # removes the last character from $String if it is a record separator
    

#### See Also[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-7)]

  * chop \- To remove the last character from a string

### chop[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-8)]

#### Action[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-9)]

Removes the last character from a string regardless

#### Returns[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-10)]

?

#### Syntax[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-11)]

chop($String = $_);

#### Example[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-12)]
    
    
    chop; # removes the last character from $_
    chop(); # (same)
    chop($String); # removes the last character from $String
    

#### See Also[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-13)]

  * chomp \- To remove the last character from a string if it is a record seperator

Removes the last character from a string (e.g. removes the newline characters when reading from a file)

### chr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-14)]
    
    
    print chr(65);  # Prints a capital A
    

Gets an ASCII character, given it's code

### crypt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-15)]
    
    
    # One-way hash function
    my $HashedWord = crypt($Word, $Salt);
    

(See also [MD5](http://search.cpan.org/~gaas/MD5-2.03/MD5.pm) )

The salt string needs only be 2 characters long, and provides a way of randomising the hash, such that the same word can produce several different hashes, if used with different values of $Salt;!

### hex[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-16)]
    
    
    print hex(11);  # Prints B
    

Converts a number to hexadecimal

Other way around - converts hex to number: print hex(11); # prints 17

you can use

print sprintf("%X",11); # Prints B

### index[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-17)]

Search for one string within another. (see _rindex_ to search from end-to-start)
    
    
    $Result = index($Haystack, $Needle);
    $Result = index($Haystack, $Needle, $StartPosition);
    
    index("Some text", "bleh"); # Returns -1 (not found)
    index("Some text", "Some"); # Returns 0 (first character)
    index("Some text", "text"); # Returns 5 (sixth character)
    

The special variable $[ always gets added to the return value, but $[ is normally 0, and the manual recommends leaving it at 0.

### lc[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-18)]
    
    
    $Lowercase = lc($String);
    

Converts a string to lower-case

### lcfirst[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-19)]

Converts the first character of a string to lowercase

### length[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-20)]
    
    
    print "String is " . length($String) . " characters long\n";
    

Returns the length of a string

### oct[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-21)]
    
    
    print oct(8);  # Prints 10
    

Converts a number to octal

### ord[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-22)]

Converts a character to its number.
    
    
    print ord("A"); # prints 65
    

### pack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-23)]

Takes a list and converts it into a string using a supplied set of rules.
    
    
    my $String = pack($Template, @ListOfNumbers);
    my $String = pack("CCCC",65,66,67,68); # Result: "ABCD"
    

$Template can be made up of:
    
    
       a       A string with arbitrary binary data, will be null padded.
       A    An ascii string, will be space padded.
       Z    A null terminated (asciz) string, will be null padded.
    
    
    
       b       A bit string (ascending bit order inside each byte, like vec()).
       B    A bit string (descending bit order inside each byte).
       h    A hex string (low nybble first).
       H    A hex string (high nybble first).
    
    
    
       c       A signed char value.
       C    An unsigned char value.  Only does bytes.  See U for Unicode.
    
    
    
       s       A signed short value.
       S    An unsigned short value. (Exactly 16 bits unless you use the ! suffix)
    
    
    
       i       A signed integer value.
       I    An unsigned integer value. (At least 32 bits wide, machine-dependant)
    
    
    
       l       A signed long value.
       L    An unsigned long value. (Exactly 32 bits unless you use the ! suffix)
    
    
    
       n       An unsigned short in "network" (big-endian) order.
       N    An unsigned long in "network" (big-endian) order.
       v    An unsigned short in "VAX" (little-endian) order.
       V    An unsigned long in "VAX" (little-endian) order. (Exactly 16 bits and 32 bits respectively)
    
    
    
       q       A signed quad (64-bit) value.
       Q    An unsigned quad value. (Only available if your system supports 64-bit integers and Perl has been compiled to support them)
    
    
    
       f       A single-precision float in the native format.
       d    A double-precision float in the native format.
    
    
    
       p       A pointer to a null-terminated string.
       P    A pointer to a structure (fixed-length string).
    
    
    
       u       A uuencoded string.
       U    A Unicode character number.  Encodes to UTF-8 internally.
    
    
    
       w       A BER compressed integer.  Its bytes represent an unsigned integer in base 128, most significant digit first, with as few digits as possible.  Bit eight (the high bit) is set on each byte except the last.
    
    
    
       x       A null byte.
       X    Back up a byte.
       @    Null fill to absolute position.  
    

Each letter may optionally be followed by a number giving a repeat count.

The integer types s, S, l, and L may be immediately followed by a ! suffix to signify native shorts or longs

### reverse[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-24)]

Reverses a string (in scalar context) or a list (in list context):
    
    
    my @ReversedList = reverse(@List);
    
    
    
    # As commonly seen in Perl programs:
    foreach( reverse( sort( @List )))
    {
    ...
    }
    
    
    
    my $ReversedString = reverse($String);
    
    
    
    my @List = ("One ", "two ", "three...");
    my $ReversedListAsString = reverse(@List); # Prints "...eerht owt enO"
    

### rindex[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-25)]

Search for one string within another, starting at the end of the string.
    
    
    $Result = rindex($Haystack, $Needle);
    $Result = rindex($Haystack, $Needle, $StartPosition);
    
    rindex("Some text", "bleh"); # Returns -1 (not found)
    rindex("Some text", "Some"); # Returns 0 (first character)
    rindex("abbbbb", "b");       # Returns 5 (first "b" found, when starting at the end)
    

### sprintf[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-26)]

Prints a formatted string:
    
    
    my $Text = sprintf("%d / %d is %08.5f", 1, 3, 1/3); # Result: "10 / 3 is 003.33333"
    
    
    
    sprintf("Character: %c", 65); 
    sprintf("String %s", "Hello");
    sprintf("Signed integer: %d", 15);
    sprintf("Unsigned integer: %u", 15);
    sprintf("Unsigned int (in octal): %o", 15);
    sprintf("Unisgned int (in hex): %x", 15);      # Use %X to get upper-case output
    sprintf("Binary number: %b", 15);
    sprintf("Scientific notation: %e", 5000);      # Use %E to get upper-case output
    sprintf("Floating point number: %f", 1/3);     # 0.3333333
    sprintf("Floating point number: %g", 1/3);     # Decides between scientific and float.  %G is uppercase
    sprintf("Pointer: %p", $Variable);
    

Use %% to get a percent-sign.

Use %n to request the number of characters written so far, and put it into the next variable in the list. You may want to check that user-supplied formatting rules don't contain this code.
    
    
    sprintf("%02d", $Minutes);  # Forces leading zeros to make the string 2 characters long
    sprintf("%1.5f", $Number);  # Limits the number of decimal places
    

### substr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-27)]

Return part of a string (a _substring_)

Format: substr _string_ _start-position_ _length_

    _start-position_ is zero-based.
    A negative number starts from the end of the string.
    
    
    $FirstLetter   = substr($Text, 0, 1);   # First letter
    $First3Letters = substr($Text, 0, 3);   # First three letters
    $Last3Letters  = substr($Text, -3);     # Last three letters
    

You can use **substr** on the left side of an assignment statement to change part of a string. This can actually shorten or lengthen the string.
    
    
     $text = 'cat dog';
     substr ($mystring, 3, 1) = ' and ';  # $text now contains 'cat and dog'
    

### uc[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-28)]
    
    
    $Uppercase = uc($String);
    

Converts a string to upper-case

### ucfirst[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-29)]

Converts the first character of a string to uppercase

## Numeric functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-30)]

### abs[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-31)]

Returns the absolute(positive) value of a number
    
    
    $Number = abs(-100); # Returns 100;
    

### atan2[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-32)]
    
    
    # Converts cartesian(x,y) coordinates into an angle
    $Number = atan2($Y, $X);
    

### cos[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-33)]
    
    
    # Returns the cosine of an angle (radians)
    $Number = cos($Angle);  # Cosine = Adjacent/Hypotenuse
    

### exp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-34)]
    
    
    # Raises e to a specified power 
    $Number = exp(2); # Returns ![e^2](//upload.wikimedia.org/math/1/1/b/11bf4aa6706937636de8b6ebb7fc3a92.png)
    
    
    
    e ≈ 2.71828183 [more about e](//en.wikipedia.org/wiki/E_\(mathematical_constant\))
    

### hex[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-35)]
    
    
    # Interprets a string as hexidecimal, and returns its value
    $Number = hex("10"); # Returns 16
    $Number = hex("0xFF"); # Returns 255
    

### int[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-36)]

Rounds a number towards zero, returning an integer
    
    
    $Number = int(-1.6);  # Returns -1
    $Number = int(0.9);   # Returns 0
    $Number = int(28.54); # Returns 28
    

### log[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-37)]
    
    
    # Returns the natural logarithm of a number
    $Number = log(2.71828183);   # Returns 1
    $Number = exp(log($X));      # Returns $X
    $Number = log($X) / log(10); # Returns log10($X). Alternately, you can use the log10() function in the POSIX module
    $Number = log($X) / log(15); # Returns log to the base 15 of $X
    

### oct[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-38)]
    
    
    # Interprets a string as octal, and returns its value
    $Number = oct("10"); # Returns 8
    $Number = oct("21"); # Returns 17
    

### rand[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-39)]
    
    
    # Gets a random number (may automatically call srand() if that's not been done)
    $Number = rand();  # Returns a random number from 0 to 1
    $Number = int(rand(800));  # Returns a random integer from 0 to 799
    $Number = 1 + int(rand(999));  # Returns a random integer from 1 to 999
    

### sin[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-40)]
    
    
    # Returns the sine of an angle (radians)
    $Number = sin($Angle);  # Sine = Opposite/Hypotenuse
    

### sqrt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-41)]
    
    
    # Returns the square-root of a number
    $Number = sqrt(4);                  # Returns 2
    $Number = sqrt($X ** 2 + $Y ** 2);  # Returns the diagonal distance across a $X x $Y rectangle
    
    
    
    See the Math::Complex module if you need to take roots of negative numbers;
    

### srand[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-42)]
    
    
    # Seeds (sets-up) the random-number generator
    srand();
    

Version-dependant, and older versions of Perl are not guaranteed to have a good seed value. See the Math::TrulyRandom module for more possibilities. The current version of Perl uses the urandom device if it's available.

## Array functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-43)]

### pop[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-44)]
    
    
    $LastElement = pop(@MyArray);
    

Take the last element from an array

### push[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-45)]
    
    
    push(@MyArray, "Last element");
    push(@MyArray, "several", "more", "elements");
    

Push a list of elements onto the end of an array

### shift[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-46)]
    
    
    shift(@MyArray); #Delete the first element
    $FirstElement = shift(@MyArray); #Delete the first element, load it into $FirstElement instead
    

Take the first element out of an array

### splice[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-47)]
    
    
    # Removes elements from an array, optionally replacing them with a new array
    splice(@Array); # Removes all elements from array
    splice(@Array, 10); # Removes from element 10 to the end of the array
    splice(@Array, -10); # Removes the last 10 elements of the array
    splice(@Array, 0, 10); # Removes the first 10 elements of the array
    @NewArray = splice(@Array, 0, 10); # Removes the first 10 elements of the array and returns those 10 items
    splice(@Array, 0, 10, @Array2); # Replaces the first 10 elements of the array with Array2
    

### unshift[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-48)]
    
    
    unshift(@MyArray, "New element");
    unshift(@MyArray, "several", "more", "elements");
    

Add a list of elements onto the beginning of an array

## List functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-49)]

### grep[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-50)]
    
    
    # Returns a list of elements for which an expression is true
    @TextFiles = grep(/\.txt$/, @AllFiles);
    $NumberOfTextFiles = grep(/\.txt$/, @AllFiles);
    
    
    
    # Can use a block of code instead of an expression
    @TextFiles = grep({return(substr($_, -3) eq "txt");}, @AllFiles);
    

### join[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-51)]
    
    
    # Joins the items of a list into a single string
    $OneItemPerLine = join( "\n", @List);
    $EverythingBunchedTogether = join( "", @List);
    $Filename = join( "/", ($Directory, $Subdirectory, $Filename));
    

### map[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-52)]
    
    
    # Evaluates a block of code for each item in a list, and returns
    # a list of the results
    @UppercaseList = map(uc, @List);
    @Numbers = map {"Number $_"} 1..100;
    

### reverse[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-53)]
    
    
    # Reverses the order of a list
    @ReversedList = reverse(@List);
    # In scalar context, concatenates the list and then reverses the string
    $ReversedString = reverse('foo','bar','baz'); # gives 'zabraboof'
    

### sort[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-54)]
    
    
    # Sorts the elements in a list
    @AsciiSort = sort(@RandomList);
    @AsciiSort = sort @RandomList;
    foreach $Item (sort @RandomList)
      {...}
    
    
    
    # Can specify a function to decide the sort order
    @CaseInsensitiveSort = sort {uc($a) cmp uc($b)} @RandomList;
    @NumericSort = sort {$a <=> $b} @RandomList;
    @CustomSort = sort custom_function_name @RandomList;
    

### unpack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-55)]

Unpacks a string into a list - see the templates available for the pack() function for details

## Associative array functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-56)]

### delete[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-57)]
    
    
    #Remove an element from a hash
    %h = ('a'=>1, 'cow'=>'moo', 'b'=>2);
    delete $h{cow};
    # %h now contains ('a'=>1, 'b'=>2)
    

### each[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-58)]
    
    
    #Return the 'next' key/value pair (in a random order)
    while (($key, $value) = each (%hash)){
       print "$key => $value\n";
    }
    

### exists[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-59)]
    
    
     #Tests whether or not a key exists in a hash (even if the value for that key is undef)
     if (exists $hash{$key}){
        print "\%hash contains a value for key '$key'\n";
     }
    

### keys[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-60)]
    
    
     #Returns a list of all keys from the hash, in same 'random' order as each
     foreach $key (keys %hash){
        print "$key => $hash{$key}\n";
     }
    

### values[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-61)]
    
    
     #Returns a list of all values from the hash, in same 'random' order as keys
     foreach $value (values %hash){
        print "\%hash contains a value '$value'\n";
     }
    

## Input and output functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-62)]

### binmode[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-63)]

### close[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-64)]
    
    
    #closes a filehandle when it is no longer needed
    close(STDERR); #hide debugging info from the user
    

### closedir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-65)]
    
    
    # Close a directory open by opendir
    closedir(DIRHANDLE);
    
    

### dbmclose[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-66)]

### dbmopen[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-67)]

### die[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-68)]

Exits the program, printing to "STDERR" the first parameter and the current file and line. Used to trap errors.
    
    
    die "Error: $!\n" unless chdir '/';
    
    

### eof[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-69)]
    
    
    eof FILEHANDLE
    eof()
    eof
    

This function returns true if the next read on FILEHANDLE would return end-of-file, or if FILEHANDLE is not open. FILEHANDLE may be an expression whose value gives the real filehandle, or a reference to a filehandle object of some sort. An eof without an argument returns the end-of-file status for the last file read. An eof() with empty parentheses () tests the ARGV filehandle (most commonly seen as the null filehandle in <>). Therefore, inside a while (<>) loop, an eof() with parentheses will detect the end of only the last of a group of files. Use eof (without the parentheses) to test each file in a while (<>) loop. For example, the following code inserts dashes just before the last line of the last file:  

    
    
    while (<>) {
        if (eof()) {
            print "-" x 30, "\n";
        }
        print;
    }
    

On the other hand, this script resets line numbering on each input file:
    
    
    # reset line numbering on each input file
    while (<>) {
        next if /^\s*#/;        # skip comments
        print "$.\t$_";
    } continue {
        close ARGV if eof;      # Not eof()!
    }
    

Like "$" in a sed program, eof tends to show up in line number ranges. Here's a script that prints lines from /pattern/ to end of each input file:
    
    
    while (<>) {
        print if /pattern/ .. eof;
    }
    

Here, the flip-flop operator (..) evaluates the pattern match for each line. Until the pattern matches, the operator returns false. When it finally matches, the operator starts returning true, causing the lines to be printed. When the eof operator finally returns true (at the end of the file being examined), the flip-flop operator resets, and starts returning false again for the next file in @ARGV

### fileno[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-70)]

### flock[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-71)]

### format[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-72)]

### getc[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-73)]

### print[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-74)]

Prints the parameters given.

Discussed in the following sections:

    _[Digression on print_ in _Strings_ section](/wiki/Perl_Programming/Strings#Brief_Digression_from_Strings_Alone:_The_print_Function)

### printf[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-75)]

### read[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-76)]

### readdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-77)]

### rewinddir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-78)]

### seek[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-79)]

### seekdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-80)]

### select[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-81)]

### syscall[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-82)]

### sysread[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-83)]

### sysseek[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-84)]

### syswrite[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-85)]

### tell[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-86)]

### telldir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-87)]

### truncate[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-88)]

### warn[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-89)]

### write[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-90)]

## Functions for working with fixed length records[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-91)]

### pack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-92)]

See the entry for **pack** further up the page

### read[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-93)]
    
    
    # Reads data from a file-handle
    read(FILEHANDLE, $StoreDataHere, $NumberBytes);
    
    
    
    # Returns the number of bytes read
    $NumberBytesRead = read(FILEHANDLE, $StoreDataHere, $NumberBytes);
    
    
    
    # Optional offset is applied _when the data is stored_ (not when reading)
    read(FILEHANDLE, $StoreDataHere, $NumberBytes, Offset);
    

  


### syscall[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-94)]
    
    
    # Runs a system command
    syscall( $Command, $Argument1, $Argument2, $Argument3);
    
    
    
    # (maximum 14 arguments)
    $ReturnValue = syscall($Command);
    

  


### sysread[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-95)]

### syswrite[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-96)]

### unpack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-97)]
    
    
    # See the **pack** function for details (unpack does the opposite!)
    unpack($Template, $BinaryData);
    

### vec[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-98)]

## Filesystem functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-99)]

### -X[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-100)]
    
    
    if( -r $FullFilename) // File is readable by effective uid/gid.
    if( -w  $FullFilename) // File is writable by effective uid/gid.
    if( -x  $FullFilename) // File is executable by effective uid/gid.
    if( -o  $FullFilename) // File is owned by effective uid.
    
    
    
    if( -R     $FullFilename) // File is readable by real uid/gid.
    if( -W  $FullFilename) // File is writable by real uid/gid.
    if( -X  $FullFilename) // File is executable by real uid/gid.
    if( -O  $FullFilename) // File is owned by real uid.
    
    
    
    if( -e     $FullFilename) // File exists.
    if( -z  $FullFilename) // File has zero size.
    if( -s  $FullFilename) // File has nonzero size (returns size).
    
    
    
    if( -f     $FullFilename) // File is a plain file.
    if( -d  $FullFilename) // File is a directory.
    if( -l  $FullFilename) // File is a symbolic link.
    if( -p  $FullFilename) // File is a named pipe (FIFO), or Filehandle is a pipe.
    if( -S  $FullFilename) // File is a socket.
    if( -b  $FullFilename) // File is a block special file.
    if( -c  $FullFilename) // File is a character special file.
    if( -t  $FullFilename) // Filehandle is opened to a tty.
    
    
    
    if( -u     $FullFilename) // File has setuid bit set.
    if( -g  $FullFilename) // File has setgid bit set.
    if( -k  $FullFilename) // File has sticky bit set.
    
    
    
    if( -T     $FullFilename) // File is an ASCII text file.
    if( -B  $FullFilename) // File is a "binary" file (opposite of -T).
    
    
    
    $Age = -M $FullFilename; // Age of file in days when script started.
    $Age = -A $FullFilename; // Same for access time.
    $Age = -C $FullFilename; // Same for inode change time.  
    

### chdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-101)]
    
    
    chdir $Directory;
    chdir $Directory || die("Couldn't change directory");
    

### chmod[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-102)]
    
    
    chmod 0744 $File1;
    chmod 0666 $File1, $File2, $File3;
    # 0 for octal, at the beginning of a number
    
    
    
            | Owner | Group | Others |
    Execute |   4   |   4   |   4    |
    Write   |   2   |   2   |   2    |
    Read    |   1   |   1   |   1    |
    ======--+======-+======-+======--+
    Total   |       |       |        |
    

### chown[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-103)]
    
    
    # Change the owner of a file
    chown($NewUserID, $NewGroupID, $Filename);
    chown($NewUserID, $NewGroupID, $File1, $File2, $File3);
    
    
    
    chown($NewUserID, -1, $Filename); # Leave group unchanged
    chown(-1, $NewGroupID, $Filename); # Leave user unchanged
    

### chroot[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-104)]
    
    
    chroot $NewRootDirectory;
    

Sets the root directory for the program, such that the "/" location refers to the specified directory.

Program must be running as root for this to succeed.

### fcntl[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-105)]

### glob[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-106)]
    
    
    #Expands filenames, in a shell-like way
    my @TextFiles = glob("*.txt");
    

See also File::Glob

### ioctl[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-107)]

### link[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-108)]
    
    
    # Creates a link to a file
    link($ExistingFile, $LinkLocation);
    link($ExistingFile, $LinkLocation) || die("Couldn't create link");
    

### lstat[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-109)]

Identical to stat(), except that if given file is symbolic link, stat link not the target.

### mkdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-110)]
    
    
    mkdir $Filename || die("Couldn't create directory");
    mkdir $Filename, 0777; # Make directory with particular file-permissions
    

### open[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-111)]
    
    
    open(my $FileHandle, $Filename) || die("Couldn't open file");
    open(my $fp, "<", $Filename);   # Read from file
    open(my $fp, ">", $Filename);   # Write to file
    open(my $fp, ">>", $Filename);  # Append to file
    
    
    
    open(my $fp, "<$Filename");     # Read from file
    open(my $fp, ">$Filename");     # Write to file
    open(my $fp, ">>$Filename");    # Append to file
    
    
    
    open(my $fp, "<", "./   filename with whitespace   \0");
    open(my $fp, "<", "./->filename with reserved characters\0");
    

  

    
    
    open(my $fp, "$Program |");     # Read from the output of another program
    open(my $fp, "| $Program");     # Write to the input of another program
    
    
    
    open(my $fp, "<", "-");         # Read from standard input
    open(my $fp, ">", "-");         # Write to standard output
    

  


### opendir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-112)]
    
    
    opendir(my $DirHandle, $Directory) || die("Couldn't open directory");
    while (my $Filename = readdir $DirHandle){
      # Do something with $Filename in $Directory
    }
    closedir($DirHandle);
    
    
    
    opendir(DIR, $Directory) || die("Couldn't open directory");
    foreach(readdir(DIR)){
      # Do something with $_ in $Directory
    }
    closedir(DIR);
    

### readlink[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-113)]
    
    
    # Finds the value of a symbolic link
    $LinkTarget = readlink($LinkPosition);
    

### rename[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-114)]
    
    
    rename $OldFile, $NewFile or die("Couldn't move file");
    

May work differently on non-*nix operating systems, and possibly not at all when moving between different filesystems. See [[File::Copy]] for more complicated file operations.

### rmdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-115)]
    
    
    rmdir $Filename || die("Couldn't remove directory");
    

### stat[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-116)]
    
    
    @FileStatistics = stat($Filename); 
    
    
    
    $DeviceNum    = $FileStatistics[0]; # device number of filesystem
    $Inode        = $FileStatistics[1]; # inode number
    $FileMode     = $FileStatistics[2]; # (type and permissions)
    $NumHardLinks = $FileStatistics[3]; # number of (hard) links to the file
    $UserID       = $FileStatistics[4]; # numeric user ID
    $GroupID      = $FileStatistics[5]; # numeric group ID
    $DeviceIdent  = $FileStatistics[6]; # Device identifier (special files only)
    $SizeBytes    = $FileStatistics[7]; 
    $AccessTime   = $FileStatistics[8]; # seconds since the epoch
    $ModifyTime   = $FileStatistics[9];
    $ChangeTime   = $FileStatistics[10];
    $BlockSize    = $FileStatistics[11];
    $NumBlocks    = $FileStatistics[12];
    

### symlink[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-117)]
    
    
    # Creates a new filename symbolically linked to the old filename
    symlink($OldFilename, $NewFilename);
    symlink($OldFilename, $NewFilename) || die("Couldn't create symlink");
    eval(symlink($OldFilename, $NewFilename));
    

### umask[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-118)]
    
    
    # Sets or returns the _umask_ for the process.
    my $UMask = umask();
    umask(0000); # This process can create any type of files
    umask(0001); # This process can't create world-readable files
    umask(0444); # This process can't create executable files
    

### unlink[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-119)]
    
    
    # Deletes a file
    unlink $Filename;
    unlink $Filename || die("Couldn't delete file");
    unlink $File1, $File2, $File3;
    (unlink($File1, $File2, $File3) == 3) || die("Couldn't delete files");
    

### utime[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-120)]
    
    
    # Updates the modification times of a list of files
    my $AccessTime = time();
    my $ModificationTime = time();
    
    
    
    utime($AccessTime, $ModificationTime, $Filename);
    my $NumFilesChanged = utime($AccessTime, $ModificationTime, $File1, $File2, $File3);
    

## Program functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-121)]

### caller[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-122)]

Returns information about the current function call stack. In scalar context, returns only the name of the package from where the current subroutine was called. In list context, returns the package, filename, and line number. In list context with a numeric argument passed, returns several pieces of information (see below). The argument represents how many levels in the call stack to go back.
    
    
    #!/usr/bin/perl
    
    foo();
    sub foo {
       $package = caller; #returns 'main'
       ($package, $filename, $line) = caller; #returns 'main', the file name, and 3
       # Line below returns all 10 pieces of info. (Descriptions self-explanatory from variable names)
       ($package, $filename, $line, $subroutine, $hasargs, $wantarray, $evaltext, $is_require, $hints, $bitmask) =
          caller(0); 
     }
    

### import[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-123)]

There is no actual 'import' function. Rather, it is a convention when writing a module to create a subroutine named 'import' which populates the current namespace with that module's needed variables and/or methods.

The standard 'Exporter' module provides an import method if your class has it as a base class.

### package[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-124)]

Declares all lines that follow (until EOF or the next package statement) to belong to the given package's namespace.
    
    
    #!/usr/bin/perl
    
    $x = 5;  #sets $main::x
    
    package Foo;
    $x = 5;  #sets $Foo::x
    sub bar { #defines &Foo::bar
       print "hello world";
    }
    
    package Temp;
    $x = 5; #sets $Temp::x
    

### require[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-125)]

includes the specified module's code into the current program. The module can be specified either with an absolute or relative path, or with a bareword. If a bareword is given, a '.pm' extention is added, and :: is replaced with the current operating system's path seperator:
    
    
    require Foo::Bar;
    #identical to:
    require 'Foo/Bar.pm';
    

### use[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-126)]

Requires and imports the given module or pragma, at compile time. The line
    
    
    use Foo qw/bar baz/;
    

is identical to:
    
    
    BEGIN {
       require Foo;
       import Foo qw/bar baz/;
    }
    

## Misc functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-127)]

### defined[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-128)]
    
    
    #returns true if argument is not undef
    $x = 0;
    print "X defined\n" if defined $x; #prints
    print "Y defined\n" if defined $y; #does not print
    
    

### dump[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-129)]

### eval[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-130)]
    
    
    eval('$a=30;$b=40;');
    print $a,$b;
    

### formline[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-131)]

### local[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-132)]
    
    
    #assigns temporary value to global variable for duration of lexical scope
    $x = 5;
    print "x = $x\n"; # 5
    {
      local $x = 10;
      print "x = $x\n"; # 10
    }
    print "x = $x\n"; # 5
    

### my[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-133)]
    
    
    #creates new lexical (ie, not global) variable
    $x = 5;  #refers to $main::x
    {
      my $x = 10;
      print "x = $x\n"; # the lexical - 10
      print "main's x = $main::x\n" # the global - 5
    }
    print "x = $x\n";  #the global, because no lexical in scope - 5
    

### reset[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-134)]
    
    
    #resets hash's internal pointer, to affect lists returned by each
    while ($k, $v = each %h){
      print "$k = $v\n";
      last if ($i++ == 2);
    }
    #if another each done here, $k,$v will pick up where they left off.
    reset %h
    #now each will restart from the beginning.
    

### scalar[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-135)]
    
    
    #forces scalar context on an array
    @sizes = (scalar @foo, scalar @bar);
    #creates a list of the sizes of @foo and @bar, rather than the elements in @foo and @bar
    

### undef[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-136)]
    
    
    #undefines an existing variable
    $x = 5;
    undef $x;
    print "x = $x\n" if defined $x; #does not print
    

### wantarray[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-137)]
    
    
    #returns 'true', 'false', or undef if function that called it was called in list, scalar, or void context, respectively.
    sub fctn {
       my @vals = (5..10);
       if (wantarray) {
          return @vals;
       } elsif (defined wantarray) {
          return $vals[0];
       } else {
          warn "Warning!  fctn() called in void context!\n";
       }
    }
    

## Processes[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-138)]

### alarm[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-139)]

### exec[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-140)]

### fork[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-141)]
    
    
    #clones the current process, returning 0 if clone, and the process id of the clone if the parent
    my $pid = fork();
    if ($pid == 0) {
       print "I am a copy of the original\n";
    } elsif ($pid == -1)  {
       print "I can't create a clone for some reason!\n";
    } else {
       print "I am the original, my clone has a process id of $pid\n";
    }
    

### getpgrp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-142)]

### getppid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-143)]

### getpriority[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-144)]

### kill[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-145)]

### pipe[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-146)]

### qx/STRING/[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-147)]

### setpgrp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-148)]

### setpriority[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-149)]

### sleep[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-150)]

### system[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-151)]

### times[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-152)]

### wait[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-153)]

### waitpid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-154)]

## Modules[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-155)]

### do[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-156)]

### import[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-157)]

### no[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-158)]

### package[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-159)]

### require[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-160)]

### use[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-161)]

## Classes and objects[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-162)]

See also [Perl Objects](/wiki/Perl_Programming/Objects)

### bless[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-163)]

### dbmclose[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-164)]

### dbmopen[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-165)]

### package[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-166)]

### ref[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-167)]

### tie[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-168)]

### tied[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-169)]

### untie[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-170)]

### use[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-171)]

## Sockets[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-172)]

### accept[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-173)]

### bind[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-174)]

### connect[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-175)]

### getpeername[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-176)]

### getsockname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-177)]

### getsockopt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-178)]

### listen[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-179)]

### recv[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-180)]

### send[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-181)]

### setsockopt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-182)]

### shutdown[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-183)]

### socket[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-184)]

### socketpair[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-185)]

## Login information[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-186)]

### endgrent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-187)]

### endhostent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-188)]

### endnetent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-189)]

### endpwent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-190)]

### getgrent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-191)]

### getgrgid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-192)]

### getgrnam[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-193)]

### getlogin[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-194)]

### getpwent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-195)]

### getpwnam[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-196)]

### getpwuid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-197)]

### setgrent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-198)]

### setpwent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-199)]

## Network information[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-200)]

### endprotoent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-201)]

### endservent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-202)]

### gethostbyaddr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-203)]

### gethostbyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-204)]

### gethostent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-205)]

### getnetbyaddr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-206)]

### getnetbyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-207)]

### getnetent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-208)]

### getprotobyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-209)]

### getprotobynumber[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-210)]

### getprotoent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-211)]

### getservbyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-212)]

### getservbyport[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-213)]

### getservent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-214)]

### sethostent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-215)]

### setnetent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-216)]

### setprotoent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-217)]

### setservent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-218)]

## Time and date[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-219)]

### gmtime[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-220)]

Converts a timestamp to GMT
    
    
    @TimeParts = gmtime(); 
    @TimeParts = gmtime($Time); 
    
    
    
    $Seconds    = $TimeParts[0]; # 0-59 
    $Minutes    = $TimeParts[1]; # 0-59
    $Hours      = $TimeParts[2]; # 0-23
    $DayOfMonth = $TimeParts[3]; # 1-31
    $Month      = $TimeParts[4]; # 0-11
    $Year       = $TimeParts[5]; # Years since 1900
    $DayOfWeek  = $TimeParts[6]; # 0:Sun 1:Mon 2:Tue 3:Wed 4:Thu 5:Fri 6:Sat
    $DayOfYear  = $TimeParts[7]; # 1-366
    

### localtime[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-221)]

Converts a timestamp to local time
    
    
    @TimeParts = localtime(); 
    @TimeParts = localtime($Time); 
    
    
    
    $Seconds    = $TimeParts[0]; # 0-59 
    $Minutes    = $TimeParts[1]; # 0-59
    $Hours      = $TimeParts[2]; # 0-23
    $DayOfMonth = $TimeParts[3]; # 1-31
    $Month      = $TimeParts[4]; # 0-11
    $Year       = $TimeParts[5]; # Years since 1900
    $DayOfWeek  = $TimeParts[6]; # 0:Sun 1:Mon 2:Tue 3:Wed 4:Thu 5:Fri 6:Sat
    $DayOfYear  = $TimeParts[7]; # 1-366
    

### time[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-222)]
    
    
    $Time = time();
    

Returns number of seconds since an epoch (which is system-dependant, but may be Jan 1 1970)

See also [Time::Hires](/w/index.php?title=Perl_Programming/Time::Hires&action=edit&redlink=1)

### times[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-223)]
    
    
    @CPUTimes = times();
    $UserTimeForProcess    = $CPUTimes[0];
    $SystemTimeForProcess  = $CPUTimes[1];
    $UserTimeForChildren   = $CPUTimes[2];
    $SystemTimeForChildren = $CPUTimes[3];
    

## Functions that reverse each other[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-224)]

Some functions in perl reverse or otherwise cancel the effect of each other, so running a string through both of them will produce the same output as the input, for example
    
    
    print ord(chr(1));
    

will echo `1` to standard output,

`ord()` will convert a character to its number in the character set, while `chr()` will convert a number to its corresponding character, therefore

in the same way that ![\\sqrt{x^2} = x](//upload.wikimedia.org/math/b/b/d/bbd79cf326fe94290894fbeb26a4bef3.png) and ![\\sqrt{x}^2 = x](//upload.wikimedia.org/math/6/8/7/68727c1db6d65066e8b44e242d7892e9.png) in [Mathematics](//en.wikipedia.org/wiki/Mathematics) (assuming x is non-negative), `ord(chr(1)) = 1` and `chr(ord(1)) = 1` in Perl.

List of functions that reverse each other:

  * `lc()` and `uc()`
  * `lcfirst()` and `ucfirst()`
  * `ord()` and `chr()`
  * `join()` and `split()`
  * `push()` and `pop()`
  * `unshift()` and `shift()`

  


  
These are a set of eight exercises that can be used to test your ability to write Perl programs. In some cases, these exercises might include material not covered from the textbook; in those cases, you may have to consult your platform documentation to identify a necessary function or otherwise implement one yourself.

  * [Exercise 1](/wiki/Perl_Programming/Exercise_1)
  * [Exercise 2](/wiki/Perl_Programming/Exercise_2)
  * [Exercise 3](/wiki/Perl_Programming/Exercise_3)
  * [Exercise 4](/wiki/Perl_Programming/Exercise_4)
  * [Exercise 5](/wiki/Perl_Programming/Exercise_5)
  * [Exercise 6](/wiki/Perl_Programming/Exercise_6)
  * [Exercise 7](/wiki/Perl_Programming/Exercise_7)
  * [Exercise 8](/wiki/Perl_Programming/Exercise_8)

  


## Section 2: In-depth Perl ideas[[edit](/w/index.php?title=Perl_Programming/Print_version&action=edit&section=2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Perl_Programming/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

  * <http://perldoc.perl.org/perlstyle.html>

  


## Introduction[[edit](/w/index.php?title=Perl_Programming/References_and_Data_Structures&action=edit&section=T-1)]

So you've been plodding along with your perl scripts, fiddling with arrays and hashes and suddenly you realize that you would like to pass a function to another function depending on the data you encounter, or perhaps you would like to get back a hash when you look up an array index. References are the thing for you, allowing you to build and pass around ever more complex data structures.

## Referencing and Dereferencing Syntax[[edit](/w/index.php?title=Perl_Programming/References_and_Data_Structures&action=edit&section=T-2)]
    
    
    my $nightmare = "clowns";
    my $ref = \$nightmare;
    print "I laugh in the face of " . ${$ref} . "\n";
    

Output should be _I laugh in the face of clowns_.

The curly brackets are optional, but generally recommended.

## External links[[edit](/w/index.php?title=Perl_Programming/References_and_Data_Structures&action=edit&section=T-3)]

  * <http://perldoc.perl.org/perlref.html>
  * <http://perldoc.perl.org/perlreftut.html>

  


  
Regular expressions are tools for complex searching of text, considered one of the most powerful aspects of the Perl language. A regular expression can be as simple as just the text you want to find, or it can include wildcards, logic, and even sub-programs.

To use regular expressions in perl, use the =~ operator to bind a variable containing your text to the regular expression:
    
    
    $Haystack =~ /needle/;
    

This returns 1 if "needle" is contained within $HayStack, or 0 otherwise.
    
    
    $Haystack =~ /needle/i;    # The i means "case-insensitive"
    
    
    
    $Haystack =~ /(needle|pin)/;  # Either/Or statements
    
    
    
    $Haystack =~ /needle \d/;     # "needle 0" to "needle 9"
    

  
Regular expression can also be used to modify strings. You can search and replace complex patterns by using the regex format s///
    
    
     $msg = "perl is ok";
     $msg =~ s/ok/awesome/;           # search for the word "ok" and replace it with "awesome"
     ($msg is now "perl is awesome")
    

  


  


### Match a string[[edit](/w/index.php?title=Perl_Programming/Regular_Expression_Operators&action=edit&section=T-1)]
    
    
    # Shorthand form uses // to quote the regular expression
    $Text =~ /search words/;
    
    
    
    # The m function allows you to use your choice of quote marks
    $Text =~ m|search words|;
    $Text =~ m{search words};
    $Text =~ m<search words>;
    $Text =~ m#search words#;
    

  


### Split a string into parts[[edit](/w/index.php?title=Perl_Programming/Regular_Expression_Operators&action=edit&section=T-2)]
    
    
    # The split function allows you to split a string wherever a regular expression is matched
    @ArrayOfParts = split( /,/, $Text);     # Splits wherever a comma is found
    @ArrayOfParts = split( /\s+/, $Text);   # Splits where whitespace is found
    @ArrayOfParts = split( /,\s*/, $Text);  # Comma followed by optional whitespace
    @ArrayOfParts = split( /\n/, $Text);    # Newline marks where to split
    

  


### Search and replace a string[[edit](/w/index.php?title=Perl_Programming/Regular_Expression_Operators&action=edit&section=T-3)]
    
    
    # The s function allows you to search and replace within a string. s(ubstitute)
    $Text =~ s/search for/replace with/;
    $Text =~ s|search for|replace with|;
    $Text =~ s{search for}{replace with};
    
    
    
    # Putting a g (global) at the end, means it replaces all occurances and not just the first
    $Text =~ s/search for/replace with/g;
    
    
    
    # As with everything, putting an i (insensitive) at the end ignores the differences between
    # uppercase and lowercase.
    Use Locale;
    $Text =~ s/search for/replace with/i;
    

  


### Extracting values from a string[[edit](/w/index.php?title=Perl_Programming/Regular_Expression_Operators&action=edit&section=T-4)]
    
    
    # This function sets the variables $1, $2, $3 ... 
    #   to the information that it has extracted from a string.
    
    $Text =~ m/before(.*)after/;
    # So, if $Text was "beforeHelloafter", $1 is now "Hello"
      
    $Text =~ m/bef(.*)bet(.*)aft/;
    # This time, if $Text was "befOnebetTwoaft", $1 is now "One" and $2 is "Two"
    
    
    
    # It can also be used to extract certain kind of information.
    $Text =~ m|([^=]*)=(\d*)|;
      
    #If $Text was "id=889", $1 now equals "id" and $2 equals 889.
    

  


### Regular Expressions with Perl Examples[[edit](/w/index.php?title=Perl_Programming/Regular_Expressions_Reference&action=edit&section=T-1)]

Metacharacter Description Example  
Note that all the if statements return a TRUE value

`.`
Matches an arbitrary character, but not a newline.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/...../) {
    print "$string1 has length >= 5\n";
    }
    

`( )`
Groups a series of pattern elements to a single element. When you match a pattern within parentheses, you can use any of $1, $2, ... $9 later to refer to the previously matched pattern.

**Program:**
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/(H..).(o..)/) {
    print "We matched '$1' and '$2'\n";
    }
    

**Output:**
    
    
    We matched 'Hel' and 'o W';
    

`+`
Matches the preceding pattern element one or more times.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/l+/) {
    print "There are one or more consecutive l's in $string1\n";
    }
    

`?`
Matches zero or one times.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/H.?e/) {
    print "There is an 'H' and a 'e' seperated by ";
    print "0-1 characters (Ex: He Hoe)\n";
    }
    

`?`
Matches the *, +, or {M,N}'d regexp that comes before as few times as possible.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/(l+?o)/) {
    print "The non-greedy match with one or more 'l'
    print "followed by an 'o' is 'lo', not 'llo'.\n";
    }
    

`*`
Matches zero or more times.
    
    
    $string1 = "Hello World\n";
    if ($string =~ m/el*o/) {
    print "There is a 'e' followed by zero to many";
    print "'l' followed by 'o' (eo, elo, ello, elllo)\n";
    }
    

`{M,N}`
Denotes the minimum M and the maximum N match count.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/l{1,2}/) {
    print "There exists a substring with at least 1";
    print "and at most 2 l's in $string1\n";
    }
    

`[...]`
Denotes a set of possible matches.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/[aeiou]+/) {
    print "$string1 contains a one or more";
    print "vowels\n";
    }
    

`[^...]`
Matches any character not in the square brackets.
    
    
    $string = "Sky.";
    if (String =~ /[^aeiou]/) {
    print "$string doesn't contain any vowels";
    }
    

`|`
Matches one of the left or right operand.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/(Hello|Hi)/) {
    print "Hello or Hi is ";
    print "contained in $string1";
    }
    

`\b`
Matches a word boundary.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/ello?\b/) {
    print "There is a word that ends with";
    print " 'ello'\n";
    } else {
    print "There are no words that end with";
    print "'ello'\n";
    }
    

`\w`
Matches alphanumeric, including "_".
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/\w/) {
    print "There is at least one alpha-";
    print "numeric char in $string1 (A-Z, a-z, 0-9, _)\n";
    }
    

`\W`
Matches a non-alphanumeric character.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/\W/) {
    print "The space between Hello and ";
    print "World is not alphanumeric\n";
    }
    

`\s`
Matches a whitespace character (space, tab, newline, formfeed)
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/\s.*\s/) {
    print "There are TWO whitespace ";
    print "characters seperated by other characters in $string1";
    }
    

`\S`
Matches anything BUT a whitespace.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/\S.*\S/) {
    print "There are TWO non-whitespace ";
    print "characters seperated by other characters in $string1";
    }
    

`\d`
Matches a digit, same as [0-9].
    
    
    $string1 = "99 bottles of beer on the wall.";
    if ($string1 =~ m/(\d+)/) {
    print "$1 is the first number in '$string1'\n";
    }
    '''Output:'''
    99 is the first number in '99 bottles of beer on the wall.'
    

`\D`
Matches a non-digit.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/\D/) {
    print "There is at least one character in $string1";
    print "that is not a digit.\n";
    }
    

`^`
Matches the beginning of a line or string.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/^He/) {
    print "$string1 starts with the characters 'He'\n";
    }
    

$
Matches the end of a line or string.
    
    
    $string1 = "Hello World\n";
    if ($string1 =~ m/rld$/) {
    print "$string1 is a line or string";
    print "that ends with 'rld'\n";
    }
    

  


## Overview[[edit](/w/index.php?title=Perl_Programming/Code_Reuse_\(Modules\)&action=edit&section=T-1)]

Perl modules (Files that end with the pm extension) are files of perl code that can be reused from program to program. There is an online repository of perl modules called CPAN (Comprehensive Perl Archive Network) at <http://cpan.org>. Many of these modules come standard with Perl, but others must be installed as needed.

There are thousands of perl modules that do everything from creating a temporary file to calling Amazon web services. These modules can make it easy to quickly write your application if you know how to find, install, and use the appropriate Perl modules. If you are thinking of writing your own Perl module, the best thing to do is to first search at <http://Search.cpan.org> to make sure you are not about to reinvent the wheel.

There are two major styles of Perl modules:

  1. Object-Oriented
  2. Functional

Some perl modules use both approaches.

To use an object-oriented Perl module you would do something like this:
    
    
    use Foo;
    my $foo = Foo->new();
    print $foo->bar;  #call Foo's bar method and print the output.
    

A functional perl module might get used like this:
    
    
    use Foo qw/bar/; # Import the name of the subroutine you want to use.
    print bar();
    

### How to install a Perl module[[edit](/w/index.php?title=Perl_Programming/Code_Reuse_\(Modules\)&action=edit&section=T-2)]

Find the perl module you want at <http://cpan.org>, and download the gzipped file. Untar and unzip the file:
    
    
    tar -zxvf MyModule.tgz
    

Then cd into the directory, and follow the instructions in the README or INSTALL file.

You can also use a command-line program called cpan, if you have it installed:
    
    
    sudo cpan -imt Module::I::Want
    

### To Write your own Perl Module[[edit](/w/index.php?title=Perl_Programming/Code_Reuse_\(Modules\)&action=edit&section=T-3)]

Perl modules differ from perl scripts in two key and simple ways. Instead of starting the module with "#!/path/to/perl", you start the file with the following:
    
    
    package My::Module::Name;
    

You need to end the module with a true value, so the common practice is to do this at the end of the file:
    
    
    1;
    

The following is a valid perl module:
    
    
    package My::Module::Name;
    
    1;
    

#### Example[[edit](/w/index.php?title=Perl_Programming/Code_Reuse_\(Modules\)&action=edit&section=T-4)]

We create a new file called ExampleModule.pm, and in it have the following code:
    
    
    package ExampleModule;
    use strict;
    use base "Exporter";
    our @EXPORT = qw/hello_world/;
    
    sub hello_world
    {
       print "hello, world!\n";
    }
    
    1;
    

We can test to see if the syntax is valid by running:
    
    
    perl -c ExampleModule.pm
    

It will print out "ExampleModule.pm syntax OK" if all is well. Otherwise, you can debug using the messages that are printed out.

Now we can use it in a script to see if it works:
    
    
    #!/usr/bin/perl
    
    use ExampleModule;
    
    hello_world();
    
    exit;
    

Voilá! You have made a perl module.

### Create a CPAN-style Perl module[[edit](/w/index.php?title=Perl_Programming/Code_Reuse_\(Modules\)&action=edit&section=T-5)]

CPAN-style modules have test suites and a way to build the module into the perl library.

Download and install: Module::Starter from CPAN. Once this is installed, there will be a program called module-starter in your path. To create a new module, do the following from the command line:
    
    
    module-starter --module=My::Module::Name, My::Other::Module::Name, --author="My Name" --email="myemail@gmail.com"
    

It will then create a set of directories for you, including some shell module files with starter POD documentation. The perl modules will be inside the lib directory inside the directory that is created. These are the files to edit. You can put your tests for the modules into the "t" directory. To install and build the module, you do the following:
    
    
    >perl Makefile.PL
    >make
    >make test
    >sudo make install
    

  


  
When Perl was initially developed there was no support at all for Object Orientated (OO) programming. Since Perl 5 OO has been added using the concept of Perl packages (namespaces), an operator called bless, some magic variables (@ISA, AUTOLOAD, UNIVERSAL), the `->` and some strong conventions for supporting inheritance and encapsulation.

An object is created using the `package` keyword. All subroutines declared in that package become object or class methods.

A class instance is created by calling a constructor method which must be provided by the class, by convention this method is called new()

Let's see this constructor.
    
    
    package Object;
    
    sub new {
      return bless {}, shift;
    }
    
    sub setA {
      my $self = shift;
      my $a = shift;
      $self->{a}=$a;
    }
    
    sub getA {
      my $self = shift;
      return $self->{a};
    }
    

Client code can use this class something like this.
    
    
    my $o = Object->new;
    $o->setA(10);
    print $o->getA;
    

This code prints 10.

Let's look at the `new` contructor in a little more detail:

The first thing is that when a subroutine is called using the -> notation a new argument is pre-pended to the argument list. It is a string with either the name of the Package or a reference to the object (Object->new() or $o->setA. Until that makes sense you will find OO in Perl very confusing.

To use private variables in objects and have variables names check, you can use a little different approach to create objects.
    
    
    package my_class;
    use strict;
    use warnings;
    {
      # All code is enclosed in block context
    
      my %bar;  # All vars are declared as hashes
      sub new {
        my $class = shift;
        my $this = \do{ my $scalar }; # object is a reference to scalar (inside out object)
        bless $this, $class;
        return $this;
      }
    
      sub set_bar {
        my $this = shift;
        $bar{$this} = shift;
      }
    
      sub get_bar {
        my $this = shift;
        return $bar{$this};
      }
    }
    

Now you have good encapsulation - you cannot access object variables directly via $o->{bar} but only using set/get methods. It's also impossible to make mistakes in object variable names, because they are not a hash-keys but normal perl variables, needed to be declared.

We use them the same way like hash-blessed objects:
    
    
    my $o = my_class->new();
    $o->set_bar(10);
    print $o->get_bar();
    

prints 10

  


## Section 3: Interfacing Perl[[edit](/w/index.php?title=Perl_Programming/Print_version&action=edit&section=3)]

There are several GUI widget sets available as additions to perl, though the most common is probably Perl/Tk.

  * [Perl Tk](http://search.cpan.org/dist/Tk/) (sometimes pTk or ptk) is a collection of modules and code which attempts to wed the simple Tk widget set to perl 5.
  * [Tcl::Tk](http://search.cpan.org/dist/Tcl-Tk/) same as perlTk, but uses existing Tcl/Tk via Tcl, so allowing Tcl widgets
  * [Tkx](http://search.cpan.org/dist/Tkx/) a different, lightweight, access to Tk via Tcl.
  * [Gtk](http://search.cpan.org/dist/Gtk/) uses Gtk+, the Gimp Toolkit.
  * [Gtk2](http://search.cpan.org/dist/Gtk2/) uses Gtk+ 2.x.
  * [Gtk3](http://search.cpan.org/dist/Gtk3/) uses Gtk+ 3.x.
  * [Qt](http://search.cpan.org/dist/qt/) uses the Qt toolkit.
  * [Wx](http://search.cpan.org/dist/Wx/) uses the platform independent wxWidgets toolkit.
  * [Prima](http://search.cpan.org/~karasik/Prima/Prima.pm) uses its own toolkit.

## Links[[edit](/w/index.php?title=Perl_Programming/GUI_Programming&action=edit&section=T-1)]

[The comp.lang.perl.tk FAQ](http://w4.lns.cornell.edu/~pvhp/ptk/ptkFAQ.html)

  
A huge collection of freely usable perl modules, ranging from advanced mathematics to database connectivity, networking and more, can be downloaded from a network of sites called CPAN. Most or all of the software on CPAN is also available under either the Artistic License, the GPL, or both. CPAN.pm is also the name of the perl module that downloads and installs other perl modules from one of the CPAN mirror sites; such installations can be done with interactive prompts, or can be fully automated.

[Look for modules on CPAN](http://search.cpan.org/)

## Installing modules[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-1)]

### With ActivePerl (Windows systems)[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-2)]

From a command-line, type the command
    
    
    ppm
    

This will give you a "Perl Package Manager" prompt, which allows you to download and install modules from the internet. For example, to install the Time::HiRes module, type:
    
    
    search time::hires
    

That will give you a list of modules which match your search query. Once you know the module is available and what its exact name is, you can install the module with:
    
    
    install Time::HiRes
    

### With Perl[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-3)]

If you're using a normal version of Perl, the way to activate the package manager is this:
    
    
    perl -MCPAN -e shell;
    

This will load the CPAN module, and let you search for, download, install, and manage the modules on your computer the same as PPM.

### With Perl (cpanm)[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-4)]

The Perl module cpanm (CPAN Minus) is another alternative for installing modules from the CPAN library <http://search.cpan.org/~miyagawa/App-cpanminus-1.1001/lib/App/cpanminus.pm>.

cpanm can be installed and used like this on a UNIX-like system:
    
    
    curl -L "<http://cpanmin.us>" >cpanm
    chmod +x cpnam
    ./cpanm LWP::Bundle
    

One must have root privileges in order to install module in the system-wide directories, however alternatives exist such as local::lib, which allows regular users to install and use Perl modules in their home folder <http://search.cpan.org/~getty/local-lib-1.006007/lib/local/lib.pm>.

### With Strawberry Perl (Windows systems)[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-5)]

Strawberry Perl also includes the CPAN module, so you can use the command above to activate the package manager.

The start menu, however, also includes a shortcut (with the name of `"CPAN Client"`) so that you don't have to go to a command line to do so.

A number of modules are already included in Strawberry Perl, beyond what comes with a normal version of Perl, or what comes with ActivePerl, so you may wish to check if the module you want is already installed before you start the CPAN client.

## Using a module in your program[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-6)]

To incorporate a module into your program, use the Use keyword:
    
    
    use Time::HiRes;
    

You can supply an optional list of the functions you want to use from this module, if you're worried that some of the function names in the module are too similar to functions you're already using:
    
    
    use Time::Hires qw(time gmtime);
    

With that done, you can simply use the supplied functions as normal. Most modules have example programs within their documentation, and the best way to start using a module is to copy and adapt one of the example programs.

## Finding documentation[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-7)]

The documentation for each module is installed in your documentation directory when you get a new module, or you can browse documentation on [search.cpan.org](http://search.cpan.org/) and [perldoc.perl.org](http://perldoc.perl.org/).

### Unix systems[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-8)]

On Unix systems, the documentation is usually installed as _man_ pages in section 3p, so that the command below will work:
    
    
    man 3p Module::Name
    

`perldoc Module::Name` will also work.

If you want documentation that is browseable in a web browser, you can install Perldoc::Server as noted below.

### Windows systems running ActivePerl[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-9)]

Module documentation is installed as HTML files in ActivePerl. To find those files, try looking in some of the following directories:

  * C:\Perl\html\lib
  * C:\Perl\html\site\lib

If you're having real trouble finding the HTML documentation for a module, you may be able to read the *.pm perl file yourself for POD comments, or use the pod2html tool yourself to generate the HTML file.

### Windows systems running Strawberry Perl[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-10)]

Strawberry Perl does not install module documentation as either manpages or html files. Instead, you can run the perldoc command to display module documentation.
    
    
    perldoc Module::Name
    

You can also use `Perldoc::Server` to display module documentation, as illustrated below.

### Perldoc::Server[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-11)]

The Perldoc::Server module (which can be installed via CPAN) will provide a local server that will display html files "on the fly" from Perl's documentation and the documentation for installed modules. Install it, and the command
    
    
    perldoc-server
    

will be in your path. Run it, and then browse to <http://localhost:7375/> in your web browser to see the documentation.

Note that the perldoc-server command must be running to provide the documentation using this method.

## Contributing your own modules to CPAN[[edit](/w/index.php?title=Perl_Programming/CPAN&action=edit&section=T-12)]

In the event that a module you need isn't available on CPAN, the usual answer is to write the module yourself and add it to CPAN. That way, nobody else needs to waste time creating the same functionality that you're already written.

See [How to contribute modules to CPAN](http://cpan.org/misc/cpan-faq.html#How_contribute_modules)

  


## Section 4: CGI and Apache[[edit](/w/index.php?title=Perl_Programming/Print_version&action=edit&section=4)]

Assuming you already have an Apache server (or compatible server that reads a shebang! line - more on this in a moment) and a perl installation running, it is fairly simple to start running a perl program on the internet.

First, you must have some way to access the program. Here we will deal with form data and submission, so we will assume that your form code in HTML has a property saying ACTION="_programname.cgi_".

## The Initial Setup[[edit](/w/index.php?title=Perl_Programming/CGI&action=edit&section=T-1)]

CGI scripts begin like any other Perl program, with a "shebang", something like:
    
    
    #!/usr/bin/perl
    

(see [Perl Programming/First Programs](/wiki/Perl_Programming/First_Programs) for details)

Next load the CGI module:
    
    
    use CGI;
    

The CGI module makes our work easy because it has pre-programmed functions in it for internet use. Then we must create a handle to CGI - something that allows us to access the functions. We do this with:
    
    
    my $query = CGI->new();
    

This means that the variable $query is loading the CGI standard functions.

Now that our program is setup using the CGI module, it should look something like this:
    
    
    #!/usr/bin/perl
    
    use CGI;
    my $query = CGI->new();
    

So we have a program, it just doesn't do anything yet, and will actually cause a server error because the server has no output or any idea of what kind of output to display even if it had some.

## Retrieving Information[[edit](/w/index.php?title=Perl_Programming/CGI&action=edit&section=T-2)]

Before we tell the server what to do with our output, we need to retrieve our input. To do this, we use the $query variable we declared earlier. Say we have a text box in the form that is named "Name" and we want to find out what was typed there. To do this, we put the following line of code in our program:
    
    
    my $Name = $query->param('Name');
    

Now, this line of code introduces us to the param() function (for "parameter"). The param() function can do quite a few handy tricks for us, all of them nice ways to retrieve our variables. It processes all of the http coding so all we get is a nice clean variable. Another note, you aren't required to use $Name as your variable. It's simply more convenient to only remember one name for the same variable. Still, use what's best for you.

## Output[[edit](/w/index.php?title=Perl_Programming/CGI&action=edit&section=T-3)]

Now we must create our header information. CGI even makes THIS easy for us. Instead of memorizing a bunch of mime-type declarations (which you may do as well), all we must do is type:
    
    
    print $query->header();
    

and it prints out our header information. A note about headers. Inside the parenthesis, we may specify parameters like cookies to send to the user's browser. This becomes very useful later. For now we will just stick to the headers.

The last thing you need to put (though the program will run, displaying a blank page without it) is some output. Let's simply have it display the user's name back to him/her. This would look like.
    
    
    print " You said your name was: $Name";
    

## The Finished Code[[edit](/w/index.php?title=Perl_Programming/CGI&action=edit&section=T-4)]

So we now have a complete program that processes a form, using only 6 lines of code. Isn't Perl great? The final code looks like this:
    
    
    #!/usr/bin/perl
    
    use CGI;
    my $query = new CGI;
    
    my $Name = $query->param('Name');
    
    print $query->header();
     
    print "You said your name was: ", $query->escapeHTML($Name);
    

When put into perspective, we can see that the $query variable is a very important connection to the CGI module as it tells perl that the function you are referencing belongs to CGI; Again, you may declare any variable name in the place of $query so long as you are consistent, though you will find many developers use $query or $q. Also note the use of the escapeHTML method to avoid any [HTML injection](//en.wikipedia.org/wiki/en:HTML_injection) problems.

Final note. Make sure you change /usr/bin/perl to the path of your perl installation (assuming that is not it) so perl will execute properly

## Frameworks[[edit](/w/index.php?title=Perl_Programming/CGI&action=edit&section=T-5)]

There are a number of CGI frameworks to help with common CGI programming tasks:

  * [CGI::Application](http://cgi-app.org/index.cgi)
  * [Catalyst](http://www.catalystframework.org/)

  
**mod_perl** is an optional module for Apache. It embeds a [Perl](/wiki/Perl) interpreter into the Apache server, so that dynamic content produced by Perl scripts can be served in response to incoming requests, without the significant overhead of re-launching the Perl interpreter for each request. As Lincoln D. Stein defined mod_perl in his words:

> mod_perl is more than CGI scripting on steroids. It is a whole new way to create dynamic content by utilizing the full power of the Apache web server to create stateful sessions, customized user authentication systems, smart proxies and much more. Yet, magically, your old CGI scripts will continue to work and work very fast indeed. With mod_perl you give up nothing and gain so much!

mod_perl can emulate a [Common Gateway Interface](/wiki/Common_Gateway_Interface) (CGI) environment, so that existing Perl CGI scripts can benefit from the performance boost without having to be re-written.

Unlike CGI (and most other web application environments), mod_perl provides complete access to the Apache API, allowing programmers to write handlers for all phases in the Apache request cycle, manipulate Apache's internal tables and state mechanisms, share data between Apache processes or threads, alter or extend the Apache configuration file parser, and add Perl code to the configuration file itself, among other things.

## External links[[edit](/w/index.php?title=Apache/mod_perl&action=edit&section=T-1)]

  * [Main website](http://perl.apache.org/)
  * [Why mod_perl?](http://www.perl.com/pub/a/2002/02/26/whatismodperl.html)
  * [The magic of mod_perl](http://www.revsys.com/writings/modperl.html)
  * [Writing Apache Modules with Perl and C](http://www.modperl.com/)
  * [The mod_perl Developer's Cookbook](http://www.modperlcookbook.org/)
  * [Practical mod_perl](http://modperlbook.org/)
  * [mod_perl2 User's Guide](http://modperl2book.org/)

  


## The Initial Setup[[edit](/w/index.php?title=Perl_Programming/HTML::Mason&action=edit&section=T-1)]

## Retrieving Information[[edit](/w/index.php?title=Perl_Programming/HTML::Mason&action=edit&section=T-2)]

## Output[[edit](/w/index.php?title=Perl_Programming/HTML::Mason&action=edit&section=T-3)]

## The Finished Code[[edit](/w/index.php?title=Perl_Programming/HTML::Mason&action=edit&section=T-4)]

## Section 5: Perl and beyond[[edit](/w/index.php?title=Perl_Programming/Print_version&action=edit&section=5)]

[Perl 6](//en.wikipedia.org/wiki/Perl_6) will separate parsing and compilation and runtime, making the virtual machine more attractive to developers looking to port other languages to the architecture.

[Parrot](//en.wikipedia.org/wiki/Parrot_virtual_machine) is the Perl6 runtime, and can be programmed at a low level in Parrot assembly language. Parrot exists in a limited form as of June, 2003, and a small number of languages (Jako, Cola, Basic, Forth and a subset of Perl 6) exist simply to be 'compiled' down to Parrot assembly language opcodes.

While Perl6 is being developed, the best way to stay informed about what's happening is to keep an eye on the front-page of <http://www.perl.com/> and look out for articles. As each new language-feature is being developed, it gets discussed on Perl.com and the associated mailing lists, so subscribe to some of those to see glimpses of what Perl6 will be like.

  


  


### Obfuscated code[[edit](/w/index.php?title=Perl_Programming/Humour&action=edit&section=T-1)]

Some people claim Perl stands for 'Pathologically Eclectic Rubbish Lister' due to the high use of meaningful punctuation characters in the language syntax.

In common with [C programming language](/wiki/Programming:C), obfuscated code competitions are an interesting feature of the Perl culture. Similar to obfuscated code but with a different purpose, Perl Poetry is the practice of writing poems that can actually be compiled by perl. This practice is fairly unique to Perl, due to the large number of regular English words used in the language. New poems can regularly be seen in [the Perl Poetry section of perlmonks.org](http://www.perlmonks.org/index.pl?node=Perl%20Poetry).

### Just another Perl Hacker[[edit](/w/index.php?title=Perl_Programming/Humour&action=edit&section=T-2)]

Your mission, should you choose to accept it, is to write a one-liner perl script which displays the phrase "Just another Perl hacker," (including the comma, and capitalization as shown). If successful, you win the right to use it as an email signature identifying yourself as a Perl hacker. Entries will be judged on how smart-ass the code is. Around 100 of the first JAPHs and some funky obfu Perl can be seen [on CPAN](http://www.cpan.org/misc/japh).

### Acme[[edit](/w/index.php?title=Perl_Programming/Humour&action=edit&section=T-3)]

There's always a place in Perl for odd modules, and one such place is the Acme:: namespace. If you have a module which knows how long a piece of string is, or one which converts your perl script into an image of Che Guevara, post it here.

### Golf[[edit](/w/index.php?title=Perl_Programming/Humour&action=edit&section=T-4)]

Perl is a very compact language. So compact, that some have even create a game around perl's terseness called perlgolf. In perlgolf, you are given a problem to solve. You must solve it in the fewest number of characters possible. A scorecard is kept, and after 18 "holes", a winner is announced.

  


## Section 6: Sample code[[edit](/w/index.php?title=Perl_Programming/Print_version&action=edit&section=6)]

This script counts the number of occurences of each letter in a file:
    
    
    #!/usr/bin/perl
    # always enable compiler warnings, as they may highlight potential trouble
    use warnings;
    # let's ask the compiler to be more strict, make sure we declare our variables etc.
    use strict;
     
    # This statement prompts the user for a filename to read from.
    print "What file would you like to read from?\n";
     
    # This statement assigns whatever is given on the standard input(usually your keyboard) to a scalar
    # variable named $filename and removes the newline character that is included by default.
    chomp (my $filename = <STDIN>);
     
    # This line opens the file referred to in $filename for input via a lexical filehandle
    # stored in a scalar variable named "$file".
    open my $file, "<", $filename or die "Can't open '$filename' for reading: $^E\n";
     
    # This loop goes through each line of the file, splits the line into separate characters and
    # increments the number of occurrences of each letter using a hash called "%chars".
     
    my %chars;
    while(<$file>) {
        $_ = lc($_); # convert everything to lowercase
        my @characters = split (//, $_);  # Store list of characters in an array
        foreach (@characters) {
            if(/\w/) {                    # Ignore all characters except letters and numbers
                $chars{$_}++;
            }
        }
    }
    close $file;
     
    # This loop goes through each letter in the %chars hash and prints a report informing the user of
    # how many times each letter occurred.
     
    foreach my $key (sort keys %chars) {
        if($chars{$key} == 1) {
            print "$key appeared once.\n";
        } else {
            print "$key appeared $chars{$key} times.\n";
        }
    }
    

If you executed this program on a file containing the sentence "The quick, brown fox jumps over the lazy dog.", you would see this as output:
    
    
    a appeared once.
    b appeared once.
    c appeared once.
    d appeared once.
    e appeared 3 times.
    f appeared once.
    g appeared once.
    h appeared 2 times.
    i appeared once.
    j appeared once.
    k appeared once.
    l appeared once.
    m appeared once.
    n appeared once.
    o appeared 4 times.
    p appeared once.
    q appeared once.
    r appeared 2 times.
    s appeared once.
    t appeared 2 times.
    u appeared 2 times.
    v appeared once.
    w appeared once.
    x appeared once.
    y appeared once.
    z appeared once.
    

Hi-Lo: A simple game written in perl that asks you for a guess between 1 and 100 and tells you if you are too high or low.
    
    
    use warnings;
    use strict;
     
    $| = 1;
     
    print "Enter number of games to play: ";
    chomp(my $Num_Games = <STDIN>);
     
    my $Num_Guesses = 0;
    for my $gameno (1 .. $Num_Games) {
            my $number = 1 + int rand 100;
     
            my $guess;
            do {
                    print "Enter guess from 1 to 100: ";
                    chomp($guess = <STDIN>);
                    ++$Num_Guesses;
     
                    if ($guess < $number) {
                            print "Higher!\n";
                    } elsif ($guess > $number) {
                            print "Lower!\n";
                    }
            } until $guess == $number;
     
            print "Correct!\nAverage guesses per game: ", 
            $Num_Guesses / $gameno, "\n\n";
    }
     
    print "Games played: $Num_Games\n";
    

## Section 7: Reference[[edit](/w/index.php?title=Perl_Programming/Print_version&action=edit&section=7)]

## String functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-1)]

### chomp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-2)]

#### Action[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-3)]

Removes the last characters from a string only if they're recognized as a record separator (e.g. a newline character)

#### Returns[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-4)]

?

#### Syntax[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-5)]

chomp($String = $_);

#### Example[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-6)]
    
    
    chomp; # removes the last character from $_ if it is a record separator
    chomp(); # (same)
    chomp($String); # removes the last character from $String if it is a record separator
    

#### See Also[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-7)]

  * chop \- To remove the last character from a string

### chop[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-8)]

#### Action[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-9)]

Removes the last character from a string regardless

#### Returns[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-10)]

?

#### Syntax[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-11)]

chop($String = $_);

#### Example[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-12)]
    
    
    chop; # removes the last character from $_
    chop(); # (same)
    chop($String); # removes the last character from $String
    

#### See Also[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-13)]

  * chomp \- To remove the last character from a string if it is a record seperator

Removes the last character from a string (e.g. removes the newline characters when reading from a file)

### chr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-14)]
    
    
    print chr(65);  # Prints a capital A
    

Gets an ASCII character, given it's code

### crypt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-15)]
    
    
    # One-way hash function
    my $HashedWord = crypt($Word, $Salt);
    

(See also [MD5](http://search.cpan.org/~gaas/MD5-2.03/MD5.pm) )

The salt string needs only be 2 characters long, and provides a way of randomising the hash, such that the same word can produce several different hashes, if used with different values of $Salt;!

### hex[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-16)]
    
    
    print hex(11);  # Prints B
    

Converts a number to hexadecimal

Other way around - converts hex to number: print hex(11); # prints 17

you can use

print sprintf("%X",11); # Prints B

### index[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-17)]

Search for one string within another. (see _rindex_ to search from end-to-start)
    
    
    $Result = index($Haystack, $Needle);
    $Result = index($Haystack, $Needle, $StartPosition);
    
    index("Some text", "bleh"); # Returns -1 (not found)
    index("Some text", "Some"); # Returns 0 (first character)
    index("Some text", "text"); # Returns 5 (sixth character)
    

The special variable $[ always gets added to the return value, but $[ is normally 0, and the manual recommends leaving it at 0.

### lc[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-18)]
    
    
    $Lowercase = lc($String);
    

Converts a string to lower-case

### lcfirst[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-19)]

Converts the first character of a string to lowercase

### length[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-20)]
    
    
    print "String is " . length($String) . " characters long\n";
    

Returns the length of a string

### oct[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-21)]
    
    
    print oct(8);  # Prints 10
    

Converts a number to octal

### ord[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-22)]

Converts a character to its number.
    
    
    print ord("A"); # prints 65
    

### pack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-23)]

Takes a list and converts it into a string using a supplied set of rules.
    
    
    my $String = pack($Template, @ListOfNumbers);
    my $String = pack("CCCC",65,66,67,68); # Result: "ABCD"
    

$Template can be made up of:
    
    
       a       A string with arbitrary binary data, will be null padded.
       A    An ascii string, will be space padded.
       Z    A null terminated (asciz) string, will be null padded.
    
    
    
       b       A bit string (ascending bit order inside each byte, like vec()).
       B    A bit string (descending bit order inside each byte).
       h    A hex string (low nybble first).
       H    A hex string (high nybble first).
    
    
    
       c       A signed char value.
       C    An unsigned char value.  Only does bytes.  See U for Unicode.
    
    
    
       s       A signed short value.
       S    An unsigned short value. (Exactly 16 bits unless you use the ! suffix)
    
    
    
       i       A signed integer value.
       I    An unsigned integer value. (At least 32 bits wide, machine-dependant)
    
    
    
       l       A signed long value.
       L    An unsigned long value. (Exactly 32 bits unless you use the ! suffix)
    
    
    
       n       An unsigned short in "network" (big-endian) order.
       N    An unsigned long in "network" (big-endian) order.
       v    An unsigned short in "VAX" (little-endian) order.
       V    An unsigned long in "VAX" (little-endian) order. (Exactly 16 bits and 32 bits respectively)
    
    
    
       q       A signed quad (64-bit) value.
       Q    An unsigned quad value. (Only available if your system supports 64-bit integers and Perl has been compiled to support them)
    
    
    
       f       A single-precision float in the native format.
       d    A double-precision float in the native format.
    
    
    
       p       A pointer to a null-terminated string.
       P    A pointer to a structure (fixed-length string).
    
    
    
       u       A uuencoded string.
       U    A Unicode character number.  Encodes to UTF-8 internally.
    
    
    
       w       A BER compressed integer.  Its bytes represent an unsigned integer in base 128, most significant digit first, with as few digits as possible.  Bit eight (the high bit) is set on each byte except the last.
    
    
    
       x       A null byte.
       X    Back up a byte.
       @    Null fill to absolute position.  
    

Each letter may optionally be followed by a number giving a repeat count.

The integer types s, S, l, and L may be immediately followed by a ! suffix to signify native shorts or longs

### reverse[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-24)]

Reverses a string (in scalar context) or a list (in list context):
    
    
    my @ReversedList = reverse(@List);
    
    
    
    # As commonly seen in Perl programs:
    foreach( reverse( sort( @List )))
    {
    ...
    }
    
    
    
    my $ReversedString = reverse($String);
    
    
    
    my @List = ("One ", "two ", "three...");
    my $ReversedListAsString = reverse(@List); # Prints "...eerht owt enO"
    

### rindex[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-25)]

Search for one string within another, starting at the end of the string.
    
    
    $Result = rindex($Haystack, $Needle);
    $Result = rindex($Haystack, $Needle, $StartPosition);
    
    rindex("Some text", "bleh"); # Returns -1 (not found)
    rindex("Some text", "Some"); # Returns 0 (first character)
    rindex("abbbbb", "b");       # Returns 5 (first "b" found, when starting at the end)
    

### sprintf[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-26)]

Prints a formatted string:
    
    
    my $Text = sprintf("%d / %d is %08.5f", 1, 3, 1/3); # Result: "10 / 3 is 003.33333"
    
    
    
    sprintf("Character: %c", 65); 
    sprintf("String %s", "Hello");
    sprintf("Signed integer: %d", 15);
    sprintf("Unsigned integer: %u", 15);
    sprintf("Unsigned int (in octal): %o", 15);
    sprintf("Unisgned int (in hex): %x", 15);      # Use %X to get upper-case output
    sprintf("Binary number: %b", 15);
    sprintf("Scientific notation: %e", 5000);      # Use %E to get upper-case output
    sprintf("Floating point number: %f", 1/3);     # 0.3333333
    sprintf("Floating point number: %g", 1/3);     # Decides between scientific and float.  %G is uppercase
    sprintf("Pointer: %p", $Variable);
    

Use %% to get a percent-sign.

Use %n to request the number of characters written so far, and put it into the next variable in the list. You may want to check that user-supplied formatting rules don't contain this code.
    
    
    sprintf("%02d", $Minutes);  # Forces leading zeros to make the string 2 characters long
    sprintf("%1.5f", $Number);  # Limits the number of decimal places
    

### substr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-27)]

Return part of a string (a _substring_)

Format: substr _string_ _start-position_ _length_

    _start-position_ is zero-based.
    A negative number starts from the end of the string.
    
    
    $FirstLetter   = substr($Text, 0, 1);   # First letter
    $First3Letters = substr($Text, 0, 3);   # First three letters
    $Last3Letters  = substr($Text, -3);     # Last three letters
    

You can use **substr** on the left side of an assignment statement to change part of a string. This can actually shorten or lengthen the string.
    
    
     $text = 'cat dog';
     substr ($mystring, 3, 1) = ' and ';  # $text now contains 'cat and dog'
    

### uc[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-28)]
    
    
    $Uppercase = uc($String);
    

Converts a string to upper-case

### ucfirst[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-29)]

Converts the first character of a string to uppercase

## Numeric functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-30)]

### abs[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-31)]

Returns the absolute(positive) value of a number
    
    
    $Number = abs(-100); # Returns 100;
    

### atan2[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-32)]
    
    
    # Converts cartesian(x,y) coordinates into an angle
    $Number = atan2($Y, $X);
    

### cos[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-33)]
    
    
    # Returns the cosine of an angle (radians)
    $Number = cos($Angle);  # Cosine = Adjacent/Hypotenuse
    

### exp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-34)]
    
    
    # Raises e to a specified power 
    $Number = exp(2); # Returns ![e^2](//upload.wikimedia.org/math/1/1/b/11bf4aa6706937636de8b6ebb7fc3a92.png)
    
    
    
    e ≈ 2.71828183 [more about e](//en.wikipedia.org/wiki/E_\(mathematical_constant\))
    

### hex[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-35)]
    
    
    # Interprets a string as hexidecimal, and returns its value
    $Number = hex("10"); # Returns 16
    $Number = hex("0xFF"); # Returns 255
    

### int[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-36)]

Rounds a number towards zero, returning an integer
    
    
    $Number = int(-1.6);  # Returns -1
    $Number = int(0.9);   # Returns 0
    $Number = int(28.54); # Returns 28
    

### log[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-37)]
    
    
    # Returns the natural logarithm of a number
    $Number = log(2.71828183);   # Returns 1
    $Number = exp(log($X));      # Returns $X
    $Number = log($X) / log(10); # Returns log10($X). Alternately, you can use the log10() function in the POSIX module
    $Number = log($X) / log(15); # Returns log to the base 15 of $X
    

### oct[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-38)]
    
    
    # Interprets a string as octal, and returns its value
    $Number = oct("10"); # Returns 8
    $Number = oct("21"); # Returns 17
    

### rand[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-39)]
    
    
    # Gets a random number (may automatically call srand() if that's not been done)
    $Number = rand();  # Returns a random number from 0 to 1
    $Number = int(rand(800));  # Returns a random integer from 0 to 799
    $Number = 1 + int(rand(999));  # Returns a random integer from 1 to 999
    

### sin[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-40)]
    
    
    # Returns the sine of an angle (radians)
    $Number = sin($Angle);  # Sine = Opposite/Hypotenuse
    

### sqrt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-41)]
    
    
    # Returns the square-root of a number
    $Number = sqrt(4);                  # Returns 2
    $Number = sqrt($X ** 2 + $Y ** 2);  # Returns the diagonal distance across a $X x $Y rectangle
    
    
    
    See the Math::Complex module if you need to take roots of negative numbers;
    

### srand[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-42)]
    
    
    # Seeds (sets-up) the random-number generator
    srand();
    

Version-dependant, and older versions of Perl are not guaranteed to have a good seed value. See the Math::TrulyRandom module for more possibilities. The current version of Perl uses the urandom device if it's available.

## Array functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-43)]

### pop[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-44)]
    
    
    $LastElement = pop(@MyArray);
    

Take the last element from an array

### push[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-45)]
    
    
    push(@MyArray, "Last element");
    push(@MyArray, "several", "more", "elements");
    

Push a list of elements onto the end of an array

### shift[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-46)]
    
    
    shift(@MyArray); #Delete the first element
    $FirstElement = shift(@MyArray); #Delete the first element, load it into $FirstElement instead
    

Take the first element out of an array

### splice[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-47)]
    
    
    # Removes elements from an array, optionally replacing them with a new array
    splice(@Array); # Removes all elements from array
    splice(@Array, 10); # Removes from element 10 to the end of the array
    splice(@Array, -10); # Removes the last 10 elements of the array
    splice(@Array, 0, 10); # Removes the first 10 elements of the array
    @NewArray = splice(@Array, 0, 10); # Removes the first 10 elements of the array and returns those 10 items
    splice(@Array, 0, 10, @Array2); # Replaces the first 10 elements of the array with Array2
    

### unshift[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-48)]
    
    
    unshift(@MyArray, "New element");
    unshift(@MyArray, "several", "more", "elements");
    

Add a list of elements onto the beginning of an array

## List functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-49)]

### grep[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-50)]
    
    
    # Returns a list of elements for which an expression is true
    @TextFiles = grep(/\.txt$/, @AllFiles);
    $NumberOfTextFiles = grep(/\.txt$/, @AllFiles);
    
    
    
    # Can use a block of code instead of an expression
    @TextFiles = grep({return(substr($_, -3) eq "txt");}, @AllFiles);
    

### join[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-51)]
    
    
    # Joins the items of a list into a single string
    $OneItemPerLine = join( "\n", @List);
    $EverythingBunchedTogether = join( "", @List);
    $Filename = join( "/", ($Directory, $Subdirectory, $Filename));
    

### map[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-52)]
    
    
    # Evaluates a block of code for each item in a list, and returns
    # a list of the results
    @UppercaseList = map(uc, @List);
    @Numbers = map {"Number $_"} 1..100;
    

### reverse[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-53)]
    
    
    # Reverses the order of a list
    @ReversedList = reverse(@List);
    # In scalar context, concatenates the list and then reverses the string
    $ReversedString = reverse('foo','bar','baz'); # gives 'zabraboof'
    

### sort[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-54)]
    
    
    # Sorts the elements in a list
    @AsciiSort = sort(@RandomList);
    @AsciiSort = sort @RandomList;
    foreach $Item (sort @RandomList)
      {...}
    
    
    
    # Can specify a function to decide the sort order
    @CaseInsensitiveSort = sort {uc($a) cmp uc($b)} @RandomList;
    @NumericSort = sort {$a <=> $b} @RandomList;
    @CustomSort = sort custom_function_name @RandomList;
    

### unpack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-55)]

Unpacks a string into a list - see the templates available for the pack() function for details

## Associative array functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-56)]

### delete[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-57)]
    
    
    #Remove an element from a hash
    %h = ('a'=>1, 'cow'=>'moo', 'b'=>2);
    delete $h{cow};
    # %h now contains ('a'=>1, 'b'=>2)
    

### each[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-58)]
    
    
    #Return the 'next' key/value pair (in a random order)
    while (($key, $value) = each (%hash)){
       print "$key => $value\n";
    }
    

### exists[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-59)]
    
    
     #Tests whether or not a key exists in a hash (even if the value for that key is undef)
     if (exists $hash{$key}){
        print "\%hash contains a value for key '$key'\n";
     }
    

### keys[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-60)]
    
    
     #Returns a list of all keys from the hash, in same 'random' order as each
     foreach $key (keys %hash){
        print "$key => $hash{$key}\n";
     }
    

### values[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-61)]
    
    
     #Returns a list of all values from the hash, in same 'random' order as keys
     foreach $value (values %hash){
        print "\%hash contains a value '$value'\n";
     }
    

## Input and output functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-62)]

### binmode[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-63)]

### close[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-64)]
    
    
    #closes a filehandle when it is no longer needed
    close(STDERR); #hide debugging info from the user
    

### closedir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-65)]
    
    
    # Close a directory open by opendir
    closedir(DIRHANDLE);
    
    

### dbmclose[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-66)]

### dbmopen[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-67)]

### die[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-68)]

Exits the program, printing to "STDERR" the first parameter and the current file and line. Used to trap errors.
    
    
    die "Error: $!\n" unless chdir '/';
    
    

### eof[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-69)]
    
    
    eof FILEHANDLE
    eof()
    eof
    

This function returns true if the next read on FILEHANDLE would return end-of-file, or if FILEHANDLE is not open. FILEHANDLE may be an expression whose value gives the real filehandle, or a reference to a filehandle object of some sort. An eof without an argument returns the end-of-file status for the last file read. An eof() with empty parentheses () tests the ARGV filehandle (most commonly seen as the null filehandle in <>). Therefore, inside a while (<>) loop, an eof() with parentheses will detect the end of only the last of a group of files. Use eof (without the parentheses) to test each file in a while (<>) loop. For example, the following code inserts dashes just before the last line of the last file:  

    
    
    while (<>) {
        if (eof()) {
            print "-" x 30, "\n";
        }
        print;
    }
    

On the other hand, this script resets line numbering on each input file:
    
    
    # reset line numbering on each input file
    while (<>) {
        next if /^\s*#/;        # skip comments
        print "$.\t$_";
    } continue {
        close ARGV if eof;      # Not eof()!
    }
    

Like "$" in a sed program, eof tends to show up in line number ranges. Here's a script that prints lines from /pattern/ to end of each input file:
    
    
    while (<>) {
        print if /pattern/ .. eof;
    }
    

Here, the flip-flop operator (..) evaluates the pattern match for each line. Until the pattern matches, the operator returns false. When it finally matches, the operator starts returning true, causing the lines to be printed. When the eof operator finally returns true (at the end of the file being examined), the flip-flop operator resets, and starts returning false again for the next file in @ARGV

### fileno[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-70)]

### flock[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-71)]

### format[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-72)]

### getc[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-73)]

### print[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-74)]

Prints the parameters given.

Discussed in the following sections:

    _[Digression on print_ in _Strings_ section](/wiki/Perl_Programming/Strings#Brief_Digression_from_Strings_Alone:_The_print_Function)

### printf[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-75)]

### read[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-76)]

### readdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-77)]

### rewinddir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-78)]

### seek[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-79)]

### seekdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-80)]

### select[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-81)]

### syscall[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-82)]

### sysread[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-83)]

### sysseek[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-84)]

### syswrite[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-85)]

### tell[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-86)]

### telldir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-87)]

### truncate[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-88)]

### warn[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-89)]

### write[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-90)]

## Functions for working with fixed length records[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-91)]

### pack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-92)]

See the entry for **pack** further up the page

### read[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-93)]
    
    
    # Reads data from a file-handle
    read(FILEHANDLE, $StoreDataHere, $NumberBytes);
    
    
    
    # Returns the number of bytes read
    $NumberBytesRead = read(FILEHANDLE, $StoreDataHere, $NumberBytes);
    
    
    
    # Optional offset is applied _when the data is stored_ (not when reading)
    read(FILEHANDLE, $StoreDataHere, $NumberBytes, Offset);
    

  


### syscall[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-94)]
    
    
    # Runs a system command
    syscall( $Command, $Argument1, $Argument2, $Argument3);
    
    
    
    # (maximum 14 arguments)
    $ReturnValue = syscall($Command);
    

  


### sysread[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-95)]

### syswrite[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-96)]

### unpack[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-97)]
    
    
    # See the **pack** function for details (unpack does the opposite!)
    unpack($Template, $BinaryData);
    

### vec[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-98)]

## Filesystem functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-99)]

### -X[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-100)]
    
    
    if( -r $FullFilename) // File is readable by effective uid/gid.
    if( -w  $FullFilename) // File is writable by effective uid/gid.
    if( -x  $FullFilename) // File is executable by effective uid/gid.
    if( -o  $FullFilename) // File is owned by effective uid.
    
    
    
    if( -R     $FullFilename) // File is readable by real uid/gid.
    if( -W  $FullFilename) // File is writable by real uid/gid.
    if( -X  $FullFilename) // File is executable by real uid/gid.
    if( -O  $FullFilename) // File is owned by real uid.
    
    
    
    if( -e     $FullFilename) // File exists.
    if( -z  $FullFilename) // File has zero size.
    if( -s  $FullFilename) // File has nonzero size (returns size).
    
    
    
    if( -f     $FullFilename) // File is a plain file.
    if( -d  $FullFilename) // File is a directory.
    if( -l  $FullFilename) // File is a symbolic link.
    if( -p  $FullFilename) // File is a named pipe (FIFO), or Filehandle is a pipe.
    if( -S  $FullFilename) // File is a socket.
    if( -b  $FullFilename) // File is a block special file.
    if( -c  $FullFilename) // File is a character special file.
    if( -t  $FullFilename) // Filehandle is opened to a tty.
    
    
    
    if( -u     $FullFilename) // File has setuid bit set.
    if( -g  $FullFilename) // File has setgid bit set.
    if( -k  $FullFilename) // File has sticky bit set.
    
    
    
    if( -T     $FullFilename) // File is an ASCII text file.
    if( -B  $FullFilename) // File is a "binary" file (opposite of -T).
    
    
    
    $Age = -M $FullFilename; // Age of file in days when script started.
    $Age = -A $FullFilename; // Same for access time.
    $Age = -C $FullFilename; // Same for inode change time.  
    

### chdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-101)]
    
    
    chdir $Directory;
    chdir $Directory || die("Couldn't change directory");
    

### chmod[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-102)]
    
    
    chmod 0744 $File1;
    chmod 0666 $File1, $File2, $File3;
    # 0 for octal, at the beginning of a number
    
    
    
            | Owner | Group | Others |
    Execute |   4   |   4   |   4    |
    Write   |   2   |   2   |   2    |
    Read    |   1   |   1   |   1    |
    ======--+======-+======-+======--+
    Total   |       |       |        |
    

### chown[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-103)]
    
    
    # Change the owner of a file
    chown($NewUserID, $NewGroupID, $Filename);
    chown($NewUserID, $NewGroupID, $File1, $File2, $File3);
    
    
    
    chown($NewUserID, -1, $Filename); # Leave group unchanged
    chown(-1, $NewGroupID, $Filename); # Leave user unchanged
    

### chroot[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-104)]
    
    
    chroot $NewRootDirectory;
    

Sets the root directory for the program, such that the "/" location refers to the specified directory.

Program must be running as root for this to succeed.

### fcntl[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-105)]

### glob[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-106)]
    
    
    #Expands filenames, in a shell-like way
    my @TextFiles = glob("*.txt");
    

See also File::Glob

### ioctl[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-107)]

### link[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-108)]
    
    
    # Creates a link to a file
    link($ExistingFile, $LinkLocation);
    link($ExistingFile, $LinkLocation) || die("Couldn't create link");
    

### lstat[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-109)]

Identical to stat(), except that if given file is symbolic link, stat link not the target.

### mkdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-110)]
    
    
    mkdir $Filename || die("Couldn't create directory");
    mkdir $Filename, 0777; # Make directory with particular file-permissions
    

### open[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-111)]
    
    
    open(my $FileHandle, $Filename) || die("Couldn't open file");
    open(my $fp, "<", $Filename);   # Read from file
    open(my $fp, ">", $Filename);   # Write to file
    open(my $fp, ">>", $Filename);  # Append to file
    
    
    
    open(my $fp, "<$Filename");     # Read from file
    open(my $fp, ">$Filename");     # Write to file
    open(my $fp, ">>$Filename");    # Append to file
    
    
    
    open(my $fp, "<", "./   filename with whitespace   \0");
    open(my $fp, "<", "./->filename with reserved characters\0");
    

  

    
    
    open(my $fp, "$Program |");     # Read from the output of another program
    open(my $fp, "| $Program");     # Write to the input of another program
    
    
    
    open(my $fp, "<", "-");         # Read from standard input
    open(my $fp, ">", "-");         # Write to standard output
    

  


### opendir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-112)]
    
    
    opendir(my $DirHandle, $Directory) || die("Couldn't open directory");
    while (my $Filename = readdir $DirHandle){
      # Do something with $Filename in $Directory
    }
    closedir($DirHandle);
    
    
    
    opendir(DIR, $Directory) || die("Couldn't open directory");
    foreach(readdir(DIR)){
      # Do something with $_ in $Directory
    }
    closedir(DIR);
    

### readlink[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-113)]
    
    
    # Finds the value of a symbolic link
    $LinkTarget = readlink($LinkPosition);
    

### rename[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-114)]
    
    
    rename $OldFile, $NewFile or die("Couldn't move file");
    

May work differently on non-*nix operating systems, and possibly not at all when moving between different filesystems. See [[File::Copy]] for more complicated file operations.

### rmdir[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-115)]
    
    
    rmdir $Filename || die("Couldn't remove directory");
    

### stat[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-116)]
    
    
    @FileStatistics = stat($Filename); 
    
    
    
    $DeviceNum    = $FileStatistics[0]; # device number of filesystem
    $Inode        = $FileStatistics[1]; # inode number
    $FileMode     = $FileStatistics[2]; # (type and permissions)
    $NumHardLinks = $FileStatistics[3]; # number of (hard) links to the file
    $UserID       = $FileStatistics[4]; # numeric user ID
    $GroupID      = $FileStatistics[5]; # numeric group ID
    $DeviceIdent  = $FileStatistics[6]; # Device identifier (special files only)
    $SizeBytes    = $FileStatistics[7]; 
    $AccessTime   = $FileStatistics[8]; # seconds since the epoch
    $ModifyTime   = $FileStatistics[9];
    $ChangeTime   = $FileStatistics[10];
    $BlockSize    = $FileStatistics[11];
    $NumBlocks    = $FileStatistics[12];
    

### symlink[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-117)]
    
    
    # Creates a new filename symbolically linked to the old filename
    symlink($OldFilename, $NewFilename);
    symlink($OldFilename, $NewFilename) || die("Couldn't create symlink");
    eval(symlink($OldFilename, $NewFilename));
    

### umask[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-118)]
    
    
    # Sets or returns the _umask_ for the process.
    my $UMask = umask();
    umask(0000); # This process can create any type of files
    umask(0001); # This process can't create world-readable files
    umask(0444); # This process can't create executable files
    

### unlink[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-119)]
    
    
    # Deletes a file
    unlink $Filename;
    unlink $Filename || die("Couldn't delete file");
    unlink $File1, $File2, $File3;
    (unlink($File1, $File2, $File3) == 3) || die("Couldn't delete files");
    

### utime[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-120)]
    
    
    # Updates the modification times of a list of files
    my $AccessTime = time();
    my $ModificationTime = time();
    
    
    
    utime($AccessTime, $ModificationTime, $Filename);
    my $NumFilesChanged = utime($AccessTime, $ModificationTime, $File1, $File2, $File3);
    

## Program functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-121)]

### caller[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-122)]

Returns information about the current function call stack. In scalar context, returns only the name of the package from where the current subroutine was called. In list context, returns the package, filename, and line number. In list context with a numeric argument passed, returns several pieces of information (see below). The argument represents how many levels in the call stack to go back.
    
    
    #!/usr/bin/perl
    
    foo();
    sub foo {
       $package = caller; #returns 'main'
       ($package, $filename, $line) = caller; #returns 'main', the file name, and 3
       # Line below returns all 10 pieces of info. (Descriptions self-explanatory from variable names)
       ($package, $filename, $line, $subroutine, $hasargs, $wantarray, $evaltext, $is_require, $hints, $bitmask) =
          caller(0); 
     }
    

### import[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-123)]

There is no actual 'import' function. Rather, it is a convention when writing a module to create a subroutine named 'import' which populates the current namespace with that module's needed variables and/or methods.

The standard 'Exporter' module provides an import method if your class has it as a base class.

### package[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-124)]

Declares all lines that follow (until EOF or the next package statement) to belong to the given package's namespace.
    
    
    #!/usr/bin/perl
    
    $x = 5;  #sets $main::x
    
    package Foo;
    $x = 5;  #sets $Foo::x
    sub bar { #defines &Foo::bar
       print "hello world";
    }
    
    package Temp;
    $x = 5; #sets $Temp::x
    

### require[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-125)]

includes the specified module's code into the current program. The module can be specified either with an absolute or relative path, or with a bareword. If a bareword is given, a '.pm' extention is added, and :: is replaced with the current operating system's path seperator:
    
    
    require Foo::Bar;
    #identical to:
    require 'Foo/Bar.pm';
    

### use[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-126)]

Requires and imports the given module or pragma, at compile time. The line
    
    
    use Foo qw/bar baz/;
    

is identical to:
    
    
    BEGIN {
       require Foo;
       import Foo qw/bar baz/;
    }
    

## Misc functions[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-127)]

### defined[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-128)]
    
    
    #returns true if argument is not undef
    $x = 0;
    print "X defined\n" if defined $x; #prints
    print "Y defined\n" if defined $y; #does not print
    
    

### dump[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-129)]

### eval[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-130)]
    
    
    eval('$a=30;$b=40;');
    print $a,$b;
    

### formline[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-131)]

### local[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-132)]
    
    
    #assigns temporary value to global variable for duration of lexical scope
    $x = 5;
    print "x = $x\n"; # 5
    {
      local $x = 10;
      print "x = $x\n"; # 10
    }
    print "x = $x\n"; # 5
    

### my[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-133)]
    
    
    #creates new lexical (ie, not global) variable
    $x = 5;  #refers to $main::x
    {
      my $x = 10;
      print "x = $x\n"; # the lexical - 10
      print "main's x = $main::x\n" # the global - 5
    }
    print "x = $x\n";  #the global, because no lexical in scope - 5
    

### reset[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-134)]
    
    
    #resets hash's internal pointer, to affect lists returned by each
    while ($k, $v = each %h){
      print "$k = $v\n";
      last if ($i++ == 2);
    }
    #if another each done here, $k,$v will pick up where they left off.
    reset %h
    #now each will restart from the beginning.
    

### scalar[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-135)]
    
    
    #forces scalar context on an array
    @sizes = (scalar @foo, scalar @bar);
    #creates a list of the sizes of @foo and @bar, rather than the elements in @foo and @bar
    

### undef[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-136)]
    
    
    #undefines an existing variable
    $x = 5;
    undef $x;
    print "x = $x\n" if defined $x; #does not print
    

### wantarray[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-137)]
    
    
    #returns 'true', 'false', or undef if function that called it was called in list, scalar, or void context, respectively.
    sub fctn {
       my @vals = (5..10);
       if (wantarray) {
          return @vals;
       } elsif (defined wantarray) {
          return $vals[0];
       } else {
          warn "Warning!  fctn() called in void context!\n";
       }
    }
    

## Processes[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-138)]

### alarm[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-139)]

### exec[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-140)]

### fork[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-141)]
    
    
    #clones the current process, returning 0 if clone, and the process id of the clone if the parent
    my $pid = fork();
    if ($pid == 0) {
       print "I am a copy of the original\n";
    } elsif ($pid == -1)  {
       print "I can't create a clone for some reason!\n";
    } else {
       print "I am the original, my clone has a process id of $pid\n";
    }
    

### getpgrp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-142)]

### getppid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-143)]

### getpriority[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-144)]

### kill[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-145)]

### pipe[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-146)]

### qx/STRING/[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-147)]

### setpgrp[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-148)]

### setpriority[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-149)]

### sleep[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-150)]

### system[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-151)]

### times[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-152)]

### wait[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-153)]

### waitpid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-154)]

## Modules[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-155)]

### do[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-156)]

### import[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-157)]

### no[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-158)]

### package[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-159)]

### require[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-160)]

### use[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-161)]

## Classes and objects[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-162)]

See also [Perl Objects](/wiki/Perl_Programming/Objects)

### bless[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-163)]

### dbmclose[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-164)]

### dbmopen[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-165)]

### package[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-166)]

### ref[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-167)]

### tie[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-168)]

### tied[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-169)]

### untie[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-170)]

### use[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-171)]

## Sockets[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-172)]

### accept[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-173)]

### bind[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-174)]

### connect[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-175)]

### getpeername[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-176)]

### getsockname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-177)]

### getsockopt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-178)]

### listen[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-179)]

### recv[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-180)]

### send[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-181)]

### setsockopt[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-182)]

### shutdown[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-183)]

### socket[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-184)]

### socketpair[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-185)]

## Login information[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-186)]

### endgrent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-187)]

### endhostent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-188)]

### endnetent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-189)]

### endpwent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-190)]

### getgrent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-191)]

### getgrgid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-192)]

### getgrnam[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-193)]

### getlogin[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-194)]

### getpwent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-195)]

### getpwnam[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-196)]

### getpwuid[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-197)]

### setgrent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-198)]

### setpwent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-199)]

## Network information[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-200)]

### endprotoent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-201)]

### endservent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-202)]

### gethostbyaddr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-203)]

### gethostbyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-204)]

### gethostent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-205)]

### getnetbyaddr[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-206)]

### getnetbyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-207)]

### getnetent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-208)]

### getprotobyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-209)]

### getprotobynumber[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-210)]

### getprotoent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-211)]

### getservbyname[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-212)]

### getservbyport[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-213)]

### getservent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-214)]

### sethostent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-215)]

### setnetent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-216)]

### setprotoent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-217)]

### setservent[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-218)]

## Time and date[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-219)]

### gmtime[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-220)]

Converts a timestamp to GMT
    
    
    @TimeParts = gmtime(); 
    @TimeParts = gmtime($Time); 
    
    
    
    $Seconds    = $TimeParts[0]; # 0-59 
    $Minutes    = $TimeParts[1]; # 0-59
    $Hours      = $TimeParts[2]; # 0-23
    $DayOfMonth = $TimeParts[3]; # 1-31
    $Month      = $TimeParts[4]; # 0-11
    $Year       = $TimeParts[5]; # Years since 1900
    $DayOfWeek  = $TimeParts[6]; # 0:Sun 1:Mon 2:Tue 3:Wed 4:Thu 5:Fri 6:Sat
    $DayOfYear  = $TimeParts[7]; # 1-366
    

### localtime[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-221)]

Converts a timestamp to local time
    
    
    @TimeParts = localtime(); 
    @TimeParts = localtime($Time); 
    
    
    
    $Seconds    = $TimeParts[0]; # 0-59 
    $Minutes    = $TimeParts[1]; # 0-59
    $Hours      = $TimeParts[2]; # 0-23
    $DayOfMonth = $TimeParts[3]; # 1-31
    $Month      = $TimeParts[4]; # 0-11
    $Year       = $TimeParts[5]; # Years since 1900
    $DayOfWeek  = $TimeParts[6]; # 0:Sun 1:Mon 2:Tue 3:Wed 4:Thu 5:Fri 6:Sat
    $DayOfYear  = $TimeParts[7]; # 1-366
    

### time[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-222)]
    
    
    $Time = time();
    

Returns number of seconds since an epoch (which is system-dependant, but may be Jan 1 1970)

See also [Time::Hires](/w/index.php?title=Perl_Programming/Time::Hires&action=edit&redlink=1)

### times[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-223)]
    
    
    @CPUTimes = times();
    $UserTimeForProcess    = $CPUTimes[0];
    $SystemTimeForProcess  = $CPUTimes[1];
    $UserTimeForChildren   = $CPUTimes[2];
    $SystemTimeForChildren = $CPUTimes[3];
    

## Functions that reverse each other[[edit](/w/index.php?title=Perl_Programming/Function_Reference&action=edit&section=T-224)]

Some functions in perl reverse or otherwise cancel the effect of each other, so running a string through both of them will produce the same output as the input, for example
    
    
    print ord(chr(1));
    

will echo `1` to standard output,

`ord()` will convert a character to its number in the character set, while `chr()` will convert a number to its corresponding character, therefore

in the same way that ![\\sqrt{x^2} = x](//upload.wikimedia.org/math/b/b/d/bbd79cf326fe94290894fbeb26a4bef3.png) and ![\\sqrt{x}^2 = x](//upload.wikimedia.org/math/6/8/7/68727c1db6d65066e8b44e242d7892e9.png) in [Mathematics](//en.wikipedia.org/wiki/Mathematics) (assuming x is non-negative), `ord(chr(1)) = 1` and `chr(ord(1)) = 1` in Perl.

List of functions that reverse each other:

  * `lc()` and `uc()`
  * `lcfirst()` and `ucfirst()`
  * `ord()` and `chr()`
  * `join()` and `split()`
  * `push()` and `pop()`
  * `unshift()` and `shift()`

  


  
See <http://search.cpan.org/>

Also, try subscribing to the [use.perl.org](http://use.perl.org) mailing list, which sends out daily summaries of new modules as they're added to CPAN.

  


  * [File Tests](/w/index.php?title=Perl_Programming/Print_version/File_Tests&action=edit&redlink=1)
  * [Perl functions](/w/index.php?title=Perl_Programming/Print_version/Functions&action=edit&redlink=1)
  * [Regular Expressions](/w/index.php?title=Perl_Programming/Print_version/Regular_Expressions&action=edit&redlink=1)
  * [Database](/w/index.php?title=Perl_Programming/Print_version/Database&action=edit&redlink=1)
  * [Time and Date](/w/index.php?title=Perl_Programming/Print_version/Time_and_Date&action=edit&redlink=1)

  


## Key Sites[[edit](/w/index.php?title=Perl_Programming/Websites&action=edit&section=T-1)]

  * [perl.org](http://www.perl.org) \- the home of the Perl programming language
  * [perldoc.perl.org](http://perldoc.perl.org/) \- Perl documentation
  * [cpan.org](http://www.cpan.org/) \- The Comprehensive Perl Archive Network, a huge repository for Perl modules and scripts
  * [dev.perl.org/perl6](http://dev.perl.org/perl6/) \- Perl 6 development site 

    [The Parrot virtual machine](http://www.parrotcode.org)

## Community[[edit](/w/index.php?title=Perl_Programming/Websites&action=edit&section=T-2)]

  * [Perl Mongers](http://www.pm.org), Perl User Group Index
  * [The Perl Monastery](http://www.perlmonks.org), themed Perl based help site

## Other[[edit](/w/index.php?title=Perl_Programming/Websites&action=edit&section=T-3)]

  * [perl.com](http://www.perl.com) \- a Perl blog
  * [The DMOZ directory](http://dmoz.org/Computers/Programming/Languages/Perl/), DMOZ Perl index
  * [Perl Outsourcing Stats](http://www.odesk.com/trends/perl)
  * [Perl Tutorial](http://www.programmingbulls.com/perl-tutorial)
  * [Wikipedia:Perl](//en.wikipedia.org/wiki/Perl)

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Perl_Programming/Print_version&oldid=2451693](http://en.wikibooks.org/w/index.php?title=Perl_Programming/Print_version&oldid=2451693)" 

[Category](/wiki/Special:Categories): 

  * [Perl Programming](/wiki/Category:Perl_Programming)

Hidden category: 

  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Perl+Programming%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Perl+Programming%2FPrint+version)

### Namespaces

  * [Book](/wiki/Perl_Programming/Print_version)
  * [Discussion](/w/index.php?title=Talk:Perl_Programming/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Perl_Programming/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Perl_Programming/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Perl_Programming/Print_version&action=edit)
  * [View history](/w/index.php?title=Perl_Programming/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Perl_Programming/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Perl_Programming/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Perl_Programming/Print_version&oldid=2451693)
  * [Page information](/w/index.php?title=Perl_Programming/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Perl_Programming%2FPrint_version&id=2451693)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Perl+Programming%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Perl+Programming%2FPrint+version&oldid=2451693&writer=rl)
  * [Printable version](/w/index.php?title=Perl_Programming/Print_version&printable=yes)

  * This page was last modified on 1 December 2012, at 16:17.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Perl_Programming/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
