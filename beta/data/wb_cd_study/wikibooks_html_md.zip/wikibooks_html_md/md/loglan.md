# Loglan/Print version

From Wikibooks, open books for an open world

< [Loglan](/wiki/Loglan)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Loglan](/wiki/Loglan)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Loglan/Print_version&action=purge&printable=yes) this page.

# Introduction

## Loglan, the logical language

### Introduction

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

A _****printable version****_ of Loglan is available. ([edit it](//en.wikibooks.org/w/index.php?title=Loglan/Print_version&action=edit))

The name **Loglan**, in this context, refers to the logical language that James Cooke Brown first started to develop in the 1950s. Loglan forms an example of a _logical language_ because the developers based the language on predicate logic which forms a way of defining logical relationships. However, for practical purposes you could view the language as an example of a _fill the blanks_ language as each of the main type of words used in Loglan effectively form an incomplete sentence where you fill in the blanks to complete the meaning. For example, the Loglan word meaning _to see_, _vizka_, has three blanks and forms the sentence _x sees y against background z_ as in _mi vizka tu_ meaning _I see you_ (you don't have to use all the blanks in loglan).

Loglan could form a future auxiliary language as it has a number of advantages over natural languages and languages such as Esperanto.

  * Loglan has a set of consistent rules - no exceptions
  * Consistent spelling (the base words come in either CVCCV or CCVCV form (where C stands for "consonant" and V for "vowel")).
  * Simpler rule set. Loglan has about 200 rules, far less than a natural language.
  * A defined way to grow so any additions follow a set of rules as the language grows and develops. So, once you know Loglan your knowledge doesn't get out dated as the language changes.
  * Simpler grammar. No nouns, adverbs, imperfect forms etc to learn.

### Table of Contents

  * Chapter 1 - [Overview of Loglan](/w/index.php?title=Loglan/Print_version/Overview_of_Loglan&action=edit&redlink=1)
  * Chapter 2 - [Putting Things Together - Forming Sentences](/w/index.php?title=Loglan/Print_version/Putting_Things_Together_-_Forming_Sentences&action=edit&redlink=1)
  * Chapter 3 - [The Power of Little Words](/w/index.php?title=Loglan/Print_version/The_Power_of_Little_Words&action=edit&redlink=1)
  * Chapter 4 - [Using Loglan](/w/index.php?title=Loglan/Print_version/Using_Loglan&action=edit&redlink=1)

# Chapter 1 - Overview of Loglan

You construct a sentence in Loglan from three groups of words:

  * [Predicates](/w/index.php?title=Loglan/Print_version/Predicates&action=edit&redlink=1) \- the main words of Loglan
  * [Arguments](/w/index.php?title=Loglan/Print_version/Arguments&action=edit&redlink=1) \- used to fill the blanks
  * [Little words](/w/index.php?title=Loglan/Print_version/Little_words&action=edit&redlink=1) \- control words

## Predicates

You use predicates to form the main subject of a sentence. If fact, you can view a predicate words as an incomplete sentence. Just fill in the blanks to say what you want to say. Each predicate word has from one to five blanks to fill in.

Predicates come in three main forms.

  * Base words
  * Compound words
  * Lone words

  


## Base Words

These form the main set of words used in Loglan. They have a constant spelling; either CVCCV form or CCVCV form. They all end in a vowel and they all have only one meaning each.

### Examples

NB. The letters x, y and z represent the blanks.

CVCCV form

  * vizka - x sees y against background z
  * hasfa - x is the house of y
  * tarci - x is a star of galaxy y
  * fundi - x likes y more than z
  * takna - x talks to y about z

  
CCVCV form

  * cnida - x needs y for z
  * clika - x is similar to x in feature z
  * tcaro - x is a motorised vehicle
  * jmite - x meets y
  * zvoto - x is outside of y

## Compound Words

The base words in Loglan number about 1 500. To say more you can use two or more base words to make a metaphor. If you think others can use the metaphor you can combine the words to make a new word. Each base word has a combining form which you can use to construct more complex words.

### Examples

  * fagctu - ash. Constructed from _fagro_ (fire) and _ctuda_ (excrement); fagro ctuda. The word _fagro_ has the combining form _fag_ and _ctuda_ the combining form of _ctu_ so the metaphor _fagro ctuda_ becomes the word _fagctu_.
  * bamfoa - sphere. Constructed from _balma_ (ball) and _forma_ (form / shape); balma forma. The word _balma_ has the combining form _bam_ and _forma_ the combining form of _foa_ so the metaphor _balma forma_ becomes the word _bamfoa_.
  * trigru - forest / wood. Constructed from _tricu_ (tree) and _grupa_ (group); tricu grupa. The word _tricu_ has the combining form _tri_ and _grupa_ the combining form of _gru_ so the metaphor _tricu grupa_ becomes the word _trigru_.

## Lone Words

When using Loglan you try to use Loglan word to construct a metaphor for a new idea of concept. However, you might not have the opportunity to do that at all time such as when an idea or concept has a close relationship to one group of people. In such cases, Loglan allows borrowing but with certain rules.

### Examples

  * proteini - x is a protein of type y
  * cerkopithekui - x is a cercopithecus (a primate) of that genus

## Arguments

These form a set of words that you use to fill in the blanks of the predicates. They form the objects or agents that you talk about. Argeuments come in three forms:

  * Names
  * [Predicates](/w/index.php?title=Loglan/Predicates&action=edit&redlink=1) as arguments
  * [Little words](/w/index.php?title=Loglan/Little_words&action=edit&redlink=1) as arguments

We use a little word to tell the difference between a name and a normal predicate word used as an argument; either _le_ or _la_. The little word _le_ means _the one I call_ and the the little word _la_ means _the one that actually is_. The word 'le' then forms a prefix for a description and the little word _la_ forms a prefix for a name.

## Names

Names in Loglan come in two types:

  * Proper Names
  * Predicate Names

All proper names end in a consonant and can have any number of letters. We can use predicates as names if we use the little word _la_ first. As predicates together form a metaphor we use the little word _gu_ to show where the name ends and the main predicate of the sentence starts.

### Examples

Proper names:

  * Frans - France
  * Sol - Sun
  * Romas - Rome

Predicate Names

  * la farfu - father / dad
  * la ratcu - Rat

## Predicates as arguments

You can use predicates words as arguments to the main predicate of a sentence to form the object or agent of a predicate. To do so, you need to add the little word _le_ to show that the you mean _the one I call_ and then use the little word _gu_ to show when the argument predicate comes to an end and the main sentence predicate begins.

### Examples

  * _le nirli_ gu tcatro - the girl is driving (a vehicle)
  * _le farfu_ gu kamla - the father comes
  * _le hasfa_ gu redro - the house is red
  * _le prano mrenu_ gu goztsefui - the running man is late

## Little words as arguments

Loglan has a number of little words that you can use for common occurring actors or objects.

### Examples

  * tu - you
  * ti - this
  * toi - that ( the last mentioned remark)
  * da - he / she / it

## Little words

Little words form a type of control word for sentences. You can use them to _form brackets_, add time and place or add additional information to a sentence. You can also use some little words for common words you might use such as _me_, _it_ or numbers.

## Examples

  * mi - me / I / myself
  * gu - a separator between predicates / a right boundary marker
  * to - the number two
  * rau - ... because of reason ...
  * e - and

# Chapter 2 - Putting Things Together - Forming Sentences

You build a proper sentence in Loglan around a predicate word. You then fill what blanks you need and then add any additional information using little words.

## Simple sentences

(vizka = x sees y against background z)

  * mi _vizka_ tu - I see you (main predicate = vizka)
  * tu _vizka_ mi - You see me (main predicate = vizka)
  * mi _ridle_ ba le bukcu - I read something from a book (main predicate = ridle with arguments = ba and le bukcu)

  


## More complex sentences

  * mi nu _vizka_ tu - I am seen by you (you see me) (main predicate = vizka and using the place converter nu to swap arguments)
  * mi _vizka_ tu, ui - I see you (which I am happy about) (main predicate = vizka and using the emotional indicator ui)

(soisni = x is sleepier than y) (cioru = many / too much) (muspli = x exercises muscles y)

  * la maris _soisni_ rau lepo da cioru muspli - Mary feels sleepy because she has exercised too much (main predicate = soisni with rau to give a physical cause)

(tcatro = x drives vehicle y from z to a via b) (livhao = x is the home of y) (turka = x work on y for purpose z) (sitfa = x is the place of b in reference frame z)

  * le mrenu gu _tcatro_ le tcaro le livhao le turka sitfa pa - the man drove the car from home to the work place (main predicate = tcatro and using the little word pa to put the event in the past)
  * le mrenu gu _tcatro_ le tcaro le livhao le turka sitfa fa - the man will drive the car from home to the work place (main predicate = tcatro and using the little word fa to put the event in the future)

# Chapter 3 - The Power of Little Words

Much of the expressive power of Loglan lies in the little words. A basic sentence in Loglan just defines a relationship between actors and objects but says nothing about the whys, whens or wheres. For example, _mi vizka tu_ defines a relationship between me and you of the type seeing; "I see you" but says nothing about where or when or why. We can use the little words to add those additional informations.

Little words come in different types:

[Logical Operators and Connections](/w/index.php?title=Loglan/Print_version/Logical_Operators_and_Connections&action=edit&redlink=1) \- joining things together

[Time and Space](/w/index.php?title=Loglan/Print_version/Time_and_Space&action=edit&redlink=1) -the wheres and whens

[Modifiers](/w/index.php?title=Loglan/Print_version/Modifiers&action=edit&redlink=1) \- the whys

[Numbers and Letters](/w/index.php?title=Loglan/Print_version/Numbers_and_Letters&action=edit&redlink=1)

[He, she and it](/w/index.php?title=Loglan/Print_version/He,_she_and_it&action=edit&redlink=1)

## Logical Operators and Connections

Loglan has five basic logical operators for joining things together and one way to separate sentences. Loglan also has an operator for _please indicate which_ :

  * [a](/wiki/Loglan/The_Power_of_Little_Words/Logical_Operators_and_Connections/OR_operator) \- the _or_ operator
  * [e](/wiki/Loglan/The_Power_of_Little_Words/Logical_Operators_and_Connections/AND_operator) \- the _and_ operator
  * [o](/wiki/Loglan/The_Power_of_Little_Words/Logical_Operators_and_Connections/IF_and_only_IF) \- the _if and only if_ operator
  * [u](/wiki/Loglan/The_Power_of_Little_Words/Logical_Operators_and_Connections/Whether_or_not_operator) \- the _whether or not_ operator
  * [no](/wiki/Loglan/The_Power_of_Little_Words/Logical_Operators_and_Connections/no) \- the inverse operator
  * [i](/wiki/Loglan/The_Power_of_Little_Words/Start_of_a_Sentence) \- the start of a sentence
  * [ze](/wiki/Loglan/The_Power_of_Little_Words/mixing) \- mixing things together
  * [ha](/wiki/Loglan/The_Power_of_Little_Words/how_connected) \- How connected

Loglan then extends these basic operator for connecting words or sentences in different ways

  


## The _OR_ Operator

### a

In Loglan, we define the _Or_ operator as true if one item it links together has a value of true. The little word _a_ connects predicates together.

#### Examples

  * mi tcatro _a_ maifle - I am a driver or a pilot (or both)
  * le tetri gu solflo _a_ kleda - the weather is sunny or cold (or both)
  * le bakso gu redro _a_ dirlu _a_ groda - the box is red or lost or large (or any combination)

### ca, ka, anoi and ica

The little word _a_ forms the foundations for a set of "OR" words.

  * ca - forms an _OR_ operation with predicates as arguments
  * ka - forms an _OR_ operation as _a_ but as a forethought connection. It works with the little word _ki_
  * anoi - represents an _if_ relationship and results from _NOT OR_
  * ica - connects two sentences together with an _OR_ operation

#### Examples

ca

  * le mrenu _ca_ fumna gu godzi - the man or woman goes
  * le katmu gu fundi le cutri _ca_ ficlu - the cat likes water or fish

ka

  * le _ka_ mrenu ki fumna gu godzi - the man or woman goes
  * le katmu gu fundi le _ka_ cutri ki ficlu - the cat likes water or fish

anoi

  * mi fundi le bukcu _anoi_ le sinma - I like the book if I like the film

ica

  * mi fundi le bukcu _ica_ le sinma - I like the book or I like the film

  


## The AND Operator

The AND operator links together a group of items so that for the whole group to have the value true all the items have to have the value true. If one or more items have the value false then the whole group has the value false.

### e

The little word _e_ links together predicates.

#### Examples

  * la djan gu herkeu e larmao - John is a hairdresser and an artist
  * da tcaro e plebekti - that is a car and a toy

### ce, ke and enoi

The other AND operators in Loglan follow on from _e_.

The little word _ce_ joins together arguments and so does _ke_ but we use _ke_ in a forethought way and it works together with _ki_. We can use the little word _enoi_ to mean _... but not ..._.

#### Examples

ce

  * da lemi hasfa _ce_ livhao - this is my house and home
  * le tetri gu cetlo _ce_ briflo - the weather is wet and windy
  * tu ponsu le grobou _ce_ botsu - you own the ship and the boat

ke

  * da lemi _ke_ hasfa ki livhao - this is my house and home
  * mi clika lemi _ke_ matma ki farfu - I am like my mother and father

enoi

  * mi madzo le hasfa enoi le livhao - I make a house but not a home

  


## The IF and only IF operator

### o

The little word _o_ means _if and only if_. We can use it to link predicates together.

#### Examples

  * mi godzi o dzoru - I go if and only if I walk
  * mi clivi o brute - I am alive if and only if I breath

### co, ko, onoi and ico

We can extend the basic little word _o_ for connecting arguments ans sentences.

  * _co_ \- links arguments together
  * _ko_ \- the forethought equivalent and works with _ki_
  * _onoi_ \- the exclusive OR (XOR) operator that means _a XOR b but not both_
  * _ico_ \- links sentences

#### Examples

co

  * mi hapci _co_ crano pernu - I am a happy (if and only if smiling) person
  * da nakso le bakso _co_ kuvbao - Someone fix the box if and only chest

ko

  * mi _ko_ hapci ki crano gu pernu - I am a happy (if and only if smiling) person

onoi

  * le crina onoi le solflo gu tetri - the weather is either raining or sunny but not both
  * mi kamla le fusto _onoi_ le livhao - I come to the office or the home but not both

ico

  * mi klama le fusto _ico_ klama le livhao - I come to the office or I come to the home but not both

  


## The Whether or Not Operator

### u

The little word _u_ means _x whether or not y_ and links together predicates.

#### Examples

  * mi godzi u brecea - I go, whether or not I am ready
  * da bakso u redro - it is a box, whether or not it is red
  * ti bukcu u ponsu ti - it is a book, whether or not I own it

### cu, ku and icu

We can use the little word _cu_ to link together arguments and so does _ku_. However, _ku_ works as a forethought operator and works with _ki_. The little word _icu_ links sentences.

#### Examples

cu

  * mi godzi le hasfa _cu_ vemsia - I go to the house, whether or not I go to the shop
  * le katmu _cu_ kangu gu fundi le ficlu - The cat, whether or not the dog, likes the fish

ku

  * mi godzi le ku hasfa ki vemsia - I go to the house, whether or not I go to the shop
  * tu fleti la Romas cu Pari's - you fly to Rome, whether or not you fly to Paris

icu

  * tu vrelaa icu mi vrecoa - you are tall, whether or not I am short

  


## The Inverse Operator

### no

We use the little word _no_ to invert or negate a relationship. I can mean slightly different things depending exactly where it appears in a sentence.

#### Examples

  * no, mi vizka tu - It is not the case that I see you (no _relationship_ between you and me)
  * mi no vizka tu - I don't see you (but there is a _relationship_ between you and me but its not _seeing_. I could _hear_ you instead, for example)
  * mi vizka no tu - I don't see you (I see something but its not you)

  


## Start a Sentence

### i

The little word _i_ indicates the start of a sentence. We can also combine _i_ with other operators to produce sentence combining forms such as _ica_ (_i_ \+ _ca_).

#### Examples

  * mi vizka tu. _i_ tu vizka mi - I see you. You see me.
  * mi fleti la Romas. _i_ tu stolo le livhao - I fly to Rome. You stay at home.

  


## Mixing Things Together

### ze

Sometimes a composition forms something. For example, a black and white cat composed of both black fir and white fir. In loglan, if we say a _black and white cat_ (le nigro ce blabi katmu) we mean the cat is both black and white at the same time, which not only forms and example of an impossibility but also we do not mean that. Loglan, however, does provide a word to mix things together.

#### Examples

  * le nigro _ze_ blabi katmu - black and white cat
  * le redro _ze_ vegri hasfa - The red and green house

  


## How Connected

### ha

For an OR operation to have a truth value of true only one item in the list need a truth value of true. So, the question "would you like sugar or milk in your coffee" has the answer "yes" if I would like sugar or if I would like milk or if I would like milk and sugar. It only has the answer "no" if I want neither milk nor sugar. Technically correct the answer "yes", but not very useful. If I answer "yes" do I want milk, sugar or both? To over come this, Loglan provides the little word _ha_ to mean _which if any_.

#### Example

  * ei, tu danza le sakta _ha_ le malna kii letu skafi - Would you like sugar or milk with your coffee?

## Time and Space

A simple sentience in Loglan only defines a relationship between the arguments but says nothing about where on when the relationship holds true. Unlike some natural languages, you can chose to add time and space to a sentence in Loglan or chose to leave it out.

The Loglan sentence, _mi viska tu_ means _I see you_ or _I was seen by you_ or _I will see you_. English forces us to add in the time; was it past, present or future? But in Loglan _mi viska tu_ can hold true if I see you now or I have seen you or even if I will see you at some point in the future. Loglan does not force you to refer to time or space.

Loglan treats time and space the same. That means you place a relationship in time the same way that you place it in space; you add one of three words for time and one of three words for space. Whatever you can do with time words you can do with space words.

For time we have the following three words:

  * pa
  * na
  * fa

  
For space we have the following three words:

  * vi
  * va
  * vu

  


### pa, na, and fa

If we want to add time into a sentence Loglan provides us with three little words to do that; _pa_, _na_ and _fa_. You can add theses little words anywhere in the sentence.

The little word _pa_ refers to the past and means _before_.

  * mi vizka tu _pa_ \- I saw you
  * mi _pa_ vizka tu - I saw you
  * _pa_ mi vizka tu - I saw you

The little word _na_ refers to now and means _at the instance of_.

  * mi _na_ vizka tu - I see you now

The last of the three, _fa_, refers to the future and means _after_.

  * mi vizka tu _fa_ \- I will see you

### vi, va and vu

The little words _vi_, _va_ and _vu_ indicate place and work like the words for time; they go anywhere in the sentence.

The little word _vi_ means _here_ or _close to this place_

  * mi viska tu _vi_ \- I see you here
  * mi _vi_ viska tu - I see you here
  * _vi_ mi viska tu - I see you here

The little word _va_ means _over there_ or _nearby_.

  * mi vizka tu _va_ \- I saw you nearby

The last little, _vu_ word refers to a place far away; _over there_ or _yonder_.

  * mi vizka tu _vu_ \- I saw you far away over there

### zi, za, and zu

You can add more details to the time and space words using the _zi_, _za_, and _zu_ little words.

  * zi - near or very short duration
  * za - soon or a short duration
  * zu - long time or long duration

so,

  * fazi - very short time in the future
  * vuzu - a very long distance away
  * naza - in a little while

The context determines how long is long and how short is short. The existence of humans on Earth is a short time in geological ages but and hour might mean a long time to wait for a bus.

### Other Places and Other Times

The use of _vi, va, vu_ and _pa, na, fa_ defines time and place relative to the speaker. We can use the little word _la_ to define a place or time relative to something else if we combine it with the place and time words.

  * mi vizka tu _lena_ kinkra - I saw you at the time of the convention
  * mi _lena kinkra_ gu vizka tu - I, at the time of the convention, saw you
  * mi vizka tu _lefa_ kinkra - I will see you at the time of the convention
  * mi vizka tu _levi_ kinkra - I saw you at the place of the convention
  * mi vizka tu _leva_ kinkra - I saw you near the place of the convention

## Modifiers

The basic Loglan sentence just defines a relationship but Loglan allows you to add more information if you wish. These extra words we group together as:

  * Sentence modifiers
  * Argument modifiers
  * Free modifiers

  


### Sentence Modifiers

Sentence modifiers include the time and space words and the logical contention words. They also include modal and causal relative operators. You can place a modal anywhere in a sentence but if they appear anywhere other than on the end of a sentance you might need a _gu_ to say when the modeal ends and the remaining part of the sentence continues.

#### Modal Operators

Modal operators add information on who or in what way something relates to something else. They all come in CVV form.

  * _kii_ \- With as in mi godzi _kii_ tu (I walk with you)
  * _tie_ \- using tool as in Da pa _tie_ leda najda gu kutla de (someone, with a knife, cut something. Note the use of _gu_ to end the modal)
  * _hea_ \- with help as in mi kamla le hijra _hea_ tu (I came here with your help)

#### Causal Operators

Causal operators work just the same way as modal operators. Causal operators give the reason why a relationship holds.

  * _kou_ \- because of physical reason as in mi cetlo kou le crina (I am wet because of the rain)
  * _moi_ \- because of motive as in mi kamla le hijra _moi_ lepo mi danza lepo mi vizka tu (I came because I wanted to see you)
  * _rau_ \- because of reason as in mi fundi tu _rau_ lepo tu minspu (I like you because you are clever)
  * _soa_ \- because of premise as in letu kukreo gu denro _soa_ lepo ra dortau gu denro (your rifle is dangerous because all weapons are dangerous)

### Argument Modifiers

Argument modifiers adds additional information to an argument such as making claims or identifying the argument.

  * _ji_ \- adds more information to identify the argument as in lemi hasfa _ji_ le redro hasfa, gu snire (my house - the red house - is close)
  * _ja_ \- makes a claim and adds more information about the argument as in lemi hasfa _ja_ le redro hasfa, gu snire (my house, which is a red house, is close)

### Free Modifiers

Theses modifiers add more information about the writer / speaker or about the sentence as a whole. They can go anywhere in a sentence without effecting the sentence (except after _le_, _la_ and the others in that group). Loglan contains a number of different types of free modifiers, which includes.

  * Attitude
  * Discursive
  * Parenthesis

#### Attitude

These all have a VV form and form groups depending on the first letter. The 'a' series deals with intention, 'e' with requests, 'i' with conviction, 'o' with obligation and 'u' with motive. The second letter deals with degree with 'a' as positive, 'i' mid way and 'u' as negative. Some examples:

  * _ua_ \- satisfaction
  * _ui_ \- happy
  * _uo_ \- anger
  * _uu_ \- sorrow
  * _oa_ \- must / feel obliged to do so
  * _ou_ \- Doesn't matter
  * _ia_ \- agree
  * _ii_ \- maybe
  * _iu_ \- don't know
  * _ei_ \- is it so
  * _eo_ \- please
  * _eu_ \- assume
  * _ai_ \- intend
  * _au_ \- don't care

## Numbers

Loglan has a set of numbers composed of 10 little words which represent a single digit each:

  * 0 - ni
  * 1 - ne
  * 2 - to
  * 3 - te
  * 4 - fo
  * 5 - fe
  * 6 - so
  * 7 - se
  * 8 - vo
  * 9 - ve

All odd numbers end in _e_ and all even numbers end in _o_. You can form larger numbers though combining words in the same way we combine digits.

### Examples

  * 10 - neni
  * 123 - netote

## Sequences

You can add _fi_ on to the end of a number to describe a sequence such as _first, second, third_.

### Examples

  * Nefi - first
  * tofi - second
  * tefi - third

## Letters

Loglan has away to refer to each letter. You might want to do this when using letters as variables. You just need to add an ending to the letter depending on weather you use a Latin of Greek letter, vowel or consonant. NB Loglan does not use the letter **c** or **w** for Greek letters as Greek has no corresponding sounds (c = _sh_ and w = _eu_ in Loglan).

  * -ei for lower case Latin consonant letters
  * -si for lower case Latin vowel letters
  * -ai for upper case Latin consonant letters
  * -ma for upper case Latin vowel letters
  * -eo for lower case Greek consonant letters
  * gao- for upper case Greek consonant letters
  * -fi for lower case vowel letters
  * gao,- for upper case Greek vowel letters

### Examples

  * A - Ama
  * a - asi
  * B - Bai
  * b - bei
  * Alpha - gao,afi
  * alpha - afi
  * Beta - gaobeo
  * beta - beo

## He, She and It

### Gender in Loglan

In many natural languages when referring to a person you also have to refer to the person's gender. For example, in English, if you refer to a man you use "he" and for a woman you use "she". The words "he" and "she" automatically tells you the person's gender. Loglan, however, does not specify gender like in English. Instead, Loglan maintains gender neutrality.

### First Letter

Loglan has a number of ways to refer to a person. One way involves using the first letter of the person's name.

#### Examples

  * John helps people. He works as a doctor. - la djan helba lo pernu. i la _D_ kicmu
  * Mary has arrived. She's in the red car over there. - la Maris godzi le hijra. i la _M_ nenri le redro tcaro va ti

### He, She, it

Loglan has no specifi words for "he", "she" or "it". Instead it has variables _da_, _de_, _di_, _do_, and _du_, which takes the place of the person or item in the order they appear in a conversation or sentence. So, you can use _da_ to refer to the first person or item mentioned and _de_ for the second person or item as you would use "he", "she" or ""it".

#### Examples

  * John helps people. He works as a doctor. - la djan helba lo pernu. i _da_ kicmu
  * Mary has arrived. She's in the red car over there. - la Maris godzi le hijra. i _de_ nenri le redro tcaro va ti

# Chapter 4 Using Loglan

## Greetings

  * Hello - loi
  * Good bye - loa
  * How are you? - tu he
  * How do you feel? - ei tu djela
  * What is your name? - hu namci tu
  * My name is <name> \- la <name> namci lemi

## Time

  * What is the time? - hu jolkeo
  * The time is \- le jolkeo
  *   * When? What interval of time? - nia hu
  *   * When? At what point in time? - na hu
  * ## Questions

  * What did you say? Who? Which? - ie
  *   * Why? What for? - moi hu
  *   * What is it? - he
  *   * How? By what means? Using what? - tie hu
  *   * What is this? - ti ie
  *   * What is that? - ta ie
  *   * Is it true that ...? ei, ...
  *   * Whatever - rabu, rabe, rabo, raba
  *   * How did that happen? What caused that to happen? - kou hu
  *   * How many? - ho
  *   * How's it going? - tu ie nu vetci
  *   * Why? For who? - dii hu
  *   * Why? For what motivation? - moi hu
  *   * Why? For what reason - rau hu?
  *   * Why? To please whom? - lui hu
  *   * Why? According to what premise? - soa hu
  *   


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Loglan/Print_version&oldid=2397118](http://en.wikibooks.org/w/index.php?title=Loglan/Print_version&oldid=2397118)" 

[Categories](/wiki/Special:Categories): 

  * [Loglan](/wiki/Category:Loglan)
  * [Constructed languages](/wiki/Category:Constructed_languages)

Hidden category: 

  * [Books with print version](/wiki/Category:Books_with_print_version)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Loglan%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Loglan%2FPrint+version)

### Namespaces

  * [Book](/wiki/Loglan/Print_version)
  * [Discussion](/wiki/Talk:Loglan/Print_version)

### 

### Variants

### Views

  * [Read](/wiki/Loglan/Print_version)
  * [Edit](/w/index.php?title=Loglan/Print_version&action=edit)
  * [View history](/w/index.php?title=Loglan/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Loglan/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Loglan/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Loglan/Print_version&oldid=2397118)
  * [Page information](/w/index.php?title=Loglan/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Loglan%2FPrint_version&id=2397118)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Loglan%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Loglan%2FPrint+version&oldid=2397118&writer=rl)
  * [Printable version](/w/index.php?title=Loglan/Print_version&printable=yes)

  * This page was last modified on 20 August 2012, at 09:49.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Loglan/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
