# Internet Technologies/Print version

From Wikibooks, open books for an open world

< [Internet Technologies](/wiki/Internet_Technologies)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

## Contents

  * 1 The Internet
    * 1.1 References
  * 2 Domain names
    * 2.1 External links
  * 3 Web hosting
    * 3.1 What is Web Hosting?
    * 3.2 What does Web Hosting do?
    * 3.3 How and Where can I get hosting?
    * 3.4 Reseller vs. Shared
    * 3.5 Types of hosting control panels
    * 3.6 Running a site on your personal computer
    * 3.7 Further reading
  * 4 Routing
  * 5 Protocols
    * 5.1 Common Internet protocols
    * 5.2 See also
  * 6 History and evolution
  * 7 The Web
    * 7.1 URLs, HTTP and HTML
    * 7.2 Beyond text
    * 7.3 Java and Javascript
    * 7.4 Sociological Implications
    * 7.5 Publishing web pages
  * 8 History of the Web
    * 8.1 Works Cited
  * 9 HTML
    * 9.1 HTML
    * 9.2 For further reading
  * 10 Embedded technologies
    * 10.1 Embedded technologies
    * 10.2 See also
  * 11 Proxy servers
  * 12 Search engine
    * 12.1 Sources
    * 12.2 Work Cited
  * 13 Web advertising
  * 14 Online shopping
    * 14.1 Online Auctions
    * 14.2 Works Cited
  * 15 Email
  * 16 History of email
  * 17 Routing email
  * 18 Email spam
    * 18.1 External Links
  * 19 Email security
  * 20 Usenet
    * 20.1 External Links
  * 21 History of Usenet
  * 22 IRC
    * 22.1 Technology of IRC
    * 22.2 Using Internet Relay Chat
    * 22.3 Registering your nickname
      * 22.3.1 Example HowTo for a network
    * 22.4 Private conversations and chats
    * 22.5 IRC clients
    * 22.6 IRC commands
      * 22.6.1 Basic commands
      * 22.6.2 Privileged User Commands
  * 23 Remote Access
  * 24 Telnet
    * 24.1 External Links
  * 25 SSH
    * 25.1 Uses
      * 25.1.1 Using SSH
      * 25.1.2 Using SFTP
      * 25.1.3 Using SCP
      * 25.1.4 Creating SSH Keys
      * 25.1.5 Permissions
      * 25.1.6 Establish Trust
        * 25.1.6.1 ssh-copy-id
        * 25.1.6.2 Manual
      * 25.1.7 SSH Personal Configuration
        * 25.1.7.1 Example
      * 25.1.8 Using an SSH Agent
        * 25.1.8.1 Using Keychain
        * 25.1.8.2 BASH configuration Change
    * 25.2 Public-key cryptography
    * 25.3 Setting up OpenSSH with public key cryptography
    * 25.4 SSH as a Proxy
    * 25.5 SSH from your webbrowser
    * 25.6 Further reading
  * 26 VNC
    * 26.1 How it works
    * 26.2 how to copy and paste
    * 26.3 External Links
  * 27 Remote Desktop Connection
    * 27.1 What you can do with Remote Desktop Connection
      * 27.1.1 Setup
        * 27.1.1.1 User Password
        * 27.1.1.2 Enabling Remote Desktop Connection (on the host)
        * 27.1.1.3 Getting your IP address
        * 27.1.1.4 Connecting to the host machine from another machine
      * 27.1.2 Pros
      * 27.1.3 Cons

  


# The Internet

The [Internet](//en.wikipedia.org/wiki/Internet) is a worldwide collection of computer networks that began as a single network that was originally created in 1969 by ARPA (Advanced Research Projects Agency), a U.S. government agency that was far more interested in creating projects that would survive a nuclear war than in creating anything useful for the civilian population.

In its original form, ARPANET, the U.S. government hoped to create a network of computers that would allow communication between government agencies and certain educational centers that would be able to survive a nuclear explosion. It is doubtful that the original founders of ARPANET foresaw what we now know as "the Internet." From its humble beginnings as a military project, the ARPANET grew slowly throughout the 70's and 80's as a community of academics accomplished the truly monumental task of hammering out the building blocks of this new, open, modular conglomeration of networks.

The various protocols, including IP, TCP, DNS, POP, and SMTP, took shape over the years, and by the time the World Wide Web ([HTML](//en.wikipedia.org/wiki/HTML) and HTTP) was created in the early 90's, this "Internet" had become a fully functional, fairly robust system of network communication, able to support this new pair of protocols which eventually turned the Internet into a household word.

While a large portion of users today confuse the Web with the Internet itself, it must be emphasized that the Web is only one type of Internet application, and one set of protocols among a great many which were in use for over a decade before the Web entered into the public awareness.

The Web is a subset of the Net. Email is not a part of the Web, and neither are newsgroups, although Web designers have developed web sites through which users, the world over, commonly access both of these much older forms of Internet media.

While the Net is a largely abstract phenomenon, it cannot (at least, not yet) be accurately equated with the concept of "cyberspace" as depicted in science fiction. If "judgement day" were to occur as depicted in the latest "Terminator" film, much of the Internet would survive it, but most of the electrical and data infrastructure by which we access the net would not. The line which currently demarcates the "digital divide" would shift dramatically to a point where it would leave only a small segment of humanity in virtual touch. This limitation, however, will slowly be overcome as wireless technologies continue to proliferate and wired technologies become increasingly cheaper.

In March 1972 ARPA became known as DARPA, the Defense Advanced Research Project Agency, and then went back to ARPA in February 1993 and back to DARPA in March 1996 and has been ever since. It was originally created as ARPA in 1958 in response to the launching of Sputnik. The launch of Sputnik made America realize that the Soviet Union could exploit military technology. DARPA has contributed to the creation of ARPANET as well as the Packet Radio Network, the Packet Satellite Network and the Internet. As well as research into the Artificial Intelligence field commonly referred to as AI. By the late 1970's the Department of Defense had adopted BSD UNIX as the primary operating system for DARPA. It has also had its hands in Space projects which included the launching of the Apollo missions.

## References

  * <http://en.wikipedia.org/wiki/DARPA>
  * <http://www.darpa.mil/DARPA50thevent/history.html>

  


# Domain names

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Edit-clear.svg/40px-Edit-clear.svg.png)

**This page was [imported](/wiki/Help:Importing) and needs to be _[de-wikified](/wiki/Wikibooks:Dewikify)_**.  
Books should use wikilinks rather sparsely, and only to reference technical or esoteric terms that are critical to understanding the content. Most if not all wikilinks should simply be removed. Please remove {{[dewikify](/wiki/Template:Dewikify)}} after the page is dewikified.

The **Domain Name System**, most often known as simply **DNS**, is a core feature of the [Internet](/wiki/Internet). It is a distributed database that handles the mapping between host names (**domain names**), which are more convenient for humans, and the numerical [Internet addresses](//en.wikipedia.org/wiki/IP_address). For example, _www.wikipedia.org_ is a domain name and _130.94.122.199_ the corresponding numerical internet address. The domain name system acts much like an automated phone book, so you can "call" _www.wikipedia.org_ instead of _130.94.122.199_. So, it converts human-friendly names such as "www.wikipedia.org" into computer-friendly (IP) addresses such as 130.94.122.199. It can also handle the reverse mapping, meaning that we can query for a name for _130.94.122.199_, that return _larousse.wikipedia.org_

DNS was first invented in 1983 by [Paul Mockapetris](//en.wikipedia.org/wiki/Paul_Mockapetris); the original specifications are described in [RFC](//en.wikipedia.org/wiki/RFC) 882\. In 1987 [RFC 1034](//tools.ietf.org/html/rfc1034) and [RFC 1035](//tools.ietf.org/html/rfc1035) were published which updated the DNS specifcation and made [RFC 882](//tools.ietf.org/html/rfc882) and [RFC 883](//tools.ietf.org/html/rfc883) obsolete. Subsequent to that there have been quite a few RFCs published that propose various extensions to the core protocols.

DNS implements a hierarchical name space by allowing name service for parts of a name space known as zones to be "delegated" by a [name server](//en.wikipedia.org/wiki/Name_server) to subsidiary name-servers. DNS also provides additional information, such as alias names for systems, contact information, and which hosts act as mail hubs for groups of systems or domains.

The present restriction on the length of domain names is 63 characters, excluding the _www._ and _.com_ or other extension. Domain names are also limited to a subset of [ASCII](//en.wikipedia.org/wiki/ASCII) characters, preventing many languages from representing their names and words correctly. The [Punycode](//en.wikipedia.org/wiki/Punycode)-based [IDNA](//en.wikipedia.org/wiki/IDNA) system, which maps [Unicode](//en.wikipedia.org/wiki/Unicode) strings into the valid DNS character set, has been approved by [ICANN](//en.wikipedia.org/wiki/ICANN) and adopted by some [registries](//en.wikipedia.org/wiki/domain_name_registry) as a workaround.

The DNS system is run by various flavors of DNS software, including:

  * [BIND](//en.wikipedia.org/wiki/BIND) (Berkeley Internet Name Domain), the most commonly used namedaemon.
  * [DJBDNS](//en.wikipedia.org/wiki/DJBDNS) (Dan J Bernstein's DNS implementation)
  * [MaraDNS](//en.wikipedia.org/wiki/MaraDNS)
  * [NSD](//en.wikipedia.org/wiki/NSD) (Name Server Daemon)
  * [PowerDNS](//en.wikipedia.org/wiki/PowerDNS)

Any [IP](//en.wikipedia.org/wiki/Internet_protocol) computer network can use DNS to implement its own private name system. However, the term "domain name" is most commonly used to refer to domain names implemented in the public [Internet](//en.wikipedia.org/wiki/Internet) DNS system. This is based on thirteen "root servers" worldwide, all but three of which are in the [United States of America](//en.wikipedia.org/wiki/United_States_of_America). From these thirteen [root servers](//en.wikipedia.org/wiki/root_nameserver), the rest of the Internet DNS name space is delegated to other DNS servers which serve names within specific parts of the DNS name space.

An 'owner' of a domain name can be found by looking in the [WHOIS](//en.wikipedia.org/wiki/whois) database: for most TLDs a basic WHOIS is held by ICANN, with the detailed WHOIS maintained by the domain registry which controlls that domain. For the 240+ Country Code TLDs the position is usually that the registry holds the entire authorative WHOIS for that extension, as part of their many functions.

The current way the main DNS system is controlled is often criticized. The most common problems pointed at are that it is abused by monopolies or near-monopolies such as [VeriSign](//en.wikipedia.org/wiki/VeriSign) Inc., and problems with assignment of [top-level domains](//en.wikipedia.org/wiki/top-level_domain).

Some also allege that many implementations of DNS server software fail to work gracefully with dynamically allocated IP addresses, although that is the failure of specific implementations and not failures of the protocol itself.

DNS uses [TCP](//en.wikipedia.org/wiki/Transmission_Control_Protocol) and [UDP](//en.wikipedia.org/wiki/User_Datagram_Protocol) [port](//en.wikipedia.org/wiki/computer_port) 53\. Most DNS queries (such as name resolution requests) use UDP connections as the amount of data transferred is small and the session establishment overhead would introduce unnecessary traffic and load on nameservers. DNS zone file transfers between nameserver peers use TCP connections as the volume of data transferred is potentially much larger.

A DNS domain definition (sometimes referred to as a 'zone file') consists of individual DNS records. There are several record types in common usage:

  * **SOA** or Start Of Authority records contain parameters for the domain definition itself.
  * **A** records resolve names into an IP addresses
  * **PTR** records resolve IP addresses to names
  * **NS** records define the authoritative nameservers for the domain.
  * **CNAME** or Canonical Name records allow aliasing of one name to another.
  * **MX** or Mail Exchange records define the mail server associated with a domain or A record.
  * **HINFO** or Hardware Information records can be used to hold descriptive text about a specific device.

Virtually all modern operating systems and network applications contain resolver libraries or routines for interrogating DNS services. However, OSs generally provide a command line interface for querying DNS servers. The Windows NT family of operating systems provides the 'nslookup' command. Unix-based operating systems may also offer 'nslookup' or 'dig' tools.

**nslookup** can either be used interactively, or non-interactively. An example of non-interactive usage follows. In this example, we gather the A record for www.wikipedia.org from the client's default nameserver:

_nslookup www.wikipedia.org_

Nslookup is somewhat more powerful when used interactively. An example of this follows. In the example, we find the mail servers for the domain wikipedia.org:

_nslookup_

_> set q=MX_

_> wikipedia.org_

_Non-authoritative answer:_

_wikipedia.org MX preference = 50, mail exchanger = mormo.org_

_wikipedia.org MX preference = 10, mail exchanger = mail.wikimedia.org_

_>_

See also: [cybersquatting](//en.wikipedia.org/wiki/cybersquatting), [dynamic DNS](//en.wikipedia.org/wiki/dynamic_DNS), [ICANN](//en.wikipedia.org/wiki/ICANN), [DNSSEC](//en.wikipedia.org/wiki/DNSSEC)

## External links

  * [DNS & BIND Resources](http://www.bind9.net/)
  * [DNS Security Extensions (DNSSEC)](http://www.dnssec.net/)
  * [Domain Name FAQs](http://www.hostfaqs.info/Domains.php)
  * [www.root-servers.org](http://www.root-servers.org/)
  * [RFC 882](http://ietf.org/rfc/rfc0882)
  * [RFC 883](http://ietf.org/rfc/rfc0883)
  * [RFC 1034](http://ietf.org/rfc/rfc1034)
  * [RFC 1035](http://ietf.org/rfc/rfc1035)

  


# Web hosting

**Web Hosting: An Introduction**

_Important: Someone needs to write the "Types of Hosting Control Panels" section. This article also needs cleanup._

## What is Web Hosting?

When someone sets up a server and hooks it up to the Internet, the files on the server become accessible over the Internet. Web Hosting is the space on a Web server where you can upload files. If you upload HTML files, you'll have a Web site. If you upload .ZIP files, you'll have a download area. There are a lot of organizations that provide Web hosting.

## What does Web Hosting do?

Most companies own their own servers these days, but some still pay for Web hosting. Let's say John Doe decides he wants to sell his paintings online. He purchases Web hosting, and sets up a Web site. Jane Doe, on the other hand, wants to set up a forum system. She purchases Web hosting and installs the forums. If you know how, you can make an entire Web site, or put any files you want, online, via your Web hosting.

In addition, over the last few years hundreds of "Web site softwares" have been written that, when installed onto your hosting account, give you an immediate Web site.

When looking for a Web site software, it's important to consider the software license. If you stick with [free software](http://www.gnu.org/philosophy/license-list.html) when selecting your Web site software, you will have the advantage of new software releases that are made available free of charge. Commercial, albeit more powerful, alternatives are often available..

## How and Where can I get hosting?

Web hosting is available in two forms — paid and free.

Paid Web hosting has a periodic fee, be it monthly, quarterly or annually, and typically provides considerable amounts of storage space for your files. Depending on the service, one may get additional support for server-side scripts, Web commerce support, visitor traffic reports, and so on. If the hosting service has high-speed connections to the Internet and fast server equipment, it may be able to provide access for many thousands of visitors and allow downloading of tens of gigabytes of files, and more, per day. Technical support is usually available around the clock, by telephone, Web chat or email, allowing the subscriber to resolve most problems in a few minutes, or, at most, in several hours.

Free hosting, on the other hand, typically has severely limited file storage space and low bandwidth provisions. It may be run on equipment that is just as capable as that used by paid hosting services, but it is usually an adjunct to some other business being carried out by the provider. Your Web pages will be presented to the site visitor along with advertising banners or pop-up advertisements as a way of recovering the cost of providing this free service to you. Support for server-side scripts may be limited or non-existent, as well as access to many of the basic functions that most Web hosting programs are capable of providing. Technical support is usually limited, usually by email only, with response times figured in days. If you are a novice, a free service may be the place to start, as they often provide semi-automated site-building templates and online tutorials.

With the recent drop in monthly fees for Web hosting — usually in the range of a few dollars a month for a basic plan — it is recommended that one subscribe to decent, commercial hosting service.

Free hosting sites are over-subscribed and would be good for those who do not mind waiting for periods of time for support resolution.

## Reseller vs. Shared

Reseller accounts allow clients to divide their account and sell or distribute these allocations to other users. For example, if John purchases a 10GB reseller account, he can then sell ten 1GB accounts. Shared hosting refers to the fact that there are usually 100+ people per server — in effect, "sharing" the server.

## Types of hosting control panels

[Comparison of Web hosting control panels](http://en.wikipedia.org/wiki/Comparison_of_web_hosting_control_panels) at Wikipedia

## Running a site on your personal computer

_This section should probably be removed or moved into a new section/category — running a home server is not related to remote Web hosting._

Most home Internet connections can be used to create a home server to act as your personal Web Host. Depending on connection speed (especially upload speed), it can be slow or fast. The simplest type of Web server is probably running HTTP server software like Apache using an operating system, typically either Linux or Windows.

## Further reading

More information is available on the [Wikipedia](//en.wikipedia.org/wiki/Web_hosting) article about Web Hosting.

  


# Routing

A **route** is the path that data takes when travelling through a network from one host to another. Routing is the process by which the path, or some subset of it, is determined. One of the characteristic features of the Internet, as compared to other network architectures, is that each node that receives a packet will typically determine for itself what the next step in the path should be.

  
IP routing decisions are generally made based on the destination of network traffic. When an IP packet is sent from a node on the network, it will consult its _routing table_ to determine the next hop device that the traffic should be sent to, in order for it to reach its final destination. The routing table on a typical home machine may look something like this (except formatted properly :):
    
    
    Kernel IP routing table
    Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
    x.y.z           *               255.255.255.255 UH    0      0        0 ppp0
    192.168.0.0     *               255.255.255.0   U     0      0        0 eth0
    127.0.0.0       *               255.0.0.0       U     0      0        0 lo
    default         x.y.z           0.0.0.0         UG    0      0        0 ppp0
    

So, for example, when it receives a packet on interface eth0 which has a destination of 216.239.59.104, it will consult the table and see that it should send it through the default interface, the host x.y.z, which is on interface ppp0.

The routing table is constructed from a combination of statically defined routes and those learned from dynamic routing protocols.

Statically defined routes may be declared at system boot time, or via a command line interface. They will generally include the following parameters:

  * **Destination** \- this may be either a single host, or a network (in which case a network mask is also required).
  * **Gateway** \- the device to which traffic with the defined destination should be sent.

Static routes may also include the following parameters:

  * **Interface** \- the interface through which the traffic to a destination must be sent. (Most OSs can determine this automatically)
  * **Metric** \- the number of 'hops' away that the gateway is from this host. For a gateway that resides on a directly connected network, the metric is '1'.

The _default route_ is a special case of a statically defined route. It is the route of last resort. All traffic that does not match another destination in the routing table is forwarded to the default gateway.

Dynamic routing protocols allow network attached devices to learn about the structure of the network dynamically from peer devices. This reduces the administrative effort required to implement and change routing throughout a network. Some examples of dynamic routing protocols are:

  * **RIP** (Routing Information Protocol)
  * **OSPF** (Open Shortest Path First)
  * **ISIS** (Intermediate system to intermediate system)
  * **BGP** (Border Gateway Protocol)
  * **IGRP** (Interior Gateway Routing Protocol)

ISIS and OSPF are link-state protocols, meaning each node part of the same zone, will know the state of all the link in the mesh. Due to the exponential number of link in a mesh, thoses protocols are for small mesh such as an ISP national backbone.

RIP is usually used to easily announce customer's routes in a backbone.

BGP is used as an external routing protocol to exchange routes with other entities. ISP use BGP extensivly to "trade" their routes. It can also be used to carry customers routes accross a network, in a MPLS backbone for example.

  


# Protocols

In networking, a communications protocol or network protocol is the specification of a set of rules for a particular type of communication.

Different protocols often describe different aspects of a single communication; taken together, these form a protocol stack. The terms "protocol" and "protocol stack" also refer to the software that implements a protocol.

Most recent protocols are assigned by the IETF for internet communications, and the IEEE, or the ISO organizations for other types. The ITU-T handles telecommunications protocols and formats.

Index page for network protocols and protocol layers, categorised by the nearest matching layers of the OSI seven layer model.

Systems engineering principles have been applied to design network protocols.

### Common Internet protocols

Common Internet protocols include TCP/IP (Transmission Control Protocol/Internet Protocol), UDP/IP (User Datagram Protocol/Internet Protocol), HTTP (HyperText Transfer Protocol) and FTP (File Transfer Protocol).

TCP/IP 
    TCP/IP is a stream protocol. This means that a connection is negiotated between a client and a server. Any data transmitted between these two endpoints is guaranteed to arrive, thus it is a so-called lossless protocol. Since the TCP protocol (as it is also refered to in short form) can only connect two endpoints, it is also called a peer-to-peer protocol.

HTTP 
    HTTP is the protocol used to transmit all data present on the World Wide Web. This includes text, multimedia and graphics. It is the protocol used to transmit HTML, the language that makes all the fancy decorations in your browser. It works upon TCP/IP.

FTP 
    FTP is the protocol used to transmit files between computers connected to each other by a TCP/IP network, such as the Internet.

## See also

  * [Finding Your IP Address](/wiki/Finding_Your_IP_Address)
  * [Embedded Systems/Common Protocols](/wiki/Embedded_Systems/Common_Protocols)

  


# History and evolution

The Internet began life as a research project sponsored by ARPA. Previously US defense computers were connected to each other in a one way fashion such that each computer was connected to the others in series. In case of one computer being destroyed all others would lose communication. To avoid this the government decided to connect the computers in a web with each computer connected to all others. The motivation was to connect the few then existing proprietary computer networks to one interconnected network. The first version of the Internet was called ARPANET and was implemented in 1969. It then consisted of 4 Nodes in UCLA, UC Santa Barbara, Stanford Research Lab, and the University of Utah. It was to be the predecessor of what is today called the Internet.

  


# The Web

The **World Wide Web** (the "**Web**" or "**WWW**" for short) is a [hypertext](//en.wikipedia.org/wiki/hypertext) system that operates over the [Internet](//en.wikipedia.org/wiki/Internet). To view the information, you use a software program called a [web browser](//en.wikipedia.org/wiki/web_browser) to retrieve pieces of information (called "documents" or "[web pages](//en.wikipedia.org/wiki/web_page)") from [web servers](//en.wikipedia.org/wiki/web_server) (or "[web sites](//en.wikipedia.org/wiki/web_site)") and view them on your screen. You can then follow [hyperlinks](//en.wikipedia.org/wiki/hyperlink) on the page to other documents or even send information back to the server to interact with it. The act of following hyperlinks is often called _"surfing"_ the web.

Looking further at web browsers, a web browser is an application program that accesses the World Wide Web, which then searches for wanted information on the Internet. The first web browser named Mosaic was developed in the early 1990s. The ease of information access provided by web browsers greatly added to the popularity of the Internet. Companies and individual users alike can use a browser to access untold amounts of information, and its as easy to find as clicking a mouse. The three most popular web browsers are Internet Explorer, Firefox, and Netscape. Tight competition has caused for continual improvement in the programs and associated technologies. Web browsers are loaded with ease-of-use features and are customizable to an individual user’s preference.

## URLs, HTTP and HTML

The core functionality of the Web is based on three standards: the _[Uniform Resource Locator](//en.wikipedia.org/wiki/URL)_ (URL), which specifies how each page of information is given a unique "address" at which it can be found; _[Hyper Text Transfer Protocol](//en.wikipedia.org/wiki/HTTP)_ (HTTP), which specifies how the browser and server send the information to each other; and _[Hyper Text Markup Language](//en.wikipedia.org/wiki/HTML)_ (HTML), a method of encoding the information so it can be displayed on a variety of devices.

Tim Berners-Lee now heads the [World Wide Web Consortium](//en.wikipedia.org/wiki/World_Wide_Web_Consortium), which develops and maintains these standards and others that enable computers on the Web to effectively store and communicate all kinds of information.

## Beyond text

The initial "www" program at CERN only displayed text, but later browsers such as [Pei Wei](//en.wikipedia.org/wiki/Pei_Wei)'s [Viola](//en.wikipedia.org/wiki/Viola_web_browser) (1992) added the ability to display graphics as well. [Marc Andreessen](//en.wikipedia.org/wiki/Marc_Andreessen) of [NCSA](//en.wikipedia.org/wiki/NCSA) released a browser called "[Mosaic](//en.wikipedia.org/wiki/Mosaic_web_browser) for X" in 1993 that sparked a tremendous rise in the popularity of the Web among novice users. Andreesen went on to found Mosaic Communications Corporation (now [Netscape Communications](//en.wikipedia.org/wiki/Netscape_Communications), a unit of [AOL Time Warner](//en.wikipedia.org/wiki/AOL_Time_Warner)). Additional features such as dynamic content, music and animation can be found in modern browsers.

Frequently, the technical capability of browsers and servers advances much faster than the standards bodies can keep up with, so it is not uncommon for these newer features to not work properly on all computers, and the web as seen by [Netscape](//en.wikipedia.org/wiki/Netscape_Navigator) is not at all the same as the web seen by [Internet Explorer](//en.wikipedia.org/wiki/Internet_Explorer). The ever-improving technical capability of the WWW has enabled the development of real-time web-based services such as [webcasts](//en.wikipedia.org/wiki/webcasts), [web radio](//en.wikipedia.org/wiki/web_radio) and live [web cams](//en.wikipedia.org/wiki/web_cam).

## Java and Javascript

Another significant advance in the technology was [Sun Microsystems](//en.wikipedia.org/wiki/Sun_Microsystems)' [Java programming language](//en.wikipedia.org/wiki/Java_programming_language), which enabled web servers to embed small programs (called [applets](//en.wikipedia.org/wiki/applet)) directly into the information being served that would run on the user's computer, allowing faster and richer user interaction.

The similarly named, but actually quite different, [JavaScript](//en.wikipedia.org/wiki/ECMAScript_programming_language) is a scripting language developed for Web pages. In conjunction with the [Document Object Model](//en.wikipedia.org/wiki/Document_Object_Model) (DOM), JavaScript has become a much more powerful language than its creators originally envisaged.

## Sociological Implications

The [exponential growth](//en.wikipedia.org/wiki/exponential_growth) of the Internet was primarily attributed to the emergence of the [web browser Mosaic](//en.wikipedia.org/wiki/Mosaic_web_browser), followed by another, [Netscape Navigator](//en.wikipedia.org/wiki/Netscape_Navigator) during the mid-1990s.

It brought unprecedented attention to the Internet from media, industries, policy makers, and the general public.

Eventually, it led to several visions of how our society might change, although some point out that those visions are not unique to the Internet, but repeated with many new technologies (especially information and communications technologies) of various era.

Because the web is global in scale, some suggested that it will nurture mutual understanding on a global scale.

## Publishing web pages

The web is available to individuals outside mass media. In order to "publish" a web page, one does not have to go through a publisher or other media institution, and the potential reader is around the globe, some thought. This to some is a oppportunity to enhance democracy by giving voices to alternative and minority views. Some others took it as a path to anarchy and unrestrained freedom of expression. Yet others took it as a sign that hierarchically organized society, mass media being a symptomatic part of it, will be replaced by so-called network society.

In addition, the hyper-text seemed to promote non-hierarchical and non-linear way of expression and thinking. Unlike books and documents, hypertext does not have a linear order from the beginning to the end. It is not broken down into the hierarchy of chapters, sections, subsections, etc. This reminded some of the idea of [Marshall McLuhan](//en.wikipedia.org/wiki/Marshall_McLuhan) that new media change people's perception of the world, mentality, and way of thinking. While not unique issue to the web, hypertext in this sense is closely related to the notion of "[death of author](//en.wikipedia.org/wiki/death_of_author)" and [intertextuality](//en.wikipedia.org/wiki/intertextuality) in [structuralist](//en.wikipedia.org/wiki/structuralism) literary theory.

These bold visions are at least not fully realized yet. We can find both supporting and countering aspects of web usage.

First, regarding the increased global unity, it is true that many different kinds of information are now available on the web, and for those who wish to know other societies, their cultures and peoples, it became easier. When one travels to a foreign country or a remote town, s/he might be able to find some information about the place on the web, especially if the place is in one of developed countries. Local newspapers, government publications, and other materials are easier to access, and therefore the variety of information obtainable with the same effort may be said to have increased, for the users of the Internet.

At the same time, there are some obvious limitations. The web is so far a very text-centered medium, and those who are illiterate cannot make much use of it. Even among the literate, usage of a computer may or may not be easy enough. It has been known during the late 1990s, though with ample exceptions, that web users are dominantly young male in college or with a college degree. Now the trend has been changing and female and elderly are also using the web, level of education and income are related to the web use, some think (See also the Wikipedia article [Digital divide](//en.wikipedia.org/wiki/Digital_divide)). Another significant obstacle is the language. Currently, only a limited number of languages are useable on the web, due to software and standard issues, and none would understand all the available languages. These factors would challenge the notion that the World Wide Web will bring a unity to the world.

Second, the increased oppportunity to individuals are certainly observable in the countless personal pages, as well as other groups such as families, small shops, which are not among those who publish materials. The emergence of free [web hosting](//en.wikipedia.org/wiki/web_hosting) services are perhaps an important factor in bringing this possibility into the reality. The activities of alternative media expanded into the web as well.

Yet not a small part of those pages seem to be either prematurely abandoned or one-time practice. Very few of those pages, even when they are well-developed, are popular. When it comes to the expression of ideas and provision of information, it seems that the major media organizations and those companies who became major organizations through their online operations are still favored by the dominant majority. In addition, the Web is not necessarily a tool for political self-education and deliberation. The most popular uses of the Web include searching and downloading of pornography, which perhaps have very limited effect in improving democracy. The most intensively accessed web pages include the document detailing the former U.S. president Bill Clinton's sexual misconduct with Monica Lewinsky, as well as the lingerie fashon show by Victoria's Secret. In sum, both in terms of writers and readers, the Web is not popularly used for democracy. While this is not enough to categorically reject the possibility of the Web as a tool for democracy, the effect so far seems to be smaller than some of the expectations for a quite simple reason, lack of interest and popularity. Anarchistic freedom of expression may be enjoyed by some, but many web hosting companies have developed their acceptable use policy over time, sometimes prohibiting some sensitive and potentially illegal expressions. And again, those expressions may not reach great many. The web is still largely a hierarchical place, some may argue.

Third, regarding non-linear and non-hierarchical structure of the Web, the effect of those on people's perception and psychology are still largely unknown. Some argue that our culture is changing to that of [postmodernity](//en.wikipedia.org/wiki/postmodernity), which is closely related to non-linear and non-hierarchical way of thinking, being, and even social organization. Yet the counter evidences are available as well. Among the most notable would be the existence of [web directories](//en.wikipedia.org/wiki/web_directory) and [search engines](//en.wikipedia.org/wiki/search_engine). Those sites often provide navigations to most popular sites to the visitors. In addition, it is quite obvious that many web sites are organized according to a simple hierarchy, having the "home page" at the top. At least the present state of the Web and web users seem to suggest the change has not been as great as envisioned by some.

  


# History of the Web

The Web grew out of a project at [CERN](//en.wikipedia.org/wiki/CERN), beginning around 1989, where [Tim Berners Lee](//en.wikipedia.org/wiki/Tim_Berners-Lee) and [Robert Cailliau](//en.wikipedia.org/wiki/Robert_Cailliau) built the prototype system that became the core of what is now the World Wide Web. The original intent of the system was to make it easier to share research papers among colleagues. The original name of the first prototype was Enquire Within Upon Everything, after a famous 19th century reference work of how-tos. Berners-Lee released files describing his idea for the "World Wide Web" onto the Internet on August 6, 1991.

## Works Cited

  


# HTML

## HTML

HTML is the language of the web.

**H**yper

**T**ext

**M**ark-up

**L**anguage

## For further reading

  * [Wikiversity: Web Design/Basic HTML and CSS](//en.wikiversity.org/wiki/Web_Design/Basic_HTML_and_CSS)
  * [HTML Programming](/wiki/HTML_Programming)

  


# Embedded technologies

## Embedded technologies

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  


Embedded Technologies in the context of the internet are stand-alone programs and plugins that extend the normal functionality of a web page. Java, Shockwave Flashtm, audio and video players are all examples of embedded technologies that can assist creating a web site.

## See also

  * [Macromedia](http://www.macromedia.com)
  * [Java](http://www.java.sun.com)
  * [xine](http://xinehq.de)
  * [mplayer](http://www.mplayerhq.hu)
  * [xmms](http://www.xmms.org)

  


# Proxy servers

Proxy servers provide a cache of items available on other servers which are presumably slower, more expensive to access or unavailable from the local network.

The process of proxying a network through a single host on another network is called network masquerading or IP-masquerading if the source and target networks use the Internet Protocol.

This term is used particularly for a World Wide Web server which accepts URLs with a special prefix. When it receives a request for such a URL, it strips off the prefix and looks for the resulting URL in its local cache. If found, it returns the document immediately, otherwise it fetches it from the remote server, saves a copy in the cache and returns it to the requester. The cache will usually have an expiry algorithm which flushes documents according to their age, size, and access history.

The Squid cache is the popular http proxy server in UNIX/Linux world. However, Apache's mod_proxy module also provides proxying and caching capabilities, and has the advantage of already being installed on nearly all systems.

  


# Search engine

A **search engine** is a type of computer software used to search data in the form of text or a database for specified information.

Search engines normally consist of spiders (also known as bots) which roam the web searching for links and keywords. They send collected data back to the indexing software which categorizes and adds the links to databases with their related keywords. When you specify a search term the engine does not scan the whole web but extracts related links from the database.

Please take note that this is **not** a simple process. Search engines literally scan through millions of pages in its database. Once this has taken place all the results are put together in order of relevancy. Remember also not to get a search engine and directory mixed up. Yes they are used interchangeably, but they do in fact perform two different tasks!

Before 1993 the term search engine never existed. From then until now that has changed drastically, and almost everyone knows what it is. Since the Internet is used by millions of Americans daily, a search engine sees a lot of visitors especially ones such as Google and Yahoo. Almost all of us use one of the two if we have the Internet. By simply typing words into the engine, we get several results which gives us a list of sites. (Seigel)

Usually a search engine sends out a spider which fetches as many documents as possible. An index is then created by what is called an indexer that reads the documents and creates it. Only meaningful results are created for each query though, a process called proprietary algorithm. (Webopedia)

## Sources

(2004, October 5). Search Engine. Retrieved September 19, 2008, from Webopedia Web site: <http://www.webopedia.com/TERM/s/search_engine.html>

Seigel, Carolyn (2006). Internet Marketing. Boston, MA: Houghton Mifflin Company.

## Work Cited

Boswell, Wendy. "How do search engines work?" What is a search engine? 19 September 2008. <http://websearch.about.com/od/enginesanddirectories/a/searchengine.htm>

  


**Did You Know?**

* * *

Google's spider is known as Googlebot. You can make Googlebot not add a page to its database. For more information, click [here](http://www.google.com/bot.html#robotsinfo).

  


# Web advertising

Web Advertising uses static images, animated GIFs, and Flash Animation to display a product or service. Advertising on the Web displays in many different ways such as banners or buttons, Pop-up and Pop-under, and intro pages to websites.

A banner or a button can be an image, animated gif, flash video or plain text

A Pop-up or Pop-under causes a new browser window to open and displays a webpage that can contain text, images and flash.

Intro Pages to websites usually have a flash or gif animation to introduce a company, their services or Products.

  
Internet advertising is delivered by ad servers. The most common type of ad server in use today is the [Central ad server](http://en.wikipedia.org/wiki/Central_ad_server).

* * *

Standard Sizes for Banner Style Advertisements are as follows:  


Rectangles -  


300x250  
250x250  
240x400  
336x280  
180x150  


Banners -  


468x60  
234x60  
88x31  
120x90  
120x240  
125x125  
728x90  


Skyscrapers -  


160x600  
120x600  
300x600  


  


# Online shopping

**Online shopping** is just like going to the store and shopping around and looking for things you want except in form of the internet. Tim Berners-Lee started the World Wide Web in 1990. Shortly there after, online shopping started and has expanded exponentially ever since. It provides such a convenience for consumers to keep from having to leave the house or use gas to get to all the different stores, where online shopping you can get anything you want from as many different stores as you want all at one time. Online shopping mainly takes place from people using search engines and typing in exactly what they want. Then the search engine will bring up the most popular sites for the items you look for. Once you find what you are looking for online, most sites will let you put the item in a shopping cart just like a brick and mortar store, so you can keep searching around for anything else that you may need.

Shopping online makes life so much easier because you can just type in a debit card number, wire money, deliver money, electronic money, etc. and be done with it within seconds or minutes. It makes life easy, but you just have to be careful what sites you order from because of all the scams that go on everyday. It is so easy for hackers today to steal people's identity, so being smart is definitely a key when shopping online.

It makes it easy for companies to use online catalogs or stores to do business not only because people will use it but because there is so much more of a selection that they can put online and not even have in the actual store due to space constraints.

## Online Auctions

Online auctions have become increasing popular with the rise of online shopping. These auctions allow buyers and sellers to obtain and sell products and services quickly and efficiently. Auctions allow for individuals and businesses to extend their products and services to a much larger customer base.

In 1995, the current powerhouse, Ebay, was started from founder Pierre Omidyar's house. While bidding and searching through auctions is free, sellers are charged certain fees:

\- A nonrefundable Insertion Fee is charged which can cost a seller anywhere from 30 cents up to $3.30, depending on the seller's starting bid on the item. - If a seller wishes to further promote their listings, the seller can highlight a listing for an additional fee. - A Final Sale fee is charged at the end of the seller's auction. This fee generally ranges from 1.25% to 5% of the final sale price.

At the end of the auction, both the seller and the buyer are notified by Ebay. The seller usually has a minimum price they will accept for the bid item. If the buyer's bid exceeds the seller's lowest price, the transaction is completed between the two parties or independently of eBay. The above rules apply to Ebay itself, but all auction-based websites charge fees for providing customers with a specific place for e-commerce.

Although Ebay is a widely recognized name in the Internet world, there are several other popular auctions sites such as Ubid.com, Bidz.com, Webidz.com. Popularity and use of auction sites has become more common, however, there are some downsides to these websites. Once an auction has ended, the binding contract of the auction is between the winning bidder and the seller only. Meaning the actual website has limited to no liability for a bad transaction. Auction sites do provide their customers with several options to retrieve money from a dishonest buyer or seller. If these options fail to achieve results, the buyer or seller is essentially on their own.

There are many benefits from online auctions. Individuals and businesses sell and purchase products that are sometimes hard-to-find and hard to sell. Usually, these products come at cheaper prices, and can be found right in the comfort of your own home.

## Works Cited

  * <http://www.cs.brandeis.edu/~magnus/ief248a/eBay/history.html>
  * <http://en.wikipedia.org/wiki/EBay>

  


# Email

Since the beginning of time, our innate nature creates a desire for convenience and a desire to find new ways to create convenience. The business world is especially guilty of this characteristic as efficient operations are necessary in order to provide a profitable book of business. Over the past few decades the internet has made a grand entrance and a lasting impression on the business world. Since then, it seems, that the internet, and furthermore email, has made an even larger impression on the way business is conducted. While, seemingly enough all effects are positive, there are reasons that a company should "second-guess" its decision to utilize email in such heavy and reliant ways.

While email is convenient and efficient to send a message, whether it be to someone in your clientele base, a sister company across the nation or to someone in the cubicle next to you, email can also create communication barriers that could have an everlasting effect on your business, especially concerning customer service. Email creates a way to send bills, eliminate phone calls and provide services to your customers without ever having contact with that customer. Eliminating your "one-on-one" contact with everyone involved in your business creates hazards such as dishonesty, miscommunication in unerstanding company policies, etc. Below are a few more adverse effects that email could have on a business as reported by Paul McFredrie, (<http://www.mcfedries.com/Ramblings/email-pros-cons.asp>):
    
    
        Creates an impersonal environment
        Excessive involvement (can require more attention than you can give)
        Lax in security
        "Text-only" (can create massive and detrimental misunderstandings)
    

As duly noted, email has its obvious positive effects on our business world and definitely plays a large role in its success. However, we should always be aware of the problems that can be caused as well.

  


# History of email

Email began as an experiment by the military to be able to send to and from the battlefield. Thus was born email or electronic-mail

The first email was sent in 1972 using two machines by an engineer named Ray Tomlinsin. Later he wrote a mail program for Tenex, the BBN-grown operating system that, by now, was running on most of the ARPANET's PDP-10 machines. (Heliomedia) The mail program was written in two parts (1)to send messages, you would use a program called SNDMSG; (2)to receive mail, you would use the other part called READMAIL.(Heliomedia)

In 1972, the commands MAIL and MLFL were added to the FTP program and provided standard network transport capabilities for email transmission. FTP sent a separate copy of each email to each recipient, and provided the standard ARPANET email functionality until the early 1980's when the more efficient SMTP protocol was developed. Among other improvements, SMTP enabled sending a single message to a domain with more than one addressee, after which the local server would locally copy the message to each recipient. (Livinginternet)

Over the years the email has evolved with many different programs put with it and many people working to improve the email systems.

In 1993, the large network service providers America Online and Delphi started to connect their proprietary email systems to the Internet, beginning the large scale adoption of Internet email as a global standard. (Livinginternet)

The first important email standard was called SMTP, or simple message transfer protocol. SMTP was very simple and is still in use - however, as we will hear later in this series, SMTP was a fairly naïve protocol, and made no attempt to find out whether the person claiming to send a message was the person they purported to be. Forgery was (and still is) very easy in email addresses. These basic flaws in the protocol were later to be exploited by viruses and worms, and by security frauds and spammers forging identities. Some of these problems are still being addressed in 2004.

(Category: Net History)

Ian, Peter; <http://www.nethistory.info/History%20of%20the%20Internet/email.html>

  
E-mail predates the Internet; existing e-mail systems were a crucial tool in creating the Internet. 1965 as a way for multiple users of a time-sharing mainframe computer to communicate. Although the exact history is murky, among the first systems to have such a facility were SDC's Q32 and MIT's CTSS. E-mail was quickly extended to become network e-mail, allowing users to pass messages between different computers. The early history of network e-mail is also murky; the AUTODIN system may have been the first allowing electronic text messages to be transferred between users on different computers in 1966, but it is possible the SAGE system had something similar some time before. The ARPANET computer network made a large contribution to the evolution of e-mail. There is one report [1] which indicates experimental inter-system e-mail transfers on it shortly after its creation, in 1969. Ray Tomlinson initiated the use of the @ sign to separate the names of the user and their machine in 1971 [2]. The common report that he "invented" e-mail is an exaggeration, although his early e-mail programs SNDMSG and READMAIL were very important. The first message sent by Ray Tomlinson is not preserved; it was "a message announcing the availability of network email"[3]. The ARPANET significantly increased the popularity of e-mail, and it became the killer app of the ARPANET.

  
((Origins of E-mail)

<http://www.lookforemails.com/EmailFacts.aspx>

  


BBN was the first company to send an e-mail. BBN stands for Bolt Beranek and Newman. BBN was hired by the US Defense Department and created what is known as the ARPANET. The ARPANET helped to evolved into what is known today as the internet. The first e-mail was sent three years later in 1971 by Ray Tomlinson. Ray Tomlinson eventually was the first to use the @ symbol in his emails to show which message was sent at which computer to show that it wasnt a local host.

<http://www.mailmsg.com/history.htm>

One of the first new developments when personal computers came on the scene was "offline readers". Offline readers allowed email users to store their email on their own personal computers, and then read it and prepare replies without actually being connected to the network - sort of like Microsoft Outlook can do today. (Net History)

This was particularly useful in parts of the world where telephone costs to the nearest email system were expensive. (often this involved international calls in the early days) With connection charges of many dollars a minute, it mattered to be able to prepare a reply without being connected to a telephone, and then get on the network to send it. It was also useful because the "offline" mode allowed for more friendly interfaces. Being connected direct to the host email system in this era of very few standards often resulted in delete keys and backspace keys not working, no capacity for text to "wrap around" on the screen of the users computer, and other such annoyances. Offline readers helped a lot. (Net History)

The first important email standard was called SMTP, or simple message transfer protocol. SMTP was very simple and is still in use - however, as we will hear later in this series, SMTP was a fairly naïve protocol, and made no attempt to find out whether the person claiming to send a message was the person they purported to be. Forgery was (and still is) very easy in email addresses. These basic flaws in the protocol were later to be exploited by viruses and worms, and by security frauds and spammers forging identities. Some of these problems are still being addressed in 2004. (Net History)

But as it developed email started to take on some pretty neat features. One of the first good commercial systems was Eudora, developed by Steve Dorner in 1988. Not long after Pegasus mail appeared. (Net History)

When Internet standards for email began to mature the POP (or Post Office Protocol) servers began to appear as a standard - before that each server was a little different. POP was an important standard to allow users to develop mail systems that would work with each other. (Net History)

These were the days of per-minute charges for email for individual dialup users. For most people on the Internet in those days email and email discussion groups were the main uses. These were many hundreds of these on a wide variety of topics, and as a body of newsgroups they became known as USENET. (Net History)

With the World Wide Web, email started to be made available with friendly web interfaces by providers such as Yahoo and Hotmail. Usually this was without charge. Now that email was affordable, everyone wanted at least one email address, and the medium was adopted by not just millions, but hundreds of millions of people. (Net History)

  


# Routing email

Email routing is performed based entirely on the destination address of the email message. An email address has the following format:

_username_ **@** _domain_

(For example: user@wikipedia.org)

While it would be theoretically possible for mail clients to deliver their own messages directly to recipients, this is not desirable. So, an end user's mail client will deliver outbound messages to their local mail server using SMTP or a similar protocol.

The local mail server then performs a DNS lookup to find the 'MX' (mail exchanger) records for the recipient's domain name. These MX devices are the designated mail servers for all email addresses within that domain.

The local server then attempts an SMTP connection to each of the MX servers in order of priority, until a connection is successful. It forwards the message to the remote server and ends the connection.

The remote mail server then either repeats this process, forwarding the message closer to the intended recipient, or may deliver the message directly to the recipient.

**History**

Prior to the advent of the SMTP protocol, email was delivered using the UUCP (Unix-to-Unix Copy Protocol).

In the early days of SMTP, before Spam became a massive problem on the Internet, it was possible to manually define the route that an email message was to take. This was done by appending multiple "@domain" entries to a recipient address. For example:

user@domain1.com@domain2.com@domain3.com

A message with this recipient address would be routed first to the mail server for domain3.com, then to the mail server for domain2.com, then finally to the mail server for domain1.com where it would be delivered to the local user.

Due to anti-relaying restrictions now in place on Internet-accessible mail servers, this is generally no longer possible.

  


# Email spam

Email spam (or just "Spam") is unsolicited email, similar to conventional "junk mail", but often on a larger scale.

Spam is estimated to have cost U.S. organizations over $10 billion (in lost productivity) in 2003.

Various software products are available to block or filter spam. Even lawmakers are stepping up to fight spam- in the United States the Can-Spam Act of 2003 was passed into law.

"Spammers" - people or organizations responsible for sending out email spam - use large lists of email addresses that are collected in a number of ways. One of these means is by using computer programs that search websites for email addresses. An email address that appears on a website is therefore more likely to get spammed, other things being equal. There are various ways of preventing your email being harvested in this way. One is to include it as an image rather than a link. This is not ideal, though, because it means firstly that people will have to type the address themselves, and secondly, it makes the address inaccessible to blind people, or people who browse without images. An alternative, better method, is to use a small piece of 'JavaScript' to insert the email address into the page when it is displayed, keeping it out of the html which an email-collecting spam program might look at. One final method is to create a contact form to display on your website. The website user would fill out the form which when submitted forwards the message to you without displaying your email address. This final method has one drawback in that it circumvents the user's email system and does not provide the user with a record of the email that they sent.

I have also seen many people try the format of me@REMOVETHISaol.com or whatever. The person who has a genuine interest in emailing you will remove the REMOVETHIS part of the eddress before sending, but programmes that gather email addresses en-masse will use it as-is - thus, you do not receive spam. One must be fairly inventive to make this effective; the instance given would be algorithmically handled by most site-scraping email bots.

In addition, there is a new anti-spam feature now availible. Named the "Challenge/Response System", this either sends a link, or a word-verification page to a user, the first time they e-mail you. The user must either click the link or enter the word to verify they are not a spamming program. After this, you get the e-mail and they're added to your allow list.

A study, by Brockmann & Company IT consultants showed that challenge-response proved to be superior to appliances, hosted spam filters and commercial filters.Brockmann surveyed more than 500 businesses, with 40% of the respondents having IT responsibilities. The independently funded study resulted in the creation of a spam index to measure how satisfied workers were with their spam technologies.

Despite being less sophisticated than filtering technology sold by antispam and antivirus vendors, the challenge-response method was twice as effective as hosted services for spam prevention. According to the survey, 67% of challenge-response users specified that they are very satisfied with their email experience as compared to next highest technology, hosted services, in which 42% reported that they were very satisfied. Commercial software filters, such as those produced by McAfee, Symantec and Trend Micro, scored the lowest satisfying only 22% of respondents.(SearchSecurity.com, Robert Westervelt Jul. 2007)

www.bluebottle.com currently offers a public beta of this software.

Spam is a very common thing and at one point or another it is something that we have all had. Spam is not only an annoying email, it is a tactics for marketing. However many times you have received this type of email, it is becoming more and more dangerous. It can be generated by businesses as well as individuals. It is used to promote products and is also brought about by things like forwarding ( things like jokes, images or chain letters) spam can be used to gather information from your computer if opened as well as used to send out viruses. It is becoming an increasing threat. Spam has become such an issue, that people now have to have an entire email address just as a "throw away account" an email address specifically catered toward junk mail because if we were to let it, it would take up about 90% of our inbox's, not only is this an issue for our email account but it is also being directed towards our phone, and needs to be handled with caution Email-spam-sample.png‎ Spam is a very common thing and at one point or another it is something that we have all had. Spam is not only an annoying email, it is a tactics for marketing. However many times you have received this type of email, it is becoming more and more dangerous. It can be generated by businesses as well as individuals. It is used to promote products and is also brought about by things like forwarding ( things like jokes, images or chain letters) spam can be used to gather information from your computer if opened as well as used to send out viruses. It is becoming an increasing threat. Spam has become such an issue, that people now have to have an entire email address just as a "throw away account" an email address specifically catered toward junk mail because if we were to let it, it would take up about 90% of our inbox's, not only is this an issue for our email account but it is also being directed towards our phone, and needs to be handled with caution ![Email-spam-sample.png](//upload.wikimedia.org/wikipedia/commons/c/c3/Email-spam-sample.png)

## External Links

  * [Can-Spam Act of 2003](http://www.spamlaws.com/federal/108s877.html)
  * [The Coalition Against Unsolicited Commercial Email](http://www.cauce.org/)
  * [Fight Spam on the Internet!](http://spam.abuse.net/)
  * [Spam Assassin Website](http://useast.spamassassin.org/index.html) \- Server software designed to detect Spam and denote it before the user downloads the message.

  


# Email security

Over time, e-mail has been one of the most used components to send messages around the world or to people around oneself. Also, e-mail has alot of harm that can happen while in the process. There are different types of components that may occur while sending an innocent message to others. Email threats can be divided into several distinct categories: Viruses, Worms and Trojan Horses, Phishing, and also Spam. According to "IT Security," Viruses, Worms and Trojan Horses are delivered as email attachments, destructive code can devastate a host system's data, turn computers into remote control slaves known as bootnets and cause recipients to lose serious money. Trojan horse keyloggers, for example, can surreptitiously record system activities, giving unauthorized external parties access to corporate bank accounts, internal business Web sites and other private resources. Phishing attacks utilize social engineering to steal consumers' personal and financial data. Spam Although not an overt threat like a virus-infected attachment, junk email can quickly overwhelm an inbox, making it difficult or even impossible for its owner to view legitimate messages. The spam problem has gotten so bad that it is commonplace for users to abandon email accounts that are overrun with spam rather than try to fight the problem. Spam is also the delivery medium of choice for both phishers and virus attackers. As we can see, emails might be one of the top used networks, but many consequences can come from the technology.

  


# Usenet

**Usenet** is a "network" of newsgroup servers (often run by ISPs) working together. Once connected to Usenet one can find everything from logical conversation to porn. One bad thing about Usenet is that it is often used to distribute warez, or illegal digital content like mp3s, Screeners, or cracked video games. In most cases Usenet is the first step in the life of warez. Unfortunately this has caused many newsgroup servers to block access to known warez newsgroups.

Usenet providers normally charge money for access but many ISPs have newsgroup servers running that their customers can access for free. So if you would like to check out Usenet first call your ISP and find out if they have a newsgroup server running.

## External Links

  * [Search engine for the alt.binaries newsgroups](http://www.usenetlive.com)

  


# History of Usenet

Tom Truscott and Jim Ellis developed Usenet as graduate students in 1979. They thought that the software could be replacement software for Duke University to post announcements. Steve Bellovin became interested in the software and wrote the first UNIX-based “news” software for the system. (Interview with Tom Truscott April 18, 2007)

At the time the current announcement software that was used by the university was made obsolete because of a hardware upgrade. Usenet was a side project of Truscott and Ellis that they worked on in their spare time. Bellovin wrote the script, and soon after “netnews” was created; linking Duke University and the University of North Carolina. Soon after the program was made available to the public and “A News” was created which was the first Usenet package. (Usenet History)

Usenet is bulletin board software where users with the correct software can read and post messages. It is still running today, URL’s that begin with news refer to Usenet groups. The NNTP or Network News Transport Protocol is the transportation system that sends out the Usenet messages. (Siegel 2006)

•Giganews, "Tom Truscott", Interview April 18, 2007, www.giganews.com/usenet-history/truscott.html

•Giganews, "Usenet History" <http://www.giganews.com/usenet-history/>

•Siegel F Carolyn, "Internet Marketing" Foundations and Applications 2E. Chapter 2 Internet Fundamentals, P-31

  


# IRC

![Search Meta](//upload.wikimedia.org/wikipedia/commons/thumb/7/75/Wikimedia_Community_Logo.svg/40px-Wikimedia_Community_Logo.svg.png)
Meta has related information at: 

_**[IRC instructions](//meta.wikimedia.org/wiki/IRC_instructions)**_

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Internet Relay Chat**_](//en.wikipedia.org/wiki/Internet_Relay_Chat), _**[List of IRC clients**_](//en.wikipedia.org/wiki/Special:Search/List_of_IRC_clients)  and _**[List of IRC commands**_](//en.wikipedia.org/wiki/Special:Search/List_of_IRC_commands)

**Internet Relay Chat**, commonly abbreviated **IRC**, is a chat protocol, a way how to enable several people to talk to each other by entering text messages, each participant seeing everything that the other participants write, as if they were in a telephone conference.

## Technology of IRC

Formally, IRC is a real-time text-based multi-user communication protocol specification and implementation, which relays messages between users on the network. According to [Efnet.org](http://efnet.org/), IRC was born sometime in 1988. According to [IRChelp.org](http://www.irchelp.org/irchelp/rfc/), the official specification for IRC was written in 1993 in the [RFC](//en.wikipedia.org/wiki/RFC) format. The specification "[RFC 1459](//tools.ietf.org/html/rfc1459): Internet Relay Chat Protocol" is a really excellent source for both and introduction to and for detailed information about the IRC protocol. Today IRC has a very wide range of users and anyone can find a place to participate in chat.

IRC's largest unit of architecture is the **IRC network**. There are perhaps hundreds of IRC networks in the world each one running parallel and disjoint from the others. A client logged into one network can communicate only with other clients on the same network, not with clients on other networks. Each network is composed of one or more **IRC servers**. An IRC client is a program that connects to a given IRC server in order to have the server relay communications to and from other clients on the same network but not necessarily the same server.

Messages on IRC are sent as blocks. That is, other IRC clients will not see one typing and editing as one does so. One creates a message block (often just a sentence) and transmits that block all at once, which is received by the server and based on the addressing, delivers it to the appropriate client or relays it to other servers so that it may be delivered or relayed again, et cetera.

Once connected to a server, addressing of other clients is achieved through **IRC nicknames**. A nickname is simply a unique string of ASCII characters identifying a particular client. Although implementations vary, restrictions on nicknames usually dictate that they be composed only of characters a-z, A-Z, 0-9, underscore, and dash.

Another form of addressing on IRC, and arguably one of its defining features, is the **IRC channel**. IRC channels are often compared to CB Radio (Citizen's Band Radio) channels. While with CB one is said to be "listening" to a channel, in IRC one's client is said to be "joined" to the channel. Any communication sent to that channel is then "heard" or seen by the client. On the other hand, other clients on the same network or even on the same server, but not on the same channel will not see any messages sent to that channel.

While IRC is by definition not a [P2P](/wiki/Internet_Technologies/Peer-to-Peer_\(P2P\)) protocol, IRC does have some extensions that support text and file transmission directly from client to client without any relay at all. These extensions are known as [DCC](//en.wikipedia.org/wiki/Direct_Client-to-Client) (Direct Client Connect) and [CTCP](//en.wikipedia.org/wiki/Client-To-Client_Protocol) (Client To Client Protocol). For CTCP, clients like mIRC implement commands such as "ctcp nickname version" or "ctcp nickname ping" to get some interesting infos about other users.

## Using Internet Relay Chat

To use Internet Relay Chat, you need to do the following:

  1. Choose and install an IRC client.
  2. Find the _channel_ discussing the topic of your interest (similar to a room in other chat environments).
  3. Find the _server_ at which the channel is located. You can be directed to both the server and the channel by the website of a project, such as Wikibooks.
  4. Connect to the _server_ using the client, using a nickname of your choice.
  5. Connect to the _channel_ (a room).

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
Provide more information on how to choose nicknames and their use and restrictions of registering them.

## Registering your nickname

Some IRC networks offer to register your nickname through a service bot. This provides sometimes access to channels that are blocked to unregistered users and in most cases reserves your nickname so no one else can use it (it will at least mark you as the logged in user and anyone else who uses it as not logged in).

The service bots providing this is mostly named "NickServ", sometimes also "AuthServ" or on a big network just "Q". When you found out which one of those bots exists, you can gather more information by typing:

    
    
    
    /msg [BOTNAME] help
    

This should get you detailed instructions on how to use the service.

### Example HowTo for a network

The process is fairly simple, once you have chosen a nickname you would like to register (assuming it's not owned by anyone else) and chosen a password, follow these steps:

  * If you have not done so already, change your nickname to the one you would like to register

    
    
    
    /nick [NICKNAME]
    

For example:

    
    
    
    /nick JohnDoe
    

  * Send a private message to the network's nickserv service with the password you chose and your email address with

    
    
    
    /msg nickserv register [PASSWORD] [EMAIL]
    

For example:

    
    
    
    /msg nickserv register 1234abcd JohnDoe@email.com
    

  * After messaging the nickserv you should shortly receive a reply back stating that the it received your registration request and sent an email to the address you provided.

    
    
    
    An email containing nickname activation instructions has been sent to JohnDoe@email.com
    

  * To complete the registration process, you will need to message the nickserv with the registration code emailed to your address.

    
    
    
    /msg NickServ VERIFY REGISTER JohnDoe p4huc5gqunnc
    

  * Once you have correctly entered the registration code, the nickserv should message you back stating the nick registration process was completed successfully.

    
    
    
    JohnDoe has now been verified.
    

You should now be "logged in" under your nick. If you disconnect from the server, to relogin under your nick you will need to message the nickserv with your password:

    
    
    
    /msg nickserv identify [PASSWORD]
    

For example:

    
    
    
    /msg nickserv identify 1234abcd
    

Once doing so, it should reply back saying you successfully logged in.

    
    
    
    You are now identified for JohnDoe
    

## Private conversations and chats

By default, the conversations using IRC are public, visible to all users in the channel.

To have a private conversation with a user in the channel, type "/query nickname".

To have a private chat, join an non-existent channel, and then allow joining only by invitation using the command "/mode +i". Chunked into steps:

  1. /join #mynewchannel
  2. /mode +i
  3. /invite someotherguy

## IRC clients

To use IRC, you'll need an IRC client--a program that lets you connect to an IRC server, and enter an IRC channel. There is a variety of IRC clients:

Some IRC clients

IRC Client Description OS Restrictions Note

[ChatZilla](http://www.mozilla.org/projects/rt-messaging/chatzilla/)
An add-in for Firefox.

[IRSSI](http://www.irssi.org)
Has a text-only user interface.

[mIRC](http://www.mirc.com)
Windows
Good for beginners.

[XChat](http://www.xchat.org)
([XChat-WDK](http://code.google.com/p/xchat-wdk/) for Windows)

[Smuxi](http://www.smuxi.org)
A user-friendly client for GNOME.
Linux and Windows

[Colloquy](http://colloquy.info)
For Mac OS X only.

[Pidgin](http://www.pidgin.im)
A multi-protocol client.
Has more chat protocols than IRC.

[Miranda](http://www.miranda-im.org)
A multi-protocol client.

[Trillian](http://www.trillian.cc)
A multi-protocol client.

[Opera](//en.wikipedia.org/wiki/Opera_\(web_browser\))
A web browser with integrated IRC client.

[BitchX](http://www.bitchx.org)

## IRC commands

What follows is an overview of some of the basic commands of the IRC protocol. All the commands are already prefixed with a slash "/", as in most clients this will indicate that an IRC command follows that shall be executed. With some IRC clients including ChatZilla and Pidgin, you do not need to know these commands: you tell the client what you want to do using the graphical user interface and the client sends the necessary commands for you.

### Basic commands

Some basic commands for IRC are listed in the following section. Please note that not all of them are available in all clients, as some of them are client-sided inventions to make your life easier and not part of the IRC protocol itself.

Command What it does Example

`/attach`

`/server`

`/connect`

Sign on to a server
`**/attach** irc.freenode.net`

`**/server** irc.freenode.net`

`**/connect** irc.freenode.net`

`/nick`
Set your nickname
`**/nick** YourName`

`/join`
Join a channel
`**/join** #wikibooks`

`/msg`
Sends a message (can either be private or to the entire channel)
Message the channel: `**/msg** #wikibooks hello world!`

Send a private message: `**/msg** JohnDoe Hi john.`

`/whois`
Display information about a user on the server
`**/whois** JohnDoe`

`/clear`

`/clearall`

Clears a channel's text. 

Clears all open channel's text.

`**/clear**`

`**/clearall**`

`/away`
Sets an away message. To return from "away", type `/away` or send a message.
`**/away** I'm away because...`

`/me`
Sends an action to the channel. See example.
The following: 

`**/me** loves pie.`

would output to the chat in the case of JohnDoe:

`**JohnDoe** loves pie.`

`/topic`
Querries or sets the topic of discussion.
`**/topic** Using IRC`

### Privileged User Commands

Commands for half-operators, channel operators, channel owners, and admins:

Command What it does Example

`/kick`
Kicks, or boots a user from the channel. **You must be a half-operator or greater to do this.**
Kick a user from the channel with a reason: `**/kick** #channel JohnDoe I kicked you because...`

`/ban`

`/unban`

Bans a user from the channel. **You must be a channel operator or greater to do this.**

Unbans a user from the channel. **You must be a channel operator or greater to do this.**

`**/ban** JohnDoe`

`**/unban** JohnDoe`

  


# Remote Access

Remote access allows you to access one computer from another using a protocol (ex. Secure Shell).

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Remote access**_](//en.wikipedia.org/wiki/Remote_access)

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Internet_Technologies/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

  


# Telnet

**Telnet** is a protocol designed to remotely access computers in a client-server fashion. Telnet is inherently insecure, as the data passed from the client to the server or vice-versa is not encrypted. For connections through insecure networks (such as the Internet), [SSH](/wiki/Internet_Technologies/SSH) (Secured SHell), should be used so all communications between the client and server are encrypted.

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Telnet**_](//en.wikipedia.org/wiki/Telnet)

## External Links

  


# SSH

[SSH](//en.wikipedia.org/wiki/SSH) is a secure replacement for [Telnet](//en.wikipedia.org/wiki/Telnet) and [rsh](//en.wikipedia.org/wiki/Remote_Shell). All communications between the client and server are encrypted. To access an SSH client (usually [OpenSSH](/wiki/OpenSSH)) in most Unix OSs, type `ssh user@host.com` in a terminal window. If you don't specify the username, the user that entered the command (`$USER`) will be used. In Windows, you will need to download a 3rd-party utility such as [PuTTY](http://www.chiark.greenend.org.uk/~sgtatham/putty) or Cygwin. Find more information in the ssh(1) man page. On other Operating Systems (smart phones for example, you will have to use a [webbased client](http://webssh.uni.me/)) There are several SSH apps for Android, including ConnectBot, Dropbear, ServerAssistant, and the Telnet / SSH Simple Client.[1]

## Uses

SSH is actually so much more than just a way to access a remote shell securely. It can be used for lots of other ways to transfer information securely. It includes a neat utility "scp", which stands for secure copy, which is a great way to copy files between machines. It works almost exactly like your default unix cp command. scp also allows you to copy a file from a remote host to a remote host. An example of scp:

`scp user@host.com:~/files/ .` which means copy files from user's home directory on the host.com machine from his files/ directory (it will copy ALL files from the files/ directory to the CWD (current working directory)).

Another great use is to use it to encrypt the transport of any data from one machine to another. As an extreme example, you can use SSH to remotely move a disk from one machine to another (akin to ghost, but securely). This may not be the best use of SSH, or the fastest way to transfer data from one machine to another over a network, but it shows you how powerful SSH can be.

Another great feature is port forwarding. This allows you 'redirect' communication to and from a local application through SSH to another host. So, with SSH you can secure otherwise insecure communications over an encrypted 'tunnel'.

### Using SSH

The secure shell client is conveniently called `ssh`.

    `ssh user@host`

### Using SFTP

SFTP has _nothing_ to do with FTP. SFTP merely works like FTP, meaning you use it as you would FTP. Using SFTP requires only the SSH server. The FTP server is irrelevant to SFTP. Files are transferred as binary by default.

    `sftp user@host`

### Using SCP

`scp`, aka Secure Copy, works just like `rcp`. Don't know what `rcp` is, then don't fret.

  * Copy to a remote host - You must use the colon. REMOTE_PATH is not necessary and all REMOTE_PATHs are relative to the user's home directory. 

    `scp FILE_PATH user@host:REMOTE_PATH`
  * Copy from a remote host 

    `scp user@host:REMOTE_PATH LOCAL_PATH`

Note : If your filename contains spaces then, use scp like this

  * file name is _/media/sda6/Tutorials/Linux Unix/linux_book.pdf_ then destination directory is _home/narendra/data_
    * `$scp _user_@_host_:"/media/sda6/Tutorials/Linux\\\ Unix/linux_book.pdf" /home/narendra/data`
  * file name is _/home/narendra/linux_book.pdf_ then destination directory is _/media/Tutorials/Linux Unix/_
    * $ `scp /home/narendra/linux_book.pdf _user_@_host_:"/media/Tutorials/Linux\\\ Unix/"`

Note : If you want to copy the whole directory then use

  * `scp -r user@host:"<source_dirname>" <destination_dirname>`

### Creating SSH Keys

Although SSH can be used with passwords, doing so is not recommended, and many servers will not allow password logins. Instead, use a key - this is more secure, and more convenient.

To create an SSH key...

Most modern Unix systems include the OpenSSH client. To generate a key, run:
    
    
    $ ssh-keygen -t rsa
    

This will store your private key in `$HOME/.ssh/id_rsa`, and your public key in `$HOME/.ssh/id_rsa.pub`. You can use different filenames, but these are the default filenames, so it's easiest to not change them.

### Permissions

Because the security of your private key is so important, SSH will not work if file permissions are insecure. SSH will create files and directories with the appropriate permissions, but sometimes things will go wrong. To fix permission issues:
    
    
    $ chmod 600 ~/.ssh/KEY ~/.ssh/KEY.pub
    $ chmod 700 ~/.ssh
    

### Establish Trust

To log into a remote server, you'll need to put the public key on that server.

#### ssh-copy-id

The easiest way to do that is using `ssh-copy-id`. This requires some alternate form of authentication, usually password (since you haven't got a key on the server you cannot use key authentication yet).
    
    
    $ ssh-copy-id -i ~/.ssh/id_rsa.pub user@host.net
    

#### Manual

  * Assume the directory is not on the destination server

    `ssh user@host "mkdir ~/.ssh && chmod 700 ~/.ssh"`

  * Upload your PUBLIC key only (not your private key)

    `scp ~/.ssh/KEY.pub user@host:.ssh/`
    `ssh user@host`
    `cd ~/.ssh`
    `cat KEY.pub >> ~/.ssh/authorized_keys`

  * Command for advance *nix users only!

    `cat ~/.ssh/KEY.pub | ssh user@host "cat >> ~/.ssh/authorized_keys"`

### SSH Personal Configuration

You don't need to set up a `~/.ssh/config` file, but it makes authentication easier. The important part is to specify your user name and your private key - if this is specified in the config file, you needn't provide it on the command line. Using HostName, you can shorten the ssh command to:
    
    
    $ ssh servername
    

#### Example
    
    
    #Specific configuration applied to one host
    #This configuration applies specifically to a host which uses Windows Domain login
    Host Short_Name
            HostName some_host.com
            User domain\username
            Protocol 2
            UseRsh no
            IdentityFile ~/.ssh/KEY
    
    # Generic configuration that I apply to all hosts, especially on my private LAN
    # Of note, the options to forward X11 and the SSH Agent.  X11 forwarding lets you
    # tunnel and X session or programs via SSH.
    Host *
            User USERNAME
            Protocol 2
            ForwardX11 yes
            ForwardAgent yes
            UseRsh no
            IdentityFile ~/.ssh/key_37_rsa
            FallBackToRsh no
            # In a pesky lab environment, add the following to your config
            # CheckHostIP no
    

You can now ssh into `some_host.com` with just `ssh Short_Name`.

### Using an SSH Agent

This part assumes that you are not using a ssh client configuration file and that your keys are protected with a passphrase. An excellent BASH utility script called [Keychain](http://www.gentoo.org/proj/en/keychain/) automates and simplifies the tedious use of ssh-agents. If your host does not have Keychain installed, ask your administrator. Alternatively you can download and unpack the script into your home directory from the [Keychain](http://www.gentoo.org/proj/en/keychain/) website.

#### Using Keychain

  * Start your agent on your local host

    `keychain` \- honestly you don't need to type this, simply loading your keys causes this to happen

  * Access your forwarded agent from a remote host

    `keychain --inherit any-once`

  * Load your key

    `keychain ~/.ssh/KEY`
    This will prompt you for a password (if you gave your key one!).

  * Unload your key

    `keychain --clear`

  * Stop the agent

    `keychain --stop`

#### BASH configuration Change

add the following lines to `~/.bash_login` and `~/.bashrc`

    `keychain`
    `source ~/.keychain/${HOSTNAME}-sh`

## [Public-key cryptography](//en.wikipedia.org/wiki/Public-key_cryptography)

The most significant difference between SSH and Telnet & rsh is in the realm of security. SSH uses [RSA](//en.wikipedia.org/wiki/RSA) or [DSA](//en.wikipedia.org/wiki/Digital_Signature_Algorithm) for [public-key cryptography](//en.wikipedia.org/wiki/Public-key_cryptography).

  * The server or domain to which you are trying to connect generates 2 keys (public and private) for a client.
  * The public key is given to the client the first time it tries to connect. The corresponding private key is a secret and kept with the server.
  * The client sends the packets of data by encrypting it through the public key and this data is decrypted by using the corresponding private key stored there.

Communication from the server to the client is also possible in the same way—the server encrypts using the client's public key and the client decrypts using it's private key.

## Setting up OpenSSH with public key cryptography

  1. With your distro's package manager, install sshd (or openssh-server) on the server, and on the client install ssh (or openssh-clients). It's likely that they're already installed since they're probably part of the distro's default installation.
  2. Make sure the following is there and uncommented (there's no # in front of them) in /etc/ssh/sshd_config on the server:
    
    
    PubkeyAuthentication yes
    PasswordAuthentication no
    

  1. On the client, `ssh-keygen -t rsa`.
  2. Copy where you saved your generated keys/id_dsa.pub to portable storage.
  3. Bring the portable storage to the server and mount it as the user you will be remotely logging in as. Don't log out yet.
  4. cat portable storage mount point/id_rsa.pub>>~/.ssh/authorized_keys
  5. Add either sshd:ALL or sshd:IP of client to /etc/hosts.allowed.
  6. Open TCP port 22. This varies depending on your firewall. For Fedora Core, RHEL, and derivatives, this can be done with system-config-securitylevel. For other GNU/Linux systems, echo '-A INPUT -p tcp -m tcp --dport 80 --syn -j ACCEPT'>>/etc/sysconfig/iptables and restart the iptables service. You may wish to run sshd on a non-standard port.
  7. If the server's behind a router: 
    1. Stop using DHCP and assign a static IP address to your server. See the Gentoo Handbook for instructions if you don't know how.
    2. Forward TCP port 22 to your server.
  8. (Re)start the sshd service.
  9. Test the setup by running ssh user to login as on the server@IP or domain of the server. Tip: If the username that you're logging in as on the server is the same as the one you're currently using on the client, you don't need to specify the user to log in as on the server.

## SSH as a Proxy

If you can make an SSH connection, you can (most likely) use that connection as a SOCKS proxy, without any extra setup on the remote computer. Traffic is tunneled securely through the SSH connection. If you are on an unsecured wireless connection, you can use this to effectively secure all your traffic from snooping. You can also use this to bypass IP restrictions, because you will appear to be connecting from the remote computer. Note that DNS traffic is not tunneled.

Pick some big port number (bigger than 1024 so you can use it as non-root). Here I choose 1080, the standard SOCKS port. Use the `-D` option for dynamic port forwarding.
    
    
    ssh -D 1080 user@host
    

That's it. Now as long as the SSH connection is open, your application can use a SOCKS proxy on port 1080 on your own computer (localhost). For example, in Firefox on Linux:

  * go to Edit -> Preferences -> Advanced -> Network -> Connection -> Settings...
  * check "Manual proxy configuration"
  * make sure "Use this proxy server for all protocols" is cleared
  * clear "HTTP Proxy", "SSL Proxy", "FTP Proxy", and "Gopher Proxy" fields
  * enter "127.0.0.1" for "SOCKS Host", and "1080" (or whatever port you chose) for Port.

## SSH from your webbrowser

You can also use ssh from a webbrowser with javascript support even when you don't have a secure shell client. In order to do this you have to install [AnyTerm, AjaxTerm or WebShell](//en.wikipedia.org/wiki/Web-based_SSH) on the system where the SSH server is running or use a third party service like [WebSSH](http://webssh.uni.me/).

## Further reading

  1. ↑ ["Top Free Android SSH Tools"](http://www.linuxlinks.com/article/20111022065038482/AndroidSSHTools.html)

  * [OpenSSH](/wiki/OpenSSH)
  * [SSH, the Secure Shell](/wiki/SSH,_the_Secure_Shell)
  * [LPI Linux Certification/Secure Shell (SSH)](/wiki/LPI_Linux_Certification/Secure_Shell_\(SSH\))

  


# VNC

**Virtual Network Computing** (VNC) is a remote desktop protocol to remote control another computer. VNC is used to transport the desktop environment of a graphical user interface from one computer to a viewer application on another computer on the network. There are clients and servers for many platforms including Linux, Microsoft Windows, Berkeley Software Distribution variants and MacOS X. In fact you would be hard pressed to not find a viewer available for any GUI operating system. The VNC protocol allows for complete platform independence. A VNC viewer on any operating system can connect to a VNC server on any other operating system. It is also possible for multiple clients to connect to a VNC server at the same time. Popular uses of the technology include remote tech support, and accessing your files on your work PC while at home or even on the road. There is even a Java viewer for VNC, so you can connect to a VNC server from your web browser without installing any software. The original VNC code is open source, as are many of the flavors of VNC available today.

## How it works

VNC is actually two parts, a client and a server. A server is the machine that is sharing its screen, and the client, or viewer is the program that is doing the watching and perhaps interacting with the server. VNC is actually a VERY simple protocol and is based one one and only one graphic primitive, "Put a rectangle of pixel data at a given x,y position". What this means is VNC takes small rectangles of the screen (actually the framebuffer) and transports them from the server to the client. This in its simplest form would cause lots of bandwidth to be used, and hence various methods have been invented to make this process go faster. There are now many different 'encodings' or methods to determine the most efficient way to transfer these rectangles. The VNC protocol allows the client and server to negotiate which encoding it will use. The simplest and lowest common denominator is the _raw encoding_ method where the pixel data is sent in left-to-right scanline order, and after initial setup, then only transfers the rectangles that have changed.

## how to copy and paste

How do I copy-and-paste from applications running on a server (visible inside a local VNC window) to applications running locally (outside the VNC window) and back?

Some people [[1]](http://www.realvnc.com/pipermail/vnc-list/2003-February/037299.html) [[2]](http://landru.uwaterloo.ca/cgi-bin/wiki.pl?Remote_Access) suggest using xcutsel or autocutsel as a work-around:

> On the VNC server side (inside the VNC window) run "`xcutsel &`". Leave it up and running.
> 
>   * 1\. If you want to copy from VNC to local, select what you want to copy, then click "copy PRIMARY to 0" in xcutsel, then paste in local.
>   * 2\. If you want to copy from local to VNC, select what you want to copy, then click "copy 0 to PRIMARY" in xcutsel, then paste in VNC window.

Others [[3]](http://www.lugs.org.sg/pipermail/slugnet/2002-July/000590.html) recommend autocutsel (or is it autcutsel?), pointing at [the VNC FAQ](http://www.uk.research.att.com/vnc/faq.html#q25).

For more about the subtleties of cutting and pasting in the X Window System, see ["X Selections, Cut Buffers, and Kill Rings."](http://www.jwz.org/doc/x-cut-and-paste.html) by Jamie Zawinski 2002 (especially helpful if you are writing X11 applications).

## External Links

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[VNC**_](//en.wikipedia.org/wiki/VNC)

  * [UltraVNC](http://www.ultravnc.com/) \- Most advanced free VNC - Supports RC4 encryption, Windows authentication, file transfer, and much more
  * [VNC Scan Enterprise Console](http://www.vncscan.com) \- VNC Manager designed for deploying UltraVNC and many others
  * [RealVNC](http://www.realvnc.com/)
  * [TightVNC](http://www.tightvnc.org/)
  * [Decryption of RealVNC Passwords](http://www.jonaspiela.de/code.html#vncdec)
  * Tristan Richardson, Quentin Stafford-Fraser, Kenneth R. Wood & Andy Hopper, "Virtual Network Computing", _IEEE Internet Computing_, Vol.2 No.1, Jan/Feb 1998 pp33-38 [PDF format](http://www.uk.research.att.com/pub/docs/att/tr.98.1.pdf)
  * [Ubuntu wiki: VNC over SSH](https://help.ubuntu.com/community/VNCOverSSH) \-- how to set up a secure VNC session, by running VNC over the secure shell (SSH) protocol.

  


# Remote Desktop Connection

**Note**: This is for Windows. Linux users may be interested in [VNC](/wiki/Internet_Technologies/VNC).

## What you can do with Remote Desktop Connection

Wish you could access your home desktop from work? Going on vacation, but want to be able to use your home computer? This can be easily done with Windows XP’s built in Remote Desktop Connection feature.

Some companies also use remote Desktop for technical support. Cisco systems (among others) allow engineers to use remote desktop to look in on issues and correct them. This troubleshooting method can save time and money for numerous industries.

### Setup

**In order to take advantage of remote desktop connection, you have to have port 3389 (TCP) open on your firewall/router. To do so consult your firewall or router’s manual.**

#### User Password

In order for remote desktop to work, you have to set a password on your user account. Follow these steps to set a password.

  1. Go to Start then to My Computer (or go to your desktop and go to My Computer)
  2. Go to Control Panel
  3. Go to User Accounts
  4. Click on your user account
  5. Go to Create a Password
  6. Fill everything out and hit Create Password

#### Enabling Remote Desktop Connection (on the host)

Now you’re ready to enable remote desktop. **You have to be logged in as an administrator**

  1. Go to Start then right click on My Computer (or right click My Computer on your desktop)
  2. Select Properties
  3. Go to the Remote tab
  4. Check “Allow users to connect remotely to this computer”
  5. If you have other users that you want to allow remote access to the computer then go to Select Remote Users and select add and type in the user account name of the user where it says “Enter the object names to select”

#### Getting your IP address

You now have to get your ip address. Please see [Finding Your IP Address](/wiki/Finding_Your_IP_Address) for more information.

#### Connecting to the host machine from another machine

Now, this is how to connect to your computer from using Remote Desktop Connection. If you’re using a computer that doesn’t have Windows XP then you can load the client side of Remote Desktop Connection. Get it at <http://www.microsoft.com/windowsxp/pro/downloads/rdclientdl.asp> and then you can follow these steps.

  1. Go to Start
  2. Go to All Programs
  3. Go to Accessories
  4. Go to Communications
  5. Click Remote Desktop Connection
  6. Go to Options and modify the options as you seem fit
  7. Type in your IP address by 'Computer'
  8. Log in with your username and password

You should now have access to your computer. Take note that playing music will not work well with over the remote connection unless you have it stay at the local computer (change this in the options). Also, if you view images and webpages over the connection it will be very slow. Oh, and of course, you can’t play games like Quake 3 over the connection, this simply isn’t possible.

Similar software does exist for other operating systems, such as rdesktop.

### Pros

  * You can access your documents from anywhere.
  * You can keep your IRC (internet relay chat) and IM clients open on one machine and then connect to your computer from other places. Thus you don’t have to leave your screen names and whatnot behind on other people’s computers.
  * Check and save email in YOUR email client instead of using webmail.
  * Perhaps your workplace/school doesn’t allow you to run IRC or IM clients, but you can use remote desktop. Then you can log on to your computer and IRC and IM from there.
  * You could use this as some sort of tech support method.
  * You can use Remote Desktop if you can’t always have a monitor plugged in to the box.
  * Great for servers, you don't need to buy keyboard, mouse, monitor etc. to use.

### Cons

  * You can’t play games with it, since the connection will have lag.
  * In order to start the server you have to log into your account, meaning if you’re on vacation and your computer locks up, you’ll have to have someone else reboot the computer and log in with your password. But this problem can be fixed by modifying a DLL file and adding a registry value. And up to 2 more computers can be connected remotely at the same time.

See the following link for more information on the procedure for enabling it.

<http://www.golod.com/2005/10/enabling-multiple-remote-desktop-sessions-in-windows-xp-professional-and-media-center-edition-2005/>

  * You need a broadband connection that is always on, if you want to be able to access it all the time. Dialup won’t cut it there.
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Internet_Technologies/Print_version&oldid=2145699](http://en.wikibooks.org/w/index.php?title=Internet_Technologies/Print_version&oldid=2145699)" 

[Categories](/wiki/Special:Categories): 

  * [Internet Technologies](/wiki/Category:Internet_Technologies)
  * [Pages needing to be dewikified](/wiki/Category:Pages_needing_to_be_dewikified)

Hidden category: 

  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Internet+Technologies%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Internet+Technologies%2FPrint+version)

### Namespaces

  * [Book](/wiki/Internet_Technologies/Print_version)
  * [Discussion](/w/index.php?title=Talk:Internet_Technologies/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Internet_Technologies/Print_version)
  * [Edit](/w/index.php?title=Internet_Technologies/Print_version&action=edit)
  * [View history](/w/index.php?title=Internet_Technologies/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Internet_Technologies/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Internet_Technologies/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Internet_Technologies/Print_version&oldid=2145699)
  * [Page information](/w/index.php?title=Internet_Technologies/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Internet_Technologies%2FPrint_version&id=2145699)

### In other languages

  * [العربية](//ar.wikibooks.org/wiki/%D8%A2%D9%8A_%D8%A2%D8%B1_%D8%B3%D9%8A)
  * [Česky](//cs.wikibooks.org/wiki/IRC)
  * [Dansk](//da.wikibooks.org/wiki/IRC-kursus)
  * [Español](//es.wikibooks.org/wiki/Tecnolog%C3%ADas_de_Internet/IRC)
  * [Français](//fr.wikibooks.org/wiki/Guide_d%E2%80%99utilisation_de_l%E2%80%99IRC)
  * [Italiano](//it.wikibooks.org/wiki/IRC)
  * [Polski](//pl.wikibooks.org/wiki/IRC/Ok%C5%82adka)
  * [Português](//pt.wikibooks.org/wiki/Internet_Relay_Chat)
  * [Suomi](//fi.wikibooks.org/wiki/IRC)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Internet+Technologies%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Internet+Technologies%2FPrint+version&oldid=2145699&writer=rl)
  * [Printable version](/w/index.php?title=Internet_Technologies/Print_version&printable=yes)

  * This page was last modified on 18 July 2011, at 17:59.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Internet_Technologies/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
