# Wikijunior:Maze and Drawing Book/Print version

From Wikibooks, open books for an open world

< [Wikijunior:Maze and Drawing Book](/wiki/Wikijunior:Maze_and_Drawing_Book)

![Edits to this page require review.](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/doc-magnify.png)![This is a reviewed version of this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/2.png)This is the [latest reviewed version](/wiki/Wikibooks:REVIEW), [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Wikijunior:Maze_and_Drawing_Book/Print_version) on _6 June 2013_.(+)

 **Quality**: minimal  

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Wikijunior:Maze and Drawing Book](/wiki/Wikijunior:Maze_and_Drawing_Book)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&action=purge&printable=yes) this page.

## Contents

  * 1 Christmas tree
  * 2 A knight searching his castle
  * 3 Witch's cottage
  * 4 Calf
  * 5 Mad Scientist
  * 6 Mona Lisa
  * 7 Find the odd one
  * 8 Birthday cake
  * 9 Wikipe-tan
  * 10 Missing instrument
  * 11 Pirate
  * 12 Samurai
  * 13 Plane
  * 14 Kites
  * 15 /Hen and chicks in a labyrinth
  * 16 Tux
  * 17 Vehicles
  * 18 Boys and men
  * 19 Sea world
  * 20 Squirrel's maze
  * 21 Pretty man
  * 22 Home

  


  


# Christmas tree

Color this christmas tree with the colors of your choice.

![Color this christmas tree.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/30/Color_this_christmas_tree.svg/600px-Color_this_christmas_tree.svg.png)

# A knight searching his castle

Help the knight to return to his castle.

![A knight searching his castle.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3c/A_knight_searching_his_castle.svg/600px-A_knight_searching_his_castle.svg.png)

# Witch's cottage

Color the house of the witch with the colors of your choice.

![Witch's cottage in black and white.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/15/Witch%27s_cottage_in_black_and_white.svg/600px-Witch%27s_cottage_in_black_and_white.svg.png)

# Calf

Take a pencil, follow the dashed line and then color the calf.

![Calf outline.svg](//upload.wikimedia.org/wikipedia/commons/thumb/5/59/Calf_outline.svg/600px-Calf_outline.svg.png)

# Mad Scientist

Color the mad scientist with the colors of your choice.

![Mad scientist bw.svg](//upload.wikimedia.org/wikipedia/commons/thumb/5/55/Mad_scientist_bw.svg/600px-Mad_scientist_bw.svg.png)

# Mona Lisa

Draw Mona Lisa's face.

![Draw Mona Lisa's face.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Draw_Mona_Lisa%27s_face.svg/600px-Draw_Mona_Lisa%27s_face.svg.png)

# Find the odd one

Find the odd one and circle it.

![Find the odd one among vegetables.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/17/Find_the_odd_one_among_vegetables.svg/600px-Find_the_odd_one_among_vegetables.svg.png)

# Birthday cake

Color this birthday cake with the colors of your choice.

![Draw this birthday cake.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/82/Draw_this_birthday_cake.svg/600px-Draw_this_birthday_cake.svg.png)

# Wikipe-tan

Color Wikipe-tan with the colors of your choice.

![Wikipe-tan full length bw.png](//upload.wikimedia.org/wikipedia/commons/thumb/c/c4/Wikipe-tan_full_length_bw.png/400px-Wikipe-tan_full_length_bw.png)

# Missing instrument

One musician has forgotten her or his instrument. Find her or him and circle her or him.

![Find the musician who has lost their instrument.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Find_the_musician_who_has_lost_their_instrument.svg/600px-Find_the_musician_who_has_lost_their_instrument.svg.png)

# Pirate

Color the Pirate with the colors of your choice.

![Piratey bw.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Piratey_bw.svg/383px-Piratey_bw.svg.png)

# Samurai

Help the samurai to find his castle through the labyrinth.

![Help the samurai to find his castle.svg](//upload.wikimedia.org/wikipedia/commons/thumb/0/07/Help_the_samurai_to_find_his_castle.svg/600px-Help_the_samurai_to_find_his_castle.svg.png)

# Plane

Color this plane with the colors of your choice.

![C 172 line drawing oblique.svg](//upload.wikimedia.org/wikipedia/commons/thumb/5/5c/C_172_line_drawing_oblique.svg/600px-C_172_line_drawing_oblique.svg.png)

# Kites

Find the Michiko's kite by following the string with a pen.

![Find the kite.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Find_the_kite.svg/600px-Find_the_kite.svg.png)

# /Hen and chicks in a labyrinth

[Wikijunior:Maze and Drawing Book//Hen and chicks in a labyrinth](/w/index.php?title=Wikijunior:Maze_and_Drawing_Book//Hen_and_chicks_in_a_labyrinth&action=edit&redlink=1)

# Tux

Color Tux the penguin with the colors of your choice.

![Tux bw.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/14/Tux_bw.svg/334px-Tux_bw.svg.png)

# Vehicles

Link with a pen the vehicle with the place we can find it.

![Link the vehicle with the right place.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Link_the_vehicle_with_the_right_place.svg/600px-Link_the_vehicle_with_the_right_place.svg.png)

# Boys and men

Circle all the boys only without circling the bad men. The lines may be crossed.

![Circle all the boys only.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Circle_all_the_boys_only.svg/600px-Circle_all_the_boys_only.svg.png)

# Sea world

Color this picture with the colors of your choice.

![Color this sea world.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Color_this_sea_world.svg/600px-Color_this_sea_world.svg.png)

# Squirrel's maze

Help the squirrel to find its oak nut.

![Squirrel's maze.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Squirrel%27s_maze.svg/600px-Squirrel%27s_maze.svg.png)

# Pretty man

Color this pretty man with the colors of your choice.

![DrawingPersonalityMan.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/cc/DrawingPersonalityMan.svg/600px-DrawingPersonalityMan.svg.png)

# Home

Link with a pen the resident with its home.

![Link the resident with its home.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Link_the_resident_with_its_home.svg/600px-Link_the_resident_with_its_home.svg.png)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&oldid=2533281](http://en.wikibooks.org/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&oldid=2533281)" 

[See also](/wiki/Special:Categories): 

  * [Wikijunior:Maze and Drawing Book](/wiki/Category:Wikijunior:Maze_and_Drawing_Book)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3AMaze+and+Drawing+Book%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3AMaze+and+Drawing+Book%2FPrint+version)

### Namespaces

  * [Wikijunior](/wiki/Wikijunior:Maze_and_Drawing_Book/Print_version)
  * [Discussion](/w/index.php?title=Wikijunior_talk:Maze_and_Drawing_Book/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Wikijunior:Maze_and_Drawing_Book/Print_version)
  * [Edit](/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&action=edit)
  * [View history](/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Wikijunior:Maze_and_Drawing_Book/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Wikijunior:Maze_and_Drawing_Book/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&oldid=2533281)
  * [Page information](/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Wikijunior%3AMaze_and_Drawing_Book%2FPrint_version&id=2533281)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Wikijunior%3AMaze+and+Drawing+Book%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Wikijunior%3AMaze+and+Drawing+Book%2FPrint+version&oldid=2533281&writer=rl)
  * [Printable version](/w/index.php?title=Wikijunior:Maze_and_Drawing_Book/Print_version&printable=yes)

  * This page was last modified on 6 June 2013, at 07:14.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Wikijunior:Maze_and_Drawing_Book/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
