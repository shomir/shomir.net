# GENtle/Print version

From Wikibooks, open books for an open world

< [GENtle](/wiki/GENtle)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [GENtle](/wiki/GENtle)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=GENtle/Print_version&action=purge&printable=yes) this page.

**GENtle** is an [open source](//en.wikipedia.org/wiki/open_source) software for [molecular biology](//en.wikipedia.org/wiki/molecular_biology). It is available at <http://gentle.magnusmanske.de> .

## About[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=1)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

## Rules[[edit](/w/index.php?title=GENtle/About&action=edit&section=T-1)]

  * Keys are marked `like this`
  * Menus, Buttons etc. are marked _like this_
  * "Double click" always refers to the left mouse button
  * "Context menu" always refers to the popup menu that appears on clicking with the right mouse button

## Copyright[[edit](/w/index.php?title=GENtle/About&action=edit&section=T-2)]

  * GENtle is © 2004-2008 by Magnus Manske, licensed under GPL
  * This manual is © 2004-2008 by its authors, licensed under GFDL

## Setup[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=2)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

## Installation[[edit](/w/index.php?title=GENtle/Setup&action=edit&section=T-1)]

On Windows, run the file `GENtleSetup.exe`. It will set up GENtle in a directory of your choice, and also prepare for a clean deinstallation.

## Databases[[edit](/w/index.php?title=GENtle/Setup&action=edit&section=T-2)]

There are two types of databases supported by GENtle: File-based (sqlite) and MySQL. By default, a file-based database `local.db` is set up in the installation directory of GENtle. You can (and should, if access limitations prevent you from working with local.db) create new databases and share them with other users of GENtle in your work group (if you want to).

Database management can be found through the menu "Tools/Manage database", under the tab "Databases".

### File-based databases[[edit](/w/index.php?title=GENtle/Setup&action=edit&section=T-3)]

You can add an existing or create a new database via the appropriate buttons. Select the database name and location in the following file dialog.

### MySQL databases[[edit](/w/index.php?title=GENtle/Setup&action=edit&section=T-4)]

These work similar to the file databases, but require more parameters. Also, a MySQL server has to be installed prior to MySQL database creation. Contact your local system administrator about this.

Creating a new MySQL database might require more MySQL privileges than actually using the created database. Thus, after creation, one might want to remove the database entry via the "Remove" button (the database will continue to exist), and add it again with different MySQL privileges.

## DNA[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=3)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e8/GENtle_dna.png/220px-GENtle_dna.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The DNA modul.

Within the DNA module, DNA sequences can be viewed, edited and annotated. It is the central module of GENtle. Two major components of the DNA module are the [DNA map](/wiki/GENtle/DNA_map) and the [Sequence map](/wiki/GENtle/Sequence_map); see there for details.

## Open and display DNA[[edit](/w/index.php?title=GENtle/DNA&action=edit&section=T-1)]

A DNA sequence can be opened in one of the following ways:

  * Open from a database (see [Databases](/wiki/GENtle/Databases))
  * Import from file (see [Import](/wiki/GENtle/Import))
  * Manual input (see [Enter sequence](/wiki/GENtle/Enter_sequence))
  * Create from another DNA module

## Toolbar[[edit](/w/index.php?title=GENtle/DNA&action=edit&section=T-2)]

Several functions and display options can be invoked in the tool bar:

  * [Enter sequence](/wiki/GENtle/Enter_sequence)
  * [Open sequence](/wiki/GENtle/Databases)
  * Save sequence
  * Undo
  * Cut
  * Copy
  * Paste
  * Toggle linear/circular
  * Show/hide open reading frames
  * Show/hide features
  * Show/hide restriction sites
  * Expand (=show only) map
  * Toggle edit mode
  * Zoom

## Detail tree[[edit](/w/index.php?title=GENtle/DNA&action=edit&section=T-3)]

The detail tree, left of the DNA map, shows all parts of the current sequence, including features and restriction enzymes, in a structured fashion. Features and restriction enzymes can be toggled in visibility by a double click, or further manipulated through the context menu.

## Special menus[[edit](/w/index.php?title=GENtle/DNA&action=edit&section=T-4)]

View/Show 3'->5'
Show the complementary DNA strand in the sequence map

Edit/Edit ORFs
Change the settings for open reading frame display

Edit/Show possible sequencing primers
Opens the [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) dialog, which can add possible sequencing primers as features

Edit/Remove sequencing primers
Removes all sequencing primers generated by the above function from the sequence

Edit/[Auto-annotate sequence](/wiki/GENtle/Automatic_annotation)
Finds features from common vectors and other databases in the current sequence

File/Print map
Prints the [DNA map](/wiki/GENtle/DNA_map)

File/Print sequence
Prints the [Sequence map](/wiki/GENtle/Sequence_map)

File/Print report
Prints a brief overview. See [Printing](/wiki/GENtle/Printing)

## DNA map[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=4)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ee/GENtle_dna_map.png/220px-GENtle_dna_map.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The DNA map.

The DNA map is shown for DNA sequences (though a variant is also used in [protein](/wiki/GENtle/Protein) module for the schematics display). It shows the linear or circular (e.g., plasmid) DNA sequence as a map.

## Display[[edit](/w/index.php?title=GENtle/DNA_map&action=edit&section=T-1)]

Displayed are

  * features (including optional [sequencing primers](/wiki/GENtle/Sequencing_Primers))
  * restriction sites
  * sticky ends (if any)
  * open reading frames (optional)
  * sequence name and length (optional, see [Options](/wiki/GENtle/Options))
  * methylation (optional, see [Options](/wiki/GENtle/Options))
  * GC contents (optional, see [Options](/wiki/GENtle/Options))

## Mouse actions[[edit](/w/index.php?title=GENtle/DNA_map&action=edit&section=T-2)]

Action on Mouse button Function

Background
left
Mark sequence

left (double click)
Open [Sequence editor](/wiki/GENtle/Sequence_editor)

middle
Show marked DNA in sequence; show current position in sequence if nothing is marked

Feature
left
Move feature display

left (double click)
Edit feature (see [Sequence editor](/wiki/GENtle/Sequence_editor))

middle
Mark DNA that matches feature

middle (`shift` pressed)
Extend currently marked area to include the DNA of the feature

Restriction site
left
Move site display

left (double click)
Edit enzyme list (see [Sequence editor](/wiki/GENtle/Sequence_editor))

middle
Open [Restriction Assistant](/wiki/GENtle/Restriction_Assistant)

Open reading frame
left
Mark ORF sequence

left (double click)
Mark and show ORF sequence

All
right
Context menu

## Context menu[[edit](/w/index.php?title=GENtle/DNA_map&action=edit&section=T-3)]

The context menu opens on a click with the right mouse button when somewhere inside the DNA map. The contents of the menu depends on what object in the map you clicked on. Also, depending on the properties of the object, some functions might not be available, for example, amino acids of a feature with no reading frame.

### Background[[edit](/w/index.php?title=GENtle/DNA_map&action=edit&section=T-4)]

Edit sequence
Opens the [Sequence editor](/wiki/GENtle/Sequence_editor)

Transform sequence
Make sequence inverted and/or complementary

Limit enzymes
Limits enzymes to those that cut no more than _n_ times

PCR/PCR
Starts the [PCR modul](/wiki/GENtle/PCR_and_Primer_Design)

PCR/Forward
Starts the [PCR modul](/wiki/GENtle/PCR_and_Primer_Design) and generates a 5'->3'-primer

PCR/Backward
Starts the [PCR modul](/wiki/GENtle/PCR_and_Primer_Design) and generates a 5'->3'-primer

PCR/Both
Starts the [PCR modul](/wiki/GENtle/PCR_and_Primer_Design) and generates both primers

PCR/Mutation
Starts the [PCR modul](/wiki/GENtle/PCR_and_Primer_Design) and generates overlapping mutagenesis primers

Selection/Cut
Removes the selected part of the sequence and puts it into the clipboard

Selection/Copy
Copys the selected part of the sequence into the clipboard

Selection/Copy to new sequence
Generate a new DNA sequence entry based on the selection

Selection/Show enzymes that cut here
Opens a variant of the [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) dialog for the selected part of the sequence

Selection/Selection as new feature
Generates a new feature for the selected part of the sequence

Selection/Extract amino acids
Extracts the amino acid sequence of the selected part of the DNA sequence

Selection/BLAST amino acids
Runs a BLAST search for the amino acid sequence of the selected part of the DNA sequence

Selection/BLAST DNA
Runs a BLAST search for the selected part of the DNA sequence

Sequence map/Save as image
Saves the DNA map as an image file

Sequence map/Copy image to clipboard
Copies the DNA map as a bitmap or WMF (see [Options](/wiki/GENtle/Options)) to the clipboard

Sequence map/Print map
Prints the DNA map

Show/hide ORFs
Toggles the open reading frame display

Edit ORFs
Adjusts the open reading frame display

### Restriction sites[[edit](/w/index.php?title=GENtle/DNA_map&action=edit&section=T-5)]

Edit restriction enzyme
Add/remove/manage restriction enzyme via the [Sequence editor](/wiki/GENtle/Sequence_editor)

Show/hide enzyme
Toggle visibility for the enzyme (this will affect all restriction sites for that enzyme in this sequence)

Remove enzyme
Remove the enzyme from the current selection (this will affect all restriction sites for that enzyme in this sequence).  
This will **not** work for automatically added enzymes (see [Options](/wiki/GENtle/Options#Enzyme_settings))

Mark restriction site
Marks the recognition sequence of that enzyme at that restriction site

Mark and show restriction site
Marks the recognition sequence of that enzyme at that restriction site and shows it in the sequence

Online enzyme information
Opens the [ReBase](http://rebase.neb.com/rebase/rebase.html) page for that enzyme

Add to cocktail
This adds the enzyme to the restriction cocktail (see [Restriction Assistant](/wiki/GENtle/Restriction_Assistant))

Add to cocktail
This adds the enzyme to the restriction cocktail (see [Restriction Assistant](/wiki/GENtle/Restriction_Assistant)) and starts the restriction

### Features[[edit](/w/index.php?title=GENtle/DNA_map&action=edit&section=T-6)]

Edit feature
Edit the feature properties (see [GENtle/Sequence editor](/wiki/GENtle/Sequence_editor))

Hide feature
Hide the feature from display

Delete feature
Delete the feature

DNA Sequence/Mark feature sequence
Mark the DNA sequence that matches the feature

DNA Sequence/Mark and show feature sequence
Mark the DNA sequence that matches the feature and shows it in the sequence

DNA Sequence/Copy (coding) DNA sequence
Copies the DNA sequence that matches the feature to the clipboard

DNA Sequence/This feature as new sequence
Generates a new DNA sequence based on the feature

DNA Sequence/BLAST DNA
Runs a BLAST search for the DNA of the feature

Amino acid sequence/Copy amino acid sequence
Copies the amino acid sequence of the feature to the clipboard

Amino acid sequence/As new entry
Generates a new protein entry based on the amino acid sequence of the feature

Amino acid sequence/Blast amino acids
Runs a BLAST search for the amino acid sequence of the feature

### Open reading frames[[edit](/w/index.php?title=GENtle/DNA_map&action=edit&section=T-7)]

As new feature
Generate a new feature from the ORF, with the appropriate reading frame and direction

DNA sequence/Copy DNA sequence
Copies the DNA sequence of the ORF to the clipboard

DNA sequence/As new DNA
Generates a new DNA sequence entry based on the DNA sequence of the ORF

DNA sequence/BLAST DNA
Runs a BLAST search for the DNA sequence of the ORF

Amino acid sequence/Copy amino acid sequence
Copies the amino acid sequence of the ORF to the clipboard

Amino acid sequence/As new AA
Generates a new protein entry based on the amino acid sequence of the ORF

Amino acid sequence/BLAST amino acids
Runs a BLAST search for the amino acid sequence of the ORF

## Sequence map[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=5)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/83/GENtle_sequence_map.png/220px-GENtle_sequence_map.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The sequence map.

The sequence map is used by most GENtle modules. It shows sequences of DNA or amino acids, as well as primers, features, restriction sites and more. The basic behaviour, however, is always similar.

## Clicks[[edit](/w/index.php?title=GENtle/Sequence_map&action=edit&section=T-1)]

A double click usuaqlly opens the [editor](/wiki/GENtle/Sequence_editor) for the sequence.

## Context menu[[edit](/w/index.php?title=GENtle/Sequence_map&action=edit&section=T-2)]

The available functions in the context menu vary with the module the sequence map is used in, its state, and selection.

Edit sequence
Turn on edit mode

Transform sequence
Invert and/or complement the sequence ([DNA](/wiki/GENtle/DNA) module only)

Limit enzymes
Limit enzymes so that only enzymes below a certain number of cuts in the sequence is shown ([DNA](/wiki/GENtle/DNA) module only)

PCR
Compare [DNA map](/wiki/GENtle/DNA_map#Background)

Selection
Compare [DNA map](/wiki/GENtle/DNA_map#Background)

Copy as image
Copies the sequence map as a bitmap to the clipboard (**Caveat :** Such a bitmap can take up a huge amount of memory, depending on the length of the sequence)

Save as image
Saves the sequence map in one of several image formats

Print sequence
Prints the sequence

## Keys[[edit](/w/index.php?title=GENtle/Sequence_map&action=edit&section=T-3)]

The whole sequence can be marked by `Ctrl-A`. The [Find](/wiki/GENtle/Find) dialog can be invoked by `Ctrl-F`. Both functions can also be called upon through a menu.

In the DNA and PCR modules, the amino acid reading frame can be toggled by keys like this:

  * `Ctrl-1` = reading frame 1
  * `Ctrl-2` = reading frame 2
  * `Ctrl-3` = reading frame 3
  * `Ctrl-4` = reading frame 1, complementary strand
  * `Ctrl-5` = reading frame 2, complementary strand
  * `Ctrl-6` = reading frame 3, complementary strand
  * `Ctrl-7` = all reading frames, one-letter code
  * `Ctrl-8` = known reading frames only (from the features)
  * `Ctrl-0` = hide amino acids
  * `Ctrl-W` = three-letter code (not when displaying all reading frames)
  * `Ctrl-Q` = one-letter code

## Edit mode[[edit](/w/index.php?title=GENtle/Sequence_map&action=edit&section=T-4)]

Display and edit mode can be toggled by `F2` or the toolbar. During editing, the sequence display is maximized, and the DNA map is hidden, improving ease of edit. Depending on the current module, only some keys are allowed (in the DNA module, "A", "C", "G", and "T") by default; any other key will trigger a request to allow all keys for that sequence, for that session. The cursor can be moved similar to that in a text editor. Insert and overwrite mode can be toggled, except for some modules like PCR or Sequencing, where overwrite mode is mandatory. In these modules, backspace and delete are diasbeled as well.

When editing a primer in PCR mode, the "`.`" key copies the base at the current position from the 3'→5' or 5'→3' sequence, respectively.

## Horizontal mode[[edit](/w/index.php?title=GENtle/Sequence_map&action=edit&section=T-5)]

In some modules, the sequence display can be toggled to horizontal. This can enhance visibility. Printing, however, is always done in standard ("vertical") mode.

## Protein[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=6)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/10/GENtle_protein_module.png/220px-GENtle_protein_module.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The protein module.

In this module, amino acid sequences (peptides/proteins) can be viewed, edited and annotated. It uses a [sequence map](/wiki/GENtle/Sequence_map) as main display, and a multi-purpose overview display at the top.

## Toolbar[[edit](/w/index.php?title=GENtle/Protein&action=edit&section=T-1)]

Several functions and display options can be invoked in the tool bar:

  * Enter sequence
  * Open sequence
  * Save sequence
  * Print sequence
  * Undo
  * Cut
  * Copy
  * Paste
  * Plot (shows a plot within the sequence map)
  * Horizontal mode

## Function display[[edit](/w/index.php?title=GENtle/Protein&action=edit&section=T-2)]

The smaller display on the top can show several types of information:

Data
Shows some basic data that has been calculated from the sequence

Description
Shows the sequence description

Scheme
Shows a [DNA map](/wiki/GENtle/DNA_map)-like layout of the whole protein

AA weight
Shows a plot of the molecular weight of the individual amino acids

AA isoelectric point
Shows a plot of the isoelectric point of the individual amino acids

Hydrophobicity
Shows a plot of the local hydrophobicity of the amino acids nearby

Chou-Fasman plot
Shows a detailed Chou-Fasman-plot

## Special menus[[edit](/w/index.php?title=GENtle/Protein&action=edit&section=T-3)]

Edit/Photometer analysis
Invokes the respective [calculator](/wiki/GENtle/Calculators#Protein_calculator)

Edit/'Backtranslate' DNA
Attempts to generate the DNA sequence which codes for this amino acid sequence, using the full range of IUPAC base letters

Edit/Proteolysis assistant
Invokes the [proteolysis assistant](/wiki/GENtle/Proteolysis_assistant)

## PCR and Primer Design[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=7)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a4/GENtle_PCR.png/220px-GENtle_PCR.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

PCR and primer design.

This module allows for designing primers and running virtual PCRs. It can be started from a [DNA](/wiki/GENtle/DNA) module via context menu of the [DNA](/wiki/GENtle/DNA_map#Background) or [../Sequence map#Context menu|sequence]] map, or through _Tools/PCR_. If a sequence is selected in the DNA module, one or more primers can be generated automatically upon startup of the PCR module. These will only be rough suggestions, and are in no way optimized by default.

## Toolbar[[edit](/w/index.php?title=GENtle/PCR_and_Primer_Design&action=edit&section=T-1)]

  * Enter new primer
  * Open primer/sequence
  * Print PCR
  * Add a primer (you will have to open or enter the primer first)
  * Export a primer (generate its sequence)
  * Edit mode
  * Show/hide features
  * Polymerase running length
  * Horizontal mode

The polymerase running length is the number of nucleotides the polymerase is allowed to run during the PCR in the elongation step. This is usually measured in minutes, but each polymerase runs at a different speed, which is why this information is given here in nuleotides. The value is initially computed automatically, but can be changed manually.

## Primer list[[edit](/w/index.php?title=GENtle/PCR_and_Primer_Design&action=edit&section=T-2)]

The primer list (the upper left) shows all primers used in this PCR, as well as certain key properties of these. Selecting one of these primers will show more detailed information in the box on the right (see [here](/wiki/GENtle/Edit_primer_dialog#Properties_display) for details). Double-clicking one of the primers will mark and show that primer in the sequence. A selected primer can be removed through the _Remove_ button, or [edited](/wiki/GENtle/Edit_primer_dialog) via the _Edit_ button. A selected primer can also be exported via the Export button in the toolbar; a new sequence will be generated for that primer.

    **Caveat :** The generated sequence is _not_ stored anywhere automatically, it needs to be saved manually!
    **Caveat :** To add a primer, use the Add button in the toolbar, or the _Selection as new primer_ context menu. Merely editing the sequence (see below) is for editing existing primers only, it will _not_ create new ones!

## Sequence[[edit](/w/index.php?title=GENtle/PCR_and_Primer_Design&action=edit&section=T-3)]

The sequence consists of the following lines:

  * Features of the template DNA (can be turned off in the toolbar)
  * 5' primer
  * Template DNA (5'→3')
  * Amino acid sequence of the template
  * Template DNA (3'→5')
  * 3' primer
  * Restriction sites of the resulting DNA
  * Resulting DNA (shown in green)
  * Amino acid sequence of the resulting DNA

Some special functions and properties of the PCR sequence display:

  * The amino acid reading frame can be set as described [here](/wiki/GENtle/Sequence_map#Keys). This will affect both amino acid sequences shown (template and result).
  * Only the two primer sequences can be edited; overwrite mode is mandatory, and deleting is disabeled.
  * To delete a nucleotide, overwrite it with `Space`.
  * The "`.`" key will copy the matching template nucleotide to that position in the primer sequence.
  * Matching primer nucleotides (that is, matching with the template) are shown in blue, mismatches in red.
  * If (when _not_ in edit mode) an empty span of the primer sequence is selected, it can be turned into a new primer via the context menu (_Selection as new primer_).
  * The sequence of a restriction site can be inserted left or right of a selection (in edit mode, right or left of the cursor) via the context menu. A selection dialog for the desired enzyme will appear.
  * A [silent mutation](/wiki/GENtle/Silent_Mutagenesis) can be introduced via the context menu.

Finally, the resulting DNA or amino acid sequence (the green sequence, which will be the one generated by the PCR) can be copied to the clipboard or generated as a new sequence (containing all features, restriction enzymes etc.) via the context menu.

## Sequencing[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=8)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/90/GENtle_sequencing_module.png/220px-GENtle_sequencing_module.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The sequencing module

The sequencing module allows to view the data recorded by a sequence analyser. The data is loaded by importing the appropriate .abi/.ab1 file.

## Display[[edit](/w/index.php?title=GENtle/Sequencing&action=edit&section=T-1)]

The data is displayed in the main [sequence](/wiki/GENtle/Sequence_map) window. The text window on the upper right shows data stored in the file. On the left side, the following display options for the sequence are available:

Help lines
Gray vertial lines down from each sequence letter to the baseline. These can help to identify which letter belongs to which peak

Invert&complement
Shows the sequencing complement/inverted. Useful for [Alignments](/wiki/GENtle/Alignments)

Scale height
Sets the height of the graphic display [unit in text lines]

Scale width
Sets the graphical points per data value. Default is 2; 1 would mean one pixel width per data point

Zoom
Sets the zoom factor for the data; useful to see small peaks

## Toolbar[[edit](/w/index.php?title=GENtle/Sequencing&action=edit&section=T-2)]

  * Enter new sequence
  * Open sequence
  * Save sequence (see caveats)
  * Copy sequence to clipboard
  * Horizontal mode

## Caveats[[edit](/w/index.php?title=GENtle/Sequencing&action=edit&section=T-3)]

  * Editing works in overwrite-mode only
  * Saving will only store the **sequence** in the database, not the sequencer data (the peaks), due to memory concerns.

## Alignments[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=9)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/71/GENtle_alignments.png/220px-GENtle_alignments.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Alignment.

The alignment module displays alignments of DNA and amino acid sequences. It can be invoked through _Tools/Alignment_ or `Ctrl-G`.

## Settings dialog[[edit](/w/index.php?title=GENtle/Alignments&action=edit&section=T-1)]

The settings dialog will be invoked upon starting the module, or through the "settings" button in the toolbar. The sequences to align, their order, and the alignment algorithm and its parameters can be chosen here. The following algorithms are available:

Clustal-W
This (default) algorithm generates alignments of high quality, but is rather slow for simple alignments, and sometimes stumbles over local alignments.

Smith-Waterman
An internal, fast, but simple algorithm for local alignments, that is, aligning one or multiple short sequences againast a long one. The long sequence has to be the first. It works great for checking [sequencing data](/wiki/GENtle/Sequencing) against the expected sequence.

Needlemann-Wunsch
An internal, fast, but simple algorithm for global alignments, that is, aligning sequences of roughly the same length (e.g., different alleles of a gene). As with Smith-Waterman, all alignments are made against the first sequence.

**Caveat :** Clicking _OK_ in this dialog will recalculate the alignment; the previous alignment and all manual changes made to it will be lost.

## Toolbar[[edit](/w/index.php?title=GENtle/Alignments&action=edit&section=T-2)]

Several functions and display options can be invoked in the tool bar:

  * Enter sequence
  * Open sequence
  * Save sequence
  * Print sequence
  * Settings
  * Horizontal mode
  * Middle mouse button function

## View menu[[edit](/w/index.php?title=GENtle/Alignments&action=edit&section=T-3)]

Some display options can be combined with each other:

  * Bold (shows characters in bold)
  * Mono (black-and-white mode)
  * Conserved (shows characters that match the one in the first line as dots)
  * Identity (toggles the "identity" line)

Some of them exclude one another:

  * Normal (shows colored text on white background)
  * Inverted (shows white text on colored background)

Some other display options are planned, but not implemented as of now.

## Sequence display[[edit](/w/index.php?title=GENtle/Alignments&action=edit&section=T-4)]

The [sequence map](/wiki/GENtle/Sequence_map) can be altered through the context menu. These changes will only alter the display, _not_ recalculate the alignment.

  * Lines can be moved up or down
  * Features for each line can be shown or hidden. By default, features for the first line are shown, features of the other lines are hidden.
  * Gaps can be inserted or deleted, in this line, or all except this line. One of these four possible functions is additionally assigned to the middle mouse button; this setting can be changed in the toolbar.
  * A double click on a character (_not_ on a gap) opens the "source" window for that sequence (if available), marks and shows the position that was clicked in the alignment. This can be helpful for checking a sequencing.
  * Sequences can be marked across multiple lines, then formatted via the _Appearance_ context menu.

Sequences can _not_ be edited within the alignment module. For that, you will have to edit the original sequence, then re-run the alignment.

## Notes[[edit](/w/index.php?title=GENtle/Alignments&action=edit&section=T-5)]

  * Legend for the ClustalW consensus line:

    ***** = identical or conserved residues in all sequences in the alignment
    **:** = indicates conserved substitutions
    **.** = indicates semi-conserved substitutions

## Calculators[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=10)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b0/GENtle_calculator.png/220px-GENtle_calculator.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Protein calculator

The calculator module can be invoked via _Tools/Calculator_. It contains several specialized spreadsheet-based calculators for typical tasks in molecular miology. The editable fields are shown in blue, the (major) results of the calculation are shown in red.

## Ligation calculator[[edit](/w/index.php?title=GENtle/Calculators&action=edit&section=T-1)]

This calculator gives the amount (in µl) of vector and insert for a ligation, based on the length and concentration of each respectively, their desired ratio and total mass of DNA. A typical ratio of insert:vector is 3:1

## DNA concentration calculator[[edit](/w/index.php?title=GENtle/Calculators&action=edit&section=T-2)]

This calculator gives the amount and putiry of DNA based on photometric absorption at 260 and 280 nm, respectively, as well as the dilution (in case one measures a 1:100 dilution of the original DNA sample) and a correction factor for different types of nucleic acids.

## Protein calculator[[edit](/w/index.php?title=GENtle/Calculators&action=edit&section=T-3)]

This calculator gives the amount and purity of peptides/proteins based on photometric absorption at 250 and 280 nm, respectively, as well as the molecular weight of the peptide, the layer thickness of the cuvette used, and the number of tryptophanes, tyrosines and cysteines in the peptide.

This

## Data[[edit](/w/index.php?title=GENtle/Calculators&action=edit&section=T-4)]

This shows a codon table and a reverse codon table, both for standard code. This page can not be edited.

## Virtual Gel[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=11)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/GENtle_virtual_gel.png/220px-GENtle_virtual_gel.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Virtual gel.

A **virtual** agarose (DNA) **gel** can be generated or expanded via the [Restriction Assistant](/wiki/GENtle/Restriction_Assistant). A new virtual gel will be created if none exists; otherwise, the existing one will be expanded.

Within the gel viewer, gel concentration can be varied. Also, labeling can be turned on/off. Gels can be printed, or saved/copied as an image.

The name of a lane can be changed by double-clicking on the lane.

You can chose one of several DNA markers. If your favorite marker is not there, you can file a [feature request](/wiki/GENtle/Feature_requests) or [add your own directly](/wiki/GENtle/DNA_markers).

## Image Viewer[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=12)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/GENtle_image_viewer.png/220px-GENtle_image_viewer.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Image viewer.

The Image Viewer module can be invoked via _Tools/Image viewer_. It can display images, such as gel photos, print them, or save them in another image format.

The viewer can read and write common formats, such as JPG, TIF, BMP, GIF, etc. In addition, it can read the IMG format used by the BioRad Molecular Analyst software.

The directory can be selected via the upper left button. The files in that directory are shown below. A single click on a file displays the image.

The context menu of the image contains entries to save or print the image, or copy it to the clipboard. For saving, PNG, TIF, BMP, and JPG are available formats, with PNG being the default, as it has the best lossless compression.

Labels of IMG images are shown on screen, print, and saved images by default. This can be changed through the "Show labels" checkbox beneath the file list.

An image can be inverted (black <=> white) through the "Invert" checkbox.

## Web interface[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=13)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

The GENtle web interface lets you access DNA and amino acid sequences from [NCBI](http://www.ncbi.com), as well as publications listed at [PubMed](http://www.ncbi.nlm.nih.gov). The interface also covers BLAST searches.

## NCBI[[edit](/w/index.php?title=GENtle/Web_interface&action=edit&section=T-1)]

Chosing _Nucleotide_ or _Protein_, entering a sequence name/keywords, and hitting _Search_/`ENTER` will show the NCBI search results for that query. More results (if any) can be browsed with _>>_.

Double-clicking an entry will download and open the (annotated) sequence.

## PubMed[[edit](/w/index.php?title=GENtle/Web_interface&action=edit&section=T-2)]

The _PubMed_ option gives new entry fields for author(s) (written "Lastname Initials", separated by "`,`"), and date limitations (years), as well as a result sort option.

Double-clicking an entry will open a web browser window with the respective PubMed abstract page.

## BLAST[[edit](/w/index.php?title=GENtle/Web_interface&action=edit&section=T-3)]

Running a BLAST search for a DNA or amino acid sequence will open a new tab in the web interface, showing a countdown for the time the BLAST results are expected to arrive. Once loaded, the results are displayed as simple alignments.

Double-clicking an entry will open the found sequence.

### Ligation[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=14)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/75/GENtle_ligation.png/220px-GENtle_ligation.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Ligation dialog.

The ligation dialog is a means for virtually ligating two (or more) DNA fragments. It can be invoked via _Tools/Ligation_ or `Ctrl-L`.

The left list shows all potential DNA sequences to be ligated. Some of these are automatically selected, but selection can be manually changed. The right list shows the possible products of a ligation of the selected sequences. Some circular products will be shown in two forms (A-B and B-A), which only differ visually.

The selected products will be generated as new sequences on clicking the _Ligate_ button.

### Options[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=15)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

Global program options can be altered via _Tools/Options_.

## Global settings[[edit](/w/index.php?title=GENtle/Options&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cc/GENtle_global_settings.png/220px-GENtle_global_settings.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Global settings.

Option Description

Language
Currently English and German are available

Enhanced display
Can be turned off on machines with very show graphics

Show sequence title
Displays the sequence title in the [DNA map](/wiki/GENtle/DNA_map)

Show sequence length
Displays the sequence length in the [DNA map](/wiki/GENtle/DNA_map)

Load last project on startup
Automatically loads the last used [project](/wiki/GENtle/Projects) when starting GENtle

Use metafile format
Generates a WMF when copying the [DNA map](/wiki/GENtle/DNA_map) instead of a bitmap

Show splashscreen
Shows the GENtle splash screen when starting

Check for new version on startup
Checks (and downloads) a new GENtle version via internet on startup

Use internal help
Help should open in a browser window by default. If that doesn't work, check this option

## Enzyme settings[[edit](/w/index.php?title=GENtle/Options&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/57/GENtle_enzyme_settings.png/220px-GENtle_enzyme_settings.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Enzyme settings.

Here the gloal enzyme options can be selected. These can be overridden for an individual sequence in the [sequence editor](/wiki/GENtle/Sequence_editor#Restriction_enzymes_.282.29), where there is a tab identical to this one.

Option Description

Use global enzyme settings
Turn most of the other options on this tab on or off globally

Join enzymes
In a [DNA map](/wiki/GENtle/DNA_map), cuts of isoenzymes can be grouped together instead of displayed individually

Use color coding
Restriction enzymes can be shown in a color matching their number of cuts in a given sequence. The three buttons to the right of this option each hold a color choice dialog for single, double, and triple cutters.

Use min/max cutoff
Shows only enzymes that cut a minimum/maximum times

Sequence length
Shows only enzymes with recognition sequences of the selected lengths

Use enzyme group
Uses only enzymes from the selected enzyme group

Show methylation
Shows DAM and/or DCM methylation in map and sequence, in red

Show GC contents
shows the GC contents in the map

### Databases (Open/save/manage)[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=16)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/bd/GENtle_database.png/220px-GENtle_database.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Databases.

The GENtle database management dialog is where sequences are stored and retrieved. DNA and amino acid sequences, primers, alignments, and projects all go to databases, which can be local (for one computer only) or shared (used by the whole work group, institute, etc.).

## Management[[edit](/w/index.php?title=GENtle/Databases&action=edit&section=T-1)]

The "Management" tab can be reached through the _File_ menu, the _Tools/Manage database_ menu, the `Ctrl-O` and `Ctrl-S` keys ("open" and "save", respectively), or the appropriate buttons in the toolbar. The tab consists of two or three parts:

### Filter[[edit](/w/index.php?title=GENtle/Databases&action=edit&section=T-2)]

The filter section allows to filter the database entries so the list(s) below show only the matching entries.

The filter text box limits the shown sequences to those whose name (or description or sequence, depending on the checkboxes) contain that text. Multiple search words are separated by a space (" ") and work as a logical AND. Thus, entering "pgex igf" in the filter text box shows only those sequences whose name (or description) contain both the word "pgex" and "igf". The search in not case-sensitive, so searching for "igf" or "IGF" will make no difference.

The checkboxes on the right limit the display to any combination of DNA, protein (amino acid sequences), and primers. If non of these is selected, all types of entries are shown, including alignments. As already described, search for text can be extended beyond the sequence name to description and the sequence itself through two other checkboxes, where description search is enabeled as default.

### Lists[[edit](/w/index.php?title=GENtle/Databases&action=edit&section=T-3)]

One or two lists are shown, depending on the appropriate checkbox above the left list. The database(s) to search/display can be selected via the drop-down box(es). One list with full width is good for an overview of a single database, whereas two lists are needed for moving and copying entries between databases; also, a search will be run on both databases simultaneously.

Entries will be sorted alphabetically. Every entry has a small icon associated with its type. There are icons for DNA, amino acid sequences, primers, and alignments. There is also a [project](/wiki/GENtle/Projects) icon, but these will only be shown when opening/saving a project.

A single entry can be selected by clicking with the left mouse button. When opening a file, a double click or pressing `RETURN` on a selected entry will open it. Multiple entries can be selected by dragging a rectangle with the mouse, or by holding down the `SHIFT` and/or `CTRL` keys. A multiple selection can be opened via `RETURN`.

Grabbing selected entries with the left mouse button and dragging them into the other list will **move** these entries to that database. To **copy** these entries, hold down the `CTRL` key when releasing the left mouse button over the target list.

Selected entries can be opened, renamed, and deleted via their context menu.

### Save[[edit](/w/index.php?title=GENtle/Databases&action=edit&section=T-4)]

If you save an entry to a database, there will be an additional line below the lists. It consists of a drop-down box with the database to save the entry to, and a text box for the name. The name of the database is remembered if you originally opened that entry from a database, otherwise the standard database is the default.

Saving an entry to a database where an entry with that name already exists will lead to the following:

  * If the sequence of the entry in the database is exactly the same as the sequence of the entry you're trying to save, a message box will ask you if you really want to overwrite that entry.
  * If the sequence of the entry in the database differs from the sequence of the entry you're trying to save, a message box will tell you that this action was prevented. This will avoid accidental overwriting of an entry with a different sequence. If you are very certain you want to replace that entry, you will have to delete the entry in the database manually via the context menu, as described above.

## Databases[[edit](/w/index.php?title=GENtle/Databases&action=edit&section=T-5)]

Currently, GENtle supports sqlite and MySQL databases, both of them freely available. Each has different advantages and disadvantages, though both are integrated seamlessly into GENtle. Once set up, all functions are available on all databases, no matter the type.

The "Databases" tab keeps a list of all the databases that can be accessed. New databases can be created, and existing can be added to or removed from that list. The exception is the local database, which is essential for the functioning of GENtle and therefore can not be removed. Removal of a database will _not_ delete the database itself, only the entry in the list.

One of the databases in the list is the default database. The default database can be set by selecting its entry in the list, then clicking the _As Default_ button. The default database can carry shared [enzyme groups](/wiki/GENtle/Sequence_editor).

### Sqlite[[edit](/w/index.php?title=GENtle/Databases&action=edit&section=T-6)]

Sqlite is already integrated in GENtle, so no separate installation or setup of any kind is required. A sqlite database consists of a single file with the ending ".db". For each GENtle installation, a database ("local.db") is automatically created. New sqlite databases can be created, or existing ones added to GENtle, on the "Databases" tab in the dialog. To take such a database with you (e.g., for use at home or on a laptop), just copy the ".db" file. While sqlite databases are easy to set up and maintain, sharing them across a network tends to be slow, depending on the size of the database.

### MySQL[[edit](/w/index.php?title=GENtle/Databases&action=edit&section=T-7)]

MySQL is a professional client/server database system that will reliably store and serve millions of entries. It is ideal for shared databases, as even a huge number of stored sequences will not slow it down significantly, even across a network. Hovever, there are some steps required to use MySQL databases with GENtle:

  * A "server" computer on your network, that is, a computer that is running most of the time, and preferably is not used for direct work. If the server is not running, or disconnected from the network, no one will be able to access the MySQL database and the sequences stored in it!
  * The MySQL server software (4.1 works fine, other versions will likely do as well), which available for free [here](http://dev.mysql.com/downloads/).
  * Someone to configure the MySQL server (not as complicated as it sounds)

Once the MySQL setup is complete, MySQL databases can be created (by one) and added to all the GENtle clients that should have access.

### Import[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=17)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

The import dialog is a standard "file open" dialog. It can be invoked via _Files/Import_ or `Ctrl-I`.

Multiple files can be chosen to be imported in a row. GENtle will automatically try to determine the file type, but also a file type can be chosen manually.

Supported formats include:

  * GenBank
  * GenBank XML
  * FASTA
  * ABI/AB1 (popular sequencer output format)
  * PDB (a 3D format, import as annotated sequence)
  * Clone (old DOS program, proprietary format)
  * Numerous other sequence formats that will be imported as "sequence only", without annnotations, features etc.
  * Comma-separated values (CSV) from various machines (HPLC/FPLC/photometer) for [graphs and plots](/wiki/GENtle/Graph)

### Enter sequence[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=18)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/GENtle_enter_sequence.png/220px-GENtle_enter_sequence.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Enter a sequence manually.

This dialog to enter a sequence manually can be invoked via _File/Enter sequence_ or `Ctrl-N`.

Beside the sequence, to be typed or pasted into the large text box, one can enter a title (name) for that sequence, and choose a type.

Types available are:

  * DNA
  * Amino acid sequence
  * GenBank
  * (GenBank) XML
  * Primer

When chosing DNA, amino acids, or primer, all non-sequence characters, like blanks and numbers, are automatically removed.

    **Note :** A primer _has_ to be given the type "Primer", otherwise it will be added as DNA.

### Find dialog[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=19)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3e/GENtle_find_dialog.png/220px-GENtle_find_dialog.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Find dialog.

The **Find dialog** in [DNA](/wiki/GENtle/DNA) and [amino acid](/wiki/GENtle/Protein) sequence can be invoked via `Ctrl-F` or _Edit/Search_. It displays can find a string in

  * the current sequence
  * a feature name
  * a feature description

In DNA sequence display, it also look in

  * the reverse sequence
  * the translated amino acid sequence(s)
  * restriction enzyme names

The search is commenced automatically after changing the search string, if it is three or more characters long. For shorter search queries, the _Search_ button has to be clicked.

Single-clicking on a search result will select and display the result in the sequence. A double click will exit the dialog, and open the [sequence editor](/wiki/GENtle/Sequence_editor) for features, or the [enzyme management](/wiki/GENtle/Enzyme_management) dialog for restriction enzymes.

### Sequence editor[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=20)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/37/GENtle_properties.png/220px-GENtle_properties.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Sequence editor, properties tab.

The sequence editor holds the key to several properties of a sequence. It consists of several tabs, depending on the type of sequence, which can be DNA or amino acid.

## Properties[[edit](/w/index.php?title=GENtle/Sequence_editor&action=edit&section=T-1)]

Here, the title and description of the sequence can be altered. As for feature descriptions, the sequence description will make http references clickable.

For DNA sequences, sticky ends can be entered.

## Features[[edit](/w/index.php?title=GENtle/Sequence_editor&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1c/GENtle_sequence_editor_features.png/220px-GENtle_sequence_editor_features.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The sequence editor, features tab.

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/5f/GENtle_sequence_editor_edit_feature.png/220px-GENtle_sequence_editor_edit_feature.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Edit feature dialog.

This tab shows a list of all features of the sequence. Features can be added, edited, and deleted. Most of the settings should be self-explanatory.

  * The setting _reading frame_ is only available when the type is set to "CDS" ("coding sequence").
  * A _leading_ sequence is read 5'→3'; leading unchecked, 3'→5'
  * _Edit feature_ will invoke an additional "Edit feature" dialog

### Edit feature[[edit](/w/index.php?title=GENtle/Sequence_editor&action=edit&section=T-3)]

  * _Fill color_ is the color of the feature; it will invoke a color choice dialog
  * _Type in sequence display_ determines how that feature is drawn in the [sequence map](/wiki/GENtle/Sequence_map)
  * _Use offset_ sets the numbering for the first amino acid of the feature; useful if the feature marks a part of a protein

The list box below contains original data from GenBank format import.

## Restriction enzymes[[edit](/w/index.php?title=GENtle/Sequence_editor&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c1/GENtle_enzyme_settings%281%29.png/220px-GENtle_enzyme_settings%281%29.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Sequence editor, enzyme settings tab.

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c4/GENtle_enzyme_settings%282%29.png/220px-GENtle_enzyme_settings%282%29.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Sequence editor, enzyme settings (2).

When editing a DNA sequence, two tabs with settings for restriction enzymes are available. The first one is identical to the [enzyme management](/wiki/GENtle/Enzyme_management) dialog. The second one is identical to the [global enzyme settings](/wiki/GENtle/Options#Enzyme_settings) tab, but contains the settings for this sequence alone. By default, its options are disabled, and the global options are used. By activation the options here, global settings are overridden.

## Proteases[[edit](/w/index.php?title=GENtle/Sequence_editor&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/GENtle_sequence_editor_proteases.png/220px-GENtle_sequence_editor_proteases.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The sequence editor, protease tab.

This tab holds a list of available proteases. Potential cleavage sites for selected (checked) proteases are shown in the [sequence](/wiki/GENtle/Sequence_map) (_not_ in the [DNA map](/wiki/GENtle/DNA_map)).

New proteases can be added similar to the following examples:

  * Example : "Thermolysin" 
    * Sequence for this protease : "!DE|AFILMV"
    * Explanation: "Not D or E", "cut", "then A, F, I, L, M, or V"
  * Example: Proline-endopeptidase 
    * Sequence for this protease : "HKR,P|!P"
    * Explanation : "H, K, or R", "then P", "cut", "then not P"

### Restriction Assistant[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=21)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fc/GENtle_restriction_assistant.png/220px-GENtle_restriction_assistant.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The Restriction Assistant.

The Restriction Assistant can be invoked via menu _Tools/Enzyme Assistant_, or through a click with the middle mouse button on a restriction site in the [DNA map](/wiki/GENtle/DNA_map). For the latter, the selected enzyme is automatically selected in the list of "Available enzymes" (left). This list depends on the selections "Group" and "Subselection". It can be sorted by enzyme name or number of cuts by clicking on the respective column title. For a selected enzyme, the resulting fragments are shown in the lower left list.

The list on the right shows the contents of the "restriction cocktail", the enzymes already selected for cutting. The resulting fragments for these enzymes together are shown in the lower right list. The enzyme selected in the left list can be put in the cocktail via _Add to cocktail_; all enzymes from the left list can be added at once via _Add all_. An enzyme can be removed from the cocktail by selecting it in the right list, then via _Remove enzyme_.

_Do not create fragments below ___ base pairs_, when selected, limits the fragments generated to a minimum size. _Done_ exits the restriction assistant while preserving the changes mage to the cocktail, whereas _Cancel_ will void all changes made.

_Start restriction_ (the scissors symbol) will initiate the simulated restriction. The result of this can be influenced by several further settings:

  * _Create fragments_ will generate the actual DNA sequences with their blunt/sticky ends that will result from a digestion with the cocktail. This option is pre-selected.
  * _Add to gel_ will add the fragments to a [virtual gel](/wiki/GENtle/Virtual_Gel), together in one lane.
  * _One lane each_ will alter the above so that each enzyme gets its own lane.
  * _Partial restriction_ will add all possible fragments to a virtual gel lane, simulating a partial (incomplete) restriction. The option _One lane each_ is not available when _Partial restriction_ is checked.

The restriction cocktail will be preserved so you can cut another DNA with that very enzyme combination, which is useful for an upcoming [Ligation](/wiki/GENtle/Ligation).

### Projects[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=22)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

A project in GENtle is a collection of sequences that belong together, even if they are in different databases. Projects can be

  * loaded via _File/Load Project_ or `F11`
  * saved via _File/Save Project_ or `F12`
  * closed via _File/Close Project_

Depending on the [options](/wiki/GENtle/Options), the last used project is automatically opened when GENtle starts.

Projects consists of a list of sequences, **not** the sequences themselves. If a sequence is renamed, moved or deleted, GENtle will dispay a warning next time a project containing that sequence is opened.

For efficient use of sequencing primers, one can create a project that contains all available sequencing primers, and then refer to that project in the [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) dialog.

### Edit primer dialog[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=23)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a9/GENtle_edit_primer_dialog.png/220px-GENtle_edit_primer_dialog.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Edit primer dialog.

This dialog assists in optimizing a primer. For that reason, many variants of the primer are generated and can be examined.

The center line of the dialog shows the current variant of the primer; details of that variant are shown in the upper right box. _OK_ will end the dialog, committing that variant to the PCR module. _Cancel_ will end the dialog and _not_ change the PCR module. _Reset_ will return the primer in the dialog to the variant the dialog was originally started with.

The list in the lower half of the dialog contains an automatically generated list of variants of the current primer, sorted by an arbitrary score. The "region" of variants can be influenced by multiple settings in the upper left quarter of the dialog. Available settings include:

  * The variation of the 5'-end of the primer to the right and to the left.
  * The variation of the 3'-end of the primer to the right and to the left.
  * The minimum and maximum length of the primer.
  * The minimum and maximum melting temperature of the primer.

Any change of these settings will trigger a recalculation of possible variations. These variations are then evaluated and shown in the list in the lower half of the dialog. Double-clicking one of the varaiations will change the current variation in the center line, and the properties display in the upper right quarter of the dialog.

## Properties display[[edit](/w/index.php?title=GENtle/Edit_primer_dialog&action=edit&section=T-1)]

This will display:

  1. The primer sequence in 5'→3' orientation
  2. The ΔH and ΔS values
  3. The length and GC contents of the primer
  4. The melting temperature, calculated according to the Nearest Neighbour method (usually best results, but only for longer primers)
  5. The melting temperature, calculated according to the salt-adjusted method (medicore results)
  6. The melting temperature, calculated according to the GC method (simplicistic)
  7. The highest self-annealing score (arbitrary) and the display of that annealing

    **Caveat :** Calculating primer melting temperatures is tricky. If one of the three methods gives a totally different result than the other two, ignore it. Also, the melting temperature is only calculated for the 3'-end of the primer that anneals with the sequence!

### Printing[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=24)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

[Sequence](/wiki/GENtle/Sequence_map) and [DNA maps](/wiki/GENtle/DNA_map) can be printed via the respective context menus or the _File_ menu.

For [DNA](/wiki/GENtle/DNA) sequences, a report can be printed via _File/Print report_. It contains the DNA map and a list of the features annotated in the sequence. This can be useful for a detailed overview of the sequence where the sequence itself is not required.

### Enzyme management[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=25)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/16/GENtle_enzyme_management.png/220px-GENtle_enzyme_management.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The enzyme management dialog

The enzyme editor for enzyme management, both globally and per DNA sequence, is divided into three lists:

  1. A list of enzyme groups (top right)
  2. A list of enzymes in that group (bottom right)
  3. A list of current/temporary enzymes (left)

Enzymes can be copied into/removed from the left list through the `<\--Add` and `Remove-->` buttons. Enzymes can be deleted from a group (except `All`) via `Delete` from group, or added via `New enzyme`. A double click on an enzyme name in either list shows an enzyme properties dialog.

Enzymes from the left list can be added to a new or existing group via the respective buttons. All enzymes from a group can be added to the left list, and a group can be deleted.

You can share enzyme groups with other GENtle users on your intranet via a commonly shared database. Create an enzyme group as "Database name:Enzyme group name", and it will be available to everyone using that database on the next start of GENtle. Note that when creating the enzyme group, use the name of the database as it appears in your local installation (maybe "Shared", "Shared0", "Shared (2)" etc.).

### Sequencing Primers[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=26)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

![Sequencing primers dialog](//upload.wikimedia.org/wikipedia/commons/c/c6/GENtle_sequencing_primers.png)

The sequencing primers dialog can add possible sequencing primers as features to a [DNA](/wiki/GENtle/DNA) sequence. What primers to add can be specified:

  * The minimum alignment (3') of a primer to the sequence. This means exact annealing!
  * The database to search for primers. All primers from that database will be considered.
  * Alternatively, use all primers that are part of a project in that database. That way, a range of primers across databases can be specified in a project and be considered as sequencing primers here.
  * Primers that run in 5'→3' or 3'→5' direction.

You can also have the dialog remove old sequencing primers from the sequence. This can also be done manually through _Edit/Remove sequencing primers_ in the DNA module. Note: Sequencing primers, if not removed, will be saved as features together with the sequence; they can still be removed lated, though.

Sequencing primers will display as yellow features, where the shade of yellow depends on their direction. The actual sequencing primer feature is only as long as the 3' annealing of the primer, so the primer might actually be longer than the feature towards the 5' end. For details, see the feature description, which contains the original primer sequence, among other data.

### Silent Mutagenesis[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=27)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/80/GENtle_silent_mutation.png/220px-GENtle_silent_mutation.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The silent mutation dialog

This dialog can find restriction enzymes that cut in a marked DNA sequence (context menu _Selection/Show enzymes that cut here_ in the DNA module). It can also find alternate versions of the DNA which will translate into the same amino acid sequence, but contains a new restriction site (silent mutation). A chosen enzyme/mutation will appear in the sequence (DNA or primer, respectively) upon `OK`.

The results can be changed by

  * changing which enzyme group to search
  * limiting the number of times an enzyme may cut in the whole sequence
  * limiting the number of mutations needed for a restriction site to manifest (PCR module only)

### Automatic annotation[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=28)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[GENtle](/wiki/GENtle): [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs)

[Ligation](/wiki/GENtle/Ligation) \- [Options](/wiki/GENtle/Options) \- [Databases](/wiki/GENtle/Databases) \- [Import](/wiki/GENtle/Import) \- [Enter sequence](/wiki/GENtle/Enter_sequence) \- [Sequence editor](/wiki/GENtle/Sequence_editor) \- [Restriction Assistant](/wiki/GENtle/Restriction_Assistant) \- [PCR troubleshoot dialog](/wiki/GENtle/PCR_troubleshoot_dialog) \- [Proteolysis assistant](/wiki/GENtle/Proteolysis_assistant) \- [Projects](/wiki/GENtle/Projects) \- [Edit primer dialog](/wiki/GENtle/Edit_primer_dialog) \- [Find dialog](/wiki/GENtle/Find) \- [Printing](/wiki/GENtle/Printing) \- [Enzyme management](/wiki/GENtle/Enzyme_management) \- [Sequencing Primers](/wiki/GENtle/Sequencing_Primers) \- [Silent Mutagenesis](/wiki/GENtle/Silent_Mutagenesis) \- [Automatic annotation](/wiki/GENtle/Automatic_annotation)

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0f/GENtle_auto_annotate.png/220px-GENtle_auto_annotate.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The automatic annotation dialog.

The **automatic annotation** feature can search a database of standard vectors (included with the GENtle package), and (optionally) a user-generated database, for feature sequences that are found in the currently opened DNA sequence. Recognized features are then annotated in the current sequence.

Invoked through _Edit/Auto-annotate sequence_ or `F9`, a dialog opens, offering various settings:

  * Whether or not to search the common vectors database
  * Whether or not to use a user-generated database (and, if so, which one)
  * Whether or not to reduce the number of generated features (recommended; otherwise, a lot of features are annotated)
  * Whether or not to add unrecognized open reading frames as features

## FAQ[[edit](/w/index.php?title=GENtle/Print_version&action=edit&section=29)]

![GENtle splash screen.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/GENtle_splash_screen.png/60px-GENtle_splash_screen.png)
[The GENtle manual](/wiki/GENtle)

[About](/wiki/GENtle/About) \- [FAQ](/wiki/GENtle/FAQ) \- [Setup](/wiki/GENtle/Setup) \- [DNA](/wiki/GENtle/DNA) \- [Protein](/wiki/GENtle/Protein) \- [PCR and Primer Design](/wiki/GENtle/PCR_and_Primer_Design) \- [Sequencing](/wiki/GENtle/Sequencing) \- [Alignments](/wiki/GENtle/Alignments) \- [Calculators](/wiki/GENtle/Calculators) \- [Virtual Gel](/wiki/GENtle/Virtual_Gel) \- [Image Viewer](/wiki/GENtle/Image_Viewer) \- [Tools and Dialogs](/wiki/GENtle/Tools_and_Dialogs) \- [Web interface](/wiki/GENtle/Web_interface) \- [Graphs and plots](/wiki/GENtle/Graph) \- [DNA map](/wiki/GENtle/DNA_map) \- [Sequence map](/wiki/GENtle/Sequence_map) \- [Dot plot](/wiki/GENtle/Dot_plot) \- [Restriction Identifier](/wiki/GENtle/Restriction_Identifier)

FAQ - frequently asked questions.

    **Q**: This manual sucks! And I want one in my language! What can I do?
    **A**: It's a wiki! You can edit any page and improve the manual yourself. You can even start and maintain a new translation (contact the programmer through [this page](http://gentle.magnusmanske.de)).

  


    **Q**: Why does GENtle try to connect to the internet all the time?
    **A**: An internet connection is mandatory for BLAST- and ReBase-searches, as well as for the online tools.
    **A**: At the beginning of each GENtle session, a check for possible updates takes place, which also requires an internet connection. This can be turned off in the _Tools/Options_ menu.

  


    **Q**: Why can't I perform a BLAST search for the amino acids coded by the selected DNA sequence?
    **Q**: Why can't I extract amino acids from the selected DNA sequence?
    **A**: A reading frame must be selected.

  


    **Q**: There's a problem with multiple users using GENtle on my Windows machine.
    **A**: You might have to allow write access to "local.db" in the GENtle directory for all users involved.
    **A**: You can turn off the "registry settings bug" via _Tools/Options/Register protocols and extensions on startup_

  


    **Q**: New updates download, but don't install.
    **A**: You need write access to the GENtle program directory. Alternatively, ask your friendly administrator to download the latest version of GENtle [here](http://gentle.magnusmanske.de) and install it for you. Remind him that he'll have to do this every few weeks, which might convince him to give you write access...

  


    **Q**: I found a bug! And I want new functions as well! Can my favourite protease/marker/restriction enzyme be in the default installation? Where can I donate huge amounts of money for a poor programmer?
    **A**: Add a [bug report](/wiki/GENtle/Bug_reports) or a [feature request](/wiki/GENtle/Feature_requests) right here in the wiki, or contact the author of GENtle through the [GENtle site](http://gentle.magnusmanske.de).

* * *

New proteases to add!

How?

  1. Open any DNA or amino acid sequence
  2. Double-click the sequence
  3. Go to "Proteases"
  4. Click on "New protease"
  5. Enter name and sequence (one of the following)

PreScission
    L,E,V,L,F,Q|G,P

See [here](/wiki/GENtle/Sequence_editor#Proteases) for a more detailed description.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=GENtle/Print_version&oldid=1495159](http://en.wikibooks.org/w/index.php?title=GENtle/Print_version&oldid=1495159)" 

[Category](/wiki/Special:Categories): 

  * [GENtle](/wiki/Category:GENtle)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=GENtle%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=GENtle%2FPrint+version)

### Namespaces

  * [Book](/wiki/GENtle/Print_version)
  * [Discussion](/w/index.php?title=Talk:GENtle/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/GENtle/Print_version)
  * [Edit](/w/index.php?title=GENtle/Print_version&action=edit)
  * [View history](/w/index.php?title=GENtle/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/GENtle/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/GENtle/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=GENtle/Print_version&oldid=1495159)
  * [Page information](/w/index.php?title=GENtle/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=GENtle%2FPrint_version&id=1495159)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=GENtle%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=GENtle%2FPrint+version&oldid=1495159&writer=rl)
  * [Printable version](/w/index.php?title=GENtle/Print_version&printable=yes)

  * This page was last modified on 9 May 2009, at 17:54.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/GENtle/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
