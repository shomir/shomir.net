# Mathematics for Chemistry/Print version

From Wikibooks, open books for an open world

< [Mathematics for Chemistry](/wiki/Mathematics_for_Chemistry)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Mathematics_for_Chemistry/Print_version) on _18 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&oldid=2503106&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Mathematics for Chemistry](/wiki/Mathematics_for_Chemistry)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=purge&printable=yes) this page.

## Contents

  * 1 Table of contents
  * 2 Introduction
    * 2.1 Quantitative methods in chemistry
  * 3 Numbers
    * 3.1 Surds
    * 3.2 Notation
    * 3.3 Exponents
    * 3.4 Order of operations
    * 3.5 Partial fractions
      * 3.5.1 Problems
      * 3.5.2 Answers
    * 3.6 Polynomial division
    * 3.7 Substitutions and expansions
  * 4 Functions
    * 4.1 Functions as tools in chemistry
      * 4.1.1 The quadratic formula
  * 5 Units and dimensions
    * 5.1 Conversion factors
      * 5.1.1 Energy
      * 5.1.2 Length
      * 5.1.3 Angles
      * 5.1.4 Dipole moment
      * 5.1.5 Magnetic Susceptibility
      * 5.1.6 Old units
    * 5.2 Greek alphabet
    * 5.3 Unit labels
      * 5.3.1 Dimensional analysis
    * 5.4 An aside on scaling
    * 5.5 Making tables
  * 6 Statistics
    * 6.1 Definition of errors
    * 6.2 Combination of uncertainties
      * 6.2.1 Addition or subtraction
      * 6.2.2 Multiplication or division
  * 7 Plotting graphs
    * 7.1 The properties of graphs
      * 7.1.1 Practice
  * 8 Complex numbers
  * 9 Trigonometry
    * 9.1 Trigonometry - the sin and cosine rules
    * 9.2 Trigonometric identities
    * 9.3 Identities and equations
    * 9.4 Some observations on triangles
    * 9.5 The interior angles of a polygon
  * 10 Vectors
    * 10.1 Vectors
    * 10.2 A summary of vectors
      * 10.2.1 Vector magnitude
      * 10.2.2 A constant times a vector
      * 10.2.3 Vector addition
      * 10.2.4 Vector subtraction
      * 10.2.5 Scalar Product
      * 10.2.6 Vector product
  * 11 Matrices and determinants
    * 11.1 Practice simultaneous equations
    * 11.2 Matrices
    * 11.3 Matrix multiply practice
    * 11.4 Finding the inverse
    * 11.5 Determinants and the Eigenvalue problem
      * 11.5.1 Simultaneous equations as linear algebra
    * 11.6 Matrices with complex numbers in them
  * 12 Differentiation
    * 12.1 The basic polynomial
    * 12.2 The chain rule
    * 12.3 Differentiating a product
    * 12.4 Differentiating a quotient
      * 12.4.1 Problems
      * 12.4.2 Answers
      * 12.4.3 Harder differentiation problems
    * 12.5 Using differentiation to check turning points
  * 13 Integration
    * 13.1 The basic polynomial
    * 13.2 The integration and differentiation of positive and negative powers
    * 13.3 Logarithms
    * 13.4 Integrating 1/x
    * 13.5 Integrating 1/x like things
    * 13.6 Some observations on infinity
    * 13.7 Definite integrals (limits)
    * 13.8 Integration by substitution
    * 13.9 Simple integration of trigonometric and exponential Functions
      * 13.9.1 Answers
    * 13.10 Integration by parts
    * 13.11 Integration Problems
    * 13.12 Differential equations
    * 13.13 The calculus of trigonometric functions
    * 13.14 Integration by rearrangement
    * 13.15 The Maclaurin series
      * 13.15.1 Factorials
      * 13.15.2 Stirling's approximation
      * 13.15.3 Trigonometric power series
    * 13.16 Calculus revision
      * 13.16.1 Problems
      * 13.16.2 Answers
  * 14 Some useful aspects of calculus
    * 14.1 Numerical differentiation
    * 14.2 Numerical integration
  * 15 Enzyme kinetics
  * 16 Some mathematical examples applied to chemistry
    * 16.1 van der Waals Energy
    * 16.2 A diatomic potential energy surface
    * 16.3 A one-dimensional metal
    * 16.4 Kepler's Laws
    * 16.5 Newton's law of cooling
    * 16.6 Bacterial Growth
    * 16.7 Partial fractions for the 2nd order rate equation
  * 17 Tests and exams
    * 17.1 50 Minute Test II
    * 17.2 50 Minute Test III
  * 18 Further reading
    * 18.1 Books
    * 18.2 Online resources

# Table of contents[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=1)]

  1. [Introduction](/wiki/Mathematics_for_Chemistry/Introduction)
  2. [Number theory](/wiki/Mathematics_for_Chemistry/Number_theory)
  3. [Functions](/wiki/Mathematics_for_Chemistry/Functions)
  4. [Units and dimensions](/wiki/Mathematics_for_Chemistry/Units_and_dimensions)
  5. [Statistics](/wiki/Mathematics_for_Chemistry/Statistics)
  6. [Plotting graphs](/wiki/Mathematics_for_Chemistry/Plotting_graphs)
  7. [Complex numbers](/wiki/Mathematics_for_Chemistry/Complex_Numbers)
  8. [Trigonometry](/wiki/Mathematics_for_Chemistry/Trigonometry)
  9. [Vectors](/wiki/Mathematics_for_Chemistry/Vectors)
  10. [Matrices and determinants](/wiki/Mathematics_for_Chemistry/Matrices_and_Determinants)
  11. [Differentiation](/wiki/Mathematics_for_Chemistry/Differentiation)
  12. [Integration](/wiki/Mathematics_for_Chemistry/Integration)
  13. [Some useful aspects of calculus](/wiki/Mathematics_for_Chemistry/Some_Useful_Aspects_of_Calculus)
  14. [Enzyme kinetics](/w/index.php?title=Mathematics_for_Chemistry/Enzyme_kinetics&action=edit&redlink=1)
  15. [Some mathematical examples applied to chemistry](/wiki/Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry)
  16. [Tests and exams](/wiki/Mathematics_for_Chemistry/Tests_and_Exams)
  17. [Further reading](/wiki/Mathematics_for_Chemistry/Further_reading)

# Introduction[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=2)]

  1. This book was initially derived from a set of notes used in a university chemistry course. It is hoped it will evolve into something useful and develop a set of open access **problems** as well as pedagogical material.

For many universities the days when admission to a Chemistry, Chemical Engineering, Materials Science or even Physics course could require the equivalent of A-levels in Chemistry, Physics and Mathematics are probably over for ever. The broadening out of school curricula has had several effects, including student entry with a more diverse educational background and has also resulted in the subject areas Chemistry, Physics and Mathematics becoming **disjoint** so that there is no co-requisite material between them. This means that, for instance, physics cannot have any advanced, or even any very significant mathematics in it. This is to allow the subject to be studied without any of the maths which might be first studied by the A-level maths group at the ages of 17 and 18. Thus physics at school has become considerably more descriptive and visual than it was 20 years ago. The same applies to a lesser extent to chemistry.

This means there must be an essentially _remedial_ component of university chemistry to teach just the Mathematics and Physics which is needed and not too much, if any more, as it is time consuming and perhaps not what the student of Chemistry is most focused on. There is therefore also a need for a book [Physics for Chemistry](/w/index.php?title=Physics_for_Chemistry&action=edit&redlink=1).

## Quantitative methods in chemistry[[edit](/w/index.php?title=Mathematics_for_Chemistry/Introduction&action=edit&section=T-1)]

There are several reasons why numerical (quantitative) methods are useful in chemistry:

  * Chemists need numerical information concerning reactions, such as how much of a substance is consumed, how long does this take, how likely is the reaction to take place.
  * Chemists work with a variety of different units, with wildly different ranges, which one must be able to use and convert with ease.
  * Measurements taken during experiments are not perfect, so evaluation and combination of errors is required.
  * Predictions are often desired, and relationships represented as equations are manipulated and evaluated in order to obtain information.

# Numbers[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=3)]

  1. ==Numbers==

    _For more details on this topic, see [Number Theory](/wiki/Number_Theory)._

[Real numbers](//en.wikipedia.org/wiki/en:Real_number) come in several varieties and forms;

  * [Integers](//en.wikipedia.org/wiki/en:Integer) are whole numbers used for counting indivisible objects, together with negative equivalents and zero, _e.g._ 42, -7, 0
  * [Rational numbers](//en.wikipedia.org/wiki/en:Rational_number) can always be expressed as fractions, _e.g._ 4.673 = 4673/1000.
  * [Irrational numbers](//en.wikipedia.org/wiki/en:Irrational_number), unlike rational numbers, cannot be expressed as a fraction or as a definite decimal, _e.g._ ![\\pi](//upload.wikimedia.org/math/5/2/2/522359592d78569a9eac16498aa7a087.png) and ![\\sqrt 2](//upload.wikimedia.org/math/1/7/f/17f932331bcaa69989387e73e0af09ac.png)
  * [Natural numbers](//en.wikipedia.org/wiki/en:Natural_number) are integers that are greater than or equal to zero.

It is also worth noting that the [imaginary unit](//en.wikipedia.org/wiki/en:Imaginary_unit) and therefore [complex numbers](//en.wikipedia.org/wiki/en:Complex_number) are used in chemistry, especially when dealing with equations concerning waves.

### Surds[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-2)]

The origin of [surds](//en.wikipedia.org/wiki/en:Nth_root#Working_with_surds) goes back to the Greek philosophers. It is relatively simple to prove that the square root of 2 cannot be a ratio of two integers, no matter how large the integers may become. In a rather [Pythonesque](//en.wikipedia.org/wiki/en:Monty_Python) incident the inventor of this proof was put to death for heresy by the other philosophers because they could not believe such a pure number as the root of 2 could have this _impure_ property.

(The original use of quadratic equations is very old, Babylon many centuries BC.) This was to allocate land to farmers in the same quantity as traditionally held after the great floods on the Tigris and Euphrates had reshaped the fields. The mathematical technology became used for the same purpose in the Nile delta.

When you do trigonometry later you will see that surds are in the trigonometric functions of the important symmetrical angles, _e.g._ ![ \\sin 60 = \\frac {\\sqrt{3} } {2} ](//upload.wikimedia.org/math/a/5/f/a5fa08f4ecfdca795fbe2afa7af9c35f.png) and so they appear frequently in mathematical expressions regarding 3 dimensional space.

### Notation[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-3)]

The notation used for recording numbers in chemistry is the same as for other scientific disciplines, and appropriately called [scientific notation](//en.wikipedia.org/wiki/en:Scientific_notation), or _standard form_. It is a way of writing both very large and very small numbers in a shortened form compared to [decimal notation](//en.wikipedia.org/wiki/en:Decimal#Decimal_notation). An example of a number written in scientific notation is

![4.65 \\times 10^6](//upload.wikimedia.org/math/0/a/a/0aada83fa8313721b6b851c552c3b38b.png)

with 4.65 being a coefficient termed the [significand](//en.wikipedia.org/wiki/en:Significand) or the _mantissa_, and 6 being an integer [exponent](//en.wikipedia.org/wiki/en:Exponentiation). When written in decimal notation, the number becomes

![4650000](//upload.wikimedia.org/math/8/f/6/8f6344f2756fea766e17d87e5a3850f5.png).

Numbers written in scientific notation are usually normalised, such that only one digit precedes the decimal point. This is to make [order of magnitude](//en.wikipedia.org/wiki/en:Order_of_magnitude) comparisons easier, by simply comparing the exponents of two numbers written in scientific notation, but also to minimise transcription errors, as the decimal point has an assumed position after the first digit. In computing and on calculators, it is common for the ![\\times 10](//upload.wikimedia.org/math/0/1/6/0166cd53a72257dda7daf058140c638c.png) ("times ten to the power of") to be replaced with "E" (capital e). It is important not to confuse this "E" with the [mathematical constant _e_](//en.wikipedia.org/wiki/en:E_\(mathematical_constant\)).

Engineering notation is a special restriction of scientific notation where the exponent must be divisible by three. Therefore, engineering notation is not normalised, but can easily use [SI prefixes](//en.wikipedia.org/wiki/en:SI_prefix) for magnitude.

Remember that in [SI](//en.wikipedia.org/wiki/en:International_System_of_Units), numbers do not have commas between the thousands, instead there are spaces, _e.g._ ![18~617~132](//upload.wikimedia.org/math/c/a/8/ca8b18fcdee312f22193d87dbd40be6e.png), (an integer) or ![1.861~713~2 {\\rm x}  10^{7}](//upload.wikimedia.org/math/7/e/a/7eac08712be8a2fa4aca12a94d0ed3b9.png). Commas are used as decimal points in many countries.

### Exponents[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit).

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Exponentiation**_](//en.wikipedia.org/wiki/Exponentiation)

Consider a number ![x^n](//upload.wikimedia.org/math/5/e/d/5ed2ec358abc7d521a3330e8b84cc7df.png), where ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) is the [base](//en.wikipedia.org/wiki/en:Base_\(mathematics\)) and ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) is the [exponent](//en.wikipedia.org/wiki/en:Exponentiation). This is generally read as “![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) to the ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png)” or “![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) to the power of ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png)”. If ![n=2](//upload.wikimedia.org/math/c/3/0/c303081f7a16f603112b0375bdc84883.png) then it is common to say “![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) squared”, and if ![n=3](//upload.wikimedia.org/math/f/4/b/f4b339682e05755eb7408448ef87e1ca.png) then “![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) cubed”. Comparing powers (exponentiation) to multiplication for positive integer values of n ![\(n = 1, 2, 3\\dots\)](//upload.wikimedia.org/math/b/c/c/bcc4c381278759fdec3ec5397ac95603.png), it can be demonstrated that

![4x = x+x+x+x](//upload.wikimedia.org/math/5/b/9/5b9ca42897dbc93046dc24ae5643c1a4.png), _i.e._ four lots of ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) added together

![x^4 = x \\times x \\times x \\times x](//upload.wikimedia.org/math/2/5/e/25e9120ea5dde4e511ba859aedc28f35.png), _i.e._ ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) multiplied by itself four times.

For ![x^1](//upload.wikimedia.org/math/6/3/f/63f08d62841dde1a9a22641ec0c1767a.png), the result is simply ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png). For ![x^0](//upload.wikimedia.org/math/5/9/b/59b95a7f867ce9d4e0f0b5f86f1260ff.png) the result is ![1](//upload.wikimedia.org/math/c/4/c/c4ca4238a0b923820dcc509a6f75849b.png).

### Order of operations[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-5)]

When an expression contains different operations, they must be evaluated in a certain order. Exponents are evaluated first. Then, multiplication and division are evaluated from left to right. Last, addition and subtraction are evaluated left to right. Parentheses or brackets take precedence over all operations. Anything within parentheses must be calculated first. A common acronym used to remember the order of operations is **PEMDAS**, for "Parentheses, Exponents, Multiplication, Division, Addition, Subtraction". Another way to remember this acronym is "Please Excuse My Dear Aunt Sally".

Keep in mind that negation is usually considered multiplication. So in the case of ![-x^2](//upload.wikimedia.org/math/2/b/c/2bcf020f163801f04d18b832eaceb98e.png), the exponent would be evaluated first, then negated, resulting in a negative number.

Take note of this example:

![3 + x \\times 2](//upload.wikimedia.org/math/1/0/4/104e795817638b6c18896bebc5d1e410.png), let x=5.

If evaluated incorrectly (left-to-right, with no order of operations), the result would be 16. Three plus five gives eight, times two is 16. The correct answer should be 13. Five times two gives ten, plus three gives 13. This is because multiplication is solved before addition.

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Order of operations**_](//en.wikipedia.org/wiki/Order_of_operations)

## Partial fractions[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-6)]

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Partial fractions**_](//en.wikipedia.org/wiki/Partial_fractions)

Partial fractions are used in a few derivations in thermodynamics and they are good for practicing algebra and factorisation.

It is possible to express quotients in more than one way. Of practical use is that they can be collected into one term or generated as several terms by the method of partial fractions. Integration of a complex single term quotient is often difficult, whereas by splitting it up into a sum, a sum of standard integrals is obtained. This is the principal chemical application of partial fractions.

An example is

![ \\frac {x-2} {\(x+1\) \(x-1\) } = \\frac { A \(x-1\) + B \(x+1\) } {\(x+1\) \(x-1\) } = \\frac {A} {\(x+1\) } + \\frac {B} {\(x-1\) } ](//upload.wikimedia.org/math/2/a/2/2a2fb5535182a096040bb77dcfe0b5d8.png)

In the above ![ x-2 ](//upload.wikimedia.org/math/4/b/a/4ba98f95a0382c3e1af6425dfd7927bd.png) must equal ![ A \(x-1\) + B \(x+1\) ](//upload.wikimedia.org/math/8/b/f/8bf2c17d7d77c559c57e85cff5abc696.png) since the denominators are equal. So we set ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) first to +1 giving ![ -1 = 2B](//upload.wikimedia.org/math/6/3/c/63c7ec7f4a7b644725cdf90f9f7cde56.png). Therefore B = -1/2. If we set ![x = -1](//upload.wikimedia.org/math/d/3/2/d3289a96da4c1cf6ce57b2b76b80b965.png) instead ![-3 = -2A](//upload.wikimedia.org/math/3/c/1/3c18b515f5bd554ecef013e8ec32165c.png), therefore ![A = 3/2](//upload.wikimedia.org/math/f/6/7/f6738d390d05264fb1f5268c80a016b6.png). So

![ \\frac {x-2} {\(x+1\) \(x-1\) }  =  \\frac {3} {2\(x+1\) } - \\frac {1} {2\(x-1\) } ](//upload.wikimedia.org/math/b/9/5/b95f45328aecb7efa2c99a6d00d5c822.png)

We can reverse this process by use of a _common denominator_.

![ \\frac {3} {2\(x+1\) } - \\frac {1} {2\(x-1\) } = \\frac {3 \(x-1\) - \(x+1\)} {2\(x+1\)\(x-1\) } ](//upload.wikimedia.org/math/8/c/5/8c5ace6825985bdeb9028d65aa3413a9.png)

The numerator is ![2x -4](//upload.wikimedia.org/math/2/3/3/2337b99632edd811579404d743e1f02e.png), so it becomes

![ \\frac {\(x-2\) } {\(x+1\)\(x-1\) } ](//upload.wikimedia.org/math/5/5/8/558c2859acfb3a8404be4968786f7f66.png)

which is what we started from.

So we can generate a single term by multiplying by the denominators to create a common denominator and then add up the numerator to simplify. A typical application might be to convert a term to partial fractions, do some calculus on the terms, and then regather into one quotient for display purposes. In a factorised single quotient it will be easier to see where numerators go to zero, giving solutions to ![f\(x\) = 0](//upload.wikimedia.org/math/f/d/0/fd05d8d90456c441c8f10641bd8576bc.png), and where denominators go to zero giving infinities.

A typical example of a meaningful infinity in chemistry might be an expression such as

![ \\frac A {{\(E-E_a\)}^2} ](//upload.wikimedia.org/math/a/e/8/ae849205c9ffe2670b776447ffa4d320.png)

The variable is the energy E, so this function is small everywhere, except near ![E_a](//upload.wikimedia.org/math/7/0/6/706147204f35ca44a72fd767aab6fa6e.png). Near ![E_a](//upload.wikimedia.org/math/7/0/6/706147204f35ca44a72fd767aab6fa6e.png) a _resonance_ occurs and the expression becomes infinite when the two energies are precisely the same. A molecule which can be electronically excited by light has several of these resonances.

Here is another example. If we had to integrate the following expression we would first convert to partial fractions:

![ \\frac {3x} {2x^2 - 2x -4} = \\frac {3x} {2 \(x+1\) \(x-2\)} = \\frac A {x+1} + \\frac B {x-2} ](//upload.wikimedia.org/math/a/5/e/a5e6f2403da1cf84cd5ef2bdb9742718.png)

so

![ \\frac 3 2 x = A \(x-2\) + B \(x-1\) ](//upload.wikimedia.org/math/d/1/3/d136f4332c125de0d636dfffa42c892b.png)

let ![x = 2](//upload.wikimedia.org/math/5/6/6/566162f3afaf9f5f67e7d7ca7a4b424e.png) then ![3 = B](//upload.wikimedia.org/math/3/b/7/3b75d694883fd1aef9f8980abf8cff52.png)

let ![x = 1](//upload.wikimedia.org/math/a/2/5/a255512f9d61a6777bd5a304235bd26d.png) then ![\\frac{3}{2} = -A](//upload.wikimedia.org/math/d/1/0/d10993ce8de5533df3659ea984709016.png)

therefore the expression becomes

![ \\frac 3 {x-2} - \\frac 3 {2\(x+1\)} ](//upload.wikimedia.org/math/b/f/1/bf14d9f1f58adb660a3233cac7d1221c.png)

Later you will learn that these expressions integrate to give simple ![\\ln](//upload.wikimedia.org/math/3/c/1/3c178b05d8a108e6346e61420651bedf.png) expressions.

### Problems[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-7)]

![{\\rm \(1\)~~~~~~}\\frac {3} {x^2-1}{~~~~~~~~~~~~\\rm \(2\)~~~~~~}\\frac {4x-2} {x^2+2x}](//upload.wikimedia.org/math/7/f/e/7fee771962b92e94748b4108514bf592.png)

![{\\rm \(3\)~~~~~~}\\frac {4} {\(2x+1\) \(x-3\)}{~~~~~~~~~~~~\\rm \(4\)~~~~~~}\\frac {7x+6} {x^2+3x+2}](//upload.wikimedia.org/math/6/1/4/61424cef7cc785e69de2180292d6cba4.png)

![{~~~~~~\\rm \(5\)~~~~~~}\\frac {x+1} {2x^2-6x+4}](//upload.wikimedia.org/math/0/3/f/03f7949e5be3df0a5849cb5de444c17b.png)

### Answers[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-8)]

![{~~~~~~\\rm \(1\)~~~~~~}\\frac {3} {2\(x-1\) } - \\frac {3} {2\(x+1\) }{~~~~~~~~~~~~\\rm \(2\)~~~~~~}\\frac {5} {\(x+2\) } - \\frac {1} {x }](//upload.wikimedia.org/math/4/5/5/455e3809d66fd751e8b2b39ade960f92.png)

![{~\\rm \(3\)~~~~~~}\\frac {4} {7\(x-3\) } - \\frac {8} {7\(2x+1\) }{~~~~~~~~~~~~\\rm \(4\)~~~~~~}\\frac {8} {x+2 } - \\frac {1} {x+1 }](//upload.wikimedia.org/math/f/7/c/f7c392064106c771b939822f07d01e15.png)

![{~~\\rm \(5\)~~~~~~}\\frac {3} {2\(x-2\) } - \\frac {2} {2\(x-1\) }](//upload.wikimedia.org/math/a/2/5/a2594806234ce8ed522a34a8ec09ba3f.png)

## Polynomial division[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-9)]

This is related to partial fractions in that its principal use is to facilitate integration.

Divide out

![\\frac { 3x^2 -4 x -6} { 1 + x}](//upload.wikimedia.org/math/b/2/a/b2a183c97cc1382a6ed0df3ec6deceae.png)

like this

  

    
    
                   3x  - 7
                 -----------------
          x + 1  ) 3x2  -4x   -6
                   3x2  +3x
                   ---------
                    0   -7x   -6
                        -7x   -7
                        --------
                               1
    

So our equation becomes ![3 x - 7 + \\frac {1}{1+x}](//upload.wikimedia.org/math/7/1/a/71a692217257d05b0d5d92c9a0f89b89.png)

This can be easily differentiated, and integrated. If this is differentiated with the quotient formula it is considerably harder to reduce to the the same form. The same procedure can be applied to partial fractions.

## Substitutions and expansions[[edit](/w/index.php?title=Mathematics_for_Chemistry/Number_theory&action=edit&section=T-10)]

You can see the value of changing the variable by simplifying

![\\frac {{\\left\(\\frac { J \(J+1\)} {\\epsilon} \\right\) }^3 + 2 {\\left\(\\frac { J \(J+1\)} {\\epsilon} \\right\) } +1 } {{\\left\(\\frac { J \(J+1\)} {\\epsilon} \\right\) }^2 -9} - \\frac {{\\left\(\\frac { J \(J+1\)} {\\epsilon} \\right\) }^2 - 2 {\\left\(\\frac { J \(J+1\)} {\\epsilon} \\right\) } +1 } {{\\left\(\\frac { J \(J+1\)} {\\epsilon} \\right\) }^2 + 9}](//upload.wikimedia.org/math/3/d/8/3d86edf4cec2e249dd1f8c6ccb039329.png)

to

![\\frac {x^3 + 2x + 1 } {x^2 - 9} - \\frac {x^2 - 2x + 1 } {x^2 + 9}](//upload.wikimedia.org/math/a/1/b/a1b3b5d76df0a0577c324322d06918c0.png)

where

![x = \\frac { J \(J+1\)} {\\epsilon}](//upload.wikimedia.org/math/d/d/e/dde43b15f7c439f20ae1d1ab165f0ec3.png)

This is an example of simplification. It would actually be possible to differentiate this with respect to either ![J](//upload.wikimedia.org/math/f/f/4/ff44570aca8241914870afbc310cdb85.png) or ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png) using only the techniques you have been shown. The algebraic manipulation involves _differentiation of a quotient_ and the _chain rule_.

Evaluating ![\\frac { {\\rm d} y} { {\\rm d} x}](//upload.wikimedia.org/math/7/c/4/7c42735883f1f04633f45e2faf49155d.png) gives

![ \\frac{3x^2 + 2}{x^2 - 9} -2 \\frac{\(x^3 + 2x + 1\)x}{\(x^2 - 9\)^2} - \\frac{2x - 2}{x^2 + 9} +2 \\frac{\(x^2 - 2x + 1\)x}{\(x^2 + 9\)^2} ](//upload.wikimedia.org/math/b/b/1/bb1618814d0ed586fc00377bd2018de7.png)

Expanding this out to the ![J](//upload.wikimedia.org/math/f/f/4/ff44570aca8241914870afbc310cdb85.png)s and ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png)s would look ridiculous.

Substitutions like this are continually made for the purpose of having new, simpler expressions, to which the rules of calculus or identities are applied.

# Functions[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=4)]

  1. ![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this chapter as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

## Functions as tools in chemistry[[edit](/w/index.php?title=Mathematics_for_Chemistry/Functions&action=edit&section=T-1)]

### The quadratic formula[[edit](/w/index.php?title=Mathematics_for_Chemistry/Functions&action=edit&section=T-2)]

In order to find the solutions to the general form of a [quadratic equation](//en.wikipedia.org/wiki/en:Quadratic_equation),

![a x^{2 }+ b x + c = 0](//upload.wikimedia.org/math/1/5/d/15d1a3243e73d6de47d474345769d809.png)

there is a formula

![ x =  \\frac {-b \\pm  \\sqrt { \(b^{2 }- 4 a c\)} } {2 a}](//upload.wikimedia.org/math/1/3/7/137227d5bf495e1350f6365e943452d3.png)

(Notice the line over the square root has the same _priority_ as a bracket. Of course we all know by now that ![\\sqrt {a +b}](//upload.wikimedia.org/math/3/8/5/3857f8bf5aae525af9a9e4db3b02cc3d.png) is not equal to ![\\sqrt {a } + \\sqrt {b}](//upload.wikimedia.org/math/2/7/9/27995d1407929fc103a873928eadb6b2.png) but errors of [priority](//en.wikipedia.org/wiki/en:Order_of_operations) are among the most common algebra errors in practice).

There is a formula for a [cubic equation](//en.wikipedia.org/wiki/en:Cubic_function) but it is rather complicated and unlikely to be required for undergraduate-level study of chemistry. Cubic and higher equations occur often in chemistry, but if they do not factorise they are usually solved by computer.

Solve:

![ 2x^{2} -  14 x + 9 ](//upload.wikimedia.org/math/c/4/a/c4a8173b745fb0aabf736e5387c921bc.png)

![ 1.56 \( x^{2} +  3.67 x + 0.014 \) ](//upload.wikimedia.org/math/4/7/4/4746d5ce29366b0d36d213d8532bd1cf.png)

Notice the _scope_ or _range_ of the bracket.

![ 2x^{2 } -  4 x + 2 ](//upload.wikimedia.org/math/8/e/4/8e42ffb93fdb997294c815248c886aef.png)

![ -45.1 \( 1.2\[A\]^{2 } -  57.9 \[A\] + 4.193 \) ](//upload.wikimedia.org/math/5/c/6/5c6da1c81887b1148e23ad50a8909dc4.png)

Notice here that the variable is a _concentration,_ not the ubiquitous ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png).

# Units and dimensions[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=5)]

  1. ==Units, multipliers and prefixes==

It is usually necessary in chemistry to be familiar with at least three systems of units, [Le Système International d'Unités (SI)](//en.wikipedia.org/wiki/en:International_System_of_Units), [atomic units](//en.wikipedia.org/wiki/en:Atomic_units) as used in theoretical calculations and the unit system used by the experimentalists. Thus if we are dealing with the ionization energy, the units involved will be the [Joule](//en.wikipedia.org/wiki/en:Joule) (J), the [Hartree](//en.wikipedia.org/wiki/en:Hartree) (Eh, the atomic unit of energy), and the [electron volt](//en.wikipedia.org/wiki/en:Electron_volt) (eV).

These units all have their own advantages;

  * The SI unit should be understood by all scientists regardless of their field.
  * The atomic unit system is the natural unit for theory as most of the fundamental constants are unity and equations can be cast in dimensionless forms.
  * The electron volt comes from the operation of the ionization apparatus where individual electrons are accelerated between plates which have a potential difference in Volts.

An advantage of the SI system is that the dimensionality of each term is made clear as the fundamental constants have structure. This is a complicated way of saying that if you know the dimensionality of all the things you are working with you know an awful lot about the mathematics and properties such as scaling with size of your system. Also, the same system of units can describe both the output of a large power station (gigaJoules), or the interaction of two inert gas atoms, (a few kJ per mole or a very small number of Joules per molecule when it has been divided by Avogadro's number).

In SI the symbols for units are lower case unless derived from a person's name, _e.g._ ampere is A and kelvin is K.

SI base units

Name Symbol Quantity

[metre](//en.wikipedia.org/wiki/en:Metre)
**m**
[length](//en.wikipedia.org/wiki/en:Length)

[kilogram](//en.wikipedia.org/wiki/en:Kilogram)
**kg**
[mass](//en.wikipedia.org/wiki/en:Mass)

[second](//en.wikipedia.org/wiki/en:Second)
**s**
[time](//en.wikipedia.org/wiki/en:Time)

[ampere](//en.wikipedia.org/wiki/en:Ampere)
**A**
[electric current](//en.wikipedia.org/wiki/en:Electric_current)

[kelvin](//en.wikipedia.org/wiki/en:Kelvin)
**K**
[thermodynamic temperature](//en.wikipedia.org/wiki/en:Thermodynamic_temperature)

[candela](//en.wikipedia.org/wiki/en:Candela)
**cd**
[luminous intensity](//en.wikipedia.org/wiki/en:Luminous_intensity)

[mole](//en.wikipedia.org/wiki/en:Mole_\(unit\))
**mol**
[amount of substance](//en.wikipedia.org/wiki/en:Amount_of_substance)

Derived units used in chemistry

Quantity Unit Name Symbol

Area
m2

Volume
m3

Velocity
m s-1

Acceleration
m s-2

Density
kg m3

Entropy
J mol-1 K-1

Force
kg m s-2
newton
N

Energy
N m
joule
J

Pressure
N m-2
pascal
Pa

Frequency
s-1
hertz
Hz

Approved prefixes for SI units

Prefix Factor Symbol

atto
10-18
a

femto
10-15
f

pico
10-12
p

nano
10-9
n

micro
10-6
μ

milli
10-3
m

centi
10-2
c

deci
10-1
d

kilo
103
k

mega
106
M

giga
109
G

tera
1012
T

peta
1015
P

exa
1018
E

Note the use of capitals and lower case and the increment on the exponent being factors of 3. Notice also centi and deci are supposed to disappear with time leaving only the powers of 1000.

## Conversion factors[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-2)]

The ![\\hat { } ](//upload.wikimedia.org/math/8/4/2/842de8fcbddc738be98872a8fb103d84.png), (sometimes call caret or hat), sign is another notation for _to the power of_. E means _times 10 to the power of_, and is used a great deal in computer program output.

### Energy[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-3)]

An approximation of how much of a chemical bond each energy corresponds to is placed next to each one. This indicates that light of energy 4 eV can break chemical bonds and possibly be dangerous to life, whereas infrared radiation of a few cm-1 is harmless.

  * 1 eV = 96.48530891 kJ mol-1 (Near infrared), approximately 0.26 chemical bonds
  * 1 kcal mol-1 = 4.184000000 kJ mol-1 (Near infrared), approximately 0.01 chemical bonds
  * 1 MHz = 0.399031E-06 kJ mol-1 (Radio waves), approximately 0.00 chemical bonds
  * 1 cm-1 = 0.01196265819 kJ mol-1 (Far infrared), approximately 0.00 chemical bonds

Wavelength, generally measure in nanometres and used in UV spectroscopy is defined as an inverse and so has a reciprocal relationship.

### Length[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-4)]

There is the metre, the Angstrom (10-10 m), the micron (10-6 m), the astronomical unit (AU)and many old units such as feet, inches and light years.

### Angles[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-5)]

The radian to degree conversion is 57.2957795130824, (i.e. a little bit less than 60, remember your equilateral triangle and radian sector).

### Dipole moment[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-6)]

1 Debye = 3.335640035 Cm x 10-30 (coulomb metre)

### Magnetic Susceptibility[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-7)]

1 cm3 mol-1 = 16.60540984 JT-2 x 1030 (joule tesla2)

### Old units[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-8)]

Occasionally, knowledge of older units may be required. Imperial units, or convert energies from BTUs in a thermodynamics project, etc.

In university laboratory classes you would probably be given material on the _Quantity Calculus_ notation and methodology which is to be highly recommended for scientific work.

A good reference for units, quantity calculus and SI is: I. Mills, T. Cuitas, K. Homann, N. Kallay, K. Kuchitsu, _Quantities, units and symbols in physical chemistry, 2nd edition_, (Oxford:Blackwell Scientific Publications,1993).

## Greek alphabet[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-9)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit).

## Unit labels[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-10)]

The labelling of tables and axes of graphs should be done so that the numbers are dimensionless, _e.g._ temperature is ![T / K](//upload.wikimedia.org/math/7/b/9/7b9e8074bbc570a6fa67f053584d947f.png),

![\\ln \(k/k_0\)](//upload.wikimedia.org/math/a/8/f/a8f319f9aaa6dea93477d45201a0998d.png) and energy mol / kJ _etc_.

This can look a little strange at first. Examine good text books like Atkins Physical Chemistry which follow SI carefully to see this in action.

The hardest thing with conversion factors is to get them the right way round. A common error is to divide when you should be multiplying, also another common error is to fail to raise a conversion factor to a power.

![ \\text{Conversion factor} = \\frac {\\text{Units required}} {\\text{Units given}}](//upload.wikimedia.org/math/9/6/7/96704c05d2c54aa0415dfabcf75a113c.png)

1 eV = 96.48530891 kJ mol-1

1 cm-1 = 0.01196265819 kJ mol-1

To convert eV to cm-1, first convert to kJ per mole by multiplying by 96.48530891 / 1. Then convert to cm-1 by multiplying by 1 / 0.01196265819 giving 8065.540901. If we tried to go directly to the conversion factor in 1 step it is easy to get it upside down. However, common sense tell us that there are a lot of cm-1s in an eV so it should be obviously wrong.

1 inch = 2.54 centimetres. If there is a surface of nickel electrode of 2 * 1.5 square inches it must be 2 * 1.5 * 2.542 square centimetres.

To convert to square metres, the SI unit we must divide this by 100 * 100 not just 100.

### Dimensional analysis[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-11)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit).

The technique of adding unit labels to numbers is especially useful, in that analysis of the units in an equation can be used to double-check the answer.

## An aside on scaling[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-12)]

One of the reasons powers of variables are so important is because they relate to the way quantities scale. Physicists in particular are interested in the way variables scale in the limit of very large values. Take cooking the turkey for Christmas dinner. The amount of turkey you can afford is linear, (power 1), in your income. The size of an individual serving is quadratic, (power 2), in the radius of the plates being used. The cooking time will be something like cubic in the diameter of the turkey as it can be presumed to be linear in the mass.

(In the limit of a very large turkey, say one the diameter of the earth being heated up by a nearby star, the internal conductivity of the turkey would limit the cooking time and the time taken would be exponential. No power can go faster / steeper than exponential in the limit. The series expansion of ![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png) goes on forever even though ![1 / n!](//upload.wikimedia.org/math/c/3/a/c3a130ac78bbcb8898cee85821c57f03.png) gets very small.)

Another example of this is why dinosaurs had fatter legs than modern lizards. If dinosaurs had legs in proportion to small lizards the mass to be supported rises as length to the power 3 but the strength of the legs only rises as the area of the cross section, power 2. Therefore the bigger the animal the more enormous the legs must become, which is why a rhino is a very chunky looking version of a pig.

There is a very good article on this in Cooper, Necia Grant; West, Geoffrey B., _Particle Physics: A Los Alamos Primer_, [ISBN 0521347807](/wiki/Special:BookSources/0521347807)

## Making tables[[edit](/w/index.php?title=Mathematics_for_Chemistry/Units_and_dimensions&action=edit&section=T-13)]

# Statistics[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=6)]

  1. ![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this chapter as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

## Definition of errors[[edit](/w/index.php?title=Mathematics_for_Chemistry/Statistics&action=edit&section=T-1)]

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Approximation error**_](//en.wikipedia.org/wiki/Approximation_error)

For a quantity ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) the error is defined as ![\\Delta x](//upload.wikimedia.org/math/b/5/6/b56546a86ab832a9b2a5b15f96519319.png). Consider a burette which can be read to ±0.05 cm3 where the volume is measured at 50 cm3.

  * The _absolute error_ is ![\\pm \\Delta x, \\pm 0.05~\\text{cm}^3](//upload.wikimedia.org/math/c/d/7/cd7b3577eb096f75730285592a832d39.png)
  * The _fractional error_ is ![\\pm \\frac{\\Delta x}{x}](//upload.wikimedia.org/math/8/1/b/81b6b1d7563112ce8cba0ee6b64b7094.png), ![\\pm \\frac{0.05}{50} = \\pm 0.001](//upload.wikimedia.org/math/f/7/4/f74508f279fa93a489b255d49602479c.png)
  * The _percentage error_ is ![\\pm 100 \\times \\frac{\\Delta x}{x} = \\pm 0.1](//upload.wikimedia.org/math/e/a/9/ea92d21a794d68ab0382028a17e53c1c.png)%

## Combination of uncertainties[[edit](/w/index.php?title=Mathematics_for_Chemistry/Statistics&action=edit&section=T-2)]

In an experimental situation, values with errors are often combined to give a resultant value. Therefore, it is necessary to understand how to combine the errors at each stage of the calculation.

### Addition or subtraction[[edit](/w/index.php?title=Mathematics_for_Chemistry/Statistics&action=edit&section=T-3)]

Assuming that ![\\Delta x](//upload.wikimedia.org/math/b/5/6/b56546a86ab832a9b2a5b15f96519319.png) and ![\\Delta y](//upload.wikimedia.org/math/7/f/5/7f5a0c1aa836580b7c14bcd90384f9c9.png) are the errors in measuring ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png), and that the two variables are combined by addition or subtraction, the uncertainty (absolute error) may be obtained by calculating

![\\sqrt{\(\\Delta x\)^2 + \(\\Delta y\)^2}](//upload.wikimedia.org/math/9/9/7/99761477b2ad53804b10dcd25462169f.png)

which can the be expressed as a relative or percentage error if necessary.

### Multiplication or division[[edit](/w/index.php?title=Mathematics_for_Chemistry/Statistics&action=edit&section=T-4)]

Assuming that ![\\Delta x](//upload.wikimedia.org/math/b/5/6/b56546a86ab832a9b2a5b15f96519319.png) and ![\\Delta y](//upload.wikimedia.org/math/7/f/5/7f5a0c1aa836580b7c14bcd90384f9c9.png) are the errors in measuring ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png), and that the two variables are combined by multiplication or division, the fractional error may be obtained by calculating

![\\sqrt{\(\\frac{\\Delta x}{x}\)^2 + \(\\frac{\\Delta y}{y}\)^2}](//upload.wikimedia.org/math/9/d/a/9daa7a2362918bb956d2909ece6a4031.png)

# Plotting graphs[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=7)]

  1. ![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this chapter as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

## The properties of graphs[[edit](/w/index.php?title=Mathematics_for_Chemistry/Plotting_graphs&action=edit&section=T-1)]

The most basic relationship between two variables ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png) is a straight line, a _linear relationship_.

![ y = {\\rm m} x + {\\rm c} ](//upload.wikimedia.org/math/f/a/f/fafd4d6cf52b44ef34b0994af2eed9cf.png)

The variable ![m](//upload.wikimedia.org/math/6/f/8/6f8f57715090da2632453988d9a1501b.png) is the gradient and ![c](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png) is a constant which gives the intercept. The equations can be more complex than this including higher powers of ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png), such as

![ y = {\\rm a} x^2 + {\\rm b} x + {\\rm c} ](//upload.wikimedia.org/math/5/5/f/55f0ccec3848d6049cd02d2a15b48175.png)

This is called a _quadratic equation_ and it follows a shape called a [parabola](//en.wikipedia.org/wiki/en:Parabola). High powers of ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) can occur giving _cubic_, _quartic_ and _quintic_ equations. In general, as the power is increased, the line mapping the variables wiggles more, often cutting the ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png)-axis several times.

### Practice[[edit](/w/index.php?title=Mathematics_for_Chemistry/Plotting_graphs&action=edit&section=T-2)]

Plot ![x^2 - 1](//upload.wikimedia.org/math/8/7/1/8713a66a0a3e5f37cbf1103af6f56511.png) between -3 and +2 in units of 1.

Plot ![x^2 + 3 x](//upload.wikimedia.org/math/2/f/8/2f8d43e33ce097e0c6ef537269553d83.png) between -4 and +1 in units of 1.

Plot ![2 x^3 -5 x^2 - 12 x](//upload.wikimedia.org/math/8/6/1/861d5e695b5664756abb0629327ce15b.png) between -5 and +4 in units of 1.

# Complex numbers[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=8)]

  1. ==Introduction to complex numbers==

The equation:

![x^2 + 6 x + 13 = 0](//upload.wikimedia.org/math/4/9/2/4921b5219c59ad684f4a18deabb15454.png)

Does not factorise

![x = -3 \\pm \\sqrt {9-13}](//upload.wikimedia.org/math/c/4/6/c46ccb5670ea4912ac0904f449ebe626.png)

![\\sqrt {-4}](//upload.wikimedia.org/math/3/2/8/32843c249ca5f696d6def2bbc74d2275.png) without [complex numbers](//en.wikipedia.org/wiki/en:Complex_number) does not exist. However the number ![i=\\sqrt{-1}](//upload.wikimedia.org/math/9/0/2/9023999c16c1b1fa72a18a56d709120b.png) behaves exactly like any other number in algebra without any anomalies, allowing us to solve this problem.

The solutions are ![-3\\pm2i](//upload.wikimedia.org/math/6/1/3/613bd547290bd784a87d6a9eb81f1346.png).

![2i](//upload.wikimedia.org/math/e/5/d/e5de2e95102b1ed31c3edbcd9701b6f0.png) is an _imaginary_ number. ![-3-2i](//upload.wikimedia.org/math/0/2/8/02828cea19d4936729374e2980d381a8.png) is a _complex_ number.

Two complex numbers ![\(a,b\) = a + ib](//upload.wikimedia.org/math/8/4/9/84920da3da33906951e2aca550a22d71.png) are added by ![\(a,b\) + \(c,d\)                                              =

\(a+c,b+d\)](//upload.wikimedia.org/math/7/c/e/7ce3f919987f2350d46973176dc1e54b.png) ![= a+c+i\(b+d\)](//upload.wikimedia.org/math/9/e/e/9ee2c65b490a719c68adbfc6dc824d4d.png).

Subtraction is obvious: ![\(a,b\) - \(c,d\) = \(a-c,b-d\)](//upload.wikimedia.org/math/1/f/6/1f62a1c40cd394524beb3b37fc0af111.png).

![\(a,b\) . \(c,d\) = ac + i \( ad + bc \) - bd](//upload.wikimedia.org/math/b/d/1/bd139db9a95060d720e65486dc8f4ffb.png)

Division can be worked out as an exercise. It requires![\(c+id\) \(c-id\)](//upload.wikimedia.org/math/1/6/b/16ba5acc6462a1fcf1922857e6556fdf.png) as a common denominator. This is ![c^2-\(id\)^2](//upload.wikimedia.org/math/9/5/8/95814abfa93a98df918696b639862098.png), (difference of two squares), and is ![c^2 + d^2](//upload.wikimedia.org/math/f/4/d/f4d2fc07afdd68bcdc58072c1789cd19.png).

This means

![\\frac {\(a,b\) } {\(c,d\)} = \\frac {ac+bd+i\(cb-ad\)} {c^2+d^2}](//upload.wikimedia.org/math/1/9/a/19a9a352da4a3f73a2340481753a571b.png)

In practice complex numbers allow one to simplify the mathematics of magnetism and angular momentum as well as completing the number system.

There is an apparent one to one correspondence between the Cartesian ![x-y](//upload.wikimedia.org/math/1/9/d/19d59c7d61b117f2865b20b59c8b70f7.png) plane and the complex numbers, ![x + iy](//upload.wikimedia.org/math/2/f/1/2f12ba7cefcda3fc8b7350b087e20cf9.png). This is called an Argand diagram. The correspondence is illusory however, because say for example you raise the square root of ![i](//upload.wikimedia.org/math/8/6/5/865c0c0b4ab0e063e5caa3387c1a8741.png) to a series of ascending powers. Rather than getting larger it goes round and round in circles around the origin. This is not a property of ordinary numbers and is one of the fundamental features of behaviour in the complex plane.

Plot on the same Argand diagram ![2-i,~~~~3i-1,~~~~-2-2i](//upload.wikimedia.org/math/9/1/5/91576dfdfb176d6a4ae21a82960b5ac7.png)

Solve

![x^2 + 4x +29 = 0](//upload.wikimedia.org/math/4/a/f/4af064b6cce0ea72f1ae40bbf27acc84.png)

![4x^2 - 12x +25 = 0](//upload.wikimedia.org/math/3/0/9/309a0a3c1071afc6bd140af6d625a003.png)

![x^2 + 2ix + 1 = 0](//upload.wikimedia.org/math/b/7/0/b70d96c350fbd379e01f20212738fd80.png)

(Answers -2 plus or minus 5i, 3/2 plus or minus 2i, i(-1 plus or minus root 2)

2 important equations to be familiar with, Euler's equation:

![e^{i\\theta} = \\cos \\theta + i \\sin \\theta](//upload.wikimedia.org/math/8/c/7/8c7494d0429ac63725c5211166e1f1e5.png)

and de Moivre's theorem:

![{ \( \\cos \\theta + i \\sin \\theta \) }^n = \\cos n \\theta + i \\sin n \\theta](//upload.wikimedia.org/math/7/6/3/763da9698de4274ecf12a1901e28bfde.png)

Euler's equation is obvious from looking at the Maclaurin expansion of ![e^{ i\\theta}](//upload.wikimedia.org/math/d/8/d/d8d6f8466e46b0d087286a91cc71e739.png).

To find the square root of ![i](//upload.wikimedia.org/math/8/6/5/865c0c0b4ab0e063e5caa3387c1a8741.png) we use de Moivre's theorem.

![e^{i\\frac \\pi 2} = 0 +1i](//upload.wikimedia.org/math/6/c/e/6ceb72839ea381c9e2256c841371fe37.png)

so de Moivre's theorem gives ![\\sqrt{e^{i\\frac \\pi 2}}  = \\cos \\frac \\pi {2.2} + i  \\sin \\frac \\pi {2.2}](//upload.wikimedia.org/math/9/4/2/942848edf78df62b8c8278be175a3bed.png)

![= \\frac 1 {\\sqrt 2} + \\frac 1 {\\sqrt 2} i](//upload.wikimedia.org/math/a/2/2/a226f126aea71e06f5950e512527a9c5.png)

Check this by squaring up to give ![i](//upload.wikimedia.org/math/8/6/5/865c0c0b4ab0e063e5caa3387c1a8741.png).

The other root comes from:

![\\frac {5 \\pi} {4} + i  \\sin \\frac {5 \\pi} {4} = -\\frac 1 {\\sqrt 2} - \\frac 1 {\\sqrt 2} i](//upload.wikimedia.org/math/5/6/f/56ff42c9fe545ee32dbf16b6a7ecae63.png)

de Moivre's theorem can be used to find the _three_ cube roots of unity by

![1 = \\cos \\theta + i \\sin \\theta](//upload.wikimedia.org/math/f/b/5/fb5bf4701e01e88421137f4f84a888fb.png)

where ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) can be ![0 \\pm 2 \\pi / n](//upload.wikimedia.org/math/9/6/5/9651493b4e3b43920b5fe86a2c94829b.png).

Put ![n=1/3](//upload.wikimedia.org/math/4/d/e/4decd5844ee5217db5ebb2951a3b11c1.png), ![\\cos \\theta = -1 / 2](//upload.wikimedia.org/math/6/4/8/6482f98c31759a345b0bf52bc4ba4dc1.png) and ![\\sin \\theta = \\pm \\sqrt 3 / 2](//upload.wikimedia.org/math/d/1/d/d1d5412a23b1fcbf12f5c5e666a77f22.png)

![{\\left\( - \\frac  1 2 + \\frac {\\sqrt 3} 2 i \\right\) }^3 = \\left\(\\frac 1 4 - \\frac 3 4 -\\frac {\\sqrt 3} 2 i  \\right\)\\left\( - \\frac  1 2 + \\frac {\\sqrt 3} 2 i \\right\)](//upload.wikimedia.org/math/4/b/b/4bbe034158a5d3d4021b6458f3a9e7c1.png)

![= \\left\( - \\frac  1 2 - \\frac {\\sqrt 3} 2 i \\right\)\\left\( - \\frac  1 2 + \\frac {\\sqrt 3} 2 i \\right\)](//upload.wikimedia.org/math/f/4/8/f48794b5cc34e257ee5e9b5835cef989.png)

This is the difference of two squares so

![{  \\left\( \\frac  1 2 \\right\) }^2 - \\frac 3 4 i^2~~ = ~~~  \\frac  1 4 +  \\frac 3 4](//upload.wikimedia.org/math/9/1/6/916bb403abf4db1707aac85e7205e3ff.png)

Similarly any collection of ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png)th roots of 1 can be obtained this way.

Another example is to get the expressions for ![\\cos 4 \\theta](//upload.wikimedia.org/math/b/a/c/bac562bad071f614d33fce915f0f5e5c.png) and ![\\sin 4 \\theta](//upload.wikimedia.org/math/0/8/2/082c65ff780539a3c5e4dbb301294d60.png) without expanding ![\\cos \(2 \\theta + 2 \\theta\)](//upload.wikimedia.org/math/1/3/6/136751b104721d1f0e28fe3fd6f24c8b.png).

![\\cos 4 \\theta + i \\sin 4 \\theta = { \( \\cos \\theta + i \\sin \\theta \) }^4](//upload.wikimedia.org/math/b/2/6/b26e2ddb7dfbd3e9d42898331f895379.png)

Remember Pascal's Triangle

  

    
    
                              1
                          1   2   1
                        1   3   3   1
                      1   4   6   4   1
                    1   5   10  10  5   1
                  1   6   15  20  15  6   1
    

  
![= \\cos^4 \\theta + 4 \\cos^3\\theta i \\sin\\theta +  6 \\cos^2\\theta i^2 \\sin^2 \\theta + 4 \\cos\\theta i^3 \\sin^3 \\theta + i^4 \\sin^4 \\theta](//upload.wikimedia.org/math/8/d/4/8d43d70289e1b20875e621086020e0dd.png)

![= \\cos^4 \\theta -  6 \\cos^2\\theta  \\sin^2 \\theta +  \\sin^4 \\theta +i \( 4 \\cos^3\\theta \\sin\\theta - 4 \\cos\\theta  \\sin^3 \\theta\)](//upload.wikimedia.org/math/7/c/b/7cbc6c6ad5795a48631541d189327812.png)

_Separating the real and imaginary parts_ gives the two expressions. This is a lot easier than

![\\cos \(2 \\theta + 2 \\theta\)](//upload.wikimedia.org/math/1/3/6/136751b104721d1f0e28fe3fd6f24c8b.png)

Use the same procedure to get

![\\cos 6 \\theta](//upload.wikimedia.org/math/6/c/b/6cba271e74370fa4a0cb1f63a05ec457.png) and ![\\sin 6 \\theta](//upload.wikimedia.org/math/f/5/9/f592b106745cdc78839e301d395d3d08.png).

# Trigonometry[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=9)]

  1. ==Free Web Based Material from UK HEFCE==

There is a DVD on trigonometry at [Math Tutor](http://www.mathtutor.ac.uk/viewdisksinfo.php?disk=5).

## Trigonometry - the sin and cosine rules[[edit](/w/index.php?title=Mathematics_for_Chemistry/Trigonometry&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/48/Trigonometric_Triangle.svg/280px-Trigonometric_Triangle.svg.png)

Trigonometric triangle

In the following trigonometric identities, ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png), ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) and ![c ](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png) are the lengths of sides in a triangle, opposite the corresponding angles ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png), ![B](//upload.wikimedia.org/math/9/d/5/9d5ed678fe57bcca610140957afab571.png) and ![C](//upload.wikimedia.org/math/0/d/6/0d61f8370cad1d412f80b84d143e1257.png).

  * The sin rule ![\\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C}](//upload.wikimedia.org/math/e/4/2/e420193c4516417f3cc365ec8c0ab528.png)
  * The cosine rule ![c^2 = a^2 + b^2 -2ab \\cos C](//upload.wikimedia.org/math/7/6/d/76d67c8a1b7577ebd6e177830c1cb07d.png)
  * The ratio identity ![\\tan A = \\frac{\\sin A}{\\cos A}](//upload.wikimedia.org/math/5/c/6/5c6713c8394000c3c1a0563a78fc5772.png)

## Trigonometric identities[[edit](/w/index.php?title=Mathematics_for_Chemistry/Trigonometry&action=edit&section=T-3)]

![ \\cos^2 \\theta + \\sin^2 \\theta = 1](//upload.wikimedia.org/math/8/0/4/8044379582d6972f8bfc5e045dd65bac.png)

Remember this is a consequence of Pythagoras' theorem where the length of the hypotenuse is 1.

![\\sin \( \\theta + \\phi \) = \\sin  \\theta \\cos \\phi  + \\cos  \\theta \\sin \\phi](//upload.wikimedia.org/math/a/7/3/a73ed39a3e8ffbda93a7b0864fafcc26.png)

![\\cos \( \\theta + \\phi \) = \\cos  \\theta \\cos \\phi  - \\sin  \\theta \\sin \\phi](//upload.wikimedia.org/math/8/1/b/81bd90e5e441f0e02023eb02da657675.png)

The difference of two angles can easily be generated by putting ![\\phi = -\\phi](//upload.wikimedia.org/math/a/0/2/a023df3de1a820d130aaee04fc5edf14.png) and remembering ![\\sin -\\phi = - \\sin \\phi](//upload.wikimedia.org/math/e/7/2/e7277f5389cd8f76d6ffe2b043e05081.png) and ![\\cos -\\phi =  \\cos \\phi](//upload.wikimedia.org/math/8/f/f/8ffb74367d6beb0957850e0aceedeb3a.png). Similarly, the double angle formulae are generated by induction. ![\\tan \( \\theta + \\phi \)](//upload.wikimedia.org/math/c/6/6/c666368be3af2b89ca18402322d1b43e.png) is a little more complicated but can be generated if you can handle the fractions! The proofs are in many textbooks but as a chemist it is not necessary to know them, only the results.

## Identities and equations[[edit](/w/index.php?title=Mathematics_for_Chemistry/Trigonometry&action=edit&section=T-4)]

Identities and equations look very similar, two things connected by an equals sign. An identity however is a memory aid of a mathematical equivalence and can be proved. An equation represents new information about a situation and can be solved.

For instance,

![
\\cos^2 \\theta + \\sin^2 \\theta = 1
](//upload.wikimedia.org/math/8/0/4/8044379582d6972f8bfc5e045dd65bac.png)

is an identity. It cannot be solved for ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png). It is valid for all ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png). However,

![
\\cos^2 \\theta = 1
](//upload.wikimedia.org/math/0/0/6/0062bef585f7d9489352de44325d5a07.png)

is an equation where ![\\theta = \\arccos \\pm 1](//upload.wikimedia.org/math/4/f/8/4f80a79c88150a1b20feee5178467923.png).

If you try and solve an identity as an equation you will go round and round in circles getting nowhere, but it would be possible to dress up ![\\cos^2 \\theta + \\sin^2 \\theta = 1](//upload.wikimedia.org/math/8/0/4/8044379582d6972f8bfc5e045dd65bac.png) into a very complicated expression which you could mistake for an equation.

## Some observations on triangles[[edit](/w/index.php?title=Mathematics_for_Chemistry/Trigonometry&action=edit&section=T-5)]

Check you are familiar with your elementary geometry. Remember from your GCSE maths the properties of equilateral and iscoceles triangles. If you have an iscoceles triangle you can always dispense with the sin and cosine rules, drop a perpendicular down to the base and use trig directly. Remember that the bisector of a side or an angle to a vertex cuts the triangle in two by area, angle and length. This can be demonstrated by drawing an obtuse triangle and seeing that the areas are ![\\frac 1 2 \\frac 1  2 .R.h](//upload.wikimedia.org/math/8/8/4/88479789a26390a905efa99a69819c80.png).

## The interior angles of a polygon[[edit](/w/index.php?title=Mathematics_for_Chemistry/Trigonometry&action=edit&section=T-6)]

Remember that the interior angles of a ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png)-sided polygon are n * 180 -360,

(![n \\pi - 2 \\pi](//upload.wikimedia.org/math/a/d/5/ad5d2e4730a42cba755b20586e015706.png)).

For [benzene](//en.wikipedia.org/wiki/en:Benzene) there are six _equilateral_ triangles if the centre of the ring is used as a vertex, each of which having an interior angle of 120 degrees. Work out the the angles in azulene, (a hydrocarbon with a five and a seven membered ring), assuming all the C-C bond lengths are equal, (this is only approximately true).

# Vectors[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=10)]

  1. ==Free Web Based Material from HEFCE==

There is a DVD on vectors at [Math Tutor](http://www.mathtutor.ac.uk/viewdisksinfo.php?disk=4).

## Vectors[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-2)]

Imagine you make a rail journey from Doncaster to Bristol, from where you travel up the West of the country to Manchester. Here you stay a day, travelling the next morning to Glasgow, then across to Edinburgh. At the end of a day's work you return to Doncaster. Mathematically this journey could be represented by vectors, (in 2 dimensions because we are flat earthers on this scale). At the end of the 2nd journey (D-B) + (B-M) you are only a short distance from Doncaster, 50 miles at 9.15 on the clockface. Adding two more vectors, (journeys) takes you to Edinburgh, (about 250 miles at 12.00). Completing the journey leaves you at a zero vector away from Doncaster, _i.e._ all the vectors in this closed path add to zero.

Mathematically we usually use 3 dimensional vectors over the 3 Cartesian axes ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png), ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png) and ![z](//upload.wikimedia.org/math/f/b/a/fbade9e36a3f36d3d676c1b808451dd7.png).

It is best always to use the conventional right handed axes even though the other way round is equally valid if used consistently. The wrong handed coordinates can occasionally be found erroneously in published research papers and text books. The memory trick is to think of a sheet of graph paper, ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) is across as usual and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png) up the paper. Positive ![z](//upload.wikimedia.org/math/f/b/a/fbade9e36a3f36d3d676c1b808451dd7.png) then comes out of the paper.

A _unit vector_ is a vector _normalised_, _i.e._ multiplied by a constant so that its value is 1. We have the unit vectors in the 3 dimensions:

![{\\hat {\\mathbf i}}  + {\\hat {\\mathbf j}}  + {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/1/c/4/1c42019d323f517425bd2a474cd2115e.png)

so that

![{\\mathbf v}  = A_x{\\hat {\\mathbf i}}  + A_y {\\hat {\\mathbf j}}  + A_z {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/1/7/2/17208b2464f055071a7f9b4931a5f3e7.png)

The hat on the i, j, k signifies that it is a _unit vector_. This is usually omitted.

Our geographical analogy allows us to see the meaning of vector addition and subtraction. Vector **products** are less obvious and there are two definitions the _scalar product_ and the _vector product_. These are different kinds of mathematical animal and have very different applications. A scalar product is an area and is therefore an ordinary number, a scalar. This has many useful trigonometrical features.

The vector product seems at first to be defined rather strangely but this definition maps onto nature as a very elegant way of describing _angular momentum_. The structure of Maxwell's Equations is such that this definition simplifies all kinds of mathematical descriptions of atomic / molecular structure and electricity and magnetism.

## A summary of vectors[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-3)]

The unit vectors in the 3 Cartesian dimensions:

![{\\hat {\\mathbf i}}  + {\\hat {\\mathbf j}}  + {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/1/c/4/1c42019d323f517425bd2a474cd2115e.png)

a vector ![{\\mathbf v}](//upload.wikimedia.org/math/2/0/a/20aaed6ad640476dedcd1261dcfb8c5f.png) is:

![{\\mathbf v}  = A_x{\\hat {\\mathbf i}}  + A_y {\\hat {\\mathbf j}}  + A_z {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/1/7/2/17208b2464f055071a7f9b4931a5f3e7.png)

The hat on the i, j, k signifies that it is a _unit vector_.

### Vector magnitude[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-4)]

![V_{mag}   =  \\sqrt { { A_x }^2 +  { A_y }^2 +  { A_z }^2 }](//upload.wikimedia.org/math/7/9/e/79e26a6e48b3a4a8599352805a844b67.png)

### A constant times a vector[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-5)]

![{\\mathbf v_{new}}  = c A_x {\\hat {\\mathbf i}}  + c A_y {\\hat {\\mathbf j}}  + c A_z {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/f/7/d/f7dfaa10ce76ffbdab9f73baabffd7f8.png)

### Vector addition[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-6)]

![{\\mathbf  A}   + {\\mathbf B}  = \( A_x + B_x  \) {\\hat {\\mathbf i}} + \( A_y + B_y  \) {\\hat {\\mathbf j}}  + \( A_z + B_z \) {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/b/b/b/bbbd3d5e485261320879b641b8026736.png)

Notice ![{\\mathbf  B}   + {\\mathbf A} = {\\mathbf  A}   + {\\mathbf B}](//upload.wikimedia.org/math/c/0/f/c0f7dd09481a80a5e17dc14ba52ca242.png)

### Vector subtraction[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-7)]

![{\\mathbf  A}   - {\\mathbf B}  = \( A_x - B_x  \) {\\hat {\\mathbf i}} + \( A_y - B_y  \) {\\hat {\\mathbf j}} + \( A_z - B_z \) {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/c/c/b/ccbde629b18351bbc3520bfcfe5d8a72.png)

Notice ![{\\mathbf  A}   - {\\mathbf B} = - \( - {\\mathbf  A}   + {\\mathbf B}\)](//upload.wikimedia.org/math/e/4/6/e462addb72ea2059ef43760d31711abc.png)

### Scalar Product[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-8)]

![{\\mathbf  A}   . {\\mathbf B}  =  A_x . B_x   +  A_y . B_y   +  A_z . B_z](//upload.wikimedia.org/math/a/3/0/a309a8139647f52bb09b7f53602f81b3.png)

Notice ![{\\mathbf  B} . {\\mathbf A} = {\\mathbf  A} . {\\mathbf B}](//upload.wikimedia.org/math/0/c/a/0cac94e669286b1271eaa8afde923920.png)

Notice that if ![{\\mathbf  A} = {\\mathbf B} ](//upload.wikimedia.org/math/6/6/5/66557de620207ad9edd55337fa01bf06.png) this reduces to a square.

If A and B have no common non-zero components in ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png), ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png) and ![z](//upload.wikimedia.org/math/f/b/a/fbade9e36a3f36d3d676c1b808451dd7.png) the value is zero corresponding to _orthogonality_, _i.e._ they are at right angles. (This can also occur by sign combinations making ![{\\mathbf  A} . {\\mathbf B} ](//upload.wikimedia.org/math/c/a/9/ca99872aa921734347d0f1952c4a1745.png) zero. corresponding to non axis-hugging right angles.)

### Vector product[[edit](/w/index.php?title=Mathematics_for_Chemistry/Vectors&action=edit&section=T-9)]

![{\\mathbf  A}  {\\rm x }{\\mathbf B}  = \( A_y  B_z  - A_z B_y\) {\\hat {\\mathbf i}} - \( A_x  B_z  - A_z B_x \) {\\hat {\\mathbf j}} +  \( A_x  B_y - A_y B_x\) {\\hat {\\mathbf k}}](//upload.wikimedia.org/math/2/3/b/23b3687bc978902446adee2bf6ff7aee.png)

Notice ![{\\mathbf  B}   {\\rm x }{\\mathbf A} = - {\\mathbf  A}   {\\rm x }{\\mathbf B}](//upload.wikimedia.org/math/d/5/2/d52bac167dcbeea0664127908d1e0edd.png)

The minus sign on the middle term comes from the definition of the determinant, explained in the lecture. Determinants are defined that way so they correspond to right handed rotation. (If you remember our picture of ![\\cos^2 + \\sin^2 = 1](//upload.wikimedia.org/math/8/1/c/81c6887a6ae7c128cba4d1d3c3c878e9.png) going round the circle, as one coordinate goes up, _i.e._ more positive, another must go down. Therefore rotation formulae must have both negative and positive terms.) Determinants are related to rotations and the solution of simultaneous equations. The solution of ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) simultaneous equations can be recast in graphical form as a rotation to a unit vector in ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png)-dimensional space so therefore the same mathematical structures apply to both space and simultaneous equations.

# Matrices and determinants[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=11)]

  1. ==Simultaneous linear equations==

If we have 2 equations of the form ![y = {\\rm m} x + {\\rm c}](//upload.wikimedia.org/math/f/a/f/fafd4d6cf52b44ef34b0994af2eed9cf.png) we may have a set of _simultaneous equations_. Suppose two rounds of drinks are bought in a cafe, one round is 4 halves of orange juice and 4 packets of crisps. This comes to 4 pounds 20. The thirstier drinkers at another table buy 4 pints of orange juice and only 1 packet of crisps and this comes to 6 pounds 30. So we have:

![4.20 = 2 x + 4 y](//upload.wikimedia.org/math/e/8/b/e8bfefaaa5f2b38ac9ea3aceaa5be40a.png)

and

![6.30 = 4 x + y](//upload.wikimedia.org/math/7/6/1/761280c6b4c535bd15279c291d378f8c.png)

_i.e._ ![y =  \\frac {4.20}  4 - \\frac 2 4 x  ~~~~~~~~~~~~~ {\\rm and}   ~~~~~~~~~~~y =  6.30 - 4 x](//upload.wikimedia.org/math/9/a/8/9a83182b713f384c14e8d60841dbc0ee.png)

If you plot these equations they will be simultaneously true at ![ x=1.5](//upload.wikimedia.org/math/d/c/c/dcc7caccedd8909efec869195b0a1a14.png) and ![y = 0.30](//upload.wikimedia.org/math/f/a/b/fab76d7ba239c35e57d4fd7de512334b.png).

Notice that if the two rounds of drinks are 2 pints and 2 packets of crisps and 3 pints and 3 packets of crisps we cannot solve for the prices! This corresponds to two parallel straight lines which never intersect.

If we have the equations:

![3 x + 4 y = 4](//upload.wikimedia.org/math/3/9/5/39594c36ff67961a122de674c80355dc.png)

![3 x + 2 y = 1](//upload.wikimedia.org/math/3/3/8/338cab353b15f3f43e51b15c23c22f5f.png)

If these are simultaneously true we can find a _unique_ solution for both ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png).

By subtracting the 2 equations a new equation is created where ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) has disappeared and the system is solved.

![2y = 3](//upload.wikimedia.org/math/8/8/f/88f71b7cdb10ff2470045052c8dd6d75.png)

Substituting back ![y = 1.5](//upload.wikimedia.org/math/5/2/6/526dfb6b89edf14b24a77f35783270dd.png) gives us ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png).

This was especially easy because ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) had the same coefficient in both equations. We can always multiply one equation throughout by a constant to make the coefficients the same.

If the equations were:

![3x + 4y = 4](//upload.wikimedia.org/math/3/9/5/39594c36ff67961a122de674c80355dc.png)

and

![6x + 8y = 8](//upload.wikimedia.org/math/3/3/6/3365a8c8d85543cedd34c9d09fc34bd9.png)

things would go horribly wrong when you tried to solve them because they are two copies of the same equation and therefore not _simultaneous_. We will come to this later, but in the meantime notice that 3 times 8 = 4 times 6. If our equations were:

![3 x + 4 y + 9 z = 4](//upload.wikimedia.org/math/7/a/6/7a6e84490aeaa604d250b45d273bb2f3.png)

![3 x + 2 y - 4 z  = 1](//upload.wikimedia.org/math/5/3/c/53ce102e5ca127b0e3f9046b1a500cb2.png)

![9 x + 2 y - 2 z  = 1](//upload.wikimedia.org/math/3/2/6/3268dacc5d57f479eedcc57517d92ef7.png)

we can still solve them but would require a lot of algebra to reduce it to three (2x2) problems which we know we can solve. This leads on to the subject of matrices and determinants.

Simultaneous equations have applications throughout the physical sciences and range in size from (2x2)s to sets of equations over 1 million by 1 million.

## Practice simultaneous equations[[edit](/w/index.php?title=Mathematics_for_Chemistry/Matrices_and_Determinants&action=edit&section=T-2)]

Solve:

![x - 2y = 1](//upload.wikimedia.org/math/0/0/1/0011b1240b10e4ff063c5ed826bf4ffe.png)

![x + 4y = 8](//upload.wikimedia.org/math/a/b/0/ab0a01d8c402aab731481e427f8ee062.png)

and

![x + 5y = 10](//upload.wikimedia.org/math/e/e/4/ee4a87b72af4a92aaae65d3c4d76f287.png)

![7x - 4y =10](//upload.wikimedia.org/math/a/3/c/a3c63abb14a0b7e95e8de664bd65f4a5.png)

Notice that you can solve:

![3 x + 4 y + 9 z = 4](//upload.wikimedia.org/math/7/a/6/7a6e84490aeaa604d250b45d273bb2f3.png)

![3 x + 2 y - 4 z  = 1](//upload.wikimedia.org/math/5/3/c/53ce102e5ca127b0e3f9046b1a500cb2.png)

![0 x + 0 y - 2 z  = 1](//upload.wikimedia.org/math/8/2/b/82b44768719470871e0da8f4cf05d85a.png)

because it breaks down into a (2x2) and is not truly a (3x3). (In the case of the benzene molecular orbitals, which are (6x6), this same scheme applies. It becomes two direct solutions and two (2x2) problems which can be solved as above.)

## Matrices[[edit](/w/index.php?title=Mathematics_for_Chemistry/Matrices_and_Determinants&action=edit&section=T-3)]

The multiplication of matrices has been explained in the lecture.

![A = \\begin{pmatrix}0 & 1 & 2\\\\ 0 & -1 & -2\\\\ \\end{pmatrix}
~~~~~~~~B = \\begin{pmatrix}3 & -3\\\\ 4 & -4\\\\ 5 & -5\\\\ \\end{pmatrix}
~~~~~~~~~~AB = \\begin{pmatrix}14 & -14\\\\ -14 & 14\\\\ \\end{pmatrix}](//upload.wikimedia.org/math/f/7/7/f77cb9c8ff3f11065eac7b670b2fb6cf.png)

![BA = \\begin{pmatrix}0 & 6 & 12\\\\ 0 & 8 & 16\\\\ 0 & 10 & 20\\\\ \\end{pmatrix}](//upload.wikimedia.org/math/e/9/7/e973be780d30213864cced2e293e5e7b.png)

![{\\rm if} A = \\begin{pmatrix}1 &  2 & 3\\\\ \\end{pmatrix}  ~~~~~~~
{\\rm and} ~~~~~   B = \\begin{pmatrix} 4 & 5\\\\ 6 & 7\\\\ 8 & 9\\\\ \\end{pmatrix}  ~~~~~~~
AB = \\begin{pmatrix}40 & 60\\\\ \\end{pmatrix}](//upload.wikimedia.org/math/6/b/e/6be3be648af76ddd3fde39055092e106.png)

but ![BA](//upload.wikimedia.org/math/5/f/c/5fc810cf62601df84b7923b9964c53e6.png) cannot exist. To be multiplied two matrices must have the 1st matrix with the same number of elements in a row as the 2nd matrix has elements in its columns.

![a_{ij} = \\Sigma_k a_{ik} b_{kj}](//upload.wikimedia.org/math/2/e/8/2e8495249ce52b0eccda2aa82b2deec8.png)

where the ![a_{ij}](//upload.wikimedia.org/math/5/f/e/5fe0de05a0584639c658a0815efccce9.png)s are the elements of ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png).

![\\begin{pmatrix} a_{11} & a_{12} & a_{13}\\\\ a_{21} & a_{22} & a_{23}\\\\ a_{31} & a_{32} & a_{33}\\\\ \\end{pmatrix}](//upload.wikimedia.org/math/f/5/1/f51c29a403a7c6475a9a5c93d1394023.png)

Look at our picture of ![\\cos](//upload.wikimedia.org/math/1/f/1/1f141abfb260b11b18ca7ace446d349f.png) and ![\\sin](//upload.wikimedia.org/math/8/8/2/88265cd42f61bdf16ef2bd9fada9d5cd.png) as represented by a unit vector in a circle. The rotation of the unit vector ![{\\hat j}](//upload.wikimedia.org/math/a/7/1/a7196bf83d4c0811e6df4358969b72ab.png) about the ![z](//upload.wikimedia.org/math/f/b/a/fbade9e36a3f36d3d676c1b808451dd7.png)-axis can be represented by the following mathematical construct.

![\\begin{pmatrix}
\\cos \(\\theta\) & \\sin \(\\theta\) & 0   \\\\
-\\sin \(\\theta\) & \\cos \(\\theta\) & 0   \\\\
0 & 0 & 1   \\\\
\\end{pmatrix}](//upload.wikimedia.org/math/9/1/3/91388659ad66656dd5f3e83cf61e6623.png)

![\\begin{pmatrix}
0   \\\\
1   \\\\
0   \\\\
\\end{pmatrix} = \\begin{pmatrix}
\\sin \(\\theta\)    \\\\
\\cos \(\\theta\)   \\\\
0   \\\\
\\end{pmatrix}](//upload.wikimedia.org/math/c/3/9/c39da7ea96bea155613d46cf00f15d58.png)

In two dimensions we will rotate the vector at 45 degrees between ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png):

![\\begin{pmatrix}
\\cos \(\\theta\) & \\sin \(\\theta\)    \\\\
-\\sin \(\\theta\) & \\cos \(\\theta\)   \\\\
\\end{pmatrix}
\\begin{pmatrix}
\\frac r {\\sqrt 2}   \\\\
\\frac r {\\sqrt 2}   \\\\
\\end{pmatrix} = \\begin{pmatrix}
\\frac {r \\cos \\theta} {\\sqrt 2} + \\frac {r \\sin \\theta} {\\sqrt 2}  \\\\
\\frac {-r \\sin \\theta} {\\sqrt 2} + \\frac {r \\cos \\theta} {\\sqrt 2}  \\\\
\\end{pmatrix} = \\begin{pmatrix}
r   \\\\
0   \\\\
\\end{pmatrix}](//upload.wikimedia.org/math/2/8/4/28493c54063598ad1780f27e64ebec83.png)

This is if we rotate by +45 degrees. For ![\\theta = -45^o](//upload.wikimedia.org/math/2/1/1/21190827b0aee5a1cecb862671acea64.png) ![\\cos\(-45\) = \\cos 45](//upload.wikimedia.org/math/8/a/d/8ad98b72487476e206285053844f0a05.png) and ![\\sin\(-45\) = -\\sin 45](//upload.wikimedia.org/math/5/a/9/5a9e0f2279313eb7951480991d40cdb0.png). So the rotation flips over to give ![\( 0 1 \)](//upload.wikimedia.org/math/2/b/c/2bc7065217131e4fe8861cc8301271d9.png). The minus sign is necessary for the correct mathematics of rotation and is in the lower left element to give a right handed sense to the rotational sign convention.

As discussed earlier the solving of simultaneous equations is equivalent in some deeper sense to rotation in ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png)-dimensions.

## Matrix multiply practice[[edit](/w/index.php?title=Mathematics_for_Chemistry/Matrices_and_Determinants&action=edit&section=T-4)]

i) Multiply the following (2x2) matrices.

![
\\begin{pmatrix}
3& 5   \\\\
6 & 4   \\\\
\\end{pmatrix}
](//upload.wikimedia.org/math/3/7/1/3711c154e94fe5bd29f78c0cb154a29a.png) ![
\\begin{pmatrix}
1& 2   \\\\
3 & 4   \\\\
\\end{pmatrix}
](//upload.wikimedia.org/math/5/1/c/51c6c0a5ad5f104e92f2094f4db1a031.png) = ![
\\begin{pmatrix}
3 {\\rm x} 1 + 5 {\\rm x} 3& 3 {\\rm x} 2 + 5 {\\rm x} 4   \\\\
6 {\\rm x} 1 + 4 {\\rm x} 3 & 6 {\\rm x} 2 + 4 {\\rm x} 4   \\\\
\\end{pmatrix}
](//upload.wikimedia.org/math/b/a/d/bada8ee4176dd7d666be8bcbf88aa8c5.png)

ii) Multiply the following (3x3) matrices.

![
\\begin{pmatrix}
38.15 & -42.17& 4.02   \\\\
4.69 & 0.76 & -5.35   \\\\
-9.94 & 8.20 & 2.74   \\\\
\\end{pmatrix}
](//upload.wikimedia.org/math/1/b/1/1b1c09ab808ea5da56d25c6ab9b5d9a3.png) ![
\\begin{pmatrix}
0.205 & 0.665& 1   \\\\
0.181 & 0.647 & 1   \\\\
0.207 & 0.476 & 1   \\\\
\\end{pmatrix}
](//upload.wikimedia.org/math/7/7/7/777caedcf19c8cbc7b78bcf50de1b34e.png)

You will notice that this gives a _unit matrix_ as its product.

![
\\begin{pmatrix}
1 & 0 & 0   \\\\
0& 1 &0   \\\\
0& 0 &1   \\\\
\\end{pmatrix}
](//upload.wikimedia.org/math/b/7/9/b79950c11d4d1b6132aa442fd5ce6ed4.png)

The first matrix is the _inverse_ of the 2nd. Computers use the inverse of a matrix to solve simultaneous equations.

  
If we have ![
\\begin{pmatrix}
y_1 = a_{11} x_1 + a_{12} x_2 + a_{13} x_3 .....  + a_{1n} x_n  \\\\
y_2 = a_{21} x_2 + a_{22} x_2 + a_{23} x_3 .....  + a_{2n} x_n  \\\\
.....  \\\\
.....  \\\\
y_n = a_{n1} x_n + a_{n2} x_n + a_{n3} x_3 .....  + a_{nn} x_n\\\\
\\end{pmatrix}
](//upload.wikimedia.org/math/e/e/c/eec469c9f983b1a5e854de00c39105ec.png)

  
In matrix form this is....

![
Y = AX
](//upload.wikimedia.org/math/b/2/1/b21a1abe658fc87092f0b8b2a0dfa0ac.png)

![
A^{-1}Y=X
](//upload.wikimedia.org/math/9/7/8/97805c7617902dc78737232a08e64683.png)

In terms of work this is equivalent to the elimination method you have already employed for small equations but can be performed by computers for ![10~000](//upload.wikimedia.org/math/1/9/b/19b19f5c15ce893a36ed2ecb0afad44f.png) simultaneous equations.

(Examples of large systems of equations are the fitting of reference data to 200 references molecules, dimension 200, or the calculation of the quantum mechanical gradient of the energy where there is an equation for every way of exciting 1 electron from an occupied orbital to an excited, (called _virtual_, orbital, (typically ![10~000](//upload.wikimedia.org/math/1/9/b/19b19f5c15ce893a36ed2ecb0afad44f.png) equations.)

## Finding the inverse[[edit](/w/index.php?title=Mathematics_for_Chemistry/Matrices_and_Determinants&action=edit&section=T-5)]

How do you find the inverse... You use Maple or Matlab on your PC but if the matrix is small you can use the formula...

![A^{-1} = \\frac 1 {Det A} Adj A](//upload.wikimedia.org/math/d/2/3/d23c2dac50948ee7860e235588336c83.png)

Here Adj A is the adjoint matrix, the transposed matrix of cofactors. These strange objects are best described by example.....

![\\begin{vmatrix}
1 & -1 & 2  \\\\
2 & 1 & 1  \\\\
3 & -1 & 1  \\\\
\\end{vmatrix}](//upload.wikimedia.org/math/1/c/e/1ce1d3e0f20ef489f0a64b04844ea35f.png)

This determinant is equal to: 1 ( 1 x 1 - 1 x (-1)) - (-1) ( 2 x 1 - 1 x 3) + 2 ( 2 x (-1) - ( 1 x 3) each of these terms is called a _cofactor_.

![\\begin{vmatrix}
a_{11}  & a_{12}  & a_{13}   \\\\
a_{21}  & a_{22}  & a_{23}   \\\\
a_{31}  & a_{32}  & a_{33} \\\\
\\end{vmatrix}](//upload.wikimedia.org/math/d/1/6/d16aa806a37e2e92716c9ae96526c611.png)

  


![ Det A =  -1^{i+j-1} \\begin{pmatrix} a_{11} \( a_{22}   a_{33} - a_{23}   a_{32} \) \\\\ 
 +  -1^{i+j-1} a_{12} \( a_{21}   a_{33} - a_{23}   a_{31} \) \\\\ 
 +  -1^{i+j-1} a_{13} \( a_{21}   a_{32} - a_{22}   a_{31} \) \\\\
\\end{pmatrix}](//upload.wikimedia.org/math/e/2/a/e2a2a46b2bf9494cea1f7966860eee18.png)

This ![ -1^{i+j-1}](//upload.wikimedia.org/math/7/b/a/7ba416956f98436b80a91ac9d19cf4e4.png) thing gives the sign alternation in a form mathematicians like even though it is incomprehensible.

Use the determinant

![\\begin{vmatrix}
1 & -1 & 2  \\\\
2 & 1 & 1  \\\\
3 & -1 & 1  \\\\
\\end{vmatrix}](//upload.wikimedia.org/math/1/c/e/1ce1d3e0f20ef489f0a64b04844ea35f.png)

to solve the simultaneous equations on page 47 by the matrix inverse method. The matrix corresponding to the equations on p47.2 is:
    
    
    
         1      -1      2                 6
    
         2       1      1          =      3
    
         3      -1      1                 6
    
    
    The cofactors are
    
         2       1     -5
    
        -1      -5     -2
    
        -3       3      3
    
    
    You may find these 9 copies of the matrix useful for
    striking out rows and columns to form this inverse....
    
        1    -1    2      1    -1    2        1    -1    2
        2     1    1      2     1    1        2     1    1
        3    -1    1      3    -1    1        3    -1    1
    
    
    
        1    -1    2      1    -1    2        1    -1    2
        2     1    1      2     1    1        2     1    1
        3    -1    1      3    -1    1        3    -1    1
    
    
    
        1    -1    2      1    -1    2        1    -1    2
        2     1    1      2     1    1        2     1    1
        3    -1    1      3    -1    1        3    -1    1
    
    
     These are the little determinants with the -1 to the (n-1) factors
     and the value of the determinant is -9.
    
    The transposed matrix of cofactors is
    
         2      -1     -3
    
         1      -5      3
    
        -5      -2      3
    
    So the inverse is
    
    
                     2      -1     -3
    
        -1/9  X      1      -5      3
    
                    -5      -2      3
    
    Giving a solution
    
    
                   2      -1     -3         6          1
    
      -1/9  X      1      -5      3    X    3     =   -1
    
                  -5      -2      3         6          2
    
    

This takes a long time to get all the signs right. Elimination by subtracting equations is MUCH easier. However as the computer cannot make sign mistakes it is not a problem when done by computer program.

The following determinant corresponds to an equation which is repeated three times giving an unsolvable set of simultaneous equations.

![\\begin{vmatrix}
1 & 2 & 3  \\\\
-1 & -2 & -3  \\\\
2 & 4 & 6  \\\\
\\end{vmatrix}](//upload.wikimedia.org/math/1/9/8/1982d7f2c80b03c1580e3eb2d4d93981.png)

Matrix multiplication is not necessarily commutative, which in English means ![AB](//upload.wikimedia.org/math/b/8/6/b86fc6b051f63d73de262d4c34e3a0a9.png) does not equal ![BA](//upload.wikimedia.org/math/5/f/c/5fc810cf62601df84b7923b9964c53e6.png) all the time. Multiplication may not even be possible in the case of rectangular rather than square matrices.

I will put a list of the properties and definitions of matrices in an appendix for reference through the later years of the course.

## Determinants and the Eigenvalue problem[[edit](/w/index.php?title=Mathematics_for_Chemistry/Matrices_and_Determinants&action=edit&section=T-6)]

In 2nd year quantum chemistry you will come across this object: ![\\begin{vmatrix}
\\alpha - E &  \\beta  & 0 & 0  \\\\
\\beta & \\alpha -E & \\beta  &  0  \\\\
0 & \\beta & \\alpha -E & \\beta    \\\\
0 & 0 & \\beta & \\alpha -E    \\\\
\\end{vmatrix}
= 0](//upload.wikimedia.org/math/7/c/f/7cfa969699631a8ff74ac90aeea56698.png)

You divide by ![\\beta](//upload.wikimedia.org/math/0/7/1/071997f13634882f823041b057f90923.png) and set ![\(\\alpha - E \) / \\beta](//upload.wikimedia.org/math/8/9/c/89c798f7f0dde3db11f5d632a92e5b13.png) to equal ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) to get:

![\\begin{vmatrix}
x & 1  & 0 & 0  \\\\
1 & x & 1  &  0  \\\\
0 & 1 & x & 1    \\\\
0 & 0 & 1 & x    \\\\
\\end{vmatrix}
= 0](//upload.wikimedia.org/math/9/6/3/96319151ca12033337a268acc457a74b.png)

Expand this out and factorise it into two quadratic equations to give:

![\(x^2 +x -1\)\(x^2-x-1\)= 0](//upload.wikimedia.org/math/f/3/f/f3f4cfd31f586cf54dd5dd7ed0e4e832.png)

which can be solved using ![x = -b \\pm etc.](//upload.wikimedia.org/math/4/d/f/4df3ca51486b16945625213fb2d269c8.png)

### Simultaneous equations as linear algebra[[edit](/w/index.php?title=Mathematics_for_Chemistry/Matrices_and_Determinants&action=edit&section=T-7)]

The above determinant is a special case of simultaneous equations which occurs all the time in chemistry, physics and engineering which looks like this:

![\\begin{pmatrix}
 \( a_{11} - \\lambda \) x_1 + a_{12} x_2 + a_{13} x_3 .....  + a_{1n} x_n = 0   \\\\
 a_{21} x_2 + \( a_{22} - \\lambda \) x_1 + a_{23} x_3 .....  + a_{2n} x_n = 0   \\\\
.....  \\\\
.....  \\\\
 a_{1n} x_n + a_{2n} x_n + a_{n3} x_3 .....  +  \( a_{11} - \\lambda \) x_1 = 0\\\\
\\end{pmatrix}](//upload.wikimedia.org/math/c/4/6/c46bc071f57adbefd2082a1dd8f295ba.png)

This equation in matrix form is ![\({\\mathbf  A} - \\lambda {\\mathbf 1}\) {\\mathbf x} = 0](//upload.wikimedia.org/math/e/f/a/efa033f7588fdb11c34e528fb82d1d93.png) and the solution is ![{\\rm Det }\({\\mathbf A} - \\lambda {\\mathbf 1}\) = 0](//upload.wikimedia.org/math/8/6/d/86d65acd9fda172a9aab9d52af7b5a17.png).

This is a _polynomial equation_ like the quartic above. As you know polynomial equations have as many solutions as the highest power of ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) _i.e._ in this case ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png). These solutions can be _degenerate_ for example the ![\\pi](//upload.wikimedia.org/math/5/2/2/522359592d78569a9eac16498aa7a087.png) orbitals in benzene are a degenerate pair because of the factorisation of the ![x^6](//upload.wikimedia.org/math/0/e/9/0e98bfd9a5b4f7bba1f6327f372a2822.png) polynomial from the 6 Carbon-pz orbitals. In the 2nd year you may do a lab exercise where you make the benzene determinant and see that the polynomial is

![\(x^2-4\) \(x^2-1\) \(x^2-1\) = 0](//upload.wikimedia.org/math/a/6/9/a69785f10d6f0cdae7c1837fba029733.png)

from which the 6 solutions and the orbital picture are immediately obvious.

The use of matrix equations to solve arbitrarily large problems leads to a field of mathematics called _linear algebra_.

## Matrices with complex numbers in them[[edit](/w/index.php?title=Mathematics_for_Chemistry/Matrices_and_Determinants&action=edit&section=T-8)]

Work out the quadratic equation from the 3 determinants

![\\begin{vmatrix}
x & i    \\\\
-i & x   \\\\
\\end{vmatrix}
~~~~~~~
\\begin{vmatrix}
x & 1    \\\\
1 & x   \\\\
\\end{vmatrix}
~~~~~~~
\\begin{vmatrix}
x & \\frac 1 {\\sqrt 2} + \\frac i {\\sqrt 2}    \\\\
 \\frac 1 {\\sqrt 2} - \\frac i {\\sqrt 2} & x    \\\\
\\end{vmatrix}](//upload.wikimedia.org/math/0/c/0/0c00e405fdb8abed7ac085899578e12c.png)

They are all the same! This exemplifies a deeper property of matrices which we will ignore for now other than to say that complex numbers allow you to calculate the same thing in different ways as well as being the _only_ neat way to formulate some problems.

# Differentiation[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=12)]

  1. ==Free web-based material from HEFCE==

There is a DVD on differentiation at [Math Tutor](http://www.mathtutor.ac.uk/viewdisksinfo.php?disk=6).

## The basic polynomial[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-2)]

The most basic kind of differentiation is:

![f \(x\) = x^n](//upload.wikimedia.org/math/3/8/3/383f350ad0b7e0938d3872273ddf07ab.png)

![f^{'} \(x\) = n x^{n-1}](//upload.wikimedia.org/math/b/c/0/bc04688c8fc94001a7ba02a244ea695e.png)

There are two simple rules:

  1. The derivative of a function times a constant is just the same constant times the derivative.
  2. The derivative of a sum of functions is just the sum of the two derivatives.

To get higher derivatives such as the _second derivative_ keep applying the same rules.

One of the big uses of differentiation is to find the stationary points of functions, the maxima and minima. If the function is smooth, (unlike a saw-tooth), these are easily located by solving equations where the first derivative is zero.

## The chain rule[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-3)]

![\\frac {dy} {dx}  = \\frac {dy} {dw} . \\frac {dw} {dx}](//upload.wikimedia.org/math/e/9/5/e954aae9d906fde9a76182912adfe38d.png)

This is best illustrated by example: find ![\\frac {dy} {dx}](//upload.wikimedia.org/math/e/f/a/efaf9f3a22dad4658696b0ea9c0c7139.png) given ![y = { \(x^4 + 1\)}^9](//upload.wikimedia.org/math/e/3/8/e3857a14e3831e2c3223ee0068fb7dc6.png)

Let ![y = u^9](//upload.wikimedia.org/math/c/3/7/c377a76c9588b3f8734d48daf5863360.png) and ![u = x^4 + 1](//upload.wikimedia.org/math/f/f/3/ff31f1c4925a9cdab2bd686f9aeb7add.png).

Now ![\\frac {dy} {du} = 9 u^8](//upload.wikimedia.org/math/0/6/a/06a60a3159f57aff8696c8356adb8e49.png) and ![\\frac {du} {dx} = 4 x^3](//upload.wikimedia.org/math/6/a/5/6a511ea9903b521f3a1f90082137018c.png)

So using the chain rule we have ![9 { \(x^4 + 1\)}^8 .4 x^3 = 36 x^3 { \(x^4 + 1\)}^8](//upload.wikimedia.org/math/4/3/6/4362143a33f644eeb7f032ced89404ca.png)

  


## Differentiating a product[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-4)]

![\\frac {d\(u.v\)} {dx}  = v \\frac {du} {dx} + u \\frac {dv} {dx}](//upload.wikimedia.org/math/a/7/c/a7caa9ec3203b126be629216d997dbb8.png)

Notice when differentiating a product one generates two _terms_. (Terms are mathematical expression connected by a plus or minus.) An important point is that terms which represent physical quantities must have the same units and dimensions or must be pure dimensionless numbers. You cannot add 3 oranges to 2 pears to get 5 orangopears. Integration by parts also generates an extra term each time it is applied.

## Differentiating a quotient[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-5)]

You use this to differentiate ![\\tan](//upload.wikimedia.org/math/e/d/2/ed23bd70400679f30d3b078558556b74.png).

![ \\frac {d} {dx}  \\left\( \\frac {u} {v}  \\right\) = \\frac {  v \\frac {du} {dx}  - u \\frac {dv} {dx} } {v^2} ](//upload.wikimedia.org/math/8/b/5/8b52529cada5e942043a6468ff54acc8.png)

### Problems[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-6)]

Differentiate with respect to ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png)

![ 3 x^2 - x \( 1 + x\) \(1-x\) ](//upload.wikimedia.org/math/f/7/2/f7296a8a24d5ed392e249c7a4b0114db.png)

Notice we have ![\(a^2-b^2\)](//upload.wikimedia.org/math/b/f/5/bf5b590f0dd99005ae620ca7db823317.png). ![ 4 x^7 -3 x^2 ](//upload.wikimedia.org/math/5/0/0/500c71cbf858c1de9b1688e482696aea.png)

![ {\( 3 x + 2 \)}2 + e^x ](//upload.wikimedia.org/math/8/5/e/85e04bf935bd9a9397b7ddd805736501.png)

![ 8 x^6 - 12 {\\sqrt x} ](//upload.wikimedia.org/math/a/4/8/a48cb96786c32d38c827c0a13f4b02e8.png)

![ x {\( x + 3\)}2 ](//upload.wikimedia.org/math/c/d/f/cdf7a6d34e1bb142161bc054c750b46a.png)

![ x^2 \( 3 x - \( 2 + x \) \(2 - x\) \) ](//upload.wikimedia.org/math/0/a/a/0aa5def7c8a66522d30f7f9571280ec5.png)

Evaluate the inner brackets first.

Evaluate

![\\frac {\\rm d} { {\\rm d} z} \\left\( e^{z} - \\frac {z^9} {18} - \\frac 3 {z^2} \\right\)](//upload.wikimedia.org/math/2/9/9/299169eb6e507d0c497863212d90f677.png)

![ \\frac {\\rm d} { {\\rm d} c} \\left\(  \\sqrt { c^5} \\right\) ](//upload.wikimedia.org/math/f/4/4/f442591c90a5fed30944afc60ec8a898.png)

![ \\frac {\\rm d} { {\\rm d} \\omega} \\left\( \\frac 1 {\\omega } - \\frac 1 {\\omega ^2} - \\frac 1 {\\omega ^3} \\right\) ](//upload.wikimedia.org/math/2/8/8/288b2a867f8b3434fbeaae23f09c8e47.png)

![ \\frac {\\rm d} { {\\rm d} \\phi} \\left\( e^\\phi - \\left\(  \\frac 1 {\\phi^2} + \\frac 3 2  \\phi ^ 2 \\right\) \\right\) ](//upload.wikimedia.org/math/0/c/7/0c79f4e6b08299d698c13694bf20b31f.png)

![ \\frac {\\rm d} { {\\rm d} r} \\left\( e^{5 r} - \\left\( \\frac a {r^3} + \\frac b {r^6} + \\frac c {r^9} \\right\) \\right\) ](//upload.wikimedia.org/math/b/c/1/bc136c0ada3d48c83dca7a7782e10499.png)

a, b and c are constants. Differentiate with respect to ![r](//upload.wikimedia.org/math/4/b/4/4b43b0aee35624cd95b910189b3dc231.png).

![ 3 r e^{-3r} ](//upload.wikimedia.org/math/0/6/4/0645efe1297183867b5a1ba594c762d2.png)

![ \\frac {\\rm d} { {\\rm d} x} \\left\(  x ^6 e^{x} \\right\) ](//upload.wikimedia.org/math/4/e/7/4e7270b2057d6157c918d32c541e428f.png)

### Answers[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-7)]

![ 3x^2 + 6x -1 ](//upload.wikimedia.org/math/0/1/0/0106b2bac7ae41c2782520afb93d0756.png)

![ 28x^6 -6x ](//upload.wikimedia.org/math/d/7/f/d7fc971fed380620599014bfe92cea38.png)

![ e^x + 18x + 12 ](//upload.wikimedia.org/math/7/0/f/70f5fd3a9fd6ea38cb69bc56748077bb.png)

![ 48x^5 - \\frac 6 {\\sqrt x} ](//upload.wikimedia.org/math/4/d/7/4d735bb0aaf9531e6f6d7c4a58c773ae.png)

![ 3x^2 + 12x + 9 ](//upload.wikimedia.org/math/8/2/6/826fb1c3b4f3f7ef32d43a4742127d31.png)

![ 4x^3 + 9x^2 - 8x ](//upload.wikimedia.org/math/b/6/7/b67ea406fa2c8a4d4e7b147f3f3e4860.png)

![ e^z + \\frac{z^8}{2} + \\frac{6}{z^3} ](//upload.wikimedia.org/math/b/8/f/b8f202c642f27c65f359a804ce6b7dc6.png)

![ \\frac 5 2 c ^{3/2} {\\rm or} \\frac 5 2 {\\sqrt {c^3}} ](//upload.wikimedia.org/math/8/2/a/82ad146229f3d1edcc6f057d597f463e.png)

![ - \\frac{1}{\\omega ^2} + \\frac 2 {\\omega ^3} + \\frac 3 {\\omega ^4}](//upload.wikimedia.org/math/1/b/1/1b148c4ca68a5b15ec863e968d7d72d8.png)

![e^\\phi + \\frac 2 {\\phi^3} - 3 \\phi](//upload.wikimedia.org/math/6/a/4/6a4e05bfc14c6577c44369fe43bfcc91.png)

![5 e^{5 r} + \\frac {3 a} {r^4} + \\frac {6 b} {r^7} + \\frac {9 c} {r^{10}}](//upload.wikimedia.org/math/6/7/d/67deb1a2890dd78ab94d971774268bf3.png)

![e^{-3r} \( 3 - 9 r\)](//upload.wikimedia.org/math/2/6/1/2611035ea60724f905860cde0f35e8c4.png)

![x^5 e^x \(x+6\)](//upload.wikimedia.org/math/4/c/b/4cb4d923c210e2ca7e4f4d96a98f3d37.png)

### Harder differentiation problems[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-8)]

Differentiate with respect to ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png):

![x^4 {\( x+9\)}^5](//upload.wikimedia.org/math/8/7/f/87f32b525048686c14d5c958cbd16aa0.png)

![5 x^2 {\( x^2 -7x +9\)}^5](//upload.wikimedia.org/math/1/9/f/19f30d0bb805d0c5e0d45a85e6471363.png)

Differentiate with respect to ![r](//upload.wikimedia.org/math/4/b/4/4b43b0aee35624cd95b910189b3dc231.png)

![{\( r^2 + 3r -1\)}^3 e^{-4r}](//upload.wikimedia.org/math/a/9/7/a97cbbe0b32d6eb59779d3a54f7d6ff4.png)

Differentiate with respect to ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png)

![\\frac {1} { {\\omega}^4} \\left\( { {\\omega}^2 -3 \\omega -19} \\right\)](//upload.wikimedia.org/math/1/4/c/14cfa0ecf5cf17e58c54ebc84419eab1.png)

![\\frac {e^{\\omega}} { {\\omega}^4}](//upload.wikimedia.org/math/6/6/d/66deff366d2592c80ec112556fc10eec.png)

Evaluate

![\\frac { {\\rm d} } { {\\rm d} z} \\left\( e^{-4z} \\left\( {z-1}^2 \\right\) \\right\)](//upload.wikimedia.org/math/d/a/3/da30558335cfcc4c73b78090c1d275ce.png)

![\\frac { {\\rm d} } { {\\rm d} \\phi} \\left\( \\phi ^2 e^{-2\\phi} \\left\( 1 - \\frac 1 {{\\phi}^2}  \\right\) \\right\)](//upload.wikimedia.org/math/4/b/a/4ba38f24d9e79855c342138d2129f52a.png)

## Using differentiation to check turning points[[edit](/w/index.php?title=Mathematics_for_Chemistry/Differentiation&action=edit&section=T-9)]

![\\frac{dy}{dx}](//upload.wikimedia.org/math/e/f/a/efaf9f3a22dad4658696b0ea9c0c7139.png) is the tangent or gradient. At a minimum ![\\frac{dy}{dx}](//upload.wikimedia.org/math/e/f/a/efaf9f3a22dad4658696b0ea9c0c7139.png) is zero. This is also true at a maximum or an [inflection point](//en.wikipedia.org/wiki/en:Inflection_point). The _second gradient_ gives us the nature of the point. If ![\\frac{d^2y}{dx^2}](//upload.wikimedia.org/math/4/a/7/4a7f0c3a47a7b32fea2d729e374758a5.png) is positive the turning point is a minimum and if it is negative a maximum. Most of the time we are interested in minima except in _transition state theory_.

If the equation of ![ y = x^3](//upload.wikimedia.org/math/d/0/3/d0360b65da395195302d76bd4a7267bc.png) is plotted, is is possible to see that at ![x = 0](//upload.wikimedia.org/math/e/1/1/e11729b0b65ecade3fc272548a3883fc.png) there is a third kind of point, an inflection point, where both ![\\frac{dy}{dx}](//upload.wikimedia.org/math/e/f/a/efaf9f3a22dad4658696b0ea9c0c7139.png) and ![\\frac {d^2y} {dx^2}](//upload.wikimedia.org/math/4/a/7/4a7f0c3a47a7b32fea2d729e374758a5.png) are zero.

![ y = f\(x\) \\frac{dy}{dx} = f^{'}\(x\) \\frac{d^2y}{dx^2} = f^{''}\(x\)](//upload.wikimedia.org/math/e/e/2/ee29980be4b1c3b98ecb615b3cc5da0e.png)

Plot ![x^3+x^2-6x](//upload.wikimedia.org/math/d/1/6/d1693500f8f3cdc250392be4cb1dbe1f.png) between -4 and +3, in units of 1. (It will speed things up if you factorise it first. Then you will see there are 3 places where ![f\(x\)=0](//upload.wikimedia.org/math/f/d/0/fd05d8d90456c441c8f10641bd8576bc.png) so you only need calculate 5 points.) By factorising you can see that this equation has 3 roots. Find the 2 turning points. (Differentiate once and find the roots of the quadratic equation using ![x=-b\\dots](//upload.wikimedia.org/math/2/e/6/2e65efffa58876c7c4727b12be1d3cdc.png). This gives the position of the 2 turning points either side of zero. As the equation is only in ![x^3](//upload.wikimedia.org/math/c/d/8/cd81d846781f418f883642fab802ae4a.png) it has 3 roots and 2 maxima / minima at the most therefore we have solved everything. Differentiate your quadratic again to get ![\\frac{d^2y}{dx^2}](//upload.wikimedia.org/math/4/a/7/4a7f0c3a47a7b32fea2d729e374758a5.png). Notice that the turning point to the left of zero is a maximum _i.e._ ![\\frac{d^2y}{dx^2} = -ve](//upload.wikimedia.org/math/d/4/8/d48dcafefc5fd3030d9fad4616894317.png) and the other is a minimum _i.e._ ![\\frac{d^2y}{dx^2} = +ve](//upload.wikimedia.org/math/a/3/b/a3b36796c61933a36bda3283a3f6905c.png).

What is the solution and the turning point of ![y=x^3](//upload.wikimedia.org/math/d/0/3/d0360b65da395195302d76bd4a7267bc.png).

Solve ![x^3-x =  0](//upload.wikimedia.org/math/f/9/0/f906663f891f332b10fe78e7565e956d.png), by factorisation.

(The 3 roots are -3,0 and +2. ![\\frac {{\\rm d}y} { {\\rm d} x} = f^{'}\(x\) = 3x^2 + 2x-6](//upload.wikimedia.org/math/4/9/e/49e9994eb029509649e038e9e2428e23.png)

Solutions are ![1/3\(\\sqrt {19} -1\)](//upload.wikimedia.org/math/9/6/0/96090267b920223ad28aabd30eb39d39.png) and ![-1/3\(\\sqrt {19} +1\)](//upload.wikimedia.org/math/d/7/e/d7e2dbd78fd9de72f461dc91f676d21b.png), _i.e._ -1.7863 and 1.1196.

![\\frac{d^2y}{dx^2} = f^{''}\(x\)= 6x+2](//upload.wikimedia.org/math/9/6/8/968e77739bd35190bdd4e9c256e8f37b.png)

There are 3 coincident solutions at ![x=0](//upload.wikimedia.org/math/e/1/1/e11729b0b65ecade3fc272548a3883fc.png), ![\\frac{d^2y}{dx^2} = 0](//upload.wikimedia.org/math/d/1/0/d1065022a26cc4b6667d1881f21955f9.png), at 0 so this is an _inflection point_.

The roots are 0, 1 and -1.

# Integration[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=13)]

  1. ==Free Web Based Material from HEFCE==

There is a DVD on integration at [Math Tutor](http://www.mathtutor.ac.uk/viewdisksinfo.php?disk=7).

### The basic polynomial[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-2)]

![f \(x\) = x^n](//upload.wikimedia.org/math/3/8/3/383f350ad0b7e0938d3872273ddf07ab.png)

![\\int { f\(x\) }dx  = \\frac {x^{n+1}}{n+1} + c](//upload.wikimedia.org/math/6/a/5/6a5742dab409304db7efa02f9f3e99fb.png)

This works fine for all powers except -1, for instance the integral of

![\\frac {1} {x^7}](//upload.wikimedia.org/math/1/b/4/1b43adb13612ab7575725c14832d0580.png)

is just

![- \\frac {1} {6 x^6} + c](//upload.wikimedia.org/math/f/1/4/f145ad861676953b1a98ebec8a3ed7af.png)

-1 is clearly going to be a special case because it involves an infinity when ![x = 0](//upload.wikimedia.org/math/e/1/1/e11729b0b65ecade3fc272548a3883fc.png) and goes to a steep spike as ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) gets small. As you have learned earlier this integral is the [natural logarithm](//en.wikipedia.org/wiki/en:Natural_logarithm) of ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and the infinity exists because the _log_ of zero is minus infinity and that of negative numbers is undefined.

### The integration and differentiation of positive and negative powers[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-3)]
    
    
       >>>>>>>>>>>>>>>>>>>>>>Differentiation
    
       1/3 x*x*x  x*x       2x        2         0        0       0       0
    
       1/3 x*x*x  x*x       2x        2         ?        ?       ?       ?
    
       Integration<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
       I(x)        H(x)     G(x)      F(x)      ln(x)   1/x    -1/(x*x)
    

  
Here I, H, G and F are more complicated functions involving ![\\ln x](//upload.wikimedia.org/math/2/e/2/2e2d2bfd8d38a8371cedaa366a5c07ab.png).

You will be able to work them out easily when you have done more integration. The thing to notice is that the calculus of negative and positive powers is not symmetrical, essentially caused by the _pole_ or _singularity_ for ![\\frac 1 {x^n}](//upload.wikimedia.org/math/f/a/b/fabad288e5a373c37972e5007c14c53e.png) at ![x=0](//upload.wikimedia.org/math/e/1/1/e11729b0b65ecade3fc272548a3883fc.png).

## Logarithms[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-4)]

[Logarithms](//en.wikipedia.org/wiki/en:Logarithm) were invented by Napier, a Scottish Laird, in the 17th-century. He made many inventions but his most enduring came from the necessity of doing the many long divisions and trigonometric calculations used in astronomy. The Royal Navy in later years devoted great time and expense to developing logarithm technology for the purposes of navigation, leading to the commissioning of the first mechanical stored program computer, which was theoretically sound but could not be made by [Charles Babbage](//en.wikipedia.org/wiki/en:Charles_Babbage) between 1833 and 1871.

The heart of the system is the observation of the properties of powers:

![\\frac {e^a} {e^b} = e^{a-b}](//upload.wikimedia.org/math/4/2/9/429f851ba07c464b1ea592edbd36d83c.png)

This means that if we have the _inverse_ function of ![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png) we can change a long division into a subtraction by looking up the exponents in a set of tables. Before the advent of calculators this was the way many calculations were done.

![ y = e^x](//upload.wikimedia.org/math/4/4/7/447ce721b91100d103620dac5452b495.png)

![\\ln y = x](//upload.wikimedia.org/math/b/7/a/b7a167fd4c4ff741a492505b90138450.png)

Napier initially used logs to the base ![e](//upload.wikimedia.org/math/e/1/6/e1671797c52e15f763380b45e841ec32.png) for his calculations, but after a year or so he was visited by Briggs who suggested it would be more practical to use base 10. However base ![e](//upload.wikimedia.org/math/e/1/6/e1671797c52e15f763380b45e841ec32.png) is necessary for the purposes of calculus and thermodynamics.

## Integrating 1/x[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-5)]

![x = e^y~~~~~~~~~\\frac {{\\rm d} x}  { {\\rm d} y} = e^y~~~~~ {\\rm also} = x](//upload.wikimedia.org/math/e/3/7/e370292552a4735b32ffbbb3a6ecd74a.png)

This is true because ![e^y](//upload.wikimedia.org/math/2/b/c/2bc0199dc4f464c4a2342f2cea6ec15a.png) is our function which reduces or grows at the rate of its own quantity.

![y = \\ln x](//upload.wikimedia.org/math/c/0/f/c0fffc8747dc974e1f19eac7a4e8e212.png)

This is our definition of a logarithm.

![\\frac {{\\rm d} x}  { {\\rm d} y}  = \\frac 1 { \\frac {{\\rm d} y}  { {\\rm d} x}  } ~~~~~~ {\\rm also} = x](//upload.wikimedia.org/math/f/7/7/f77f80325c46307e93b3ba446384eef7.png)

therefore

![\\frac {{\\rm d} y}  { {\\rm d} x}  = \\frac 1 x](//upload.wikimedia.org/math/6/5/2/6523016afee0e97b338aa03d683b82ab.png)

![\\int {\\frac{dy}{dx}} dx = y](//upload.wikimedia.org/math/7/9/3/7937de42d8b3f4a004f3b2f4ad736fc5.png)

therefore

![\\int { \\frac{1}{x}} dx = \\ln x](//upload.wikimedia.org/math/2/0/6/206e0a350ca29ca5d525297eecf85de5.png)

## Integrating 1/x like things[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-6)]

Just as

![ \\frac { \\rm d}  {  {\\rm d} x}  \\ln x = \\frac 1 x ](//upload.wikimedia.org/math/6/5/7/657b83e0e9ba44d7e55cbc16a5ac0148.png)

so

![\\frac { \\rm d}  {  {\\rm d} x}  \\ln u = \\frac 1 u \\frac { { \\rm d} u}  {  {\\rm d} x}](//upload.wikimedia.org/math/1/5/2/1523c84e50f85fc51a65862cf31d2515.png)

therefore by the _chain rule_

![\\frac { { \\rm d}}  {  {\\rm d} x}  \\ln f\(x\) =  \\frac { f^{'} \(x\)}  {   f \(x\)}](//upload.wikimedia.org/math/4/a/3/4a3388e42e6262fcc5bc04d88eb8b603.png)

therefore

![\\int { \\frac { f^{'} \(x\)}  {   f \(x\)} } {\\rm d}x = \\ln | f \(x\) | + c](//upload.wikimedia.org/math/2/9/1/2911cef3ad7a2eef051cd730432c2a78.png)

Examples of this are:

![\\int { \\frac { \\cos \\phi}  {   1 + \\sin \\phi  } }  {\\rm d}\\phi = \\ln \(  1 + \\sin \\phi \) + c](//upload.wikimedia.org/math/f/6/3/f63d5cee908ad4f58d520896e0095d47.png)

or

![\\int { \\frac { \\sin \\phi}  {   1 + \\cos \\phi  } }  {\\rm d}\\phi = - \\ln \(  1 + \\cos \\phi \) + c](//upload.wikimedia.org/math/9/6/3/963a0f81baec0ac98114c9b2960991b4.png)

and

![\\int { \\frac { e^y}  {   e^y + 2  } }  {\\rm d}y = \\ln \(  e^y + 2 \) + c](//upload.wikimedia.org/math/a/3/4/a34cb1c80cabd0e34da901466eb1d2cd.png)

As the integral of ![1/x](//upload.wikimedia.org/math/6/1/b/61b98bb724d72e0b009c3f523c50cd82.png) is ![\\ln](//upload.wikimedia.org/math/3/c/1/3c178b05d8a108e6346e61420651bedf.png) so the differential of ![\\ln](//upload.wikimedia.org/math/3/c/1/3c178b05d8a108e6346e61420651bedf.png) is ![1/x](//upload.wikimedia.org/math/6/1/b/61b98bb724d72e0b009c3f523c50cd82.png) so

![\\frac { \\rm d}  {  {\\rm d} x} \\ln 5 x^3 = \\ln 5 + \\ln x^3 = \\ln 5 + 3 \\ln x](//upload.wikimedia.org/math/d/d/9/dd9df976a32b5b962ba51a125c85dbc9.png)

![\\ln 5 ](//upload.wikimedia.org/math/9/8/d/98d07bab9489568c62c0205153389d00.png) is just a constant so ![\\frac { \\rm d}  {  {\\rm d} x} = 0](//upload.wikimedia.org/math/2/7/0/27014d43a063dbab8d8510636c4fcf3b.png) so

![\\frac { \\rm d}  {  {\\rm d} x} \\ln 5 x^3 = \\frac 3 x](//upload.wikimedia.org/math/d/b/6/db663b26e92223ad0b7ced8a7b8b43ae.png)

This can also be done by the chain rule

![\\frac { \\rm d}  {  {\\rm d} x} \\ln 5 x^3 = \\frac 1 {5 x^3} .\\frac { { \\rm d}\(5x^3\) }  {  {\\rm d} x}= \\frac { 15x^2 }  {  5x^3 } = \\frac 3 x](//upload.wikimedia.org/math/2/1/6/2163b42cdc073664305a36a0bb0d870f.png)

What is interesting here is that the 5 has disappeared completely. The gradient of the log function is unaffected by a multiplier! This is a fundamental property of logs.

## Some observations on infinity[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-7)]

Obviously ![\\frac{1}{0}](//upload.wikimedia.org/math/1/f/b/1fb1a065bd0764d464c7527fc2ae816b.png) is ![\\infty](//upload.wikimedia.org/math/d/2/4/d245777abca64ece2d5d7ca0d19fddb6.png).

![\\frac 0 0](//upload.wikimedia.org/math/1/b/d/1bdaba5b88513d042a8b7674faa34e60.png)nd ![\\frac \\infty \\infty](//upload.wikimedia.org/math/5/2/9/529e66b8c0f524b44708f6f9b07b530c.png) are undefined but sometimes a large number over a large number can have defined values. An example is the ![\\sin](//upload.wikimedia.org/math/8/8/2/88265cd42f61bdf16ef2bd9fada9d5cd.png) of 90 degrees, which you will remember has a large opposite over a large hypotenuse but in the limit of an inifinitesmally thin triangle they become equal. Therefore the ![\\sin](//upload.wikimedia.org/math/8/8/2/88265cd42f61bdf16ef2bd9fada9d5cd.png) is 1.

## Definite integrals (limits)[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-8)]

Remember how we do a definite integral

![\\int_0^3 { \( f \(x\) \)}  = {\\left\[ F \(x\)  \\right\] }_0^3 =  F \(3\)  -  F \(0\)](//upload.wikimedia.org/math/6/2/a/62a6a98f8ccad10fec3adc78cab418ff.png)

where ![F](//upload.wikimedia.org/math/8/0/0/800618943025315f869e4e1f09471012.png) is the indefinite integral of ![f](//upload.wikimedia.org/math/8/f/a/8fa14cdd754f91cc6554c9e71929cce7.png).

Here is an example where limits are used to calculate the 3 areas cut out by a quartic equation:

![x^4 -2x^3-x^2+2x](//upload.wikimedia.org/math/5/4/4/5449424913bedb4a73b9c8585fafad81.png).

We see that ![x=1](//upload.wikimedia.org/math/a/2/5/a255512f9d61a6777bd5a304235bd26d.png) is a solution so we can do a polynomial division:

  

    
    
            x3  -x2 -2x
          -------------------
     x-1  ) x4 -2x3 -x2 +2x
            x4  -x3
           --------
                -x3 -x2
                -x3 +x2
                -------
                    -2x2 +2x
                    -2x2 +2x
                    --------
                         0
    

So the equation is ![x\(x^2-x-2\)\(x-1\)](//upload.wikimedia.org/math/7/9/3/793b4067a07eb8057effc864a2d48cc3.png) which factorises to

![x\(x-2\)\(x+1\)\(x-1\)](//upload.wikimedia.org/math/1/2/1/121242d6c88f65a3f38688a429c615ff.png).

![\\int_a^b { x^4 -2x^3-x^2+2x}  = {\\left\[ x^5/5 -x^4/2-x^3/3+ x^2\\right\] }_a^b](//upload.wikimedia.org/math/0/5/d/05d527dea211ea5e5ef7020ed4c65bcb.png)

## Integration by substitution[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-9)]

![\\int \\sin \\theta \\cos \\theta  {\\rm d} \\theta =\\int u \\frac  { {\\rm d}  u } { {\\rm d}  \\theta  } {\\rm d} \\theta](//upload.wikimedia.org/math/0/a/e/0aed3cb360550f302797604cdfcc60fb.png)

where ![ u = \\sin \\theta](//upload.wikimedia.org/math/8/4/3/8436ec5f9a3f9cdba98c2df711a61012.png).

![\\int \\sin \\theta \\cos \\theta  {\\rm d} \\theta =\\frac  { \\sin^2 \\theta } { 2  } + c](//upload.wikimedia.org/math/c/9/2/c92563aed9fbe08957364229c9bf8715.png)

![\\int \\sin^9 \\theta \\cos \\theta  {\\rm d} \\theta ~~~~~~~{\\rm similarly}~~~~~~~~ =\\frac  { \\sin^{10} \\theta } { 10  } + c](//upload.wikimedia.org/math/0/5/6/056aa316c1775129118d0041990c8aac.png)

## Simple integration of trigonometric and exponential Functions[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-10)]

![\\int { 4e^{2x}} dx](//upload.wikimedia.org/math/2/5/2/252f8412a883cd8e810ac78ca52387a9.png)

![\\int { -9e^{-3x}} dx](//upload.wikimedia.org/math/3/6/c/36cf122d60a8ee7ba4134a48fe206433.png)

![\\int { \\sin 2 \\theta } d \\theta](//upload.wikimedia.org/math/a/c/e/acec7dadd0bbfad9628ff218af730a1c.png)

![\\int { \\sin^2 \\theta + \\cos^2 \\theta } d \\theta](//upload.wikimedia.org/math/c/0/7/c070dd9e2a23fd8695189dd9538a2c6a.png)

![\\int {  -\\cos \\phi } d \\phi](//upload.wikimedia.org/math/c/f/9/cf9a84147da61e66edf0dc03871687ac.png)

### Answers[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-11)]

![2e^{2x} + c](//upload.wikimedia.org/math/e/e/2/ee27ffd019586f742be9ffa4b7e30c14.png)

![3e^{-3x} + c](//upload.wikimedia.org/math/6/b/4/6b45fed2c0ddff634b56fc612b6f3943.png)

![- \\frac 1 2 \\cos 2 \\theta + c](//upload.wikimedia.org/math/f/0/4/f04e9ef5271984c43b45e90b74f44de2.png)

![\\theta + c](//upload.wikimedia.org/math/6/8/1/681cb3844796eed2d769a2ceee004f61.png)

_i.e._ the integral of ![ 1 d \\theta](//upload.wikimedia.org/math/8/9/2/892faf341ecb8f7a75189c19a4e2290f.png).

![\\sin \\phi + c](//upload.wikimedia.org/math/1/8/2/1820f2e8cc8aca0dad366b7684c25bcf.png)

## Integration by parts[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-12)]

This is done in many textbooks and wikipedia. Their notation might be different to the one used here, which hopefully is the most clear. You derive the expression by taking the product rule and integrating it. You then make one of the ![UV^{'}](//upload.wikimedia.org/math/1/0/4/104519ac6db76fb192ea0d10775699b4.png) into a product itself to produce the expression.

![\\int {UV} = U \\int {V}  - \\int {\\left\( U^{'} \\int { V} \\right\) }](//upload.wikimedia.org/math/d/4/a/d4a23cc22d27af9506551335c92f2b91.png)

(all integration with respect to ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png). Remember by

![\\int {UV} = U \[ {\\rm int} \] - \\int { \[ {\\rm diff} \] \[ {\\rm int} \]  }](//upload.wikimedia.org/math/e/2/4/e2455a09fe2a45c3e2b91142abd21acc.png)

(![U](//upload.wikimedia.org/math/4/c/6/4c614360da93c0a041b22e537de151eb.png) gets differentiated.)

The important thing is that you have to integrate one expression of the product and differentiate the other. In the basic scheme you integrate the most complicated expression and differentiate the simplest. Each time you do this you generate a new _term_ but the function being differentiated goes to zero and the integral is solved. The expression which goes to zero is ![U](//upload.wikimedia.org/math/4/c/6/4c614360da93c0a041b22e537de151eb.png).

The other common scheme is where the parts formula generates the expression you want on the right of the equals and there are no other integral signs. Then you can rearrange the equation and the integral is solved. This is obviously very useful for trig functions where ![\\sin >> \\cos >> -\\sin >> -\\cos >> sin](//upload.wikimedia.org/math/8/e/9/8e98129a0867755296ba49f62bde7d82.png) _ad infinitum_.

![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png) also generates itself and is susceptible to the same treatment.

![\\int { e^{-x} \\sin x }~ dx = \( -e^{-x} \) \\sin x - \\int { \(-e^{-x}\) \\cos x} ~ dx](//upload.wikimedia.org/math/2/8/3/2831dbe33745926104d1819214f14d39.png)

![ =  -e^{-x}  \\sin x + \\int { e^{-x} \\cos x } ~ dx](//upload.wikimedia.org/math/c/c/0/cc00483e0720e88b7db4dd86684de8cb.png)

![ =  -e^{-x}  \(\\sin x +  \\cos x \) - \\int { e^{-x} \\sin x } ~ dx + c](//upload.wikimedia.org/math/f/d/5/fd57685925a5b109261bdb9bed4b2f0a.png)

We now have our required integral on both sides of the equation so

![= - \\frac 1 2 e^{-x} \( \\sin x + \\cos x \) + c](//upload.wikimedia.org/math/8/5/4/8545d87a1ee25d76d97805975434d42f.png)

## Integration Problems[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-13)]

Integrate the following by parts with respect to![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png).

![x e^x](//upload.wikimedia.org/math/6/2/7/627bf8a30ab0f60cf88c64166bab773d.png)

![x^2 \\sin x](//upload.wikimedia.org/math/9/f/a/9facb526b283b02ef478a9321bfa20fb.png)

![x \\cos x](//upload.wikimedia.org/math/7/8/e/78e9113552c9d84671f5103581c505d4.png)

![x^2  e^x](//upload.wikimedia.org/math/1/0/d/10dc028264f0d6652c195243890a75c8.png)

![x^2  \\ln x](//upload.wikimedia.org/math/b/c/6/bc6add18e6bba8e3782ec7ce4d7c31bb.png)

![e^{x} \\sin x](//upload.wikimedia.org/math/2/0/d/20dabb42ec4348a513f97463887e91c8.png)

![e^{2x} \\cos x](//upload.wikimedia.org/math/6/d/2/6d208821e5e7e47279678054d50aa161.png)

![x {\( 1 + x \)}^7](//upload.wikimedia.org/math/5/3/2/53216e6b95caada67b8ae9410268b5e3.png)

Actually this one can be done quite elegantly by parts, to give a two term expression. Work this one out. Expanding the original integrand by Pascal's Triangle gives:
    
    
             2       3       4       5       6      7    8
      x + 7 x  + 21 x  + 35 x  + 35 x  + 21 x  + 7 x  + x
    

  
The two term integral expands to
    
    
          2        3         4      5         6      7        8        9
     1/2 x  + 7/3 x  + 21/4 x  + 7 x  + 35/6 x  + 3 x  + 7/8 x  + 1/9 x  - 1/72
    

So one can see it is correct on a term by term basis.

![3 x \\sin x](//upload.wikimedia.org/math/1/d/2/1d2b13370d8f454bb5e6e1eb82338971.png)

![2 x^2  \\cos 2 x](//upload.wikimedia.org/math/3/0/0/300efd2a57fcc5d0dabc10b0333b861c.png)

If you integrate ![x^7 \\sin x](//upload.wikimedia.org/math/5/2/8/5287a35d40edcb3d655b23361dd47d69.png) you will have to apply _parts_ 7 times to get ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) to become 1 thereby generating 8 terms:
    
    
    
    
        7             6              5               4               3
      -x  cos(x) + 7 x  sin(x) + 42 x  cos(x) - 210 x  sin(x) - 840 x  cos(x) +
    
            2
      2520 x  sin(x) +  5040 x cos(x) - 5040 sin(x)  + c
    
    
    (Output from Maple.) 
    

Though it looks nasty there is quite a pattern to this, 7, 7x6,7x6x5 ------7! and sin, cos, -sin, -cos, sin, cos _etc_ so it can easily be done by hand.

## Differential equations[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-14)]

First order differential equations are covered in many textbooks. They are solved by integration. (First order equations have ![\\frac{dy}{dx}](//upload.wikimedia.org/math/e/f/a/efaf9f3a22dad4658696b0ea9c0c7139.png), second order equations have ![\\frac{dy}{dx}](//upload.wikimedia.org/math/e/f/a/efaf9f3a22dad4658696b0ea9c0c7139.png) and ![\\frac{d^2 y}{dx^2}](//upload.wikimedia.org/math/4/a/7/4a7f0c3a47a7b32fea2d729e374758a5.png).)

The arbitary constant means another piece of information is needed for complete solution, as with the Newton's Law of Cooling and Half Life examples.

Provided all the ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png)s can be got to one side and the ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png)s to another the equation is separable.

![ 2 y \\frac { {\\rm d} y }  { {\\rm d} x}  = 6x^2](//upload.wikimedia.org/math/f/6/1/f612be1fa8a00487dcb89964a70cbb79.png)

![\\int 2 y  {\\rm d} y  = \\int 6x^2 {\\rm d} x](//upload.wikimedia.org/math/6/1/2/61288abee9fa1d7fe54f25c7f8a55f3f.png)

![y^2 = 2x^3 + c](//upload.wikimedia.org/math/9/1/4/91490735ae7d11a0ca1c6e6dd630e7fc.png)

This is the _general solution_.

Typical examples are:

![y = x  \\frac { {\\rm d} y }  { {\\rm d} x} ~~~~~~~~~~~~~~~~~~~~~~~~~\\int \\frac { {\\rm d} y }  { y} = \\int \\frac { {\\rm d} x }  { x}](//upload.wikimedia.org/math/9/2/d/92d06da3c9d2122e15fa8c022702abac.png)

![\\ln y = \\ln x + \\ln A ~~~~~~\(constant\)~~~~ i.e.~~~~~ y = A x](//upload.wikimedia.org/math/f/5/e/f5e739f59a89421577c6d944ba1fbf7b.png)

by definition of logs.

![\\frac { {\\rm d} y }  { {\\rm d} x} = ky~~~~~~~~~~~~~~](//upload.wikimedia.org/math/0/5/e/05e0de98456212be5073195b58795485.png) (1)

![{\\rm k} x y = \\frac { {\\rm d} y }  { {\\rm d} x} ](//upload.wikimedia.org/math/8/6/4/86467112e178a866745e2e41ec287f67.png)

![ \\int {\\frac  {{\\rm d} y }  { y}  } = \\int  kx {\\rm d} x   ~~~~~~~~~~~~~~](//upload.wikimedia.org/math/d/b/9/db9977aa4ddf9ec2a2746c3822c2833c.png) (2)

![~~~~~~~~\\ln y = \\frac 1 2 kx^2 + A ~~~~~~~](//upload.wikimedia.org/math/3/0/8/3082ab92a0b5e9b40134fc5888e48e64.png) (3)

This corresponds to:

![y = B e ^{\\frac 1 2 kx^2 }](//upload.wikimedia.org/math/6/4/3/6431ba6710a8bfead49cd4b20bccbd30.png)

The Schrödinger equation is a 2nd order differential equation _e.g._ for the particle in a box

![ \\frac {\\hbar^2 } {2m} \\frac {{\\rm d}^2 \\Psi } { {\\rm d}x^2 }  + E \\Psi = 0](//upload.wikimedia.org/math/4/a/a/4aa8e2eb236e407b35f788044de0a664.png)

It has taken many decades of work to produce computationally efficient solutions of this equation for polyatomic molecules. Essentially one expands in coefficients of the _atomic orbitals_. Then integrates to make a differential equation a set of numbers, integrals, in a _matrix_. Matrix algebra then finishes the job and finds a solution by solving the resultant simultaneous equations.

## The calculus of trigonometric functions[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-15)]

There are many different ways of expressing the same thing in trig functions and very often successful integration depends on recognising a trig identity.

![\\int { \\sin 2x dx} = -\\frac 1 2 \\cos 2x + c](//upload.wikimedia.org/math/6/5/9/659e519f5261cb0f8c73810fd910a47c.png)

but could also be

![\\sin^2 x ~~{\\rm or} ~~ -\\cos^2 x](//upload.wikimedia.org/math/3/8/3/383b0973961d68d5e9af47d6ca17d7c0.png)

(each with an integration constant!).

When applying calculus to these functions it is neccessary to spot which is the simplest form for the current manipulation. For integration it often contains a product of a function with its derivative like ![2 \\sin x \\cos x](//upload.wikimedia.org/math/d/d/3/dd31f53909beb1bf616bb284db81093a.png) where integration by substitution is possible.

Where a derivative can be spotted on the numerator and its integral below we will get a ![\\ln](//upload.wikimedia.org/math/3/c/1/3c178b05d8a108e6346e61420651bedf.png) function. This is how we integrate ![tan](//upload.wikimedia.org/math/5/b/2/5b2d4484498235e80d61a233a7c04991.png).

![\\int { \\tan x dx} = \\int { \\frac {\\sin x} { \\cos x} } dx =- \\ln~ \( \\cos x \) + c](//upload.wikimedia.org/math/6/f/b/6fb01def72b0ec58e1f8fee8a335303a.png)

We can see this function goes to infinity at ![\\pi / 2](//upload.wikimedia.org/math/1/f/8/1f8b57e932cf2d585ed71af904be8638.png) as it should do.

## Integration by rearrangement[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-16)]

Take for example:

![\\int { \\cos^2 x dx}](//upload.wikimedia.org/math/4/3/0/430cbf7acacd99e83d257d2028870dcc.png)

Here there is no ![\\sin](//upload.wikimedia.org/math/8/8/2/88265cd42f61bdf16ef2bd9fada9d5cd.png) function producted in with the ![\\cos](//upload.wikimedia.org/math/1/f/1/1f141abfb260b11b18ca7ace446d349f.png) powers so we cannot use substitution. However there are the two trig identities

![\\cos^2 \\theta + \\sin^2 \\theta = 1](//upload.wikimedia.org/math/8/0/4/8044379582d6972f8bfc5e045dd65bac.png)

and

![\\cos^2 \\theta - \\sin^2 \\theta = \\cos 2 \\theta](//upload.wikimedia.org/math/e/0/e/e0ebd00cdcc031cfd0339b2e21d33dc2.png)

Using these we have

![\\int { \\cos^2 x dx}  = \\int { \\frac 1 2 { \(1 + \\cos 2 x \) } } dx](//upload.wikimedia.org/math/1/e/8/1e8a02469518b33e394b04b2ff425c58.png)

so we have two simple terms which we can integrate.

## The Maclaurin series[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-17)]

We begin by making the assumption that a function can be approximated by an infinite power series in ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png):

![f\(x\) = a_0 + a_1 x + a_2 x^2 + a_3 x^3 + a_4 x^4 + \\dots](//upload.wikimedia.org/math/5/0/4/504a853c1c5cc40e6bb142c1cc437423.png)

By differentiating and setting ![x = 0](//upload.wikimedia.org/math/e/1/1/e11729b0b65ecade3fc272548a3883fc.png) one gets

![f\(x\) = f\(0\)  + f^{'}\(0\) x + \\frac {f^{''}\(0\)} {2!} x^2 + \\frac {f^{'''}\(0\)} {3!} x^3 + \\frac {f^{''''}\(0\)} {4!} x^4 + \\ldots](//upload.wikimedia.org/math/9/9/d/99da85c71859b47df331e0f75cd27bea.png)

Sin, cos and ![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png) can be expressed by this series approximation

![\\sin x = x - \\frac {x^3} {3!} + \\frac {x^5} {5!} - \\frac {x^7} {7!} \\dots](//upload.wikimedia.org/math/9/6/3/963081f516367176c75e602ea1f9b9e6.png)

![\\cos x = 1 - \\frac {x^2} {2!} + \\frac {x^4} {4!} - \\frac {x^6} {6!} \\dots](//upload.wikimedia.org/math/9/6/8/968faeb8cd4b8ab06f38bf72d4f7010c.png)

![e^x = 1 + x + \\frac {x^2} {2!} + \\frac {x^3} {3!} + \\frac {x^4} {4!} \\dots](//upload.wikimedia.org/math/3/0/e/30eab8546c60250aae0d593804c54cc6.png)

Notice ![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png) also works for negative ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png).

When differentiated or integrated ![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png) generates itself!

When differentiated ![\\sin x](//upload.wikimedia.org/math/c/d/b/cdba58911c590ced3e2435dfa39f6873.png) generates ![\\cos x](//upload.wikimedia.org/math/9/6/e/96eb9bf5314b593783ee57983efbed9d.png).

By using series we can convert a complex function into a polynomial, and can use ![\\sin x = x - x^3 / 6](//upload.wikimedia.org/math/5/d/7/5d7beaf113288c9a2582b9892daec571.png) for small ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png).

In actual fact the kind of approximation used inside computer programs is more like: ![\\frac {a x^2 + b x + c } {A x^2 + B x + C }](//upload.wikimedia.org/math/9/c/5/9c5a6c9e79757238a2cdd70c9b485df7.png)

These have greater range but are much harder to develop and a bit fiddly on the calculator or to estimate by raw brain power.

We cannot expand ![\\ln x](//upload.wikimedia.org/math/2/e/2/2e2d2bfd8d38a8371cedaa366a5c07ab.png) this way because ![\\ln 0](//upload.wikimedia.org/math/b/6/0/b60f787e138271041a2c74dab9a0c262.png) is

![- \\infty](//upload.wikimedia.org/math/b/e/a/beab416080922c84a90ba092f7734fe5.png). However ![\\ln \(1 + x\)](//upload.wikimedia.org/math/d/9/b/d9b3cec34b6cfb15dcc6b28d8a8c242c.png) can be expanded.

Work out the series for ![\\ln \(1 + x\)](//upload.wikimedia.org/math/d/9/b/d9b3cec34b6cfb15dcc6b28d8a8c242c.png).

### Factorials[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-18)]

The factorials you have seen in series come from repeated differentiation. ![n!](//upload.wikimedia.org/math/3/8/8/388f554901ba5d77339eec8b26beebea.png) also has a statistical meaning as it is the number of unique ways you can arrange ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) objects.

![0!](//upload.wikimedia.org/math/e/5/6/e5602d45e1b58eea1f57a8ad60a8b6e6.png) is 1 by definition, _i.e._ the number of different ways you can arrange 0 objects is 1.

In statistical thermodynamics you will come across many factorials in expressions such as: ![W = \\frac {N!}{n_0! n_1! n_2!...}](//upload.wikimedia.org/math/f/9/5/f95ca7b1e7ba6f0c861468da56f763e6.png)

Factorials rapidly get unreasonably large: 6! = 720, 8! = 40320 but 12! = 479001600 so we need to divide them out into reasonable numbers if possible, so for example ![8! /6! = 7 {\\rm x} 8](//upload.wikimedia.org/math/e/c/2/ec220f1e2dc354ba7294a69b09c5d56f.png).

### Stirling's approximation[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-19)]

Also in statistical thermodynamics you will find _Stirling's approximation_:

![\\ln x! \\approx x \\ln x -x](//upload.wikimedia.org/math/8/3/c/83c7e9f365b89df64cf2bdce870f43ad.png)

This is proved and discussed in Atkins' _Physical Chemistry_.

How can you use series to estimate ![\\ln 2](//upload.wikimedia.org/math/1/c/a/1ca4d3ea7a03b51fba0451cd3bfe01b5.png). Notice that the series for

![\\ln \(1+x\)](//upload.wikimedia.org/math/d/9/b/d9b3cec34b6cfb15dcc6b28d8a8c242c.png) converges extremely slowly. ![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png) is much faster because the

![n!](//upload.wikimedia.org/math/3/8/8/388f554901ba5d77339eec8b26beebea.png) denominator becomes large quickly.

### Trigonometric power series[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-20)]

Remember that when you use ![\\sin x = x](//upload.wikimedia.org/math/3/f/a/3fa0f6e84f8c49713b1132baeff9bccd.png) and ![\\cos x = 1 - x^2 / 2](//upload.wikimedia.org/math/e/4/5/e451871ce6cb8b257f1b4b94650cc0fb.png)

that x must be in radians.....

## Calculus revision[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-21)]

### Problems[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-22)]

integrate x to the power of x with respect to x

  1. Differentiate ![e^{-t} \\cos 2t](//upload.wikimedia.org/math/a/e/1/ae11f07ab6a53b7034feaccfed711ea0.png), with respect to ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png). (Hint - use the chain rule.)
  2. Differentiate ![x^{2} { \( 3x + 1 \) } ^4](//upload.wikimedia.org/math/f/2/a/f2af38b013df446b44a38578d153ad54.png). (Chain rule and product rule here.)
  3. Differentiate ![\\ln~ \(7x^4\)](//upload.wikimedia.org/math/3/7/3/373689614b091f4f619bdcb4c4502ab2.png). (Hint - split it into a sum of logs first.)
  4. Integrate ![\\ln~ x](//upload.wikimedia.org/math/d/d/e/dde3009514a5353e3addf40fa8383c2f.png). (Hint - use integration by parts and take the expression to be differentiated as 1.)

### Answers[[edit](/w/index.php?title=Mathematics_for_Chemistry/Integration&action=edit&section=T-23)]

  1. It is just ![e^{-t} . -2 \\sin 2t - e^{-t} \\cos 2t](//upload.wikimedia.org/math/e/f/0/ef0beea2dfccc7fbbb66888e9bfda017.png). Bring a ![-e^{-t}](//upload.wikimedia.org/math/b/0/1/b01328de38fc9831a51e7e1f4d869e40.png) out of each term to simplify to ![-a\(b+c\)](//upload.wikimedia.org/math/8/0/7/807f04d4bf6aa6ec61387f71afd58959.png).
  2. ![2x { \( 9x + 1\) } { \( 3x + 1 \) } ^3](//upload.wikimedia.org/math/3/d/6/3d63736279ca1ffeb4b4a9da9ff99c41.png).
  3. ![\\ln~ 7 + 4 \\ln~ x](//upload.wikimedia.org/math/e/4/7/e4766a5c3bb55070543181f1a8c54e20.png) \- therefore it is 4 times the derivative of ![\\ln~ x](//upload.wikimedia.org/math/d/d/e/dde3009514a5353e3addf40fa8383c2f.png).
  4. You should get ![x \\ln~ x - x](//upload.wikimedia.org/math/6/2/3/623acee8d921d085da3eeb19eeaff8b4.png) by 1 application of _parts_.

# Some useful aspects of calculus[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=14)]

  1. ==Limits==

Many textbooks go through the proper theory of differentiation and integration by using limits. As chemists it is possible to live without knowing this so we might well not have it as an examinable topic. However here is how we differentiate **sin** from 1st principles.

![\\frac {{\\rm d} y} { {\\rm d} x} = \\left\( \\frac {{\\delta} y} { {\\delta} x} \\right\)_{{\\rm limit}~~~~ \\delta x \\rightarrow 0}](//upload.wikimedia.org/math/e/6/0/e60b625b2a3ebeb79c154f1158c86105.png)

![= \\frac { \\sin \(x + \\delta x\) - \\sin x} {\\delta x}](//upload.wikimedia.org/math/f/3/5/f35be080e9b82662bfa5ad23f110828a.png)

![= \\frac { \\sin x \\cos  \\delta x +\\sin \\delta x \\cos  x - \\sin x} {\\delta x}](//upload.wikimedia.org/math/4/d/6/4d69999db6ded3e50122780015c9be47.png)

![=  \\frac { \\sin x } {\\delta x} - \\frac { \\sin x } {\\delta x} + \\frac { \\sin \\delta x } {\\delta x} \\cos x](//upload.wikimedia.org/math/c/1/c/c1cd9d7bb77c5cd28ff35de92f6e3840.png)

As ![ \\sin \\delta x =  \\delta x](//upload.wikimedia.org/math/2/c/e/2ce44092132915e823dc6a54a5a1fd48.png) for small ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) this expression is ![\\cos x](//upload.wikimedia.org/math/9/6/e/96eb9bf5314b593783ee57983efbed9d.png).

Similarly for ![\\cos \\theta](//upload.wikimedia.org/math/9/3/a/93a4d3e2443c7e649d1fd9627795a36c.png)

![\\frac {{\\rm d} y} { {\\rm d} \\theta} = \\frac { \\cos \(\\theta + \\delta \\theta\) - \\cos \\theta} {\\delta \\theta}](//upload.wikimedia.org/math/5/b/f/5bf04b0b1c20438a5470fd5184fe05e5.png)

![= \\frac { \\cos \\theta \\cos  \\delta \\theta -sin  \\theta \\sin \\delta  \\theta - \\cos \\theta} {\\delta \\theta}](//upload.wikimedia.org/math/e/8/e/e8e0b6dc1af1e8de667571688e33d2f7.png)

![= \\frac { \\cos \\theta } {\\delta \\theta} - \\frac { \\sin  \\theta ~~\\delta \\theta} {\\delta \\theta} - \\frac { \\cos \\theta } {\\delta \\theta}](//upload.wikimedia.org/math/8/5/d/85d2c8383f233c08e5af92458a03ef65.png)

This is equal to ![- \\sin \\theta ](//upload.wikimedia.org/math/c/7/c/c7c0555be2a31fe8da6b032fc5fd8229.png).

## Numerical differentiation[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Useful_Aspects_of_Calculus&action=edit&section=T-2)]

You may be aware that you can fit a quadratic to 3 points, a cubic to 4 points, a quartic to 5 _etc_. If you differentiate a function numerically by having two values of the function ![\\delta x](//upload.wikimedia.org/math/5/8/b/58b1e9f4b9a86690cb106e65a265a34f.png) apart you get an approximation to ![\\frac {{\\rm d} y} { {\\rm d} x}](//upload.wikimedia.org/math/7/c/4/7c42735883f1f04633f45e2faf49155d.png) by constructing a triangle and the gradient is the tangent. There is a forward triangle and a backward triangle depending on the sign of ![\\delta x](//upload.wikimedia.org/math/5/8/b/58b1e9f4b9a86690cb106e65a265a34f.png). These are the forward and backward differentiation approximations.

If however you have a central value with a ![\\delta](//upload.wikimedia.org/math/f/1/0/f10f03c9836c36537d2539196058bfa2.png) either side you get the central difference formula which is equivalent to fitting a quadratic, and so is second order in the small value of ![\\delta x](//upload.wikimedia.org/math/5/8/b/58b1e9f4b9a86690cb106e65a265a34f.png) giving high accuracy compared with drawing a tangent. It is possible to derive this formula by fitting a quadratic and differentiating it to give:

![\\frac {{\\rm d} y} { {\\rm d} x} = \\frac { f^+ + f^-  - 2  f^0 } {\\delta^2}](//upload.wikimedia.org/math/a/0/c/a0cc71cc83a414e42da1d76c083cface.png)
    
    
    
       HCl   r-0.02
       sigma (iso)       32.606716      142.905788     -110.299071
    
       HCl   r-0.01
       sigma (iso)       32.427188      142.364814     -109.937626
    
       HCl   r0         Total shielding: paramagnetic  : diamagnetic
       sigma (iso)       32.249753      141.827855     -109.578102
    
       HCl   r+0.01
       sigma (iso)       32.074384      141.294870     -109.220487
    
       HCl   r+0.02
       sigma (iso)       31.901050      140.765819     -108.864769
    
    
    

This is calculated data for the shielding in ppm of the proton in HCl when the bondlength is stretched or compressed by 0.01 of an Angstrom (not the approved unit pm). The total shielding is the sum of two parts, the paramagnetic and the diamagnetic. Notice we have retained a lot of significant figures in this data, always necessary when doing numerical differentiation.

_Exercise_ \- use numerical differentiation to calculated d (sigma) / dr and d2 (sigma) / dr2 using a step of 0.01 and also with 0.02. Use 0.01 to calculate d (sigma(para)) / dr and d (sigma(dia)) / dr.

## Numerical integration[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Useful_Aspects_of_Calculus&action=edit&section=T-3)]

Wikipedia has explanations of the [Trapezium rule](//en.wikipedia.org/wiki/en:Trapezium_rule) and [Simpson's Rule](//en.wikipedia.org/wiki/en:Simpson%27s_rule). Later you will use computer programs which have more sophisticated versions of these rules called [Gaussian quadratures](//en.wikipedia.org/wiki/en:Gaussian_quadrature) inside them. You will only need to know about these if you do a numerical project later in the course. [Chebyshev quadratures](//en.wikipedia.org/wiki/en:Chebyshev%E2%80%93Gauss_quadrature) are another version of this procedure which are specially optimised for integrating noisy data coming from an experimental source. The mathematical derivation averages rather than amplifies the noise in a clever way.

# Enzyme kinetics[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=15)]

  1. [Mathematics for Chemistry/Enzyme kinetics](/w/index.php?title=Mathematics_for_Chemistry/Enzyme_kinetics&action=edit&redlink=1)

# Some mathematical examples applied to chemistry[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=16)]

  1. ==Variable names==

The ubiquitous ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) is not always the variable as you will all know by now. One problem dealing with real applications is sorting out which symbols are the variables and which are constants. (If you look very carefully at professionally set equations in text books you should find that there are rules that constants are set in Roman type, _i.e._ straight letters and variables in _italics_. Do not rely on this as it is often ignored.)

Here are some examples where the variable is conventionally something other than ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png).

  1. The [Euler angles](//en.wikipedia.org/wiki/en:Euler_angles) which are used in rotation are conventionally ![\\alpha, \\beta](//upload.wikimedia.org/math/4/3/1/431cef7e6de4eaf4478a41cc1d58ee00.png) and ![\\gamma](//upload.wikimedia.org/math/3/3/4/334de1ea38b615839e4ee6b65ee1b103.png) not the more usual angle names ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) and ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png). The _rotation matrix_ for the final twist in the commonest Euler definition therefore looks like ![\\begin{bmatrix}\\cos \(\\gamma\) & \\sin \(\\gamma\) & 0 \\\\-\\sin \(\\gamma\) & \\cos \(\\gamma\) & 0 \\\\0 & 0 & 1 \\\\\\end{bmatrix}](//upload.wikimedia.org/math/4/d/b/4db5dc33a157a6db70bf136ca8766b89.png)
  2. The energy transitions in the [hydrogen atom](//en.wikipedia.org/wiki/en:Hydrogen_atom) which give the [Balmer series](//en.wikipedia.org/wiki/en:Balmer_series) are given by the formula ![\\tilde {\\nu } = {\\rm R_H} \\left\(  \\frac 1 {2^2}  - \\frac 1 {n^2} \\right\)](//upload.wikimedia.org/math/5/4/2/54250a0462ca12cfbbefd881e32ff5a5.png) ![\\tilde {\\nu }](//upload.wikimedia.org/math/4/c/c/4ccf713b8382e627626e927dc5c83437.png) is just a single variable for the energy the _tilde_ being a convention used by spectroscopists to say it is wavenumbers, (cm-1). The H subscript on ![{\\rm R_H} ](//upload.wikimedia.org/math/3/8/2/382e0414b2114505caf608c2343c3025.png) has no mathematical meaning. It is the Rydberg constant and is therefore in Roman type. ![{\\rm R_H} ](//upload.wikimedia.org/math/3/8/2/382e0414b2114505caf608c2343c3025.png) is known very accurately as 109,677.581 cm-1. It has actually been known for a substantial fraction of the class to make an error putting this fraction over a common denominator in examination conditions.
  3. In the theory of light ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) is used for frequency and ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png) not surprisingly for time. Light is an oscillating electric and magnetic field therefore the cosine function is a very good way of describing it. You can also see here the use of complex numbers. Using the real axis of the [Argand diagram](http://mathworld.wolfram.com/ArgandDiagram.html) for the electric field and the imaginary axis for the magnetic field is a very natural description mathematically and maps ideally onto the physical reality. Here we are integrating with respect to ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png) and ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png), the operating frequency if it is a laser experiment is a constant, therefore it appears on the denominator in the integration. ![\\int \\cos \( \\omega t\) \\sin \( \\omega t\) dt = -{\\frac {\\cos\(\\omega \)^{2}}{2\\,\\omega}} + c](//upload.wikimedia.org/math/a/8/e/a8e435ab41ffcdd2b671bc48aa068499.png) In this case we can see a physical interpretation for the integration constant. It will be a _phase factor_. If we were dealing with sunlight we might well be integrating a different function over ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) in order to calculate all of the phenomenon which has different strengths at the different light frequencies. Our integration limits would either be from zero to infinity or perhaps over the range of energies which correspond to visible light.
  4. This example is a laser experiment called [Second Harmonic Generation](//en.wikipedia.org/wiki/en:Second_harmonic_generation). There is an electric field ![F](//upload.wikimedia.org/math/8/0/0/800618943025315f869e4e1f09471012.png), frequency ![\\nu](//upload.wikimedia.org/math/7/3/6/7368318dd3647eb6bbf6afaf6d26c48d.png) and a property constant ![ \\chi_{\(2\)}](//upload.wikimedia.org/math/d/0/0/d009000b5040e1a89d6f28ca0f7e4613.png). ![\\epsilon_{0} ](//upload.wikimedia.org/math/1/d/d/1dddc03e617f2f087ffb89a9b20b368f.png) is a fundamental constant. We have an intense monochromatic laser field fluctuating at the frequency ![\\nu](//upload.wikimedia.org/math/7/3/6/7368318dd3647eb6bbf6afaf6d26c48d.png), (_i.e._ a strong light beam from a big laser). ![F_{v} \\sin \(2\\pi \\nu t\)](//upload.wikimedia.org/math/3/4/e/34edf5287a60ab95516d641e79bea12d.png) Therefore the ![F^{2}](//upload.wikimedia.org/math/4/f/4/4f49b20a43c89ed6497573df66d2080d.png) term contributes ![\\epsilon_{0} \\chi_{\(2\)} F_{v}^{2} \\sin^{2}\(2 \\pi \\nu t \)](//upload.wikimedia.org/math/0/d/3/0d31000fddb5029ea135bee7b09cb526.png) to the polarization. We know from trigonometric identities that ![\\sin^{2}](//upload.wikimedia.org/math/e/f/0/ef0f51949784b52e9b588f99608c4184.png) can be represented as a cosine of the double angle ![\\cos \( 2 \\theta \) = 1 - 2 \\sin^{2}\\theta](//upload.wikimedia.org/math/4/2/7/427841dbb6151cdb13a8007d498018ae.png) Therefore the polarization is ![\\frac 1 2 \\epsilon_{0}\\chi_{\(2\)}F_{v}^{2} \( 1 - \\cos 4 \\pi \\nu t \)](//upload.wikimedia.org/math/f/f/f/fff65a425e9d67535ab2c0ae3da82b53.png) In this forest of subscripts and Greek letters the important point is that there are _two_ terms contributing to the output coming from ![\( 1 - \\cos 4 \\pi \\nu t \)](//upload.wikimedia.org/math/c/e/5/ce528119ad45398cc0fe06ce4d0d44ab.png) which multiplies the rest of the stuff. In summary we have ![A \\sin^{2}\( t \)](//upload.wikimedia.org/math/e/6/0/e605b490d223ab3ff4845c90c8b70caa.png) is equal to ![B \( 1 - \\cos\( 2 t \) \)](//upload.wikimedia.org/math/8/f/b/8fbb52a9313c7887ab2ad635bc0e9e02.png) where everything except the trig(t) and trig(2t) are to some extent unimportant for the phenomenon of doubling the frequency. ![\\sin](//upload.wikimedia.org/math/8/8/2/88265cd42f61bdf16ef2bd9fada9d5cd.png) and ![\\cos](//upload.wikimedia.org/math/1/f/1/1f141abfb260b11b18ca7ace446d349f.png) differ only in a phase shift so they represent the same physical phenomenon, _i.e._ light, which has phase. (One of the important properties of laser light is that it is _coherent_, _i.e._ it all has the same phase. This is fundamentally embedded in our mathematics.)

## van der Waals Energy[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry&action=edit&section=T-2)]

The [van der Waals energy](//en.wikipedia.org/wiki/en:Van_der_Waals_force) between two inert gas atoms can be written simply as a function of ![r](//upload.wikimedia.org/math/4/b/4/4b43b0aee35624cd95b910189b3dc231.png)

![E_{vdw} =  \\frac {\\rm A} {r^{12}} -  \\frac {\\rm B} {r^{6}}](//upload.wikimedia.org/math/1/5/c/15cfba5a9390cff5f92c7aab8d193391.png)

Notice that the ![r^{12}](//upload.wikimedia.org/math/d/0/1/d0187189aa9f42b92e0c3d84b593d5a4.png) term is positive corresponding to repulsion. The ![r^{6}](//upload.wikimedia.org/math/f/d/6/fd6f784ce0bab895ac2dcc3f3972ba2d.png) term is the attractive term and is negative corresponding to a reduction in energy. A and B are constants fitted to experimental numbers.

This function is very easy to both differentiate and integrate. Work these out. In a gas simulation you would use the derivative to calculate the forces on the atoms and would integrate [Newton's equations](//en.wikipedia.org/wiki/en:Newton%27s_laws_of_motion) to find out where the atoms will be next.

Another potential which is used is:

![E_{vdw} =  {\\rm A} e ^{- {\\rm B} r} - {\\rm C} r ^{-6}](//upload.wikimedia.org/math/c/2/6/c26b7c08817e51df2de48e9fdd7e3adb.png)

This has 1 more fittable constant. Integrate and differentiate this.

The ![\\frac {\\rm A} {r^{12}} -  \\frac {\\rm B} {r^{6}}](//upload.wikimedia.org/math/3/e/0/3e09213b8ff4d89966bdcadc3e1002c0.png) is called a [Lennard-Jones potential](//en.wikipedia.org/wiki/en:Lennard-Jones_potential) and is often expressed using the 2 parameters of an energy ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png) and a distance ![\\sigma](//upload.wikimedia.org/math/9/d/4/9d43cb8bbcb702e9d5943de477f099e2.png).

![E\(r\) =  4 \\epsilon \\left\( { { \\left\( \\frac \\sigma r \\right\) } ^ {12} - { \\left\( \\frac \\sigma r \\right\) } ^ 6 } \\right\)](//upload.wikimedia.org/math/b/8/6/b86bc716e0b182be3325161ef871c4e4.png)

![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png) is an energy. Set the derivative of this to zero and find out where the van der Waals minimum is. Differentiate again and show that the derivative is positive, therefore the well is a minimum, not a turning point.

## A diatomic potential energy surface[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/04/Argon_dimer_potential.png/220px-Argon_dimer_potential.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Interaction energy of argon dimer. The long-range part is due to London dispersion forces

In a diatomic molecule the energy is expanded as the bond stretches in a polynomial. We set ![x = \( r - r_0 \)](//upload.wikimedia.org/math/9/6/5/965b654bbf3685adf21971efadb0b159.png). At ![r_0](//upload.wikimedia.org/math/e/a/d/ead4ced109234b2f906f72270171d0ab.png) the function is a minimum so there is no ![ dE / dx](//upload.wikimedia.org/math/a/6/c/a6c65ec9796bcc9f10fd0df4d25fb501.png) term.

![E =  \\frac 1 2 k_{harm.} \\frac {{\\rm d}^2 E} {{\\rm d} x^2} +  \\frac 1 6 k_{anharm.} \\frac {{\\rm d}^3 E} {{\\rm d} x^3}](//upload.wikimedia.org/math/2/7/d/27d35ceeefb8a92983a2844b60a621d2.png)

Whatever function is chosen to provide the energy setting the 1st derivative to zero will be required to calculate ![r_0](//upload.wikimedia.org/math/e/a/d/ead4ced109234b2f906f72270171d0ab.png). The 2nd and 3rd derivatives will then need to be evaluated to give the shape of the potential and hence the infra-red spectrum. ![E](//upload.wikimedia.org/math/3/a/3/3a3ea00cfc35332cedf6e5e9a32e94da.png) is usually modelled by a very complicated function whose differentiation is not entered into lightly.

## A one-dimensional metal[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry&action=edit&section=T-4)]

A one-dimensional metal is modelled by an infinite chain of atoms 150 picometres apart. If the metal is lithium each nucleus has charge 3 and its electrons are modelled by the function

![cos^2\\left\\{ \\frac \\pi  2 \\frac r {150} \\right\\}](//upload.wikimedia.org/math/5/3/4/53410ae6198e37c602afb81514c2ccc3.png)

which repeats every 150 pm. What constant must this function be multiplied by to ensure there are 3 electrons on each atom? (Hint... integrate ![cos^2](//upload.wikimedia.org/math/3/c/8/3c89b142344d3602d00e04475b7b68f4.png) between either ![-\\frac \\pi  2](//upload.wikimedia.org/math/8/a/2/8a263ae7ba2d86ba1d5cff2c0e1d444b.png) and ![+\\frac \\pi  2](//upload.wikimedia.org/math/0/e/d/0ed02a4868cc7a6b06304e87ed03cff4.png) or -75pm and +75pm according to your equation. This integral is a dimensionless number equal to the number of electrons, so we will have to multiply by a _normalisation constant_.)

Here we have modelled the density of electrons. Later in the second year you will see electronic structure more accurately described by functions for _each independent electron_ called _orbitals_. These are subject to rigorous mathematical requirements which means they are quite fun to calculate.

## Kepler's Laws[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry&action=edit&section=T-5)]

Another physics problem but a good example of a log-log plot is the radius and time period relations of the planets.

This data is dimensionless because we have divided by the time / distance of the earth. We can take logs of both.

Mercury Venus Earth Mars Jupiter Saturn

r 0.3871 0.7233 1 1.524 5.203 9.539

T 0.2408 0.6152 1 1.881 11.86 29.46

Mercury Venus Earth Mars Jupiter Saturn

log10r -0.4122 0 0.9795

log10T -0.6184 0 1.4692

Try a least squares fit on your spreadsheet program. Using the Earth and Saturn data: (which is extremely bad laboratory practice, to usejust two points from a data set!)

![\\Delta\({\\log} T \) / \\Delta\({\\log} r \) = 1.5000359](//upload.wikimedia.org/math/4/9/4/4947eb77120bc307bb9a65783bb4cafc.png)

so ![{\\log} T = 1.5 {\\log} r =  {\\log} r^{1.5}](//upload.wikimedia.org/math/4/4/3/44315fb0ce8e0a808ab9e3a1ddc13fa7.png)

so ![ T = r^{3/2}](//upload.wikimedia.org/math/7/6/2/7622ec970248ad3865a9215528894fd7.png) and ![T^2 = r^3](//upload.wikimedia.org/math/b/2/d/b2d987fb88afbbadf239a0eba5c6791d.png)

This is [Kepler's 3rd law](//en.wikipedia.org/wiki/en:Kepler%27s_laws_of_planetary_motion#Third_law). If you use either a least squares fit gradient or the mercury to saturn data you get the same powers. We have got away with not using a full data set because the numbers given are unusually accurate and to some extent tautological, (remember the planets go round in ellipses not circles!).

## Newton's law of cooling[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry&action=edit&section=T-6)]

![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) is the excess temperature of a cooling body over room temperature (20oC say). The rate of cooling is proportional to the excess temperature.

![-\\frac {{\\rm d} \\theta} { {\\rm d} t} = k \\theta](//upload.wikimedia.org/math/a/9/f/a9f7f88c7df00edeac56424686db4c16.png)

![{\\rm using ~~~~~}\\frac {{\\rm d} x} { {\\rm d} y} =  \\frac 1{ \\frac {{\\rm d} y} { {\\rm d} x} }](//upload.wikimedia.org/math/4/7/8/478b9631a737c75a6949ff73a8ad7387.png)

![\\frac {{\\rm d} t} { {\\rm d} \\theta} = - \\frac 1 {k \\theta}](//upload.wikimedia.org/math/1/f/3/1f30dd3fd9e357d647cf5e2d7aa25885.png)

This is a differential equation which we integrate with respect to ![\\theta](//upload.wikimedia.org/math/5/0/d/50d91f80cbb8feda1d10e167107ad1ff.png) to get

![t = - \\frac 1 k \\ln \\theta + c](//upload.wikimedia.org/math/e/4/d/e4d2c54228f6648499c1edfdf2412a14.png)

The water is heated to ![80^o](//upload.wikimedia.org/math/7/7/8/7784d53ce12d48da89a1fc4dd68c0217.png)C and room temperature is ![20^o](//upload.wikimedia.org/math/3/2/8/328ed40beeeae3b9e91edcc5ff4ae2be.png)C. At the beginning ![t = 0](//upload.wikimedia.org/math/3/e/8/3e8f7b0adf6d7024b951f29a18225e4a.png) and ![\\theta = 60](//upload.wikimedia.org/math/c/a/7/ca77dae73258c94b8f34628fad662a80.png), so

![0 = - \\frac 1 k \\ln 60 + c](//upload.wikimedia.org/math/1/9/5/195cdc152cb2a5b3eb017eb19cee8413.png)

therefore

![c = \\frac {\\ln 60}  k](//upload.wikimedia.org/math/8/4/5/8454fc82cb1306707640f2210b27f65e.png)

![t = - \\frac 1 k \\ln \\theta +  \\frac 1 k \\ln 60](//upload.wikimedia.org/math/0/7/f/07f4dcc0d5666b9a0ffe13346e11ef09.png)

but ![\\ln 60  -\\ln \\theta = - \\ln {\\frac \\theta {60}}](//upload.wikimedia.org/math/0/2/d/02dcfe1937269b7d93893ae4581e619e.png)

so ![\\ln {\\frac \\theta {60}} = - k t](//upload.wikimedia.org/math/1/c/6/1c64f2162c52a9e31b74d2f402e99c5d.png)

After 5 minutes the water has cooled to ![70^o](//upload.wikimedia.org/math/9/a/c/9ac68030bc0c8f28c58df2df058012ad.png)C.

so ![\\ln {\\frac {50}  {60}} = - 5k ](//upload.wikimedia.org/math/f/b/b/fbbb53838b1248c8b4e2e10c53650944.png) so ![k = - \\frac 1 5 \\ln \\frac 5 6 =  \\frac 1 5 \\ln \\frac  6  5<math>.
So <math>k = 0.0365](//upload.wikimedia.org/math/4/c/a/4caec946dac1132d150172196e44f894.png)

![\\ln{\\frac \\theta {60}} = -0.0365 t](//upload.wikimedia.org/math/5/c/d/5cda3c1d874f66a0acc63f260a86c09c.png)

![\\frac \\theta {60} = e ^{-0.0365 t}](//upload.wikimedia.org/math/5/3/4/5346ba429c7b3c66ca2fe0c064a2cb5f.png)

by the definition of logarithms. This gives the plot of an exponential decay between 80 and 20oC.

So after 10 minutes ![t = 20 + 60 e^{-0.365} = 61.6^o](//upload.wikimedia.org/math/5/6/3/56383d79ab9e5d9d480f6615125293a3.png)C. After 20 minutes ![t = 20 + 60 e^{-0.73} = 49.9^o](//upload.wikimedia.org/math/9/9/d/99d6bfbb85c2b58fedd56611c66583cd.png)C. After 30 minutes ![t = 20 + 60 e^{-1.10} = 40.1^o](//upload.wikimedia.org/math/6/4/5/6457b5896959b30a37e5e1da119f4b5c.png)C.

## Bacterial Growth[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry&action=edit&section=T-7)]

2 grams of an organism grows by 1/10 gram per day per gram.

![\\frac {{\\rm d} m} { {\\rm d} t} = \\frac m {10}](//upload.wikimedia.org/math/b/a/d/bad1be481e28cd281200609ecc513f3f.png)

This is a differential equation which is solved by integration thus

![\\int \\frac {10} m {\\rm d} m = \\int  { {\\rm d} t}](//upload.wikimedia.org/math/6/3/4/6348b1fbb595aab48c6be3b507a04587.png)

![10 \\ln m = t + c](//upload.wikimedia.org/math/3/7/9/379058720fccab88fb69ddc8087058ed.png)

![\\ln m = \\frac t {10} + c](//upload.wikimedia.org/math/a/7/3/a73d8762ce2185c826182de82ef50f04.png)

therefore

![m = e^c e^{\\frac t {10}}](//upload.wikimedia.org/math/0/3/6/0369108f468178348bff5daded619172.png)

When ![t = 0 ](//upload.wikimedia.org/math/3/e/8/3e8f7b0adf6d7024b951f29a18225e4a.png) we have 2 grams so

![m = 2 e^{t/10}](//upload.wikimedia.org/math/d/d/c/ddc27d016d4b0e3070999e0c4214f46f.png)

For the sample to double in mass

![4 = 2 e^{t/10}](//upload.wikimedia.org/math/8/3/6/8362549b3969cc001be8b8ff11bb3f74.png)

![2 =  e^{t/10}](//upload.wikimedia.org/math/0/5/8/05805d632ef3e9ff0388189290dff132.png)

![\\ln 2 = \\frac t {10}](//upload.wikimedia.org/math/5/6/7/56758580477e2d64bf9731e217be6767.png)

![t = 10 \\ln 2 = 6.9315 {\\rm days}](//upload.wikimedia.org/math/e/d/1/ed1c5702fcbeec5ace24060140fe9975.png)

Half life calculations are similar but the exponent is negative.

## Partial fractions for the 2nd order rate equation[[edit](/w/index.php?title=Mathematics_for_Chemistry/Some_Mathematical_Examples_applied_to_Chemistry&action=edit&section=T-8)]

In chemistry work you will probably be doing the 2nd order [rate equation](//en.wikipedia.org/wiki/en:Rate_equation) which requires partial fractions in order to do the integrals.

If you remember we have something like

![\\frac{1}{\(2-x\)\(3-x\)} = \\frac{A}{\(2-x\)} + \\frac{B}{\(3-x\)}](//upload.wikimedia.org/math/0/e/3/0e3901f7eb9b00a5c4741938ac2f8eaa.png)

Put the right-hand side over a common denominator

![\\frac{1}{\(2-x\)\(3-x\)} = \\frac{A\(3-x\)+B\(2-x\)}{\(2-x\)\(3-x\)}](//upload.wikimedia.org/math/a/a/e/aaeabbe3cd17bded8d94155e7cf63604.png)

This gives ![1 = 3A - Ax + 2B - Bx](//upload.wikimedia.org/math/6/3/3/63368d98efb5da16d60d10a843419d9d.png)

By setting x to 3 we get 1 = -B (B=-1). Setting x = 0 and B = -1
    
    
    
                 1 = 3A -2     (A=+1)
    
       Check    1 = 3 -x -2 +x  true...
    
    

Therefore

![\\int \\frac{1}{\(2-x\)\(3-x\)} dx = \\int\\frac{1}{\(2-x\)} - \\int\\frac{1}{\(3-x\)} dx = \\ln \(2-x\) + \\ln \(3-x\) + c](//upload.wikimedia.org/math/d/0/5/d057cc9af08d31cec2620d68e3a3b69b.png)

noting the sign changes on integrating 1/(2-x) not 1/x.

# Tests and exams[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=17)]

  1. ==A possible final test with explanatory notes==

This test was once used to monitor the broad learning of university chemists at the end of the 1st year and is intended to check, somewhat lightly, a range of skills in only 50 minutes. It contains a mixture of what are perceived to be both easy and difficult questions so as to give the marker a good idea of the student's algebra skills and even whether they can do the infamous _integration by parts_.

* * *

(1) Solve the following equation for ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png)

![x^2+2x-15 = 0](//upload.wikimedia.org/math/1/5/2/15287e6076ac27e7569732c84891f8f7.png)

It factorises with 3 and 5 so : ![\(x+5\)\(x-3\) = 0](//upload.wikimedia.org/math/8/4/6/8465619d0063c13dc1c8c0f05c7fcede.png) therefore the **roots** are -5 and +3, not 5 and -3!

* * *

(2) Solve the following equation for ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png)

![2x^2-6x -20 = 0](//upload.wikimedia.org/math/6/3/0/630e54d4973528b36cde549ee2750dd4.png)

Divide by 2 and get ![x^2-3x -10 = 0](//upload.wikimedia.org/math/3/c/a/3caeaacc4ac2d886fbf75eec41faf4c1.png).

This factorises with 2 and 5 so : ![\(x-5\)\(x+2\) = 0](//upload.wikimedia.org/math/9/9/a/99abb53a8332c14a68fa14061008071b.png) therefore the **roots** are 5 and -2.

* * *

(3) Simplify

![\\ln w^6 - 4\\ln w](//upload.wikimedia.org/math/2/5/2/252f1a8e6a62dfffba6475e6b5936fb4.png)

Firstly ![6\\ln w - 4\\ln w ](//upload.wikimedia.org/math/3/c/e/3ce33b383258eef0ada84437fbdf8293.png) so it becomes ![2\\ln w](//upload.wikimedia.org/math/3/a/4/3a41a6f966efe2d16da7696607e64c1a.png).

* * *

(4) What is

![\\log_{2} \\frac 1 { 64}](//upload.wikimedia.org/math/6/6/d/66d738ae4153075852b134224eccad14.png)

64 = 8 x 8 so it also equals ![2^3 ](//upload.wikimedia.org/math/6/3/a/63a1e1a5a5a28b0cf5e7687836075240.png)x![ 2^3](//upload.wikimedia.org/math/6/3/a/63a1e1a5a5a28b0cf5e7687836075240.png) _i.e._ ![\\frac 1 { 64}](//upload.wikimedia.org/math/9/0/3/903798f46fcaa09100c26dddde22589e.png) is ![2^{-6}](//upload.wikimedia.org/math/6/6/3/6634e49dc5dabf529eaae89e422d0443.png), therefore the answer is -6.

* * *

(5) Multiply the two complex numbers

![3+5i  ~~~~ {\\rm and} ~~~~ 3-5i](//upload.wikimedia.org/math/f/3/6/f364a9e5f5377067b5bba367dd0a9196.png)

These are complex conjugates so they are ![3^2](//upload.wikimedia.org/math/5/6/a/56a5d0fae0136327e61476dcfe43109a.png) minus ![i^2 ](//upload.wikimedia.org/math/c/7/8/c78660a7b99d99f1c82eb162119b45f1.png)x![ 5^2](//upload.wikimedia.org/math/7/0/7/70706222b4ca912c2702d03b87174b32.png) _i.e._ plus 25 so the total is 34.

* * *

(6) Multiply the two complex numbers

![\(5,-2\)  ~~~~ {\\mathrm and}  ~~~~ \(-5,-2\)](//upload.wikimedia.org/math/4/6/2/46257d274ca9eb1cee612a99fbc27e93.png)

The real part is -25 plus the ![4i^2](//upload.wikimedia.org/math/9/6/7/967f1005fa1538555745d6b19061172e.png). The cross terms make ![-10i](//upload.wikimedia.org/math/a/a/7/aa7b698808dbcfdf98be986c15f01ae1.png) and ![+10i](//upload.wikimedia.org/math/2/3/f/23fc81a9fa81985aa3d92a7423ecb937.png) so the imaginary part disappears.

* * *

(7) Differentiate with respect to ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png):

![\\frac 1 {3x^2}-3x^2](//upload.wikimedia.org/math/9/7/5/9754539b989f941bf111273e0feca736.png)

Answer: ![ ~~~~~~~- \\frac 2 {3x^3}-6x](//upload.wikimedia.org/math/f/5/1/f51a52987dd9eec864a79ccaa9522640.png)

* * *

(8) ![ \\frac  6 {x^4} +3  x^3](//upload.wikimedia.org/math/5/b/d/5bdd5d3f62fd18e3205badf5c8188371.png)

Answer: ![ ~~~~~~~ 9  {x^2} - \\frac  {24} {x^5} ](//upload.wikimedia.org/math/5/5/3/5534636a933cc009de6e8b1d36d82f7f.png)

* * *

(9) ![ \\frac{2}{\\sqrt x} + 2 \\sqrt x](//upload.wikimedia.org/math/8/e/3/8e357c71b2db6e6fe93a53513226e466.png)

Answer: ![ ~~~~~~\\frac 1 {\\sqrt x} - \\frac 1 {\\sqrt {x^3}}](//upload.wikimedia.org/math/a/8/d/a8d1e2d61f392f0e96893d930baf7bf1.png)

* * *

(10) ![x^3 \(  x - \( 2x + 3 \) \(2x - 3\) \)](//upload.wikimedia.org/math/7/d/1/7d1e4e31fda6db52b824c393c131c57f.png)

Expand out the difference of 2 squares first.....collect and multiply....then just differentiate term by term giving: ![ ~~~~ 20x^4 -4x^3 + 27x^2](//upload.wikimedia.org/math/c/6/6/c665c326d7327642fa9d4812d8f8c915.png)

* * *

(11) ![3x^3  \\cos 3x](//upload.wikimedia.org/math/b/1/b/b1bbe5f29de568af9a792e866f77ab05.png)

This needs the product rule.... Factor out the ![9x^2](//upload.wikimedia.org/math/5/7/b/57b42b7a1770810cd36584b12cf6b0de.png) .... ![ 9x^2\( \\cos 3x - x \\sin 3x\)](//upload.wikimedia.org/math/a/d/2/ad2ee1beb4b95f21d7867c05828cc3e7.png)

* * *

(12) ![\\ln \( 1 - x\)^2](//upload.wikimedia.org/math/8/8/1/88116084b5ee66f4c2a15a672e56df67.png)

This could be a chain rule problem....... ![\\frac 1 { \( 1 - x\)^2}  . 2 . \(-1\) . \( 1 - x \)](//upload.wikimedia.org/math/d/a/1/da11ba0275871ff154fd41ca0eee35a8.png)

or you could take the power 2 out of the log and go straight to the same answer with a shorter version of the chain rule to:![- \\frac 2 {\( 1 - x\)}](//upload.wikimedia.org/math/8/e/a/8ea25052f7c2ee92254f343b640cfff8.png).

* * *

(13) Perform the following integrations:

![\\int  \\left\( 2 \\cos^2 \\theta + 2 \\theta \\right\) {\\rm d}\\theta](//upload.wikimedia.org/math/3/2/a/32a58e107629b9a2c2d815f899914fb3.png)

![\\cos^2](//upload.wikimedia.org/math/0/8/d/08d39000a1419a78d577812f143ba8e4.png) must be converted to a double angle form as shown many times.... then all 3 bits are integrated giving .......

![\\cos \\theta \\sin \\theta +  \\theta +  \\theta^2](//upload.wikimedia.org/math/5/2/d/52d82e3ebc9ebeef977cea0426c3802f.png)

* * *

(14) ![\\int \\left\( 8 x^{-3} - \\frac 4 x + \\frac 8 {x^3} \\right\) {\\rm d}x](//upload.wikimedia.org/math/d/1/e/d1ed4ef14c597d1102c3608c3ac142cb.png)

Apart from ![ - \\frac 4 x ](//upload.wikimedia.org/math/c/7/9/c79d364e8fa804474e6df5203dee7138.png), which goes to ![\\ln](//upload.wikimedia.org/math/3/c/1/3c178b05d8a108e6346e61420651bedf.png), this is straightforward polynomial integration. Also there is a nasty trap in that two terms can be telescoped to ![\\frac {16} { x^3}](//upload.wikimedia.org/math/0/e/1/0e13bd70c08baa874a3fa09be0560a13.png).

![-\(\\frac 8 {x^2} + 4 \\ln x\)](//upload.wikimedia.org/math/6/c/2/6c293f362059eba9baf15a01966c96b9.png)

* * *

(15) What is the equation corresponding to the determinant:

![\\begin{vmatrix}
b & \\frac 1 {\\sqrt 2}  & 0\\\\
\\frac 1 {\\sqrt 2}& b & 1\\\\
0 & 1 & b\\\\
\\end{vmatrix}
= 0](//upload.wikimedia.org/math/7/9/3/793c63a3ade908d6b8d36fb5f866f66c.png)

The first term is ![b\(b^2-1\)](//upload.wikimedia.org/math/4/f/6/4f6821df71f03d26c1b633ec324471fb.png) the second ![-\\frac 1 {\\sqrt 2} \(\\frac b {\\sqrt 2} - 0 \)](//upload.wikimedia.org/math/f/5/a/f5a56367830155f402f0043ec1e06393.png) and the 3rd term zero. This adds up to ![b^3 -3 /2 b](//upload.wikimedia.org/math/7/e/f/7efbe6d1e4d6f722055177a1b9ca55e1.png).

* * *

(16) What is the general solution of the following differential equation:

![\\frac {{\\rm d} \\phi} { {\\rm d} r} = \\frac  {\\rm A} r](//upload.wikimedia.org/math/f/8/2/f82aa782886992aaa4e52b27117e3923.png)

where A is a constant..

![\\theta = A \\ln r + k](//upload.wikimedia.org/math/b/6/d/b6de9275875855cf694050584297a379.png).

* * *

(17) Integrate by parts: ![\\int x \\sin x  {\\rm d} x](//upload.wikimedia.org/math/4/8/a/48a05f0151f205684311efa456075ab2.png)

Make ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) the factor to be differentiated and apply the formula, taking care with the signs... ![\\sin x - x \\cos x](//upload.wikimedia.org/math/9/c/f/9cf88b32a0f0246ea1fb70e47c6106db.png).

* * *

(18)The Maclaurin series for which function begins with these terms?

![1 + x +  x^2/  2! + x^3 / 3! + x^4/  4! + \\dots](//upload.wikimedia.org/math/3/0/8/308d050cf4e65a1f1f212e4afda77751.png)

It is ![e^x](//upload.wikimedia.org/math/5/c/f/5cffa5d7a0c145a80dee9dc2295d5cdf.png)....

* * *

(19)Express

![\\frac {x-2} {\(x-3\)\(x+4\)}](//upload.wikimedia.org/math/a/8/a/a8af2287532d473d7e680c8d93b6f4ee.png) as partial fractions.

It is ..... ![~~~~~\\frac 1 {7\(x-3\)} + \\frac 6 {7\(x+4\)}](//upload.wikimedia.org/math/a/f/9/af9c801e0f6557ae5a3af5e54392ac28.png)

* * *

(20) What is ![2e^{i4\\phi} - \\cos 4 \\phi](//upload.wikimedia.org/math/9/7/b/97b7a5c2dafce495e33ead0a7c5ad89e.png) in terms of sin and cos

This is just Euler's equation..... ![2e^{i4\\phi} = 2\\cos 4 \\phi - 2 i \\sin 4 \\phi](//upload.wikimedia.org/math/5/b/a/5bad81cb05b9af59abfb2c897d6ac94e.png)

so one ![\\cos 4 \\phi](//upload.wikimedia.org/math/9/b/b/9bb960c826b9f00844806c1bf6873d4b.png) disappears to give ... ![\\cos 4 \\phi - 2 i \\sin 4 \\phi](//upload.wikimedia.org/math/3/0/2/302c0b3dac909cb0ad3c90f367f68236.png).

### 50 Minute Test II[[edit](/w/index.php?title=Mathematics_for_Chemistry/Tests_and_Exams&action=edit&section=T-2)]

(1) Simplify ![2\\ln \(1 / x^3\) + 5\\ln x](//upload.wikimedia.org/math/4/b/1/4b1061d7a226e36bc63a1bb357652382.png)

* * *

(2)What is ![\\log_{10} \\frac 1 { 10~000}](//upload.wikimedia.org/math/e/8/8/e882af6ce5657c38edf7a9cd5a5f8982.png)

* * *

(3) Solve the following equation for ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png)

![t^2-3t-4 = 0](//upload.wikimedia.org/math/e/5/f/e5f18d417fed210807c231ecb28ac389.png)

* * *

(4) Solve the following equation for ![w](//upload.wikimedia.org/math/f/1/2/f1290186a5d0b1ceab27f4e77c0c5d68.png)

![w^2+4w-12 = 0](//upload.wikimedia.org/math/c/e/b/ceba439d294da16234cd9691aeb1e3eb.png)

* * *

(5) Multiply the two complex numbers ![\(-4,3\) ~~~~ {\\rm and } ~~~~~ \(-5,2\)](//upload.wikimedia.org/math/6/d/b/6db560d84978557d8b7408006be246ac.png)

* * *

(6) Multiply the two complex numbers ![3+2i ~~~~ {\\rm and }  ~~~~~~ 3-2i](//upload.wikimedia.org/math/0/f/8/0f80a6be40d0c69fbbc1606f461f8d2d.png)

* * *

(7) The Maclaurin series for which function begins with these terms?

![x - x^3/  6 + x^5 / 120 + \\dots](//upload.wikimedia.org/math/b/7/f/b7f0125d99f8b3ea85db973f4bf2f39e.png)

* * *

(8) Differentiate with respect to ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png):

![x^3 \( 2 - 3x \)^2](//upload.wikimedia.org/math/7/c/c/7cc2233dfea2dbb47f4ed82e360cc7d6.png)

* * *

(9) ![\\frac {\\sqrt x} 2 - \\frac {\\sqrt 3} {2 \\sqrt x}](//upload.wikimedia.org/math/1/9/f/19f9beac345b3940611ca70bc9571f1e.png)

* * *

(10)![x^4-3x^2+{\\rm k}](//upload.wikimedia.org/math/2/e/6/2e62482333142089174cca753f7ea217.png)

where k is a constant.

* * *

(11) ![\\frac 2 {3x^4}-{\\rm A}x^4](//upload.wikimedia.org/math/2/0/0/200483f924b0bf604f52ced5fdccbebd.png)

where A is a constant.

* * *

(12) ![3x^3 e^{3x}](//upload.wikimedia.org/math/c/e/3/ce3ed1272cfe1dfcd79abdd0a52a7970.png)

* * *

(13) ![\\ln \( 2 - x\)^3](//upload.wikimedia.org/math/7/a/a/7aa9efa5bf21f882ab3d7118b22df915.png)

* * *

(14) Perform the following integrations:

![\\int \\left\( 3 w^4 - 2 w^2 + \\frac 6 {5 w^2} \\right\) {\\rm d}w](//upload.wikimedia.org/math/0/c/e/0ce811b54744fe71486b0f3e18c18a78.png)

* * *

(15) ![\\int  \\left\( 3 \\cos \\theta  + \\theta \\right\) {\\rm d}\\theta](//upload.wikimedia.org/math/2/c/b/2cbc9bc4776fbb72ffccc616814cc282.png)

* * *

(16) What is the equation belonging to the determinant \begin{vmatrix} x & 0 & 0\\\ 0 & x & i \\\ 0 & i & x \\\ \end{vmatrix} = 0</math>

* * *

(17) What is the general solution of the following differential equation:

![\\frac {{\\rm d} y} { {\\rm d} x} = k y](//upload.wikimedia.org/math/f/7/7/f771800043d5c4a47e5a8164beccbd6f.png)

* * *

(18) Integrate by any appropriate method:

![\\int \\left\(  \\ln x  + \\frac 4 x \\right\)  {\\rm d} x](//upload.wikimedia.org/math/d/e/9/de9415fe9527045190b4ff20e50d083e.png)

* * *

(19) Express ![\\frac {x+1} {\(x-2\)\(x+2\)}](//upload.wikimedia.org/math/4/6/5/465ac85d2228043658928bdd9bd9c95b.png)

as partial fractions.

* * *

(20) What is ![2e^{i2\\phi} + 2i \\sin 2 \\phi](//upload.wikimedia.org/math/3/b/a/3baa5137382f560eee740ef59c037466.png) in terms of sin and cos.

## 50 Minute Test III[[edit](/w/index.php?title=Mathematics_for_Chemistry/Tests_and_Exams&action=edit&section=T-3)]

(1) Solve the following equation for ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png)

![t^2-4t-12 = 0](//upload.wikimedia.org/math/a/c/6/ac6219558061f48878d73711394a82bd.png)

* * *

(2) What is ![\\log_{4} \\frac 1 { 16}](//upload.wikimedia.org/math/b/b/4/bb4a3ddd5b83abdf8647b70ff6968f29.png)

* * *

(3) The Maclaurin series for which function begins with these terms?

![1 - x^2/ 2 + x^4 / 24 + \\dots
](//upload.wikimedia.org/math/0/9/d/09dc74bcaf39905e5bbe162b67747f80.png)\---- (4) Differentiate with respect to ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png):

![\\frac  5  {x^2} - 8 {x^4}](//upload.wikimedia.org/math/f/6/5/f6572b2f70c65b1ccf5d4fea8ae7eda7.png)

* * *

(5) ![\\frac 4 {\\sqrt x} - {\\sqrt 2 x}](//upload.wikimedia.org/math/a/3/5/a3560549ebd388e2fec0dc01fff20572.png)

* * *

(6) ![5 {\\sqrt x} + \\frac  6 {x^3  }](//upload.wikimedia.org/math/4/3/a/43addf6f0c907dd8a0d9f281e2733704.png)

* * *

(7) ![\\frac 5 {x^3}-5x^3](//upload.wikimedia.org/math/e/1/e/e1e6daf64bd22879c789368d8ec2013a.png)

* * *

(8) ![x^2 \(2x^2 - \( 5 + 2x \) \(5 - 2x\) \)](//upload.wikimedia.org/math/a/8/a/a8a638ec688f4d69aedee6e550312ae5.png)

* * *

(9) ![2x^2  \\sin x](//upload.wikimedia.org/math/d/6/b/d6b51aade1a3542bee7c1ab792f1e6b4.png)

* * *

(10) Multiply the two complex numbers ![\(2,3\) ~~~~~~ {\\rm  and } ~~~~~~ \(2,-3\)](//upload.wikimedia.org/math/1/2/9/129075f98e0d25405f99fae4f72fade2.png)

* * *

(11) Multiply the two complex numbers ![3 -i ~~~~~ {\\rm  and } ~~~~ -3 +i](//upload.wikimedia.org/math/f/4/9/f4980ae1c114b0d362e38d6693582076.png)

* * *

(12) Perform the following integrations:

![\\int  \\left\(  \\frac 1 {3x} + \\frac 1 {3x^2} -  5 x^{-6}  \\right\) {\\rm d}x](//upload.wikimedia.org/math/e/f/1/ef1f0530ef1538bdf37a9279f049bdb5.png)

* * *

(13)

![\\int \\left\( 6 x^{-2} + \\frac 2 x - \\frac 8 {x^2} \\right\) {\\rm d}x](//upload.wikimedia.org/math/c/7/6/c764af5967329d12fbe232b82ed12a1b.png)

* * *

(14) ![\\int  \\left\( \\cos^2 \\theta + \\theta \\right\) {\\rm d}\\theta](//upload.wikimedia.org/math/7/1/f/71f9ed8ba2ce5110c0f683fe66f8e4bb.png)

* * *

(15) ![\\int  \\left\( \\sin^3 \\theta \\cos \\theta + 2 \\theta \\right\) {\\rm d}\\theta](//upload.wikimedia.org/math/4/6/3/4639ecf6b02e8426efeed6cc406f5a8a.png)

* * *

(16) Integrate by parts: ![\\int 2 x \\cos x  {\\rm d} x](//upload.wikimedia.org/math/d/7/2/d72094e58044c99f00c687247bef8b0f.png)

* * *

(17) What is the equation corresponding to the determinant:

![\\begin{vmatrix}
x & -1  & 0\\\\
-1 & x & 0 \\\\
0 & 0 & x   \\\\
\\end{vmatrix}
= 0](//upload.wikimedia.org/math/f/e/7/fe7e4b730f290433037d627b5922117b.png)

* * *

(18) Express ![\\frac {x-1} {\(x+3\)\(x-4\)}](//upload.wikimedia.org/math/a/d/5/ad5d299adc2c15242bd348ddbef58c68.png) as partial fractions.

* * *

(19)What is the general solution of the following differential equation:

![\\frac {{\\rm d} \\theta} { {\\rm d} r} = \\frac { r} A](//upload.wikimedia.org/math/0/e/5/0e54f79733bdd3036527802f7c8d5a8d.png)

* * *

(20) What is ![e^{i2\\phi} - 2i \\sin 2 \\phi](//upload.wikimedia.org/math/1/b/1/1b1b4f437c4d041f9e3f9dd3a238d1df.png) in terms of sin and cos.

# Further reading[[edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit&section=18)]

  1. ==Further reading==

### Books[[edit](/w/index.php?title=Mathematics_for_Chemistry/Further_reading&action=edit&section=T-2)]

  * Paul Monk, _Maths for Chemistry: A Chemist's Toolkit of Calculations_, (Oxford, 2006), [ISBN 978-0199277414](/wiki/Special:BookSources/9780199277414).
  * Bostock and Chandler, _Core Maths for A-level, Third Edition_, (Nelson Thornes, 2000), [ISBN 978-0748755097](/wiki/Special:BookSources/9780748755097).
  * M. C. R. Cockett and G. Doggett, _Maths for Chemists: Numbers, Functions and Calculus v. 1_, (Royal Society of Chemistry, London, 2003), [ISBN 978-0854046775](/wiki/Special:BookSources/9780854046775)
  * M. C. R. Cockett and G. Doggett, _Maths for Chemists: Power Series Complex Numbers and Linear Algebra v. 2_, (Royal Society of Chemistry, London, 2003), [ISBN 978-0854044955](/wiki/Special:BookSources/9780854044955)
  * G. Currell and T. Dowman,_Mathematics and Statistics for Science_, (Wiley, 2005), [ISBN 978-0470022290](/wiki/Special:BookSources/9780470022290).
  * Stephen K. Scott, _Beginning Maths for Chemistry_, (Oxford, 1995), [ISBN 978-0198559306](/wiki/Special:BookSources/9780198559306)
  * Peter Tebbutt, _Basic Mathematics for Chemists, 2nd edition_, (Wiley, 1994), [ISBN 978-0471972839](/wiki/Special:BookSources/9780471972839)

### Online resources[[edit](/w/index.php?title=Mathematics_for_Chemistry/Further_reading&action=edit&section=T-3)]

There is much useful free material relevant to this book, including downloadable DVDs, funded by the HEFCE Fund for the Development of Teaching & Learning and the Gatsby Technical Education Project in association with the Higher Education Academy at [Math Tutor](http://www.mathtutor.ac.uk/).

[Discover Maths for Chemists](http://discovermaths.rsc.org) from the [Royal Society of Chemistry](http://www.rsc.org) is a a one-stop site designed by chemists for chemists. This new free-to-use site brings together all the best resources to help you combine maths and chemistry.

[Maths for Chemistry](http://mathsforchemistry.info) is an online resource providing interactive context-based resources which explain how various aspects of maths can be applied to chemistry. There are quizzes and downloadable files to check understanding.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&oldid=2503106](http://en.wikibooks.org/w/index.php?title=Mathematics_for_Chemistry/Print_version&oldid=2503106)" 

[Categories](/wiki/Special:Categories): 

  * [Mathematics for Chemistry](/wiki/Category:Mathematics_for_Chemistry)
  * [Section stubs](/wiki/Category:Section_stubs)
  * [Chapter stubs](/wiki/Category:Chapter_stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Mathematics+for+Chemistry%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Mathematics+for+Chemistry%2FPrint+version)

### Namespaces

  * [Book](/wiki/Mathematics_for_Chemistry/Print_version)
  * [Discussion](/w/index.php?title=Talk:Mathematics_for_Chemistry/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Mathematics_for_Chemistry/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Mathematics_for_Chemistry/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=edit)
  * [View history](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Mathematics_for_Chemistry/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Mathematics_for_Chemistry/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Mathematics_for_Chemistry/Print_version&oldid=2503106)
  * [Page information](/w/index.php?title=Mathematics_for_Chemistry/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Mathematics_for_Chemistry%2FPrint_version&id=2503106)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Mathematics+for+Chemistry%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Mathematics+for+Chemistry%2FPrint+version&oldid=2503106&writer=rl)
  * [Printable version](/w/index.php?title=Mathematics_for_Chemistry/Print_version&printable=yes)

  * This page was last modified on 18 March 2013, at 14:50.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Mathematics_for_Chemistry/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
