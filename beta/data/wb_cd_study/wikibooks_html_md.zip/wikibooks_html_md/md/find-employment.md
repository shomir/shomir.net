# Find Employment/Print Version

From Wikibooks, open books for an open world

< [Find Employment](/wiki/Find_Employment)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Find Employment](/wiki/Find_Employment)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Find_Employment/Print_Version&action=purge&printable=yes) this page.

  
[Find Employment/Cover](/w/index.php?title=Find_Employment/Cover&action=edit&redlink=1)  
This wikibook is an attempt to explain the process of finding a job and getting hired for that job. It will explain such topics as finding a job, writing a resume, and performing at an interview.

Disclaimer: External Links are provided for reference, and do not constitute an endorsement. Spam will not be tolerated, and will be removed on sight.

  


# Introduction

**[Find Employment](/wiki/Find_Employment)**

## What this book is about

This book is about finding work. This book will discuss finding a job through the creation of a resume and a cover letter, the application process, and the interview. This book will also briefly discuss finding work by starting your own business.

## Who this book is for

Technically speaking, this book is for every person. People who are unemployed, or who are looking to switch careers should read this book. This book will be most relevant to those living in the United States, or those countries that have similar standards and methods as the USA.

## How this book is arranged

This book is arranged in a chronological manner. The first section deals with finding job prospects, and doing research on companies. The second section deals with writing a resume and a cover letter. The third section deals with the interview process. Finally, the fourth section deals with evaluating an offer. Additional information and resources can be found in the appendix.

## Job search is a job

It often takes months of time and effort to find a job that matches your qualifications and desires. Actively pursuing multiple leads will maximize your search efforts and reduce the time it takes you to find employment. This means devoting as much time as you can to your job search. If you are unemployed, treat your job search like a full-time job, waking up early and working a full day. If you are working or in school, it is still important to devote time every day to your job search.

Inform people you know that you are looking for a job. Read the classified ads. Use the Internet, including general job search sites, special interest sites, company Web sites, and trade and professional association Web sites. Directly contact employers in which you are interested, even if they are not advertising a job opening. You may also wish to consult State employment service offices and to consider private employment agencies.

  


Getting Started

  


  


# Your Career

**[Find Employment](/wiki/Find_Employment)**

## Consider Your Career

Our careers take up a large part of our lives. Not only do they provide us with money in exchange for our time, skills, and services, but they also are a place where we spend a large part of our time. Being in a career that is a good fit for you can be one of the most positive things you do for your life, and vice-versa, being in a career that is a bad fit, can be something that makes your life miserable.

At the time you are looking for employment you may want to consider your career as a whole. Are you on the right path for you? If you want a change now might be a good time to make it. Like any major decision, deciding a career involves a lot of fact finding. Fortunately, some of the best informational resources are easily accessible. You should assess career guidance materials carefully. Information that seems out of date or glamorizes an occupation, overstates its earnings or exaggerates the demand for workers, for example, should be evaluated with scepticism. Gathering as much information as possible will help you make a more informed decision. A [decision matrix](//en.wikipedia.org/wiki/Decision_Matrix) may be a useful tool to help make your decision. You may also wish to pursue more than one career option at the same time.

## Some Factors to Consider

  * Income
  * Health Benefits
  * Retirement Benefits
  * Other Benefits
  * Personal Satisfaction
  * Style of Work
  * Stress Load

## Resources that may Help while Researching Career Options

### Ask People You Know about Careers

One of the best resources can be those you know, such as friends and family. They may answer some questions about a particular occupation or put you in touch with someone who has some experience in the field. This personal networking can be invaluable in evaluating an occupation or an employer. These people will be able to tell you about their specific duties and training, as well as what they did or did not like about a job. People who have worked in an occupation locally also may be able to recommend and get you in touch with specific employers. These same people can also help you get a job later through networking.

### School career planning and placement offices

Many high schools and colleges have placement offices that have materials about career options. Many also have counsellors that you can talk with about potential careers.

### Employers

Through your library and Internet research, develop a list of potential employers in your desired career field. Employer Web sites often contain lists of job openings. Web sites and business directories can provide you with information on how to apply for a position or whom to contact. Even if no open positions are posted, do not hesitate to contact the employer and the relevant department. Set up an interview with someone working in the same area in which you wish to work. Ask them how they got started, what they like and dislike about the work, what type of qualifications are necessary for the job, and what type of personality succeeds in that position. Not only can this be invaluable in helping you to decide whether this career path is right for you, it also might open up doors for getting a job with the company in the future, or they may be able to put you in contact with other people who might hire you. Make sure to send them your resume and a cover letter. If you are able to obtain an interview, be sure to send a thank-you note. Directly contacting employers is one of the most successful means of job hunting.

### Internet Resources

While the Internet contains a lot of resources to help you get a specific job, it also contains a lot of good information that can help you choose a general career path.

  * <http://www.world-jobs.org>
  * www.calmis.ca.gov/codefinder/codefinder.htm
  * www.payscale.com
  * www.salary.com
  * online.onetcenter.org
  * www.labormarketinfo.edd.ca.gov
  * www.bls.gov
  * www.indeed.com
  * www.CACareerZone.org

  


# Education and Training

**[Find Employment](/wiki/Find_Employment)**

## Education

Education can open doors for those looking to start a new career or change specialty within their current occupation. This section outlines some major sources of education and training required to enter many occupations.

For information on the specific training and educational requirements for a particular occupation, and what training is typically provided by an employer, consult the Training, Other Qualifications, and Advancement section of the appropriate Handbook statement.

### Disclaimer

Links to non-BLS Internet sites are provided for your convenience and do not constitute an endorsement.

## Four-Year colleges and universities

These institutions provide detailed information on theory and practice for a wide variety of subjects. Colleges and universities can provide one with the knowledge and background necessary to be successful in many fields. They also can help to place students in cooperative education programs often called "co-ops" or internships. Co-ops and internships are short-term jobs with firms related to one's field of study that lead to college credit. In co-ops and internships, students learn the specifics of a job while making valuable contacts that can lead to a permanent position.

For more information on colleges and universities, go to your local library, consult your high school guidance counselor, or contact individual colleges. Also check with your State's higher education agency. A list of these agencies is available on the Internet: <http://www.ed.gov/Programs/EROD>.

## Junior and community colleges

Junior and community colleges offer a mixture of programs that lead to associate degrees and training certificates. Community colleges tend to be less expensive than 4-year colleges and universities. They typically are more willing to accommodate part-time students, and their programs are more tailored to the needs of local employers. Many have an open admissions policy, and often these institutions offer weekend and night classes.

Many community colleges form partnerships with local businesses that allow students to gain job-specific training. For students who may not be able to enroll in a college or university because of their academic record, limited finances, or distance from such an institution, junior or community colleges are often used as a place to earn credits that can be applied toward a degree at a 4-year college. Junior and community colleges also are noted for their extensive role in continuing an adult education.

For more information on junior and community colleges, go to your local library, consult your high school guidance counselor, or contact individual schools. Also check with your State's higher education agency. A list of these agencies is available on the Internet: <http://www.ed.gov/Programs/EROD>.

Note that many community colleges hire based on enrollment, and may add course sections based on student demand in the weeks immediately before a semester begins. Adjuncts are often contacted immediately prior to the first week of classes, even if they have submitted applications months earlier.

## Vocational and trade schools

These institutions train people in specific trades. They offer courses designed to provide hands-on experience. Vocational and trade schools tend to concentrate on trades, services, and other types of skilled work.

Vocational and trade schools frequently engage students in real-world projects, allowing them to apply field methods while learning theory in classrooms. Graduates of vocational and trade schools have an advantage over informally trained or self-trained job seekers because graduates have an independent organization certifying that they have the knowledge, skills, and abilities necessary to perform the duties of a particular occupation. These schools also help students to acquire any license or other credentials needed to enter the job market.

For more information on vocational and trade schools, go to your local library, consult your high school guidance counselor, or contact individual schools. Also check with your State's director of vocational-technical education. A list of State directors of vocational-technical education is available on the Internet: <http://www.ed.gov/Programs/EROD>.

## Apprenticeships

An apprenticeship provides work experience as well as education and training for those entering certain occupations. Apprenticeships are offered by sponsors, who employ and train the apprentice. The apprentice follows a training course under close supervision and receives some formal education to learn the theory related to the job.

Apprenticeships are a way for inexperienced people to become skilled workers. Apprenticeships are an agreement between the apprentice and the sponsor and generally last between 1 and 4 years. Some apprenticeships allow the apprentice to earn an associate degree. An Apprenticeship Completion Certificate is granted to those completing programs. This certificate is administered by federally approved State agencies.

Information on apprenticeships is available from the Office of Apprenticeship Training, Employer, and Labor Services on the Internet: <http://www.dir.ca.gov/databases/das/aigstart.asp>. For assistance finding an apprenticeship program, go to: <http://www.electricianprograms.org/electro/apprenticeships-they-are-alive-and-well-and-right-in-your-backyard.html>.

## Professional Groups

Professional societies, trade associations, and labor unions are other useful sources of information. These groups are made up of people with common interests, usually in related occupations or industries. The groups frequently are able to provide training, access to training through their affiliates, or information on acceptable sources of training for their field. If licensing or certification is required, they also may be able to assist you in meeting those requirements.

For a listing of professional societies, trade associations, and labor unions related to an occupation, check the Sources of Additional Information section at the end of that occupational statement in the Handbook.

Employers. Many employers provide on-the-job training. On-the-job training can range from spending a few minutes watching another employee demonstrate a task to participating in formal training programs that may last for several months. In some jobs, employees may continually undergo training to stay up to date with new developments and technologies, or to add new skills.

## Military

The United States Armed Forces trains and employs people in more than 4,100 different occupations. For more information, see the Handbook statement on "Job Opportunities in The Armed Forces." For detailed answers to specific questions, contact your local recruiting office. Valuable resources also are available on the Internet: <http://www.todaysmilitary.com>.

  


# Financial Aid

**[Find Employment](/wiki/Find_Employment)**

## Funding

Many people fund their education or training through financial aid or tuition assistance programs. Federal student aid comes in three forms�grants, work-study programs, and loans. All Federal student aid applicants must first fill out a Free Application for Federal Student Aid (FAFSA), which provides a Student Aid Report (SAR) and eligibility rating. Forms must be submitted to desired institutions of study, which determine the amount of aid you will receive.

For information on applying for Federal financial aid, visit the FAFSA Internet site: <http://www.fafsa.ed.gov>.

A U.S. Department of Education publication describing Federal financial aid programs, called The Student Guide, is available at: <http://www.studentaid.ed.gov/> students/publications/student_guide/index.html.

Information on Federal programs is available from: <http://www.studentaid.ed.gov> and <http://www.students.gov>.

Information on State programs is available from your State�s higher education agency. A list of these agencies is available at: <http://wdcrobcolp01.ed.gov/Programs/EROD/>.

## Grants

A grant is money which is given to a student or the institution they are attending in order to pay for their education or training and any associated expenses. Grants are typically given on the basis of financial need. Grants are considered gifts and are not paid back. Federal grants are almost exclusively for undergraduate students. They include Pell Grants, which can be worth up to $4,050 annually, and Federal Supplemental Educational Opportunity Grants (FSEOG), which can be worth up to $4,000 annually. Priority for FSEOG awards is given to those who have also received the Pell Grant and have exceptional financial need.

Additional information on grants is available on the Internet: <http://www.studentaid.ed.gov>.

Information also is available from your State Higher Education agency. A list of these agencies is available at: <http://wdcrobcolp01.ed.gov/Programs/EROD/>.

## Federal Work-Study program

The Federal Work-Study program is offered at most institutions and consists of Federal sponsorship of a student who works part time at the institution he or she is attending. The money a student earns through this program goes directly toward the cost of attending the institution. There are no set minimum or maximum amounts for this type of aid, although, on average, a student can expect to earn about $2,000 per school year.

For additional information on work-study opportunities offered, check with individual institutions. General information on the Federal Work-Study program is available at: <http://www.studentaid.ed.gov/students/publications/> student_guide/2005-2006/english/types-fed-workstudy.htm.

## Scholarships

A scholarship is a sum of money donated to a student to help pay for his or her education or training and any associated costs. Scholarships can range from small amounts up to the full cost of schooling. They are based on financial need, academic merit, athletic ability, or a wide variety of other criteria set by the organizations that provide the scholarships. Frequently, students must meet minimum academic requirements to be considered for a scholarship. Other qualifying requirements�such as intended major field of study, heritage, or group membership�may be added by the organization providing the scholarship.

Scholarships can be provided by a wide variety of institutions, including educational institutions, State and local governments, private associations, social groups, and individuals. There are no federally awarded scholarships based on academic merit. Most large scholarships are awarded to students by the institution they plan to attend. Students who have received State scholarships and plan to attend a school in another State should check with their State to see if the scholarship can be transferred.

Information on scholarships is typically available from high school guidance counselors and local libraries. Additional scholarship information is available from State higher education agencies. A list of these agencies is available at: <http://wdcrobcolp01.ed.gov/Programs/EROD/>. The College Board has information on available scholarships at: <http://www.collegeboard.com/pay>.

## Student loans

Many institutions, both public and private, provide low-interest loans to students and their parents or guardians. The Federal Government also provides several types of student loans based on the applicant�s level of financial need. The amount of money a student can receive in loans varies by the distributing institution and depends on whether the student is claimed by a parent or guardian as a dependent. Since the process of applying for a loan may take several months, it is a good idea to start applying for Federal student loans well in advance.

The available Federal loan programs can accommodate prospective undergraduate, graduate, vocational, and disabled students. Federal loans can be distributed through the school that the student is attending, from the Federal Government directly, or from a third-party private lender or bank. Perkins loans are distributed through the school the student is attending. Loans coming from the Federal Government directly from the William D. Ford Federal Direct Loan Program are dispersed by the Department of Education. Third-party loans through a private lender or bank are from the Federal Family Education Loan (FFEL) program. For all federally funded loans, payments are made to the institution that originally dispersed the funds.

For those with financial need, Federal Perkins loans and both Direct and FFEL-subsidized Stafford loans are available. Perkins loans have no minimum amount, but they are capped at $4,000 per year for undergraduates and $6,000 per year for graduate students. Subsidized Stafford loans can range in value from $2,625 to $8,500 per year and can increase as a student completes more years of undergraduate, graduate, or professional education. Interest rates remain at a flat 5 percent for all Perkins loans, while rates can fluctuate up to 8.25 percent for subsidized Stafford loans. Those with Perkins loans are not responsible for starting to repay the loan until they have been out of school for 9 months. Those with subsidized Stafford loans must begin payments within 6 to 9 months of leaving school but are not charged monthly interest while in school.

For those who do not demonstrate financial need, Direct and FFEL-unsubsidized Stafford Loans and Federal Parent Loans for Students (PLUS) are available. Unsubsidized Stafford loans can range in value from $2,625 to $18,500 per year. PLUS loans are capped at the cost of attendance. With Federal unsubsidized Stafford Loans, interest payments start almost immediately and can be paid monthly or accrued until the completion of studies. The latter option results in a larger total loan cost but may be more convenient for some students. With PLUS loans, the parent must pay interest and principal payments while the student is enrolled in school and must continue payments after completion. Check with your lender for available repayment schedules. Typically, students have 10 years to repay Perkins loans and from 10 to 30 years for unsubsidized Stafford loans.

Subsidized and unsubsidized Stafford loans are only available to students who are enrolled in an academic program at least half time. As with any loan, be sure to investigate different lenders, and understand what your loan contract requires of you before agreeing to any loan. Check with established financial institutions to compare the terms of available private student loans. Comparisons of the various types of loans are available on the Internet: <http://www.studentaid.ed.gov/students/publications/student_guide/index.html>.

The College Board has information on available loans at: <http://www.collegeboard.com/pay>.

## Employer tuition support programs

Some employers offer tuition assistance programs as part of their employee benefits package. The terms of these programs depend on the firm and can vary by the type and amount of training subsidized, as well as by eligibility requirements. Consult your human resources department for information on tuition support programs offered by your employer.

Military tuition support programs. The United States Armed Forces offer various tuition assistance and loan repayment programs for military personnel. See the Handbook statement on "Job Opportunities in the Armed Forces" for more information. Also go to:

  * <http://www.todaysmilitary.com/wyg/t5_wyg_tuitionsupport.php>.

  


# Find Prospects

**[Find Employment](/wiki/Find_Employment)**

## Find Prospects

Before you can go to an interview, or even mail out a resume, you need to find companies (with job openings) where you are interested in working. Traditional methods of finding prospective employers is to look at the classified ads in the newspapers, look through job-hunting magazines and periodicals, or even attend career-fairs. Modern methods for finding jobs involve the internet, and sites such as careerbuilder.com and monster.com.

## Research the Employer

Study the prospective employer. Research for information about the employer's policies, scope of operations, and work culture. Find out what skills are in demand, and can get you hired. Find out what salaries are paid to people in the position, which you have applied for. This information helps in negotiations at a later stage. Many professional websites also have lists of Job openings. It is always preferable to apply to a specific job. Submitting a resume that is not in response to a specific job opening is known as **cold submitting**, and has a low chance of success.

Once you find the specific job opening (or openings) that you are interested in applying for, copy down the relevant information: You are going to need it to write an effective cover letter, and to focus your resume.

After reviewing your research, create questions to ask your prospective employer. These questions will display your initiative and your interest in the company.

## Networking

Eighty percent of available jobs are never advertised, and over half of all employees get their jobs through networking, according to BH Careers International. Therefore, the people you know -friends, family, neighbors, acquaintances, teachers, and former co-workers - are some of the most effective resources for your job search. The network of people that you know and the people that they know can lead to information about specific job openings that are not publicly posted. To develop new contacts, join student, community, or professional organizations.

## Career Fairs

Career fairs are great places to submit resumes, talk to company representatives, and to gather valuable contact information. However, because of the nature of career fairs, it can be difficult to provide a focused resume and cover letter to every company in attendance. Often times, you are forced to simply create a generic resume that you will hand to every company. Also, representatives at career fairs receive many resumes, and many applications, and often times the representatives don't have the time to carefully read each one. If your resume doesn't stand out from the pile immediately (and you shouldn't suspect that it will), then you may never hear back from the company. The most important job that you can do at a job fair is to gather contact information for the human resources personnel at the target company. After the job fair is over, you should create a focused resume and cover letter specifically for that company, and mail (or email) those materials directly to the HR department. This will ensure that your resume stands out from the crowd, and that the HR people are forced to look at your resume closely, after the career fair has ended.

## Personal contacts

Eighty percent of available jobs are never advertised, and over half of all employees get their jobs through networking, according to BH Careers International. Therefore, the people you know — friends, family, neighbors, acquaintances, teachers, and former co-workers — are some of the most effective resources for your job search. The network of people that you know and the people that they know can lead to information about specific job openings that are not publicly posted. To develop new contacts, join student, community, or professional organizations.

School career planning and placement offices. High school and college placement offices help their students and alumni find jobs. They allow recruiters to use their facilities for interviews or career fairs. Placement offices usually have a list of part-time, temporary, and summer jobs offered on campus. They also may have lists of jobs for regional, non-profit, and government organizations. In addition to linking you to potential employers, career planning offices usually provide career counselling, career testing, and job search advice. Some have career resource libraries; host workshops on job search strategy, résumé writing, letter writing, and effective interviewing; critique drafts of résumés; conduct mock interviews; and sponsor job fairs.

## Employers

Through your library and Internet research, develop a list of potential employers in your desired career field. Employer Web sites often contain lists of job openings. Web sites and business directories can provide you with information on how to apply for a position or whom to contact. Even if no open positions are posted, do not hesitate to contact the employer and the relevant department. Set up an interview with someone working in the same area in which you wish to work. Ask them how they got started, what they like and dislike about the work, what type of qualifications are necessary for the job, and what type of personality succeeds in that position. Even if they don’t have a position available, they may be able to put you in contact with other people who might hire you, and they can keep you in mind if a position opens up. Make sure to send them your résumé and a cover letter. If you are able to obtain an interview, be sure to send a thank-you note. Directly contacting employers is one of the most successful means of job hunting.

## Classified ads

The "Help Wanted" ads in newspapers list numerous jobs. You should realize, however, that many other job openings are not listed, and that the classified ads sometimes do not give all of the important information. They may offer little or no description of the job, working conditions, or pay. Some ads do not identify the employer. They may simply give a post office box to which you can mail your résumé, making follow-up inquiries very difficult. Some ads offer out-of-town jobs; others advertise employment agencies rather than actual employment opportunities.

When using classified ads, keep the following in mind:

  * Do not rely solely on the classifieds to find a job; follow other leads as well.
  * Answer ads promptly, because openings may be filled quickly, even before the ad stops appearing in the paper.
  * Read the ads every day, particularly the Sunday edition, which usually includes the most listings.
  * Beware of "no experience necessary" ads. These ads often signal low wages, poor working conditions, or commission work.
  * Keep a record of all ads to which you have responded, including the specific skills, educational background, and personal qualifications required for the position.

## Internet networks and resources

The Internet is an invaluable resource. Use it to find advice on conducting your job search more effectively; to search for a job; to research prospective employers; and to communicate with people who can help you with your job search. No single Web site will contain all the information available on employment or career opportunities, so in addition to the Web sites listed below, use a search engine to find what you need. The different types of sites that may be useful include general career advice sites, job search sites, company Web sites, trade and professional association Web sites, and forums. Internet forums, also called message boards, are online discussion groups where anyone may post and read messages. Use forums specific to your profession or to career-related topics to post questions or messages and to read about other peoples’ job searches or career experiences.

In job databases, remember that job listings may be posted by field or discipline, so begin your search using keywords. Some Web sites provide national or local classified listings and allow job seekers to post their résumés online. When searching employment databases on the Internet, it usually is possible to send your résumé to an employer by e-mail or to post it online.

CareerOneStop is a database consisting of three separate career resource tools. It can be accessed on the Internet at: <http://www.CareerOneStop.org>, or by telephone at: (877) 348-0502. Alternatively, each resource tool can be accessed directly at its own Internet address.

America’s Job Bank allows you to search through a database of more than 1 million jobs nationwide, create and post your résumé online, and set up an automated job search. The database contains a wide range of mostly full-time private sector jobs that are available all over the country. Job seekers can access America’s Job Bank at: <http://www.ajb.org>.

America’s Career InfoNet provides information on educational, licensing, and certification requirements for different occupations by State. It also provides information on wages, cost of living, and employment trends, and helps job seekers identify their skills and write résumés and cover letters. Job seekers can access America’s Career InfoNet at: <http://www.acinet.org>.

America’s Service Locator provides listings of local employment service offices which help job seekers find jobs and help employers find qualified workers at no cost to either. At the State employment service office, an interviewer will determine if you are "job ready" or if you need help from counselling and testing services to assess your occupational aptitudes and interests and to help you choose and prepare for a career. After you are "job ready," you may examine available job listings and select openings that interest you. A staff member can then describe the job openings in detail and arrange for interviews with prospective employers. Job seekers can access America’s Service Locator at: <http://www.servicelocator.org>. A list of offices is also in the State government telephone listings under "Job Service" or "Employment."

Using Internet Resources to Plan your Future, a U.S. Department of Labor publication, offers advice on organizing your Internet job search. It is primarily intended to provide instruction for job seekers on how to use the Internet to their best advantage, but recruiters and other career service industry professionals will find information here to help them also. How to Use the Internet in your Job Search; The Job Search Process; and the Career-Related Pages, other U.S. Department of Labor Internet publications, each discusses specific steps that job seekers can follow to identify employment opportunities. Included are daily tips and hints, plus a large database of links and job search engines. Check with your State employment service office, or order a copy of these and other publications from the U.S. Government Printing Office’s Superintendent of Documents. Telephone: (202) 512-1800. Internet: <http://bookstore.gpo.gov> or <http://www.doleta.gov>.

## State employment service offices

The State employment service, sometimes called the Job Service, operates in coordination with the U.S. Department of Labor’s Employment and Training Administration. Local offices, found nationwide, help job seekers to find jobs and help employers to find qualified workers at no cost to either. To find the office nearest you, look in the State government telephone listings under "Job Service" or "Employment."

Job matching and referral. At the State employment service office, an interviewer will determine if you are "job ready" or if you need help from counselling and testing services to assess your occupational aptitudes and interests and to help you choose and prepare for a career. After you are "job ready," you may examine available job listings and select openings that interest you. A staff member can then describe the job openings in detail and arrange for interviews with prospective employers.

Services for special groups. By law, veterans are entitled to priority for job placement at State employment service centers. If you are a veteran, a veterans’ employment representative can inform you of available assistance and help you to deal with problems.

State employment service offices refer people to opportunities available under the Workforce Investment Act (WIA) of 1998. WIA reforms Federal employment, adult education, and vocational rehabilitation programs to create an integrated, "one-stop" system of workforce investment and education activities for adults and youths. Services are provided to employers and job seekers, including adults, dislocated workers, and youths. WIA's primary purpose is to increase the employment, retention, skills, and earnings of participants. These programs help to prepare people to participate in the State's workforce, increase their employment and earnings potential, improve their educational and occupational skills, and reduce their dependency on welfare, which will improve the quality of the workforce and enhance the productivity and competitiveness of the Nation's economy.

We have more information on these services in the appendix.

## Federal Government

Information on obtaining a position with the Federal Government is available from the U.S. Office of Personnel Management (OPM) through USAJOBS, the Federal Government’s official employment information system. This resource for locating and applying for job opportunities can be accessed through the Internet at <http://www.usajobs.opm.gov> or through an interactive voice response telephone system at (703) 724-1850 or TDD (978) 461-8404. These numbers are not tollfree, and charges may result.

## Professional associations

Many professions have associations that offer employment information, including career planning, educational programs, job listings, and job placement. To use these services, associations usually require that you be a member; information can be obtained directly from an association through the Internet, by telephone, or by mail.

## Labor unions

Labor unions provide various employment services to members, including apprenticeship programs that teach a specific trade or skill. Contact the appropriate labor union or State apprenticeship council for more information.

Private employment agencies and career consultants. These agencies can be helpful, but they may charge you for their services. Most operate on a commission basis, with the fee dependent upon a percentage of the salary paid to a successful applicant. You or the hiring company will pay the fee. Find out the exact cost and who is responsible for paying associated fees before using the service.

Although employment agencies can help you save time and contact employers who otherwise might be difficult to locate, the costs may outweigh the benefits if you are responsible for the fee. Contacting employers directly often will generate the same type of leads that a private employment agency will provide. Consider any guarantees that the agency offers when determining if the service is worth the cost.

## Community agencies

Many non-profit organizations, including religious institutions and vocational rehabilitation agencies, offer counselling, career development, and job placement services, generally targeted to a particular group, such as women, youths, minorities, ex-offenders, or older workers.

## School career planning and placement offices

High school and college placement offices help their students and alumni find jobs. They allow recruiters to use their facilities for interviews or career fairs. Placement offices usually have a list of part-time, temporary, and summer jobs offered on campus. They also may have lists of jobs for regional, non-profit, and government organizations. In addition to linking you to potential employers, career planning offices usually provide career counselling, career testing, and job search advice. Some have career resource libraries; host workshops on job search strategy, resume writing, letter writing, and effective interviewing; critique drafts of resumes; conduct mock interviews; and sponsor job fairs.

## Internet networks and resources

The Internet is an invaluable resource. Use it to find advice on conducting your job search more effectively; to search for a job; to research prospective employers; and to communicate with people who can help you with your job search. No single Web site will contain all the information available on employment or career opportunities, so in addition to the Web sites listed below, use a search engine to find what you need. The different types of sites that may be useful include general career advice sites, job search sites, company Web sites, trade and professional association Web sites, and forums. Internet forums, also called message boards, are online discussion groups where anyone may post and read messages. Use forums specific to your profession or to career-related topics to post questions or messages and to read about other peoples' job searches or career experiences.

In job databases, remember that job listings may be posted by field or discipline, so begin your search using keywords. Some Web sites provide national or local classified listings and allow job seekers to post their resumes online. When searching employment databases on the Internet, it usually is possible to send your resume to an employer by e-mail or to post it online.

CareerOneStop is a database consisting of three separate career resource tools. It can be accessed on the Internet at: <http://www.CareerOneStop.org>, or by telephone at: (877) 348-0502. Alternatively, each resource tool can be accessed directly at its own Internet address.

America's Job Bank allows you to search through a database of more than 1 million jobs nationwide, create and post your resume online, and set up an automated job search. The database contains a wide range of mostly full-time private sector jobs that are available all over the country. Job seekers can access America's Job Bank at: <http://www.ajb.org>.

America's Career InfoNet provides information on educational, licensing, and certification requirements for different occupations by State. It also provides information on wages, cost of living, and employment trends, and helps job seekers identify their skills and write resumes and cover letters. Job seekers can access America's Career InfoNet at: <http://www.acinet.org>.

America's Service Locator provides listings of local employment service offices which help job seekers find jobs and help employers find qualified workers at no cost to either. At the State employment service office, an interviewer will determine if you are "job ready" or if you need help from counselling and testing services to assess your occupational aptitudes and interests and to help you choose and prepare for a career. After you are "job ready," you may examine available job listings and select openings that interest you. A staff member can then describe the job openings in detail and arrange for interviews with prospective employers. Job seekers can access America's Service Locator at: <http://www.servicelocator.org>. A list of offices is also in the State government telephone listings under "Job Service" or "Employment."

Using Internet Resources to Plan your Future, a U.S. Department of Labor publication, offers advice on organizing your Internet job search. It is primarily intended to provide instruction for job seekers on how to use the Internet to their best advantage, but recruiters and other career service industry professionals will find information here to help them also. How to Use the Internet in your Job Search; The Job Search Process; and the Career-Related Pages, other U.S. Department of Labor Internet publications, each discusses specific steps that job seekers can follow to identify employment opportunities. Included are daily tips and hints, plus a large database of links and job search engines. Check with your State employment service office, or order a copy of these and other publications from the U.S. Government Printing Office's Superintendent of Documents. Telephone: (202) 512-1800. Internet: <http://bookstore.gpo.gov> or <http://www.doleta.gov>.

## Federal Government

Information on obtaining a position with the Federal Government is available from the U.S. Office of Personnel Management (OPM) through USAJOBS, the Federal Government's official employment information system. This resource for locating and applying for job opportunities can be accessed through the Internet at <http://www.usajobs.opm.gov> or through an interactive voice response telephone system at (703) 724-1850 or TDD (978) 461-8404. These numbers are not tollfree, and charges may result.

## Professional associations

Many professions have associations that offer employment information, including career planning, educational programs, job listings, and job placement. To use these services, associations usually require that you be a member; information can be obtained directly from an association through the Internet, by telephone, or by mail.

## Labor unions

Labor unions provide various employment services to members, including apprenticeship programs that teach a specific trade or skill. Contact the appropriate labor union or State apprenticeship council for more information.

## Private employment agencies, career consultants

These agencies can be helpful, but they may charge you for their services. Most operate on a commission basis, with the fee dependent upon a percentage of the salary paid to a successful applicant. You or the hiring company will pay the fee. Find out the exact cost and who is responsible for paying associated fees before using the service.

Although employment agencies can help you save time and contact employers who otherwise might be difficult to locate, the costs may outweigh the benefits if you are responsible for the fee. Contacting employers directly often will generate the same type of leads that a private employment agency will provide. Consider any guarantees that the agency offers when determining if the service is worth the cost.

## Community agencies

Many non-profit organizations, including religious institutions and vocational rehabilitation agencies, offer counselling, career development, and job placement services, generally targeted to a particular group, such as women, youths, minorities, ex-offenders, or older workers.

## State employment service offices

The State employment service, sometimes called the Job Service, operates in coordination with the U.S. Department of Labor's Employment and Training Administration. Local offices, found nationwide, help job seekers to find jobs and help employers to find qualified workers at no cost to either. To find the office nearest you, look in the State government telephone listings under "Job Service" or "Employment."

Job matching and referral. At the State employment service office, an interviewer will determine if you are "job ready" or if you need help from counselling and testing services to assess your occupational aptitudes and interests and to help you choose and prepare for a career. After you are "job ready," you may examine available job listings and select openings that interest you. A staff member can then describe the job openings in detail and arrange for interviews with prospective employers.

Services for special groups. By law, veterans are entitled to priority for job placement at State employment service centers. If you are a veteran, a veterans' employment representative can inform you of available assistance and help you to deal with problems.

State employment service offices refer people to opportunities available under the Workforce Investment Act (WIA) of 1998. WIA reforms Federal employment, adult education, and vocational rehabilitation programs to create an integrated, "one-stop" system of workforce investment and education activities for adults and youths. Services are provided to employers and job seekers, including adults, dislocated workers, and youths. WIA's primary purpose is to increase the employment, retention, skills, and earnings of participants. These programs help to prepare people to participate in the State's workforce, increase their employment and earnings potential, improve their educational and occupational skills, and reduce their dependency on welfare, which will improve the quality of the workforce and enhance the productivity and competitiveness of the Nation's economy.

## Research

Local libraries. Libraries can be an invaluable source of information. Since most areas have libraries, they can be a convenient place to look for information. Also, for those who do not otherwise have access to the Internet or e-mail, many libraries provide this access.

Libraries may have information on job openings, locally and nationally; potential contacts within occupations or industries; colleges and financial aid; vocational training; individual businesses or careers; and writing resumes. Libraries frequently have subscriptions to various trade magazines that can provide information on occupations and industries. These sources often have references to organizations which can provide additional information about training and employment opportunities. Your local library also may have video materials.

If you need help getting started or finding a resource, ask your librarian for assistance.

## Professional Groups

These groups, such as professional societies, trade groups, and labor unions have information on an occupation or various related occupations with which they are associated or which they actively represent. This information may cover training requirements, earnings, and listings of local employers. These groups may train members or potential members themselves, or may be able to put you in contact with organizations or individuals who perform such training.

Each occupational statement in the Handbook concludes with a section on sources of additional information, which lists organizations that may be contacted for more information. Another valuable source for finding organizations associated with occupations is The Encyclopedia of Associations, an annual publication that lists trade associations, professional societies, labor unions, and fraternal and patriotic organizations.

Employers. This is the primary source of information on specific jobs. Employers may post lists of job openings and application requirements, including the exact training and experience required, starting wages and benefits, and advancement opportunities and career paths.

## Postsecondary institutions

Colleges, universities, and other postsecondary institutions may put a lot of effort into helping place their graduates in good jobs, because the success of their graduates may indicate the quality of their institution and may affect their ability to attract new students. Postsecondary institutions frequently have career centers with libraries of information on different careers, listings of related jobs, and alumni contacts in various professions. Career centers frequently employ career counsellors who generally provide their services only to their students and alumni. Career centers can help you build your resume; find internships and co-ops which can lead to full-time positions; and tailor your course selection or program to make you a more attractive job applicant.

## Guidance and career counsellors

Counsellors can help you make choices about which careers might suit you best. Counsellors can help you determine what occupations suit your skills by testing your aptitude for various types of work, and determining your strengths and interests. Counsellors can help you evaluate your options and search for a job in your field or help you select a new field altogether. They can also help you determine which educational or training institutions best fit your goals, and find ways to finance them. Some counsellors offer other services such as interview coaching, resume building, and help in filling out various forms. Counsellors in secondary schools and postsecondary institutions may arrange guest speakers, field trips, or job fairs.

Common places where guidance and career counsellors are employed include:

  * High school guidance offices
  * College career planning and placement offices
  * Placement offices in private vocational or technical schools and institutions
  * Vocational rehabilitation agencies
  * Counselling services offered by community organizations
  * Private counselling agencies and private practices
  * State employment service offices

When using a private counsellor, check to see if the counsellor is experienced. One way to do so is to ask people who have used their services in the past. The National Board of Certified Counsellors and Affiliates is an institution which accredits career counsellors. To verify the credentials of a career counsellor and to find a career counsellor in your area, contact:

  * The National Board for Certified Counsellors and Affiliates, 3 Terrace Way, Suite D, Greensboro, NC 27403-3660. Internet: <http://www.nbcc.org/cfind>

Internet resources. With the growing popularity of the Internet, a wide verity of career information has become easily accessible. Many online resources include job listings, resume posting services, and information on job fairs, training, and local wages. Many of the resources listed elsewhere in this section have Internet sites that include valuable information on potential careers. Since no single source contains all information on an occupation, field, or employer, you will likely need to use a variety of sources.

When using Internet resources, be sure that the organization is a credible, established source of information on the particular occupation. Individual companies may include job listings on their Web sites, and may include information about required credentials, wages and benefits, and the job's location. Contact information, such as whom to call or where to send a resume, is typically included.

Some sources exist primarily as a Web service. These services often have information on specific jobs, and can greatly aid in the job hunting process. Some commercial sites offer these services, as do Federal, State, and some local governments. Career OneStop, a joint program by the Department of Labor and the States as well as local agencies, provides these services free of charge.

Online Sources from the Department of Labor. A major portion of the U.S. Department of Labor's Labor Market Information System is the Career OneStop site. This site includes:

  * America's Job Bank allows you to search over a million job openings listed with State employment agencies.
  * America's Career InfoNet provides data on employment growth and wages by occupation; the knowledge, skills, and abilities required by an occupation; and links to employers.
  * America's Service Locator is a comprehensive database of career centers and information on unemployment benefits, job training, youth programs, seminars, educational opportunities, and disabled or older worker programs.

Career OneStop, along with the National Tollfree Helpline (877-USA-JOBS) and the local One-Stop Career Centers in each State, combine to provide a wide range of workforce assistance and resources:

  * Career OneStop. Internet: <http://www.careeronestop.org>

Use the O*NET numbers at the start of each Handbook statement to find more information on specific occupations:

  * O*NET Online. Internet: <http://www.onetcenter.org/>

Provided in collaboration with the U.S. Department of Education, Career Voyages has information on certain high-demand occupations:

  * Career Voyages. Internet: <http://www.careervoyages.org>

The Department of Labor's Bureau of Labor Statistics publishes a wide range of labor market information, from regional wages for specific occupations to statistics on National, State, and area employment:

  * Bureau of Labor Statistics. Internet: <http://www.bls.gov>

While the Handbook discusses careers from an occupational perspective, a companion publication **Career Guide to Industries** discusses careers from an industry perspective. The Career Guide is also available at your local career center and library:

  * Career Guide to Industries. Internet: <http://www.bls.gov/oco/cg/home.htm>

For information on occupational wages:

  * Wage Data. Internet: <http://www.bls.gov/bls/blswage.htm>

For information on training, workers' rights, and job listings:

  * Education and Training Administration. Internet: <http://www.doleta.gov/jobseekers>

Organizations for specific groups. Some organizations provide information designed to help specific groups of people. Consult directories in your library's reference center or a career guidance office for information on additional organizations associated with specific groups.

## Summer Jobs

Doing summer job is a good experience for growth. However, remember that summer jobs are just that: temporary jobs that you have over the summer (or even during the school year), that don't necessarily help prepare you for future careers. This book will not talk specifically about part-time or seasonal jobs. However, many of the techniques from this book can be adapted to finding summer work. Further information about summer jobs can be found in the appendix.

## Disabled workers

State counselling, training, and placement services for those with disabilities are available from:

  * State Vocational Rehabilitation Agency. Internet: <http://www.ed.gov/Programs/EROD>

Information on employment opportunities, transportation, and other considerations for people with all types of disabilities is available from:

  * National Organization on Disability, 910 Sixteenth St. NW., Suite 600, Washington, DC 20006. Telephone: (202) 293-5960. TTY: (202) 293-5968. Internet: <http://www.nod.org/economic>

For information on making accommodations in the work place for people with disabilities:

  * Job Accommodation Network (JAN), P.O. Box 6080, Morgantown, WV 26506. Internet: <http://www.jan.wvu.edu>

A comprehensive Federal Web site of disability-related resources is accessible at:

  * <http://www.disabilityinfo.gov>

Blind workers:

Information on the free national reference and referral service for the blind can be obtained by contacting:

  * National Federation of the Blind, Job Opportunities for the Blind (JOB), 1800 Johnson St., Baltimore, MD 21230. Telephone: (410) 659-9314. Internet: <http://www.nfb.org>

Older workers:

  * National Council on the Aging, 300 D St. SW., Suite 801, Washington, DC 20024. Telephone: (202) 479-1200. Internet: <http://www.ncoa.org>
  * National Caucus and Center on Black Aged, Inc., Senior Employment Programs, 1220 L St. NW., Suite 800, Washington, DC 20005. Telephone: (202) 637-8400. Fax: (202) 347-0895. Internet: <http://www.ncba-aged.org>

## Veterans

Contact the nearest regional office of the U.S. Department of Labor's Veterans Employment and Training Service or:

  * Credentialing Opportunities Online (COOL), which explains how Army soldiers can meet civilian certification and license requirements related to their Military Occupational Specialty (MOS). Internet: <http://www.cool.army.mil/index.htm>

## Women

  * Department of Labor, Women's Bureau, 200 Constitution Ave. NW., Washington, DC 20210. Telephone: (800) 827-5335. Internet: <http://www.dol.gov/wb>

Federal laws, executive orders, and selected Federal grant programs bar discrimination in employment based on race, color, religion, sex, national origin, age, and handicap. Information on how to file a charge of discrimination is available from U.S. Equal Employment Opportunity Commission offices around the country. Their addresses and telephone numbers are listed in telephone directories under U.S. Government, EEOC. Telephone: (800) 669-4000. TTY: (800) 669-6820).

  * [EEOC](http://www.eeoc.gov)

Office of Personnel Management. Information on obtaining civilian positions within the Federal Government is available from the U.S. Office of Personnel Management through USAJobs, the Federal Government's official employment information system. This resource for locating and applying for job opportunities can be accessed through the Internet or through an interactive voice response telephone system at (703) 724-1850 or TDD (978) 461-8404. These numbers are not tollfree, and charges may result.

  * [USA Jobs](http://www.usajobs.opm.gov)

Military.The military employs and has information on hundreds of occupations. Information is available on the Montgomery G.I. Bill, which provides money for school and educational debt repayments. Information on military service can be provided by your local recruiting office. Also see the Handbook statement on Job Opportunities in the Armed Forces. For more information on careers in the military:

  * Today's Military. Internet: <http://www.todaysmilitary.com>

  


Apply

  


  


# About Resumes

**[Find Employment](/wiki/Find_Employment)**

## About Resumes

In your lifetime, you will be preparing many resumes of many types: education, job, true-love, health-treatment, legal-justifications, financial justifications, and others. So start with your MASTER RESUME. Then you can use to then cut-and-paste all the later needs for your immediate resume.

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

The correct spelling is: **résumé**, but due to difficulties in typing, the remainder of this book may ignore the accents.

If you ever need to use your life experiences for the human service industries, it might be worthwhile recording dates & places of any human-type activities: friends, clubs, etc. At a very serious job interview (the last of several for an important application, you can use a copy of this "Master" to illustrate or support the statements made in writing or spoken in any interview.

Resumes are usually just advertisements, that are supposed to sell your most valuable product: you. Resumes should be truthful, but they do not (and should not) be complete descriptions of you, your past, and your skills. Specifically, modern guidelines state that a resume should be 1 page long, no more, and generally no less. The resume should be specifically tailored to the job for which you are applying.

## Résumés and application forms

Résumés and application forms are two ways to provide employers with written evidence of your qualifications and skills. Generally, the same information appears on both the résumé and the application form, but the way in which it is presented differs. Some employers prefer a résumé and others require an application form. The accompanying box presents the basic information you should include in your résumé.

There are many ways of organizing a résumé; choose the format that best showcases your skills and experience. It may be helpful to look for examples on the Internet or in books at your local library or bookstore. Typically, an employer has a very limited amount of time to review your résumé. It is important to make sure it is clear and concise, and highlights your skills and experiences effectively through the use of formatting, ordering, and headings.

Many employers scan résumés into databases, which they then search for specific keywords or phrases. The keywords are usually nouns referring to experience, education, personal characteristics, or industry buzz words. Identify keywords by reading the job description and qualifications; use the same words in your résumé that are used in the job ad. For example, if the job description includes customer service tasks, use the words "customer service" on your résumé. Scanners sometimes misread paper résumés, which could mean some of your keywords don't get into the database. So, if you know that your résumé will be scanned, and you have the option, e-mail an electronic version. If you must submit a paper résumé, make it scannable by using a simple font and avoiding underlines, italics, and graphics. It is also a good idea to send a traditionally formatted résumé along with your scannable résumé, with a note on each marking its purpose.

When you fill out an application form, make sure you fill it out completely and follow all instructions. Do not omit any requested information and make sure that the information you provide is correct.

## Writing the Resume

Writing a résumé can often be a strenuous task because it is this piece of paper alone which will separate yourself from hundreds, if not thousands of other applicants.

When writing a résumé, one must be careful to make theirs stand out so that the prospective employer does not just throw it in a pile. A résumé should contain your name, previous employment history, skills, accomplishments and goals you wish to achieve in your life.

Avoid the use of prose when describing what you have accomplished in your current or previous jobs. Bullets are definitely your friend when it comes to sharing you accomplishments. Start each bullet point with a good, strong verb. If you have data to share, such as an increase in sales, a savings of money, or something similar, be sure to include this information. For example: Developed new training protocols resulting in a savings of $10,000 a year for the company.

## Warning

Studies have shown that employers often do not read entire résumés, but quickly scan through them. You have approximately 30-45 seconds to make an impression on a prospective employer - to make him or her want to read your résumé more closely. Therefore, you must make your résumé stand out from the rest. Think of a résumé as a marketing tool, and what you are selling is yourself. With this in mind, one must learn some basic marketing skills which will help produce leads (job interviews). In order to produce a good result, if done correctly, one will not have to be dishonest in his or her résumé, and often, being dishonest can later be a drawback for future promotions or possibly be grounds for termination.

## Focus

When writing your résumé, you must focus on the needs of your prospective employer, not yours. When selling yourself, you need to make yourself sound like a good buy and you need to present yourself as one who would benefit the company in the long-term. Now put yourself in the employer's shoes: what would make you want to hire a prospective candidate? What does the corporation really need? What would set yourself apart from the rest of the crowd? If you are looking for a job in an area that you are familiar with, you will probably know what employers in your field are already looking for. If you are unsure, you can find out from the tone of the help-wanted ad and by talking to people in the area that you wish to work in. Do not be afraid to call the employer and ask him or her what they are looking for in a candidate. This itself would show initiative on your part, and probably keep the employer thinking about you. It can also be a good idea to ask a prospective employer for a copy of the position description. By reviewing this document, you can tailor your resume to highlight how you can meet the needs of the company.

  


# Resume Sections

**[Find Employment](/wiki/Find_Employment)**

Resumes have a number of different sections, depending on the aspects that you want to illustrate about yourself. This page will talk about the different sections of a resume, and when to use each one.

## Styles of Resumes

Sometimes Resumes are categorized by how they present information and in what order they present information. Most resumes share certain common features, and there is not just one "right" way of doing a resume. If the resume gets you a job, then you did it right. The type of resume you choose to use determines which sections you will include and where you will put the sections.

### Chronological résumé

This is the most traditional type of resumes. They emphasize job experience and are good for people with a lot of experience in a given field who are entering back into the same field. They are called a "chronological" resume because they list your experience in sequence of time, from new to old.

### Functional résumé

A functional résumé lists work experience and skills sorted by skill area or job function.

The functional résumé is used to assert a focus to skills that are specific to the type of position being sought. This format directly emphasizes specific professional capabilities and utilizes experience summaries as its primary means of communicating professional competency. In contrast, the chronological résumé format will briefly highlight these competencies prior to presenting a comprehensive timeline of career growth via reverse-chronological listing with most recent experience listed first.

### Combination résumé

The combination résumé balances the functional and chronological approaches. A résumé organized this way typically leads with a functional list of job skills, followed by a chronological list of employers.

### Curriculum Vitae

In the United States, a CV is expected to include a comprehensive listing of professional history including every term of employment, academic credential, publication, contribution or significant achievement. In certain professions, it may even include samples of the person's work and may run to many pages.

Within the European Union, a standardised CV model known as Europass has been developed (in 2004 by the European Parliament) and promoted by the EU to ease skilled migration between member countries.

## What Usually Goes into a Resume

  * Name, address, e-mail address, and telephone number.
  * Employment objective. State the type of work or specific job you are seeking.
  * Education, including school name and address, dates of attendance, major, and highest grade completed or degree awarded. Consider including any courses or areas of focus that might be relevant to the position.
  * Experience, paid and volunteer. For each job, include the job title, name and location of employer, and dates of employment. Briefly describe your job duties.
  * Special skills, computer skills, proficiency in foreign languages, achievements, and membership in organizations.
  * References, only when requested.
  * Keep it short; only one page for less experienced applicants.
  * Avoid long paragraphs; use bullets to highlight key skills and accomplishments.
  * Have several people review your resume for any spelling or grammatical errors.
  * Print it on high quality paper.

## The Objective

Despite all the effort that you put into your resume, many employers may not read any further then the first section, before they decide if you are an interesting potential candidate or not. For this reason, many people choose to make the first section of the resume a statement about their value, and the reason why they would be a good addition to the company. This first section is generally titled the "Objective" section, although some templates will call this the "Purpose" section, or even the "Statement of Goals".

The objective section should state exactly what position you are applying for, and the reasons why you are a good fit for that position. For this reason, your objective section--if nothing else--should be specifically tailored to the job you are applying for.

## Work History

Nobody wants to read about the summer job you had during school, so that you could have some money in your pocket. The work history section is more aptly named the "Relevant Work Experiance" section, and should only contain job experiences that are relevant to the new business. For instance, if you spent several years as a tax preparer, it doesnt make sense to elaborate on that too much when applying for a job in designing computers. Of course, most people don't make such drastic career shifts in their lifetimes, so frequently it pays off listing all the work experience you have had (at least since you graduated).

Employers like to see job continuity. This is meant in two ways: First, employers like to see that you have spent time at your previous jobs. In other words, you didnt sign on, and quit within a month. Employers are making an investment in you, and the would like to think that you are going to hang around for a while. Second, employers like to see that you have been continually employed for some time. If there are several years unaccounted for in your resume, employers are going to ask questions. For example:
    
    
    1990 - 1995  Mr Computer Shack   Someplace, USA
    IT Consultant
    
    2000 - Present  Jim's Computer Barn     Otherplace, USA
    Sales Person
    

Now, the hiring manager is going to read this, and ask "What did you do for those 5 years?". Did you take time off to write your memoirs? Did you spend time in prison? Did you drink yourself into the gutter? If you do have a gap in your employment, be prepared to discuss that gap both in your cover letter, and at the interview (if you get the interview). It is always better to bring the issue up and make the reason known, then to try and avoid the issue. However, be warned that employers don't want to hear all your whiney excuses either.

## Education

In today's world, prospective employees for most corporate jobs are required to have some degree of higher education. You should almost always list your education on the resume, but if it isn't your crowning achievement in life, you should probably not play it up too much. Also, if your degree is in an unrelated (or nearly unrelated) field from the job you are applying for, it only serves as a notice that "I can be taught".

If you are a newly graduating student, it is generally recommended that you do not include your GPA on your resume, unless your GPA is fantastic: Don't mention it unless it is over about 3.5 (depending on how competitive your major is). Many students with low GPAs include them on their resume unnecessarily, and many students with high GPAs omit them. Some companies do specifically ask for you to include your GPA, so in that case you should.

## Awards and Memberships

This is a section that again, is probably more important for a graduating student then for a seasoned worker. However, if you are a member of a professional organization, or if you have received different professional awards, those are certainly worth mentioning. It is not generally worth while to mention that you are part of a book club, or a knitting circle, or a bowling team, although such an entry can help to spark conversation at the interview.

## Interests

Many people also like to include sections on their own personal interests on their resume. This can be a useful tactic if you have a small amount of room left on your resume that you would like to fill. Including some information about your interests and hobbies can alert the hiring manager as to the individual personality characteristics that you can bring to the team environment. Also, including some interests can help to feed the discussion at the interview.

However, there are some conflicting ideas about an interests section. Some employers consider resume sections that don't directly pertain to the job at hand as being a distraction. Whether to include an interests section in your resume or not is a decision that is worth some careful consideration.

  


# Electronic Resumes

In today's computerized world, you might not submit a printed resume, but instead you might be asked to fax, email, or post online your resume. This section will help you to have your resume come out looking the best it can depending upon how you need to submit it.

## Internet Submission

### Emailing a Resume

Of all the electronic submission methods, emailing is generally the most preferred, as it is the option that, if done properly, can have the sent resume look the closest to the original. The best way to send a resume via email is to make a PDF file of your resume and attach it to your email message. (See the [PDF Resumes](/wiki/Find_Employment/Electronic_Resumes#PDF_Resume) section)

You may also wish to "hedge your bets" by also attaching a copy in Microsoft Word format. And also include a copy of the resume in the body of your message. But beware, it is often difficult to make the resume look the same in the body of your message as the original was. (See the [ASCII Resume](/wiki/Find_Employment/Electronic_Resumes#ASCII_Resume) section for hints about how to make it look better.)

### Submitting a Resume on a Job Website

  * General Job Sites 
    * [HotJobs](http://www.hotjobs.com)
    * [Monster.com](http://www.monster.com)
    * [CareerBuilder](http://www.careerbuilder.com)
  * Specific Site to Who You Are Applying for
  * Get an Account
  * Post Resume 
    * Form Process
    * Copy & Paste (Often ASCII)
    * Upload a File (PDF, or Word, etc.)

### Making a Web Page Resume

If you want to have more control of your site, but it requires more technical expertise.

  * Make Site 
    * Word Processing App
    * Web Page Design App
    * Direct HTML
  * Get a Host 
    * Free Hosts
    * Paid Hosts
    * Job Site Hosts? (Do any of these support full web page posting?)
  * Get a URL 
    * URL Provided by Host
    * Domain Name
    * Service such as TinyURL

### Video Resume

  * Distribution Methods 
    * DVD
    * "Business Card" CDs
    * Web Sites (Examples: YouTube, CareerBuilder)

## Resume File Formats

### PDF Resume

Given all format options, generally PDF is the best option. This is because PDF is an open standard that most recipients will have the ability to view. Further your resume will look nearly identical to your printed resume. Also, there are several methods of making PDF files including several free open source programs.

One free method that works with most Windows computer programs is the Open Source [PDFCreator](//en.wikipedia.org/wiki/PDFCreator). If you have a different operating system, [Ghostscript](//en.wikipedia.org/wiki/Ghostscript) is an Open Source program that can be used to create PDF files.

### ASCII Resume

## Faxing a Resume

If given the choice, faxing is the least preferred method to get a resume to a potential employer. But many businesses may only accept faxed resumes. Many of these will then convert the resume to a digital format using [OCR](//en.wikipedia.org/wiki/Optical_Character_Recognition). Because this process is not perfect, a resume that looked beautiful before being sent, often may look bad after it arrives. Further, some parts of your resume may even not go through at all.

To avoid these problems, if you are asked to fax a resume, make a separate resume from your standard one that follows the following rules:

  1. Do not include underlining or italics
  2. Do not include shaded print, underlines, boxes around text, or graphics
  3. Only use white paper, only use black typing
  4. Bullets should be the simple standard circular bullet. Do not use fancy bullets.

Even though you resume may not look as nice as your original before faxing, it will most likely look much better than your original would have after faxing.

## Resume "Business" Card

While not strictly an "electronic" resume, a novel method of helping you to get a job, is to create a resume "business" card. These act similar to a business card, and you should have them on you at all times, but instead of telling a person about your business, the cards tell a person about yourself. The reason for these cards, is that you never know where you might find a job lead, it may happen at a grocery store or waiting in line for a movie. By having a resume "business" card on you at all time, you are prepared for whenever opportunity strikes.

### Creating the Resume "Business" Card

You may choose to create the cards yourself, using a desktop publishing program like Microsoft Publisher, or word processing program such as Microsoft Word, or OpenOffice. There are also several websites that make business cards, or you can have a local company make them for you.

### Things to Place on Your Card

Since a resume "business" card has far less room than a resume, it is critical to put the most important things on your card that best sell yourself. The following are some suggestions:

  1. Your name (of course)
  2. Contact information, you may wish to only place an email and phone number, since there is limited room.
  3. Type of work you are seeking. Keep this short, don't try to make a whole objective statement.
  4. Skills, or most relevant experience. Boil down your resume to no more than 6 bullets that tell the most important things about you to a potential employer.
  5. Picture or graphic. If you have a good photo of yourself, place it on your card, or if there is a piece of clip-art that represents you well, feel free to use it.

### Other Thoughts

If you are printing your own resume "business" cards, you may wish to use both sides of the card so you can fit more information. There are some self print business cards, that allow you to have clean edges (not perforated), but these generally can not be printed on both sides.

  


# Cover Letters

**[Find Employment](/wiki/Find_Employment)**

## The Cover Letter

A cover letter is sent with a résumé or application form, as a way of introducing yourself to prospective employers. As with your résumé, it may be helpful to look for examples on the Internet or in books at your local library or bookstore, but be sure not to copy letters directly from other sources. Your cover letter should be original, capture the employer's attention, follow a business letter format, and usually should include the following information:
    
    
       * Name and address of the specific person to whom the letter is addressed.
       * Reason for your interest in the company or position.
       * Your main qualifications for the position.
       * Request for an interview.
       * Your home and work telephone numbers.
    

If you send a scannable résumé, you should also include a scannable cover letter, which is created similarly to a scannable résumé, by avoiding graphics, fancy fonts, italics, and underlines.

Different employers use cover letters in different manners. It is quite common for an employer to first sort through a stack of applicants by reading the résumé and making sure potential employees have the correct qualifications, and after filtering out non-qualified applicants, to then read the cover letters to determine who will get interviews.

## Content

In essence, the cover letter says all the things that the résumé can't (or shouldn't) say. The cover letter also provides a forum for discussing some of the issues that are present on your resume. For instance a cover letter allows you to address:

  * Prolonged period of missing time in your work history
  * Connecting items listed on your resume that may look unrelated to the job at hand (transferable skills)
  * A deep passion or dream you have of working in the field you are applying for
  * Other selling points that are not addressed well in the résumé

## Opportunity

The cover letter also is a good opportunity to request an interview, and mention that you will be making a follow-up telephone call (and you will make this call, if you want the job).

## Style of the Letter

The resume is a listing of words and phrases, but the cover letter should be (must be) a formal, business-style letter. It should be broken up into paragraphs, it should contain well-formed sentences, and you should check and double-check your spelling. Running spell-check is not enough for this letter, because the spell-check will not pick up some errors such as "they're and their and there". Many different websites and manuals will specify the paragraph layout of your cover letter, and most of them will even impose some restrictions on your sentence structure. For instance, many resources recommend that sentences be kept short and direct (12 words or so, at maximum). Also, it is generally considered a good idea to use the active voice (as opposed to the passive voice), and to be assertive.

  


# Applying Online

**[Find Employment](/wiki/Find_Employment)**

## Applying Online

Many companies offer online or email-based application methods. This can be a tempting idea, but there are a number of factors to consider. First off, many online applications don't allow for uploading your resume or coverletters directly, but instead ask that you copy+paste the text into an available plain-text edit box. This can be very frustrating, considering that you have (or should have) spent a lot of time and effort formatting your resume and cover letters to look stylish and eye-catching. Note that when you copy+paste a heavily formatted document into a plain-text edit box, you lose more than just the fancy look: your text can be out of order, you can be missing important line-breaks, and you may also wind up with annoying control characters or blank characters in your edit box.

## Plain-Text Resume

If you are applying to many places that accept resumes in this way, it may be a good idea to take the time to prepare a second, plain-text resume before hand. You can create one in notepad or a similar editor, and you can ensure that everything looks as nice as is possible in such a simple format.

## Email

Also, be sure to look for options where you can email a resume instead of uploading a plain-text one. If you are going to be emailing a large number of resumes, it might be worthwhile to invest the time (and money) to convert your resume to PDF format, to look more professional. Certain word processing programs such as OpenOffice.org can easily (and freely) produce PDF documents, and can also be used to convert pre-existing documents to PDF.

  


# Follow Up

**[Find Employment](/wiki/Find_Employment)**

## Follow Up

After you mail in your resume, many people feel that you must now sit and wait for a response. However, this is not the best action, because you should always follow up your application with additional communications. Oftentimes the best method is to obtain the phone number of the hiring manager, and call him on a regular basis to find out what the status of the application is, and to help keep you on the front of everybody's mind. Persistance can be the key in these situations. Follow-Up emails can also be used, although they are not always as effective. A hybrid strategy combining emails and phone conversations however, could prove to be very effective.

  


Interview

  


  


# Interviewing

**[Find Employment](/wiki/Find_Employment)**

## The Interview

Most of us face employment interviews in our careers. While there are no foolproof methods to "pass" the interview, there are some things that will help you on your way. If the interview allows preparation, read & understand the many publications that can help you. Rehearsing an interview with friend(s) can be useful, particularly if your rehearsals are done as close as possible to the real situation:, with aids, games, unprepared expectations that may be required just before the main interview, etc.

Find out the interview situation if you can: how many are on the interview panel, whether this interview will be one of several this time, how long will the session be. Also, do your homework about travel to the interview site so you know exact travel time. If you are going to an unfamiliar area, it is good to drive the route the day before - preferably at the same time of day.

## Make a Good Impression

This is crucial. Be psychologically prepared, like an athlete at peak performance: not sleepy nor too-relaxed, but not over-aroused. Properly finish with your food/ drink/ toiletry-needs. Exercise your face, mouth, body and voice before the interview session, to get yourself in peak readiness.

Dress appropriately for the type of job you applying to. Wear sensible shoes, and carry a suitable handbag or briefcase. It is important to look professional, and to give the impression that you will fit in to the work atmosphere. If you look out of place, people will assume you are out of place, and form a negative opinion of you. Wearing heavy colognes or perfume is a no-no. Many people are sensitive or allergic to perfumes and are distracted when exposed to them. Introduce yourself before sitting down and be sure to shake the interviewer's hand if he or she extends it. There will be generally less than three interviewers in a panel. Remember their names and use them along the course of the interview. This would reflect well on your ability to get along with people. Avoid flirting, or being too serious, or too playful.

The outfit that you wear to an interview at a garage is certainly different from what you would wear to a business office. No matter where you are applying, however, it is important to remember that as a new applicant, you should definitely be dressed just as well or better than any of the current employees. You should dress well to set yourself apart. The better you appear, the better the hiring manager's opinion of you will be.

## Ask Questions

The interview is an opportunity for the hiring manager to learn about you, but it is also a good opportunity for you to learn more about the company. Do not hesitate to ask questions that you are unsure of. Do ask what the salary is like. Do ask about the benefits. Do ask about the environment, and the management, and even the food (if they serve food on the premises). At the interview, you might realize that you don't want to work for this company in the first place.

## Communicate effectively

Answer all questions honestly and precisely. Avoid rambling or guessing. If you don't know the answer to a question, say so. Do not short-sell yourself. If the employer asks you about your own positive and negative qualities, do not go overboard while describing the negative qualities. One negative quality is enough per interview session. Avoid cracking jokes, unless you are auditioning to be a stand-up comedian. If you've done your homework well, answering questions will be a breeze.

Keep your answers short and engaging.

Practice answering all kinds of interview questions. Every answer should be no shorter than 5 seconds and no longer than 30 seconds unless it includes a story. If it does include a story, try to keep the answer to less than 2 minutes. The only exception is a question that asks you to set up a scenario and how you dealt with it. E.g. “Tell me about a time you led a team and overcame internal obstacles.” This will take more time, but keep it entertaining and focussed on the core of the question.

## Structure of a Job Interview

Before receiving a job offer from an employer, you will typically have a series of interviews. The first interview is a screening interview conducted either over the phone or at the employer's office. On-campus interviews are considered screening interviews. Screening interviews are brief, usually lasting 30-60 minutes. During that time, the employer will want you to elaborate on experiences and skills outlined in your resume.

Many employers use the screening interview as a chance to describe the organization and the position. If the employer is impressed with your performance in this interview, you will be invited to a second (and perhaps third or fourth) interview. The second interview is longer, lasting anywhere from two hours to a whole day. It could include a variety of questions, some form of testing, lunch or dinner, a tour, as well as a series of interviews with various employees. You should come away from the second interview with a thorough understanding of the organization's culture and environment, job responsibilities, and have enough information to decide on a job offer - if one is extended.

The Warm-Up
    Each interview follows a rather predictable pattern of warm-up, information exchange, and wrap-up conversations. During the first few minutes of the interview (the warm-up), an employer will be formulating a first, lasting, impression of you. The way you greet the employer, the firmness of your handshake, and the way you are dressed, will all be a part of this initial impression. An interviewer may begin by asking common-ground questions about shared interests, the weather, or your travel to the interview. Some interviewers might start by saying "Tell me about yourself." This is an opening for you to briefly and concisely describe your background, skills, and interest in the position.

The Information Exchange
    The information exchange will be the primary part of the interview. This is when you will be asked the most questions and learn the most about the employer. In screening interviews, many employers will spend more time describing their opportunities than asking you specific questions. The reverse will be true in second interviews. Interview questions may range from "Why did you choose to pursue a business degree?" to "What are your strengths/weaknesses?" and "What are your long-range career goals?" If you are prepared for the interview, you will be able to emphasize your qualifications effectively as you respond to each question. By practicing for interviews, you will gain confidence and have more polished answers.

The Wrap-up
    Eventually the employer will probably say, "Do you have any questions?" This is your cue that the interview is moving to the wrap-up stage. Always ask questions. This demonstrates your research and interest in the job. Your questions might be direct, logistical questions such as, "When can I expect to hear from you?" (if that has not been discussed); questions to clarify information the employer has presented; a question regarding the employer's use of new technology or practices related to the career field; or a question to assess the culture and direction of the organization such as "Where is this organization headed in the next five years?" or "Why do you like working for this organization?" Do not ask specific questions about salary or benefits unless the employer broaches the subject first. The employer may also ask you if you have anything else you would like to add or say. Again, it's best to have a response. You can use this opportunity to thank the employer for the interview, summarize your qualifications, and reiterate your interest in the position. If you want to add information or emphasize a point made earlier, you can do that, too. This last impression is almost as important as the first impression and will add to the substance discussed during the information exchange.

  


# Interview Questions

**[Find Employment](/wiki/Find_Employment)**

## Interview Questions you might be asked

This is a list of common questions that you are likely to be asked. You should prepare answers to these questions, or at least be prepared to answer them in case they arise.

About Your Qualifications

  * Tell me about yourself.
  * How do you think a friend or someone who knows you well would describe you?
  * What do you think is your greatest weakness?
  * Can you summarize the contribution you would make to our organization?
  * Please tell me about the greatest professional assignment you've ever handled.
  * What accomplishment has given you the most satisfaction?
  * Tell me about your experiences at school.
  * What has been the most rewarding college experience?
  * Tell me about your most significant work experience.
  * How would those who have worked with you describe you?
  * Why are you the best candidate for this position?
  * Have you ever supervised anyone?

About Your Ability to Work in the Environment

  * Why are you interested in this job?
  * What do you know about us?
  * In what kind of work environment are you most comfortable?
  * What criteria are you using to evaluate the organization for which you hope to work?
  * Are you a team player?
  * How do you work under pressure?
  * How do you handle conflict?
  * What major problem have you encountered and how have you dealt with it?
  * How competitive are you?
  * What do you expect from your supervisor?
  * What qualities should a successful manager possess?
  * Describe the relationship that should exist between a supervisor and those reporting to him or her.

About Your Career and Personal Choices

  * What are your long-range career goals? When and why did you establish these goals and how are you preparing yourself to achieve them?
  * What are the most important rewards you expect in your business career?
  * What do you do in your spare time?
  * What kind of salary are you looking for?

Welcome to the Real World

  * For the most recent graduate, here are some tough questions specifically tailored to discover your business potential.
  * Why did you choose [school]?
  * What led you to major in_______?
  * What course have you liked the least? The most?
  * I'd be interested to hear about some things you learned in school that could be used on the job.
  * Do you think your grades adequately represent your abilities?
  * If you could do so, how would you plan your academic study differently? Why?
  * We have tried to hire people from your school/your major before, and they never seem to work out. What makes you different?
  * Have you ever had difficulties getting along with others?
  * What problems do you see in your school? How would you go about correcting them?
  * What have you done that shows initiative and willingness to work?

Hard Questions

  * Did you ever have a group leader or boss you disliked? Why did you dislike him/her?
  * How would someone who dislikes you describe you?
  * Talk about a group situation in which there were problems. How did you handle the situation and what was the outcome? What role did you play in the group? How could the group improve its performance?
  * Tell me about a time when you experienced a failure and how you reacted to it.
  * Tell me about a time when you were under considerable pressure to meet one or more goals.
  * Describe a situation where you had to resolve a problem at work and explain how you resolved it.
  * Give me an example of how you are a risk taker.
  * If you could have any job in the world, what would it be?
  * What motivates you?
  * Why do you want to work for us and not for our competitor?
  * Why should we hire you over everyone else we spoke to today?
  * What do you think is the most important/difficult ethical dilemma facing corporations today?
  * Give a one sentence positioning statement of yourself.
  * How do you go about deciding what to do first when given a project?
  * Tell me about an experience you have had in a working environment (school, work, or community).
  * Describe a situation where you did not agree with something your boss asked you to do and how you resolved the problem.
  * Can you work under pressure?
  * What did you like/dislike about your last job?
  * What would you like to be doing five years from now?

The Stress Interview

  * Would you like to have your boss's job?
  * See this pen I'm holding? Sell it to me.
  * Why should I hire an outsider when I could fill the job with someone inside the organization?
  * Why were you out of work for so long?
  * Describe a situation when your work or an idea was criticized.
  * Your application shows you have been with one organization a long time without any appreciable increase in rank or salary. Tell me about this.

For Career Changers

  * Why would you be interested in this kind of work?
  * How do you expect to get up to speed in all the areas which will be unfamiliar to you?

And, the Most Dreaded Question, "Tell Us about Yourself". This is also your greatest opportunity. You are likely to be asked this, so plan to use the open-ended nature of the question to your advantage. It is not necessary to answer autobiographically. You may choose to organize your thoughts around your interest in the job and why you are prepared to do it.

## Questions you might ask

"Do You Have Any Questions for Us?" The right answer is always yes, or you risk appearing uninterested. Prepare some questions in advance, but, above all, ask questions that show a response to what you have learned from the interviewers, and that are lively, rather than formulaic. Some examples include:

Advancement

  * Can you tell me how success in this position is measured?
  * What skills would I need to be successful in this position?
  * How do you encourage your employees to keep current with professional developments in the field?
  * Could you tell me about your training program? What are some of the typical career paths followed by others who have been in this position? What would be a realistic timeframe for advancement?
  * What are the opportunities for personal growth?
  * What is the retention rate of people in the position for which I am interviewing?
  * Is it organizational policy to promote from within? What is the work history of your top management?

Responsibilities

  * Tell me about a typical day in this job.
  * Who would I work with most closely on a day-to-day basis?
  * How often can I expect to relocate during the initial years of employment with your organization?

Being New on the Job

  * What do you consider the most challenging aspect of this position for someone who is new to your organization?
  * What does the new [job title] need to accomplished in the next 6-12 months?
  * What qualities are you looking for in your new hires?
  * What are your expectations for new hires?
  * Could you describe a typical first assignment?
  * What are the most challenging facets of the position?

More about the Organization

  * Why is this position available?
  * What are your department's major projects in the coming year?
  * What do you think are your organization's greatest competitive strengths with clients?
  * What is the overall structure of the department where the position is located?
  * What is the work environment like?
  * What makes your organization different from its competitors?
  * What are your organizations strengths and weaknesses?
  * How would you describe your corporation's personality and management style?
  * Why did you join the organization? Why have you stayed with the organization?

  


# Interview Tips

**[Find Employment](/wiki/Find_Employment)**

## Things not to do in an interview

  1. Never bring into discussion your ideologies or politics.
  2. Never say anything negative about previous employers.
  3. Do not put anything on your resume that you are not strong in. They might turn out to be an achilles heel. Only put your strengths on the resume.
  4. Do not flirt, do not make obscene or suggestive comments. Do not curse. This can be difficult if you are going directly to the interview from an informal atmosphere such as school or a day out with friends.
  5. Do not brag. Nobody wants to hire you if you are cocky or over-confidant. Likewise, do not be too modest. It is important to point out your strengths without being arrogant or condescending.

  


## Job Interview Tips

An interview gives you the opportunity to showcase your qualifications to an employer, so it pays to be well prepared. The following information provides some helpful hints.

Preparation

  * Learn about the organization.
  * Have a specific job or jobs in mind.
  * Review your qualifications for the job.
  * Prepare answers to broad questions about yourself.
  * Review your résumé.
  * Practice an interview with a friend or relative.
  * Arrive before the scheduled time of your interview.

Personal appearance

  * Be well groomed.
  * Dress appropriately.
  * Do not chew gum or smoke.

The interview

  * Relax and answer each question concisely.
  * Respond promptly.
  * Use good manners.
  * Learn the name of your interviewer and greet him or her with a firm handshake.
  * Use proper English—avoid slang.
  * Be cooperative and enthusiastic.
  * Use body language to show interest.
  * Ask questions about the position and the organization, but avoid questions whose answers can easily be found on the company Web site. Also avoid asking questions about salary and benefits unless a job offer is made.
  * Thank the interviewer when you leave and, as a follow-up, in writing.

Test (if employer gives one)

  * Listen closely to instructions.
  * Read each question carefully.
  * Write legibly and clearly.
  * Budget your time wisely and don’t dwell on one question.

Information to bring to an interview

  * Social Security card.
  * Government-issued identification (driver’s license).
  * Résumé. Although not all employers require applicants to bring a résumé, you should be able to furnish the interviewer information about your education, training, and previous employment.
  * References. Employers typically require three references. Get permission before using anyone as a reference. Make sure that they will give you a good reference. Try to avoid using relatives as references.
  * Transcripts. Employers may require an official copy of transcripts to verify grades, coursework, dates of attendance, and highest grade completed or degree awarded.

  


The Offer

  


  


# Offer Strategies

**[Find Employment](/wiki/Find_Employment)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Mergefrom.svg/50px-Mergefrom.svg.png)

**A Wikibookian suggests that _[Find Employment/Evaluating an Offer](/wiki/Find_Employment/Evaluating_an_Offer)_ be [merged](/wiki/Help:Pages#Merging) into this book or chapter.**  
Discuss whether or not this merger should happen on the [discussion page](/w/index.php?title=Talk:Find_Employment/Print_Version&action=edit&redlink=1).

## The Offer

If the interview has gone well, and if both parties are happy with the interview process, you might receive an offer. Many offers are verbal, over the phone, but recently some companies have been sending out offers (at least informal offers) over email as well. Inevitably, the question will come up about compensation, and the hiring manager is likely to ask "how much money do you want?" This is a loaded question, so it is worth while to prepare your response.

Once you receive a job offer, you are faced with a difficult decision and must evaluate the offer carefully. Fortunately, most organizations will not expect you to accept or reject an offer immediately.

### Issues to Consider

There are many issues to consider when assessing a job offer. Will the organization be a good place to work? Will the job be interesting? Are there opportunities for advancement? Is the salary fair? Does the employer offer good benefits? If you have not already figured out exactly what you want, the following discussion may help you to develop a set of criteria for judging job offers, whether you are starting a career, reentering the labor force after a long absence, or planning a career change.

### The organization

Background information on an organization can help you to decide whether it is a good place for you to work. Factors to consider include the organization�s business or activity, financial condition, age, size, and location.

You generally can get background information on an organization, particularly a large organization, on its Internet site or by telephoning its public relations office. A public company�s annual report to the stockholders tells about its corporate philosophy, history, products or services, goals, and financial status. Most government agencies can furnish reports that describe their programs and missions. Press releases, company newsletters or magazines, and recruitment brochures also can be useful. Ask the organization for any other items that might interest a prospective employee. If possible, speak to current or former employees of the organization.

Background information on the organization may be available at your public or school library. If you cannot get an annual report, check the library for reference directories that may provide basic facts about the company, such as earnings, products and services, and number of employees. Some directories widely available in libraries either in print or as online databases include:

  * Dun & Bradstreet’s Million Dollar Directory
  * Standard and Poor’s Register of Corporations
  * Mergent’s Industrial Review (formerly Moody’s Industrial Manual)
  * Thomas Register of American Manufacturers
  * Ward’s Business Directory

Stories about an organization in magazines and newspapers can tell a great deal about its successes, failures, and plans for the future. You can identify articles on a company by looking under its name in periodical or computerized indexes in libraries. However, it probably will not be useful to look back more than 2 or 3 years

The library also may have government publications that present projections of growth for the industry in which the organization is classified. Long-term projections of employment and output for detailed industries, covering the entire U.S. economy, are developed by the Bureau of Labor Statistics and revised every 2 years. See the November 2005 Monthly Labor Review for the most recent projections, covering the 2004-14 period, on the Internet at: <http://www.bls.gov/opub/mlr/mlrhome.htm>. Trade magazines also may include articles on the trends for specific industries.

Career centers at colleges and universities often have information on employers that is not available in libraries. Ask a career center representative how to find out about a particular organization.

Does the organization's business or activity match your own interests and beliefs?

It is easier to apply yourself to the work if you are enthusiastic about what the organization does.

### Size of the FCompany

How will the size of the organization affect you?

Large firms generally offer a greater variety of training programs and career paths, more managerial levels for advancement, and better employee benefits than do small firms. Large employers also may have more advanced technologies. However, many jobs in large firms tend to be highly specialized.

Jobs in small firms may offer broader authority and responsibility, a closer working relationship with top management, and a chance to clearly see your contribution to the success of the organization.

Should you work for a relatively new organization or one that is well established?

New businesses have a high failure rate, but for many people, the excitement of helping to create a company and the potential for sharing in its success more than offset the risk of job loss. However, it may be just as exciting and rewarding to work for a young firm that already has a foothold on success.

### Type of Company

Does it make a difference if the company is private or public?

An individual or a family may control a privately owned company and key jobs may be reserved for relatives and friends. A board of directors responsible to the stockholders controls a publicly owned company and key jobs usually are open to anyone.

Is the organization in an industry with favorable long-term prospects?

The most successful firms tend to be in industries that are growing rapidly.

### Nature of the job

Even if everything else about the job is attractive, you will be unhappy if you dislike the day-to-day work. Determining in advance whether you will like the work may be difficult. However, the more you find out about the job before accepting or rejecting the offer, the more likely you are to make the right choice. Actually working in the industry and, if possible, for the company would provide considerable insight. You can gain work experience through part-time, temporary, or summer jobs, or through internship or work-study programs while in school, all of which can lead to permanent job offers.

Where is the job located?

If the job is in another section of the country, you need to consider the cost of living, the availability of housing and transportation, and the quality of educational and recreational facilities in that section of the country. Even if the job location is in your area, you should consider the time and expense of commuting.

Does the work match your interests and make good use of your skills?

The duties and responsibilities of the job should be explained in enough detail to answer this question.

How important is the job in this company?

An explanation of where you fit in the organization and how you are supposed to contribute to its overall objectives should give you an idea of the job�s importance.

Are you comfortable with the hours?

Most jobs involve regular hours—for example, 40 hours a week, during the day, Monday through Friday. Other jobs require night, weekend, or holiday work. In addition, some jobs routinely require overtime to meet deadlines or sales or production goals, or to better serve customers. Consider the effect that the work hours will have on your personal life.

How long do most people who enter this job stay with the company?

High turnover can mean dissatisfaction with the nature of the work or something else about the job.

### Opportunities offered by employers

A good job offers you opportunities to learn new skills, increase your earnings, and rise to positions of greater authority, responsibility, and prestige. A lack of opportunities can dampen interest in the work and result in frustration and boredom.

The company should have a training plan for you. What valuable new skills does the company plan to teach you?

The employer should give you some idea of promotion possibilities within the organization. What is the next step on the career ladder? If you have to wait for a job to become vacant before you can be promoted, how long does this usually take? When opportunities for advancement do arise, will you compete with applicants from outside the company? Can you apply for jobs for which you qualify elsewhere within the organization, or is mobility within the firm limited?

### Salaries and benefits

Wait for the employer to introduce these subjects. Some companies will not talk about pay until they have decided to hire you. In order to know if their offer is reasonable, you need a rough estimate of what the job should pay. You may have to go to several sources for this information. Try to find family, friends, or acquaintances who recently were hired in similar jobs. Ask your teachers and the staff in placement offices about starting pay for graduates with your qualifications. Help-wanted ads in newspapers sometimes give salary ranges for similar positions. Check the library or your school�s career center for salary surveys such as those conducted by the National Association of Colleges and Employers or various professional associations.

If you are considering the salary and benefits for a job in another geographic area, make allowances for differences in the cost of living, which may be significantly higher in a large metropolitan area than in a smaller city, town, or rural area.

You also should learn the organization's policy regarding overtime. Depending on the job, you may or may not be exempt from laws requiring the employer to compensate you for overtime. Find out how many hours you will be expected to work each week and whether you receive overtime pay or compensatory time off for working more than the specified number of hours in a week.

Also take into account that the starting salary is just that—the start. Your salary should be reviewed on a regular basis; many organizations do it every year. How much can you expect to earn after 1, 2, or 3 or more years? An employer cannot be specific about the amount of pay if it includes commissions and bonuses.

Benefits also can add a lot to your base pay, but they vary widely. Find out exactly what the benefit package includes and how much of the cost you must bear.

National, State, and metropolitan area data from the Bureau�s National Compensation Survey are available from:

  * Bureau of Labor Statistics, Office of Compensation Levels and Trends, 2 Massachusetts Ave. NE., Room 4175, Washington, DC 20212-0001. Telephone: (202) 691-6199.

Internet: <http://www.bls.gov/ncs/>

Data on earnings by detailed occupation from the Occupational Employment Statistics (OES) Survey are available from:

  * Bureau of Labor Statistics, Office of Occupational Statistics and Employment Projections, 2 Massachusetts Ave. NE., Room 2135, Washington, DC 20212-0001. Telephone: (202) 691-6569. Internet: <http://www.bls.gov/oes/>

## Research

It is important, before you even go to an interview, and certainly before you entertain an offer, that you know what you are worth, and what the job pays. There are many resources on the internet, such as Salary.com, where you can find out what other people in your area are getting paid for similar work. If you are a college graduate, ask your advisors what kinds of salary people with your qualifications are worth. If you aren't a graduate, find out what other qualifications you have, and what their combined worth is. If you have your highschool diploma, and a number of certifications, and if you have attended training programs, do some research and find out what your net worth is.

## Don't Make the First Offer

No matter what happens, you should never say a dollar amount first. If you ask for a number that is too high, the hiring manager may think that you are unrealistic, or that you are accustomed to having too high paying a job. If you ask for too little, the manager might accept your offer, even if they were willing to pay you more.

Here is a story: A hiring manager is looking to hire an office assistant for approximately 20$ an hour, plus some benefits. The manager interviews 2 candidates, both of which are equally qualfied. He asks what each one wants to make. The first candidate says "I've done some research, I know this job is worth approximately 20$/hour, but I'm not despirate, and I'm willing to negotiate". The second candidate says "I want to make at least 15$ an hour." So who gets the job? The hiring manager will likely hire the second candidate, because the second candidate will be happy with only 15$ an hour, and the hiring manager can save 25% of his money for other needs!

Now, the example above may make it look like you can get your foot in the door if you under-bid the competition, but keep in mind: If you make yourself look cheap, people will think you are cheap. People may think that they can get away with giving you too little money, or they may think that you simply haven't done your research (which makes you look bad), or they may even think that you are only worth the lower amount! if competition for a job is tough, don't undersell yourself, because you lose your edge.

## Don't Forget Benefits

Benefits, if they are being offered, are an important part of your employment package. Which is better: $35,000 a year with full medical and dental, or $40,000 per year with no benefits at all? If you are already covered, you might spring for the higher number, but many people should definitely think hard about this decision, because it could affect the rest of your life. If you have college loan debt, see if the company offers tuition reimbursement. For young women, find out what the maternity package is like. Everybody should inquire about the retirement options, the medical benefits, life insurance options, et cetera. Also, if the company is unionized, find out what the union dues cost, and find out what the union benefits are. It's your job, and if you've gotten this far in the employment process, you can probably find another job if this one doesn't meet your needs.

## Evaluating a Job Offer

Once you receive a job offer, you are faced with a difficult decision and must evaluate the offer carefully. Fortunately, most organizations will not expect you to accept or reject an offer immediately.

There are many issues to consider when assessing a job offer. Will the organization be a good place to work? Will the job be interesting? Are there opportunities for advancement? Is the salary fair? Does the employer offer good benefits? If you have not already figured out exactly what you want, the following discussion may help you to develop a set of criteria for judging job offers, whether you are starting a career, reentering the labor force after a long absence, or planning a career change.

### The organization

Background information on an organization can help you to decide whether it is a good place for you to work. Factors to consider include the organization’s business or activity, financial condition, age, size, and location.

You generally can get background information on an organization, particularly a large organization, on its Internet site or by telephoning its public relations office. A public company’s annual report to the stockholders tells about its corporate philosophy, history, products or services, goals, and financial status. Most government agencies can furnish reports that describe their programs and missions. Press releases, company newsletters or magazines, and recruitment brochures also can be useful. Ask the organization for any other items that might interest a prospective employee. If possible, speak to current or former employees of the organization.

Background information on the organization may be available at your public or school library. If you cannot get an annual report, check the library for reference directories that may provide basic facts about the company, such as earnings, products and services, and number of employees. Some directories widely available in libraries either in print or as online databases include:

  * Dun & Bradstreet’s Million Dollar Directory
  * Standard and Poor’s Register of Corporations
  * Mergent’s Industrial Review (formerly Moody’s Industrial Manual)
  * Thomas Register of American Manufacturers
  * Ward’s Business Directory

Stories about an organization in magazines and newspapers can tell a great deal about its successes, failures, and plans for the future. You can identify articles on a company by looking under its name in periodical or computerized indexes in libraries. However, it probably will not be useful to look back more than 2 or 3 years

The library also may have government publications that present projections of growth for the industry in which the organization is classified. Long-term projections of employment and output for detailed industries, covering the entire U.S. economy, are developed by the Bureau of Labor Statistics and revised every 2 years. See the November 2005 Monthly Labor Review for the most recent projections, covering the 2004-14 period, on the Internet at: <http://www.bls.gov/opub/mlr/mlrhome.htm>. Trade magazines also may include articles on the trends for specific industries.

Career centers at colleges and universities often have information on employers that is not available in libraries. Ask a career center representative how to find out about a particular organization.

Does the organization’s business or activity match your own interests and beliefs?
    It is easier to apply yourself to the work if you are enthusiastic about what the organization does.

How will the size of the organization affect you?
    Large firms generally offer a greater variety of training programs and career paths, more managerial levels for advancement, and better employee benefits than do small firms. Large employers also may have more advanced technologies. However, many jobs in large firms tend to be highly specialized.

Jobs in small firms may offer broader authority and responsibility, a closer working relationship with top management, and a chance to clearly see your contribution to the success of the organization.

Should you work for a relatively new organization or one that is well established?
    New businesses have a high failure rate, but for many people, the excitement of helping to create a company and the potential for sharing in its success more than offset the risk of job loss. However, it may be just as exciting and rewarding to work for a young firm that already has a foothold on success.

Does it make a difference if the company is private or public?
    An individual or a family may control a privately owned company and key jobs may be reserved for relatives and friends. A board of directors responsible to the stockholders controls a publicly owned company and key jobs usually are open to anyone.

Is the organization in an industry with favorable long-term prospects?

The most successful firms tend to be in industries that are growing rapidly.

### Nature of the job

Even if everything else about the job is attractive, you will be unhappy if you dislike the day-to-day work. Determining in advance whether you will like the work may be difficult. However, the more you find out about the job before accepting or rejecting the offer, the more likely you are to make the right choice. Actually working in the industry and, if possible, for the company would provide considerable insight. You can gain work experience through part-time, temporary, or summer jobs, or through internship or work-study programs while in school, all of which can lead to permanent job offers.

Where is the job located?
    If the job is in another section of the country, you need to consider the cost of living, the availability of housing and transportation, and the quality of educational and recreational facilities in that section of the country. Even if the job location is in your area, you should consider the time and expense of commuting.

Does the work match your interests and make good use of your skills?
    The duties and responsibilities of the job should be explained in enough detail to answer this question.

How important is the job in this company?
    An explanation of where you fit in the organization and how you are supposed to contribute to its overall objectives should give you an idea of the job’s importance.

Are you comfortable with the hours?
    Most jobs involve regular hours—for example, 40 hours a week, during the day, Monday through Friday. Other jobs require night, weekend, or holiday work. In addition, some jobs routinely require overtime to meet deadlines or sales or production goals, or to better serve customers. Consider the effect that the work hours will have on your personal life.

How long do most people who enter this job stay with the company?
    High turnover can mean dissatisfaction with the nature of the work or something else about the job.

## Opportunities offered by employers

A good job offers you opportunities to learn new skills, increase your earnings, and rise to positions of greater authority, responsibility, and prestige. A lack of opportunities can dampen interest in the work and result in frustration and boredom.

The company should have a training plan for you. What valuable new skills does the company plan to teach you?

The employer should give you some idea of promotion possibilities within the organization. What is the next step on the career ladder? If you have to wait for a job to become vacant before you can be promoted, how long does this usually take? When opportunities for advancement do arise, will you compete with applicants from outside the company? Can you apply for jobs for which you qualify elsewhere within the organization, or is mobility within the firm limited?

## Salaries and benefits

Wait for the employer to introduce these subjects. Some companies will not talk about pay until they have decided to hire you. In order to know if their offer is reasonable, you need a rough estimate of what the job should pay. You may have to go to several sources for this information. Try to find family, friends, or acquaintances who recently were hired in similar jobs. Ask your teachers and the staff in placement offices about starting pay for graduates with your qualifications. Help-wanted ads in newspapers sometimes give salary ranges for similar positions. Check the library or your school’s career center for salary surveys such as those conducted by the National Association of Colleges and Employers or various professional associations.

If you are considering the salary and benefits for a job in another geographic area, make allowances for differences in the cost of living, which may be significantly higher in a large metropolitan area than in a smaller city, town, or rural area.

You also should learn the organization’s policy regarding overtime. Depending on the job, you may or may not be exempt from laws requiring the employer to compensate you for overtime. Find out how many hours you will be expected to work each week and whether you receive overtime pay or compensatory time off for working more than the specified number of hours in a week.

Also take into account that the starting salary is just that: the start. Your salary should be reviewed on a regular basis; many organizations do it every year. How much can you expect to earn after 1, 2, or 3 or more years? An employer cannot be specific about the amount of pay if it includes commissions and bonuses.

Benefits also can add a lot to your base pay, but they vary widely. Find out exactly what the benefit package includes and how much of the cost you must bear.

## Resources

National, State, and metropolitan area data from the Bureau’s National Compensation Survey are available from:

  * Bureau of Labor Statistics, Office of Compensation Levels and Trends, 2 Massachusetts Ave. NE., Room 4175, Washington, DC 20212-0001. Telephone: (202) 691-6199. Internet: <http://www.bls.gov/ncs/>

Data on earnings by detailed occupation from the Occupational Employment Statistics (OES) Survey are available from:

  * Bureau of Labor Statistics, Office of Occupational Statistics and Employment Projections, 2 Massachusetts Ave. NE., Room 2135, Washington, DC 20212-0001. Telephone: (202) 691-6569. Internet: <http://www.bls.gov/oes/>

  


# Evaluating an Offer

**[Find Employment](/wiki/Find_Employment)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Merge-arrow.svg/50px-Merge-arrow.svg.png)

**A Wikibookian suggests that this book or chapter be [merged](/wiki/Help:Pages#Merging) into _[Find Employment/Offer Strategies](/wiki/Find_Employment/Offer_Strategies)_.**  
Please discuss whether or not this merge should happen on the [discussion page](/wiki/Talk:Find_Employment/Offer_Strategies).

## Evaluating a Job Offer

Once you receive a job offer, you are faced with a difficult decision and must evaluate the offer carefully. Fortunately, most organizations will not expect you to accept or reject an offer immediately.

There are many issues to consider when assessing a job offer. Will the organization be a good place to work? Will the job be interesting? Are there opportunities for advancement? Is the salary fair? Does the employer offer good benefits? If you have not already figured out exactly what you want, the following discussion may help you to develop a set of criteria for judging job offers, whether you are starting a career, reentering the labor force after a long absence, or planning a career change.

## The organization

Background information on an organization can help you to decide whether it is a good place for you to work. Factors to consider include the organization’s business or activity, financial condition, age, size, and location.

You generally can get background information on an organization, particularly a large organization, on its Internet site or by telephoning its public relations office. A public company’s annual report to the stockholders tells about its corporate philosophy, history, products or services, goals, and financial status. Most government agencies can furnish reports that describe their programs and missions. Press releases, company newsletters or magazines, and recruitment brochures also can be useful. Ask the organization for any other items that might interest a prospective employee. If possible, speak to current or former employees of the organization.

Background information on the organization may be available at your public or school library. If you cannot get an annual report, check the library for reference directories that may provide basic facts about the company, such as earnings, products and services, and number of employees. Some directories widely available in libraries either in print or as online databases include:

  * Dun & Bradstreet’s Million Dollar Directory
  * Standard and Poor’s Register of Corporations
  * Mergent’s Industrial Review (formerly Moody’s Industrial Manual)
  * Thomas Register of American Manufacturers
  * Ward’s Business Directory

Stories about an organization in magazines and newspapers can tell a great deal about its successes, failures, and plans for the future. You can identify articles on a company by looking under its name in periodical or computerized indexes in libraries. However, it probably will not be useful to look back more than 2 or 3 years

The library also may have government publications that present projections of growth for the industry in which the organization is classified. Long-term projections of employment and output for detailed industries, covering the entire U.S. economy, are developed by the Bureau of Labor Statistics and revised every 2 years. See the November 2005 Monthly Labor Review for the most recent projections, covering the 2004-14 period, on the Internet at: <http://www.bls.gov/opub/mlr/mlrhome.htm>. Trade magazines also may include articles on the trends for specific industries.

Career centers at colleges and universities often have information on employers that is not available in libraries. Ask a career center representative how to find out about a particular organization.

Does the organization’s business or activity match your own interests and beliefs?
    It is easier to apply yourself to the work if you are enthusiastic about what the organization does.

How will the size of the organization affect you?
    Large firms generally offer a greater variety of training programs and career paths, more managerial levels for advancement, and better employee benefits than do small firms. Large employers also may have more advanced technologies. However, many jobs in large firms tend to be highly specialized.

Jobs in small firms may offer broader authority and responsibility, a closer working relationship with top management, and a chance to clearly see your contribution to the success of the organization.

Should you work for a relatively new organization or one that is well established?
    New businesses have a high failure rate, but for many people, the excitement of helping to create a company and the potential for sharing in its success more than offset the risk of job loss. However, it may be just as exciting and rewarding to work for a young firm that already has a foothold on success.

Does it make a difference if the company is private or public?
    An individual or a family may control a privately owned company and key jobs may be reserved for relatives and friends. A board of directors responsible to the stockholders controls a publicly owned company and key jobs usually are open to anyone.

Is the organization in an industry with favorable long-term prospects?

The most successful firms tend to be in industries that are growing rapidly.

## Nature of the job

Even if everything else about the job is attractive, you will be unhappy if you dislike the day-to-day work. Determining in advance whether you will like the work may be difficult. However, the more you find out about the job before accepting or rejecting the offer, the more likely you are to make the right choice. Actually working in the industry and, if possible, for the company would provide considerable insight. You can gain work experience through part-time, temporary, or summer jobs, or through internship or work-study programs while in school, all of which can lead to permanent job offers.

Where is the job located?
    If the job is in another section of the country, you need to consider the cost of living, the availability of housing and transportation, and the quality of educational and recreational facilities in that section of the country. Even if the job location is in your area, you should consider the time and expense of commuting.

Does the work match your interests and make good use of your skills?
    The duties and responsibilities of the job should be explained in enough detail to answer this question.

How important is the job in this company?
    An explanation of where you fit in the organization and how you are supposed to contribute to its overall objectives should give you an idea of the job’s importance.

Are you comfortable with the hours?
    Most jobs involve regular hours—for example, 40 hours a week, during the day, Monday through Friday. Other jobs require night, weekend, or holiday work. In addition, some jobs routinely require overtime to meet deadlines or sales or production goals, or to better serve customers. Consider the effect that the work hours will have on your personal life.

How long do most people who enter this job stay with the company?
    High turnover can mean dissatisfaction with the nature of the work or something else about the job.

  


Start Business

  


  


# Start Business

**[Find Employment](/wiki/Find_Employment)**

More and more people are creating their own next job by starting their own business. You can start your own business with the purpose of just yourself working for it or you can create a business with the ambition to employ other people.

## Free Agents

Our modern economy has been described as a free agent economy. Free agents are people who work for several companies independently not beening hired as an employee by the companies. A free agent can in many cases work much like an employee of a company but does not have the same rights to benefits etc. as an employee.

## Things to consider

  


Appendicies

  


  


# Regional Job Help

**[Find Employment](/wiki/Find_Employment)**

## State and Local Information

Most States have career information delivery systems (CIDS), which may be found in secondary and postsecondary institutions, as well as libraries, job training sites, vocational-technical schools, and employment offices. A wide range of information is provided, from employment opportunities to unemployment insurance claims.

Whereas the Handbook provides information for occupations on a national level, each State has detailed information on occupations and labor markets within their respective jursidictions. State occupational projections are available at: <http://www.projectionscentral.com>

Alabama

Director, Labor Market Information Division, Alabama Department of Industrial Relations, 649 Monroe St., Room 422, Montgomery, AL 36131. Telephone: (334) 242-8859. Internet: <http://dir.alabama.gov>

Alaska

Chief, Research and Analysis Section, Department of Labor and Workforce Development, P.O. Box 25501, Juneau, AK 99802-5501. Telephone: (907) 465-4518. Internet: <http://almis.labor.state.ak.us>

Arizona

Research Administrator, Arizona Department of Economic Security, P.O. Box 6123 SC 733A, Phoenix, AZ 85005-6123. Telephone: (602) 542-5984. Internet: <http://www.workforce.az.gov>

Arkansas

Division Chief, Labor Market Information, Department of Workforce Services, P.O. Box 2981, Little Rock, AR 72203-2981. Telephone: (501) 682-3198. Internet: <http://www.arkansas.gov/esd>

California

Chief, State of California Employment Development Department, Labor Market Information Division, P.O. Box 826880, Sacramento, CA 94280-0001. Telephone: (916) 262-2160. Internet: <http://www.calmis.cahwnet.gov>

Colorado

Director, Labor Market Information, Colorado Department of Labor and Employment, 633 17th St., Suite 600, Denver, CO 80202-3660. Telephone: (303) 318-8850. Internet: <http://www.coworkforce.com/lmi/>

Connecticut

Director, Office of Research, Connecticut Department of Labor, 200 Folly Brook Blvd., Wethersfield, CT 06109-1114. Telephone: (860) 263-6275. Internet: <http://www.ctdol.state.ct.us/lmi>

Delaware

Chief, Office of Occupational and Labor Market Information, Department of Labor, 4425 N. Market St.-Fox Valley Annex, Wilmington, DE 19809-1307. Telephone: (302) 761-8069. Internet: <http://www.delawareworks.com/oolmi/welcome.shtml>

District of Columbia

Chief, Office of Labor Market Research and Information, 64 New York Ave. NE., Suite 3035, Washington, D.C. 20002. Telephone: (202) 671-1633. Internet: <http://www.does.dc.gov/does>

Florida

Director, Labor Market Statistics, Agency for Workforce Innovation, MSC G-020, 107 E. Madison St., Tallahassee, FL 32399-4111. Telephone: (850) 245-7205. Internet: <http://www.labormarketinfo.com>

Georgia

Director, Workforce Information and Analysis, Room 300, Department of Labor, 223 Courtland St., CWC Building, Atlanta, GA 30303. Telephone: (404) 232-3875. Internet: <http://www.dol.state.ga.us/em/> get_labor_market_information.htm

Guam

Chief Economist, Guam Department of Labor, P.O. Box 9970, Tamuning, GU 96931. Telephone: (671) 475-7062.

Hawaii

Chief, Research and Statistics Office, Department of Labor and Industrial Relations, 830 Punchbowl St., Room 304, Honolulu, HI 96813. Telephone: (808) 586-8999. Internet: <http://www.hiwi.org>

Idaho

Chief, Research and Analysis Bureau, Department of Commerce and Labor, 317 West Main St., Boise, ID 83735-0670. Telephone: (208) 332-3570. Internet: <http://lmi.idaho.gov>

Illinois

Deputy Director of Workforce and Career Information, Illinois Department of Employment Security, Economic Information and Analysis Division, 33 South State St., 9th Floor, Chicago, IL 60603. Telephone: (312) 793-2316. Internet: <http://lmi.ides.state.il.us>

Indiana

Director, Research and Analysis - Indiana Workforce Development, SE 211, 10 North Senate Ave., Indianapolis, IN 46204-2277. Telephone: (317) 232-7460. Internet: <http://www.in.gov/dwd>

Iowa

Policy and Information Division, Iowa Workforce Development, 1000 East Grand Ave., Des Moines, IA 50319-0209. Telephone: (515) 281-6642. Internet: <http://www.iowaworkforce.org/lmi>

Kansas

Director, Kansas Department of Labor, Labor Market Information Services, 401 SW Topeka Blvd., Topeka, KS 66603-3182. Telephone: (785) 296-5058. Internet: <http://laborstats.dol.ks.gov>

Kentucky

Research and Statistics Branch, Office of Employment and Training, 275 East Main St., Mail Stop 2-WG, Frankfort, KY 40621. Telephone: (502) 564-7976. Internet: <http://www.workforcekentucky.ky.gov>

Louisiana

Director, Research and Statistics Division, Department of Labor, 1001 North 23rd St., Baton Rouge, LA 70804-9094. Telephone: (225) 342-3141. Internet: <http://www.laworks.net>

Maine

Director, Labor Market Information Services Division, Maine Department of Labor, 19 Union St., Augusta, ME 04332. Telephone: (207) 287-2271. Internet: <http://www.state.me.us/labor/lmis/index.html>

Maryland

Maryland Department of Labor, Licensing and Regulations, Office of Labor Market Analysis and Information, Room 316, 1100 North Eutaw St., Baltimore, MD 21201. Telephone: (410) 767-2250. Internet: <http://www.dllr.state.md.us/lmi/index.htm>

Massachusetts

Assistant Director of Economic Research, Massachusetts Division of Unemployment Assistance, 19 Staniford St., Boston, MA 02421. Telephone: (617) 626-6556. Internet: <http://www.detma.org/LMIdataprog.htm>

Michigan

Director, Bureau of Labor Market Information and Strategic Initiatives, Department of Labor and Economic Growth, 3032 West Grand Blvd., Suite 9-100, Detroit, MI 48202. Telephone: (313) 456-3100. Internet: <http://www.michlmi.org>

Minnesota

Research Director, Department of Employment and Economic Development, Labor Market Information Office, 1st National Bank Building, 332 Minnesota St., Suite E200, St. Paul, MN 55101-1351. Telephone: (651) 296-6545. Internet: <http://www.deed.state.mn.us/lmi>

Mississippi

Chief, Labor Market Information Division, Mississippi Department of Employment Security, 1235 Echelon Pkwy., Jackson, MS 39213. Telephone: (601) 321-6262. Internet: <http://mdes.ms.gov>

Missouri

LMI Research Manager, Missouri Economic Research and Information Center, P.O. Box 3150, Jefferson City, MO 65101-3150. Telephone: (573) 751-3637. Internet: <http://www.missourieconomy.org>

Montana

Research and Analysis Bureau, P.O. Box 1728, Helena, MT 59624. Telephone: (406) 444-2430. Internet: <http://www.ourfactsyourfuture.org>

Nebraska

Administrator, Nebraska Workforce Development-Labor Market Information, Nebraska Department of Labor, P.O. Box 4600, Lincoln, NE 68509-4600. Telephone: (402) 471-2600. Internet: <http://www.dol.state.ne.us/nelmi.htm>

Nevada

Chief, Research and Analysis, Department of Employment, Training and Rehabilitation, 500 East Third St., Carson City, NV 89713-0020. Telephone: (775) 684-0387. Internet: <http://www.detr.state.nv.us/lmi/index.htm>

New Hampshire

Director, Economic and Labor Market Information Bureau, New Hampshire Employment Security, 32 South Main St., Concord, NH 03301-4587. Telephone: (603) 228-4123. Internet: <http://www.nhes.state.nh.us/elmi>

New Jersey

Director, Division of Labor Market and Demographic Research, Department of Labor and Workforce Development, P.O. Box 388, Trenton, NJ 08625-0388. Telephone: (609) 984-2593. Internet: <http://www.state.nj.us/labor/lra>

New Mexico

Research Chief, New Mexico Department of Labor, Economic Research and Analysis, 501 Mountain Rd. NE, Albuquerque, NM 87102. Telephone: (505) 222-4684. Internet: <http://www.dol.state.nm.us/dol_lmif.html>

New York

Director, Research and Statistics, New York State Department of Labor, State Office Campus, Room 400, Albany, NY 12240. Telephone: (518) 457-3805. Internet: <http://www.labor.state.ny.us/> workforceindustrydata/index.asp

North Carolina

Director, Labor Market Information Division, Employment Security Commission, 700 Wade Ave., Raleigh, NC 27605. Telephone: (919) 733-2936. Internet: <http://www.ncesc.com>

North Dakota

Labor Market Information Manager, Job Service North Dakota, P.O. Box 5507, Bismarck, ND 58506-5507. Telephone: (701) 328-3136. Internet: <http://www.jobsnd.com/data/index.html>

Ohio

Chief, Bureau of Labor Market Information, Office of Workforce Development, Ohio Department of Job and Family Services, P.O. Box 1618, Columbus, OH 43216-1618. Telephone: (888) 296-7541, Option 6. Internet: <http://jfs.ohio.gov/owd/LaborMarket.stm>

Oklahoma

Labor Market Information, Oklahoma Employment Security Commission, P.O. Box 52003, Oklahoma City, OK 73152. Telephone: (405) 557-7221. Internet: <http://www.oesc.state.ok.us/lmi/default.htm>

Oregon

Oregon Employment Department, Attention: Research Division, Room 207, 875 Union St. NE., Salem, OR 97311. Telephone: (503) 947-1200. Internet: <http://www.qualityinfo.org/olmisj/OlmisZine>

Pennsylvania

Director, Center for Workforce Information and Analysis, Pennsylvania Department of Labor and Industry, 220 Labor and Industry Building, Seventh and Forster Sts., Harrisburg, PA 17121. Telephone: (877) 493-3282. Internet: <http://www.paworkstats.state.pa.us>

Puerto Rico

Economist, Labor Market Information Office, P.O. Box 195540, San Juan, Puerto Rico 00919-5540. Telephone: (787) 754-5347. Internet: <http://www.net-empleopr.org/almis23/index.jsp>

Rhode Island

Assistant Director, Labor Market Information, Rhode Island Department of Employment and Training, 1511 Pontiac Ave., Cranston, RI 02920. Telephone: (401) 462-8767. Internet: <http://www.dlt.ri.gov/lmi/>

South Carolina

Director, Labor Market Information Department, South Carolina Employment Security Commission, 631 Hampton St., Columbia, SC 29202. Telephone: (803) 737-2660. Internet: <http://www.sces.org/lmi/index.asp>

South Dakota

Director, Labor Market Information Center, Department of Labor, 420 S. Roosevelt St., Aberdeen, SD 57402-4730. Telephone: (605) 626-2314. Internet: <http://www.state.sd.us/dol/lmic/index.htm>

Tennessee

Director, Research and Statistics Division, Department of Labor and Workforce Development, 500 James Robertson Pkwy., 11th Floor, Nashville, TN 37245-1000. Telephone: (615) 741-2284. Internet: <http://www.state.tn.us/labor-wfd/lmi.htm>

Texas

Labor Market Information, Texas Workforce Commission, 9001 North IH-35, Suite 103A, Austin, TX 75753. Telephone: (512) 491-4800. Internet: <http://www.tracer2.com>

Utah

Director of Workforce Information, Utah Department of Workforce Services, 140 East 300 South, Salt Lake City, UT 84111. Telephone: (801) 526-9401. Internet: <http://jobs.utah.gov/opencms/wi>

Vermont

Chief, Research and Analysis, Vermont Department of Labor, P.O. Box 488, Montpelier, VT 05601-0488. Telephone: (802) 828-4202. Internet: <http://www.labor.vermont.gov>

Virgin Islands

Chief, Bureau of Labor Statistics, Department of Labor, P.O. Box 303359, St. Thomas, VI 00803-3359. Telephone: (340) 776-3700. Internet: <http://www.vidol.gov>

Virginia

Director, Economic Information Services, Virginia Employment Commission, 703 East Main St., Room 327, Richmond, VA 23218. Telephone: (804) 786-5496. Internet: <http://velma.virtuallmi.com>

Washington

Director, Labor Market and Economic Analysis, Washington Employment Security Department, P.O. Box 9046, Olympia, WA 98507-9046. Telephone: (360) 438-4804. Internet: <http://www.workforceexplorer.com>

West Virginia

WORKFORCE West Virginia, Research, Information and Analysis Division, 112 California Ave., Charleston, WV 25303-0112. Telephone: (304) 558-2660. Internet: <http://www.wvbep.org/bep/lmi>

Wisconsin

Director, Bureau of Workforce Information, Department of Workforce Development, 201 E. Washington Ave., Madison, WI 53702. Telephone: (608) 266-8212. Internet: <http://worknet.wisconsin.gov/worknet>

Wyoming

Manager, Research and Planning, Wyoming Department of Employment, P.O. Box 2760, Casper, WY 82602-2760. Telephone: (307) 473-3807. Internet: <http://doe.state.wy.us/lmi>

  


# Summer Work

**[Find Employment](/wiki/Find_Employment)**

This appendix page will discuss the topic of summer jobs, part-time work, or seasonal work.

Internet: <http://www.quintcareers.com/finding_summer_jobs.html>

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Find_Employment/Print_Version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

  


# Industries

**[Find Employment](/wiki/Find_Employment)**

The 2006-07 Career Guide to Industries — U.S. Department of Labor — Bureau of Labor Statistics — Bulletin 2601 — Career Guide to Industries, Overview and Outlook

The U.S. economy is comprised of industries with diverse characteristics. For each industry covered in the Career Guide, detailed information is provided about specific characteristics: The nature of the industry, working conditions, employment, occupational composition, training and advancement requirements, earnings, and job outlook. This chapter provides an overview of these characteristics and the outlook for the various industries and economy as a whole.

## Nature of the Industry

Industries are defined by the processes they use to produce goods and services. Workers in the United States produce and provide a wide variety of products and services and, as a result, the types of industries in the U.S. economy range widely�from agriculture, forestry, and fishing to aerospace manufacturing. Each industry has a unique combination of occupations, production techniques, inputs and outputs, and business characteristics. Understanding the nature of the industry is important because it is this unique combination that determines working conditions, educational requirements, and the job outlook for each of the industries discussed in the Career Guide.

Industries consist of many different places of work, called establishments. Establishments are physical locations in which people work, such as the branch office of a bank, a gasoline service station, a school, a department store, or a plant that manufactures machinery. Establishments range from large factories and corporate office complexes employing thousands of workers to small community stores, restaurants, professional offices, and service businesses employing only a few workers. Establishments should not be confused with companies or corporations, which are legal entities. Thus, a company or corporation may have a single establishment or more than one establishment. Establishments that use the same or similar processes to produce goods or services are organized together into industries. Industries are, in turn, organized together into industry groups. These are further organized into industry subsectors and then ultimately into industry sectors. For the purposes of labor market analysis, the Bureau of Labor Statistics organized industry sectors into industry supersectors. A company or corporation could own establishments classified in more than one industry, industry sector, or even industry supersector.

Each industry subsector is made up of a number of industry groups, which are, as mentioned, determined by differences in production processes. An easily recognized example of these distinctions is in the food manufacturing subsector, which is made up of industry groups that produce meat products, preserved fruits and vegetables, bakery items, and dairy products, among others. Each of these industry groups requires workers with varying skills and employs unique production techniques. Another example of these distinctions is found in utilities, which employs workers in establishments that provide electricity, natural gas, and water.

There were slightly more than 8 million private business establishments in the United States in March 2004. Business establishments in the United States are predominantly small; 59.9 percent of all establishments employed fewer than 5 workers in March 2004. However, the medium-sized to large establishments employ a greater proportion of all workers. For example, establishments that employed 50 or more workers accounted for only 4.6 percent of all establishments, yet employed 56.3 percent of all workers. The large establishments�those with more than 500 workers�accounted for only 0.2 percent of all establishments, but employed 17.3 percent of all workers. Table 1 presents the percent distribution of employment according to establishment size.

The average size of these establishments varies widely across industries. Most establishments in the construction, wholesale trade, retail trade, finance and insurance, real estate and rental and leasing, and professional, scientific, and technical services industries are small, averaging fewer than 20 employees per establishment. However, wide differences within industries can exist. Hospitals, for example, employ an average of 724.9 workers, while physicians� offices employ an average of 10.1. Similarly, although there is an average of 14.3 employees per establishment for all of retail trade, department stores employ an average of 124.1 people but jewelry stores employ an average of only 5.8.

Establishment size can play a role in the characteristics of each job. Large establishments generally offer workers greater occupational mobility and advancement potential, whereas small establishments may provide their employees with broader experience by requiring them to assume a wider range of responsibilities. Also, small establishments are distributed throughout the Nation�every locality has a few small businesses. Large establishments, in contrast, employ more workers and are less common, but they play a much more prominent role in the economies of the areas in which they are located.

Table 1. Percent distribution of establishments and employment in all private industries by establishment size, March 2004 Establishment size (number of workers) Establishments Employment

  


  
Total 100.0 100.0

  


  
1 to 4 59.9 6.8

5 to 9 16.9 8.4

10 to 19 11.1 11.2

20 to 49 7.6 17.3

50 to 99 2.6 13.3

100 to 249 1.4 16.4

250 to 499 0.4 9.3

500 to 999 0.1 6.6

1,000 or more 0.1 10.7

  


## Working Conditions

Just as the goods and services produced in each industry are different, working conditions vary significantly among industries. In some industries, the work setting is quiet, temperature-controlled, and virtually hazard free, while other industries are characterized by noisy, uncomfortable, and sometimes dangerous work environments. Some industries require long workweeks and shift work, but standard 40-hour workweeks are common in many other industries. In still other industries, a lot of the jobs can be seasonal, requiring long hours during busy periods and abbreviated schedules during slower months. Production processes, establishment size, and the physical location of work usually determine these varying conditions.

One of the most telling indicators of working conditions is an industry�s injury and illness rate. Overexertion, being struck by an object, and falls on the same level, are among the most common incidents causing work-related injury or illness. In 2003, approximately 5.0 million nonfatal injuries and illnesses were reported throughout private industry. Among major industry divisions, manufacturing and construction tied for the highest rate of injury and illness�6.8 cases for every 100 full time workers�while financial activities had the lowest rate�1.7 cases. About 5,700 work-related fatalities were reported in 2004; the most common events resulting in fatal injuries were transportation incidents, contact with objects and equipment, assaults and violent acts, and falls.

Work schedules are another important reflection of working conditions, and the operational requirements of each industry lead to large differences in hours worked and in part-time versus full-time status. In food services and drinking places, for example, fully 38.0 percent of employees worked part time in 2004 compared with only 1.5 percent in motor vehicles and motor vehicle equipment manufacturing. Table 2 presents industries having relatively high and low percentages of part-time workers.

Table 2. Part-time workers as a percent of total employment, selected industries, 2004 Industry Percent part-time

  


  
All industries 15.9

  


  
Many part-time workers

  
Food services and drinking places 38.0

Clothing and clothing accessories stores 33.1

Grocery stores 31.4

Arts, entertainment, and recreation 28.7

Child day care services 28.2

Social assistance 25.9

Motion picture and video industries 24.7

Educational services 21.0

  


  
Few part-time workers

  
Chemical manufacturing, except drugs 3.6

Aerospace product and parts manufacturing 3.3

Mining 3.3

Computer and electronic product manufacturing 3.2

Pharmaceutical and medicine manufacturing 2.7

Utilities 2.5

Iron and steel mills and steel product manufacturing 2.5

Motor vehicles and motor vehicle equipment manufacturing 1.5

The low proportion of part-time workers in some manufacturing industries often reflects the continuous nature of the production processes that makes it difficult to adapt the volume of production to short-term fluctuations in product demand. Once begun, it is costly to halt these processes; machinery must be tended and materials must be moved continuously. For example, the chemical manufacturing industry produces many different chemical products through controlled chemical reactions. These processes require chemical operators to monitor and adjust the flow of materials into and out of the line of production. Because production may continue 24 hours a day, 7 days a week under the watchful eyes of chemical operators who work in shifts, full-time workers are more likely to be employed. Retail trade and service industries, on the other hand, have seasonal cycles marked by various events that affect the hours worked, such as school openings or important holidays. During busy times of the year, longer hours are common, whereas slack periods lead to cutbacks in work hours and shorter workweeks. Jobs in these industries are generally appealing to students and others who desire flexible, part-time schedules.

## Employment

The total number of jobs in the United States in 2004 was 145.6 million. This included 12.1 million self-employed workers, 141,000 unpaid workers in family businesses, and 133.5 million wage and salary jobs�including primary and secondary job holders. The total number of jobs is projected to increase to 164.5 million by 2014, and wage and salary jobs are projected to account for more than 152.1 million of them.

As shown in table 3, wage and salary jobs are the vast majority of all jobs, but they are not evenly divided among the various industries. Education, health, and social services had the largest number of jobs in 2004 with almost 28 million. Manufacturing, construction, and utilities had almost 21.9 million jobs, including 14.3 million manufacturing and 7.0 million construction jobs. The trade supersector was nearly as large, with about 20.7 million jobs, followed by professional and business services with 16.4 million jobs in 2004. Among the industries covered in the Career Guide, wage and salary employment ranged from only 156,200 in steel manufacturing to over 13 million in health care. The three largest industries�education services, health care, and food services and drinking places�together accounted for 34.7 million jobs, over one-quarter of the Nation's wage and salary employment.

Table 3. Wage and salary employment in industries covered in the Career Guide, 2004 and projected change, 2004-14 (Employment in thousands) Industry 2004 2014 2004-14 Employment Percent distribution Employment Percent distribution Percent change Employment change

  


  
All industries 133,478 100.0 152,093 100.0 13.9 18,615

  


  
Agriculture and natural resources 1,672 1.3 1,567 1.0 -6.3 -105

Agriculture, forestry, and fishing 1,149 0.9 1,090 0.7 -5.2 -60

Mining 207 0.2 180 0.1 -12.9 -27

Oil and gas extraction 316 0.2 297 0.2 -6.1 -19

  


  
Manufacturing, construction, and utilities 21,864 16.4 21,872 14.4 0.0 8

Aerospace product and parts manufacturing 444 0.3 480 0.3 8.2 36

Chemical manufacturing, except drugs 596 0.5 510 0.3 -14.4 -86

Computer and electronic product manufacturing 1,326 1.0 1,232 0.8 -7.1 -94

Construction 6,964 5.2 7,757 5.1 11.4 792

Food manufacturing 1,498 1.1 1,555 1.0 3.8 57

Machinery manufacturing 1,142 0.9 995 0.7 -12.8 -146

Motor vehicle and parts manufacturing 1,109 0.8 1,171 0.8 5.6 62

Pharmaceutical and medicine manufacturing 291 0.2 367 0.2 26.1 76

Printing 665 0.5 600 0.4 -9.8 -65

Steel manufacturing 156 0.1 135 0.1 -13.4 -21

Textile, textile product, and apparel manufacturing 701 0.5 380 0.2 -45.8 -321

Utilities 570 0.4 563 0.4 -1.3 -8

  


  
Trade 20,689 15.5 22,814 15.0 10.3 2,125

Automobile dealers 1,254 0.9 1,407 0.9 12.2 153

Clothing, accessory, and general merchandise stores 4,205 3.1 4,628 3.0 10.1 423

Grocery stores 2,447 1.8 2,607 1.7 6.6 160

Wholesale trade 5,655 4.2 6,131 4.0 8.4 476

  


  
Transportation 4,250 3.2 4,756 3.1 11.9 506

Air transportation 515 0.4 560 0.4 8.8 45

Truck transportation and warehousing 1,907 1.4 2,174 1.4 14.0 267

  


  
Information 3,138 2.4 3,502 2.3 11.6 364

Broadcasting 327 0.2 362 0.2 10.7 35

Motion picture and video industries 368 0.3 430 0.3 17.1 63

Publishing, except software 671 0.5 715 0.5 6.5 44

Software publishers 239 0.2 400 0.3 67.6 161

Telecommunications 1,043 0.8 975 0.6 -6.5 -68

Internet services providers, web search portals, and data processing services 388 0.3 496 0.3 27.8 108

  


  
Financial activities 8,052 6.0 8,901 5.9 10.5 849

Banking 1,783 1.3 1,751 1.2 -1.8 -31

Insurance 2,260 1.7 2,476 1.6 9.5 215

Securities, commodities, and other investments 767 0.6 888 0.6 15.8 121

  


  
Professional and business services 16,414 12.3 20,980 13.8 27.8 4,566

Advertising and public relations services 425 0.3 520 0.3 22.4 95

Computer systems design and related services 1,147 0.9 1,600 1.1 39.5 453

Employment services 3,470 2.6 5,050 3.3 45.5 1,580

Management, scientific, and technical consulting services 779 0.6 1,250 0.8 60.5 471

Scientific research and development services 548 0.4 613 0.4 11.9 65

  


  
Education, health, and social services 27,973 20.957 34,399 22.6 23.0 6,426

Child day care services 767 0.6 1,062 0.7 38.4 295

Educational services 12,778 9.6 14,901 9.8 16.6 2,123

Health care 13,062 9.8 16,626 10.9 27.3 3,564

Social assistance, except child day care 1,365 1.0 1,810 1.2 32.6 445

  


  
Leisure and hospitality 12,479 9.3 14,694 9.7 17.7 2,215

Arts, entertainment, and recreation 1,833 1.4 2,293 1.5 25.1 460

Food services and drinking places 8,850 6.6 10,301 6.8 16.4 1,451

Hotels and other accommodations 1,796 1.3 2,100 1.4 16.9 304

  


  
Government and advocacy, grantmaking, and civic organizations 11,047 8.3 12,170 8.0 10.2 1,123

Advocacy, grantmaking, and civic organizations 1,231 0.9 1,410 0.9 14.5 179

Federal Government 1,943 1.5 1,993 1.3 2.5 50

State and local government, except education and health 7,872 5.9 8,767 5.8 11.4 895

  


  


Note
    May not add to totals due to omission of industries not covered in the Career Guide.

Although workers of all ages are employed in each industry, certain industries tend to possess workers of distinct age groups. For the previously mentioned reasons, retail trade employs a relatively high proportion of younger workers to fill part-time and temporary positions. The manufacturing sector, on the other hand, has a relatively high median age because many jobs in the sector require a number of years to learn and perfect specialized skills that do not easily transfer to other firms. Also, manufacturing employment has been declining, providing fewer opportunities for younger workers to get jobs. As a result, one-forth of the workers in retail trade were 24 years of age or younger in 2004, compared with only 8.2 percent of workers in manufacturing. Table 4 contrasts the age distribution of workers in all industries with the distributions in five very different industries.

Table 4. Percent distribution of wage and salary workers by age group, selected industries, 2004 Industry Age group 16 to 24 25 to 44 45 to 64 65 and older

  


  
All industries 14 47 36 4

  


  
Computer systems design and related services 7 63 29 1

Educational services 9 42 45 3

Food services and drinking places 44 39 15 2

Telecommunications 8 56 34 2

Utilities 5 43 50 2

Employment in some industries is concentrated in one region of the country. Such industries often are located near a source of raw or unfinished materials upon which the industry relies. For example, oil and gas extraction jobs are concentrated in Texas, Louisiana, and Oklahoma; many textile mills and products manufacturing jobs are found in North Carolina, South Carolina, and Georgia; and a significant proportion of motor vehicle manufacturing jobs are located in Michigan and Ohio. On the other hand, some industries�such as grocery stores and educational services�have jobs distributed throughout the Nation, reflecting the general population density.

## Occupations in the Industry

The occupations found in each industry depend on the types of services provided or goods produced. For example, because construction companies require skilled trades workers to build and renovate buildings, these companies employ large numbers of carpenters, electricians, plumbers, painters, and sheet metal workers. Other occupations common to construction include construction equipment operators and mechanics, installers, and repairers. Retail trade, on the other hand, displays and sells manufactured goods to consumers. As a result, retail trade employs numerous retail salespersons and other workers, including more than three-fourths of all cashiers. Table 5 shows the industry sectors and the occupational groups that predominate in each.

Table 5. Industry sectors and their largest occupational group, 2004 Industry sector Largest occupational group Percent of industry wage and salary jobs

  


  
Agriculture, forestry, fishing, and hunting Farming, fishing, and forestry occupations 61.1

Mining Construction and extraction occupations 33.3

Construction Construction and extraction occupations 66.2

Manufacturing Production occupations 52.1

Wholesale trade Sales and related occupations 24.7

Retail trade Sales and related occupations 52.5

Transportation and warehousing Transportation and material moving occupations 56.0

Utilities Installation, maintenance, and repair occupations 25.6

Information Professional and related occupations 29.1

Finance and insurance Office and administrative support occupations 51.4

Real estate and rental and leasing Sales and related occupations 22.7

Professional, scientific, and technical services Professional and related occupations 42.6

Management of companies and enterprises Office and administrative support occupations 33.6

Administrative and support and waste management and remediation services Office and administrative support occupations 23.2

Educational services, private Professional and related occupations 59.6

Health care and social assistance Professional and related occupations 42.6

Arts, entertainment, and recreation Service occupations 57.2

Accommodation and food services Service occupations 84.0

Government Professional and related occupations 43.7

The Nation�s occupational distribution clearly is influenced by its industrial structure, yet there are many occupations, such as general managers or secretaries, that are found in all industries. In fact, some of the largest occupations in the U.S. economy are dispersed across many industries. For example, professional and related occupations is among the largest in the Nation while also experiencing the fastest growth rate. . (See table 6.) Other large occupational groups include service occupations, office and administrative support occupations, sales and related occupations, and management, business, and financial occupations.

Table 6. Total employment and projected change by broad occupational group, 2004-14 (Employment in thousands) Occupational group Employment, 2004 Percent change, 2004-14

  


  
Total, all occupations 145,612 13.0

  


  
Professional and related occupations 28,544 21.2

Service occupations 27,673 19.0

Office and administrative support occupations 23,907 5.8

Sales and related occupations 15,330 9.6

Management, business, and financial occupations 14,987 14.4

Production occupations 10,562 -0.1

Transportation and material moving occupations 10,098 11.1

Construction and extraction occupations 7,738 12.0

Installation, maintenance, and repair occupations 5,747 11.4

Farming, fishing, and forestry occupations 1,026 -1.3

  


## Training and Advancement

Workers prepare for employment in many ways, but the most fundamental form of job training in the United States is a high school education. Better than 88 percent of the Nation�s workforce possessed a high school diploma or its equivalent in 2004. However, many occupations require more training, so growing numbers of workers pursue additional training or education after high school. In 2004, 28.7 percent of the Nation�s workforce reported having completed some college or an associate's degree as their highest level of education, while an additional 29.5 percent continued in their studies and attained a bachelor's or higher degree. In addition to these types of formal education, other sources of qualifying training include formal company-provided training, apprenticeships, informal on-the-job training, correspondence courses, Armed Forces vocational training, and non-work-related training.

The unique combination of training required to succeed in each industry is determined largely by the industry�s production process and the mix of occupations it requires. For example, manufacturing employs many machine operators who generally need little formal education after high school, but sometimes complete considerable on-the-job training. In contrast, educational services employs many types of teachers, most of whom require a bachelor�s or higher degree. Training requirements by industry sector are shown in table 7.

Table 7. Percent distribution of workers by highest grade completed or degree received, by industry sector, 2004 Industry sector High school diploma or less Some college or associate degree Bachelor's or higher degree

  


  
All industries 41.6 28.7 29.5

  


  
Agriculture, forestry, fishing, and hunting 64.3 21.4 14.2

Mining 60.4 21.8 17.8

Construction 64.7 24.5 10.8

Manufacturing 51.5 25.1 23.4

Wholesale trade 42.7 29.0 28.3

Retail trade 50.6 32.3 17.1

Transportation and warehousing 52.6 31.7 15.6

Utilities 38.7 34.1 27.0

Information 26.7 31.3 42.0

Finance and insurance 24.9 31.6 43.4

Real estate and rental and leasing 36.2 31.7 32.2

Professional, scientific, and technical services 14.4 25.1 60.6

Administrative and support and waste management services 55.3 28.4 16.3

Educational services 17.8 19.0 63.2

Health care and social assistance 30.6 34.8 34.7

Arts, entertainment, and recreation 39.5 31.8 28.6

Accommodation and food services 60.7 28.4 11.0

Persons with no more than a high school diploma accounted for about 64.7 percent of all workers in construction; 64.3 in agriculture, forestry, fishing, and hunting; 60.7 percent in accommodation and food services; 60.4 percent in mining; 51.5 percent in manufacturing; and 50.6 in retail trade. On the other hand, those who had acquired a bachelor�s or higher degree accounted for 63.2 percent of all workers in private educational services; 60.6 percent in professional, scientific, and technical services; 43.4 percent in finance and insurance; and 42.0 percent in information.

Education and training also are important factors in the variety of advancement paths found in different industries. Each industry has some unique advancement paths, but workers who complete additional on-the-job training or education generally help their chances of being promoted. In much of the manufacturing sector, for example, production workers who receive training in management and computer skills increase their likelihood of being promoted to supervisory positions. Other factors that impact advancement and that may figure prominently in the industries covered in the Career Guide include the size of the establishments, institutionalized career tracks, and the mix of occupations. As a result, persons who seek jobs in particular industries should be aware of how these advancement paths and other factors may later shape their careers.

## Earnings

Like other characteristics, earnings differ by industry, the result of a highly complicated process that reflects a number of factors. For example, earnings may vary due to the nature of occupations in the industry, average hours worked, geographical location, workers� average age, educational requirements, industry profits, and the degree of union representation of the workforce. In general, wages are highest in metropolitan areas to compensate for the higher cost of living. Also, as would be expected, industries that employ a large proportion of unskilled minimum-wage or part time workers tend to have lower earnings.

The difference in earnings of between the software publishers and the food services and drinking places industries illustrates how various characteristics of industries can result in great differences in earnings. In software publishers, earnings of all wage and salary workers averaged $1,342 a week in 2004, while in food service and drinking places, earnings of all wage and salary workers the averaged only $194 weekly. The difference is large primarily because software publishing establishments employ more highly skilled, full-time workers, while food services and drinking places employ many lower skilled workers on a part time basis. In addition, most workers in software publishing are paid an annual salary, while many workers in food service and drinking places are paid an hourly wage, but many are able to supplement their low hourly wage rate with money they receive as tips. Table 8 highlights the industries with the highest and lowest average weekly earnings.

Table 8. Average weekly earnings of production or nonsupervisory workers on private nonfarm payrolls, selected industries, 2004 Industry Earnings

  


  
All industries $529

  


  
Industries with high earnings

  
Software publishers 1,342

Computer systems design and related services 1,136

Aerospace product and parts manufacturing 1,019

Scientific research and development services 1,006

Motor vehicle and parts manufacturing 925

Mining 909

  


  
Industries with low earnings

  
Food manufacturing 510

Grocery stores 332

Arts, entertainment, and recreation 313

Hotels and other accommodations 302

Child day care services 299

Food services and drinking places 194

Employee benefits, once a minor addition to wages and salaries, continue to grow in diversity and cost. In addition to traditional benefits�paid vacations, life and health insurance, and pensions�many employers now offer various benefits to accommodate the needs of a changing labor force. Such benefits sometimes include childcare, employee assistance programs that provide counseling for personal problems, and wellness programs that encourage exercise, stress management, and self-improvement. Benefits vary among occupational groups, full- and part-time workers, public and private sector workers, regions, unionized and nonunionized workers, and small and large establishments. Data indicate that full-time workers and those in medium-sized and large establishments�those with 100 or more workers�usually receive better benefits than do part-time workers and those in smaller establishments.

Union representation of the workforce varies widely by industry, and it also may play a role in determining earnings and benefits. In 2004, about 13.8 percent of workers throughout the Nation were union members or covered by union contracts. As table 9 demonstrates, union affiliation of workers varies widely by industry. Fully 50.0 percent of the workers in air transportation were union members, the highest rate of all the industries, followed by 37.6 percent in educational services, and 33.0 percent in iron and steel mills and steel product manufacturing. Industries with the lowest unionization rate include computer systems design and related services, 1.3 percent; food services and drinking places, 1.7 percent; and advertising and related services, 1.7 percent.

Table 9. Union members and other workers covered by union contracts as a percent of total employment, selected industries, 2004 Industry Percent union members or covered by union contract

  


  
All industries 13.8

  


  
Industries with high unionization rates

  
Air transportation 50.0

Educational services 37.6

Iron and steel mills and steel product manufacturing 33.0

Motor vehicles and motor vehicle equipment manufacturing 30.2

  


  
Industries with low unionization rates

  
Banking and related activities 1.9

Advertising and related services 1.7

Food services and drinking places 1.7

Computer systems design and related services 1.3

  


## Outlook

Total employment in the United States is projected to increase by about 14 percent over the 2004-14 period. Employment growth, however, is only one source of job openings. The total number of openings in any industry also depends on the industry�s current employment level and its need to replace workers who leave their jobs. Throughout the economy, replacement needs will create more job openings than will employment growth. Employment size is a major determinant of job openings�larger industries generally have larger numbers of workers who must be replaced and provide more openings. The occupational composition of an industry is another factor. Industries with high concentrations of professional, technical, and other jobs that require more formal education�occupations in which workers tend to leave their jobs less frequently�generally have fewer openings resulting from replacement needs. On the other hand, more replacement openings generally occur in industries with high concentrations of service, laborer, and other jobs that require little formal education and have lower wages because workers in these jobs are more likely to leave their occupations.

Employment growth is determined largely by changes in the demand for the goods and services provided by an industry, worker productivity, and foreign competition. Each industry is affected by a different set of variables that determines the number and composition of jobs that will be available. Even within an industry, employment may grow at different rates in different occupations. For example, changes in technology, production methods, and business practices in an industry might eliminate some jobs, while creating others. Some industries may be growing rapidly overall, yet opportunities for workers in occupations could be stagnant or even declining because they are adversely affected by technological change. Similarly, employment of some occupations may be declining in the economy as a whole, yet may be increasing in a rapidly growing industry.

As shown above in table 3, employment growth rates over the next decade will vary widely among industries. Agriculture and natural resources is the only sector in which all of the industries are expected to experience employment declines. Consolidation of farm land, increasing worker productivity, and depletion of wild fish stocks should continue to decrease employment in agriculture, forestry, and fishing. Employment in mining is expected to decline due to laborsaving technology while jobs in oil and gas extraction are expected to decrease with the continued reliance on foreign sources of energy.

Employment in manufacturing, construction, and utilities is expected to remain nearly unchanged as growth in construction is partially offset by declines in utilities and selected manufacturing industries. Growth in construction employment will stem from new factory construction as existing facilities are modernized; from new school construction, reflecting growth in the school-age population; and from infrastructure improvements, such as road and bridge construction. Employment declines are expected in chemical manufacturing, except drugs; machinery manufacturing; computer and electronic product manufacturing; printing; steel manufacturing; and textile, textile product, and apparel manufacturing. Textile, textile product, and apparel manufacturing is projected to lose about 321,200 jobs over the 2004-14 period�more than any other manufacturing industry�due primarily to increasing imports replacing domestic products.

Employment gains are expected in some manufacturing industries. Small employment gains in food manufacturing is expected, as a growing and ever more diverse population increases the demand for manufactured food products. Employment growth in pharmaceutical and medicine manufacturing is expected, as sales of pharmaceuticals increase with growth in the population, particularly among the elderly, and with the introduction of new medicines to the market. Both food and pharmaceutical and medicine manufacturing also have growing export markets. Aerospace product and parts manufacturing and motor vehicle and parts manufacturing are both expected to have modest employment increases.

Growth in overall employment will result primarily from growth in service-providing industries over the 2004-14 period, almost all of which are expected to have increasing employment. Job growth is expected to be led by health care and educational services�the two largest industries discussed in the Career Guide�with large numbers of new jobs also in employment services, food services and drinking places, state and local government, and wholesale trade. When combined, these sectors will account for almost half of all new wage and salary jobs across the Nation. Employment growth is expected in many other service-providing industries discussed in the Career Guide, but they will result in far fewer numbers of new jobs.

Health care will account for the most new wage and salary jobs, about 3.6 million over the 2004-14 period. Population growth, advances in medical technologies that increase the number of treatable diseases, and a growing share of the population in older age groups will drive employment growth. Offices of physicians, the largest health care industry group, is expected to account for about 760,000 of these new jobs as patients seek more health care outside of the traditional inpatient hospital setting.

Educational services is expected to grow by nearly 17 percent over the 2004-14 period, adding about 2.1 million new jobs. A growing emphasis on improving education and making it available to more children and young adults will be the primary factors contributing to employment growth. Employment growth at all levels of education is expected, particularly at the postsecondary level, as children of the baby boomers continue to reach college age, and as more adults pursue continuing education to enhance or update their skills.

Employment in one of the Nation�s fastest growing industries�employment services�is expected to increase by more than 45 percent, adding another 1.6 million jobs over the 2004-14 period. Employment will increase, particularly in temporary help services and professional employer organizations, as businesses seek new ways to make their workforces more specialized and responsive to changes in demand.

The food services and drinking places industry is expected to add almost 1.5 million new jobs over the 2004-14 projection period. Increases in population, dual-income families, and dining sophistication will contribute to job growth. In addition, the increasing diversity of the population will contribute to job growth in food services and drinking places that offer a wider variety of ethnic foods and drinks.

Over 890,000 new jobs are expected to arise in State and local government, adding over 11 percent over the 2004-14 period. Job growth will result primarily from growth in the population and its demand for public services. Additional job growth will result as State and local governments continue to receive greater responsibility for administering federally funded programs from the Federal Government.

Wholesale trade is expected to add almost 480,000 new jobs over the coming decade, reflecting growth both in trade and in the overall economy. Most new jobs will be for sales representatives at the wholesale and manufacturing levels. However, industry consolidation and the growth of electronic commerce using the Internet are expected to limit job growth to 8.4 percent over the 2004-14 period, less than the 14 percent projected for all industries.

Continual changes in the economy have far-reaching and complex effects on employment in each of the industries covered in the Career Guide. Jobseekers should be aware of these changes, keeping alert for developments that can affect job opportunities in industries and the variety of occupations that are found in each industry. For more detailed information on specific occupations, consult the 2006-07 edition of the Occupational Outlook Handbook, which provides information on hundreds of occupations.

  


Last Modified Date: January 17, 2006 Source: Bureau of Labor Statistics

  


# Resources

**[Find Employment](/wiki/Find_Employment)**

## Resources

Some material quoted from the Occupational Outlook Handbook (OOH), 2006-07 Edition

    <http://www.bls.gov/oco/>

The original text of this book is provided by the US Department of Labor and was in the public domain

    <http://www.bls.gov/oco/oohinfo_faq.htm?/oco/home.htm#pub3>

Any references here to "the Handbook" refers to this book.

Some material quoted from various U.S. Department of Labor websites, all in the public domain.

  


# Licensing

**[Find Employment](/wiki/Find_Employment)**

## Licensing

The text of this book is released under the following license:

![GNU head](//upload.wikimedia.org/wikipedia/commons/thumb/2/22/Heckert_GNU_white.svg/50px-Heckert_GNU_white.svg.png)
Permission is granted to copy, distribute and/or modify this document under the terms of the **[GNU Free Documentation License](//en.wikipedia.org/wiki/GNU_Free_Documentation_License)**, Version 1.2 or any later version published by the [Free Software Foundation](//en.wikipedia.org/wiki/Free_Software_Foundation); with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts. A copy of the license is included in the section entitled "[GNU Free Documentation License](/wiki/GNU_Free_Documentation_License)."

  


Some initial text and contributions are derived from the US Department of Labor. All US Government published resources are released into the Public Domain.

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Find_Employment/Print_Version&oldid=1071840](http://en.wikibooks.org/w/index.php?title=Find_Employment/Print_Version&oldid=1071840)" 

[Category](/wiki/Special:Categories): 

  * [Find Employment](/wiki/Category:Find_Employment)

Hidden categories: 

  * [Books to be merged](/wiki/Category:Books_to_be_merged)
  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Find+Employment%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Find+Employment%2FPrint+Version)

### Namespaces

  * [Book](/wiki/Find_Employment/Print_Version)
  * [Discussion](/w/index.php?title=Talk:Find_Employment/Print_Version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Find_Employment/Print_Version)
  * [Edit](/w/index.php?title=Find_Employment/Print_Version&action=edit)
  * [View history](/w/index.php?title=Find_Employment/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Find_Employment/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Find_Employment/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Find_Employment/Print_Version&oldid=1071840)
  * [Page information](/w/index.php?title=Find_Employment/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Find_Employment%2FPrint_Version&id=1071840)

### In other languages

  * [Ελληνικά](//el.wikibooks.org/wiki/%CE%95%CF%8D%CF%81%CE%B5%CF%83%CE%B7_%CE%95%CF%81%CE%B3%CE%B1%CF%83%CE%AF%CE%B1%CF%82/%CE%95%CE%BA%CF%80%CE%B1%CE%AF%CE%B4%CE%B5%CF%85%CF%83%CE%B7_%CE%BA%CE%B1%CE%B9_%CE%95%CE%BE%CE%AC%CF%83%CE%BA%CE%B7%CF%83%CE%B7)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Find+Employment%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Find+Employment%2FPrint+Version&oldid=1071840&writer=rl)
  * [Printable version](/w/index.php?title=Find_Employment/Print_Version&printable=yes)

  * This page was last modified on 31 December 2007, at 14:52.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Find_Employment/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
