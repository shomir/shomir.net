# Patterns Of Screen Writing/Print version

From Wikibooks, open books for an open world

< [Patterns Of Screen Writing](/wiki/Patterns_Of_Screen_Writing)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&stable=1) was [approved](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Patterns_Of_Screen_Writing/Print_version) on _7 August 2011_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&oldid=2153955&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Patterns Of Screen Writing](/wiki/Patterns_Of_Screen_Writing)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=purge&printable=yes) this page.

  


## Contents[[edit](/w/index.php?title=Patterns_Of_Screen_Writing&action=edit&section=T-1)]

  * [Introduction](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Introduction&action=edit&redlink=1)![50 percents developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
  * [Style Guide](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Style_Guide&action=edit&redlink=1)![25 percents developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  * [Pattern Template](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Pattern_Template&action=edit&redlink=1)![0% developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  * [Planning](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Planning&action=edit&redlink=1)![0% developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)

    

  * [Viewer's Perspective](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Planning/Viewer%27s_Perspective&action=edit&redlink=1)![75 percents developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
  * [Law Of Variation](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Planning/Law_Of_Variation&action=edit&redlink=1)![25 percents developed  as of 09:13, 5 August 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)

  * Appendices

    

  * [Contributors](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Contributors&action=edit&redlink=1)![0% developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  * [Bibliography](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Bibliography&action=edit&redlink=1)![0% developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  * [Filmography](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Filmography&action=edit&redlink=1)![0% developed  as of 09:13, 29 July 2011 \(UTC\)](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)

![reel](//upload.wikimedia.org/wikipedia/commons/thumb/0/04/Veckans_samarbete_rund.svg/107px-Veckans_samarbete_rund.svg.png)

[Patterns Of Screen Writing](/wiki/Patterns_Of_Screen_Writing)  
_Time-Tested Solutions to Recurring Problems in Screenwriting_  
[Contents](/wiki/Patterns_Of_Screen_Writing/Contents) • [Introduction](/wiki/Patterns_Of_Screen_Writing/Introduction)  
[Planning Patterns](/wiki/Patterns_Of_Screen_Writing/Planning) • [Structural Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Structure&action=edit&redlink=1) • [Exposition Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Exposition&action=edit&redlink=1)  
[Character Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Character&action=edit&redlink=1) • [Generic Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Generic&action=edit&redlink=1) • [Pathos Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Pathos&action=edit&redlink=1)  
[Dialogue Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Dialogue&action=edit&redlink=1) • [Writing & Rewriting Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Rewriting&action=edit&redlink=1) •  
[Glossary](/w/index.php?title=Patterns_Of_Screen_Writing/Pronunciation&action=edit&redlink=1) • [Contributors](/wiki/Patterns_Of_Screen_Writing/Contributors) • [Bibliography](/wiki/Patterns_Of_Screen_Writing/Bibliography)  


![Applications-multimedia.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Applications-multimedia.svg/55px-Applications-multimedia.svg.png)

  


![reel](//upload.wikimedia.org/wikipedia/commons/thumb/0/04/Veckans_samarbete_rund.svg/107px-Veckans_samarbete_rund.svg.png)

## Intended Audience[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Introduction&action=edit&section=T-1)]

The intended audience of this text is primarily authors interested in screenwriting. It would also prove useful to any aspiring _storyteller_**storyteller**, whether she is writing a novella or he is preparing an important presentation. The text attempts to covers all aspects of story development for screenwriting. The rationale is to break down story to its constituents elements and explain how each should be put together most effectively. In this way we treat planning, selection of structure, matching action to the character. The craft of writing, rewriting are also covered, how to _evoking emotions_**evoking emotions** and how to deliver a message while entertaining the audience. At the highest level of storytelling the writer is able to control all these elements and deliver a quality product within a tight schedule.

## Scope[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Introduction&action=edit&section=T-2)]

The book has much to offer both beginner and experienced writers alike. Most screenwriting techniques can be adapted to other media once the difference each is understood. These can be the traditional forms like a short story, a novella or theatrical play. It can also arise in less traditional settings like a computer game; a business presentation or an animated commercial. As media, diverge underlying assumptions may change. In screenwriting, storytelling is principally visual.

## Visual Storytelling[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Introduction&action=edit&section=T-3)]

Visual storytelling has subtle restrictions dictated by the media of film. The advice most commonly heard by new screenwriters is "show, don’t tell". This means dramatizing any aspect of the story that is not already in the action. The difficulty is to use the available devices to illuminate a character's inner world. You might consider using a disembodied voice to instruct the audience of some thought going in the heroine's mind using voice over _narration_**narration**? This might be possible but there are other techniques possible. In a movie, the eye assimilates 90% of the information and the ear the other 10%. For the stage, the assimilation of information reverses. This is the root of most difficulties adapting problems faced in adapting plays to the screen. Even the outstanding to _dialogue_ **dialogue** and monologues quickly become artificial and tiresome without visual action that the eye expects. The problem does not end here. A single talking head alone on-screen has very limited visual possibilities. The eye exhausts the visual information in a good shot in two seconds after which it will start to wonder. Few actors can deliver their narration as effectively as _Woody Allen_ [P 1] the standup comedian; screenwriter; actor director . When speaking off-screen his expressiveness diminishes, his dialogue loses its subtext and soon his audience grows restless. When less gifted actors deliver his narrations, the effect is disastrous. Show, don’t tell. The stringent requirements of visual storytelling do not bind other prose writers. They can freely enlist metaphor; listen in on a character's inner voice and shape structures of complexity that is unworkable into _120 pages_**120 pages** of a screenplay. This is not a place to analyze the differences of each media. It appears that the discipline and economy of screenwriting will benefit to any creative writer. Even with the differences in media, most of the patterns would serve any storyteller. Where medium specific aspects of film making are encountered they will be accompanied by this icon

![reel](//upload.wikimedia.org/wikipedia/commons/thumb/0/04/Veckans_samarbete_rund.svg/107px-Veckans_samarbete_rund.svg.png)

[Patterns Of Screen Writing](/wiki/Patterns_Of_Screen_Writing)  
_Time-Tested Solutions to Recurring Problems in Screenwriting_  
[Contents](/wiki/Patterns_Of_Screen_Writing/Contents) • [Introduction](/wiki/Patterns_Of_Screen_Writing/Introduction)  
[Planning Patterns](/wiki/Patterns_Of_Screen_Writing/Planning) • [Structural Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Structure&action=edit&redlink=1) • [Exposition Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Exposition&action=edit&redlink=1)  
[Character Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Character&action=edit&redlink=1) • [Generic Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Generic&action=edit&redlink=1) • [Pathos Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Pathos&action=edit&redlink=1)  
[Dialogue Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Dialogue&action=edit&redlink=1) • [Writing & Rewriting Patterns](/w/index.php?title=Patterns_Of_Screen_Writing/Rewriting&action=edit&redlink=1) •  
[Glossary](/w/index.php?title=Patterns_Of_Screen_Writing/Pronunciation&action=edit&redlink=1) • [Contributors](/wiki/Patterns_Of_Screen_Writing/Contributors) • [Bibliography](/wiki/Patterns_Of_Screen_Writing/Bibliography)  


![Applications-multimedia.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Applications-multimedia.svg/55px-Applications-multimedia.svg.png)

  


![reel](//upload.wikimedia.org/wikipedia/commons/thumb/0/04/Veckans_samarbete_rund.svg/107px-Veckans_samarbete_rund.svg.png)

# Planning Patterns[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning&action=edit&section=T-1)]

Hollywood folklore is rife with stories about a professional writers pressured by an impossible deadlines into writing a screenplay for an award-winning movie. In reality, professional screenwriters require between three months to a year to write a quality screenplay. If you are not yet making a living from writing you will need to spend more time to polish and tighten your stories.

### What Are Planning Patterns?[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning&action=edit&section=T-2)]

The common denominator of planning patterns is an aim to manage your project in a way that minimizes risks. These risks include commercial issues related to marketing, missing deadlines, creating an untenable structure, improving story quality.

### Reducing Risks[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning&action=edit&section=T-3)]

The risk involved in writing a screenplay are manyfold. A writer will have to invest time and effort in researching, planning and writing. It might be done as a speculation or under contract for a client. So once the writing the writer needs to sell it, and a success will mean further requirments and further rewrites.

By taking professional attitude it is possible to that reduce the above risks so that the efforts will turn out to concrete results. You will get a second round of benefits once you close a deal that requires work with a development or production team.

For each hour spent planning, you will save tenfold on unproductive activities. With a fully planed story on the drawing board, the second and third acts will write themselves.

You will still need great tenacity and rewrite several drafts. The difference is that you will have the confidence to shape the story, improve structure, strengthen characters, and intensify conflict, deepen emotional impact and send the viewers a coherent and meaningful statement.

Finally, it is superior planning which will enable you to unleash your full creative potential.

### Focus[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning&action=edit&section=T-4)]

  * How to tap into your creative potential for original ideas; fresh points of view and understand breakthrough in genre. ([Brainstorming](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Brainstorming&action=edit&redlink=1))
  * Succinctly define a dramatic premise in such a way that it can permeate all levels of story crystallizing them into a coherent structure. ([Logline](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Logline&action=edit&redlink=1); [Moral Premise](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Moral_Premise&action=edit&redlink=1))
  * Work out the narrative and the necessary back-story.([The Board](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/The_Board&action=edit&redlink=1); [Storyboard](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Storyboard&action=edit&redlink=1) )
  * Build up interest by a rhythmically varying their perspective between suspense mystery and dramatic irony.([Viewer's Perspective](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Viewer%27s_Perspective&action=edit&redlink=1))
  * Enhance your creative output. ([Concept of Artistic Limitation](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Concept_of_Artistic_Limitation&action=edit&redlink=1);[Law of Variation](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Law_of_Variation&action=edit&redlink=1))

Patterns in later sections such as structure, character, conflict, and dialogue will also collaborate with these planning patterns by contributing much detail to the plan, subsequently reducing the scope of later planning tasks. However, it is the patterns in this section, which form the foundation of the story structure. Why are they so important?

Essentially, planning patterns assist you to reduce the risk of ending up with partial project or an unsalable-draft. They will allow you organize your work logically; Break up big daunting task into easily managed ones; economize your time and maximize the impact of you effort. Finally planning is a part of establishing a routine of disciplined writing.

## The Patterns[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning&action=edit&section=T-5)]

  * [Brainstorming](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Brainstorming&action=edit&redlink=1)
  * [Logline](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Logline&action=edit&redlink=1)
  * [Moral Premise](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Moral_Premise&action=edit&redlink=1)
  * [Viewer's Perspective](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Viewer%27s_Perspective&action=edit&redlink=1)
  * [Concept Of Artistic Limitation](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Concept_Of_Artistic_Limitation&action=edit&redlink=1)
  * [Law Of Variation](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Law_Of_Variation&action=edit&redlink=1)
  * [The Board](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/The_Board&action=edit&redlink=1)
  * [Storyboard](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Storyboard&action=edit&redlink=1)

==Case Studies==

  


## Patterns Of Screen Writing/Planning/Viewer's Perspective[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-1)]

“
There is no terror in the bang, only in the anticipation of it.
”

—Alfred Hitchcock

  


### Intent[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-2)]

Make and break information asymmetry between audience and the characters.

### Also Known As[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-3)]

Mystery; Suspense; Dramatic irony; Tension release laughter; Comic distance; Emotional Rhythm

### Motivation[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-4)]

It is necessary to be aware which crucial elements of the plot have been revealed to which characters and if the audience is also in the know.

It is possible to create a powerful dynamic within the story simply by controlling the flow of information regarding (an incident). In the most basic form it is possible to dramatizing the effect as it is revealed to a sequence of characters. In the next level of sophistication individuals will face a dilemma whether to disseminate or to withhold crucial knowledge.

**Example of: Tragedy**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

In **Mystic River** the plot is framed by a police investigation. The main characters **Jimmy Markum** (_Sean Penn_)[P 2], **Dave Boyle** (_Tim Robbins_)[P 3] and **Sean Devine** (_Kevin Bacon_)[P 4] once close are drawn together by the murder of Jimmy's daughter. Sean became a cop, Jimmy is an (ex)con and Dave who was abducted by child molesters in the first act is now a blue-collar labourer. In the final analysis there is little action taking place in Mystic River. Yet the story builds interest and emotion as the audience are shown the trail of information reaching the three friends. In the final act climax Jimmy confronts Dave and accuses him of the murder. It is soon revealed that the Jimmy is only seeing part of the picture.

 —Eastwood, C. (Director). (2003). _[Mystic River_](http://www.imdb.com/title/0327056/). [Motion picture]. <http://www.imdb.com/title/0327056/>. [F 1]

  
A single incident can elicit curiosity, mystery, suspense, dread, and comic release. The emotional reactions created depends on how the action is presented to the viewers. These are discussed in detail in [/pathos/mystery](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/pathos/mystery&action=edit&redlink=1) [/pathos/suspense](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/pathos/suspense&action=edit&redlink=1) and [/pathos/dramatic irony](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/pathos/dramatic_irony&action=edit&redlink=1) patterns.

Many aspects of the viewers point of view , the largest and most readily perceptible is information. It depends on different Ideally, each is present in some degree in every story. These ingredients can be created by manipulating the view’s point of view. By auditing the information made available to the viewers you can change their point of view.

Many of the dramatic effects in a story depend on how the story unfolds.

### Applicability[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-5)]

  * Emotions 
    * limited gamut of emotions
  * Exposition 
    * too much or too little information
  * Scenes 
    * too predictable
    * undermined by insufficient emotional variety
  * Conflict 
    * jumping conflict
    * foreshadowing too brief

### Structure[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-6)]

If X is the character, whose point of view owns the current narrative line, then:

#### Technique 1. Narrative Perspective[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-7)]

When the audience discovers information together with character X we say they are in narrative perspective. This perspective generates suspense. This by far the most common technique used to hold the compel the viewer’s interest. They have anxiety over the ending and fear for the protagonist fate.

**Example of: Narrative Perspective**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 2. Inferior Perspective[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-8)]

When the audience knows less than characters X say they are in inferior position to X. This perspective elicits curiosity and mystery. Breaking to narrative perspective by revealing the missing information end the mystery. It is possible to create a false sense of inferior perspective, by offering the audience a false clues using an intermediatry (an unreliable narrator) or directly (confunding). It is difficult to sustain mystery overtime unless you are working on a Murder Mystery.

**Example of: Inferior Perspective**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

Inferior perspective is used in North by Northwest. "The Professor" tries to convince the Protagonist, **Mr Thornhill** (_Carry Grant_)[P 5] to save the love interest from mortal danger. It seems a lost cause but as they step closer to a plane noise drowns out the dialogue placing the audience in an inferior perspective.

 —Lehman E. (Writer); Hitchcock, A. (Director). (1959). _[North by Northwest_](http://www.imdb.com/title/tt0053125/). [Motion picture]. <http://www.imdb.com/title/tt0053125/>. [F 2]

  


#### Technique 3. Superior Perspective[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-9)]

When the audience knows more than characters X say they are in superior position to X. This perspective produces suspense and dread of the discovery of what we already know. It can also sustain curiosity since the viewer’s information is limited. The question is how it will happen? the question of how Breaking to narrative creates relief, but before we break we could increase out superior perspective make his situation effectively worse a couple of times

**Example of: Superior Perspective**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

He foreshadows a death using "These cymbals will decide a man’s life" Placing the audience immediately in superior perspective. Creating curiosity which together with sympathy for the protagonists turns to dread. But the incident with the cymbals is not the third act climax. The the second act climax is preceded by a sequence in Albert Hall that runs 12 minutes without any dialogue, from the beginning of Storm Cloud Cantata until the climax, when the Doris Day character screams. By the end of the turning point, the audience is once again in superior perspective.

  


#### Technique 4. Foreshadowing[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-10)]

The [Exposition/Foreshadowing/](/w/index.php?title=Exposition/Foreshadowing/&action=edit&redlink=1) pattern is yet another method that can be used to alter the viewer's perspective. Since foreshadowing is the promise future conflict it should be used to build up the action gradually.

**Example of: Foreshadowing**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 5. Comic distance[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-11)]

The comic perspective means suspending empathy.

**Example of: Foreshadowing**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

One of the main aspect of comedy is that no matter the misfortune inflicted on the characters we can look at at it and laugh. If empathy would not be suspended we would cry at their misfortunes.

#### Technique 6. Diminishing[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-12)]

Repeated application of the same techniques twice will have diminished results the second time. The third time it can have a reversed effect. In some genres, this has become a convention. Hitchcock NNW uses this type of pattern. Following the second set piece. It ends in an impasse that _Thornhill_ must overcome though action.

**Example of: Diminishing**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 7. Reversal into Laughter[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-13)]

Repeated application of the same techniques more than twice will numb the viewers and can be used to produce comic distance. When this is the intended effect it is called a reversal into Laughter. In some genres, this has become a convention. Hitchcock NNW uses this type of pattern. Following the second set piece. It ends in an impasse that _Thornhill_ must overcome though action.

#### Technique 8. Unreliable Narrator [1][[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-14)]

“
A lot of recent films seem unsatisfied unless they can add final scenes that redefine the reality of everything that has gone before; call it the _Keyser Söze_ syndrome.
”

—Roger Ebert [2]

A narrator who misinforms his listeners is called a **unreliable narrator**. The misinformation places the audience in an **inferior position**. Such a situation can then be dramatically reversed as follows:

  * By revealing the narrator's lie without revealing the secret. (maintains **inferior position**).
  * By revealing the lie and reveling the truth but only to the viewers. (Switching to **superior position**).
  * By revealing the lie to the viewers and the point of view character. (Switching to **narrative position**).
  * By creating ambiguity by creating revealing alternative version of the truth without passing judgment on the narrator. (maintains **inferior position**).

Some classical examples illuminate these possibilities:

**Example of: Three Agendas in Roshmon**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

The film _Rashomon_ (1950), uses multiple narrators to retell the story of the death of a samurai. Each witnesses describe the same basic events but the subjective views cannot be reconciled, alternately they claim the samurai died by accident, suicide, or murder. Only one at best could be a reliable story-teller. The term _Rashomon effect_ is used to describe how different witnesses are able to produce incompatible, yet plausible, accounts of the same event.

 —Kurosawa, A. (Director). (1950). _[Rashomon_](http://www.imdb.com/title/tt0053125/). [Motion picture]. <http://www.imdb.com/title/tt0053125/>. [F 3]

  


**Example of: Narrator as Trickster**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

American neo-noir film **The Usual Suspects** (1995) is told mostly from the perspective of con artist **Roger "Verbal" Kint** (_Kevin Spacey_)[P 6] about his dealings with quasi-mythical criminal mastermind _Keyser Söze_. In the end, 'Kint' is revealed to have concocted much of the story based upon observations of the room he was in. Even on repeated viewings, it's impossible to tell how much of the story is real, and how much is invented by _Kint_ (an aspect of the film not even its creators can agree on)

 —Bryan Singer (Director) Christopher McQuarrie (Writer). (1995). _[The Usual Suspects_](http://www.imdb.com/title/tt0053125/). [Motion picture]. <http://www.imdb.com/title/tt0053125/>. [F 4]

  
A mentally impaired narrator may describe the world as they perceive it rather than as it really is. A similar effect can be arise from the narration by a child (naive) Except that a child's point of view is much more amiable to empathy - we were all once more naive and can take some humour from this point of view while a mentally defective point of view is harder to empathise with.

**Example of: Unreliable due to Senile Dementia**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

In the film _Amadeus_ which is narrated by an elderly **Antonio Salieri** (_F. Murray Abraham_)[P 7] from an insane asylum, where he claims to have murdered his rival, Wolfgang Amadeus Mozart. It is left unclear whether the story actually happened, or whether it is the product of Salieri's delusions; this is especially ambiguous and could be missed by an audience unfamiliar with the Salieri's or Mozart's biograpy.

 —Peter Shaffer (Writer) Milos Forman (Director). (1999). _[Amadeus_](http://www.imdb.com/title/tt0086879/). [Motion picture]. <http://www.imdb.com/title/tt0086879/>. [F 5]

  


**Example of: Unreliable due to a split personality**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

In the film _Fight Club_, the narrator's best friend, **Tyler Durden** (_Brad Pitt_)[P 8], is—unbeknownst to the narrator—an aspect of his own split personality, meaning that everything Tyler does is actually being carried out (or imagined by) the narrator.

 —Jim Uhls (Adaptation) David Fincher (Director). (1999). _[Fight Club_](http://www.imdb.com/title/tt0137523/). [Motion picture]. <http://www.imdb.com/title/tt0137523/>. [F 6]

  
The most elusive and probably the hardest to or prehaps the most elusive - is a _reluctent_ narrator - one who is unreliable because he or she chooses to ignore the truth.

**Example of: Reluctent Narrator**

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

In the film The Remains of the day, **James Stevens** (_Anthony Hopkins_)[P 9] is the protagonist whose role is as an English Butler. Throughout the story he repeatedly ignores other people's plight, showing little kindness to his colleagues or even his father. He also disregards and his own inner drive with a major personal cost. All this is done under a pretext of blindly following his master's (presumed) wishes. Eventually in his capacity he faces a moral dilemma - perpetuate his master's prejudices by dismissing two members of the household who would be deported to nazi Germany and face certain death or to turn a blind eye and protect the innocents as requested by the romance character. **Miss Kenton** (_Emma Thompson_)[P 10]

 —Kazuo Ishiguro (Novel), Ruth Prawer Jhabvala (Screenplay), James Ivory(Director). (1993). _[The Remains of the Day_](http://www.imdb.com/title/tt0107943/). [Motion picture]. <http://www.imdb.com/title/tt0107943/>. [F 7]

  


### Participants[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-15)]

[Exposition](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Exposition&action=edit&redlink=1); [Pathos/Mystery](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Pathos/Mystery&action=edit&redlink=1); [Pathos/Suspense](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Pathos/Suspense&action=edit&redlink=1); [Structure/Rhythm](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Structure/Rhythm&action=edit&redlink=1); [Structure//Intensity](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Structure//Intensity&action=edit&redlink=1);

### Collaborations[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-16)]

[Character/Dimension](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Character/Dimension&action=edit&redlink=1); [Character/Center Of Being](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Character/Center_Of_Being&action=edit&redlink=1); [Pathos/Empathy And Sympathy](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version/Pathos/Empathy_And_Sympathy&action=edit&redlink=1)

### Consequences[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-17)]

By tracking the viewer's perspective in relation to each character you will:

  * Detect and eliminate illogical story holes due to information.
  * Root your narratives dynamic in exposition as opposed to action. This is required to produce the most powerful turning points.
  * Create interest by eliciting basic emotions.

### Uses & Abuses[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-18)]

Once the auteur is in full control of his medium, he will utilize these basic techniques as well as other aspects like music, cinematography and so on to layers of emotions. This way the emotional message can be pure color, uses many hues of the same color or create secondary or tertiary effect by mixing different or even conflicting effects. While today this type of layering is still outside the realm of the screenwriter, a solid foundation in weaving the emotional overlay will allow the script to suggest more advanced emotional layering.

### Related Patterns[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Viewer%27s_Perspective&action=edit&section=T-19)]

[Planning/Story Rhythm/](/w/index.php?title=Planning/Story_Rhythm/&action=edit&redlink=1)

## Law Of Variation[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-1)]

“
fly like a butterfly sting like a bee
”

—Muhammad Ali

  


### Intent[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-2)]

To maintain the viewer's interest and maximize the emotional effects.

### Also Known As[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-3)]

Avoid cliché, Avoid Stereotypes, Develop Symbol systems, Rhythm, Intensification, Irony,

### Motivation[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-4)]

If for some reason the viewer's interest is lost, the easiest fix is to introduce change. This applies to almost any aspect of screenwriting.

### Applicability[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-5)]

  * Emotions

    

  * Emotional Highs and Lows (as discussed below)

  * Exposition

    

  * Transpose Exposition and action

  * Scenes

    

  * Long and Short scenes

  * Conflict

    

  * Present opposing points of view

### Structure[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-6)]

  * Variation – do not repeat, recycle material, adopt clichés, use stereotypes, change scene length.
  * Intensification – conflict, action, risks, stakes, pace, and intensity all need to become more intensive.
  * Reverse Expectation – "fly like a butterfly sting like a bee"; before success, the deepest abyss.
  * Surprise – the unexpected is the acme of variation.
  * Maximize - the scope of variation and you will be maximizing its effect.

#### Technique 1. Inside Outside[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-7)]

Follow an indoors scene with an outdoors scene.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 2. Short Long[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-8)]

Follow an short scene with a long scene.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 3. Action Exposition[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-9)]

Follow action with a exposition.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 4. Emotional Highs And Lows[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-10)]

  * Maximise the emotional effects of scenes by planning a sequence of increasing climaxes.
  * As you build up a climax use a wide mix of emotional effects.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 5. Covert Overt[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-11)]

Show and later explain. This technique is used in some of the greatest movies. The moral message is dramatised subtly symbolically in several ways. Once the viewer has become emotional invested in the premise, it will be restated enunciated explicitly, unequivocaly in dialogue or voiceover. The latter version of the message might be controversial, but the use of variation helps to carry it past the viewers resistance.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


#### Technique 6. Character's strength and Weakness[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-12)]

To make a character more accessible to the audience you need to show incidents in which expose his strength his weakness and how he develops to over come his weakness. This variation of success and failure due to a character flaw is another element whose variation should be planed to increase the viewer's stakes. Such incidents should have a unifying theme and should refer to the moral premise.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Tape_16mm.png/70px-Tape_16mm.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

  


### Participants[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-13)]

### Collaborations[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-14)]

### Consequences[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-15)]

### Uses & Abuses[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-16)]

### Related Patterns[[edit](/w/index.php?title=Patterns_Of_Screen_Writing/Planning/Law_Of_Variation&action=edit&section=T-17)]

  


### References

#### Books

#### Films

  1. ↑ Eastwood, C. (Director). (2003). _[Mystic River_](http://www.imdb.com/title/0327056/). [Motion picture]. <http://www.imdb.com/title/0327056/>. 
  2. ↑ Lehman E. (Writer); Hitchcock, A. (Director). (1959). _[North by Northwest_](http://www.imdb.com/title/tt0053125/). [Motion picture]. <http://www.imdb.com/title/tt0053125/>. 
  3. ↑ Kurosawa, A. (Director). (1950). _[Rashomon_](http://www.imdb.com/title/tt0053125/). [Motion picture]. <http://www.imdb.com/title/tt0053125/>. 
  4. ↑ Bryan Singer (Director) Christopher McQuarrie (Writer). (1995). _[The Usual Suspects_](http://www.imdb.com/title/tt0053125/). [Motion picture]. <http://www.imdb.com/title/tt0053125/>. 
  5. ↑ Peter Shaffer (Writer) Milos Forman (Director). (1999). _[Amadeus_](http://www.imdb.com/title/tt0086879/). [Motion picture]. <http://www.imdb.com/title/tt0086879/>. 
  6. ↑ Jim Uhls (Adaptation) David Fincher (Director). (1999). _[Fight Club_](http://www.imdb.com/title/tt0137523/). [Motion picture]. <http://www.imdb.com/title/tt0137523/>. 
  7. ↑ Kazuo Ishiguro (Novel), Ruth Prawer Jhabvala (Screenplay), James Ivory(Director). (1993). _[The Remains of the Day_](http://www.imdb.com/title/tt0107943/). [Motion picture]. <http://www.imdb.com/title/tt0107943/>. 

#### People

  1. ↑ [Woody Allen](//en.wikipedia.org/wiki/Woody_Allen)
  2. ↑ [Sean Penn](//en.wikipedia.org/wiki/Sean_Penn)
  3. ↑ [Tim Robbins](//en.wikipedia.org/wiki/Tim_Robbins)
  4. ↑ [Kevin Bacon](//en.wikipedia.org/wiki/Kevin_Bacon)
  5. ↑ [Carry Grant](//en.wikipedia.org/wiki/Carry_Grant)
  6. ↑ [Kevin Spacey](//en.wikipedia.org/wiki/Kevin_Spacey)
  7. ↑ [F. Murray Abraham](//en.wikipedia.org/wiki/F._Murray_Abraham)
  8. ↑ [Brad Pitt](//en.wikipedia.org/wiki/Brad_Pitt)
  9. ↑ [Anthony Hopkins](//en.wikipedia.org/wiki/Anthony_Hopkins)
  10. ↑ [Emma Thompson](//en.wikipedia.org/wiki/Emma_Thompson)

#### Others

  1. ↑ [wikipedia article](//en.wikipedia.org/wiki/Unreliable_narrator)
  2. ↑ Fight Club, review by Roger Ebert, Chicago Sun-Times, October 15, 1999, accessed February 15, 2008
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&oldid=2153955](http://en.wikibooks.org/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&oldid=2153955)" 

[Categories](/wiki/Special:Categories): 

  * [Patterns Of Screen Writing](/wiki/Category:Patterns_Of_Screen_Writing)
  * [Patterns Of Screen Writing/Print version](/w/index.php?title=Category:Patterns_Of_Screen_Writing/Print_version&action=edit&redlink=1)

Hidden category: 

  * [Requests for expansion](/wiki/Category:Requests_for_expansion)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Patterns+Of+Screen+Writing%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Patterns+Of+Screen+Writing%2FPrint+version)

### Namespaces

  * [Book](/wiki/Patterns_Of_Screen_Writing/Print_version)
  * [Discussion](/w/index.php?title=Talk:Patterns_Of_Screen_Writing/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=edit)
  * [View history](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Patterns_Of_Screen_Writing/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Patterns_Of_Screen_Writing/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&oldid=2153955)
  * [Page information](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Patterns_Of_Screen_Writing%2FPrint_version&id=2153955)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Patterns+Of+Screen+Writing%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Patterns+Of+Screen+Writing%2FPrint+version&oldid=2153955&writer=rl)
  * [Printable version](/w/index.php?title=Patterns_Of_Screen_Writing/Print_version&printable=yes)

  * This page was last modified on 6 August 2011, at 04:48.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Patterns_Of_Screen_Writing/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
