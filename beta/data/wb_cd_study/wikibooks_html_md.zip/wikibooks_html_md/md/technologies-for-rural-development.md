# Technologies for Rural Development/Complete

From Wikibooks, open books for an open world

< [Technologies for Rural Development](/wiki/Technologies_for_Rural_Development)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Technologies for Rural Development](/wiki/Technologies_for_Rural_Development)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Technologies_for_Rural_Development/Complete&action=purge&printable=yes) this page.

  
  
[Technologies for Rural Development/Title Page](/w/index.php?title=Technologies_for_Rural_Development/Title_Page&action=edit&redlink=1)  
  


Technologies for Rural Development

The goal of this book is to educate children about processes and technologies that can improve the lives of people in poor or disadvantaged communities, while respecting their local environment.

When working on this project, remember that it is aimed at children. It must be simple and easily understood while being quite accurate. Use technical vocabulary when you need to, but don't use big words where simpler language would work.

## Contents

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

A _****printable version****_ of Technologies for Rural Development is available. ([edit it](//en.wikibooks.org/w/index.php?title=Technologies_for_Rural_Development/Complete&action=edit))

  1. [Introduction](/w/index.php?title=Technologies_for_Rural_Development/Complete/Introduction&action=edit&redlink=1) ![25 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  2. [Using water resources](/w/index.php?title=Technologies_for_Rural_Development/Complete/Using_water_resources&action=edit&redlink=1) ![25 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  3. [Using communication systems](/w/index.php?title=Technologies_for_Rural_Development/Complete/Using_communication_systems&action=edit&redlink=1) ![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  4. [Health and hygiene](/w/index.php?title=Technologies_for_Rural_Development/Complete/Health_and_hygiene&action=edit&redlink=1) ![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  5. [Building houses](/w/index.php?title=Technologies_for_Rural_Development/Complete/Building_houses&action=edit&redlink=1) ![25 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  6. [Ways of farming](/w/index.php?title=Technologies_for_Rural_Development/Complete/Ways_of_farming&action=edit&redlink=1) ![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  7. [Dealing with waste](/w/index.php?title=Technologies_for_Rural_Development/Complete/Dealing_with_waste&action=edit&redlink=1) ![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  8. [Creating energy](/w/index.php?title=Technologies_for_Rural_Development/Complete/Creating_energy&action=edit&redlink=1) ![25 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  9. [Building infrastructures](/w/index.php?title=Technologies_for_Rural_Development/Complete/Building_infrastructures&action=edit&redlink=1) ![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  10. [Improving transportation](/w/index.php?title=Technologies_for_Rural_Development/Complete/Improving_transportation&action=edit&redlink=1) ![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)

## Major Questions

The points to appear in every page are:

  * A summary of the issue or process to be discussed.
  * Brief history of the technologies or processes in question.
  * Applications of technologies that can be used to drive development.
  * Environmental considerations for the technologies or processes.
  * Safety and hygiene.
  * Diagrams to illustrate the main concepts

  
  


## Introduction

Rural Development is a term that is used widely in governmental organizations and many publications regarding rural activity in all the countries around the world. This book is about Rural Development at a basic level, with the material directed towards informing children about what can drive the first phases of development.

  


### [Technologies for Rural Development/Using water resources](/wiki/Technologies_for_Rural_Development/Using_water_resources)

The water resources module explains how the water cycle operates and how important its protection and correct use is to development in all areas of life. A number of technologies that can improve use of water are explained.

  


### [Technologies for Rural Development/Building houses](/wiki/Technologies_for_Rural_Development/Building_houses)

The housing module explains many ways of creating reliable housing in different rural locations around the globe.

### [Technologies for Rural Development/Ways of farming](/wiki/Technologies_for_Rural_Development/Ways_of_farming)

This module explains how simple technologies can improve farming in rural areas.

### [Technologies for Rural Development/Dealing with waste](/wiki/Technologies_for_Rural_Development/Dealing_with_waste)

This module explains how simple technologies can improve waste management to minimise pollution.

### [Technologies for Rural Development/Building infrastructures](/w/index.php?title=Technologies_for_Rural_Development/Building_infrastructures&action=edit&redlink=1)

This module explains the importance of building infrastructures and working as a community.

### [Technologies for Rural Development/Creating energy](/wiki/Technologies_for_Rural_Development/Creating_energy)

This module explains simple ways to create and use energy in developing communities.

## Introduction for Parents, Guardians and Educators

_The Technologies for Rural Development_ is a book written by a group of volunteers and made freely available to Internet users, printers and distributors under the terms of its license. It is the result of cooperation between, The Wikimedia Foundation and volunteer writers and editors.

The volunteer writers and contributors thank you for obtaining this book. By making it available to a young person you complete the goal of the project to encourage reading and literacy among young people.

The original text and graphics are available at <http://www.wikibooks.org> and printed versions may be available from many different entities under license.

## Licensing

All text is available under the terms of the [GNU Free Documentation License](/wiki/Wikibooks:GNU_Free_Documentation_License) and [Creative Commons Attribution-ShareAlike License](/wiki/Wikibooks:CC-BY-SA) which applies to all Wikibooks projects. Please contact the authors to inform them of any publishing.  
  
  
  


**Using Water Resources**

  
  


Water has always been the most necessary resource for life on earth and therefore human development. Once fire was discovered and used to heat food it became possible to use water to boil some food times to make them more edible. It is believed that water was used for cooking as early as ----- by the poeple who lived in-----. Population density was always highest in river basins as they are very fertile lands. Ancient civilizations flourished near the great rivers such as the Nile and Indus. It is known that water was used to irrigate crops to improve yields as early as 5500BC in Mesopotamia now present day Iraq. These basic types of irrigation are still used in many parts of the world. Early civilizations also used channelled water as a levelling device for construction. This principle is still used by most builders today; by using a transparent pipe filled with water to compare levels.

## The Water Cycle

Water is the most important resource for the success of any community or project. All water resources are linked together in a huge global cycle. Understanding this cycle is very important for making decisions about what technologies and processes should be used to utilise the available water resources.

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/9/94/Water_cycle.png/400px-Water_cycle.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

This image is borrowed from [[Water cycle](http://en.wikipedia.org/wiki/Water_cycle)], it would be best for a new diagram to be created for this project without text so that it can be used in translated versions. It should also be drawn in a style that is suitable for educational purposes. Use the following disclaimer template [[PD-Self](http://commons.wikimedia.org/wiki/Template:PD-self)]

The water cycle has four main storage phases. These are:

  * In the ocean
  * In the atmosphere
  * On land
  * Under the ground

  


The majority of the water in the world is stored in the ocean. This water is heated up by the sun and evaporates into the air. The water is then stored in vapour form in the clouds until it falls to the earth as rain, hail or snow. When the water falls to earth there are many different processes that can happen. It can be stored as snow and ice in cold areas of the world for great lengths of time; it can flow across the ground as runoff and enter into streams, rivers and lakes; it can be absorbed directly by plants; or it can filter its way under the ground.

The water that infiltrates into earth becomes part of the groundwater system. This water is a very important resource for development because the process of infiltration, which can take a long time with the water flowing over great distances, causes the water to be purified and have important minerals added.

  


## Drinking Water

  
Drinkable or potable water is a resource that is scarce in many parts of the world; it is also affected very easily by many types of pollution. Before drinking any water from an unknown source it is important to test its quality.

### Water quality testing

  
A good indication of the quality of a water resource can be taken from the odour, the colour, and the quantity of particles. These three concepts give a general indication, before drinking it is best to filter it or get it tested in a laboratory if available.

  
If water is not potable there are a range of filtering processing that can improve its quality.

### Water filtering

  
In polluted or even unfiltered mountain water there are many parasitic organisms and inorganic chemicals that are dangerous to humans, because of this it is very important to filter water.

If no energy or technology is available the simplest way to filter water is using a cloth. Water taken from any source is put into a container and left to settle, and then the water is passed through a cloth folded over itself about 8 times. The best type of cloth to use is cotton. This basic filter is effective against simple organisms and to some extent against cholera. However it is not very effective against giardia or cryptosporidium.

Carbon Filters are more advanced filters that require manufacturing; they are most effective for filtering chlorine and volatile organic compounds.

Advanced filtrations systems that are used all over the world to clean drinking water typically have the following components:

  * A sediment filter to trap particles including rust and calcium carbonate.
  * A second sediment filter with smaller pores is sometimes included.
  * An activated carbon filter to trap organic chemicals and chlorination.
  * A reverse osmosis filter with a thin film composite membrane.
  * A second carbon filter to capture those chemicals not removed by the RO membrane is sometimes used.
  * An ultra-violet lamp can be used for disinfection of the remaining microbes.

The filters range in size and capacity for large industrial installations to supply water for cities, to small portable devices that use gravity to filter water.

How to make:

  * ClayPotFilter : make the lower part of the clay pot with a mix of sawdust and clay... during the baking process, the sawdust will transform into active coal and allow water to pass but retain the bacteria. Only use a limited diameter range of sawdust, not to big-not to dusty. Search for ClayPotFilter for more info
  * CocaColaWaterDisinfector : works with clear, transparent water. Lay the bottle on its side, paint half of the bottle black... the sun will kill micro-organisms, viruses and cycsts in various ways: 
    * raise in temperature... it doesn't need to be boiling... boiling is a great visual feedback to know for sure you have reached far beyond survival temperature of micro-organisms, viruses and cysts. It's actually about getting above a minimun kill-off temperature, and how long you stay at a certain temperature above that minimum temperature. In a warm country, on a sunny day... 2 hours will do just fine.
    * a certain wavelenght in the UV in the sunlight, will split oxygen molecules in its radicals, making oxigenated water... that way, you burn little holes in the organisms/organic material... it's a way of chemically burning.
    * A certain wavelenght in the UV spectrum has the same lenght as the average bond distance of the molecules in the membrane... it can induce a self-resonance leading to rupture of the membrane, which kills the bacteria
    * Idem to the previous but on the DNA level... the bacteria won't be able to survive. Search for SODIS for more info.

### Extraction from Groundwater

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Groundwater_flow.svg/250px-Groundwater_flow.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Diagram of ground water system.

Ground water is generally the best quality water available for drinking and irrigation, during the years of natural filtration through the earth the water absorbs minerals which are important for life support, during this process contaminants are generally removed.

The water table is found at different depths in different regions of the earth, this depth also varies over time due to water extraction and the regeneration process that depends on rainfall and natural water storage in lakes and rivers.

In areas where the water table is close to the surface small wells can be dug by hand or using machinery if available.

One option that has been used for centuries is the hand power percussion drill. It was first used by the chinese around 3000 years ago.

If drilling machines are available they can be used to extract water from greater depths.

## Pumps

### Rope and washer pump

### Manuel pumps

### Treadle pump

## Irrigation for agriculture

### Channel sytems

### Sprinkler systems

### Drip systems

## Water diversion

In many areas around the world rivers and streams are partially or fully diverted for irrigation purposes. This has the advantage of supplying water using gravity. However it is very important to consider the effects of reducing the flow in the river or stream. The flora and fauna may not be able to survive in a dry season without the normal flow; these changes can affect the lives of the people and animals living downstream.

## Water storage

### Damming

### wadis for soaking in groundwater

## Environmental concerns when dealing with Water

Water absorbs almost everything that it comes into contact with. However, only over long times and through specific processes does water returned to a clean state. When dealing with water it is important to consider that the water you are using is just in one of the phases of its continual cycle. Therefore, by keeping it as clean as possible at every stage of the water cycle, you can be sure that when the water comes back around it will be fit for use.

## Useful Links

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[water _cycle**_](//en.wikipedia.org/wiki/Water_cycle)

  * [Water for Life Decade](http://www.un.org/waterforlifedecade/educationandyouth.html) \-- This website has information about water resources.
  * [Hand powered percussion drill](http://www.wellspringafrica.org/drildesc.htm)

  
  


**Building houses**

  
  


The building of houses is fundamental for human development, especially in areas of the globe with extreme weather conditions.

It is very important for family and for general social development, because it is where we live and so it must be comfortable and healthy. Many types of houses are difficult to build; they require a lot of knowledge and work to create them.

To be a good house it must comply with a few basic functions.

  * Be a functional and health environment for those that live in it.
  * Inside of the house one must be protected from wind, cold, heat, rain sand and dust.
  * Last few many years without requiring much maintenance.

There are many ways to build a house. Houses vary according to their location; they change due to cultural differences and also due to the local resources available to create them. In cold places houses must be more compact and have thick walls and small windows to resist the cold, they also have heating systems. In the hottest places the houses are built below ground level so that the earth keeps them cool during the day, they also have central courtyards to create shade from the sun. The forest areas the houses are made from wood, en the mountains they are made from stone, in areas with clay they are made from brick. In areas where there is seismic activity it is important to consider this when designing the structure of the house. Each country has its own regulation to guide this work.

## Housing for Cold Climates

In cold climates a house must insulate its inhabitants from the outside temperature. This is achieved by creating walls that are made from materials that insulate well, often requiring layers of different materials. It is also necessary to include a heating system for the house. The type of heating will depend on the resources available (wood, gas, kerosene or electric), this should always be minimised by using the passive solar heating that the sun supplies. To make the passive solar heating from the sun more effective it is important to orientate the most important rooms towards the equator. (In the Southern Hemisphere towards the North, and in the Northern Hemisphere towards the South).

### Passive Heating of Houses

Passive heating of living spaces is created by what is called the “greenhouse effect” because a greenhouse is a building made of glass used to grow plants in cool climates or accelerate growth by increasing the warmth.

Glass creates a greenhouse effect because the glass only transmits some light waves, this means that the light is trapped inside and bounces around within the area; the result is that there is more heat gain through the window, than heat loss.

  


  


#### Resources for good insulation:

  * Thick walls and ceiling made of materials with low heat transfer.
  * Walls and ceiling filled with insulation material that creates an air space (glass wool, cork, hay etc.)
  * Walls and ceiling with an air space (a double wall or ceiling).
  * Walls and ceiling insulated from water so that heat is not transferred with the moisture.
  * Doors and windows that insulate (double glazed or double doors).

## Housing for Hot Climate

In hot areas it is important to cool the house down to make it comfortable to live in. The house must have walls and ceiling that insulate the inter spaces from the outside heat just like a house in cold climates.

The house must also have as much of its walls and floor in contact with the earth because the earth does not heat up as much as the air especially if the night time temperatures are lower than the day time temperatures.

The house must be shaded from direct sunlight this can be done by building the house partially under the ground, or by planting trees around the house.Cavity wall construction can be taken up at south and west sides considering the solar path .

## Housing for Windy Climates

Houses built for windy climates need to be strongly anchored to the ground and need the roofs to be designed to support the force of the wind.

  


## Choosing the right materials

Choosing the right materials to build a house depends on the region that the house it to be built in. Each area of the planet it different and has many different materials that can be used for housing.

### Earth Bricks

Earth bricks can be made from some types of clay it is a very common material and requires very little energy to turn into a construction material.

#### Required Resources

  * Spade or shovel
  * Cement
  * A press to create the earth bricks

#### Construction System

The earth is mixed with a small amount of cement (without water) and then pressed into brick shape and left to harden. The humidity of the environment will enter the brick mixing with the cement and harden it. Normally small bricks and made so that they are easy to transport and work with.

It is considered one the most environmentally friendly construction methods.

The main disadvantage is it can not be used in the construction of the roof unless a arched or domed roof is created.

### Ceramic Brick

This brick is made from clay which when heated goes hard to form a brick. It is very common in many parts of the world, but it is a material that is very fertile and so its use for construction reduces the fertile land in the area, it also used a lot of heat energy for its creation.

### Wood

Wood houses has a long tradition in Asia, and the United Status. If there are renewable wood forest to supply the wood very efficient construction can be done by creating kit-set houses.

#### Necessary resources

  * Pieces of wood cut to size and dried.
  * Saws, hammers and nails also bolts for more important joints..

#### Construction system

The wood must be cut into lengths; these are normally standardized so that builders can use the same practices for more than one house. These are used to create the structure of the house and panelling is used to close the house. Insulation should be included between the inner and outer panels. Wood does not resist water and will rot if not treated with chemicals in humid climates. Because of this it is best suited to dry climates.

### Installations

A good house should also have running water and a toilet and bathroom so that the inhabitants can keep clean and also have access to water to drink and cook with.

## Environmental considerations

## Links

<http://en.wikipedia.org/wiki/Passive_house>  
  


**Ways of Farming**

  
  


Farming can be divided into two main sections, crop farming and animal husbandry. Both have been a major part of human development over last few thousand years.

The first farming began in the Fertile Crescent located in present day Iraq and Syria, with wheat harvesting and the husbandry of sheep and goats around 8000BC. Agriculture was also developed independently in China and the New World at later dates.

  


## Animal Husbandry

Organic farming according to Köpke (1990) comprises the principle of a precise organisation of an agronomically appropriate ( A. Young ), largely self-contained farm organisms. The overall concept makes the combination of plant production and animal husbandry, that is the traditional mixed farm or appropriate cooperations necessary.

Animal husbandry an important financial pillar of organically producing farms. Usually they earn more than 50% of their turnover with animal husbandry.

## Environmental Considerations

### Soil Stability

Soil erosion is a very important problem for agriculture today; it is caused by overgrazing and also by land clearing.

To solve this problem trees can be planted on steep slopes, or in some cases types of grass such as Vetiver (a grass that grows on my types of soils).  
  


**Dealing with Waste**

  
  


As the population grows in any given location, the strain on resources and the environment increases. This strain is due in part to the way we deal with the waste that our lives create.

## Definitions

Waste can be grouped into three main types, Biodegrable, Inert or Toxic waste.

## Biodegradable Waste

Biodegradable waste normally originates from plant or animal sources, and it may be broken down by other living organisms.

This waste should not be mixed with general waste, because it can be composted and used for agricultural purposes.

## Inert Waste

Inert non-biodegradable waste can be recycled, reused or dumped in a location where the contamination of the area is minimal. The most important point is not to let any liquid components of the waste get into the water ways or the water table.

## Toxic Waste

Toxic waste is any waste that can harm living organisms, this sort of waste either gives of gases or liquids which contaminate the air, water or earth that they come in contact with.

## Identifying Waste

### Household waste

### Farm Waste

### Liquid Waste

## Solutions

The sequence normally followed when approaching waste management is:

  * Reduce - what can be done to reduce the volume of waste
  * Re-use - can packaging or the waste be re-used (returnable bottles returned for cleaning and filling)
  * Re-cycle - this means the waste is re-processed (glass is melted to make more bottles)
  * Discard - the waste is sent to the correct landfill site or incinerator

### Reduce

### Reusing

Returnable beer bottles have a life expectancy of at least 25 trips, and at the end of the lifespan the brewer crushes the glass and recycles it to the glass supplier.

  


### Recycling

**Glass recycling** To yield the best value glass waste it is important to keep the different glass colours separate.

Contaminants of recycled glass include high temperature glass such as borosilicate glass and "Pyrex" or porcelain. These should be re-cycled separately.

### Correct disposal

  
  
[Technologies for Rural Development/Building infrastructures](/w/index.php?title=Technologies_for_Rural_Development/Building_infrastructures&action=edit&redlink=1)  
  


**Creating Energy**

  
  


Energy is used for many purposes, as a culture becomes more complex the uses for energy diversify.

## Basic energy uses

The prime need for energy use in all parts of the world is for food preparation, preservation in hot climes & cooking. In cold climates it is essential for heating living spaces.

## Energy Sources

  * Firewood
  * Solar energy 
    * Solar Energy for cooking
    * Solar energy for water heating
    * Solar energy for creating electricity
  * Hydroelectricity
  * Hydromechanical
  * Wind energy
  * Connection to the network

### Firewood

Firewood is the oldest and often most accessible energy source. An open wood fire can be used to cook food. There are many types of stoves and ovens that use wood to create heat for cooking and for heating of living spaces.

It is important to consider the source of the firewood; in many areas in the world people have cut all the trees down in an area to supply firewood or building material leaving no trees for future generations. As a general rule for every tree that is cut down 3 new ones should planted.

### Solar Energy

The energy from the sun can be used to heat water or even cook food; this is the best way to do this from an environmental point of view. It creates no pollution and uses no resources apart from those used for its fabrication.

#### Solar Cooking

  


![](//upload.wikimedia.org/wikipedia/commons/2/25/Solar-Panel-Cooker-in-front-of-hut.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

This image is borrowed from the Wikipedia article on Solar Cooking[[[1]](http://en.wikipedia.org/wiki/Solar_Cooking)], it would be best for a new photo or diagram to be created for this project. It should also be drawn in a style that is suitable for educational purposes. Use the following disclaimer template [[PD-Self](http://commons.wikimedia.org/wiki/Template:PD-self)]

Solar cooking has been used for centuries by explorers travelling in areas without access to wood to create fire. Since the 1970´s general interest has increased because of the energy it saves.

The simplest design is called the CooKit designed by Frenchman Roger Bernard en the early 1990´s; it is made from cardboard tinfoil a heat resistant plastic bag and a dark coloured pot.

  
**See links below for more information.**

#### Solar for Heating Water

Solar water heating systems are very efficient. In developed countries where it is common to heat water with electricity or gas from a centralized system, the cost of the installation can be paid back from saving in energy costs.

For rural development simple solar heating systems can be used to heat water even in areas the electricity or gas network has not yet reached.

Solar heating of the water is also called solar pasteurization; by heating the water many viruses and bacteria that cause diseases are killed. Hot water can also be used to clean living spaces and cooking and eating utensils more effectively.

#### Solar for Generating Electricity

Using solar energy for creating electricity is an environmentally friendly process but is unfortunately not very efficient, primarily because of the cost of fabrication of the solar panels. It is a very good technology when small amounts of energy are needed; to supply power for school computers etc.

If electricity is needed at night then a battery system must be added to store the energy.

### Hydroelectricity

If there are waterways nearby, dams are a very easy way to create energy in mechanical form; this can be turned into electricity with a turbine and generator.

The main problem with damming waterways to create energy is the change in ecosystem it creates, and the negative effect is has on the movement of silt downstream, the probabilty of the dam silting up, & the migration of fish up and downstream.

It is very important to create fish passes (ladders) so that the natural migration of fish can continue.

Small scale hydroelectric sets can be placed directly in streams with little or no civil engineering needed other than to anchor the set.

### Hydromechanical

This is a very old technology, & is simply extracting energy as torque, via a paddle-wheel of some sort, & applying it to a set of grinding wheels, hammers

### Wind Energy

Wind energy was first harnessed in Persia around 200BC to grind grain, shortly after the technology was copied by the Romans and consequently spreads across Europe where it has been used for pumping water and grinding grain until the early 20th century.

The first wind-,turbine used to create electricity was constructed in the United States in 1888, since then they have been used for pumping water or generating electricity in isolated areas around the world primarily on farms.

Wind turbines range in size from small 30 cm diameter models used to generate small amounts of electricity, to 10m high 2m diameter wind-turbine that typically has many blades, to giant 100m high 120m diameter wind-turbine that produce up to 5MW of energy.

In rural areas where it is not possible to connect to the electrical network, wind-turbines can installed to pump water and generate electricity.

## Energy Storage

Electrical energy can be stored mechanically or chemically. The most common mechanical storage is by damming water; this can be done by waiting for it to flow into a dam or by pumping it up into a dam using excess electricity in a network. Batteries use a chemical process to store electricity. This process is not very efficient, batteries are expensive to make & dispose of, and even rechargeable ones have quite short life spans. Therefore it is best to try and avoid storing electricity and only create it when it is needed. That is why developed countries have large electrical networks to supply the electricity as it is generated.

## Connecting to the Electrical Network

The first electrical network was connected in New York in 1883 by Thomas Edison the American inventor at the worlds first Research & Development centre. Since then the network has grown across the globe with most most developed countries in the world having centralized networks by mid 20th century.

Because alternative energy sources are only available when there is wind or sunshine, having a village connected to the electrical network means that excess energy produced from generation installations can be sold and when there is no wind or sunshine needed energy can be purchased. This is more efficient and environmentally friendly than using batteries.

## Environmental Considerations

Energy creating generally uses up resources, which should be replaced if possible; trees cut down for firewood should be replaced with 3 trees planted.

Energy creating also produces Carbon Dioxide and other gases which pollute the air. CO2 (Carbon Dioxide) is one of the known Greenhouse gases, which may be linked to Global warming.

Whenever possible it is best to use renewable energy sources like solar or wind energy, and also try and be inventive about the way of using energy to minimize the amount that is used.

## Further Reading

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[solar cooker**_](//en.wikipedia.org/wiki/Solar_cooker)

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[wind power**_](//en.wikipedia.org/wiki/Wind_power)

  * [PDF file with comprehensive information about Solar Cooking.](http://solarcooking.org/plans/Plans.pdf)
  * [Solar Cookers International](http://solarcooking.org)
  * [Climate Change/Renewable energy](/wiki/Climate_Change/Renewable_energy)

  
  


# License

# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Technologies_for_Rural_Development/Complete&oldid=792806](http://en.wikibooks.org/w/index.php?title=Technologies_for_Rural_Development/Complete&oldid=792806)" 

[Category](/wiki/Special:Categories): 

  * [Technologies for Rural Development](/wiki/Category:Technologies_for_Rural_Development)

Hidden category: 

  * [Books with print version](/wiki/Category:Books_with_print_version)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Technologies+for+Rural+Development%2FComplete&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Technologies+for+Rural+Development%2FComplete)

### Namespaces

  * [Book](/wiki/Technologies_for_Rural_Development/Complete)
  * [Discussion](/w/index.php?title=Talk:Technologies_for_Rural_Development/Complete&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Technologies_for_Rural_Development/Complete)
  * [Edit](/w/index.php?title=Technologies_for_Rural_Development/Complete&action=edit)
  * [View history](/w/index.php?title=Technologies_for_Rural_Development/Complete&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Technologies_for_Rural_Development/Complete)
  * [Related changes](/wiki/Special:RecentChangesLinked/Technologies_for_Rural_Development/Complete)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Technologies_for_Rural_Development/Complete&oldid=792806)
  * [Page information](/w/index.php?title=Technologies_for_Rural_Development/Complete&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Technologies_for_Rural_Development%2FComplete&id=792806)

### In other languages

  * [Español](//es.wikibooks.org/wiki/Tecnolog%C3%ADas_para_el_Desarrollo_Rural/Introducci%C3%B3n)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Technologies+for+Rural+Development%2FComplete)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Technologies+for+Rural+Development%2FComplete&oldid=792806&writer=rl)
  * [Printable version](/w/index.php?title=Technologies_for_Rural_Development/Complete&printable=yes)

  * This page was last modified on 19 March 2007, at 17:22.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Technologies_for_Rural_Development/Complete)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
