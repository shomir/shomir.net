# Inkscape/Print version

From Wikibooks, open books for an open world

< [Inkscape](/wiki/Inkscape)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Inkscape.logo.svg/220px-Inkscape.logo.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Inkscape's logo.

This is a guide to [Inkscape](http://www.inkscape.org/)\--a vector illustration program that is open source and cross-platform. To get help while running Inkscape, choose **Help → Tutorials** in its menu.

## Contents[[edit](/w/index.php?title=Inkscape/Print_version&action=edit&section=1)]

  1. #About
  2. #Introduction
  3. #Shape Tools
  4. #Path Drawing Tools
  5. #Other Tools
    1. ![25 percents developed  as of 2008-07-05](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png) #Making a Tomato
    2. #Appendix:Reference
    3. #Glossary

  


# About[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## About[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-1)]

**Inkscape** is a free open source scalable vector graphics (svg) editor application. Its stated goal is to become a powerful graphic tool while being fully compliant with the [XML](/wiki/XML), [SVG](/wiki/Scalable_Vector_Graphics), [CSS](/wiki/Cascading_Style_Sheets) and [HTML5](/w/index.php?title=HTML5&action=edit&redlink=1) standards.

Inkscape is for Linux, Windows and Mac OS X (under X11), and other Unix-like operating systems. As of 2013, Inkscape is under active development, with new features being added regularly. Inkscape's implementation of SVG and CSS standards is not at svg 1.1 standards; most notably, it does not support animations, and SVG fonts. However, complete support for both is on the [roadmap](http://wiki.inkscape.org/wiki/index.php/Roadmap). As of this writing inkscape is at version 0.48. The version numbering goal is to release a fully svg 1.1 compliant editor, labelled inkscape 1.1.

Inkscape has good multi-lingual support particularly for complex scripts, something currently lacking in most commercial vector graphics applications.

### History[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-2)]

Inkscape began in 2003 as a fork of the Sodipodi project. Sodipodi, developed since 1999, was itself based on Gill, the work of Raph Levien.

The fork was led by a team of four former Sodipodi developers (Ted Gould, Bryce Harrington, Nathan Hurst, and _MenTaLguY_) who identified differences over project objectives, openness to third-party contributions, and SVG compliance as their reasons for forking. Inkscape, they claimed, would seek to focus development on implementing the complete SVG standard, whereas Sodipodi development had emphasized creating a general-purpose vector graphics editor, possibly at the expense of SVG.[1]

Since the fork, Inkscape has, among other things, changed from using the C to [C++](/wiki/C%2B%2B); changed to the GTK+ toolkit C++ bindings (gtkmm); redesigned the user interface and added a number of new features. Its implementation of the SVG standard has shown gradual improvement, but is still incomplete.

Rather than top-down governance, its developers claim to encourage an equal culture where authority stems from an individual developer's abilities and active involvement in the project. As a result, the project places special emphasis on giving full access to its source code repository to all active developers, and on participation in the larger open source community (often in the form of inter-project initiatives and secondary projects like the Open Clip Art Library). While the project founders are still well-represented in the decision-making process, many newcomers have also come to play prominent roles. Among them is "bulia byak", architect of the profound user interface changes that have given Inkscape its present appearance.

Inkscape is currently a Google Summer of Code and linuxfund.org projects.[2]

### Features[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-3)]

#### Object creation[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-4)]

  * Drawing/Rendering: 
    * Pencil tool (freehand drawing with stroked paths)
    * Bezier Curves and Straight lines
    * Calligraphy tool (freehand drawing with calligraphic strokes, graphics tablet pressure/angle support)
  * Shape tools: 
    * Rectangles and Squares (optionally with rounded corners)
    * 3D Boxes
    * Circles, Ellipses and Arcs)
    * Stars and Polygons (optionally rounded or randomized)
    * Spirals (inner/outer controls, divergence)
  * Text tool (text on path, flow into frame, support for unicode (ctrl+u))
  * Diagram Connectors (i.e., flow charts, circuit boards)
  * Linked or Embedded bitmap images, either imported or rasterized from selected objects.
  * Spray Tool, duplicate pre-selected objects by sculpting or painting
  * >Edit>Clones ("live" linked copies of objects). Other programs refer to similar functionality as "symbols". 
    * >Extensions>Render (generate menu driven objects)

#### Object manipulation[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-5)]

  * Object transformations (positioning, scaling, rotating, skewing), via freehand, snapped, locked, key combinations, by numeric values or dedicated dialogs (menus)
  * Z-order operations, object stacking order within a layer
  * Grouping objects, with a way to "select in group" without ungrouping, or "enter the group"
  * Layers, with a way to lock and/or hide individual layers, rearrange them, etc; layers form a stacking order
  * Cut, Copy and Paste operations of objects
  * Alignment and Distribution commands, including grid arrange, randomization, unclumping
  * A tool to create patterns of clones, using wallpaper symmetries plus arbitrary scales, shifts, rotates, and color changes, optionally randomized
  * Grid, Guide, Node, Object and other options for snapping

#### Styling objects[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-6)]

  * Color selector (RGB, HSL, CMYK, color wheel), color palette, picker ("dropper") tool
  * Fill opacity, stroke opacity, master opacity, gradient stop opacity
  * Gradients: linear and radial, may have multiple stops; can be edited on canvas or with a dedicated gradient editor, with draggable, sculpting (Alt+) and mergeable stops
  * Pattern fills made from any objects or the patterns within the software
  * Per file Swatch
  * Dropper Tool, color picker can pick color under cursor, inverted color under cursor, or average color of cursor drag area
  * Full dedicated (presets) filter menu and or a filter editor
  * Masks and clip effects
  * Dashed strokes, with predefined dash patterns
  * Path Start, Mid and End Markers (e.g. arrowheads, dots, diamonds, etc)
  * Ability to copy/paste style between objects

#### Operations on paths[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-7)]

  * Node editing: positioning nodes and segments, curve handles, node alignment and distribution, scaling and rotating node groups, "node sculpting" (proportional editing of multiple nodes)
  * Converting to path (for text, images or shapes), including converting stroke to path
  * Boolean operations (union, intersection, difference, exclusion, division)
  * Path simplification, with variable threshold
  * Path insetting and outsetting, including dynamic and linked offset objects
  * Clipping paths (non-destructive clipping)
  * Bitmap tracing (both color and b/w)
  * Path Effects Editor... contains over a dozen effects that can be manipulated on canvas and via menu settings.
  * >Extensions >Modify Path, to add effects to existing paths and >Generate from Path for additional operations on paths.

#### Text support[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-8)]

  * Multi-line text (SVG 1.0/1.1 <text>)
  * Flowed text in frame(s) (<flowRoot>, formerly proposed for SVG 1.2)
  * Full on-canvas editability, including styled text spans
  * Uses any outline fonts installed on the system
  * Can use any scripts and languages supported by the Pango library including complex scripts (e.g. Hebrew, Arabic, Thai, Tibetan etc.)
  * Bold or Oblique (Italic), Align left/center/right, line spacing, character spacing, word spacing, character rotation, subscript, superscript, horizontal kerning, vertical shift, horizontal or vertical text.
  * Text on path (both text and path remain editable)
  * Spell Checking
  * Unicode support (ctrl+u while in the 'Create & Edit Text Tool')

#### Viewer[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-9)]

  * 256x (25600%) maximum zoom
  * Fully anti-aliased display
  * Alpha transparency support for display and PNG export
  * Normal, No Filter and Outline (wireframe) mode

#### Miscellaneous[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-10)]

  * Collaborative editing over a network (whiteboard)
  * Live watching and editing the document tree in the XML editor
  * PNG export
  * EnhancedPostScript (EPS) and PDF export
  * Command line options for export, conversions, and analysis of SVG files
  * RDF metadata (authorship, date, license, etc.)
  * Extension support
  * User interface is translated in more than 40 languages

### Interface and usability[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-11)]

One of the priorities of the Inkscape project is interface consistency and usability. This includes efforts to follow the GNOME Human interface guidelines compliance, universal keyboard accessibility, and convenient on-canvas editing. Inkscape has achieved significant progress in usability since the project started.

The interface of Sodipodi (Inkscape's predecessor) was partly based on those of CorelDRAW and GIMP. The current Inkscape interface has been partially influenced by that of Xara Xtreme.

The number of floating dialog boxes has been reduced, with their functions available using keyboard shortcuts or in the docked toolbars in the editing window. The tool controls bar at the top of the window always displays the controls relevant to the current tool.

All transformations (not only moving but also scaling and rotating) have keyboard shortcuts with consistent modifiers (e.g. Alt transforms by 1 screen pixel at the current zoom, Shift multiplies the transformation by 10, etc.); these keys work on nodes in Node tool as well as on objects in Selector. The most common operations (such as transformations, zooming, z-order) have convenient one-key shortcuts.

Inkscape provides floating/mouse-over tooltips and status bar hints for all buttons, controls, commands, keys, and on-canvas handles. It comes with a complete keyboard and mouse reference (in HTML and SVG) and several interactive tutorials in SVG.

## References[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-12)]

  1. ↑ ["Initial announcement of Inkscape fork on Sodipodi mailing list"](http://sourceforge.net/mailarchive/forum.php?thread_id=3416220&forum_id=3970). [http://sourceforge.net/mailarchive/forum.php?thread_id=3416220&forum_id=3970](http://sourceforge.net/mailarchive/forum.php?thread_id=3416220&forum_id=3970). 
  2. ↑ ["Google Summer of Code entry in the Inkscape developers' wiki"](http://wiki.inkscape.org/wiki/index.php/Googles_Summer_Of_Code). <http://wiki.inkscape.org/wiki/index.php/Googles_Summer_Of_Code>. 

## External links[[edit](/w/index.php?title=Inkscape/About&action=edit&section=T-13)]

  * [Official site](http://www.inkscape.org/)
  * GnomeDesktop.org: [Inkscape news](http://gnomedesktop.org/taxonomy/term/79)
  * On-line Book: [A Guide to Inkscape](http://tavmjong.free.fr/INKSCAPE/MANUAL/html/index.php)
  * [Inkscape Wiki](http://wiki.inkscape.org/wiki/index.php/Inkscape)
  * [A gallery of art created in Inkscape](http://inkscape.deviantart.com/favourites)
  * [Inkscape review: It's all in the UI](http://software.newsforge.com/article.pl?sid=05/09/08/1835253)

  


  


# Introduction[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Vector graphics[[edit](/w/index.php?title=Inkscape/Introduction&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Bitmap_VS_SVG.svg/300px-Bitmap_VS_SVG.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Scaling a bitmap and a SVG drawings makes the differences appear.

A vector object is composed of edit enabled path(s) and geometrical elements based on vector (x/y) coordinate values. This is very different from raster (or bitmap) images, which are composed from a grid (bitmap) of colored squares. Bitmaps are inherently "pixellated" when scaled larger (zoomed in), while vectors can be scaled to any size, and won't display any pixelized objects.

Some graphic editor programs, such as the GIMP, are known as bitmap or raster editors. With Inkscape, you can create and edit vector graphics, and save them as SVG (Scalable Vector Graphics) files or 'save as' over 15 graphic editor based file formats. SVG is an open standard designed by the World Wide Web Consortium (W3C), that uses XML to create graphic based objects.

## The Graphic User Interface (GUI)[[edit](/w/index.php?title=Inkscape/Introduction&action=edit&section=T-2)]

When you load Inkscape you will see the following:

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Inkscape%28main_window%29.png/175px-Inkscape%28main_window%29.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Inkscape's User Interface

Here are some quick explanations of what each button does: Select and Transform Objects (F1): From this option, you can, select, move, scale, rotate, and skew objects Edit Path nodes or control handles (F2) This tool is designed for manipulating the geometry of objects Zoom in or Out(F3) Allows you to access a wide set of zoom operations Create Rectangles or Squares(F4) A tool for creating and manipulating rectangles, squares, circles, and ellipses

  


# Shape Tools[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

You will need to know how to draw basic shapes before you can draw more complex shapes. This page will teach you how to draw these shapes. The shape tools are useful because they allow you to make and manipulate basic forms easily.

All shapes have control handles that can be dragged to manipulate various aspects. Sometimes it's better to use the shape's resize handles, instead of the Selector's generic resize abilities. While the Selector resizes relative to _the document_, the shape tools will resize relative to _the object_. Experiment with both to see which works best for you. (Use **Ctrl-Z** to undo any changes you don't want to keep.) To restrain the resize handles, **Ctrl-drag** them. This limits movement to 15-degree steps. To change the step size, go to **File > Inkscape Preferences** and choose **Steps**.

## Rectangles[[edit](/w/index.php?title=Inkscape/Shape_Tools&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/45/Inkscape_rectangle_tool.png/200px-Inkscape_rectangle_tool.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

A rounded rectangle with all handles extended.

Keyboard Shortcut - **F4** or **R**

To draw a rectangle, select the rectangle tool and drag from the top left to the bottom right. Hold down **Ctrl** while dragging to create a ratio-proportionate rectangle (e.g. a square). Hold **Shift** while dragging to draw the rectangle from its center.

Rectangles have four handles: the square ones control the size and aspect ratio, the round ones control rounding of corners. (**Shift-click** the handle to remove rounding.) One rounding handle is vertical, and makes rectangles more circular; the other is horizontal, and makes rectangles more elliptical.

## 3D Boxes[[edit](/w/index.php?title=Inkscape/Shape_Tools&action=edit&section=T-2)]

The 3D Box tool is an easy way to create a 3-dimensional rectangle. To select only one side of a 3D box, **Ctrl-click** it.

## Ellipses[[edit](/w/index.php?title=Inkscape/Shape_Tools&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikipedia/commons/9/93/Inkscape_ellipse_tool.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

The ellipse tool, describing a segment.

Keyboard shortcut - **F5** or **E**

To draw an ellipse, circle, or an arc, select the ellipse tool (looks like a ellipse), and drag from the top left to the bottom right. The ellipse tool has four handles: two rectangular ones control the size and aspect ratio; two circular ones control the angle of the arc. Dragging the circular handles _outside_ the ellipse makes a segment; dragging them _inside_ creates an arc. **Alt-click** one of the circular handles to completely close the ellipse.

## Stars and Polygons[[edit](/w/index.php?title=Inkscape/Shape_Tools&action=edit&section=T-4)]

Keyboard Shortcut - **Shift-8**

To switch between star and polygon, click the star-shaped or polygon-shaped icon in the _Tool Controls bar_ of the Star/Polygon tool.

Stars and polygons have two handles: one outer handle, for stretching and rotation, and one inner handle, for skewing. **Ctrl-drag** the outer handle in order to stretch without rotating, and **Ctrl-drag** the inner handle to change the ratio of the two handles without skewing.

## Spirals[[edit](/w/index.php?title=Inkscape/Shape_Tools&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Inkscape_spiral_tool.png/200px-Inkscape_spiral_tool.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Spiral tool, describing a spiral with 12 turns and a divergence of .25.

Keyboard shortcut - **F9** or **I**

To draw a spiral, select the spiral tool and draw, observing the results. The spiral has two handles at each end of it-an inner one and an outer one. Dragging the handles lengthens and shortens the spiral.

_Shift-drag_ the outer handle to scale and rotate the spiral.

**Alt-drag** the inner handle to change the divergence (distance between the loops). To make the distance really big, hold **Alt** and move the inner handle first towards the center, and then further in the same direction beyond the center, and possibly beyond the external boundary of the spiral. Spirals with a divergence less than 1 are denser towards the edges; ones with divergence greater than 1 are denser towards the center. To reset divergence, **Alt-click** the handle. **Shift-click** the handle to return it to the center.

Experiment with the handles and the **Shift** and **Alt** keys to get a grip on the tool.

## Fill and Stroke[[edit](/w/index.php?title=Inkscape/Shape_Tools&action=edit&section=T-6)]

All shapes have a fill and a stroke. (One exception to this is the spiral, which should only be given a stroke.) The stroke is the outline of the shape. The fill is the area inside the shape. To set fill and stroke colors, select the shape and go to **Object > Fill and Stroke**, or press **Ctrl-Shift-F**. Objects can be filled with solid, flat color from the inkscape pallet, a linear or radial gradient fill, or a pattern fill.

## Bitmap images[[edit](/w/index.php?title=Inkscape/Shape_Tools&action=edit&section=T-7)]

To insert a bitmap image—PNG or JPEG, paste it from the clipboard or drag and drop a bitmap file from the desktop. In this way, the images are only linked to, not embedded.

To turn some or all of the linked bitmap images into _embedded images_, use in menu **Effects > Images > Embed images**.

  


# Path Drawing Tools[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
Created by taking over from [[1]](http://commons.wikimedia.org/wiki/Commons:Tutorial_for_Vectorial_graphism). Needs to be rewritten; a beginning transition is missing.

The next three buttons as we go downwards are used for drawing paths. A path is a mathematical curve that is specified by a number of points that the path must curve through. Taking them out of order, lets look at the middle one, the bezier curve tool.

### Bezier Curve tool[[edit](/w/index.php?title=Inkscape/Path_Drawing_Tools&action=edit&section=T-1)]

![InkscapeBezierButtonAndCurve.png](//upload.wikimedia.org/wikipedia/commons/9/93/InkscapeBezierButtonAndCurve.png)

  


Above is an example of a bezier curve. You can see two nodes in this view. These are the start and end nodes of the curve. But there are node control handles that you cannot see. These determine how the line curves between the end nodes. In order to see those nodes you need to click on the node editing button.

### Node tool[[edit](/w/index.php?title=Inkscape/Path_Drawing_Tools&action=edit&section=T-2)]

![InkscapeNodeTool.png](//upload.wikimedia.org/wikipedia/commons/b/bd/InkscapeNodeTool.png)

  


Clicking on the node tool reveals another node in the middle of the curve.

If you then click on the middle node you will see the bezier handles appear.

![InkscapeBezierHandles.png](//upload.wikimedia.org/wikipedia/commons/4/4c/InkscapeBezierHandles.png)

  


These handles allow you to change the shape of the curves between the nodes. Notice that a list of node tools appear at the top. You can use these to change the nodes. We will not go into detail about these tools in this beginners tutorial.

The node tool can be used on all the objects created with the other tools to reveal their nodes.

### More on the drawing tools[[edit](/w/index.php?title=Inkscape/Path_Drawing_Tools&action=edit&section=T-3)]

The other two drawing tools also create paths. The top tool of the three is the scribble tool. Use it like a pencil. The computer will calculate all the nodes and beziers for you. Closed paths can be created by drawing a loop. (With the bezier tool, click on the start node to close the curve).

The last tool in the group is the calligraphy tool. It allows you to do calligraphic writing. The pen creates closed loops in a realistic pen nib like way. Because of this many graphic artists like to draw with this pen all the time.

![InkscapeCalligraphyClosedPaths.png](//upload.wikimedia.org/wikipedia/commons/9/95/InkscapeCalligraphyClosedPaths.png)

  


  


# Other Tools[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
Created by taking over from [[2]](http://commons.wikimedia.org/wiki/Commons:Tutorial_for_Vectorial_graphism). Needs to be rewritten; a beginning transition is missing.

### Selection tool[[edit](/w/index.php?title=Inkscape/Other_Tools&action=edit&section=T-1)]

This tool allows you to select objects, resize them and move them about. If you click twice on an object with the selection tool, the handles change and you are able to rotate an object. Click a third time to switch to the object's tool.

![InkscapeSelectionRotation.png](//upload.wikimedia.org/wikipedia/commons/6/69/InkscapeSelectionRotation.png)

  


### Zoom tool[[edit](/w/index.php?title=Inkscape/Other_Tools&action=edit&section=T-2)]

This tool looks like a magnifying glass with a + sign in it. Drag the tool over an area to zoom in. Shift and click to zoom out again.

You can zoom in and out with the **+** and **-** keys, respectively. (These keys are to the left of the Backspace key, and on the right side of the numeric keypad.) Another shortcut to zoom in is **Ctrl-middle click** or **Ctrl-right click**. (**Shift-Ctrl-middle click** or **Shift-Ctrl-right click** zooms out.)

Inkscape keeps a record of your previous zoom levels. To go back to a zoom level, use **`**; to go ahead to a zoom level, use **Shift-`**.

### Text tool[[edit](/w/index.php?title=Inkscape/Other_Tools&action=edit&section=T-3)]

Keyboard Shortcut - **F8** or **T**

Looks like a letter A. Click and drag an area where you want your text to go, then start typing! If the letters are too small, click on the select button, then drag the handles to make it bigger. There are a lot of things that you can do with text that are beyond the scope of this beginners tutorial.

### Connector tool[[edit](/w/index.php?title=Inkscape/Other_Tools&action=edit&section=T-4)]

Use this to draw a connection between two objects. For example, a drawing and a label.

![InkscapeConnector.png](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/InkscapeConnector.png/200px-InkscapeConnector.png)

  


The nice thing about using this tool is that if you decide to move the objects about on the canvas, the connector still maintains the connection.

  


### Gradient tool[[edit](/w/index.php?title=Inkscape/Other_Tools&action=edit&section=T-5)]

![Inkscape icons color gradient](//upload.wikimedia.org/wikipedia/commons/thumb/6/65/Inkscape_icons_color_gradient.svg/26px-Inkscape_icons_color_gradient.svg.png)

Click the gradient tool button in the Inkscape tool bar, then click and drag on an object and you will create a gradient from a fully opaque colour to full transparency. The gradient tool can be used to edit an existing gradient, adjust colour stops by dragging and placing the gradient handles that appear over an object when the tool is active.

### Colour Sampler tool[[edit](/w/index.php?title=Inkscape/Other_Tools&action=edit&section=T-6)]

![Inkscape icons color picker](//upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Inkscape_icons_color_picker.svg/26px-Inkscape_icons_color_picker.svg.png)

The colour sampler, or "eyedropper" tool can be used to sample any colour in the inkscape window.

  


# Making a Tomato[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

We want to make a juicy and plump tomato. Mouthwatering to look at, we really want to bring our product to life.

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/98/Inkscapetutorial-tomato-final.svg/220px-Inkscapetutorial-tomato-final.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

A tomato.

**NOTE**:In some versions **SHIFT + CRTL + F** is replaced by **CRTL + ALT + F** to access the attributes of an object

  1. Using the **Circle tool** draw a circle on the page
  2. With the circle selected, press **SHIFT + CRTL + F** to go to its attributes
  3. Change the **Opacity to 80%**
  4. Change the **colour** to a nice tomato **red**
  5. With the **circle tool** again, **draw an ellipse**, the same width as the tomato, below the tomato, this will be our shadow
  6. With the ellipse selected, press **SHIFT + CRTL + F**
  7. Change the **blur to 20%**, you can check the results as you move the slider.
  8. To add the leaves, select the **calligraphy tool** and change the colour to **green**
  9. In the calligraphy tool, change the **Thinning** attribute to **0.90**
  10. **Scribble the leaves** on, if you aren't satisfied, delete them and try again.
  11. select the main body of the tomato and press **CTRL + D**, this **will make an exact copy** of the tomato directly over the original
  12. Select this new copy and press **SHIFT + CRTL + F**
  13. Change the **Alpha channel to 50%**
  14. Change the colour to white, you should now have a hazy looking tomato
  15. select the 'haze' and press **CTRL + SHIFT + C**, this will change the haze from being a circle to allow you to change its shape more vigorously
  16. With the **Node editing tool** select the haze and using the square handles **crop the haze** to look like a reflection. If you want to add more square handles to the haze just double click.
  17. Sit back and admire your work

  


# Appendix:Reference[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## Shortcuts[[edit](/w/index.php?title=Inkscape/Appendix:Reference&action=edit&section=T-1)]

shortcut does what?

ctrl \+ z
undo (can be done multiple times)

ctrl \+ y **OR** ctrl \+ shift \+ z
redo (can be done multiple times)

ctrl \+ b
hide/show scrollbars

ctrl \+ ![Arrow keys.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/Arrow_keys.svg/64px-Arrow_keys.svg.png)
scroll

shift \+ _mouse wheel_
scroll horizontally

ctrl \+ tab
cycle through Inkscape windows

ctrl \+ shift \+ tab
cycle backwards through Inkscape windows

**Zooming**

-
zoom out

+/=
zoom in

ctrl \+ _middle click/right-click_
zoom in

shift \+ _middle click/right-click_
zoom out

ctrl \+ _mouse wheel_
zoom in (up) or out (down)

  


# Glossary[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

This is a glossary of the book.

Contents:
Top \- 0–9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z

## B[[edit](/w/index.php?title=Inkscape/Glossary&action=edit&section=T-1)]

bezier curve 
    TODO

## C[[edit](/w/index.php?title=Inkscape/Glossary&action=edit&section=T-2)]

connector 
    A line connecting two objects, one which sticks to them even when they move.

## G[[edit](/w/index.php?title=Inkscape/Glossary&action=edit&section=T-3)]

gradient 
    TODO

## H[[edit](/w/index.php?title=Inkscape/Glossary&action=edit&section=T-4)]

handle 
    A small rectangle or circle that enables the user to control shapes.

## N[[edit](/w/index.php?title=Inkscape/Glossary&action=edit&section=T-5)]

node 
    A point on a curve at which the curve can be manipulated.

## P[[edit](/w/index.php?title=Inkscape/Glossary&action=edit&section=T-6)]

path 
    TODO

  


# Links[[edit](/w/index.php?title=Template:Print_entry&action=edit&section=T-1)]

## See also[[edit](/w/index.php?title=Inkscape/Links&action=edit&section=T-1)]

  * [Help:Tutorial for Vectorial graphism](//commons.wikimedia.org/wiki/Help:Vector_graphics_tutorial) — a basic tutorial on Inkscape; 3400 words,
  * [Help:Inkscape#Saving files in Inkscape](//commons.wikimedia.org/wiki/Help:Inkscape#Saving_files_in_Inkscape)
  * [Help:Text and Inkscape](//commons.wikimedia.org/wiki/Help:Text_and_Inkscape) — 380 words

## Links[[edit](/w/index.php?title=Inkscape/Links&action=edit&section=T-2)]

  * [Inkscape](http://inkscape.org) — official web page
  * [Official User Documentation](http://inkscape.org/doc/) — licensed under GNU GPL V2[[3]](http://inkscape.svn.sourceforge.net/viewvc/inkscape/doc-docbook/trunk/COPYING?revision=14188&view=markup)
  * [Manual](http://en.flossmanuals.net/bin/view/Inkscape/WebHome) at flossmanuals.net — licensed under GNU GPL V3
  * [Inkscape Manual](http://tavmjong.free.fr/INKSCAPE/MANUAL/html/index.php) by Tavmjong Bah — available without paying ony for personal use
  * [Inkscape drawings](http://inkscape.deviantart.com/favourites/) on DeviantArt

![TODO](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**Editor's note**  
Both GNU GPL V2 and GNU GPL V3 are incompatible with GNU FDL. Thus, the materials linked to licensed under either version cannot be taken over to Wikibooks.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Inkscape/Print_version&oldid=1277537](http://en.wikibooks.org/w/index.php?title=Inkscape/Print_version&oldid=1277537)" 

[Category](/wiki/Special:Categories): 

  * [Inkscape](/wiki/Category:Inkscape)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Inkscape%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Inkscape%2FPrint+version)

### Namespaces

  * [Book](/wiki/Inkscape/Print_version)
  * [Discussion](/w/index.php?title=Talk:Inkscape/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Inkscape/Print_version)
  * [Edit](/w/index.php?title=Inkscape/Print_version&action=edit)
  * [View history](/w/index.php?title=Inkscape/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Inkscape/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Inkscape/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Inkscape/Print_version&oldid=1277537)
  * [Page information](/w/index.php?title=Inkscape/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Inkscape%2FPrint_version&id=1277537)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Inkscape%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Inkscape%2FPrint+version&oldid=1277537&writer=rl)
  * [Printable version](/w/index.php?title=Inkscape/Print_version&printable=yes)

  * This page was last modified on 14 September 2008, at 07:49.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Inkscape/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
