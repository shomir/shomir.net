# Circuit Theory/All Chapters

From Wikibooks, open books for an open world

< [Circuit Theory](/wiki/Circuit_Theory)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Circuit_Theory/All_Chapters&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Circuit_Theory/All_Chapters) on _16 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Circuit_Theory/All_Chapters&oldid=2502331&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Circuit Theory](/wiki/Circuit_Theory)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Circuit_Theory/All_Chapters&action=purge&printable=yes) this page.

  


![Wheatstone Bridge.svg](//upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Wheatstone_Bridge.svg/441px-Wheatstone_Bridge.svg.png)

**Circuit Theory**  
Wikibooks: The Free Library

**[Circuit Theory](/wiki/Circuit_Theory)**

  


# Preface

This wikibook is going to be an introductory text about electric circuits. It will cover some the basics of electric circuit theory, circuit analysis, and will touch on circuit design. This book will serve as a companion reference for a 1st year of an Electrical Engineering undergraduate curriculum. Topics covered include AC and DC circuits, passive circuit components, phasors, and RLC circuits. The focus is on students of an electrical engineering undergraduate program. Hobbyists would benefit more from reading [Electronics](/wiki/Electronics) instead.

_This book is not nearly completed, and could still be improved. People with knowledge of the subject are encouraged to contribute._

The main editable text of this book is located at <http://en.wikibooks.org/wiki/Circuit_Theory>. The wikibooks version of this text is considered the most up-to-date version, and is the best place to edit this book and contribute to it.  


Electric Circuits Introduction

The theory of electrical circuits can be a complex area of study. The chapters in this section will introduce the reader to the world of electric circuits, introduce some of the basic terminology, and provide the first introduction to passive circuit elements.

  


# Introduction

**[Circuit Theory](/wiki/Circuit_Theory)**

## Who is This Book For?

This is designed for a first course in Circuit Analysis which is usually accompanied by a set of labs. It is assumed that students are in a Differential Equations class at the same time. Phasors are used to avoid the Laplace transform of driving functions while maintaining a complex impedance transform of the physical circuit that is identical in both. 1st and 2nd order differential equations can be solved using phasors and calculus if the driving functions are sinusoidal. The sinusoidal is then replaced by the more simple step function and then the convolution integral is used to find an analytical solution to any driving function. This leaves time for a more intuitive understanding of poles, zeros, transfer functions, and Bode plot interpretation.

For those that have already had differential equations, the Laplace transform equivalent will be presented as an alternative while focusing on phasors and calculus.

This book will expect the reader to have a firm understanding of Calculus specifically, and will not stop to explain the fundamental topics in Calculus.

For information on Calculus, see the wikibook: [Calculus](/wiki/Calculus).

## What Will This Book Cover?

This book will cover linear circuits, and linear circuit elements. The goal is to emphasize Kirchhoff and symbolic algebra systems such as matLab mupad or mathematica at the expense of node, mesh, Norton, etc. A phasor/calculus based approach starts at the very beginning and ends with the convolution integral to handle all the various types of forcing functions.

The result is a linear analysis experience that is general in nature but skips Laplace and Fourier transforms.

Krichhoff's laws receive normal focus, but the other circuit analysis/simplification techniques receive less than a normal attention.

The class ends with application of these concepts in Power Analysis, Filters, Control systems.

The goal is set the ground work for a transition to the digital version of these concepts from a firm basis in the physical world. The next course would be one focused on modeling linear systems and analyzing them digitally in preparation for a digital signal ([DSP](//en.wikipedia.org/wiki/Digital_signal_processing)) processing course.

## Where to Go From Here

  * For a technician version of this course which focuses on the real rather than the idea, expertise rather than theory, on algebra rather than calculus, see the **[Electronics](/wiki/Electronics)** wikibook
  * Take **[Ordinary_Differential_Equations](/wiki/Ordinary_Differential_Equations)** now that you have a practical reason to. The math class should ideally feel like an "art" class and be enjoyable.
  * To begin a course of study in Computer Engineering, see the **[Digital Circuits](/wiki/Digital_Circuits)** wikibook.
  * For a traditional "next" course see the **[Signals and Systems](/wiki/Signals_and_Systems)** wikibook. There should be an overlap with this one.
  * The intended next course would have a name such as **[A New Sequence in Signals and Linear Systems](http://www.ece.umd.edu/~adrian/enee222/textbook/enee241text0708.pdf)** or **[Elements of Discrete Signal Analysis](http://www.amazon.com/Signals-Systems-using-MATLAB-Chaparro/dp/0123747163)**.

  


# Basic Terminology

**[Circuit Theory](/wiki/Circuit_Theory)**

## Basic Terminology

There are a few key terms that need to be understood at the beginning of this book, before we can continue. This is only a partial list of all terms that will be used throughout this book, but these key words are important to know before we begin the main narrative of this text.

Time domain 
    The time domain is described by graphs of power, voltage and current that depend upon time. The "Time domain" is simply another way of saying that our circuits change with time, and that the major variable used to describe the system is time. Another name is "Temporal".

Frequency domain
    The frequency domain are graphs of power, voltage and/or current that depend upon frequency such as [Bode plots](//en.wikipedia.org/wiki/Bode_plot). Variable frequencies in wireless communication can represent changing channels or data on a channel. Another name is the "[Fourier domain](//en.wikipedia.org/wiki/Fourier_transform)". Other domains that an engineer might encounter are the "Laplace domain" (or the "s domain" or "complex frequency domain"), and the "Z domain". When combined with the time, it is called a "Spectral" or "[Waterfall](//en.wikipedia.org/wiki/Spectrogram)."

Circuit Response 
    Circuits generally have inputs and outputs. In fact, it is safe to say that a circuit isn't useful if it doesn't have one or the other (usually both). Circuit response is the relationship between the circuit's input to the circuit's output. The circuit response may be a measure of either current or voltage.

Non-homogeneous 
    Circuits are described by equations that capture the the component characteristics and how they are wired together. These equations are non-homogeneous in nature. Solving these equations requires splitting the single problem into two problems: Steady State Solution (particular solution) and Transient Solution (homogeneous solution).

Steady State Solution 
    The final value, when all circuit elements have a constant or periodic behaviour, is also known as the steady-state value of the circuit. The circuit response at steady state (when voltages and currents have stopped changing due to a disturbance) is also known as the "steady state response". The steady state solution to the particular integral is called the **[particular solution**](/wiki/Ordinary_Differential_Equations/Non_Homogenous_1).

Transient Response 
    A transient response occurs when: 

    a circuit is turned on or off
    a sensor responds to the physical world changes
    static electricity is discharged
    an old car with old spark plugs (before resistors were put in spark plugs) drives by

    Transient means momentary, or a short period of time. Transient means that the energy in a circuit suddenly changes which causes the energy storage elements to react. The circuit's energy state is forced to change. When a car goes over a bump, it can fly apart, feel like a rock, or cushion the impact in a designed manner. The goal of most circuit design is to plan for transients, whether intended or not.

    Transient solutions are determined by assuming the driving function(s) is zero which creates a homogeneous equation, which has a **[homogeneous solution**](/wiki/Ordinary_Differential_Equations/Homogenous_1) technique.

## Summary

When something changes in a circuit, there is a certain transition period before a circuit "settles down", and reaches its final value. The response that a circuit has before settling into its _steady-state response_ is known as the _transient response_. Using using **[Euler's formula**](//en.wikipedia.org/wiki/Euler%27s_formula), **[complex numbers**](/wiki/Arithmetic_Course/Types_of_Number/Complex_Number), **[phasors**](//en.wikipedia.org/wiki/Phasors) and the **[s-plane**](//en.wikipedia.org/wiki/S-plane), a **[homogeneous solution**](/wiki/Ordinary_Differential_Equations/Homogenous_1) technique will be developed that captures the transient response by assuming the final state has no energy. In addition, a **[particular solution**](/wiki/Ordinary_Differential_Equations/Non_Homogenous_1) technique will be developed that finds the final energy state. Added together, they predict the _circuit response_.

The related **[Differential equation**](/wiki/Ordinary_Differential_Equations) development of homogeneous and particular solutions will be avoided.  


# Variables and Standard Units

**[Circuit Theory](/wiki/Circuit_Theory)**

## Electric Charge (Coulombs)

**Note:**  
An electron has a charge of  
**-1.602×10E-19** C.

**[Electric charge**](//en.wikipedia.org/wiki/Electric_charge) is a [physical property](//en.wikipedia.org/wiki/physical_property) of [matter](//en.wikipedia.org/wiki/matter) that causes it to experience a [force](//en.wikipedia.org/wiki/force) when near other electrically charged matter. Electric Charge (symbol q) is measured in SI units called **"Coulombs"**, which are abbreviated with the letter capital C.

We know that q=n*e, where n = number of electrons and e= 1.6*10-19. Hence n=1/e coulombs. A Coulomb is the total charge of 6.24150962915265×1018 electrons, thus a single electron has a charge of −1.602 × 10−19.

It is important to understand that this concept of "charge" is associated with static electricity. Charge, as a concept, has a physical boundary that is related to counting a group of electrons. "Flowing" electricity is an **[entirely different situation**](//en.wikipedia.org/wiki/Electric_charge#Static_electricity_and_electric_current). "Charge" and electrons separate. Charge moves at the speed of light while electrons move at the speed of **[1 meter/hour**](//en.wikipedia.org/wiki/Drift_velocity). Thus in most circuit analysis, "charge" is an abstract concept unrelated to energy or an electron and more related to the flow of **[information**](//en.wikipedia.org/wiki/Physical_information).

Electric charge is the subject of many fundamental laws, such as **[Coulomb's Law**](//en.wikipedia.org/wiki/Coulomb%27s_law) and **[Gauss' Law**](//en.wikipedia.org/wiki/Gauss%27s_law) (static electricity) but is not used much in circuit theory.

## Voltage (Volts)

**Voltage** is a measure of the work required to move a charge from one point to another in a electric field. Thus the unit "volt" is defined as a Joules (J) per Coulomb (C).

    ![V = \\frac{W}{q}](//upload.wikimedia.org/math/1/f/9/1f9118a7a05dd7f9ab01ecc20a8102d4.png)

W represents work, q represents an amount of charge. Charge is a static electricity concept. The definition of a volt is shared between static and "flowing" electronics.

Voltage is sometimes called "electric potential", because voltage represents the a difference in Electro Motive Force (EMF) that can produce current in a circuit. More voltage means more potential for current. Voltage also can be called "Electric Pressure", although this is far less common.

Voltage is not measured in absolutes but in _relative_ terms. The English language tradition obscures this. For example we say "What is the distance to New York?" Clearly implied is the relative distance from where we are standing to New York. But if we say "What is the voltage at ______?" What is the starting point?

Voltage is defined between two points. Voltage is relative to where 0 is defined. We say "The voltage from point A to B is 5 volts." It is important to understand EMF and voltage are two different things.

When the question is asked "What is the voltage at ______?", look for the ground symbol on a circuit diagram. Measure voltage from ground to _____. If the question is asked "What is the voltage from A to B?" then put the red probe on A and the black probe on B (not ground).

The absolute is referred to as "EMF" or Electro Motive Force. The difference between the two EMF's is a voltage.

## Current (Amperes)

**Current** is a measurement of the flow of electricity. Current is measured in units called **Amperes** (or "Amps"). An ampere is "charge volume velocity" in the same way water current could be measured in "cubic feet of water per second." But current is a **[base SI unit**](//en.wikipedia.org/wiki/SI_base_unit), a fundamental dimension of reality like space, time and mass. A coulomb or charge is not. A coulomb is actually defined in terms of the ampere. "Charge or Coulomb" is a **[derived SI Unit**](//en.wikipedia.org/wiki/SI_derived_units#Derived_units_with_special_names). The coulomb is a fictitious entity left over from the **[one fluid /two fluid**](//en.wikipedia.org/wiki/History_of_electromagnetic_theory#Late_18th_century) philosophies of the 18th century.

This course is about flowing electrical energy that is found in all modern electronics. Charge volume velocity (defined by current) is a useful concept, but understand it has no basis in reality. Do not think of current as a bundle electrons carrying energy through a wire. [Special relativity](/wiki/Special_Relativity) and [quantum mechanics](/wiki/Quantum_Mechanics) concepts are necessary to understand how electrons move at **[1 meter/hour**](//en.wikipedia.org/wiki/Drift_velocity) through copper, yet electromagnetic energy moves at near the speed of light.

**[Charge**](//en.wikipedia.org/wiki/Electric_charge#Properties) is similar to the **[rest mass**](//en.wikipedia.org/wiki/Rest_mass) concept of relativity and generates the **[U(1) symmetry**](//en.wikipedia.org/wiki/Charge_\(physics\)) of electromagnetism

Amperes are abbreviated with an "A" (upper-case A), and the variable most often associated with current is the letter "i" (lower-case I). In terms of coulombs, an ampere is:

    ![i = \\frac{dq}{dt}](//upload.wikimedia.org/math/0/b/d/0bd6ff328be08b8770eab43586cff496.png)

For the rest of this book, the lower-case J ( j ) will be used to denote an imaginary number, and the lower-case I ( i ) will be used to denote current.

Because of the widespread use of complex numbers in Electrical Engineering, it is common for electrical engineering texts to use the letter "j" (lower-case J) as the imaginary number, instead of the "i" (lower-case I) commonly used in math texts. This wikibook will adopt the "j" as the imaginary number, to avoid confusion.

## Energy and Power

Electrical theory is about energy storage and the flow of energy in circuits. Energy is chopped up arbitrarily into something that doesn't exist but can be counted called a coulomb. Energy per coulomb is voltage. The velocity of a coulomb is current. Multiplied together, the units are energy velocity or power ... and the unreal "coulomb" disappears.

### Energy

Energy is measured most commonly in Joules, which are abbreviated with a "J" (upper-case J). The variable most commonly used with energy is "w" (lower-case W). The energy symbol is w which stands for work. Work is something good that we, as humans value.

From a thermodynamics point of view, all energy consumed by a circuit is work ... all the heat is turned into work. Practically speaking, this can not be true. If it were true, computers would never consume any energy and never heat up.

The reason that all the energy going into a circuit and leaving a circuit is considered "work" is because from a thermodynamic point of view, electrical energy is ideal. All of it can be used. Ideally all of it can be turned into work. Most introduction to thermodynamics courses assume that electrical energy is completely organized (and has entropy of 0).

### Power

A corollary to the concept of energy being work, is that all the energy/power of a circuit (ideally) can be accounted for. The sum of all the power entering and leaving a circuit should add up to zero. No energy should be accumulated (theoretically). Of course capacitors will charge up and may hold onto their energy when the circuit is turned off. Inductors will create a magnetic field containing energy that will instantly disappear back into the source through the switch that turns the circuit off.

This course uses what is called the "[passive](//en.wikipedia.org/wiki/Electric_power#Passive_sign_convention)" sign convention for power. Energy put into a circuit by a power supply is negative, energy leaving a circuit is positive.

Power (the flow of energy) computations are an important part of this course. The symbol for power is w (for work) and the units are Watts or W.  


# Electric Circuit Basics

**[Circuit Theory](/wiki/Circuit_Theory)**

## Circuits

**Circuits** (also known as "networks") are collections of circuit elements and wires. Wires are designated on a schematic as being straight lines. Nodes are locations on a schematic where 2 or more wires connect, and are usually marked with a dark black dot. Circuit Elements are "everything else" in a sense. Most basic circuit elements have their own symbols so as to be easily recognizable, although some will be drawn as a simple box image, with the specifications of the box written somewhere that is easy to find. We will discuss several types of basic circuit components in this book.

## Ideal Wires

For the purposes of this book, we will assume that an ideal wire has zero total resistance, no capacitance, and no inductance. A consequence of these assumptions is that these ideal wires have infinite bandwidth, are immune to interference, and are — in essence — completely uncomplicated. This is not the case in real wires, because all wires have at least some amount of associated resistance. Also, placing multiple real wires together, or bending real wires in certain patterns will produce small amounts of capacitance and inductance, which can play a role in circuit design and analysis. This book will assume that all wires are ideal.

## Ideal Junctions or Nodes

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Node-pressure.jpg/220px-Node-pressure.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Nodes are areas where the Electromotive Force is the same.

Nodes are also called "junctions" in this book in order to make a distinction between Node analysis, Kirchhoff's current law and discussions about a physical node itself. Here a physical node is discussed.

A junction is a group of wires that share the same [electromotive force](//en.wikipedia.org/wiki/Electromotive_force) (not voltage). Wires ideally have no resistance, thus all wires that touch wire to wire somewhere are part of the same node. The diagram on the right shows three big blue nodes, two smaller green nodes and two trivial (one wire touching another) nodes.

Sometimes a node is described as where two or more wires touch and students circle where wires intersect and call this a node. This only works on simple circuits.

One node has to be labeled ground in any circuit drawn before voltage can be computed or the circuit simulated. Typically this is the node having the most components connected to it. Logically it is normally placed at the bottom of the circuit logic diagram.

Ground is not always needed physically. Some circuits are [floated](//en.wikipedia.org/wiki/Floating_ground) on purpose.

[Node Quiz](/w/index.php?title=Circuit_Theory/All_Chapters/NodeQuiz&action=edit&redlink=1)

## Measuring instruments

**Voltmeters and Ammeters** are devices that are used to measure the voltage across an element, and the current flowing through a wire, respectively.

### Ideal Voltmeters

An ideal voltmeter has an infinite resistance (in reality, several megaohms), and acts like an open circuit. A [voltmeter](//en.wikiversity.org/wiki/Tutorial_on_preparing_the_multimeter_for_start_measuring_the_voltage) is placed across the terminals of a circuit element, to determine the voltage across that element. In practice the voltmeter siphons a enough energy to move a needle, cause thin strips of metal to separate or turn on a transistor so a number is displayed.

### Ideal Ammeters

An ideal ammeter has zero resistance and acts like a short circuit. Ammeters require cutting a wire and plugging the two ends into the Ammeter. In practice an ammeter places a tiny resistor in a wire and measures the tiny voltage across it or the ammeter measures the [magnetic field strength](//en.wikipedia.org/wiki/Clamp_meter) generated by current flowing through a wire. Ammeters are not used that much because of the wire cutting, or wire disconnecting they require.

## Active Passive & ReActive

The elements which are capable of delivering energy or which are capable to amplify the signal are called "Active elements". All power supplies fit into this category.

The elements which will receive the energy and dissipate it are called "Passive elements". Resistors model these devices.

Reactive elements store and release energy into a circuit. Ideally they don't either consume or generate energy. Capacitors, and inductors fall into this category.

## Open and Short Circuits

### Open

No current flows through an open. Normally an **open** is created by a bad connector. Dust, bad solder joints, bad crimping, cracks in circuit board traces, create an **open**. Capacitors respond to DC by turning into **opens** after charging up. Uncharged inductors appear as **opens** immediately after powering up a circuit. The word **open** can refer to a problem description. The word **open** can also help develop an intuition about circuits.

Typically the circuit stops working with opens because 99% of all circuits are driven by voltage power sources. Voltage sources respond to an open with no current. Opens are the equivalent of clogs in plumbing .. which stop water from flowing.

On one side of the open, EMF will build up, just like water pressure will build up on one side of a clogged pipe. Typically a voltage will appear across the open.

### Short

A voltage source responds to a **short** by delivering as much current as possible. An extreme example of this can be seen in this [ball bearing motor video](http://www.youtube.com/watch?v=g60okBMeTKo). The motor appears as a short to the battery. Notice he only completes the short for a short time because he is worried about the car battery exploding.

Maximum current flows through a **short**. Normally a **short** is created by a wire, a nail, or some loose screw touching parts of the circuit unintentionally. Most component failures start with heat build up. The heat destroys varnish, paint, or thin insulation creating a **short**. The **short** causes more current to flow which causes more heat. This cycle repeats faster and faster until there is a puff of smoke and everything breaks creating an **open**. Most component failures start with a **short** and end in an **open** as they burn up. Feel the air temperature above each circuit component after power on. Build a memory of what normal operating temperatures are. Cold can indicate a short that has already turned into an open.

An uncharged capacitor initially appears as a **short** immediately after powering on a circuit. An inductor appears as a **short** to DC after charging up. The **short** concept also helps build our intuition, provides an an opportunity to talk about electrical safety and helps describe component failure modes.

A **closed** switch can be thought of as short. [Switches](//en.wikipedia.org/wiki/Switch) are surprisingly complicated. It is in a study of switches that the term **closed** begins to dominate that of **short**.  


# Resistors and Resistance

**[Circuit Theory](/wiki/Circuit_Theory)**

### Resistors

Mechanical engineers seem to model everything with a spring. Electrical engineers compare everything to a **Resistor**. Resistors are circuit elements that resist the flow of current. When this is done a voltage appears across the resistor's two wires.

A pure [resistor](//en.wikipedia.org/wiki/Resistor) turns electrical energy into heat. Devices similar to resistors turn this energy into light, motion, heat, and other forms of energy.

![Resistor.png](//upload.wikimedia.org/wikibooks/en/1/15/Resistor.png)

Current in the drawing above is shown entering the + side of the resistor. Resistors don't care which leg is connected to positive or negative. The + means where the positive or red probe of the volt meter is to be placed in order to get a positive reading. This is called the "[positive charge](//en.wikipedia.org/wiki/Electric_current#Conventions)" flow sign convention. Some circuit theory classes (often within a physics oriented curriculum) are taught with an "electon flow" sign convention.

In this case, current entering the + side of the resistor means that the resistor is removing energy from the circuit. This is good. The goal of most circuits is to send energy out into the world in the form of motion, light, sound, etc.

### Resistance

**[Resistance](//en.wikipedia.org/wiki/Electrical_resistance)** is measured in terms of units called "Ohms" (volts per ampere), which is commonly abbreviated with the Greek letter Ω ("Omega"). Ohms are also used to measure the quantities of _impedance_ and _reactance_, as described in a later chapter. The variable most commonly used to represent resistance is "r" or "R".

Resistance is defined as:

    ![r = {\\rho L \\over A}](//upload.wikimedia.org/math/a/3/8/a38108dbe2fd2e3f53fd165f3ae7caf5.png)

where ρ is the resistivity of the material, L is the length of the resistor, and A is the cross-sectional area of the resistor.

### Conductance

**Conductance** is the inverse of resistance. Conductance has units of "Siemens" (S), sometimes referred to as mhos (ohms backwards, abbreviated as an upside-down Ω). The associated variable is "G":

    ![G = \\frac{1}{r}](//upload.wikimedia.org/math/1/3/d/13db286f93a081595a4a0769919b2fec.png)

Before calculators and computers, conductance helped [reduce](//en.wikipedia.org/wiki/Smith_chart) the number of hand calculations that had to be done. Now conductance and it's related concepts of [admittance](//en.wikipedia.org/wiki/Admittance) and susceptance can be skipped with matlab, octave, wolfram alpha and other computing tools. Learning one or more these computing tools is now absolutely necessary in order to get through this text.

### Resistor terminal relation

![](//upload.wikimedia.org/wikipedia/commons/6/64/Ohmslawvoltagesource.png)

A simple circuit diagram relating current, voltage, and resistance

The drawing on the right is of a battery and a resistor. Current is leaving the + terminal of the battery. This means this battery is turning chemical potential energy into electromagnetic potential energy and dumping this energy into the circuit. The flow of this energy or power is negative.

Current is entering the positive side of the resistor even though a + has not been put on the resistor. This means electromagnetic potential energy is being converted into heat, motion, light, or sound depending upon the nature of the resistor. Power flowing out of the circuit is given a positive sign.

The relationship of the voltage across the resistor V, the current through the resistor I and the value of the resistor R is related by [ohm's law](//en.wikiversity.org/wiki/Ohm%27s_law):

  


[Resistor Terminal Relation]

    ![V=R*I](//upload.wikimedia.org/math/a/8/7/a875f26beb49e54325659e0c9ebbf1a2.png)

  
A resistor, capacitor and inductor all have only two wires attached to them. Sometimes it is hard to tell them apart. In the real world, all three have a bit of resistance, capacitance and inductance in them. In this unknown context, they are called two terminal devices. In more complicated devices, the wires are grouped into [ports](//en.wikipedia.org/wiki/Two-port_network). A two terminal device that expresses Ohm's law when current and voltage are applied to it, is called a resistor.

### Resistor Safety

Resistors come in all forms. Most have a maximum power rating in watts. If you put too much through them, they can melt, catch on fire, etc.

### Example

Suppose the voltage across a resistor's two terminals is 10 volts and the measured current through it is 2 amps. What is the resistance?

If ![ v=iR ](//upload.wikimedia.org/math/7/5/c/75c19a37aec821a1e4cdf697a67c865c.png) then ![ R = v/i = 10V/2A = 5 ohms](//upload.wikimedia.org/math/2/8/4/2841f5d7bd78669f9da7bf18bfad4f54.png)

  


Resistive Circuits

We've been introduced to passive circuit elements such as resistors, sources, and wires. Now, we are going to explore how complicated circuits using these components can be analyzed.

  


# Resistive Circuit Analysis Techniques

[Circuit Theory/Resistive Circuit Analysis](/w/index.php?title=Circuit_Theory/Resistive_Circuit_Analysis&action=edit&redlink=1)  


# Source Transformations

**[Circuit Theory](/wiki/Circuit_Theory)**

## Source Transformations

Independent current sources can be turned into independent voltage sources, and vice-versa, by methods called "Source Transformations." These transformations are useful for solving circuits. We will explain the two most important source transformations, **Thevenin's Source**, and **Norton's Source**, and we will explain how to use these conceptual tools for solving circuits.

## Black Boxes

A circuit (or any system, for that matter) may be considered a **black box** if we don't know what is inside the system. For instance, most people treat their computers like a black box because they don't know what is inside the computer (most don't even care), all they know is what goes in to the system (keyboard and mouse input), and what comes out of the system (monitor and printer output).

Black boxes, by definition, are systems whose internals aren't known to an outside observer. The only methods that an outside observer has to examine a black box is to send input into the systems, and gauge the output.

## Thevenin's Theorem

Let's start by drawing a general circuit consisting of a source and a load, as a block diagram:

![General Source-Load Circuit.svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/47/General_Source-Load_Circuit.svg/375px-General_Source-Load_Circuit.svg.png)

Let's say that the source is a collection of voltage sources, current sources and resistances, while the load is a collection of resistances only. Both the source and the load can be arbitrarily complex, but we can conceptually say that the source is directly equivalent to a single voltage source and resistance (figure (a) below).

![Thevenin Equivalent.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/24/Thevenin_Equivalent.svg/175px-Thevenin_Equivalent.svg.png)

![Thevenin Equivalent Under Test.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Thevenin_Equivalent_Under_Test.svg/290px-Thevenin_Equivalent_Under_Test.svg.png)

_(a)_
_(b)_

We can determine the value of the resistance _Rs_ and the voltage source, _vs_ by attaching an independent source to the output of the circuit, as in figure (b) above. In this case we are using a current source, but a voltage source could also be used. By varying _i_ and measuring _v_, both _vs_ and _Rs_ can be found using the following equation:

    

    ![v=v_s+iR_s \\,](//upload.wikimedia.org/math/5/7/0/57099305bfd76d11ecba1d20f5a1aa3a.png)

There are two variables, so two values of _i_ will be needed. See [Example 1](/w/index.php?title=Circuit_Theory/All_Chapters/Examples&action=edit&redlink=1) for more details. We can easily see from this that if the current source is set to zero (equivalent to an open circuit), then _v_ is equal to the voltage source, _vs_. This is also called the open-circuit voltage, _voc_.

This is an important concept, because it allows us to model what is inside a unknown (linear) circuit, just by knowing what is coming out of the circuit. This concept is known as **Thévenin's Theorem** after French telegraph engineer [Léon Charles Thévenin](//en.wikipedia.org/wiki/L%C3%A9on_Charles_Th%C3%A9venin), and the circuit consisting of the voltage source and resistance is called the **Thévenin Equivalent Circuit**.

## Norton's Theorem

Recall from above that the output voltage, _v_, of a Thévenin equivalent circuit can be expressed as

    

    ![v=v_s+iR_s \\,](//upload.wikimedia.org/math/5/7/0/57099305bfd76d11ecba1d20f5a1aa3a.png)

Now, let's rearrange it for the output current, _i_:

    

    ![i=-\\frac{v_s}{R_s}+\\frac{v}{R_s}](//upload.wikimedia.org/math/2/6/4/264a70f493f7fe6dce222c5ac01ee40f.png)

This is equivalent to a KCL description of the following circuit. We can call the constant term _vs/Rs_ the source current, _is_.

![Norton Equivalent Under Test.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Norton_Equivalent_Under_Test.svg/325px-Norton_Equivalent_Under_Test.svg.png)

The equivalent current source and the equivalent resistance can be found with an independent source as before (see [Example 2](/w/index.php?title=Circuit_Theory/All_Chapters/Examples&action=edit&redlink=1)).

When the above circuit (the **Norton Equivalent Circuit**, after Bell Labs engineer [E.L. Norton](//en.wikipedia.org/wiki/Edward_Lawry_Norton)) is disconnected from the external load, the current from the source all flows through the resistor, producing the requisite voltage across the terminals, _voc_. Also, if we were to short the two terminals of our circuit, the current would all flow through the wire, and none of it would flow through the resistor (current divider rule). In this way, the circuit would produce the short-circuit current _isc_ (which is exactly the same as the source current _is_).

## Circuit Transforms

We have just shown turns out that the Thévenin and Norton circuits are just different representations of the same black box circuit, with the same Ohm's Law/KCL equations. This means that we cannot distinguish between Thévenin source and a Norton source from outside the black box, and that we can directly equate the two as below:

![Thevenin Equivalent.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/24/Thevenin_Equivalent.svg/175px-Thevenin_Equivalent.svg.png)

![\\equiv](//upload.wikimedia.org/math/2/e/f/2ef0deb28c4bbc1ce6c11e4cce7e75b1.png)

![Norton Equivalent.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Norton_Equivalent.svg/175px-Norton_Equivalent.svg.png)

We can draw up some rules to convert between the two:

  * The values of the resistors in each circuit are conceptually identical, and can be called the equivalent resistance, _Req_:

    

    ![R_{s_n}=R_{s_t}=R_s=R_{eq}](//upload.wikimedia.org/math/8/a/8/8a8bed5a134dbb87459e4c5050143088.png)

  * The value of a Thévenin voltage source is the value of the Norton current source times the equivalent resistance (Ohm's law):

    

    ![v_s=i_sr\\,](//upload.wikimedia.org/math/4/2/c/42cef448e3483a7c68a18a9d96c3aa3f.png)

If these rules are followed, the circuits will behave identically. Using these few rules, we can transform a Norton circuit into a Thévenin circuit, and vice versa. This method is called **source transformation**. See [Example 3](/w/index.php?title=Circuit_Theory/All_Chapters/Examples&action=edit&redlink=1).

## Open Circuit Voltage and Short Circuit Current

The open-circuit voltage, _voc_ of a circuit is the voltage across the terminals when the current is zero, and the short-circuit current _isc_ is the current when the voltage across the terminals is zero:

![Open Circuit Voltage.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Open_Circuit_Voltage.svg/125px-Open_Circuit_Voltage.svg.png)

![Short Circuit Current.svg](//upload.wikimedia.org/wikipedia/commons/thumb/6/64/Short_Circuit_Current.svg/150px-Short_Circuit_Current.svg.png)

_The open circuit voltage_
_The short circuit current_

We can also observe the following:

  * The value of the Thévenin voltage source is the open-circuit voltage:

    

    ![v_s=v_{oc}\\,](//upload.wikimedia.org/math/9/8/9/98996c26a2b3d207dd3525a1fd8a73b5.png)

  * The value of the Norton current source is the short-circuit current:

    

    ![i_s=i_{sc}\\,](//upload.wikimedia.org/math/8/0/7/8076caddd3998c7b0bce319a108fc9db.png)

We can say that, generally,

    

    ![R_{eq}=\\frac{v_{oc}}{i_{sc}}](//upload.wikimedia.org/math/5/e/7/5e790715c4fe064e6e9de49ce64afed2.png)

## Why Transform Circuits?

How are Thevenin and Norton transforms useful?

    Describe a black box characteristics in a way that can predict its reaction to any load.
    Find the current through and voltage across any device by removing the device from the circuit! This can instantly make a complex circuit much simpler to analyze.
    Stepwise simplification of a circuit is possible if voltage sources have a series impedance and current sources have a parallel impedance.

  


# Maximum Power Transfer

**[Circuit Theory](/wiki/Circuit_Theory)**

## Maximum Power Transfer

Often we would like to transfer the most power from a source to a load placed across the terminals as possible. How can we determine the optimum resistance of the load for this to occur?

Let us consider a source modelled by a Thévenin equivalent (a Norton equivalent will lead to the same result, as the two are directly equivalent), with a load resistance, _RL_. The source resistance is _Rs_ and the open circuit voltage of the source is _vs_:

![Maximum Power Transfer Circuit.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Maximum_Power_Transfer_Circuit.svg/275px-Maximum_Power_Transfer_Circuit.svg.png)

The current in this circuit is found using Ohm's Law:

    

    ![i=\\frac{v_s}{R_s+R_L}](//upload.wikimedia.org/math/d/c/e/dcef22a7ad3045416aa749aa6ecc4c31.png)

The voltage across the load resistor, _vL_, is found using the voltage divider rule:

    

    ![v_L=v_s \\,\\frac{R_L}{R_s + R_L}](//upload.wikimedia.org/math/e/3/b/e3bf6bf38372d288816023d7cc4d7de1.png)

We can now find the power dissipated in the load, _PL_ as follows:

    

    ![P_L=v_Li=\\frac{R_L \\, v^2_s}{\\left\(R_s+R_L\\right\)^2}](//upload.wikimedia.org/math/9/2/8/9289827d98d8f600ccae32b03833c84e.png)

We can now rewrite this to get rid of the _RL_ on the top:

    

    ![P_L=\\frac{v^2_s}{ \\left\(\\frac{R_s}{\\sqrt{R_L}}+\\sqrt{R_L}\\right\)^2} = 
\\frac{v^2_s}{ R_s \\left\(\\frac{\\sqrt{R_s}}{\\sqrt{R_L}}+\\frac{\\sqrt{R_L}}{\\sqrt{R_s} }\\right\)^2}](//upload.wikimedia.org/math/0/e/2/0e22fd07cfc7c502a7207debcf521267.png)

Assuming the source resistance is not changeable, then we obtain maximum power by minimising the bracketed part of the denominator in the above equation. It is an elementary mathematical result that ![x+x^{-1}](//upload.wikimedia.org/math/7/1/c/71c5147736074b132bc00d9570d708f7.png) is at a minimum when _x=1_. In this case, it is equal to 2. Therefore, the above expression is minimum under the following condition:

    

    ![\\frac{\\sqrt{R_s}}{\\sqrt{R_L}}=1](//upload.wikimedia.org/math/c/2/2/c22c14e4fd543d0ad83fb0e29beea68c.png)

This leads to the condition that:

    

    

![R_L=R_s \\,](//upload.wikimedia.org/math/a/f/4/af4babf82e43c1954bdd765ad1e45ba2.png)

We will get maximum power out of the source if the load resistance is identical to the internal source resistance. This is the **Maximum Power Transfer Theorem**.

### Efficiency

The efficiency, _η_ of the circuit is the proportion of all the energy dissipated in the circuit that is dissipated in the load. We can immediately see that at maximum power transfer to the load, the efficiency is 0.5, as the source resistor has half the voltage across it. We can also see that efficiency will increase as the load resistance increases, even though the power transferred will fall.

The efficiency can be calculated using the following equation:

    

    ![\\eta=\\frac{P_L}{P_L+P_s}](//upload.wikimedia.org/math/a/2/0/a20f97846d621b591c6934abad730375.png)

where _Ps_ is the power in the source resistor. This can be found using a simple modification to the equation for _PL_:

    

    ![P_s=\\frac{v^2_s}{ R_L \\left\(\\frac{\\sqrt{R_s}}{\\sqrt{R_L}}+\\frac{\\sqrt{R_L}}{\\sqrt{R_s} }\\right\)^2}](//upload.wikimedia.org/math/0/a/5/0a57de411f1983b37ac3d84cb53647ba.png)

The graph below shows the power in the load (as a proportion of the maximum power, _Pmax_) and the efficiency for values of _RL_ between 0 and 5 times _Rs_.

![Maximum Power Transfer Graph.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Maximum_Power_Transfer_Graph.svg/350px-Maximum_Power_Transfer_Graph.svg.png)

It is important to note that under conditions of maximum power transfer as much power is dissipated in the source as in the load. This is not a desirable condition if, for example, the source is the electricity supply system and the load is your electric heater. This would mean that the electricity supply company would be wasting half the power it generates. In this case, the generators, power lines, etc. are designed to give the lowest source resistance possible, giving high efficiency. The maximum power transfer condition is used in (usually high-frequency) communications systems where the source resistance can not be made low, the power levels are relatively low and it is paramount to get as much signal power as possible to the receiving end of the system (the load).  


# Resistive Circuit Analysis Methods

**[Circuit Theory](/wiki/Circuit_Theory)**

## Analysis Methods

When circuits get large and complicated, it is useful to have various methods for simplifying and analyzing the circuit. There is no perfect formula for solving a circuit. Depending on the type of circuit, there are different methods that can be employed to solve the circuit. Some methods might not work, and some methods may be very difficult in terms of long math problems. Two of the most important methods for solving circuits are **Nodal Analysis**, and **Mesh Current Analysis**. These will be explained below.

## Superposition

One of the most important principals in the field of circuit analysis is the principal of **superposition**. It is valid only in linear circuits.

_The **superposition principle** states that the total effect of multiple contributing sources on a linear circuit is equal to the sum of the individual effects of the sources, taken one at a time._

What does this mean? In plain English, it means that if we have a circuit with multiple sources, we can "turn off" all but one source at a time, and then investigate the circuit with only one source active at a time. We do this with every source, in turn, and then add together the effects of each source to get the total effect. Before we put this principle to use, we must be aware of the underlying mathematics.

### Necessary Conditions

Superposition can only be applied to **linear** circuits; that is, all of a circuit's sources hold a linear relationship with the circuit's responses. Using only a few algebraic rules, we can build a mathematical understanding of superposition. If _f_ is taken to be the response, and _a_ and _b_ are constant, then:

    ![f\(ax_1+bx_2\)= f\(ax_1\) + f\(bx_2\) \\,](//upload.wikimedia.org/math/4/5/c/45ce5de99b93136814be7e31cb69cf17.png)

In terms of a circuit, it clearly explains the concept of superposition; each input can be considered individually and then summed to obtain the output. With just a few more algebraic properties, we can see that superposition cannot be applied to non-linear circuits. In this example, the response _y_ is equal to the square of the input x, i.e. y=x2. If _a_ and _b_ are constant, then:

    ![y=\(ax_1+bx_2\)^2 \\ne \(ax_1\)^2 + \(bx_2\)^2 = y_1+y_2\\,](//upload.wikimedia.org/math/e/8/9/e895aabbb571c88958895d1f3045dfff.png)

Note that this is only one of an infinite number of counter-examples...

### Step by Step

Using superposition to find a given output can be broken down into four steps:

  1. Isolate a source - Select a source, and set all of the remaining sources to zero. The consequences of "turning off" these sources are explained in [Open and Closed Circuits](/wiki/Circuit_Theory/Circuit_Basics#Open_and_Closed_Circuits). In summary, turning off a voltage source results in a short circuit, and turning off a current source results in an open circuit. (Reasoning - no current can flow through a open circuit and there can be no voltage drop across a short circuit.)
  2. Find the output from the isolated source - Once a source has been isolated, the response from the source in question can be found using any of the techniques we've learned thus far.
  3. Repeat steps 1 and 2 for each source - Continue to choose a source, set the remaining sources to zero, and find the response. Repeat this procedure until every source has been accounted for.
  4. Sum the Outputs - Once the output due to each source has been found, add them together to find the total response.

## Impulse Response

An **impulse response** of a circuit can be used to determine the output of the circuit:

![System Block.svg](//upload.wikimedia.org/wikibooks/en/thumb/8/88/System_Block.svg/400px-System_Block.svg.png)

The output y is the **convolution** h * x of the input x and the impulse response:

  


[Convolution]

    ![y\(t\) = \(h*x\)\(t\) = \\int_{-\\infty}^{+\\infty} h\(t-s\)x\(s\)ds](//upload.wikimedia.org/math/b/0/7/b070e715c8ea9e673873bd7c136f7028.png).

If the input, x(t), was an **impulse** (![\\delta\(t\)](//upload.wikimedia.org/math/e/e/1/ee1e78bea7f1ee978c7bb1de848f9354.png)), the output y(t) would be equal to h(t).

By knowing the impulse response of a circuit, any source can be plugged-in to the circuit, and the output can be calculated by convolution.

## Convolution

The **convolution operation** is a very difficult, involved operation that combines two equations into a single resulting equation. Convolution is defined in terms of a definite integral, and as such, solving convolution equations will require knowledge of integral calculus. This wikibook will not require a prior knowledge of integral calculus, and therefore will not go into more depth on this subject then a simple definition, and some light explanation.

### Definition

The convolution a * b of two functions a and b is defined as:

    ![\(a * b\)\(t\) = \\int_{-\\infty}^\\infty a\(\\tau\)b\(t - \\tau\)d\\tau](//upload.wikimedia.org/math/4/4/c/44c15554e0a2a43f610d93211718889f.png)

Remember:  
Asterisks mean **convolution**, not **multiplication**

The asterisk operator is used to denote convolution. Many computer systems, and people who frequently write mathematics on a computer will often use an asterisk to denote simple multiplication (the asterisk is the multiplication operator in many programming languages), however an important distinction must be made here: **The asterisk operator means convolution.**

### Properties

Convolution is commutative, in the sense that ![a * b = b * a](//upload.wikimedia.org/math/9/0/2/902a962f5557bc5457af366545b326a1.png). Convolution is also _distributive_ over addition, i.e. ![a * \(b + c\) = a * b + a * c](//upload.wikimedia.org/math/8/f/2/8f270716deac8d46117ae5eabfb98db8.png), and _associative_, i.e. ![a * \(b * c\) = \(a * b\) * c](//upload.wikimedia.org/math/9/1/2/912b7beb45e5a845aca201833297dea4.png).

### Systems, and convolution

Let us say that we have the following block-diagram system:

![System Block.svg](//upload.wikimedia.org/wikibooks/en/thumb/8/88/System_Block.svg/400px-System_Block.svg.png)

  * _x(t)_ = **system input**
  * _h(t)_ = **impulse response**
  * _y(t)_ = **system output**

Where x(t) is the input to the circuit, h(t) is the circuit's impulse response, and y(t) is the output. Here, we can find the output by convoluting the impulse response with the input to the circuit. Hence we see that the impulse response of a circuit is not just the ratio of the output over the input. In the frequency domain however, component in the output with frequency ω is the product of the input component with the same frequency and the transition function at that frequency. The moral of the story is this: _the output to a circuit is the input convolved with the impulse response._

  


Capacitors and Inductors

Resistors, wires, and sources are not the only passive circuit elements. Capacitors and Inductors are also common, passive elements that can be used to store and release electrical energy in a circuit. We will use the analysis methods that we learned previously to make sense of these complicated circuit elements.

  


# Energy Storage Elements

[Circuit Theory/Energy Storage Elements](/w/index.php?title=Circuit_Theory/Energy_Storage_Elements&action=edit&redlink=1)  


# First-Order Circuits

**[Circuit Theory](/wiki/Circuit_Theory)**

## First Order Circuits

First order circuits are circuits that contain only one energy storage element (capacitor or inductor), and that can therefore be described using only a first order differential equation. The two possible types of first-order circuits are:

  1. RC (resistor and capacitor)
  2. RL (resistor and inductor)

RL and RC circuits is a term we will be using to describe a circuit that has either a) resistors and inductors (RL), or b) resistors and capacitors (RC).

## RL Circuits

![](//upload.wikimedia.org/wikipedia/commons/4/41/Parallel-RL.png)

An RL parallel circuit

An RL Circuit has at least one resistor (R) and one inductor (L). These can be arranged in parallel, or in series. Inductors are best solved by considering the current flowing through the inductor. Therefore, we will combine the resistive element and the source into a Norton Source Circuit. The Inductor then, will be the external load to the circuit. We remember the equation for the inductor:

    ![v\(t\) = L\\frac{di}{dt}](//upload.wikimedia.org/math/3/8/b/38bfdc9078590b7450df0eee6e4b0910.png)

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[RL circuit**_](//en.wikipedia.org/wiki/RL_circuit)

If we apply KCL on the node that forms the positive terminal of the voltage source, we can solve to get the following differential equation:

    ![i_{source}\(t\) = \\frac{L}{R_n}\\frac{di_{inductor}\(t\)}{dt} + i_{inductor}\(t\)](//upload.wikimedia.org/math/9/c/d/9cd9b941e2712bb52e72dcd276ef6edf.png)

We will show how to solve differential equations in a later chapter.

## RC Circuits

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[RC circuit**_](//en.wikipedia.org/wiki/RC_circuit)

![](//upload.wikimedia.org/wikipedia/commons/5/55/Parallel-RC.png)

A parallel RC Circuit

An RC circuit is a circuit that has both a resistor (R) and a capacitor (C). Like the RL Circuit, we will combine the resistor and the source on one side of the circuit, and combine them into a thevenin source. Then if we apply KVL around the resulting loop, we get the following equation:

    ![v_{source} = RC\\frac{dv_{capacitor}\(t\)}{dt} + v_{capacitor}\(t\)](//upload.wikimedia.org/math/8/b/5/8b59e7cab8de3c7a1e2deedf26b143a2.png)

  


  


## First Order Solution

### Series RL

The differential equation of the series RL circuit

    ![L \\frac{dI}{dt} + I R = 0](//upload.wikimedia.org/math/d/c/7/dc73cfe56d287a3e41653f406eea0660.png)
    ![\\frac{dI}{dt}  = - I \\frac{R}{L}](//upload.wikimedia.org/math/c/7/7/c77219e9603c4e2503daa66ff63372a7.png)
    ![\\frac{1}{I} dI = - \\frac{R}{L} dt](//upload.wikimedia.org/math/6/5/1/651fbb8e411ca9ddcfd0b1254504cd3f.png)
    ![\\int \\frac{1}{I} dI = - \\frac{R}{L} \\int dt](//upload.wikimedia.org/math/1/d/c/1dc807c05d7488b6bf4e28b6322a3cec.png)
    ![ln I = - \\frac{R}{L} t + C](//upload.wikimedia.org/math/b/a/9/ba92ec094291c7a7cdc5f80fd5dccace.png)
    ![I = e^\(- \\frac{R}{L} t + C \)](//upload.wikimedia.org/math/8/1/0/810e10b15b140d344173968b1f870d8e.png)
    ![I = A e^\(- \\frac{R}{L} t \)](//upload.wikimedia.org/math/a/7/9/a793ec223b2491cde169c992591939d1.png) . A = eC

t I(t)

0
A

1 ![\\frac{R}{L}](//upload.wikimedia.org/math/a/4/b/a4b1c8e307b09e34ad6760eed152a847.png)
36% A

2 ![\\frac{R}{L}](//upload.wikimedia.org/math/a/4/b/a4b1c8e307b09e34ad6760eed152a847.png)
A

3 ![\\frac{R}{L}](//upload.wikimedia.org/math/a/4/b/a4b1c8e307b09e34ad6760eed152a847.png)
A

4 ![\\frac{R}{L}](//upload.wikimedia.org/math/a/4/b/a4b1c8e307b09e34ad6760eed152a847.png)
A

5 ![\\frac{R}{L}](//upload.wikimedia.org/math/a/4/b/a4b1c8e307b09e34ad6760eed152a847.png)
1% A

### Series RC

The differential equation of the series RC circuit

    ![C \\frac{dV}{dt} + \\frac{V}{R} = 0](//upload.wikimedia.org/math/1/f/2/1f2f8176612bfd686426909a7492ca5d.png)
    ![\\frac{dV}{dt}  = - V \\frac{1}{RC}](//upload.wikimedia.org/math/b/0/e/b0ef44e1fb54c48bb64dead1daefa422.png)
    ![\\frac{1}{V} dV = - \\frac{1}{RC} dt](//upload.wikimedia.org/math/7/4/9/7495552edb4888fa252ee761bd0839a5.png)
    ![\\int \\frac{1}{V} dV = - \\frac{1}{RC} \\int dt](//upload.wikimedia.org/math/c/e/8/ce89a8d1ce10fd673c8218b4529f65c7.png)
    ![ln V = - \\frac{1}{RC} t + C](//upload.wikimedia.org/math/7/4/5/745e66aac2ec386b5474fb4806020e5c.png)
    ![V = e^\(- \\frac{1}{RC} t + C \)](//upload.wikimedia.org/math/c/a/1/ca19f2050aa07261c9b6667df8844a93.png)
    ![V = A e^\(- \\frac{1}{RC} t \)](//upload.wikimedia.org/math/b/6/0/b60ade5bc408c16e70225f1b6b5675fb.png) . A = eC

  


t V(t)

0
A

1 ![\\frac{1}{RC}](//upload.wikimedia.org/math/c/3/c/c3c34a2d37e59f51102debf04b9677fb.png)
36% A

2 ![\\frac{1}{RC}](//upload.wikimedia.org/math/c/3/c/c3c34a2d37e59f51102debf04b9677fb.png)
A

3 ![\\frac{1}{RC}](//upload.wikimedia.org/math/c/3/c/c3c34a2d37e59f51102debf04b9677fb.png)
A

4 ![\\frac{1}{RC}](//upload.wikimedia.org/math/c/3/c/c3c34a2d37e59f51102debf04b9677fb.png)
A

5 ![\\frac{1}{RC}](//upload.wikimedia.org/math/c/3/c/c3c34a2d37e59f51102debf04b9677fb.png)
1% A

  


### Time Constant

The series RL and RC has a Time Constant

    ![T = \\frac{L}{R}](//upload.wikimedia.org/math/7/8/8/788d1ed3df1d63d2ca78562ecf3483b2.png)
    ![T = \\frac{RC}{1}](//upload.wikimedia.org/math/7/8/8/7884b7d3ddcaac9b8da3b09070625f8a.png)

In general, from an engineering standpoint, we say that the system is at steady state ( Voltage or Current is almost at Ground Level ) after a time period of five Time Constants.  


# RLC Circuits

**[Circuit Theory](/wiki/Circuit_Theory)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[RLC Circuit**_](//en.wikipedia.org/wiki/RLC_Circuit)

  


## Series RLC Circuit

![RLC series circuit.png](//upload.wikimedia.org/wikipedia/commons/4/4e/RLC_series_circuit.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

### Second Order Differential Equation

    ![L \\frac{dI}{dt} + I R + \\frac{1}{C} \\int I dt = V](//upload.wikimedia.org/math/d/8/5/d85d825b8310897ef2b5314c6ad83e2c.png)
    ![\\frac{d^2I}{dt^2} + \\frac{R}{L} \\frac{dI}{dt} + \\frac{I}{LC}  = 0](//upload.wikimedia.org/math/f/1/f/f1f8104ca4888c476b32024fa70dd35a.png)

The characteristic equation is

    ![s^2 + \\frac{R}{L}s + \\frac{1}{LC}   = 0](//upload.wikimedia.org/math/f/8/1/f815c0690a40972b812399253d87d7a9.png)
    ![s = -\\alpha \\pm \\sqrt{\\alpha^2 - \\beta^2}](//upload.wikimedia.org/math/b/c/e/bcedfaff93b96629c76ea88d3b534621.png)

  
Where

    ![\\alpha = \\frac{R}{2L}](//upload.wikimedia.org/math/6/8/6/686bae93e5b4306daf283ced74fdbe10.png)
    ![\\beta = \\frac{1}\\sqrt{LC}](//upload.wikimedia.org/math/2/9/1/29115dfad4192c5758fd8a2fd2f8ab64.png)

  


  
When ![\\sqrt{\\alpha^2 - \\beta^2} = 0](//upload.wikimedia.org/math/2/1/e/21e1ac04303daf302c8a89423fe09053.png)

    ![ \\alpha^2 = \\beta^2 ; R = 2 \\sqrt{\\frac{L}{C}}](//upload.wikimedia.org/math/6/9/d/69d016ddeb8ed4a68b9bee716f420038.png)
    The equation only has one real root . ![s = -\\alpha = - \\frac{R}{2L}](//upload.wikimedia.org/math/8/b/8/8b832ebe4651b81c763e557f7b21a399.png)
    The solution for ![I\(t\) = A e^\(-\\frac{R}{2L} t\)](//upload.wikimedia.org/math/a/3/9/a391b453532f642613cede4c532899a6.png)
    The I - t curve would look like

  


When ![\\sqrt{\\alpha^2 - \\beta^2} > 0](//upload.wikimedia.org/math/4/0/f/40f1f829cfceb9fc6fd6a1b521f7cd98.png)

    ![\\alpha^2 > \\beta^2](//upload.wikimedia.org/math/3/4/1/34105d345fbf5cfeebf09a5141e1ab89.png) . R > ![\\frac{L}{C}](//upload.wikimedia.org/math/f/7/3/f73a197079a457b59d54436e0cfbe3a7.png)
    The equation only has two real root . ![s = -\\alpha ](//upload.wikimedia.org/math/b/1/9/b193e54c0e168322ccacc6ad4fc1ddf0.png) ± ![\\sqrt{\\alpha^2 - \\beta^2}](//upload.wikimedia.org/math/3/b/5/3b5e395680b60f829571e9e321be3c83.png)
    The solution for ![I\(t\) = e^{- \\alpha + \\sqrt{\\alpha^2 - \\beta^2} t} + e^{- \\alpha - \\sqrt{\\alpha^2 - \\beta^2} t} = e^{-\\alpha} e^{j\(\\sqrt{\\alpha^2 - \\beta^2}\)} + e^{-j\(\\sqrt{\\alpha^2 - \\beta^2}\)}](//upload.wikimedia.org/math/7/0/f/70f727c6fbe8cd9fd71bb9ebede9eafb.png)
    The I - t curve would look like

  


When ![\\sqrt{\\alpha^2 - \\beta^2} < 0](//upload.wikimedia.org/math/8/c/5/8c59442fcbee600c631ad93c16bb1f10.png)

    ![\\alpha^2 < \\beta^2](//upload.wikimedia.org/math/3/f/d/3fd54106c2820d611a3d638c46c92c48.png) . R < ![\\frac{L}{C}](//upload.wikimedia.org/math/f/7/3/f73a197079a457b59d54436e0cfbe3a7.png)
    The equation has two complex root . ![s = -\\alpha ](//upload.wikimedia.org/math/b/1/9/b193e54c0e168322ccacc6ad4fc1ddf0.png) ± j![\\sqrt{\\beta^2 - \\alpha^2}](//upload.wikimedia.org/math/e/e/d/eedb28a48798aada17d1f75ff8876678.png)
    The solution for ![I\(t\) = e^{\(- \\alpha + \\sqrt{\\beta^2 - \\alpha^2} t\)} + e^{\(- \\alpha - \\sqrt{\\beta^2 - \\alpha^2} t\)} = e^{-\\alpha}  e^{j\(\\sqrt{\\beta^2 - \\alpha^2}\)} + e^{-j\(\\sqrt{\\beta^2 - \\alpha^2}\)}](//upload.wikimedia.org/math/2/c/a/2caeb95950152025f7053bf52d47c1b8.png)
    The I - t curve would look like

### Damping Factor

The damping factor is the amount by which the oscillations of a circuit gradually decrease over time. We define the damping ratio to be:

Circuit Type Series RLC Parallel RLC

Damping Factor
![\\zeta = {R \\over 2L}](//upload.wikimedia.org/math/9/1/b/91b16a769d834e797bca1393522c2f19.png)
![\\zeta = {1 \\over 2RC}](//upload.wikimedia.org/math/5/3/9/53950df02147518a42395262ba32e58c.png)

Resonance Frequency
![\\omega_o = {1 \\over \\sqrt{L C}}](//upload.wikimedia.org/math/0/d/7/0d7e953a0a1180b327557bf424c7c89a.png)
![\\omega_o = {1 \\over \\sqrt{L C}}](//upload.wikimedia.org/math/0/d/7/0d7e953a0a1180b327557bf424c7c89a.png)

Compare The Damping factor with The Resonance Frequency give rise to different types of circuits: **Overdamped**, **Underdamped**, and **Critically Damped**.

### Bandwidth

  


[Bandwidth]

    ![ \\Delta \\omega  =  2 \\zeta ](//upload.wikimedia.org/math/c/a/2/ca2f258a26adf48739954a3f09ed8e17.png)

For series RLC circuit:

    ![ \\Delta \\omega  =  2 \\zeta   = { R \\over L}](//upload.wikimedia.org/math/9/d/e/9de7d764f65b729c98f8a20ac15d4752.png)

For Parallel RLC circuit:

    ![ \\Delta \\omega  =  2 \\zeta   = { 1 \\over RC}](//upload.wikimedia.org/math/e/6/6/e66cb37e2a33f4a7f40bd6768697f36d.png)

### Quality Factor

  


[Quality Factor]

    ![Q =   {\\omega_o \\over \\Delta \\omega } = {\\omega_o \\over 2\\zeta }](//upload.wikimedia.org/math/3/e/4/3e4e29caffbb0112734d74c9aed28a98.png)

For Series RLC circuit:

    ![Q =   {\\omega_o \\over \\Delta \\omega } = {\\omega_o \\over 2\\zeta } = {L \\over R \\sqrt{LC}} = {1 \\over R} \\sqrt{L \\over C}](//upload.wikimedia.org/math/7/9/7/7974d81f2125630e4afbcbb34cd79c30.png)

For Parallel RLC circuit:

    ![Q =   {\\omega_o \\over \\Delta \\omega } = {\\omega_o \\over 2\\zeta } = {RC \\over \\sqrt{LC}} = {R} \\sqrt{C \\over L}](//upload.wikimedia.org/math/f/4/0/f4076b29d3a5d5fa4de7a6558280450d.png)

### Stability

Because inductors and capacitors act differently to different inputs, there is some potential for the circuit response to approach infinity when subjected to certain types and amplitudes of inputs. When the output of a circuit approaches infinity, the circuit is said to be **unstable**. Unstable circuits can actually be dangerous, as unstable elements overheat, and potentially rupture.

A circuit is considered to be stable when a "well-behaved" input produces a "well-behaved" output response. We use the term "Well-Behaved" differently for each application, but generally, we mean "Well-Behaved" to mean a finite and controllable quantity.

## Resonance

### With R = 0

When R = 0 , the circuit reduces to a series LC circuit. When the circuit is in resonance, the circuit will vibrate at the resonant frequency.

    ![Z_L = Z_C](//upload.wikimedia.org/math/d/a/c/dacc1021f09a384a8541cf80858308bf.png)
    ![\\omega L = \\frac{1}{\\omega C}](//upload.wikimedia.org/math/9/9/e/99e7603b5bca20703605071136a30a61.png)
    ![\\omega = \\frac{1}{\\sqrt{LC}}](//upload.wikimedia.org/math/7/3/7/73780e68fccae5851127406775e49453.png)
    ![f = \\frac{1}{2\\pi} \\frac{1}{\\sqrt{LC}}](//upload.wikimedia.org/math/7/f/5/7f535d8c3eb46384e82dad655bee6ab1.png)

_The circuit vibrates and has the capability of producing a Standing Wave when R = 0 , L = C_

### With R ≠ 0

When R ≠ 0 and the circuit operates in resonance .

    The frequency dependent components L , C cancel out ie ZL \- ZC = 0 so that the total impedance of the circuit is ![Z_R + Z_L + Z_C = R + \[ Z_L - Z_C \] = R + 0 = R](//upload.wikimedia.org/math/b/b/e/bbe472f430e92eb7ff36d29fa6308875.png)
    The current of the circuit is ![I = \\frac{V}{R}](//upload.wikimedia.org/math/f/9/a/f9ae53a99f2b2b6a74146fb04fb3ff73.png)
    The Operating Frequency is ![\\omega = \\frac{1}{\\sqrt{LC}}](//upload.wikimedia.org/math/7/3/7/73780e68fccae5851127406775e49453.png)

If the current is halved by doubling the value of resistance then

    ![I = \\frac{V}{2R}](//upload.wikimedia.org/math/f/9/6/f9600582bf0b2f0c305abee93091d53b.png)
    Circuit will be stable over the range of frquencies from ![\\omega_1 - \\omega_2](//upload.wikimedia.org/math/8/c/f/8cf25f1962f4625200a0cc2b9af806a7.png)

_The circuit has the capability to select bandwidth where the circuit is stable_ . Therefore, it is best suited for Tuned Resonance Select Bandwidth Filter

Once using L or C to tune circuit into resonance at resonance frequency ![f = \\frac{1}{2\\pi} \\frac{1}{\\sqrt{LC}}](//upload.wikimedia.org/math/7/f/5/7f535d8c3eb46384e82dad655bee6ab1.png) _The current is at its maximum value ![I = \\frac{V}{R}](//upload.wikimedia.org/math/f/9/a/f9ae53a99f2b2b6a74146fb04fb3ff73.png) . Reduce current above ![I = \\frac{V}{2R}](//upload.wikimedia.org/math/f/9/6/f9600582bf0b2f0c305abee93091d53b.png) circuit will respond to narrower bandwidth than ![\\omega_1 - \\omega_2](//upload.wikimedia.org/math/8/c/f/8cf25f1962f4625200a0cc2b9af806a7.png). Reduce current below ![I = \\frac{V}{2R}](//upload.wikimedia.org/math/f/9/6/f9600582bf0b2f0c305abee93091d53b.png) circuit will respond to wider bandwidth than ![\\omega_1 - \\omega_2](//upload.wikimedia.org/math/8/c/f/8cf25f1962f4625200a0cc2b9af806a7.png)._

## Conclusion

Circuit General Series RLC Parallel RLC

Circuit

![RLC series circuit.png](//upload.wikimedia.org/wikipedia/commons/thumb/4/4e/RLC_series_circuit.png/100px-RLC_series_circuit.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

![RLC parallel circuit.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/RLC_parallel_circuit.png/200px-RLC_parallel_circuit.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Impedance
Z
![Z = \(j\\omega\)^2  + \(j\\omega\)\\frac{R}{L} + \\frac{1}{LC}](//upload.wikimedia.org/math/a/7/1/a71dddbf728182ede83d0fbeb56c5aae.png)
![Z = \\frac{1}{RLC} \\frac{1}{\(j\\omega\)^2 + j\\omega\\frac{1}{RC} + \\frac{1}{LC}}](//upload.wikimedia.org/math/f/1/0/f105ea303a6be7d95bb2f3f2ca545a2c.png)

Roots
λ
λ = ![ - \\zeta \\pm \\sqrt{\\zeta^2 - \\omega_o^2} ](//upload.wikimedia.org/math/f/4/c/f4cdd16d972638bc881375fa58626ba4.png)
λ = ![ - \\zeta \\pm \\sqrt{\\zeta^2 - \\omega_o^2} ](//upload.wikimedia.org/math/f/4/c/f4cdd16d972638bc881375fa58626ba4.png)

I(t)
Aeλ1t \+ Beλ2t
Aeλ1t \+ Beλ2t
Aeλ1t \+ Beλ2t

Damping Factor
![\\zeta](//upload.wikimedia.org/math/3/2/0/320c43589fbcdde1af041ee358550ac5.png)
![\\zeta = {R \\over 2L}](//upload.wikimedia.org/math/9/1/b/91b16a769d834e797bca1393522c2f19.png)
![\\zeta = {1 \\over 2RC}](//upload.wikimedia.org/math/5/3/9/53950df02147518a42395262ba32e58c.png)

Resonant Frequency
![\\omega_o](//upload.wikimedia.org/math/4/2/d/42d378264da9d82a0b2be919b2420a45.png)
![\\omega_o = {1 \\over \\sqrt{L C}}](//upload.wikimedia.org/math/0/d/7/0d7e953a0a1180b327557bf424c7c89a.png)
![\\omega_o = {1 \\over \\sqrt{L C}}](//upload.wikimedia.org/math/0/d/7/0d7e953a0a1180b327557bf424c7c89a.png)

Band Width
![ \\Delta \\omega  =  2 \\zeta ](//upload.wikimedia.org/math/c/a/2/ca2f258a26adf48739954a3f09ed8e17.png)
![ { R \\over L}](//upload.wikimedia.org/math/d/7/8/d786ad5ec692f9fa86a0ee32573d2b14.png)
![ { 1 \\over CR}](//upload.wikimedia.org/math/b/e/f/bef464b4bd6532757bd5d7ea80665d11.png)

Quality factor
![Q =   {\\omega_o \\over \\Delta \\omega } = {\\omega_o \\over 2\\zeta }](//upload.wikimedia.org/math/3/e/4/3e4e29caffbb0112734d74c9aed28a98.png)
![Q =  {L \\over R \\sqrt{LC}} = {1 \\over R} \\sqrt{L \\over C}](//upload.wikimedia.org/math/c/5/a/c5acccba935faab09c660d8b25ea43e1.png)
![Q = {CR \\over  \\sqrt{LC}} = {R} \\sqrt{C \\over L}](//upload.wikimedia.org/math/e/c/1/ec10cbb15ecc5a27d35d717311d69cfa.png)

  


# The Second-Order Circuit Solution

**[Circuit Theory](/wiki/Circuit_Theory)**

== Second-Order Solution

This page is going to talk about the solutions to a second-order, RLC circuit. The second-order solution is reasonably complicated, and a complete understanding of it will require an understanding of differential equations. This book will not require you to know about differential equations, so we will describe the solutions without showing how to derive them. The derivations may be put into another chapter, eventually.

The aim of this chapter is to develop the **complete response** of the second-order circuit. There are a number of steps involved in determining the complete response:

  1. Obtain the differential equations of the circuit
  2. Determine the resonant frequency and the damping ratio
  3. Obtain the characteristic equations of the circuit
  4. Find the roots of the characteristic equation
  5. Find the natural response
  6. Find the forced response
  7. Find the complete response

We will discuss all these steps one at a time.

## Finding Differential Equations

A **Second-order circuit** cannot possibly be solved until we obtain the second-order differential equation that describes the circuit. We will discuss here some of the techniques used for obtaining the second-order differential equation for an RLC Circuit.

Note
    Parallel RLC Circuits are easier to solve in terms of current. Series RLC circuits are easier to solve in terms of voltage.

### The Direct Method

The most direct method for finding the differential equations of a circuit is to perform a nodal analysis, or a mesh current analysis on the circuit, and then solve the equation for the input function. The final equation should contain only derivatives, no integrals.

### The Variable Method

If we create two variables, g and h, we can use them to create a second-order differential equation. First, we set g and h to be either inductor currents, capacitor voltages, or both. Next, we create a single first order differential equation that has g = f(g, h). Then, we write another first-order differential equation that has the form:

    ![\\frac{dh}{dt} = Kg](//upload.wikimedia.org/math/d/8/e/d8ee327e6ccd5e6233106bbb22141b94.png) or ![ \\frac{1}{K}\\frac{dh}{dt} = g](//upload.wikimedia.org/math/d/f/5/df5fce16a94bcfab92436a011574ce74.png)

Next, we substitute in our second equation into our first equation, and we have a second-order equation.

## Zero-Input Response

The **zero-input** response of a circuit is the state of the circuit when there is no forcing function (no current input, and no voltage input). We can set the differential equation as such:

    ![
{{d^2 i} \\over {dt^2}} + 2 \\zeta {{di} \\over {dt}} + \\omega_o^2  i\(t\) = 0
](//upload.wikimedia.org/math/0/8/b/08bd6c65628e2eafb94fc569fe6c7d40.png)

This gives rise to the characteristic equation of the circuit, which is explained below.

## Characteristic Equation

The characteristic equation of an RLC circuit is obtained using the "Operator Method" described below, with zero input. The characteristic equation of an RLC circuit (series or parallel) will be:

    ![s^2i + {R \\over L} si + {1 \\over {LC}} i = 0](//upload.wikimedia.org/math/3/a/4/3a4535a7b815c130a2c3d210f3834b82.png)

The roots to the characteristic equation are the "solutions" that we are looking for.

### Finding the Characteristic Equation

This method of obtaining the characteristic equation requires a little trickery. First, we create an operator s such that:

    ![sx = \\frac{dx}{dt}](//upload.wikimedia.org/math/9/b/8/9b8b5a4bd4e57be7e445d80e0f4b6003.png)

Also, we can show higher-order operators as such:

    ![s^2x = \\frac{d^2x}{dt^2}](//upload.wikimedia.org/math/d/0/0/d00e5bf67cae5bdf8a2869c4dbe02416.png)

Where x is the voltage (in a series circuit) or the current (in a parallel circuit) of the circuit source. We write 2 first order differential equations for the inductor currents and/or the capacitor voltages in our circuit. We convert all the differentiations to s, and all the integrations (if any) into (1/s). We can then use Cramer's rule to solve for a solution.

### Solutions

The solutions of the characteristic equation are given in terms of the resonant frequency and the damping ratio:

  


[Characteristic Equation Solution]

    ![ s = - \\zeta \\pm \\sqrt{\\zeta^2 - \\omega_o^2} ](//upload.wikimedia.org/math/5/6/a/56aaa5f9241660503b1e249f33f1f7fd.png)

If _either_ of these two values are used for _s_ in the assumed solution ![x = Ae^{st}](//upload.wikimedia.org/math/a/c/e/ace7995ff3a1b1a7881297860059e5ff.png) and that solution completes the differential equation then it can be considered a valid solution. We will discuss this more, below.

## Damping

The solutions to a circuit are dependant on the type of **damping** that the circuit exhibits, as determined by the relationship between the damping ratio and the resonant frequency. The different types of damping are Overdamping, Underdamping, and Critical Damping.

### Overdamped

![](//upload.wikimedia.org/wikipedia/commons/d/dc/RLC-serial-Over_Damping.PNG)

RLC series Over-Damped Response

A circuit is called **Overdamped** when the following condition is true:

  


    ![\\alpha > \\omega_0](//upload.wikimedia.org/math/c/c/0/cc0ddbc2194b78efa70fd58cfdce9bbd.png)

  
In this case, the solutions to the characteristic equation are two distinct, positive numbers, and are given by the equation:

    ![I\(t\)=A e^{\\ s_1 t} + B e^{\\ s_2 t}](//upload.wikimedia.org/math/0/4/9/04956294ca0387688f7653ff248fc9a8.png), where
    ![ s_1,s_2 = - \\alpha \\pm \\sqrt{\\alpha^2 - \\omega_0^2}](//upload.wikimedia.org/math/f/3/e/f3e4649b94f495bb5e156aa7644884e8.png)

In a parallel circuit:

    ![\\alpha = 1/\(2RC\)](//upload.wikimedia.org/math/c/6/f/c6f77253e0c67153f4f73f43d0177696.png)
    ![\\omega_0 = 1 / sqrt\(LC\)](//upload.wikimedia.org/math/5/d/1/5d125fe58cc530005f3ff0769a38bd3c.png)

In a series circuit:

    ![\\alpha = R/\(2L\)](//upload.wikimedia.org/math/7/6/5/765c2a685e3a9e1c45e00a49701b35d4.png)
    ![\\omega_0 = 1 / sqrt\(LC\)](//upload.wikimedia.org/math/5/d/1/5d125fe58cc530005f3ff0769a38bd3c.png)

Overdamped circuits are characterized as having a very large settling time, and possibly a large steady-state error.

  


### Underdamped

A Circuit is called **Underdamped** when the damping ratio is less than the resonant frequency.

    ![\\zeta < \\omega_0](//upload.wikimedia.org/math/7/9/7/79719da98f2c8ca4d76f7b3d346cdd30.png)

In this case, the characteristic polynomial's solutions are complex conjugates. This results in oscillations or _ringing_ in the circuit. The solution consists of two conjugate roots:

    ![\\lambda_1 = -\\zeta + i\\omega_c](//upload.wikimedia.org/math/0/7/e/07ee4fad82cf9be4b4b163d4aa6391c0.png)

and

    ![\\lambda_2 = -\\zeta - i\\omega_c](//upload.wikimedia.org/math/6/9/f/69f875efdc281356f66c4f14c2cb95dc.png)

where

    ![\\omega_c = \\sqrt{\\omega_o^2 - \\zeta^2}](//upload.wikimedia.org/math/4/2/d/42d6bfe1ea5ee9b0ad43536fd7b25d96.png)

The solutions are:

    ![i\(t\) = Ae^{\(-\\zeta + i \\omega_c\)t} + Be^{\(-\\zeta - i \\omega_c\)t} ](//upload.wikimedia.org/math/c/6/c/c6c9ff78db9141545054ed4d9e7311e4.png)

for arbitrary constants _A_ and _B_. Using Euler's formula, we can simplify the solution as:

    

    ![i\(t\)=e^{-\\zeta t} \\left\[ C \\sin\(\\omega_c t\) + D \\cos\(\\omega_c t\) \\right\]](//upload.wikimedia.org/math/d/4/c/d4c4e070eae9989bc30311ddde38fcec.png)

for arbitrary constants _C_ and _D_. These solutions are characterized by _exponentially decaying sinusoidal response_. The higher the **Quality Factor** (below), the longer it takes for the oscillations to decay.

  


### Critically Damped

![](//upload.wikimedia.org/wikipedia/commons/e/e9/RLC-serial-Critical_Damping.PNG)

RLC series Critically Damped

A circuit is called **Critically Damped** if the damping factor is equal to the resonant frequency:

    ![\\zeta=\\omega_0 ](//upload.wikimedia.org/math/7/b/3/7b31df0332900d95c471839e96ba6c19.png)

In this case, the solutions to the characteristic equation is a double root. The two roots are identical (![ \\lambda_1=\\lambda_2=\\lambda ](//upload.wikimedia.org/math/9/9/d/99d0b69dbe95521dd20fc5dd778497b5.png)), the solutions are:

    ![I\(t\)=\(A+Bt\) e^{\\lambda t}](//upload.wikimedia.org/math/a/d/a/ada6e8033b362fbfb7b1d90aa716acf6.png)

for arbitrary constants _A_ and _B_. Critically damped circuits typically have low overshoot, no oscillations, and quick settling time.

  


## Series RLC

![](//upload.wikimedia.org/wikipedia/commons/4/4e/RLC_series_circuit.png)

A series RLC circuit.

The differential equation to a simple series circuit with a constant voltage source V, and a resistor R, a capacitor C, and an inductor L is:

    ![L\\frac{d^2i}{dt^2} + R\\frac{di}{dt} + {1 \\over C}i = 0](//upload.wikimedia.org/math/c/b/d/cbd6a67e2d4e5494ccb38fd645e3edd2.png)

The characteristic equation then, is as follows:

    ![Ls^2 + Rs + {1 \\over C} = 0](//upload.wikimedia.org/math/3/6/c/36c3e41247bb02d8667d5c5704e26711.png)

With the two roots:

    ![s_1 = -{R\\over 2L} + \\sqrt{\({R\\over 2L}\)^2 - {1 \\over LC}}](//upload.wikimedia.org/math/c/2/6/c260e1455a5521d1ab0656df1fe7565c.png)

and

    ![s_2 = -{R\\over 2L} - \\sqrt{\({R\\over 2L}\)^2 - {1 \\over LC}}](//upload.wikimedia.org/math/a/e/5/ae5db5b911a6b744ccd7b67724fdb397.png)

  
  


## Parallel RLC

![](//upload.wikimedia.org/wikibooks/en/5/54/Parallel_RLC.png)

A parallel RLC Circuit.

The differential equation to a parallel RLC circuit with a resistor _R_, a capacitor _C_, and an inductor _L_ is as follows:

    ![C\\frac{d^2v}{dt^2} + \\frac{1}{R}\\frac{dv}{dt} + {1 \\over L}v = 0](//upload.wikimedia.org/math/d/4/3/d43822bedb1426018b1c843b8e2ab42e.png)

Where _v_ is the voltage across the circuit. The characteristic equation then, is as follows:

    ![Cs^2 + {1 \\over R}s + {1 \\over L} = 0](//upload.wikimedia.org/math/8/e/1/8e152b822f46cbecdca1f805f1dfb2f7.png)

With the two roots:

    ![s_1 = -{1\\over 2RC} + \\sqrt{\({1\\over 2RC}\)^2 - {1 \\over LC}}](//upload.wikimedia.org/math/f/7/2/f727037f5e52b205abbf88fd2d58fd47.png)

and

    ![s_2 = -{1\\over 2RC} - \\sqrt{\({1\\over 2RC}\)^2 - {1 \\over LC}}](//upload.wikimedia.org/math/a/7/3/a73ab15a64fd09b5ab1ea48c58cf635b.png)

  
  


## Circuit Response

Once we have our differential equations, and our characteristic equations, we are ready to assemble the mathematical form of our circuit response. RLC Circuits have differential equations in the form:

    ![a_2 \\frac{d^2x}{dt^2} + a_1\\frac{dx}{dt} + a_0 x = f\(t\)](//upload.wikimedia.org/math/d/1/1/d11b8e40965cadd7e88a55949e16dcb4.png)

Where _f(t)_ is the forcing function of the RLC circuit.

### Natural Response

The **natural response** of a circuit is the response of a given circuit to zero input (i.e. depending only upon the initial condition values). The natural Response to a circuit will be denoted as _xn(t)_. The natural response of the system must satisfy the unforced differential equation of the circuit:

  


[Unforced function]

    ![a_2 \\frac{d^2x}{dt^2} + a_1\\frac{dx}{dt} + a_0 x = 0](//upload.wikimedia.org/math/8/f/1/8f1aba8b15a50b4a7d14a2a2605f52db.png)

We remember this equation as being the "zero input response", that we discussed above. We now define the natural response to be an exponential function:

    ![x_n = A_1e^{st} + A_2e^{st}](//upload.wikimedia.org/math/3/2/2/32293bc91fc59728b813707994e67fb2.png)

Where _s_ are the roots of the characteristic equation of the circuit. The reasons for choosing this specific solution for _xn_ is based in differential equations theory, and we will just accept it without proof for the time being. We can solve for the constant values, by using a system of two equations:

    ![x\(0\) = A_1 + A_2](//upload.wikimedia.org/math/1/7/c/17cdecbebf5c2a86e1d10455c13106c2.png)

    ![\\frac{dx\(0\)}{dt} = s_1A_1 + s_2A_2 ](//upload.wikimedia.org/math/5/1/4/5149b4fe2bdde2ca7969b57864485ffd.png)

Where _x_ is the voltage (of the elements in a parallel circuit) or the current (through the elements in a series circuit).

### Forced Response

The **forced response** of a circuit is the way the circuit responds to an input forcing function. The Forced response is denoted as _xf(t)_.

Where the forced response must satisfy the forced differential equation:

  


[Forced function]

    ![a_2 \\frac{d^2x}{dt^2} + a_1\\frac{dx}{dt} + a_0 x = f\(t\)](//upload.wikimedia.org/math/d/1/1/d11b8e40965cadd7e88a55949e16dcb4.png)

The forced response is based on the input function, so we can't give a general solution to it. However, we can provide a set of solutions for different inputs:

Input Form Output Form

_K_ (constant)
_A_ (constant)

![M \\sin\(\\omega t\)](//upload.wikimedia.org/math/4/6/b/46b4f9910197bccd45b49298e67f4d60.png)
![A \\sin\(\\omega t\) + B \\cos \(\\omega t\)](//upload.wikimedia.org/math/9/3/1/9311a2e4b736697cc9a155ade41fb09e.png)

![M e^{-at}](//upload.wikimedia.org/math/3/5/d/35d5215bbf7141923aa7aafe29a6d69a.png)
![A e^{-at}](//upload.wikimedia.org/math/d/c/2/dc20cec205e61a49f2026a525fa801a6.png)

### Complete Response

The **Complete response** of a circuit is the sum of the forced response, and the natural response of the system:

  


[Complete Response]

    ![x_c\(t\) = x_t\(t\) + x_s\(t\)](//upload.wikimedia.org/math/a/1/0/a1068d84df700a67dedcc06a4af2a0c3.png)

Once we have derived the complete response of the circuit, we can say that we have "solved" the circuit, and are finished working.

  
the 2nd order circuit (LC) when there is no R in the circuit we consider a=1/2RC ( if the circuit parallel ) = 0 so the circuit will be in underdame case since a=0 and omega has value greater than zero  


# Mutual Inductance

**[Circuit Theory](/wiki/Circuit_Theory)**

## Magnetic Fields

![Basic Inductor with B-field.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/11/Basic_Inductor_with_B-field.svg/400px-Basic_Inductor_with_B-field.svg.png)

Inductors store energy in the form of a magnetic field. The magnetic field of an inductor actually extends outside of the inductor, and can be affected (or can affect) another inductor close by. The image above shows a magnetic field (red lines) extending around an inductor.

## Mutual Inductance

![Transformer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/26/Transformer.svg/200px-Transformer.svg.png)

If we accidentally or purposefully put two inductors close together, we can actually transfer voltage and current from one inductor to another. This property is called **Mutual Inductance**. A device which utilizes mutual inductance to alter the voltage or current output is called a **transformer**.

The inductor that creates the magnetic field is called the _primary coil_, and the inductor that picks up the magnetic field is called the _secondary coil_. Transformers are designed to have the greatest mutual inductance possible by winding both coils on the same _core_. (In calculations for inductance, we need to know which materials form the path for magnetic flux. _Air core_ coils have low inductance; Cores of iron or other magnetic materials are better 'conductors' of magnetic flux.)

The voltage that appears in the secondary is caused by the _change_ in the shared magnetic field, each time the current through the primary changes. Thus, transformers work on A.C. power, since the voltage and current change continuously.

## Ideal Transformers

![Schaltbild Trafo.png](//upload.wikimedia.org/wikipedia/commons/4/4f/Schaltbild_Trafo.png)

## Modern Inductors

![Single-phase transformer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Single-phase_transformer.svg/300px-Single-phase_transformer.svg.png)

When the coils of number of turns N1 conducts current . There exists a Magnetic Field B on the coil . Changes of B will generates an Induced Voltage on the turns of coil N1 and N2 as shown

    

-ξp = ![N_p \\frac{dB}{dt}](//upload.wikimedia.org/math/6/2/1/621569495ae2781125c06223d2c842c4.png)
-ξs = ![N_s \\frac{dB}{dt}](//upload.wikimedia.org/math/7/8/e/78e4b6e37a28650c78f2f6c4e5173531.png)

The ratio of -ξ2 over -ξ1

    

-ξp / -ξs = ![\\frac{N_p}{N_s}](//upload.wikimedia.org/math/0/a/f/0afd8e350a49cfca01baab5b946d061e.png)

If Input voltage at coil of turn Np = -ξp and the Output voltage will be

    ![\\frac{V_s}{V_p}](//upload.wikimedia.org/math/4/a/9/4a93a3862baf974a10c16ed7e893729d.png) = -ξs / -ξp = ![\\frac{N_s}{N_p}](//upload.wikimedia.org/math/3/d/f/3df78add589024d829412bdf7dd00e16.png)

  


    

![V_s = V_p \\frac{N_s}{N_p}](//upload.wikimedia.org/math/6/b/6/6b613dacc73941c9d3337c0cfa7cf69b.png)

Thus, this device is capable of Increase, Decrease and Conduct Voltage just by changing the turn ratio of the coils

Therefore, the output voltage can be

  * Increased or Step Up by increasing number of turns of coil Ns greater than Np
  * Decreased or Step Down by Decreasing number of turns of coil Ns less than Np
  * Buffered by setting number of turns of coil Ns equal to Np

  
The following photo shows several examples of the construction of inductors and transformers. At the upper right is a toroidal core type (toroid is the mathematical term for a donut shape). This shape very efficiently contains the magnetic flux, so less power (or signal) is lost to heating up the core.

![Transformers.jpg](//upload.wikimedia.org/wikipedia/commons/8/84/Transformers.jpg)

## Step Up and Step Down

The terms 'step-up' and 'step-down' are used to compare the secondary (output) voltage to the voltage supplied to the primary.

Many transformers are specially designed to operate exclusively as step-up or step-down. While an ideal transformer could simply be 'turned around', we find that many actual transformers are built to perform best at certain ranges of voltage and current.

For example, a power transformer may be used to step down household AC (about 120 Volts) to 24V for home heating controls, etc. The output current is higher than the primary current in this example, so the transformer is made with a heavier gauge of wire in its secondary windings.

In transformers that deal with very high voltages, special attention is paid to insulation. The windings that deal with thousands of volts must resist arcing and other problems we do not see at home.

Finally, some transformers in electronic equipment are designed for a task known as 'impedance matching', rather than for specific in/out voltages. This function is explained in literature covering audio and radio topics.

## further reading

  * [Electronics/Transformers](/wiki/Electronics/Transformers)

(This section has not yet been written)

  


# State-Variable Approach

**[Circuit Theory](/wiki/Circuit_Theory)**

New techniques are needed to solve 2nd order and higher circuits:

  * Symbolic solutions are so complicated, merely comparing answers is an exercise
  * Analytical solution techniques are more fragmented
  * The relationship between constants, initial conditions and circuit layout are becoming complicated

A change in strategy is needed if circuit analysis is going to:

  * Move beyond the ideal
  * Consider more complicated circuits
  * Understand limitations/approximations of circuit modeling software

The solution is "State Variables." After a state variable analysis, the exercise of creating symbolic solution can be simplified by eliminating terms that don't have a significant impact on the output.

### State Space

The [State Space](//en.wikipedia.org/wiki/State_space_representation) approach to circuit theory abandons the symbolic/analytical approach to circuit analysis. The state variable model involves describing a circuit in matrix form and then solving it numerically using tools like [series expansions](//en.wikipedia.org/wiki/Series_expansion), [Simpson's rule](//en.wikipedia.org/wiki/Simpson%27s_rule), and [Cramer's Rule](//en.wikipedia.org/wiki/Cramer%27s_rule). This was the original starting point of [matlab](//en.wikipedia.org/wiki/MATLAB).

### State

"State" means "condition" or "status" of the energy storage elements of a circuit. Since resistors don't change (ideally) and don't store energy, they don't change the circuit's state. A state is a snap shot in time of the currents and voltages. The goal of "State Space" analysis is to create a notation that describes all possible states.

### State Variables

The notation used to describe all states should be as simple as possible. Instead of trying to find a complex, high order differential equation, go back to something like [Kirchhoff analysis](/wiki/Circuit_Theory/Simultaneous_Equations/Example_6) and just write terminal equations.

State variables are voltages across capacitors and currents through inductors. This means that purely resistive circuit [cut sets](/wiki/Circuit_Theory/Circuit_Definition/Cut_Sets) are collapsed into single resistors that end up in series with an inductor or parallel to capacitor. Rather than using the symbols v and i to represent these unknowns, they are both called x. Kirchhoff's equations are used instead of node or loop equations. Terminal equations are substituted into the Kirchhoff's equations so that remaining resistor's currents and voltages are shared with inductors and capacitors.

### State Space Model

![Typical State Space Model \(CT\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Typical_State_Space_Model_%28CT%29.svg/450px-Typical_State_Space_Model_%28CT%29.svg.png)

This State Space Model describes the inputs (step function μ(t), initial conditions X(0)), the output Y(t) and A,B,C and D. A-B-C-D are transfer functions that combine as follows:

    ![\\frac{\\mathbb{Y}}{\\mathbb{\\mu}} = B\(s\)\\left\(\\frac{1}{s - A\(s\)}\\right\)C\(s\) + D\(s\)](//upload.wikimedia.org/math/8/f/c/8fca3b348332bd554b783761a6843642.png)

A [control systems](/wiki/Control_Systems/Block_Diagrams#Simplifying_Block_Diagrams) class teaches how to build these block diagrams from a desired transfer function. Integrals "remember" or accumulate a history of past states. Derivatives predict future state and both, in addition to the current state can be separately scaled. "A" represents feedback. "D" represents feed forward. There is lots to learn.

Don't try to figure out how a negative sign appeared in the denominator and where the addition term came from. How does the above help us predict voltages and currents in a circuit? Let's start by defining terms and do some examples:

  * A is a square matrix representing the circuit components (from Kirchhoff's equations.
  * B is a column matrix or vector representing how the source impacts the circuit (from Kirchhoff's equations).
  * C is a row matrix or vector representing how the output is computed (could be voltage or current)
  * D is a single number that indicates a multiplier of the source .. is usually zero unless the source is directly connected to the output through a resistor.

A and B describe the circuit in general. If X is a column matrix (vector) representing all unknown voltages and currents, then:

    ![\\boldsymbol{\\dot{X}} = \\boldsymbol{A}\\boldsymbol{X} + \\boldsymbol{B}\\boldsymbol{\\mu}](//upload.wikimedia.org/math/5/f/1/5f18ec8393e59573c33776f637f86b15.png)

At this point, X is known and represents a column of functions of time. The output can be derived from the known X's and the original step function μ using C and D:

    ![y = \\boldsymbol{C}\\boldsymbol{X} + D*\\boldsymbol{\\mu}](//upload.wikimedia.org/math/f/5/a/f5a4c9be20e9e4a5103731477bfb3988.png)

### MatLab Implementation

[File:MatLabSimulinkStateSpace.png](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=MatLabSimulinkStateSpace.png)

screen shot of matlab with simulink toolbox showing how to get to the state-space block for wikibook circuit analysis

This would not be a step forward without tools such as MatLab. These are the relevant MatLab control system toolbox commands:

  * step(A,B,C,D) assumes the initial conditions are zero
  * initial(A,B,C,D,X(0)) just like step but takes into account the initial conditions X(0)

In addition, there is a simulink block called "State Space" that can be used the same way.

### Video Introduction

  * [41 minute introduction from digilent corp](http://www.youtube.com/watch?v=2cQMO3NZz4Y&list=PLDEC730F6A8CDE318&index=27&feature=plpp_video)
  * [5 minute application to a circuit](http://www.youtube.com/watch?v=vl-lemzB1w8&list=PL170A01159D42313D&index=19&feature=plpp_video)

## Further Reading

  * [Control Systems/State-Space Equations](/wiki/Control_Systems/State-Space_Equations)
  * matlab help links

  


Sinusoidal Sources

The circuits that we have analyzed previously have been DC , where a constant voltage or current is applied to the circuit. In the following chapters, we will discuss the topic of alternating current (AC), which utilizes sinusoidal forcing functions to stimulate a circuit.

  


# Sinusoidal Sources

**[Circuit Theory](/wiki/Circuit_Theory)**

## Steady State

"Steady State" means that we are not dealing with turning on or turning off circuits in this section. We are assuming that the circuit was turned on a very long time ago and it is behaving in a pattern. We are computing what the pattern will look like. The "complex frequency" section models turning on and off a circuit with an exponential.

## Sinusoidal Forcing Functions

Let us consider a general AC forcing function:

    ![v\(t\) = M\\sin\(\\omega t + \\phi\)](//upload.wikimedia.org/math/c/b/9/cb96e95168437261f962f77f9bf70292.png)

In this equation, the term M is called the "Magnitude", and it acts like a scaling factor that allows the peaks of the sinusoid to be higher or lower than +/- 1. The term ω is what is known as the "Radial Frequency". The term φ is an offset parameter known as the "Phase".

Sinusoidal sources can be current sources, but most often they are voltage sources.

## Other Terms

There are a few other terms that are going to be used in many of the following sections, so we will introduce them here:

Period 
    The period of a sinusoidal function is the amount of time, in seconds, that the sinusoid takes to make a complete wave. The period of a sinusoid is always denoted with a capital T. This is not to be confused with a lower-case t, which is used as the independent variable for time.

Frequency 
    Frequency is the reciprocal of the period, and is the number of times, per second, that the sinusoid completes an entire cycle. Frequency is measured in Hertz (Hz). The relationship between frequency and the Period is as follows:

    

    ![f = \\frac{1}{T}](//upload.wikimedia.org/math/c/f/5/cf56377ea780a8ce1586d2abed17482c.png)

    Where f is the variable most commonly used to express the frequency.

Radian Frequency 
    Radian frequency is the value of the frequency expressed in terms of Radians Per Second, instead of Hertz. Radian Frequency is denoted with the variable ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png). The relationship between the Frequency, and the Radian Frequency is as follows:

    

    ![\\omega = 2 \\pi f](//upload.wikimedia.org/math/e/e/f/eefe9093ec365c277ea859d088715133.png)

Phase 
    The phase is a quantity, expressed in radians, of the time shift of a sinusoid. A sinusoid phase-shifted ![\\phi = +2 \\pi](//upload.wikimedia.org/math/c/c/e/cce484068809e77b3437fc065817e8ad.png) is moved forward by 1 whole period, and looks exactly the same. An important fact to remember is this:

    

    ![\\sin \(\\frac{\\pi}{2}-t\) = \\cos \(t\)](//upload.wikimedia.org/math/f/0/7/f07c1ca61fac5a81386f078ed8c4797a.png) or ![\\sin \(t\) = \\cos \(t - \\frac{\\pi}{2}\)](//upload.wikimedia.org/math/3/4/c/34ccc3978c97724e3cc5840e5316cd59.png)

Phase is often expressed with many different variables, including ![\\phi, \\psi, \\theta, \\gamma](//upload.wikimedia.org/math/5/f/9/5f96bfc1f6c2e7cd06f6a5e3490f5511.png) etc... This wikibook will try to stick with the symbol ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png), to prevent confusion.

## Lead and Lag

A circuit element may have both a voltage across its terminals and a current flowing through it. If one of the two (current or voltage) is a sinusoid, then the other must also be a sinusoid (remember, voltage is the derivative of the current, and the derivative of a sinusoid is always a sinusoid). However, the sinusoids of the voltage and the current may differ by quantities of magnitude and phase.

If the current has a lower phase angle than the voltage the current is said to **lag** the voltage. If the current has a higher phase angle then the voltage, it is said to **lead** the voltage. Many circuits can be classified and examined using lag and lead ideas.

## Sinusoidal Response

Reactive components (capacitors and inductors) are going to take energy out of a circuit like a resistor and then pump some of it back into the circuit like a source. The result is initially a mess. But after a while (5 time constants), the circuit starts behaving in a pattern. The capacitors and inductors get in a rhythm that reflects the driving sources. If the source is sinusoidal, the currents and voltages will be sinusoidal. This is called the "particular" or "steady state" response. In general:

    ![A_{in} \\cos\(\\omega_{in} t + \\phi_{in}\) \\to A_{out} \\cos\(\\omega_{out} t + \\phi_{out}\)](//upload.wikimedia.org/math/4/5/c/45ce6de814f87dd829a3bf01dd9240a6.png)

What happens initially, what happens if the capacitor is initially charged, what happens if sources are switched in and out of a circuit is that there is an energy imbalance. A voltage or current source might be charged by the initial energy in a capacitor. The derivative of the voltage across an Inductor might instantaneously switch polarity. Lots of things are happening. We are going to save this for later. Here we deal with the steady state or "particular" response first.

## Sinusoidal Conventions

For the purposes of this book we will generally use cosine functions, as opposed to sine functions. If we absolutely need to use a sine, we can remember the following trigonometric identity:

    ![\\cos\(\\omega t\) = \\sin\(\\pi/2 -\\omega t\)](//upload.wikimedia.org/math/1/2/e/12e4d47ba402b0fd76950ff1e49139ad.png)

We can express all sine functions as cosine functions. This way, we don't have to compare apples to oranges per se. This is simply a convention that this wikibook chooses to use to keep things simple. We could easily choose to use all sin( ) functions, but further down the road it is often more convenient to use cosine functions instead by default.

## Sinusoidal Sources

There are two primary sinusoidal sources: wall outlets and [oscillators](//en.wikipedia.org/wiki/Electronic_oscillator). Oscillators are typically crystals that electrically vibrate and are found in devices that communicate or display video such as TV's, computers, cell phones, radios. An electrical engineer or tech's working area will typically include a "[function generator](//en.wikipedia.org/wiki/Function_generator)" which can produce oscillations at many frequencies and in shapes that are not just sinusoidal.

RMS or [Root mean square](//en.wikipedia.org/wiki/Root_mean_square) is a measure of amplitude that compares with DC magnitude in terms of power, strength of motor, brightness of light, etc. The trouble is that there are several types of AC amplitude:

  * peak
  * peak to peak
  * average
  * RMS

Wall outlets are called [AC](//en.wikipedia.org/wiki/Alternating_current) or alternating current. Wall outlets are sinusoidal voltage sources that range from 100 RMS volts, 50 Hz to 240 RMS volts 60 Hz world wide. RMS, rather than peak (which makes more sense mathematically), is used to describe magnitude for several reasons:

  * historical reasons related to the competition between Edison (DC power) and Tesla (Sinusoidal or AC power)
  * effort to compare/relate AC (wall outlets) to DC (cars, batteries) .. 100 RMS volts is approximately 100 DC volts.
  * average sinusoidal is zero
  * meter movements ([physical needles moving](//en.wikipedia.org/wiki/Ammeter#Types) on measurement devices) were designed to measure both DC and RMS AC

RMS is a type of average: ![
p_{\\mathrm{rms}} = \\sqrt {{1 \\over {T_2-T_1}} {\\int_{T_1}^{T_2} {\[p\(t\)\]}^2\\, dt}}
](//upload.wikimedia.org/math/6/6/1/6617028f46ecd7ee919009c79c9653bf.png)

[Electrical power delivery](//en.wikipedia.org/wiki/Three-phase_electric_power) is a complicated subject that will not be covered in this course. Here we are trying to define terms, design devices that use the power and understand clearly what comes out of wall outlets.  


# Phasor Representation

**[Circuit Theory](/wiki/Circuit_Theory)**

![Warning icon WikiBooks.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Warning_icon_WikiBooks.svg/35px-Warning_icon_WikiBooks.svg.png)

This book contains mathematical formulae that look better **[rendered as PNG](/wiki/Wikibooks:Render_as_PNG)**.

# Phasors

## Variables

Variables are defined the same way. But there is a difference. Before variables were either "known" or "unknown." Now there is a sort of in between.

At this point the concept of a constant function (a number) and a variable function (varies with time) needs to be reviewed. See this [student professor](/w/index.php?title=Circuit_Theory/All_Chapters/student_professor&action=edit&redlink=1) dialogue. Knowns are described in terms of functions, unknowns are computed based upon the knowns and are also functions.

For example:

    ![v\(t\) = M_v \\cos \(\\omega t + \\phi_v\)](//upload.wikimedia.org/math/0/2/d/02db276bf7db52cfdd244a0743e3e167.png) voltage varying with time

Here ![v\(t\)](//upload.wikimedia.org/math/2/7/3/273a383345e167ee1791232c40eaf917.png) is the symbol for a function. It is assigned a function of the symbols ![M_v, \\omega, \\phi_v](//upload.wikimedia.org/math/1/f/3/1f37f46c60af4a8e49c876011a226061.png) and ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png). Typically time is not ever solved for.

Time remains an unknown. Furthermore all power, voltage and current turn into equations of time. Time is not solved for. Because time is everywhere, it can be eliminated from the equations. Integrals and derivatives turn into algebra and the answers can be purely numeric (before time is added back in).

At the last moment, time is put back into voltage, current and power and the final solution is a function of time.

Most of the math in this course has these steps:

  1. describe knowns and unknowns in the time domain, describe all equations
  2. change knowns into phasors, eliminate derivatives and integrals in the equations
  3. solve numerically or symbolically for unknowns in the phasor domain
  4. transform unknowns back into the time domain

## Passive circuit output is similar to input

If the input to a linear circuit is a sinusoid, then the output from the circuit will be a sinusoid. Specifically, if we have a voltage sinusoid as such:

    ![v\(t\) = M_v \\cos \(\\omega t + \\phi_v\)](//upload.wikimedia.org/math/0/2/d/02db276bf7db52cfdd244a0743e3e167.png)

Then the current through the linear circuit will also be a sinusoid, although its magnitude and phase may be different quantities:

    ![i\(t\) = M_i \\cos \(\\omega t + \\phi_i\)](//upload.wikimedia.org/math/0/f/d/0fd78c195b7d79349dbd93669d386db7.png)

Note that both the voltage and the current are sinusoids with the same radial frequency, but different magnitudes, and different phase angles. Passive circuit elements cannot change the frequency of a sinusoid, only the magnitude and the phase. Why then do we need to write ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) in every equation, when it doesnt change? For that matter, why do we need to write out the cos( ) function, if that never changes either? The answers to these questions is that _we don't need to write these things every time._ Instead, engineers have produced a short-hand way of writing these functions, called "phasors".

## Phasor Transform

Phasors are a type of "transform." We are transforming the circuit math so that time disappears. Imagine going to a place where time doesn't exist.

We know that every function can be written as a series of sine waves of various frequencies and magnitudes added together. (Look up fourier transform animation). The entire world can be constructed from [sin waves](//en.wikipedia.org/wiki/Matter_wave). Here, one sine wave is looked at, the repeating nature (![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png)) is stripped away. Whats left is a phasor. Since time is made of circles, and if we consider just one of these circles, we can move to a world where time doesn't exist and circles are "things". Instead of the word "world", use the word "domain" or "plane" as in two dimensions.

Math in the Phasor domain is almost the same as DC circuit analysis. What is different is that inductors and capacitors have an impact that needs to be accounted for.

The transform into the Phasors plane or domain and transforming back into time is based upon Euler's equation. It is the reason you studied imaginary numbers in past math class.

## Euler's Equation

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/71/Euler%27s_formula.svg/220px-Euler%27s_formula.svg.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Euler's Formula

Euler started at these three series. Obviously there is a relationship:

    ![\\cos x = 1 - \\frac{x^2}{2!} + \\frac{x^4}{4!} - \\frac{x^6}{6!} + \\cdots](//upload.wikimedia.org/math/a/a/3/aa3f731a421493d130b12e0d904876fb.png)
    ![\\sin x = x - \\frac{x^3}{3!} + \\frac{x^5}{5!} - \\frac{x^7}{7!} + \\cdots](//upload.wikimedia.org/math/c/5/c/c5c065beaaa58aa47da0e07dd4f9ddbf.png)
    ![e^{x} = 1 + x + \\frac{x^2}{2!} + \\frac{x^3}{3!} + \\frac{x^4}{4!} + \\frac{x^5}{5!} + \\cdots](//upload.wikimedia.org/math/6/d/a/6dac4a605d4aee4ffc3a3416558e0292.png)

He did the following:

    ![e^{ix} = 1 + i x + \\frac{i^2 x^2}{2!} + \\frac{i^ 3 x^3}{3!} + \\frac{i^ 4 x^4}{4!} + \\frac{i^ 5 x^5}{5!} + \\cdots](//upload.wikimedia.org/math/4/a/7/4a7e181dc90c584ea946c2dc53878f2e.png)
    ![e^{ix} = 1 + i x - \\frac{x^2}{2!} - i\\frac{x^3}{3!} + \\frac{x^4}{4!} + i\\frac{x^5}{5!} - \\frac{x^6}{6!} - i\\frac{x^7}{7!} \\cdots](//upload.wikimedia.org/math/e/a/1/ea1eef80c36bda9a402d72d10eb770f2.png)
    ![e^{ix} = \(1  - \\frac{x^2}{2!} + \\frac{x^4}{4!} - \\frac{x^6}{6!} + \\cdots\) + i \(x - \\frac{x^3}{3!}  + \\frac{x^5}{5!} - \\frac{x^7}{7!} + \\cdots\)](//upload.wikimedia.org/math/b/2/c/b2cc04172426cf9fd4884889e62232ec.png)
    ![e^{ix} = \\cos\(x\) + i \\sin\(x\)](//upload.wikimedia.org/math/3/5/f/35ff0741ce2512c5967550af6241a08c.png)

Set x = π and:

    ![e^{i\\pi} = -1](//upload.wikimedia.org/math/1/d/1/1d1ab6f86bc92873a4648dd68a40bcc6.png)

Euler's formula is ubiquitous in mathematics, physics, and engineering. The physicist [Richard Feynman](//en.wikipedia.org/wiki/Richard_Feynman) called the equation "our jewel" and "one of the most remarkable, almost astounding, formulas in all of mathematics."

A more general version of Euler's equation is:

    ![M e^{j\(\\omega t + \\phi\)} = M \\cos \(\\omega t + \\phi\) + j M \\sin \(\\omega t + \\phi\)](//upload.wikimedia.org/math/b/4/2/b42f7c2b98b0989257dbf0488243991c.png)

This equation allows us to view sinusoids as complex exponential functions. A cyclic function represented as a voltage, current or power given in terms of radial frequency and phase angle turns into an arrow having length ![\\mathbb{C}](//upload.wikimedia.org/math/f/0/b/f0b01fe0a1eec87c634584ac0694fb71.png) (magnitude) and angle ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png) (phase) in the phasor domain/plane or a point having both a real (![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png)) and imaginary (![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png)) coordinate in the complex domain/plane.

Generically, the phasor ![\\mathbb{C}](//upload.wikimedia.org/math/f/0/b/f0b01fe0a1eec87c634584ac0694fb71.png), (which could be voltage, current or power) can be written:

    ![\\mathbb{C} = X + jY](//upload.wikimedia.org/math/e/9/e/e9eda3c07e5f79691863c56d05998a39.png) (rectangular coordinates)  

    ![\\mathbb{C} = M_v \\angle \\phi](//upload.wikimedia.org/math/7/1/d/71d02cc64036b558417c01d02e2c253d.png) (polar coordinates)

We can graph the point (X, Y) on the complex plane and draw an arrow to it showing the relationship between ![X,Y,\\mathbb{C}](//upload.wikimedia.org/math/3/b/d/3bde2fe09452e65f1d415ab1e79a96cc.png) and ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png).

Using this fact, we can get the angle from the origin of the complex plane to out point (X, Y) with the function:

  


[Angle equation]

    ![\\theta_C = \\arctan\(\\frac{Y}{X}\)](//upload.wikimedia.org/math/6/c/6/6c61040dba0b605de536e2a8d26ef892.png)

And using the pythagorean theorem, we can find the magnitude of C -- the distance from the origin to the point (X, Y) -- as:

  


[Pythagorean Theorem]

    ![M_C = |\\mathbb{C}| = \\sqrt{X^2 + Y^2}](//upload.wikimedia.org/math/3/8/d/38d06e2feca7b3f283d57855b9e84d7d.png).

## Phasor Symbols

Phasors don't account for the frequency information, so make sure you write down the frequency some place safe.

Suppose in the time domain:

    ![v\(t\) = M_v e^{j\(\\omega t + \\phi\)}](//upload.wikimedia.org/math/4/f/c/4fce4a39de49bba55b4a4c4550a331a7.png)

In the phasor domain, this voltage is expressed like this:

    ![\\mathbb{V} = M_v \\angle \\phi](//upload.wikimedia.org/math/c/6/d/c6dfd4a187cf16a11233446dd8763f61.png)

The radial velocity ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) disappears from known functions (not the derivate and integral operations) and reappears in the time expression for the unknowns.

## Not Vectors

Contrary to the statement made in this heading, phasors (phase vectors), are vectors. Phasors form a vector space with additional structure, hence they have some properties that are not common to all vector spaces; these additional properties exist because phasors form a field - thus you also get division.

For more details see <http://en.wikipedia.org/wiki/Phasor_(electronics)>

* * *

Like many kinds of vectors they have additional struct Phasors will always be written out either with a large bold letter (as above). They are not a vector. Vectors have two or more real axes that are not related by Euler, but are independent. They share some math in two dimensions, but this math diverges.

    

    

    

    

    

    **Phasors can be divided, but vectors can not.**

Voltage can be divided by current (in the phasor domain), but East can not be divided by North (vectors can not be divided). Vectors move into three or more dimensions of linear algebra math that help build complicated structures in the real world such as [space frames](//en.wikipedia.org/wiki/Space_frame). Phasors move into more complicated transforms related to differential equation math and electronics.

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Cross_product_animation.gif/220px-Cross_product_animation.gif)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

cross product visualization

The math of phasors is exactly the same as ordinary math, except with imaginary numbers. Vectors demand new mathematical operations such as dot product and cross product:

  * The dot product of vectors finds the shadow of one vector on another.
  * The cross product of vectors combines vectors into a third vector perpendicular to both.

## Cosine Convention

In this book, all phasors correspond to a **cosine** function, not a **sine** function.

It is important to remember which trigonometric function your phasors are mapping to. Since a phasor only includes information on magnitude and phase angle, it is impossible to know whether a given phasor maps to a sin( ) function, or a cos( ) function instead. By convention, this wikibook and most electronic texts/documentation map to the cosine function.

If you end up with an answer that is sin, convert to cos by subtracting 90 degrees:

    ![\\sin\(\\omega t + \\phi\) = cos\(\\omega t + \\phi - \\frac{\\pi}{2}\)](//upload.wikimedia.org/math/6/2/5/62546c00f9a08d0893ac1acc27dfd127.png)

If your simulator requires the source to be in sin form, but the starting point is cos, then convert to sin by adding 90 degrees:

    ![\\cos\(\\omega t + \\phi\) = sin\(\\omega t + \\phi + \\frac{\\pi}{2}\)](//upload.wikimedia.org/math/1/0/b/10b82c499f54d36a13742f0f42ba8910.png)

## Phasor Concepts

Inside the phasor domain, concepts appear and are named. Inductors and capacitors can be coupled with their derivative operator transforms and appear as imaginary resistors called "reactance." The combination of resistance and reactance is called "impedance." Impedance can be treated algebraically as a phasor although technically it is not. Power concepts such as real, reactive, apparent and power factor appear in the phasor domain. Numeric math can be done in the phasor domain. Symbols can be manipulated in the phasor domain.

## Phasor Math

There is more information about Phasors in  
**[The Appendix](/wiki/Circuit_Theory/Phasor_Arithmetic)**

Phasor math turns into the imaginary number math which is reviewed below.

Phasor A can be multiplied by phasor B:

  


[Phasor Multiplication]

    ![\\mathbb{A} \\times \\mathbb{B} = \(M_a \\times M_b\) \\angle \(\\phi_a + \\phi_b\)](//upload.wikimedia.org/math/a/f/a/afa31d3cdd8f4808a4613a8fe0eee582.png)

The phase angles add because in the time domain they are exponents of two things multiplied together.

  


[Phasor Division]

    ![\\mathbb{A} / \\mathbb{B} = \(M_a / M_b\) \\angle \(\\phi_a - \\phi_b\)](//upload.wikimedia.org/math/6/2/1/621e8f2c1e184ac96a0ebb7976cdbf18.png)

Again the phase angles are treated like exponents ... so they subtract.

The magnitude and angle form of phasors can not be used for addition and subtraction. For this, we need to convert the phasors into rectangular notation:

    ![\\mathbb{C} = X + jY](//upload.wikimedia.org/math/e/9/e/e9eda3c07e5f79691863c56d05998a39.png)

Here is how to convert from polar form (magnitude and angle) to rectangular form (real and imaginary)

    ![X = M \\cos \(\\phi\)](//upload.wikimedia.org/math/6/d/c/6dcd3fb8589993bb88a98ee63b0d6834.png), ![Y = M \\sin \(\\phi\)](//upload.wikimedia.org/math/0/7/7/07764b63ec8f4ddbb0f403dfdacd60bc.png)

Once in rectangular form:

  * Real parts get add or subtract
  * Imaginary parts add or subtract

  


[Phasor Addition]

    ![\\mathbb{C} = \\mathbb{A} + \\mathbb{B} = \(X_A + X_B\) + j\(Y_A + Y_B\) = X_C + jY_C](//upload.wikimedia.org/math/9/0/c/90ca95da1eea32ae78f3b186f3325e13.png)

Here is how to convert from rectangular form to polar form:

    ![\\mathbb{C} = M_c \\angle \\phi_c = \\sqrt{X^2 + Y^2} \\angle \\arctan\(\\frac{Y}{X}\)](//upload.wikimedia.org/math/5/9/f/59fb9fe58e1d11ed23dc0f339a841911.png)

Once in polar phasor form, conversion back into the time domain is easy:

    ![\\operatorname{Re}\(M e^{j\(\\omega t + \\phi\)}\) = M \\cos \(\\omega t + \\phi\)](//upload.wikimedia.org/math/4/c/0/4c07d20d1b2aa0081bbca058a9806979.png)

## Function transformation Derivation

![g\(t\)](//upload.wikimedia.org/math/0/9/6/096254c7552111f593bb632a91205f32.png) represents either voltage, current or power.

    ![g\(t\)=G_m cos\(\\omega t + \\phi\)](//upload.wikimedia.org/math/7/7/c/77c4a6c5f5e4bd4c2bae02bf96ae5752.png) starting point  

    ![g\(t\)=G_m \\operatorname{Re}\(e^{j\(\\omega t + \\phi\)}\)](//upload.wikimedia.org/math/f/6/e/f6e4b4bed906abfa66d7008c43346f5a.png) from Euler's Equation  

    ![g\(t\)=G_m \\operatorname{Re}\(e^{j\\phi}e^{j\\omega t}\)](//upload.wikimedia.org/math/6/e/2/6e2f6cd416fd7878cdb3a80169051e7c.png) law of exponents
    ![g\(t\)=\\operatorname{Re}\(G_m e^{j\\phi}e^{j\\omega t}\)](//upload.wikimedia.org/math/8/f/0/8f0dfcb74c18ba326fabc1423a33e0da.png) .... ![G_m](//upload.wikimedia.org/math/a/d/3/ad3a9cfb5827fa3c2e2e607611be4fef.png) is a real number so it can be moved inside
    ![g\(t\)=\\operatorname{Re}\(\\mathbb{G} e^{j\\omega t}\)](//upload.wikimedia.org/math/d/a/b/dab642816b99bc027b629f52d28f2c80.png) ![ .... \\mathbb{G}](//upload.wikimedia.org/math/1/4/e/14efe12d24764cb201c30b262b0b833a.png) is the definition of a phasor, here it is an expression substituting for ![G_m e^{j\\phi}](//upload.wikimedia.org/math/e/7/3/e73db69286e36b378892e53573dc2a06.png)
    ![g\(t\) \\Leftrightarrow \\mathbb{G}](//upload.wikimedia.org/math/4/4/4/4446acc17ab0db18b5fa223fb5c9bf43.png) where ![ \\mathbb{G} = G_m e^{j\\phi}](//upload.wikimedia.org/math/d/9/c/d9ce32e0805a7c1f96aca8f6b66f5681.png)

What happens to ![e^{j\\omega t}](//upload.wikimedia.org/math/1/0/b/10b2958e7b2d46919722499d2d8808c3.png) term? [Long Answer](/w/index.php?title=Circuit_Theory/All_Chapters/j_omega_disappears&action=edit&redlink=1). It hangs around until it is time to transform back into the time domain. Because it is an exponent, and all the phasor math is algebra associated with exponents, the final phasor can be multiplied by it. Then the real part of the expression will be the time domain solution.

time domain transformation phasor domain

![A cos\(\\omega t\)](//upload.wikimedia.org/math/5/5/a/55ace62dc186a0912135771592d13e17.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png) [proof](/w/index.php?title=Circuit_Theory/All_Chapters/proof1&action=edit&redlink=1)
![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png)

![A sin\(\\omega t\)](//upload.wikimedia.org/math/8/8/e/88e5853ff450c5489a5c89a1ceee3863.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png) [proof](/w/index.php?title=Circuit_Theory/All_Chapters/proof2&action=edit&redlink=1)
![-Aj](//upload.wikimedia.org/math/6/9/b/69b3a7f36c3acbb3489d58269ebf68a1.png)

![A cos\(\\omega t\) + B sin\(\\omega t\)](//upload.wikimedia.org/math/a/c/9/ac92a6a4f1085611de0f49d1967000ae.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png)
![A-Bj](//upload.wikimedia.org/math/e/1/7/e17e6c83978da12bb03c0443d36f4660.png)

![A cos\(\\omega t\) - B sin\(\\omega t\)](//upload.wikimedia.org/math/b/6/9/b695696ecb4a958221f2d0fb963784bf.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png)
![A+Bj](//upload.wikimedia.org/math/8/e/8/8e803c7026eda03c03d1596712a87580.png)

![A cos\(\\omega t + \\phi\)](//upload.wikimedia.org/math/1/a/0/1a01441d73e2c8e59b27362a024701a9.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png) [proof](/w/index.php?title=Circuit_Theory/All_Chapters/proof5&action=edit&redlink=1)
![A cos\(\\phi\) + A sin\(\\phi\)j](//upload.wikimedia.org/math/7/a/5/7a5a7fbccedd8b46f4979b1f59dd9b8f.png)

![A sin\(\\omega t + \\phi\)](//upload.wikimedia.org/math/2/6/a/26ad592eeb2ba7b437d57ae0f59b03fc.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png) [proof](/w/index.php?title=Circuit_Theory/All_Chapters/proof6&action=edit&redlink=1)
![A sin\(\\phi\) - A cos\(\\phi\)j](//upload.wikimedia.org/math/e/b/a/ebac8689ecffb0aff9f014588f829afe.png)

![A cos\(\\omega t - \\phi\)](//upload.wikimedia.org/math/a/d/7/ad7e77efc19cfc73c03cd2928c2ff80a.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png) [proof](/w/index.php?title=Circuit_Theory/All_Chapters/proof7&action=edit&redlink=1)
![A cos\(\\phi\) - A sin\(\\phi\)j](//upload.wikimedia.org/math/0/e/1/0e1b4dc3645550d832c12b01e096aa74.png)

![A sin\(\\omega t - \\phi\)](//upload.wikimedia.org/math/f/b/a/fbaa68344d240b1d7cf7fb10d1dfd065.png)
![\\Leftrightarrow](//upload.wikimedia.org/math/0/1/4/014cced2b73c22eb88cdc6901afb0c9d.png) [proof](/w/index.php?title=Circuit_Theory/All_Chapters/proof8&action=edit&redlink=1)
![-A sin\(\\phi\) - A cos\(\\phi\)j](//upload.wikimedia.org/math/2/4/4/2440217f0fd07b5de1ea6db75d36e9a2.png)

In all the cases above, remember that ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png) is a constant, a known value in most cases. Thus the phasor is an complex number in most calculations.

There is another transform associated with a derivatives that is discussed in "phasor calculus."

## Transforming calculus operators into phasors

When sinusoids are represented as phasors, differential equations become algebra. This result follows from the fact that the complex exponential is the [eigenfunction](//en.wikipedia.org/wiki/Eigenfunction) of the operation:

    ![\\frac{d}{dt}\(e^{j \\omega t}\) = j \\omega e^{j \\omega t}](//upload.wikimedia.org/math/2/5/1/25154c78ccd98bfb6ad768e150a460dc.png)

That is, only the complex amplitude is changed by the derivative operation. Taking the real part of both sides of the above equation gives the familiar result:

    ![\\frac{d}{dt} \\cos{\\omega t} = - \\omega \\sin{\\omega t}\\,](//upload.wikimedia.org/math/8/6/9/8697df703b793d7d98812e4d8a9883ad.png)

Thus, a time derivative of a sinusoid becomes, when tranformed into the phasor domain, algebra:

    ![{d \\over dt}i\(t\)\\rightarrow j\\omega\\mathbb{I}](//upload.wikimedia.org/math/9/d/9/9d923711085aa72caaf0cc14c3521af7.png) j is the square root of -1 or an imaginary number

In a similar way the time integral, when transformed into the phasor domain is:

    ![\\int V\(t\) dt \\rightarrow \\frac{\\mathbb{V}}{j\\omega}](//upload.wikimedia.org/math/5/e/0/5e077391dfe452abb8df801ec793af14.png)

There is an integration constant that will have to be dealt with when translating back into the time domain. It doesn't disappear.

The above is true of voltage, current, and power.

The question is why does this work? Where is the proof? Lets do this three times: once for a resistor, then inductor, then capacitor. The symbols for the current and voltage going through the terminals are: ![V_m cos\(\\omega t + \\phi_v\)](//upload.wikimedia.org/math/8/e/f/8ef6137b906f5320ec636337936e1594.png) and ![I_m cos\(\\omega t + \\phi_I\)](//upload.wikimedia.org/math/8/3/4/83400605e0df20afb3a3308212bccf25.png)

### Resistor Terminal Equation

    ![V=R I](//upload.wikimedia.org/math/3/4/7/347c046230f14b745fb0255b700f52eb.png) . terminal relationship
    ![V_m cos\(\\omega t + \\phi_V\) = R I_m cos\(\\omega t + \\phi_I\)](//upload.wikimedia.org/math/b/3/f/b3ff6a58adc4d20d88f1115e19b64408.png) .. substituting example functions
    ![V_m e^{\\omega t + j \\phi_V} = R I_m e^{\\omega t + j \\phi_I}](//upload.wikimedia.org/math/d/2/c/d2c4ebc873a7ced006e1f5e6a8157735.png) .. Euler's version of the terminal relationship
    ![V_m e^{\\omega t} e^{j \\phi_V} = R I_m e^{\\omega t} e^{j \\phi_I}](//upload.wikimedia.org/math/8/1/8/818cfc2f3c328cc19eff999bbc6b7cf8.png) .. law of exponents
    ![V_m \\cancel{e^{\\omega t}} e^{j \\phi_V} = R I_m \\cancel{e^{\\omega t}} e^{j \\phi_I}](//upload.wikimedia.org/math/1/d/9/1d992e7b79b3da9408df9d87fd224e43.png) .. do same thing go both sides of equal sign
    ![V_m e^{j \\phi_V} = R I_m e^{j \\phi_I}](//upload.wikimedia.org/math/2/9/3/293b47c049a9b8915e593b78390717fb.png) .. time domain result
    ![\\mathbb{V} = R \\mathbb{I}](//upload.wikimedia.org/math/c/b/3/cb365bd4678bf043031c67a098dad1a5.png) .. phasor expression

Just put the voltage and current in phasor form and substitute to migrate equation into the phasor domain.

### Inductor Terminal Equation

    ![V = L\\frac{d}{dt}I](//upload.wikimedia.org/math/b/a/6/ba6600059c7b0b779bbe0da5fbc6ba18.png) ... terminal relationship
    ![V_m cos\(\\omega t + \\phi_V\) = L \\frac{d}{dt} \(I_m cos\(\\omega t + \\phi_I\)\)](//upload.wikimedia.org/math/6/7/5/675a88293e4824dda186c70615ea2435.png) .. substitution of a generic sinusodial
    ![V_m cos\(\\omega t + \\phi_V\) = -\\omega L I_m sin\(\\omega t + \\phi_I\)](//upload.wikimedia.org/math/f/e/2/fe2c29eede2b43013bbe2d4d72eb4659.png) .. taking the derivative
    ![- sin\(\\omega t + \\phi_I\) = cos\(\\omega t + \\phi_I + \\frac{\\pi}{2}\)](//upload.wikimedia.org/math/8/5/2/8525f18f91a13053c9e855d0b692a6a8.png) .. trig
    ![V_m cos\(\\omega t + \\phi_V\) = \\omega L I_m cos\(\\omega t + \\phi_I + \\frac{\\pi}{2}\)](//upload.wikimedia.org/math/3/1/6/31622cb4f63ef8d1ea3570de97c8d306.png) .. substitution
    ![V_m \\operatorname{Re}\(e^{j\(\\omega t + \\phi_V\)}\) = \\omega L I_m \\operatorname{Re}\(e^{j\(\\omega t + \\phi_L + \\frac{\\pi}{2}\)}\)](//upload.wikimedia.org/math/1/a/2/1a2c29ff666d5f17e4094ab2d2844187.png) from Euler's Equation
    ![V_m \\operatorname{Re}\(e^{j\\omega t} e^{j\\phi_V}\) = \\omega L I_m \\operatorname{Re}\(e^{j\\omega t}e^{j\\phi_L}e^{j\\frac{\\pi}{2}}\)](//upload.wikimedia.org/math/f/4/e/f4ece0251905ce4176fff21088236551.png) law of exponents
    ![ \\operatorname{Re}\(V_m e^{j\\phi_V} \\cancel{e^{j\\omega t}} \) = \\operatorname{Re}\(e^{j\\frac{\\pi}{2}} \\omega L I_m e^{j\\phi_L} \\cancel{e^{j\\omega t}}\)](//upload.wikimedia.org/math/3/6/b/36b0df79c0a8dd1c1652aa74f6812e31.png) .... real numbers can be moved inside
    ![e^{j\\frac{\\pi}{2}} = cos\(\\frac{\\pi}{2}\) + j*sin\(\\frac{\\pi}{2}\) = j](//upload.wikimedia.org/math/7/c/3/7c3560f1c37827bb718972d059928d4c.png) ... substitute in above
    ![\\mathbb{I} = I_m e^{j\\phi_L}](//upload.wikimedia.org/math/6/0/a/60ad8e28d5c1d5bd4ce25588c5c16923.png) and ![\\mathbb{V} = V_m e^{j\\phi_V}](//upload.wikimedia.org/math/8/a/2/8a22185438da720bc479f9f08ed212c3.png) .. substitute in above
    cancel out the ![e^{j\\omega}](//upload.wikimedia.org/math/b/6/7/b67db7d7ce0df3e7ba38b982c1576a91.png) terms on both sides
    ![ \\operatorname{Re}\(\\mathbb{V}e^{j\\omega t} \) = \\operatorname{Re}\(j \\omega L \\mathbb{I}e^{j\\omega t}\)](//upload.wikimedia.org/math/0/e/0/0e0691cdb11a94ad2db16748d836d5ec.png) .... definition of phasors
    ![ \\mathbb{V} = j \\omega L \\mathbb{I}](//upload.wikimedia.org/math/3/c/6/3c66310a41cfc624b062044e9bf25c7e.png) .... equation transformed into phasor domain

Conclusion, put the voltage and current in phasor form, replace ![\\frac{d}{dt}](//upload.wikimedia.org/math/8/9/f/89f074357e01c5d501c32eefb0e7444a.png) with ![j\\omega](//upload.wikimedia.org/math/5/6/7/567f5696b59cd1178bd884d76e6d5df8.png) to translate the equation to the phasor domain.

### Capacitor Terminal Equation

A capacitor is basically the same form, V and I switch sides, C is substituted for L.

    ![I = C\\frac{d}{dt}V](//upload.wikimedia.org/math/c/e/6/ce6e9f9a5c370f918999dd1c4d54982d.png) ... terminal relationship
    ![I_m cos\(\\omega t + \\phi_I\) = C \\frac{d}{dt} \(V_m cos\(\\omega t + \\phi_V\)\)](//upload.wikimedia.org/math/7/9/0/790b13b2c7ad39f6b6e90debbb11acce.png) .. substitution of a generic sinusodial
    ![I_m cos\(\\omega t + \\phi_I\) = -\\omega C V_m sin\(\\omega t + \\phi_V\)](//upload.wikimedia.org/math/4/4/1/441f2cb4cde34fac8b9d04f1a74fcc29.png) .. taking the derivative
    ![- sin\(\\omega t + \\phi_V\) = cos\(\\omega t + \\phi_V + \\frac{\\pi}{2}\)](//upload.wikimedia.org/math/c/2/f/c2ff7d1b429bec3a18ec991aefa34fa0.png) .. trig
    ![I_m cos\(\\omega t + \\phi_I\) = \\omega C V_m cos\(\\omega t + \\phi_V + \\frac{\\pi}{2}\)](//upload.wikimedia.org/math/4/b/4/4b46d8d7a48177346f904c9ba7c2c9eb.png) .. substitution
    ![I_m \\operatorname{Re}\(e^{j\(\\omega t + \\phi_I\)}\) = \\omega C V_m \\operatorname{Re}\(e^{j\(\\omega t + \\phi_V + \\frac{\\pi}{2}\)}\)](//upload.wikimedia.org/math/4/5/c/45ceb2fbdf862231ef129898da292aad.png) from Euler's Equation
    ![I_m \\operatorname{Re}\(e^{j\\omega t} e^{j\\phi_I}\) = \\omega C V_m \\operatorname{Re}\(e^{j\\omega t}e^{j\\phi_V}e^{j\\frac{\\pi}{2}}\)](//upload.wikimedia.org/math/e/c/8/ec82807f10a2fc99b9b2cb017a335869.png) law of exponents
    ![ \\operatorname{Re}\(I_m e^{j\\phi_I} \\cancel{e^{j\\omega t}}\) = \\operatorname{Re}\(e^{j\\frac{\\pi}{2}} \\omega C V_m e^{j\\phi_V} \\cancel{e^{j\\omega t}}\)](//upload.wikimedia.org/math/7/f/e/7fe6b94f80dd24ee19b3df379add1de4.png) .... real numbers can be moved inside
    ![e^{j\\frac{\\pi}{2}} = cos\(\\frac{\\pi}{2}\) + j*sin\(\\frac{\\pi}{2}\) = j](//upload.wikimedia.org/math/7/c/3/7c3560f1c37827bb718972d059928d4c.png) ... substitute in above equation
    ![\\mathbb{V} = V_m e^{j\\phi_V}](//upload.wikimedia.org/math/8/a/2/8a22185438da720bc479f9f08ed212c3.png) and ![\\mathbb{I} = I_m e^{j\\phi_I}](//upload.wikimedia.org/math/e/3/8/e382a20016c72b3fce603022d1a529f4.png).. substitute in above
    cancel out the ![e^{j\\omega}](//upload.wikimedia.org/math/b/6/7/b67db7d7ce0df3e7ba38b982c1576a91.png) terms on both sides
    ![ \\operatorname{Re}\(\\mathbb{I}e^{j\\omega t} \) = \\operatorname{Re}\(j \\omega C \\mathbb{V}e^{j\\omega t}\)](//upload.wikimedia.org/math/6/d/e/6de621932cd71509c6e633022e149f06.png) .... definition of phasors
    ![ \\mathbb{I} = j \\omega C \\mathbb{V}](//upload.wikimedia.org/math/4/7/9/47929ad1c3c5b9083e400868ce1b79fc.png) .... equation transformed into phasor domain

Conclusion, put the voltage and current in phasor form, replace ![\\frac{d}{dt}](//upload.wikimedia.org/math/8/9/f/89f074357e01c5d501c32eefb0e7444a.png) with ![j\\omega](//upload.wikimedia.org/math/5/6/7/567f5696b59cd1178bd884d76e6d5df8.png) to translate the equation to the phasor domain.

In summary, all the terminal relations have ![e^{j \\omega}](//upload.wikimedia.org/math/b/6/7/b67db7d7ce0df3e7ba38b982c1576a91.png) terms that cancel:

    ![V_m e^{j\\phi}\\cancel{e^{j\\omega t}} = I_m e^{j\\phi}\\cancel{e^{j\\omega t}} * R](//upload.wikimedia.org/math/b/8/1/b815fa1a793e817649e3a601f575e2f0.png)
    ![\\mathbb{V} = \\mathbb{I}R](//upload.wikimedia.org/math/4/8/8/48895b8f7cdb5f82c98243ba6a9137df.png)

    ![V_m e^{j\\phi}\\cancel{e^{j\\omega t}} = I_m e^{j\\phi}\\cancel{e^{j\\omega t}} * j\\omega*L](//upload.wikimedia.org/math/4/5/3/4537bf4dea8dbaf36553e93e7aa51765.png)
    ![\\mathbb{V} = \\mathbb{I}j\\omega L](//upload.wikimedia.org/math/8/e/f/8ef61e0be2c0bd1e6942b39080c70087.png)

    ![I_m e^{j\\phi}\\cancel{e^{j\\omega t}} = V_m e^{j\\phi}\\cancel{e^{j\\omega t}} * j\\omega*C](//upload.wikimedia.org/math/c/1/e/c1e61914919e07927d4e3e9fa43a5348.png)
    ![\\mathbb{I} = \\mathbb{V}j\\omega C](//upload.wikimedia.org/math/9/1/f/91f6afdaa6b2e42c9e1a8acfdeb07465.png)

What is interesting about this path of inquiry/logic/thought is a new concept emerges:

Device ![\\frac{\\mathbb{V}}{\\mathbb{I}}](//upload.wikimedia.org/math/2/f/4/2f40b2c0c6e0bd8029fc0a31bf49d7ab.png) ![\\frac{\\mathbb{I}}{\\mathbb{V}}](//upload.wikimedia.org/math/d/1/e/d1eacb4c4ffdeebb4a5895bf4c64ed49.png)

Resistor
![R](//upload.wikimedia.org/math/e/1/e/e1e1d3d40573127e9ee0480caf1283d6.png)
![\\frac{1}{R}](//upload.wikimedia.org/math/7/2/5/72561ae5bd1805a5bb0a231f341d1537.png)

Capacitor
![\\frac{1}{j\\omega C}](//upload.wikimedia.org/math/0/4/a/04a8d6e2e3a741b55e38b54269ebda42.png)
![j\\omega C](//upload.wikimedia.org/math/6/9/9/699699bdcf80d1b7b4a37c3412c79915.png)

Inductor
![j\\omega L](//upload.wikimedia.org/math/e/9/c/e9c1f37cef8b196aee24981bce45bb0c.png)
![\\frac{1}{j\\omega L}](//upload.wikimedia.org/math/c/c/0/cc0434a26063b1bd545978618eb6998d.png)

The ![j\\omega](//upload.wikimedia.org/math/5/6/7/567f5696b59cd1178bd884d76e6d5df8.png) terms that don't cancel out come from the derivative terms in the terminal relations. These derivative terms are associated with the capacitors and inductors themselves, not the sources. Although the derivative is applied to a source, the independent device the derivative originates from (a capacitor or inductor) is left with it's feature after the transform! So if we leave the driving forces as ![\\frac{output}{input}](//upload.wikimedia.org/math/9/0/a/90aa21de3b7ccb7fa34651b26030db17.png) ratios on one side of the equal sign, we can consider separately the other side of the equal sign as a function! These functions have a name ... Transfer Functions. When we analyze the voltage/current ratios's in terms of R, L an C, we can sweep ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) through a variety of driving source frequencies, or keep the frequency constant and sweep through a variety of inductor values .. . we can analyze the circuit response!

Note: Transfer Functions are an entire section of this course. They come up in mechanical engineering control system classes also. There are similarities. Driving over a bump is like a surge or spike. Driving over a curb is like turning on a circuit. And when mechanical engineers study vibrations, they deal with sinusoidal driving functions, but they are dealing with a three dimensional object rather than a one dimensional object like we are in this course.

## Phasor Domain to Time Domain

Getting back into the time domain is just about as simple. After working through the equations in the phasor domain and finding ![\\mathbb{V}](//upload.wikimedia.org/math/9/3/4/934f0e1f6c7bfaf8da7335a074631bec.png) and ![\\mathbb{I}](//upload.wikimedia.org/math/a/4/5/a451c1a8e48f5769fa6eff6e3ee7b862.png), the goal is to convert them to ![V](//upload.wikimedia.org/math/5/2/0/5206560a306a2e085a437fd258eb57ce.png) and ![I](//upload.wikimedia.org/math/d/d/7/dd7536794b63bf90eccfd37f9b147d7f.png).

The phasor solutions will have the form ![\\mathbb{G} = A + Bj = G_m e^{j\\phi}](//upload.wikimedia.org/math/0/4/d/04dd02b779471279ce1128f3c63ad9eb.png) you should be able now to convert between the two forms of the solution. Then:

    ![G = \\operatorname{Re}\(\\mathbb{G} e^{j\\omega t}\)= \\operatorname{Re}\(G_m e^{j\\phi}e^{j\\omega t}\) = \\operatorname{Re}\(G_m e^{j\(\\omega t + \\phi\)}\) = G_m cos\(\\omega t + \\phi\)](//upload.wikimedia.org/math/c/a/e/caec940c12887b688dc042755805614d.png)

If there was an integral involved in the phasor math, then a constant needs to be added onto the time domain solution. The time constant is calculated from the initial conditions. If the solution doesn't involve a differential equation, then time constant is computed immediately. Otherwise the solution is treated as a particular solution and the time constant is computed after the homogeneous solution's magnitude is found. See the [phasor examples](/wiki/Circuit_Theory/Phasors/Examples) for more detail.

## What is not covered

There is another way of thinking about circuits where inductors and capacitors are complex resistances. The idea is:

    

    

    impedance = resistance + j * reactance

Or symbolically

    

    

    ![Z = R + j*X](//upload.wikimedia.org/math/2/f/8/2f84549cacee901fc901bb6c084ceca3.png)

[Here](/wiki/Electronics/Impedance) the derivative is attached to the inductance and capacitance, rather than to the terminal equation as we have done. This spreads the math of solving circuit problems into smaller pieces that is more easily checked, but it makes symbolic solutions more complex and can cause numeric solution errors to accumulate because of intermediate calculations.

The phasor concept is found everywhere. Some day it will be necessary to study this if you get in involved in microwave projects that involve "[stubs](/wiki/Communication_Systems/Microwave_Systems#Microwave_Components)" or antenna projects that involve a "[loading coil](//en.wikipedia.org/wiki/Loading_coil#Radio_antenna)" ... the list is huge.

The goal here is to avoid the concepts of [conductance, reactance, impedance, susceptance, and admittance](//en.wikipedia.org/wiki/Admittance) ... and avoid the the confusion of relating these concepts while trying to compare phasor math with calculus and Laplace transforms.

## Phasor Notation

Remember, a phasor represents a single value that can be displayed in multiple ways.

    ![\\mathbb{C} = M \\angle \\phi](//upload.wikimedia.org/math/3/c/b/3cb5626c71c1df50fb15902c13adbba5.png) "Polar Notation"
    ![C = M e^{j\(\\omega t + \\phi\)}](//upload.wikimedia.org/math/1/e/4/1e468e866e3f193989340c588d15833d.png) "Exponential Notation"
    ![\\mathbb{C} = A + jB](//upload.wikimedia.org/math/c/a/9/ca9e171692faf8e8e82ba834468b2749.png) "Rectangular Notation"
    ![C = M \\cos \(\\omega t + \\phi\) + j M \\sin \(\\omega t + \\phi\)](//upload.wikimedia.org/math/6/2/5/62504bb2e8bc07e25d5297487ea1bd9e.png) "time domain notation"

These 4 notations are all just different ways of writing the same exact thing.

## Phasor symbols

When writing on a board or on paper, use hats ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png) to denote phasors. Expect variations in books and online:

  * ![\\mathbb{V}](//upload.wikimedia.org/math/9/3/4/934f0e1f6c7bfaf8da7335a074631bec.png) (the large bold block-letters we use in this wikibook)
  * ![\\bar{V}](//upload.wikimedia.org/math/4/e/5/4e54d09ea522273fac364fe1ba131ed8.png) ("bar" notation, used by Wikipedia)
  * ![\\vec{V}](//upload.wikimedia.org/math/b/4/0/b403e3d84f97e81a8492025406975d11.png) (bad ... save for vectors ... vector arrow notation)
  * ![\\tilde{V}](//upload.wikimedia.org/math/9/f/2/9f29711fb7045091daf1123847af7d7b.png) (some text books)
  * ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png) (some text books)

# Differential Equations

## Phasors Generate the Particular Solution

Phasors can replace calculus, they can replace Laplace transforms, they can replace trig. But there is one thing they can not do: initial conditions/integration constants. When doing problems with both phasors and Laplace, or phasors and calculus, the difference in the answers is going to be an integration constant.

Differential equations are solved in this course in three steps:

  * finding the particular solution ... particular to the driving function ... particular to the voltage or current source
  * finding the homogenous solution ... the solution that is the same no matter what the driving function is ... the solution that explores how an initial energy imbalance in the circuit is balanced
  * determining the coefficients, the constants of integration from initial conditions

## Phasors Don't Generate Integration Constants

The integration constant doesn't appear in phasor solutions. But they will appear in the Laplace and Calculus alternatives to phasor solutions. If the full differential equation is going to be solved, it is absolutely necessary to see where the phasors fail to create a symbol for the unknown integration constant ... that is calculated in the third step.

Phasors are the technique used to find the particular AC solution. Integration constants document the initial DC bias or energy difference in the circuit. Finding these constants requires first finding the homogeneous solution which deals with the fact that capacitors may or may not be charged when a circuit is first turned on. Phasors don't completely replace the steps of Differential Equations. Phasors just replace the first step: finding the particular solution.

## Differential Equations Review

The goal is to solve Ordinary Differential Equations (ODE) of the first and second order with both phasors, calculus, and Laplace transforms. This way the phasor solution can be compared with content of pre-requiste or co-requiste math courses. The goal is to do these problems with numeric and symbolic tools such as matLab and mupad/mathematica/wolframalpha. If you have already had the differential equations course, this is a quick review.

The most important thing to understand is the nature of a function. Trig, Calculus, and Laplace transforms and phasors are all associated with functions, not algebra. If you don't understand the difference between algebra and a function, maybe this [student professor](/w/index.php?title=Circuit_Theory/All_Chapters/student_professor&action=edit&redlink=1) dialogue will help.

We start with equations from terminal definitions, loops and junctions. Each of the symbols in these algebraic equations is a function. We are not transforming the equations. We are transforming the functions in these equations. All sorts of operators appear in these equations including + - * / and ![\\frac{d}{dt}](//upload.wikimedia.org/math/8/9/f/89f074357e01c5d501c32eefb0e7444a.png). The first table focuses on transforming these operators. The second focuses on transforming the functions themselves.

The real power of the Laplace tranform is that it eliminates the integral and differential operators. Then the functions themselves can be transformed. Then unknowns can be found with just algebra. Then the functions can be transformed back into time domain functions.

Here are some of the [Properties and Theorems](//en.wikipedia.org/wiki/Laplace_transform#Properties_and_theorems) needed to transform the typical sinusolidal voltages, powers and currents in this class.

### Laplace Operator Transforms

Properties of the unilateral Laplace transform

Time domain 's' domain Comment

Time scaling
![f\(at\)](//upload.wikimedia.org/math/d/b/9/db9495cb8c252f4ce9f9f671ef46f785.png)
![ \\frac{1}{|a|} F \\left \( {s \\over a} \\right \)](//upload.wikimedia.org/math/1/e/b/1ebe56412fe53763e6c7c1c7c36a67d7.png)
for figuring out how ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) affects the equation

Time shifting
![ f\(t - a\) u\(t - a\) \\ ](//upload.wikimedia.org/math/1/0/a/10a00bd8ac9a55888ef7be1fe2fda387.png)
![ e^{-as} F\(s\) \\ ](//upload.wikimedia.org/math/2/2/f/22fc9b726798e1c37ea2a5591a820d68.png)
_u_(_t_) is the unit step function .. for figuring out the ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png) phase angle

Linearity
![ a f\(t\) + b g\(t\) \\ ](//upload.wikimedia.org/math/d/f/2/df2830682a5971d4d87303fed7dbc0ea.png)
![ a F\(s\) + b G\(s\) \\ ](//upload.wikimedia.org/math/c/7/a/c7a80b998a228dfec3c427354ee56728.png)
Can be proved using basic rules of integration.

Differentiation
![ f'\(t\) \\ ](//upload.wikimedia.org/math/7/9/d/79df2abee668b5848ffded8bd2426547.png)
![ s F\(s\) - f\(0\) \\ ](//upload.wikimedia.org/math/7/1/0/7109032d339052e71e4a677c804a3358.png)
_f_ is assumed to be a differentiable function, and its derivative is assumed to be of exponential type. This can then be obtained by integration by parts

Integration
![ \\int_0^t f\(\\tau\)\\, d\\tau  =  \(u * f\)\(t\)](//upload.wikimedia.org/math/1/2/d/12d326904ebd5674e988d3ada86b61bf.png)
![ {1 \\over s} F\(s\) ](//upload.wikimedia.org/math/2/1/3/213cb5bab411f6d133857721df7e0d03.png)
a constant pops out at the end of this too

### Laplace Function Transform

Here are some of the [transforms](//en.wikipedia.org/wiki/Laplace_transform#Table_of_selected_Laplace_transforms) needed in this course:

Function Time domain  
![f\(t\) = \\mathcal{L}^{-1} \\left\\{ F\(s\) \\right\\}](//upload.wikimedia.org/math/1/f/e/1fefd08deceab8942f35467945d2e426.png) Laplace s-domain  
![F\(s\) = \\mathcal{L}\\left\\{ f\(t\) \\right\\}](//upload.wikimedia.org/math/e/a/5/ea58badb1eaa86d35e9659d26aa0cd49.png) Region of convergence Reference

exponential decay
![ e^{-\\alpha t} \\cdot u\(t\)  \\ ](//upload.wikimedia.org/math/1/9/1/1919aaa2fef3c5ddb49df3e3471637bc.png)
![ { 1 \\over s+\\alpha } ](//upload.wikimedia.org/math/6/e/8/6e880ff4aad32224561bfdd466699774.png)
Re(_s_) > −α
Frequency shift of  
unit step

exponential approach
![\( 1-e^{-\\alpha t}\)  \\cdot u\(t\)  \\ ](//upload.wikimedia.org/math/7/5/0/75041e853ab9c527869df292b5246876.png)
![\\frac{\\alpha}{s\(s+\\alpha\)} ](//upload.wikimedia.org/math/e/a/e/eaee77a3af02c3f3eede9e7065e08d81.png)
Re(_s_) > 0
Unit step minus  
exponential decay

sine
![ \\sin\(\\omega t\) \\cdot u\(t\) \\ ](//upload.wikimedia.org/math/e/f/1/ef1399eb0d683a1da837fcd9e01a30c8.png)
![ { \\omega \\over s^2 + \\omega^2  } ](//upload.wikimedia.org/math/d/8/8/d887c67f9da1c8bd616b7cf17ab402bb.png)
Re(_s_) > 0

cosine
![ \\cos\(\\omega t\) \\cdot u\(t\) \\ ](//upload.wikimedia.org/math/6/4/d/64d80573adcf47a35cce38377746c409.png)
![ { s \\over s^2 + \\omega^2  } ](//upload.wikimedia.org/math/0/6/2/062e1cbe552e3d25c8db6089828700bd.png)
Re(_s_) > 0

exponentially decaying  
sine wave
![e^{-\\alpha t}  \\sin\(\\omega t\) \\cdot u\(t\) \\ ](//upload.wikimedia.org/math/5/2/0/5206af7452b66757d193150a34550c3e.png)
![ { \\omega \\over \(s+\\alpha \)^2 + \\omega^2  } ](//upload.wikimedia.org/math/a/e/c/aec60733f9248f3314935e649e117441.png)
Re(_s_) > −α

exponentially decaying  
cosine wave
![e^{-\\alpha t}  \\cos\(\\omega t\) \\cdot u\(t\) \\ ](//upload.wikimedia.org/math/7/1/c/71ce8129258b5d8b301092578c36bd37.png)
![ { s+\\alpha \\over \(s+\\alpha \)^2 + \\omega^2  } ](//upload.wikimedia.org/math/7/6/f/76ff02c32e9c46bfb0d5c93b68e47ddf.png)
Re(_s_) > −α

  


# Phasor Circuit Analysis

**[Circuit Theory](/wiki/Circuit_Theory)**

## Phasor Analysis

The mathematical representations of individual circuit elements can be converted into phasor notation, and then the circuit can be solved using phasors.

## Resistance, Impedance and Admittance

In phasor notation, resistance, capacitance, and inductance can all be lumped together into a single term called "impedance". The phasor used for impedance is ![\\mathbb{Z}](//upload.wikimedia.org/math/0/b/1/0b100eeff3848a15dbb46291e7fe52ad.png). The inverse of Impedance is called "Admittance" and is denoted with a ![\\mathbb{Y}](//upload.wikimedia.org/math/e/a/a/eaa0150b987965cf14a856bd04492c61.png). ![\\mathbb{V}](//upload.wikimedia.org/math/9/3/4/934f0e1f6c7bfaf8da7335a074631bec.png) is Voltage and ![\\mathbb{I}](//upload.wikimedia.org/math/a/4/5/a451c1a8e48f5769fa6eff6e3ee7b862.png) is current.

    ![\\mathbb{Z} = \\frac{1}{\\mathbb{Y}}](//upload.wikimedia.org/math/b/6/5/b65a304e3a71153da30b0ff4cc26dd71.png)

And the Ohm's law for phasors becomes:

    ![\\mathbb{V} = \\mathbb{Z} \\mathbb{I} = \\frac{\\mathbb{I}}{\\mathbb{Y}}](//upload.wikimedia.org/math/7/f/b/7fb929b913dcd634994cb87be2db1623.png)

It is important to note at this point that _Ohm's Law still holds true_ even when we switch from the time domain to the phasor domain. This is made all the more amazing by the fact that the new term, impedance, is no longer a property only of resistors, but now encompasses all load elements on a circuit (capacitors and inductors too!).

Impedance is still measured in units of Ohms, and admittance (like Conductance, its DC-counterpart) is still measured in units of Siemens.

Let's take a closer look at this equation:

  


[Ohm's Law with Phasors]

    ![\\mathbb{V} = \\mathbb{Z} \\mathbb{I}](//upload.wikimedia.org/math/e/7/4/e74f4f24f88549a22699e6871f64a970.png)

If we break this up into polar notation, we get the following result:

    ![M_V \\angle \\phi_V = \(M_Z \\times M_I\) \\angle \(\\phi_Z + \\phi_I\)](//upload.wikimedia.org/math/4/f/c/4fc2d2812099fbce333d1c3411d31b00.png)

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Electrical impedance**_](//en.wikipedia.org/wiki/Electrical_impedance)

This is important, because it shows that not only are the magnitude values of voltage and current related to each other, but also the phase angle of their respective waves are also related. Different circuit elements will have different effects on both the magnitude and the phase angle of the voltage given a certain current. We will explore those relationships below.

## Resistors

Resistors do not affect the phase of the voltage or current, only the magnitude. Therefore, the impedance of a resistor with resistance R is:

  


[Resistor Impedance]

    ![\\mathbb{Z} = R \\angle 0](//upload.wikimedia.org/math/e/5/8/e58b6be0bac9ad8e742a5d3fa648e723.png)

Through a resistor, the phase difference between current and voltage will not change. This is important to remember when analyzing circuits.

## Capacitors

A capacitor with a capacitance of C has a phasor value:

  


[Capacitor Impedance]

    ![\\mathbb{Z} = C \\angle \\left\(-\\frac{\\pi}{2}\\right\)](//upload.wikimedia.org/math/0/2/3/02393191caa060933317f26a356c33a4.png)

To write this in terms of degrees, we can say:

    ![\\mathbb{Z} = C \\angle \(-90^{\\circ}\)](//upload.wikimedia.org/math/a/8/2/a82abe1822e6038e58f8c3a0752f46c7.png)

We can accept this for now as being axiomatic. If we consider the fact that phasors can be graphed on the imaginary plane, we can easily see that the angle of ![-\\pi/2](//upload.wikimedia.org/math/7/2/e/72e954820cf96e8e14449e653db9862a.png) points directly downward, along the negative imaginary axis. We then come to an important conclusion: The impedance of a capacitor is _imaginary_, in a sense. Since the angle follows directly along the imaginary axis, there is no real part to the phasor at all. Because there is no real part to the impedance, we can see that capacitors have no resistance (because resistance is a real value, as stated above).

### Reactance

A capacitor with a capacitance of C in an AC circuit with an angular velocity ![ \\omega ](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) has a reactance given by

![\\mathbb{X} = \\frac {1}{\\omega C} \\angle \(-90^{\\circ}\)](//upload.wikimedia.org/math/1/7/f/17fd802ddbe50e86cd0f91e496842bff.png)

Reactance is the impedance specific to an AC circuit with angular velocity ![ \\omega ](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png).

## Inductors

Inductors have a phasor value:

  


[Inductor Impedance]

    ![\\mathbb{Z} = L \\angle \\left\(\\frac{\\pi}{2}\\right\)](//upload.wikimedia.org/math/0/b/b/0bb87087a59044380e82d9349094e83e.png)

Where L is the inductance of the inductor. We can also write this using degrees:

    ![\\mathbb{Z} = L \\angle \(90^\\circ\)](//upload.wikimedia.org/math/3/5/0/350bd196648defc80f104d4de244fb05.png)

Like capacitors, we can see that the phasor for inductor shows that the value of the impedance is located directly on the imaginary axis. However, the phasor value for inductance points in exactly the opposite direction from the capacitance phasor. We notice here also that inductors have no resistance, because the resistance is a real value, and inductors have only an imaginary value.

### Reactance

In an AC circuit with a source angular velocity of ![ \\omega ](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png), and inductor with inductance L.

![\\mathbb{X} = \\omega L \\angle \(90^\\circ\)](//upload.wikimedia.org/math/c/0/8/c08afbed2bf114126b045829a1d92266.png)

## Impedances Connected in Series

If there are several impedances connected in series, the equivalent impedance is simply a sum of the impedance values:
    
    
    ----[ Z1 ]----[ Z2 ]--- ... ---[ Zn ]---   ==> ---[ Zseries ]---
    

  


[Impedances in Series]

    ![\\sum_{series} \\mathbb{Z}_n = \\mathbb{Z}_{series}](//upload.wikimedia.org/math/7/2/a/72aa8d5d31b3aa297aa6508967111558.png)

Notice how much easier this is than having to differentiate between the formulas for combining capacitors, resistors, and inductors in series. Notice also that resistors, capacitors, and inductors can all be mixed without caring which type of element they are. This is valuable, because we can now combine different elements into a single impedance value, as opposed to different values of inductance, capacitance, and resistance.

Keep in mind however, that phasors need to be converted to rectangular coordinates before they can be added together. If you know the formulas, you can write a small computer program, or even a small application on a programmable calculator to make the conversion for you.

## Impedances in Parallel

Impedances connected in parallel can be combined in a slightly more complicated process:

  


[Impedances in Parallel]

    ![\\mathbb{Z}_{parallel} = \\frac{\\prod_N Z_n}{\\sum_N Z_n}](//upload.wikimedia.org/math/b/f/6/bf6140e3897ada348083739a889d2299.png)

Where N is the total number of impedances connected in parallel with each other. Impedances may be multiplied in the polar representation, but they must be converted to rectangular coordinates for the summation. This calculation can be a little bit time consuming, but when you consider the alternative (having to deal with each type of element separately), we can see that this is much easier.

## Steps For Solving a Circuit With Phasors

There are a few general steps for solving a circuit with phasors:

  1. Convert all elements to phasor notation
  2. Combine impedances, if possible
  3. Combine Sources, if possible
  4. Use Ohm's Law, and Kirchoff's laws to solve the circuit
  5. Convert back into time-domain representation

Unfortunately, phasors can only be used with sinusoidal input functions. We cannot employ phasors when examining a DC circuit, nor can we employ phasors when our input function is any non-sinusoidal periodic function. To handle these cases, we will look at more general methods in later chapters

## Network Function

The network function is a phasor, ![\\mathbb{H}](//upload.wikimedia.org/math/8/a/9/8a90e649fb19a02082ed9f8023a626ab.png) that is a ratio of the circuit's input to its output. This is important, because if we can solve a circuit down to find the network function, we can find the response to _any_ sinusoidal input, by simply multiplying by the network function. With time-domain analysis, we would have to solve the circuit for every new input, and this would be very time consuming indeed.

Network functions are defined in the following way:

  


[Network Function]

    ![\\mathbb{H} = \\frac{\\mathbb{Y}}{\\mathbb{X}}](//upload.wikimedia.org/math/a/7/f/a7fec18df366ca6c42b6b284f2e45090.png)

Where ![\\mathbb{Y}](//upload.wikimedia.org/math/e/a/a/eaa0150b987965cf14a856bd04492c61.png) is the phasor representation of the circuit's output, and ![\\mathbb{X}](//upload.wikimedia.org/math/9/5/f/95fff02452dd9ea258d284d5412a8daf.png) is the representation of the circuit's input. In the time domain, to find the output, we would need to convolute the input with the impulse response. With the network function, however, it becomes a simple matter of multiplying the input phasor with the network function, to get the output phasor. Using this method, we have converted an entire circuit to become a simple function that changes magnitude and phase angle.

## Gain

Gain is the amount by which the magnitude of the sinusoid is amplified or attenuated by the circuit. Gain can be computed from the Network function as such:

  


[Gain]

    ![Gain = \\left| \\mathbb{H}\(\\omega\) \\right| 
           = \\frac{\\left| \\mathbb{Y}\(\\omega\) \\right|}{\\left| \\mathbb{X}\(\\omega\) \\right|}
](//upload.wikimedia.org/math/a/6/2/a62143232dcadd7da803310f59d0c8ab.png)

Where the bars around the phasors are the "magnitude" of the phasor, and not the "absolute value" as they are in other math texts. Again, gain may be a measure of the magnitude change in either current or voltage. Most frequently, however, it is used to describe voltage.

## Phase Shift

The phase shift of a function is the amount of phase change between the input signal and the output signal. This can be calculated from the network function as such:

  


[Phase Shift]

    ![\\angle \\mathbb{H}\(\\omega\) = \\angle \\mathbb{Y}\(\\omega\) - \\angle \\mathbb{X}\(\\omega\)](//upload.wikimedia.org/math/3/3/1/331dcf38de476f062f65edcc1e7fb7a3.png)

Where the ![\\angle](//upload.wikimedia.org/math/c/5/8/c58f5b6977cb475bd9ae57cb9674d324.png) denotes the phase of the phasor.

Again, the phase change may represent current or voltage.  


# Phasor Theorems

**[Circuit Theory](/wiki/Circuit_Theory)**

## Circuit Theorems

Phasors would be absolutely useless if they didn't make the analysis of a circuit easier. Luckily for us, all our old circuit analysis tools work with values in the phasor domain. Here is a quick list of tools that we have already discussed, that continue to work with phasors:

  * Ohm's Law
  * Kirchoff's Laws
  * Superposition
  * Thevenin and Norton Sources
  * Maximum Power Transfer

This page will describe how to use some of the tools we discussed for DC circuits in an AC circuit using phasors.

## Ohm's Law

Ohm's law, as we have already seen, becomes the following equation when in the phasor domain:

    ![\\mathbb{V} = \\mathbb{Z} \\mathbb{I}](//upload.wikimedia.org/math/e/7/4/e74f4f24f88549a22699e6871f64a970.png)

Separating this out, we get:

    ![M_V \\angle \\phi_V = \(M_Z \\times M_I\) \\angle \(\\phi_Z + \\phi_I\)](//upload.wikimedia.org/math/4/f/c/4fc2d2812099fbce333d1c3411d31b00.png)

Where we can clearly see the magnitude and phase relationships between the current, the impedance, and the voltage phasors.

## Kirchoff's Laws

Kirchoff's laws still hold true in phasors, with no alterations.

### Kirchoff's Current Law

Kirchoff's current law states that the amount of current entering a particular node must equal the amount of current leaving that node. Notice that KCL never specifies what form the current must be in: any type of current works, and KCL always holds true.

  


[KCL With Phasors]

    ![\\sum_n \\mathbb{I}_n = 0](//upload.wikimedia.org/math/7/b/6/7b67a4c1988f3acd82070e6a178d02f9.png)

### Kirchoff's Voltage Law

KVL states: The sum of the voltages around a closed loop must always equal zero. Again, the form of the voltage forcing function is never considered: KVL holds true for any input function.

  


[KVL With Phasors]

    ![\\sum_n \\mathbb{V}_n = 0](//upload.wikimedia.org/math/d/8/2/d821bc9cee966a858c0c6c4cef9778f9.png)

## Superposition

Superposition may be applied to a circuit if all the sources have the same frequency. However, superposition _must_ be used as the only possible method to solve a circuit with sources that have different frequencies. The important part to remember is that impedance values in a circuit are based on the frequency. Different reactive elements react to different frequencies differently. Therefore, the circuit must be solved once for every source frequency. This can be a long process, but it is the only good method to solve these circuits.

## Thevenin and Norton Circuits

Thevenin Circuits and Norton Circuits can be manipulated in a similar manner to their DC counterparts: Using the phasor-domain implementation of Ohm's Law.

    ![\\mathbb{V} = \\mathbb{Z}\\mathbb{I}](//upload.wikimedia.org/math/e/7/4/e74f4f24f88549a22699e6871f64a970.png)

It is important to remember that the ![\\mathbb{Z}](//upload.wikimedia.org/math/0/b/1/0b100eeff3848a15dbb46291e7fe52ad.png) does not change in the calculations, although the phase and the magnitude of both the current and the voltage sources might change as a result of the calculation.

## Maximum Power Transfer

The maximum power transfer theorem in phasors is slightly different then the theorem for DC circuits. To obtain maximum power transfer from a thevenin source to a load, the internal thevenin impedance (![\\mathbb{Z}_t](//upload.wikimedia.org/math/9/1/1/9114bc42fef7c46b2fe7d89ab6b814e3.png)) must be the complex conjugate of the load impedance (![\\mathbb{Z}_l](//upload.wikimedia.org/math/c/7/7/c77d56e2f9e685c1243165ce15549cc1.png)):

  


[Maximum Power Transfer, with Phasors]

    ![\\mathbb{Z}_l = R_t - jX_t](//upload.wikimedia.org/math/e/5/3/e53a1d1adf8f041876f31b65e2001a18.png)

  


# Complex Power

[Circuit Theory/Complex Power](/w/index.php?title=Circuit_Theory/Complex_Power&action=edit&redlink=1)

  


The Laplace Transform

The Laplace Transform is a useful tool borrowed from mathematics to quickly and easily analyze systems that are represented by high-order linear differential equations. The Fourier Transform, which is closely related, can also provide us with insight about the frequency response characteristics of a system.

**[Circuit Theory](/wiki/Circuit_Theory)**

![Warning icon WikiBooks.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Warning_icon_WikiBooks.svg/35px-Warning_icon_WikiBooks.svg.png)

This book contains mathematical formulae that look better **[rendered as PNG](/wiki/Wikibooks:Render_as_PNG)**.

  


## Laplace Transform

The **Laplace Transform** is a powerful tool that is very useful in Electrical Engineering. The transform allows equations in the "time domain" to be transformed into an equivalent equation in the **Complex S Domain**. The laplace transform is an integral transform, although the reader does not need to have a knowledge of integral calculus because all results will be provided. This page will discuss the Laplace transform as being simply a tool for solving and manipulating ordinary differential equations.

Laplace transformations of circuit elements are similar to phasor representations, but they are not the same. Laplace transformations are more general than phasors, and can be easier to use in some instances. Also, do not confuse the term "Complex S Domain" with the complex power ideas that we have been talking about earlier. Complex power uses the variable ![\\mathbb{S}](//upload.wikimedia.org/math/c/d/0/cd0e78da53c1192a9cc230ca222b8f16.png), while the Laplace transform uses the variable s. The Laplace variable s has nothing to do with power.

The transform is named after the mathematician **Pierre Simon Laplace** (1749-1827). The transform itself did not become popular until Oliver Heaviside, a famous electrical engineer, began using a variation of it to solve electrical circuits.

  


## Laplace Domain

The **Laplace domain**, or the "Complex s Domain" is the domain into which the Laplace transform transforms a time-domain equation. s is a complex variable, composed of real and imaginary parts:

    ![s = \\sigma + j\\omega](//upload.wikimedia.org/math/7/a/d/7addd3c9d3736265ecd7dbea420b1190.png)

The Laplace domain graphs the real part (σ) as the horizontal axis, and the imaginary part (ω) as the vertical axis. The real and imaginary parts of s can be considered as independent quantities.

The similarity of this notation with the notation used in Fourier transform theory is no coincidence; for ![\\sigma=0](//upload.wikimedia.org/math/8/7/c/87c24f9fc08ae35a5477f440b0b615c9.png), the Laplace transform is the same as the Fourier transform if the signal is causal.

## The Transform

The mathematical definition of the Laplace transform is as follows:

  


[The Laplace Transform]

    ![F\(s\) 
  = \\mathcal{L} \\left\\{f\(t\)\\right\\}
  = \\int_{0^-}^\\infty e^{-st} f\(t\)\\,dt](//upload.wikimedia.org/math/e/e/0/ee02fa8c0f1e7cfcd47909a3a8673b6f.png)

**Note:**  
The letter **s** has no special significance, and is used with the Laplace Transform as a matter of common convention.

The transform, by virtue of the definite integral, removes all t from the resulting equation, leaving instead the new variable s, a complex number that is normally written as ![s=\\sigma+j\\omega](//upload.wikimedia.org/math/7/a/d/7addd3c9d3736265ecd7dbea420b1190.png). In essence, this transform takes the function f(t), and "transforms it" into a function in terms of s, F(s). As a general rule the transform of a function f(t) is written as F(s). Time-domain functions are written in lower-case, and the resultant s-domain functions are written in upper-case.

There is a table of Laplace Transform pairs in  
**[the Appendix](/w/index.php?title=Circuit_Theory/Transform_Tables&action=edit&redlink=1)**

we will use the following notation to show the transform of a function:

    ![f\(t\) \\Leftrightarrow F\(s\)](//upload.wikimedia.org/math/1/b/7/1b770694694da5bf1e853ee082f17425.png)

We use this notation, because we can convert F(s) back into f(t) using the **inverse Laplace transform**.

## The Inverse Transform

The **inverse laplace transform** converts a function in the complex S-domain to its counterpart in the time-domain. Its mathematical definition is as follows:

  


[Inverse Laplace Transform]

    ![ 
\\mathcal{L}^{-1} \\left\\{F\(s\)\\right\\}
  = {1 \\over {2\\pi}}\\int_{c-i\\infty}^{c+i\\infty} e^{ft} F\(s\)\\,ds = f\(t\)](//upload.wikimedia.org/math/7/f/7/7f7e6a58c1845a0fda59a239053802b4.png)

where ![c](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png) is a real constant such that all of the poles ![s_1,s_2,...,s_n](//upload.wikimedia.org/math/e/5/a/e5a32099b1b203c48315712e2b4c6489.png) of ![F\(s\)](//upload.wikimedia.org/math/2/f/8/2f8669b6af152741e8f084706d157e86.png) fall in the region ![\\mathfrak{R}\\{s_i\\} < c](//upload.wikimedia.org/math/6/7/c/67cc219572e3d09ea81a69bcc06c268d.png). In other words, ![c](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png) is chosen so that all of the poles of ![F\(s\)](//upload.wikimedia.org/math/2/f/8/2f8669b6af152741e8f084706d157e86.png) are to the left of the vertical line intersecting the real axis at ![s=c](//upload.wikimedia.org/math/3/2/8/328b4a37f28f5b445b490f4161569418.png).

The inverse transform is more difficult mathematically than the transform itself is. However, luckily for us, extensive tables of laplace transforms and their inverses have been computed, and are available for easy browsing.

## Transform Properties

There is a table of Laplace Transform properties in  
**[The Appendix](/w/index.php?title=Circuit_Theory/Transform_Tables&action=edit&redlink=1)**

The most important property of the Laplace Transform (for now) is as follows:

    ![\\mathcal{L} \\left\\{ f'\(t\) \\right\\} = sF\(s\) - f\(0\)](//upload.wikimedia.org/math/7/4/e/74e84b624c18c7b88d4ec42d0820ad2e.png)

Likewise, we can express higher-order derivatives in a similar manner:

    ![\\mathcal{L} \\left\\{f''\(t\)\\right\\} = s^2F\(s\) - s f\(0\) - f'\(0\) ](//upload.wikimedia.org/math/d/2/a/d2a0d19b0aa79d034238819bfad225bb.png)

Or for an arbitrary derivative:

    ![\\mathcal{L} \\left\\{f^{\(n\)}\(t\)\\right\\} = s^nF\(s\) - \\sum_{i=0}^{n-1} s^{\(n-1-i\)} f^{\(i\)}\(0\) ](//upload.wikimedia.org/math/5/e/8/5e8fa452f813675d3cd1e212228d9b7e.png)

where the notation ![ f^{\(n\)}\(t\) ](//upload.wikimedia.org/math/4/f/7/4f76ffee56df890f2461ed2b5f83c8d6.png) means the nth derivative of the function ![ f ](//upload.wikimedia.org/math/8/f/a/8fa14cdd754f91cc6554c9e71929cce7.png) at the point ![ t ](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png), and ![ f^{\(0\)}\(t\) ](//upload.wikimedia.org/math/a/e/a/aea850ccd74851ae5c64c7774affd446.png) means ![ f\(t\) ](//upload.wikimedia.org/math/d/6/e/d6e3af948a34fd5f432cb9d377a98ef0.png).

In plain English, the laplace transform converts differentiation into polynomials. The only important thing to remember is that we must add in the initial conditions of the time domain function, but for most circuits, the initial condition is 0, leaving us with nothing to add.

For integrals, we get the following:

    ![\\mathcal{L}\\left\\{ \\int_0^t f\(t\)\\, dt \\right\\} = {1 \\over s}F\(s\)](//upload.wikimedia.org/math/0/7/4/0744d966ceb147fccc62135621bd0ed4.png)

## Initial Value Theorem

The **Initial Value Theorem** of the laplace transform states as follows:

  


[Initial Value Theorem]

    ![f\(0\) \\Leftrightarrow \\lim_{s \\to \\infty} sF\(s\)](//upload.wikimedia.org/math/5/5/5/555e90e7055505ecdaf041b4b0534680.png)

This is useful for finding the initial conditions of a function needed when we perform the transform of a differentiation operation (see above).

## Final Value Theorem

Similar to the Initial Value Theorem, the **Final Value Theorem** states that we can find the value of a function f, as t approaches infinity, in the laplace domain, as such:

  


[Final Value Theorem]

    ![\\lim_{t \\to \\infty} f\(t\) \\Leftrightarrow \\lim_{s \\to 0} sF\(s\)](//upload.wikimedia.org/math/8/1/d/81d96b6b429715ffd1f8b968765b35cc.png)

This is useful for finding the steady state response of a circuit. The final value theorem may only be applied to stable systems.

## Transfer Function

If we have a circuit with impulse-response h(t) in the time domain, with input x(t) and output y(t), we can find the **Transfer Function** of the circuit, in the laplace domain, by transforming all three elements:

![LTI.png](//upload.wikimedia.org/wikipedia/commons/thumb/f/f5/LTI.png/500px-LTI.png)

In this situation, H(s) is known as the "Transfer Function" of the circuit. It can be defined as both the transform of the impulse response, or the ratio of the circuit output to its input in the Laplace domain:

  


[Transfer Function]

    ![H\(s\) = \\mathcal{L} \\left\\{h\(t\) \\right\\} = \\frac{Y\(s\)}{X\(s\)}](//upload.wikimedia.org/math/0/5/2/052726eeb0d934ac4b1fe3a42a0ed7ac.png)

Transfer functions are powerful tools for analyzing circuits. If we know the transfer function of a circuit, we have all the information we need to understand the circuit, and we have it in a form that is easy to work with. When we have obtained the transfer function, we can say that the circuit has been "solved" completely.

## Convolution Theorem

Earlier it was mentioned that we could compute the output of a system from the input and the impulse response by using the convolution operation. As a reminder, given the following system:

![System Block.svg](//upload.wikimedia.org/wikibooks/en/thumb/8/88/System_Block.svg/400px-System_Block.svg.png)

  * _x(t)_ = **system input**
  * _h(t)_ = **impulse response**
  * _y(t)_ = **system output**

We can calculate the output using the convolution operation, as such:

    ![y\(t\) = x\(t\) * h\(t\)](//upload.wikimedia.org/math/2/3/3/233c5ed232f461bcbe3b2d8cebc2030b.png)

Where the asterisk denotes convolution, not multiplication. However, in the S domain, this operation becomes much easier, because of a property of the laplace transform:

  


[Convolution Theorem]

    ![\\mathcal{L} \\left\\{ a\(t\) * b\(t\) \\right\\} = A\(s\)B\(s\)](//upload.wikimedia.org/math/8/7/3/87308b83039e1e7547e0fb0f5133eed8.png)

Where the asterisk operator denotes the convolution operation. This leads us to an English statement of the convolution theorem:

Convolution in the time domain becomes multiplication in the S domain, and convolution in the S domain becomes multiplication in the time domain.[1]

Now, if we have a system in the Laplace S domain:

![Laplace Block.svg](//upload.wikimedia.org/wikibooks/en/thumb/4/47/Laplace_Block.svg/349px-Laplace_Block.svg.png)

  * _X(s)_ = **Input**
  * _H(s)_ = **Transfer Function**
  * _Y(s)_ = **Output**

We can compute the output Y(s) from the input X(s) and the Transfer Function H(s):

    ![Y\(s\) = X\(s\)H\(s\)](//upload.wikimedia.org/math/e/9/b/e9b598b8a0687e5a86b167455e9a0747.png)

Notice that this property is very similar to phasors, where the output can be determined by multiplying the input by the network function. The network function and the transfer function then, are very similar quantities.

## Resistors

The laplace transform can be used independently on different circuit elements, and then the circuit can be solved entirely in the S Domain (Which is much easier). Let's take a look at some of the circuit elements:

Resistors are time and frequency invariant. Therefore, the transform of a resistor is the same as the resistance of the resistor:

  


[Transform of Resistors]

    ![R\(s\) = r](//upload.wikimedia.org/math/6/1/4/61454fde6e6aed5a919e3ad3b37cc8b9.png)

Compare this result to the phasor impedance value for a resistance r:

    ![Z_r = r \\angle 0](//upload.wikimedia.org/math/f/c/1/fc17c7655b126de79c9825c61f4b6a9e.png)

You can see very quickly that resistance values are very similar between phasors and laplace transforms.

## Ohm's Law

If we transform Ohm's law, we get the following equation:

  


[Transform of Ohm's Law]

    ![V\(s\) = I\(s\)R](//upload.wikimedia.org/math/8/8/a/88aae91638e5c4009e277c2cbe274247.png)

Now, following ohms law, the resistance of the circuit element is a ratio of the voltage to the current. So, we will solve for the quantity ![\\frac{V\(s\)}{I\(s\)}](//upload.wikimedia.org/math/2/2/a/22aeca532c0915f69621b41e34e2d00f.png), and the result will be the resistance of our circuit element:

    ![R = \\frac{V\(s\)}{I\(s\)}](//upload.wikimedia.org/math/1/0/b/10b256f5cc0c19c226707fe253ec4722.png)

This ratio, the input/output ratio of our resistor is an important quantity, and we will find this quantity for all of our circuit elements. We can say that the transform of a resistor with resistance r is given by:

  


[Tranform of Resistor]

    ![\\mathcal{L}\\{resistor\\} = R = r](//upload.wikimedia.org/math/7/f/e/7fe5b0ab60b83b75ca84044df309e663.png)

## Capacitors

Let us look at the relationship between voltage, current, and capacitance, in the time domain:

    ![i\(t\) = C\\frac{dv\(t\)}{dt}](//upload.wikimedia.org/math/1/b/f/1bfd4157c546f25151e09a580d7689cc.png)

Solving for voltage, we get the following integral:

    ![v\(t\) = \\frac{1}{C}\\int_{t_0}^{\\infty} i\(t\)dt](//upload.wikimedia.org/math/1/0/9/109b128b222dec33934306318e38368a.png)

Then, transforming this equation into the laplace domain, we get the following:

    ![V\(s\) = \\frac{1}{C} \\frac{1}{s} I\(s\)](//upload.wikimedia.org/math/5/b/7/5b727a6816f64c388709407bf294e6e7.png)

Again, if we solve for the ratio ![\\frac{V\(s\)}{I\(s\)}](//upload.wikimedia.org/math/2/2/a/22aeca532c0915f69621b41e34e2d00f.png), we get the following:

    ![\\frac{V\(s\)}{I\(s\)} = \\frac{1}{sC}](//upload.wikimedia.org/math/7/b/b/7bbf6ae11b57dcb60f7ff11dd60f5254.png)

Therefore, the transform for a capacitor with capacitance C is given by:

  


[Transform of Capacitor]

    ![\\mathcal{L}\\{\\mbox{capacitor}\\} = \\frac{1}{sC}](//upload.wikimedia.org/math/b/b/a/bba2bf508e31b61cb8e844504e49399a.png)

## Inductors

Let us look at our equation for inductance:

    ![v\(t\) = L \\frac{di\(t\)}{dt}](//upload.wikimedia.org/math/f/c/1/fc19a7ce96062fa21fb5df3841456089.png)

putting this into the laplace domain, we get the formula:

    ![V\(s\) = sLI\(s\)](//upload.wikimedia.org/math/c/9/0/c900fd2c8f4bdfb72e62059ca4e8f344.png)

And solving for our ratio ![\\frac{V\(s\)}{I\(s\)}](//upload.wikimedia.org/math/2/2/a/22aeca532c0915f69621b41e34e2d00f.png), we get the following:

    ![\\frac{V\(s\)}{I\(s\)} = sL](//upload.wikimedia.org/math/c/a/0/ca03b9315a064b58aeb6f90569977d53.png)

Therefore, the transform of an inductor with inductance L is given by:

  


[Transform of Inductor]

    ![\\mathcal{L}\\{Inductor\\} = sL](//upload.wikimedia.org/math/1/3/e/13eb9561cb9f7b2e06cabcff39071bef.png)

## Impedance

Since all the load elements can be combined into a single format dependent on s, we call the effect of all load elements **impedance**, the same as we call it in phasor representation. We denote impedance values with a capital Z (but not a phasor ![\\mathbb{Z}](//upload.wikimedia.org/math/0/b/1/0b100eeff3848a15dbb46291e7fe52ad.png)).

  


## Determining electric current in circuits

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Electric_circuit_RCL.jpg/220px-Electric_circuit_RCL.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

RCL circuit with zero capacitance and zero initial current.

In the network shown, determine the character of the currents ![I_1\(t\)](//upload.wikimedia.org/math/6/2/d/62d079b61dad38e2f1ff1feaf2b0ef64.png), ![I_2\(t\)](//upload.wikimedia.org/math/c/a/c/cacb2c8568b8c6a40b8fe0eaaaa5d4bd.png), and ![I_3\(t\)](//upload.wikimedia.org/math/6/3/8/6388a6bcb84fd436e839cbb235183a03.png) assuming that each current is zero when the switch is closed.

### Solution[2]

#### Current flow at a joint in circuit

Since the algebraic sum of the currents at any junction is zero, then

![ I_1\(t\)-I_2\(t\)-I_3\(t\) = 0 ](//upload.wikimedia.org/math/4/9/c/49c063047435876e2fa9d77c2d694c43.png).........(182)

#### Voltage balance on a circuit

Applying the voltage law to the circuit on the left we get

![ I_1\(t\)R_1 + L_2 \\frac{dI_2\(t\)}{dt}\\ =E\(t\) ](//upload.wikimedia.org/math/c/7/3/c73b0d70de91556af92864f170b047c0.png)......... (182-1)

Applying again the voltage law to the outside circuit, given that E is constant, we get

![ I_1\(t\)R_1+I_3\(t\)R_3 + L_3 \\frac{dI_3\(t\)}{dt}\\ =E\(t\) ](//upload.wikimedia.org/math/c/d/0/cd0c008ef8b264e6a178f6da4725f1cb.png)......... (182-2)

#### Laplace Transforms of current and voltage equations

Transforming (182), (182-1) and (182-2), we get

![ i_1\(s\)-i_2\(s\)-i_3\(s\)=0](//upload.wikimedia.org/math/0/1/7/0173348ab64f6ed4f1cd568a37515218.png).........(182-3)

![ i_1\(s\)R_1 +sL_2i_2\(s\)=\\frac{E}{s}\\ ](//upload.wikimedia.org/math/e/9/b/e9b58726ef35b9238d43022626f3dea0.png)......... (182-4)

![ i_1\(s\)R_1 +\( R_3 + sL_3 \) i_3\(s\)= \\frac{E}{s}\\ ](//upload.wikimedia.org/math/a/7/8/a78ed7aad1291fbabef296d4eae8aac0.png) ......... (182-5)

##### Review on implementing Laplace Transformation

The three Laplace transformed equations (182-3), (182-4), and (182-5) show the [benefits of integral transformation in converting differential equations](http://www.amazon.com/Advanced-Mathematics-Personal-Study-Notes/dp/1461084423/ref=tmm_pap_title_0?ie=UTF8&qid=1366661958&sr=8-1) into linear algebraic equations that could be solved for the dependent variables (the three currents in this case), then inverse transformed to yield the required solution.

  * In equation (182-3), we utilized the _sum property_ of Laplace transforms.
  * In equation (182-4), we utilized the transform of _differential derivative_ as follows.

![ si_2\(s\)-I_2\(0\)= \\mathcal{L}\\left\\lbrace\\frac {dI_2}{dt}\\right\\rbrace ](//upload.wikimedia.org/math/f/6/4/f641407470a7c235810a583db69a7c2d.png).........(182-4.1)

Since, substituted by the given initial condition: ![ I_2\(0\)=0](//upload.wikimedia.org/math/1/5/d/15d43581d9af5dad578d57c7fde76839.png)

  * In equation (182-5), we also utilized the transform of differential derivative

![ si_3\(s\)-I_3\(0\)= \\mathcal{L}\\left\\lbrace\\frac {dI_3}{dt}\\right\\rbrace ](//upload.wikimedia.org/math/5/a/a/5aa1865ad30eebfde586698ab1d9ee24.png).........(182-5.2)

Again, we substituted by the given initial condition: ![ I_3\(0\)=0](//upload.wikimedia.org/math/6/7/7/6775dd1e32ab976e1a4580be556b5101.png)

The fact that the applied voltage was constant, implied the use of Laplace transform of constant, as follows:

![ \\frac {E}{s}= \\mathcal{L}\\left\\lbrace E \\right\\rbrace ](//upload.wikimedia.org/math/4/f/f/4ff6534cb89ab4b281691f5aa713b390.png).........(182-5.3)

  


#### Solution linear simultaneous equations

The three linear simultaneous equations (182-3), (182-4), and (182-5) have the three unknown ![i_1\(s\)](//upload.wikimedia.org/math/c/5/e/c5e34a7414d554f3c282caa75a27b621.png), ![i_2\(s\)](//upload.wikimedia.org/math/a/6/7/a67fbf032b9d8ce5cf8bab71f69c61ed.png), and ![i_3\(s\)](//upload.wikimedia.org/math/4/d/f/4dfe73548d9a1c38e6ab11d040ab9070.png) and can be solved by Cramer’s rule of matrices among other simple methods of elimination, as follows.

  
![ i_1\(s\) = \\frac{ \\begin{vmatrix}
0 & -1 & -1 \\\\
\\frac{E}{s}\\  & sL_2 & 0 \\\\
\\frac{E}{s}\\ & 0 &R_3 + sL_3 \\\\
\\end{vmatrix}}{ \\Delta}= \\frac{E}{s}\\frac{R_3+s\(L_2+L_3\)}{\\Delta}
](//upload.wikimedia.org/math/d/8/a/d8ab4bd17f528a304658efd38bc5604f.png) ......... (182-6)

Where, the determinant ∆ for the matrix is determined as follows

![ \\Delta = \\begin{vmatrix}
1 & -1 & -1 \\\\
R_1  & sL_2 & 0 \\\\
R_1 & 0 &R_3 + sL_3 \\\\
\\end{vmatrix} = \\begin{vmatrix}
1 & 0 & 0 \\\\
R_1  & sL_2+R_1 & R_1 \\\\
R_1 & R_1 & R_1+R_3 + sL_3 \\\\
\\end{vmatrix} ](//upload.wikimedia.org/math/3/9/3/3935d7b44941c1b7e8af3275fd10bec0.png)

  
![ \\Delta = s^2L_2L_3+s\(R_1L_2+R_3L_2 +R_1R_3\)+R_1R_3](//upload.wikimedia.org/math/1/f/d/1fdefcb5fad17c4a2b86f2fc468fc211.png)......... (182-6.1)

Since we are interested in the factors of Δ, we consider the equation Δ =0. Since all coefficients of this equation are positive, hence it cannot have any positive roots. Its discriminant is

![\(R_1L_2+R_3L_2 +R_1R_3\)^2-4L_2L_3R_1R_3](//upload.wikimedia.org/math/8/0/4/804031b9e9196e6c0f9718eca2c63be4.png) ........ (182-6.1.1)

  
which can be written

    ![R^2_1L^2_2+2R_1L_2\(R_3L_2+R_1L_3\)+\(R_3L_2-R_1L_3\)^2](//upload.wikimedia.org/math/7/9/a/79ab566a4ec6fb1b6ac36aba171284be.png)........ (182-6.1.2)

  


which is positive. Hence the equation Δ = 0 has two negative distinct roots ![-\\alpha_1](//upload.wikimedia.org/math/3/0/0/3000706d466cea2228c70b0195fef0fc.png) and ![-\\alpha_2](//upload.wikimedia.org/math/0/d/6/0d61de84904b307bfd4b337bec49467b.png), say.

Therefore,

![\\Delta = L_2L_3\(s+\\alpha_1\)\(s+\\alpha_2\)](//upload.wikimedia.org/math/1/1/c/11c6ac3bfab9256e1cdc99d3c34c3809.png) ......... (182-6.2)

  


Where,![-\\alpha_1](//upload.wikimedia.org/math/3/0/0/3000706d466cea2228c70b0195fef0fc.png) and ![-\\alpha_2](//upload.wikimedia.org/math/0/d/6/0d61de84904b307bfd4b337bec49467b.png) are the roots of the quadratic equation (182-6.1) as follows

  


![\\alpha_1=\\frac{1}{2}\\left\\lbrace\\frac{R_1L_2+R_3L_2+R_1R_3}{L_2L_3}+\\sqrt {\\left\(\\frac{R_1L_2+R_3L_2+R_1R_3}{L_2L_3}\\right\)^2-4\\frac{R_1R_3}{L_2L_3}}\\right\\rbrace ](//upload.wikimedia.org/math/9/1/7/9170d4960512a6a62bd50ebf10b366b1.png) ......... (182-6.2.1)

  


![\\alpha_2=\\frac{1}{2}\\left\\lbrace\\frac{R_1L_2+R_3L_2+R_1R_3}{L_2L_3}-\\sqrt {\\left\(\\frac{R_1L_2+R_3L_2+R_1R_3}{L_2L_3}\\right\)^2-4\\frac{R_1R_3}{L_2L_3}}\\right\\rbrace ](//upload.wikimedia.org/math/5/b/1/5b16174b250a018a1e641a9fd242d06e.png) ......... (182-6.2.2)

  


Therefore, equations (182-6) and (186-6.2) give

![i_1\(s\)=\\frac{E}{s}.\\frac{R_3+s\(L_2+L_3\)}{L_2L_3\(s+\\alpha_1\)\(s+\\alpha_2\)} ](//upload.wikimedia.org/math/f/f/0/ff08b3bc9b3ea42085ab871abc004715.png)

![i_1\(s\)=\\frac{A_0}{s}+\\frac{A_1}{s+\\alpha_1}+\\frac{A_1}{s+\\alpha_2} ](//upload.wikimedia.org/math/5/b/f/5bf77fcaeccd263648df6b775287c601.png) .........(182-7)

The constants ![A_0](//upload.wikimedia.org/math/3/a/d/3adb4edd14951ddd757ccb4eb18f8518.png), ![A_1](//upload.wikimedia.org/math/e/2/8/e283f48f6f3d4077546b2b697c3eebad.png), and ![A_2](//upload.wikimedia.org/math/1/7/b/17b99e166258f650036939b57689bdec.png) are obtained in terms of ![R_1](//upload.wikimedia.org/math/b/e/4/be473692ca1cbc48985e5e93af6755bf.png), ![L_2](//upload.wikimedia.org/math/d/8/4/d843d71869425cb9eefb67d52e20c972.png), ![L_3](//upload.wikimedia.org/math/3/7/0/37088076966c44ff397be489c434039b.png), and ![R_3](//upload.wikimedia.org/math/c/f/0/cf0ba5ee4a563a4998150f104e50f8c6.png) and are given as:

  


![A_0=-\\frac{ER_3}{L_2L_3\\alpha_1\\alpha_2}](//upload.wikimedia.org/math/d/c/f/dcf4490704c1ec9ddc73eb1727a38962.png) .........(182-7.1)

  


![A_1=E\\frac{R_3\\alpha_2-\\alpha_1\\alpha_2\(L_2+L_3\)}{L_2L_3\\alpha_1\\alpha_2\(\\alpha_1-\\alpha_2\)}](//upload.wikimedia.org/math/a/a/e/aaec97ebde28f3ae5df835acac7587b3.png).........(182-7.2)

  


![A_2=E\\frac{\\alpha_2\(L_2+L_3\)-R_3}{L_2L_3\\alpha_2\(\\alpha_1-\\alpha_2\)}](//upload.wikimedia.org/math/5/c/a/5cabee1e70866104b8860e5bde258e8e.png).........(182-7.3)

#### Inverse Laplace Transforms of current equations

The inverse Laplace transform of (182-7) is therefore,

![I_1\(t\)=\\mathcal{L}^{-1}\\left\\lbrace\\frac{A_0}{s}+\\frac{A_1}{s+\\alpha_1}+\\frac{A_1}{s+\\alpha_2}\\right\\rbrace  
=A_0+A_1e^{-\\alpha_1t}+A_2e^{-\\alpha_2t}
](//upload.wikimedia.org/math/a/e/e/aeeace98a66e57a02ecb82e803199670.png).........(182-8)

The remaining variables ![I_2\(t\)](//upload.wikimedia.org/math/c/a/c/cacb2c8568b8c6a40b8fe0eaaaa5d4bd.png) and ![I_3\(t\)](//upload.wikimedia.org/math/6/3/8/6388a6bcb84fd436e839cbb235183a03.png) and the corresponding voltages are determined by equations (182), (182-1) and (182-2)

  


##### Analysis of circuit dynamics

The electric current ![I_1\(t\)](//upload.wikimedia.org/math/6/2/d/62d079b61dad38e2f1ff1feaf2b0ef64.png) in equation (182-8) shows a time-independent component ![A_0](//upload.wikimedia.org/math/3/a/d/3adb4edd14951ddd757ccb4eb18f8518.png) and two decay terms, which reach asymptotic values as t reaches ∞. In other words, the currents in the three circuits lack sinusoidal osculation, mainly because: (1) the applied voltage is constant and (2) the circuit does not have capacitance components.

**Notes:** This example could be is modified in various ways[3] to involve voltage impulse, sinusoidal voltage source, capacitance,and various boundary and initial conditions of charges and currents.

## Generalization of the method

In the above example, the following modifications can be made:

(1) The applied voltage in the Krichhoff's equation can take many forms such as

  *  :![E\(t\)=E_o\\delta\(t\)](//upload.wikimedia.org/math/3/c/8/3c8735f5a5b475f5d4a97f48804b1be4.png)
  *  :![E\(t\)=E_osin\(\\omega t\)](//upload.wikimedia.org/math/8/a/0/8a0e994272e3e3a52bddfdc2713995d2.png)
  *  :![E\(t\)=E_of\(t\)](//upload.wikimedia.org/math/3/1/9/319221815cc1c4fa8e855eba36f9328c.png)

(2) Capacitance add the integral term of current over the duration as

  *  : ![ \\frac{1}{C}\\int_0^t I\(\\tau\)d\\tau](//upload.wikimedia.org/math/6/0/3/603044b747b72152bd946b4a7a9eb5b3.png)

## References

  1. ↑ Lecture 6 Slide 22 (Page 6 in the PDF document) <http://www.ee.ic.ac.uk/pcheung/teaching/ee2_signals/Lecture%206%20-%20Laplace%20Transform.pdf>
  2. ↑ El-Hewie, Mohamed F. (2013). _[Laplace Transforms_](http://www.amazon.com/Laplace-Transforms-Mohamed-F-El-Hewie/dp/1484136349/ref=sr_1_2?ie=UTF8&qid=1366249920&sr=8-2&keywords=eL-hEWIE+Laplace+transform). USA: Shaymaa Publishing. pp. 217-220. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [1484136349](/wiki/Special:BookSources/1484136349). [http://www.amazon.com/Laplace-Transforms-Mohamed-F-El-Hewie/dp/1484136349/ref=sr_1_2?ie=UTF8&qid=1366249920&sr=8-2&keywords=eL-hEWIE+Laplace+transform](http://www.amazon.com/Laplace-Transforms-Mohamed-F-El-Hewie/dp/1484136349/ref=sr_1_2?ie=UTF8&qid=1366249920&sr=8-2&keywords=eL-hEWIE+Laplace+transform). 
  3. ↑ El-Hewie, Mohamed F. (2013). _[Laplace Transforms_](http://www.amazon.com/Laplace-Transforms-Mohamed-F-El-Hewie/dp/1484136349/ref=sr_1_2?ie=UTF8&qid=1366249920&sr=8-2&keywords=eL-hEWIE+Laplace+transform). USA: Shaymaa Publishing. pp. 190–220. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [1484136349](/wiki/Special:BookSources/1484136349). [http://www.amazon.com/Laplace-Transforms-Mohamed-F-El-Hewie/dp/1484136349/ref=sr_1_2?ie=UTF8&qid=1366249920&sr=8-2&keywords=eL-hEWIE+Laplace+transform](http://www.amazon.com/Laplace-Transforms-Mohamed-F-El-Hewie/dp/1484136349/ref=sr_1_2?ie=UTF8&qid=1366249920&sr=8-2&keywords=eL-hEWIE+Laplace+transform). 

**[Circuit Theory](/wiki/Circuit_Theory)**

## Laplace Circuit Solution

One of the most important uses of the Laplace transform is to solve linear differential equations, just like the type of equations that represent our first- and second-order circuits. This page will discuss the use of the Laplace Transform to find the complete response of a circuit.

## Steps

Here are the general steps for solving a circuit using the Laplace Transform:

  1. Determine the differential equation for the circuit.
  2. Use the Laplace Transform on the differential equation.
  3. Solve for the unknown variable in the laplace domain.
  4. Use the inverse laplace transform to find the time domain solution.

Another method that we can use is:

  1. Transform the individual circuit components into impedance values using the Laplace Transform.
  2. Find the Transfer function that describes the circuit
  3. Solve for the unknown variable in the laplace domain.
  4. Use the inverse laplace transform to find the time domain solution.

**[Circuit Theory](/wiki/Circuit_Theory)**

![](//upload.wikimedia.org/wikipedia/commons/c/c7/Fourier.jpg)

[Joseph Fourier](//en.wikipedia.org/wiki/Joseph_Fourier), after whom the Fourier Transform is named, was a famous mathematician who worked for Napoleon.

This course started with phasors. We learned how to transform forcing sinusodial functions such as voltage supplies into phasors. To handle more complex forcing functions we switched to complex frequencies. This enabled us to handle forcing functions of the form:

    ![e^{st}\\cos\(\\omega t + \\phi\)](//upload.wikimedia.org/math/d/9/e/d9e21c4b6eeea935b6a389456553921e.png)

where s is:

    ![s=\\sigma + j\\omega](//upload.wikimedia.org/math/7/a/d/7addd3c9d3736265ecd7dbea420b1190.png)

And the convolution integral can do anything.

Along the way "s" began to transform the calculus operators back into algebra. Within the complex domain, "s" could be re-attached to the inductors and capacitors rather than forcing functions. The transfer function helped us use "s" to capture circuit physical characteristics.

This is all good for designing a circuit to operate at a single frequency ω. But what about circuits that operate at a variety of frequencies? A RC car may operate at 27mhz, but when a control is pressed, the frequency might increase or decrease. Or the amplitude may increase or decrease. Or the phase may shift. All of these things happen in a cell phone call or wifi/blue tooth/xbee/AM/FM/over the air tv, etc.

How does a single circuit respond to these changes?

## Fourier analysis

Fourier analysis says we don't have to answer all the above questions. Just one question has to be answered/designed to. Since any function can be turned into a series of sinusiodals added together, then sweeping the circuit through a variety of \omega's can predict it's response to any particular combination of them.

So to start this we get rid of the exponential term and go back to phasors.

Set σ to 0:

    ![s = j\\omega](//upload.wikimedia.org/math/a/8/5/a85b8a883b07d53a9bf9d8c408de5c5c.png)

The variable ω is known as the "radial frequency" or just frequency. With this we can design circuits for cell phones that all share the air, for set-top cable TV boxes that pack multiple channels into one black cable. Every vocal or pixel change during transmission or reception can be designed for within this framework. All that is required is to sweep through all the frequencies that a sinusoidal voltage or current source can produce.

Analysis stays in the frequency domain. Because everything repeats over and over again in time, there is no point in going back to the time from a design point of view.

## Radial Frequency

In the Fourier transform, the value ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) is known as the **Radial Frequency**, and has units of radians/second (rad/s). People might be more familiar with the variable f, which is called the "Frequency", and is measured in units called Hertz (Hz). The conversion is done as such:

    ![\\omega = 2\\pi f](//upload.wikimedia.org/math/e/e/f/eefe9093ec365c277ea859d088715133.png)

For instance, if a given AC source has a frequency of 60Hz, the resultant radial frequency is:

    ![\\omega = 2\\pi f = 2\\pi\(60\) = 120\\pi](//upload.wikimedia.org/math/a/5/8/a58a05882e68240ca24ea61a5bc67e6e.png)

## Fourier Domain

The Fourier domain then is broken up into two distinct parts: the **magnitude graph**, and the **phase graph**. The magnitude graph has jω as the horizontal axis, and the magnitude of the transform as the vertical axis. Remember, we can compute the magnitude of a complex value C as:

    ![C = A + jB](//upload.wikimedia.org/math/9/f/9/9f919dd9c391d04645d37cc21bcfa0b2.png)
    ![|C| = \\sqrt{A^2 + B^2}](//upload.wikimedia.org/math/6/7/c/67c048d2e54ea30fc05e217aeddabc93.png)

The Phase graph has jω as the horizontal axis, and the phase value of the transform as the vertical axis. Remember, we can compute the phase of a complex value as such:

    ![C = A + jB](//upload.wikimedia.org/math/9/f/9/9f919dd9c391d04645d37cc21bcfa0b2.png)
    ![\\angle C = \\tan^{-1}\\left\(\\frac{B}{A}\\right\)](//upload.wikimedia.org/math/5/b/3/5b33764f847e850d8853089a157d398c.png)

The phase and magnitude values of the Fourier transform can be considered independent values, although some abstract relationships do apply. Every fourier transform must include a phase value and a magnitude value, or it cannot be uniquely transformed back into the time domain.

The combination of graphs of the magnitude and phase responses of a circuit, along with some special types of formatting and interpretation are called [Bode Plots](/wiki/Circuit_Theory/Bode_Plots).

## Bode Plots

Bode plots plot the transfer function. Since the transfer function is a complex number, both the magnitude and phase are plotted (in polar coordinates). The independent variable ω is swept through a range of values that center on the major defining feature such as time constant or resonant frequency. A magnitude plot has dB of the transfer function magnitude on the vertical axis. The phase plot typically has degrees on the vertical axis.

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/76/Example45B.png/220px-Example45B.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

voltage across capacitor and resistor parallel combination is the output

[File:Example45bode1.png](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Example45bode1.png)

Bode plot for VCR compared to VS which looks like a passive, low pass filter with slope of -40dB/decade, the cut off frequency looks to be 100 = 1 radian/sec. The resistor dominates at DC and the capacitor dominates at very high frequencies.

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Example14Transfer.png/220px-Example14Transfer.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

find current through R3

## MatLab tr and bode

### Example 1

[Previously](/wiki/Circuit_Theory/TF_Objectives#Applications) the transfer function was found to be:

    ![H\(s\) = \\frac{\\mathbb{V}_{cr}\(s\)}{\\mathbb{V}_s\(s\)} = \\frac{1}{CLs^2 + \\frac{Ls}{R} + 1} = \\frac{1}{s^2 + 2s + 1} ](//upload.wikimedia.org/math/9/8/d/98d6af89e7b5bd717b14834b2471df1f.png)

MatLab has a short hand notation method for entering this information where the coefficients are listed (high power to low power)(numerator first, then denominator). For this example
    
    
    f = tf([1],[1 2 1])
    

Leaving the colon off the end should display the transfer function. The next step is to plot it:
    
    
    grid on
    bode(f)
    

The result is a low pass filter. Rather than understand how to create these plots (not trivial), the goal is to interpret the plot .. (which is almost the same thing). But at this point, the goal is to exercise MatLab.

[File:Example14Bode.png](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Example14Bode.png)

Bode diagram of R3 current versus Vs, looks like a notch filter at around 1K radians/sec

### Example 2

[Previously](/wiki/Circuit_Theory/TF_Examples) the transfer function was found to be:

    ![\\frac{\\mathbb{I}_o}{\\mathbb{V}_s} = \\frac{1000s^3 + 5*10^9s}{s^4 + 5*10^6*s^3 + 2.000015*10^{12}*s^2 + 3.5*10^{13}*s + 5*10^{13}}](//upload.wikimedia.org/math/6/4/8/648fb162d02a9f219ab38b1303770bc6.png)
    
    
    f = tf([1000 0 5*10^9 0],[1 5*10^6 2.000015*10^12 3.5*10^13 5*10^13])
    grid on
    bode(f)
    

### Magnitude Graph

Bode magnitude plots are dB which is both a measure of power and voltage and current simultaneously. The vertical dB axis is not an approximation or relative to anything. The vertical axis is an accurate number. The horizontal, dependent axis could be radians/sec or Hz.

### Phase Graph

The Bode Phase Plot is a graph where the radial frequency is plotted along the X axis, and phase shift of the circuit _at that frequency_ is plotted on the Y-axis. Axis could be in radians or degrees, frequency could be in radians per second or Hz.

## Poles and Zeros

A transfer function has 7 features that can be realized in circuits. Before looking at these features, the terms pole, zero and origin need to be defined. Start with this definition of a transfer fuction:

    ![H\(j\\omega\) = \\frac{Z\(j\\omega\)}{P\(j\\omega\)}](//upload.wikimedia.org/math/8/2/7/827aac1f611757dcb6bfd59ae7b122bd.png)

  * Zeros are roots in the numerator.
  * Poles are roots in the denominator.
  * The origin is where s = jω = 0 (no real part in a Bode analysis). When the frequency is zero, the input is DC. This is where after a long time caps open and inductors short.

The 7 possible features in a transfer function are:

  * A constant
  * Zeros at the origin (s in the numerator)
  * Poles at the origin (s in the denominator)
  * Real Zero (an s+a factor in the numerator)
  * Real Pole (an S+a factor in the denominator)
  * Complex conjugate poles
  * Complex conjugate zeros

The bode and bodeplot functions are available in the [MatLab Control system toolbox](http://www.mathworks.com/products/control/). [BodePlotGui](http://lpsa.swarthmore.edu/Bode/BodeFiles.html) does the same thing and is discussed here. BodePlotGui was developed at Swarthmore through an NSF grant. There is a summary of the [Swathmore Bode Diagram tutorial](http://lpsa.swarthmore.edu/Bode/Bode.html).

Circuit simulation software can plot bode diagrams [also](https://www.circuitlab.com/circuit/s5c7k7/p9-5/).

## Bode Equation Format

let us say that we have a generic transfer function with poles and zeros:

    ![H\(j\\omega\) = \\frac{\(\\omega_A + j\\omega\)\(\\omega_B + j\\omega\)}{\(\\omega_C+ j\\omega\)\(\\omega_D + j\\omega\)}](//upload.wikimedia.org/math/1/b/e/1be2d71014b4c4e28169a238e89f43f6.png)

Each term, on top and bottom of the equation, is of the form ![\(\\omega_N + j\\omega\)](//upload.wikimedia.org/math/c/5/5/c555b3f6fde70ede250bdd30a425d1f8.png). However, we can rearrange our numbers to look like the following:

    ![\\omega_N\(1 + \\frac{j\\omega}{\\omega_N}\)](//upload.wikimedia.org/math/a/2/9/a2942d8e5785e2431d6f24ca3c47c9a2.png)

Now, if we do this for every term in the equation, we get the following:

    ![H_{bode}\(j\\omega\) = \\frac{\\omega_A \\omega_B}{\\omega_C \\omega_D}
      \\frac{\(1 + \\frac{j\\omega}{\\omega_A}\)\(1 + \\frac{j\\omega}{\\omega_B}\)}
           {\(1 + \\frac{j\\omega}{\\omega_C}\)\(1 + \\frac{j\\omega}{\\omega_D}\)}](//upload.wikimedia.org/math/d/c/f/dcf64694af916e495ce5b9318667242c.png)

This is the format that we are calling "Bode Equations", although they are simply another way of writing an ordinary frequency response equation.

## DC Gain

The constant term out front:

    ![\\frac{\\omega_A \\omega_B}{\\omega_C \\omega_D}](//upload.wikimedia.org/math/5/5/5/5551659cc7d31850a1f830d014b0eb00.png)

is called the "DC Gain" of the function. If we set ![\\omega \\to 0](//upload.wikimedia.org/math/e/4/9/e492678f7541d604fe50fa99ffa4499a.png), we can see that everything in the equation cancels out, and the value of H is simply our DC gain. DC then is simply the input with a frequency of zero.

## Break Frequencies

in each term:

    ![\(1 + \\frac{j\\omega}{\\omega_N}\)](//upload.wikimedia.org/math/e/e/3/ee3faa7b51d17dbdf28875208f02b846.png)

the quantity ![\\omega_N](//upload.wikimedia.org/math/3/e/8/3e83ae84e541059ac5b7e135b3d2b94e.png) is called the "Break Frequency". When the radial frequency of the circuit equals a break frequency, that term becomes (1 + 1) = 2. When the radial frequency is much higher than the break frequency, the term becomes much greater than 1. When the radial Frequency is much smaller than the break frequency, the value of that term becomes approximately 1.

### Approximations

Bode diagrams are constructed by drawing straight lines (on log paper) that approximations of what are really curves. Here is a more precise definition.

The term "much" is a synonym for "At least 10 times". "Much Greater" becomes "At least 10 times greater" and "Much less" becomes "At least 10 times less". We also use the symbol "<<" to mean "is much less than" and ">>" to mean "Is much greater than". Here are some examples:

  * 1 << 10
  * 10 << 1000
  * 2 << 20 Right!
  * 2 << 10 WRONG!

For a number of reasons, Electrical Engineers find it appropriate to approximate and round some values very heavily. For instance, manufacturing technology will never create electrical circuits that perfectly conform to mathematical calculations. When we combine this with the << and >> operators, we can come to some important conclusions that help us to simplify our work:

If A << B:

  * A + B = B
  * A - B = -B
  * A / B = 0

All other mathematical operations need to be performed, but these 3 forms can be approximated away. This point will come important for later work on bode plots.

Using our knowledge of the Bode Equation form, the DC gain value, Decibels, and the "much greater, much less" inequalities, we can come up with a fast way to approximate a bode magnitude plot. Also, it is important to remember that these gain values are not constants, but rely instead on changing frequency values. Therefore, the gains that we find are all _slopes_ of the bode plot. Our slope values all have units of "decibel per decade", or "db/decade", for short.

## At Zero Radial Frequency

At zero radial frequency, the value of the bode plot is simply the DC gain value _in decibels_. Remember, bode plots have a log-10 magnitude Y-axis, so we need to convert our gain to decibels:

    ![Magnitude = 20\\log_{10}\(DC Gain\)](//upload.wikimedia.org/math/7/e/c/7ecfa5bb39a9cefb7120117b4cc82c2e.png)

## At a Break Point

We can notice that each given term changes it's effect as the radial frequency goes from below the break point, to above the break point. Let's show an example:

    ![\(1 + \\frac{j\\omega}{5}\)](//upload.wikimedia.org/math/4/8/d/48de187ccfcaf3dadb4263c8a2374ec2.png)

Our breakpoint occurs at 5 radians per second. When our radial frequency is _much less_ than the break point, we have the following:

    ![Gain = \(1 + 0\) = 1](//upload.wikimedia.org/math/5/3/5/535ff6bc5820ecf55128fedba94481c2.png)

    ![Magnitude = 20\\log_{10}\(1\) = 0db/decade](//upload.wikimedia.org/math/b/8/6/b8610e543c7e3c49a3ec3ada03c9834c.png)

When our radial frequency is equal to our break point we have the following:

    ![Gain = |\(1 + j\)| = \\sqrt{2}](//upload.wikimedia.org/math/9/a/7/9a7288b64c1f2cbebcb2382a0771221e.png)

    ![Magnitude = 20\\log_{10}\(\\sqrt{2}\) = 3db/decade](//upload.wikimedia.org/math/8/c/6/8c68dda40931db391ead3e11f808bdc0.png)

And when our radial frequency is much higher (10 times) our break point we get:

    ![Gain = |\(1 + 10 j\)| \\approx 10](//upload.wikimedia.org/math/8/f/5/8f59194d3ba64ff49c13bbac98fb0607.png)

    ![Magnitude = 20\\log_{10}\(10\) = 20db/decade](//upload.wikimedia.org/math/d/d/2/dd22d01b894b1ab062d52d4600a5b2d3.png)

However, we need to remember that some of our terms are "Poles" and some of them are "Zeros".

### Zeros

Zeros have a positive effect on the magnitude plot. The contributions of a zero are all positive:

Radial Frequency << Break Point 
    0db/decade gain.
Radial Frequency = Break Point 
    3db/decade gain.
Radial Frequency >> Break Point 
    20db/decade gain.

### Poles

Poles have a negative effect on the magnitude plot. The contributions of the poles are as follows:

Radial Frequency << Break Point 
    0db/decade gain.
Radial Frequency = Break Point 
    -3db/decade gain.
Radial Frequency >> Break Point 
    -20db/decade gain.

## Conclusions

To draw a bode plot effectively, follow these simple steps:

  1. Put the frequency response equation into bode equation form.
  2. identify the DC gain value, and mark this as a horizontal line coming in from the far left (where the radial frequency conceptually is zero).
  3. At every "zero" break point, increase the slope of the line upwards by 20db/decade.
  4. At every "pole" break point, decrease the slope of the line downwards by 20db/decade.
  5. at every breakpoint, note that the "actual value" is 3db off from the value graphed.

And then you are done!

**[Circuit Theory](/wiki/Circuit_Theory)**

## Impedance

Let's recap: In the transform domain, the quantities of resistance, capacitance, and inductance can all be combined into a single complex value known as "Impedance". Impedance is denoted with the letter Z, and can be a function of s or jω, depending on the transform used (Laplace or Fourier). This impedance is very similar to the phasor concept of impedance, except that we are in the complex domain (laplace or fourier), and not the phasor domain.

Impedance is a complex quantity, and is therefore comprised of two components: The real component (resistance), and the complex component (reactance). Resistors, because they do not vary with time or frequency, have real values. Capacitors and inductors however, have imaginary values of impedance. The resistance is denoted (as always) with a capital R, and the reactance is denoted with an X (this is common, although it is confusing because X is also the most common input designator). We have therefore, the following relationship between resistance, reactance, and impedance:

  


[Complex Laplace Impedance]

    ![Z = R + jX](//upload.wikimedia.org/math/0/6/8/068f49ce5fa5748972b9fd8f67f38c1f.png)

## Susceptance and Admittance

The inverse of resistance is a quantity called "Conductance". Similarly, the inverse of reactance is called "Susceptance". The inverse of impedance is called "Admittance". Conductance, Susceptance, and Admittance are all denoted by the variables Y or G, and are given the units **Siemens**. This book will not use any of these terms again, and they are just included here for completeness.

## Parallel Components

Once in the transform domain, all circuit components act like basic resistors. Components in parallel are related as follows:

    ![Z_1 || Z_2 = \\frac{Z_1 Z_2}{Z_1 + Z_2}](//upload.wikimedia.org/math/9/8/a/98ab57fb1889e24b4045e7e3fc5ace08.png)

## Series Components

Series components in the transform domain all act like resistors in the time domain as well. If we have two impedances in series with each other, we can combine them as follows:

    ![Z_1 \\mbox{ in series with } Z_2 = Z_1 + Z_2](//upload.wikimedia.org/math/c/6/9/c69b4a2d458312b67386a2f4b44385e0.png)

## Solving Circuits

(This section has not yet been written)

  
  


3-Phase Circuits

This section is about 3-Phase circuits.

[Circuit Theory/3-Phase Transmission](/w/index.php?title=Circuit_Theory/3-Phase_Transmission&action=edit&redlink=1)

  


Appendices

Circuit Functions  
Phasor Arithmetic  
Decibels  
Transform Tables  
Resources

  


# Circuit Functions

**[Circuit Theory](/wiki/Circuit_Theory)**

## Circuit Functions

This appendix page will list the various values of the variable H that have been used throughout the circuit theory textbooks. These values of H are all equivalent, but are represented in different domains. All of the H functions are a ratio of the circuit input over the circuit output.

## The "Impulse Response"

The **impulse response** is the time-domain relationship between the circuit input and the circuit output, denoted with the following notation:

    ![h\(t\)](//upload.wikimedia.org/math/6/e/c/6ece45e3f78470bcf0e7db1d3c539a09.png)

The impulse response is, strictly speaking, the output that the circuit will produce when an ideal impulse function is the input. The impulse response can be used to determine the output from the input through the convolution operation:

    ![y\(t\) = h\(t\) * x\(t\)](//upload.wikimedia.org/math/c/a/4/ca45ed01415f949551821bd19ba569d9.png)

## The "Network Function"

The **network function** is the phasor-domain representation of the impulse response. The network function is denoted as such:

    ![\\mathbb{H}\(\\omega\)](//upload.wikimedia.org/math/a/2/2/a22a1170040f9826328a8dfe9f638556.png)

The network function is related to the input and output of the circuit through the following relationships:

    ![\\mathbb{Y}\(\\omega\) = \\mathbb{H}\(\\omega\) \\mathbb{X}\(\\omega\)](//upload.wikimedia.org/math/7/8/5/785b2c7ce20a941ea62b061f6daa56f4.png)

Similarly, the network function can be received by dividing the output by the input, in the phasor domain.

## The "Transfer Function"

The **transfer function** is the laplace-transformed representation of the impulse response. It is denoted with the following notation:

    ![H\(s\)](//upload.wikimedia.org/math/f/6/8/f68021749ff69bf0b89869d4358ea300.png)

The transfer function can be obtained by one of two methods:

  1. Transform the impulse response.
  2. Transform the circuit, and solve.

The Transfer function is related to the input and output as follows:

    ![Y\(s\) = H\(s\) X\(s\)](//upload.wikimedia.org/math/b/0/3/b038557f6b66391c5799046c2c951720.png)

## The "Frequency Response"

The **Frequency Response** is the fourier-domain representation of the impulse response. It is denoted as such:

    ![H\(j \\omega\)](//upload.wikimedia.org/math/9/3/a/93aa1f1d3216563bc3ad960a6e075ed4.png)

The frequency response can be obtained in one of three ways:

  1. Transform the impulse response
  2. Transform the circuit and solve
  3. Substitute ![s = j \\omega](//upload.wikimedia.org/math/a/8/5/a85b8a883b07d53a9bf9d8c408de5c5c.png) into the transfer function

The frequency response has the following relationship to the circuit input and output:

    ![Y\(j \\omega\) = H\(j \\omega\) X\(j \\omega\)](//upload.wikimedia.org/math/2/3/2/2320ca76e23a6fc02026b2c79fac8899.png)

The frequency response is particularly useful when discussing a sinusoidal input, or when constructing a bode diagram.  


# Phasor Arithmetic

**[Circuit Theory](/wiki/Circuit_Theory)**

## Phasor Arithmetic

This page will review phasors and phasor arithmetic topics.

## Forms

Phasors have two components, the magnitude (M) and the phase angle (φ). Phasors are related to sinusoids through our cosine convention:

    ![\\mathbb{C} = |M| \\angle \\phi = |M| \\cos \(t\\omega + \\phi\)](//upload.wikimedia.org/math/a/6/a/a6ac2e16b5171962a91f2144aa79abf8.png)

Remember, there are **3 forms to phasors**:

#### Polar Form

  * ![\\mathbb{C} = |M| \\angle \\phi](//upload.wikimedia.org/math/a/d/f/adf3a4d98183f867ee109b57a1203398.png)

#### Rectangular Form

  * ![\\mathbb{C} = A + jB](//upload.wikimedia.org/math/c/a/9/ca9e171692faf8e8e82ba834468b2749.png)

#### Exponential Form

  * ![\\mathbb{C} = |M|e^{j\\phi}](//upload.wikimedia.org/math/e/4/5/e45fceb7f435ced7dfe73d572e8c6e2b.png)

Phasor and Exponential forms are identical and are also referred to as polar form.

## Converting between Forms

When working with phasors it is often necessary to convert between rectangular and polar form. To convert from rectangular form to polar form:

    ![|M| = \\sqrt{A^2 + B^2}](//upload.wikimedia.org/math/5/0/f/50f366e316b5d84bb7248c95d84ba4ea.png)

    ![\\phi = \\arctan \\left\( \\frac{B}{A} \\right\)](//upload.wikimedia.org/math/f/a/1/fa1f4a102ab5bc4c0bf70bfae94bfb3b.png)

To convert from polar to rectangular form:

A is the part of the phasor along the real axis

    ![A = |M|\\cos \\left\( \\phi \\right\)](//upload.wikimedia.org/math/7/6/b/76b36d91c0702af2d4ae4ad79a6ace6e.png)

B is the part of the phasor along the imaginary axis

    ![B = |M|\\sin \\left\( \\phi \\right\)](//upload.wikimedia.org/math/b/d/6/bd63f6b2a0c8358a67e7f1ad56333d4f.png)

## Addition

To add two phasors together, we must convert them into rectangular form:

    ![\\mathbb{C}_1 = A_1 + jB_1](//upload.wikimedia.org/math/f/a/5/fa5bfabaf4a21c0ea66a349d93ec8a41.png)

    ![\\mathbb{C}_2 = A_2 + jB_2](//upload.wikimedia.org/math/e/f/8/ef8cbdc766d04047a03c736831c42799.png)

    ![\\mathbb{C}_1 + \\mathbb{C}_2 = \(A_1 + A_2\) + j\(B_1 + B_2\)](//upload.wikimedia.org/math/f/8/4/f845ac5de082ee6462059a1ad8e8ef37.png)

This is a well-known property of complex arithmetic.

## Subtraction

Subtraction is similar to addition, except now we subtract

    ![\\mathbb{C}_1 = A_1 + jB_1](//upload.wikimedia.org/math/f/a/5/fa5bfabaf4a21c0ea66a349d93ec8a41.png)

    ![\\mathbb{C}_2 = A_2 + jB_2](//upload.wikimedia.org/math/e/f/8/ef8cbdc766d04047a03c736831c42799.png)

    ![\\mathbb{C}_1 - \\mathbb{C}_2 = \(A_1 - A_2\) + j\(B_1 - B_2\)](//upload.wikimedia.org/math/1/0/9/109316a311df2fd135bd6bc7a190b3aa.png)

## Multiplication

To multiply two phasors, we should first convert them to polar form to make things simpler. The product in polar form is simply the product of their magnitudes, and the phase is the sum of their phases.

    ![\\mathbb{C}_1 = M_1 \\angle \\phi_1](//upload.wikimedia.org/math/0/6/a/06afbd0bf524bc5ba05f5bfd5a7a338d.png)

    ![\\mathbb{C}_2 = M_2 \\angle \\phi_2](//upload.wikimedia.org/math/a/9/e/a9eada4ebd2c92cf415aaedf98134218.png)

    ![\\mathbb{C}_1 \\times \\mathbb{C}_2 = M_1 \\times M_2 \\angle {\\phi_1+\\phi_2}](//upload.wikimedia.org/math/c/5/1/c51590436fad7c7f26c97a3c4f54b346.png)

Keep in mind that in polar form, phasors are exponential quantities with a magnitude (M), and an argument (φ). Multiplying two exponentials together forces us to multiply the magnitudes, and add the exponents.

## Division

Division is similar to multiplication, except now we divide the magnitudes, and subtract the phases

    ![\\mathbb{C}_1 = |M_1| \\angle \\phi_1](//upload.wikimedia.org/math/2/2/f/22f9673b377b8e27a93d6e8bb8caf293.png)

    ![\\mathbb{C}_2 = |M_2| \\angle \\phi_2](//upload.wikimedia.org/math/c/d/1/cd1677d34f97178a4d10058d2dad2081.png)

    ![{|\\mathbb{C}_1 \\over \\mathbb{C}_2|} = {|M_1 \\over M_2|} \\angle {\\phi_1-\\phi_2}](//upload.wikimedia.org/math/a/c/f/acf68d449976c4c0854d6b7ea4d50de0.png)

## Inversion

An important relationship that is worth understanding is the **inversion property** of phasors:

    ![\\mathbb{C} = M_C\\angle 0 = -M_C \\angle \\pi](//upload.wikimedia.org/math/d/4/d/d4d701c733d1267ebafbd00b4dc133e7.png)

Or, in degrees,

    ![\\mathbb{C} = M_C\\angle 0^\\circ = -M_C \\angle 180^\\circ](//upload.wikimedia.org/math/4/f/b/4fb110efc5e32a6966eb3c0aa253fedd.png)

On the normal cartesian plane, for instance, the negative X axis is 180 degrees around from the positive X axis. By using that fact on an imaginary axis, we can see that the Negative Real axis is facing in the exact opposite direction from the Positive Real axis, and therefore is 180 degrees apart.

## Complex Conjugation

Similar to the inversion property is the **complex conjugation property** of phasors. Complex conjugation is denoted with an asterisk above the phasor to be conjugated. Since phasors can be graphed on the Real-Imaginary plane, a 90 degree phasor is a purely imaginary number, and a -90 degree phasor is its complex conjugate:

    ![\\mathbb{C} = M \\angle 90^\\circ](//upload.wikimedia.org/math/1/f/5/1f59ba8bff5d4aa20ea710d18efefb3a.png)

    ![\\mathbb{C}^* = M \\angle -90^\\circ = M \\angle 270^\\circ](//upload.wikimedia.org/math/5/3/5/535f2082b3ace4461d2031b902e9791d.png)

Essentially, this holds true for phasors with all angles: the sign of the angle is reversed to produce the complex conjugate of the phasor in polar notation. In general, for polar notation, we have:

    ![\\mathbb{C} = M \\angle \\phi](//upload.wikimedia.org/math/3/c/b/3cb5626c71c1df50fb15902c13adbba5.png)
    ![\\mathbb{C}^* = M \\angle -\\phi](//upload.wikimedia.org/math/4/5/c/45cb168237e134499e2bd3cc98f4f667.png)

In rectangular form, we can express complex conjugation as:

    ![\\mathbb{C} = A + jB](//upload.wikimedia.org/math/c/a/9/ca9e171692faf8e8e82ba834468b2749.png)
    ![\\mathbb{C}^* = A - jB](//upload.wikimedia.org/math/a/a/0/aa0bc3895fe242fdad31ac377daa923e.png)

Notice the only difference in the complex conjugate of C is the sign change of the imaginary part.  


# Decibels

**[Circuit Theory](/wiki/Circuit_Theory)**

This appendix page is going to take a deeper look at the units of decibels, it will describe some of the properties of decibels, and will demonstrate how to use them in calculations.

## Definition

Decibels are, first and foremost, a power calculation. With that in mind, we will state the definition of a decibel:

    ![dB = 10 \\log{\\frac{P_{out}}{P_{in}}}](//upload.wikimedia.org/math/2/e/0/2e0ef3586159f2145df3de815cd7acaa.png)

The letters "dB" are used as the units for the result of this calculation. dB ratios are always in terms of watts, unless otherwise noted.

## Voltage Calculation

now, another formula has been demonstrated that allows a decibel calculation to be made using voltages, instead of power measurements. We will derive that equation here:

First, we will use the power calculation and Ohm's law to produce a common identity:

    ![P = VI = \\frac{V^2}{R}](//upload.wikimedia.org/math/3/f/4/3f440a0d89fe90a6be6e4365bc1ef6c6.png)

Now, if we plug that result into the definition of a decibel, we can create a complicated equation:

    ![dB = 10 \\log{ \\left\[\\frac{ \\frac{V_{out}^2}{R} }{ \\frac{V_{in}^2}{R} }\\right\]}](//upload.wikimedia.org/math/4/3/6/43602d7efae537b890da36056c3a696a.png)

Now, we can cancel out the resistance values (R) from the top and bottom of the fraction, and rearrange the exponent as such:

    ![dB = 10 \\log{\\left\[ \\left\(\\frac{V_{out}}{V_{in}}\\right\)^2 \\right\]}](//upload.wikimedia.org/math/f/0/a/f0a48b7bf0021012f75809d0f4c412cb.png)

If we remember the properties of logarithms, we will remember that if we have an exponent inside a logarithm, we can move the exponent outside, as a coefficient. This rule gives us our desired result:

    ![dB = 20 \\log{\\left\[ \\frac{V_{out}}{V_{in}} \\right\] }](//upload.wikimedia.org/math/8/d/b/8dbeb837e4b6f94192728dc07a55bd9c.png)

## Inverse Calculation

It is a simple matter of arithmetic to find the inverse of the decibel calculation, so it will not be derived here, but stated simply:

    ![P = 10^{dB/10}](//upload.wikimedia.org/math/1/8/0/180f3e4951e5c5fcb019990cbbaea500.png)

## Reference Units

Now, this decible calculation has proven to be so useful, that occasionally they are applied to other units of measurement, instead of just watts. Specifically, the units "dBm" are used when the power unit being converted was in terms of milliwatts, not just watts. Let's say we have a value of 10dBm, we can go through the inverse calculation:

    ![P = 10^{10dBm/10} = 10mW](//upload.wikimedia.org/math/1/8/0/1805119f81f86805b8bfb260b38d9683.png)

Likewise, let's say we want to apply the decibel calculation to a completely unrelated unit: hertz. If we have 100Hz, we can apply the decibel calculation:

    ![dB = 10 \\log{100Hz} = 20dBHz](//upload.wikimedia.org/math/2/5/c/25cacbc95e537e347991d1901a747892.png)

If no letters follow the "dB" lable, the decibels are referenced to watts.

## Decibel Arithmetic

Decibels are ratios, and _are not real numbers_. Therefore, specific care should be taken not to use decibel values in equations that call for gains, unless decibels are specifically called for (which they usually aren't). However, since decibels are calculated using logarithms, a few principles of logarithms can be used to make decibels usable in calculations.

### Multiplication

Let's say that we have three values, **a** **b** and **c**, with their respective decibel equivalents denoted by the upper-case letters **A** **B** and **C**. We can show that for the following equation:
    
    
    a = b c
    

That we can change all the quantities to decibels, and convert the multiplication operations to addition:
    
    
    A = B + C
    

### Division

Let's say that we have three values, **a** **b** and **c**, with their respective decibel equivalents denoted by the upper-case letters **A** **B** and **C**. We can show that for the following equation:
    
    
    a = b / c
    

Then we can show through the principals of logarithms that we can convert all the values to decibels, and we can then convert the division operation to subtraction:
    
    
    A = B - C
    

  


# Transform Tables

[Circuit Theory/Transform Tables](/w/index.php?title=Circuit_Theory/Transform_Tables&action=edit&redlink=1)  


# Resources

**[Circuit Theory](/wiki/Circuit_Theory)**

  


## Further Reading

Pages listed here are sources of further information on the topic of electric circuits, or are additional subjects that may be of interest for a reader of this book. Many of the resources listed here are sources of information, and this may be treated as a bibliography for this wikibook.

### Wikibooks

  * Wikibooks: [Electronics](/wiki/Electronics)
  * Wikibooks: [Signals and Systems](/wiki/Signals_and_Systems)
  * Wikibooks: [Digital Circuits](/wiki/Digital_Circuits)
  * Wikibooks: [Circuit Idea](/wiki/Circuit_Idea)

The following Wikibooks list [Circuit Theory](/wiki/Circuit_Theory) as a prerequisite:

  


### Other Resources

  * Horowitz and Hill, _The Art of Electronics_, Second Edition, Cambridge University Press, 1989. [ISBN 0521370957](/wiki/Special:BookSources/0521370957)
  * US Navy, _Basic Electrity_, Dover, 1970. [ISBN 0486209733](/wiki/Special:BookSources/0486209733)
  * US Navy, _Basic Electronics_, Dover, 1973. [ISBN 0486210766](/wiki/Special:BookSources/0486210766)
  * Comer and Comer, _Fundamentals of Electronic Circuit Design_, John Wiley & Sons, 2003. <http://www.wiley.com/college/comer/> [ISBN 0471410160](/wiki/Special:BookSources/0471410160)
  * Dorf and Svoboda, _Introduction to Electric Circuits_, Sixth Edition, John Wiley & Sons, 2004. [ISBN 0471447951](/wiki/Special:BookSources/0471447951)
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Circuit_Theory/All_Chapters&oldid=2502331](http://en.wikibooks.org/w/index.php?title=Circuit_Theory/All_Chapters&oldid=2502331)" 

[Categories](/wiki/Special:Categories): 

  * [Circuit Theory](/wiki/Category:Circuit_Theory)
  * [Circuit Theory/Stubs](/wiki/Category:Circuit_Theory/Stubs)

Hidden category: 

  * [Pages with broken file links](/wiki/Category:Pages_with_broken_file_links)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Circuit+Theory%2FAll+Chapters&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Circuit+Theory%2FAll+Chapters)

### Namespaces

  * [Book](/wiki/Circuit_Theory/All_Chapters)
  * [Discussion](/wiki/Talk:Circuit_Theory/All_Chapters)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Circuit_Theory/All_Chapters&stable=1)
  * [Latest draft](/w/index.php?title=Circuit_Theory/All_Chapters&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Circuit_Theory/All_Chapters&action=edit)
  * [View history](/w/index.php?title=Circuit_Theory/All_Chapters&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Circuit_Theory/All_Chapters)
  * [Related changes](/wiki/Special:RecentChangesLinked/Circuit_Theory/All_Chapters)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Circuit_Theory/All_Chapters&oldid=2502331)
  * [Page information](/w/index.php?title=Circuit_Theory/All_Chapters&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Circuit_Theory%2FAll_Chapters&id=2502331)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Circuit+Theory%2FAll+Chapters)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Circuit+Theory%2FAll+Chapters&oldid=2502331&writer=rl)
  * [Printable version](/w/index.php?title=Circuit_Theory/All_Chapters&printable=yes)

  * This page was last modified on 16 March 2013, at 06:53.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Circuit_Theory/All_Chapters)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
