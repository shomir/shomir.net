# English as an Additional Language/Print version

From Wikibooks, open books for an open world

< [English as an Additional Language](/wiki/English_as_an_Additional_Language)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=English_as_an_Additional_Language/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=English_as_an_Additional_Language/Print_version) on _8 March 2009_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=English_as_an_Additional_Language/Print_version&oldid=1436863&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


## Contents

  * 1 Introduction
  * 2 Overview
    * 2.1 Terminology
  * 3 The English alphabet
    * 3.1 Vowels and Consonants
  * 4 Pronunciation
    * 4.1 Pronunciation
      * 4.1.1 Consonants
    * 4.2 Vowels
      * 4.2.1 Received Pronunciation
        * 4.2.1.1 Full vowels
        * 4.2.1.2 Reduced vowels
      * 4.2.2 General American
        * 4.2.2.1 Full vowels
        * 4.2.2.2 Reduced vowels
      * 4.2.3 General Australian
        * 4.2.3.1 Full vowels
        * 4.2.3.2 Reduced vowels
    * 4.3 References
  * 5 General rules of spelling and capitalization
    * 5.1 Capitalization in English
    * 5.2 Spelling in English
  * 6 Greetings and Expressions
  * 7 Articles and Adjectives
    * 7.1 Articles
    * 7.2 Adjectives
  * 8 Numbers and Time
    * 8.1 Numbers
    * 8.2 Time
  * 9 Plural forms of nouns
    * 9.1 Plural Formation
  * 10 Personal pronouns
  * 11 Subject Personal Pronouns
    * 11.1 Subject Pronouns **replace** subject nouns.
    * 11.2 Subject Pronouns **replace** subject noun phrases.
    * 11.3 Subject pronouns **agree** with the **PERSON** and **NUMBER** of subject nouns
    * 11.4 Subjects which are **third person and singular** must agree with the **GENDER** of the noun as well.
  * 12 Copular verb to be: present tense
    * 12.1 The Present Tense
  * 13 Simple present tense
    * 13.1 Regular Verbs
    * 13.2 Irregular Verbs
  * 14 Negatives
  * 15 Possessives
    * 15.1 Singular Possessives
    * 15.2 Plural Possessives
  * 16 Simple past tense
    * 16.1 Past Tense
    * 16.2 External links
  * 17 Introducing prepositions
    * 17.1 Prepositions of place
    * 17.2 Prepositions of time
    * 17.3 Adjective / Verbs with prepositions (dependent prepositions)
  * 18 Homework
    * 18.1 Lesson
    * 18.2 Vocabulary
  * 19 Telling the Time
    * 19.1 Asking for the time
    * 19.2 Giving the time
  * 20 Rail Travel
  * 21 Links

# Introduction

Welcome!

This book attempts to introduce prospective students to the English language. We hope to create a solid and well-done course to those who wish to learn how to speak, read, and write English. The benefits of learning this language are manifold: English is spoken in more countries than any other language, and is considered the "lingua franca," or international language of the world. It is the primary or major secondary language in the United States, the United Kingdom, Canada, Australia, New Zealand, India, South Africa, and many other countries, and is used by businesspeople, travelers, etc. across the world.

This book is intended for both non-native speakers learning English, and teachers trying to teach the English language. While it does not talk about the aspects of teaching, it contains content that should be useful.

Check back often for more content!

  


# Overview

There are two basic forms of English as an additional language: English to use in an English-speaking region (e.g. by refugees and immigrants) and English to use in a non-English-speaking region (e.g. by international business people).

This textbook offers resources for English teachers working in both contexts. When appropriate we will mark information that is specific to one discipline or the other. Included are language reference information, teaching techniques and tips, historical information about the English language, and activities to be used in your classes.

### Terminology

English as a Foreign Language (EFL) refers to English for use in the second of these situations, in a non-English-speaking region. Teaching English as a Foreign Language (TEFL) is a common abbreviation for the teaching aspect (education, career and methods).

In North America, in the first situation, English for use in an English-speaking region, is known as English as a Second Language (ESL). In Britain this is called English for Speaker of Other Languages (ESOL) in recognition of the fact that many of the learners already speak more than one language. Teaching English to Speakers of Other Languages (TESOL) is a common abbreviation for the teaching aspect.

  * _Chapter 0: Morphology and Spelling_

# The English alphabet

_Note: if the target audience's native language already uses the Latin alphabet, then much of this information can be omitted._

English is written with the Latin alphabet. It consists of 26 letters:

**lower-case letters:** a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z

**upper-case letters:** A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z

Each letter has a lower-case and an upper-case (or "capital") form. In some cases (e.g. the letters S, X, and O), the upper-case form is simply a larger version of the lower-case. However, some letters have differing forms in upper- and lower-case, such as A, Q, and T. Lower-case letters evolved from modified forms of the upper-case letters, which were used in ancient times.

## Vowels and Consonants

There are 5 vowel letters in English: a, e, i, o, u ("y" and "w" also act as vowels, and are used for orthographic reasons). This does not correlate with the number of vowel sounds, of which there are about 14, depending on dialect.

There are 21 consonant letters: b, c, d, f, g, h, j, k, l, m, n, p, q, r, s, t, v, w, x, y, z.

In many cases, the spelling of an English word only gives a rough indication of its pronunciation. For this reason, the English spelling system is notorious for being one of the hardest to learn of all the alphabetic scripts.

![About this sound](//upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Loudspeaker.svg/11px-Loudspeaker.svg.png) [click here](//upload.wikimedia.org/wikibooks/en/f/fa/Alphabet_1.ogg) ([help](//en.wikipedia.org/wiki/Wikipedia:Media_help)·[info](/wiki/File:Alphabet_1.ogg)) to listen to the pronunciation of the alphabet.

# Pronunciation

## Pronunciation

### Consonants

The symbols used for consonants are shown in the following table. Where symbols appear in pairs, the one to the left is voiceless, the one to the right voiced.

  Bi­labial Labio-  
dental Labio-  
velar Den­tal Alveo­lar Post-  
alveo­lar Pala­tal Velar Glot­tal

Stop
p  b
 
 
 
t  d
 
 
k  g
 

Affricate
 
 
 
 
 
tʃ  dʒ
 
 
 

Nasal
m
 
 
 
n
 
 
ŋ
 

Fricative
 
f  v
 
θ  ð
s  z
ʃ  ʒ
 
(x)
h

Approximant
 
 
(ʍ)  w
 
ɹ
 
j
 
 

Lateral  
approximant
 
 
 
 
l
 
 
 
 

  * /p/: **p**it
  * /b/: **b**it
  * /t/: **t**in
  * /d/: **d**in
  * /k/: **c**ut
  * /ɡ/: **g**ut
  * /tʃ/: **ch**eap
  * /dʒ/: **j**eep
  * /m/: **m**ap
  * /n/: **n**ap
  * /ŋ/: ba**ng**
  * /f/: **f**at
  * /v/: **v**at

  * /θ/: **th**in
  * /ð/: **th**en
  * /s/: **s**ap
  * /z/: **z**ap
  * /ʃ/: **sh**e
  * /ʒ/: mea**s**ure
  * /x/: lo**ch**, **Ch**anukah (often replaced by /-k/ and /h-/, respectively)
  * /h/: **h**am
  * /ʍ/: **wh**ine (also written /hw/, often replaced by /w/)
  * /w/: **w**e
  * /ɹ/: **r**un (often written /r/ in broad transcription)
  * /j/: **y**es
  * /l/: **l**eft

## Vowels

### Received Pronunciation

Received Pronunciation is the prestige British accent, sometimes referred to as _BBC English_. It is used as the standard in most media within Great Britain.

#### Full vowels

Full vowels are those that appear in stressed syllables.

Monophthongs Short
Long

Front Back Front Central Back

Close
ɪ
ʊ
iː
 
uː

Mid
ɛ
ʌ
 
ɜː
ɔː

Open
æ
ɒ
 
ɑː

  * /ɪ/: b**i**d
  * /ʊ/: g**oo**d
  * /ɛ/: b**e**d (sometimes transcribed /e/)
  * /ʌ/: b**u**d
  * /æ/: b**a**t (sometimes transcribed /a/)
  * /ɒ/: p**o**t

  * /iː/: b**ea**d
  * /uː/: b**oo**ed
  * /ɜː/: b**ir**d (sometimes transcribed /əː/)
  * /ɔː/: b**ough**t, b**oar**d
  * /ɑː/: f**a**ther, b**ar**d

Diphthongs Closing
Centring

to /ɪ/ to /ʊ/

Starting close
 
 
ɪə  ʊə

Starting mid
eɪ  ɔɪ
əʊ
ɛə

Starting open
aɪ
aʊ
 

  * /eɪ/: b**ay**
  * /ɔɪ/: b**oy**
  * /əʊ/: t**oe**
  * /aɪ/: b**uy** (sometimes transcribed /ʌɪ/)
  * /aʊ/: c**ow**

  * /ɪə/: b**eer**
  * /ʊə/: b**oor** (falling out of use in British English; often replaced by /ɔː/)
  * /ɛə/: b**ear** (sometimes transcribed /ɛː/)

#### Reduced vowels

Reduced vowels occur in unstressed syllables.

  * /ɪ/: ros**e**s
  * /ə/: Ros**a**’s, runn**er**
  * /l̩/: bott**le**
  * /n̩/: butt**on**
  * /m̩/: rhyth**m**

  


### General American

General American is the standardized accent of the United States, and is the dialect most commonly used in spoken media there.

#### Full vowels

Monophthongs Checked
Free

Front Central Back Front Central  
rhotacized Back

Close
ɪ
 
ʊ
i
 
u

Close-mid
 
 
 
e
 
o

Open-mid
ɛ
ʌ
 
 
ɝ
ɔ

Open
æ
 
 
 
 
ɑ

  * /ɪ/: b**i**d
  * /ʊ/: g**oo**d
  * /ɛ/: b**e**d
  * /ʌ/: b**u**d
  * /æ/: b**a**d

  * /i/: b**ea**d
  * /u/: b**oo**ed
  * /e/: b**ay**ed
  * /o/: b**o**de
  * /ɝ/: b**ir**d
  * /ɔ/ or /ɑ/: b**ough**t
  * /ɑ/: b**o**dy, p**o**d, f**a**ther

Note: the vowels /e/ and /o/ are usually diphthongal, so the transcriptions /eɪ/ and /oʊ/ are also often used. [1]

Diphthongs Closing
Rhotacized

to /ɪ/ to /ʊ/

Starting close
 
 
ɪɹ  ʊɹ

Starting mid
ɔɪ
 
ɛɹ  ɔɹ

Starting open
aɪ
aʊ
ɑɹ

  * /ɔɪ/: b**oy**
  * /aɪ/: b**uy**, th**igh**
  * /aʊ/: b**ou**t, c**ow**

  * /ɪɹ/: b**eer**, h**ere**
  * /ʊɹ/: b**oor**, man**ure** (often replaced by /ɝ/, sometimes by /ɔɹ/ in American English)
  * /ɛɹ/: b**ear**, **air**
  * /ɔɹ/: b**ore** (sometimes phonemicized /oɹ/)
  * /ɑɹ/: b**ar**

#### Reduced vowels

  * /ɨ/: ros**e**s (for many Americans merged with /ə/)
  * /ə/: Ros**a**’s
  * /ɚ/: runn**er**
  * /l̩/: bott**le**
  * /n̩/: butt**on**
  * /m̩/: rhyth**m**

  


### General Australian

#### Full vowels

Monophthongs Short
Long

Front Central Back Front Central Back

Close
ɪ
 
ʊ
iː
ʉː
 

Mid
e
 
ɔ
eː
ɜː
oː

Open
æ
a
 
æː
aː
 

  * /ɪ/: b**i**d
  * /ʊ/: g**oo**d
  * /e/: b**e**d
  * /ɔ/: p**o**t
  * /æ/: b**a**t
  * /a/: b**u**d

  * /iː/: b**ea**d
  * /ʉː/: b**oo**ed
  * /eː/: b**ar**ed
  * /ɜː/: b**ir**d
  * /oː/: b**ough**t, b**oar**d
  * /æː/: b**a**d
  * /aː/: f**a**ther, b**ar**d

Diphthongs Closing
Centring

to unrounded to rounded

Starting close
 
 
ɪə  ʊə

Starting mid
oɪ
əʉ
 

Starting open
æɪ  ɑe
æɔ
 

  * /oɪ/: b**oy**
  * /əʉ/: t**oe**
  * /æɪ/: b**ay**
  * /ɑe/: b**uy**
  * /æɔ/: c**ow**

  * /ɪə/: b**eer**
  * /ʊə/: t**our** (falling out of use in Australian English; often replaced by disyllabic /ʉːə/ or monophthongal /oː/)

#### Reduced vowels

  * /ə/: ros**e**s, Ros**a**’s, runn**er**
  * /l̩/: bott**le**
  * /n̩/: butt**on**
  * /m̩/: rhyth**m**

## References

  1. ↑ Roca, Iggy & Johnson, Wyn (1999). _Course in Phonology_. Blackwell Publishing.

  


# General rules of spelling and capitalization

English has many rules on capitalization and spelling, and spelling tends to vary between different dialects (especially British English and American English).

  


## Capitalization in English

There are several times when letters must be capitalized in English. They are:  
1) At the start of a sentence; "_**T**he cat is on the bed._"  
2) The first letter of a proper noun (a month/day/country/language/name etc.) and adjectives, adverbs etc. derived from them; "_**P**eter went to **S**pain on **T**uesday._" and "_**J**ohn ate a **S**panish dish._"  
3) In a religious context, when using 'he' to refer to God; "_**H**e thought it good._"  
4) First person singular: “**I**”.  


## Spelling in English

British English and American English have different ways of spelling certain words, especially those with **ou** in the middle, for example:  
1\. British English: _colo**u**r_, American English: _color_. 2. British English: _hono**u**r_, American English: _honor_.

Another variation is the use of 'z' instead of 's' in certain words in American English. 1. British English: _capitalisation_, American English: _capitali**z**ation_ 2\. British English: _modernisation_, American English: _moderni**z**ation_. 3. British English: _industrialisation_, American English: _industriali**z**ation_. This usually only applies to words that end in -ise and -isation.

  * _Chapter 1: First Sentences_

# Greetings and Expressions

Before we get into grammar it is useful to learn some common greetings and expressions in English. Here are some common phrases and their translations in Spanish, French, German, Polish respectively.

  


English Spanish French German Polish Arabic Chinese Japanese Italian

(Español/Castellano)

**Hello**
Hola
Bonjour
Hallo
Dzień dobry
مرحبا
喂
今日は
Salve

**How are you?**
¿Cómo Estás?
Comment vas-tu?
Wie geht's?
Jak się masz?
كيف حالك؟
你好吗？
元気ですか？
Come stai?

**I am good/bad**
Estoy bien/mal
Ça va bien/mal
Es geht mir gut/schlecht
Czuję się dobrze/źle
انا بخير \مستاء
我很好/不好
元気です/元気じゃないです
Sto bene/male

**Goodbye**
Adiós
Au revoir
Auf Wiedersehen
Do widzenia
مع السلامه
再见
さようなら
Addio

**Thank You**
Gracias
Merci
Danke
Dziękuję
شكرا
谢谢
ありがとうございます
Grazie

**You're welcome**
De nada
De rien
Gern geschehen
Proszę
على الرحب و السعه
不客气
どういたしまして
Prego

**What's your name?**
¿Cómo te llamas?
Quel est votre nom ?
Wie heißt du?
Jak masz na imię?
ما اسمك؟
你叫什么?
お名前は何ですか？
Come ti chiami?

**My name is...**
Me llamo...
Je m'appelle...
Ich heiße...
Mam na imię...
اسمي ...
我的名字是...
私の名前は。。。です
Mi chiamo...

  


# Articles and Adjectives

Next up we will learn two very important things: articles and adjectives. Both articles and adjectives typically occur before the noun they modify, with articles occurring before adjectives.

## Articles

Like other languages, English has a definite and an indefinite article. Unlike most Romance languages, English has no gender of nouns and so the articles don't change at all.

  * Definite article (used when the noun or nouns are already known): 
    * **The**
  * Indefinite article (used when the noun or nouns is not already known): 
    * For singular nouns: **a**
    * For singular nouns beginning in a vowel or a silent "h:" **an** Note that often "a" is used in front of vowels for some words; you will have to learn the exceptions individually.
    * For plural nouns, the closest thing to an article would be **some.**

## Adjectives

Remember that an adjective describes a noun. In English, adjectives are always placed before the noun, for example:

  * The **red** apple.
  * A **soft** sheep.
  * An **angry** dragon.
  * The **silly** boys.
  * Some **hard** rocks.

Also, English adjectives do NOT agree with number or gender:

  * The **red** apples, NOT The **reds** apples
  * Some **tall** women, NOT Some **talles** women

The exception, however is the adjective "blond", which agrees with gender in writing:

  * The **blond** boy, but;
  * The blond_e_ girl.

This is not strictly observed, however. Either "blond" or "blonde" is acceptable, and you are unlikely to be noticed using the feminine form for a male noun or vice versa.

  


# Numbers and Time

## Numbers

This page lists numbers used in English and provides phonetic transcriptions to help you pronounce them.

1 - one /wʌn/  
2 - two /tu/  
3 - three /θɹi/  
4 - four /fɔɹ/  
5 - five /faiv/  
6 - six /sɪks/  
7 - seven /ˈsɛvən/  
8 - eight /eit/  
9 - nine /nain/  
10 - ten /tɛn/  
11 - eleven /əˈlɛvən/  
12 - twelve /twɛlv/  
13 - thirteen /θɚˈtin/  
14 - fourteen /fɔɹˈtin/  
15 - fifteen /fɪfˈtin/  
16 - sixteen /sɪksˈtin/  
17 - seventeen /sɛvənˈtin/  
18 - eighteen /eiˈtin/  
19 - nineteen /nainˈtin/  
20 - twenty /ˈtwɛnti/  
21 - twenty-one /twɛntiˈwʌn/  
30 - thirty /ˈθɚti/  
31 - thirty-one /θɚtiˈwʌn/  
40 - forty /ˈfɔɹti/  
50 - fifty /ˈfɪfti/  
60 - sixty /ˈsɪksti/  
70 - seventy /ˈsɛvənti/  
80 - eighty /ˈeiti/  
90 - ninety /ˈnainti/  
100 - one hundred /wʌn ˈhʌndrəd/  
  


## Time

What time is it?  
What is the time?  
Do you have the time?  


  * _Chapter 2_

# Plural forms of nouns

Generally, making plurals (more than 1 of something) is very easy in English.

## Plural Formation

For almost all nouns we form the plural by adding **s**.

  * I have an apple
  * I have 5 apple**s.**

For nouns which end with the letter **y** we form the plural by removing the **y** and adding **ies**.

  * I have a fly
  * I have 5 fl**ies.**

For nouns which end with the letter **s** (dress), **ch** (beach), **x** (box), **sh** (bush) or **z** (quiz), we form the plural by adding **es**.

  * I have a bus.
  * I have 5 bus**es.**

There are also a small number of nouns which are very irregular. The first word in the following list is the singular form and the second word is the plural form:

  * child - children
  * man - men
  * woman - women
  * foot - feet
  * tooth - teeth
  * goose - geese
  * mouse - mice
  * fish - fish
  * sheep - sheep
  * deer - deer

As you can see, with some words there is no change to form the plural. The plural form and the singular form are exactly the same.

  


# Personal pronouns

English has 6 personal pronouns.

# Subject Personal Pronouns

**Subject Pronouns** are words that **replace** _subject nouns_ or _subject noun phrases_.

**I** \- first person singular (**yo, eu, je, ich, أنا**)  
**You** \- second person singular (**tú (usted)*, tu (você)*, tu, du, أنت**)  
**He/She/It** \- third person singular (**el/ella, ele/ela, il/elle, er/sie/es, هى/هو**)  
**We** \- first person plural (**nosotros, nós, nous, wir, نحن**)  
**You** \- second person plural - rarely used (**vosotros (ustedes)*, vós (vocês)*, vous, ihr/Sie, انتم\انتن**)  
**They** \- third person plural (**ellos/ellas, eles/elas, ils/elles, sie, هم\هن**)  


(*) formal

  


Subject Pronouns Singular (Number) Plural (Number)

First Person
I
We

Second Person
You
You

Third Person

Masculine (Gender):
He

Feminine (Gender):
She

Neuter (No Gender):
It
They

  


## Subject Pronouns **replace** subject nouns.

Consider these two sentences:
    
    
     **Charles** picks flowers from the garden.
     **He** picks flowers from the garden.
    

**Charles** is a _noun_. **Charlie** is also the _subject_ of the sentence  
Therefore, **Charles** is a _subject noun_. Because **Charles** is a male personal name, the subject of the sentence is male in gender.

'_He_ is a _subject pronoun_, describing male nounds. **He** _**replaces**_ **Charles**.

## Subject Pronouns **replace** subject noun phrases.

Consider these two sentences:
    
    
    * **BIRDS FROM CANADA** fly south in the winter.
    * **THEY** fly south in the winter.
    

**BIRDS FROM CANADA** is a _noun phrase_. **BIRDS FROM CANADA** is also the _subject_.  
Therefore, **BIRDS FROM CANADA** is a _subject noun phrase_.

**THEY** is a _subject pronoun_. **THEY** _**replaces**_ **BIRDS FROM CANADA**.

## Subject pronouns **agree** with the **PERSON** and **NUMBER** of subject nouns

Pronouns are either FIRST person, SECOND person, or THIRD person.

Pronouns have NUMBER. This means pronouns are either SINGULAR or PLURAL.

Consider these two sentences:
    
    
    * **JOHN AND I** went to the movies.
    * **WE** saw Spiderman II.
    

**JOHN AND I** is the _subject_.  
**JOHN AND I** is **FIRST PERSON**.  
**JOHN AND I** is also **PLURAL**.

**WE** is the **FIRST PERSON, PLURAL** _subject pronoun_. **WE** _**replaces**_ **JOHN AND I**.

## Subjects which are **third person and singular** must agree with the **GENDER** of the noun as well.

Third Person, **SINGULAR** Pronouns replace _People_ or _Things_.  
People can be _men_ or _women_. Men have a **MASCULINE GENDER**. Women have a **FEMININE GENDER**.  
Things are _not_ people. In English, things usually have **NO GENDER** _(neuter)_.

**Note:** **ALL** third person, **PLURAL** Pronouns are _**the same (THEY)**_.

Consider these sentences:
    
    
    * **CINDY** ran three miles on the beach.
    * **SHE** usually runs five miles.
    

**CINDY** is a woman. A woman has a **FEMININE GENDER**.  
Therefore, **CINDY** is THIRD PERSON, SINGLE, _**and**_ **FEMININE**.

**SHE** is the THIRD PERSON, SINGLE, **FEMININE** Subject Pronoun. **SHE** _**replaces**_ **CINDY**.

Consider these sentences:
    
    
    * **BOB** watched nine hours of television.
    * **HE** didn't run three miles on the beach.
    

**BOB** is a man. A man has a **MASCULINE GENDER**.  
Therefore, **BOB** is THIRD PERSON, SINGLE, _**and**_ **MASCULINE**.

**HE** is the THIRD PERSON, SINGLE, **MASCULINE** Subject Pronoun. **HE** _**replaces**_ **BOB**.

The third person, single pronoun for most _non-human (**things**)_ nouns or noun phrases is **IT**.
    
    
    * **THE CAR** is very dirty.
    * **IT** needs a car wash.
    

**THE CAR** is a thing. Things have **NO** Gender.  
Therefore, **THE CAR** is THIRD PERSON, SINGLE, _**but**_ _NO GENDER_.

**IT** is the THIRD PERSON, SINGLE Subject Pronoun for **things** with **NO GENDER**. **IT** _**replaces**_ **THE CAR**.

**Never use IT to refer to a person!** Use **HE** if the person is a man. Use **SHE** if the person is a woman.

If the gender of the person being referred to is _unknown_ or if one wants to refer _generically_ to people, **they** is often used.
    
    
    * Whoever _THEY_ were; _they_ did a good job.
    

  


# Copular verb to be: present tense

'To be' is perhaps the most important verb in the English language. It is known as a 'copular verb'. 'Be' is irregular, so its present tense conjugation must be memorized.

## The Present Tense

Here is the present tense conjugation, with their IPA equivalents.

  * I **am**. /æːm/
  * You **are**. /ɑr/
  * He **is**. /ɪz/
  * She **is**. /ɪz/
  * It **is**. /ɪz/
  * We **are**. /ɑr/
  * They **are**. /ɑr/

The forms of to be contract to the pronoun, shown here:

  * I'm
  * You're
  * He's
  * She's
  * It's
  * We're
  * They're  


These contracted forms are used regularly in speech by native speakers.

Here are some examples.

  * I **am** 36 years old.
  * They **are** hungry.
  * _Chapter 3_

# Simple present tense

The present simple tense is usually regular. Yet, there are a few exceptions, particularly with verbs ending in 'y'. Compared to most other Indo-European languages, English regular verbs have simple conjugation, because the first and second person forms are the same.

## Regular Verbs

Here is an example of the form of the present simple for regular verbs, using the verb "to like":

  * I **like** football.
  * You **like** football.
  * He/She/It **likes** football.
  * We **like** football.
  * They **like** football.

As you can see from the example above, the infinitive only changes for the 3rd person singular, where an **s** is added to the end of the word.

## Irregular Verbs

English has a large number of irregular verbs, most significantly the verb "to be," which you are learning throughout this textbook. Other verbs conjugate in different ways, including:

  * Verbs like **can** and **should** do not change in any present conjugation.
  * Verbs like **try** add **ies** instead of **s.**
  * The verb **have** use a completely different form in the 3rd person singular, in this case **has.**

  


# Negatives

English forms negatives in the Simple Present using _not_.

The verb _to be_ is special. Here is the negative form for it.

  * I am from Canada. - I am _not_ from Canada.
  * She is from Finland. - She is _not_ from Finland.
  * She is from Finland. - She is_n't_ from Finland
  * She is from Finland. - She's _not_ from Finland.

All other verbs use _don't (do not)_ or _doesn't (does not)_ to form negatives:

  * I play football. - I _do not_ play football.
  * I play football. - I _don't_ play football.
  * She likes jazz. - She _does not_ like jazz.
  * She likes jazz. - She _doesn't_ like jazz.

  


# Possessives

We use possessives when we talk about things which are owned by somebody or a direct relation to someone or something. In many languages it is common to talk about possession using a structure like 'object of subject' where the object is owned or possessed by the subject. This is possible in English but it generally sounds unnatural - **This is the garden of my mum**.

Usually in English we use possessives - **This is my mum's garden**

## Singular Possessives

This is simple. Simply add **'s** to the end of the noun if the owner or possessor is singular (I only have one mother).

  * Tom's pen
  * Ross's new house
  * Sarah's DVD player
  * The dog's dinner (dinner of one dog)

## Plural Possessives

If the owner or possessor is plural - i.e. many people own it - then we add the **'** after the 's' of the plural noun.

  * The dogs' dinner (dinner of many dogs)
  * _Chapter 4_

# Simple past tense

The past tense signifies actions that were done in the past. Conjugating verbs to show the past tense is very easy in English, almost as easy as conjugating the present tense.

## Past Tense

**Regular verbs** take the ending '-d' or 'ed' in the affirmative. The negative and interrogative are formed using _did_ (past of the auxiliary verb _do_) together with the infinitive of the verb. The verb _work_ is conjugated as follows:

Affirmative

I worked

you worked

he worked

she worked

it worked

we worked

you worked

they worked

Negative

I did not work
  or  
I didn't work

you did not work
  or  
you didn't work

he did not work
  or  
he didn't work

she did not work
  or  
she didn't work

it did not work
  or  
it didn't work

we did not work
  or  
we didn't work

you did not work
  or  
you didn't work

they did not work
  or  
they didn't work

Interrogative

did I work

did you work

did he work

did she work

did it work

did we work

did you work

did they work

Negative Interrogative

did I not work
  or  
didn't I work

did you not work
  or  
didn't you work

did he not work
  or  
didn't he work

did she not work
  or  
didn't she work

did it not work
  or  
didn't it work

did we not work
  or  
didn't we work

did you not work
  or  
didn't you work

did they not work
  or  
didn't they work

  


**Irregular verbs** change their form in the past tense affirmative in a variety of ways. The past of _go_, for example, is _went_, of _buy_, _bought_, of _keep_, _kept_. As with the regular verbs, the negative and interrogative are formed using _did_ together with the infinitive of the verb. The verb _go_ is conjugated in the past tense as follows:

Affirmative

I went

you went

he went

she went

it went

we went

you went

they went

Negative

I did not go
  or  
I didn't go

you did not go
  or  
you didn't go

he did not go
  or  
he didn't go

she did not go
  or  
she didn't go

it did not go
  or  
it didn't go

we did not go
  or  
we didn't go

you did not go
  or  
you didn't go

they did not go
  or  
they didn't go

Interrogative

did I go

did you go

did he go

did she go

did it go

did we go

did you go

did they go

Negative Interrogative

did I not go
  or  
didn't I go

did you not go
  or  
didn't you go

did he not go
  or  
didn't he go

did she not go
  or  
didn't she go

did it not go
  or  
didn't it go

did we not go
  or  
didn't we go

did you not go
  or  
didn't you go

did they not go
  or  
didn't they go

## External links

  * [Wiktionary Appendix:Irregular Verbs.](http://en.wiktionary.org/wiki/Appendix:Irregular_verbs:English)
  * [Verbbusters: Complete set of resources for the study of the irregular verbs.](http://www.verbbusters.com)

  


# Introducing prepositions

Prepositions are words which add meaning to a sentence. A preposition can tell you where or when something happens.

## Prepositions of place

On, under, above, below, behind, in front of, near, next to, opposite...

## Prepositions of time

On, At, In

  * I'll meet you _at_ 18.30
  * My birthday is _in_ March
  * My birthday is _on_ the 2nd of March

## Adjective / Verbs with prepositions (dependent prepositions)

Listen to, believe in, worried about, dream of...

  * _Some Useful Guides and Words_

{print entry|School and Education}}

# Homework

## Lesson

Schoolchildren, also called school kids, do homework. They do not like it. At least, they say that they do not like it. Homework is assignments that children do outside of class. However, sometimes students have time in class to do their homework. When a teacher gives an assignment to do during class it is called class work. Both homework and class work are types of schoolwork.

Sometimes students answer questions in a textbook.

    Teacher: Class, please turn your books to page seventy-one and do questions one through ten. If you don’t finish it is homework due tomorrow.
    Teacher: Open your books to chapter three and do every other question on page forty-five. Turn them in on my desk at the end of class.

Other times, homework is doing research and writing a report about something.

    Teacher: Your assignment will be a report about the causes of the US Civil War. It should be ten pages long, typed and double-spaced. Please include a bibliography of at least ten cited works. You may use the Internet. Please look up information in at least three books from the school library. Do not make more than three references to encyclopedias.

Students sometimes do homework together in groups. They call these groups study groups. This is part of the student’s sense of humor. This is because many American students prefer to socialize, or talk to their friends, than to do any work. Boys may tend to joke around while girls prefer to gossip about other girls.

Students in all levels of school may have to do homework. However, younger students usually have to do less homework than older students. In high school, some students may have to do several hours of homework a night. Students may do their homework at home or in a library. Another place where kids can work on their homework is in study hall. Study hall is an open period of the day. Students can use study hall to read, do homework, maybe talk with their friends, or make trouble.

Students sometimes complain that homework is boring. Other assignments are more interesting. Homework is hard if it makes you think a lot, and easy if it doesn’t make you think much. Americans call things that are easy “a piece of cake”. When a student finishes his or her homework he or she might like to relax for a while, go outside or watch some TV.

Other homework assignments may be a reading, math problems, an art project, or filling in answers in a worksheet.

## Vocabulary

  * schoolchildren – niños de la escuela - öğrenci - schüler
  * school kids – niños de la escuela - öğrenci - schüler
  * homework – tareas - ödev - hausaufgabe
  * assignments – tareas (cosas pedidas) - iş,görev - zuweisungen
  * class – clase - sınıf - klasse
  * students – estudiantes - öğrenci - schüler
  * class work – trabajo de clase - sınıf çalışması - klassaufgaben
  * schoolwork – trabajo de la escuela - okul çalışması - schulaufgaben
  * questions – preguntas, dudas - sorular - fragen
  * textbook – libro de texto -ders kitabı - lehrbuch
  * due – se debe entregar - yeterli - gerekli - aufgrund
  * to turn in – entregar - dönüş - liefernen
  * to do research – hacer investigación - araştırma yapmak - erforschen
  * to write a report – escribir un reporte - rapor yazmak - einen bericht schreiben
  * typed - escrito con máquina çeşit- örnek - typisierte
  * double-spaced – con espacio doble (entre líneas de texto) çift ara -
  * bibliography – bibliografía kaynak -bibliyografya
  * works – obras işler
  * information – información bilgi
  * books – libros kitaplar
  * library – biblioteca kütüphane
  * references – referencias danışmalar başvurmalar
  * encyclopedias – enciclopedias ansiklopedi
  * study groups – grupos de estudio çalışma grubu
  * socialize – socializar toplum içine girmek -girişgen
  * joke around – hacer bromas şakalaşmak
  * gossip – chismear dedikodu
  * younger – más jóven çok genç
  * older – más grande çok yaşlı
  * at home – en casa evde
  * study hall – periodio (sala) de estudio çalışma salonu
  * open period – periodo abierto bir ders
  * read – leer okumak
  * make trouble – hacer problemas sorun yaratmak(başbelası)
  * complain – quejarse şikayet etmek yakınmak
  * boring – aburrido sıkıcı
  * interesting – interesante ilginç ilgi çekici
  * hard – difícil (duro) zor
  * easy – fácil kolay
  * think – pensar düşünmek
  * a piece of cake – algo fácil, “un pedazo de pastel” bir parça kek
  * to finish – terminar bitmek,bitirmek,son
  * reading – lectura okuma
  * math problems – problemas de matemática matematik problemi
  * art project – projecto de arte sanat projesi
  * filling in answers – llenando respuestas cevapları doldurma
  * worksheet – hoja de trabajo çalıma kağıdı,test[kategori:türkçe](/w/index.php?title=Kategori:t%C3%BCrk%C3%A7e&action=edit&redlink=1)

{print entry|Stores, Shopping and Money}}

# Telling the Time

Talking about time is important to be able to speak English well but it can be confusing because of different sayings and formats for time in different countries.

For example, in the USA it is very rare for people to use the 24 hour clock (e.g. 18.30) when speaking or writing. The 24 hour clock is often used in the United Kingdom and Ireland but not often in spoken English.

## Asking for the time

  * What's the time?
  * What time is it?
  * Do you have the time? / Have you got the time?

## Giving the time

  * (12.00, 00.00) It's 12 o'clock / It's 12 / It's 12 (o'clock) in the morning / evening
  * (12.05, 00.05) It's five past twelve / It's 12 'oh' 5 / It's five past twelve (in the morning/afternoon) / It's five after twelve

  


# Rail Travel

RAIL TRAVEL **Buying a train ticket**

A young traveller goes up to the ticket office in a Railway Station in England:

  * Traveller: "A ticket to Coventry, please."
  * Clerk: "Is that a single or a return?"
  * Traveller: "A return, please. "
  * Clerk: "That's five pounds seventy then."
  * (The traveller hands over a ten pound note.)
  * The Ticket Clerk takes the money and gives out a two part ticket along with some coins.
  * Clerk: "Four pounds thirty is your change. Platform 3, you'd better hurry."
  * Traveller: "Thanks"

The young traveller checks his change and hurries off as the Ticket Clerk serves the next passenger.

(Note that the exchange tends to be hurried and clipped. Flowery, extended sentences aren't needed, just the required information, a little courtesy, and a check of the coins and the tickets. Mistakes do happen, especially if you are in a hurry.)

A quick check now can save problems later:

The traveller rushes back to the ticket office, and tries to speak to the same Ticket Clerk:

  * Traveller: "Sorry, these tickets say Daventry not Coventry"
  * Clerk: "You said Daventry, sir."
  * Traveller: "I'm sure I did not. I wanted a ticket to Coventry."
  * Clerk: "Let's have a look then."
  * (The Clerk takes the tickets back and examines the two pieces of the ticket.)
  * Clerk: "OK. Return to Coventry, same fare."
  * (The Clerk prints out two new parts to the ticket.)
  * Clerk: "Here you go. Coventry, return."
  * (The Clerk passes the new ticket back to the Traveller.)
  * Traveller: "Thank you very much."

The traveller hurries off again with the correct tickets, just in time to board the train to Coventry.

* * *

There are many ways to ask the same question (or be asked):

  * "Is this the train to Liverpool?"
  * "Is this the train for Liverpool?"
  * "Does this train go to Liverpool?"
  * "This the Liverpool train?" (notice that the "is" can be left out in general speech)
  * "Going to Liverpool?"
  * "Liverpool train?"
  * "Liverpool?" (although this can be confusing, meaning many things in just one word.)

(Note that some of these sentences are technically incorrect, but are acceptable in general speech. When writing English, outside of character dialogue or quotation, be specific and grammatically correct.)

  * **Glossary**
    * Luggage - Bags carried by a passenger. Can be suitcases, backpacks, boxes or any bag.
    * Lost Luggage - An office where items that passengers have forgotten are taken.
    * Fare - The cost of the ticket.
    * Ticket - The token given to a passenger to allow them to travel, showing the cost and destination etc.
    * Guard - on British trains, a train company worker checking tickets and keeping passengers safe.
    * Change - The money returned to somebody who paid with more than the cost of the transaction.
    * Train - A group of carriages rolling along rails, carrying passengers or freight.
    * Passenger - A person, usually not counting the driver, riding in a vehicle.
    * Return - A type of ticket allowing _there and back_ travel.
    * Single - A type of ticket allowing one way travel, that is just to _there_.
    * Destination - another word for the place the train passenger is going to.

  


# Links

External links:

  * [List of idioms in the English language](//en.wikipedia.org/wiki/List_of_idioms_in_the_English_language)
  * [Resources (online grammar tests, handouts, video-based exercises) for ESL students](http://www.learnenglishfeelgood.com/)
  * [Vocabulary exercises for beginners](http://www.learningchocolate.com/)
  * [ESL Resources including Lesson Plans, Worksheets, Handouts and Games](https://www.esl101.com/resources)
  * [Grammar and Vocabulary for ESL Students](http://www.eflnet.com/)
  * [English Exercises Online](http://www.smic.be/smic5022/)
  * [Exercises and handouts for beginners](http://www.clearbluerecords.com/esl)
  * [Activities for ESL Students](http://a4esl.org/)
  * [English Club](http://www.englishclub.com/), a free site for students and teachers.
  * [valodas](http://www.valodas.com/) Free language learning software.
  * [Ruler of the Wall](http://www.langwidge.com/ruler_of_the_wall_updated.pdf) \-- A game designed to run in the background of a classroom to encourage writing and dialog.
  * [Idiom Connections](http://www.certifiedchinesetranslation.com/idioms/)
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=English_as_an_Additional_Language/Print_version&oldid=1436863](http://en.wikibooks.org/w/index.php?title=English_as_an_Additional_Language/Print_version&oldid=1436863)" 

[Category](/wiki/Special:Categories): 

  * [English as an Additional Language](/wiki/Category:English_as_an_Additional_Language)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=English+as+an+Additional+Language%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=English+as+an+Additional+Language%2FPrint+version)

### Namespaces

  * [Book](/wiki/English_as_an_Additional_Language/Print_version)
  * [Discussion](/wiki/Talk:English_as_an_Additional_Language/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=English_as_an_Additional_Language/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=English_as_an_Additional_Language/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=English_as_an_Additional_Language/Print_version&action=edit)
  * [View history](/w/index.php?title=English_as_an_Additional_Language/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/English_as_an_Additional_Language/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/English_as_an_Additional_Language/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=English_as_an_Additional_Language/Print_version&oldid=1436863)
  * [Page information](/w/index.php?title=English_as_an_Additional_Language/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=English_as_an_Additional_Language%2FPrint_version&id=1436863)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=English+as+an+Additional+Language%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=English+as+an+Additional+Language%2FPrint+version&oldid=1436863&writer=rl)
  * [Printable version](/w/index.php?title=English_as_an_Additional_Language/Print_version&printable=yes)

  * This page was last modified on 8 March 2009, at 09:54.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/English_as_an_Additional_Language/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
