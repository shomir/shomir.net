# General Biology/Print version

From Wikibooks, open books for an open world

< [General Biology](/wiki/General_Biology)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=General_Biology/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=General_Biology/Print_version) on _15 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=General_Biology/Print_version&oldid=2501994&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

## Contents

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Book](/w/index.php?title=Book&action=edit&redlink=1)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=General_Biology/Print_version&action=purge&printable=yes) this page.

# General Biology Textbook

# Getting Started

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Biology - The Life Science

The word _**biology**_ means, "the science of life", from the Greek **bios,** _life_, and **logos,** _word_ or _knowledge._ Therefore, Biology is the science of Living Things. That is why Biology is sometimes known as Life Science.

The science has been divided into many subdisciplines, such as [botany](/wiki/Botany), bacteriology, [anatomy](/wiki/Anatomy), zoology, histology, mycology, embryology, parasitology, [genetics](/wiki/Genetics), [molecular biology](/w/index.php?title=Molecular_Biology&action=edit&redlink=1), systematics, immunology, [microbiology](/wiki/Microbiology), physiology, [cell biology](/wiki/Cell_Biology), cytology, [ecology](/wiki/Ecology), and virology. Other branches of science include or are comprised in part of biology studies, including [paleontology](/wiki/Paleontology), taxonomy, evolution, phycology, helimentology, protozoology, entomology, biochemistry, biophysics, biomathematics, bio engineering, bio climatology and anthropology.

  


## Characteristics of life

Not all scientists agree on the definition of just what makes up life. Various characteristics describe most living things. However, with most of the characteristics listed below we can think of one or more examples that would seem to break the rule, with something nonliving being classified as living or something living classified as nonliving. Therefore we are careful not to be too dogmatic in our attempt to explain which things are living or nonliving.

  * Living things are composed of **matter structured in an orderly way** where simple molecules are ordered together into much larger macromolecules.

An easy way to remember this is GRIMNERD C All organisms; - **G**row, **R**espire, **I**nteract, **M**ove, Need **N**utrients, **E**xcrete (Waste), **R**eproduce,**D**eath, **C**ells (Made of)

  * Living things are **sensitive,** meaning they are able to **respond to stimuli.**
  * Living things are able to **grow**, **develop**, and **reproduce**.
  * Living things are able to **adapt** over time by the process of **natural selection**.
  * All known living things use the **hereditary molecule, [DNA](//en.wikipedia.org/wiki/DNA)**.
  * Internal functions are coordinated and **regulated** so that the internal environment of a living thing is relatively constant, referred to as **[homeostasis](//en.wikipedia.org/wiki/homeostasis).**

Living things are organized in the microscopic level from atoms up to [cells](//en.wikipedia.org/wiki/cell). Atoms are arranged into molecules, then into [macromolecules](//en.wikipedia.org/wiki/macromolecule), which make up [organelles](//en.wikipedia.org/wiki/organelle), which work together to form cells. Beyond this, cells are organized in higher levels to form entire multicellular organisms. Cells together form [tissues](/wiki/General_Biology/Tissues), which make up organs, which are part of organ systems, which work together to form an entire organism. Of course, beyond this, organisms form populations which make up parts of an ecosystem. All of the Earth's ecosystems together form the diverse environment that is the earth.

Example:-

sub atoms, atoms, molecules, cells, tissues, organs, organ systems, organisms, population, community, eco systems

## Nature of science

Science is a **methodology** for **learning about the world**. It involves the **application of knowledge**.

The scientific method deals with **systematic investigation**, **reproducible results**, the formation and testing of **hypotheses**, and **reasoning.**

Reasoning can be broken down into two categories, **induction** (specific data is used to develop a generalized observation or conclusion) and **deduction** (general information leads to specific conclusion). Most reasoning in science is done through induction.

Science as we now know it arose as a discipline in the 17th century.

## Scientific method

The scientific method is not a step by step, linear process. It is an intuitive process, a methodology for learning about the world through the application of knowledge. Scientists must be able to have an "imaginative preconception" of what the truth is. Scientists will often observe and then hypothesize the reason why a phenomenon occurred. They use all of their knowledge and a bit of imagination, all in an attempt to uncover something that might be true. A typical scientific investigation might go like so:

    You _observe_ that a room appears dark, and you ponder _why_ the room is dark. In an attempt to find explanations to this curiosity, your mind unravels several different _hypotheses_. One hypothesis might state that the lights are turned off. Another hunch might be that the room's lightbulb has burnt out. Worst yet, you could be going blind. To discover the truth, you _experiment_. You feel your way around the room and find a light switch and turn it on. No light. You _repeat_ the experiment, flicking the switch back and forth. Still nothing. That means your initial hypothesis, the room is dark because the lights are off, has been _rejected_. You devise more experiments to test your hypotheses, utilizing a flashlight to prove that you are indeed not blind. In order to _accept_ your last remaining hypothesis as the truth, you could _predict_ that changing the light bulb will fix the problem. If all your predictions succeed, the original hypothesis is valid and is accepted. In some cases, however, your predictions will not occur, in which you'll have to start over. Perhaps the power is off.

![](//upload.wikimedia.org/wikipedia/commons/6/66/Ap_biology_scienceofbiology01.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

**How Science is Done**  
A diagram that illustrates scientific investigation

  
Scientists first make observations that raise a particular question. In order to explain the observed phenomenon, they develop a number of possible explanations, or hypotheses. This is the inductive part of science, observing and constructing plausible arguments for why an event occurred. Experiments are then used to eliminate one of more of the possible hypotheses until one hypothesis remains. Using deduction, scientists use the principles of their hypothesis to make predictions, and then test to make sure that their predictions are confirmed. After many trials (repeatability) and all predictions have been confirmed, the hypothesis then may become a theory.

**Quick Definitions**

    **Observation** \- Quantitative and qualitative measurements of the world.
    **Inference** \- Deriving new knowledge based upon old knowledge.
    **Hypotheses** \- A suggested explanation.
    **Rejected Hypothesis** \- An explanation that has been ruled out through experimentation.
    **Accepted Hypothesis** \- An explanation that has not been ruled out through excessive experimentation and makes verifiable predictions that are true.
    **Experiment** \- A test that is used to rule out a hypothesis or validate something already known.
    **Scientific Method** \- The process of scientific investigation.
    **Theory** \- A widely accepted hypothesis that stands the test of time. Often tested, and usually never rejected.

The scientific method is based primarily on the testing of hypotheses by experimentation. This involves a **control**, or subject that does not undergo the process in question. A scientist will also seek to limit variables to one or another very small number, single or minimum number of variables. The procedure is to form a hypothesis or prediction about what you believe or expect to see and then do everything you can to violate that, or falsify the hypotheses. Although this may seem unintuitive, the process serves to establish more firmly what is and what is not true.

A founding principle in science is a lack of absolute truth: the accepted explanation is the most likely and is the basis for further hypotheses as well as for falsification. All knowledge has its relative uncertainty.

**Theories** are hypotheses which have withstood repeated attempts at falsification. Common theories include evolution by natural selection and the idea that all organisms consist of cells. The scientific community asserts that much more evidence supports these two ideas than contradicts them.

## Charles Darwin

![Hw-darwin.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Hw-darwin.jpg/130px-Hw-darwin.jpg)

Charles Darwin is most remembered today for his contribution of the theory of **evolution through natural selection**.

The seeds of this theory were planted in Darwin's mind through observations made on a five-year voyage through the New World on a ship called the Beagle. There, he studied fossils and the geological record, geographic distribution of organisms, the uniqueness and relatedness of island life forms, and the affinity of island forms to mainland forms.

Upon his return to England, Darwin pondered over his observations and concluded that evolution must occur through natural selection. He declined, however, to publish his work because of its controversial nature. However, when another scientist, Wallace, reached similar conclusions, Darwin was convinced to publish his observations in 1859. His hypothesis revolutionized biology and has yet to be falsified by empirical data collected by mainstream scientists.

## After Darwin

Since Darwin's day, scientists have amassed a more complete **fossil record**, including **microorganisms** and **chemical fossils**. These fossils have supported and added subtleties to Darwin's theories. However, the age of the Earth is now held to be much older than Darwin thought. Researchers have also uncovered some of the preliminary mysteries of the mechanism of heredity as carried out through **genetics** and **DNA**, areas unknown to Darwin. Another growing area is **comparative anatomy** including homology and analogy.

Today we can see a bit of evolutionary history in the **development** of embryos, as certain (although not all) aspects of development recapitulate evolutionary history.

The [molecular biology](/w/index.php?title=Molecular_biology&action=edit&redlink=1) study of slowly mutating genes reveal considerable evolutionary history consistent with fossil and anatomical record.

## Challenges to Darwin

![Editorial cartoon depicting Charles Darwin as an ape \(1871\).jpg](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Editorial_cartoon_depicting_Charles_Darwin_as_an_ape_%281871%29.jpg/125px-Editorial_cartoon_depicting_Charles_Darwin_as_an_ape_%281871%29.jpg)

Darwin and his theories have been challenged many times in the last 150 years. The challenges have been primarily religious based on a perceived conflict with the preconceived notion of creationism. Many of those who challenge Darwin have been adherents to the young earth hypothesis that says that the Earth is only some 6000 years old and that all species were individually created by a god. Some of the proponents of these theories have suggested that chemical and physical laws that exist today were different or nonexistent in earlier ages. However, for the most part, these theories are either not scientifically testable and fall outside the area of attention of the field of biology, or have been disproved by one or more fields of science.

_This text is based on notes very generously donated by Dr. Paul Doerder, Ph.D., of Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# The Nature of Molecules

## [Matter](//en.wikipedia.org/wiki/Matter)

Matter is defined as anything that has [mass](//en.wikipedia.org/wiki/mass) (an amount of matter in an object) and occupies [space](//en.wikipedia.org/wiki/space#Physics) (which is measured as [volume](//en.wikipedia.org/wiki/volume)).

  * Particles, from smallest to largest 
    1. Subatomic particles 
      * [Electrons](//en.wikipedia.org/wiki/Electrons)
      * [Protons](//en.wikipedia.org/wiki/Protons)
      * [Neutrons](//en.wikipedia.org/wiki/Neutrons)
    2. Atoms
    3. Molecules
    4. Macromolecules
  * Origin of matter 
    1. [Big Bang](//en.wikipedia.org/wiki/Big_Bang), about 13.7 billion years ago
    2. [Hydrogen](//en.wikipedia.org/wiki/Hydrogen), [helium](//en.wikipedia.org/wiki/Helium)
    3. Heavier elements formed in suns, super nova 
      * Earth's matter predates formation of sun, 4.5 billion years ago
  * All matter consists of atoms, which are composed of : electrons, protons, neutrons

## [The atom](//en.wikipedia.org/wiki/Atom)

  * Example: Hydrogen 
    * The simplest element
    * One proton (+)
    * One electron in orbit (-)
  * Built by adding one proton (and one electron) at a time
  * Number of protons determines atomic number and number of electrons
  * Neutrons 
    * Neutral charge
    * Contribute mass
    * May decay
  * [Oxygen](//en.wikipedia.org/wiki/Oxygen)
    * 8 protons (mass)
    * 8 electrons
    * 8 neutrons (mass)

## Mass and isotopes

  * Atomic mass 
    * Sum of masses of protons and neutrons
    * Measured in daltons or AMU (Atomic Mass Unit)
    * An AMU is 1/12 the mass of Carbon-12
    * proton ~1 AMU or dalton
    * 6.024 x 1023 daltons/gram
  * Atoms with same atomic number belong to same element
  * Isotopes 
    * Same atomic number but different atomic mass
    * Some are radioactive
    * Uses of isotopes 
      * Radioactive: 3H, 14C, 32P, 35S 
        * Tracers in biochemical reactions
        * Detection of molecules in recombinant DNA technology (genetic engineering)
        * Half-life: dating of rocks, fossils
      * Non-radioactive (N, C, O) 
        * Diet of organisms (including fossils)
        * Biochemical tracers

## Electrons

  * Negative charge
  * Held in orbit about nucleus by attraction to positively charged nucleus
  * Atom may gain or lose electron, altering charge 
    * Cation: loses electron, positive charge 
      * Na+
    * Anion: gains electron, negative charge 
      * Cl-
  * Determine chemical properties of atoms 
    * Number
    * Energy level

## Chemical bonds

  * Form molecules
  * Enzymes: make, break, rearrange chemical bonds in living systems
  * Ionic
  * Covalent 
    * Sharing of one or more pairs of electrons 
      * Called single, double, or triple
    * No net charge (as in ionic bonds)
    * No free electrons
    * Give rise to discrete molecules
    * Hydrogen

## Chemical reactions

  * Formation and breaking of chemical bonds
  * Shifting arrangement of atoms
  * Reactants -> products
  * Reactions are influenced by: 
    * Temperature
    * Concentration of reactants, products
    * Presence of catalysts (enzymes)
  * Oxidation:reduction

## [Water](//en.wikipedia.org/wiki/Water)

  * Essential for life
  * ~75% earth's surface is water
  * Life evolved in water
  * Solvent for many types of solutes
  * High specific heat
  * High polarity 
    * Creates a slightly negative Oxygen and a Slightly positive hydrogen
    * allows formation of Hydrogen Bonds

### Hydrogen bonding

  * A type of polar interaction
  * Critical for: 
    * Protein structure
    * Enzymatic reactions
    * Movement of water in plant stems
  * Weak and transient
  * Powerful cumulative effect 
    * Solubility of many compounds
    * Cohesion (capillary action)
    * Lower density of ice
  * Formed between molecules other than water 
    * Protein structure
    * [DNA](//en.wikipedia.org/wiki/DNA), [RNA](//en.wikipedia.org/wiki/RNA) structure

Water organizes nonpolar molecules

  * Nonpolar molecules: no polarity (+/-) charges
  * Hydrophobic: exclude water because they don't form hydrogen bonds with it
  * Consequences: 
    * Membranes
    * Protein structure
  * Hydrophilic: polar substances associate with water

Ionization of water: H2O -> H+ \+ OH-

  * Forms a Hydrogen ion (H+), hydroxide ion (OH-)
  * Due to spontaneous breakage of covalent bond
  * At 25°C, 1 liter of water contains 10-7 moles of H+ ions: 10-7 moles/liter

pH

  * A convenient way of indicating H+ concentration
  * [pH](//en.wikipedia.org/wiki/pH) = -log[H+]
  * For water, pH = -log[10-7] = 7
  * Since for each H+ in pure water, there is one OH-, pH of 7 indicates neutrality
  * Logarithmic scale

Buffer

  * Reservoir for H+
  * Maintains relatively constant pH over buffering range

_This text is based on notes very generously donated by Dr. Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# The Chemical Building Blocks of Life

Building blocks of life

  * Carbon based: organic molecules
  * Carbohydrates: CHO
  * Lipids: CHO, water insoluble
  * Proteins: CHONS, structure/function in cells
  * Nucleic acids: CHONP, hereditary (genetic) information

## [Carbon](//en.wikipedia.org/wiki/Carbon)

  * Can make 4 [covalent bonds](//en.wikipedia.org/wiki/covalent_bonds)
    * Chains 
      * Straight
      * Branched
      * Ring
    * [Hydrocarbons](//en.wikipedia.org/wiki/Hydrocarbons) (C, H): store energy
    * Functional groups 
      * Attach to carbon
      * Alter chemical properties
      * Form macromolecules
      * Sapoteton

## [Carbohydrates](//en.wikipedia.org/wiki/Carbohydrates)

  * Principally CHO (rare N, S and P) 
    * 1C:2H:1O ratio
    * Energy rich (many C-H bonds)
  * Monosaccharides (principal: [glucose](//en.wikipedia.org/wiki/glucose)) 
    * Simple sugars
    * Principle formula: C6H12O6
    * Form rings in water solution
  * Disaccharides (sucrose, lactose)
  * Polysaccharides (starch, glycogen, cellulose, chitin)

## Stereoisomers

  * Bond angles of carbon point to corners of a tetrahedron
  * When 4 different groups are attached to a carbon, it is asymmetric, leading to various types of isomerism 
    * Stereoisomers: (D, L)
  * Same chemical properties
  * Different biological properties
  * D sugars, L amino acids

## [Lipids](//en.wikipedia.org/wiki/Lipids)

  * C-H bonds (nonpolar) instead of C-OH bonds as in carbohydrates 
    * High energy
    * Hydrophobic (insoluble in water)
  * Categories 
    * Fats: glycerol and three fatty acids
    * Phospholipids: primary component of membranes
    * Prostaglandins: chemical messengers (hormones)
    * Steroids: membrane component; hormones
    * Terpenes: pigments; structure

### [Fatty acids](//en.wikipedia.org/wiki/Fatty_acid)

  * Hydrocarbon chain 
    * Even number of C, 14->20
    * Terminates in carboxyl group
  * Saturated: contain maximum number of hydrogens (all single bonds); maximum energy
  * Unsaturated: one or more double bonds 
    * Usually higher melting point
    * Many common oils are polyunsaturated

## [Proteins](//en.wikipedia.org/wiki/Proteins)

  * Polymer of amino acids 
    * 21 different amino acids found in proteins
    * Sequence of amino acids determined by gene
  * Amino acid sequence determines shape of molecule 
    * Linked by peptide bond (covalent)
  * Functions 
    * regulate chemical reactions and cell processes [enzymes]
    * form bone and muscle; various other tissues
    * facilitate transport across cell membrane [carrier proteins]
    * fight disease [antibodies]
  * Motifs: folding patterns of secondary structure
  * Domains: structural, functional part of protein often independent of another part; often encoded by different exons
  * Shape determines protein's function

### [Amino acids](//en.wikipedia.org/wiki/Amino_acids)

  * 21 commonly found in proteins 
    * 21st is selenocysteine, not mentioned in text
  * Common structure 
    * Amino group: NH2
    * Carboxyl group: COOH
    * R group- 4 different kinds of R groups 
      * acidic
      * basic
      * hydrophilic (polar)
      * hydrophobic (nonpolar)
  * Confer individual properties on amino acids
  * [List of amino acids](//en.wikipedia.org/wiki/Amino_acid#List_of_amino_acids)

### Structure

  * Primary structure: the amino acid sequence 
    * Determines higher orders of structure
    * Critical for structure and function of protein
  * Secondary: stabilized by intramolecular hydrogen bonding 
    * helix
    * sheet
  * Tertiary: folding, stabilized by ionic bonds (between R groups), hydrogen bonding, van der Waal's forces, hydrophobic interactions
  * Quaternary: _ 2 polypeptides

### Function

  * Requires proper folding, cofactors, pH, temperature, etc.
  * Proteins are often modified after synthesis 
    * Chemical modification
    * Addition of heme groups (hemoglobin, cytochrome)
  * Denatured proteins can not function properly
  * Proteins are degraded by proteosome as part of constant turnover of cell components

## Hereditary (Genetic) information

  * Nucleic acids 
    * DNA: deoxyribonucleic acid
  * Hereditary information of all cells
  * Hereditary information for many viruses 
    * RNA: ribonucleic acid
  * Hereditary information of certain viruses ([HIV](//en.wikipedia.org/wiki/HIV))
  * Intermediate in gene expression
  * Composed of nucleotides 
    * Ribonucleotides
    * Deoxyribonucleotides

### RNA DNA origin

  * Which came first?
  * Paradox: DNA encodes protein necessary for its own replication
  * Discovery of catalytic RNA by Cech and Altman suggested that RNA might have been first self-replicating molecule
  * DNA evolved as more stable type of storage molecule

_This text is based on notes very generously donated by Dr. Paul Doerder, Ph.D., of the Cleveland State University._

Proteins: Their building block is amino acids. The bond connecting 2 of the amino acids together are called peptide bonds. One of these bonds makes a monopeptide, two a dipeptide, and any more than that makes a polypeptide. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Life: History and Origin

## Properties of life

  1. Organization: Being structurally composed of one or more cells, which are the basic units of life. 
    * prokaryote: no nucleus
    * eukaryote: membrane bound nucleus.  

  2. Sensitivity: respond to stimuli.  

  3. Energy Processing  

  4. Growth and Development  

  5. Reproduction  

    * hereditary mechanisms to make more of self; DNA based.
  6. Regulation, including homeostasis.  

  7. Evolution.

## Origin of life: 3 hypotheses

  * Extraterrestrial origin (panspermia): meteor, comet borne from elsewhere in universe 
    * evidence of amino acids and other organic material in space (but often both D & L forms)
    * questionable bacterial fossils in Martian rock

-However, this would imply that some other origin of life was likely because it would have had to happen elsewhere before it could be transported here, and the only difference would be that life did not originate on Earth.

  * Spontaneous origin on earth: primitive self-replicating macromolecules acted upon by natural selection ((macro)Evolution is one example of this)

-This is often attacked for the seeming impossibility for life to have been produced by a chemical reaction triggered by lightning and the ability of any produced DNA to actually be in a sequence that could produce a working model of life if replicated. It is also attacked for religious reasons, as it bypasses things like the idea of a supreme being directly creating humans. It also seems unlikely to some that such huge changes are possible in evolution without evidence of an "in-between stage" that is credible. Many of the stages of man are disputed due to their somewhat shakey grounds. For example, bones from other animals have been taken accidentally in some cases to be part of a humanoid, and complete skeletons have been sketched out from a limited number of bones.

  * Special creation: religious explanations (Intelligent Design is one popular example of this.) These explanations contend that life was created by God (or perhaps some other Intelligent Designer). 
    * Proponents of Intelligent design suggest that the vast complexity of life could only have been intentionally designed while other creationists cite biblical support.

-This is often attacked for many of the same reasons that religion is attacked, and is often regarded as superstitious and/or unscientific.

  * It is debated as to whether schools should teach one hypothesis or the other when talking about the origin of life. However, since they are all currently known major hypotheses (and sometimes hypotheses proven wrong are shown for educational purposes), this wikibook includes what it can without discriminating unfairly against one hypothesis or the other.

## The early earth

It is believed that the Earth was formed about 4.5 billion years ago.

  * Heavy bombardment by rubble ceased about 3.8 billion years ago.
  * Reducing atmosphere: much free H 
    * also H2O, NH3, CH4
    * little, if any, free O2
    * with numerous H electrons, require little energy to form organic compounds with C
  * Warm oceans, estimated at 49-88°C
  * Lack of O2 and consequent ozone (O3) meant considerable UV energy

Chemical reactions on early earth

  * UV and other energy sources would promote chemical reactions and formation of organic molecules
  * Testable hypothesis: Miller-Urey experiment 
    * simulated early atmospheric conditions
    * found amino acids, sugars, etc., building blocks of life
    * won Nobel prize for work
    * experiment showed prebiotic synthesis of biological molecules was possible

Issues

  * Miller later conceded that the conditions in his experiments were not representative of what is currently thought to be those of early earth
  * He also conceded that science has no answer for how amino acids could self-organize into replicating molecules and cells
  * In the 50 years since Miller-Urey, significant issues and problems for biogenesis have been identified. This is a weak hypothesis at this time.
  * Conclusion: Life exists, we don't know why.

## Origin of cells

Cells are very small and decompose quickly after death. As such, fossils of the earliest cells do not exist. Scientists have had to form a variety of theories on how cells (and hence life) was created on Earth.

  * Bubble hypothesis 
    * A. Oparin, J.B.S. Haldane, 1930’s
  * Primary abiogenesis: life as consequence of geochemical processes
  * Protobionts: isolated collections of organic material enclosed in hydrophobic bubbles 
    * Numerous variants: microspheres, protocells, protobionts, micelles, liposomes, coacervates
  * Other surfaces for evolution of life 
    * deep sea thermal vents
    * ice crystals
    * clay surfaces
    * tidal pools

## The RNA world?

  * DNA → RNA → polypeptide (protein)
  * Catalytic RNA: ribozyme 
    * discovered independently by Tom Cech and Sid Altman (Nobel prize)
    * catalytic properties: hydrolysis, polymerization, peptide bond formation, etc.
  * Self-replicating RNA molecule may have given rise to life 
    * consistent with numerous roles for RNA in cells as well as roles for ribonucleotides (ATP)
    * relationship to bubble-like structures is uncertain

## The earliest cells

  * Microfossils 
    * ~3.5 by
    * resemble bacteria: prokaryotes
    * biochemical residues
    * stromatolites
  * Archaebacteria (more properly Archaea) 
    * extremophiles: salt, acid, alkali, heat, methanogens
    * may not represent most ancient life
  * Eubacteria 
    * cyanobacteria: photosynthesis
  * atmospheric O2; limestone deposits
  * chloroplasts of eukaryotes

Cyanobacteria

## Major steps in evolution of life

  * Prebiotic synthesis of macromolecules
  * Self replication 
    * RNA? (primitive metabolism)
  * DNA as hereditary material
  * 1st cells
  * Photosynthesis
  * Aerobic respiration
  * Multicellularity (more than once)

_This text is based on notes very generously donated by Dr. Paul Doerder, Ph.D., of the Cleveland State University._

# Cells

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Cell structure

## What is a cell?

The word cell comes from the Latin word "cella", meaning "small room", and it was first coined by a microscopist observing the structure of cork. The cell is the basic unit of all living things, and all organisms are composed of one or more cells. Cells are so basic and critical to the study of life, in fact, that they are often referred to as "the building blocks of life". Organisms - bacteria, amoebae and yeasts, for example - may consist of as few as one cell, while a typical human body contains about a trillion cells.

According to _Cell Theory,_ first proposed by Schleiden and Schwann in 1839, all life consists of cells. The theory also states that all cells come from previously living cells, all vital functions (chemical reactions) of organisms are carried out inside of cells, and that cells contain necessary hereditary information to carry out necessary functions and replicate themselves. It is the basis of human life.

  
All cells contain:

  * Lipid bilayer boundary (plasma membrane)
  * Cytoplasm
  * DNA (hereditary information)
  * Ribosomes for protein synthesis

Eukaryotic cells also contain:

  * At least one nucleus
  * Mitochondria for cell respiration and energy

Cells may also contain:

  * Lysosomes
  * Peroxisomes
  * Vacuoles
  * Cell walls

### Concepts

Plasma Membrane 
    Phospholipid bilayer, which contains great amount of proteins, the most important functions are the following:

  1. It selectively isolates the content of the cell of the external atmosphere.
  2. It regulates the interchange of substances between the cytoplasm and the environment.
  3. Communicates with other cells.

Model of the fluid mosaic 
    Describes the structure of the plasma membrane, this model was developed in 1972 by cellular biologists J. Singer and L. Nicholson.
Phospholipid bilayer 
    Is in the plasma membrane and produces the fluid part of membranes.
Proteins 
    Long chains of amino acids.
Glucose proteins 
    Proteins together with carbohydrates in the plasma membrane, mostly in the outer parts of the cell.
Functions of proteins 
    Transport oxygen, they are components of hair and nails, and allow the cell interact with its environment.
Transport Proteins 
    Regulate the movement of soluble water molecules, through the plasma membrane. Some transport proteins called **channel proteins** form pores or channels in the membrane so that water soluble molecules pass.
Carrying proteins 
    Have union sites that can hold specific molecules.
Reception proteins 
    They activate **cellular responses** when specific molecules join.
Proteins of recognition 
    They work as identifiers and as place of union to the cellular surface.
Fluid 
    It is any substance that can move or change of form.
Concentration 
    Number of molecules in a determined unit of volume.
Gradient 
    Physical difference between two regions of space, in such a way that the molecules tend to move in response to the gradients.
Diffusion 
    Movement of the molecules in a fluid, from the regions of high concentration to those of low concentration.
Passive transport 
    Movement of substances in a membrane that doesn’t need to use energy.
Simple diffusion 
    Diffusion of water, gases or molecules across the membrane.
Facilitated diffusion 
    Diffusion of molecules across the membranes with the participation of proteins.
Osmosis 
    Diffusion of the water across a membrane with differential permeability.
Transport that needs energy 
    Movement of substances across a membrane generally in opposition to a gradient of concentration with the requirement of energy.
Active transport 
    Movement of small molecules using energy (ATP).
Endocytosis 
    Movement of big particles towards the interior of the cell using energy. The cells enclose particles or liquids.
Pinocytosis 
    (Literally cell drinking) Form in which the cell introduces liquids.
Phagocytosis 
    Way of eating of the cells. It feeds in this case of big particles or entire microorganisms.
Pseudopods 
    False feet (the amoeba).
Exocitosis 
    Movement of materials out of the cell with the use of energy. It throws waste material.
Isotonic 
    The cytoplasm fluid of the interior of the cells is the same that the outer.
Hypertonic solution 
    The solutions that have a higher concentration of dissolved particles than the cellular cytoplasm and that therefore water of the cells goes out with osmosis.
Hypotonic 
    The solutions with a concentration of dissolved particles lower than the cytoplasm of a cell and that therefore do that water enters the cell with osmosis.
Swelling 
    Pressure of the water inside the vacuole.
Endoplasmic Reticulum 
    It is the place of the synthesis of the cellular membrane.

### Structure and function of the cell

Rudolf Virchow 
    Zoologist, who proposed the postulates of the cellular theory, observes that the living cells could grow and be in two places at the same time, he proposed that all the cells come from other equal cells and proposed 3 postulates:

  1. Every living organism is formed from one or more cells
  2. The smallest organisms are unicellular and these in turn are the functional units of the multicellular organisms.
  3. All the cells come from preexisting cells.

### Common characteristics of all the cells

Molecular components 
    Proteins, amino acids, lipids, sweeten, DNA, RNA.
Structural components 
    Plasmatic membrane, citoplasm, ribosomes.
Robert Hooke 
    He postuled for the first time the term _cell_
Prokaryotes 
    Their genetic material is not enclosed in a membrane ex. Bacterias
Eukaryotes 
    Their genetic material is contained inside a nucleus closed by a membrane

## History of cell knowledge

The optical microscope was first invented in 17th century. Shortly thereafter scientists began to examine living and dead biological tissues in order to better understand the science of life. Some of the most relevant discovery milestones of the time period include:

  * The invention of the microscope, which allowed scientists for the first time to see biological cells
  * Robert Hooke in 1665 looked at cork under a microscope and described what he called cork "cells"
  * Anton van Leeuwenhoek called the single-celled organisms that he saw under the microscope "animalcules"
  * Matthias Jakob Schleiden, a botanist, in 1838 determined that all _plants_ consist of cells
  * Theodor Schwann, a zoologist, in 1839 determined that all _animals_ consist of cells
  * Rudolf Virchow proposed the theory that all cells arise from previously existing cells

  
In 1838, the botanist Matthias Jakob Schleiden and the physiologist Theodor Schwann discovered that both plant cells and animal cells had nuclei. Based on their observations, the two scientists conceived of the hypothesis that all living things were composed of cells. In 1839, Schwann published 'Microscopic Investigations on the Accordance in the Structure and Growth of Plants and Animals', which contained the first statement of their joint cell theory.

### Cell Theory

Schleiden and Schwann proposed spontaneous generation as the method for cell origination, but spontaneous generation (also called abiogenesis) was later disproven. Rudolf Virchow famously stated "Omnis cellula e cellula"... "All cells only arise from pre-existing cells." The parts of the theory that did not have to do with the origin of cells, however, held up to scientific scrutiny and are widely agreed upon by the scientific community today.

The generally accepted portions of the modern Cell Theory are as follows: (1) The cell is the fundamental unit of structure and function in living things. (2) All organisms are made up of one or more cells. (3) Cells arise from other cells through cellular division. (4) Cells carry genetic material passed to daughter cells during cellular division. (5) All cells are essentially the same in chemical composition. (6) Energy flow (metabolism and biochemistry) occurs within cells.

## Microscopes

  * Allow greater resolution, can see finer detail
  * Eye: resolution of ~ 100 μm
  * Light microscope: resolution of ~ 200 nm
  * Limited to cells are larger organelles within cells
  * Confocal microscopy: 2 dimension view
  * Electron microscope: resolution of ~0.2 nm
  * Laser tweezers: move cell contents

## Cell size

One may wonder why all cells are so small. If being able to store nutrients is beneficial to the cell, how come there are no animals existing in nature with huge cells? Physical limitations prevent this from occurring. A cell must be able to diffuse gases and nutrients in and out of the cell. A cell's surface area does not increase as quickly as its volume, and as a result a large cell may require more input of a substance or output of a substance than it is reasonably able to perform. Worse, the distance between two points within the cell can be large enough that regions of the cell would have trouble communicating, and it takes a relatively long time for substances to travel across the cell.

That is not to say large cells don't exist. They are, once again, less efficient at exchanging materials within themselves and with their environment, but they are still functional. These cells typically have more than one copy of their genetic information, so they can manufacture proteins locally within different parts of the cell.

**Key concepts:** Cell size:

  * Is limited by need for regions of cell to communicate
  * Diffuse oxygen and other gases
  * Transport of [mRNA](//en.wikipedia.org/wiki/RNA) and [proteins](//en.wikipedia.org/wiki/protein)
    * Surface area to volume ratio limited
  * Larger cells typically: 
    * Have extra copies of genetic information
    * Have slower communication between parts of cell

# Structure of Eukaryotic cells

[Eukaryotic](//en.wikipedia.org/wiki/Eukaryote) cells feature membrane delimited nucleii containing two or more linear [chromosomes](//en.wikipedia.org/wiki/chromosome); numerous membrane-bound cytoplasmic organelles: mitochondria, [RER](//en.wikipedia.org/wiki/RER), [SER](//en.wikipedia.org/wiki/SER), lysosomes, [vacuoles](//en.wikipedia.org/wiki/vacuole), [chloroplasts](//en.wikipedia.org/wiki/chloroplast); ribosomes and a [cytoskeleton](//en.wikipedia.org/wiki/cytoskeleton). Also, plants, fungi, and some protists have a cell wall.

## Structure of the nucleus

The nucleus is the round object in the cell that holds the genetic information (DNA) of the cell. It is surrounded by a nuclear envelope and has a nucleolus inside.

### Nuclear envelope

The nuclear envelope is a double-layered [plasma membrane](/w/index.php?title=Plasma_membrane&action=edit&redlink=1) like the cell membrane, although without membrane proteins. To allow some chemicals to enter the nucleus, the nuclear envelope has structures called [Nuclear pores](/w/index.php?title=Nuclear_pore&action=edit&redlink=1). The nuclear envelope is continuous with the endoplasmic reticulum.

### Nucleolus

The nucleolus appears in a microscope as a small dark area within the nucleus. The nucleolus is the area where there is a high amount of [DNA transcription](/w/index.php?title=DNA_transcription&action=edit&redlink=1) taking place.

## Chromatin

Chromosomes consist of [chromatin](//en.wikipedia.org/wiki/chromatin). This is made up of strings of DNA, which typically measure centimeters in length if stretched out. This DNA is wound around a [histone](//en.wikipedia.org/wiki/histone) core and organized into [nucleosomes](//en.wikipedia.org/wiki/nucleosome).

The [chromatin](//en.wikipedia.org/wiki/chromatin) must be uncoiled for [gene expression](//en.wikipedia.org/wiki/gene_expression) and [replication](//en.wikipedia.org/wiki/replication). Chromosome micrograph

## Endoplasmic reticulum

The [endoplasmic reticulum](//en.wikipedia.org/wiki/endoplasmic_reticulum) is a cellular [organelle](//en.wikipedia.org/wiki/organelle) made up of a series of extended folded intracellular membranes. It is continuous with the nuclear membane.

There are two main types of endoplasmic reticulum:

  * RER: rough endoplasmic reticulum (site of [protein synthesis](//en.wikipedia.org/wiki/protein_synthesis)) associated with ribosomes
  * SER: smooth endoplasmic reticulum (site of [lipid synthesis](//en.wikipedia.org/wiki/lipid_synthesis))

### Rough Endoplasmic Reticulum

Proteins are directed to the RER by a **signal sequence** of a growing [polypeptides](//en.wikipedia.org/wiki/polypeptide) on the ribosome. This is recognised by a signal recognition particle which brings the ribosome/polypeptide complex to a channel on the RER called a translocon. At the translocon, the signal sequence and ribosome/polypeptide complex interact with the translocon to open it. The signal sequence becomes attached to the translocon. The ribosome can continue to translate the polypeptide into the lumen of the RER. As synthesis continues, 2 processes can happen.

  1. If the protein is destined to become a membrane bound protein then the protein synthesis will continue until termination. The ribosome can then dissociate, allowing protein folding within the RER lumen to occur and continuation to the golgi apparatus for processing of the polypeptide.
  2. If the protein is destined for storage for later secretion after stimulation or for continuous secretion then a protease -an enzyme which cuts proteins at the peptide bond- can cut the signal sequence from the growing polypeptide. Continuation to the golgi etc. can then occur.

When produced, proteins are then exported to one of several locations. The proteins are either modified for extracellular membrane insertion or secretion. Note, this is in contrast with ribosomes which do not associate with the RER and produce proteins which will become cytosolic enzymes for example.

### Smooth Endoplasmic Reticulum

Smooth endoplasmic reticulum produces [enzymes](//en.wikipedia.org/wiki/enzyme) for lipid and carbohydrate biosynthesis and detoxification RER

### Sarcoplasmic Reticulum

This is a specialised form of endoplasmic reticulum found in some muscle cell types-particularly striated, skeletal muscle. Its main function is different from the other 2 types in that is mainly acts as a storage of calcium. This reticulum has voltage gated channels which respond to signals from 'motor neurones' to open and release calcium into the cytoplasm. This can then bring about the next part in muscle contraction.

![Nucleus ER golgi.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/2/25/Nucleus_ER_golgi.jpg/300px-Nucleus_ER_golgi.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

_**Figure 1 :** Image of [nucleus](//en.wikipedia.org/wiki/cell_nucleus), endoplasmic reticulum and Golgi apparatus.  
_

  1. Nucleus.
  2. Nuclear pore.
  3. Rough endoplasmic reticulum (RER).
  4. Smooth endoplasmic reticulum (SER).
  5. Ribosome on the rough ER.
  6. Proteins that are transported.
  7. Transport vesicle.
  8. Golgi apparatus.
  9. Cis face of the Golgi apparatus.
  10. Trans face of the Golgi apparatus.
  11. Cisternae of the Golgi apparatus.

## The Golgi apparatus

The [golgi apparatus](//en.wikipedia.org/wiki/Golgi_apparatus) is made up of multiple stacks of bilipid membranes.

  * Proteins made on the RER are modified and then sorted
  * Formation of secretory vesicles
  * Formation of lysosomes (intracellular digestion)

Other membrane-bound cytoplasmic organelles include:

  * [Microbodies](//en.wikipedia.org/wiki/Microbody) (generic term)
  * Glyoxysome (transforms fat into carbohydrate in plants)
  * [Peroxisome](//en.wikipedia.org/wiki/Peroxisome) (uses oxidative metabolism to form hydrogen peroxide and is destroyed by [catalase](//en.wikipedia.org/wiki/catalase))

## Ribosomes

Ribosomes are the site of protein synthesis. Ribosomes themselves are synthesized in the cell [nucleoli](//en.wikipedia.org/wiki/nucleoli) and are structured as two subunits, the large and the small. These parts are composed of RNA and protein.

Prokaryotic and eukaryotic ribosomes are different, the eukaryotic ones being larger and more complicated.

## DNA-containing organelles

**Mitochondria**

  * Double membrane
  * Aerobic metabolism, internal membrane
  * DNA, ribosomes
  * Give rise to new mitochondria

**[Chloroplast](//en.wikipedia.org/wiki/Chloroplast)**

  * Double membrane
  * Photosynthesis, internal membrane
  * DNA, ribosomes
  * Give rise to new chloroplasts

**[Centrioles](//en.wikipedia.org/wiki/Centriole)**

  * Microtubule organizing centers 
    * Animal cells and many protists
    * Pair constitutes the centrosome
    * Give rise to flagellum during spermatogenesis
  * Consist of 9 triplet microtubules
  * [Mitosis](//en.wikipedia.org/wiki/mitosis), [meiosis](//en.wikipedia.org/wiki/meiosis)

## Cytoskeleton

Cytoskeleton is a collective term for different filaments of proteins that can give physical shape within the cell and are responsible for the 'roads' which organelles can be carried along.

  * Gives the cell shape
  * Anchors other organelles
  * Vital to intracellular transport of large molecules

The cytoskeleton is composed of 3 main types of filaments:

  * [Actin](//en.wikipedia.org/wiki/Actin) filaments (7 nm)
  * [Microtubules](//en.wikipedia.org/wiki/Microtubule): (25 nm) polymer of tubulin; 13/ring.
  * [Intermediate Filaments](//en.wikipedia.org/wiki/Intermediate_Filament)

Both actin and microtubules can have associated motor proteins.

### Intermediate Filaments

These are rope like filaments, 8-10nm in diameter and tend to give the structural stability to cells. Examples inculude Vimentin, neurofilaments and keratin. It is keratin which priniciply makes up hair, nails and horns.

### Actin Filaments

##### Growth

These filaments are 2-stranded and composed of dimeric subunits called G-Actin. They contain a GTP molecule in order to bind (polymerise). As GTP is hydrolysed then the structure becomes unstable and depolymerisation occurs. The growth of actin filaments is concentration dependant-that is, the higher the concentration of free G-actin, the greater the polymerisation. The are also polar, having a + and a - end (not related to charge) and polymerisation tends to happen faster at the + end.

Cilia and flagella are threads of microtubules that extend from the exterior of cells and used to move single celled organisms as well as move substances away from the surface of the cell. motor proteins-move, wave motion **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Membranes

## Biological membranes

![](//upload.wikimedia.org/wikibooks/en/thumb/4/4f/Bilayer.png/400px-Bilayer.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Plasma membrane bilayer

Biological membranes surround cells and serve to keep the insides separated from the outsides. They are formed of [phospholipid bilayers](/w/index.php?title=Lipid_bilayer&action=edit&redlink=1), which by definition are a double layer of [fatty acid](/w/index.php?title=Fatty_acid&action=edit&redlink=1) molecules (mostly [phospholipids](/w/index.php?title=Phospholipid&action=edit&redlink=1), lipids containing lots of phosphorus).

[Proteins](/w/index.php?title=Proteins&action=edit&redlink=1) serve very important functions in cellular membranes. They are **active transports** in and out of the cell, acting as gatekeepers. They relay **signals** in and out of the cell. Proteins are the **site of many enzymatic reactions** in the cell, and play a role in **regulation of cellular processes.**

## Phospholipid

Phospholipid bilayer

  * basis of biological membranes and cellular organisms
  * contains a charged, hydrophilic (attracted to water) head and two hydrophobic (repelled by water) hydrocarbon tails
  * In presence of water, phospholipids form bilayer 
    * maximize hydrogen bonds between water
    * creates barrier to passage of materials
    * fluid mosaic model shows horizontal (common) and "flip-flop" (rare) movement of phospholipids

## Fluid mosaic model

  * Current model of membrane
  * Phospholipid bilayer 
    * Phospholipids
  * Move freely in lipid layer, but rarely switch layers
  * Different phospholipids in each layer in different organelles 
    * Glycolipids
    * Sterols (cholesterol in animals)
  * Transmembrane proteins "float" in fluid lipid bilayer 
    * also called intrinsic, integral proteins
  * Exterior (extrinsic, peripheral) proteins

## Membrane proteins

  * Transport channels
  * Enzymes
  * Cell surface receptors
  * Cell surface identity markers
  * Cell adhesion proteins
  * Attachments to cytoskeleton

Integral membrane proteins

  * Anchoring to membrane 
    * Protein has attached phosphatidylinositol (GPI) linkage, anchors protein in outer layer (no picture)
    * Protein has one or more hydrophobic transmembrane domains
  * -helix
  * -sheet

  


* * *

**Channel protein** Transport across membranes *** Diffusion**

  *     * From higher concentration to lower concentration
    * Membranes are selectively permeable
  * Ions diffuse through membrane channels 
    * Selective
    * Movement determined by diffusion and voltage differences
  * **Facilitated diffusion**
    * Carrier protein, physically binds transported molecule
  * **Osmosis**
  * Diffusion of water down concentration gradient
  * In cell: various solutes (amino acids, ions, sugars, etc.) 
    * interact with water, e.g., hydration shells
  * Water moves through aquaporin channels into cell
  * Depends upon the concentration of all solutes in solution 
    * Hyperosmotic solution: higher concentration of solutes
    * Hypoosmotic solution: lower concentration of solutes
    * Isoosmotic solution: solute concentrations equal
  * Water moves from hypoosmotic solution to hyperosmotic solution

Osmotic pressure **Bulk transport**

  * Endocytosis: energy requiring 
    * Phagocytosis
  * Solid material, typically food 
    * Pinocytosis
  * Primarily liquid

**** Receptor-mediated endocytosis**

  * Pits on cell surface coated with clathrin and receptors
  * Bind specific proteins
  * Exocytosis 
    * Discharge of materials from vesicle at cell surface

## Receptor-mediated endocytosis

Active transport

  * Energy required (usually ATP)
  * Highly selective
  * Works against concentration gradient
  * Many examples, e.g., Na+/K+ pump

Cotransport (coupled transport)

  * Does not use ATP directly
  * Molecule is transported in connection with another molecule that is moving down a concentration gradient 
    * Example: Na+ gradient is established by a Na+ pump, with higher concentration on outside of cell. Cotransport channel carries Na+ and another molecule (e.g. glucose) into cell
  * May involve proton (H+) pumps (chemiosmosis - ATP production)

_This text is based on notes very generously donated by Dr. Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Cell-cell interactions

with the environment with each other

  


## Cell signaling

  * Signaling requires 
    * Signal
    * Cell receptor (usually on surface)
  * Signaling is important in: 
    * Response to environmental stimuli
    * Sex
    * Development
  * Major area of research in biology today

### Types of signaling

  * Direct contact (e.g., gap junctions between cells)
  * Paracrine: Diffusion of signal molecules in extracellular fluid; highly local
  * Endocrine: Signal (hormone) molecule travels through circulatory system
  * Synaptic: neurotransmitters

#### Types of signal molecules

  * Hormones: chemically diverse 
    * Steroid
    * Polypeptide
    * Vitamin/amino acid derived
  * Cell surface proteins/glycoproteins
  * Ca2+, NO
  * Neurotransmitter 
    * Several hundred types
    * Some are also hormones e.g. Estrogen, progesterone

#### Receptor molecules

  * Intracellular 
    * Protein that binds signal molecule in cytoplasm
    * Bound receptor may act as:
  * Gene regulator
  * Enzyme
  * Cell surface 
    * Gated ion channels (neurotransmitter receptor)
    * Enzymic receptors
    * G protein-linked receptors

##### Cell surface protein

  * Tissue identity 
    * glycolipids
    * MHC proteins
  * Immune systems 
    * distinguish self from not-self
  * Intercellular adhesion 
    * permanent contact
    * help form sheets of cells, tissues
    * may permit signaling

###### Example: G proteins

  * Transmembrane surface receptor binds signal molecule
  * Conformational change allows binding of G protein on cytoplasmic side
  * G protein binds GTP, becomes activated
  * G protein activates intracellular signal cascade 
    * Change in gene expression
    * Secrection
    * Many other possible consequences

## Communicating junctions

  * Gap junctions 
    * animals
    * small molecules and ions may pass
  * Plasmodesmata 
    * plants
    * lined with plasma membrane
    * permit passage of water, sugars, etc.

### Gap junctions

_This text is based on notes very generously donated by Dr. Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Energy and Metabolism

## Energy

  * The capacity to do work. 
    * Kinetic energy: energy of motion (ex. jogging).
    * Potential energy: stored energy (ex. a lion that is about to leap on its prey).
  * Many forms of energy: e.g., 
    * Heat
    * Sound
    * Electric current
    * Light
    * All convertible to heat
  * Most energy for biological world is from sun
  * Heat (energy of random molecular motion, thermal energy) 
    * Convenient in biology
    * All other energy forms can be converted to heat
    * Thermodynamics: study of thermal energy
  * Heat typically measured in kilocalories 
    * Kcal: 1000 calories
    * 1 calorie: amount of heat required to raise the temperature of one gram of water one degree Celsius (°C)
  * Heat plays major role in biological systems 
    * Ecological importance
    * Biochemical reactions

## Oxidation–Reduction

  * Energy flows into biological world from sun
  * Light energy is captured by photosynthesis 
    * Light energy raises electrons to higher energy levels
    * Stored as potential energy in covalent C-H bonds of sugars
  * Strength of covalent bond is measured by amount of energy required to break it 
    * 98.8 kcal/mole of C-H bonds
  * In chemical reaction, energy stored in covalent bonds may transfer to new bonds. When this involves transfer of electrons, it is oxidation–reduction reaction
  * Always take place together 
    * Electron lost by atom or molecule through oxidation is gained by another atom or molecule through reduction
    * Potential energy is transferred from one molecule to another (but never 100%)
  * Often called redox reactions 
    * Photosynthesis
    * Cellular Respiration
    * Chemiosynthesis
    * Autotrophs
    * Heterotrophs

## NAD+

  * Common electron acceptor/donor in redox reactions
  * Energetic electrons often paired with H+

## Free energy

  * Energy required to break and subsequently form other chemical bonds 
    * Chemical bonds: sharing of electrons, tend to hold atoms of molecule together
    * Heat, by increasing atomic motion, makes it easier to break bonds (entropy)
  * Energy available to do work in a system
  * In cells, G = H - TS 
    * G = Gibbs’ free energy
    * H = H (enthalpy) energy in molecule’s chemical bonds
    * TS (T, temperature in °K; S, entropy)
  * Chemical reactions break and make bonds, producing changes in energy
  * Under constant conditions of temperature, pressure and volume, ΔG = ΔH - TΔS
  * ΔG, change in free energy 
    * If positive (+), H is higher, S is lower, so there is more free energy; endergonic reaction, does not proceed spontaneously; require input of energy (e.g., heat)
    * If negative (–), H is lower, S is higher. Product has less free energy; exergonic; spontaneous

## =Activation energy =

  * Reactions with –ΔG often require activation energy 
    * e.g., burning of glucose
    * Must break existing bonds to get reaction started
  * Catalysts lower activation energy

## Enzymes

  * Biological catalysts 
    * Protein
    * RNA (ribozyme)
  * Stabilizes temporary association between reactants (substrates) to facilitate reaction 
    * Correct orientation
    * Stressing bonds of substrate
  * Lower activation energy
  * Not consumed (destroyed) in reaction

### Carbonic anhydrase

  * Important enzyme of red blood cells
  * CO2 \+ H2O → H2CO3 -> HCO3 \+ H+
  * Carbonic anhydrase catalyzes 1st reaction 
    * Converts water to hydroxyl
    * Orients the hydroxyl and CO2

### Enzyme mechanism

  * One or more active sites which bind substrates (reactants) 
    * Highly specific
  * Binding may alter enzyme conformation, inducing better fit

### Factors affecting enzyme activity

  * Substrate concentration
  * Product concentration
  * Cofactor concentration
  * Temperature
  * pH
  * Inhibitors 
    * Competitive: bind to active site
    * Noncompetitive: bind to 2nd site, called allosteric site; changes enzyme conformation
  * Activators 
    * Bind to allosteric sites, increase enzyme activity

#### Cofactors

  * Required by some enzymes
  * Positively charged metal ions 
    * e.g., ions of [Zn](/w/index.php?title=Zinc&action=edit&redlink=1), Mo, Mg, Mn
    * Draw electrons away from substrate (stress chemical bonds)
  * Non-protein organic molecules (coenzymes) 
    * E.g., NAD+, NADP+, etc.
    * Major role in oxidation/reduction reactions by donating or accepting electrons

## ATP

  * Adenosine triphosphate
  * Major energy currency of cells, power endergonic reactions
  * Stores energy in phosphate bonds 
    * Highly negative charges, repel each other
  * Makes these covalent bonds unstable 
    * Low activation energy
  * When bonds break, energy is transferred
  * ATP → ADP + Pi + 7.3 kcal/mole

## Biochemical pathways

  * Metabolism: sum of chemical reactions in cell/organism
  * Many anabolic and catabolic reactions occur in sequences (biochemical pathways)
  * Often highly regulated

Evolution of biochemical pathways

  * Protobionts or 1st cells likely used energy rich substrates from environment
  * Upon depletion of a substrate, selection would favor catalyst which converts another molecule into the depleted molecule
  * By iteration, pathway evolved backward

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Respiration: harvesting of energy

Glucose + O2 → CO2 \+ H2O + ATP

## Energy

  * Energy is primarily in C-H bonds (C-O too)
  * Chemical energy drives metabolism 
    * Autotrophs: harvest energy through photosynthesis or related process (plants, algae, some bacteria)
    * Heterotrophs: live on energy produced by autotrophs (most bacteria and protists, fungi, animals)
  * Digestion: enzymatic breakdown of polymers into monomers
  * Catabolism: enzymatic harvesting of energy
  * Respiration: harvesting of high energy electrons from glucose

## Respiration

  * Transfer of energy from high energy electrons of glucose to ATP
  * Energy depleted electron (with associated H+) is donated to acceptor molecule 
    * Aerobic respiration: oxygen accepts electrons, forms water
    * Anaerobic respiration: inorganic molecule accepts hydrogen/electron
    * Fermentation: organic molecule accepts hydrogen/electron

## Respiration of glucose

  * C6H12O6 \+ 6 O2 → 6 CO2 \+ 6 H2O + energy
  * ΔG = -720 kcal/mole under cellular conditions
  * Largely from the 6 C-H bonds
  * Same energy whether burned or catabolized
  * In cells, some energy produces heat, most is transferred to ATP

## Alternative anaerobic respiration

  * Methanogens (Archaebacteria). 
    * CO2 is electron acceptor, forming CH4
  * Sulfur bacteria 
    * SO4 reduced to H2S
    * Formation of H2S set stage for evolution of photosynthesis (H2S as electron donor before H2O)
    * About 2.7 by, based on ratio of 32S/34S, where only biological processes produce 32S enrichment

## Glycolysis overview

Glycolysis accounting

  * Oxidation 
    * Two electrons (one proton) are transferred from each G3P to NAD+ forming NADH

2NADH

  * Substrate level phosphorylation 
    * G3P to pyruvate forms 2 ATP molecules
    
    
    4 ATP (from 2 G3P) 
    

–2 ATP (priming)
    
    
     2 ATP (net gain)
    

Summary: The net input of glycolysis is 2 ATP molecules which are used to split one glucose molecule. The net yield of this step is 2 ATP and 2 pyruvate.

## Regeneration of NAD+

  * Reduction of NAD+ to NADH can deplete NAD+ supply; it must be regenerated
  * Two pathways, coupled to fate of pyruvate 
    * With oxygen: enter electron transport chain, forming water (and ATP)
    * Without oxygen: fermentation
  * lactate
  * ethanol

## Alcohol fermentation

## Lactate formation

Either [lactic acid](//en.wikipedia.org/wiki/Lactate) or alcohol can be formed as a result of anaerobic respiration in cells.

## Krebs cycle: overview

  * Matrix of mitochondrion
  * Priming steps 
    * Joining of acetyl-CoA to oxaloacetate
    * Isomerization reactions
  * Energy extraction steps in Krebs cycle 
    * Per glucose
  * 6 NADH
  * 2 FADH2
  * 2 ATP (from GTP)
  * 4 CO2

## ATP production

  * Chemiosmosis (Mitchell)
  * H+ (from NADH and FADH2) is pumped against a gradient into the intermembranal space of the mitochondrion (creates voltage potential)
  * Diffusion back into matrix through ATP synthase channels drives synthesis of ATP (ADP + Pi → ATP)
  * ATP exits mitochondrion by facilitated transport

## Evolution of aerobic respiration

  * Preceded by evolution of photosynthesis (O2 needed; also, prior evolution of electron transport and chemiosmosis)
  * High efficiency of ATP production compared to glycolysis 
    * Fostered evolution of heterotrophs
    * Fostered evolution of mitochondria by endosymbiosis in eukaryotes

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Photosynthesis

**6 CO2 \+ 6 H2O → C6H12O6 \+ 6 O2**

  * One of most important reactions in history of life: 
    * source of atmospheric O2
    * ultimately led to aerobic respiration and eukaryotes
  * Responsible for bulk of glucose production
  * Early experiments showed that mass of plant must be derived from substances in the air, not the soil
  * Experiments with isotopes showed that liberated oxygen comes from water
  * Experiments also showed that light is essential but that some reactions (e.g., reduction of CO2) continue in the dark
  * Plants do two big, important things during photosynthesis: gain energy (absorb light) and build sugar (glucose).
  * Photosynthesis can be divided into two series of chemical reactions: the light (light-dependent) reactions and the dark (light-independent) reactions. In light reactions, light is absorbed; in dark reactions, sugar is built.
  * Occurs when plants, algae, and autotrophic bacteria absorb light energy and build glucose.

## Light Reactions

  * Part of the electromagnetic spectrum
  * Consists of units of energy called photons
  * Photons at UV end of spectrum have more energy than those at the red end
  * Occur on the surface of thylakoid disks
  * Chlorophyll and other plant pigments differentially absorb photons 
    * Chlorophyll a: light to chemical energy
    * Chlorophyll b: accessory chlorophyll
    * Chlorophylls absorb primarily blue and red (green reflected back, hence the green color of plants)

### Accessory pigments

  * Chlorophyll is a major light gathering pigment 
    * Absorbs light with considerable efficiency (i.e., retaining energy)
  * Accessory pigments 
    * Chlorophyll b
    * Carotenoinds
  * capture light of wavelengths not captured by chlorophylls
  * Confer other colors to plant leaves (autumn colors too)

Photosynthetic steps

  * Primary photoevent: light photon captured by photosystem and energy transferred to electron donated by water
  * Electron transport: excited electron is shuttled along imbedded series of electron carriers to proton pump and electron is transferred to acceptor
  * Chemiosmosis: transport of protons back into chloroplast drives synthesis of ATP

### The Even More Detailed Light Reactions

**What the Light Reactions Do:**

The light reactions of photosynthesis occur in chloroplasts in and on the thylakoid disks. During the light reactions, light energy charges up ATP molecules. More specifically, light turns the chloroplast into an acid battery, and this battery charges up ATP.

**How the "Chloroplast-Battery" Charges ATP:**

The **stroma** is the fluid inside of the chloroplasts, and it carries a negative charge. This means that it contains about a "gazillion" extra electrons. The solvent of stroma is water.

The fluid inside the thylakoid disks is positively charged because it contains a lot of hydrogen (H+) ions. The pH here is low, making the fluid very acidic. The solvent of thylakoid disk fluid is water.

A chloroplast acts like a battery, because it has separated a strong positive charge and a strong negative charge in two different compartments. Energy is released when H+ ions (free protons) flow from the inside of a thylakoid disk to the stroma. This is electrical energy, since it is a flow of charged particles.

The protons pass through special channels (made of protein) in the thylakoid membrane; this reaction is 'exothermic.' The energy that is given off is used to fuel this reaction (Pi is the phosphate ion):
    
    
                        ADP + Pi --> ATP
    

The proton can go to the negative stroma, but only if it uses its energy to charge up ATP. Since one reaction wants to go, and the other one doesn't, and since the first reaction releases energy and the second one absorbs energy, the two reactions are known to be 'coupled' together so that the first fuels the second. Of course, a special enzyme must be involved for this to happen.

**Chlorophyll Molecules on a Thylakoid Disk:**

Hundreds of chlorophyll molecules cover the surface of a thylakoid disk, making the disk green. The nonpolar "tails" of the chlorophyll molecule are embedded in the membrane of the thylakoid.

## “Dark” reactions

  * ATP drives endergonic reactions
  * NADPH provides hydrogens for reduction of CO2 to carbohydrate (C-H bonds)
  * Occur in the stroma
  * First step in carbon fixation

### The Detailed Dark Reactions

**What the Dark Reactions Do:**

The dark reactions build sugar from carbon dioxide gas (CO2), water (H2O), and energy from ATP molecules that were charged up during the light reactions. The dark reactions occur in the stroma of a chloroplast. Dark reactions usually occur in the light, but they don't have to. They'll occur in the dark until the chloroplast's supply of ATP runs out (usually about 30 seconds).

**The Calvin Cycle:**

The Calvin Cycle is the fancy name for the metabolic pathway that builds sugar. This means that it involves a whole lot of chemical reactions, and it uses a lot of different enzymes to catalyze the reactions.

Carbon dioxide gas is stable, therefore the bonds that hold the carbon and oxygen atoms are strong. Therefore it takes a lot of energy to break the bonds and separate the carbon atoms from the oxygen atoms. The energy needed to do this comes from ATP molecules.

When inorganic carbon (like from CO2) is being added to an organic molecule (such as sugar), this is called carbon fixation.

It takes 2 complete turns of the Calvin Cycle to make a glucose molecule.

  
_Some portions of this text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._ The detailed portions are not provided by Dr. Doerder. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

How cells divide

## Prokaryote cell division

  * Binary fission 
    * Doubling of cell contents, including DNA
    * Fission to divide contents
  * Segregation of replicated genomes by growth of membrane between attachment points
  * Partitioning of cytoplasmic components
  * Escherichia coli 
    * Capable of cell division every 20 minutes under optimal conditions (DNA in continuous state of replication)
    * Model organism of bacterial cell division

## Bacterial DNA replication

  * Replication follows rules of base pairing, with each polynucleotide chain serving as template for synthesis of its complement.
  * Genetic evidence showed that the bacterial chromosome is circular long before there was corroborating physical evidence.

Eukaryotic chromosomes

  * Discovered by Walther Fleming in 1882 in dividing cells of salamander larvae, following improvements in microscopes and staining technology 
    * He called division mitosis (mitos = “thread”)
  * Chromosome number is constant in a species 
    * Ranges from 2 to >500 (46 in human somatic cells)
    * Homologous pairs, one contributed by each parent
    * Change in number is cause and consequence of speciation
  * Chromosome constancy and their precise division in mitosis and meiosis led biologists to postulate that they were carriers of hereditary information

## Chromosome number

  * 1N = number of chromosomes in gamete
  * 1N = haploid chromosome number
  * 2N = number of chromosomes in somatic cells (cells that are not egg or sperm)
  * 2N = diploid
  * Deviations from N or 2N are usually lethal in animals

Chromosome numbers

## Eukaryotic chromosomes

  * Consist of chromatin 
    * DNA and associated proteins, mainly histones
    * Nucleosomal organization
    * Euchromatin: unwound chromatin, in basic nucleosomal configuration; genes available for expression
    * Heterochromatin: highly condensed except during replication
  * Karyotype: array of chromosomes an individual possesses 
    * Clinical importance (Down syndrome; cancer)
    * Evolutionary importance (speciation)

## Chromosome organization

## Human karyotype stained by chromosome painting

## Chromosomes

  * Homologous pairs 
    * Inherited one from each parent
    * Identical in length and position of centromere
    * Contain identical or similar genes
    * Homologous pair = homologs
  * Morphology 
    * After replication, consist of two sister chromatids attached to a centromere

## Human chromosomes

  * Diploid number = 2n = 46 = 23 pairs of homologs
  * Haploid number = 23 (gametes)
  * Each replicated chromosome contains 2 sister chromatids = 92 chromatids

Cell cycle

  * Growth and division cycle of cells
  * Precisely controlled by biochemical and gene activity, except in cancer
  * Phases 
    * G1: primary growth phase
    * S: DNA replication; chromosome replication
    * G2: second growth phase; preparation for mitosis
    * M: mitosis; nuclear division
    * C: cytoplasmic division

## Mitotic cell cycle

  * Cells exiting the cell cycle are said to be in G0
  * Cell cycle time varies with stages of life cycle and development, with G1 the most variable
  * DNA replication occurs during S phase of the cell cycle following G1.
    
    
     - at this point the chromosomes are composed of two sister chromotids connected by a common centromere.
    

## Replicated human chromosomes

## Mitosis

  * Nuclear division 
    * equational division of replicated chromosomes
    * chromatids move to opposite poles
  * Continuous process 
    * prophase
    * metaphase
    * anaphase
    * telophase
  * Driven by motors and microtubules
  * No change in chromosome number 
    * N → N by mitosis
    * 2N → 2N by mitosis
  * May be accompanied by cytokinesis

Kinetochore Microtubules attach to kinetochores. Metaphase

  * Momentary alignment of chromosomes in center of cell

Anaphase

## Plant mitosis

  * Similar to animal mitosis
  * New cell wall formed between cells from membrane partition

Cell cycle control

  * Cell cycle events are regulated by protein complexes and checkpoints
  * Discovered by microinjection of proteins in to eggs, by mutational analysis and by techniques of molecular biology

Molecular control of cell cycle: Cdk and cyclin

  * Cyclin dependent protein kinase (Cdk) 
    * Phosphorylate serine/threonine of target regulatory proteins
    * Function only when bound to cyclin
  * Cyclin: short-lived proteins that bind to cdks

## Controlling the cell cycle

  * External signals initiate cell division in multicellular organisms
  * Growth factors: extracellular regulatory signals 
    * Usually soluble; bind to cell surface receptor
    * Sometimes membrane bound, requiring cell-cell contact with receptor
    * E.g., upon wound, platelets release PDGF which stimulates fibroblasts to enter cell cycle (exit G0), to heal wound

## Cancer

  * Unregulated cell proliferation
  * Cancer cells have numerous abnormalities 
    * >46 chromosomes
    * Mutations in proto-oncogenes
  * Encode proteins stimulating the cell cycle
  * May be regulated by phosphorylation
  * Often over expressed in cancer cells 
    * Mutations in tumor-suppressor genes
  * Encode proteins inhibiting the cell cycle 
    * Often bind to products of proto-oncogenes
  * May be regulated by phosphorylation

## Mutations and cancer

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Sexual reproduction

## Sexual

  * Exclusively eukaryotes
  * Fusion of two haploid genomes 
    * Fertilization (= syngamy)
    * Forms new individuals in multicellular organisms as result of fusion of egg and sperm
  * Plants
  * Animals
  * Meiosis yields haploid genomes at some point in life cycle

## Sexual life cycle

Typical animal life cycle

  * Meiosis occurs in germ line cells in gonads producing haploid gametes
  * All other cells are somatic cells
  * Alternation of generations
  * Sexual intercourse

## Meiosis

  * Gives rise to genetic variation
  * Reduction division: 2n to n
  * Preceded by one round of DNA (chromosome) replication
  * Two rounds of nuclear (& usually cell) division 
    * Meiosis I
  * Synapsis of homologs
  * Segregation of homologs
  * Reduction division, 2n to n 
    * Meiosis II
  * No chromosome replication
  * Segregation of sister chromatids
  * Formation of 4 haploid (n) cells
  * Two nuclear divisions, usually 2 cell divisions, only one round of replication
  * Meiosis I 
    * Prophase: synapsis and crossing over
    * Metaphase
    * Anaphase: chromosome segregation
    * Telophase
  * Meiosis II (mitosis-like) 
    * Prophase
    * Metaphase
    * Anaphase: sister chromosome segregation
    * Telophase

## Prophase I: synapsis

  * Complete alignment of replicated homologs
  * Synapsis occurs throughout the entire length of a pair of homologs
  * Key to chromosome segregation
  * Synapsis, crossing over
  * Subdivided into 5 continuous stages

## Crossing over

  * Reciprocal, physical exchange between nonsister chromatids
  * Type of recombination; mixes maternal and paternal genes
  * Visual evidence: chiasmata

## Microtubules and anaphase I

  * During prophase microtubules attach to kinetochores on one side of centromere
  * The metaphase checkpoint insures proper attachment
  * A phosphorylation event initiates motor activity and anaphase

## Meiosis II

  * Cytologically similar to mitosis 
    * No preceding DNA replication
    * Chromatids segregate and move to opposite poles as chromosomes
    * 4 haploid cells produced
  * In animals, these cells differentiate into gametes
  * In plants and many other organisms, these cells divide by mitosis, followed some time later by gamete formation

## Evolution of sex

  * Asexual reproduction: all offspring genetically identical to parent
  * Sex: recombination destroys advantageous combinations
  * So why sex? 
    * Many hypotheses
    * Effect repair of genetic damage?
  * Much pachytene repair as well as gene conversion
  * Some protists form diploid cells in response to stress 
    * Recombination breaks up combinations of genes favoring parasites, thus reducing parasitism?

## Consequences of sex

  * Recombination: generates genetic diversity 
    * Crossing over
    * Independent assortment
  * Random fertilization 
    * Qualities of gamete usually do NOT reflect qualities of genes enclosed in gamete

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._

# Genetics

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# [Gregor Mendel](//en.wikipedia.org/wiki/Gregor_Mendel) and biological inheritance

[Charles Darwin](/wiki/Charles_Darwin), for all he contributed to the science of biology, never knew about the mechanism by which living things inherit traits from previous generations, or how new traits arise.

As any schoolchild can tell you, this mechanism of interitance has since been found to be **[DNA](//en.wikipedia.org/wiki/DNA)**, or deoxyribonucleic acid. DNA allows for stable inheritance of traits: the code in each strand of DNA is replicated precisely through the pairing of basic units along each strand. The error rate in this replication is amazingly low; not even one base pair in a million matches out of sequence.

However, when even one base pair is added to a new strain of DNA in an order differently than in the parent chain, it can be the basis of a **mutation**. These changes in DNA sequences are the microscopic origin of changes in traits of all studied living things. Even the smallest difference in a strand of DNA can result in a change in traits that can cost the life of the organism. Mutations can produce proteins with a new or altered function. In humans, the example of [Sickle cell anemia](//en.wikipedia.org/wiki/Sickle_cell_anaemia) is commonly given as its origin is a difference of only one base pair in a section of DNA that encodes red blood cells.

Individual sequences of DNA that encode for specific proteins are called **genes** and are the units of heredity. Each one has a set [nucleotide](//en.wikipedia.org/wiki/nucleotide), and together all of the genes (and some sequence of DNA that apparently do not code for any biologically important functions) together make up the entire **[chromosome](//en.wikipedia.org/wiki/chromosome)**

## Mendel

  * Discovered principle of genetic segregation via numerous experiments utilizing pea plants
  * Inferred the existence of genes through segregation of phenotypes
  * Used quantitative methods: counted; ratios
  * Work is model of scientific method
  * In particular, observed the F2 progeny, which lead to the discovery of dominant and recessive traits
  * Published work in 1866, went unnoticed
  * In 1900 his scientific paper was “rediscovered”
  * Mendel is acknowledged as founder of Genetics 
    * still used alphabet letters to designate genes
    * still refer to dominant and recessive genes
    * still refer to segregation of alleles in meiosis
    * principle of segregation applies to all sexually reproducing organisms; Mendel’s results were immediately applied to humans in 1900

## Mendel’s experiments

  * 1856, began experiments with the garden pea, Pisum sativum
  * 1865, presented results to the Bruno natural history society, which he helped found
  * 1866, published his results in proceedings of the society
  * Naegeli encouraged Mendel to reproduce results in another species, which failed because the species did not undergo true fertilization
  * discrete traits in Pisum sativum 
    * pure-breeding lines
    * dominant/recessive alleles
  * alleles are two alternate versions of a gene 
    * gametes contain hybridized chromosomes that are formed during meiosis
    * homozygous has two of the same allele
    * heterozygous has two different alleles
  * reciprocal F1 crosses (all exhibiting dominant phenotypes); F2; F3
  * counted offspring, noted ratios
  * inferred genotypes from phenotypes
  * tested hypotheses with testcrosses
  * attempted to repeat with another species

## Mendel’s seven pairs of traits

  1. Seed form (round or wrinkled)
  2. Cotyledon color (green or yellow)
  3. Seed coat color (white or colored)
  4. Pod form (inflated or constricted)
  5. Pod color (green or yellow)
  6. Flower position (axial or terminal)
  7. Plant heights (tall or short)

## Locus

  * The location of a specific gene within a chromosome

## Modern Y chromosome

Y-chromosome is the most evolved chromosome. Generally it is thought that if Y- chromosome is present in an individual then he will be male. But if mutation occurs at sex determining region or zinc factor then it will not code for testis determining factor, and results in normal female. This type of female's frequency is 1/250000.

## Chromosome phenomena

  * X-chromosome inactivation 
    * Barr bodies
  * Nondisjunction: failure of chromosome segregation at meiosis or mitosis 
    * Results in 2N ± 1 chromosome number
  * Trisomy 2N + 1 
    * Usually lethal. Trisomy 21 (Down) exception
  * Monosomy 2N ** 1 
    * Lethal except XO
    * Usually maternal origin in humans

## X-chromosome inactivation

In females, one X-chromosone is randomly switched off forming a Barr body.

## Barr body

Dense region in the nucleus formed by the inactive X-chromosome.

## Human genetic disorders

**Down's Syndrome(Mongolism)**

Down's Syndrome is usually produced by the nondisjunction of chromosome 21 during oogenesis and sometimes during spermatogenesis. The individual suffering from this type of syndrome has 47 chromosomes instead of the normal 46. The extra chromosome is not a sex chromosome but an autosome.

Most cases of mongolism were found to occur in children born by women in their forties. The affected children, called mongoloids, show mental retardation and have a shorter life expectancy. Their most prominent feature is the Mongolian folds in their eyes; hence, the term mongolism.

**Klinefelter's Syndrome**

When an XY-bearing sperm unites with an X-bearing egg, the resulting condition is called Klinefelter's Syndrome, or sexually undeveloped male. Individuals having the syndrome show the following characteristics:

  * testes are small
  * sperms are never produced
  * breasts are enlarged
  * body hair is sparse
  * individuals are mentally defective

The same abnormal meiotic division may occur in females. They produce eggs with XX or no sex chromosomes. Such egg, when fertilized by a Y-bearing sperm, will not develop (YO). This is because YO is lethal--it wil cause death to the offspring. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# DNA: The Genetic Material

## DNA

DNA stands for _Deoxyribose Nucleic Acid_. That is, a nucleic acid with two sugars. DNA is the hereditary material of cells and is considered the blueprint of life. DNA is found in all kingdoms of life. Even most viruses have DNA. A molecule of DNA is chemically stable (it does not have a 2-prime alcohol group.)

When someone says DNA, they may be referring to one's genetic material on multiple levels: They may be speaking about a single deoxyribose nucleic acid molecule, a section of a double helix, a section of a chromosome, or one's entire hereditary composition.

  * antiparallel
  * Double helix 
    * Semiconservative replication
    * Sequence of nucleotides encodes functional RNA or polypeptide

## Historical perspective

  * Mitosis and meiosis 
    * Regular distribution of chromosomes suggested that they contain hereditary information
    * Bridges/Morgan, using Drosophila melanogaster showed that genes are on chromosomes (1910s)
  * Hammerling: nucleus contains hereditary information (1930s)
  * Griffith: transformation of bacteria (1928)
  * Avery, MacLeod, McCarty: transforming substance is DNA (1944)
  * Hershey, Chase: DNA is hereditary material of viruses (1952)
  * Rosalind Franklin
  * Watson and Crick: structure of DNA (1953)

## Hershey-Chase Experiment

The Hershey and Chase experiment was one of the leading suggestions that DNA was a genetic material. Hershey and Chase used phages, or viruses, to implant their own DNA into a bacterium. They did two experiments marking either the DNA in the phage with a radioactive phophorus or the protein of the phage with radioactive sulfur. With the bacteria that was infected by the phages with radioactive DNA the DNA in the bacteria was radioactive. In the bacteria that was infected with the radioactive protein the bacteria was radioactive, not the DNA. This proves that DNA is a genetic material and it is passed on in viruses.

## DNA/RNA components

  * Miescher: discovered DNA, 1869

### Structure of DNA

DNA is in a double helix structure made up of nucleotides. The "backbone" of the double helix is composed of phosphates connected to a five carbon sugar called _deoxyribose_, . The "rungs" are composed of nitrogenous bases, Purines and Pyrimidines. Purines contain Adenine(A) and Guanine(G) and have two rings in their structures. Pyrimidines contain Cytosine(C) and Thymine (T) and have one ring in their structures.

## Chemical structure of DNA

  * Polynucleotide 
    * Phosphodiester bonds between nucleotides
    * 5’-pGpTpCpGpTpApApTp-OH 3’
  * Chargaff’s rules, in DNA: equimolar amounts 
    * A = T
    * G = C

## 3D structure of DNA

  * [James Watson](http://en.wikipedia.org/wiki/James_D._Watson) and [Francis Crick](http://en.wikipedia.org/wiki/Francis_Crick) ([1953](http://en.wikipedia.org/wiki/1953)) 
    * Nucleotide
    * Keto and amino forms of bases
    * Chargaff’s rules
    * X-ray crystallographic data ([Rosalind Franklin](http://en.wikipedia.org/wiki/Rosalind_Franklin))

## Franklin

  * X-ray diffraction of DNA crystals
  * revealed regular pattern explained by antiparallel double helix

DNA model

  * Double helix of polynucleotides 
    * antiparallel
    * 3’-5’ phosphodiester bonds
  * Base pairs held by hydrogen bonds 
    * AT
    * GC
  * There are about 10 base pairs per turn of helix
  * model has predictive power 
    * mode of DNA replication
    * encoding of genetic information

## DNA replication

  * Conservative model 
    * One double helix of both old strands
    * One double helix of two new strands
  * Dispersed 
    * Each strand mixture of old new
  * Semiconservative 
    * Meselson-Stahl experiment confirmed its viability over the previous two 
      * grew _E. coli_ bacterium in a culture containing 15N (a heavy isotope of nitrogen)
      * bacterium assimilated the 15N into their DNA
      * a similar process was then done using 14N, a lighter isotope
      * following centrifugation, the densities were observed to be that of combined in the middle, and 14N on top, thereby confirming the semiconservative model

## DNA replication

  * Semiconservative
  * New nucleotides added to 3’ –OH
  * Replication fork 
    * Replication complex
  * DNA polymerase
  * Associated enzymes/proteins 
    * Energy from phosphate bonds of triphosphate nucleotide substrates (dNTP)

## DNA polymerases

  * Prokaryotes, E. coli 
    * 3 DNA polymerases
    * III is main enzyme for DNA replication
    * ~1000 nt/sec
  * Eukaryotes 
    * 6 DNA polymerases
  * Add nucleotide to 3’ –OH end
  * All require primer, i.e., free 3’ –OH

## DNA replication complex

  * Helicase "unzips" the DNA double helix
  * Primase: synthesize RNA primer
  * Single-strand binding proteins
  * DNA gyrase (topoisomerase)
  * DNA polymerase III
  * DNA polymerase I (remove primer, fill gaps)

## DNA replication

  * 5’ → 3’ replication 
    * Nucleotide addition at 3’ –OH
    * No exceptions
  * New strands are oriented in opposite direction due to 5’ → 3’ constraint 
    * Leading strand: continuous replication
    * Lagging strand: discontinuous replication 
      * contains multiple Okazaki fragments
  * Joined by DNA ligase

## DNA replication fork

  * primer required by all DNA polymerases

## Replication units

## Replicon

A region of DNA that is replicated from a single origin.

## What is gene?

  * Garrod 
    * “inborn errors of metabolism”
    * Alkaptonuria: enzyme deficiency
  * Beadle and Tatum 
    * One gene one enzyme
    * Genetic and biochemical analysis in Neurospora
  * Today: gene is sequence of nucleotides encoding functional RNA molecule or the amino acid sequence of a polypeptide

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Gene expression

Flow of genetic information

  * DNA → mRNA → polypeptide
  * Transcription: DNA → mRNA 
    * RNA polymerase
    * Nucleus in eukaryotes
    * Transcription also makes rRNA and tRNA
  * Translation: mRNA → polypeptide 
    * Ribosomes: protein and rRNA
    * Genetic code and tRNA

## “Central Dogma”

## The Genetic Code

  * Triplet codon 
    * 64 triplet codons (43)
    * Experimentally deciphered in 1961
  * Nearly universal 
    * Implies common ancestor to all living things
    * Minor exceptions: certain ciliates, mitochondria, chloroplasts
  * Still evolving

## Transcription

  * RNA polymerase 
    * NTP substrates
    * Synthesizes single stranded RNA complementary to template strand of DNA
    * New nucleotides to 3’ end
  * Begins at promoter site 
    * no primer necessary
  * Ends at terminator site
  * Much posttranscriptional modification in eukaryotes

## Transcription bubble

Promoter site

  * Prokaryotes 
    * -10 nt, TATA box
    * -35 nt, additional signal
  * Eukayotes 
    * -25, TATAAA box
    * Additional signals upstream
  * Promoters may be strong or weak
  * In eukaryotes, access to promoter depends upon state of chromatin coiling

## Eukaryote mRNA

  * Synthesized as pre-mRNA, processed in nucleus
  * 5’ end: GTP cap placed in inverted position 
    * Essential for ribosome recognition
  * 3’ end: poly-A tail; non-templated addition of ~50-250 A nucleotides; stability
  * Introns: intervening sequences removed

## Translation

  * Requires: 
    * mRNA
    * tRNA
    * ribosomes
    * translation factors (various proteins)
  * In prokaryotes, takes place on growing mRNA
  * In eukaryotes, in cytoplasm on free ribosomes and RER
  * AUG start codon to stop codon

## Translation in bacteria

tRNA

  * Transfer RNA
  * Two important parts 
    * Anticodon
  * Hydrogen bonds with mRNA codon 
    * 3’ end
  * Accepts amino acid (using energy of ATP)
  * Aminoacyl-tRNA synthetase

## Aminoacyl tRNA synthase

  * Enzyme used to bind amino acid from the cytoplasm to tRNA, which then transfers that amino acid to the ribosome for polypeptide formation

## Ribosome structure

## Large ribosome subunit

## Translation

  * Initiation complex 
    * Small ribosomal subunit
    * mRNA
    * fMet-tRNA (prokaryotes only; met-tRNA in eukaryotes)
    * Initiation factors
  * Elongation 
    * Ribosome
    * mRNA
    * tRNAs
    * Elongation factors

## Initiation complex

## Elongation, translocation

  * incoming tRNA enters the A site
  * rRNA catalyzes peptide bond formation. Note that growing peptide is attached to what was incoming tRNA at P site after translocation.
  * empty tRNA leaves via E site; recycled
  * A site ready for next charged tRNA

  


## Introns/exons

  * In eukaryotes, coding regions of gene may be interrupted by introns, noncoding regions of DNA (RNA)
  * Introns 
    * 22- >10,000 nt in length
    * 5’ GU … 3’ AG removal sequence
    * Not essential to genes
    * May constitute >90% of gene
  * removed from pre-mRNA to form mRNA
  * Exon: often codes for functional domain of protein 
    * translatable mRNA

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Gene regulation

  * Not all genes are expressed in a cell
  * Gene expression can be turned on and off
  * Multiple levels of regulation gene function 
    * Transcription initiation
  * State of chromatin
  * Transcription factors 
    * Post-transcriptional
  * mRNA processing
  * mRNA half-life
  * Translational
  * Post-translational 
    * Protein modification

## Transcriptional control

  * State of chromatin 
    * Euchromatin: transcriptionally active
    * Heterochromatin: transcriptionally inactive
    * Chemical modification of histones
    * Methylation of bases
  * Transcription factors 
    * Bind to DNA at promoter or other regulatory sites (enhancers)
  * Recognize base sequence through major and minor grooves 
    * Recruit RNA polymerase

## DNA grooves

Categories of transcription factors in eukaryotes

  * Helix-turn-helix 
    * Two small "-helices
    * Fit into DNA groove
  * Homeodomain 
    * Highly conserved helical domains
    * ~60 amino acids
  * Zinc finger motif 
    * Zn atom bound
  * Leucine zipper 
    * dimer

## Regulatory proteins

  * Activity may depend upon allosteric binding of small molecules 
    * cAMP
    * Co-repressors
    * Inhibitors
  * Binding to promoter region may “bend” DNA, making it accessible to other regulatory proteins

## Lac operon of E. coli

  * Single promoter region for cluster of genes
  * Regulated and transcribed as a single unit
  * Operons typical in prokaryotes
  * Repressor: turns OFF gene expression

lac repressor

  * Turns off transcription by blocking access by RNA polymerase
  * repressor in activated by allosteric binding of lactose

Regulation in eukaryotes

  * Both proximal (promoter) and distal (enhancer) to gene
  * Typically transcription unit encodes a single polypeptide
  * Promoter 
    * TATA box
    * Other elements (regulatory sequences) may be present
  * Enhancers 
    * Work upstream, downstream, close, far from gene
    * Bend DNA

## Alternative splicing

  * Single transcript gives rise to 2 or more mature mRNAs 
    * encode different polypeptides with shared domains
    * tissue and developmentally specific

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

(This Page was Last Edited December 2005)

# Mutation

A mutation is a permanent change to an organism's genetic material ([DNA](//en.wikipedia.org/wiki/DNA) or RNA). Mutations are a rare but significant biological process, since they provide the variation on which [evolution](/wiki/General_Biology/Evolution) acts and are also the source of cancer.

An organism's genetic material is made up of polymers (chains) of four different [nucleotides](//en.wikipedia.org/wiki/nucleotide), like a recipe book written in a language of only four letters. A mutation event is when the order of the nucleotides in DNA change, usually when the DNA is being copied.

Mutations come in a number of forms:

## Point Mutations

Point mutations are all mutations which involve a single nucleotide. These come in the form of substitutions, insertions and deletions:

## Substitution

Substitution Mutations: In substitution mutations, a nitrogenous base of a triplet codon of DNA is replaced by another nitrogen base or some derivative of the nitrogen base, changing the codon. The altered codon codes for a different amino acid substitution.The substitution mutations are of two types:

  
1.Transitions: It is the replacement of one purine in a polynucleotide chain by another purine(A by G or G by A) or one pyrimidine by another pyrimidine(T by C or C by T)

2.Transversions:A base pair substitution involving the substitution of a purine by pyrimidine or pyrimidine by a purine is called transversion.

### Insertion

### Deletion

## Larger mutations

Larger mutations which involve more than one nucleotide also include insertions and deletions, but can also include inversions, rearrangement of nucleotides and duplication of entire genes:

### Inversion

### Rearrangement

### Gene/Exon Duplications

#### Transposition

#### Retrotransposition

## Chromosomal mutations

Chromosomal mutations involve changes to entire chromosomes. These mutations are particularly rare:

### Translocation

### Fusion

### Fission

### Segmental Duplication

### Chromosomal Duplication

### Genome Duplication

## Causes of mutations

## Effects of mutations

Mutations can have a variety of different effects depending on the type of mutation, the significance of the piece of genetic material affected and whether the cells affected are germ-line cells. Only mutations in germ-line cells can be passed on to children, while mutations elsewhere can cause cell-death or cancer.

Mutations can be classified by their effects:

### Silent Mutation

Silent Mutations are DNA mutations that do not result in a change to the amino acid sequence or a protein. They may occur in a non-coding region (outside of a gene or within an intron), or they may occur within an exon in a manner that does not alter the final amino acid chain.

### Frameshift

### Missense Mutation

Missense mutations are types of point mutations where a single nucleotide is changed to cause substitution of a different amino acid. This in turn can render the resulting protein nonfunctional. Such mutations are responsible for diseases such as Epidermolysis bullosa.

### Nonsense Mutation

## Further reading

### Books

  * Jones, S. 1993. _The Language of the Genes_. Harper Collins [ISBN 0006552439](/wiki/Special:BookSources/0006552439).

### Websites

  * [Wikipedia: Mutation](//en.wikipedia.org/wiki/Mutation)
  * [[1]](http://www.evowiki.org/Mutation%7CEvoWiki:Mutation)

## Original notes

  * “Rare” change in nucleotide sequence 
    * Somatic vs germline
  * only those in germline are heritable 
    * Point mutation
  * Single nucleotide change 
    * Change in gene position
  * Transposition
  * Chromosomal rearrangement
  * Mutagenic agents
  * Raw material for evolutionary change

## Point mutation

  * Ionizing radiation 
    * UV light induces thymine dimers
  * Reparable
  * Error during DNA synthesis
  * Movement of transposons 
    * McClintock
  * Chemical mutagens
  * May alter 
    * Properties of promoter, enhancer
    * Amino acid sequence of polypeptide

## Acquisition of genetic variability

  * Mutation
  * Sex (fusion of genomes)
  * Recombination 
    * Crossing over
  * Reciprocal (may result in gene conversion)
  * Unequal (gives rise to gene families) 
    * Independent segregation
  * Transposition by transposons
  * Conjugation in bacteria 
    * One way transfer from donor to recipient

## Eukaryote genome

  * Thousands of transposons
  * Millions of transposon derived elements 
    * LINES, SINES
  * Above may constitute largest portion of genome
  * Pseudogenes
  * Tandem clusters (rRNA genes; nucleolus)
  * Multigene families
  * Single-copy genes (one copy per 1n)

## Barbara McClintock

  * Discovered transposons in perhaps greatest and ultimately most important intellectual endeavors in genetics 
    * Maize
    * Worked alone
  * Transposons: likely responsible for considerable evolution in eukaryotic genomes
  * Likely origin of viruses

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Recombinant DNA technology

  * Revolutionized modern biology 
    * Ability to manipulate genes in vitro
  * Hybrid genes, including combining genes of different species
  * Detailed study of gene function 
    * Determine nucleotide sequences of genes and their regulators (deduce amino acid sequences of proteins)
  * Genome projects: complete nucleotide sequence of >40 genomes, including human
  * Made possible by convergence of: 
    * discovery of restriction enzymes
    * genetics of bacteria and their plasmids

## Recombinant DNA technology

  * Uses 
    * Detailed study of gene function
  * Homeostasis, response to stress
  * Development (birth defects) 
    * Evolution of genes informs on evolution of life
  * Human betterment 
    * Medicine
  * Identification, treatment of genetic disorders
  * Molecular medicine: from deduced amino acid sequences, design better drugs 
    * Foods
  * Improve crop yield, resistance to disease
  * Improve nutritional value 
    * Forensics
  * DNA fingerprinting: guilt or innocence

## Restriction endonucleases

Originally found in bacteria to prevent invasion of viral DNA, cuts double stranded DNA that is unmethylated, will not cut newly synthesized DNA since hemi-methylated, a product of semi-conservative replication of DNA

  * sever phosphodiester bonds of both polynucleotide strands in order to combine foreign DNA 
    * create restriction fragments (restriction digestion)
    * 5’ phosphate and 3’ –OH at ends
  * usually nucleotide specific target sequence 
    * 4-6 bp most common, the more bases, then the more specific for recombination
    * cuts in or near sequence
    * ends
  * sticky=overhanging ends, 5’ or 3’
  * blunt ends - straight cut, will anneal with any other blunt end in the presence of high ligase
  * Hundreds of know restriction endonucleases, usually named after the bacteria that it was found in 
    * e.g. EcoR1, Alu1, BAM, HIND3

## Restriction endonucleases

Gene cloning

  * Cloning: 
    * Restriction digestion of DNA
    * insertion of restriction fragment into cloning vector
  * Bacterial plasmid
  * Bacterial virus
  * Yeast artificial chromosomes
  * Transformation of bacteria with recombinant plasmid, virus
  * Screening for clone of interest by using reporter genes or resistance upon exposure to anti-biotic

## Uses of cloned gene

  * Determine nucleotide sequence and deduce amino acid sequence from genetic code 
    * Submit to GenBank (available on WWW)
  * Manipulate gene to study function 
    * In vitro
    * In vivo
  * Transgenic (recombinant) organisms
  * Knockout organisms
  * Medical and commercial uses

## Other molecular procedures

  * Polymerase chain reaction (Mullis) 
    * Amplifies target DNA without cloning
    * Target amount can be single molecule
    * Amplified DNA can be sequenced, cloned, etc.
  * Southern blotting 
    * Used to identify restriction fragments carrying particular gene
    * Also used for DNA fingerprinting and RFLP analysis
  * cDNA construction 
    * Reverse transcription from mRNA template

## RFLP(restriction fragment length polymorphism) analysis

  * Basis of DNA fingerprinting using SNP - single nucleotide polymorphisms and repeats of DNA sequence
  * Many uses 
    * Criminal cases using multiple probes
    * Parentage
    * Species identification
    * Gene evolution
    * Species evolution

## Sanger DNA sequencing

  * Uses dideoxynucleotides (ddNTP), a template strand, DNA polymerase 1 (Also known as Kornberg enzymes) and dNTPs 
    * Missing 3’-OH for nulceopjilic attack for elongation
    * DNA synthesis stops after one is incorporated into DNA fragment
    * ratio of ddNTP to dNTP determines likelihood of termination
  * Manual method with 32P-labeled ddATP and 4 test tubes - ddATP, ddCTP, ddGTP, ddTTP
  * Automated method using ddNTPs labeled with fluorescent dyes in capillary tube 
    * Often done commercially

## Automated sequencing

Typical machine

  *     * 2 hour sequencing run
    * 600-1000 bases per sample
    * multiple samples
  * Up to 500,000 bases per day (12 hr)
  * Data processed by computer
  * In big labs, sequencing reactions also are automated

## Genome projects

  * Determine entire nucleotide sequence of genome
  * >40 genomes sequenced 
    * Helicobacter pylori
    * Escherichia coli
    * Saccharomyces cerevisiae
    * Caenorhabditis elegans
    * Drosophila melanogaster
    * Homo sapiens (first rough draft)
  * Computer identifies all genes, based on properties of genes (e.g., start/stop codons, introns, etc.).

## Biochips

  * Microarray of DNA fragments, size of postage stamp; can be expensive, but has decreased in cost

Microarray chips contain wells of DNA that code for specific genes that uses the concept of hybridization with the gene of interest to see if a gene is expressed or is present.

  * Designed to detect: 
    * mutated genes (SNPs)
    * expressed genes
  * Instant DNA profile (“GATTACA”)

## DNA chip controversies

  * Medicine 
    * Risks and informed consent for gene replacement therapy
    * Alteration of human gene pool
    * Parental choice
    * Privacy
  * Genetically modified foods 
    * Safety
    * Labeling
  * Forensics 
    * Mandatory tests
    * Reliability standards

## Gene patenting

  * Techniques to study and manipulate genes are patented (e.g., cloning and PCR)
  * Should genes be patented? 
    * Are they the intellectual property of the discoverer?
    * Don’t they belong to all of us?
    * Should indigenous peoples be compensated for useful genes extracted from their local plants and fungi?

## Stem cells

  * Totipotent cells from early embryo 
    * grow into any tissue or cell type
  * Recombinant genes can be introduced
  * Considerable use in analyzing gene expression in mice
  * Possible therapeutic use in humans
  * Very controversial

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._

# Classification of Living Things

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

  


### Classification of Living Things & Naming

With so many flora and fauna on planet Earth, there must be a method to classify each organism to distinguish it from others so it can be correctly identified. Classification does not only apply to biology. For example, supermarkets and grocery stores organise their products by classifying them. Beverages may occupy one aisle, while cleaning supplies may occupy another. In science, the practice of classifying organisms is called **taxonomy** (Taxis means arrangement and nomos means law). The modern taxonomic system was developed by the Swedish botanist Carolus (Carl) Linneaeus (1707-1788). He used simple physical characteristics of organisms to identify and differentiate between different species.

Linneaeus developed a hierarchy of groups for taxonomy. To distinguish different levels of similarity, each classifying group, called **taxon** (pl. taxa) is subdivided into other groups. To remember the order, it is helpful to use a mnemonic device. The taxa in hierarchical order:

  * Domain - Archea, Eubacteria, Eukaryote
  * Kingdom - Plants, Animals, Fungi, Protists, Eubacteria (Monera), Archaebacteria
  * Phylum
  * Class
  * Order
  * Family
  * Genus
  * Species

The domain is the broadest category, while species is the most specific category available. The taxon Domain was only introduced in 1990 by Carl Woese, as scientists reorganise things based on new discoveries and information. For example, the European Hare would be classified as follows:

Eukaryote --> Animal --> Chordata --> Mammalia --> Lagomorpha --> Leporidae --> Lepus --> _Lepus europaeus_.

**Binomial nomenclature** is used to name an organism, where the first word beginning with a capital is the genus of the organism and the second word beginning with lower-case letter is the species of the organism. The name must be in italics and in Latin, which was the major language of arts and sciences in the 18th century. The scientific name can be also abbreviated, where the genus is shortened to only its first letter followed by a period. In our example, _Lepus europaeus_ would become _L. europaeus'._

Taxonomy and binomial nomenclature are both specific methods of classifying an organism. They help to eliminate problems, such as mistaken identity and false assumptions, caused by common names. An example of the former is the fact that a North American robin is quite different from the English robin. An example of the latter is the comparison between crayfish and catfish, where one might believe that they both are fish when in fact, they are quite different.

Nomenclature is concerned with the assignment of names to taxonomic groups in agreement with published rules. To study for a test these are the best words to know taxonomist, biologist, chemist, geologist, unicellular, multi- cellular, bilateral symmetry, radial symmetry, chlorophyll, photosynthesis, respiration, reproduction, vertebrates, endoskeleton, exoskeleton, consumers, decomposers, heterotroph, autotroph, vascular, non-vascular. these are all part of classifying things

### Eukaryotes & Prokaryotes

Recall that there are two basic types of cells: **eukaryotes** and **prokaryotes**.

Eukaryotes are more complex in structure, with nuclei and membrane-bound organelles. Some characteristics of eukaryotes are:

  * Large (100 - 1000 μm)
  * DNA in nucleus, bounded by membrane
  * Genome consists of several chromosomes.
  * Sexual reproduction common, by mitosis and meiosis
  * Mitochondria and other organelles present
  * Most forms are multicellular
  * Aerobic

Prokaryotes refer to the smallest and simplest type of cells, without a true nucleus and no membrane-bound organelles. Bacteria fall under this category. Some characteristics:

  * Small (1-10 μm)
  * DNA circular, unbounded
  * Genome consists of single chromosome.
  * Asexual reproduction common, not by mitosis or meiosis.
  * No general organelles
  * Most forms are singular
  * Anaerobic

### The Three Domains

The three domains are organised based on the difference between eukaryotes and prokaryotes. Today's living prokaryotes are extremely diverse and different from eukaryotes. This fact has been proven by molecular biological studies (e.g. of RNA structure) with modern technology. The three domains are as follows:

**Archea (Archeabacteria)** consists of archeabacteria, bacteria which live in extreme environments. The kingdom Archaea belongs to this domain.

**Eubacteria** consists of more typical bacteria found in everyday life. The kingdom Eubacteria belongs to this domain.

**Eukaryote** encompasses most of the world's visible living things. The kingdoms Protista, Fungi, Plantae, and Animalia fall under this category.

### The Six Kingdoms

Under the three domains are six kingdoms in taxonomy. The first two, **Plants** and **Animals**, are commonly understood and will not be expounded here.

**Protista**, the third kingdom, was introduced by the German biologist Ernst Haeckel in 1866 to classify micro-organisms which are neither animals nor plants. Since protists are quite irregular, this kingdom is the least understood and the genetic similarities between organisms in this kingdom are largely unknown. For example, some protists can exhibit properties of both animals and plants.

**Fungi** are organisms which obtain food by absorbing materials in their bodies. Mushrooms and moulds belong in this kingdom. Originally, they were part of the plant kingdom but were recategorised when they were discovered not to photosynthesise.

**Eubacteria** are bacteria, made up of small cells, which differ in appearance from the organisms in the above kingdoms. They lack a nucleus and cell organelles. They have cell walls made of peptidoglycan.

**Archae (or Archaebacteria)** are bacteria which live in extreme environments, such as salt lakes or hot, acidic springs. These bacteria are in their own category as detailed studies have shown that they have unique properties and features (ex. unusual lipids that are not found in any other organism)which differ them from other bacteria and which allow them to live where they live. Their cell walls lack peptidoglycan.

### Origins of Diversity

The diversity in our planet is attributed to diversity within a species. As the world changed in climate and in geography as time passed, the characteristics of species diverged so much that new species were formed. This process, by which new species evolve, was first described by British naturalist Charles Darwin as **natural selection**.

For an organism to change, genetic mutations must occur. At times, genetic mutations are accidental, as in the case of prokaryotes when they undergo asexual reproduction. For most eukaryotes, genetic mutations occur through sexual reproduction, where meiosis produces haploid gametes from the original parent cells. The fusion of these haploid gametes into a diploid zygote results in genetic variation in each generation. Over time, with enough arrangement of genes and traits, new species are produced. Sexual reproduction creates an immense potential of genetic variety.

One goal of taxonomy is to determine the evolutionary history of organisms. This can be achieved by comparing species living today with species in the past. The comparison in anatomy and structure is based on data from development, physical anatomy, biochemistry, DNA, behaviour, and ecological preferences. The following are examples of how such data is used:

  * Anatomy:

Although a horse and a human may look different, there is evidence that their arm structures are quite similar. Their arms' sizes and proportions may be different, but the anatomical structures are quite similar. Such evidence reveals that animals in different taxa may not be that different. Biological features from a common evolutionary origin are known as **homologous**.

  * Development
  * Biochemistry:

Biochemical analysis of animals similar in appearance have yielded surprising results. For example, although guinea pigs were once considered to be rodents, like mice, biochemistry led them to be in their taxon of their own.

### Phylogeny, Cladistics & Cladogram

Modern taxonomy is based on many hypotheses' of the evolutionary history of organisms, known as **phylogeny**. As with the Scientific Method, scientists develop a hypothesis on the history of an animal and utilise modern science and technology to prove the phylogeny.

**Cladistics** is a classification system which is based on phylogeny. Expanding on phylogeny, cladistics is based on the assumption that each group of related species has one common ancestor and would therefore retain some ancestral characteristics. Moreover, as these related species evolve and diverge from their common ancestor, they would develop unique characteristics. Such characteristics are known as **derived characteristics**

The principles of phylogeny and cladistics can be expressed visually as a **cladogram**, a branching diagram which acts as a family (phylogenetic) tree for similar species. A cladogram can also be used to test alternative hypotheses for an animal's phylogeny. In order to determine the most likely cladogram, the derived characteristics of similar species are matched and analysed.

### Classification of Living Things Practice Questions

1\. If taxonomists had to select an existing kingdom to reclassify, which of the six would most likely be chosen? Why?

2\. Complete the following without consulting external sources:

a) The species _caudatum_ is in the family _Paramecidae_. What would be the binomial name of this organism?

b) Give the abbreviation of the binomial name.

3.

a) Irish moss belongs to the genus _Chondrus_. The name for this species is _crispus_. Give the binomial name.

b) Give the abbreviation of the binomial name.

4\. Humans and chimpanzees are alike. Which of the following data would most accurately prove this correct?

    a) biochemistry
    b) DNA
    c) appearance
    d) development
    e) A, B, C

5\. Which of the following is out of order?

    a) Kingdom --> Phylum --> Class
    b) Class --> Family --> Order
    c) Family --> Order --> Genus
    d) Genus --> Species
    e) A, C
    f) A, B, D
    g) B, C

6\. A taxonomist discovers Organism A and Organism B and wishes to classify them. Which of the following choices is the most informative?

    a) Both organisms are brown.
    b) Both organisms have a tail.
    c) Both organisms have ears.
    d) Both organisms are nocturnal.

7\. DNA analysis is usually done using DNA found in a cell's mitochondria, and not in a cell's nucleus. From your knowledge of mitosis, explain why this is so.

1\. Arachbacteria 3.a) Chondrus crispus b) C. cripus 4. B 5. G 6. B

## Introduction

**Viruses** are the smallest biological particle (the tiniest are only 20 nm in diameter). However, they are not biological organisms so they are not classified in any kingdom of living things. They do not have any organelles and cannot respire or perform metabolic functions. Viruses are merely strands of DNA or RNA surrounded by a protective protein coat called a **capsid**. Viruses only come to life when they have invaded a cell. Outside of a host cell, viruses are completely inert.

Since first being identified in 1935, viruses have been classified into more than 160 major groups. Viruses are classified based on their shape, replication properties, and the diseases that they cause. Furthermore, the shape of a virus is determined by the type and arrangement of proteins in its capsid. Viruses pathogenic to humans are currently classified into 21 groups.

Viruses can also attack bacteria and infect bacterial cells. Such viruses are called **bacteriophages**.

## Viral Replication

As previously stated, viruses are not a biological life form so they cannot reproduce by themselves. They need to take over a functioning eukaryotic or prokaryotic cell to replicate its DNA or RNA and to make protein coat for new virus particles.

In order to enter a cell, a virus must attach to a specific receptor site on the plasma membrane of the host cell. The proteins on the surface of the virus act as keys which fit exactly into a matching glycoprotein on the host cell membrane. In some viruses, the attachment protein is not on the surface of the virus but is in the capsid or in the envelope.

There are two forms of viral replication: the **lytic cycle** and the **lysogenic cycle**.

### Lytic Cycle

  1. Attachment: The virus binds to specific receptors on the host cell.
  2. Entry: There are two ways in which a virus can enter cells. Firstly, the virus can inject its nucleic acid into the host cell. Secondly, if a virus is contained in an envelope, the host cell can phagocytosise the entire virus particle into a vacuole. When the virus breaks out of the vacuole, it then releases its nucleic acid into the cell.
  3. Replication: The virus's nucleic acid instructs the host cell to replicate the virus's DNA or RNA.
  4. Assembly: New virus particles are assembled.
  5. Lysis and Release: The virus directs the production of an enzyme which damages the host cell wall, causing the host cell to swell and burst. The newly formed virus particles are now released.

### Lysogenic Cycle

  1. Attachment: Similar to Lytic Cycle
  2. Entry: Similar to Lytic Cycle
  3. Incorporation: The viral nucleic acids is not replicated, but instead integrated by genetic combination (crossing over) into the host cell's chromosome. When integrated in a host cell this way, the viral nucleic acid as part of the host cell's chromosome is known as a **prophage**.
  4. Host Cell Reproduction: The host cell reproduces normally. Subsequent cell divisions, daughter cells, contain original father cell's chromosome embedded with a prophage.
  5. Cycle Induction: Certain factors now determine whether the daughter cell undergoes the lytic or lysogenic cycle. At any time, a cell undergoing the lysogenic cycle can switch to the lytic cycle.

The reproduction cycle of viruses with RNA and no DNA is slightly different. A notable example of a RNA-based virus is HIV, a retrovirus.

#### Retrovirus reproductive cycle

  1. The retrovirus force RNA into cell, by either one of the two methods of entry (See above).
  2. In the retrovirus are reverse transcriptase enzymes, which catalyses the synthesis of a DNA strand complementary to the viral RNA.
  3. Reverse transcriptase catalyses a second DNA strand complementary to the first. With these two strands, the double-stranded DNA can be created.
  4. DNA is then incorporated into the host cell's chromosomes. Similar to the concept of a prophage, this incorporated DNA is called a **provirus**. However, the provirus never leaves the host cell, unlike a prophage.
  5. The infected host cell undergoes the lytic or lysogenic cycle.

## Viral Genome

The genome of a virus consists of DNA or RNA, whose size and configuration vary. The entire genome can exist as a single nucleic acid molecule or several nucleic acid segments. Also, the DNA or RNA may be single-stranded or double-stranded, and either linear or circular.

Not all viruses can reproduce in a host cell by themselves. Since viruses are so small, the size of their genome is limiting. For example, some viruses have coded instructions for only making a few different proteins for the viruses' capsid. On the other hand, the human genome codes for over 30,000 different proteins. Therefore, the lack of coded instructions cause some viruses to need the presence of other viruses to help them reproduce themselves. Such viruses are called **replication defective**.

Lastly, it is worthy to note that 70% of all viruses are RNA viruses. As the process of RNA replication (with enzymes and other organelles of the host cell) is more prone to errors, RNA viruses have much higher mutation rates than do DNA viruses.

## Viruses Practice Questions

  1. As the name implies, the Tomato Spotted Wilt Virus targets tomatoes. Would it be possible for this virus to target other fruits as well? Explain.
  2. If a DNA and a RNA virus both infected somatic cells, which virus would be more difficult to detect?
  3. Many people have had cold sores, which are caused by infection with the herpes simplex virus. One characteristic of cold sores is that after a period of inactivity, they will reappear many times during the course of a person's life. Which cycle would the herpes simplex virus undergo?
  4. Chicken pox is a common, non-fatal disease usually acquired in adolescence and caused by the varicella zoster virus. In adulthood, many people suffer from shingles, an altered form of the varicella zoster virus. Which cycle would the varicella zoster virus have undergone?
  5. Would an antibiotic work for a person suffering from a cold of flu? Explain.

[Answers to Viruses Practice Questions](/w/index.php?title=General_Biology/Print_version/Answers&action=edit&redlink=1) For Eubacteria, please visit [General Biology/Classification of Living Things/Eubacteria](/wiki/General_Biology/Classification_of_Living_Things/Eubacteria).

## Archaea

  * Proposed as separate group from (eu)bacteria by Carl Woese 
    * based on structure and metabolic pathways
    * inhabit extreme environments
    * unique branched lipids in membrane
  * Share traits with both eukaryotes and eubacteria, e.g., RNA polymerase, introns
  * Biochemically diverse
  * Economically important 
    * Taq polymerase used in PCR

### Types

  * Methanogens
  * Halophiles
  * Thermophiles

  


#### Underground bacteria

  * Metabolism 
    * built around inorganic energy sources
  * e.g., basalt reacts with H2O to release hydrogen which is catalytically combined with CO2 to form carbohydrate (akin to photosynthesis)
  * may result in deposit of minerals
  * Unresolved problems 
    * Did bacteria move downward from surface or did they first evolve there, protected from harsh surface conditions?
    * Could bacteria be ejected into space in rocks?

## Prokaryote evolution

  * Tentative, subject to change
  * Derived largely from molecular systematics (rRNA sequences)
  * Note: most bacteria can’t be cultured, thus hard to study! (Studied by PCR of water/soil samples)

## Domains of life: characteristics

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._

## Introduction

Out of the six kingdoms, Protista is the most diverse. This is the kingdom of organisms with strange, atypical characteristics. In essence, this kingdom is designated for organisms which do not belong in any other kingdom. The majority of protists are microscopic.

## Classification of Protists

There are three phyla of protists, based on their type of nutrition.

1\. **Protozoa** (animal-like protists) are heterotrophs that ingest or absorb their food.

2\. **Algae** (plant-like protists) are autotrophs they get nutrition from photosythesis.

3\. **Slime moulds** and **water moulds** (fungus-like protists) are also heterotrophs, like protozoa.

## Protozoa

As heterotrophs, protozoa scavenge materials from their surroundings. Others are predators which actively hunt or ambush small organisms such as bacteria and other protozoa for a source of nutrition. Protozoa can be parasitic as well; they may live inside larger organisms, like humans. Most protozoa live as single cells, although a few form colonies.

Protozoa are generally difficult to identify due to their varied shape. They may appear as jelly-like blobs, spherical sunbursts, or a flattened leaf. Tiny blood parasites may be only 2 μm long. On the other hand, shell-covered marine may be 5 cm or more in diameter.

Furthermore, different protozoans have their own complex life cycles. The complexity has led certain organisms to be mistakenly classified for other species.

Nevertheless, protozoa can move, and so, they are classified based on their methods of locomotion.

_Characteristics of Protozoa :_

  * About 30,000 species known
  * About 10,000 species are pathogenic, including some of the worst human diseases
  * heterotrophic
  * highly variable in form and life cycle
  * mostly unicellular
  * range in size from 0.005 mm to 50 mm
  * lack cell walls

they love environment and each other..............

## Algae

Algae are much simpler than protozoa. They are aquatic and contain chlorophyll. Algae can exist as a single cell or as giant seaweeds 60 m in length. Formerly, algae were classified as plants but this was incorrect as algae lack parts of true plants: leaves, stems, roots, xylem, and phloem. Since algae belong in the kingdom Protista, algae is a broad term used to denote all aquatic eukaryotes which photosynthesise; algae can differ in size and shape as well.

There are six phyla of algae: **chlorophytes (green algae)**, **phaeophytes (brown algae)**, **rhodophytes (red algae)**, **chrysophytes (diatoms)**, **pyrrophytes (dinoflagellates)**, and **euglenophytes (euglenoids)**.

### Chlorophytes

Chlorophytes resemble plants the most. Like plants, their cell walls contain cellulose and they store food in reserve as starch. Chlorophytes can be unicellular or multicellular. Most chlorophytes use flagellae for some locomotion.

### Phaeophytes

Phaeophytes are nearly all multicellular marine organisms, which are known to us as seaweeds. They have cell walls composed of cellulose and alginic acid (a substance similar to pectin). The cellulose and alignic acid help to retain water and prevent seawood from drying out when exposed to air at low tide.

Since phaeophytes live in a tidal environment, they have large, flat fronds (a large leaf) which can withstand pounding by waves. Their bases strongly anchor the algae to the rocky seabed and prevent them from being washed out to sea. Phaeophytes are usually found in areas of cold water.

### Rhodophytes

Rhodophytes are typically found in warmer seawater, and are more delicate and smaller than brown algae (phaeophytes). Rhodophytes are also able to grow at deeper depths in the ocean, since red algae absorb green, violet, and blue light, the wavelengths of which penetrate the deepest below the water surface. They also have mucilaginous material to resist drying.

### Chryosophytes

Chryosophytes are the most abundant unicellular algae in the oceans. They are also one of the biggest components of plankton, a free-floating collection of microorganisms, eggs, and larvae. As photosynthetic organisms, they produce a significant amount of atmospheric oxygen.

The reproduction cycle of chryosophytes is particularly interesting. Note that diatoms reproduce both asexually and sexually. Since diatoms have a rigid cell wall with an outer layer of silica (found in sand and glass), the daughter cells produced by mitosis must fit inside the original cell wall. Therefore, each generation of diatoms is smaller than the one before. The reduction in size continues until the diatoms produce sexually, producing a zygote which eventually grows to the original size as it matures.

### Pyrrophytes

Pyrrophytes are unicellular, photosynthetic, and mostly aquatic. They have protective coats composed of stiff cellulose. They are more easily identifiable, due to the presence of two flagellae. The longer flagellae propels the dinoflagellate, while the second shorter, flatter flagellae functions as a rudder.

Some species of pyrrophytes are **zooxanthellae**. Since they lack cellulose plates, they make their home in coral reefs and animals, such as sea anemones, and molluscs. In returning the favour of sheltering them, dinoflagellates provide carbohydrates to their host through photosynthesis. This is why there are nutrient-rich coral reefs in malnutritions water.

A negative aspect of pyrrophytes is that under certain conditions, species of dinoflagellates reproduce rapidly to form a **harmful algal bloom (HAB)**, known as a red tide if dinoflagellates are the cause. Such pyrrophytes can produce toxins which may injure or kill wildlife, and additionally any consumers of contaminated wildlife.

### Euglenophytes

Like pyrrophytes, euglenophytes are small unicellular freshwater organisms with two flagella. They are mainly autotrophic or heterotrophic, depending if they have a red, light-sensitive structure called an **eyespot**.

## Slime molds & Water molds

There are two phyla of slime moulds and one phylum of water moulds.

### Oomycotes (Water moulds)

Oomycotes are filamentous organisms which resemble fungi, in that they live as saprotrophs. Oomycotes differ from other moulds with the presence of spores and their sexual life cycle.

### Myxomycotes (Plasmodial slime moulds)

Myxomycoties are visible to the naked eye as tiny slug-like organisms which creep over decayed and dead matter. This streaming blob containing many nuclei is called a **plasmodium**.

### Acrasiomycotes (Cellular slime moulds) and its reproductive cycle

Acrasiomycotes exist as individual amoeboid cells with one nucleus each. When in unfavourable conditions, each acrasiomycete cell gathers together to form a **pseudoplasmodium**.

#### Reproductive Cycle:

1\. One acrasiomycete cell joins with others to form a pseudoplasmodium.

2\. The pseudoplasmodium shrinks and forms a smaller plasmodium.

3\. The plasmodium migrates to a suitable environment.

4\. The plasmodium develops a sporangia, where original parental nuclei has divided by meiosis into haploid spores to be germinated.

5\. When favourable conditions arise, the spores germinate and are carried away by animals or the wind.

6\. Cycle repeats.

## Protists Practice Questions

1\. Which of the following adjectives describe the major food source of protozoa?

    a) chemoautotrophic
    b) photoheterotrophic
    c) chemoheterotrophic
    d) heterotrophic
    e) A, C, D
    f) C, D

  
2\. The protozoan _Giardia lamblia_ can inhabit a human body's intestinal tract and cause gastroenteritis.

a) Give the abbreviated binomial name of this protozoan.

b) Would the relationship between this protozoan and human being be mutualistic, commensalistic, or parasitic?

3\. Found in many products, such as Petri dishes, agar is made from mucilagnious material in seaweed. Of the six phyla of algae, which phyllum/phyla would agar be made from?

4\. Which of the following adjectives describe the major food source of Euglenophytes without an eyespot?

    a) photoautotrophic
    b) photoheterotrophic
    c) chemoautotrophic
    d) chemoheterotrophic
    e) B or C
    f) C or D

5\. Can coral reefs exist in nutrient-poor areas? Explain. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Multicellular Photosynthetic Autotrophs

## Plants

  * Multicellular
  * Cellulose cell walls
  * Chlorophylls a and b
  * Develop from embryophyte
  * Alternation of generations
  * Major food source for terrestrial life
  * Atmospheric O2 and CO2 balance
  * Coal deposits
  * Intimate association with mycorrhizal fungi
  * >250,000 species (~500,000?)
  * Taxonomy 
    * State of flux
  * DNA sequencing
  * Developmental studies 
    * Division (old literature) = phylum (new literature)
    * ~12 phyla, 9 of which are vascular plants

## Plant phyla

Phyla are 12 groupings

## Plant evolution

  * Evolved from green algae, likely related to charophytes
  * Evidence 
    * DNA sequences
    * homologous chloroplasts: chlorophyll b and beta-carotene; thylakoids in grana;
    * Cellulose in both groups; also peroxisomes
    * Mitosis and cytokinesis similar
    * Sperm ultrastructure

### Terrestrial adaptations

  * Stomata: pores in leaves for exchange of gases; prevent desiccation
  * Secondary metabolites: 
    * cuticle: waxy coating to prevent H2O loss
    * lignin: hardens wood
    * sporopollenin: resistant polymer; coats pollen
    * predator defenses
  * Embryonic development 
    * gametangia in early plants
    * spores; seeds
  * Mycorrhizae
  * Water/food conducting systems

## Plant phylogeny

## Plant life cycles

  * Alternation of generations
  * Sporophyte 
    * diploid
    * produces spores in sporangia
  * Gametophyte 
    * develops from spore
    * haploid
    * produces gametes in gametangia
  * Haplodiplontic life cycle

## Moss life cycle

## Vascular plants

  * Most have roots
  * Aerial shoot systems
  * Vascular tissue 
    * xylem: water, mineral transport
    * phloem: food transport
  * Lignin
  * Branched sporophyte is dominant stage 
    * amplified production of spores
    * evolution of complex plant bodies
  * Dominated Carboniferous (360 my)

## Vascular plant life cycles

  * Homosporous (single type of spore)
  * Heterosporous (two types of spore)

## Pterophyta (ferns)

  * Non-seed plant
  * Sporophyte conspicuous (vascular tissue)
  * Rhizome: ground stem, roots
  * Fronds: leaves
  * Sori: clusters of sporangia
  * Motile sperm require external water for fertilization
  * Originated in Devonian, 350 my

Tree fern Fern life cycle

## Non-seed plants, continued

  * Lycophyta: club mosses 
    * E.g., Lycopodium (“ground pine”)
    * Many species became extinct 270 my, once dominant (coal formations)
    * Gametophyte non-photosynthetic, nourished by fungi
  * Arthrophyta: horsetails 
    * Equisitum
    * Some fossil forms (300 my) were tree-size (coal)
    * Photosynthetic stems, no leaves
    * Silica deposits in epidermal cells

## Seed plants

  * 1st appeared in Devonian, 360 my
  * Seed develops from ovule, protects embryo 
    * withstands drought
    * dispersal is enhanced
    * no immediate need for water for germination
  * Heterosporous 
    * male gametophyte: arise from microspores
    * female gametophyte: arise from megaspores in ovule in ovary
  * Two groups 
    * gymnosperms
    * angiosperms
    
    
    plant
    

## Sporophyte/gametophyte

## Megasporangium (nucellus)

  * Key to seed development
  * Nucellus: solid, fleshy, surrounded by integuments derived from sporophyte (seed coat)
  * Entire structure called ovule
  * Flower may have many ovules

## Pollen

  * Develop from microspores, become male gametophyte
  * Protected by sporopellenin
  * In most plants, sperm lack flagella (loss)
  * Many mechanisms to transport pollen 
    * wind
    * insects, birds,

## Gymnosperms

  * “naked seed” 
    * ovule not fully enclosed by sporophyte at time of pollination
  * Conifers, cycads, gnetophytes, Ginkgo
  * Small, inconspicuous plants to giants like sequoia
  * Conifers: to carry cones fv 
    * male cones, Female conesvv
    * evergreen

## Pine life cycle

## Other Coniferophyta

  * Cycadophyta: cycads 
    * tropical, subtropical
    * flagellated sperm
  * Gnetophyta 
    * e.g., Ephedra, Mormon Tea
  * Ginkgophyta: Ginkgo 
    * only one surviving species
    * diocious (separate % and &trees)

## Other gymnosperms

## Angiosperms

  * Flowering plants, Anthophyta 
    * monocots- single seed leaf (grasses, lilies, etc.)
    * dicots- two seed leaves (roses, pulses, maples)
  * More specialized xylem (water transport) 
    * vessel elements
    * fiber cells
  * Fossils date to 130 my
  * Animal (e.g., insect) coevolution

### Monocots vs dicots

## Earliest angiosperm

  * What is earliest angiosperm?
  * Recent analysis of nucleotide and amino acid sequences suggests that Amborella, a tropical plant found only on the island of New Caledonia, is closest relative to flowering plants

## Angiosperm flower

Insert non-formatted text hereInsert non-formatted text here

## Angiosperm life cycle

_This text is based on notes very generously donated by Paul Doerder, Ph.D., of the Cleveland State University._

## Introduction

Although you may not recognise fungi, they are just as prevalent as plants and animals. Their spores are in the air which we breathe, fungi allow us to make bread, and mushrooms (a type of fungi) are eaten by us. A few types of fungi are unicellular. For example, yeasts live as individual oval or cylindrical cells. However, the majority of fungi live are multicellular. Their bodies are composed of **hyphae**, a network of fine filaments. In a mushroom, the hyphae are densely packed so it is difficult to see the individual structures when a mushroom is eaten. However, a mushroom is only a specialised reproductive part of the whole fungus. The main part of the fungi is underground in a whole web of hyphae, called a **mycelium**.

In the mycelium, each fungal cell is separated from each other by a septum. Each fungal cell may have one or more nuclei and remains connected to the mycelium because the septa are porous, allowing cytoplasm to flow through the hyphae and fungal cell walls, made of a hard material called **chitin**. Some fungi do not have septa, and they appear to be large, branching, multinucleate cells.

## Nutrition

Fungi are **saprophytes**. When they find a source of food (e.g. dead wood, orange peel) , they decompose it and digest it. The enzymes break down larger organic molecules in the substrate into smaller molecules. These smaller molecules diffuse into the fungus, where they are used to allow growth and repair.

Fungi which feed on living cells are parasitic. For example, athlete's foot grows on the human foot. These kinds of fungi produce hyphae called **haustoria**, which can penetrate host cells without immediately killing them.

However, they are friendlier species of fungi. Many fungi live symbiotically with plants or animals. For example, most trees have fungi living in close contact with their roots. In this relationship, known as a **mycorrhiza**, there are many benefits:

  * Growing around the plant roots and often entering plant cells, the hyphae absorb minerals from the soil and release them in the roots. The fungi gets its source of food (organic nutrients) while delivering food to the plant.
  * The mycelium here would increase the surface area, thus the absorptive surface, of the plant roots.
  * The fungal cells help to maintain air and water flow in the soil around the roots.
  * The fungi may prevent other potentially pathogenic fungi to attack the tree.

## Fungal Reproduction

Fungi can reproduce in two ways. Firstly, they make asexually produce through **fragmentation**. This occurs when pieces of hyphae are broken off, which then grow into new mycelia.

The second method is by spores. Spores are lightweight structures and windblown designed to be transported over long distances and by many mediums, such as on the bodies of insects and birds. They are additionally light enough to be blown away for hundreds of kilometers. Spores may be asexual and sexual. Their sexual properties can be analysed to classify the four phylla of fungi.

## Types of Fungi

### Zygospore Fungi (Zygomycetes)

This phyllum includes bread moulds and other saprotrophs. Comparable to bacteria, this phyllum prefers asexual reproduction over sexual reproduction.

1\. Two haploid hyphae of opposite types, also known as **mating strain +** and **mating strain -**, combine and fuse together.

2\. **Plasmogamy**, the union of the two parent hyphae, occurs and results in the creation of a heterokaryotic (n + n) **zygosporangium or zygospore**. Note that the zygospore is NOT diploid yet; the haploid nuclei are simply clumped together.

3\. Immediately, a thick wall develops around the zygospore to protect it from drying and other hazards. The zygospore becomes dormant.

4\. When conditions are favourable, the zygospore absorbs water and undergoes **karyogamy** (n + n = 2n), where the haploid nuclei contributed by the two parents fuse to produce diploid zygosporangia.

5\. The now diploid zygosporangium then undergoes meiosis to form haploid sporangia.

6\. Through asexual reproduction of fungi (See above for more information), the spores from the sporangia germinate and grow into new mycelia.

7\. Back to step #1.

### Club Fungi (Basidiomycetes)

This phyllum increases mushrooms and shelf fungi. In many ways, the reproduction stages of this phyllum is similar to that of zygomycetes.

1\. Two haploid hyphae of opposite types, also known as **mating strain +** and **mating strain -**, combine and fuse together.

2\. Plasmogamy takes place, and a dikaryotic mycelium forms. The dikaryotic mycelium grows faster then the haploid parental mycelia.

3\. Environmental factors cause the dikaryotic mycelium to form compact masses which develop into **basidiocarps**, short-lived reproductive structures. An example is the mushroom.

4\. The basidiocarp gills are lined with terminal dikaryotic cells called **basidia**, which then undergo karyogamy.

5\. The basidia are now diploid. They undergo meiosis to develop haploid **basidiospores**, a term referring to a basidiomycete's spores.

6\. Still remaining on the basidiocarp, the haploid basidiospores eject, fall from the basidiocarp, and are dispersed by the wind when mature.

7\. In a favourable environment, the basidiospores germinate and grow into short-lived haploid mycelia.

8\. Back to Step #1. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

  


## Key Terms

synapomorphy

  


## Introduction

What makes an animal an animal?

If animals are a monophyletic taxon, then animals should be able to be defined by synapomorphies, (shared, derived characteristics). Ideally, we would NOT define this or any taxon using symplesiomorphies (shared ancestral or primitive characteristics) or homoplastic characters (the independent evolution of similarity, or "convergent evolution"). See pages 654 - 656 and Fig. 32.6 in your text to review these concepts. As you consider the characteristics listed below, ask yourself whether or not each is a synapomorphy.

  


## Characteristics of an Animal

  * There is no one universally accepted definition of an animal. The following treatment follows your text, beginning on page 876. 
    * Animals: 
      * Are multicellular, heterotrophic eukaryotes …
      * Lack the distinctive cell walls of plants & fungi
      * Share unique characteristics …
      * Share certain reproductive characteristics …
      * Other commonly used definitions …

Animals are multicellular heterotrophic eukaryotes

  * Unfortunately, none of these traits is exclusive to animals: 
    * Plants, fungi, and some algae are multicellular.
    * Many bacteria, protists, and all fungi are heterotrophic.
    * Everything other than bacteria and archaea are eukaryotic.
  * Moreover, all three of these characteristics also apply to fungi. 
    * However, there is a difference here between animals and fungi. Animals generally take in their food through ingestion, or eating and swallowing something. Fungi are absorptive heterotrophs; they secrete their digestive enzymes onto their food, and then absorb the resulting nutrients.

Animals share unique characteristics

  * Only animals have muscle tissue and nervous tissue.
  * Only animals have collagen, a structural protein
  * Only animals have the following types of intercellular junctions: (See pages 135 - 139, Figure 7.15 in your text for more information on these junctions.) 
    * Tight junctions (sealing function)
    * Desmosomes (anchoring function)
    * Gap junctions (communication function)

Animals share certain reproductive characteristics

  * Most animals reproduce sexually, with the diploid stage dominating.
  * In most animals, a small, haploid, flagellated, motile sperm fertilizes a larger, haploid, nonmotile egg to form a diploid zygote.
  * Mitotic division of the zygote yields a blastula stage, followed by a gastrula stage. A synapomorphy? This feature could be another "unique characteristic" shared by animals.
  * Development may be direct to adult form, or there may be a sexually immature stage (or stages) that are morphologically & ecologically distinct from the adult called a larva (plural: larvae).

Other commonly used definitions or characterizations

  * It is surprisingly difficult to find two texts that agree on a precise definition of an animal. Here are a few perspectives from some other texts. 
    * Animals are multicellular eukaryotes; they are chemosynthetic heterotrophs that ingest their food.
    * Animals are motile, though many are secondarily sessile. Gametes usually are produced in multicellular sex organs, and the zygote passes through embryonic stages that include a blastula.
    * Animals are organisms that are multicellular, with more than one type of cell. They are heterotrophic. They reproduce sexually (at least sometimes), with a zygote formed from two different haploid gametes. They go through a developmental stage called a blastula.
    * Animals are not photosynthetic, have no cell wall, and no hyphae or mycelia. (What would a cladist think of this definition of the taxon Animalia?)

What kinds of animals are there?

  * Kingdom Animalia generally is recognized to have approximately 30 phyla ... 
    * There is relatively little dispute over the number of phyla recognized; however, the phylogenetic relationships among the phyla are hotly debated.
    * Molecular techniques for assess similarity based on nucleotide sequences in nucleic acids are providing valuable new perspectives on this question.
  * Remember that two animals in different phyla generally are considered to be more different from each other than are animals within one phylum (e.g., nematodes are more different from annelids than humans are from sharks).

_This text is based on notes very generously donated by [Ralph Gibson, Ph.D.](http://bgesweb.artscipub.csuohio.edu/faculty/gibson.htm) of the [Cleveland State University](http://www.csuohio.edu)._ **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

## Introduction to animal phyla

There currently are almost 40 recognized phyla.

  
Phylum — Number of Species — Common Name

  * [Placozoa](/w/index.php?title=Placozoa&action=edit&redlink=1) — 1
  * [Monoblastozoa](/w/index.php?title=Monoblastozoa&action=edit&redlink=1) — 1
  * [Rhombozoa](/w/index.php?title=Rhombozoa&action=edit&redlink=1) — 50
  * [Orthonectida](/w/index.php?title=Orthonectida&action=edit&redlink=1) — 50
  * _**[Porifera](/w/index.php?title=Porifera&action=edit&redlink=1)**_ — 9,000 — sponges (figures)
  * _**[Cnidaria](/w/index.php?title=Cnidaria&action=edit&redlink=1)**_ — 9,000 — corals (figures)
  * [Ctenophora](/w/index.php?title=Ctenophora&action=edit&redlink=1) — 100 — comb jellies
  * _**[Platyhelminthes](/w/index.php?title=Platyhelminthes&action=edit&redlink=1)**_ — 20,000 — flatworms (figures)
  * [Nemertea](/w/index.php?title=Nemertea&action=edit&redlink=1) — 900 — ribbon worms (figures)
  * _**[Rotifera](/w/index.php?title=Rotifera&action=edit&redlink=1)**_ — 1,800 — rotifers (figures)
  * [Gastrotricha](/w/index.php?title=Gastrotricha&action=edit&redlink=1) — 450 — gastrotrichs
  * Kinorhyncha — 150 — kinorhynchids
  * _**Nematoda**_ — 12,000 — roundworms (figures)
  * Nematomorpha — 230 — horsehair worms
  * Priapula — 15
  * Acanthocephala — 700 — (figures)
  * Entoprocta — 150
  * Gnathostomulida — 80
  * Loricifera — 35
  * _**Annelida**_ — 15,000 — segmented worms (figures)
  * Sipuncula — 250 — peanut worms (figures)
  * Echiura — 135
  * Pogonophora — 145 — beard worms
  * Vestimentifera — 8 — beard worms
  * _**Arthropoda**_ — 957,000 — arthropods (figures)
  * Onychophora — 80
  * Tardigrada — 400 — water bears
  * Pentastomida — 95 — tongue worms
  * _**Mollusca**_ — 100,000 — molluscs (figures)
  * Phoronida — 15
  * Ectoprocta — 4,500 — sessile zooids
  * Brachiopoda — 335 — lampshells
  * _**Echinodermata**_ — 7000 — echinoderms (figures)
  * Chaetognatha — 100 — arrow worms (figures)
  * Hemichordata — 85 — acorn worms
  * _**Chordata**_ — 50,000 — chordates (figures)

## Phylum Porifera

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Woda-1_ubt.jpeg/220px-Woda-1_ubt.jpeg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Sponges

Name means "pore-bearing".

This phylum consists of the sponges. The number of species is estimated to be between 5,000 and 10,000. All are aquatic and almost all are marine.

Animals in this phyla have no true tissues, which means, for example, that they have no nervous system or sense organs. Although sponges are multicellular, they are described as being essentially at a cellular level of organization. They are sessile as adults, but have a free swimming larva.

Their bodies are porous. They are filter feeders; water flows in through many small openings, and out through fewer, large openings. They have inner and outer cell layers, and a variable middle layer. The middle layer often is gelatinous with spiny skeletal elements (called spicules) of silica or calcium carbonate, and fibres made of spongin (a form of collagen). Choanocytes are flagellated cells lining the inside of the body that generate a current, and trap and phagocytize food particles.

Their cells remain totipotent, or developmentally flexible: they can become any type of cell at any point in the sponge's development. This allows for the great regenerative power sponges have.

Sponges are an ancient group, with fossils from the early Cambrian (ca. 540 mya) and possibly from the Precambrian. Sponges often are abundant in reef ecosystems. They somehow are protected from predators (spicules? bad taste?).

Many organisms are commensals of sponges, living inside them. Some sponges harbor endosymbiotic cyanobacteria or algae (dinoflagellates, a.k.a. "zooxanthellae").

## [Phylum Cnidaria](//en.wikipedia.org/wiki/Cnidaria)

See text pages 886 - 889.

Name comes from the Greek knide- meaning "nettle".

This phylum They have one opening, which serves as both mouth and anus. The body wall has an outer ectoderm, an inner endoderm, and a variable undifferentiated middle layer called mesoglea or mesenchyme that may be jelly-like. The mesoglea is **NOT** considered to be true mesoderm and so the Cnidaria are described as diploblastic. Tentacles usually extend from the body wall around the mouth/anus.

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Schleiden-meduse.jpg/220px-Schleiden-meduse.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Jellyfish Development

There are two basic body plans: the [polyp](//en.wikipedia.org/wiki/polyp) and the [medusa](//en.wikipedia.org/wiki/Medusa_\(biology\)). The polyp is sessile and attaches to substrate by the aboral end (i.e., the end away from the mouth). The medusa ("jellyfish") is a floating form, and looks like an upside-down version of the polyp. Some cnidarians only have the polyp stage, some have only the medusa stage, and others have both.

The typical life cycle of a cnidarian involves what is called "alternation of generations": an alternation between an asexual polyp stage and a sexual medusa stage.

The tentacles are armed with cnidae (or nematocysts), small intracellular "harpoons" that function in defense and prey capture. When fired, the cnidae deliver a powerful toxin that in some cases is dangerous to humans. The phylum is named after the cnidae.

Cnidarians have no head, no centralized nervous system, and no specialized organs for gas exchange, excretion, or circulation. They do have a "nerve net."

Many cnidarians have intracellular algae living within them in a mutualistic symbiotic relationship (Dinoflagellates = zooxanthellae). This combination is responsible for much of the primary productivity of coral reefs.

There are three main classes in the phylum

  * [Class Hydrozoa](//en.wikipedia.org/wiki/Hydrozoa) (hydras and Portugese man-of-war are well-known but atypical examples of this Class)
  * [Class Scyphozoa](//en.wikipedia.org/wiki/Scyphozoa) (jellyfish) 
    * The medusa stage is dominant and the polyp stage often is reduced.
  * [Class Anthozoa](//en.wikipedia.org/wiki/Anthozoa) (sea anemones, most corals) 
    * No medusa (jellyfish) stage, so sexual reproduction occurs in the polyp stage in this group. The polyps also can reproduce asexually, which is how individual "corals" grow.

## [Phylum Platyhelminthes](//en.wikipedia.org/wiki/Platyhelminthes)

See text pages 890 - 893.

Name means "flat worm"

Most members of this phylum are parasitic (flukes and tapeworms), but some are free living (e.g., planaria). There are about 20,000 species.

They are dorsoventrally compressed (i.e., "flat").

Animals in this phylum are acoelomate, triploblastic, bilaterally symmetrical, and unsegmented. Platyhelminths have a simple anterior "brain" and a simple ladder-like nervous system. Their gut has only one opening. Flatworms have NO circulatory or gas exchange systems. They do have simple excretory/osmoregulatory structures (protonephridia or "flame cells").

Platyhelminths are hermaphroditic, and the parasitic species often have VERY complex reproductive (life) cycles.

There are four main classes of platyhelminths:

  * [Class Turbellaria](//en.wikipedia.org/wiki/Turbellaria) (mostly free living flatworms, e.g., planaria)
  * [Class Monogenea](//en.wikipedia.org/wiki/Monogenea) (parasitic flukes)
  * [Class Trematoda](//en.wikipedia.org/wiki/Trematoda) (parasitic flukes, e.g., liver fluke and the human blood fluke, Schistosoma)
  * [Class Cestoda](//en.wikipedia.org/wiki/Cestoda) (tapeworms) 
    * Cestodes are endoparasitic in the gut of vertebrates. They do not have a mouth or digestive system.

## [Phylum Rotifera](//en.wikipedia.org/wiki/Rotifer)

See text page 900

The Rotifers. The name means "wheel bearing," a reference to the corona, a feeding structure (see below).

They are triploblastic, bilaterally symmetrical, and unsegmented. They are considered pseudocoelomates.

Most less than 2 mm, some as large as 2 - 3 mm.

Rotifers have a three part body: head, trunk foot. The head has a ciliary organ called the corona that, when beating, looks like wheels turning, hence the name of the phylum. The corona is a feeding structure that surrounds the animal's jaws. The gut is complete (i.e., mouth & anus), and regionally specialized. They have protonephridia but no specialized circulatory or gas-exchange structures.

Most live in fresh water, a very few are marine or live in damp terrestrial habitats. They typically are very abundant. There are about 2,000 species.

Parthenogenesis, where females produce more females from unfertilized but diploid eggs, is common. Males may be absent (as in bdelloid rotifers) or reduced. When males are present, sexual and asexual life cycles alternate. Males develop from unfertilized haploid eggs and are haploid. Males produce sperm by mitosis which can fertilize haploid eggs, yielding a diploid zygote that develops into a diploid female. Sexual reproduction occurs primarily when living conditions are unfavorable.

Most structures in rotifers are syncytial ("a mulitnucleate mass of protoplasm not divided into separate cells," or "a multinucleated cell") and show eutely (here, "constant or near-constant number of nuclei").

## Phylum Nematoda

See text pages 894 - 895.

Name from the Greek for "thread".

This phylum consists of the round worms. There are about 12,000 named species but the true number probably is 10 - 100 times this!

These animals are triploblastic, bilaterally symmetrical, unsegmented pseudocoelomates. They are vermiform, or wormlike.

In cross-section, they are round, and covered by a layered cuticle (remember this cuticle !!). Probably due to this cuticle, juveniles in this phylum grow by molting. The gut is complete. They have a unique excretory system but they lack special circulatory or gas-exchange structures. The body has only longitudinal muscle fibers. The sexes are separate.

Nematodes can be incredibly common, widespread, and of great medical and economic importance. They are parasites of humans and our crops. They can live pretty much anywhere.

    In one rotting apple, there can be up to 90,000 nematodes, and in one tablespoon of coastal mud, there can be 236 species of nematodes!

Nematodes can be free living or important parasites of our crops, or of humans and other animals. They have become very important in development studies, especially the species Caenorhabditis elegans, presumably due to its small size and constancy of cell number (eutely - 959 cells in C. elegans).

## Phylum Annelida

See text pages 906 - 909.

Name means "ringed", from the Greek annulatus.

This phylum consists of earthworms, leeches, and various marine worms given many different names (e.g., sand worms, tube worms). There are about 12,000 - 15,000 species.

Animals in this phylum are triploblastic, bilaterally symmetrical, segmented coelomates. Development is typically protostomous. They have a complete circulatory system, and a well-developed nervous system. Typically, each segment has paired epidermal "bristles" (setae or chaetae).

Most are marine but they are successful occupants of almost anywhere sufficient water is available. They can be free living, parasitic, mutualistic, or commensalistic.

Major advances of this phylum include the true coelom, segmentation, both longitundinal and circular muscles, a closed circulatory system and, for most, a more advanced excretory system (metanephridia).

There are three main classes of Annelids

  * Class Oligochaeta (earthworms)
  * Class Polychaeta (marine worms)
  * Class Hirudinea (leeches)

## Phylum Arthropoda

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Arthro_characters.jpeg/220px-Arthro_characters.jpeg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Arthropods

Name means "jointed feet".

This phylum consists of spiders, ticks, mites, insects, lobsters, crabs, and shrimp, and is the largest of all the phyla. So far, over 1 million species have been named, and it is likely that the true number out there is 10 - 100 times greater.

    This phylum also includes the extinct trilobites, which were prevalent in the Paleozoic era. Because of their exoskeletons, these animals fossilized well and over 4000 species have been named.

These animals are triploblastic, bilaterally symmetrical, segmented, protostome coelomates. The coelom is generally reduced to portions of the reproductive and excretory systems. They have an open circulatory system.

The most notable advancement of this phylum is a rigid exoskeleton. It has major implications in these organisms' locomotion, flexibility, circulatory systems, gas exchange systems, and growth. It also was partially responsible for the ability of the arthropods to move on to land.

There are several major groupings of arthropods:

    Major subgroups include: 

  * The chelicerates (eurytperids, horseshoe crabs, scorpions, spiders, ticks) have clawlike feeding appendages. They lack antennae and usually have simple eyes.
  * The Trilobites...they get their own grouping
  * The uniramians (centipedes, millipedes, insects) have one pair of antennae and unbranched (uniramous) appendages.
  * The crustaceans (crabs, shrimp, lobsters, barnacles and many others) have two pairs of antennae and branched (biramous) appendages.
    Major Classes Include 

  * Class Arachnida (mites, scorpions, spiders, ticks)
  * Class Diplopoda (millipedes)
  * Class Chilopoda (centipedes)
  * Class Insecta (insects)
  * Class Crustacea (crabs, crayfish, lobsters, shrimp)

## Phylum Mollusca

See text pages 900 - 905.

Name means "soft".

This phylum consists of snails, slugs, bivalves, chitons, squids, octopus, and many others. About 110,000 species

All molluscs have a similar body plan:

  * A muscular foot, usually used for movement.
  * A visceral mass, containing most of the internal organs.
  * A mantle, a fold of tissue that drapes over the visceral mass and secretes the shell, if present.
  * Most have a radula, or a rasping organ to scrape food.

Molluscs are bilaterally symmetrical, or secondarily asymmetrical. They are coelomates, but the coelom generally has been greatly reduced; the main body cavity is a hemocoel. Development is typically protostomous. The gut is complete with marked regional specialization. Large, complex, metanephridia (excretion).

Many molluscan life cycles include a trochophore larva. This stage also is characteristic of annelids.

There are several major classes of molluscs:

  * Class Polyplacophora (chitons)
  * Class Gastropoda (snails, slugs, nudibranchs)
  * Class Bivalvia (clams, mussels, scallops, oysters)
  * Class Cephalopoda (squids, octopuses, chambered nautiluses)

## Phylum Echinodermata

Name means "spiny skin"

This phylum consists of sea stars, brittle stars, sea urchins, and sea cucumbers.

Echinoderms are mostly sessile or very slow moving animals.

As adults, they are radially symmetrical, but in the larval stage, they are bilaterally symmetrical. They are considered deuterostomes.

Echinoderms are unique in that they have a water vascular system composed of a system of fluid-filled canals. These canals branch into the tube feet, which function in feeding, locomotion, and gas exchange.

There are six major classes of echinoderms:

  * Class Asteroidea (sea stars)
  * Class Ophiuroidea (brittle stars)
  * Class Echinoidea (sea urchins, sand dollars)
  * Class Crinoidea (sea lilies)
  * Class Holothuroidea (sea cucumbers)

## Phylum Chordata

Name means "the chordates", i.e., these animals have a notochord at some stage in their lifecycle.

This phylum consists of tunicates, lancelets, and the vertebrates.

There are four major features that characterize the phylum Chordata.

  * A notochord, or a longitudinal, flexible rod between the digestive tube and the nerve cord. In most vertebrates, it is replaced developmentally by the vertebral column. This is the structure for which the phylum is named.
  * A dorsal hollow nerve cord which develops from a plate of ectoderm that rolls into a tube located dorsal to the notochord. Other animal phyla have solid nerve cords ventrally located. A chordate nerve cord splits into the central nervous system: the brain and spinal cord.
  * Pharyngeal slits, which allow water that enters through the mouth to exit without continuing through the entire digestive tract. In many of the invertebrate chordates, these function as suspension feeding devices; in vertebrates, they have been modified for gas exchange, jaw support, hearing, and other functions.
  * A muscular, postanal tail which extends posterior to the anus. The digestive tract of most nonchordates extends the length of the body. In chordates, the tail has skeletal elements and musculature, and can provide most of the propulsion in aquatic species.

Chordates have a segmented body plan, at least in development. This segmentation evolved independently from the segmentation of annelids.

Three subphyla make up the phylum Chordata:

  * Subphylum Urochordata (tunicates): the adults are enclosed in a tunic made of a carbohydrate much like cellulose. They squirt water out of an excurrent siphon. Urochordates are characterized by errant (mobile and active) larvae and sessile adults. All are filter feeders. The only "chordate" characteristics retained in adult life are the pharyngeal slits. Larval urochordates look more like adult cephlochordates & adult vertebrates than adult urochordates.
  * Subphylum Cephalochordata: Cephalochordates are known as lancelets because of their blade-like shape; they are also known as amphioxus. They are marine animals and usually live on the bottom, but can swim.
  * Subphylum Vertebrata (vertebrates) ...

Formally, the phyla Urochordata and Cephalochordata are considered invertebrates.

### Subphylum Vertebrata

Vertebrata refers to the presence of vertebrae and a vertebral column.

This subphylum includes most of the animals with which most people are familiar.

    Vertebrates show extreme cephalization.

The notochord generally is replaced by the cranium & vertebral column in adults.

#### Neural Crest Cells

Later in development, these give rise to many cells of the body, including some cartilage cells, pigment cells, neurons & glial cells of the peripheral nervous systems, much of the cranium, and some of the cells of the endocrine system.

Some scientists would like to classify the neural crest as the fourth germ layer.

Neural crest cells come from the dorsal edge of the neural plate, thus ectoderm. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Chordates

The phylum Chordata includes three subphyla. These include vertebrates and invertebrate chordates.

## Characteristics

Notochord: the rod-shaped supporting axis found in the dorsal part of the embryos of all chordates, including vertebrates

Flexible, non-collapsible rod dorsal to the gut/coelom and below the nervous system, hydrostatic, fluid wrapped in tough connective tissue. As bone does not compact, muscles tensed on one side result in movement instead of shortening the animal. This allows much better locomotion than do cilia for larger animals in water, a crucial victory for later success.

Pharyngeal slits: Slits in the pharynx originally used to gather food, water enters the mouth, passes through pharynx and out gill-like slits, passing through a cavity called an antrium and then outside. In humans, present only in embryo.

Dorsal nerve cord: A neural tube dorsal to the notochord

Postanal tail: Elongation of the body and notochord, nerve cord and muscles past anus into tail, early locomotive function led to success.

Non-synapomorphic characteristics (not limited to chordates):

  * bisymmetrical (bilateral symmetry)
  * segmented muscles and bones

## Subphylum Urochordata

The tunicates are located in this subphylum. Along with the subphylum Cephalochordata, these two subphyla make up the invertebrate chordates. Only the tunicate larvae have notochords, nerve cords, and postanal tails. Most adult tunicates are sessile, filter-feeders which retain their pharyngeal slits. Adult tunicates also develop a sac, called a tunic, which gives tunicates their name. Cilia beating within the turnicate cause water to enter the incurrent siphon. The water enters the body, passes through the pharyngeal slits, and leaves the body through the excurrent siphon. Undigested food is removed through the anus. Tunicates are hemaphrodites and can reproduce asexually through budding.In urochordates notochord is confined to larval tail.These lack cranium. These have an open type of circulatory system.Excretion is by neural gland,nephrocytes.there are two siphons through which water enters and exit.they have a tubular heart.they have a tough outer covering.example acidia

## Subphylum Cephalochordata

The lancelets are located in this subphylum. Along with the subphylum Urochordata, these two subphyla make up the invertebrate chordates. Lancelets receive their name from their bladelike shape. They resemble fish but they are actually scaleless chordates only a few centimeters long. They spend most of their time buried in the sand with their mouths protruding. Fossils of lancelets have been found to be over 550 million years old.

Dropped out sessile stage, what was the larval stage is now sexually reproductive. Includes Branchiostoma (“amphioxus”).

## Subphylum Vertebrata

(Vertebra from Latin vertere, to turn). Characterized by separate bones or cartilage blocks firmly joined as a backbone. The backbone supports and protects a dorsal nerve cord. Vertebrates have tissues which are organized into organs which in turn are organized into organ systems.

All vertebrates share the following characteristics: - segmentation - a true coelom - bilateral symmetry - cephalization - a backbone - a bony skull - a closed circulatory system - chambered heart - two pairs of jointed appendages - tissues organized into organs

Vertebrate Organ Systems: - Nervous System - Circulatory System - Digestive System - Respiratory System - Reproductive System - Excretory System

  * Vertebral column: Not present in higher vertebrate adults. (In humans, the gel-like, spongy core of the vertebral column is the only remainder. Ruptured or herniated disc is an injury to this.)
  * Cranium: Composite structure of bone/cartilage. Two functions: 1. Supports sensory organs of head and 2. Encloses or partially encloses the brain.

What evolutionary relationship could we imagine between sessile echinoderms and the higher chordate animals?

Paedomorphic (child-form) hypothesis: basically, evolution of sexual reproduction in what had previously been a larval life stage, or the retention of at least one juvenile characteristic into the adult (adult = sexually reproducing) stage. Some scientists believe that this occurred in a proto-chordate animal lineage. Maybe chordates (and vertebrates) arose from sessile (attached) ancestors. Selection in these proto-chordates maybe began to favor more time in the larval stage, as feeding was more successful or mortality lower in this stage. As larvae got bigger physics shows that the cilia become less efficient for locomotion, favoring the undulating motion allowed by a notochord.

Is this hypothesis crazy? A similar example of this today is Epemeroptera, the mayfly, which has almost abandoned its adult stage. Its one-year lifespan is mostly larval with just a brief day of reproduce-and-die as an adult, which doesn’t even have usable mouthparts.

Tunicate (sea squirt) larva has all four chordate characteristics, although adult sessile (“attached”).

### Class Agnatha

"jawless fish"

  * Ostracoderms: extinct Agnathans which had primitive fins and massive plates of bony tissue on their body.
  * Cyclostomes: "circle mouth" - a group of Agnathans which is still alive in the form of lampreys and hagfish.

Appeared approximately 500 million years ago and dominated the oceans for about 100 million years. The first group of fish to appear. They had neither jaws, paired fins, nor scales, but they were the first organisms with a backbone.

#### Class Acanthodia

"spiny fish" Appeared about 430 million years ago. An extinct class of fish that developed jaws with bony edges. They had internal skeletons made of cartilage and some bone.

#### Class Placodermi

Appeared about 410 million years ago, dominated the sea for about 50 million years. An extinct class of fisive heads.

### Class Chondrichthyes

"cartilaginous fish" Appeared about 400 million years ago with bony fish. Includes sharks, skates and rays, and chimaeras. Their skeletons are made of cartilage strengthened by the mineral calcium carbonate.

The main characteristics and distinguishing features of this class: - gills - single-loop blood circulation - vertebral column - presence of placoid scales on their bodies - internal skeleton of cartilage - paired, fleshy pectoral and pelvic fins - asymmetrical tail fin prevents sinking - fatty liver provides neutral buoyancy - visceral clefts present as separate and distinct gills - no external ear - oviparous - internal fertilization - ectoderms - cold blooded

### Class Osteichthyes

"bony fish" Appeared about 400 million years ago with cartilaginous fish. Includes about 95% of today's fish species.

##### Subclass Sarcopterygii

fleshy-finned fishes. Fins have bones and muscles, homologous to our limbs.

##### Order Dipnoi

lung fishes, two groups isolated when continents separated

##### Order Crossopterygii

includes coelacanths and rhipodistians, gave rise to amphibians, had lungs which evolved into a swim bladder in bony fishes, and labyrinthodont teeth, characterized by complex folding of enamel.

  
• Skeleton made of bone, jaws, fins, most with scales, two-chambered heart.

### Class Amphibia

means “both lives”, aquatic larvae, terrestrial adult Amphibians: - Legs - Lungs - Double-Loop Circulation - Partially Divided Heart - Cutaneous Respiration (Breathes through Skin)

##### Order Salientia

frogs (jumping) (aka Anura)

##### Order Urodela

salamanders (tailed)

Labyrinthodont amphibians: oldest known amphibians, inherited characteristic teeth from crossopterygii ancestor, had stocky, aquatic larvae.

Amphibians have limbs instead of fins. Girdles and vertebral column now more substantial and connected, support body on legs.

Lisamphybia: no scales, “smooth”, eggs with no shell, laid in water (water-reliant).

Amphibians gave rise to cotylosaurs, from which arose dinosaurs, turtles, lizards, and therapsids.

#### [Class Reptilia](/w/index.php?title=Reptiles&action=edit&redlink=1)

amniotic egg allowed freedom from water, shelled egg. (Amnion: protection). Reptiles have four extra-embryonic membranes:

  * Amnion: supports aquatic environment inside egg in fluid sac.
  * Allantois: allows gas exchange and elimination of wastes.
  * Chorion: gas exchange
  * Yolk sac: only one of the four left over from amphibian ancestor

Reptiles cold-blooded, or ectothermic, meaning that their heat come from their environment. Sometimes defined as all amniotes that are not birds or mammals.

Reptiles can be classified by skull structure into four groups:

  * Anapsid
  * Synapsid
  * Diapsid
  * Euryasid

Refers to number of holes in the skull. Cotylosaurs had Anapsid skull

Dermatocranium: from bony outer skull structure, precursor to human cranium.

##### Subclass Anapsidia

##### Subclass Testudinata

[turtles](/w/index.php?title=Turtle&action=edit&redlink=1), terrapins

##### Subclass Diapsida

[dinosaurs](/w/index.php?title=Dinsosaur&action=edit&redlink=1), [snakes](/w/index.php?title=Snake&action=edit&redlink=1), most stuff

##### Subclass Synapsida

###### Order Therapsids

##### Subclass Diapsida

includes Ichthyosaurs, marine reptiles convergent on dolphins; Plesiosaurs, ancient sea monsters; Squamates, including lizards and snakes; and Thecodonts, which gave rise to

  * birds
  * dinosaurs
  * crocodilians

Dinosaurs: broken into two groups, based on hip structure

  * Saurischia: lizard hips (gave rise to birds [!]), ancestrally bipedal
  * Ornithischian: bird hips, ancestrally quadripedal

Crocodilians: come from archosaurs, the only extant (still living today) archosaur descendant. Ancestrally bipedal, secondarily quadripedal.

Synapsids: refers to joined (Greek syn-, together with) parts of skull. Led eventually to mammals. Synapsid pelycosaur >> therapsid >> mammals

Pelycosaur: Sail-backed dinosaur, legs not spread out like lizard but more pillar-like and under body, allowing greater activity and competence in motion, pendulum like rather than constant push-up. Teeth differentiated into different types, for pre-processing of food needed by higher metabolism. Skull changes, bone histology, suggestions of warm-bloodedness.

#### Class Aves

arose late Jurassic, early Cretaceous. Feathers, skeleton modified for flight. Feathers: epidermal derivative, made of keratin (like fingernails). Carpometacarpis: bears primary flight feathers, parallel to hand parts. Keeled sternum: breastbone, powerful one needed to support flight muscles. Strong, light, occasionally hollow bones. All birds lay eggs (as contrasted to reptiles, which have developed live birthing over 100 independent times.) Why are there no live-bearing birds? Early birds had teeth, lost them. With mammals, only exothermic animals.

Archaeopteryx: “ancient wing”, Jurassic bird-reptile, very dinosaur-like. Good fossils found in Zolenhoffen, German sandstone mine with fine sand, shows feathers clearly, found shortly after Darwin’s publication and used to support his hypothesis. Thick, heavy bones and no sternum, bony tail, not a good flyer but did have primary flight feathers.

Archaeornithes: includes archaeopteryx.

Paleognathae: gave rise to Australian flightless birds.

Neognathae: remaining live birds.

#### [Class Mammalia](/w/index.php?title=Mammals&action=edit&redlink=1)

Two unique characteristics, or synapomorphies:

  * Hair
  * Mammary glands

(don’t fossilize well)

Three skeletal characteristics (fossilize)

  * Lower jaw only one bone, the dentary (several in reptiles)
  * Three bones in middle ear: malleus, incus, stapes (reptiles have one or two, never three)
  * Joint between upper and lower jaws between dentary and squamosal of skull (in reptiles this joint is between other bones)

Mammals basically have a synapsid skull design inherited from ancestor

Non diagnostic characteristics (not unique to mammals):

  * Warm-blooded
  * Skin glands: sweat glands and oil-producing sebaceous glands
  * Large nasal cavities (because of high metabolism) Clean, warm and humidify air
  * Heterodonty (differentiated teeth)
  * Diphiodonty: two sets of teeth: baby and adult (“deciduous” teeth, drop out) (reptile teeth are continually replaced)

##### Subclass Protheria

monotremes (Greek mon-, one; and trema, hole), or egg-laying mammals, have one opening for excretion and urination.

##### Subclass Theria

Metatheria: Marsupials (opossum, kangaroo…) Eutheria: Placental mammals (all common mammals)

Marsupium: (from Greek marsypion, purse or pouch). Gestation period much shorter than in Eutherian mammals, but after leaving the uterus the tiny offspring crawls into a pouch where it completes development latched onto a teat.

Recent molecular (read: genetic) evidence suggests that two different mammal groups may have developed live-bearing ability separately. Instead of being a “rough draft” for placental-style live bearing, perhaps the marsupial pouch approach is another solution to the same problem. Advantage: in tough times the parent can pitch out the offspring and increase its own chance of survival.

# Tissues and Systems

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Epithelial tissue

Comes from various sources, **ectodermal** or **endodermal** material. Cell sheet lines a surface or body cavity. One side, called **freesurface or Apical**, is exposed to

  * animal **interior** (forming the **lumen**) or
  * **exterior** of its **body cavity**.

The other side rests on the **basal layer**.

Epithelial tissue is not penetrated by blood vessels.

Two categories:

  * **sheets**
  * **glands**

Classified on two features:

  * **simple**, (a single layer of cells),
  * **stratified**, (more than one cell layer.)

Cell shape at free surface:

  * **squamous** (broad and flat)
  * **cuboidal** (spherish)
  * **columnar** (tall and thin)

**Simple squamous epithelium** 
    usually lines body cavities and vessels,alveoli, glomeruli of kidney; in blood and lymph vessels called endothelium; in body cavities called mesothelium (serosae): parietal serous membranes line body wall, visceral serous membranes cover organ
**Simple cuboidal epithelium** 
    in ducts like kidney and salivary glands.
**Simple columnar epithelium** 
    nonciliated type lines digestive tract, ciliated type lines some regions of uterine tubes and lungs
**Stratified squamous epithelium** 
    (important) lines mouth, esophagus,and vagina. Cells sometimes dead, flat and keratinized, making them resistant to abrasion. Stratified squamous epithelium changes to columnar squamous epithelium progressively down esophagus to the stomach.
**Epidermis** 
    from epithelium. Below this is **dermis**, thicker and with blood vessels.

Two specialized epithelia:

  * **pseudostratified**
  * **transitional**

**Pseudostratified epithelia** 
    lines the trachea (where it is ciliated)and the male urethra (where it is non ciliated), looks stratified but not.
**Transitional epithelia** 
    found only in bladder and urinary system. As it stretches it appears to go from 6 to 3 cell layers deep.
**Glandular epithelia** 
    (**gland**: group of cells that excretes something.. mostly derived from **epithelium**. Glands are classified into **endocrine** and **exocrine** by where they excrete.
**Endocrine glands** 
    secrete hormones into the **blood** without use of ducts.
**Exocrine glands** 
    secrete onto the **body surface** or into a **cavity**, thru a **duct**. Exocrine substances include sweat, mucous, oil, and saliva. An exocrine gland is the **liver**, which secretes bile.

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Connective tissue

This is a “grab bag” category of diverse tissue types. Functions include binding and supporting. Types include **bone**, **cartilage**, **fibrous connective tissue**, **blood** and **adipose** (fat) tissue.

If you took away everything in the body except the connective tissue, you’d still be able to see the basic form of the body.

**Form**: distinctive cells surrounded by a **cell matrix** made of **extra-cellular fiber** grounded in a **ground substance** (excluding blood)

Types:  
1\. **connectile connective tissues** (can be 1. **loose** or 2. **dense**)  
2\. **special connective tissue** (includes blood, bones and cartilage).

**Fibroblasts** form **connective tissue proper;**  
**chondoroblasts** form **cartilage;**  
**osteoblasts** form **bone;**  
and **blood** is formed from various sources.

**Ground substance**: “unstructured” material that fills space between cells and contains fibers. Made of  
1\. **interstitial fluid** (bathes cells)  
2\. **proteoglycans** (protein core with attached polysaccharides, glycoaminoglycans or GAGs such as chondroitin sulfate, keratin sulfate, and hyalronic acid, whose consistency is syrupy to gelatin-like)  
3\. **cell-adhesion proteins** (connect connective tissue cells to the fibers).

**Fibers** of **connective tissue**:  
1\. **Collagen** (flexible protein resistant to stretching, tensile strength, most abundant protein in animals, white)  
2\. **elastin** (rubbery, resilient protein, in dermis, lungs, blood vessels, yellow when fresh)  
3\. **andreticulin** (like collagen).

**Loose connective tissue**: found beneath skin, anchors muscles,nerves etc. Include **fibroblasts**, **macrophages**, **mast cells**,and **adipose cells**. **Fibers** include **collagen** and **elastic fibers**. Ground substance is “syrupy”. Adipose included.

**Dense connective tissue**: largely densely packed fibers of **collagen** or **elastin** regularly or irregularly arranged. Forms **tendons** and **ligaments**, coverings of muscles, capsules around organs and joints, and **dermis** of skin.

**Cartilage vs. bone**  


**Feature**
**Bone**
**Cartilage**

**cell type**
osteocytes
chondrocytes

**ground substance**
calcium phosphate 
chondroitin sulfate

**vascularization**
vascular
avascular

**micro architecture** 
highly ordered
less organized

**units called**
osteons

**fibrous sheath**
peristeum
perichondrium

**Cartilage:** There are three cartilage types:  
1\. **hyaline** cartilage  
2\. **fibrocartilage** (fibrous cartilage)  
3\. **elastic** cartilage

**Hyaline cartilage**: most widespread cartilage type, in adults forms articular surfaces of long bones, rib tips, rings of trachea, and parts of skull. Mostly **collagen**, name refers to **glassy** appearance. In embryo, bones form first as **hyaline** cartilage, later **ossifies**. Found in tracheal rings. Few collagen fibers.

**Fibrous cartilage**: have lots of **collagen** fibers. Found in intervertebral discs, pubic symphesis. Grades into dense **tendon** and **ligament** tissue.

**Elastic cartilage**: springy and elastic. Found in internal support of external ear and in epiglottis, yellow when fresh.

**Chondrocites** (cartilage cells) rely on diffusion for nutrients, as cartilage has no direct blood supply, and no enervation (nerves). Can be loaded with calcium salts.

**Bone**: Specialized connective tissue, calcium phosphate arranged in highly ordered unit called **osteon**, or **Hyvercian system**. Concentric rings around central canal with blood vessels and enervation (nerves). Bone varied, not all vertebrate bone is even cellular. Our concern: simple pattern for mammals.

**Lacuna** (spaces in which osteocytes found); **canaliculi** (little canals) bigger diagonal cells, layers of bone called **lamellae.**

Three types of bone cells, ending in  
-**blast**, (mend bone)  
-**cyte** (fortify bone)   
-**clast** (tear down bone)

Classified by  
1\. **appearance** (**spongy** vs. **hard**)  
2\. **where found** (outside or inside)  
3\. **how it is formed** (endochondral cartilage model forms first and then is ossified, and entramembranous, bone forms directly without cartilage precursor)

Example of **endochondral bone formation**: long bone begins to ossify from center shaft, calcified region expands and cuts off diffusion of nutrients as bone replaces cartilage. In young mammals, secondary ossification centers then form at bone ends, growth has stopped by sexual maturity as all primary bone is ossified. In other animals, bones continue growing throughout their lifetime.

Three types of **intramembrous bone**:  
1\. **dermal** bone  
2\. **sessamoid** bone  
3\. **perichondral** bone.

**Dermal bone** forms skull, shoulder/pectoral girdle, and integument, descended from dermal armor of ancestor. Comes from **mesoderm**, in dermis of skin.

**Sessamoid bones**: form directly in tendons. Example: kneecap, also in wrist. Deals with stress.

**Perichondral bone** means **“around cartilage,”** forms around cartilage or bone. Functions in bone repair and in ossification of endochondral bone.

**Bone remodeling and repair**: bone has mineral structure, and develops tiny fractures, which, under stress, can lead to larger fractures. To combat this, bone is constantly replaced. **Osteoclasts** channel through existing bone, tear down and leave behind **osteoblasts** and **lacuna**, leaving **osteocytes**. Continually resets mineral structure of bone, and is preventative maintenance.

When bone broken, callus forms in open ends, **periosteum** gives rise to new bone with calcium and new bone matrix, leaves irregular mend. Later, osteoblasts continue fixing over time and slowly removing imperfection. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Muscle tissue

Mesodermal in origin, muscle has several functions: **supply force for movement**, **restrain movement**, proper **posture**, act on viscera (internal organs) for **peristalsis** (moving food down digestive tract), give body **shape**, form **sphincters**, (such as in esophagus, between stomach and intestine, large and small intestine, in anus), in **sheets** of muscles, affect ai**r flow** in and out of lungs, line **blood vessels** and play vital role in **circulation**.

Secondary roles: **heat production** (shivering a specialized heat production to supplement metabolism).

Muscles co-opted to other non-original functions: sharks detect electrical field created by fish muscles. Some fish formed electric organs, create current strong enough to repel predators or stun prey. Other fish can use field as “radar” to see things and communicate with other animals. (Evolved independently in different groups).

Different classifications: by **color**, (red or white) **location**, nature of **nervous system contro**l (voluntary or involuntary), **embryonic origin**, or by **general microscopic appearance** (striated, smooth, and cardiac.)

**Striated muscle** (or **skeletal** muscle): under **voluntary control**. Individual cells called **fibers**, grouped into **fascicle**. **Myofibrils** founding one cell made of even smaller **myofilaments**. Each striated cell very long and **multi-nucleated**. Fibers joined end to end to form longer **composite fibers**. **Sarcomeres**: repeating units make up **myofibrils**. Two kinds of **myofilaments**, thick kind made up of **myosin** and thin of **actin**. Striations visible in light microscope, smaller part only with electron microscope.

**Cardiac muscle**: occurs only in **heart**. Light banding visible under light microscope. Each band short, principally mononucleate (occasionally dinucleate) often branched, joined together with intercollated discs. Involuntary. Waves of contraction spread through intercollated discs. Initiated by nerve stimulation or can originate in the heart itself (useful in heart transplants.)

**Smooth muscle**: no striations visible with light microscope. Almost entirely **visceral** function: digestion, sphincters, urogenital tracts, piloerectory muscles (make hairs stand up), lungs. Non-voluntary control. Slow and sustained action. Each cell mononucleate, short, fusiform (spindly) in shape, cells usually uniform in size.

Striated muscle contraction: Muscle broken into units called fascicles, in units of myofibrils. Repeating units called sarcomeres, consisting of two kinds of myofilaments:  
1\. thick, **myosin** filament  
2\. thin, **actin** filament.

**Sarcomere**: Thick and thin filaments interspersed in ordered grid.

**Sliding filament theory**: thick and thin filaments move past each other in opposite direction, shortening length. Longer muscles contract more rapidly than short ones (see cell bio for details).

**Myosin molecule**: two polypeptides twisted together with two globular heads at end.

**Myosin filament**: many slender myosin molecules together.

**Actin filament**: chain of actin single, **tropomyosin** strands with repeated **globular troponin**, and with **actin**. All play role in muscle contraction. Myocin heads have sites that bind to actin. Actin filaments have many regular sites that can bind to myosin.

**Troponin** has **four site**s:  
1\. one to bind **myosin**  
2\. one for **actin**  
3\. one for **tropomyocin**  
4\. one for **calcium ions**

Nerve signal reaches muscle, triggers release of chemical signal called neurotransmitter, that diffuses across cell membrane (**sarcolimic reticulum**) and binds to receptors in it. Receptor is **acetylcholine**, ACH. When there is enough nerve signal, the message travels through t-line to sarcoplasmic reticulum to release calcium ions.

Lacking calcium, **tropomyosin** site blocked. In calcium, myosin binding sites exposed and heads bind to **actin** molecules, delivering force to move **fibers** in relation to each other. Myocin head then interacts with **ATP** to get “recocked”, if myosin still exposed then it fires again and results in further muscle contration. If there is no further nerve signal, **sarcoplasmic reticulum** sequesters Ca+ ions again and no recocking occurs.

**Quirari (or curare)**: known from movies, used in South America, blocks **acetylcholine receptors** in cell and causes skeletal paralysis. Victim dies of asphyxiation because he can’t breathe.

**Duchenne's muscular dystrophy**: degeneration of **sarcolema**, plasma membrane of muscle cell unable to release signal and quickly atrophies.

**Fast** and **slow twitch fibers**: vertebrate muscle fiber. Terms relative within one group of animals. Differences related to differences in **enervation**, type of **myocin**, and **actin activation**.

Two parts of force generated by muscle: 1. **active** component 2. **elastic** component (energy stored in muscle when stretched by gravity or another force. Stored in muscle elastic tissue around tendons. Especially important in **limb oscillation**, like running, or trunk twisting, like fish swimming. Up to 90% of stored elastic energy can be recovered.)

How does a muscle match its power to its job? Two ways:  
1\. **rate modulation**, derived from frequency of nervous stimulation of muscle, force increases as frequency of stimulation increases up to point of tetanus.  
2\. **selective involvement of motor units**, a given neuron enervates a fixed number of muscle cells, (a motor unit), and force is increased by recruiting more motor units. Motor units may be small, such as in eye, or larger, like in leg muscle.

How do muscles grow stronger?  
1\. add more **myofilaments**, increases cross sectional area by up to 50%, more little ratchets working  
2\. proliferation in **blood vessels** and **connective tissue** around muscle

Muscle strength is relative to **cross sectional area**, not length. Not always feasible to add more cross sectional area.

**Pinnate fibers**: oriented obliquely (Y-shaped) to minimize muscle mass, in certain circumstances, like calf muscle. Spreads muscle out.

Velocity of shortening greater in long muscle than short. Why? Contraction tied to relation between fibers, and to total length of muscle. Both long and short muscles reach same percentage of contraction in same unit time, but distance covered by the longer muscle is greater.

**Synergist muscles**: muscles work together to produce motion in same general direction. Bicep shares work with brachialis.

**Antagonist muscles**: muscles that oppose each other. Bicep pulls forearm in, triceps pulls it back out.

**Origin vs. insertion**: origin is the end of the muscle that more fixed in its attachment to the body. The more movable end called insertion.

**Fixators**: muscles that act to stabilize a joint or lever system. Like upper arm when you clench your fist hard.

**Flexors and extensors**: applied mainly to limbs. Flexor bends one part relative to another about limb, extensor straightens it.

**Adductor and abductor**: adductor draws a limb toward the ventral surface. Abductor moves limb away from ventral surface. (Adduct: drawn toward; abduct: carry away). **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Vertebrate digestive system

  
Functions to break down food into molecules small enough to absorb, or pass across digestive membrane.

**Digestive tract**: tube extending from lips of mouth to anus or cloacae in bird, reptile or monotreme.

**Lumanal glands**: empty into inner body cavity (lumen: inner surface).

Tract divided into three main regions:  
1\. buccal cavity  
2\. pharynx   
3\. alimentary canal

Alimentary canal divided into four regions:  
1\. esophagus  
2\. stomach  
3\. small intestine   
4\. large intestine

**Accessory digestive glands**, outside digestive tract proper, secrete into lumen of tract through ducts. Includes the **salivary glands**, **liver** and **pancreas**.

**Buccal cavity**, which includes **palate** and **tongue**, develops from infolding of **stomadeum**, or second opening of blastula, whereas the rest of the digestive tract develops from the **primitive** gut**.**

**Teeth**: capture and hold prey. In mammals in particular further process and break down food into small particles, increasing surface area available for enzymatic action.

**Tooth anatomy**:  
1\. **crown** projects above gum,  
2\. **root** below gum,  
3\. **enamel** is outer coating of crown, hardest surface in body, of epideral origin  
4\. **dentin**, below enamel, bone-like and forms bulk of tooth, is harder than bone and contains nerves and blood vessels. (Remember that mammals are **heterodontic**, with different types of teeth).

**Pharynx**: air passage for adult, gill slits in embryo. Important in lower vertebrates, site of gills. Features derived from **pharyngeal** region: first pharyngeal pouch gives rise to parts of the ear, other pouches give rise to various other structures.

**Alimentary canal**: epithelium lines lumen, glands secrete into lumen, longitudinal and circular muscles help digestive movements (**peristalsis**).

**Esophagus**: tube carries food from mouth to stomach. Expands to fit large **bolus** (lump of chewed food). Secretes mucus for lubrication. Birds have **crop** for storage, enlargement of esophagus.

**Epiglottis**: keeps food out of air tube, an evolutionary “kludge,” or fix.

**Stomach**. Absorbs water, alcohol, nutrients, uses gastric juice with enzymes, mucous, HCl, released by **chief** and **parietal cells** (release protein enzymes) in gastric pits. **Rugae**: folds of stomach, disappear when full. **Sphincter** at both ends of stomach, control food passage.

**Chyme**: semi-digested food released to small intestine.

**Small intestine**: three regions, **duodenum**, **jejunum**, and **ileum**.

**Duodenum** site of most intestinal digestion. **Jejunum** and **ileum** do most of intestinal absorption. Ileum ends with another sphincter, **ileocolic valve** or ileosecal valve. Structure: Circular folds covered with **villi** (singular is villus).

**Villi**: finger-like cellular projections, covered with **microvilli**, tiny projections which increase surface area. Increases surface area by 900x, speeds **digestion** (break down) and **absorption** (taking in nutrients).

**Large intestine**: larger diameter, shorter length than small intestine. No villi. In mammals, forms large gentle loop, colon, empties into straight region, rectum, empties into outside world through anal sphincter. Colon: absorbs water left over, also absorbs vitamins released by bacteria which live there (vitamin K).

**Food**: made up of 1. **proteins**, 2. **fats**, 3. **carbohydrates** 4\. **fibrous material**.

Digestive system breaks foods down. **Proteins** must be broken to **amino acids** to be absorbed. **Polysaccharides** to **monosaccharides**, **lipids** to **fatty acids** and **monoglycerides** to absorb.

**Salivary glands** in mouth, saliva contains mucous, salt and a few enzymes (amalase, begins starch breakdown). Snake venom from oral gland, mixture of toxins and digestive enzymes. Breaks down blood vessels and disables nervous system.

**Stomach enzymes**: released in inactive form, **zymogene**, converts to active form in lumen of gut. Transformation is triggered by another enzyme, or the stomach’s low pH. **Pepsin** secreted as **pepsinogen** (-ogen means primitive form). Stomach glands secrete up to two or three liters a day of gastric juice, which is reabsorbed.

**Chyme** released to **duodenum**.

**Small intestine** has two major accessory glands:  
1\. **pancreas**  
2\. **liver**

**Pancreas** has **endocrine** and **exocrine** functions, releases large amounts of carbonate to neutralize acidic chyme, as intestinal enzymes work in neutral pH, and stuff to break down lipids and starch (zymogens, like tripsin)

**Liver** releases **bile**. Bile made from cholesterol, stored in **gall bladder'_, released in duodenum, emulsifies fats.'_**

**Emulsify**: keeps fats in tiny drops, which are suspended, increasing surface area and action of lipases. Protein and carbohydrates absorbed in intestine, taken to liver for processing. Fatty acids go to lymphatic system

**Appendix**: vestigial remnant. Much variation in digestive systems within mammals: herbivore, carnivore, insectivore, non-ruminant herbivore.

**Rumen**: four-chambered stomach of animals like cows (ruminant herbivores). Cellulose resistant to digestion, rely on microorganisms to break down cellulose. Some bacteria, protists and fungi can break down cellulose, almost no animals can. Bacteria break down cellulose in rumen, to be taken back to the mouth to chew their cud (ruminate). Later cow swallows to proceed with digestion. (Horses not like this).

**Coprophagy**: rabbits and other animals eat their own feces for the nutritious products of the cecum. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Circulatory system

**Circulatory system functions**

1\. **Transportation**  

    
    
     a. Respiration: gas exchange (O2 and CO2), overcomes limited rate of
    

diffusion  

    
    
     b. Nutrition:  
     c. Excretory: (remove metabolic wastes)  
    
    

2\. **Regulation**  

    
    
     a. Transport hormones  
     b. Regulate body temperature  
     c. Protection  
        i.  Blood clotting  
        ii.  Immune system (carries white blood cells)
    

**Vasodilation**: allows heat loss across epidermis, as seen in elephant ears, takes more blood to surface of body, sweating may accompany

**Countercurrent heat exchange**: used by dolphins in fins to conserve heat in cold water. Veins surround an artery, and blood returning to body absorbs heat from blood traveling out from body to fin, minimizing heat loss. Used by dogs in feet, etc.

Blood made of  
1\. **plasma** and  
2\. **formed cellular elements** (red and white blood cells, and platelets).

Plasma makes up 55% of blood volume. Cellular elements make up the other 45%.

**Plasma makeup**: 90% water, 7-8% soluble proteins (**albumin** maintains blood osmotic integrity, others clot, etc.) 1% electrolytes 1% elements in transit

**Red blood cell** (**erythrocyte**): contains **hemoglobin**, functions in oxygen transport. In mammals, red blood cells lose nuclei on maturation, and take on biconcave, dimpled, shape. No self repair, live 120 days. About 1000x more red blood cells than white blood cells. About 7-8 micrometers in diameter.

**Hematocrit**: proportion of blood volume that is occupied by cells, about 43% in humans on average. 48% for men and 38% for women.

**White blood cells** (**leukocytes**): Nucleated, about 10-14 micrometers in diameter, commonly amoeboid, escape circulatory system in capillary beds. Include basophils, eosinophils, neutrophils, monocytes, B- and T-cell lymphocytes.

**Platelets** (**thrombocytes**) Membrane bound cell fragments in mammals, no nucleus. In non-mammals, platelet role replaced by nucleated cells. Accumulate at site of broken blood vessels, form clots. Bud off special cells in bone marrow. 1-2 micrometers in diameter. 7-8 day life span, 1/10 or 1/20 as abundant as white blood cells.

**Arteries**: carry blood **away** from heart. Smallest tubes called **arterioles**, feed blood to capillaries.

**Veins**: return blood to heart. Smallest veins called **venules**.

Structure of arteries and veins, listed from inside (lumen) out:  
1\. **epithelium** (endothelium),  
2\. **elastic connective tissue fibers**,  
3\. **smooth muscle**,  
4\. **connective tissue**. Arteries have thicker elastic layer than do veins.

**Capillaries**, where exchange of materials occurs, are very thin and narrow, and red blood cells pass through single file. Capillaries are tiny but numerous, and their total volume is greater than that of supplying arteries.

Blood velocity drops in capillaries, picks back up in veins. Pressure highest in arteries, lower in capillaries and arteries.

Osmotic pressure draws interstitial fluid from blood in arterioles, but replaces it in venules.

**One-way valves** mean that blood can flow only one way, works with residual blood pressure and compression by skeletal muscles. Low pressure in thoracic cavity caused by breathing also helps move blood.

* * *

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material) **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

**Lymphatic system**: part of the immune system, a one-way, or **open**, system. Takes up **interstitial fluid** not taken up by venules.

**Lymphatic structures**:  
1\. lymphatic **capillaries**  
2\. lymphatic **vesicles**  
3\. **lymph nodes**  
4\. lymphatic **organs** (**spleen** and **thymus**)

**Lymph**: movement in mammals through one-way valves, similar to blood movement in veins. (Some non-mammals have lymphatic hearts of unknown embryonic origin. Frogs and salamanders have several.) Lymph rejoins cardiovascular system into a large vein near the heart via single large thoracic duct.

As lymph passes through system, passes **lymphocytes**, second part of immune system.

**Heart**: pumps blood, design varies between animals. In adult mammal,four chambers form two separate circulations  
1\. **pulmonary circulation** to and from lungs and  
2\. **systemic circulation** to and from tissues of body.

Everything in the heart comes in pairs: 2 atria, 2 ventricles (left and right).

Diagrams usually drawn as though animal were on its back.

**Pattern of blood flow through heart**: blood returning from **major veins** (vena cava) enters right **atrium**, contraction there delivers blood to right **ventricle** through a **tricuspid valve**, one of atrial ventricular valves (AV valve). Contraction of right ventricle drives blood through **semi lunar valve** into **pulmonary circuit** and to **lungs**.Blood return to heart in **pulmonary veins**, is oxygenated. Goes to left **atrium**, which contracts and delivers blood to left **ventricle**by way of **aortic semi-lunar valve**, then goes to **systemic circulation**.

Both **atria** and **ventricles** contract in unison, left is more powerful than right (to all system vs. just lungs).

**Systole**: heart contraction, **diastole**: heart relaxed

**Timing of heart contraction**: **ventricles** rebound to relaxed shape (diastole), and **semi-lunar valves** close. Both **atria**(singular: atrium) fill with blood coming from pulmonary and systemic circulations.Pressure rises in the atria and blood begins to move into the **ventricles**.The atria then contract, forcing more blood into the ventricles. There is a pause, then ventricles contract. This raises ventricle pressure, **atrio-ventricular(AV) valves** shut and semi-lunar valves open, forcing blood from the left ventricle into the major arteries and from the right ventricle into the **aorta**.

Control for this action doesn’t rely on nervous stimulation, has intrinsic rhythmicity, called **myogenic**. This is the case in mammal as well as in mollusk hearts. Other animals have **neurogenic** hearts that rely on nervous stimulation for heart action, originating in the **cardiac ganglion**.

The rhythmicity of mammalian heart relies on the **sino-atrial (SA)node**, or pacemaker. This is a **phylogenic** (based on evolutionary history) remnant of an early vertebrate heart that had one more chamber than modern hearts.

**How the heart contracts**: waves of **depolarization** start in **SA node** and spread through **atria**. Connectile tissue pauses the spread of depolarization at the atrial ventricular node. Signal continued by **bundle branches** to **lower ventricle**, begins to stimulate heart to contract. Contraction starts at bottom of heart at **heart apex**,then signals spread through heart.

**Medulla** (in the brain) controls autonomic nervous system. (The medulla is part of the brain, is continuous with the spinal cord, and controls involuntary actions of the body). **Sympathetic cardiac accelerator**connects to **spinal cord**, uses **norepinephrine** to signal. **Parasympathetic cardio-inhibitory center** reaches heart through **Vagus nerve**, uses**acetylcholine** to signal. Hyperpolarizes membrane to inhibit heart contraction. (Autonomic nervous system: two parts working in contra to control from both sides.) Dominant effect here is **inhibitory**. If we cut Vagus nerve, heart rate promptly rises about 25 bpm.

* * *

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material) **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Respiratory system

In humans and other animals, for example, the anatomical features of the respiratory system include **airways**, **lungs**, and the respiratory muscles.

Other animals, such as insects, have respiratory systems with very simple anatomical features, and in amphibians even the skin plays a vital role in gas exchange.

Plants also have respiratory systems but the directionality of gas exchange can be opposite to that in animals. The respiratory system in plants also includes anatomical features such as holes on the undersides of leaves known as **stomata**.

In mammals, the **diaphragm** divides the body cavity into the
    
    
      **abdominal cavity**: contains the viscera (e.g., stomach and intestines)
    
    
    
      **thoracic cavity**: contains the heart and lungs. 
    

**Respiratory tree**: terminates in alveolus, alveoli. Respiratory bronchioles branch into alveolar ducts and into alveoli. Alveolus: microscopic air sacs, 300 million of these in human lungs. Total surface area large. Gas diffuses micrometer, very tiny distance. **Nervous System**

Composed of tissues designed to integrate sensory information and direct a coordinated response to the environment.

Basic unit of the nervous system is the [neuron](http://en.wikipedia.org/wiki/Neuron), a highly specialized cell that uses both electrical and chemical processes to communicate. Neurons "listen" to sensory organs or other neurons, and can simultaneously "hear" from 1 to hundreds of inputs simultaneously. Likewise, a neuron can "talk" to other neurons or cells that can create an action, like muscle cells or glands.

Neurons are outnumbered in the nervous system by _glia_. Glia were once thought to only play a supportive role in helping neurons survive; today we know that they also are important participants in the communication process. Glial cells include astrocytes, ependymal cells, and a cell that has a macrophage like function. There are also oligodendocytes and Schwann cells that provide a myelin sheath.

## Neuron structure

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Complete_neuron_cell_diagram_en.svg/220px-Complete_neuron_cell_diagram_en.svg.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Neuron

  * Dendrite will receive information from other axons
  * Stoma is the neuron body and contains typical cell parts including the mitochondria and nucleus. This is where neurotransmitters are synthesized.
  * Axon hillock is where the cell body and the axon meet.
  * Axon is surrounded by myelin. 
    * Contains nodes of Ranvier

Types of axons include unipolar, bipolar, pseudopolar.

Action potentials results from excitatory stimuli received from the dendrites that results in a signal that travels down the axon. On the cellular level, there is a Na+ influx via channels causing a depolarization of the cell. Once those channels close, the slower opening K+ channels will open resulting in hyperpolarization by the cell.

Synapses

Neurotransmitters allow a chemical signal to be sent from one neuron to the other. Neurotransmitters must bypass a physical gap called the synapse. Examples of neurotransmitters include acetylcholine, epinephrine, and glutamate.

Example : Neuromuscular synapses

Circuits / Nuclei / Ganglia

## Central nervous system

Central nervous system includes the brain and the spinal cord.

Brain There are four lobes of the brain.

  * Frontal lobe - decision making
  * Parietal lobe
  * Temporal lobe
  * Occipital lobe - vision

The areas of the brain are also dedicated to different functions.

  * Precentral gyrus
  * Postcentral gyrus

Protection The CNS is protected by three layers - the pia mater, the arachnoid mater, and the dura mater. Protection also comes from the circulation of cerebral spinal fluid (CSF). CSF helps to float the brain and also provide nutrients to both the brain and the spinal cord. CSF is synthesized from the choroid plexus of the lateral ventricles. In total, there are four ventricles - 2 lateral ventricles, a 3rd, and 4th ventricle.

## Peripheral nervous system

The peripheral nervous system is broken down into two sub-systems, the somatic nervous system and the autonomic nervous system.

ANS - Autonomic Nervous System The ANS has two components - parasympathetic and sympathetic.

The sympathetic nervous system is the "fight or flight" or fright response and results in an increased heart rate, increased rate of breathing, and an elevated blood glucose level. There is also decreased digestion. The second neurotransmitter is epinephrine. In this case, the first neuron is short and the second neuron is long.

The parasympathetic nervous system is the rest and digest system.

Drugs must be able to pass the blood brain barrier to have an effect on the CNS. Drugs act by affecting the neuron and how likely it is to fire an action potential.

Stroke occurs when there is a blood clot that goes to the brain and prevent blood flow. **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Sensory systems

Categorized by  


  1. **nature of stimulus**, such as **mechanical**, **chemical**or **light** stimulus, and  

  2. **where stimulus received**, such as **outside** (**exteroceptors**,such as the **eye** and **skin temp receptors**) or **inside**body (**interoceptors**, such as **blood body temperature receptors**).

**Transduction** of sensory input into signal. Means to “carry across”,signal transduced, or carried, from environment into nervous signal.

Three sensory processes we cover  


  1. **taste** and **smell** (chemoreception)  

  2. **gravity** and **movement**   

  3. **light**

## Taste and smell (chemoreception)

Found in mammal nose and mouth, fly feet, fish bodies, moth antennae.

Papilla: bumps on tongue, contain taste buds down between. Sweet, sour, salty and bitter. Some act directly by ion channels, others act indirectly. Other “taste” sensations really smell.

Smell: received in **nasopharynx**. Airborne molecules go into solution on moist epithelial surface of nasal passage. Approximately 1000 genescode for sensory neuron receptors. “Fried onions” odor not one receptor but a mixture of many odors registered in our mind as one. Very sensitive, habituates rapidly (don’t notice a smell after a bit). Odor sensation has relatively unfiltered root to higher brain centers.

Snakes more chemosensory focused than us.

## Response to gravity and movement

Registered in **inner ear**. Three semicircular canals loop in three planes at right angles to each other, responsible for transduction of movement messages. Method: hair cells deformed by gelatinous membrane. **Vestibular apparatus**, gives us perception of gravity and movement. Due to **physical response**, not chemical binding.

**Cochlea**: bony, coil shaped part of inner ear, where hearing occurs.

Sound enters through **auditory canal**, vibrates **tympanic membrane**,moving three bones of middle ear (**malleus**, **incus**, and **stapes**)against oval window opening in front of cochlea. Cochlea has three fluid filled ducts, one of these the **organ of Corti**. Sound waves in air go to vibration in organ of Corti; fluid tickles **hair cells**, which register the movement along **basilar membrane** in cochlea. Different sound frequencies move different portions of basilar membrane. Hearing loss due to loss of hair cells.Humans normally smell more than 300 odors in a day(Facts and Truth).

Transduction of sound accomplished throgh **physical deformation**,not chemical binding.

## Vision

Light enters **pupil_, focused by_** _lens **onto** retina**.'**_

**Sclera**: hardened part behind retina.

**Optic nerves** and **neurons** attached to retina. Blind spot where optic nerve attaches, has no receptors. 

Two types of photoreceptors  


  1. **rods** \- black and white low-light vision, 100 million in each retina in humans.  

  2. **cones** \- color vision, work best under better illumination. 3 million in each retina.

**Fovia**: region of most acute vision, has most of the cones, few rods.

Transduction process of light to signal a molecular change, to light absorbing molecule called photopigment. Located in outer parts of rods and cones in pigment discs. The rod photopigment is called **rhodopsin**,cone has three photopigments, called **photopsins**. This molecular change initiates pathways to result in action potential in downstream neuron leading to vision center in brain.**Parul Godika**

Each of the three photopsins has a different peak of sensitivity: **blue**,**green** or **red**, and changes **isometric form** (from cisto trans) based on light from a particular wavelength range. Color blindness:inherited lack of one or more types of these cones. Gene carried on X chromosome, therefore more common in men than women.

* * *

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material) **[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

## Homeostasis

Is a very important part of everyone's and everything's lives. Defined as **dynamic constancy of internal environment**, maintenance of a relatively stable environment inside an organism usually involving **feedback regulation**.

**Homeostasis** is maintained in face of

  1. a **varying external environment**, or
  2. a **non-ideal, constant external environment** (as with the penguin).  


Deals with **temperature**, **pH**, **chemical concentrations**,**pressure**, **oxygen levels**.

Occurs through **negative feedback loops**.

Various forms: simple thermostat in house turns off heater when above a certain temperature and on when below a certain temperature Involves **stimulus**, **sensor**,**integrating center**, **effector** and **response**.

More efficient control has **two sensors** and **two effectors**. Can be antagonistic to each other, such as, one cools, the other heats.

Precise control through **proportional control**, not all-or-none, furnace comes on a little bit if the house a bit cold. Examples in humans: vasoconstriction, change in metabolic rate, shivering. Physiological responses for high body temp: blood goes to body surface, sweating, behavioral changes (get out of sun).

**Positive feedback loop**: effector increases deviation from set point. Amplifies reaction. Like blood clotting process, uterine contraction during childbirth. Negative feedback must exist at some point for control.

## Osmotic environments and regulations

  1. **Marine invertebrates**
    1. fully marine invertebrates (not intertidal or estuarine) osmoconformers (set internal environment same as environment, no net flow of ions) in a stenohaline (narrow non-changing salt level) environment
    2. Coastal, intertidal, estuarine (ion levels fluctuate) invertebrates.Partly osmoconfomers, partly osmoregulators in a euryhaline (wide salt level variation) environment (ex: shore crab, regulates sometimes when salt levels in environment get real low).
  2. **Freshwater animals**. Here, environment has lower solute concentrations than do living organisms so water tends to flow in and solutes out. 
    1. Freshwater fish (bony) dilute urine, and gills actively take up ions (NaCl)
    2. Freshwater invertebrates: same situation as freshwater fish but with different structures
    3. Freshwater amphibians: active uptake of salts across their skin
  3. **Marine fishes**: Here the environment has a higher solute concentration than does the organism so water tends to flow out and ions in. 
    1. Bony fishes: actively secrete salts (NaCl) across gills, absorb water across gut wall, their kidney (unlike mammalian kidney) is unable to generate concentrated urine so glomerulus is reduced, active tubular secretion of MgSO4
    2. cartilaginous fishes (and coelacanth): blood retains urea and trimethylamineoxide to increase its osmolality to that of seawater
  4. **Terrestrial animals**: here problem is loss of water to a drier environment, and regulation of salt levels. 
    1. water loss adaptations
    2. concentrated exception of salts and nitrogenous wastes

**Hypoosmotic**: having less osmotic potential than nearby fluid

**Hyperosmotic**: having more osmotic potential than nearby fluid

**Isoosmotic**: having equal osmotic potential than nearby fluid

**Glomerulus**: reduces volume of kidney

Fish started in salt water, spread to fresh water, later reinvaded salt-water environment.

Terrestrial animal water sources:  
1\. drinking  
2\. moist foods  
3\. from breakdown of metabolic molecules like fats. (Desert kangaroo rats get 90% of their water from metabolism.)

Secretion of nitrogenous wastes: from metabolism of amino acids, amino group has to be removed in one of three basically interchangeable chemical forms:  
1\. **ammonia** (aquatic life)  
2\. **urea** (mammals)  
3\. **uric acid** (birds)

**Ammonia** very toxic, soluble, and cheap to produce. Easy to expel for bony fishes.

**Urea**: low toxicity, good solubility, more costly to lose as it contains other groups on it. Must be released in solution, water cost.

**Uric acid** (white part of bird poo) low toxicity, insoluble, secreted with little water loss, more costly side groups lost than the others.

**Mammalian kidney**: Structure: fist-sized organ in lower back. About 1/5 of blood from aorta at any time is passing through kidneys. Blood passes through kidney many times a day.

**Nephron**: structural and functional unit of kidney.

**Bowmans capsule**: funnel-like opening, contains primary filter, the **glomerulus**.

**Proximal convoluted tubule**: receives stuff from Bowmans capsule.

**Loop of Henle**: descends and ascends.

**Vasa recta**: capillaries that surround the Loop of Henle.

**Glomerulus**: main filter of the **nephron**, located within the **Bowman's capsule**

Kidney properties and processes important to its function

1\. **Active transport of solutes** from one fluid to another against a concentration gradient, Na+ actively transported out of filtrate by cells of the thick ascending loop of Henley into the interstitial fluid  
2\. **Passive movement of solutes** and water from one fluid to another(down a concentration gradient), movement of water and NaCl out of descending loop of Henley into interstitial fluid.  
3\. **Differential permeability of cells** in different regions of the nephron to movement of water and solutes, ascending thick look is impermeable to water, descending portion is permeable to water  
4\. **Hormonal control of that permeability**, antidiuretic hormone(ADH) increases permeability of collecting due to water, resulting in reduced volume of filtrate and thus more concentrated urine.  
5\. **Increasing solute concentration in the interstitial fluid of the kidney**, from the cortex to the deepest medulla, maintained by a countercurrent multiplier mechanism

* * *

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

# Additional material

  * [Francis Crick](//en.wikipedia.org/wiki/Francis_Crick) _chemist and molecular biologist, discovered structure of DNA molecule_
  * [Charles Darwin](/wiki/General_Biology/Gallery_of_Biologists/Charles_Darwin) _the father of the science of evolutionary biology_
  * [Richard Dawkins](//en.wikipedia.org/wiki/Richard_Dawkins) _zoologist and biology populariser_
  * [Stephen Jay Gould](//en.wikipedia.org/wiki/Stephen_Jay_Gould) _paleontologist and science populariser_
  * [J.B.S. Haldane](//en.wikipedia.org/wiki/J.B.S._Haldane) _geneticist and evolutionary biologist, founded population genetics and the modern synthesis_
  * [Bill Hamilton](//en.wikipedia.org/wiki/William_Hamilton) _formulated theory of inclusive fitness and kin selection_
  * [Thomas Huxley](//en.wikipedia.org/wiki/Thomas_Huxley) _"Darwin's Bulldog", early evolutionary biologist and science populariser_
  * [Lynn Margulis](//en.wikipedia.org/wiki/Lynn_Margulis) _introduced the theory of eukaryotic cell origin through endosymbiosis_
  * [Barbara McClintock](//en.wikipedia.org/wiki/Barbara_McClintock) _geneticist and molecular biologist, discovered transposons_
  * [Gregor Mendel](//en.wikipedia.org/wiki/Gregor_Mendel) _discovered the basic rules of heredity_
  * [Ernst Mayr](//en.wikipedia.org/wiki/Ernst_Mayr) _evolutionary biologist and science populariser_
  * [Mark Ridley](//en.wikipedia.org/wiki/Mark_Ridley) _science populariser_
  * [Fred Sanger](//en.wikipedia.org/wiki/Fred_Sanger) _founder of DNA and protein sequencing techniques_
  * [John Maynard Smith](//en.wikipedia.org/wiki/John_Maynard_Smith) _evolutionary biologist and science populariser_
  * [Alfred Russel Wallace](//en.wikipedia.org/wiki/Alfred_Russel_Wallace) _evolutionary biologist_
  * [James Watson](//en.wikipedia.org/wiki/James_Watson) _molecular biologist, discovered structure of DNA molecule_
  * [Edward Wilson](//en.wikipedia.org/wiki/Edward_O._Wilson) _founded "sociobiology"_

This book is intended as a compilation of biographies describing the lives and work of influential biologists.

## External Links

  * [EvoWiki: List of Biologists](http://wiki.cotch.net/index.php/List_of_biologists)

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

# Glossary

  * **[Autotroph](/w/index.php?title=Autotroph&action=edit&redlink=1)**: an organism which can make its own energy
  * **[Cell](/w/index.php?title=Cell&action=edit&redlink=1)**: Fundamental structural unit of all living things
  * **[Ether](/w/index.php?title=Ether&action=edit&redlink=1)**:
  * **[Eukaryote](/w/index.php?title=Eukaryote&action=edit&redlink=1)**: an [organism](/w/index.php?title=Organism&action=edit&redlink=1) with a nucleus
  * **[Exoenzyme](/w/index.php?title=Exoenzyme&action=edit&redlink=1)**: an enzyme used to break down [organic molecules](/w/index.php?title=Organic_molecule&action=edit&redlink=1) outside the body
  * **[Glycerol](/w/index.php?title=Glycerol&action=edit&redlink=1)**:
  * **[Heterotroph](/w/index.php?title=Heterotroph&action=edit&redlink=1)**: an organism which can not make its own energy
  * **[Hydrocarbon](/w/index.php?title=Hydrocarbon&action=edit&redlink=1)**: an organic compound that contains [carbon](/w/index.php?title=Carbon&action=edit&redlink=1) and [hydrogen](/w/index.php?title=Hydrogen&action=edit&redlink=1) only.
  * **[Lipid](/w/index.php?title=Lipid&action=edit&redlink=1)**: [fatty acid](/w/index.php?title=Fatty_acid&action=edit&redlink=1) [esters](/w/index.php?title=Ester&action=edit&redlink=1) which form the basis of cell membranes
  * **[Nucleus](/w/index.php?title=Cell_nucleus&action=edit&redlink=1)**: [Membrane](/w/index.php?title=Membrane&action=edit&redlink=1)-bound [organelle](/w/index.php?title=Organelle&action=edit&redlink=1) which contains the [chromosomes](/w/index.php?title=Chromosome&action=edit&redlink=1)
  * **[Prokaryote](/w/index.php?title=Prokaryote&action=edit&redlink=1)**: an organism with no nucleus
  * **Seed**:
  * **Flower**:
  * **Tracheid**:
  * **Haploid**: A cell with a single set of chromosomes (23 in humans), in humans this is usually in gametes. This is commonly represented by n.
  * **Diploid**: A cell with two sets of chromosomes (46 in humans). This is commonly represented by 2n.
  * **Sporangium**:

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

* * *

The majority of the modules making up this book are based on notes very generously donated by [Paul Doerder, Ph.D.](http://bgesweb.artscipub.csuohio.edu/faculty/doerder.htm) and [Ralph Gibson, Ph.D.](http://bgesweb.artscipub.csuohio.edu/faculty/gibson.htm) both currently of the [Cleveland State University](http://www.csuohio.edu/).

The book was initiated by [Karl Wick](/wiki/User:Karl_Wick), who donated many of his own class notes for other modules, and who is fleshing out the outline format of Dr. Doerder's notes into text.

## Users

[Alsocal](/wiki/User:Alsocal)

[Darren Hess](/wiki/User:Dmhessmdphd) MD/PhD recent grad, enjoys teaching, hopes to help work up the Nervous System Tissue section.

* * *

**[General Biology](/wiki/General_Biology)** | [Getting Started](/wiki/General_Biology/Getting_Started) | [Cells](/wiki/General_Biology/Cells) | [Genetics](/wiki/General_Biology/Genetics) | [Classification](/wiki/General_Biology/Classification_of_Living_Things) | [Evolution](/wiki/General_Biology/Evolution) | [Tissues & Systems](/wiki/General_Biology/Tissues_and_Systems) | [Additional Material](/wiki/General_Biology/Additional_Material)

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=General_Biology/Print_version&oldid=2501994](http://en.wikibooks.org/w/index.php?title=General_Biology/Print_version&oldid=2501994)" 

[Category](/wiki/Special:Categories): 

  * [General Biology](/wiki/Category:General_Biology)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=General+Biology%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=General+Biology%2FPrint+version)

### Namespaces

  * [Book](/wiki/General_Biology/Print_version)
  * [Discussion](/w/index.php?title=Talk:General_Biology/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=General_Biology/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=General_Biology/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=General_Biology/Print_version&action=edit)
  * [View history](/w/index.php?title=General_Biology/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/General_Biology/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/General_Biology/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=General_Biology/Print_version&oldid=2501994)
  * [Page information](/w/index.php?title=General_Biology/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=General_Biology%2FPrint_version&id=2501994)

### In other languages

  * [Bahasa Melayu](//ms.wikibooks.org/wiki/Templat:BioAsas)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=General+Biology%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=General+Biology%2FPrint+version&oldid=2501994&writer=rl)
  * [Printable version](/w/index.php?title=General_Biology/Print_version&printable=yes)

  * This page was last modified on 15 March 2013, at 09:43.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/General_Biology/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
