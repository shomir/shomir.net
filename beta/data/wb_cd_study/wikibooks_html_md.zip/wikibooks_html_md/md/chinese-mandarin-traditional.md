# Chinese (Mandarin)/Print version

From Wikibooks, open books for an open world

< [Chinese (Mandarin)](/wiki/Chinese_\(Mandarin\))

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Chinese_\(Mandarin\)/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Chinese_\(Mandarin\)/Print_version) on _7 May 2012_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Chinese_\(Mandarin\)/Print_version&oldid=2327522&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

+

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Chinese (Mandarin)](/wiki/Chinese_\(Mandarin\))**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Chinese_\(Mandarin\)/Print_version&action=purge&printable=yes) this page.

  


Chinese (Mandarin)

The current, editable version of this book is available in Wikibooks, the open-content textbooks collection, at  
<http://en.wikibooks.org/wiki/Chinese_(Mandarin)>

Permission is granted to copy, distribute, and/or modify this document under the terms of the [Creative Commons Attribution-ShareAlike 3.0 License](/wiki/Wikibooks:Creative_Commons_Attribution-ShareAlike_3.0_Unported_License).

# Table of contents

## Text / 课文

### Introduction / 介绍

    [About Chinese  
中文是什么？](/wiki/Chinese/About_Chinese) ![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    [How to use this textbook  
如何使用这本教科书](/wiki/Chinese/How_To_Use_This_Textbook) ![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    [How to study Chinese  
如何学习中文](/wiki/Chinese/How_To_Study_Chinese) ![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)

## Pronunciation

    [Pinyin Pronunciation Basics](/wiki/Chinese/Pinyin_Pronunciation) ![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    [Pronunciation of Initials](/wiki/Chinese/Pronunciation_of_Initials)
    [Pronunciation of Finals](/wiki/Chinese/Pronunciation_of_Finals)
    [Possible Initial-Final Combinations](/wiki/Chinese/Possible_Initial-Final_Combinations)
    [Using Tones](/wiki/Chinese/Using_Tones)

# Text / 课文

  1. [Hello! - 第一课：你好！](/wiki/Chinese_\(Mandarin\)/Lesson_1) ![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
  2. [Are you busy today? - 第二课：今天你忙不忙?](/wiki/Chinese_\(Mandarin\)/Lesson_2) ![75 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
  3. [An introduction to particles - 第三课：助词](/wiki/Chinese/Lesson_3) ![75 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
  4. [Word order and Verbs - 第四课：词序和动词](/wiki/Chinese_\(Mandarin\)/Lesson_4) ![0% developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  5. [Measure words/Counters - 第五课：量词](/wiki/Chinese_\(Mandarin\)/Lesson_5) ![75 percents developed  as of August 16, 2009](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
  6. [More on interrogatives - 第六课：疑问助词](/wiki/Chinese_\(Mandarin\)/Lesson_6) ![0% developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  7. [What's this? - 第七课：这是什么?](/wiki/Chinese_\(Mandarin\)/Lesson_7) ![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
  8. [Who is she? - 第八课：她是谁?](/wiki/Chinese_\(Mandarin\)/Lesson_8) ![25 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  9. [Where is the railway station? - 第九课：火车站在哪里？](/wiki/Chinese_\(Mandarin\)/Lesson_9) ![0% developed  as of Oct 5, 2008](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  10. [A telephone conversation - 第十课：电话](/wiki/Chinese_\(Mandarin\)/Lesson_10) ![0% developed  as of Dec 30,2009](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  11. [Taiwan - 第十一课：台湾](/wiki/Chinese_\(Mandarin\)/Taiwan) ![0% developed  as of Dec 30,2009](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  12. [Mandarin is so interesting! - 第十二课：华语真好玩](/w/index.php?title=Chinese_\(Mandarin\)/Mandarin_is_so_interesting&action=edit&redlink=1) ![0% developed  as of Dec 30,2009](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  13. [I'm sick - 第十三课：我生病了](/w/index.php?title=Chinese_\(Mandarin\)/I%27m_sick&action=edit&redlink=1) ![0% developed  as of Dec 30,2009](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  14. [Drinking tea - 第十七课：喝茶](/w/index.php?title=Chinese_\(Mandarin\)/Drinking_tea&action=edit&redlink=1) ![0% developed  as of Dec 30,2009](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  15. [China - 第十八课：中国](/w/index.php?title=Chinese_\(Mandarin\)/China&action=edit&redlink=1) ![0% developed  as of Sep 12，2010](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)

## Introduction / 介绍

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# About Chinese

![Flag of the PRC](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/100px-Flag_of_the_People%27s_Republic_of_China.svg.png)
![Flag of Singapore](//upload.wikimedia.org/wikipedia/commons/thumb/4/48/Flag_of_Singapore.svg/100px-Flag_of_Singapore.svg.png)

中华人民共和国 (中国)
新加坡共和国 (新加坡)

_People's Republic of China  
(China)_
_Republic of Singapore  
(Singapore)_

![Map-Chinese World.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Map-Chinese_World.png/320px-Map-Chinese_World.png)

The Chinese cultural sphere of influence

The **Chinese language** (汉语/漢語, 华语/華語 or 中文; [Pinyin](/wiki/Pinyin): [Hanyu](/w/index.php?title=Hanyu&action=edit&redlink=1), [Huayu](/w/index.php?title=Huayu&action=edit&redlink=1), [Zhongwen](/w/index.php?title=Zhongwen&action=edit&redlink=1)) is a member of the Sino-Tibetan family of languages. About one-fifth of the world speaks some form of Chinese as its native language, making it the most common natively-spoken language in the world.

There is great internal variety within Chinese, and spoken Chinese languages such as Standard Mandarin (Putonghua), Shanghainese (Wu), and Cantonese, which are not mutually intelligible. Nevertheless, there is a single standardized form of Chinese known as Standard Mandarin (国语), which is based on the dialect of Beijing, which is in turn its own Mandarin dialect, among a large and diverse group of Chinese dialects spoken in Northern and Southwestern China. Standard Mandarin is the official language of Mainland China and Chinese Taiwan, one of four official languages of Singapore, and one of six official languages of the United Nations. Standard Mandarin also corresponds to the modern standard written Chinese language used by people speaking all forms of Chinese from all corners of China, including Mandarin, Wu, Cantonese, Hakka, Min-nan, and so forth. This textbook will teach Standard Mandarin, both spoken and written.

Chinese grammar is in many ways simpler than European languages (for example, you will see no tenses, plurals, or subject-verb agreement), but there are also plenty of pitfalls that will trip up the unsuspecting beginner (for example, you will encounter tones, measure words, and discourse particles, which do not feature as strongly in European languages.) In addition, the complexity of the writing system often daunts newcomers, as Chinese is one of the few languages in the world that does not use an alphabet or a syllabary; instead, thousands of characters are used, each representing a word or a part of a word. However, most complex Chinese characters are composed of only a few hundred simpler characters and many contain phonetic hints. There is a common Western misconception of Chinese writing as having thousands of distinct and idiomatic symbols each representing a single word, however, Chinese writing is surprisingly mnemonic, granted it is not as simple as the writing of Romance languages. The government of China has developed a system of writing Standard Mandarin pronunciation in the Roman alphabet, known as _Hanyu Pinyin_, or simply, _pinyin_ (汉语拼音/漢語拼音, "spelling according to sounds"). Hanyu Pinyin is used to write out Chinese words phonetically in an effort to help learners of Chinese with their pronunciation. This wikibook will teach you Hanyu Pinyin first, before any actual sentences. All examples and new vocabulary will always be given together with Hanyu Pinyin.

There are two character sets: Simplified Chinese characters (简体字/簡體字, [Pinyin](/wiki/Pinyin): [Jiǎntǐzì](/w/index.php?title=Ji%C7%8Ent%C7%90z%C3%AC&action=edit&redlink=1)) and Traditional Chinese characters (繁体字/繁體字, [Pinyin](/wiki/Pinyin): [Fǎntǐzi](/w/index.php?title=F%C7%8Ent%C7%90zi&action=edit&redlink=1)). Traditional characters trace their lineage through thousands of years of Chinese history, and continue to be used in Hong Kong, Macau, Taiwan, and among many overseas Chinese. Simplified Chinese characters were the result of reforms carried out in Mainland China to increase literacy rates and is now used in Singapore as well. The two systems share many of the same characters or with systematic, predictable reductions in stroke; however, some changes are not as formulaic. As a result, most native Chinese speakers are able to write in only one of the two systems, though they can usually read both. You are recommended to do the same. It is considered easier for people who learn Traditional to read both sets than people who learn Simplified only, but Simplified characters are less intimidating for beginners. In this wikibook, all examples and vocabulary are given in both systems, and you are encouraged to choose one system and stick with it throughout.

Chinese characters have also been used in the past by other neighbouring Asian countries, and are still being used by some of them today. Some older Koreans still know how to read and write Chinese characters, but although the members of younger generations are taught Chinese characters or _hanja_, they are rarely used and unnecessary for literacy in Korean, with the native alphabet, _hangul_. Chinese characters are occasionally used for abbreviations, to clarify technical vocabulary (as Chinese serves roughly the same role in Korean that Latin serves in English), and to write family and many personal names. The Japanese still preserve many Chinese characters or _kanji_ today and use them along with two syllabaries to write the Japanese language.

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

## Expectations

This textbook will assume that you have no prior knowledge of Chinese, but are willing to take Chinese as a serious subject of study. Each lesson contains a combination of new vocabulary and new grammar in a gradual progression, building on previous lessons.

Each lesson should be appropriate for a week's worth of daily classes, so don't feel overwhelmed by the amount of material per lesson. Learning to write new characters will probably be your limiting factor, so split up the memorization of a lesson's characters over two or three days and use class time mostly for work on grammar and speaking skills.

  


## Lesson Sections

Each lesson consists of five parts:

  1. **Dialogue**. Here you will see a dialogue carried out by two or more people. All texts are given in 4 versions: Simplified Chinese, Traditional Chinese, Hanyu Pinyin, and an English translation.
  2. **Grammar**. This section breaks down all of the new sentence structures introduced in the dialogue and shows example sentences to reinforce them.
  3. **Vocabulary**. New vocabulary for the lesson, with translation and pronunciation. Every newly introduced character will be linked to an image or animation showing its stroke order.
  4. **Examples**. A page of sentences and phrases giving more examples based on the lesson material.
  5. **Exercises**. Questions and activities to test comprehension of the material. May be used as homework or as review material for lesson exams.

  


## Wikibook Navigation

All the lessons and appendices of this Wikibook are arranged as subpages of the Chinese main page (the Table of Contents). Navigating between lessons is done by clicking the appropriate link in the green mini-Table of Contents box found at the top and bottom of every page. To navigate to less-commonly-accessed pages from a subpage, you must first return to the Chinese main page by clicking on "< Chinese" which appears in the top left corner of all subpages.

Additionally, lesson subpages have subpages branching off of them which contain supporting material for the lesson such as examples, exercises, and animations demonstrating the stroke orders of new characters. You'll also find "Traditional" listed as a subpage, which is a toggle button for accessing the traditional version of the page. Click on it, and "Simplified" replaces it, meaning you can easily switch back and forth between the simplified and traditional character versions of this text.

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

  


## Speaking and Pronunciation

  * **Learn pinyin**. Not only is it used throughout this book to explain proper pronunciation, it is needed to look up words in dictionaries and to type in Chinese.
  * **Pay attention to the tones.** Since there are so few syllables in Chinese, there are many homonyms, making attention to tones very important. Learning to write the pinyin with correct tones at the same time as you learn the characters will improve your pronunciation and your listening comprehension.
  * **Read the text aloud.** Speaking (and hearing yourself speak) will help reinforce the text in your memory. Exaggerating the tones can help you remember them. In Chinese, character (something that when writing takes a space unit), word (which may include some characters or a single character), and sentence may be different from English. When speaking Chinese, the pronunciation of each character should be a single unit.
  * **Find a language partner.** There may be a Chinese language club in a nearby city or university. There are also free websites on the Internet that can help you set up a language exchange using [Skype](http://www.skype.com) or other VoIP programs. Two examples are [The Mixxer](http://www.language-exchanges.org) and [E-Tandem](http://www.slf.ruhr-uni-bochum.de/etandem/etindex-en.html).
  * **Use a Text To Speech (TTS) service.** In other words, have a computer read the text for you. Free examples include [Google Translate](http://translate.google.com) and [imtranslator.net](http://imtranslator.net/translate-and-speak/). Google Translate can not only read the text (the volume icon, not available for large texts) but also give you the pinyin (the A with the umlaut), and, of course, translate.
  * **Consume Chinese media.** Immersing yourself in Chinese after learning the basics will make learning easier. To learn pronunciation, make the voices of native speakers your constant companions, and after finishing this book, continue to immerse yourself—you will have learned enough to take on Chinese "in the wild". A wide variety of multimedia options exist for exposing your ears to native Chinese speakers. Two of the best sites for easy listening materials are [Popup Chinese](http://popupchinese.com) and [ChineseClass101.com](http://chineseclass101.com). Advanced learners can listen to broadcasts of [Xinhua](http://www.xinhua.org/), China's official news network, or visit [Youku](http://www.youku.com), a Chinese incarnation of YouTube (YouTube is blocked in China, and Facebook as well, for that matter). Download as much audio as you can from these sites to your MP3 player and start listening. You can listen to Chinese whenever you're in the car, commuting, or doing mechanical tasks. Note that, since Internet Explorer 6 is still a popular browser in China, Chinese websites may seem a bit quirky, and video streaming services may not work at all on modern browsers.

## Reading and Writing

  * **Practice writing—a lot.** When you study, write a character at least ten times, and more if you have trouble remembering it. You can find special grid paper for writing practice with Chinese characters on the Internet; for example, PDF sheets are available on [UVM's web site](http://www.uvm.edu/~chinese/characte.htm), and a practice sheet generator is available at [www.chinesetools.eu](http://www.chinesetools.eu/tools/chinese-grid/) (or [original site](http://www.chine-informations.com/chinois/outils/generateur-grille/), French). The output is set up as a grid, so that a typical printer can print 11 characters with 8 boxes each per page in portrait mode, giving each character one row, or 5 characters with 17 boxes each, and so on. In landscape mode, a printer can print 8 characters with 11 boxes each per page, or 4 characters with 23 boxes each giving each character two lines. Remember to quiz yourself periodically to test your memory and to find which characters you need to practice more. As you write, think of the sound and meaning of the character, or say it out loud. Check out the [East Asian Calligraphy](/wiki/East_Asian_Calligraphy) wikibook for more help with Chinese writing. Learn the correct stroke order initially and write carefully, looking at the printed character each time before copying. Actually writing is important to establish a 'motor memory' of each character, which will allow your writing to flow more easily.
  * **Use a flashcard program.** Many people use flash cards memorize information, but there's often much time wasted reviewing what they already know well, or in relearning what they forgot. The free programs [Anki](http://www.ichi2.net/anki/) and [Mnemosyne](http://mnemosyne-proj.org/index.php), can optimize your review schedule using their algorithms. They can also use audio for pronunciation help and 3-sided cards to study reading, writing, and translation separately. You can download [free cardsets](http://mnemosyne-proj.org/taxonomy/term/7), [export your own](http://shengci.wojas.nl/mnemosyne), or write them yourself to fully customize your character selection.

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/ae/Radical053.png/80px-Radical053.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

A radical highlighted in 3 characters

  * **Look for radicals.** [Radicals](//en.wikipedia.org/wiki/Radical_\(Chinese_character\)) are components of Chinese characters that you will see repeated over and over again. Learning the meaning of radicals will help you to see the connections between similar categories of words. Many characters are comprised of radical-phonetic pairings, where the radical is the "root" that hints at the meaning of the word, while another part of the character hints at the sound of the word. Learning to spot radicals is also useful since they can be used when looking up words when you don't know the pinyin in Chinese dictionaries.
  * **Buy a dictionary.** They're useful for looking up new words or just browsing. Beginner's dictionaries have larger fonts, usage examples, and Pinyin pronunciation, all of which are sometimes missing in comprehensive dictionaries. [CC-CEDICT](http://cc-cedict.org) is a thorough Chinese-English dictionary available under Creative Commons. [KTdict C-E](http://itunes.apple.com/us/app/ktdict-c-e-chinese-english/id291179703) is a free iOS app that uses CEDICT. A good physical dictionary that provides many example sentences and phrases is _[The Starter Oxford Chinese Dictionary](http://www.amazon.com/gp/product/0198602588/ref=pd_sim_b_2/002-3287198-3112035?%5Fencoding=UTF8&v=glance&n=283155)_ (Simplified characters only). A good online dictionary would be [nciku](http://www.nciku.com/). It is searchable by pinyin, characters, and sketches, via a drawing panel. It not only contains definitions, also shows the stroke order of a character, and gives examples of its use.

### Suggested Reading Materials

    

  * Children's story books (the characters are easier, many include pinyin or zhuyin for difficult characters)
  * [Xinhua](http://www.xinhua.org) is the official Chinese news network, but again, it is mostly for advanced learners.
  * [Pinyin/Pinyin-English News Summary](/wiki/Pinyin/Pinyin-English_News_Summary)

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Pronunciation

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

  


# Pinyin Pronunciation

This lesson shows the pronunciation of pinyin, the standard Romanization system used for Mandarin Chinese and the one that will be used throughout the textbook. While most of the letters are the same or very close to the English usage, there are some important differences.

## Pronunciation Basics

Mandarin Chinese may sound strange, but is actually relatively easy for English speakers to pick up—much easier than it is for Mandarin-speakers to learn English. A large part of the reason is that Chinese has a very limited sound inventory, meaning there are not many sounds in the language, and hardly any new ones if you already know English. On the other hand, that means Chinese-speakers trying to grasp English must learn to produce dozens of entirely new sounds—remember that as you proceed through these first lessons on pronunciation!

One very different aspect of Chinese is its use of [tones](//en.wikipedia.org/wiki/Pinyin#Tones). Because of its limited sound inventory, the pitch, also known as the tone or inflection, is used to help differentiate between words. Words with different tones usually have entirely different meanings, but may have the same base with different radicals. While some dialects of Chinese have up to nine tones, Mandarin is comparatively easy with only four. It's often difficult for beginners to distinguish the tone of a word, especially when not sure of the context, people who do not speak a [tonal language](//en.wikipedia.org/wiki/Tone_\(linguistics\)) are not used to listening for pitch in conversation. Speaking Chinese is like singing, but even if you have perfect pitch, it may be hard to follow or reproduce what seems like a roller coaster ride of tonal transitions. Don't worry though, you'll improve by listening and practicing. These lessons will describe how to understand and reproduce all the syllables and tones of Mandarin.

### If you know another Romanization system or the IPA

If you are familiar with Zhuyin (bopomofo), Tongyong Pinyin, or the Wade-Giles system of Romanization, Wikipedia has an [equivalency chart](//en.wikipedia.org/wiki/Zhuyin#Zhuyin_vs._Tongyong_Pinyin_.26_Hanyu_Pinyin) comparing the different systems. Learn to use [Hanyu Pinyin](//en.wikipedia.org/wiki/Hanyu_Pinyin)—the more common Romanization system for Chinese, which will be used for this book.

The [IPA](//en.wikipedia.org/wiki/International_Phonetic_Alphabet), or International Phonetic Alphabet, is a standard set of symbols that can be used to write _any_ sound from _any_ human language. The sounds of pinyin are listed below in IPA.

## The Mandarin syllable

There are three parts to all syllables in Mandarin; the _[initial](//en.wikipedia.org/wiki/initial)_, the _[final](//en.wikipedia.org/wiki/final)_, and the _tone_. In pinyin, the tone, initial, and final are represented as follows:

### Tone

The **tone** is represented by a tone mark placed on top of the syllable. There are exactly four tone marks: ˉ, ˊ, ˇ, and ˋ. The two dots on ü (like a German umlaut) do not have to do with the tone, so if you see ǖ, ǘ, ǚ, or ǜ, the symbol _above_ the dots represents the tone.

### Initial

The **initial** is...

  * in the beginning of a syllable
  * a consonant (excluding _y_, or _w_)
  * usually one letter, except for _zh_, _ch_, _sh_

### Final

The **final** is made up of the letter(s) after a syllable's initial, not including the tone mark. A final...

  * begins with a vowel
  * can be made of 1-4 characters
  * ends with a vowel, _n_, _ng_, or _r_

### Exceptions to initial-final combinations in syllables

Some syllables have no initial or no final. In Pinyin, this is shown as follows:

  * **For syllables with no final:**
    * an unpronounced _i_ is added to the end of the syllable
    * Occurs only with the following initials:_zh_, _ch_, _sh_, _r_, _z_, _c_, _s_
  * **For syllables with no initial:**
    * if the final begins with an _i_, it is replaced with a _y_
    * if the final begins with an _u_, it is replaced with a _w_
    * if the final begins with an _ü_, it is replaced with _yu_
    * **Exceptions to the above:**
      * _i_ alone is replaced by _yi_
      * _iu_ is replaced by _you_
      * _in_ is replaced by _yin_
      * _ing_ is replaced by _ying_
      * _u_ alone is replaced by _wu_
      * _ui_ is replaced by _wei_
      * _un_ is replaced by _wen_
      * _ueng_ is replaced by _weng_

**One other exception:**

  * when combined with initials _j_, _q_, _x_; any _ü_ in a final is changed to _u_.

Please note that the pronunciation of these syllables is not according to the English pronunciation of the letters. The next few pages give examples of how initials and finals are pronounced, put together, and how to use tones.

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

* * *

Remember, since hearing is very important for learning to speak, audio samples and the voices of native speakers should be your constant companions.

## Pronunciation of initials

**Pinyin** **[IPA](//en.wikipedia.org/wiki/International_Phonetic_Alphabet)** **Explanation** **Examples**

_b_
[p]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/3/35/Voiceless_bilabial_stop.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

unaspirated **p**, as in s**p**it
帮 bāng, to help  
包 bāo, (Chinese) bun

_p_
[pʰ]
as in English
炮 pào, gun; cannon

_m_
[m]
as in English
马 mǎ, horse

_f_
[f]
as in English
风 fēng, wind

_d_
[t]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/e/e0/Voiceless_alveolar_stop.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

unaspirated **t**, as in s**t**and
大 dà, big  
刀 dāo, knife

_t_
[tʰ]
as in English
头 tóu, head

_n_
[n]
as in English
男 nán, male

_l_
[l]
as in English
老 lǎo, old

_g_
[k]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/e/e3/Voiceless_velar_plosive.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

unaspirated **k**, as in s**k**ill
格 gé, grid  
歌 gē, song

_k_
[kʰ]
as in English
看 kàn, to see

_h_
[x]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/0/0f/Voiceless_velar_fricative.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

like the English **h** if followed by "a"; otherwise it is pronounced more roughly (not unlike the [Scots](//en.wikipedia.org/wiki/Scots_language) **ch**)
好 hǎo, good  
喝 hē, to drink  
画 huà, to draw

_j_
[tɕ]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/c/c4/Voiceless_alveolo-palatal_affricate.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

like **q**, but unaspirated. (To get this sound, first take the sound halfway between **j**oke and **ch**eck, and then slowly pass it backwards along the tongue until it is entirely clear of the tongue tip.) While this exact sound is not used in English, the closest match is the **j** in a**j**ar, not the **s** in A**s**ia; this means that "Beijing" is pronounced like "bay-jing", **not** like "beige-ing".
叫 jiào, to call  
家 jiā, home, family  
近 jìn, close  
尖 jiān, sharp

_q_
[tɕʰ]
like j above, but with strong aspiration. Similar to **ch**urch; pass it backwards along the tongue until it is free of the tongue tip
气 qì, air, gas  
桥 qiáo, bridge

_x_
[ɕ]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/0/0b/Voiceless_alveolo-palatal_sibilant.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

like **sh**, but take the sound and pass it backwards along the tongue until it is clear of the tongue tip; very similar to the final sound in German i**ch**, Portuguese en**x**ada, lu**x**o, **x**ícara, pu**x**a, and to **h**uge or **H**ugh in some English dialects
小 xiǎo, little, small  
心 xīn, heart  
想 xiǎng, to think; to want

_zh_
[tʂ]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/e/e9/Voiceless_retroflex_affricate.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

**ch** with no aspiration (take the sound halfway between **j**oke and **ch**urch and curl it upwards); very similar to mer**g**er in American English, but not voiced
长 zhǎng, to grow  
中 zhōng, center, middle  
重 zhòng, heavy

_ch_
[tʂʰ]
Like zh above, but with strong aspiration. Similar to **ch**in, but with the tongue curled upwards; very similar to nur**tu**re in American English, but strongly aspirated
吃 chī, to eat  
茶 chá, tea

_sh_
[ʂ]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/b/b1/Voiceless_retroflex_sibilant.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

as in **sh**inbone, but with the tongue curled upwards; very similar to under**sh**irt in American English
沙 shā, sand  
手 shǒu, hand  
上 shàng, up, on

_r_
[ɻ]

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/d/d2/Retroflex_approximant.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

similar to the English **r** in **r**ank, but with the lips spread and with the tongue curled upwards
日 rì, sun  
热 rè, hot

_z_
[ts]
unaspirated **c** (halfway between be**ds** and be**ts**), (more common example is su**ds**)
紫 zǐ, purple

_c_
[tsʰ]
like **ts**, aspirated (more common example is ca**ts**)
草 cǎo, grass  
次 cì, time(s)

_s_
[s]
as in **s**un
送 sòng, to send

_y_
[j], [ɥ]
as in English. If followed by a u, pronounce it with rounded lips
月 yuè, moon  
音 yīn, tone

_w_
[w]
as in English
外 wài, outside

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

## Pronunciation of finals

**Pinyin** **[IPA](//en.wikipedia.org/wiki/International_Phonetic_Alphabet)** **Final-only form** **Explanation**

_a_
[a]
**a**
if ending a syllable, then as in "f**a**ther"

_o_
[ɔ]
(n/a)
plain continental '**or'**. Only used in certain interjections.

_e_
[ɤ], [ə]
**e**
when occurring at the end of a syllable and not in the combinations of ie, üe, ue, then a backward, unrounded vowel, which can be formed by first pronouncing a plain continental "o" ([AuE](//en.wikipedia.org/wiki/Australian_English) and [NZE](//en.wikipedia.org/wiki/New_Zealand_English) l**aw**) and then spreading the lips without changing the position of the tongue. That same sound is also similar to English "d**uh**", but not as open. Many unstressed syllables in Chinese use the [schwa](//en.wikipedia.org/wiki/schwa) (ide**a**), and this is also written as _e_.

_ê_
[ɛ]
(n/a)
as in "b**e**t". Only used in certain interjections.

_ai_
[aɪ̯]
**ai**
like English "eye", but a bit lighter

_ei_
[eɪ̯]
**ei**
as in "h**ey**"

_ao_
[ɑʊ̯]
**ao**
approximately as in "c**ow**"; the _a_ is much more audible than the _o_

_ou_
[oʊ̯]
**ou**
as in "s**o**", "d**ough**"

_an_
[an]
**an**
starts with plain continental "a" ([AuE](//en.wikipedia.org/wiki/Australian_English) and [NZE](//en.wikipedia.org/wiki/New_Zealand_English) b**u**d) and ends with "n"; as in "st**un**", "f**un**"

_en_
[ən]
**en**
as in "tak**en**"

_ang_
[ɑŋ]
**ang**
as in German _Angst_, including the English loan word _angst_ (starts with the vowel sound in f**a**ther and ends in the [velar nasal](//en.wikipedia.org/wiki/velar_nasal); as in "fl**ung**", "d**ung**", "y**oung**";like s**ong** in American English)

_eng_
[əŋ]
**eng**
like _e_ in _en_ above but with ng added to it at the back

_er_
[ɑɻ]
**er**
like _ar_ (exists only on own, or as last part of final in combination with others- see bottom of list)

_i_
[i]
**yi**
like English "ee", except when preceded by "c", "ch", "r", "s", "sh", "z" or "zh"; in these cases it should be pronounced as a natural extension of those sounds in the same position, but slightly more open to allow for a clear-sounding vowel to pass through

_ia_
[i̯a]
**ya**
as **i** \+ **a**; like English "**ya**rd" or the name "**ia**go"

_io_
[iou]
(n/a)
as **i** \+ **o**; like English slang "**yo**"; (only exists as a final-only interjection)

_ie_
[i̯ɛ]
**ye**
as **i** \+ **ê**; but is very short; _e_ (pronounced like _ê_) is pronounced longer and carries the main stress (similar to the initial sound **ye** in **yet**)

_iai_
[iɑi]
**yai**
as **i** \+ **ai**; like "**yi**" in "**yikes**"; (only exists as final-only form "**yai**")

_iao_
[i̯ɑʊ̯]
**yao**
as **i** \+ **ao**

_iu_
[i̯oʊ̯]
**you**
as **i** \+ **ou**

_ian_
[i̯ɛn]
**yan**
as **i** \+ **an**; like English **yen**

_in_
[in]
**yin**
as **i** \+ **en**; as in the English word "in";

_iang_
[i̯ɑŋ]
**yang**
as **i** \+ **ang**

_ing_
[iŋ]
**ying**
as **i** \+ **eng**

_u_
[u]
**wu**
like English "oo", except in xu and yu, where it is pronounced as u

_ua_
[u̯a]
**wa**
as **u** \+ **a**

_uo_, _o_
[u̯ɔ]
**wo**
as **u** \+ **o** (as **o** after initials b, p, m and f); the _o_ is pronounced shorter and lighter than in the _o_ final

_uai_
[u̯aɪ̯]
**wai**
as **u** \+ **ai**

_ui_
[u̯eɪ̯]
**wei**
as **u** \+ **ei**; here, the _i_ is pronounced like _ei_

_uan_
[u̯an]
**wan**
as **u** \+ **an**

_un_
[u̯ən]
**wen**
as **u** \+ **en**; like the _on_ in the English _won_

_uang_
[u̯ɑŋ]
**wang**
as **u** \+ **ang**; like the _ang_ in English _angst_ or _anger_

_ong_
[ʊŋ], [u̯əŋ]
**weng**
as **u** \+ **eng**; starts with the vowel sound in b**oo**k and ends with the velar nasal sound in si**ng**

_ü_
[y]
**yu**
as in German "**ü**ben" or French "l**u**ne" (To get this sound, say "ee" with rounded lips)

_üe_
[y̯œ]
**yue**
as **ü** \+ **ê**; the _ü_ is short and light

_üan_
[y̯ɛn]
**yuan**
as **ü** \+ **an**;

_ün_
[yn]
**yun**
as **ü** \+ **en**;

_iong_
[i̯ʊŋ]
**yong**
as **ü** \+ **eng**;

Finals that are a combination of finals above + **er** final

**Pinyin** **[IPA](//en.wikipedia.org/wiki/International_Phonetic_Alphabet)** **Explanation**

e'r
[ɤɻ]
as **e** \+ **er** (not to be confused with _er_ final on its own- this form only exists with an initial character before it)

air, anr
[ɑɻ]
as **ai** \+ **er**, **an** \+ **er**

aor
[ɑʊ̯ɻ]
as **ao** \+ **er**

our
[oʊ̯ɻ]
as **ou** \+ **er**

angr
[ɑŋɻ]
as **ang** \+ **er**

iar, ianr
[i̯ɑɻ]
as **ia** \+ **er**, **ian** \+ **er**

inr, ir
[i̯əɻ]
as **in** \+ **er**, **i** \+ **er**

ingr
[i̯əŋɻ]
as **ing** \+ **er**

ur
[uɻ]
as **u** \+ **er**

uor
[u̯ɔɻ]
as **uo** \+ **er**

uir
[u̯əɻ]
as **ui** \+ **er**

ongr
[ʊŋɻ]
as **ong** \+ **er**

ür
[y̯əɻ]
as **ü** \+ **er**

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

## Using Tones

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/58/Pinyin_Tone_Chart.svg/150px-Pinyin_Tone_Chart.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Relative pitch changes of the four tones

Every syllable in Chinese has a clearly defined pitch of voice associated with it to distinguish characters with the same sound from each other. Unfortunately, there is no indication of the tone given when reading a character, so the tones for words must be individually memorized. To help with this, pinyin uses four easily-remembered diacritical marks to tell you what the tones of words are. The diagram to the right shows the pitch changes of the four tones on a five-bar scale going from lowest (1), to highest (5), while the five tone marks are:

  1. **First tone (阴平)( ˉ )**, high level.
  2. **Second tone (阳平)(ˊ)**, middle rising.
  3. **Third tone (上声)( ˇ )**, low dipping.
  4. **Fourth tone (去声)(ˋ)**, high falling.
  5. **Tone of unstressed syllable (轻声)(without any marks)**, low level.

  
Tone marks are always placed over vowels, never consonants. If there is more than one vowel in the syllable, the mark placement is determined by three simple rules.

  1. If there is an a or an e, the tone goes on the a or the e. No pinyin syllable contains both an a and an e.
  2. In the ou combination, the o takes the tone mark.
  3. In all other cases, the final vowel gets the tone mark.

### Pronouncing the tones

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Mandarin_tones_in_musical_notation.svg/400px-Mandarin_tones_in_musical_notation.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Each bar of this musical staff represents the relative pitch changes when saying tones 1, 2, 3 and 4

Say the first tone as if you were singing a high note. The second tone is pronounced like a question in English, with your pitch rising at the end of the syllable. Third tones are low and extended, noticeably longer than the other tones because of the dip. The fourth tone is said abruptly and forcefully, like a curt command in English. The neutral tone's pitch depends on the tone that precedes it. It is described more fully below, but in general, they are pronounced quickly and softly. The classic example used to show the difference tones make is:

[妈](//en.wiktionary.org/wiki/%E5%A6%88)(mā) [麻](//en.wiktionary.org/wiki/%E9%BA%BB)(má) [马](//en.wiktionary.org/wiki/%E9%A9%AC)(mǎ) [骂](//en.wiktionary.org/wiki/%E9%AA%82)(mà) [吗](//en.wiktionary.org/wiki/%E5%90%97)(·ma)  
  
(Being "mother", "hemp", "horse", "scold" and a question particle, respectively.)

[mā má mǎ mà](/wiki/File:Zh-pinyin_tones_with_ma.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/6/64/Zh-pinyin_tones_with_ma.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

A sound sample of the four tones

* * *

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Half-third_Pinyin_Tone_Chart.svg/150px-Half-third_Pinyin_Tone_Chart.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

The shape of the 3rd tone when before 1st, 2nd and 4th tones

In many cases, several characters can have exactly the same syllable and tone. For example, along with 马, the characters 码 and 蚂 are also pronounced exactly the same (mǎ). 马 can be used alone to mean the animal "horse." It can also be combined with other characters for new meanings. 马上mǎshàng-immediately; 马球mǎqiú-polo; 马路mǎlù-street; etc. Other characters with the same pronunciation will be used differently as well. 数码相机shùmǎ xiàngjī-digital camera; 蚂蚁mǎyǐ-ant; etc. Since these characters alone sound exactly the same in conversation, the only way to distinguish them is through context.

### Tone changes

The third tone, with its dip-and-rebound, is hard to fit into a continuous sentence. This is why the third-tone _changes_ depending on its environment. There are two rules:

  1. If a third tone comes _before another third tone_, then it is pronounced as a second tone.
  2. If a third tone comes _before any other tone_, then it only dips, and doesn't rebound and is called a half-third tone (see image).

Because of these broad rules, _the majority_ of third tones you encounter will be spoken as second tones or half-third tones. Be mindful of this because the written tone marks remain unchanged despite the differences in actual pronunciation.

### Neutral Tones

Some syllables don't have a tone and carry no tone mark. They are not stressed, and they take their tone from the syllable before them:

  1. If it follows a first- or second-tone syllable, then the toneless syllable is mid-range.
  2. If it follows a third-tone syllable, then the toneless syllable is high, as if the dip-and-rebound of the third-tone continues right into it.
  3. If it follows a fourth-tone syllable, then the toneless syllable is low, as if the fall of the fourth-tone continues right into it.

## Test and Review

[Mandarin One: Lesson One](//en.wikiversity.org/wiki/Mandarin/Mandarin_One/Lesson_One)

Congratulations! You have completed the pronunciation lessons. Continue to [Lesson 1!](/wiki/Chinese/Lesson_1)

  


* * *

[About Chinese](/wiki/Chinese_\(Mandarin\)/About_Chinese)  —  [How To Use This Textbook](/wiki/Chinese_\(Mandarin\)/How_To_Use_This_Textbook)  —  [How To Study Chinese](/wiki/Chinese_\(Mandarin\)/How_To_Study_Chinese)  —  [Writing in Chinese](/wiki/Chinese_\(Mandarin\)/Writing_in_Chinese)  —  [Pinyin Basics](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation)  —  [Initials](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Initials)  —  [Finals](/wiki/Chinese_\(Mandarin\)/Pronunciation_of_Finals)  —  [Tones](/wiki/Chinese_\(Mandarin\)/Using_Tones)

* * *

  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lessons / 课程

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

## Contents

  * 1 Table of contents
    * 1.1 Text / 课文
      * 1.1.1 Introduction / 介绍
    * 1.2 Pronunciation
  * 2 Text / 课文
    * 2.1 Introduction / 介绍
  * 3 About Chinese
    * 3.1 Expectations
    * 3.2 Lesson Sections
    * 3.3 Wikibook Navigation
    * 3.4 Speaking and Pronunciation
    * 3.5 Reading and Writing
      * 3.5.1 Suggested Reading Materials
  * 4 Pronunciation
  * 5 Pinyin Pronunciation
    * 5.1 Pronunciation Basics
      * 5.1.1 If you know another Romanization system or the IPA
    * 5.2 The Mandarin syllable
      * 5.2.1 Tone
      * 5.2.2 Initial
      * 5.2.3 Final
      * 5.2.4 Exceptions to initial-final combinations in syllables
    * 5.3 Pronunciation of initials
    * 5.4 Pronunciation of finals
    * 5.5 Using Tones
      * 5.5.1 Pronouncing the tones
      * 5.5.2 Tone changes
      * 5.5.3 Neutral Tones
    * 5.6 Test and Review
  * 6 Lessons / 课程
  * 7 Lesson 1: 你好！
    * 7.1 Dialogues
      * 7.1.1 Dialogue 1
      * 7.1.2 Dialogue 2
    * 7.2 Vocabulary
      * 7.2.1 Proper Nouns
    * 7.3 Grammar
      * 7.3.1 Basic Sentences
      * 7.3.2 Sentences using shì [是]
      * 7.3.3 Articles
      * 7.3.4 The question particle 吗  ‹ma›
      * 7.3.5 The question particle 呢  ‹ne›
      * 7.3.6 Question words
  * 8 Lesson 2: 今天你忙不忙？
    * 8.1 Dialogues
    * 8.2 Vocabulary
    * 8.3 Grammar
      * 8.3.1 The adverb Hěn [很]
      * 8.3.2 Le [了] as emphasizer
      * 8.3.3 Affirmative-negative questions
      * 8.3.4 Sentences using yǒu [有]
  * 9 Lesson 3: 助詞
    * 9.1 The De {的} particle as possessive
    * 9.2 The Le {了} / Liăo {了} particle
    * 9.3 The Zhe [着] particle showing continuation
    * 9.4 The Zháo [着] particle indicating accomplishment
    * 9.5 The De [得] particle indicating degree
    * 9.6 Vocabulary
  * 10 Lesson 4: Word order and Verbs
    * 10.1 Basic Word Order
      * 10.1.1 Subject-Verb-Object
      * 10.1.2 Topic-Comment
    * 10.2 Comparisons Using bǐ [比]
    * 10.3 Notes
  * 11 Lesson 5: Measure words
    * 11.1 Measure Words/量词(liàngcí)
      * 11.1.1 Some Common Measure Words
  * 12 Lesson 6: What do you want to buy? 你想要買什麼?
    * 12.1 Vocabulary
  * 13 Lesson 7: 这是什么? What's this?
    * 13.1 Text 1
    * 13.2 Text 2
    * 13.3 Vocabulary
      * 13.3.1 Stroke orders
    * 13.4 Grammar
      * 13.4.1 Chinese Names
      * 13.4.2 这(/那)是什么？
      * 13.4.3 A　是　B
      * 13.4.4 A　不是　B
      * 13.4.5 吗
      * 13.4.6 是/不
      * 13.4.7 的
    * 13.5 Exercise
    * 13.6 Further reading
    * 13.7 Useful phrases
    * 13.8 Translation for the text
  * 14 Lesson 8
  * 15 她是谁？
    * 15.1 Dialogues
      * 15.1.1 Dialogue 1
      * 15.1.2 Dialogue 2
    * 15.2 Vocabulary
    * 15.3 Grammar
    * 15.4 Translation of the text
  * 16 Lesson 9: 請問火車站在哪裡？
    * 16.1 Dialogues
      * 16.1.1 Dialogue 1
      * 16.1.2 Dialogue 2
      * 16.1.3 Vocabulary
  * 17 Taiwan - 第十一课：台湾
    * 17.1 Traditional Characters
    * 17.2 Simplified Characters
    * 17.3 English
  * 18 Vocabulary
  * 19 Grammar
    * 19.1 Appendices / 附录
    * 19.2 Chinese languages
      * 19.2.1 Chinese, Cantonese (Sinitic)
      * 19.2.2 Chinese, Mandarin (Sinitic)
      * 19.2.3 Chinese, Shanghainese (Sinitic)
      * 19.2.4 Chinese, Min Nan / Taiwanese (Sinitic)
    * 19.3 Everyday Phrases
    * 19.4 Greetings
    * 19.5 Yes and No
    * 19.6 Please and Thank You
    * 19.7 Getting Attention
    * 19.8 Apology
    * 19.9 Farewells
    * 19.10 Praise
    * 19.11 Toast
    * 19.12 Finding the Bathroom
    * 19.13 A
    * 19.14 B
    * 19.15 C
    * 19.16 D
    * 19.17 E
    * 19.18 F
    * 19.19 G
    * 19.20 H
    * 19.21 I
    * 19.22 J
    * 19.23 K
    * 19.24 L
    * 19.25 M
    * 19.26 N
    * 19.27 O
    * 19.28 P
    * 19.29 Q
    * 19.30 R
    * 19.31 S
    * 19.32 T
    * 19.33 U
    * 19.34 V
    * 19.35 W
    * 19.36 X
    * 19.37 Y
    * 19.38 Z
    * 19.39 Lesson1
      * 19.39.1 Matching Sentences
    * 19.40 Hello
    * 19.41 Good morning
    * 19.42 Good afternoon
    * 19.43 Good evening / Good night
    * 19.44 Good-bye
    * 19.45 Chinese New Year Greetings
    * 19.46 Table of Possible Combinations of Chinese Initials and Finals
    * 19.47 Number System (数字系统)
      * 19.47.1 基本用字 Basic Characters
      * 19.47.2 个十百千万 Larger Numbers
    * 19.48 更大的数字（亿兆） Even Larger Numbers
    * 19.49 中文中零的用法 The Use of Zero in Chinese
    * 19.50 数字手势 Chinese Gestures for Numbers
    * 19.51 Asia 亚洲 / 亞洲 _Yàzhōu_
    * 19.52 Oceania 大洋洲 _Dàyángzhōu_
    * 19.53 America 美洲 _Měizhōu_
    * 19.54 Europe 欧洲 / 歐洲 _Ōuzhōu_
    * 19.55 Africa 非洲 _Fēizhōu_
  * 20 Names of Radicals 中文偏旁的名称
    * 20.1 一笔画 One Stroke
    * 20.2 二笔画 Two Strokes
    * 20.3 三笔画 Three Strokes
    * 20.4 四笔画 Four Strokes
    * 20.5 五笔画 Five Strokes
    * 20.6 六笔画 Six Strokes
    * 20.7 七笔画 Seven Strokes
    * 20.8 Slang List
    * 20.9 External links
    * 20.10 2006
    * 20.11 2005
    * 20.12 2004
    * 20.13 2003
  * 21 Contributors
  * 22 Ways to Contribute
    * 22.1 Internationalization
      * 22.1.1 Keep the Simplified/Traditional Versions in Sync
      * 22.1.2 Translate Pages
      * 22.1.3 Add InterWiki Links
    * 22.2 Stroke Order Images
    * 22.3 Sound Samples
    * 22.4 Chinese Wikibook Purpose and Audience
    * 22.5 The Need for Planning
    * 22.6 _Lesson Roadmap_
    * 22.7 Subjects Areas to Cover
    * 22.8 Decided Conventions
    * 22.9 Unresolved Issues
  * 23 License
    * 23.1 GNU Free Documentation License
    * 23.2 0\. PREAMBLE
    * 23.3 1\. APPLICABILITY AND DEFINITIONS
    * 23.4 2\. VERBATIM COPYING
    * 23.5 3\. COPYING IN QUANTITY
    * 23.6 4\. MODIFICATIONS
    * 23.7 5\. COMBINING DOCUMENTS
    * 23.8 6\. COLLECTIONS OF DOCUMENTS
    * 23.9 7\. AGGREGATION WITH INDEPENDENT WORKS
    * 23.10 8\. TRANSLATION
    * 23.11 9\. TERMINATION
    * 23.12 10\. FUTURE REVISIONS OF THIS LICENSE
    * 23.13 11\. RELICENSING
  * 24 How to use this License for your documents

# Lesson 1: 你好！

It is appropriate to start off the introduction to Chinese with the common greeting 你好 ![Look up 你好 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹nǐ hǎo› (“hello”)。 Below is a dialogue between two people meeting each other for the first time.

## Dialogues

### Dialogue 1

[Dialogue 1](/wiki/File:Chinese-Lesson1-Dialogue1.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikipedia/commons/7/7c/Chinese-Lesson1-Dialogue1.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

Simplified Characters Traditional Characters

金妮:
你好。
金妮:
你好。

欧文:
你好。
歐文:
妳好。

金妮:
我叫金妮。你叫什么名字？
金妮:
我叫金妮。你叫什麽名字？

欧文:
我叫欧文。
歐文:
我叫歐文。

Pīnyīn English

Jīnní:
[Nǐ hǎo](/wiki/Pinyin/Vocabulary#N).
Ginny:
Hello.

Ōuwén:
[Nǐ hǎo](/wiki/Pinyin/Vocabulary#N).
Owen:
Hello.

Jīnní:
[Wǒ](/wiki/Pinyin/Vocabulary#W) [jiào](/wiki/Pinyin/Vocabulary#J) Jīnní. [Nǐ](/wiki/Pinyin/Vocabulary#N) [jiào](/wiki/Pinyin/Vocabulary#J) [shénme](/wiki/Pinyin/Vocabulary#S) [míngzi](/wiki/Pinyin/Vocabulary#M)?
Ginny:
I'm Ginny. What's your name?

Ōuwén:
[Wǒ](/wiki/Pinyin/Vocabulary#W) [jiào](/wiki/Pinyin/Vocabulary#J) Ōuwén.
Owen:
I'm Owen.

### Dialogue 2

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Gnome-mime-audio-openclipart.svg/50px-Gnome-mime-audio-openclipart.svg.png)

[Dialogue 2](/wiki/File:Chinese-Lesson1-Dialogue2.ogg)

Sorry, your browser either has JavaScript disabled or does not have any supported player.  
You can [download the clip](//upload.wikimedia.org/wikibooks/en/9/9c/Chinese-Lesson1-Dialogue2.ogg) or [download a player](//www.mediawiki.org/wiki/Extension:TimedMediaHandler/Client_download) to play the clip in your browser.

* * *

_Problems listening to this file? See [media help](//en.wikipedia.org/wiki/Wikipedia:Media_help)._

Simplified Characters Traditional Characters

金妮:
他们是谁？
金妮:
他們是誰？

欧文:
她是艾美，她是中国人。他是东尼，他是美国人。
歐文:
她是艾美，她是中國人。他是東尼，他是美國人。

金妮:
你也是美国人吗？
金妮:
你也是美國人嗎？

欧文:
不是，我是英国人。你呢？你是哪国人？
歐文:
不是，我是英國人。你呢？你是哪國人？

金妮:
我是法国人。
金妮:
我是法國人。

  


Pīnyīn English

Jīnní:
Tāmen shì shéi?
Ginny:
Who are they?

Ōuwén:
Tā shì Àiměi, tā shì Zhōngguórén. Tā shì Dōngní, tā shì Měiguórén.
Owen:
She is Amy. She's Chinese. He's Tony, an American.

Jīnní:
Nĭ yě shì Měiguórén ma?
Ginny:
Are you also American?

Ōuwén:
Bú shì. Wǒ shì Yīngguórén. Nǐ ne? Nǐ shì nǎ guó rén?
Owen:
No, I'm British. How about you? Which nationality are you?

Jīnní:
Wǒ shì Fǎguórén.
Ginny:
I'm French.

## Vocabulary

_**Note**_: Visit this lesson's [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1) subpage to see images and animations detailing how to write the following characters. Audio files of the words are linked from the pīnyīn when available. Problems listening? See [media help](//en.wikipedia.org/wiki/Media_help).

Simplified Traditional (if diff.) Pīnyīn [Part of speech](/wiki/Chinese/Abbreviations) English [‍[m.](/wiki/Chinese/Abbreviations)‍]

1a.
你 ![Look up 你 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[nǐ](//upload.wikimedia.org/wikipedia/commons/7/73/Zh-n%C7%90.ogg)
(pro)
you (singular, masculine)

1b.
妳 ![Look up 妳 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
妳 ![Look up 妳 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[nǐ](//upload.wikimedia.org/wikipedia/commons/7/73/Zh-n%C7%90.ogg)
(pro)
you (singular, feminine)

2.
好 ![Look up 好 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[hǎo](//upload.wikimedia.org/wikipedia/commons/1/15/Zh-hao3.ogg)
(adj)
good

3.
们 ![Look up 们 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
們 ![Look up 們 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[men](//upload.wikimedia.org/wikipedia/commons/6/68/Zh-men.ogg)
(particle)
(noun plural marker)

4a.
你们 ![Look up 你们 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
你們 ![Look up 你們 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[nǐmen](//upload.wikimedia.org/wikipedia/commons/d/d2/Zh-ni3men.ogg)
(pro)
you all (plural, masculine)

4b.
妳们 ![Look up 妳们 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
妳們 ![Look up 妳們 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[nǐmen](//upload.wikimedia.org/wikipedia/commons/d/d2/Zh-ni3men.ogg)
(pro)
you all (plural, feminine)

5.
我 ![Look up 我 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[wǒ](//upload.wikimedia.org/wikipedia/commons/c/c4/Zh-wo3.ogg)
(pro)
I, me

6.
我们 ![Look up 我们 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
我們 ![Look up 我們 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[wǒmen](//upload.wikimedia.org/wikipedia/commons/9/9e/Zh-wo3men.ogg)
(pro)
we, us

7.
他 ![Look up 他 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[tā](//upload.wikimedia.org/wikipedia/commons/6/6f/Zh-ta1.ogg)
(pro)
he, him

8.
她 ![Look up 她 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[tā](//upload.wikimedia.org/wikipedia/commons/6/6f/Zh-ta1.ogg)
(pro)
she, her

9.
他们 ![Look up 他们 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
他們 ![Look up 他們 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[tāmen](//upload.wikimedia.org/wikipedia/commons/9/9e/Zh-ta1men.ogg)
(pro)
they, them (masc.)

10.
她们 ![Look up 她们 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
她們 ![Look up 她們 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[tāmen](//upload.wikimedia.org/wikipedia/commons/9/9e/Zh-ta1men.ogg)
(pro)
they, them (fem.)

11.
叫 ![Look up 叫 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[jiào](//upload.wikimedia.org/wikipedia/commons/2/2b/Zh-jiao4.ogg)
(v)
to be named, (lit.) to call

12.
什么 ![Look up 什么 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
什麽 ![Look up 什麽 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[shénme](//upload.wikimedia.org/wikipedia/commons/e/ee/Zh-shen2me.ogg)
(pro)
what

13.
名字 ![Look up 名字 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[míngzi](//upload.wikimedia.org/wikipedia/commons/2/28/Zh-ming2zi.ogg)
(n)
name

14.
是 ![Look up 是 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[shì](//upload.wikimedia.org/wikipedia/commons/4/4c/Zh-shi4.ogg)
(v)
to be (am/is/are)

15.
谁 ![Look up 谁 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
誰 ![Look up 誰 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[shéi _**OR**_ shuí](//upload.wikimedia.org/wikipedia/commons/8/86/Zh-shei2_shui2.ogg)
(pro)
who, whom

16.
国 ![Look up 国 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
國 ![Look up 國 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[guó](//upload.wikimedia.org/wikipedia/commons/6/67/Zh-guo2.ogg)
(n)
country

17.
人 ![Look up 人 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[rén](//upload.wikimedia.org/wikipedia/commons/d/d5/Zh-ren2.ogg)
(n)
person [个 ![Look up 个 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹gè› (個 ![Look up 個 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) )]

18.
也 ![Look up 也 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[yě](//upload.wikimedia.org/wikipedia/commons/7/7a/Zh-ye3.ogg)
(adv)
also

19.
吗 ![Look up 吗 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
嗎 ![Look up 嗎 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[ma](//upload.wikimedia.org/wikipedia/commons/3/37/Zh-ma.ogg)
(part)
(question particle for yes or no questions)

20.
呢 ![Look up 呢 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[ne](//upload.wikimedia.org/wikipedia/commons/f/f8/Zh-ne.ogg)
(part)
(question particle for known context)

21.
哪 ![Look up 哪 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[nǎ _**OR**_ něi](//upload.wikimedia.org/wikipedia/commons/0/02/Zh-na3_nei3.ogg)
(pro)
what, which

22.
不 ![Look up 不 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[bù](//upload.wikimedia.org/wikipedia/commons/1/14/Zh-bu4.ogg)
(adv)
(negates verbs)

### Proper Nouns

Simplified Traditional (if diff.) Pīnyīn English

1.
金妮
[Jīnní](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-jin1ni2.ogg)
Ginny

2.
欧文
歐文
[Ōuwén](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-ou1wen2.ogg)
Owen

3.
艾美
[Àiměi](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-ai4mei3.ogg)
Amy

4.
东尼
東尼
[Dōngní](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-dong1ni2.ogg)
Tony

5.
中国 ![Look up 中国 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
中國 ![Look up 中國 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[Zhōngguó](//upload.wikimedia.org/wikipedia/commons/6/6c/Zh-zhongguo.ogg)
China

6.
美国 ![Look up 美国 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
美國 ![Look up 美國 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[Měiguó](//upload.wikimedia.org/wikipedia/commons/3/3e/Zh-mei3guo2.ogg)
America

7.
英国 ![Look up 英国 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
英國 ![Look up 英國 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[Yīngguó](//upload.wikimedia.org/wikipedia/commons/7/7e/Zh-ying1guo2.ogg)
Britain

8.
法国 ![Look up 法国 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
法國 ![Look up 法國 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) 
[Fǎguó](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-fa4guo2.ogg)
France

Forming the nationality is usually as simple as adding on 人 ![Look up 人 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹rén› (“person”) to the country name. 中国 ![Look up 中国 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹Zhōngguó› (“China”) becomes 中国人 ![Look up 中国人 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹Zhōngguó rén› (“a person of Chinese nationality”), and so forth.

## Grammar

### Basic Sentences

The sentence structure of Chinese is very similar to that of English in that they both follow the pattern of [Subject-Verb-Object](//en.wikipedia.org/wiki/Subject_Verb_Object) (SVO). Unlike many languages, verbs in Chinese are not conjugated and noun and adjective endings do not change. They are never affected by things such as time or person.

  


S + V + O

  


  
1\. 我叫艾美。

    Wǒ jiào Àiměi.
    _I'm called Amy._

* * *

### Sentences using _shì_ [是]

The equational verb 是 ![Look up 是 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹shì› (“to be”) can be used as the English _is_ or _equals_. 是 ![Look up 是 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹shì› can only be used to equate combinations of nouns, noun phrases, and pronouns. In Chinese, 是 ![Look up 是 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹shì› (“to be”) is not used with adjectives, as it is in English, as in, "He is cold."

  


S + 是 + O

  


  


1\. 我是中国人。

    Wǒ shì Zhōngguórén.
    _I **am** a Chinese person._

2\. 她是金妮。

    Tā shì Jīnní.
    _She **is** Ginny._  


3\. 她们是英国人。

    Tāmen shì Yīngguórén.
    _They **are** English._  


是 ![Look up 是 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹shì› is negated when preceded by 不 ![Look up 不 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹bù› (“not”). 不 ![Look up 不 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹bù› is normally 4th tone, but changes to a 2nd tone when it precedes another 4th tone.

  


S + 不 + 是 + O

  


  


1\. 他不是东尼。

    Tā bú shì Dōngní.
    _He **is not** Tony._

2\. 我不是美国人。

    Wǒ bú shì Měiguórén.
    _I **am not** American._

* * *

### Articles

There are no articles in Chinese grammar. While English noun clauses often begin with "a", "an", or "the", Chinese is less verbose.

An example:

  1. 我是中国人。 

    Wǒ shì Zhōngguórén.
    _I **am** [a] Chinese person._

An "a" appears in the English translation, but the [singular](//en.wikipedia.org/wiki/Grammatical_number) and [indefinite](//en.wikipedia.org/wiki/Article_\(grammar\)#Indefinite_article) nature of 中国人 ![Look up 中国人 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹Zhōngguórén› (“Chinese person”) is just inferred in Chinese.

* * *

### The question particle 吗 ![Look up 吗 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹ma›

Adding the modal particle 吗 ![Look up 吗 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹ma› to the end of a sentence makes a statement into a question. There is no change in word order unlike in English.

The declarative example sentence in #1 is transformed into an interrogative in #2.

1\. 她是金妮。

    Tā shì Jīnní.
    _She is Ginny._

2\. 她是金妮吗？

    Tā shì Jīnní ma?
    _She is Ginny ?_

* * *

### The question particle 呢 ![Look up 呢 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹ne›

Using the ending modal particle 呢 ![Look up 呢 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹ne› makes a question when the context is already known, similar to saying "How about...?" in English. A common circumstance is when you wish to repeat a question that was just asked for another subject. Simply add 呢 ![Look up 呢 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹ne› to the end of the noun or pronoun to ask "How about _this_".

  
1\. 我叫东尼, 你呢？

    Wǒ jiào Dōngní, nǐ ne?
    _I'm called Tony. How about you?_

2\. 艾美是中国人, 他呢？

    Àiměi shì Zhōngguórén, tā ne?
    _Amy is Chinese. How about him?_

* * *

### Question words

Question words like 哪 ![Look up 哪 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹nǎ› (“what”) and 谁 ![Look up 谁 in Wiktionary](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Wiktionary-logo_wpstyle-en_with_transparency.png/32px-Wiktionary-logo_wpstyle-en_with_transparency.png) ‹shéi› (“who”) also make statements into questions without changing the order of the sentence. In Chinese, each question word appears where its answer would complete the surrounding sentence.

  
1\. 他们是**哪**国人？

    Tāmen shì **nǎ** guó rén?
    _What nationality are they?_ (literally, "They are **what** country person?")

2\. **谁**是美国人？

    **Shéi** shì Měiguórén?
    _Who is American?'_

3\. 她是**谁**？

    Tā shì **shéi**?
    _Who is she?_ (literally, "She is **who**?")

* * *

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lesson 2: 今天你忙不忙？

Lesson 2 contains a dialogue of two students discussing their classes for the day.

## Dialogues

**Dialogue 1**

Simplified Characters Traditional Characters

东尼:
艾美，早上好（早安）。
東尼:
艾美，早上好（早安）。

艾美:
早。你好吗？
艾美:
早。你好嗎？

东尼:
我很好，谢谢。你呢？
東尼:
我很好，謝謝。你呢？

艾美:
我也很好。你今天忙吗？
艾美:
我也很好。你今天有空嗎？

东尼:
今天我很忙。我有五门课。
東尼:
今天我很忙。我有五門課。

艾美:
五门？太多了！我今天只有一门。
艾美:
五門？太多了！我今天只有一門。

东尼:
一门？太少了！
東尼:
一門？太少了！

Pīnyīn English

Dōngní:
Àiměi, [zăoshang hǎo](/wiki/Pinyin/Vocabulary#Z) ([zǎo'ān](/wiki/Pinyin/Vocabulary#Z)).
Tony:
Good morning, Amy.

Àiměi:
[Zăo](/wiki/Pinyin/Vocabulary#Z). [Nǐ hǎo ma?](/wiki/Pinyin/Vocabulary#N)
Amy:
Good morning. How are you?

Dōngní:
[Wǒ](/wiki/Pinyin/Vocabulary#W) [hěn](/wiki/Pinyin/Vocabulary#H) [hǎo](/wiki/Pinyin/Vocabulary#H), [xièxie](/wiki/Pinyin/Vocabulary#X). [Nǐ](/wiki/Pinyin/Vocabulary#N) [ne](/wiki/Pinyin/Vocabulary#N)?
Tony:
I'm fine, thanks. And you?

Àiměi:
[Wǒ](/wiki/Pinyin/Vocabulary#W) [yě](/wiki/Pinyin/Vocabulary#Y) [hěn](/wiki/Pinyin/Vocabulary#H) [hǎo](/wiki/Pinyin/Vocabulary#H). [Nǐ](/wiki/Pinyin/Vocabulary#N) [jīntiān](/wiki/Pinyin/Vocabulary#J) ([máng](/wiki/Pinyin/Vocabulary#M) [ma?](/wiki/Pinyin/Vocabulary#M)) ([yǒukòng](/wiki/Pinyin/Vocabulary#Y) [ma?](/wiki/Pinyin/Vocabulary#M))
Amy:
I'm also fine. Are you busy today?

Dōngní:
[Jīntiān](/wiki/Pinyin/Vocabulary#J) [wǒ](/wiki/Pinyin/Vocabulary#W) [hěn](/wiki/Pinyin/Vocabulary#H) [máng](/wiki/Pinyin/Vocabulary#M). [Wǒ](/wiki/Pinyin/Vocabulary#W) [yǒu](/wiki/Pinyin/Vocabulary#Y) [wǔ](/wiki/Pinyin/Vocabulary#W)[-mén](/wiki/Pinyin/Vocabulary#M) [kè](/wiki/Pinyin/Vocabulary#K).
Tony:
I'm very busy today. I have five classes.

Àiměi:
[Wǔ](/wiki/Pinyin/Vocabulary#W)[-mén](/wiki/Pinyin/Vocabulary#M)? [Tài](/wiki/Pinyin/Vocabulary#T) [duō](/wiki/Pinyin/Vocabulary#D) [le!](/wiki/Pinyin/Vocabulary#L) [Wǒ](/wiki/Pinyin/Vocabulary#W) [jīntiān](/wiki/Pinyin/Vocabulary#J) [zhĭyǒu](/wiki/Pinyin/Vocabulary#Z) [yī](/wiki/Pinyin/Vocabulary#Y)[-mén](/wiki/Pinyin/Vocabulary#M).
Amy:
Five? That's too many! Today I only have one.

Dōngní:
[Yī](/wiki/Pinyin/Vocabulary#Y)[-mén](/wiki/Pinyin/Vocabulary#M)? [Tài](/wiki/Pinyin/Vocabulary#T) [shǎo](/wiki/Pinyin/Vocabulary#S) [le!](/wiki/Pinyin/Vocabulary#L)
Tony:
One? That's too few!

**Dialogue 2**

Simplified Characters Traditional Characters

东尼:
艾美，下午好。
東尼:
艾美，下午好。

艾美:
下午好。你那五门课上完了吗？
艾美:
下午好。你那五門課上完了嗎？

东尼:
上了三节，你呢？
東尼:
上了三節。你呢？

艾美:
上完了，下午想去公园。
艾美:
上完了，下午想去公園。

东尼:
哦。这个计划不错。
東尼:
哦。這個計劃不錯。

艾美:
谢谢夸奖。那么，明天见！
艾美:
謝謝夸獎。那麼，明天見！

东尼:
明天见。
東尼:
明天見。

Pīnyīn English

Dōngní:
Àiměi, xiàwǔ hǎo.
Tony:
Good afternoon, Amy.

Àiměi:
Xiàwǔ hǎo. Nǐ nà wǔ-mén kè shàng-wánle ma?
Amy:
Good afternoon. Did you finish your five classes?

Dōngní:
Shàng-le sān-jié, nǐ ne?
Tony:
I finished 3 of them. And you?

Àiměi:
Shàng-wánle, xiàwǔ xiǎng qù gōngyuán.
Amy:
I'm free now. I am going to the park.

Dōngní:
O. Zhègè jìhuà bùcuò.
Tony:
Oh. That's a good plan.

Àiměi:
Xièxiè kuājiǎng. Nàme, míngtiān jiàn!
Amy:
Thanks a lot. Hey, see you tomorrow.

Dōngní:
Míngtiān jiàn!
Tony:
See you.

## Vocabulary

_**Note**_: Visit this lesson's [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1) subpage to see images and animations detailing how to write the following characters. Audio files of the words are linked from the pīnyīn when available. Problems listening? See [media help](//en.wikipedia.org/wiki/Media_help).

Simplified (traditional in parentheses) Pīnyīn [Part of speech](/wiki/Chinese/Abbreviations) English [‍[m.](/wiki/Chinese/Abbreviations)‍]

1.
一
[yī](//upload.wikimedia.org/wikipedia/commons/6/64/Zh-yi1.ogg)
(adj)
one

2.
二
[èr](//upload.wikimedia.org/wikipedia/commons/5/51/Zh-%C3%A8r.ogg)
(adj)
two

3.
三
[sān](//upload.wikimedia.org/wikipedia/commons/2/2d/Zh-san1.ogg)
(adj)
three

4.
四
[sì](//upload.wikimedia.org/wikipedia/commons/6/60/Zh-s%C3%AC.ogg)
(adj)
four

5.
五
[wǔ](//upload.wikimedia.org/wikipedia/commons/5/5c/Zh-wu3.ogg)
(adj)
five

6.
六
[liù](//upload.wikimedia.org/wikipedia/commons/7/73/Zh-liu4.ogg)
(adj)
six

7.
七
[qī](//upload.wikimedia.org/wikipedia/commons/3/3f/Zh-qi1.ogg)
(adj)
seven

8.
八
[bā](//upload.wikimedia.org/wikipedia/commons/0/01/Zh-ba1.ogg)
(adj)
eight

9.
九
[jiǔ](//upload.wikimedia.org/wikipedia/commons/a/af/Zh-jiu3.ogg)
(adj)
nine

10.
十
[shí](//upload.wikimedia.org/wikipedia/commons/c/c0/Zh-shi2.ogg)
(adj)
ten

11.
早
[zăo](//upload.wikimedia.org/wikipedia/commons/b/be/Zh-zao3.ogg)
(n)
morning (often spoken alone as a shortened form to mean "good morning" just like with English)

12.
安
[ān](//upload.wikimedia.org/wikipedia/commons/1/10/Zh-an1.ogg)
(adj)
peaceful

13.
早安
[zăo'ān](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-zao3an1.ogg)
(phrase)
good morning

14.
很
[hěn](//upload.wikimedia.org/wikipedia/commons/1/1c/Zh-hen3.ogg)
(adv)
very

15.
谢谢 (謝謝)
[xièxie](//upload.wikimedia.org/wikipedia/commons/2/23/Zh-xie4xie.ogg)
(v)
thanks

16.
天
[tiān](//upload.wikimedia.org/wikipedia/commons/1/1d/Zh-ti%C4%81n.ogg)
(n)
day/sky

17.
今天
[jīntiān](//upload.wikimedia.org/wikipedia/commons/d/d7/Zh-j%C4%ABnti%C4%81n.ogg)
(n)
today

18.
忙
[máng](//upload.wikimedia.org/wikipedia/commons/5/5d/Zh-mang2.ogg)
(adj)
busy

19.
有
[yǒu](//upload.wikimedia.org/wikipedia/commons/e/e6/Zh-y%C7%92u.ogg)
(v)
to have, possess

20.
没(沒)
[méi](//upload.wikimedia.org/wikipedia/commons/3/3d/Zh-m%C3%A9i.ogg)
(adv)
negates yǒu

21.
门 (門)
[mén](//upload.wikimedia.org/wikipedia/commons/6/62/Zh-m%C3%A9n.ogg)
(m)
(measure word for school courses)

22.
课 (課)
[kè](//upload.wikimedia.org/wikipedia/commons/c/ca/Zh-ke4.ogg)
(n)
class [節-measure word for class]

23.
太
[tài](//upload.wikimedia.org/wikipedia/commons/f/f6/Zh-tai4.ogg)
(adv)
too, extremely

24.
了
[le](//upload.wikimedia.org/wikipedia/commons/3/3c/Zh-le.ogg)
(part)
(combines with 太 - see grammar)

25.
多
[duō](//upload.wikimedia.org/wikipedia/commons/f/fc/Zh-duo1.ogg)
(adj)
many

26.
少
[shăo](//upload.wikimedia.org/wikipedia/commons/2/20/Zh-shao3.ogg)
(adj)
few

27.
只
[zhĭ](//upload.wikimedia.org/wikipedia/commons/8/89/Zh-zhi3.ogg)
(adv)
only, merely

28.
都
[dōu](/w/index.php?title=D%C5%8Du&action=edit&redlink=1)
(adv)
all,both

29.
早上好
[zǎoshàng hǎo](/w/index.php?title=Z%C7%8Eosh%C3%A0ng_h%C7%8Eo&action=edit&redlink=1)
(phrase)
good morning

30.
下午好
[xiàwǔhǎo](/w/index.php?title=Xi%C3%A0w%C7%94h%C7%8Eo&action=edit&redlink=1)
(phrase)
good afternoon

## Grammar

### The adverb _Hěn_ [很]

Though translated as "very", _Hěn_ [很] has a weaker meaning than it does in English. It is often added before a single-syllable adjective just to enhance the rhythmic flow of the sentence. _Hěn_ is used before the adjective in affirmative sentences, but _not_ in negative sentences or questions. A common mistake of beginners is to insert _shì_ [是] into adjectival sentences, but this usage is incorrect as _shì_ can only be used to equate combinations of nouns, noun phrases and pronouns.

  


1\. 我很忙。

    Wǒ hěn máng
    _I am (very) busy._

### _Le_ [了] as emphasizer

The particle _le_ [了] has many different functions in Chinese, but in this case, it serves to add emphasis to the verb or adjective of the sentence. It can be seen paired with _tài_ [太] to express excessiveness.

  


1\. 太多了。

    Tài duō le.
    (That's) too many.

2\. 太少了。

    Tài shăo le.
    (That's) too few.

### Affirmative-negative questions

A sentence can be made into a question by having both affirmative and negative options together. To answer in the affirmative, the verb or adjective is repeated. (An affirmative adjective in this case is usually preceded by _hěn_ [很] to avoid a comparative tone.) Responding in the negative is simply saying "not verb" or "not adjective".

  


S + V 不 V + O?

  
  


Example:  


Because the _bù_ in affirmative-negative questions is often said quickly, marking the tone on _bù_ is not strictly necessary in their case.

Q: 他是不是东尼？

    Tā shì bu shì Dōngní?
    _Is he Tony?_
    literally, "he is/is not Tony?"

A: 是的。（是，他是/嗯，他是。）**or** 不是。 （不，他不是。）

The _de_ is not necessary. You can simply answer _是_ (_shì_).

    Shì de. (Shì tā shì) **or** Bú shì (Bù tā bú shì).
    _Yes (he is)._ **or** _No (he isn't)._

  


S + adj. 不 adj.? （The second adjective can be omitted.）

  
  


Example:  
Q:艾美今天忙不忙？/艾美今天忙不？

    Àiměi jīntiān máng bù （máng）?
    _Is Amy busy today?_
    literally, "Today, Amy busy/not busy"

A: 她很忙。**or** 她不忙。

    Tā hěn máng. **or** Tā bù máng.
    _Yes, she's (very) busy._ **or** _No, she's not busy._

### Sentences using _yǒu_ [有]

_Yǒu_ [有] means _to have_ and indicates possession.

  


S + 有 + O

  
  


Example:  
我有三门课。

    Wǒ yǒu sān mén kè.
    _I have three classes._

_Yǒu_ is negated when preceded by _méi_ [没].

  


S + 没 + 有 + O

  
  


Example:  
今天，他们没有课。

    Jīntiān tāmen méi yǒu kè.
    _Today, they don't have any classes._

_Yǒu_ is negated when preceded by _méi_ [没].

  


S + 一 + O + 都没有

  
  


Example:  


The adverb _都_ (_dōu_) is required here in front of 没有 to emphasize the lack of a single one of the object. Also, be sure to remember to place the proper measure word between 一 and the object.

今天，他们一门课都没有。

    Jīntiān tāmen yì mén kè dōu méi yǒu.
    _Today, they don't have a single class._

* * *

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lesson 3: 助詞

The Chinese language employs heavy usage of particles to modify the meaning of characters and sentences. Since Chinese has neither inflections nor tense, the mastery of particles is an absolute must if one is to fully comprehend both written and spoken Chinese. Below, you will find some of the most common particles in everyday Chinese.

## The _De_ {的} particle as possessive

The particle _de_ [的] can be used to indicate possession. It is roughly equivalent to the contraction "X's" in English, where X is the subject.

Example:
    
    
          她  的   名字   是   金妮。
           Tā de míngzi shì Jīnní.
          Her name is Ginny.
    

sometimes the "的" is following an adjective to make meaning clearer.

  


Example 她是一个美丽的姑娘
    
    
            Ta shi yige meili de gu’niang.
           She is a beautiful girl.
    

## The _Le_ {了} / _Liăo_ {了} particle

**Perfective Aspect Particle**

  


The {了} particle is used mainly to indicate a **completed action** (this overlaps somewhat with the English _perfect aspect_, i.e. "to have gone", "to have eaten").

Example:
    
    
          他  走  了。
           Tā zŏu le.
          He has gone. 
    
    

※The "le" here is used to modify 走 (zŏu, _to go_) into an action which has already been completed.

  


The {了} can also be used as an **imperative**, that is, a command which is issued by the subject

Example:
    
    
          別   再   打扰  我  了! 
          別   再   打擾  我  了! 
          Bié zài dărăo wŏ le! 
          Do not bother me again!
    

※In this instance, le is used in conjunction with bié ("do not") to form an imperative. _Note_: most imperatives are not formed using this construction.

  


The {了} , as in Liăo (a homographic variant) can be used to indicate the subject's **capability** in doing such and such.

Example:
    
    
          我  实在    吃  不  了   了。
           我  實在    吃  不  了   了。 
           Wŏ shízài chī bù liăo le. 
          I cannot possibly eat any more.
    

  


At first glance, this sentence may seem a bit daunting as it includes two instances of the le particle, paired side-by-side. However, the first le is understood to be liăo given its placement (bù + le is a nonsensical pairing). Therefore, liăo serves to indicate the capability of eating any further and le _emphasizes_ this assertion.

## The _Zhe_ [着] particle showing continuation

The particle _Zhe_ [着] is used after a verb to show that the action is in progress or that the results from that action are continuing.

1\. 他睡着觉时有人敲门。

    Tā shuìzhe jiào shí yŏurén qiāomén.
    _While he was sleeping, someone knocked on the door._  


2\. Alternatively you could take out "着" and say "他睡觉时有人敲门。"

## The _Zháo_ [着] particle indicating accomplishment

The particle _Zháo_ [着] is used after a verb to show accomplishment or result. 

Note: It is not to be confused with the identically written particle Zhe, which shows continuation (Lesson 3).

1\. 我终于把东西买着了!
    
    
     (我終於把東西買著了!) 
    

    Wŏ zhōngyú bă dōngxī măi zháo le.
    _I've finally been able to buy this item!_  


And another word, _dào_ [到], can be seen as a substitution for 着, in most cases they are interchangeable.

2\. 他在行窃时被当场抓到。

    Tā zài xíng qìe shí beì dāng chǎng zhuā dào.
    He was(is) caught in the act of stealing.

The 把 + N + V + 着(到)了 construction is particularly useful and should be studied.

## The _De_ [得] particle indicating degree

The particle _de_ [得] is used in few special constructs to indicate degree of complement (how fast, how early, how expensive, etc.). It has no equivalent in English but must be used to indicate the meanings below.

S + V + 得 + adjective

1\. 我说得很好.

    Wŏ shuō de hěn hăo.
    _I speak very well._

This construct often requires a context to gain its full meaning.

If you wish to speak more specifically about an action, the two constructs below demonstrate the use of 得 with a direct object.

S + V + O + V + 得 + adjective

2\. 我说中文说得很好.

    Wŏ shuō zhōngwén shuō de hěn hăo.
    _I speak Chinese very well._

Note the dual-use of the verb.

O + S + V + 得 + adjective

3\. 中文我说得很好.

    Zhōngwén wŏ shuō de hěn hăo.
    _I speak Chinese very well._

This construct emphasizes the object (here being "Chinese").

S + O + V + 得 + adjective

4\. 我中文说得很好.

    Wŏ zhōngwén shuō de hěn hăo.
    _I speak Chinese very well._

This expression is the simplification of the 2nd expression by eliminating the 1st verb. This form is even more frequently used than the 2nd expression above.

## Vocabulary

_**Note**_: Visit this lesson's [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1) subpage to see images and animations detailing how to write the following characters. Audio files of the words are linked from the pīnyīn when available. Problems listening? See [media help](//en.wikipedia.org/wiki/Media_help).

Simplified Traditional (if diff.) Pīnyīn [Part of speech](/wiki/Chinese/Abbreviations) English [‍[m.](/wiki/Chinese/Abbreviations)‍]

1.
走
[zǒu](//upload.wikimedia.org/wikipedia/commons/1/1b/Zh-z%C7%92u.ogg)
(v)
to walk, leave

2.
打扰
打擾
[dărăo](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-d%C4%83r%C4%83o.ogg)
(v)
to bother

3.
实在
實在
[shízài](//upload.wikimedia.org/wikipedia/commons/c/cb/Zh-sh%C3%ADz%C3%A0i.ogg)
(adv)
emphatically, etc.

4.
吃
[chī](//upload.wikimedia.org/wikipedia/commons/4/43/Zh-ch%C4%AB.ogg)
(v)
to eat

5.
睡觉
睡覺
[shuìjiào](//upload.wikimedia.org/wikipedia/commons/a/a7/Zh-shu%C3%ACji%C3%A0o.ogg)
(v)
to sleep

6.
时
時
[shí](//upload.wikimedia.org/wikipedia/commons/e/e3/Zh-sh%C3%AD.ogg)
(n)
(lit.) time. When used in conjunction with a verb, it means "when/as" that action is taking place

7.
敲
[qiāo](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-qi%C4%81o.ogg)
(v)
to knock

8.
门
門
[mén](//upload.wikimedia.org/wikipedia/commons/6/62/Zh-m%C3%A9n.ogg)
(n)
door, gate

9.
终于
終於
[zhōngyú](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=Zh-zh%C5%8Dngy%C3%BA.ogg)
(adv)
finally, eventually

10.
东
東
[dōng](//upload.wikimedia.org/wikipedia/commons/f/fe/Zh-d%C5%8Dng.ogg)
(adj)
east

11.
西
[xī](//upload.wikimedia.org/wikipedia/commons/8/8f/Zh-x%C4%AB.ogg)
(adj)
west

12.
东西
東西
[dōngxī](//upload.wikimedia.org/wikipedia/commons/f/fd/Zh-d%C5%8Dngxi.ogg)
(n)
a general expression for "thing"

13.
玩
[wán](/w/index.php?title=W%C3%A1n&action=edit&redlink=1)
(n)
Only be used express that "play" the game.It can't be used like "play the piano" or "play video"...etc.

13.
喝
[hē](/w/index.php?title=H%C4%93&action=edit&redlink=1)
(v)
drink

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

  
  


# Lesson 4: Word order and Verbs

## Basic Word Order

### Subject-Verb-Object

The order of most Chinese sentences, like in English, is S-V-O, that is **S**ubject-**V**erb-**O**bject.

    我看这本书。
    我看這本書。
    Wǒ kàn zhè běn shū.
    _I read this book._

Word order in Chinese is more rigid than in English. However, sometimes you may find sentences that seem to defy normal word order. For example, 我住在中国。wǒ zhù zài zhōngguó. The English translation does this too: I live in China. The reason for this is that "in China" is a preposition (prepositions indicate place or time) that is tacked on to the main sentence—"I live." More examples:

    下午一点半，我们走。
    Xiàwǔ yīdiǎn bàn, wǒmen zǒu.
    _At 1:30 in the afternoon, we'll go._

    在青岛，我看到了。
    Zài qīngdǎo, wǒ kàn dào le.
    _In Qingdao, I saw it._

As in English, a preposition can also appear after a subject.

    我在我家看这本书。
    我在我家看這本書。
    Wǒ zài wǒ jiā kàn zhè běn shū.
    _I read this book at my house._

    我明天看这本书。
    我明天看這本書。
    Wǒ míngtiān kàn zhè běn shū.
    _I will read this book tomorrow._

When using both a preposition for time and a preposition for place, put the preposition for time first.

    我明天在我家看这本书。
    我明天在我家看這本書。
    Wǒ míngtiān zài wǒ jiā kàn zhè běn shū.
    _I will read this book at my house tomorrow._

    明天在我家，我看这本书。
    明天在我家，我看這本書。
    Míngtiān zài wǒ jiā, wǒ kàn zhè běn shū.
    _Tomorrow at my house, I will read this book._

    明天，我在我家看这本书。
    明天，我在我家看這本書。
    Míngtiān, wǒ zài wǒ jiā kàn zhè běn shū.
    _Tomorrow, I will read this book at my house._

Note the variation in word order. You can also place a preposition for place, but not for time, at the end of a sentence.

    我看这本书在我家。
    我看這本書在我家。
    Wǒ kàn zhè běn shū zài wǒ jiā.
    _I read this book at my house._

### Topic-Comment

Another structure for Chinese sentences is topic-comment. That is, the first thing mentioned is the topic of discussion and then the speaker will add a comment following that.

It is used to emphasize a certain part of the sentence. In the following example, the speaker wants to emphasize that he is going to read the particular book being discussed.

    这本书，我明天在我家看。
    這本書，我明天在我家看。

Zhè běn shū, wǒ míngtiān zài wǒ jiā kàn.

    _I will read_ this _book tomorrow._

## Comparisons Using _bǐ_ [比]

Comparisons can be made using _bǐ_ [比]. Adverbs (like 不，也，只，都）and any auxiliary verbs are placed before _bǐ_ in the sentence. The amount of the disparity between the two is placed after the adjective.

  


A 比 B + Adj.

  


  


    她比我忙。
    Tā bǐ wǒ máng.
    _She is busier than I am._

  


    东尼也比我忙很多。
    東尼也比我忙很多。
    Dōngní yě bǐ wǒ máng hěn duō.
    _Tony is also a lot busier than I am._

## Notes

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lesson 5: Measure words

### Measure Words/量词(liàngcí)

In Chinese, most specified or numbered nouns must be preceded by [measure words](//en.wikipedia.org/wiki/measure_word), also known as classifiers, according to the type of object. Consider the English phrase, "two pairs of pants." Like the word "pair," Chinese measure words are placed between the noun and the preceding number.

1\. 这本书里没有一个汉字。

    Zhè bĕn shū lǐ méi yŏu yí gè Hànzì.
    _This book doesn’t contain one Chinese character._

2\. 那间宿舍有六十个学生。

    Nà jiān sùshè yŏu liùshí ge xuésheng.
    _That dorm has sixty students._

The phrase 一朵花 (yī duǒ huā) means "one flower," but how would you say "a pile of flowers?" It's simple: just change the classifier. The phrase 一堆花 (yī duī huā) means "a pile of flowers." You could also say 一把花 (yī bǎ huā; a handful of flowers), 一桶花 (yī tǒng huā; a bucket of flowers), or 一种花 (yī zhòng huā; a kind of flower). You can see that measure words act as adjectives.

In Chinese, like in English, you can omit the noun if it's already known, leaving only the classifier. 你看到那种（花）吗？ (Nǐ kàn dào nà zhǒng (huā) ma?) means "Did you see that kind (of flower)?" You can see that measure words also act as nouns.

Measure words are also used with [demonstrative pronouns](//en.wikipedia.org/wiki/demonstrative) (this, that). For example, 这朵花 means "this flower," and 那朵花 means "that flower."

You might also encounter something like this: 书架上有书本。 (Shūjià shàng yǒu shūběn.) which means "The bookshelf has books on it." Note that the classifier is after the noun. This signifies multiple books where the exact number is not important, here translated "books." The sentence 书架上有书。, means the same as above, but is without the classifier.

#### Some Common Measure Words

Column key: Trad. is Traditional, Simp. shows changes made for the simplified variant (if any).

Trad. Simp. Pinyin Main uses Example

個
个
ge
individual things, people — usage of this classifier in conjunction with any noun is generally accepted if the person does not know the proper classifier.
一个书包 yí ge shūbāo, a schoolbag

把
bǎ
"handful", "fistful" — objects that can be held or grabbed (knives, scissors, keys; also chairs)
一把刀 yì bă dāo. One knife. 

一把盐 yì bă yán. A handful of salt.

包
bāo
"package", "bundle"
一包纸巾 yì bāo zhǐ jīn. A package of paper towels.

杯
bēi
"cup" — drinks
一杯水 yì bēi shuǐ. A cup of water.

本
běn
"volume" — any bound print or written matter (books, etc.)
一本书 yì běn shū. A book.

册
cè
slimmer volumes of books

次
cì
"time" — opportunities, accidents
两次 liǎng cì. Twice. 三次 sān cì. Three times.

滴
dī
"droplet" — water, blood, and other such fluids
一滴水 yì dī shuǐ. A drop of water.

點
点
diǎn
ideas, suggestions, can also mean "a bit"
你睡一点。 Nǐ shuì yīdiǎn. Sleep a bit.

堆
duī
"pile" — anything in a pile
一堆书 yī duī shū. A pile of books.

朵
duǒ
flowers, clouds
一朵花 yì duŏ huā. One flower.

份
fèn
newspapers, jobs
一份报 yì fèn bào. A newspaper

根
gēn
thin, slender objects, lit. "a root of a..." (needles, pillars, grass, vegetable roots etc.)
一根针 yì gēn zhēn. A needle

家
jiā
gathering of people (families, companies, etc.)
一家人 yī jiā rén. A family of people.

架
jià
objects with a "frame" or structure; generally used for machines or mechanical objects (esp. cars, planes, etc.)
一架飞机 yī jià fēijī. One plane.

件
jiàn
matters, clothing, etc.
一件衣服 yí jiàn yī fù. An article of clothing.

節
节
jié
"a section" — of bamboo, tutorials and classes, etc.

輛
辆
liàng
automobiles, bicycles, vehicles, etc.
一辆车 yí liàng chē. One car.

面
miàn
any flat and smooth objects, lit. "a surface of a..." (mirrors, flags, walls, etc.)
一面镜子 yí miàn jìng zi. One mirror

匹
pǐ
horses and other mounts, or rolls/bolts of cloth
一匹马 yì pǐ mă. One horse.

片
piàn
"slice" — any flat object, like cards, slices of bread, tree leaves, etc.
一片叶子 yì piàn yè zi. One leaf.

瓶
píng
"bottle" — drinks

扇
shàn
objects that open and close (doors, windows)
一扇门 yì shàn mén. One door

艘
sōu
ships
一艘船 yì sōu chuán. One ship.

所
suǒ
any buildings, apartment

台
tái
heavy objects (TVs, computers, etc.) and performances (esp. in theatre, etc.)
一台电脑 yī tái diànnǎo. One computer.

條
条
tiáo
long, narrow, flexible objects (fish, trousers, etc.)
一条鱼 yì tiáo yú. One fish.

頭
头
tóu
"head" — herd animals (pigs, cows, sheep etc., _never_ for fowls or birds), hair
一头牛 yì tóu niú. One head of cattle (Literally translated into English, "头" means head).

位
wèi
polite classifier for people (e.g. gentlemen, professors, customers)
几位？Jǐ wèi? How many (people)?

些
xiē
"some" — anything that's plural
一些书 yī xiē shū. Some books. _Never_ 两些书

張
张
zhāng
"sheet" — squarish or rectangular flat objects (paper, tables, etc.), faces, bows, paintings, tickets, constellations
一张纸 yì zhāng zhǐ. One piece of paper.

支
zhī
stick-like objects (pens, chopsticks, etc.)
一支笔 yì zhī bǐ. One pen.

隻
只
zhī
one of a pair (e.g. hands, limbs), animals (birds, cats, etc.)
一只狗 yì zhī gŏu. One dog.

種
种
zhǒng
types or kinds of objects, ideas, etc.

棟
栋
dǒng
building object
一栋房子 yí dòng fáng zí. One house

See [Chinese measure words](//en.wikipedia.org/wiki/Chinese_measure_word) on Wikipedia for a more complete reference.

* * *

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lesson 6: What do you want to buy? 你想要買什麼?

**王明**：你好，李红。  


**李红**：嗨！王明。你去哪儿？  
**王明**：我去图书馆。你呢？  
**李红**：回家。  
**王明**：再见。  
**李红**：再见。  


**Wang Ming**: Nǐ hǎo, Lǐ Hóng.  


**Li Hong**: Hài! Wáng Míng. Nǐ qù nǎr?  
**Wang Ming**: Wǒ qù túshūguǎn, nǐ ne?  
**Li Hong**: Huí jiā.  
**Wang Ming**: Zài jiàn.  
**Li Hong**: Zài jiàn.  


**Wang Ming**: Hello, Li Hong.  


**Li Hong**: Hi, Wang Ming. Where are you going?  
**Wang Ming**: I'm going to the library. What about you?  
**Li Hong**: Going home.  
**Wang Ming**: See you.  
**Li Hong**: See you.  


  
**NOTE**: It's also appropriate with close friends (ones who you would use "你" (nǐ) instead of "您" (nín) with) to greet with "哎" (aì), the closest equivalent in English being "Hey". This can precede or even take place of the traditional "你好" greeting, and partially serves as an attention-getter. However, if the pronunciation of "哎" (aì) is stretched/lengthened, it may sound as if you are complaining about something, which uses the same word.

### Vocabulary

  * 嗨 / hài = hi
  * 去 / qù = go
  * 哪儿 （哪兒） / nǎr = where
  * 图书馆 (圖書館） / túshūguǎn = library
  * 再见 （再見 / zàijiàn = bye, goodbye (literally: see you again)

* * *

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lesson 7: 这是什么? What's this?

### Text 1

_You can check out the translations here._

  * ![About this sound](//upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Loudspeaker.svg/11px-Loudspeaker.svg.png) [Listen to audio](//upload.wikimedia.org/wikibooks/en/b/ba/Chinese-lesson-7-dialogue-1.ogg) ([help](//en.wikipedia.org/wiki/Wikipedia:Media_help)·[info](/wiki/File:Chinese-lesson-7-dialogue-1.ogg))

王明：这是什么？  


李红：这是书。  
王明：那是什么？  
李红：那是钢笔。  
王明：那是杂志吗？  
李红：不，那不是杂志。那是字典。  


Wáng Míng: Zhè shì shěnme?  
Lǐ Hóng: Zhè shì shū.  
Wáng Míng: Nà shì shěnme?  
Lǐ Hóng: Nà shì gāngbǐ.  
Wáng Míng: Nà shì zázhì ma?  
Lǐ Hóng: Bù, nà bùshì zázhì. Nà shì zìdiǎn.  


### Text 2

  * ![About this sound](//upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Loudspeaker.svg/11px-Loudspeaker.svg.png) [Listen to audio](//upload.wikimedia.org/wikibooks/en/0/05/Chinese-lesson-7-dialogue-2.ogg) ([help](//en.wikipedia.org/wiki/Wikipedia:Media_help)·[info](/wiki/File:Chinese-lesson-7-dialogue-2.ogg))

王明是中国人。  


王明是学生。  
史密斯是美国人。  
史密斯是王明的朋友。  
史密斯是律师。  


Wáng Míng shì Zhōngguórén.  


Wáng Míng shì xuéshēng.  
Shīmìsī shì Měiguórén.  
Shīmìsī shì Wángmíng de péngyǒu.  
Shīmìsī shì lǜshī.  


### Vocabulary

  * 王明 (Wáng Míng)
_n._ Wang Ming [personal name] [Wang= Family Name, Ming=First name/Personal name]

  * 李红／李紅 (Lǐ Hóng)
_n._ Li Hong [personal name] [Li= Family Name, Hong= First/Personal name]

  * 这/這 (zhè)
_pron._ this

  * 是 (shì)
_v._ to be (is/are)

  * 什么／甚麼 (_Mainland_ shěnme  
and _Taiwan_ shěme)
_pron._ what

  * 那 (nà)
_pron._ that

  * 笔 (bǐ)
_n._ pen; a generic term for all pens

  * 钢笔 (gāngbǐ)
_n._ fountain pen

  * 铅笔 (qiānbǐ)
_n._ pencil

  * 原子笔 (yuánzíbǐ)
_n._ ballpoint pen

  * 毛笔 (máobǐ)
_n._ brush (calligraphy pen)

  * 杂志 (zázhì)
_n._ magazine

  * 报纸 (bàozhī)
_n._ newspaper

  * 书本 (shūběn)
_n._ book

  * 传单 (chuándān)
_n._ pamphlet

  * 吗 (ma)
final interrogative particle used  
to form a question sentence

  * 不 (bù)
_adv._ no

  * 字典 (zìdiǎn)
_n._ dictionary

  * 人 (rén)
_n._ person/people

  * 中国人 (Zhōngguórén)
_n._ PRC Chinese (中国：China　人：people)

  * 外国人 (WàiGuórén)
_n._ Foreigners (外：Outside　国：Country　人：People)

  * 日本人 (Rìběnrén)
_n._ Japanese (日本：Japan 人：People)

  * 英国人 (Yīngguórén)
_n._ British (英国：Britain 人：People)

  * 新加坡人 (Xīnjiāpōrén)
_n._ Singaporean （新加坡：Singapore)

  * 美国人 (měiguórén)
_n._ American

  * 学生 (xuéshēng)
_n._ student

  * 老师 (lǎoshī)
_n._ teacher

  * 校长 (xiàozhǎng)
_n._ principal

  * 史密斯 (Shǐmìsī)
_n._ Smith

  * 美国人 (Měiguórén)
_n._ American

  * 朋友 (péngyǒu)
_n._ friend

  * 律师 (lǜshī)
_n._ lawyer

  * 笔记本/筆記本 (bǐjìběn)
  * 铅笔/鉛筆 (qiānbǐ)
  * 英国人/英國人 (Yīngguórén)
  * 法国人/法國人 (Fǎguórén)
  * 报纸/報紙 (bàozhǐ)
  * 老师/老師 (lǎoshī)
  * 作家 (zuòjiā)

_n._ notepads  
_n._ pencil  
_n._ British people  
_n._ French people  
_n._ newspaper  
_n._ teacher  
_n._ writer  


#### Stroke orders

    ![王-bw.png](//upload.wikimedia.org/wikipedia/commons/thumb/c/ca/%E7%8E%8B-bw.png/250px-%E7%8E%8B-bw.png)
    ![明-bw.png](//upload.wikimedia.org/wikipedia/commons/thumb/e/e2/%E6%98%8E-bw.png/450px-%E6%98%8E-bw.png)
    ![李-bw.png](//upload.wikimedia.org/wikipedia/commons/thumb/e/e1/%E6%9D%8E-bw.png/400px-%E6%9D%8E-bw.png)

_More [stroke orders](//commons.wikimedia.org/wiki/Category:Chinese_stroke_order_in_BW_pictures) will be added if it's helpful._

## Grammar

### Chinese Names

In Chinese names, the family name comes before the given name. Family names are passed down paternally and usually have only one character. Chinese given names are usually two characters long, but may also be one character. 

Hence a man called 王明 (Wáng Míng) is addressed as Mr. Wang, not Mr. Ming. A woman called 李红 (Lǐ Hóng) is addressed as Mrs./Miss Li.

However, if the person has a western personal name, it is presented in the GIVEN-NAME/FAMILY-NAME format, following the Western convention. Hence if 李红 (Lǐ Hóng) has a western-style personal name of Mary, she is usually introduced as "Mary Li" and not "Li Mary"

  


In this lesson, we learn how to say "something is something" in Chinese. The first thing you need to know is that the sentence structure of Chinese is very similar to that of English in that they both follow the pattern of Subject-Verb-Object (SVO). But unlike many Western languages, verbs in Chinese aren't conjugated and noun and adjective endings don't change. They are never affected by things such as time or person.

### 这(/那)是什么？

This sentence means "What's this/that?":

  1. 这是什么？(What's this?)
  2. 那是什么？(What's that?)

The sentences, if broken down literally, shows that the ordering of words differs in English and Chinese:

这/那
是
什么
 ?

this/that
is
what
 ?

The order of the sentences may seem a little bit tricky, but don't worry about that, we will discuss this later.

### A　是　B

This sentence means "A is B."

"是" (shì), the equational verb _to be_, can be used as the English _is_ or _equals_. When used in a simple Subject-Verb-Object sentence, the subject defines the object. Since Chinese verbs never change, no other forms for shì exist such as _was_ or _am_ in English. Also, articles like _a_ and _the_ are absent in Chinese. They are not translated.

For example:

  1. 这是书 (zhe4 shi4 shu1): this is (a) book.
  2. 那是杂志 (na4 shi4 za2 zhi4): that is (a) magazine.

### A　不是　B

This sentence means "A is not B." in which shì is negated when preceded by "不" (bu). "不" literally means "no", "not".

For example:

  * 这不是书 (zhè bú shì shū): this is not (a) book.

Now, we come back to the "what's this/that?" questions. We already see that the order is a bit tricky comparing to the English question order. But comparing to the latter pattern "A　是　B", we find the similarity: their orders are identically the same. In fact, like particles, question words make statements into questions without changing the order of the sentence. To make one, simply substitute the QW in for place the subject would be in the answer.

Comparison:

  1. 这是**书**。(This is (a) book.)
  2. 这是**什么**？(This is **what**?)
  1. 那是**杂志**。(That is (a) magazine.)
  2. 那是**什么**？(That is **what**?)

### 吗

"吗"(ma) is a final interrogative particle used to form a question sentence. Adding this character at the end of a **statement** transforms the sentence into a question.

Example 1:

  * 这是书 (zhe4 shi4 shu1)。(This is (a) book.) 

    

    

    

    ↓
    * 这是书**吗** (zhe4 shi4 shu1 ma)？(Is this (a) book**?**)

Example 2:

  * 这不是杂志 (zhe4 bu2 shi4 za2 zhi4)。(This is not (a) magazine.) 

    

    

    

    ↓
    * 这不是杂志**吗**(zhe4 bu2 shi4 za2 zhi4 ma)？(Isn't this (a) magazine**?**)

### 是/不

"是" (shi4) can be used to answer a simple yes/no question. In this case, "是" means _yes_, whilst "不" (bu2) or "不是" (bu2 shi4) means _no_ (literally, _not is_).

How to answer yes/no questions correctly in Chinese? Usually, it's the same as in English, but pay attention if the questions are negative, like "Isn't this a book?". In Chinese, you answer to the questions, not the fact. If the question itself is a negative answer, use "不是" or simply "不", vice versa. For example:

  * A: 这不是书吗？zhe4 bu2 shi4 shu1 ma? (Isn't this (a) book? = This is not a book, right?) 
    * B: **是**，这不是书。shi4, zhe4 bu2 shi4 shu1. (**No**, this is not (a) book. = You are right; this is not a book.)
    * B: **不**，这是书。bu4, zhe4 shi4 shu1. (**Yes**, this is (a) book. = You're wrong; this _is_ a book.)

A asks if that's a book in a negative way. If the object is not a book, you should nevertheless approve A's saying first. So we use "是" to acknowledge that A is correct, and then say "this is not (a) book" to emphasis A is right; In the case of that is a book, you should deny A's saying first, using "不" (no) to point out A is wrong, then make a new statement by noting that "这是书" (this _is_ (a) book). One more example:

  * 他今天晚上不来参加宴会了，对吗？(He's not going to the party tonight, is he?) 
    * **不**，他肯定要来。(**Yes**, he's definitely coming.)
    * **是** 啊，他很忙呢！(**No**, he's so busy!)

### 的

Character "的" (de) indicates that the previous word has possession of the next one. In English it functions like '_s_ or like the word _of_ but with the position of possessor and possessee switched. For example:

  1. 史密斯(Shǐ mì Sī)的书(shū: book) <-> Smith's book
  2. 王明的钢笔 <-> Wang Ming's pen
  3. 约翰** (Yuēhàn: John)的朋友** (péngyǒu: friend) <-> John's friend or a friend of John's

## Exercise

  1. Replace the underline words, and practice. 
    1. 史密斯是_美国人_。 
      * 英国人
      * 法国人
    2. 这不是_杂志_。 
      * 书
      * 笔记本*
      * 铅笔
  2. Replace the underline words, and then answer the questions with both positive answers and negative answers. 
    * Example:
    * 史密斯是_法国人_吗？ 
      * 是，史密斯是_法国人_。
      * 不，史密斯不是_法国人_。
    1. 那是_杂志_吗？ 
      * 钢笔
      * 铅笔
      * 报纸*
    2. 王明是_学生_吗？ 
      * 律师
      * 老师*
      * 作家*
  3. Translate the following English into Chinese. 
    1. Wang Ming is not a teacher. Wang Ming is a student. Wang Ming is a Chinese. Wang Ming is not an American. 
      * Answer(答):王明不是位老師，王明是位學生。王明是位中國人，(但)王民不是位美國人。
    2. Smith is a lawyer. Smith is not a writer. Smith is an American. Smith is not a French. 
      * Answer(答):Smith是位律師，Smith不是位作家。Smith是位美國人，Smith不是位法國人。
    3. This is Smith's book. That is Wang Ming's pen. 
      * Answer(答):這是Smith的書，那是王明(Wang Ming)的筆。

## Further reading

**Read the following article, and then answer the questions in Chinese.**

    你好(nǐhǎo, hello)，我(wǒ, I)是王明。我是学生，我是中国人。这是史密斯。史密斯是我的**1** 朋友，史密斯是律师。那是史密斯的妻子(qīzi, wife)，安娜(Ana)。安娜是我的英语(yīngyǔ, English language)老师。

    

    **1.**"我　的" means "my", we will discuss this in the next lesson.

**Questions:**

  1. Who is "I"?
  2. What does Smith do?
  3. Who is Ana?
  4. What does Ana do?

## Useful phrases

**Greetings. How to greet people in Chinese?**

  * 你好！(nǐhǎo): Hello!
  * 嗨！(hài): Hi!
  * 幸會 (xìng huì) Great to meet you!
  * 你吃过饭了吗？(nǐ chī guò fàn le ma?): Have you had your meal? (This is a causal greeting between friends etc. But it doesn't mean you are asked to a dinner! Another derivation of this phrase commonly used in Beijing is "你吃了吗？")
  * 再见。(zàijiàn): Goodbye
  * 拜拜。(bāibāi): Bye-bye
  * 回头见。(huítóu jiàn): See you later.

## Translation for the text

Chinese characters
Sentences breakdown
English translation

**Text 1**

王明：这是什么？  
(王明：這是什麼？)  
李红：这是书。  
(李紅：這是書。)  
王明：那是什么？  
(王明：那是什麼？)  
李红：那是钢笔。  
(李紅：那是鋼筆。)  
王明：那是杂志吗？  
(王明：那是雜誌嗎？)  
李红：不，那不是杂志。那是字典。  
(李紅：不，那不是雜誌。那是字典。)  


**Text 1**

Wang Ming: This is what?  
Li Hong: This is book.  
Wang Ming: That is what?  
Li Hong: That is pen.  
Wang Ming: That is magazine (_final interrogative particle_)?  
Li Hong: No, that not is magazine, this is dictionary.  


**Text 1**

Wang Ming: What's this?  
Li Hong: This is a book.  
Wang Ming: What's that?  
Li Hong: That's a pen.  
Wang Ming: Is this a magazine?  
Li Hong: No, that's not a magazine. That's a dictionary.  


**Text 2**

王明是中国人。  
王明是学生。  
史密斯是美国人。  
史密斯是王明　的　朋友。  
史密斯是律师。  


**Text 2**

Wang Ming is Chinese.  
Wang Ming is student.  
Smith is American.  
Smith is Wang Ming's friend.  
Smith is lawyer.  


**Text 2**

Wang Ming is a Chinese.  
Wang Ming is a student.  
Smith is an American.  
Smith is Wang Ming's friend.  
Smith is a lawyer.  


* * *

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lesson 8

# 她是谁？

## Dialogues

_You can check out the translation here_

### Dialogue 1

Simplified Characters Traditional Characters

杨勋：你今天好吗？  
何铭：我很好。  
杨勋：你吃饭了吗？  
何铭：还没。  
杨勋：要不要一起去吃饭？  
何铭：好啊。我昨天看到你跟一个女生去图书馆，她是谁？  
杨勋：她是我的女朋友，她叫陈洁。  
何铭：原来你有女朋友，这么厉害啊！  
杨勋：哪里，不敢当。我们要去哪里吃饭？  
何铭：都可以。

楊勳：你今天好嗎？  
何銘：我很好。  
楊勳：你吃飯了嗎？  
何銘：還沒。  
楊勳：要不要一起去吃飯？  
何銘：好啊。我昨天看到你跟一個女生去圖書館，她是誰？  
楊勳：她是我的女朋友，她叫陳潔。  
何銘：原來你有女朋友，這麼厲害啊！  
楊勳：哪裡，不敢當。我們要去哪裡吃飯？  
何銘：都可以。

Pīnyīn

Yáng Xūn: Nǐ jīn tiān hǎo mā?  
Hé Míng: Wǒ hěn hǎo.  
Yáng Xūn: Nǐ chī fàn le mā?  
Hé Míng: Hái méi.  
Yáng Xūn: Yào bú yào yì qǐ qù chī fàn?  
Hé Míng: Hǎo ā. Wǒ zuó tiān kàn dào nǐ gēn yī ge ǔ shēng qù tú shū guǎn, tā shì shuí?  
Yáng Xūn: Tā shì wǒ de nǚ péng yǒu, tā jiào chén jié.  
Hé Míng: Yuán lái nǐ yǒu nǚ péng yǒu, zhè me lì hài a!  
Yáng Xūn: Nǎ li, bù gǎn dāng. Wǒ mén yào qù nǎ lǐ chī fàn?  
Hé Míng: Dōu kě yǐ.  


### Dialogue 2

Simplified Characters Traditional Characters Pinyin

王明：我叫王明。你叫什么名字？  
李红：我叫李红。  
王明：她的名字是什么？  
李红：她的名字是周朱丽。  
王明：周朱麗是一个很好的名字。  
李红：是，但是我比较喜欢你的名字。  
王明：为什么比较喜欢我的名字？  
李红：因为你的名字听起来很聪明。  
王明：哪里，我不敢当。  


王明：我叫王明。你叫什麼名字？  
李紅：我叫李紅。  
王明：她的名字是什麼？  
李紅：她的名字是周朱麗。  
王明：周朱麗是一個很好的名字。  
李紅：是，但是我比較喜歡你的名字。  
王明：為什麼比較喜歡我的名字？  
李紅：因為你的名字聽起來很聰明。  
王明：哪裡，我不敢當。  


Wáng míng: Wǒ jiào wáng míng. Nǐ jiào shén me míng zì?  
Li hóng: Wǒ jiào li hóng.  
Wáng míng: Tā de míng zì shì shén me?  
Li hóng: Tā de míng zì shì zhōu zhū lì.  
Wáng míng: Zhōu zhū lì shì yī gè hěn hǎo de míng zì.  
Li hóng: Shì, dàn shì wǒ bǐ jiào xǐ huan nǐ de míng zì.  
Wáng míng: Wèi shé me bǐ jiào xǐ huan wǒ de míng zì?  
Li hóng: Yīn wèi nǐ de míng zì tīng qǐ lái hěn cōng míng.  
Wáng míng: Nǎ lǐ, wǒ bù gǎn dāng.  


## Vocabulary

Simplified Traditional (if diff.) Pīnyīn [Part of speech](/wiki/Chinese/Abbreviations) English [‍[m.](/wiki/Chinese/Abbreviations)‍]

1.
周朱丽
周朱麗
[Zhōu Zhūlì]]
(proper noun)
Person's Name

2.
但是
dànshì
(conjunction)
But, However

3.
比较
比較
bǐjiào
by comparison

4.
喜欢
喜歡
xǐhuan
(verb)
to like

5.
为什么
為什麼
[wèishénme
(adverb)
Why (lit. "because of what?").

6.
因为
因為
yīnwèi
(conjunction)
because

7.
听起来
聽起來
tīng qǐlai
(phrase)
Sounds like

8.
聪明
聰明
cōngmíng
(adjective)
intelligent

9.
哪里
哪裡
nǎli
(noun)
lit. Nowhere, can be used as a polite response to a complement.

10.
不敢当
不敢當
bùgǎndāng
(phrase)
I don't accept (not at all) / polite response to a compliment

11.
还没
還沒
háiméi
(conjunction)
not yet

12.
图书馆
圖書館
túshūguǎn
(noun)
library

13.
名字
míngzi
(noun)
name

14.
女朋友
nǚpéngyǒu
(noun)
girlfriend

15.
昨天
zuótiān
(noun)
yesterday

## Grammar

## Translation of the text

Chinese characters
Sentences breakdown
English translation

**Text 1**

楊勳：你今天好嗎?  
何銘：我很好。  
楊勳：你吃飯了嗎？  
何銘：還沒。  
楊勳：要不要一起去吃飯?  
何銘：好啊。我昨天看到你跟一個女生去圖書館,她是誰?  
楊勳: 她是我的女朋友,她叫陳潔。  
何銘: 原來你有女朋友,這麼厲害啊!  
楊勳: 哪裡, 不敢當。我們要去哪裡吃飯?  
何銘: 都可以。  


**Text 1**
**Text 1**

Yang Xun: How are you today?  
He Ming: I'm very good.  
Yang Xun: Have you eaten yet?  
He Ming: Not yet.  
Yang Xun: Would you like to go eat together?  
He Ming: Sure. Yesterday, I saw you going to the library with a girl, who is she?  
Yang Xun: She is my girlfriend, her name is Chen Jie.  
He Ming: All along you have had a girlfriend, it's so good!  
Yang Xun: Thanks, that's flattering. Where do you want to go to eat?  
He Ming: Anywhere is fine.  


* * *

* * *

Chinese characters
Sentences breakdown
English translation

**Text 2**

王明：我叫王明。你叫什麼名字？  
李紅：我叫李紅。  
王明：她的名字是什麼？  
李紅：她的名字是周朱麗。  
王明：周朱麗是一個很好的名字。  
李紅：是, 但是我比較喜歡你的名字。  
王明: 為什麼比較喜歡我的名字?  
李紅: 因為你的名字聽起來很聰明。  
王明: 哪裡, 我不敢當。  


**Text 2**

Wang Ming: I called Wang Ming. You called what name?  
Li Hong: I called Li Hong.  
Wang Ming: Her name is what?  
Li Hong: Her name is Zhou Zhuli.  
Wang Ming: Zhou Zhuli is very good name.  
Li Hong: Yes, but I relatively (implied: more) like your name.  
Wang Ming: Why (lit: for what) relatively like my name?  
Li Hong: Because your name sounds (lit: hear-startup, hear-start-come) intelligent.  
Wang Ming: Where, I don't dare to be so.  


**Text 2**

Wang Ming: My name is Wang Ming. What is your name?  
Li Hong: My name is Li Hong.  
Wang Ming: What is her name?  
Li Hong: Her name is Zhou Zhuli.  
Wang Ming: Zhou Zhuli is a very good name.  
Li Hong: Yes, but I like your name better.  
Wang Ming: Why do you like my name better?  
Li Hong: Because your name sounds very intelligent.  
Wang Ming: Oh no, I wouldn't say that.  


  


Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

# Lesson 9: 請問火車站在哪裡？

## Dialogues

### Dialogue 1

(濃濃開車中，碰到路人妙妙)

濃濃：不好意思，請問火車站在哪裡？  


妙妙：往前開，遇到紅綠燈右轉，它就在你的左手邊。  
濃濃：這樣大約要花多久時間呢？  
妙妙：大概要花十分鐘。  
濃濃：所以是往前開，紅綠燈右轉，車站在我的左邊，大概十分鐘囉?  
妙妙：是這樣沒錯。  
濃濃：非常感謝你。  


(Nóng Nóng: kāichē zhōng, pèngdào lùrén Miào Miào)  
Nóng Nóng: bùhǎoyìsi, qǐngwèn huǒchēzhàn zài nǎlǐ?  
Miào Miào: wǎngqián kāi yùdào hónglǜdēng yòuzhuǎn tā jiù zài nǐde zuǒshǒu bian.  
Nóng Nóng: zhèyàng dàyuē yào huā duōjiǔ shíjiān ne?  
Miào Miào: dàgài yào huā shífēn zhōng.  
Nóng Nóng: suǒyǐ shì wǎngqián kāi, hónglǜdēng yòuzhuǎn, chēzhàn zài wǒde zuǒbian, dàgài shífēn zhōng luo?  
Miào Miào: shì zhèyàng méicuò.  
Nóng Nóng: fēicháng gǎnxiè nǐ.  


### Dialogue 2

(天龍在跟"話多且頻尿的"陳阿捷問路中…以下是對話)

天龍：不好意思，請問火車站怎麼走？  


腦子進水阿捷：恩…你可以再說一遍嗎？。  
天龍：不好意思，請問火車站怎麼走？。  
腦子進水阿捷：哦!你好，我不是真理大學的學生。  
天龍：……。  


(Tiān Lóng zài gēn "huà duō qiě pín suī de" Chén A Jié wènlù zhōng yǐxià shì duìhuà)  
Tiān Lóng: bù hǎo yìsi, qǐngwèn huǒchēzhàn zěnme zǒu?  
Nǎozi jìnshuǐ A Jié: ēn, nǐ kěyǐ zài shuō yībiàn ma?  
Tiān Lóng: bù hǎo yìsi, qǐngwèn huǒchēzhàn zěnme zǒu?  
Nǎozi jìnshuǐ A Jié: O! Nǐ hǎo, wǒ bùshi zhēnlǐ dàxué de xuésheng.  
Tiān Lóng: .......  


### Vocabulary

Traditional (simplified)

不好意思 (不好意思)(bùhǎo yìsi) _phrase_sorry / to feel embarrassed  
請問 (请问)(qǐngwèn) _phrase_may I ask...  
火車站 (火车站)(huǒchē zhàn) _phrase_train station  
開車 （开车)(kāichē) to drive a car  
碰到 (碰到)(pèngdào) to come across  
路人 (路人) (lùrén) passerby  
往前 (往前)(wǎngqián) to move forwards  
紅綠燈 (红绿灯)(hónglǜdēng) _noun_traffic light  


# Taiwan - 第十一课：台湾

## Traditional Characters

台灣是一個海島。  
台灣的主要語言是中文 (繁體中文)。  
它有各種文化，有名的特產。  
它處於大陸架上。所以有海鮮。  
它有山脈，所以有美麗風景。  


## Simplified Characters

台湾是一个海岛。  
台湾的主要语言是中文 (繁体中文)。  
它有各种文化，有名的特产。  
它处于大陆架上。所以有海鲜。  
它有山脉，所以有美丽风景。  


## English

Taiwan is an island.  
Its main language is Chinese (Traditional Chinese).  
It has a variety kinds of culture, famous local products.  
It is on the continental shelf. So there is seafood.  
It has mountains, it has beautiful scenery.

# Vocabulary

东南 dōngnán south east  
山脉 shānmài mountain  
特产 tèchǎn local products  
海鲜 hǎixiān seafood  
大陆架 dàlùjià continental shelf  
风景 fēngjǐng scenery  
文化 wénhuà culture

# Grammar

美丽<s>的</s>风景/beautiful scenery  
Sometimes Chinese people drop the ‘的’for adjectives. They will say ‘美丽风景’ and ‘免费图书（Free book）’[Chinese (Mandarin)/Mandarin is so interesting](/w/index.php?title=Chinese_\(Mandarin\)/Mandarin_is_so_interesting&action=edit&redlink=1) [Chinese (Mandarin)/I'm sick](/w/index.php?title=Chinese_\(Mandarin\)/I%27m_sick&action=edit&redlink=1) [Chinese (Mandarin)/Drinking tea](/w/index.php?title=Chinese_\(Mandarin\)/Drinking_tea&action=edit&redlink=1) [Chinese (Mandarin)/China](/w/index.php?title=Chinese_\(Mandarin\)/China&action=edit&redlink=1)

## Appendices / 附录

## Chinese languages

### Chinese, Cantonese (Sinitic)

_Note: Cantonese is a tonal language. Pronunciations provided below_

include numbers indicating tone. Tone 1 is high and level/falling; 2 is medium and rising;

3 is medium and level; 4 is low and falling; 5 is low and rising, 6 is low and level. For

more info, see Standard Cantonese. The characters shown are Traditional Chinese

characters. Pronunciation is given using Jyutping and IPA. However, non-use of the tones will not hinder comprehension for such simple

phrases.

Translation Phrase Jyutping IPA

Cantonese:
廣東話
_gwong2 dung1 waa2_
/kwɔːŋ2 tʊŋ1 wɑː2/

hello
你好
_nei5 hou2_
/nei5 hou2/

good-bye
再見
_zoi3 gin3_
/tsɔːi3 kiːn3/

bye-bye
拜拜
_baai1 baai3_
/pɑːi1 pɑːi3/

please
唔該
_m4 goi1_
/m̩4 kɔːi1/

thank you (for gifts)
多謝
_do1 ze3_
/tɔː1 tsɛː3/

thank you (for services rendered)
唔該
_m4 goi1_
/m̩4 kɔːi1/

sorry
對唔住
_deoi3 m4 zyu6_
/dɵy3 m̩4 tsyː6/

this one
呢個
_ni1 go3_ or _nei1 go3_
/niː1 kɔː3/ or /nei1 kɔː3/

that one
嗰個
_go2 go3_
/kɔː2 kɔː3/

how much/many? (ask for quantity)
有幾多個呀
_yau5 gei2 do1 go3 aa3_
/jɐu5 kei2 tɔː1 kɔː3 ɑː3/

how much? (ask for amount of money)
幾多錢呀
_gei2 do1 cin2 aa3_
/kei2 tɔː1 ts̚in2 ɑː3/

yes
係
_hai6_
/hɐi6/

no
唔係
_m4 hai6_
/m̩4 hɐi6/

correct/right
啱
_am1_
/a:m1/

incorrect/wrong
唔啱
_m4 am1_
/m̩4 a:m1/

I don’t understand
我唔明
_ngo5 m4 ming4_
/ŋɔː5 m̩4 mɪŋ4/

Where's the washroom (toilet, lavatory)?
洗手間喺邊度呀？
_sai2 sau2 gaan1 hai2 bin1 dou6 aa3_
/sɐi2 sɐu2 kɑːn1 hɐi2 piːn1 tou6 ɑː3/

Do you speak English?
你識唔識講英文呀？
_nei5 sik1 m4 sik1 gong2 jing1 man2 aa3_
/nei5 sɪk1 m̩4 sɪk1 kɔːŋ2 jɪŋ1 mɐn2 ɑː3/

Note: Cantonese, like most of the other Chinese languages, does not actually have words for

“yes” and “no”. Translations for “yes” and “no” given above actually mean “it is” and “it

is not” and can be used for questions asking for confirmation. However, for certain yes/no

questions, one would normally respond with the verb or the negation of the verb. For

instance, to respond to a question such as “do you want to go?” one would respond with

“want” or “not want”.

### Chinese, Mandarin (Sinitic)

_Note || Mandarin Chinese is a tonal language. Tone 1 (e.g. mā) is high and level; 2 (e.g., má) is rising; 3 (e.g., mǎ) is low dipping; 4 (e.g., mà) is falling. Also note that the first set of characters preceding the slashes are in simplified Chinese characters and the ones following the slashes are in traditional characters. If the simplified- and traditional-character versions of a phrase are identical, only one phrase is shown._

Translation Phrase Pinyin IPA Pronunciation Remarks Literal meaning

Mandarin Chinese
国语 / 國語or  
普通话 / 普通話
(_[Guóyǔ](/wiki/Pinyin/Vocabulary#G)_)  
(_[Pǔtōnghuà](/wiki/Pinyin/Vocabulary#P)_)

[kwɔ̌ jỳ]  
[pʰù tʰʊ̋ŋ xwɑ̂] || (gwo yu)  
(poo-toong-hwa) || National

language  
Common speech

hello
你好
(_[ní hǎo](/wiki/Pinyin/Vocabulary#N)_)
[nǐ xàw]
(knee-how)
You're good

good-bye
再见 / 再見
(_[zàijiàn](/wiki/Pinyin/Vocabulary#Z)_)
[tsâj ʨjɛ̂n]
(dzai-jyen)
Meet again, 

lit “to the next sighting”

please
请 / 請
(_[qǐng](/wiki/Pinyin/Vocabulary#Q)_)
[ʨʰìŋ]
(cheeng)

thank you
谢谢 / 謝謝
(_[xièxie](/wiki/Pinyin/Vocabulary#X)_)
[ɕjɛ̂-ɕjɛ̂]
(shyeh-shyeh)

good morning
早安
(_[zǎo'ān](/wiki/Pinyin/Vocabulary#Z)_)

good night
晚安
(_[wǎn'ān](/wiki/Pinyin/Vocabulary#W)_)

good luck
（祝你）好运 / （祝你)好運
(_([zhù](/wiki/Pinyin/Vocabulary#Z) [nǐ](/wiki/Pinyin/Vocabulary#N)) [hǎoyùn](/wiki/Pinyin/Vocabulary#H)_)

that one
那个 / 那個
(_[nèige](/wiki/Pinyin/Vocabulary#N)_)
[nêj gə]
(nay guh)
_See Usage Note_

1

sorry
对不起 / 對不起
(_[duìbuqǐ](/wiki/Pinyin/Vocabulary#D)_)
(dway boo chee)

no problem
没关系 / 沒關係
(_[méiguānxì](/wiki/Pinyin/Vocabulary#M)_)
(may gwan shee)

how much?
多少
(_[duōshǎo](/wiki/Pinyin/Vocabulary#D)_)
[twɔ̋ ʂàw]
(dwo shahw)
Many few

English
英文
(_[Yīngwén](/wiki/Pinyin/Vocabulary#Y)_)
[jɪ̋ŋ wə̌n]
(ing wen)

Can you speak English?
你会说英文吗 / 你會說英文嗎
_[Nǐ](/wiki/Pinyin/Vocabulary#N) [huì](/wiki/Pinyin/Vocabulary#H) [shuō](/wiki/Pinyin/Vocabulary#S) [Yīngwén](/wiki/Pinyin/Vocabulary#Y) [ma?](/wiki/Pinyin/Vocabulary#M)_

yes
是
('['shì](/wiki/Pinyin/Vocabulary#S)_)_
/ʂɻ̂/
(sher as in sherpa)
_See Usage Note 2_

[It] is

no
不
(_[bù](/wiki/Pinyin/Vocabulary#B)_)
[pû]
(boo)

where's the toilet?
厕所在哪里 / 廁所在哪裏
(_[cèsuǒ](/wiki/Pinyin/Vocabulary#C) [zài](/wiki/Pinyin/Vocabulary#Z) [nǎli](/wiki/Pinyin/Vocabulary#N)?_)
[tsʰɤ̂ swɔ̀ tsâj nɑ̌

lì] ||(tsuh swo dzai nah lee?) || _Not the politest, but you'll get your point across!_

Bathroom at/in where

generic toast
干杯 / 乾杯
(_[gānbēi](/wiki/Pinyin/Vocabulary#G)_)
[ka̋n pe̋j]
(gahn bay)
Dry 

glass/cup

  1. The second syllable of “nèi**[ge](/wiki/Pinyin/Vocabulary#G)**” is actually a generic [measure word](//en.wikipedia.org/wiki/measure_word); it is replaced by the appropriate measure word for the noun it refers to. You may therefore hear a number of different syllables after the initial **[nèi](/wiki/Pinyin/Vocabulary#N)**. In many parts of southern China, nèi is also pronounced **[nà](/wiki/Pinyin/Vocabulary#N)**.
  2. This actually means “it is” and can only be used in an answer to a question with the verb “to be” (in casual speech, this can be neglected). Languages like Chinese, Irish, Toki Pona, and Welsh do not have words for “yes” or “no”. Instead you repeat the main verb of the question in your answer. Shaking your head in affirmation or negation works as expected, though speakers should ensure they are answering negative questions as literally asked – answering in the negative to “You don’t like him?” would indicate that you _do_ like him.

### Chinese, Shanghainese (Sinitic)

_Note: Chinese characters for Shanghainese are not standardized and are provided for reference only. IPA transcription is for the Middle period of modern Shanghainese (中派上海话), pronunciation of those between 20 and 60 years old._

translation Northern Wu Lumazi IPA Simplified Chinese

Shanghainese (language):
Zanheghaewo
Zanheireiwo
[zɑ̃.'he.ɦɛ.ɦʊ]
上海咸话

Shanghainese (people):
Zanhegnin
Zanheinin
[zɑ̃.'he.ɲɪɲ]
上海人

I
ghoo, gnou
wo, ngu
[ɦʊ], [ŋu]
我

we or I
álá
aelae
[ɐˑ.lɐʔ]
阿拉

he/she
ji
yi
[ɦi]
伊

they
jila
yila
[ɦi.la]
伊拉

you (sing.)
non
non
[noŋ]
侬

you (plural)
na
na
[na]
人那

hello:
non ho
non ho
[noŋ hɔ]
侬好

good-bye:
tsewe
tzeiwei
[ˈtse.ɦue]
再会

thank you:
ziaja non
zhaya non
[ʑ̻ia.ja noŋ]
谢谢侬

sorry:
tevéchi
teivechi
[te.vəˑ.ʨʰi]
对勿起

but, however:
daezu, daezu ne
deizi, deizi nei
[dɛ.zɿ], [dɛ.zɿ.ne]
但是, 但是呢

please:
tshin
chin
[ʨʰɪɲ]
请

that one:
etsá, itsá
eitzae, itzae
[ˈe.tsɐʔ], [i.tsɐʔ]
哎只, 伊只

there:
etá, itá
eitae, itae
[ˈe.tɐʔ], [i.tɐʔ]
哎耷, 伊耷

over there:
emitá, imitá
eimitae, imitae
[ˈe.mi.tɐʔ], [i.mi.tɐʔ]
哎米耷, 伊米耷

here:
gétá
getae
[gəˑ.tɐʔ]
搿耷

to have
jeuté
youte
[ɦiɤɯ.təʔ]
有得

to exist, here, present:
láhe
laehei
[lɐˑ.he]
辣海

now, current:
jieze
yizei
[ɦi.ze]
现在

what time is it?:
jieze citie tson?
yizei citi tzon?
[ɦi.ze ʨi.ti 'tsoŋ]
现在几点钟？

where:
ghalitá, sadifan
ralitae, sadifan
[ɦa.ɺi.tɐʔ], [sa.di.fɑ̃]
何里耷, 啥地方

what:
sa
sa
[sa]
啥

who:
sagnin
sanin
[sa.ɲɪɲ]
啥人

why:
wesa
weisa
[ɦue.sa]
为啥

when:
sazencuan
sazenkuan
[sa.zəɲ.kuɑ̃]
啥辰光

how:
nanen, nana, nanenca
nanen, nana, nanenka
[na.nəɲ], [na.na], [na.nəɲ.ka]
哪能, 哪哪, 哪能家

how much?:
cidie a?
cidi a?
[ʨi.di 'a]
几钿啊?

yes:
eh
ei
[ˈe]
哎

no:
m, vézu, mmé, vio
m, vezi, mme, vio
[m̩], [vəˑ.zɿ], [m̩məʔ], [viɔ]
呒、勿是、呒没

telephone number:
diewo ghodeu
diwo rodou
[di.ɦʊ ɦɔ.dɤɯ]
电话号头

home:
ólihian
oelishan
[oˑ.ɺi.ɕiã]
屋里向

Come to our house and play.
to álá ólihian le bésian.
to aelae oelishan lei beshan.
[tɔ ɐˑ.lɐʔ oˑ.ɺi.ɕiɑ̃ le

bəˑ.ɕiã]

到阿拉屋里向来孛相（白相）！

Where's the restroom?:
daseucae lélá ghalitá?
dasoukei lelae ralitae?
[da.sɤɯ.kɛ ɺəˑ.ɺɐʔ ɦa.ɺi.tɐʔ]
汏手间勒勒何里耷?

Have you eaten dinner?:
javae chícoulé va?
yavei chiekule va?
[ɦia.vɛ ʨʰɪˑ.ku.ləʔ va]
夜饭吃过了伐?

I don’t know:
ghoo véhioté.
wo veshote.
[ɦʊ vəˑ.ɕiɔ.təʔ]
我勿晓得

Do you speak English?:
non Inven weté can va?
non Inven weite kan va?
[noŋ ˈɪn.vəɲ ɦue.təʔ kã va]
侬英文会得讲伐?

I love you:
ghoo e non!
wo ei non.
[ɦʊ e noŋ]
我爱侬！

I adore you:
ghoo emó non.
wo eimoe non.
[ɦʊ e.moʔ noŋ]
我爱慕侬

I like you a lot:
ghoo lo huoehi non ghé!
wo lo hueushi non re.
[ɦʊ ɺɔ ˈhuø.ɕi noŋ ɦəʔ]
我老欢喜侬个！

news
sinven
shinven
[ɕɪɲ.vəɲ]
新闻

dead
sithélé
shithele
[ɕi.tʰəˑ.ləʔ]
死脱了

alive
wéláhe
welaehei
[ɦuəˑ.lɐˑ.he]
活辣海

Unlike Mandarin, Shanghainese actually has the direct “yes” (eh/ei) similar to English.

### Chinese, Min Nan / Taiwanese (Sinitic)

_The Han characters provided below are for reference only. They are not necessarily_

standard.

Translation Characters Romanization Remarks

Min Nan
閩南語
Bân-lâm-gú

Taiwanese
臺灣話
Tâi-oân-oē

Hokkien
福建話
Hok-kiàn-oē

Hello.
食飽未?
Chia̍h pá boeh?
(literally, _Eaten full yet?_ Note: This greeting 

came about at a time when most of Taiwan was in poverty, so to say that one has had enough

to eat would be to imply that the person is “doing well”.)

Goodbye.
平安
Pêng-an.
(literally, _Peace_, can also be used as a greeting; 

primarily Christian usage.)

Please
拜託
Pài-thok

Thank you
勞力
Ló·-la̍t
感謝 (Kám-siā) (literally, "be grateful for, praise") or 感恩 

(Kám-ún) is more common in Taiwan.

That one
彼個
Hit-ê

how much?
若濟?
goā choē?

is
是
Sī

not
唔是
m̄-sī
(literally, "not is")

Sorry
失禮
Sit-le

Embarrassed!
歹勢!
Pháiⁿ-sè!
(often used in response when offered/given something 

by a host)

I don't understand.
我聽無.
Goá thiaⁿ bô.
(literally, "I hear not")

Where's the bathroom?
便所佇叨?
Piān-só· tī toh?
(literally "bathroom is where?")

Cheers!
呼乾啦!
Hō· ta lah!
(literally, _Let it [the cup/glass] be dry_

[empty]!_)_

Do you speak English?
你咁講英語?
Lí kám kóng Eng-gú?

## Everyday Phrases

There are several phrases that may be useful to learn if you are going to visit China. All phrases have the Chinese characters as well as the pinyin spelling and tone intonation next to them. Pinyin is the convention officially adopted in China for transcribing Chinese characters into Western-style alphabet.

## Greetings

  * 你好　- _ni3hao3_ \- How are you; hello.
  * 很好　- _hen3hao3_ \- Very well.
  * 我还不错　- _wo3hai2bu4cuo4_ \- I'm OK (not bad).
  * 亲会 - _xing4hui4_ \- Very pleased to meet you (polite/formal address).
  * 早上好 - _zao3shang hao3_ \- Good morning.
  * 早安 - _zao3an1_ \- Good morning; have a peaceful morning.
  * 晚上好 - _wan3shang4 hao3_ \- Good evening.
  * 晚安- _wan3an1_ \- Good evening; have a peaceful evening.
  * 欢迎　- _huan1ying2_ \- Welcome.

  


## Yes and No

  * 是 - _shi4_ \- Yes; is so.
  * 对 - _dui4_ \- Yes; that's correct.
  * 不 - _bu4_ \- Not.
  * 不是 - _bu4shi4_ \- No; not so.
  * 唯 - _wei3_ \- Yes/Hello (only used when answering the phone).

  


## Please and Thank You

  * 请 - _qing3_ \- please (do something).
  * 谢谢 - _xie4xie_ \- Thank you.
  * 多谢 - _duo1xie4_ \- Thanks a lot.
  * 太客气 - _tai4ke4qi_ \- You are too courteous (polite).
  * 不敢当 - _bu4gan3dang1_ \- Thank you/_I dare not accept the honor_ (chivalrous, harking a former age).
  * 不客气 - _bu4ke4qi_ \- You are welcome/_no need for formalities_.
  * 别客气 - _bie2ke4qi_ \- You are welcome/_no need for formalities_.
  * 不谢 - _bu4xie4_ \- Not at all/no need to thank me.
  * 不用谢 - _bu4yong4xie4_ \- Not at all/no need to thank me.
  * 理当的 - _li3dang1de_ \- Certainly (it's only proper)/_"courtesy demands it"_ (formal).
  * 哪里 - _na3li3_ \- Not at all (informal).

  


## Getting Attention

  * 对不起 - _dui4buqi3_ \- Excuse me.

  


## Apology

  * 对不起 - _dui4buqi3_ \- Sorry.
  * 很对不起 - _hen3dui4buqi3_ \- Very sorry.

  


## Farewells

  * 再见。- _zai4jian4_ \- Goodbye; see you again.
  * 明天见 - _ming2tian1jian4_\- See you tomorrow.
  * 回头见。- _hui2tou2jian4_ \- See you.
  * 拜拜 - _baibai_ \- Borrowed from English, Bye Bye.

  


## Praise

  * 恭喜 - _gong1xi3_ \- Congratulations

  


## Toast

  * 干杯 - _gan1bei1_ \- Cheers; bottom's up.

  


## Finding the Bathroom

  * 请问厕所在哪儿? - _qing3wen4 ce4suo3 zai3 nar3_ \- Excuse me (may I ask), where is the toilet?
  * 请问洗手间在哪里? - _qing3wen4 xi3shou3jian1 zai3 na3li3_ \- Excuse me (may I ask), where is the washroom?
  * [Pinyin-Hanzi-English Chinese-English dictionary](/wiki/Pinyin/Vocabulary)
  * [WrittenChinese.Com Free Online Chinese-English Dictionary](http://dictionary.writtenchinese.com) Search results are ranked by frequency of occurrence in everyday Chinese text.
  * [Yahoo!奇摩字典](http://tw.dictionary.yahoo.com/)
  * [Multilingual Chinese Dictionary](http://www.chinese-dictionary.org/) 9 languages (English, French, German, Spanish, Italian, Russian...)
  * [Chinese <-> English](http://www.cozywebsite.com/dictionary/cedic/) Online Dictionary with Pinyin and Zhuyin.
  * [Chinese <-> Dictionary](http://www.chinese-tools.com/tools/dictionary.html) search in Chinese, pinyin or English
  * [zhongwen](http://www.zhongwen.com/m/search.htm) A Chinese Dictionary
  * [Ting Audio Dictionary](http://hua.umf.maine.edu/Chinese/search.html) Chinese English dictionary with Illustration sentences
  * [Chinese <-> English](http://nc.zhongda.org/dict) Online Dictionary with English pronunciation and Pinyin (Simplified Chinese简体)
  * [Chinese <-> English](http://www.chinese-course.com/) Online Dictionary with traditional characters and flashcards
  * [Chinese <-> French](http://www.chine-informations.com/mods/outils/dictionnairechinois/) Online Dictionary with flashcards

Please add all vocabulary that is used in this book, and any more that should be included in the first year's worth of Chinese lessons. This is not meant to be a full dictionary with thousands of entries (see Wiktionary for that), but a reference for users of this textbook.

Contents:

A B C D E F G H I J K L M N O P Q R S T U V W X Y Z  


## A

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## B

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

bad
坏 (壞)
huài
adj.

busy
忙
máng
(adj)
[2](/wiki/Chinese/Lesson_2)

bus [辆]
公共汽车  
(公共汽車)
gōnggòngqìchē
(n)

## C

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

car
汽车 (汽車)
qìchē
noun

city
城市
chéngshì
noun

computer
电脑 / 计算机 (電腦)
dìannǎo / jìsuànjī (diànnǎo)
noun

country
国家 (國家)
guójīa
noun

## D

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

dangerous
危险 (危險)
wēixǐan
adj.

dog
狗
gǒu
noun

## E

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## F

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

Frog
青蛙
qingwa
noun

Fish
魚
yu
noun

French
法國
faguo
noun

## G

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

good
好
hǎo
adj.

## H

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## I

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## J

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## K

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

knife
刀
dāo
noun

## L

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

land
地
di
noun

love
爱 (愛)
ài
verb

## M

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

meter (metric unit)
米
mǐ
rice

money
钱
qián
noun

mountain
山
shān
noun

## N

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

now
现在 (現在)
xìanzaì
noun

## O

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## P

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

please
请 (請)
qǐng
verb

## Q

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## R

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

rice
米
mǐ
noun

person
人
rén
noun

## S

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## T

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

sunny day
晴天
qíngtiān
noun

## U

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

up
上
shàng
noun

## V

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

volcano
火山
huǒshān
noun

## W

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

water
水
shuǐ
(noun)

we, us
我们 (我們)
wǒmen
(pro)
[1](/wiki/Chinese/Lesson_1)

week
星期, 周
xingqi, zhou
(noun)

what
什么 (什麼)
shénme
(pro)
[1](/wiki/Chinese/Lesson_1)

which, what
哪
nǎ; něi
(pro)
[1](/wiki/Chinese/Lesson_1)

who, whom
谁 (誰)
shéi; shuí
(pro)
[1](/wiki/Chinese/Lesson_1)

winter
冬天
dongtian
(n)

## X

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## Y

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

## Z

English Simp. (Trad.) Pīnyīn Part of speech Lesson Introduced

zebra
斑马 (斑馬)
bānmǎ
noun

  


Contents:

Top   A B C D E F G H I J K L M N O P Q R S T U V W X Y Z  


## Lesson1

### Matching Sentences

1c,2g,3d,4b,5f,6a,7h,8e

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Chinese, like all languages, has its own set of unique greetings which may be seemingly strange to learners of the language (this is particularly true if the two cultures are vastly different). Below, you will find commonly-used Mandarin greetings and farewells, along with corresponding [pinyin](/wiki/Pinyin) pronunciations.

## Hello

  * 你好。 [Nǐ hǎo](/wiki/Pinyin/Vocabulary#N); The standard "hello" greeting. Literally means "you good."
  * 您好。 [Nín hǎo](/wiki/Pinyin/Vocabulary#N); The same "hello" greeting as above, except that 您 ([nín](/wiki/Pinyin/Vocabulary#N)), like in many European languages, is the polite form of "you", used when addressing elders, or teachers etc.
  * 你好吗? [Nǐ hǎo ma?](/wiki/Pinyin/Vocabulary#N); More often used following a greeting than not, however, this can be used as a "hello" by itself.
  * 您好吗? [Nín hǎo ma?](/wiki/Pinyin/Vocabulary#N); The same as the "Nǐ hǎo ma?" above, again, except that this is used as a more polite form.
  * 你怎么样? [Nǐ zěnmeyàng?](/wiki/Pinyin/Vocabulary#N); "What's up?", "How are you doing?"
  * 幸会 [Xìnghuì](/wiki/Pinyin/Vocabulary#X)! "Nice to meet you!"
  * 久仰 [Jiǔyǎng](/wiki/Pinyin/Vocabulary#J); An extremely polite greeting that is not commonly used between friends, but rather between professionals meeting for the first time.
  * 久闻大名 [Jiǔwéndàmíng](/wiki/Pinyin/Vocabulary#J); This greeting should be reserved for use towards those whom you have _extreme_ respect for. Literal translation: "Your name is famous" / "I have heard much about you"

## Good morning

  * 早上好 [Zǎoshàng hǎo](/wiki/Pinyin/Vocabulary#Z); Standard morning greeting. Literally means "早上 [zǎoshang](/wiki/Pinyin/Vocabulary#Z)" (morning), "好 [hǎo](/wiki/Pinyin/Vocabulary#H)" (good).
  * 早 [Zǎo](/wiki/Pinyin/Vocabulary#Z); Also good morning.
  * 早安 [Zǎo'ān](/wiki/Pinyin/Vocabulary#Z); Literally "Peace at morning".

## Good afternoon

  * 下午好 [Xìawǔ hǎo](/wiki/Pinyin/Vocabulary#X)! Seldom used in the Republic of China.
  * 午安 [Wǔ'ān](/wiki/Pinyin/Vocabulary#W); _note_: seldom used in the Mainland. Most used in the Republic of China.

## Good evening / Good night

  * 晚上好 [Wǎnshang hǎo](/wiki/Pinyin/Vocabulary#W); Good evening!
  * 晚安 [Wǎn'ān](/wiki/Pinyin/Vocabulary#W); Literally "Peace at night", Good night.

## Good-bye

  * 再见 [Zàijiàn](/wiki/Pinyin/Vocabulary#Z); Literally "See you again".
  * 明天见 [Míngtiān jiàn](/wiki/Pinyin/Vocabulary#M); Literally "See you tomorrow".
  * 拜拜 [Báibái/bàibài/bāibai](/wiki/Pinyin/Vocabulary#B); From English "Bye-Bye". Widely used in Hong Kong, Taiwan (ROC) and most urbanised parts of mainland China. 掰掰 (Báibái/bàibài/bāibai) is the variant character form that is gaining popularity in ROC.
  * 回头见 [Huítóu jiàn](/wiki/Pinyin/Vocabulary#H): roughly equivalent to "see you soon", used in northern China.
  * 回见 [Huíjiàn](/wiki/Pinyin/Vocabulary#H); usually used in Beijing or written Chinese.
  * 再会 [Zàihuì](/wiki/Pinyin/Vocabulary#Z): Literally "[we'll] hello again". Usually used in Shanghai or other part of China, and sometimes used at the end of TV programs.

## Chinese New Year Greetings

  * [Xīnniánkuàilè](/wiki/Pinyin/Vocabulary#X) 新年快乐 [Happy New Year](//en.wikipedia.org/wiki/Chinese_New_Year#Greetings)
  * [Gōngxǐfācái](/wiki/Pinyin/Vocabulary#G) 恭喜发财 [Gongxifacai](//en.wikipedia.org/wiki/Gongxifacai)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

[^ Chinese ^](/wiki/Chinese:_Contents) | <<[Pronunciation of Finals](/wiki/Chinese/Pronunciation_of_Finals) | **Possible Initial-Final Combinations** | [Using Tones>>](/wiki/Chinese/Using_Tones)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

* * *

## Table of Possible Combinations of Chinese Initials and Finals

The table below shows all possible combinations of initials and finals in Pinyin (not including -r modified syllables). It also does not reflect the use of tones. Some combinations may only be valid with the use of one tone, while others may be valid with multiple tones.

Pinyin table Initials Pinyin table

(no initial) b p m f d t n l g k h j q x zh ch sh r z c s

Group a Finals (no final)
zhi
chi
shi
ri
zi
ci
si
(no final) Group a Finals

a
a
ba
pa
ma
fa
da
ta
na
la
ga
ka
ha
zha
cha
sha
za
ca
sa
a

o
o
bo
po
mo
fo
o

e
e
me
de
te
ne
le
ge
ke
he
zhe
che
she
re
ze
ce
se
e

ê
ê

ai
ai
bai
pai
mai
dai
tai
nai
lai
gai
kai
hai
zhai
chai
shai
zai
cai
sai
ai

ei
ei
bei
pei
mei
fei
dei
nei
lei
gei
hei
zhei
shei
zei
ei

ao
ao
bao
pao
mao
dao
tao
nao
lao
gao
kao
hao
zhao
chao
shao
rao
zao
cao
sao
ao

ou
ou
pou
mou
fou
dou
tou
nou
lou
gou
kou
hou
zhou
chou
shou
rou
zou
cou
sou
ou

an
an
ban
pan
man
fan
dan
tan
nan
lan
gan
kan
han
zhan
chan
shan
ran
zan
can
san
an

en
en
ben
pen
men
fen
nen
gen
ken
hen
zhen
chen
shen
ren
zen
cen
sen
en

ang
ang
bang
pang
mang
fang
dang
tang
nang
lang
gang
kang
hang
zhang
chang
shang
rang
zang
cang
sang
ang

eng
eng
beng
peng
meng
feng
deng
teng
neng
leng
geng
keng
heng
zheng
cheng
sheng
reng
zeng
ceng
seng
eng

er
er
er

Group i Finals i
yi
bi
pi
mi
di
ti
ni
li
ji
qi
xi
i Group i Finals

ia
ya
lia
jia
qia
xia
ia

io
yo
io

ie
ye
bie
pie
mie
die
tie
nie
lie
jie
qie
xie
ie

iai
yai
iai

iao
yao
biao
piao
miao
diao
tiao
niao
liao
jiao
qiao
xiao
iao

iu
you
miu
diu
niu
liu
jiu
qiu
xiu
iu

ian
yan
bian
pian
mian
dian
tian
nian
lian
jian
qian
xian
ian

in
yin
bin
pin
min
nin
lin
jin
qin
xin
in

iang
yang
niang
liang
jiang
qiang
xiang
iang

ing
ying
bing
ping
ming
ding
ting
ning
ling
jing
qing
xing
ing

Group u Finals u
wu
bu
pu
mu
fu
du
tu
nu
lu
gu
ku
hu
zhu
chu
shu
ru
zu
cu
su
u Group u Finals

ua
wa
gua
kua
hua
zhua
chua
shua
ua

uo
wo
duo
tuo
nuo
luo
guo
kuo
huo
zhuo
chuo
shuo
ruo
zuo
cuo
suo
uo

uai
wai
guai
kuai
huai
zhuai
chuai
shuai
uai

ui
wei
dui
tui
gui
kui
hui
zhui
chui
shui
rui
zui
cui
sui
ui

uan
wan
duan
tuan
nuan
luan
guan
kuan
huan
zhuan
chuan
shuan
ruan
zuan
cuan
suan
uan

un
wen
dun
tun
lun
gun
kun
hun
zhun
chun
shun
run
zun
cun
sun
un

uang
wang
guang
kuang
huang
zhuang
chuang
shuang
uang

ong
weng
dong
tong
nong
long
gong
kong
hong
zhong
chong
rong
zong
cong
song
ong

Group ü Finals ü
yu
nü
lü
ju
qu
xu
ü Group ü Finals

üe
yue
nüe
lüe
jue
que
xue
üe

üan
yuan
lüan
juan
quan
xuan
üan

ün
yun
lün
jun
qun
xun
ün

iong
yong
jiong
qiong
xiong
iong

Pinyin table (no initial) b p m f d t n l g k h j q x zh ch sh r z c s Pinyin table

Initials

    

    **Colour Legend:**

    

    

"regular" initial or final 

Final is in Group a or is a direct combination of:

  * i+Group a final
  * u+Group a final
  * ü+Group a final

Final of i, u, ü groups is a modified combination of: 

  * i+Group a final
  * u+Group a final
  * ü+Group a final

syllable is direct combination of initial and final (or follows rules for standalone initials and finals, explained in [pronunciation basics](/wiki/Chinese/Pinyin_Pronunciation))

syllable is modified combination of initial and final

    

    **Modified i, u, and ü group finals:**
    The following finals in the i, u, and ü groups are a modified combination of i, u or ü with a group a final: 

    

  * ie=i+ê
  * iu=i+ou
  * in=i+en
  * ing=i+eng
  * ui=u+ei
  * un=u+en
  * ong=u+eng
  * üe=ü+ê
  * ün=ü+en
  * iong=i+u+eng

  


* * *

[^ Chinese ^](/wiki/Chinese:_Contents) | <<[Pronunciation of Finals](/wiki/Chinese/Pronunciation_of_Finals) | **Possible Initial-Final Combinations** | [Using Tones>>](/wiki/Chinese/Using_Tones)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

## Number System (数字系统)

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Chinese Numerals**_](//en.wikipedia.org/wiki/Chinese_Numerals)

### 基本用字 Basic Characters

![About this sound](//upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Loudspeaker.svg/11px-Loudspeaker.svg.png) [Listen to audio](//upload.wikimedia.org/wikipedia/commons/2/2a/Zero_to_ten_in_Mandarin_Chinese.ogg) ([help](//en.wikipedia.org/wiki/Wikipedia:Media_help)·[info](/wiki/File:Zero_to_ten_in_Mandarin_Chinese.ogg))

  * 0: 〇 (零) líng
  * 1: 一 (壹) yī
  * 2: 二 (Simplified:贰;Traditional:貳) èr
  * 3: 三 (Simplified:叁;Traditional:叄、參) sān
  * 4: 四 (肆) sì
  * 5: 五 (伍) wǔ
  * 6: 六 (Simplified:陆;Traditional:陸) liù
  * 7: 七 (柒) qī
  * 8: 八 (捌) bā
  * 9: 九 (玖) jiǔ
  * 10: 十 (拾) shí
  * 100: 百 (佰) bǎi
  * 1000: 千 (仟) qiān
  * 10,000: Simplified:万;Traditional萬 wàn
  * 100,000,000: Simplified:亿;Traditional億 yì
  * 1,000,000,000,000: 兆 zhào

Parenthesized entries are the complex forms, which are used mainly in notarized, official documents, and when writing checks. An exception is zero; the complex form is more widely used. The complex forms are known in English as banker's anti-fraud numerals, in Chinese as 大写 _dà xiě_ (which is the same term for "capital letter"). They are necessary because, since normal Chinese characters are so simple, a forger could easily change 三十 to 五千 with just three strokes. Some have other uses as well (for example, 贰 _èr_ can also mean "to betray"). See [Standard numbers](//en.wikipedia.org/wiki/Chinese_numerals#Standard_numbers) for more information.

### 个十百千万 Larger Numbers

  * 十一 shí yī _(eleven)_
  * 十二 shí èr _(twelve)_

等等 (děngděng) etc.

  * 二十一 èr shí yī _(twenty-one)_
  * 二十二 èr shí èr _(twenty-two)_

等等 etc.

  * 一百 yī bǎi _(one hundred)_
  * 一百零一 yī bǎi líng yī _(one hundred one)_
  * 一百五十八 yī bǎi wǔ shí bā _(one hundred fifty eight)_
  * 二百三十 èr bǎi sān shí _(two hundred thirty)_

等等 etc.

  * 一千 yī qiān _(one thousand)_
  * 七千二百五十三 qī qiān liǎng bǎi wǔ shí sān _(seven thousand two hundred fifty-three)_

等等 etc.

  * 一万 yī wàn _(one myriad_ or _ten thousand)_
  * 四万三千 sì wàn sān qiān _(forty-three thousand)_

等等 etc.

## 更大的数字（亿兆） Even Larger Numbers

  * 一亿五千万 yī yì wǔ qiān wàn _150,000,000 (one hundred fifty million)_
  * 两亿零八十万 liǎng yì líng bā shí wàn _200,800,000_ (two hundred million eight hundred thousand)

等等 etc.

## 中文中零的用法 The Use of Zero in Chinese

If a number ends in zero, there is no need to include the zero character. For example,

  * 350: 三百五十
  * 1350: 一千三百五十
  * 1600: 一千六百

However, if the zero character does not end the number (i.e., it is followed by a non-zero character), it is necessary to include the zero character, while the "tens-place" characters are dropped. For example,

  * 305: 三百零五 (_not_ 三百零<s>十</s>五)
  * 1035: 一千零三十五 (_not_ 一千零<s>百</s>三十五)

Note that the "十" in the first example and the "百" in the second example are dropped.

If a zero digit is followed by one or more zero digits, only one zero character is need. For example,

  * 1006: 一千零六 (_not_ 一千零零六)
  * 300,250: 三十萬零二百五十
  * 8,000,300: 八百萬零三百

## 数字手势 Chinese Gestures for Numbers

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/3/32/Chinesische.Zahl.Eins.jpg/110px-Chinesische.Zahl.Eins.jpg)

1 一 yī

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Chinesische.Zahl.Zwei.jpg/115px-Chinesische.Zahl.Zwei.jpg)

2 二 èr

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Chinesische.Zahl.Drei.jpg/115px-Chinesische.Zahl.Drei.jpg)

3 三 sān

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Chinesische.Zahl.Vier.jpg/119px-Chinesische.Zahl.Vier.jpg)

4 四 sì

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Chinesische.Zahl.Fuenf.jpg/120px-Chinesische.Zahl.Fuenf.jpg)

5 五 wǔ

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Chinesische.Zahl.Sechs.jpg/120px-Chinesische.Zahl.Sechs.jpg)

6 六 liù

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Chinesische.Zahl.Sieben.jpg/120px-Chinesische.Zahl.Sieben.jpg)

7 七 qī (may be interpreted as 5 by Malaysian or Singaporean Chinese)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/9/94/Chinesische.Zahl.Acht.jpg/120px-Chinesische.Zahl.Acht.jpg)

8 八 bā (may be interpreted as 7 in some regions)

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/7/72/Chinesische.Zahl.Neun.jpg/120px-Chinesische.Zahl.Neun.jpg)

9 九 jiǔ

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/d/df/Chinesische.Zahl.Zehn.jpg/120px-Chinesische.Zahl.Zehn.jpg)

10 十 shí _or_ 0 零 líng

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Chinesische.Zahl.Zehn.zweiHaende.jpg/120px-Chinesische.Zahl.Zehn.zweiHaende.jpg)

10 十 shí

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Chinesische.Zahl.Zehn.gekreuzteFinger.jpg/120px-Chinesische.Zahl.Zehn.gekreuzteFinger.jpg)

10 十 shí

Note:

  * The gesture for nine is not used in Taiwan.
  * The third sign for ten is uncommon in both Taiwan and mainland China.

Source: [commons:数字手势](//commons.wikimedia.org/wiki/%E6%95%B0%E5%AD%97%E6%89%8B%E5%8A%BF)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

Here's a list of some nations and regions, with their names in Chinese. Note that the country's name can also be used as an adjective. For example, 日本货 (rìběn huò) means "Japanese goods," and is derived from 日本 (rìběn; Japan) and 货 (huò; goods). As an aside, China imports a good number of products from Japan. Between 2001 and 2007, it was the greatest exporter to China, beating the European Union, South Korea, and Taiwan.[1] You could also say 日本椅子 (rìběn yǐzi; Japanese chair), 日本食品 (rìběn shípǐn; Japanese food products), and 日本动画片 (rìběn dònghuà piàn; Japanese cartoons). Terms like these can be shortened, for example, 日货 means the same thing. You can see 日 is an adjective which means "pertaining to Japan," i.e., "Japanese." Another way to describe its function is that it acts like a "root," much like in English. Headlines are often abbreviated this way. For example, 中俄合作 (zhōng é hézuò) can mean "China and Russia cooperate" or "Sino-Russian cooperation." In common conversation, however, excessive abbreviation is undesirable, because it often leads to ambiguity.

References

## Asia 亚洲 / 亞洲 _Yàzhōu_

East Asia 东亚 / 東亞 _Dōngyă_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

China
中国
中國
_Zhōngguó_

Hong Kong
香港
_Xiānggăng_

Japan
日本
_Rìbĕn_

Macao
澳门
澳門
_Àomén_

North Korea
朝鲜 / 朝鲜 / 北韩
朝鮮 / 朝鮮 / 北韓
_Cháoxǐan / Běicháoxǐan / BěiHán_

South Korea
韩国 / 南韩 / 南朝鲜
韓國 / 南韓 / 南朝鮮
_Hánguó / Nánhán / Náncháoxǐan_

Taiwan
台湾
臺灣
_Táiwān_

Southeast Asia 东南亚 / 東南亞 _Dōngnányà_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Brunei
文莱
汶萊
_Wénlái (...Dálŭsàlángúo)_

Cambodia
柬埔寨
柬埔寨
_Jiănpŭzhài_

East Timor
东帝汶
東帝汶
_Dōngdìwèn_

Indonesia
印度尼西亚
印度尼西亞
_Yìndùníxīyă_ (also 印尼 _Yìnní_)

Laos
老挝/寮国
寮國
Lǎowō/_Liáoguó_

Malaysia
马来西亚
馬來西亞
_Măláixīyă_

Myanmar
缅甸
緬甸
_Miăndiàn_

Philippines
菲律宾
菲律賓
_Fēilǜbīn_

Singapore
新加坡
_Xīnjiāpō_

Thailand
泰国
泰國
_Tàiguó_

Vietnam
越南
_Yuènán_

South Asia 南亚 / 南亞 _Nányà_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Bangladesh
孟加拉国
孟加拉國
_Mèngjiālāguó_

Bhutan
不丹
_Bùdān_

India
印度
_Yìndù_ (not 印尼 _Yìnní_, Indonesia)

Maldives
马尔代夫
馬爾地夫(馬爾代夫)
_Mă'ěrdàifù_

Nepal
尼泊尔
尼泊爾
_Níbó'ěr_

Pakistan
巴基斯坦
_Bājīsītăn_

Sri Lanka
斯里兰卡
斯里蘭卡
_Sīlĭlánkă_

Central Asia 中亚 / 中亞 _Zhōngyà_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Afghanistan
阿富汗
_Āfùhàn_

Kazakhstan
哈萨克斯坦
哈薩克(哈薩克斯坦)
_Hāsàkèsītǎn_

Kyrgyzstan
吉尔吉斯坦
吉爾吉斯(吉爾吉斯坦)
_Jíěrjísīsītǎn_

Mongolia
蒙古
_Ménggŭ_

Tajikistan
塔吉克斯坦
塔吉克
_Tăjíkèsītǎn_

Turkmenistan
土库曼斯坦
土庫曼(土庫曼斯坦)
_Tŭkùmànsītǎn_

Uzbekistan
乌兹别克斯坦
烏茲別克(烏茲別克斯坦)
_Wūzībiékèsītǎn_

Southwest Asia (Middle East) 西南亚 (中东) / 西南亞 (中東) _Xīnányà_ (_Zhōngdōng_)

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Armenia
亚美尼亚
亞美尼亞
_Yàmĕiníyà_

Azerbaijan
阿塞拜疆
亞塞拜然
_Āsàibàijiāng_

Bahrain
巴林
_Bālín_

Cyprus
塞浦路斯
塞浦勒斯
_Sàipǔlùsī_

Georgia
格鲁吉亚
喬治亞
_Gélǔjíyà_

Iran
伊朗
_Yīlăng_

Iraq
伊拉克
_Yīlākè_

Israel
以色列
_Yǐsèliè_

Jordan
约旦
約旦
_Yuēdàn_

Kuwait
科威特
_Kēwēitè_

Lebanon
黎巴嫩
_Líbānèn_

Oman
阿曼
_Āmàn_

Qatar
卡塔尔
卡達
_Kǎtǎ'ĕr_

Saudi Arabia
沙特阿拉伯
沙烏地阿拉伯(沙特阿拉伯)
_Shātè'ālābó_

Syria
叙利亚
敘利亞
_Xùlìyà_

Turkey
土耳其
_Tǔ'ĕrqí_

United Arab Emirates
阿拉伯联合酋长国
阿拉伯聯合大公國(阿拉伯聯合酋長國)
_Ālābó Liánhé Qiúchángguó_

Yemen
也门
葉門(也門)
_Yĕmén_

## Oceania 大洋洲 _Dàyángzhōu_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Australia
澳大利亚
澳大利亞(澳洲)
_Àodàlìyà_

Kiribati
基里巴斯
吉里巴斯
_Jīlǐbāsī_

Fiji
斐济
斐濟
_Fěijì_

Marshall Islands
马绍尔群岛
馬紹爾群島
_Mǎshào'ěr Qúndǎo_

Micronesia
密克罗尼西亚
密克羅尼西亞
_Mìkèluóníxīyà_

Nauru
瑙鲁
諾魯
_Nǎolǔ_

New Zealand
纽西兰(新西兰)
紐西蘭(新西蘭)
_Niŭxīlán (Xīnxīlán)_

Palau
帕劳
帛琉(貝勞)
_Pàláo_

Papua New Guinea
巴布亚新几内亚
巴布亞新幾內亞
_Bābùyà Xīnjǐnèiyà_

Samoa
萨摩亚
薩摩亞
_Sàmóyà_

Solomon Islands
所罗门群岛
所羅門群島
_Suǒluómén Qúndǎo_

Tonga
汤加
東加(湯加)
_Tāngjiā_

Tuvalu
图瓦卢
吐瓦魯(圖瓦盧)
_Tùwǎlú (Túwǎlǔ)_

Vanuatu
瓦努阿图
萬那杜(瓦努阿圖)
_Wǎnǔ'ātú_

## America 美洲 _Měizhōu_

North America 北美洲 _Běi Měizhōu_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Canada
加拿大
_Jiānádà_

Cuba
古巴
_Gŭbā_

Mexico
墨西哥
_Mòxīgē_

United States
美国
美國
_Měiguó_

Central America 中美洲 _Zhōngměizhōu_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Belize
伯利兹
貝里斯
_Bólìzī/Bèilǐsī_

Costa Rica
哥斯达黎加
哥斯大黎加
_Gēsīdálíjīa_

El Salvador
萨尔瓦多
薩爾瓦多
_Sà'ěrwǎduō_

Guatemela
危地马拉
瓜地馬拉
_Wēidìmālā/Guādìmǎlā_

Honduras
洪都拉斯
宏都拉斯
_Hóngdūlāsī_

Nicaragua
尼加拉瓜
尼加拉瓜
_Níjiālāguā_

Panama
巴拿马
巴拿馬
_Bānámǎ_

Caribbean Islands 加勒比 Jiālèbǐ Qǔndǎo

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Antigua and Barbuda
安提瓜和巴不达
_Āntíguā hé Bābùdá_

Bahamas
巴哈马
巴哈馬
_Bāhāmǎ_

Barbados
巴巴多斯
_Bābāduōsī_

Dominica
多米尼加
多明尼加
_Duōmǐníjiā_

Dominican Republic
多米尼加共和国
多明尼加共和國
_Duōmǐníjiā Gònghéguó_

Grenada
格林纳达
格瑞那達
_Gélínnàdá/Géruìnàdá_

Haiti
海地
_Hǎidì_

Jamaica
牙买加
牙買加
_Yámǎijiā_

Puerto Rico
波多黎各
_Bōduōlígè_

St. Kitts and Nevis
圣基茨和尼维斯
_Shèngjīcí hé Níwéisī_

St. Lucia
圣卢西亚
聖露西亞
_Shèng Lúxīyà /Shèng Lùxīyà_

St. Vincent and the Grenadines
圣文森特和格林纳丁斯
聖文森
_Shèng Wénsēntè hé Gélínnàdīngsī_

Trinidad and Tobago
特里尼达和多巴哥
千里達
_Tèlǐnídá hé Duōbāgē/Qiānlǐdá_

South America 南美洲 _Nán Měizhōu_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Argentina
阿根廷
_Āgēntíng_

Bolivia
玻利维亚
玻利維亞
_Bōlìwéiyà_

Brazil
巴西
_Bāxī_

Chile
智利
_Zhìlì_

Colombia
哥伦比亚
哥倫比亞
_GēLúnBǐYà_

Ecuador
厄瓜多尔
厄瓜多爾
_Èguāduō'ěr_

Falkland Islands (UK)
马尔维纳斯群岛
福克蘭群島
_Mǎ'ěrwéinàsī Qúndǎo/Fúkèlán Qúndǎo_

French Guiana (France)
法属圭亚那
法屬蓋亞那
_Fáshǔ Guīyànà/Fàshǔ Guīyǎnà_

Guyana
圭亚那
蓋亞那(圭亞那)
_Guīyànà/Guīyǎnà_

Paraguay
巴拉圭
_Bālāguī_

Peru
秘鲁
秘魯
_BìLŭ_ (not _MìLŭ_)

Suriname
苏里南
蘇里南
_SŭLĭNán_

Uruguay
乌拉圭
烏拉圭
_Wūlāguī_

Venezuela
委内瑞拉
_Wěinèiruìlā_

## Europe 欧洲 / 歐洲 _Ōuzhōu_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Albania
阿尔巴尼亚
阿爾巴尼亞
_Ā'ěrbāníyà (mainland)  
Ā'ěrbāníya (Taiwan)_

Andorra
安道尔
安道爾
_Āndào'ěr_

Austria
奥地利
奧地利
_Àodìlì_

Armenia
亚美尼亚
亞美尼亞
_Yàměiníyà(mainland)̀  
Yǎměiníyǎ (Taiwan)_

Azerbaijan
阿塞拜疆
阿塞拜疆
_Āsàibàijiāng_

Belarus
白俄罗斯
白俄羅斯
_Bái'éluósī_

Belgium
比利时
比利時
_Bǐlìshí_

Bosnia and Herzegovina
波斯尼亚和黑塞哥维那
波士尼亞赫塞哥維納
_Bōsīníyǎ hé hēisāigēwéinà(mainland)  
Bōshìníyǎhèsāigēwéinà (Taiwan)_

Bulgaria
保加利亚
保加利亞
_Bǎojiālìyà (mainland)  
Bǎojiālìyǎ (Taiwan)_

Croatia
克罗地亚
克羅埃西亞
_Kèluódìyà (mainland)  
Kèluódìyǎ (Taiwan)_

Czech Republic
捷克
_Jiékè_

Denmark
丹麦
丹麥
_Dānmài_

Estonia
爱沙尼亚
愛沙尼亞
_Àishāníyà (mainland)  
Àishāníyǎ (Taiwan)_

France
法国
法國
_Fǎguó (mainland)  
Fàguó (Taiwan)_

Finland
芬兰
芬蘭
_Fēnlán_

Georgia
格鲁吉亚
佐治亞
_Gélǔjíyà (mainland)  
Zuǒzhìyǎ (Taiwan)_

Germany
德国
德國
_Déguó_

Greece
希腊
希臘
_Xīlà_

Hungary
匈牙利
匈牙利
_Xiōngyálì_

Iceland
冰岛
冰島
_Bīngdǎo_

Ireland
爱尔兰
愛爾蘭
_Ài'ěrlán_

Italy
意大利
_Yìdàlì_

Latvia
拉脱维亚
拉脫維亞
_Lātuōwéiyà (mainland)  
Lātuōwéiyǎ (Taiwan)_

Liechtenstein
列支敦士登
_Lièzhīdūnshìdēng_

Lithuania
立陶宛
_Lātáowǎn_

Luxembourg
卢森堡
盧森堡
_Lúsēnbǎo_

Macedonia
马其顿
馬其頓
_Mǎqídùn_

Malta
马耳他
馬耳他
_Mǎ'ěrtā_

Moldova
摩尔多瓦
摩爾多瓦
_Mó'ěrduōwā_

Monaco
摩纳哥
摩納哥
_Mónàgē_

Netherlands
荷兰
荷蘭
_Hélán_

Norway
挪威
_Nuówēi_

Poland
波兰
波蘭
_Bōlán_

Portugal
葡萄牙
_Pútáoyá_

Romania
罗马尼亚
羅馬尼亞
_Luómǎnǐyà_

Russia
俄罗斯
俄羅斯
_Éluósī_

San Marino
圣马力诺
聖馬力諾
_Shèng Mǎlìnuò_

Serbia and Montenegro
塞尔维亚和黑山
塞爾維亞和蒙特內哥羅
_Sài'érwéiyà hé HēIshān_

Slovakia
斯洛伐克
_Sīluòfákè_

Slovenia
斯洛文尼亚
斯洛維尼亞
_Sīluòwénníyà_

Spain
西班牙
_Xībānyá_

Switzerland
瑞士
_Ruìshì_

Sweden
瑞典
_Ruìdiǎn_

Turkey
土耳其
_Tǔ'ěrqí_

Ukraine
乌克兰
烏克蘭
_Wūkèlán_

United Kingdom
英国
英國
_Yīngguó_

## Africa 非洲 _Fēizhōu_

**English  
英文**
**Simplified  
简体字**
**Traditional  
繁體字**
**Pinyin  
拼音**

Algeria
阿尔及利亚
阿爾及利亞
_Ā'ěrjílìyà_

Angola
安哥拉
安哥拉
_Āngēlā_

Benin
贝宁
貝寧
_Bèiníng_

Botswana
博斯瓦纳
波札那
_Bósīwǎnà_

Burkina Faso
布基纳法索
布吉納法索
_Bùjīnàfǎsuǒ_

Burundi
布隆迪
蒲隆地
_Búlóngdí_

Cameroon
喀麦隆
喀麥隆
_Kāmàilóng_

Cape Verde
佛得角
維德角
_Fódéjiǎo/Wéidéjiǎo_

Central African Republic
中非共和国
中非共和國
_Zhōngfēi Gònghéguó_

Chad
乍得
查德
_Zhādé/Chádé_

Comoros
科摩罗
_Kēmóluó_

Democratic Republic of the Congo
刚果民主共和国
剛果民主共和國
_Gāngguǒ Mínzhǔ Gònghéguó_

Republic of the Congo
刚果共和国
剛果共和國
_Gāngguǒ Gònghéguó_

Côte d'Ivoire
象牙海岸/科特迪瓦
象牙海岸
_Xiàngyá Hǎi'àn/ Kētèdíwǎ_

Djibouti
吉布提
吉布地
_Jíbùtí_

Egypt
埃及
埃及
_Āijí_

Equatorial Guinea
赤道几内亚
赤道幾內亞
_Chìdào Jĭnèiyà_

Eritrea
厄立特里亚
_Èlìtèlǐyà_

Ethiopia
埃塞俄比亚
衣索比亞
_Āisài'ébǐyà_

Gabon
加蓬
加彭
_Jiāpéng_

The Gambia
冈比亚
甘比亞
_Gāngbǐyà/Gānbǐyà_

Ghana
加纳
迦魶
_Jiānà_

Guinea
几内亚
幾內亞
_Jǐnèiyà_

Guinea-Bissau
几内亚比绍
幾內亞比索
_Jǐnèiyà-bǐshào_

Kenya
肯尼亚
肯亞
_Kěnníyà/Kěnyǎ_

Lesotho
莱索托
賴索托
_Láisuǒtuō_

Liberia
利比里亚
賴比瑞亞
_Lìbǐlǐyà_

Libya
利比亚
利比亞
_Lìbǐyà_

Madagascar
马达加斯加
馬達加斯加
_Mǎdájiāsījiā_

Malawi
马拉维
馬拉威
_Mǎlāwéi_

Mali
马里
馬利
_Mǎlǐ_

Mauritania
毛里塔尼亚
茅利塔尼亞
_Máolǐtǎníyà_

Mauritius
毛里求斯
_Máolǐqiúsī_

Morocco
摩洛哥
摩洛哥
_Móluògē_

Mozambique
莫桑比克
莫三比克
_Mòsāngbǐkè_

Namibia
纳米比亚
納米比亞
_Nàmǐbǐyà_

Niger
尼日尔
_Nírì'ěr_

Nigeria
尼日利亚
奈及利亞
_Nírìlìyà_

Rwanda
卢旺达
盧安達
_Lúwàngdá_

São Tomé and Príncipe
圣多美与普林西比
聖多美及普林西比
_Shèng Duōměi yǔ Pǔlínxībǐ_

Senegal
塞内加尔
塞內加爾
_Sàinèijiā'ěr_

Seychelles
塞舌尔
塞席爾
_Sàishé'ér_

Sierra Leone
塞拉利昂
獅子山
_Sàilālì'áng_

Somalia
索马里
索馬利亞
_Suǒmǎlǐ_

South Africa
南非
南非
_Nánfēi_

Sudan
苏丹
蘇丹
_Sūdān_

Swaziland
斯威士兰
史瓦濟蘭
_Sīwēishìlán_

Tanzania
坦桑尼亚
坦尚尼亞
_Tǎnsāngníyà_

Togo
多哥
多哥
_Duōgē_

Tunisia
突尼斯
突尼西亞
_Tūníxīyà_

Uganda
乌干达
烏干達
_Wūgāndá_

Zambia
赞比亚
尚比亞
_Zànbǐyà_

Zimbabwe
津巴布韦
辛巴威
_Jīnbābùwéi_

* * *

Lessons:
[Pron.](/wiki/Chinese_\(Mandarin\)/Pinyin_Pronunciation) \- [1](/wiki/Chinese_\(Mandarin\)/Lesson_1) \- [2](/wiki/Chinese_\(Mandarin\)/Lesson_2) \- [3](/wiki/Chinese_\(Mandarin\)/Lesson_3) \- [4](/wiki/Chinese_\(Mandarin\)/Lesson_4) \- [5](/wiki/Chinese_\(Mandarin\)/Lesson_5) \- [6](/wiki/Chinese_\(Mandarin\)/Lesson_6) \- [7](/wiki/Chinese_\(Mandarin\)/Lesson_7) \- [8](/wiki/Chinese_\(Mandarin\)/Lesson_8)
[Search inside this book using Google](http://www.google.com/custom?sa=Google+Search&domains=en.wikibooks.org/wiki/Chinese_\(Mandarin\)&sitesearch=en.wikibooks.org/wiki/Chinese_\(Mandarin\))

Subpages:
[Examples](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Examples&action=edit&redlink=1) \- [Exercises](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Exercises&action=edit&redlink=1) \- [Stroke Order](/w/index.php?title=Chinese_\(Mandarin\)/Print_version/Stroke_Order&action=edit&redlink=1)

'偏旁，又称部件，是合体字的结构单位。原来把合体字的左边称「偏」，右边称「旁」；后来把合体字的结构部分统称为「偏旁」。比如位于合体字的左面，称「左偏旁」；右面，称「右偏旁」。

The word for radical in Chinese is 偏旁 (_piānpáng_), or simply 旁 (_páng_). A radical, or component of a character, usually indicates its meaning. 水 (shuǐ; water) with a 冫 becomes 冰 (bīng, ice). The 冫 hints that the character pertains to ice, like the "glaci-" in glacier. Radicals may also be used to differentiate characters that sound alike. 东 (dōng; east, owner) with a 冫 becomes 冻 (dòng; to freeze, jelly). Radicals, like characters, sometimes suggest their meaning by their appearance, for example, the 亻 in 他 (tā; him) is a compressed 人, and the 氵 in 江 (jiāng; river) looks like three water droplets. Radicals reduce the amount of memorization needed, be it for the language's ancient inventors or for you. In Chinese, the large number of homophones and rhyming words make this scheme possible. A character can have multiple radicals, for example, 捌 (bā; eight, see [Numbers](/wiki/Chinese_\(Mandarin\)/Numbers)). Traditionally, the left part of composite characters was referred to as “piān” and the right side referred to as “páng.” Now, all parts of compound characters are generally referred to as “piānpáng.” For example, the left part of a compound character is referred to as 左偏旁 (zuǒ piānpáng), and the right side as 右偏旁 (yòu piānpáng).

# Names of Radicals 中文偏旁的名称

### 一笔画 One Stroke

偏旁 Part 名称 Name 拼音 Pinyin 例子 Ex.

一
横
Héng
丁、丝、上

丨
竖
Shù
中、丰、串

亅
竖钩
Shù gōu
事、予

丿
撇
Piě
九、乍、乃

乛
折
Zhé
买、予、乜

乚
竖弯钩
Shù​ wān​ gōu
乜、也、乱

.
点
Diǎn
以、义、主

### 二笔画 Two Strokes

偏旁 Part 名称 Name 拼音 Pinyin 例子 Ex.

勹
包字头
Bāo zì tóu
勺、勾、匀

冫
两点水
Liǎng diǎn shuǐ
冰、习、净

卜
卜字旁
Bǔ zì páng
卡、卤、卧

厂
偏厦
Piān shà
厕、原、厚

刂
立刀旁
Lì dāo páng
刬、刘、判

匚
三框栏
Sān kuàng lán
匠、匹、区

阝
双耳旁  
双耳刀  
左耳刀  
右耳刀
Shuāng ěr páng  
Shuāng ěr dāo  
Zuǒ ěr dāo  
Yòu ěr dāo
阞、队、阡  
邓、邗、邘

卩
单耳旁
Dān ěr páng
卫、卬、卮

冂
同字框
Tóng zì kuàng
冃、内、冈

冖
秃宝盖
Tū bǎo gài
冗、冘、写

凵
凶字框
Xiōng zì kuàng
凶、凹、凸

亻
单人旁
Dān rén páng
亿、什、仁

厶
私字
Sī zì
厾、去、厹

亠
文字头
Wénzì tóu
亡、交、亢

讠
言字旁
Yán zì páng
计、订、讣

廴
建之旁
Jiàn zhī páng
延、廷、廸

### 三笔画 Three Strokes

偏旁 Part 名称 Name 拼音 Pinyin 例子 Ex.

艹
草字头
Cǎo zì tóu
艺、艻、艾

屮
出字头
Chū zì tóu
屯、屰

彳
双人旁
Shuāng rén páng
彴、彷、彸

巛
三拐
Sān guǎi
巠、巢、巤

辶
走之儿  
走之底
Zǒu zhī er  
Zǒu zhī dǐ
边，辽、巡

廾
弄字底
Nòng zì dǐ
开、弁、异

广
广字旁  
广字头
Guǎng zì páng  
Guǎng zì tóu
庀、庄、庆

宀
宝盖  
宝盖头
Bǎo gài  
Bǎo gài tóu
宁、它、宄

犭
反犬旁、  
犬犹
Fǎn quǎn páng  
Quǎn yóu
犯、犰、犴

彡
三撇
Sān piě
形、彤、彦

饣
食字旁
Shí zì páng
饥、饧、饨

扌
提手旁、  
剔手旁
Tí shǒu páng  
Tī shǒu páng
扎、扐、扑

氵
三点水
Sān diǎn shuǐ
氿、汀、汁

纟
绞丝旁、  
乱绞丝
Jiǎo sī páng  
Luàn jiǎo sī
纠、纡、红

土
提土旁、  
剔土旁
Tí tǔ páng  
Tī tǔ páng
圢、圣、圥

忄
竖心旁、  
竖心
Shù xīn páng  
Shù xīn
忆、忉、忋

尢
尤字旁
Yóu zì páng
尤、尥、尨

夂
折文
Zhé wén
处、夆、备

子
子字旁
Zǐ zì páng
孔、孕、孖

丬
将字旁
Jiāng zì páng
壮、状、将

囗
方匡
Fāng kuāng
囚、四、囝

门
门字旁
Mén zì páng
闩、闪、闫

### 四笔画 Four Strokes

偏旁 Part 名称 Name 拼音 Pinyin 例子 Ex.

灬
四点
Sì diǎn
炁、炰、点

火
火字旁
Huǒ zì páng
灭、灯、灰

礻
示字旁、  
示补
Shì zì páng  
Shì bǔ
礼、礽、社

王
斜玉旁、  
斜玉旁
Xié yù páng  
Xié yù páng
玉、玊、玍

木
木字旁
Mù zì páng
未、末、本

牛
牛字旁、  
剔牛
Niú zì páng  
Tī niú
牝、牠、牡

### 五笔画 Five Strokes

偏旁 Part 名称 Name 拼音 Pinyin 例子 Ex.

疒
病字旁、  
病旁
Bìng zì páng  
Bìng páng
疓、疔、疕

衤
衣字旁、  
衣补
Yī zì páng  
Yī bǔ
初、补、衦


春字头
Chūn zì tóu
奉、奏、秦

罒
四字头
Sì zì tóu
罗、罘、罚

皿
皿字底、  
皿墩
Mǐn zì dǐ,  
Mǐn dūn
盂、盃、盅

钅
金字旁
Jīn zì páng
钆、钇、针

禾
禾木旁
Hé mù páng
禿、秀、私

癶
登字头
Dēng zì tóu
癸、発、登

### 六笔画 Six Strokes

偏旁 Part 名称 Name 拼音 Pinyin 例子 Ex.

米
米字旁
Mǐ zì páng
籴、娄、籸

虍
虎字头
Hǔ zì tóu
虎、虏、虐

⺮
竹字头
Zhú zì tóu
竺、笃、竼

### 七笔画 Seven Strokes

偏旁 Part 名称 Name 拼音 Pinyin 例子 Ex.

⻊
足字旁
Zú zì páng
趴、趵、趷

Mandarin, like any language, has its own slang words and informal meanings for some common words. For example, 同志 (_tóngzhì_ \- comrade, a commonly used honorific) now has a second meaning of "gay person", and the female equivalent 小姐 (_xiǎojiě_, often used with service personnel such as waitresses) can also refer to a prostitute. Below is a partial list of common slang terms. The letters "xx" stand for someone or something, lit. gives a literal translation, and equiv. refers to an equivalent English expression.

## Slang List

简体 繁體 Pinyin Meaning(s), Literal and Figurative

酷
酷
kù
cool (好酷喔 hǎo kù ō; that's cool!); lit., equiv. cool

帅
帥
shuài
good looking, handsome (of a guy)

帅呆（了）
帥呆(了)
shuài dāi (le)
very good looking, a hunk (of a guy); very good, awesome (of a situation)

爽
爽
shuǎng
satisfying, enjoyable, (as in 我昨天去按摩超爽(的)。 "The massage yesterday was very satisfying."

过隐
過隱
guò yǐn
entertaining; very pleasing; addictive

不行了
不行了
bùxíngle
dying, at the point of death; lit. not OK anymore

超
超
chāo
very, extremely, super, ultra- (as in 超冷 "very cold", 超酷 "very cool")

惹
惹
rě
to annoy, provoke, offend, or get on someone's nerves(as in 你幹嘛老是惹我？ "Why do you always get on my nerves?")

碍眼
礙眼
àiyǎn
annoying, get-in-the-way (as in 你在這裡很礙眼, 趕快去做一些有用的事情吧! "You are being a nuisance, go see whether you can make yourself useful somewhere else!); lit. 'hinder the eye'

胡鬧
胡鬧
húnào
make trouble, be a nuisance (as in 你現在馬上給我安靜睡覺,不要再胡鬧! "you are going to sleep right now, no more nonsense!"); lit ‘nonsense quarrel’

感冒
感冒
gǎnmào
(catch) a cold; to develop an aversion against someone (as in 我說了那句話之後,她就對我感冒了 "after I said that she got upset with me")

机车
機車
jīchē
(noun) motorcycle; adj: used to describe someone displaying annoying behavior (as in 她很機車 "she's annoying")

离谱
離譜
lípǔ
preposterous, outrageous; lit. leaving the manual or musical score (as in 你這樣作實在是太離譜。 "You are really out of line doing things like that.")

扯
扯
chě
farfetched, unimaginable, defying all logic (as in 很扯! "Unbelievable!", 太扯了吧! "That is ridiculous!", 你扯到哪裡去? "What are you talking about?"); lit. drag, pull; chat

扯xx（的）后腿
扯xx（的）後腿
chě xx (de) hòu tuǐ
to be a drag on xx, be a hindrance; lit. to pull xx's hind legs

正
正
zhèng
classy, good quality, high class (as in 正妹 "a classy chick", 他的女朋友很正。 "He has a knock out girlfriend.")

耍
耍
shuǎ
cheat, deceive (as in 你想耍我嗎? "You must be kidding.")

耍嘴皮
耍嘴皮
shuǎ zuǐ pí
to talk slickly, to pay lip service

耍赖
耍賴
shuǎlài
to act shamelessly; to act indifferent

赖皮
賴皮
làipí
to act shameless, brazen, like a rascal; rascal, villain

混
混
hùn
to muddle along, to partake in a given activity in a lazy and unserious manner(as in 我這裡已經快混不下去了。 "I'm about to get kicked out of here." (school or company etc), 你還想混多久? "How much longer are you planning to go on like this?")

模鱼
模魚
mó yú
to be lazy on the job; lit. to rub fish

鱿鱼
魷魚
yóuyú
marching orders; lit. squid

炒鱿鱼
炒魷魚
chǎoyóuyú
to be fired, sacked; lit. to fry squid, equiv. "getting a pink slip"

烂
爛
làn
rotten, crappy

烂掉
爛掉
làn diào
to rot, to go bad

烂摊子
爛攤子
làntānzi
bad situation, mess (as in 我可以收他的爛攤子。 "I can take care of the mess he created.")

烂醉
爛醉
lànzuì
piss drunk, blind drunk, dead drunk

烂好人
爛好人
làn hǎorén
spineless, weak person; lit. rotten good person

透
透
tòu
extremely, completely, used as a suffix (as in 爛透了 'extremely crappy'); lit. through

吓死
嚇死
xià sǐ
terrified; lit., equiv. scared to death

难搞
難搞
nán gǎo
hard to deal with, downright

休想
休想
xiūxiǎng
never (interjection), lit., equiv. in your dreams

吹牛
吹牛
chuīniú
to brag, boast

吹
吹
chuī
to brag, boast

自大
自大
zì dà
arrogant, overbearing

臭屁
臭屁
chòu pì
arrogant, overbearing; equiv. cocky, lit. stinking fart

摆架子
擺架子
bǎijiàzi
to put on an airs, to act like the master of, to be arrogant; lit. to swing a rack, shelf

假君子
假君子
jiǎ jūnzǐ
equiv. a wolf in sheep's clothes, lit. a fake gentleman

上流社会
上流社會
shàngliú shèhuì
lit. high society, the rich and famous; equiv. upper crust

黑社会
黑社會
hēishèhuì
triad, triad society; lit. the underworld, equiv. gangland

流氓
流氓
liúmáng
rouge, gangster, hoodlum; lit. flowing vagrant

老大
老大
lǎodà
the big boss, older, elder

小弟
小弟
xiǎodì
younger members of a gang; lit. little brother

吵架
吵架
chǎojià
to quarrel, to argue

斗嘴
鬥嘴
dòuzuǐ
bicker, squabble (lit. to fight with the mouth)

打架
打架
dǎjià
to fight, scuffle (physically)

把风
把風
bǎ fēng
to keep watch, be on the look out (esp. during a heist)

坏胚子
壞胚子
huài pēizi
a bad personal characteristic

好兄弟
好兄弟
hǎo xiōngdì
a ghost; a good friend; lit. good brother

不干净
不乾淨
bù gānjìng
not clean; haunted (by ghosts)

夜总会
夜總會
yèzǒnghuì
nightclub; graveyard

菜鸟
菜鳥
càiniǎo
rookie, beginner, novice, inexperienced person; lit. 'vegetable bird'

天真
天真
tiānzhēn
naive (said mostly of young girls); lit 'heaven real'

猪头
豬頭
zhū tóu
idiot; lit. pig's head

笨蛋
笨蛋
bèndàn
idiot; lit. stupid egg

坏蛋
壞蛋
huàidàn
crook, scoundrel; lit. rotten egg

王八蛋
王八蛋
wángbā dàn
son of a bitch; lit. king eight egg

货
货
huò
goods, merchandise, stuff; drugs

白痴
白痴
báichī
idiot; stupidity; lit. white fool

蠢货
蠢貨
chǔnhuò
idiot, blockhead, dunce, moron (used infrequently)

傻瓜
傻瓜
shǎguā
fool, simpleton (sometimes used lovingly); lit. stupid melon

小子
小子
xiǎozi
guy, kid; prick, brat

疯子
瘋子
fēngzi
madman, lunatic

发疯
發瘋
fāfēng
to become insane, to go mad

娘娘腔
娘娘腔
niángniang qiāng
sissy, girly, effeminate (esp. of a male)

傢伙
傢伙
jiāhuo
guy, chap (negative); weapon, gun

毒蟲
毒蟲
dú chóng
junky, someone on drugs; lit. poisonous insect

吸毒
吸毒
xīdú
to drug, to take drugs (esp. narcotics); lit. to absorb poison

上隱
上隱
shàng yǐn
to become addicted; addictive; Used colloquially: 'get hooked to something' (as in 這種啤酒太好喝了,我快要上隱了 "This kind of beer is too tasty, I'm about to get hooked"

崩溃
崩潰
bēngkuì
debacle; to fall apart, to collapse, esp. mental collapse

欠 xx
欠 xx
qiàn xx
to owe xx (as in, 欠錢 "owe money", 欠情 "owe a favor"); to ask/beg for xx (as in, 欠念 "asking for a verbal dress down", 欠揍 "asking for a beating")

放xx(的)鸽子
放xx(的)鴿子
fàng xx gēzi
to (intentionally) not not come for xx; to miss xx's appointment, equiv. to stand xx up, to be a no-show (as in, 不要放我鴿子喔！ "Don't stand me up!"); lit. release xx pigeons

吃xx(的)豆腐
吃xx(的)豆腐
chī xx(de) dòufu
to commit borderline sexual harassment with a woman (as in, 不要吃我的豆腐。 "Don't touch me.", 你想吃我的豆腐嗎? "Would you like to touch me?"); lit. to eat xx's tofu

没水准
沒水準
méi shuǐzhǔn
equiv. to have no class; lit. to have no standards

没家教
沒家教
méi jiājiào
unmannered, not well behaved, impolite; lit. without home teaching, without a good upbringing

下流
下流
xiàliú
nasty; obscene; indecent; a low life; lit. downstream

土
土
tǔ
with no class, like a buffoon (as in, 你的衣服好土喔! 'your clothes are so low class!'); lit. earth, soil

飙车
飆車
biāochē
drag racing; motorcycle racing; to drive in speedily, a crazed fashion; lit. whirlwind car

xx族
xx族
xx zú
people that do xx (as in, 上班族 "people that work", 飆車族 "people that drive too fast"); lit. xx tribe/clan/family

种草莓
種草莓
zhǒng cǎoméi
to kiss someone passionately, leaving a reddish mark (equiv. to give someone a hickey); lit. to plant strawberries

丢脸
丟臉
diūliǎn
to embarrass, to disgrace, to humiliate (as in 你在朋友的面前這樣說我真丟臉。 "The way you spoke about me in front of our friends really made me lose face."); equiv., lit. to lose face

没面子
沒面子
méi miànzi
to lose face (as in 你害我沒面子。 "You made me lose face.")

厚脸皮
厚臉皮
hòu liǎnpí
cheeky, brazen; thick skinned; willing to make daring demands (negative)

嚣张
囂張
xiāozhāng
brazen, shameless, arrogant

酒吧
酒吧
jiǔbā
a bar

酒店
酒店
jiǔdiàn
a hotel; restaurant; hostess bar (Taiwan only); wine shop

夜店
夜店
yèdiàn
a nightclub

夜猫子
夜貓子
yèmāozi
someone who sleeps late (equiv. a night owl); someone with a rich nightlife

黄包车
黃包車
huángbāochē
rickshaw / denigrating slang: a Chinese woman abroad (being promiscuous as opposed to conservative at home)

恐龙妹
恐龍妹
kǒnglóng mèi
ugly girl (lit. 'dinosaur girl')

辣妹
辣妹
làmèi
a hot girl (lit. 'spicy girl'); the Spice Girls

帅哥
帥哥
shuàigē
good looking dude, a hunk

放电
放電
fàngdiàn
to create an atmosphere of feminine attraction (of a woman); lit. 'to discharge electricity'

欲火焚身
欲火焚身
yù​huǒ​fén​shēn
to be very horny; lit. 'lust fire incinerate body'

泡妞
泡妞
pàoniū
(try to) hook up with girls, on the prowl for women; lit ‘steep/soak girls’

把妹
把妹
bǎ mèi
to hunt for girls

把马子
把馬子
bǎ mǎzi
to hunt for girls

把凯子
把凱子
bǎ kǎizi
to hunt for rich hunks (of a woman)

搭讪
搭訕
dāshan
(trying to hook up by) starting a conversation (with a stranger)

乱讲
亂講
luàn jiǎng
to speak nonsense

胡烂
胡爛
húlàn
give someone a load of nonsense; (as in 男生最利害的就是胡爛 "(said by a woman) Selling crap is what men do best"); lit ‘nonsense crap‘

放屁
放屁
fàngpì
to speak nonsense; lit. 'to fart'

废话
廢話
fèihuà
to speak nonsense, to trashtalk; lit. 'to waste words'

啰嗦
囉嗦
luōsuo
to talk too much (as in 你很囉嗦。 "You talk too much.", 不要囉嗦了！ "Stop rambling!")

哈啦
哈啦
hā la
to argue, to incessantly try to convince someone (as in 你不用哈啦這麼多, 就直接認錯吧! "Stop arguing and just admit you're wrong!", 哇,你很會哈啦喔! "Wow, you really know how to argue!")

闭嘴
閉嘴
bì zuǐ
shut up (interjection, often said by parents)

插嘴
插嘴
chāzuǐ
to interrupt someone talking (as in 你不要老是插嘴。 "Stop interrupting me."); lit. to insert a mouth

顶嘴
頂嘴
dǐngzuǐ
to talk back, to be a wiseguy; to answer defiantly (as in 如果你再頂嘴我就修理你! "I am going to take care of you if you talk back to me again.")

xx 个屁 / xx 个头
xx 個屁 / xx 個頭
xx gèpì / xx gètóu
xx my ass (interjection, as in A: 這電影好浪漫喔。 B: 浪漫個屁阿! A: This movie is so romantic. B: Romantic my ass!)

小弟弟
小弟弟
xiǎo dìdì
penis; lit. little brother

（小）鸡鸡
（小）雞雞
(xiǎo) jī jī
penis; lit. chicken

小鸟
小鳥
xiǎo niǎo
penis; lit. small bird

那话儿
那話兒
nà huà er
penis; lit. "that talk"

蛋
蛋
dàn
testicles, equiv. balls (as in 打架的時候要好好保護你的蛋(蛋)。 "When fighting you have protect your balls."); lit. egg

奶子
奶子
nǎizi
breast(s)

巨乳
巨乳
jùrǔ
huge breast(s)

波霸
波霸
bō(or pō)bà
(woman with) huge breast(s)

高潮
高潮
gāocháo
orgasm; lit. high tide, climax

做爱
做愛
zuò'ài
to have sex; lit., equiv. to make love

炒饭
炒飯
chao3fan4
to make love; lit. to fry rice

上床
上床
shàngchuáng
to go to bed; to make love

色狼
色狼
sèláng
a man with strong sexual desires, a satyr, a sex addict; lit. appearance wolf

变态
變態
biàntài
a sexual pervert; lit. metamorphosis, abnormal

（有）外遇
（有）外遇
(yǒu) wàiyù
to have an affair

劈腿
劈腿
pī tuǐ
to have an affair, to cheat on someone; lit. to split the legs

一夜情
一夜情
yīyè qíng
a one-night stand; lit. love for one night

分手
分手
fēnshǒu
to break up in a relationship; to bid farewell; lit. divide hands

兵变
兵變
bīngbiàn
a mutiny; a relationship that breaks up during military service; lit. military change

追
追
zhuī
to try to get a relationship with someone (as in 他還在追那個美妹嗎? "Is he still after that pretty girl?"); to pursue

狐狸精
狐狸精
húlíjīng
a woman that steals another woman's man; lit. a fox spirit

母老虎
母老虎
mǔ lǎohǔ
a dominant wife; lit. mother tiger

哇靠
哇靠
wākào
exclamation: WOW! (also the title of a song by 周杰倫 Jay Zhou, a famous Taiwanese singer)

干
幹
gàn
to make love [vulgar]; used as a vulgar exclamation, equiv. "F**k!"; to do something, as in 幹活 "work"

干掉
幹掉
gàndiào
to get rid of; to kill someone; lit. to do away

干你娘
幹你娘
gàn nǐ niang
to have sex with your mother, _very_ vulgar (_never_ used in public unless speaker wants to appear boorish)

干嘛
幹嘛
gàn má
exclamation, "What is it now?" or "What do you want now?", indicating irritation; why (impolite) (as in '你幹嘛花這麼多錢買這麼爛的東西? "Why would you spend so much money buying something as crappy as that?")

（他）妈的
（他）媽的
(ta1)ma1de5
exclamation, "Fuck!", "Shit!", "To hell with it!", "Damn it!"; used to increase vulgarity (as in 你也他媽的夠了吧! "You are really out of line!"); lit. his mom's

操
操
cào
to fuck [vulgar] (from 肏 which has the same pronunciation); to exercise, drill (when pronounced cāo)

操你妈的屄
操你媽的屄
cāo nǐ mā de bī
to fuck your mother's cunt [very vulgar] (never use in public, or for that matter, at home)

屌
屌
diǎo
male reproductive organ; expression (mostly among guys) showing admiration or approval (as in 你很屌! "you're awesome!" or 超屌的! "far out!")

老外
老外
lǎowài
foreigner (neutral connotation)

洋妞
洋妞
yáng niū
foreign babe, foreign chick

阿都仔
阿都仔
ā dōu zǐ
foreigner (Taiwan only)

同志
同志
tóngzhì
gay or lesbian (normally "comrade" in a Communist context)

小姐
小姐
xiǎojiě
girl working in a hostess bar; exclamation, used alone, "Waitress!"; prostitute; young woman

槟榔西施
檳榔西施
bīnláng xīshī
a young, attractive girl, usually scantily clad, hired to sell betelnuts in street stalls (西施 is a classic beauty from Chinese history/myth); lit. betelnut beauty

杀价
殺價
shājià
to haggle, to bargain (foreigners will always be forced to pay more, though)

动手
動手
dòngshǒu
to begin doing something (e.g. 他开始动手了吗？); to touch, to handle; to hit someone with hands

动手脚
動手腳
dòng shǒujiǎo
to sabotage something; to cheat by modifying something; to tinker with; lit. to move hands and feet

灌醉
灌醉
guàn zuì
to fuddle, to confuse with alcohol; to get someone drunk

海量
海量
hǎiliàng
to be capable of holding liquor (a highly valued asset in competitive drinking, a Chinese sport)

灌水
灌水
guànshuǐ
to sell inferior goods that have been tampered with (business), for example, adding water to milk; to lose a game on purpose (sports)

黑货
黑貨
hēi huò
goods that have been tampered with, potentially hazardous to health; smuggled goods; lit. black stuff

排马屁
排馬屁
pái mǎ pì
to flatter; lit. to align horse farts

排排屁股走
排排屁股走
pái pái pìgu zǒu
to run away, to take off without caring for the consequences (while engaged in a relationship or project); lit. to line up the ass and go

条子
條子
tiáozi
a police officer; a strip (esp. of paper), a note

内鬼
內鬼
nèi guǐ
to steal; lit. within ghosts

饭桶
飯桶
fàntǒng
a scallywag, a do-nothing; a guy who lives off his girlfriend; lit. a rice container

吃软饭
吃軟飯
chī ruǎnfàn
to live off one's girlfriend; lit. to eat soft rice

毛毛的
毛毛的
máomáo de
creepy, suspicious, causing goosebumps (as in 他那樣瞪我, 我都覺得毛毛的。 "The way he stared at me made me feel spooked.")

人情味
人情味
rénqíngwèi
affection, humane, used to describe a friendly, caring atmosphere (as in 中國很有人情味。); lit. the smell of human feelings

累死了
累死了
lèi sǐle
exhausted, worn out; lit. tired to the death

（老）油条
（老）油條
(lǎo) yóutiáo
a deceitful, "slick" person (油條, fried wheat cruller, is a long stick of deep fried batter, a staple in China)

狗仔（队）
狗仔（隊）
gǒuzǎi (duì)
paparazzi; lit. dog puppy team

小强
小強
xiǎo qiáng
cockroach; lit. little strong one

过头
過頭
guòtóu
in excess (as in 睡过头, to oversleep)

赖床
賴床
lài chuáng
to stay in bed (esp. too long), to not get up

昏昏欲睡
昏昏欲睡
hūn hūn yù shuì
drowsy, sleepy

拖拖拉拉
拖拖拉拉
tuō tuō lā lā
to be slow (esp. from reluctance); to procrastinate

湿达达（的）
溼達達（的）
shī dá dá (de)
soaking wet

A
A
ēi
to steal (as in A錢, to steal money)

K書
K書
kēi shū
study (as in pounding something into one's head)

SPP
SPP
sòng piào piào
having no class (Taiwan only, based on Hoklo dialect)

A片
A片
ēi piàn
a porn movie

咱们
咱們
zán men
we, us (sometimes just 咱).

## External links

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Mandarin slang**_](//en.wikipedia.org/wiki/Mandarin_slang)

  * [Chinese Chat Codes](http://www.yellowbridge.com/language/pagercodes.html) \- This page contains numeric codes used in chatting or pager messages similar to English acronyms like LOL (_L_aughing _O_ut _L_oud) or BRB (_B_e _R_ight _B_ack).
  * [Chinese Slang Dictionary](http://www.languagerealm.com/chinese/chinese_slang.php) \- A dictionary of Chinese slang, colloquialisms, curses, vulgarities, dialects, and street talk that Chinese characters, pinyin romanization, and an English version.

This history of the Chinese Wikibook highlights milestones along the book's development.

## 2006

  * **March 17** A [PDF Version](/w/index.php?title=File:Chinese_\(Mandarin\)_v0.2.pdf&action=edit&redlink=1) is created and the [first audio samples](http://en.wikibooks.org/w/index.php?title=Chinese/Lesson_1&diff=prev&oldid=400571) are added to vocabulary
  * **March 13** [Print version](http://en.wikibooks.org/w/index.php?title=Chinese_%28Mandarin%29/Print_version&oldid=396850) created

## 2005

  * **October** Chinese is elected [October's Book of the Month](/wiki/Wikibooks:Book_of_the_month/October_2005_voting), the first language text to do so
  * **June 12** [First stroke order images](http://en.wikibooks.org/w/index.php?title=Chinese/Lesson_2&diff=prev&oldid=139354) linked from vocabulary
  * **March** [First nomination](/wiki/Wikibooks:Book_of_the_month/March_2005_voting) for Book of the Month. One vote (or 37 minutes) shy of [High school extensions](/wiki/High_school_extensions)' 5 votes. Chinese would also be the runner-up in August and September.
  * Translated versions of the Chinese Wikibook appear in [Spanish](http://es.wikibooks.org/w/index.php?title=Chino_/_Contenido&oldid=9017) (March 13), [Italian](http://it.wikibooks.org/w/index.php?title=Corso_di_cinese/Indice&oldid=4215) (July 19) and [Polish](http://pl.wikibooks.org/w/index.php?title=Chi%C5%84ski&oldid=7525) (August 20).

## 2004

  * **December 29** [First Table of Contents](http://en.wikibooks.org/w/index.php?title=Template:Chinese_%28Mandarin%29TOC&oldid=81558)
  * **December 22** [Planning](http://en.wikibooks.org/w/index.php?title=Chinese/Planning&oldid=43512) page added
  * **December 19** [Major rewrite](http://en.wikibooks.org/w/index.php?title=Chinese%2FLesson_1&diff=78977&oldid=78529) of Lesson 1

## 2003

  * **December 13** [First edit](http://en.wikibooks.org/w/index.php?title=Chinese_%28Mandarin%29&oldid=9722) by [Yacht](/wiki/User:Yacht)

# Contributors

The Chinese Wikibook was started 2003 December 13. Below is a list of users who have contributed greatly to the authoring of this Wikibook. Please add your username if you have made substantial additions and/or revisions to this textbook. Use ***{{user|username}}** to add a name.

  * [everlong](/wiki/User:Everlong) ([discuss](/wiki/User_talk:Everlong) **·** [email](/wiki/Special:EmailUser/everlong) **·** [contribs](/wiki/Special:Contributions/everlong) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=everlong) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=everlong&lang=en&wiki=wikibooks))
  * [Taoster](/wiki/User:Taoster) ([discuss](/wiki/User_talk:Taoster) **·** [email](/wiki/Special:EmailUser/Taoster) **·** [contribs](/wiki/Special:Contributions/Taoster) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Taoster) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Taoster&lang=en&wiki=wikibooks))
  * [Ran](/wiki/User:Ran) ([discuss](/wiki/User_talk:Ran) **·** [email](/wiki/Special:EmailUser/Ran) **·** [contribs](/wiki/Special:Contributions/Ran) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Ran) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Ran&lang=en&wiki=wikibooks))

[M4RC0](//commons.wikimedia.org/wiki/user:M4RC0), [Yug](//commons.wikimedia.org/wiki/user:Yug) and [Wikic](//commons.wikimedia.org/wiki/user:wikic) all made substantial contributions to the [Chinese stroke order project](//commons.wikimedia.org/wiki/Category:Chinese_stroke_order) on [Wikicommons](//commons.wikimedia.org/wiki/Main_Page), which are used in our lessons. [Peter Isotalo](//commons.wikimedia.org/wiki/user:Peter_Isotalo), also of Wikicommons, contributed the first audio samples used in this Wikibook.

In addition, the authors would like to thank the development team in relation with the [Wikimedia Foundation](http://www.wikimediafoundation.org/) and its affiliates, without whom our text could not be so accessible.

# Ways to Contribute

## Internationalization

### Keep the Simplified/Traditional Versions in Sync

The Chinese Wikibook has two identical versions; [Simplified](/wiki/Chinese) and [Traditional](/wiki/Chinese_\(Mandarin\)/Traditional). This is done to unclutter the textbook and to meet the needs of people either interested in the characters used in China or used in Taiwan. However, whenever a change is made in one version, it is not automatically carried over, so periodic checks must be made to ensure that the two remain in sync. This sometimes involves translating from one script to the other, but often only involves copying formatting changes.

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/54/Domenico_Ghirlandaio_-_St_Jerome_in_his_study.jpg/220px-Domenico_Ghirlandaio_-_St_Jerome_in_his_study.jpg)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Saint Jerome, the patron saint of translators.

### Translate Pages

Currently, the English version is the most developed of the Chinese Wikibooks. If you know another language, please check if a Chinese book is started in that language and compare it to this one. You can make changes to their content based on ideas gained here, or do a wholesale translation of this textbook into the target language. Since the Chinese can stay the same across languages, a lot of work can be saved in this way. Translation efforts have been started in the following languages:

  * [Italiano](http://it.wikibooks.org/wiki/Corso_di_cinese/Indice)
  * [Polski](http://pl.wikibooks.org/wiki/Chiński)
  * [Español](http://es.wikibooks.org/wiki/Chino)

Even if a translation has been done at one time, it may have been incomplete or not been updated to reflect recent changes on the English site. Please work to keep them current. If you can only do a partial translation, leave a note to later contributors linking back to your source (a good candidate for using [Templates](/wiki/Help:Templates)).

### Add InterWiki Links

If you can't translate pages, but know enough of a language to locate the corresponding Chinese Wikibook, you can make Interwiki links. You can see them on the Wikibooks Sidebar listed under "in other languages" when available. They are typically placed at the very end of a page using a simple format. Here is the list used for the Chinese TOC page:
    
    
    [[it:Corso di cinese/Indice]]
    [[pl:Chiński]]
    [[es:Chino]]
    <!-- 在以上的课程里中文是一样的，
    在以下的课程里中文是不同的 -->
    [[fr:Enseignement du chinois]]
    [[de:Chinesisch]]
    [[ja:中国語]]
    [[nl:Mandarijn]]
    

The ones listed above the divider are translations of this book. The ones below are of their own design. In addition to the main page, Lesson pages, Stroke Order pages and anything else can be interwikied as long as the content is the same.

## Stroke Order Images

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f9/%E4%B8%8D-red.png/90px-%E4%B8%8D-red.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Black to red fade

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7f/%E6%B0%B8-order.gif/100px-%E6%B0%B8-order.gif)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Gif animations

There is [a project on Wikicommons](//commons.wikimedia.org/wiki/Commons:CJK_stroke_order_project) to upload images and animations of the stroke order for characters. There are [directions on how to contribute](//commons.wikimedia.org/wiki/commons:CJK_stroke_order:Tutorials). It's easy with the use of some free programs and can be done even with only a basic understanding of Chinese. Please contribute so that we'll have a standardized reference for our Wikibook users.

Have a look at the stroke order pages for each lesson to see what our immediate needs are:

[Lesson 1](/wiki/Chinese/Lesson_1/Stroke_Order) — [Lesson 2](/wiki/Chinese/Lesson_2/Stroke_Order) — [Lesson 3](/w/index.php?title=Chinese/Lesson_3/Stroke_Order&action=edit&redlink=1)

  


## Sound Samples

![Gnome-speakernotes.png](//upload.wikimedia.org/wikipedia/commons/a/a6/Gnome-speakernotes.png)

With a microphone and a read through the [recording guidelines](http://en.wikipedia.org/wiki/Wikipedia:WikiProject_Spoken_Wikipedia/Recording_guidelines) for the Spoken Wikipedia you can contribute audio examples. Sound samples are particularly important for beginners, especially ones who are studying alone with no teacher or native speaker on hand.

You can see what has been uploaded so far at [Category:Chinese pronunciation](//commons.wikimedia.org/wiki/Category:Chinese_pronunciation). [Peter Isotalo](//commons.wikimedia.org/wiki/user:Peter_Isotalo) started, but a native speaker would be best. **Welcome to the main Planning page for the Chinese Wikibook.** Unless your comment only pertains to a particular lesson, discuss your ideas here so that the overall planning discussion is not spread across many lesson pages. Initial planning and continued coordination of effort is extremely important to help reduce the need for reworking later. New issues are entered here, with the most recent at the bottom of the page. Please review the _Table of Contents_ to see if your issue has already been raised; also check the archives (see below) in case it was discussed some time ago.

![Haldeman and Ehrlichman discuss policy, 1973.png](//upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Haldeman_and_Ehrlichman_discuss_policy%2C_1973.png/150px-Haldeman_and_Ehrlichman_discuss_policy%2C_1973.png)

**Please observe the following guidelines:**

  1. Place your question **at the bottom** of the list;
  2. **Title** the question (by placing the title between equals signs like this: == _title_ ==);
  3. **Sign** your name and date (by adding four tildes: ~~~~).

![Wikimedia Commons logo](//upload.wikimedia.org/wikipedia/commons/thumb/2/24/Nuvola_apps_chat.png/20px-Nuvola_apps_chat.png) **[Post a new comment](//en.wikibooks.org/w/index.php?title=Chinese/Planning&action=edit&section=new)**

## Chinese Wikibook Purpose and Audience

This book is intended to be a complete learning resource center for students of Mandarin Chinese. Dialects, such as Cantonese, will be covered by their own Wikibooks and be linked to in the See Also section of the Table of Contents (TOC). It should teach listening comprehension and speaking as well as reading and writing using whatever technologies are most appropriate (includes audio for text and animations for stroke orders).

The audience is the serious studier of Chinese, either at the high school or college level. Casual learners looking for a few choice phrases or unwilling to spend the time learning characters can be served adequately by the Chinese Phrasebook on Wikivoyage. Younger audiences can have age-appropriate material created for them in WikiJunior. Intermediate- or Advanced-Level modules may be added, but because of the cumulative nature of a language text (explained below), it would probably be best to focus efforts on the Introductory Level first and make continuations of the series later.

## The Need for Planning

Language Wikibooks faces some unique challenges from a planning perspective. It's harder to produce a quality, integrated work in language instruction than in other subjects, like Biology or Physics. Those you can break into discrete units and still read about it—topics within the subject can be rearranged or meaningfully read even in isolation from the rest of the text.

Not so with an elementary language text. All the grammar and vocabulary that you learn is cumulative, so everything can only stack one way. Flipping ahead (or falling behind) more than a few chapters and you're lost. Order matters, so we use the a sequential naming scheme (Lesson 1, Lesson 2,...), not a topic-based one (Asking Questions, Giving Directions,...).

To avoid late-stage reorganizations that would neccessarily be painful with lots of work going to waste, we should agree on a 'Lesson Roadmap' beforehand and then flesh it out. I think a Wiki can really work for this, but that the project still needs a common format and approach. A standard outline for lessons would help a lot with that, so, may I suggest that the lessons of this text each include the components outlined below.

## _Lesson Roadmap_

  1. **Lesson 1: Hello! (你好！)**![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png) \- Basic Sentences and Questions 
    * Simple Sentences 
      * SVO sentence structure 
        * The equational verb shi [是] and its negation with bu [不]
        * Verb 叫
    * Intro to Questions 
      * Ma [吗] and ne [呢] particles
      * Question words (for now, only shei [谁] and na/nei [哪])
  2. **Lesson 2: Are you busy today? (今天你忙不忙?)** ![75 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png) \- Measure Words, Possession and Affirmative-Negative Questions 
    * Measure Words (the most commonly used, like 个、本、张)
    * The possessive verb you [有] and its negation with mei [没]
    * More Questions! Affirmative-Negative 
      * 是不是 Questions
      * 有没有 Questions
  3. **Unit 3: 今天星期三** \- Numbers, Days, Aux. Verbs, de [的] 
    * Numbers (to 100)
    * year, month, day, week etc.
    * Auxiliary Verbs, the de [的] particle
  4. **Lesson TBA: Unordered List of Grammar Explanations** \- Even w/o example sentences grammar can be explained nonetheless 
    * Comparisons Using bǐ [比]
    * The le [了] particle 
      * indicating a completed action
      * indicating a past event
      * expressing change of state or situation
      * adding emphasis
    * Time 
      * when - time of day, hour and minutes, morning/night
      * how long - duration of time
    * Directions/Placement Words (NESW, L/R, li3, li2, zai4, bian1)
    * Pronunciation of yi1 (b/c of tone changes)
    * Complement of degree de
    * ordinal numbers di
    * Complement of direction qu/lai
    * Compliment of result
    * ba 
      * the suggestion particle
      * as preposition
    * guo denoting experience of something
    * (some) members of family
    * reduplication
    * emphasis using shi...de
    * How to use a Radical Index (for C-E Glossary)
    * Basic rules for writing Chinese characters

## Subjects Areas to Cover

**Greetings**

**Getting around (a city)**

  * Where is the post office?
  * How far is it to the school?
  * Public transport
  * Conversation in a taxi

**Chapter Three: Buying Things**

  * How much is that shirt?
  * Haggling

**Eating**

  * Eating Out
  * At the supermarket
  * The grocer
  * A meal at home
  * Traditional Chinese cooking

**Sports**

  * What do you play?
  * Talking about a match
  * Skiing
  * Mountaineering
  * Yachting
  * Surfing

**Your House**

  * Description of house
  * Traditional Chinese furniture
  * Living in a community

**Immediate family and relatives**

**Education**

  * This is my school
  * Afterschool activities
  * School subjects

**Going to the Zoo / Wo men qu dong wu yuan**

## Decided Conventions

  1. **The Title Page leads to the main TOC**, not the Cover Page. The Cover Page can be linked from the TOC and used in Print versions.
  2. **Hanyu Pinyin is used** as the only Romanization format, though equivalency charts to other systems provided[[1]](http://en.wikipedia.org/wiki/Bopomofo). Tone marks are used instead of tone numbers.
  3. **Traditional or Simplified** characters appear only in the Lesson Text and in parentheses in the Vocabulary sections—not in titles, example sentences, or exercises.
  4. **Traditional pages are linked as parallel subpages** of every Simplified page. On every Traditional page, a parentdirectory link links back to the Simplified version, always providing a toggle button between versions.

## Unresolved Issues

# License

## GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Chinese_(Mandarin)/Print_version&oldid=2327522](http://en.wikibooks.org/w/index.php?title=Chinese_\(Mandarin\)/Print_version&oldid=2327522)" 

[Category](/wiki/Special:Categories): 

  * [Chinese (Mandarin)](/wiki/Category:Chinese_\(Mandarin\))

Hidden category: 

  * [No references for citations](/wiki/Category:No_references_for_citations)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Chinese+%28Mandarin%29%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Chinese+%28Mandarin%29%2FPrint+version)

### Namespaces

  * [Book](/wiki/Chinese_\(Mandarin\)/Print_version)
  * [Discussion](/wiki/Talk:Chinese_\(Mandarin\)/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Chinese_\(Mandarin\)/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Chinese_\(Mandarin\)/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Chinese_\(Mandarin\)/Print_version&action=edit)
  * [View history](/w/index.php?title=Chinese_\(Mandarin\)/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Chinese_\(Mandarin\)/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Chinese_\(Mandarin\)/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Chinese_\(Mandarin\)/Print_version&oldid=2327522)
  * [Page information](/w/index.php?title=Chinese_\(Mandarin\)/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Chinese_%28Mandarin%29%2FPrint_version&id=2327522)

### In other languages

  * [Italiano](//it.wikibooks.org/wiki/Cinese/Introduzione)
  * [Polski](//pl.wikibooks.org/wiki/Chi%C5%84ski/O_j%C4%99zyku_chi%C5%84skim)
  * [Türkçe](//tr.wikibooks.org/wiki/Mandarin/%C4%B0%C3%A7indekiler/Mandarin_hakk%C4%B1nda)
  * [Español](//es.wikibooks.org/wiki/Chino/C%C3%B3mo_estudiar_chino)
  * [Deutsch](//de.wikibooks.org/wiki/Chinesisch:_%E7%AC%AC%E4%B8%80%E8%AA%B2)
  * [Français](//fr.wikibooks.org/wiki/Chinois/Le%C3%A7on_1)
  * [Македонски](//mk.wikibooks.org/wiki/%D0%9A%D0%B8%D0%BD%D0%B5%D1%81%D0%BA%D0%B8_%D1%98%D0%B0%D0%B7%D0%B8%D0%BA/%D0%9B%D0%B5%D0%BA%D1%86%D0%B8%D1%98%D0%B0_1)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Chinese+%28Mandarin%29%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Chinese+%28Mandarin%29%2FPrint+version&oldid=2327522&writer=rl)
  * [Printable version](/w/index.php?title=Chinese_\(Mandarin\)/Print_version&printable=yes)

  * This page was last modified on 7 May 2012, at 18:58.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Chinese_\(Mandarin\)/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
