# Primary Mathematics/Print version

From Wikibooks, open books for an open world

< [Primary Mathematics](/wiki/Primary_Mathematics)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Primary_Mathematics/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Primary_Mathematics/Print_version) on _30 October 2012_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Primary_Mathematics/Print_version&oldid=2426679&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

## Contents

  * 1 General Overview of the Teaching of Mathematics
    * 1.1 What This Book is Not
    * 1.2 Connectedness
    * 1.3 Manipulatives and Models
  * 2 Numbers
    * 2.1 Numbers
      * 2.1.1 Natural Numbers
      * 2.1.2 Zero
      * 2.1.3 Other Types of Numbers
    * 2.2 Teaching Numbers
      * 2.2.1 Developing a sound concept of number
      * 2.2.2 Matching Activities
      * 2.2.3 Number and Numerals
      * 2.2.4 Place Value
      * 2.2.5 Place Values in other number systems
  * 3 Adding numbers
    * 3.1 Adding two single digit numbers
    * 3.2 Adding multiple digit numbers
    * 3.3 Teaching addition of numbers
  * 4 Subtracting numbers
    * 4.1 Subtracting numbers
    * 4.2 Subtraction with large numbers
    * 4.3 Teaching subtraction
  * 5 Multiplying numbers
    * 5.1 The Teaching of Multiplication
      * 5.1.1 Manipulatives and Models
      * 5.1.2 The Use of Different Algorithms to Solve Multiplication Problems
      * 5.1.3 The Lattice Method
      * 5.1.4 Multiplication with decimals
  * 6 Dividing numbers
    * 6.1 Dividing numbers
  * 7 Negative numbers
    * 7.1 Negative numbers
      * 7.1.1 Introduction
      * 7.1.2 Addition involving negative numbers
      * 7.1.3 Subtraction involving negative numbers
      * 7.1.4 Multiplication involving negative numbers
      * 7.1.5 Division involving negative numbers
      * 7.1.6 Other notations
  * 8 Fractions
    * 8.1 Learning to use fractions (Visually)
      * 8.1.1 Modern methods to teach fractions
      * 8.1.2 Origami and Fractions
      * 8.1.3 The square model vs. the circle model
      * 8.1.4 The money approach: 1, 1/4, 1/2, 1/10, 1/20, 1/100
      * 8.1.5 Whole number fractions
    * 8.2 Multiplying fractions
      * 8.2.1 Traditional multiplication method
      * 8.2.2 Multiplying Fractions with nice pictures
      * 8.2.3 Dividing fractions
      * 8.2.4 Adding fractions
      * 8.2.5 Multiplying to get equivalent fractions
  * 9 Working with fractions
    * 9.1 Working with fractions
  * 10 Decimals
    * 10.1 Decimals
    * 10.2 Addition and Subtraction
    * 10.3 Multiplication
    * 10.4 Division
    * 10.5 Fractions to Decimals
    * 10.6 Converting to fractions
    * 10.7 Significant digits
  * 11 Metric
    * 11.1 Meter
    * 11.2 Gram
    * 11.3 Liter
  * 12 Time math
    * 12.1 Time math
      * 12.1.1 Units
        * 12.1.1.1 Seconds
        * 12.1.1.2 Minutes
        * 12.1.1.3 Hours
        * 12.1.1.4 Days
        * 12.1.1.5 Weeks
        * 12.1.1.6 Months
          * 12.1.1.6.1 Memory methods
        * 12.1.1.7 Years
          * 12.1.1.7.1 What years are leap years ?
        * 12.1.1.8 Longer periods
      * 12.1.2 Systems
        * 12.1.2.1 12 hour clock
        * 12.1.2.2 24 hour clock
        * 12.1.2.3 Decimal time
      * 12.1.3 Operations
        * 12.1.3.1 Addition
          * 12.1.3.1.1 Examples
        * 12.1.3.2 Subtraction
          * 12.1.3.2.1 Examples
        * 12.1.3.3 Multiplication
          * 12.1.3.3.1 Examples
        * 12.1.3.4 Division
          * 12.1.3.4.1 Examples
  * 13 Unit math
    * 13.1 Unit math
      * 13.1.1 Addition and subtraction
        * 13.1.1.1 Examples
      * 13.1.2 Multiplication and division
        * 13.1.2.1 Examples
      * 13.1.3 Powers, roots, and exponents
        * 13.1.3.1 Examples
      * 13.1.4 Unit conversion
        * 13.1.4.1 Examples
  * 14 Introduction to significant digits
    * 14.1 Examples
    * 14.2 Limitations
    * 14.3 Use with scientific and engineering notation
    * 14.4 Beyond significant digits
    * 14.5 Accumulating error
  * 15 Powers, roots, and exponents
    * 15.1 Exponents
      * 15.1.1 Squaring numbers
        * 15.1.1.1 Table of perfect squares
      * 15.1.2 Cubing numbers
        * 15.1.2.1 Table of perfect cube numbers
      * 15.1.3 Higher powers
        * 15.1.3.1 Table of higher powers
    * 15.2 Properties of Exponents
      * 15.2.1 Bases and exponents of one and zero
      * 15.2.2 Negative and noninteger powers
    * 15.3 Roots
      * 15.3.1 Square root
        * 15.3.1.1 Manually finding a square root
      * 15.3.2 Cube root
      * 15.3.3 Higher roots
    * 15.4 Combining powers and roots
      * 15.4.1 Fractions as exponents
      * 15.4.2 Decimal exponents
      * 15.4.3 Negative exponents
      * 15.4.4 Fractions as bases
      * 15.4.5 Negative bases
      * 15.4.6 Principal root
  * 16 Scientific and engineering notation
    * 16.1 Scientific and engineering notation
      * 16.1.1 Scientific notation
      * 16.1.2 Engineering notation
  * 17 Average, media, and mode
    * 17.1 Average, median, and mode
      * 17.1.1 Median
      * 17.1.2 Average
      * 17.1.3 Weighted average
      * 17.1.4 Example
      * 17.1.5 Geometric mean
  * 18 Percentages
    * 18.1 Percentages
      * 18.1.1 Introduction
      * 18.1.2 Uses for percentages
      * 18.1.3 Defining the base
      * 18.1.4 Example
      * 18.1.5 Terms used with percentages
      * 18.1.6 Compound interest
  * 19 Probability
    * 19.1 Probability
      * 19.1.1 Models
  * 20 Factors and Primes
    * 20.1 Factors and Primes
  * 21 Method for Factoring
    * 21.1 A method of prime factorization for children
      * 21.1.1 When the factors aren't obvious

# General Overview of the Teaching of Mathematics[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=1)]

The face of the teaching of mathematics is in constant flux. This course, therefore is an attempt to stay in step with the current pedagogy(s) used in the teaching of mathematics to the primary grades. While educators should find this book helpful in learning or reacquainting themselves with some of the methodologies currently used, this course attempts to use as much lay language as possible to also be helpful to parents who, in looking over the shoulders of their children, are sometimes baffled by the "New Math". Those who perhaps might find the most value from this course would be those who wish to **home-school** their child(ren). It is hoped that teachers of mathematics will continually make updates to this course as these changes inevitably occur.

## What This Book is Not[[edit](/w/index.php?title=Primary_Mathematics/General_Overview_of_the_Teaching_of_Mathematics&action=edit&section=T-1)]

This book assumes that the reader has reached some level of competency with the topics it covers. As such, this book is not designed to teach math to the reader. Rather, it is meant to give the reader insight into how and why mathematical core understandings and skills are taught the way they are. Activities will be suggested that will present teachers and prospective home-schoolers with ideas for their own course content. A basic mathematics background should be all that is needed to find value in this course. Often times parents (and even teachers) only understand a topic in the way they were taught it, but modern math curriculums are often constructed in such a way that topics are covered in many different ways in order to accommodate the different learning styles of students. By way of example, this course will **not** teach the reader in step by step fashion how to multiply two large numbers, but the various building blocks and algorithms that students are introduced to in the process of learning this skill will be explained.

## Connectedness[[edit](/w/index.php?title=Primary_Mathematics/General_Overview_of_the_Teaching_of_Mathematics&action=edit&section=T-2)]

One of the overarching ideas that is highly valued in the teaching of mathematics in the primary grades involves the _connections_ students make in their learning. All of our mathematical understandings are intertwined. For this reason, different skills such as multiplication and understandings like those learned from the study of geometry are not taught separately. Rather, they are taught together, in such a way as to reinforce each other. Students should be encouraged to make connections by looking for patterns, exploring extremes, and forming and testing conjectures. Teachers and parents should refrain from simply "telling them how to do it." Letting student "guess at" and then check their work, learning from their mistakes as they go, leads to much stronger mathematical understandings. It also leads them to form mathematical habits that make future mathematically based explorations more efficient.

Primary and even upper school teachers recognize that understanding mathematics in the abstract is not the goal of most students. They need to see connections to the real world that inspire their learning. For this reason, teachers prefer to use real world problems that require the need for mathematical models (see below). Teachers prefer not to "teach". They prefer to "guide". Modern Educators realize that students gain true "ownership" of their understandings through, inasmuch as it is possible, making _connections_ on their own - by way of their own work and explorations. Internal links in this course, when found in this course will purposefully be placed there to emphasize what should be an ever-present concept of the connectedness of mathematical understandings.

## Manipulatives and Models[[edit](/w/index.php?title=Primary_Mathematics/General_Overview_of_the_Teaching_of_Mathematics&action=edit&section=T-3)]

One very important component of the contemporary methods used to teach math is the use of _manipulatives_ (such as toys) and _models_ (visual representations) to give added dimension to students' understandings. In each chapter of this course, the reader will find various examples of models used to teach different mathematical understandings. Often, they will find that these models serve to make _connections_ to material covered in other sections. Keep in mind that teachers in the classroom tend to be very creative and resourceful. Often, the models found in this course have many possible permutations, and can come in various shapes, sizes, and guizes. They are purposely presented here in simple forms to facilitate for the reader their identification.

  


# Numbers[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=2)]

## Numbers[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-1)]

This section is for students to read by themselves or with the help of a teacher or parent.

### Natural Numbers[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-2)]

When we count apples or oranges or elephants, we are using natural numbers. Natural numbers are 1, 2, 3, and so on without end. There is no largest natural number, one can always get a larger natural number by adding 1.[[1]](//en.wikibooks.org/wiki/Primary_Mathematics/Print_version#endnote_Numbers)

### Zero[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-3)]

Zero represents nothingness. Zero is less than every natural number. If we have zero apples or oranges or elephants, we simply do not have anything.

### Other Types of Numbers[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-4)]

## Teaching Numbers[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-5)]

This section is for teachers or home-schoolers. It is about teaching the basic concepts and conventions of numbers.

### Developing a sound concept of number[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-6)]

Children typically learn about numbers at a very young age by learning the sequence of words, "one, two, three, four, five" etc. Usually, in chanting this in conjunction with pointing at a set of toys, or mounting a flight of steps for example. Typically, 'mistakes' are made. Toys or steps are missed or counted twice, or a mistake is made in the chanted sequence. Very often, from these sorts of activities, and from informal matching activities, a child's concept of number and counting emerges as their mistakes are corrected. However, here, at the very foundation of numerical concepts, children are often left to 'put it all together' themselves, and some start off on a shaky foundation. Number concepts can be deliberately developed by suitable activities. The first one of these is object matching.

### Matching Activities[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-7)]

As opposed to the typical counting activity children are first exposed to, matching sets of objects gives a firm foundation for the concept of number and numerical relationships. It is very important that matching should be a **physical** activity that children can relate to and build on.

Typical activities would be a toy's tea-party. With a set of (say) four toy characters, each toy has a place to sit. Each toy has a cup, maybe a saucer, a plate etc. Without even mentioning 'four', we can talk with the child about 'the right number' of cups, of plates etc. We can talk about 'too many' or 'not enough'. Here, we are talking about number and important number relations without even mentioning which number we are talking about! Only after a lot of activities of this type should we talk about specific numbers and the idea of number in the abstract.

### Number and Numerals[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-8)]

Teachers should print these numbers or show the children these numbers. Ideally, the numbers should be handled by the student. There are a number of ways to achieve this: cut out numerals from heavy cardstock, shape them with clay together, purchase wooden numerals or give them sandpaper numerals to trace. Simultaneously, show the definitions of these numbers as containers or discrete quantities (using boxes and small balls, e.g., 1 ball, 2 balls, etc. Note that 0 means "no balls"). This should take some time to learn thoroughly (depending on the student).

0 1 2 3 4 5 6 7 8 9

### Place Value[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-9)]

The Next step is to learn the place value of numbers.

As you are aware, the number after 9 is 10 (called ten). This number is represented by a new place, the tens, and each time the number in the second place value increases, represents a collection of ten units. After this comes the hundred place, followed by thousands. Even though numbers can be much bigger, we will not need to create larger numbers at this time.

To help visualization, you can represent 10 as a batch of 10 coins, and 100 as 10 such batches.

### Place Values in other number systems[[edit](/w/index.php?title=Primary_Mathematics/Numbers&action=edit&section=T-10)]

Other number systems are not the same as the one we currently use. For example, the Maya Culture where there are not the ten symbols above but twenty symbols.[[2]](//en.wikibooks.org/wiki/Primary_Mathematics/Print_version#endnote_Maya) Even though there are more symbols, the place value system still remains intact.

A common number system used with computers is the use of binary, which uses the two symbols 0 and 1.

Here is how the system will be created:

Binary
0
1
10
11
100
101
110
111
1000
...

Decimal
0
1
2
3
4
5
6
7
8
...

If one uses the symbols A and B, you can get:

Binary
A
B
BA
BB
BAA
BAB
BBA
BBB
BAAA
...

Decimal
0
1
2
3
4
5
6
7
8
...

Trinary, which uses three digits, is also possible:

Trinary
0
1
2
10
11
12
20
21
22
100
...

Decimal
0
1
2
3
4
5
6
7
8
9
...

These external websites may give you enough information to figure the place value idea of any number system.

  1. **^** [Numbers](//en.wikipedia.org/wiki/Number)
  2. **^** <http://www.michielb.nl/maya/math.html>

# Adding numbers[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=3)]

## Adding two single digit numbers[[edit](/w/index.php?title=Primary_Mathematics/Adding_numbers&action=edit&section=T-1)]

Adding single digit numbers is done according to the table below. To add two single digit numbers, find one number in the first row and one number in the first column of the table. You will find the sum where that row and column intersect. These sums follow a regular pattern and are quite easy to remember with a little practice. Knowing these sums is the first step to mental arithmetic.

Addition table

+ 0 1 2 3 4 5 6 7 8 9

0
0
1
2
3
4
5
6
7
8
9

1
1
2
3
4
5
6
7
8
9
10

2
2
3
4
5
6
7
8
9
10
11

3
3
4
5
6
7
8
9
10
11
12

4
4
5
6
7
8
9
10
11
12
13

5
5
6
7
8
9
10
11
12
13
14

6
6
7
8
9
10
11
12
13
14
15

7
7
8
9
10
11
12
13
14
15
16

8
8
9
10
11
12
13
14
15
16
17

9
9
10
11
12
13
14
15
16
17
18

## Adding multiple digit numbers[[edit](/w/index.php?title=Primary_Mathematics/Adding_numbers&action=edit&section=T-2)]

To add multiple digit numbers, use the following procedure.

  1. Start at the right-most digit in each number.
  2. Add the right-most digit of each number as though they were single digit numbers.
  3. If the sum of those digits is 0 to 9, that is the right-most digit of the answer.
  4. If the sum of those digits is 10 to 18, the right-most digit of this sum is the right-most digit of the answer.
  5. Move one digit to the left in each of the two numbers you are adding.
  6. Prepare to repeat the process with these digits, with one difference. If the sum on the previous round was 10 or more, you will add 1 to the sum of these digits. If the sum on the previous round was 0 to 9, you will not add one to these digits.
  7. Repeat the process, moving left each time, remembering to add 1 if required, until there are no more digits to add. For each round, you will find the next digit to the left of the answer.

If you are using pen and paper, write the two numbers you are adding one below the other, aligning the right-most digits. Draw a line beneath the two numbers below which you will write the answer as you calculate it. As you calculate each digit of the answer, write it below the digits of the numbers above. For those rounds where the sum is 10 or more, write the "1" that you will add above the digits of the next round so that you won't forget it.
    
    
      26
    + 15
     ---
      41
    

You now know how to add numbers of any size.

## Teaching addition of numbers[[edit](/w/index.php?title=Primary_Mathematics/Adding_numbers&action=edit&section=T-3)]

When teaching young students how to add you will need to use physical items to help them understand how addition works, use items that are similar to avoid confusing younger children. It is very important that they understand the number system before trying to add or subtract. The following is an example of how to show a child how to add.

I have two blocks, and Mary has two blocks. If Mary gives me two blocks how many blocks do I have?

First show that you do in fact have two blocks, then show that Mary (or whatever the name of the person is) also has two blocks. Have the children count the number of blocks you have and the number of blocks Mary has.

Have Mary give them two blocks, now have the children count how many blocks they have. You have four blocks and now Mary has zero blocks. Some children may be able to understand addition better if you teach subtraction at the same time, some may notice that Mary has zero blocks while others may not make this connection, this depends completely on each child.

This block example should be done multiple times until every student understands how to add two single digit numbers together, if some students have trouble understanding the concept have them hold the blocks and do the above block example with each other, help them count the blocks they have. You can later increase the number of blocks slightly to help encourage further counting.

* * *

When the basic concept of adding has been introduced via a physical method children should be encouraged to learn the combinations of single digit numbers - so that addition no longer relies on counting blocks (or fingers). Especially important for mental subtraction is to learn the combinations of numbers that add to give 10.

When these basics have been taught and before moving on to adding 2 digit numbers children must learn place notation (ie that 25=20+5). Once this is learnt children can progress to adding 2 (and more) digit numbers. It needs to be explained that when you have 10 in the units column you must 'carry' that over to be 1 in the 10s column. Note that this means that 25+97 is MUCH harder than 12+13.

Depending on the child it can be useful to do this in binary as there are far fewer number combinations to remember, though this can confuse some children.

  
Due to place notation addition is usually carried out right to left:
    
    
          1   1
     45   45  45
    +37  +37 +37
    ===  === ===
           2  82 
    
    

With the 1 above the addition representing a carried digit.

It is possible to do addition left to right:
    
    
     45
    +37
    ====
     70
     12
    ====
     82
    

(adding the tens first).

Children who are taught this way will usually work out for themselves the shorter way of writing it out.

  


# Subtracting numbers[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=4)]

## Subtracting numbers[[edit](/w/index.php?title=Primary_Mathematics/Subtracting_numbers&action=edit&section=T-1)]

Subtraction is when we ask the question, if I have this many, and take away that many, how many are left? Like I may have 7 apples, but I eat 2, so I have 7-2 = 5 left.

We are not allowed to subtract a larger natural number from a smaller one because we can not have less than zero of anything.

Subtraction is just addition reversed. You can see this in the following way. If I have an addition, like 3+5 = 8, I can write it in a triangle like so:
    
    
       8
      / \
     3 + 5
    

Now the left side and the right side of the triangle are two subtractions: 8 - 3 = 5, and 8 - 5 = 3. This nicely shows that when you subtract, say, 8 - 5, you want to know what the other leg of the triangle is, given that the top is 8 and one leg is 5. To say this in another way, you want to know what must be added to 5 to get 8.

  
Below is a subtraction table for small numbers. To use it, find your first number in the left column, your second number in the top row. Then the difference is found where that row and column intersect. These differences follow a very regular pattern and are easy to remember with a little practice.

Subtraction table

- 0 1 2 3 4 5 6 7 8 9

0
0

1
1
0

2
2
1
0

3
3
2
1
0

4
4
3
2
1
0

5
5
4
3
2
1
0

6
6
5
4
3
2
1
0

7
7
6
5
4
3
2
1
0

8
8
7
6
5
4
3
2
1
0

9
9
8
7
6
5
4
3
2
1
0

10
10
9
8
7
6
5
4
3
2
1

11
11
10
9
8
7
6
5
4
3
2

12
12
11
10
9
8
7
6
5
4
3

13
13
12
11
10
9
8
7
6
5
4

14
14
13
12
11
10
9
8
7
6
5

15
15
14
13
12
11
10
9
8
7
6

16
16
15
14
13
12
11
10
9
8
7

17
17
16
15
14
13
12
11
10
9
8

18
18
17
16
15
14
13
12
11
10
9

## Subtraction with large numbers[[edit](/w/index.php?title=Primary_Mathematics/Subtracting_numbers&action=edit&section=T-2)]

When larger numbers are involved, use the following procedure. Subtraction is more complicated than addition, so pen and paper are usually required.

  * Start with the right-most digit of each number.
  * If the answer of subtracting these digits will not be less than zero, subtract these digits. The answer is the right-most digit of the answer. 
    * In this case, move one digit left in each number and repeat the process.
  * If it was not possible to perform the subtraction because the result would be less than zero, add 10 to the digit of the first number to make the subtraction possible. Do the subtraction, the answer is the right-most digit of the answer. 
    * Reduce the next digit to the left in the first number by 1. This will be possible if that digit is 1 or more. 
      * If reducing that digit was possible, the borrowing procedure is complete. Continue to the next round, moving one digit to the left in each number. You will now use the reduced digit in the next round.
      * If reducing that digit was not possible because it was 0, add 10 to it and then reduce it by one. Now one must borrow again from next left digit. Reduce the next digit to the left by 1, borrowing again if it is 0. Continue this process until you reduce by 1 a digit that is 1 or more. Then the borrowing procedure is complete. Repeat the process with the next digit of each number. You will now be using the first of the reduced digits in the next round.

To make this clearer, see the examples below.

Example 1, no borrowing required.
    
    
      27    27
    -  4, -  4
     ---   ---
       3    23
    

Example 2, 1 round of borrowing required.
    
    
          3    3
     40   <del>4</del>0   <del>4</del>0
    - 2, - 2, - 2
    ---  ---  ---
      8    8   38
    

  
Example 3, 2 rounds of borrowing required.
    
    
           09    09
     100   <del>10</del>0   <del>10</del>0
    - 15, - 15, - 15
     ---   ---   ---
       5     5    85
    

## Teaching subtraction[[edit](/w/index.php?title=Primary_Mathematics/Subtracting_numbers&action=edit&section=T-3)]

Subtracting numbers and adding numbers should be taught together, the process of teaching subtraction is the same as teaching addition. You should not teach children negative numbers at a young age as there is no way to physically show them a negative number.

* * *

As with addition it is important for children to remember the simple combinations of single digit numbers. Moving to 2 digit addition (having learnt place values), start with simple problems:
    
    
     45
    -32
    ===
    
    

first 5-2=3 second 40-30=10

  

    
    
     45
    -32
    ===
      3
     10
    

then add
    
    
     45
    -32
    ===
      3
     10
    ===
     13
    

  
To get the answer.

When this is grasped move on to harder problems:

  

    
    
     52
    -35
    ====
    

  
There are 2 methods that I would like to illustrate, the first uses carrying:

Start by saying that 5 is bigger than 2 so we take 10 from the 50 and add it to the 2 to get 12
    
    
     <s>5</s>412
    - 3 5
    ======
    

Is the usual way of writing this.

Now subtract 5 from 12 to get 7. This is another 'pair' that needs to be taught - all the numbers up to 10 subtracted from all larger numbers up to 20 are 'required', or it is possible to say that 12-2 is 10 and that 5-2 is 3 and 10-3 is 7, which is how I do it, but is not necesseraly the 'easiest' way. Different children will want to do this in different ways and will often develop their own methods for mental subtraction (ie when you don't write it down). For instance I do this: 56-38 becomes 50-40+6+2 : note that I have used both the fact that 56=50+6 and that 38=40-2 (this is why I personally feel that every child needs to know the pairs that sum to 10) and that a+b-(c-d) = a-c+b+d allthough you can 'see' this as the 'big chunk' from 40 to 50 and then the two small end bits added on (6 and 2) without expaining using algebra, again teachers should remember this general truth (that addition can be re-ordered and that minus minus = plus) in order to answer questions and with a view to the child learning it in this form.

To continue:
    
    
     <s>5</s>412
    - 3 5
    ======
        7
    

Then we take 30 from 40 (remember that it is now 40 since we gave the other 10 to the units) to get 10
    
    
     <s>5</s>412
    - 3 5
    ======
        7
       10
    

And finally add these two together
    
    
     <s>5</s>412
    - 3 5
    ======
        7
       10
    ======
       17
    

To give the answer.

An alternate method of subtraction is to perform subtraction starting on the left and heading to the right. This second method was used by some young children, which shows that young children can understand negative numbers if told about them:

The same sum:
    
    
     52
    -35
    ====
    

This time we will take 30 from 50 first (working left to right here - much more 'obvious') to get 20
    
    
     52
    -35
    ====
     20
    

Then we will take 5 from 2 to get -3
    
    
     52
    -35
    ====
     20 
     -3
    

Then we take the 3 from the 20
    
    
     52
    -35
    ====
     20 
     -3
    ====
     17
    

To finish the sum. Here students need to know what 20-3 is: This is easiest to look at as 10+10-3 and then know that 10-3 is 7 (again, numbers adding to 10).

  


# Multiplying numbers[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=5)]

## The Teaching of Multiplication[[edit](/w/index.php?title=Primary_Mathematics/Multiplying_numbers&action=edit&section=T-1)]

### Manipulatives and Models[[edit](/w/index.php?title=Primary_Mathematics/Multiplying_numbers&action=edit&section=T-2)]

In the early and middle primary grades, the operation of multiplication is first denoted by the symbol "x", and is normally first taught as repeated addition, where multiplying the numbers "3" and "5" (3 x 5) is the same as adding the number _three_ a total of _five_ times: 3 + 3 + 3 + 3 + 3 = 15, so 3 x 5 = 15. Modern curriculums initially teach this concept with _manipulatives_, or toys and objects that serve to _model_, and enable students to visualize what multiplication is. For instance, a teacher might _model_ the problem 4 x 6 by putting 4 jelly beans each in 6 bags. Subsequent models become more abstract, but the model that all students eventually learn to understand and use is called an _**area rectangle**_:

![Arearectangle.jpg](//upload.wikimedia.org/wikibooks/en/1/1f/Arearectangle.jpg)

The above area rectangle models the problem 9 x 4, which equals 36. Note that there are 4 rows and 9 columns and that the height of the rectangle is 4 units and the width (or base) is 9 units. Students find that when they count the 9 unit rows four times, they will count a total of 36 units. Soon, they come to the realization that if they were to count the 4 unit columns nine times, they arrive at the same answer. This becomes one of the ways that they learn the commutative property: a x b = b x a (See:[Wikipedia:Commutativity](//en.wikipedia.org/wiki/Commutativity)) Eventually, students should memorize all of combinations of multiplying single digit numbers, but it should be noted that just because a student has memorized their multiplication facts that they necessarily understand at an abstract level what multiplication represents. Note that the above rectangle has a total of 36 square units, which serves to introduce students to the geometric axiom that area of a rectangle is equal to the base (9 in this case) times the height(4).

By working with _area rectangles_, students make connections to geometry that serve to strengthen their understanding of multiplication. Eventually students no longer need to see the interior square units and soon come to the understanding that one or both of the lengths of these area rectangles can be expressed as the sum of two lengths. The following area diagram models the problem **16 x 3** :

![16x3arearectangle.JPG](//upload.wikimedia.org/wikibooks/en/c/c7/16x3arearectangle.JPG)

Because 16 = 10 + 6, students can visualize that the length of the above rectangle is still 16. They then can see that the larger rectangle can be expressed as the sum of the two smaller area rectangles: (3 x 10) + (3 x 6).

In upper elementary grades students are introduced to a more standard mathematical nomenclature where the mulitpication symbol "x" is no longer necessary, permitting them to notate an equation for this model as: 3(16) = 3(10) + 3(6). This is the primary model used to teach the distributive property: a(b + c) = a(b) + a(c) (See: [Wikipedia:Distributivity](//en.wikipedia.org/wiki/Distributivity))

The area model can be used to show the distributive property at an even more complex level. Consider the problem 155x360:

![155x360.jpg](//upload.wikimedia.org/wikibooks/en/a/a7/155x360.jpg)

### The Use of Different Algorithms to Solve Multiplication Problems[[edit](/w/index.php?title=Primary_Mathematics/Multiplying_numbers&action=edit&section=T-3)]

Note that in the above model, the height and width (base) of the larger area rectangle has been broken up into smaller area rectangles based on the place holder of each digit in each number, making it a representation of the **standard algorithm for multiplication**:

![360x155standardalgorithma.JPG](//upload.wikimedia.org/wikibooks/en/1/16/360x155standardalgorithma.JPG)

This standard algorithm can be further modified to make it more efficient.

![ \\begin{align}
   360 \\\\
 \\star 155 \\\\
 \\hline \\\\
 1800\\\\
1800\\  \\\\
360\\ \\ \\ \\\\
\\hline \\\\
55800
\\end{align}
](//upload.wikimedia.org/math/f/c/9/fc97f5d234bba402e205c4c560a42f65.png)

In the example above, multiplication is the same, but uses carried digits and integrates them into the same row.

  


### The Lattice Method[[edit](/w/index.php?title=Primary_Mathematics/Multiplying_numbers&action=edit&section=T-4)]

Some students find an algorithm known as the _lattice method_ easier to use because it involves the use of lines that guide the eventual values of the final place holders. It should be noted that students using this algorithm generally take more time to complete a problem. Additionally, this algorithm tends to become confusing for students when it is used with problems involving decimals. For these reasons, the use of the lattice method can become a liability in later grades. It is recommended that as soon as this model is mastered by the student, it becomes advisable to teach and encourage them to use the standard model.

![Hindu lattice.svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Hindu_lattice.svg/215px-Hindu_lattice.svg.png) ![Hindu lattice 2.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Hindu_lattice_2.svg/332px-Hindu_lattice_2.svg.png)

In the left image, the two numbers are arranged at the edges of a grid. In each cell of the grid, the two numbers in the row/colum are multiplied together to get a two digit number; the tens place is placed in the upper-left triangle in the grid, and the ones in the bottom-right corner.

In the right image, each diagonal is summed to produce a number on the bottom; digits are carried to the diagonal on the left.

### Multiplication with decimals[[edit](/w/index.php?title=Primary_Mathematics/Multiplying_numbers&action=edit&section=T-5)]

When decimals appear in a multiplication problem, they can be hidden during the multiplication. For example, when looking at the problem 21.4 x 5.63 you would ignore the decimals and perform the operation for 214 x 563. When the computation is complete and you have the answer of 120482, count the digits (or place values) to the right of the decimal in each of the original two factors. The first factor, 21.4, has one digit to the right of the decimal and the second factor 5.63 has two digits to the right of the decimal. Next, take the total of these two counts, which in this case is 3, and include the same number of digits to the right of the decimal point within the product. This makes the answer 120.482

Another way to determine where the decimal point belongs in your answer is to make an estimate. For example if you once again have the problem 21.4 x 5.63 you could make a quick estimate of 20 x 5 which is 100, so you know your answer will have to be near 100. If you complete the multiplication computation, once again ignoring the decimals (214 x 563), your answer will be 120482. The only reasonable place to insert the decimal point, based on our estimate of 100, is between the 0 and 4, making the answer 120.482

  


# Dividing numbers[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=6)]

## Dividing numbers[[edit](/w/index.php?title=Primary_Mathematics/Dividing_numbers&action=edit&section=T-1)]

When first teaching young children to divide, you may like to try getting a small group together and sharing out a number of objects evenly between them. This will ensure that the students get a clear understanding of the concept of division before moving on to the written process of short and long division.

The process of division should be taught as the reverse of multiplication, again the times tables are needed. The links between addition and subtraction and multiplication and division become important later when the 'opposite' or inverse operation will be needed to solve algebraic problems. Primary teachers can help with later learning by emphasising that division is the undoing of multiplication, as well as pointing children in the right direction for actually doing division.

The simplest division is where the multiplication is known:
    
    
    ![\\frac{10}{2} = 5](//upload.wikimedia.org/math/2/2/7/22777691c7ce511a88685eed8a76d2af.png)
    

(Note that I will write division as fractions - the formating is easier - the two are the same thing, children need to know this; I have met GCSE students, 15 and 16 years old, who were confused about this. The usual line with dots above and below (÷) is normally used for these simple problems.)

Harder are problems where the inverse is not known:
    
    
    ![\\frac{98}{2}](//upload.wikimedia.org/math/5/c/8/5c8ceee73283a9c9339612b2dfaf2e8f.png)
    

As 98 is greater than 10×2, children are unlikely to know the answer. This is where we introduce long division, which we write like this:
    
    
      __
    2/98
    

The first step is then to divide 9 by 2, however 2 does not go into 9. We find the highest number less than 9 into which 2 does go (8) and divide it by 2. The remainder (9-8=1) we add to the units as a ten (we have taken 10 away from 90 to get 80, we then add the 10 to the 8 to get 18). Having done this we divide 18 by 2 to get 9. This is often set out like this (more often it is set out as a crossed out 9 with a little 1 squished in by the 8, however this setting out is clearer and much better for harder problems):
    
    
      _49_
    2/98
     -_80_
      18
     -_18_ 
       0
    

The 8 under the 9 is 4×2 and is the lowest multiple of 2 less than 9. As the 9 is in the 10s column it is 90 and the 8 is 80. We then subtract the 80 from the original 98 and divide the resulting 18 by 2.

In a longer example we do the same thing more than once:
    
    
      _ 78487_
    2/156974
     -_140000_  (2 does not go into 1 or 15, but 2×7 is 14)
       16974  
      -_16000_  (2 does go into 16, 8 times)
         974
        -_800_  (2 does not go into 9 but it does 8) 
         174
        -_160_  (not 17 but 16)
          14
         -_14_  (and finally 7×2=14)
           0 
    

This method extends directly to division by larger numbers. For numbers larger than 12 writting out the multiples of the number to the side can be useful - only go up to what is required, calculating more as you need them. It also extends to decimals - just continue after the decimal point, allthough if the number you are dividing by is a decimal you need to multiply both it and the number you are dividing it by by 10 or 100 or 1000 etc. in order to make it an integer (whole number).

  


# Negative numbers[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=7)]

## Negative numbers[[edit](/w/index.php?title=Primary_Mathematics/Negative_numbers&action=edit&section=T-1)]

_The intended audience for this lesson is students, whether children or adults. For the same lesson, but aimed at an audience of parents and educators, whether in traditional or home-schooling environments, please see [this Wikiversity page](http://en.wikiversity.org/wiki/Primary_mathematics:Negative_numbers)._

### Introduction[[edit](/w/index.php?title=Primary_Mathematics/Negative_numbers&action=edit&section=T-2)]

Negative numbers are numbers less than zero. A convenient way to think of them is as a number owed. For example, if you have negative four apples, that means you owe four apples to someone. A dash is typically used to indicate a negative value. In our case, we would write -4 apples.

Some other examples of negative numbers are temperatures below zero, depths below sea-level, or floors in a building below the ground. Opposites can also be used, like forward and backward (negative distance), going faster and slower (negative acceleration), give and take (giving negative quantities), and heating and cooling (adding negative heat).

Negative numbers are always shown with a minus sign (-) directly in front. Positive numbers, which haven't required a label until now, are sometimes shown with a plus sign (+) directly in front, but this is optional.

### Addition involving negative numbers[[edit](/w/index.php?title=Primary_Mathematics/Negative_numbers&action=edit&section=T-3)]

When adding two negative numbers, just find the sum and make it negative:
    
    
    -4 + -3 = -7
    

This can be visualized by the use of negative _tiles_, each of which represent the number negative one (-1).

![-4+-3tiles.PNG](//upload.wikimedia.org/wikipedia/commons/thumb/8/81/-4%2B-3tiles.PNG/300px--4%2B-3tiles.PNG)

The situation gets a bit more complicated when one of the numbers to be added together is negative and the other is positive. Let's say we want to add positive two (+2) to negative three (-3). If we draw the plus and minus signs, we can pair up each positive sign with one negative sign and then they cancel each other out. This leaves one negative sign, though, meaning that +2 plus -3 equals -1:

![2+-3tiles.png](//upload.wikimedia.org/wikibooks/en/5/52/2%2B-3tiles.png)

We can write this as:
    
    
    +2 + -3 = -1
    

It doesn't matter if we change the order in addition, so we also get:
    
    
    -3 + +2 = -1
    

Some people skip the plus sign on positive numbers, this gives us these two equations:
    
    
    2 + -3 = -1
    
    
    
    -3 + 2 = -1
    

Let's review. To add two negative numbers, just add normally, then make the result negative:
    
    
    -4 + -3 = -7
    

When adding one negative number to one positive number, it can be rewritten as a subtraction problem:
    
    
    4 + -3 = 4 - 3 = 1
    

It may sometimes be necessary to change the order of the two terms to do this:
    
    
    -3 + 4 = 4 - 3 = 1
    

Any subtraction problem can also produce a negative value:
    
    
     -4 + 3 = 3 - 4 = **-1**
    

  


  


  
The last problem can be visualized as if you owed 4 apples, then got 3 (which you gave to the person to whom you owed the apples), so you would still owe them 1 apple.

### Subtraction involving negative numbers[[edit](/w/index.php?title=Primary_Mathematics/Negative_numbers&action=edit&section=T-4)]

Subtracting a negative number is the same as adding the same positive number. In other words, two negative signs makes a positive:
    
    
    5 - -2 = 5 + 2 = 7
    

Or, if both numbers are negative:
    
    
    -5 - -2 = -5 + 2 = 2 - 5 = -3
    

To illustrate the last example, imagine five negative signs, then you subtract, or take away, two negative signs, leaving you with three negative signs:

![-5--2tiles.png](//upload.wikimedia.org/wikipedia/commons/8/80/-5--2tiles.png)

It gets a bit trickier when you need to subtract more negatives than you start with. Here we start with one negative but need to take away four. This requires us to add three sets of positives and negatives, which cancel each other out. Then, once we remove the four negatives, that leaves us with three positives:

![-1--4tiles.png](//upload.wikimedia.org/wikipedia/commons/4/4f/-1--4tiles.png)

This means:
    
    
    -1 - -4 = +3
    

The other method is to say, since two negative signs make a positive sign, we instead can write:
    
    
    -1 + 4 = 4 - 1 = 3
    

Note that, unlike addition, you can't change the order in a subtraction problem, or you may get a different answer. This is true whether you are subtracting positive or negative numbers:
    
    
    9 - 8 = +1
    
    
    
    8 - 9 = -1
    

### Multiplication involving negative numbers[[edit](/w/index.php?title=Primary_Mathematics/Negative_numbers&action=edit&section=T-5)]

Just multiply normally, then apply the following rules:

  * If both numbers are negative (or both are positive), the result is positive.
  * If only one number is negative, the result is negative.

Thus:
    
    
     4 ×  3 =  12
    -4 × -3 =  12
    -4 ×  3 = -12
     4 × -3 = -12
    

You can change the order in multiplication, but, unlike addition, there isn't much advantage to doing this. Here are the previous examples in the reverse order:
    
    
     3 ×  4 =  12
    -3 × -4 =  12
     3 × -4 = -12
    -3 ×  4 = -12
    

### Division involving negative numbers[[edit](/w/index.php?title=Primary_Mathematics/Negative_numbers&action=edit&section=T-6)]

Just divide normally, then apply the following rules:

  * If both numbers are negative (or both are positive), the result is positive.
  * If only one number is negative, the result is negative.

Note that these are the same rules as were used for multiplication:
    
    
     12 ÷  3 =  4
    -12 ÷ -3 =  4
     12 ÷ -3 = -4
    -12 ÷  3 = -4
    

Here's those examples are again, using the alternate slash notation instead of the familiar division sign:
    
    
     12 /  3 =  4
    -12 / -3 =  4
     12 / -3 = -4
    -12 /  3 = -4
    

Note that you can't change the order in division, just like you can't in subtraction, or you get a different answer. Here are the previous examples in the reverse order:
    
    
     3 /  12 =  1 / 4
    -3 / -12 =  1 / 4
    -3 /  12 = -1 / 4
     3 / -12 = -1 / 4
    

### Other notations[[edit](/w/index.php?title=Primary_Mathematics/Negative_numbers&action=edit&section=T-7)]

Negative numbers are sometimes shown in parenthesis, in red, or with DB (for DeBit) next to them, in the field of accounting (that is, when dealing with money).

  


# Fractions[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=8)]

## Learning to use fractions (Visually)[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-1)]

**Fractions** or **rational numbers** are in essence the same as division, however we use them more often to express numbers less than one - for instance a half or a quarter. Fractions have a numerator (on the top) and a denominator (on the bottom). If a fraction is larger than 1 then the numerator will be larger.

### Modern methods to teach fractions[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-2)]

Today's modern methods of teaching math and fractions are drastically different than how they were taught just 10 years ago. The difference between these methods is that the later method explores the visual evidence for certain ways of manipulating fractions and whereas the earlier approach simply used variables from the beginning. Tiles of different colors sorted into groups can be useful in representing fractions visually.

### Origami and Fractions[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-3)]

There is perhaps little emphasis these days which shows the elaborate "visualization" that math requires. Students used to be taught merely by equation, but to my understanding, by teaching them such methods they tend to take the "cooking approach" to problems in that they have an inadequate sense of "visualizing" the concept the problem in their mind. What i want to do is emphasize the creative aspect of fractions while at the same time exploring the richness of why such problems are true.

Why i call this section Origami and math is because they are very much related to each other. The thing about Origami which is rich in math is that essentially folding a piece of paper proves that such a fraction exists!

in order to do this experiment, you need the following materials:

  1. Square piece of paper
  2. pencil

Steps to seeing some nice fractions

First, we have to say to ourselves, "This piece of paper is 1 piece of paper"

Now, we will explore fractions by seeing how "much" of the remaining paper we see as we fold. Every time we see the paper, we will write down the fraction of the paper on the front of it. By the time we get done, we'll have lots of fractions written on a piece of paper.

    Step 1: Obtain square piece of paper. Write "1" on it.
    Step 2: fold piece of paper in half. Write "1/2" on it.
    Step 3: Fold again in half. write "1/4"
    Step 4: Fold again in half. write "1/8"
    Step 5: Unfold the piece of paper and write lines in where there are folds in the paper

Notice: if there is a 1 on top, then whatever number is on the bottom, it takes that many "pieces" to make a "whole". For example, 1/8 needs 8 pieces to become 1 whole.

### The square model vs. the circle model[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-4)]

![A square divided into fractions](//upload.wikimedia.org/wikibooks/en/9/92/Fractions_of_a_square.jpg)
![A circle divided into fractions](//upload.wikimedia.org/wikibooks/en/0/05/Fractions_of_a_circle.jpg)

A square divided into fractions
A circle divided into fractions

### The money approach: 1, 1/4, 1/2, 1/10, 1/20, 1/100[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-5)]

A very practical way to learn fractions is the use of money, as we use it everyday.

Questions:

  1. How many quarters are in a dollar?
  2. How many dimes are in a dollar?
  3. How many nickels are in a dollar?
  4. How many pennies are in a dollar?

As said from the previous section, if there is a one on top and some number on bottom, that means it needs that much pieces to make it a whole (a whole means 1 by the way)

For example, 1/10 is the value of a dime (10 cents). You need 10 dimes (10 x 10 = 1 dollar) to get one full dollar.

### Whole number fractions[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-6)]

First of all, as always, instead of looking at complicated variable jargon, we will instead look at certain ways to "view" certain types of number. Just like art, you don't need to be an accomplished artist to draw, but rather you just need to know how to look at things better (in this case, numbers)

Since fractions have both a top (called a numerator. think "topinator") and a bottom (denominator, which "downominator" which is divided by a bar, we have to "adjust our thinking" so that we can recognize what our friendly fractions might look like.)

For example,

Q: 5 ÷ 5 reads "5 divided by 5". What does that look in Fraction form?

Well, since we are prospective mathematicians (and artists...) we will look at the magic of what the divided sign actually means:
    
    
     o
    ===
     o
    

(my divided sign) What it actually means is that dots tell you to **"Make me a number!"**  


(because Zeroes often become lonely...they want to have **value** in life...) and you see that bridge which devides them too says that, "In order to separate such ZEROES in life and making more zeroes, we say always divide your numbers from each other."

A: ![\\frac{5}{5} = 1](//upload.wikimedia.org/math/a/5/6/a562b7207d75b9da921375a8647dedef.png), which also reads "5 divided by 5".

Since we know how to recognize some fractions, we have to "see" with our naked eyes what some fractions actaully mean. The best preparation that you will have in our "artist" training is that whole numbers actually have "1" on the bottom. You may ask yourself, "How can that be? Is that even possible?"

Well Just for fun, we will go through this little exercise to show that there is indeed ones on the bottom when you have whole numbers.

**Example**: express "5" in a fraction form.

Look at our previous example about the placement of things. We now know what a denominator is and a numerator is. Since the whole number is the number of top, all we have to do is see what number is on bottom, i wonder what it is.

![\\frac{5}{?}](//upload.wikimedia.org/math/0/7/0/07014e8d837c80069f25efd73bfd3450.png)
In order to figure out what goes on bottom, we can figure it out many ways. 

Fractions are in ways actually like ratios. Such as if there were two ice creams for me and none for you, my ratio would be 2:1 and yours would be 0:1...Sad isn't it? Getting back to the point, we must think about why and how it becomes a whole number.

![\\frac{\(X\)\(X\)\(X\)\(X\)\(X\)}{\(X\)}](//upload.wikimedia.org/math/e/f/1/ef1d1caf777beab522d757022a93e027.png)
The upper part represents five oranges.  
the lower represents 1.
![=\\frac{5}{1}](//upload.wikimedia.org/math/6/c/3/6c37af63a6d6edada04ed07f54b45a3b.png)

  
So our lesson is, if there is any whole number, "1" will always go on the bottom. So if I say, "What's the number that goes on the bottom if the number is 1,2,3,4,5,6,7, or any other whole number?"

Of course, your answer should be "1", "1", "1", "1", "1", "1", "1" and always "1." I want you to remember that!

## Multiplying fractions[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-7)]

In general, multiplying fractions involves a simple formula:

![\\frac{A}{B} * \\frac{C}{D} = \\frac{A*C}{B*D}](//upload.wikimedia.org/math/7/e/7/7e7890c9ac59ac173c04c574aaa57c05.png)

Where A, B, C, and D represent the numbers within the fractions. If this seems intimidating, there are methods used to tackle the multiplication more easily.

### Traditional multiplication method[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-8)]

1\. Know what the fractions are. Write it out.

2\. If you wrote it out correctly, ignore the fractions part and look at it this way.

For example:

![\\frac{5}{3} * \\frac{5}{3} = \\frac{?}{?}](//upload.wikimedia.org/math/b/6/c/b6c6df9557ca749a7828ceec4333b350.png)

If you wrote it correctly, this is what it should look like. Also, it would be helpful if you wrote it equal to the mysteriously equal question marks, "?/?." They're there so you can see where to write your answers.

3\. Using your finger or card, cover or hide the bottom (called the denominator) so that you can concentrate on multiplying the top. Focus solely on multipling the upper portion:

![\\frac{5}{} * \\frac{5}{} = \\frac{?}{} ](//upload.wikimedia.org/math/1/0/9/1097e374f630389335031c6bf9da9bbb.png)

5 x 5 = ? (what is 5 times 5? what is the value (in cents) of 5 nickels? why 25 of course!) So if 25 is equals ?, than simply "erase" the "?" and write "25." Its that simple!

Again, since you know whats on top, do the same on the bottom:

![\\frac{}{3} * \\frac{}{3} = \\frac{}{?} ](//upload.wikimedia.org/math/5/f/8/5f8c4a8e66c8fe561c37bd147fb8e9eb.png)

Again, what is 3 x 3? Of course, it is 9. So, again, erase the "?" and write down "9"

Once you remove the finger or card, you are presented with the answer: ![\\frac{5}{3} * \\frac{5}{3} = \\frac{25}{9}](//upload.wikimedia.org/math/8/f/5/8f5b237c5f35356889bb9abe656ebf1a.png)

### Multiplying Fractions with nice pictures[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-9)]

Another good way to prove that answers are actually correct is to use a diagram or tiles to prove that it is correct. So how we do that is first write out one of our fractions on one side and the other fraction on the other side. To see what i mean, here is an example:

Here is our little lesson. We will multiply 3/4 x 1/2 = ?.

1/4

1/4

1/4

1/4
So just imagine the figure to the right is one whole 4 story "chocobar" (i will remind you that one chocobar that has 4 stories still is one chcobar) You will see that each story represents a fraction. 1/4 means its needs 4 pieces to make a whole.
    
    
     0000  __________________
    000000/                  |
     OOOO   Mr. Anaconda     | "CHOBARS ARE YUMMY!"
      \        _______       | "I hope I eat a lot     
       |      /       \      | of them!"  
       |     /         \     |  
       |    /           \    |    
       |   /             \   /  
        \-/               \-/                          
    

But the thing is, Mr. Anaconda only has enough energy to eat once a week. His mouth is 1/2-full with chocbar and the deepest he can eat is 3/4 a chocbar. How much of the chocbar has he eaten?

The fraction is set up like this:

![\\frac{3}{4} * \\frac{1}{2} = \\frac{?}{?}](//upload.wikimedia.org/math/1/2/2/1220a76aa06035fe207bb3862b8d8f1a.png)

Visually, it will look like this:

1/2 1/2

1/8
1/8

1/8
1/8

1/8
1/8

1/8
1/8
1/4

1/4

1/4

1/4

So, simplified from our little illustration is our little chocobar broken up into nice convenient blocks so that Mr. Anaconda can eat it.

1/2 1/2

1/8
1/8

1/8
1/8

1/8
1/8

1/8
1/8
1/4

1/4

1/4

1/4

From the image, you can count 3/8ths of the chocobar was eaten.

### Dividing fractions[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-10)]

As mentioned earlier, a fraction is one number divided by another. Because of textual limitations, fractions here will be represented using numbers and slashes. For example, the fraction one half will be represented as 1/2. The fraction two thirds will be represented as 2/3.

Now, on to some specifics. You may already know how to multiply fractions. Remember all you have to do is multiply the two top numbers together and put them above your two bottom numbers multiplied together. If know how to multiply fractions, dividing fractions will also be easy, and only requires one extra step.

In order to divide two fractions, you invert the second fraction and multiply. This means that you switch around the numerator (top) and denominator (bottom) of the fraction before multiplication.

Let's look at examples using our two fractions. First, let's divide the fraction 1/2 by the fraction 1/2. Since we are dividing a number by itself, we should expect to get an answer of 1.

Here is our problem.

![\\frac{1}{2}\\div\\frac{1}{2} = \\frac{1}{2} * \\frac{2}{1} = \\frac{1*2}{2*1} = \\frac{2}{2} = 1](//upload.wikimedia.org/math/b/5/5/b55834a6117506653acbb0b3711993df.png)

Now let's try another example.

![\\frac{1}{2}\\div\\frac{2}{3} = \\frac{1}{2} * \\frac{3}{2} = \\frac{1*3}{2*2} = \\frac{3}{4}](//upload.wikimedia.org/math/3/8/6/38672f66c118b181395fa9cf9c7c03e1.png)

Following these simple steps will let you solve any fraction division problem.

There is also an alternate way to divide fractions using an equivalent fraction approach. You obtain this by multiplying the numerator and denominator so that they're equivalent, cancelling out the denominator, and creating a fraction from the two remaining numerators.

![\\frac{1}{2}\\div\\frac{2}{3} = \\frac{3}{6}\\div\\frac{4}{6} = \\frac{3}{4} ](//upload.wikimedia.org/math/0/9/5/095fe6b6260dfebd5f494bb711a220ed.png)

Here is another example:

![\\frac{2}{5}\\div\\frac{3}{4} = \\frac{8}{20}\\div\\frac{15}{20} = \\frac{8}{15} ](//upload.wikimedia.org/math/1/6/0/160f1f48fcf4f5d74852d6371a7935ee.png)

It works because the common denominator will always be ![\\frac{n}{n} = 1 ](//upload.wikimedia.org/math/9/8/1/98111795db674081939f73d305e9637b.png)

### Adding fractions[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-11)]

Fractions that have the same or "Common" denominator are called "Like" fractions.

1/3, 2/3

(one-third, two-thirds)

To add Like fractions together such as these:

![\\frac{1}{3} + \\frac{2}{3} = ? ](//upload.wikimedia.org/math/9/7/6/976da6ade7cc9b3e96368d12f0b547a5.png)

  
1\. Add the numerators (the top numbers):

  * 1 + 2 = 3 (one plus two equals three)

2\. Use the common denominator (the bottom numbers):

  * /3

All together it looks like this:

![\\frac{1}{3} + \\frac{2}{3} = \\frac{3}{3} ](//upload.wikimedia.org/math/2/6/c/26cd77cdbbcd8e4ee4eb23df7c3103a0.png)

3\. Simplify the answer as much as you can by dividing the denominator into the numerator.

  * ![\\frac{3}{3} = 1](//upload.wikimedia.org/math/9/d/7/9d7d4de370f6af78c02ab5c0a1980db8.png)

If the numerator is now larger than the denominator it might look like this:

4/5 + 3/5 = 7/5 (four-fifths plus three-fifths equals seven-fifths)

This is simplified by creating a mixed number:

  * 5 goes into 7 one time, with 2 left over. Put the remainder (2) over the denominator (5).
  * ![\\frac{7}{5} = 1 \\frac{2}/{5} ](//upload.wikimedia.org/math/2/2/2/2223ff9662835d9d529c67163872863c.png)

To add or subtract fractions with different denominators, you must first convert them to equivalent fractions with common denominators.

### Multiplying to get equivalent fractions[[edit](/w/index.php?title=Primary_Mathematics/Fractions&action=edit&section=T-12)]

In some cases, you may need to add 1/2 to 1/3:

![\\frac{1}{2}+\\frac{1}{3}=?](//upload.wikimedia.org/math/f/f/e/ffe2c3988db3ab130fe7a2a6da9fb53a.png)

You will first have to convert the fractions into like fractions. The easiest means of doing so is to multiply the top and bottom of the left fraction by the bottom on the right, and the top and bottom of the right fraction by the bottom on the left:

![\\frac{1*3}{2*3}+\\frac{1*2}{3*2}=?](//upload.wikimedia.org/math/3/1/f/31f0e72f8e45ece463051efbb129faa1.png)

![\\frac{3}{6}+\\frac{2}{6}=?](//upload.wikimedia.org/math/e/0/c/e0cb8e6bdbb18bb2c958ca02146e2ac5.png)

The addition can now take place as expected:

![\\frac{3}{6}+\\frac{2}{6}=\\frac{5}{6}](//upload.wikimedia.org/math/7/d/7/7d7e68482e284180da4d9b302875c674.png)
    
    
    (rational numbers)
    

# Working with fractions[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=9)]

## Working with fractions[[edit](/w/index.php?title=Primary_Mathematics/Working_with_fractions&action=edit&section=T-1)]

Mixed numbers and top heavy fractions:

A mixed number is an integer and a fraction, eg 2 and a half, a top heavy fraction is a fraction with a larger numerator than demominator, eg 3/2. For multiplication and division you must not use mixed numbers. They can be used in addition and subtraction (do the integers and fractions seperately and combine the result) if this is not too confusing.

Simplest terms: Multiplying (or dividing) the numinator and denominator by the same number will not change the fraction. A fraction is put into its simplest terms by dividing both by the largest integer that goes into both a whole number of times, this can be done in stages using small integers such as 2 and 3, 5 and 10 repeatedly.

Multiplication:
    
    
    ![\\frac{a}{c}*\\frac{b}{d} = \\frac{ab}{cd}](//upload.wikimedia.org/math/1/7/4/1743cbe893251495d76d37d0c8aab538.png)
    

Where ab=a*b.

Division:

To divide fractions; remember that a fraction **is** a division. Fractions can be stacked like so:
    
    
    ![\\frac{\\frac{a}{b}}{\\frac{c}{d}}](//upload.wikimedia.org/math/2/b/e/2be800d9b5e524256e3954503a1740c7.png)
    

The rule to remember to simplify is that anything under an odd number of lines goes on the bottom and anything under an even number of lines goes on the top (0 is even for this purpose) thus:
    
    
    ![\\frac{ad}{bc}](//upload.wikimedia.org/math/4/8/d/48d26f07ceac5db8cb2c1c2f7ae3f049.png)
    

It is easier (perhaps) to remember that the the second fraction in the division gets turned upside down.

  
Addition and subtraction:

For addition the denomintators of the two fractions must be the same - if this is so then simply add (or subtract) the numerators:

  

    
    
    ![\\frac{a}{b}+\\frac{c}{b} = \\frac{a+c}{b}](//upload.wikimedia.org/math/b/1/9/b1987c8687a672810cd4f018dda2bc76.png)
    

If the denominators are not the same then a common denominator must be found, the simplest way to do this is take the product of the denominators allthough if one is a multiple of the other simply multiplying it by the aplicable integer works aswell. Remember to multiply the numerators by the same number. In general:
    
    
    ![\\frac{a}{b}+\\frac{c}{d} = \\frac{ad+cb}{bd}](//upload.wikimedia.org/math/2/4/e/24e535341c4da2e38f339e547f61eab7.png)
    

  
But for example
    
    
    ![\\frac{a}{5}+\\frac{b}{10} = \\frac{2a+b}{10}](//upload.wikimedia.org/math/9/b/c/9bc826f80615896cd2993b66b7b7cea2.png)
    

Is possible.

Remember that young children will not understand the algebraic formulation here. The art of primary teaching is finding a way to make this make sense to young children. However, teachers need to know these general rules.

  


# Decimals[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Primary_Mathematics/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

  


  


## Decimals[[edit](/w/index.php?title=Primary_Mathematics/Decimals&action=edit&section=T-1)]

Decimals are a means of representing a partial number without using fractions. You will see them when dealing with currency, and may find them in other situations as well. They will otherwise appear to be normal numbers.

## Addition and Subtraction[[edit](/w/index.php?title=Primary_Mathematics/Decimals&action=edit&section=T-2)]

When adding or subtracting decimal numbers, the decimal points need to be aligned. If this causes missing digits on the right, then treat them as zeros.
    
    
     16.42
    + 2.3
    ------
     18.72
    

## Multiplication[[edit](/w/index.php?title=Primary_Mathematics/Decimals&action=edit&section=T-3)]

When multiplying numbers, the right-most digits are aligned, with the decimal point being placed within the normal location for the number. Multiply the two numbers as if they are normal numbers to get the initial result. Next, count the number of digits to the right of the decimal points of the two numbers; the total of the two counts indicates the number of digits to the right of the decimal point.
    
    
      8.32 -- 2 digits after decimal
     * 3.2 -- 1 digit after decimal
    ------
     1 664
    24 96
    ------
    36.624 -- 2 + 1 = 3 digits after decimal
    

## Division[[edit](/w/index.php?title=Primary_Mathematics/Decimals&action=edit&section=T-4)]

Normally, the decimal point in the quotient is in the same location as the dividend. If a decimal point appears in the divisor, the quotient's point is moved to the right by the same number of digits in the quotient.

## Fractions to Decimals[[edit](/w/index.php?title=Primary_Mathematics/Decimals&action=edit&section=T-5)]

Converting a fraction to a decimal simply involves long division. However, some numbers may repeat infinitely as they can't be described in decimal form.

If you need to add digits to continue the decimal, simply add zeros to the quotient.
    
    
          2.375
        ___
    24 / 57
         48
         --
          9.0
          7.2
          ---
          1.80
          1.68
          ----
            120
            120
            ---
              0
    

In the example above, you get an exact value.
    
    
          2.157...
        ___
    19 / 41
         38
        ---
          3.0
          1.9
          ----
          1.10
           .95
          ----
            150 
            133
            ---
             17
    

In the example above, the number continues on without end. In general, you will want to stop after only a few digits or until you find the repeating pattern. When you find the repeating pattern, a simple notation is to draw a single line above the digits that continuously appear.

## Converting to fractions[[edit](/w/index.php?title=Primary_Mathematics/Decimals&action=edit&section=T-6)]

Finite-length decimals are trivially converted into fractions. The numberator contains the number without the decimal point, and the denominator starts with 1, and has an additional '0' appended for each digit to the right of the decimal point.

Infinite-length decimals are more complex, but are possible. The procedure for converting them requires a knowledge of [Algebra](/wiki/Algebra), but will be summarised in an example. First, write x as the repeating decimal:
    
    
           x =      0.71428571428571428571428571428571...
    

Find the length of the repetition, and both sides by 10 until they line up again:
    
    
    1000000x = 714285.71428571428571428571428571428571...
    

Subtract the first equation from the second, which should look like this:
    
    
     999999x = 714285
    

Divide both sides by the left number:
    
    
           x = 714285/999999
    

Reduce to lowest terms. In this case, both sides are divisible by 142857:
    
    
           x = 5/7
    

## Significant digits[[edit](/w/index.php?title=Primary_Mathematics/Decimals&action=edit&section=T-7)]

In practice, decimal numbers (such as those obtained from measurements), may have a degree of error. Thus, it might not make sense to always keep full precision when subtracting 0.001 from 1 million.

When adding or subtracting, a result is normally kept to the same precision as the least precise number. When multiplying or dividing, a result contains the same number of significants as the one with the least number of significant digits.

When dealing with measurements, there is usually only need for at most three significant digits. Handheld calculators, having no direct concept of significant digits, will simply display them all and will have to be rounded manually.

More information on significant digits will be found in a later chapter.

  


# Metric[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=11)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Primary_Mathematics/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

  


  


The metric system, originating in France in 1791, is the current international standard for measurements. In common use, there are three units that are frequently used in the metric system:

  * Meter (m) - a unit of length
  * Gram (g) - a unit of mass
  * Second (s) - a unit of time.

The two tangible units, meter and gram, can be converted to larger and smaller representations simply by multiplying by 10.

## Meter[[edit](/w/index.php?title=Primary_Mathematics/Metric_system&action=edit&section=T-1)]

A meter is the standard unit of length; it is approximately equal to 39.37 inches (3.28 feet) in the US customary system.

A normal meter stick will have 10 divisions, each representing 1 decimeter (dm). This is further divided by 10 to give a total of 100 centimeters (cm), and then by ten again to give 1000 millimeters (mm).

1000 meters equals 1 kilometer (km).

In the UK a meter is known as a "metre".

## Gram[[edit](/w/index.php?title=Primary_Mathematics/Metric_system&action=edit&section=T-2)]

The gram is a unit of mass. It is commonly used to state weights as well.

There are 1000 grams in a kilogram (kg).

1000 kilograms is equal to 1 tonne (t).

A milligram (mg) is 1/1000th of a gram. Milligrams are often used in medicine and chemistry.

## Liter[[edit](/w/index.php?title=Primary_Mathematics/Metric_system&action=edit&section=T-3)]

The liter (L) is a unit of liquid volume, equal to a cube of water measuring 10cm * 10cm * 10cm. A milliliter (mL) is equal to one cubic centimeter.

  


  


# Time math[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=12)]

## Time math[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-1)]

Time is often difficult to perform mathematical operations upon due to all the different units used.

### Units[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-2)]

#### Seconds[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-3)]

The second is the basic unit of time. In scientific areas, seconds are often used for even large time measurements, with scientific notation applied in such cases. In common usage, however, many other time intervals are also used.

Seconds are abbreviated "sec" or just "s".

#### Minutes[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-4)]

There are 60 seconds per minute.

Minutes are abbreviated "min" or just "m".

#### Hours[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-5)]

There are also 60 minutes per hour, which means there are 60×60 or 3600 seconds per hour.

Hours are abbreviated "hr" or just "h".

#### Days[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-6)]

There are 24 hours per day, which means there are 60×24 or 1440 minutes per day. This, in turn, means there are 60×60×24 or 86400 seconds per day.

Days are abbreviated "d".

#### Weeks[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-7)]

There are 7 days per week. This means there are 7×24 or 168 hours per week.

Weeks are abbreviated "wk".

#### Months[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-8)]

There are 4 1/3 weeks per month, on average, and from 28 to 31 days per month, as follows:

    28 or 29 days, depending on leap year (see the section below for leap year info):

    

    

  * February

    30 days:

    

    

  * April, June, September, and November.

    31 days:

    

    

  * All remaining months.

Months are abbreviated "mo"

##### Memory methods[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-9)]

Recalling which months have how many days can be tricky. There are some memory methods available to assist you, however:

  * **Knuckle method.** Place your two closed fists together and use the knuckles and valleys between the knuckles to represent months:
    
    
      J   M   M   J    A   O   D
      A   A   A   U    U   C   E
      N   R   Y   L    G   T   C
      _   _   _   _    _   _   _   _
     / \_/ \_/ \_/ \  / \_/ \_/ \_/ \
    |               ||               |
    |   F   A   J   ||   S   N       |
    |   E   P   U   ||   E   O       |
    |   B   R   N   ||   P   V       |
    |               ||               |
    |              /  \              |
    |             /    \             |
    |            /      \            |
    

    The knuckles represent months with 31 days while the valleys represent months with 30 days (or less, in the case of February). Note that the thumbs and the gap between the hands are not used, and neither is the last valley and last knuckle.

  * **Rhyme method.**

"30 days hath September, April, June, and November..."

#### Years[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-10)]

The length of the year is based on how long it takes the Earth to revolve once around the Sun, which is approximately 365 ¼ days.

Regular years have 365 days, while leap years have 366 (due to the addition of February 29th).

Normal years have 52 weeks and 1 day, while leap years have 52 weeks and 2 days.

All years have 12 months.

Years are abbreviated "yr" or just "y".

##### What years are leap years ?[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-11)]

Since there is a fractional number of days in a year, not an integer, some adjustments need to be made to prevent drift from occurring (where January would eventually end up in the summer). There are occasional "leap seconds" added to some years, in addition to leap years, to keep this from happening. Here are the rules for leap years:

  * Every fourth year is a leap year:

    

  * Except every 100th year, which is not a leap year.

    

    

  * Except every 400th year, which is a leap year.

    Here's a list of "every 4th year" from 1900 through 2100. All are leap years except for 1900 and 2100:

    

  * 1900 (Not a leap year, due to the "every 100th year" rule).
  * 1904
  * 1908
  * 1912
  * 1916
  * 1920
  * 1924
  * 1928
  * 1932
  * 1936
  * 1940
  * 1944
  * 1948
  * 1952
  * 1956
  * 1960
  * 1964
  * 1968
  * 1972
  * 1976
  * 1980
  * 1984
  * 1988
  * 1992
  * 1996

    

  * 2000 (Is a leap year, due to the "every 400th year" rule).
  * 2004
  * 2008
  * 2012
  * 2016
  * 2020
  * 2024
  * 2028
  * 2032
  * 2036
  * 2040
  * 2044
  * 2048
  * 2052
  * 2056
  * 2060
  * 2064
  * 2068
  * 2072
  * 2076
  * 2080
  * 2084
  * 2088
  * 2092
  * 2096
  * 2100 (Not a leap year, due to the "every 100th year" rule).

#### Longer periods[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-12)]

  * Decade = 10 years
  * Century = 100 years
  * Millenium = 1000 years
  * Myr = million years
  * Byr = billion years

### Systems[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-13)]

#### 12 hour clock[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-14)]

In this traditional system, the first 12 hours in the day are called "AM" ("ante meridian", or before noon) and the last 12 are called "PM" ("post meridian", or after noon). One oddity of this system is that no zero hours are used, with 12 (from the previous time period) used in it's place.

#### 24 hour clock[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-15)]

In this system, sometimes called military time, the first number is zero, and the full 24 hours is counted:
    
    
    Common name           12-hour clock   24-hour clock
    =================     =============   =============
    "Midnight"            12:00 AM         0:00
    "1 in the morning"     1:00 AM         1:00
    "2 in the morning"     2:00 AM         2:00
    "3 in the morning"     3:00 AM         3:00
    "4 in the morning"     4:00 AM         4:00
    "5 in the morning"     5:00 AM         5:00
    "6 in the morning"     6:00 AM         6:00
    "7 in the morning"     7:00 AM         7:00
    "8 in the morning"     8:00 AM         8:00
    "9 in the morning"     9:00 AM         9:00
    "10 in the morning"   10:00 AM        10:00
    "11 in the morning"   11:00 AM        11:00
    "Noon"                12:00 PM        12:00 
    "1 in the afternoon"   1:00 PM        13:00
    "2 in the afternoon"   2:00 PM        14:00
    "3 in the afternoon"   3:00 PM        15:00
    "4 in the afternoon"   4:00 PM        16:00
    "5 in the afternoon"   5:00 PM        17:00
    "6 in the evening"     6:00 PM        18:00
    "7 in the evening"     7:00 PM        19:00
    "8 in the evening"     8:00 PM        20:00
    "9 in the evening"     9:00 PM        21:00
    "10 in the evening"   10:00 PM        22:00
    "11 in the evening"   11:00 PM        23:00
    

In the military, the time isn't necessarily reset at midnight. For example, a two-day operation may go up to 48:00 (said "forty-eight hundred"). This is done to make time math simpler. So, for example, the time between 20:00 and 40:00 is 20 hours.

#### Decimal time[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-16)]

There was an attempt at decimal time during the French Revolution, but it never caught on. Days were divided into 10 "hours", which were divided into 100 "minutes" each. "Weeks" were also 10 days long. No metric time system has ever been established.

### Operations[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-17)]

#### Addition[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-18)]

Addition of a time interval to a starting time (or of two time intervals) works like normal addition, except that you may want to convert to different units.

##### Examples[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-19)]

  * 43 seconds + 2 seconds = 45 seconds
  * 43 seconds + 22 seconds = 65 seconds, which you may want to convert to 1 minute and 5 seconds
  * 43 seconds + 11:59:22 AM = 12:00:05 PM

#### Subtraction[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-20)]

Subtraction of a time interval from an ending time (or a time interval from another) works like normal subtraction, except that you may want to convert to different units.

##### Examples[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-21)]

  * 45 seconds - 2 seconds = 43 seconds
  * 1 minute and 5 seconds - 43 seconds = 65 seconds - 43 seconds = 22 seconds.
  * 12:00:05 PM - 43 seconds = 11:59:22 AM

#### Multiplication[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-22)]

You can multiply a time interval by a scalar (unitless value), but it doesn't yet make sense to multiply specific time with anything else or two time intervals together. As before, you may want to change units to something that makes sense or perform a different operation.

In [Physics](/wiki/Physics), you may see time intervals being multiplied. However, this is beyond the scope of elementary math and should be reserved until you are ready for the course (which requires knowledge of [algebra](/wiki/Algebra).)

##### Examples[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-23)]

  * 43 seconds × 2 = 86 seconds = 1 minute and 26 seconds
  * 1 day, 21 hours, 45 minutes, and 43 seconds × 2 = 2 days, 42 hours, 90 minutes, and 86 seconds = 2 days, 42 hours, 91 minutes, and 26 seconds = 2 days, 43 hours, 31 minutes, and 26 seconds = 3 days, 19 hours, 31 minutes, and 26 seconds

  


#### Division[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-24)]

You can divide a time interval by a scalar (unitless value), but it doesn't make sense to divide one time by another. As before, you may want to change units.

You may also see a scalar divided by a time interval. This can be used to show frequency (how often something occurs), or velocity (how fast something moves.)

Repeated division by a time interval appears in physics and is used to denote acceleration. However, this concept is beyond the scope of this book.

##### Examples[[edit](/w/index.php?title=Primary_Mathematics/Time_expressions&action=edit&section=T-25)]

  * 1 minute and 25 seconds / 2 = 85 seconds / 2 = 42.5 seconds
  * 30 / 5 seconds = 6 / 1 second (indicates something happens six times every second)
  * 50 km / 2 hours = 25 km / 1 hour (indicates somthing moving at 25km/h).

  


# Unit math[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=13)]

## Unit math[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-1)]

Until now, most of the numbers we've used have been scalar (unitless). However, in the real world, most numbers have units associated with them. There are special rules which apply when doing math on numbers with units.

### Addition and subtraction[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-2)]

The following rules apply:

  * If the units are the same, add or subtract normally.
  * If the units are different, then:

    

  * If they can be converted to the same units, then addition and subtraction can occur.

    

  * If they can't be converted to the same units, then addition and subtraction are not possible.

#### Examples[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-3)]
    
    
    4 apples + 3 apples = 7 apples
    4 apples - 3 apples = 1 apple
    

In the following case, we try adding apples and oranges, but encoutner a roadblock:
    
    
    4 apples + 3 oranges = ?
    

These two items cannot be directly added together. However, depending on the context, it may be possible to convert them into "pieces of fruit" and add them. The result would look like this:
    
    
    4 pieces of fruit + 3 pieces of fruit = 7 pieces of fruit
    

While the same may apply to subtraction, it is highly dependent on context (for example, the problem may be solvable if you treat it as receiving 4 pieces of fruit and giving 3 pieces of fruit in exchange.).

More commonly, you will encounter situations where you use standard unit conversion (e.g. 1 foot = 12 inches):
    
    
    1 foot + 3 inches = 12 inches + 3 inches = 15 inches
    

A complex example where unit conversion is required:
    
    
      60 MPH - 30 fps
    = 60 miles/hr - 30 ft/sec 
    = (60 <s>miles</s> × 5280 ft/<s>mile</s>)/(1 <s>hr</s> × 3600 sec/<s>hr</s>) - 30 ft/sec 
    = 316,800 ft / 3600 sec - 30 ft/sec 
    = 88 ft/sec - 30 ft/sec 
    = 58 ft/sec
    

This method is called unit cancellation, and is quite useful is science and engineering.

Here is an example where it isn't possible to convert to the same units:
    
    
    4 apples + 3 degrees = ?
    

### Multiplication and division[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-4)]

When multiplying or dividing numbers with units, the units are also multiplied or divided.

#### Examples[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-5)]

Here's are examples using the same base units:
    
    
    2 feet × 3 feet = 6 square feet = 6 ft²
    6 square feet / 2 feet = 3 feet
    2 meters × 3 meters × 4 meters = 24 cubic meters = 24 m³
    24 m³ / 2 m = 12 m²
    

Here are examples using different base units:
    
    
    2 feet × 3 pounds = 6 foot pounds (a unit of torque)
    100 miles / 2 hours = 50 miles/hr = 50 MPH
    60 pounds / 4 square inches = 15 pounds/square inch = 15 PSI
    200 miles / 10 MPH = 200 miles / (10 miles/hr) = 200 <s>miles</s> × (1 hr / 10 <s>miles</s>) = 20 hrs 
    

It is also possible to multiply or divide a number with units by a scalar (a unitless number):
    
    
    3 apples × 2 = 6 apples
    3 apples / 2 = 1.5 apples
    

So, two groups of 3 apples each gives us 6 apples, while 3 apples divided into 2 equal groups gives us 1.5 apples per group.

### Powers, roots, and exponents[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-6)]

Just like multiplication or division, the operation also applies to the units.

#### Examples[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-7)]
    
    
    (2 ft)³ = 2³ ft³ = 8 ft³ = 8 cubic ft 
    
    
    
    (100 miles²)½ = 10 miles
    

So, in the first case we calculated that a cube 2 feet long on each side has a volume of 8 cubic feet, while in the second case we calculated that a square plot of 100 square miles of land would be 10 miles long on each side.

To distinguish between feet, square feet, and cubic feet, the term "linear feet" is sometimes used to clarify that we are talking about regular feet, not square or cubic feet.

### Unit conversion[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-8)]

Sometimes it is necessary to do a unit conversion by itself. The unit cancellation method shown previously can be applied to convert from any unit to any other compatible units.

#### Examples[[edit](/w/index.php?title=Primary_Mathematics/Unit_expressions&action=edit&section=T-9)]

Convert 10 miles per day to inches per second:
    
    
    (5280 ft/<s>mile</s>) × 10 <s>miles</s>/day = 52,800 ft/day
    (12 inches/<s>ft</s>) × 52800 <s>ft</s>/day = 633,600 inch/day
    633,600 inch/<s>day</s> × (1 <s>day</s>/24 hr) = 26,400 inch/hr
    26,400 inch/<s>hr</s> × (1 <s>hr</s>/60 min) = 440 inch/min
    440 inch/<s>min</s> × (1 <s>min</s>/60 sec) = 7.33333 inch/sec
    

  


# Introduction to significant digits[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=14)]

**Significant digits** are one crude way to denote a range of values. They apply to measured or estimated numbers where the quantity can vary from the provided value.

### Examples[[edit](/w/index.php?title=Primary_Mathematics/Introduction_to_significant_digits&action=edit&section=T-1)]

By default, significant digits are measured by
    
    
    2000 means 2000 ± 500   =  1500 to 2500
    200  means  200 ± 50    =   150 to 250
    20   means   20 ± 5     =    15 to 25
    2    means    2 ± 0.5   =   1.5 to 2.5
    0.2  means  0.2 ± 0.05  =  0.15 to 0.25
    0.02 means 0.02 ± 0.005 = 0.015 to 0.025
    

(Note: The first three examples may have more significant digits depending on context.)

A terminal decimal point can be added to change the meaning of the first three cases:
    
    
    2000. means 2000 ± 0.5 = 1999.5 to 2000.5
     200. means  200 ± 0.5 =  199.5 to 200.5
      20. means   20 ± 0.5 =   19.5 to 20.5
    

An additional zero after the decimal point also changes the meaning:
    
    
    2000.0 means 2000 ± 0.05 =  1999.95 to 2000.05
     200.0 means  200 ± 0.05 =   199.95 to 200.05
      20.0 means   20 ± 0.05 =    19.95 to 20.05
       2.0 means    2 ± 0.05 =     1.95 to 2.05
    

Here we've added another zero after the decimal point:
    
    
    2000.00 means 2000 ± 0.005 = 1999.995 to 2000.005
     200.00 means  200 ± 0.005 =  199.995 to 200.005
      20.00 means   20 ± 0.005 =   19.995 to 20.005
       2.00 means    2 ± 0.005 =    1.995 to 2.005
       0.20 means  0.2 ± 0.005 =    0.195 to 0.205
    

### Limitations[[edit](/w/index.php?title=Primary_Mathematics/Introduction_to_significant_digits&action=edit&section=T-2)]

  * Significant digits only allow for ranges where the amount that can be added to the base value and the amount that can be subtracted are the same.
  * The value added and subtracted must also be 5 times or divided by a factor of 10.
  * Exact values have no error or variation. Thus, $8472.35 will only mean $8472.35.

### Use with scientific and engineering notation[[edit](/w/index.php?title=Primary_Mathematics/Introduction_to_significant_digits&action=edit&section=T-3)]

To represent certain ranges, like 2000 ± 50, it's necessary to use either scientific or engineering notation:
    
    
    0.20 × 104 Mistake: this is neither proper scientific notation nor proper engineering notation:
    

Proper scientific notation must have a nonzero digit to the left of the decimal point. Proper engineering notation must use multiples of 3 (e.g., 5 x 103, 603 x 106, 42.3 x 109, ...)
    
    
    2.0 × 103
    

### Beyond significant digits[[edit](/w/index.php?title=Primary_Mathematics/Introduction_to_significant_digits&action=edit&section=T-4)]

More complex ranges can be represented using the ± sign:
    
    
    2000 ± 38.3
    

If the plus and minus values are different, the actual range can be listed, or separate plus and minus values can be listed. The range shown to the right of the plus and minus symbol is called an error. In this example, there are two significant digits, and one doubtful digit.

Note that the ± sign shouldn't be confused with the ± operator, which can indicate either an exact addition or subtraction. This will be covered in [Algebra](/wiki/Algebra).

### Accumulating error[[edit](/w/index.php?title=Primary_Mathematics/Introduction_to_significant_digits&action=edit&section=T-5)]

As you perform mathematical operations with numbers, the error also increases.

  * When you add or subtract numbers, the ranges are added together.
  * When multiplying numbers, the error is converted into a percent of the main value (e.g. 20 ± 1 becomes 20 ± 5%). The percentages the two measurements added together, and the percentage is converted back to reflect the error of the original number.

  


# Powers, roots, and exponents[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=15)]

## Exponents[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-1)]

**Exponents**, or **powers**, are a way of indicating that a quantity is to be multiplied by itself some number of times. In the the expression 25, 2 is called the **base** and 5 is called the exponent, or power. 25 is shorthand for "multiply five twos together": 25 = 2×2×2×2×2 = 32. Notice that the exponent tells us how many bases to multiply, _not_ how many multiplications to perform. (In fact, the number of multiplications is _one less_ than the number of bases.) 25 is read "two raised to the fifth power" or simply "two to the fifth."

In general,

![x^n = \\underbrace{x \\cdot x \\cdot x \\cdot \\,\\,\\cdots\\,\\, \\cdot x}_{n factors}](//upload.wikimedia.org/math/e/6/7/e67a7f33b255ddaba2efeb3e516bc74d.png)

where there are _n x'_s to be multiplied.

### Squaring numbers[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-2)]

A convenient way to note that a number is to be multiplied by itself (for example 5×5) is to say that the number is **squared**. To help visualize this, picture a square which is 5 units long and 5 units wide. This square will then have an area of 5×5 or 25 square units. A nice way to write "5 squared" is 52, where 5 is called the **base** and 2 is called the **exponent**.

![5x5.PNG](//upload.wikimedia.org/wikipedia/commons/7/74/5x5.PNG)

Area of five rows by five columns = 5 × 5 = 52 = 25.

#### Table of perfect squares[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-3)]

You may want to memorize some perfect square numbers:

Square
Result

02
0

12
1

22
4

32
9

42
16

52
25

62
36

72
49

82
64

92
81

102
100

112
121

122
144

132
169

142
196

152
225

162
256

172
289

182
324

192
361

202
400

### Cubing numbers[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-4)]

Similarly, a convenient way to note that a number is to be multiplied by itself and then itself again (for example 5×5×5) is to say that the number is **cubed**. To help visualize this, picture a cube which is 5 units long, 5 units wide, and 5 units high. This cube will then have a volume of 5×5×5 or 125 cubic units. A nice way to write "5 cubed" is 53, where 5 is called the base and 3 is called the exponent.

![5cube.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/ca/5cube.svg/431px-5cube.svg.png)

Volume of a cube with height, width, and length of five = 5 × 5 × 5 = 53 = 125.

#### Table of perfect cube numbers[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-5)]

You may want to memorize some perfect cube numbers:

Cube
Result

03
0

13
1

23
8

33
27

43
64

53
125

63
216

73
343

83
512

93
729

103
1000

### Higher powers[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-6)]

Numbers higher than three may also be used as exponents, although there is no common term for numbers raised to a fourth power or higher. For example, 54 = 5×5×5×5 = 625.

#### Table of higher powers[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-7)]

A table of xn.  
Bases are on the left, exponents are across the top:

xn 0 1 2 3 4 5 6 7 8 9 10 11 12 ... n

0
 ?
0
0
0
0
0
0
0
0
0
0
0
0
0

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1

2
1
2
4
8
16
32
64
128
256
512
1024
2048
4096
2n

3
1
3
9
27
81
243
729
2187
6561
19683
59049
3n

4
1
4
16
64
256
1024
4096
16384
65536
262144
1048576
4n

5
1
5
25
125
625
3125
15625
78125
390625
1953125
9765625
5n

6
1
6
36
216
1296
7776
46656
279936
1679616
10077696
60466176
6n

7
1
7
49
343
2401
16807
117649
823543
5764801
40353607
282475249
7n

8
1
8
64
512
4096
32768
262144
2097152
16777216
134217728
1073741824
8n

9
1
9
81
729
6561
59049
531441
4782969
43046721
387420489
3486784401
9n

10
1
10
100
1000
10000
100000
1000000
10000000
100000000
1000000000
10000000000
10n

11
1
11
121
1331
14641
161051
1771561
19487171
214358881
2357947691
25937424601
11n

12
1
12
144
1728
20736
248832
2985984
35831808
429981696
5159780352
61917364224
12n

13
1
13
169
2197
28561
371293
4826809
62748517
815730721
10604499373
137858491849
13n

14
1
14
196
2744
38416
537824
7529536
105413504
1475789056
20661046784
289254654976
14n

15
1
15
225
3375
50625
759375
11390625
170859375
2562890625
38443359375
576650390625
15n

16
1
16
256
4096
65536
1048576
16777216
268435456
4294967296
68719476736
1099511627776
16n
...

x
1
x
x2
x3
x4
x5
x6
x7
x8
x9
x10
x11
x12

Note: 00 is undefined.

## Properties of Exponents[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-8)]

There are several properties of exponents which are frequently used to manipulate and simplify algebraic and arithmetic expressions.

![
\\begin{align}

x^mx^n & = x^{m+n}\\\\

\\dfrac{x^m}{x^n} & = x^{m-n}\\\\

\(xy\)^n & = x^ny^n\\\\

\\left\(\\dfrac{x}{y}\\right\)^n & = \\dfrac{x^n}{y^n}\\\\

\(x^m\)^n & = x^{mn}

\\end{align}
](//upload.wikimedia.org/math/6/9/a/69a2d0673dd9a8062fbe95842b1bc1e9.png)

The first, third, and fifth properties may be extended to several factors, as follows:

![
\\begin{align}

x^{m_1}x^{m_2}x^{m_3} \\cdots x^{m_n} & = x^{m_1+m_2+m_3+ \\, \\cdots \\, +m_n}\\\\

\(x_1x_2x_3 \\cdots x_n\)^m & = x_1^mx_2^mx_3^m \\cdots x_n^m\\\\

\( \\cdots \(\(\(x^{m_1}\)^{m_2}\)^{m_3}\) \\cdots \)^{m_n} & = x^{m_1m_2m_3 \\cdots \\, m_n}

\\end{align}
](//upload.wikimedia.org/math/5/3/7/53771fc7af2277b6967886fd6eb626a1.png)

### Bases and exponents of one and zero[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-9)]

Any number raised to an exponent of one equals itself. So, for example, 51 = 5.

Any non-zero number raised to an exponent of zero equals one. So, for example, 50 = 1.

Zero raised to any positive exponent is still zero. So, for example, 05 = 0.

One raised to any exponent is still one. So, for example, 15 = 1.

Zero raised to an exponent of zero is not defined.

### Negative and noninteger powers[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-10)]

A base may also be raised to a negative, fractional, or decimal power. This will be covered later in the lesson.

## Roots[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-11)]

**Roots** are the inverse operation of powers:

### Square root[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-12)]

The inverse operation of squaring a number is taking the **square root** of that number. So, for example, the square root of 25 is the number which must be multiplied by itself to equal 25. In this case, the answer is 5. There are two types of notation used here:

![\\sqrt{25} = 25^{1/2} = 5](//upload.wikimedia.org/math/7/e/a/7eadb512b480f1b0da95b2c162b9875a.png)

Note, however, that most square roots don't yield integers, and many don't even produce rational numbers.

#### Manually finding a square root[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-13)]

One method for manually taking square roots is to repeatedly do long division. Let's take the square root of 10 in this example. We would start by estimating the answer. Since 32 = 9 and 42 = 16, we know the answer lies between 3 and 4. Furthermore, since 10 is only one away from 9, but is 6 away from 16, we could estimate that the answer is one-seventh of the way between 3 and 4. This won't give an exact answer, and a seventh is ugly to work with, so let's use a fifth, instead. This gives us 3 1/5 or 3.2 as a starting estimate.

Now do long division to divide 10 by 3.2. We get 3.125. The average of 3.2 and 3.125 is (3.2 + 3.125)/2 = 6.325/2 = 3.1625, so that will be our next estimate.

Now do long division to divide 10 by 3.1625. We get 3.162055... (we didn't really need to go more than one digit beyond the number of decimal places we started with). The average of 3.1625 and 3.1621 is 3.1623, so that will be our next estimate.

Now do long division to divide 10 by 3.1623. We get 3.162255...

So, this method can be repeated to get the desired level of accuracy. The actual square root of 10 is 3.16227766...

Note that calculators or computers are used for most square root calculations, but knowing how to manually calculate a square root can be quite useful when no calculator is available.

If you would like to try this method yourself, try finding the square root of 7.

### Cube root[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-14)]

The inverse operation of cubing a number is taking the **cube root** of that number. So, for example, the cube root of 125 is the number which must be multiplied by itself and then multiplied by itself again to equal 125. In this case, the answer is 5. There are two types of notation used here:

![\\sqrt\[3\]{125} = 125^{1/3} = 5](//upload.wikimedia.org/math/9/e/1/9e1f993cd7e1e6552904473d40eb97a3.png)

Note, however, that most cube roots don't yield integers, and many don't even produce rational numbers.

### Higher roots[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-15)]

Numbers higher than three may also be used as roots, although there is no common term for fourth roots or higher. For example:

![\\sqrt\[4\]{625} = 625^{1/4} = 5](//upload.wikimedia.org/math/5/9/5/595a95a2bc5d2c92540314fe0beb2c80.png)

Note, however, that most higher roots don't yield integers, and many don't even produce rational numbers.

## Combining powers and roots[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-16)]

The unit fraction notation used for roots previously may have given you the idea that roots are really the same as powers, only with a unit fraction (one over some number) instead of an integer as the exponent. Thus, the fractional notation is actually preferred in higher mathematics, although the root symbol is still used occasionally, especially for square roots.

### Fractions as exponents[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-17)]

Other (non-unit) fractions may also be used as exponents. In this case, the base number may be raised to the power of the numerator (top number in the fraction) then the denominator (bottom number) may be used to take the root. For example:

![8^{2/3} = \\sqrt\[3\]{8^2} = \\sqrt\[3\]{64} = 4](//upload.wikimedia.org/math/8/4/c/84c00815041a9f491bf1d6c089d7c814.png)

Alternatively, you can take the root first and then apply the power:

![8^{2/3} = \(\\sqrt\[3\]{8}\)^2 = 2^2 = 4](//upload.wikimedia.org/math/e/d/a/edab0b0668c3421fd409c11badb66ab7.png)

### Decimal exponents[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-18)]

Any fractional exponent can also be expressed as a decimal exponent. For example, a square root may also be written as:

![25^{1/2} = 25^{0.5} = 5 \\;](//upload.wikimedia.org/math/8/0/c/80cd14bba53416b632c22964677eedc0.png)

Also, decimals which can't be expressed as a fraction (irrational numbers) may be used as exponents:

![5^{3.1415926...} = 156.99...\\;](//upload.wikimedia.org/math/0/d/e/0de93cb1445331214231a1ed7f235d0b.png)

Such problems aren't easy to solve by hand using basic math skills, but the answer can be estimated manually. In this case, since 3.1415926 is between 3 and 4 (and considerable closer to 3), we know that the answer will be between 5^3 (or 125) and 5^4 (or 625), and considerable closer to 125.

### Negative exponents[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-19)]

A negative exponent simply means you take the reciprocal (one over the number) of the base first, then apply the exponent:

![25^{-0.5} = 1/25^{0.5} = 1/5 \\;](//upload.wikimedia.org/math/9/3/2/932b62d2e95e8a2449c8d04c1f92b14d.png)

Alternatively, you can first apply the exponent (ignoring the sign), then take the reciprocal:

![25^{-0.5} = 5^{-1} = 1/5 \\;](//upload.wikimedia.org/math/5/6/6/5665dcb93521cba07d7645fe8c1bcc99.png)

### Fractions as bases[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-20)]

When a fraction is raised to an exponent, both the numerator and denominator are raised to that exponent:

![\(5/6\)^2 = 5^2/6^2 = 25/36 \\;](//upload.wikimedia.org/math/1/f/f/1ff73ed60b76325597c346462e8bde42.png)

Fractions may also be used for both the base and exponent:

![\(25/36\)^{1/2} = 25^{1/2}/36^{1/2} = 5/6 \\;](//upload.wikimedia.org/math/3/1/c/31c2317b2af5144ade395d173f1feadb.png)

In addition, negative fractional exponents may be used, taking the reciprocal of the base, as always, to find the solution:

![\(25/36\)^{-1/2} = \(36/25\)^{1/2} = 36^{1/2}/25^{1/2} = 6/5 \\;](//upload.wikimedia.org/math/3/e/4/3e423fdd3e739ddc243b149d3d97a8a0.png)

### Negative bases[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-21)]

Negative bases can be handled normally for integer powers:

![\(-5\)^2 = \(-5\) \\times \(-5\) = 25 \\;](//upload.wikimedia.org/math/d/4/0/d40b644c695aee518a827e962b61732b.png)

![\(-5\)^3 = \(-5\) \\times \(-5\) \\times \(-5\) = -125 \\;](//upload.wikimedia.org/math/1/8/7/187f0ce79cc18295174a9f1242131d86.png)

![\(-5\)^4 = \(-5\) \\times \(-5\) \\times \(-5\) \\times \(-5\) = 625 \\;](//upload.wikimedia.org/math/4/9/9/4994c52b99850ed8be19510d7090407c.png)

![\(-5\)^5 = \(-5\) \\times \(-5\) \\times \(-5\) \\times \(-5\) \\times \(-5\) = -3125 \\;](//upload.wikimedia.org/math/b/a/7/ba748ec04257dd403b97ab36712b7c88.png)

Note that negative bases raised to even powers produce positive results, while negative bases raised to odd powers produce negative results.

Be careful with negative signs. Since -5 = -1×5, there is a difference between ![ -5^2](//upload.wikimedia.org/math/9/7/9/979650fac206277b0b6418cfedaa4d65.png) and ![\(-5\)^2](//upload.wikimedia.org/math/1/6/b/16b187d1db899c73021f0b8c58c87dac.png). The former means the negative of 5 times 5, whereas the latter  
means -5 squared. In other words,

![-5^2 = -1\\times5^2 = -1\\times\(5\\times5\) = -1\\times25 = -25](//upload.wikimedia.org/math/3/e/c/3ec009c5e3accda5b783963b2334d50b.png)

but

![\(-5\)^2=\(-5\)\\times\(-5\)=25](//upload.wikimedia.org/math/f/9/5/f950dd0f62fdab800b8fe0e320f96b9d.png)

  
Roots and fractional/decimal powers are a bit trickier. Odd roots work out fine:

![\(-125\)^{1/3} = -5 \\;](//upload.wikimedia.org/math/6/7/7/677280659c4094774c692bae2135c5da.png)

Even roots, however, have no real solution:

![\(-25\)^{1/2} = ? \\;](//upload.wikimedia.org/math/3/2/5/32598a374c740b24818518f8707f275e.png)

![\(-625\)^{1/4} = ? \\;](//upload.wikimedia.org/math/7/0/0/700f1af44599000ab0505d377ea13f9c.png)

Note that there is no real number, when multiplied by itself, which will produce -25, because 5×5 = 25 and -5×-5 = 25. There is actually a solution, called an **imaginary number**, but that won't be discussed until later lessons.

### Principal root[[edit](/w/index.php?title=Primary_Mathematics/Powers,_roots,_and_exponents&action=edit&section=T-22)]

Note that, since both 5×5 = 25 and -5×-5 = 25, when we are asked to take the square root of 25 there are, in fact, two valid answers, 5 and -5. Actually, any even root of a positive number will have two solutions, with one being the negative of the other. This may seem unusual, but, in higher mathematics, problems often have multiple solutions.

However, for many problems, only the positive value seems to physically work. For example, if we are asked to figure the length of the sides of a square yard which has an area of 25 square units, only 5 units on a side works. If we said "each side can also have a length of -5 units", that doesn't make any sense. For this reason, the positive solution is called the **principal root**, and, depending on the question, may be the only desired answer. In cases where either answer is valid, it is sometimes written as ±5 (read as "plus or minus five"). However, the mathematical definition of the square root of x squared is the absolute value of x. Thus, square roots equations do not have two answers but two numbers can square to equal the same rational number.

  


# Scientific and engineering notation[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=16)]

## Scientific and engineering notation[[edit](/w/index.php?title=Primary_Mathematics/Scientific_and_engineering_notation&action=edit&section=T-1)]

In science and engineering it is necessary to represent extremely small and large numbers. Representing such numbers with conventional notation becomes difficult, for numbers such as these:
    
    
    123,456,000,000,000,000,000,000,000
    
    
    
    0.000 000 000 000 000 000 000 000 000 000 378
    

One way to represent such numbers is using exponents. The first number, for example, could be represented as one of the following:
    
    
    123,456 × 1021
    123.456 × 1024
    1.23456 × 1026
    0.123456 × 1027
    

The second number could be represented as one of:
    
    
    378 × 10-30
    37.8 × 10-31
    3.78 × 10-32
    0.378 × 10-33
    

This notation is used to make extremely large and small numbers easier to write. It is composed of the base on the left, and the exponent (on the right).

### Scientific notation[[edit](/w/index.php?title=Primary_Mathematics/Scientific_and_engineering_notation&action=edit&section=T-2)]

In scientific notation, the goal is to get the base number to be greater than or equal to 1.0, and less than 10. So, in the above examples, the two values in scientific notation were:
    
    
    1.23456 × 1026
    
    
    
    3.78 × 10-32
    

### Engineering notation[[edit](/w/index.php?title=Primary_Mathematics/Scientific_and_engineering_notation&action=edit&section=T-3)]

Engineering notation is a variation of scientific notation, where the exponent is a multiple of 3, and the base is as close as possible to the range 1.0-10. In the above examples, the two values in engineering notation were:
    
    
    0.123456 × 1027
    
    
    
    0.378 × 10-33
    

  


# Average, media, and mode[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=17)]

## Average, median, and mode[[edit](/w/index.php?title=Primary_Mathematics/Average,_median,_and_mode&action=edit&section=T-1)]

There are three primary **measures of central tendency**, and a couple less often used measures, which each, in their own way, tell us what a typical value is for a set of data. Generally, when finding the measures of central tendency, one would order the values of the data set from **least to greatest**.

### Median[[edit](/w/index.php?title=Primary_Mathematics/Average,_median,_and_mode&action=edit&section=T-2)]

The **median** is the middle value of a set of values. For example, if students scored 81, 84, and 93 on a test; we select the middle value of 84 as the median.

If you have an even number of values, the average of the two middle values is used as the median. For example, the median of 81, 84, 86, and 93 is 85, since that's midway between 84 and 86, the two middle values.

### Average[[edit](/w/index.php?title=Primary_Mathematics/Average,_median,_and_mode&action=edit&section=T-3)]

The **straight average**, or **arithmetic mean**,(sometimes referred to simply as "**average**" or "**mean**"), is the sum of all values divided by the number of values. For example, if students scored 81, 84, and 93 on a test, the average is (81+84+93)/3 or 86.

### Weighted average[[edit](/w/index.php?title=Primary_Mathematics/Average,_median,_and_mode&action=edit&section=T-4)]

The **weighted average** or **weighted mean**, is similar to the straight average, with one exception. When totaling the individual values, each is multiplied by a weighting factor, and the total is then divided by the sum of all the weighting factors. These weighting factors allow us to count some values as "more important" in finding the final value than others.

### Example[[edit](/w/index.php?title=Primary_Mathematics/Average,_median,_and_mode&action=edit&section=T-5)]

Let's say we had two school classes, one with 20 students, and one with 30 students. The grades in each class on a particular test were:

    Morning class = 62, 67, 71, 74, 76, 77, 78, 79, 79, 80, 80, 81, 81, 82, 83, 84, 86, 89, 93, 98

    Afternoon class = 81, 82, 83, 84, 85, 86, 87, 87, 88, 88, 89, 89, 89, 90, 90, 90, 90, 91, 91, 91, 92, 92, 93, 93, 94, 95, 96, 97, 98, 99

The straight average for the morning class is 80% and the straight average of the afternoon class is 90%. If we were to find a straight average of 80% and 90%, we would get 85% for the mean of the two class averages. However, this is not the average of all the students' grades. To find that, you would need to total all the grades and divide by the total number of students:

    ![
\\frac{4300\\%}{50} = 86\\%
](//upload.wikimedia.org/math/b/1/6/b16ab6e660ef3fab927ddcacce1eef21.png)

Or, you could find the weighted average of the two class means already calculated, using the number of students in each class as the weighting factor:

    ![
\\frac{\(20\)80\\% + \(30\)90\\%}{20 + 30} = 86\\%
](//upload.wikimedia.org/math/6/a/0/6a0551303b49d536c726da3596a228ee.png)

Note that if we no longer had the individual students' grades, but only had the class averages and the number of students in each class, we could still find the mean of all the students grades, in this way, by finding the weighted mean of the two class averages.

### Geometric mean[[edit](/w/index.php?title=Primary_Mathematics/Average,_median,_and_mode&action=edit&section=T-6)]

The **geometric mean** is a number midway between two values by multiplication, rather than by addition. For example, the geometric mean of 3 and 12 is 6, because you multiply 3 by the same value (2, in this case) to get 6 as you must multiply by 6 to get 12. The mathematical formula for finding the geometric mean of two values is:

![\\sqrt{AB}](//upload.wikimedia.org/math/1/8/a/18aeab86f76199d2fe5226bd79e8de6b.png)

Where:
    
    
    A = one value
    B = the other value
    

So, in our case:

![\\sqrt{3\(12\)} = \\sqrt{36} = 6](//upload.wikimedia.org/math/9/e/4/9e45e0a0cc00985ed19171376a9f8db1.png)

Note the new notation used to show multiplication. We now can omit the multiplication sign and show simply AB to mean A×B. However, when using numbers, 312 would be confusing, so we put parenthesis around at least one of the numbers to make it clear.

The geometric mean can be extended to additional values:

![\\sqrt\[3\]{\(2\)\(9\)\(12\)} = \\sqrt\[3\]{216} = 6](//upload.wikimedia.org/math/0/0/7/00730fe1f7496b0ef18822d73ad2b5df.png)

For three values, a cube root is performed instead of a square root. On four values, the fourth root is performed.

  


# Percentages[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=18)]

## Percentages[[edit](/w/index.php?title=Primary_Mathematics/Percentages&action=edit&section=T-1)]

### Introduction[[edit](/w/index.php?title=Primary_Mathematics/Percentages&action=edit&section=T-2)]

A percentage is a value divided by 100, shown with the percent symbol (%). For example, 4% is the same as the decimal value 0.04 or the fraction 4/100 (which could also be reduced to 1/25).

### Uses for percentages[[edit](/w/index.php?title=Primary_Mathematics/Percentages&action=edit&section=T-3)]

Traditionally, percentages are used when dealing with changes in a value, particularly money. For example, a store may have a 20% off sale or a bank may charge 7.6% interest on a loan.

### Defining the base[[edit](/w/index.php?title=Primary_Mathematics/Percentages&action=edit&section=T-4)]

The **base** of a percentage change is the starting value. Many errors occur from using the wrong base in a percentage calculation.

### Example[[edit](/w/index.php?title=Primary_Mathematics/Percentages&action=edit&section=T-5)]

If a store has an $100 item, marks it 20% off, then charges 6% sales tax, what is the final price ?

First, calculate 20% of $100. That's 0.20 × $100 or $20. We then subtract that $20 from the original price of $100 to get a reduced sale price of $80.

Now we add in the sales tax. Here's where the tricky part comes in; what is the base ? That is, do we pay 6% tax on the original $100 price or on the reduced $80 price ? In most places, we would pay tax on the reduced sales price, so $80 is the base. Thus, we multiply $80 × 0.06 to get $4.80 and add that to $80 to get $84.80 for a final price.

Notice that even though we took off 20% and then added back in 6%, this is **not** the same as taking off 14%, since the 20% and the 6% figures each had a different base. If the 6% sales tax did apply to the original full price, however, then both percentages would have the same base and the total reduction in price would, indeed, be 14%, bring the price down from $100 to $86.

### Terms used with percentages[[edit](/w/index.php?title=Primary_Mathematics/Percentages&action=edit&section=T-6)]

  * If you take 20% **off** an amount (or a 20% reduction), that means the new price is 20% less than the original (100%) price, so it's now 80% **of** the original price.
  * If you apply 20% **interest** to an amount, that means the new price is 20% higher than the original (100%) price, or 120% **of** the original price. (Note that this is **simple interest**, we will consider **compound interest** next.)

### Compound interest[[edit](/w/index.php?title=Primary_Mathematics/Percentages&action=edit&section=T-7)]

**Simple interest** is when you apply a percentage interest rate only once.

**Compound interest** is when you apply the same percentage interest rate repeatedly.

For example, let's say a $1000 deposit in a bank earns 10% interest each year, compounded annually, for three years. After the first year, $100 in interest will have been earned for a total of $1100. In the second year, however, there is not only interest on the $1000 deposit, but also on the $100 interest earned previously. This "interest on your interest" is a feature of compounding. So, in year two we earn 10% interest on $1100, for $110 in interest. Add this to $1100 to get a new total of $1210. The 10% interest in the third year on $1210 is $121, which gives us a total of $1331.

For those familiar with powers and exponents, we can use the following formula to calculate the total:
    
    
    T = P x (1 + I)N
    

Where:
    
    
    T = final Total
    P = initial Principal
    I = Interest rate per compounding period
    N = Number of compounding periods
    

In our example, we get:
    
    
    T = $1000 x (1 + 10%)3
      = $1000 x (1 + 0.10)3
      = $1000 x (1.10)3
      = $1000 x (1.10 x 1.10 x 1.10)
      = $1000 x (1.331)
      = $1331
    

More complex calculations involving compound interest will be covered in later lessons.

  


# Probability[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=19)]

## Probability[[edit](/w/index.php?title=Primary_Mathematics/Probability&action=edit&section=T-1)]

In _probability_ tells us how likely something is to happen.

If something is absolutely certain to happen, we say its _probability is one_. If something cannot possibly happen, we say its _probability is zero_. A probability between zero and one means we don't know for sure what will happen, but the higher the number the more likely something is to happen. If something has a probability of 0.25, most people would say "it **probably** won't happen".

Unfortunately, children have a hard time understanding what a probability of 0.25 suggests. Children are much more adept in understanding probability in terms of percentages (25%), and fractions (i.e., "It will happen about ¼ of the time"), so it is very important that connections between probability and the development of those skills and understandings occur together.

### Models[[edit](/w/index.php?title=Primary_Mathematics/Probability&action=edit&section=T-2)]

It can be difficult but Probability is best taught with models. Two of the most effective and commonly used models used to teach probability are _area_ and _tree diagrams_

Area diagrams give students an idea of how likely something is by virtue of the amount of space reserved for that probability. Consider the toss of a coin:

![HeadsTailsRectangle.jpg](//upload.wikimedia.org/wikibooks/en/d/db/HeadsTailsRectangle.jpg)

Students can imagine that every time they toss a coin, they need to place that coin into the appropriate side of the rectangle. As the number of throws increases, the amount of area needed to enclose the coins will be the same on both sides. The same probability can be shown using a tree diagram:

![HeadsTailsTree.JPG](//upload.wikimedia.org/wikibooks/en/5/54/HeadsTailsTree.JPG)

In this simple tree diagram, each line (or event path) will be followed ½ of the time. Note that both diagrams show **all** of the possibilities, not just the probability of one event.

Both of these models can become more complex. Consider all of the possibilities of throwing two coins in series:

![TwoTossesRectangle.JPG](//upload.wikimedia.org/wikibooks/en/4/4b/TwoTossesRectangle.JPG)

In the above area rectangle the instances where heads has been tossed twice in a row is represented in the upper left hand corner. Note that whereas the probability of tossing both heads and tails (in any order) is 50% or 1/2, and the probability of tossing two heads in a row is 25% or 1/4.

![TwoTossesTree.JPG](//upload.wikimedia.org/wikibooks/en/3/34/TwoTossesTree.JPG)

While the tree diagram gives us the same information, the student needs to understand that all of the events at the bottom have an equal chance of occurring (This is more visually evident in an area diagram). However, the tree diagram has the advantage of better showing the chronology of events (in this case the order of events is represented by downward motion).

While it may appear that both of these models have strengths and weaknesses, that is not the point. By becoming familiar with these and other models, students gain a more robust and diverse understanding of the nature of probability.

Consider the following problem:

_**If at any time a Dog is just as likely to give birth to a male puppy as she is to give birth to a female puppy, and she has a litter of 5 puppies, what is the probability that all of the puppies will be of the same sex?**_

While this problem can be easily answered with the a standard formula, ![P = 2 \\left \( \\frac{1}{2} \\right \) ^n](//upload.wikimedia.org/math/9/c/8/9c8806dd91561daec4eececf7ff1a8ae.png), where n is the number of puppies born, this nomenclature is not only unintelligible to students, but teaching it to students gives them no understanding of the underlying concepts. On the other hand, if they have explored problems similar to this with a tree diagram, they should fairly easily be able to see patterns emerging from which they can conjecture the "formula" that will find the correct answer. Consider that a student has drawn a tree diagram that shows the permutations with three puppies in the litter:

![3puppiesonly.png](//upload.wikimedia.org/wikibooks/en/8/83/3puppiesonly.png)

If a teacher was to have this student share their work, the class of students in looking at this model would be able to see that there are 8 possible outcomes. They should also notice that the only instances where litters of all males or all females can be found are on the far ends of the tree.

Students are always encouraged to look for patterns in many of their mathematical explorations. Here, students start to notice that the number of possibilities can be determined by multiplying the number 2 by itself exactly the number of times there is to be a new outcome. In this case there are three outcomes (puppies born) in a row. So 2 x 2 x 2 = 23, or 8 possible outcomes. Once the student sees a connection to this pattern, they may conjecture that if there are 5 puppies in a litter, the possible number of outcomes is 25, or 32, of which only 2 (represented by the combinations MMMMM, and FFFFF on the extreme ends) will result in a litter puppies of all the same sex.

Teachers are always looking for students to make connections with other skills they are learning. In this case the teacher might ask the students to state the answer as a reduced fraction (1/16) and a percentage (6.25%).

* * *

Since we're using math to help us understand what will happen, it may help us to be able to write an equation like this:

Pr(X) = y

If this equation is true, we would say "the probability of X happening is y". For example, we can say:

X = A coin toss coming up heads

Pr(X) = 0.5

Since the letter X is standing for an event, not a number, and we don't want to get them confused, we'll use capital letters for events, and lower-case letters for numbers. The symbol _Pr_ represents a _function_ that has some neat properties, but for now we'll just think of it as a short way of writing "the probability of X".

Since probabilities are always numbers between 0 and 1, we will often represent them as percentages or fractions. Percentages seem natural when someone says something like "I am 100% sure that my team will win." However, fractions make more sense for really computing probabilities, and it is very useful to really be able to compute probabilities to try to make good decisions, so we will use fractions here.

The basic rule for computing the probability of an event is simple, if the event is the kind where we are making a definite choice from a known set of choices based on randomness that is fair. Not everything is like that, but things like flipping a coin, rolling a single die, drawing a card, or drawing a ticket from a bag with your eyes closed are random and fair since each of the possibilities is equally likely. But the probability of things a little more complicated, like the sum of two dice, is not so easy---and that makes it fun!

Suppose we have a single die. It has six faces, and as far as we know each is equally likely to be face up if we roll the die. We can now use our basic rule for computing probability to compute the probability of each possible outcome. The basic rule is to take the number of outcomes that represent the event (called X) that you're trying to compute the probability of, and divide it by the total number of possible outcomes. So, for rolling a die:

Pr("getting a one") = 1 face that has one dot / 6 faces = 1/6

Pr("getting a two") = 1 face that has two dots / 6 faces = 1/6

Pr("getting a three") = 1 face that has three dot / 6 faces = 1/6

Pr("getting a four") = 1 face that has four dots / 6 faces = 1/6

Pr("getting a five") = 1 face that has five dot / 6 faces = 1/6

Pr("getting a six") = 1 face that has six dots / 6 faces = 1/6

So we have 6 possibilities, and each has a probability of 1/6. We know that 6 * (1/ 6) = 1. In fact, that is an example of a fundamental rule of probabilities:

The sum of probabilities of all possibilities is equal to one.

But you probably know that each face of a die is equally likely to land face-up, so so far we haven't done anything useful. So let's ask the question: What is the probability of throwing two dice and having their sum equal seven when we add them together? Knowing that can help us win at a lot of games (such as Monopoly(trademark Parker Brothers)), so it's pretty valuable to know the answer.

To find out the answer, we apply our basic rule, but now it is not so easy to know how many possible outcomes of TWO dice thrown together will equal seven. However, it is easy to know how many total possible outcomes there are: 6 times 6 = 36. One way to find out how many possible dice throws add up to seven is just to make a table of all possible dice throws that fills in their sum and count the number of sevens. Here is one:
    
    
      ***| 1 | 2 | 3 | 4 | 5 | 6
      ===========================
      1  | 2 | 3 | 4 | 5 | 6 | 7
      2  | 3 | 4 | 5 | 6 | 7 | 8
      3  | 4 | 5 | 6 | 7 | 8 | 9
      4  | 5 | 6 | 7 | 8 | 9 | 10
      5  | 6 | 7 | 8 | 9 | 10| 11
      6  | 7 | 8 | 9 | 10| 11| 12
    

The numbers along the top represent the value on the first die and the values on the left represent the values of the second die when you throw them together. The values inside the table represent the sum of the first and the second dice. (Note that the numbers range from 2 to 12 --- there's no way to throw two dice and get a number less than two!)

So if we look carefully, we can see that there are exactly 6 sevens in this table. So the probability of getting a seven if you throw two dice is 6 out of 36, or:

Pr(getting a 7) = 6 / 36 = 1 / 6.

(1 / 6 is a simple fraction equal in value to 6 / 36.)

Maybe that doesn't surprise you, but let's look at all the probabilities:

Pr(getting a 2) = 1 / 36

Pr(getting a 3) = 2 / 36

Pr(getting a 4) = 3 / 36

Pr(getting a 5) = 4 / 36

Pr(getting a 6) = 5 / 36

Pr(getting a 7) = 6 / 36

Pr(getting a 8) = 5 / 36

Pr(getting a 9) = 4 / 36

Pr(getting a 10)= 3 / 36

Pr(getting a 11)= 2 / 36

Pr(getting a 12)= 1 / 36

What do you think we would get if we added all of those probabilities together? They should equal 36 / 36, right? Check that they do.

Did you know that the probability of a getting a 5 is four times that of getting a two? Did you know that probability of getting a five, six, seven or eight is higher than the probability of other 7 numbers all together? We can tell things like that by adding the probabilities together, if the events we're talking about are completely independent, as they are in this case. So we can even write:

Pr(getting a 5, 6, 7 or 8) = Pr(getting a 5) + Pr(getting a 6) + Pr(getting a 7) + Pr(getting an 8)

But we can substitute these fractions and add them up easily to get:

Pr(getting a 5, 6, 7, or 8) = (4+5+6+5)/36 = 20/36.

Since we know the probability of all possible events must equal one, we can actually use that to compute the probability:

Pr(getting a 2,3,4,9,10,11 or 12) = 1 - (20/36) = (36/36 - 20/36) = 16/36.

This way we didn't have to add up all those individual probabilities, we just subtracted our fraction from 1.

Mathematically we could say: Pr(some events) = 1 - Pr(all the other possible events)

You might want to take the time now to get two dice and roll them 3*36 = 108 times, recording the sum of them each time. The number you get for each sum won't be exactly 3 times the probabilities that we have computed, but it should be pretty close! You should get around 18 sevens. This is fun to do with friends; you can have each person make 36 rolls and then add together all your results for each sum that is possible.

The fact that if you make a lot of rolls it is likely to get results close the probability of an outcome times the number of rolls is called the Law of Large Numbers. It's what ties the math of probability to reality, and what lets you do math to make a good decision about what roll you might get in a game, or anything else for which you can compute or estimate a probability.

Here's a homework exercise for each of you: compute the probabilities of every possible sum of throwing two dice, but two different dice: one that comes up 1,2,3 or 4 only, and the other that comes up 1,2,3,4,5,6,7 or 8. Note that we these dice (which you can get at a gaming store, if you want) the lowest and highest possible roll is the same but the number of possible rolls is only 4 * 8 = 32.
    
    
     ***| 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8
      =====================================
      1  | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9
      2  | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10
      3  | 4 | 5 | 6 | 7 | 8 | 9 | 10| 11
      4  | 5 | 6 | 7 | 8 | 9 | 10| 11| 12
    

Pr(getting a 2) = 1 / 32

Pr(getting a 3) = 2 / 32

Pr(getting a 4) = 3 / 32

Pr(getting a 5) = 4 / 32

Pr(getting a 6) = 4 / 32

Pr(getting a 7) = 4 / 32

Pr(getting a 8) = 4 / 32

Pr(getting a 9) = 4 / 32

Pr(getting a 10)= 3 / 32

Pr(getting a 11)= 2 / 32

Pr(getting a 12)= 1 / 32

(You should check our work by making sure that all these probabilities sum to 32/32 = 1).

So this is interesting: Although the possible scores of the throwing two dice are the same, the probabilities are a little different. Since 1/32 is a little more than 1/36, you are actually _more_ likely to get a two or a twelve this way. And since 4 /32 = 1/8 is less than 6 / 36 = 1/6, you are less likely to get a seven with these dice. You might have been able to guess that, but by doing the math you know for sure, and you even know by how much, if you know how to subtract fractions well.

So let's review what we've learned:

  * We know what the word probability means.
  * We know probabilities are always numbers between 0 and 1.
  * We know a basic approach to computing some common kinds of probabilities.
  * We know that the probabilities of all possible outcomes should add up to exactly 1.
  * We know the probability of a result is equal to one minus the probability of all other results.

  


# Factors and Primes[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=20)]

## Factors and Primes[[edit](/w/index.php?title=Primary_Mathematics/Factors_and_Primes&action=edit&section=T-1)]

**Factors** are numbers that you can multiply together to get another number. For example: 8 and 11 are factors of 88 as 8 x 11 = 88. Similarly, 10 is a factor of 100 as 10 x 10 is 100.

**Prime factors** are factors which are **prime numbers**
    
    
    55  = 5 x 11
    100 = 2 x 5 x 2 x 5
    

Because 2, 5, and 11 cannot be divided by any number but 1 and itself, these numbers are called _prime_. Prime numbers are an important part of mathematics, and the problem of factoring large numbers into primes remains fundamental to the study of computer science. Factoring a number like 64 often requires more than one step:
    
    
    64  = 2 x 32 (32 is not prime)
     or = 2 x 2 x 16 (16 is not prime)
     or = 2 x 2 x 2 x 8 (8 is not prime)
     or = 2 x 2 x 2 x 2 x 4 (4 is not prime)
     or = 2 x 2 x 2 x 2 x 2 x 2
    

  


# Method for Factoring[[edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit&section=21)]

## A method of prime factorization for children[[edit](/w/index.php?title=Primary_Mathematics/Method_for_Factoring&action=edit&section=T-1)]

In math, the way you get to the correct answer is just as important as getting the right answer. Sometimes the way one gets the answer can be thought of a proof. People don't usually use the word proof when talking about arithmetic problems, but I think it is a good idea and good habit to get into. This is a method of doing prime factorization that constructs a proof that your answer is correct as you arrive at the answer. It keeps you from getting lost and shows your work. More importantly, I think it helps you understand the process. It starts out very easy, so that beginners can use it, but later on lets you skip some steps to save time.

The basic point of prime factorization is to take a number and find the prime factors. Since each prime factor may occur more than once, for example in the number 4, which has prime factors (2,2), we know that the factors of a number are not a set but a multi-set. (The difference will be important as you get to more advanced math.) So the basic way we are going to do our work looks like this:
    
    
       pf(X)
    = { a reason we believe this}
       (a list of factors)
    

For example, for the number 4, we could factorize it like this:
    
    
       pf(4)
    = { 4 = 2 * 2 }
       (2,2)
    

This is a very simple proof, and also represents what is sometimes called "showing our work" or our "scratch paper". Learning math is often about learning the language and symbols of math, and we need to do that now.

I use the symbol pf(X) to mean "the prime factors of X". I use a comma list of numbers of "pf(X)" symbols between parentheses to mean a multi-set of prime factors. So (pf(45),2,5) means "multi-set that includes the prime-factors of 45 and the prime number 2 and the prime number 5".

Now, for doing prime factorization, we are only going to allow certain reasons to go from one step to the next toward the answer. For example, "my friend Harold said so" is not a good reason.

The first reason that we will allow is a simple multiplication equation of the form x = y * z. In particular, we are allowed to do this:
    
    
       pf(x)
    = { x = y*z }
       (pf(y),pf(z))
    

so long as the equation x = y* z is true (and y and z are both greater than 1, otherwise we'd be going in circles!)

The second rule that we are allowed to use is to replace pf(x) with (x) if we know for sure that x is a prime. For example, you should probably memorize the first ten primes: (2, 3, 5, 7, 11, 13, 17, 19, 23, 29), so it's OK to go from substitute the number 23 for pf(23), since we should know by heart that 23 is prime. When we do this, we give the reason "23 is prime".

Finally, we need to note that ((X)) = (X), no matter what X is , so we never need to write parentheses inside parentheses (this is not true of multiplication, it is only true because we are using parentheses to mean something special.

So let's do an example:
    
    
       pf(4)
    = { 4 = 2 * 2 }
       (pf(2), pf(2)
    = { 2 is prime}
       (2,2)
    

So, in this example, we've chained together two steps, with a reason for each one that is very simple. This is a good idea when you are starting out. However, mathematicians also want to be efficient, so if you are sure of what you are doing, you could do two steps at once:
    
    
       pf(4)
    = { 4 = 2 * 2, 2 is prime}
       (2,2)
    

Notice that whether we perform one, two, or even more steps, we are really creating an equation. If we drop out the intermediate steps, the result is pf(4) = (2,2), which is probably about what someone would want on a test.

Now let's do a harder one:
    
    
       pf(60)
    = { 60 = 6 * 10 }
       (pf(6), pf(10))
    = { 6= 2* 3, 10 = 2* 5 }
       (2,3,2,5)
    = { commutativity of multiplication}
       (2,2,3,5)
    

Commutativity of multiplication is a rule that just lets us reorder the factors. It's nice to have them in order in our list, so we will often do that at the end. But that's a lot of writing, so we'll abbreviate it { com. of mult. } Also, notice that in the second step I dropped the unnecessary parentheses, instead of writing ((2,3), (2,5)).

Now let's do an even bigger one, that's still easy, since the prime factors are all small, and it's easy to see the factors.
    
    
       pf(450)
    = { 450 = 45 * 10 }
       (pf(45), pf(10)}
    = { 45 = 5 * 9, 10 = 2 * 5 }
       (5,pf(9),2,5)
    = { 9 = 3 * 3 , com. of mult.}
       (2,3,3,5,5)
    

Now we see a way in which we could have made a mistake --- if we forgot that 9 is not prime and had written (5,9,2,5). Hopefully we would have noticed, but we need to be careful!

### When the factors aren't obvious[[edit](/w/index.php?title=Primary_Mathematics/Method_for_Factoring&action=edit&section=T-2)]

I think this is a nice method when the factors are easy to see. But unfortunately, sometimes they aren't easy to see at all, and we need a new symbol for expressing our work in that case.

Consider the number 143. Is it prime, or does it have factors? Well, its not obvious. The basic approach to finding any factor, or proving that a number is prime, is to start at the first prime (the number 2) and see if it is a factor. By going systematically up through each prime, we either find a factor or reach a prime that is bigger than the square root of the number, in which case we know the number is prime.

However, this is sometimes a big job, and we would really like to show our work in a way that helps us keep track of where we are and also can be quickly checked over to make sure we haven't made any mistakes.

The way we can do this is with the symbol nu(X,Y), which means "the multi-set of prime factors of Y, understanding that none of the numbers up to and including X evenly divide Y". I'm thus using the "not divisible up to" function nu both to help remember what has already been checked, but I've defined it so that my equation remains technically true at all times. The reason we want this symbol is that we know that is how you prove something is prime---you prove nu(sqrt(Y),Y), and then you know Y is prime. For example, if you know nu(13, 123), you know 123 is prime since 13*13 > 123\. We can introduce nu(2,X) with the reason { X is not even}. If we know nu(2,X), then we can introduce nu(3,X) with the reason { sum of X's digits not divisible by 3 }.

So let's try this:
    
    
       pf(143)
    = { 143 is not even }
       (nu(2,143))
    = { 1+4+3 not divisible by 3 }
       (nu(3,143))
    = { 143 doesn't end in 5 }
       (nu(5,143))
    = { 143 / 7 = 20 and 3 / 7 }
       (nu(7,143))
    = { 143 / 11 = 13!!}
       (11,pf(13))
    = { 13 is prime }
       (11,13)
    

So that is our answer. Now in this case, we had to use a reason that we derived by division: 143/ 7 is not a whole number, but 20 and 3/ 7s. And, we were surprised to learn that 11 evenly divides 143. Let's try an even harder one. (Note, I am using the divisibility test from the Dr. Math website: <http://mathforum.org/dr.math/faq/faq.divisibleto50.html> rather than doing division for many of these divisibility tests at noted, but if I had to do it on a test, I would use division, since I don't have those rules memorized.)
    
    
       pf(1709)
    = { not even, doesn't sum to 3, doesn't end in 5 }
       (nu(5,1709))
    = { 170+45 = 215, not divisible by 7 (x5 and add rule for 7) }
       (nu(7,1709))
    = { 1709/ 11 leaves 609, 609/ 11 leaves 59 (short division)}
       (nu(11,1709))
    = { 170+ 4*9 = 206, 20+24 = 48 not divisible by 13 (x4 and add rule for 13) }
       (nu(13,1709))
    = { 170-45 = 125, not divisible by 17 (x5 and subtract rule for 17) }
       (nu(17,1709))
    = { 170+18 = 188, not divisible by 19 (x2 and add rule for 19)}
       (nu(19,1709))
    = { 170+63 = 233, not divisible by 23 (x7 and add rule for 23)}
       (nu(23,1709))
    = { 170+27 = 197, 19+21 = 40, not divisible by 29 (x3 and add rule for 29)}
       (nu(29,1709))
    = { 170 - 27 = 143, 14 - 27 = -13, not divisible by 31 (x3 and subtract rule for 31)}
       (nu(31,1709))
    = { 170 - 99 = 71, not divisible by 37 (x11 and subtract rule for 37)}
       (nu(37,1709))
    = { 170 - 36 = 134, 41* 3 = 123 (x4 and subtract rule for 41) }
       (nu(41,1709))
    = { 4*43 = 172, 3 * 43 = 129, 1720+129 = 1849, so by nu rule we are done!}
       (1709)
    

By systematically working our way up from 2 to the square root of the number, we can always keep track of where we are. For example, if we had started with 6 * 1709 = 10254, we would have ended up with:
    
    
       pf(10254)
    = { even}
       (2,pf(5127))
    = {5+1+2+7=15 = 3 * 5 }
       (2,3,pf(1709))
    .....
       (2,3,1709)
    

and then the proof would proceed as it did above, carrying with it the prime factors 2 and 3 the whole time.

It is recommended that children use this method of writing out their work in order to build good habits that will pay off in algebra and other more advanced mathematical calculation, and introduces gently the all-important concept of the proof.

One sometimes sees factor trees suggested as a notation. Factor trees may be useful for visualizing some things but are not useful at all if one can't see the factors!

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Primary_Mathematics/Print_version&oldid=2426679](http://en.wikibooks.org/w/index.php?title=Primary_Mathematics/Print_version&oldid=2426679)" 

[Category](/wiki/Special:Categories): 

  * [Primary Mathematics](/wiki/Category:Primary_Mathematics)

Hidden category: 

  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Primary+Mathematics%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Primary+Mathematics%2FPrint+version)

### Namespaces

  * [Book](/wiki/Primary_Mathematics/Print_version)
  * [Discussion](/w/index.php?title=Talk:Primary_Mathematics/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Primary_Mathematics/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Primary_Mathematics/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Primary_Mathematics/Print_version&action=edit)
  * [View history](/w/index.php?title=Primary_Mathematics/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Primary_Mathematics/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Primary_Mathematics/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Primary_Mathematics/Print_version&oldid=2426679)
  * [Page information](/w/index.php?title=Primary_Mathematics/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Primary_Mathematics%2FPrint_version&id=2426679)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Primary+Mathematics%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Primary+Mathematics%2FPrint+version&oldid=2426679&writer=rl)
  * [Printable version](/w/index.php?title=Primary_Mathematics/Print_version&printable=yes)

  * This page was last modified on 25 October 2012, at 07:33.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Primary_Mathematics/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
