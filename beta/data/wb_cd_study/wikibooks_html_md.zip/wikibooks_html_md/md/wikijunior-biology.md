# Wikijunior:Biology/Printable version

From Wikibooks, open books for an open world

< [Wikijunior:Biology](/wiki/Wikijunior:Biology)

![Edits to this page require review.](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/doc-magnify.png)![This is a reviewed version of this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/2.png)This is the [latest reviewed version](/wiki/Wikibooks:REVIEW), [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Wikijunior:Biology/Printable_version) on _21 July 2010_.(+)

 **Quality**: poor/unrated  

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Wikijunior:Biology](/wiki/Wikijunior:Biology)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Wikijunior:Biology/Printable_version&action=purge&printable=yes) this page.

## Table of contents[[edit](/w/index.php?title=Wikijunior:Biology/Printable_version&action=edit&section=1)]

  1. [Introduction](/wiki/Wikijunior:Biology/Introduction)
  2. [Cells](/wiki/Wikijunior:Biology/Cells)
  3. [Tissues](/wiki/Wikijunior:Biology/Tissues)
  4. [Organs](/wiki/Wikijunior:Biology/Organs)
  5. [Systems](/wiki/Wikijunior:Biology/Systems)
    1. [Circulatory System](/wiki/Wikijunior:Biology/Systems/Circulatory_System)
    2. [Respiratory System](/wiki/Wikijunior:Biology/Systems/Respiratory_System)
    3. [Digestive System](/wiki/Wikijunior:Biology/Systems/Digestive_System)
    4. [Endocrine System](/wiki/Wikijunior:Biology/Systems/Endocrine_System)
    5. [Reproductive System](/wiki/Wikijunior:Biology/Systems/Reproductive_System)
    6. [Urinary System](/wiki/Wikijunior:Biology/Systems/Urinary_System)
    7. [Immune System](/wiki/Wikijunior:Biology/Systems/Immune_System)
    8. [Muscular System](/wiki/Wikijunior:Biology/Systems/Muscular_System)
    9. [Skeletal System](/wiki/Wikijunior:Biology/Systems/Skeletal_System)
    10. [Integumentary System](/wiki/Wikijunior:Biology/Systems/Integumentary_System)
    11. [Nervous System](/wiki/Wikijunior:Biology/Systems/Nervous_System)
  6. [Kingdoms](/wiki/Wikijunior:Biology/Kingdoms)
    1. [Archaea](/wiki/Wikijunior:Biology/Kingdoms/Archaea)
    2. [Bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria)
    3. [Protists](/wiki/Wikijunior:Biology/Kingdoms/Protists)
    4. [Fungi](/wiki/Wikijunior:Biology/Kingdoms/Fungi)
    5. [Plants](/wiki/Wikijunior:Biology/Kingdoms/Plants)
    6. [Animals](/wiki/Wikijunior:Biology/Kingdoms/Animals)
  7. [Viruses](/wiki/Wikijunior:Biology/Viruses)
  8. [Conclusion](/wiki/Wikijunior:Biology/Conclusion)

  


**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**Printable version**
**[Cells](/wiki/Wikijunior:Biology/Cells)**

**Biology** is the study of _Life_. It helps us understand many things, such as how our body works, how our body keeps warm, and what we are made of. Biology is very important to know. Some subjects in Biology are Genetics, Zoology, Botany, and Ecology.

A Biologist is someone who studies Biology.

## What is life?[[edit](/w/index.php?title=Wikijunior:Biology/Introduction&action=edit&section=T-1)]

Living things are different from things that are not alive. It is usually easy to tell what is living and what is not, except with really small "microscopic" life forms and colorless, lifeless-looking mosses.

Here are some properties of living things. Some non-living things can have some of these properties.

    Living things can change and grow. However, volcanoes also change and grow.

    Living things can move. However, the wind is moving air, and water always moves downhill.

    

    You probably want to know how plants can move. They can grow, and sometimes move more rapidly than that, in response to things such as the sun or water. One example is that sunflowers will turn during the course of the day so that they are always facing the sun. Another example is that if a plant gets tipped over, it will want to turn upwards.

    Living things can reproduce. That is they can produce copies of themselves, over and over. This is the most important difference between living and non-living things.

    

    In order to reproduce, living things need nutrition, that is chemicals and energy sources in order to assemble the materials needed to reproduce themselves. In this process , living things must excrete waste. Waste is material which is of no use, or harmful.

Animals, bacteria, and plants are examples of living things. Rivers, mountains, oceans, and soil are examples of non-living things, but often they are homes for living things.

Cars and tables are not living things because they cannot reproduce themselves.

## Levels of Life[[edit](/w/index.php?title=Wikijunior:Biology/Introduction&action=edit&section=T-2)]

Living things can be many sizes. Also, biologists organize the structures and groupings of living creatures according to size. A living creature is called an organism. Organisms can consist of single cells or multiple different types of cells grouped into tissues and organs. From small to large, these are how living things are grouped.

  * [Cells](/wiki/Wikijunior:Biology/Cells)

    Most cells are only a few microns wide, so small they can only be seen with a microscope. A micron is one thousandth of a millimeter.
  * [Tissues](/wiki/Wikijunior:Biology/Tissues)
  * [Organs](/wiki/Wikijunior:Biology/Organs)
  * [Organ systems](/wiki/Wikijunior:Biology/Systems)
  * Organisms
  * Populations
  * Communities
  * Ecosystems
  * Biomes
  * Biosphere 

    The biosphere is the whole network of living things on planet Earth — eight thousand miles in diameter, twenty five thousand miles around the equator.

Each thing in the list is made up of the things above it. For example, communities are made of many populations and populations are made up of many organisms.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Introduction](/wiki/Wikijunior:Biology/Introduction)**
**Printable version**
**[Tissues](/wiki/Wikijunior:Biology/Tissues)**

## Cells[[edit](/w/index.php?title=Wikijunior:Biology/Cells&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Chloroplasten.jpg/220px-Chloroplasten.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Plant cells

All living things are made of cells. They are the components and building blocks of life.

## What is a cell?[[edit](/w/index.php?title=Wikijunior:Biology/Cells&action=edit&section=T-2)]

_A cell is a bag of liquid that holds in the stuff of life._

  
A **cell** is the smallest unit of living (things)organism. If you look at living things under a microscope, you will see that they are made of small squares or balls. **Robert Hooke**, a biologist from England, saw small squares in cork with a microscope. They looked like rooms. Small rooms are sometimes called _cells_, so he named them that.

## What types of cells are there?[[edit](/w/index.php?title=Wikijunior:Biology/Cells&action=edit&section=T-3)]

There are two kinds of cells: **eukaryotes**, which have a large ball in them called a _nucleus_, and **prokaryotes**, which do not.

Most prokaryotes are very small. Prokaryotes include just two **kingdoms**: **Bacteria** and **Archea**. All of the rest of the kingdoms are Eukaryotes: **Animals** , **Plants**, **Fungi**, and **Protists**.

## What do cells look like?[[edit](/w/index.php?title=Wikijunior:Biology/Cells&action=edit&section=T-4)]

Cells are surrounded by a thin oil layer called the _cell membrane_. It separates the inside of the cell from the outside. Some cells also have a firm box around them called a _cell wall_ that keeps it from breaking. The water that fills a cell is called the _cytoplasm_. Inside a cell, knowledge is stored in a thing called a _chromosome_. It tells the cell how to work, like steps in a book.

Eukaryotic cells hold their chromosomes in a structure called a **nucleus**, which has its own oily membrane around it. Cells also have many other membrane-bound things called **organelles**, which means "little organs". Some organelles found in eukaryotic cells are called _ribosomes_, _vacuoles_, _mitochondria_, and _chloroplasts_.

![Human sperm cell](//upload.wikimedia.org/wikipedia/commons/3/39/Human_spermatozoa.png)

  
Cells that do different things have different shapes. A plant leaf cell takes light and uses it to make sugar. To do this, it has green organelles called _chloroplasts_. To get the most light it pushes cytoplasm in circles around a hollow bubble of water in the center of the cell called a _vacuole_.

A human sperm cell carries its chromosomes, found in the nucleus, to an egg cell in order to make a new baby. It has a large tail called a _flagella_ that helps it to swim. It also has many organelles called _mitochondria_ that give it power like gasoline gives power to a motor.

#### Words[[edit](/w/index.php?title=Wikijunior:Biology/Cells&action=edit&section=T-5)]

    **nucleus** \- A ball in the middle of the cell that holds the chromosomes.
    **chromosomes** \- Things that hold the knowledge of the cell.
    **prokaryote** \- A cell without a nucleus.
    **eukaryote** \- A cell with a nucleus.
    **organelles** \- Little things inside a cell.
    **cytoplasm** \- The water in a cell.
    **membrane** \- An oil bag that holds water.
    **vacuole** \- An organelle full of water inside a cell.
    **mitochondria** \- An organelle that makes power in a cell
    **chloroplast** \- An organelle that makes sugar found in a plant or protist.
    **flagella** \- A tail on a cell that makes it swim.
    **golgi body** \- An organelle which helps in secretion.
    **ribosome** \- An organelle which helps in synthesis of proteins.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Cells](/wiki/Wikijunior:Biology/Cells)**
**Printable version**
**[Organs](/wiki/Wikijunior:Biology/Organs)**

![Animal muscle tissue](//upload.wikimedia.org/wikipedia/commons/1/1b/Illu_muscle_tissues.jpg)

## Tissues[[edit](/w/index.php?title=Wikijunior:Biology/Tissues&action=edit&section=T-1)]

Organisms are made of tissues. Tissues are groups of [cells](/wiki/Wikijunior:Biology/Cells) that work together. Plant leaves have tissues that capture light and make sugar. Most animals have **muscle** tissues that help them move.

When two or more tissues work together to do one thing they make up [organs](/wiki/Wikijunior:Biology/Organs).

In plants, there are two types of tissues:

  * **Meristematic tissue**: This has actively dividing cells.
  * **Permanent tissue**: This type of tissue has developed cells. They do not divide. 
    * **Simple permanent tissue**: This type of permanent tissue has only one kind of cells. 
      * **Parenchyma**: They have loosely packed cells. The cells do not have a particular function.
      * **Collenchyma**: They have cells which have layers called [pectin](//en.wikipedia.org/wiki/pectin). They contain chlorophyll.
      * **Sclerenchyma**: They have dead cells. Between the cells, there are layers called lignin.
    * **Complex permanent tissue**: This type of tissue contains different kinds of cells. 
      * **Xylem**: This type of tissue contains mainly dead cells. They help to move water from the roots to leaves.
      * **Phloem**: This type of tissue contains mainly living cells. They help moving food materials from leaves to other parts.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Tissues](/wiki/Wikijunior:Biology/Tissues)**
**Printable version**
**[Systems](/wiki/Wikijunior:Biology/Systems)**

## Organs[[edit](/w/index.php?title=Wikijunior:Biology/Organs&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/b/b7/Humhrt2.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

A heart

Many living things have **Organs**.

Your Heart, Brain, Lungs, Liver, and Kidneys are organs.

Organs are made of two or more [tissues](/wiki/Wikijunior:Biology/Tissues).

Organs each have something that they do. The heart pumps blood. The lungs give you air.

Organs work together in groups called [Organ systems](/wiki/Wikijunior:Biology/Systems).

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Organs](/wiki/Wikijunior:Biology/Organs)**
**Printable version**
**[Circulatory System](/wiki/Wikijunior:Biology/Systems/Circulatory_System)**

## Organ systems[[edit](/w/index.php?title=Wikijunior:Biology/Systems&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/68/Scheme_female_reproductive_system-en.svg/250px-Scheme_female_reproductive_system-en.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Reproductive system in women

Two or more organs that work together make an **organ system**.

Organ systems are found in all different kinds of living things.

Some of the organ systems found in humans include:

  * [Circulatory System](/wiki/Wikijunior:Biology/Systems/Circulatory_System)
  * [Respiratory System](/wiki/Wikijunior:Biology/Systems/Respiratory_System)
  * [Digestive System](/wiki/Wikijunior:Biology/Systems/Digestive_System)
  * [Endocrine System](/wiki/Wikijunior:Biology/Systems/Endocrine_System)
  * [Reproductive System](/wiki/Wikijunior:Biology/Systems/Reproductive_System)
  * [Urinary System](/wiki/Wikijunior:Biology/Systems/Urinary_System)
  * [Immune System](/wiki/Wikijunior:Biology/Systems/Immune_System)
  * [Muscular System](/wiki/Wikijunior:Biology/Systems/Muscular_System)
  * [Skeletal System](/wiki/Wikijunior:Biology/Systems/Skeletal_System)
  * [Integumentary System](/wiki/Wikijunior:Biology/Systems/Integumentary_System)
  * [Nervous System](/wiki/Wikijunior:Biology/Systems/Nervous_System)

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Systems](/wiki/Wikijunior:Biology/Systems)**
**Printable version**
**[Respiratory System](/wiki/Wikijunior:Biology/Systems/Respiratory_System)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Grafik_blutkreislauf.jpg/200px-Grafik_blutkreislauf.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

The Circulatory System

## The Circulatory System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Circulatory_System&action=edit&section=T-1)]

The **Circulatory System** moves blood around your body. This blood carries food and _oxygen_ around to all of the cells of the body. It also carries signals called **hormones** that help the body work together.

The major organ of the circulatory system is the **heart**, which pumps the blood. Blood goes away from the heart in tubes called **arteries** and comes back to the heart in tubes called **veins**. The smallest tubes are called **capillaries**.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Circulatory System](/wiki/Wikijunior:Biology/Systems/Circulatory_System)**
**Printable version**
**[Digestive System](/wiki/Wikijunior:Biology/Systems/Digestive_System)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Lungs_diagram_simple.svg/300px-Lungs_diagram_simple.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Lungs

## The Respiratory System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Respiratory_System&action=edit&section=T-1)]

The **Respiratory System** is how air gets into our bodies. We breathe in and out with our **lungs**. The air we breathe in has something called _oxygen_ that our cells need. Cells make _carbon dioxide_ which can poison our bodies. Our lungs push this out of our bodies.

The respiratory system works together with the [circulatory system](/w/index.php?title=Wikijunior:Biology/Circulatory_System&action=edit&redlink=1) to make sure that air gets to each cell of the body.

Parts of the respiratory system are the nose, pharynx, larynx, trachea, bronchi, bronchioles, and alveoli.

  * Air comes in through the nose and mouth.
  * Dust is removed by the hair in the nose.
  * Air goes through the pharynx (in the back of the mouth), the larynx or the voice box, and down the trachea (windpipe).
  * The trachea splits into two major bronchi, one for each lung.
  * This further splits into smaller bronchi, then into smaller tubes called _bronchioles_ which lead into the air sacs called _alveoli_.
  * This is where the oxygen goes into the blood and carbon dioxide comes out.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Respiratory System](/wiki/Wikijunior:Biology/Systems/Respiratory_System)**
**Printable version**
**[Endocrine System](/wiki/Wikijunior:Biology/Systems/Endocrine_System)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Digestive_system_diagram_en.svg/300px-Digestive_system_diagram_en.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Digestive system

## The Digestive System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Digestive_System&action=edit&section=T-1)]

The **digestive system** is what a human uses to eat. Food comes in through our _mouth_ is broken down in our _stomach_ and our body takes the food in through the _intestines_. Then the waste goes out through the _anus_.

The digestive system is made of many organs. Here are some of the organs and their functions:

    **Oesophagus** \- Pushes food down into the stomach.
    **Stomach** \- Breaks down complex sugar by acid.
    **Liver** \- Makes a thing called _bile_ that breaks down fat.
    **Gall bladder** \- Stores the bile and adds it when it is needed.
    **Pancreas** \- Makes chemicals that break down food.
    **Small intestine** \- Absorbs food for body.
    **Large intestine** \- Absorbs water and salt.
    **Rectum** \- Stores waste.
    **Appendix** \- Vestigial organ(has no function in human body).

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Digestive System](/wiki/Wikijunior:Biology/Systems/Digestive_System)**
**Printable version**
**[Reproductive System](/wiki/Wikijunior:Biology/Systems/Reproductive_System)**

![Illu endocrine system.png](//upload.wikimedia.org/wikipedia/commons/d/da/Illu_endocrine_system.png)

## The Endocrine System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Endocrine_System&action=edit&section=T-1)]

The human body is made of many, many cells. To make the cells work together, the body sends signals through the blood called _hormones_ that tell the cells in the body what to do.

  
The **Endocrine System** is the [organ system](/wiki/Wikijunior:Biology) made of the organs that make hormones.

The endocrine system organs:

  1. Pineal gland
  2. Pituitary gland
  3. Thyroid gland
  4. Thymus
  5. Adrenal gland
  6. Pancreas
  7. Ovary
  8. Testis

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Endocrine System](/wiki/Wikijunior:Biology/Systems/Endocrine_System)**
**Printable version**
**[Urinary System](/wiki/Wikijunior:Biology/Systems/Urinary_System)**

## How are babies made?[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Reproductive_System&action=edit&section=T-1)]

In humans there are two sexes: _Men_ and _Women_. Babies are made when [cells](/wiki/Wikijunior:Biology/Cells) called _sperm_ (produced by men) get together with cells called _eggs_ (produced by women) in a process called **fertilization**. When the cells combine, they form a new cell, called a **zygote** (_zy_ rhymes with _eye_; _gote_ sounds like _goat_) which has all it needs to make a new man or woman. The zygote will make a baby like his mother and father.

## Where do babies come from?[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Reproductive_System&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Month_6.svg/220px-Month_6.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

A baby grows in its mother.

Babies come from their mother. To make a baby, the father must put his sperm into the mother's body. This is called _having sex_. The man puts his _penis_ into the woman's _vagina_ and the sperm cells swim into the mother's body. Fertilization happens in the mother. The new zygote grows into a ball which will stick to the mother's **womb**. This ball grows into a baby.

Nine months later (266 days after fertilization) a new baby will come out of the mother's vagina in a process called **birth**.

#### Words[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Reproductive_System&action=edit&section=T-3)]

**cell** \- Things that are alive are made of little boxes called cells.

**womb** \- The place in a body where a baby grows.

**zygote** \- The one cell made from a sperm cell and an egg cell that will grow into a person.

**sperm** \- A sex cell made by a man.

**egg** \- A sex cell made by a woman.

**fertilization** \- When sperm and egg get together and make a zygote.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Reproductive System](/wiki/Wikijunior:Biology/Systems/Reproductive_System)**
**Printable version**
**[Immune System](/wiki/Wikijunior:Biology/Systems/Immune_System)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Adrenal_gland_%28PSF%29.jpg/280px-Adrenal_gland_%28PSF%29.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Urinary System

## The Urinary System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Urinary_System&action=edit&section=T-1)]

The **Urinary system** takes bad things out of the blood and washes it out of the body. This liquid waste is called **urine**. Without the urinary system, poisons would fill up the blood and kill a person. The **kidneys** are [organs](/wiki/Wikijunior:Biology/Organs) that filter the blood and remove poison. Urine is stored in a bag called the **bladder** and it leaves the body through a tube called the **urethra**.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Urinary System](/wiki/Wikijunior:Biology/Systems/Urinary_System)**
**Printable version**
**[Muscular System](/wiki/Wikijunior:Biology/Systems/Muscular_System)**

## Immune System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Immune_System&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/a/af/PBEosinophil.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

A disease, that our Immune System tries to fight against.

The **immune system** protects our bodies from disease. Cells called _white blood cells_ found in our blood are able to kill bad things such as [bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria) and [viruses](/wiki/Wikijunior:Biology/Viruses).

There are many different types of white blood cells. Some of them make things called **antibodies** that stick to things that enter our bodies making them easy to find. Other white blood cells get rid of bacteria and stop viruses like the flu.

When our immune system does not work well, we are vulnerable to disease caused by [bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria) and [viruses](/wiki/Wikijunior:Biology/Viruses). Problems with the immune system include **allergies**; in allergies, white blood cells attack things that are not bad, like pollen in our eyes or cat dander. **AIDS (Acquired Immunodeficiency Syndrome)** is a disease caused by a virus that kills some white blood cells, leaving our bodies vulnerable to bacteria or viruses.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Immune System](/wiki/Wikijunior:Biology/Systems/Immune_System)**
**Printable version**
**[Skeletal System](/wiki/Wikijunior:Biology/Systems/Skeletal_System)**

## Muscular system[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Muscular_System&action=edit&section=T-1)]

![Illu head neck muscle.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/7/78/Illu_head_neck_muscle.jpg/350px-Illu_head_neck_muscle.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

The _muscles_ of the body are what make the body move. They are made of muscle [tissues](/wiki/Wikijunior:Biology/Tissues).

All of the muscles of the body together make up the **muscular system**.

Signals from the [nervous system](/w/index.php?title=Wikijunior:Biology/Nervous_System&action=edit&redlink=1) tell the muscles when to move. The muscles are attached to the [skeleton](/w/index.php?title=Wikijunior:Biology/Skeletal_System&action=edit&redlink=1) which holds them up.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Muscular System](/wiki/Wikijunior:Biology/Systems/Muscular_System)**
**Printable version**
**[Integumentary System](/wiki/Wikijunior:Biology/Systems/Integumentary_System)**

## The Skeletal System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Skeletal_System&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Human_skeleton_front_en.svg/220px-Human_skeleton_front_en.svg.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

The human skeleton.

The **Skeletal System** is made of all of the bones in the body. It protects the [reproductive organs](/w/index.php?title=Wikijunior:Biology/Reproductive_System&action=edit&redlink=1) and is a place for [muscles](/w/index.php?title=Wikijunior:Biology/Muscular_System&action=edit&redlink=1) to attach. Bones are a very important part of the human body. Without them, we would simply collapse, and be very unstable. They support all of our tissue and muscles, and they are very difficult to break.

The inside of the bones is called the _bone marrow_. This is where most [blood cells](/w/index.php?title=Wikijunior:Biology/Circulatory_System&action=edit&redlink=1) are made.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Skeletal System](/wiki/Wikijunior:Biology/Systems/Skeletal_System)**
**Printable version**
**[Nervous System](/wiki/Wikijunior:Biology/Systems/Nervous_System)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Gaensehaut.jpg/200px-Gaensehaut.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Skin

## The Integumentary System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Integumentary_System&action=edit&section=T-1)]

The **Integumentary System** is the system of the body made up of the skin, the nails, and the hair.

Skin keeps you cool by sweating. It also protects you by keeping things out of your body. The hair on your body keeps you warm. Skin also holds [nerves](/w/index.php?title=Wikijunior:Biology/Nervous_System&action=edit&redlink=1) that we use to touch and hold and kiss. Your nails help you pick up things. The skin is the largest organ of the human body.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Integumentary System](/wiki/Wikijunior:Biology/Systems/Integumentary_System)**
**Printable version**
**[Kingdoms](/wiki/Wikijunior:Biology/Kingdoms)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Nervous_system_diagram.png/363px-Nervous_system_diagram.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

The nervous system

## The Nervous System[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Nervous_System&action=edit&section=T-1)]

The _nervous system_ helps you sense the world around you. It includes the _brain_ and the _nerves_ as well as the _senses_.

The nervous system can sense changes inside and outside the body through specialized cells called _receptors_. This information, in the form of small electric currents, is analyzed and responses are generated in the nervous system. These responses, again in the form of small electric currents, are conveyed to the appropriate organs such as muscles or glands, at a great speed.

### The Senses[[edit](/w/index.php?title=Wikijunior:Biology/Systems/Nervous_System&action=edit&section=T-2)]

Your five senses are: _smell_ (with your nose), _taste_ (with your tongue), _touch_ (with your fingers, and so on), _sight_ (with your eyes), and _hearing_ (with your ears).

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Nose_with_glasses.jpg/100px-Nose_with_glasses.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

A child's nose

If human beings couldn't smell, they wouldn't know if their food had a bad odor. If they couldn't taste either, they might like to eat everything, or, also bad in a different way, they might not like to eat anything. If they couldn't see, it would be harder for them to find their way around. And if they couldn't hear, they could not talk to each other as easily.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Nervous System](/wiki/Wikijunior:Biology/Systems/Nervous_System)**
**Printable version**
**[Archaea](/wiki/Wikijunior:Biology/Kingdoms/Archaea)**

## Kingdoms[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms&action=edit&section=T-1)]

When we look at living things we divide them up into groups and give the groups names. This is called **classification**.

Living things are classified into groups of different sizes. The biggest groups contain almost everything. The smallest groups have only a few types of living things in them.

The groups are, from large to small:

    Domain
    Kingdom
    Phylum
    Class
    Order
    Family
    Genus
    Species

  
The domains are _Bacteria_, _Archaea_, and _Eukarya_, but most people still find it easiest to divide things by **kingdom**.

The six kingdoms are:

    [Archaea](/wiki/Wikijunior:Biology/Kingdoms/Archaea)
    [Bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria)
    [Animalia (Animals)](/wiki/Wikijunior:Biology/Kingdoms/Animals)
    [Plantae (Plants)](/wiki/Wikijunior:Biology/Kingdoms/Plants)
    [Fungi (Funguses and mushrooms)](/wiki/Wikijunior:Biology/Kingdoms/Fungi)
    [Protista (Protists and Algae)](/wiki/Wikijunior:Biology/Kingdoms/Protists)

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Kingdoms](/wiki/Wikijunior:Biology/Kingdoms)**
**Printable version**
**[Bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria)**

## Archea[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Archaea&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/71/Colourful_Thermophilic_Archaebacteria_Stain_in_Midway_Geyser_Basin.jpg/400px-Colourful_Thermophilic_Archaebacteria_Stain_in_Midway_Geyser_Basin.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Colorful archea

Archea are creatures made up of single cells. They have been on Earth for a long, long time. Their name means old.

Archea have no nucleus in their single cell. They were once called bacteria, but they were taken out of the [kingdom bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria) because they are so different.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Archaea](/wiki/Wikijunior:Biology/Kingdoms/Archaea)**
**Printable version**
**[Protists](/wiki/Wikijunior:Biology/Kingdoms/Protists)**

## Bacteria[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Bacteria&action=edit&section=T-1)]

**Bacteria** are single celled creatures with no nucleus. They are very, very small. They grow all over the Earth, in the ground, in the water, and even in our bodies.

Some bacteria can cause diseases, but most do good things like break down waste and make _oxygen_.

![Bacteriarazorback.jpg](//upload.wikimedia.org/wikipedia/commons/f/f6/Bacteriarazorback.jpg)

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria)**
**Printable version**
**[Fungi](/wiki/Wikijunior:Biology/Kingdoms/Fungi)**

## Protists[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Protists&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/24/Protist_collage.jpg/300px-Protist_collage.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

protists

Most **protists** are made of single cells. They are bigger than [archaea](/wiki/Wikijunior:Biology/Kingdoms/Archaea) and [bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria), and protist cells have a nucleus.

There are many different kinds of protist cells. Most live in the water, but some live in the soil or in animals. Some protists can cause diseases.

Green Algae is in the family protista. These can be small single cells or very large with many cells. _Sea weed_ is algae and is in the kingdom protista.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Protists](/wiki/Wikijunior:Biology/Kingdoms/Protists)**
**Printable version**
**[Plants](/wiki/Wikijunior:Biology/Kingdoms/Plants)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Shiitake_mushroom.jpg/200px-Shiitake_mushroom.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Shiitake mushroom

## Fungi[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Fungi&action=edit&section=T-1)]

**Fungi** are mostly made of many cells. Fungi made of single cells are called _yeasts_. They are also part of a group of living things called 'Eukaryotes', just like animals and plants. We're closer to mushrooms and yeasts than you think!

Lots of people, when they see fungi, think of mushrooms, however there are lots of different types of fungi, not just mushrooms and toadstools.

Fungi are very important because they break down waste. The leaves on the bottom of a forest would get higher and higher if fungi were not there to eat it.

Fungi are also important producers of food for humans. Also, yeasts are used to make wine, beer, and bread. Some fungi are bad for our food, however, such as mould.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Fungi](/wiki/Wikijunior:Biology/Kingdoms/Fungi)**
**Printable version**
**[Animals](/wiki/Wikijunior:Biology/Kingdoms/Animals)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Musa_JPG01.jpg/250px-Musa_JPG01.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Banana plant

## Plants[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Plants&action=edit&section=T-1)]

Plants are made of many [cells](/wiki/Wikijunior:Biology/Cells). Plants are usually green. Plants make their food from the sun. They use the light, carbon dioxide, and water to make glucose (sugar). Animals, fungi, some bacteria, and some protists eat plants for food.

  
Plants make _oxygen_ which humans breathe, and they take in _carbon-dioxide_ which humans exhale (that is, breathe out). Plants make their food from the sun by _photosynthesis_. They also provide shade. We make our houses from plants and make clothes from plants. Most foods that we eat are plants. Without plants, animals could not survive.

## What is photosynthesis?[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Plants&action=edit&section=T-2)]

Photosynthesis is making sugar using the energy of light.

### Why are plants green?[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Plants&action=edit&section=T-3)]

Plants are green because they have green Chloroplasts.

But why are Chloroplasts green? Chloroplasts are green because they contain the green pigment _chlorophyll_ in their thylakoid membranes. Chlorophyll is a pigment that absorbs red and blue light.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Plants](/wiki/Wikijunior:Biology/Kingdoms/Plants)**
**Printable version**
**[Viruses](/wiki/Wikijunior:Biology/Viruses)**

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/28/Ocelot.jpg/300px-Ocelot.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Ocelot, a cat

## Animals[[edit](/w/index.php?title=Wikijunior:Biology/Kingdoms/Animals&action=edit&section=T-1)]

Animals are made of many cells. They eat things and digest them inside. Most animals can move. Only animals have brains (though not even all animals do; jellyfish, for example, do not have brains).

Animals are found all over the earth. They dig in the ground, swim in the oceans, and fly in the sky.

Humans are a type of animal. So are dogs, cats, cows, horses, frogs, fish, and so on and on.

Animals can be divided into two main groups, vertebrates and invertebrates. Vertebrates can be further divided into mammals, fish, birds, reptiles, and amphibians. Invertebrates can be divided into arthropods (like insects, spiders, and crabs), mollusks, sponges, several different kinds of worms, jellyfish — and quite a few other subgroups. There are at least thirty kinds of invertebrates, compared to the five kinds of vertebrates.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Animals](/wiki/Wikijunior:Biology/Kingdoms/Animals)**
**Printable version**
**[Conclusion](/wiki/Wikijunior:Biology/Conclusion)**

## Viruses[[edit](/w/index.php?title=Wikijunior:Biology/Viruses&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Rotavirus_Reconstruction.jpg/220px-Rotavirus_Reconstruction.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

A virus called a rotavirus, which can cause diarrhoea.

Viruses are much smaller than other living things like [bacteria](/wiki/Wikijunior:Biology/Kingdoms/Bacteria), so small that it would take around one hundred viruses laid end to end just to make the length of a bacterium! Viruses are not really alive. They do not do all of the [things that living things do](/wiki/Wikijunior:Biology/Introduction#What_is_life.3F). They can only make more copies of themselves when they are inside living cells.

Viruses often kill [cells](/wiki/Wikijunior:Biology/Cells), and also make you ill. Lots of diseases are caused by viruses, the most famous ones being the flu and many colds.

**[Wikijunior:Biology](/wiki/Wikijunior:Biology)**

**[Viruses](/wiki/Wikijunior:Biology/Viruses)**
**Printable version**

## The End[[edit](/w/index.php?title=Wikijunior:Biology/Conclusion&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/As08-16-2593.jpg/400px-As08-16-2593.jpg)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

The Earth is the home of life

Biology is the study of Life. Life is all around us.

It is good to learn about living things.

  


Know Life and know the world!

  
Know Life and know yourself!

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Wikijunior:Biology/Printable_version&oldid=1896768](http://en.wikibooks.org/w/index.php?title=Wikijunior:Biology/Printable_version&oldid=1896768)" 

[See also](/wiki/Special:Categories): 

  * [Wikijunior:Biology](/wiki/Category:Wikijunior:Biology)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3ABiology%2FPrintable+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3ABiology%2FPrintable+version)

### Namespaces

  * [Wikijunior](/wiki/Wikijunior:Biology/Printable_version)
  * [Discussion](/w/index.php?title=Wikijunior_talk:Biology/Printable_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Wikijunior:Biology/Printable_version)
  * [Edit](/w/index.php?title=Wikijunior:Biology/Printable_version&action=edit)
  * [View history](/w/index.php?title=Wikijunior:Biology/Printable_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Wikijunior:Biology/Printable_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Wikijunior:Biology/Printable_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Wikijunior:Biology/Printable_version&oldid=1896768)
  * [Page information](/w/index.php?title=Wikijunior:Biology/Printable_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Wikijunior%3ABiology%2FPrintable_version&id=1896768)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Wikijunior%3ABiology%2FPrintable+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Wikijunior%3ABiology%2FPrintable+version&oldid=1896768&writer=rl)
  * [Printable version](/w/index.php?title=Wikijunior:Biology/Printable_version&printable=yes)

  * This page was last modified on 21 July 2010, at 15:41.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Wikijunior:Biology/Printable_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
