# Algorithms/Print version

From Wikibooks, open books for an open world

< [Algorithms](/wiki/Algorithms)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Algorithms/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Algorithms/Print_version) on _15 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Algorithms/Print_version&oldid=2502040&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Algorithms](/wiki/Algorithms)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Algorithms/Print_version&action=purge&printable=yes) this page.
![AlgorithmsTitleImage.png](//upload.wikimedia.org/wikipedia/commons/3/32/AlgorithmsTitleImage.png)

Permission is granted to copy, distribute and/or modify this document under the terms of the GNU Free Documentation License, Version 1.2 or any later version published by the Free Software Foundation; with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts. A copy of the license is included in the section entitled "GNU Free Documentation License".

# Contents

If you have saved this file to your computer, click on a link in the contents to go to that section.

  * Chapter 1: Introduction
  * Chapter 2: Mathematical Background
  * Chapter 3: Divide and Conquer
  * Chapter 4: Randomization
  * Chapter 5: Backtracking
  * Chapter 6: Dynamic Programming
  * Chapter 7: Greedy Algorithms
  * Chapter 8: Hill Climbing
  * Appendix A: Ada Implementation
  * GNU Free Documentation License

# Introduction

This book covers techniques for the design and analysis of algorithms. The algorithmic techniques covered include: divide and conquer, backtracking, dynamic programming, greedy algorithms, and hill-climbing.

Any solvable problem generally has at least one algorithm of each of the following types:

  1. the obvious way;
  2. the methodical way;
  3. the clever way; and
  4. the miraculous way.

On the first and most basic level, the "obvious" solution might try to exhaustively search for the answer. Intuitively, the obvious solution is the one that comes easily if you're familiar with a programming language and the basic problem solving techniques.

The second level is the methodical level and is the heart of this book: after understanding the material presented here you should be able to methodically turn most obvious algorithms into better performing algorithms.

The third level, the clever level, requires more understanding of the elements involved in the problem and their properties or even a reformulation of the algorithm (e.g., numerical algorithms exploit mathematical properties that are not obvious). A clever algorithm may be hard to understand by being non-obvious that it is correct, or it may be hard to understand that it actually runs faster than what it would seem to require.

The fourth and final level of an algorithmic solution is the miraculous level: this is reserved for the rare cases where a breakthrough results in a highly non-intuitive solution.

Naturally, all of these four levels are relative, and some clever algorithms are covered in this book as well, in addition to the methodical techniques. Let's begin.

## Prerequisites

To understand the material presented in this book you need to know a programming language well enough to translate the pseudocode in this book into a working solution. You also need to know the basics about the following data structures: arrays, stacks, queues, linked-lists, trees, heaps (also called priority queues), disjoint sets, and graphs.

Additionally, you should know some basic algorithms like binary search, a sorting algorithm (merge sort, heap sort, insertion sort, or others), and breadth-first or depth-first search.

If you are unfamiliar with any of these prerequisites you should review the material in the _[Data Structures](/wiki/Computer_Science:Data_Structures)_ book first.

## When is Efficiency Important?

Not every problem requires the most efficient solution available. For our purposes, the term efficient is concerned with the time and/or space needed to perform the task. When either time or space is abundant and cheap, it may not be worth it to pay a programmer to spend a day or so working to make a program faster.

However, here are some cases where efficiency matters:

  * When resources are limited, a change in algorithms could create great savings and allow limited machines (like cell phones, embedded systems, and sensor networks) to be stretched to the frontier of possibility.
  * When the data is large a more efficient solution can mean the difference between a task finishing in two days versus two weeks. Examples include physics, genetics, web searches, massive online stores, and network traffic analysis.
  * Real time applications: the term "real time applications" actually refers to computations that give time guarantees, versus meaning "fast." However, the quality can be increased further by choosing the appropriate algorithm.
  * Computationally expensive jobs, like fluid dynamics, partial differential equations, VLSI design, and cryptanalysis can sometimes only be considered when the solution is found efficiently enough.
  * When a subroutine is common and frequently used, time spent on a more efficient implementation can result in benefits for every application that uses the subroutine. Examples include sorting, searching, pseudorandom number generation, kernel operations (not to be confused with the operating system kernel), database queries, and graphics.

In short, it's important to save time when you do not have any time to spare.

When is efficiency unimportant? Examples of these cases include prototypes that are used only a few times, cases where the input is small, when simplicity and ease of maintenance is more important, when the area concerned is not the bottle neck, or when there's another process or area in the code that would benefit far more from efficient design and attention to the algorithm(s).

## Inventing an Algorithm

Because we assume you have some knowledge of a programming language, let's start with how we translate an idea into an algorithm. Suppose you want to write a function that will take a string as input and output the string in lowercase:
    
    
    // _tolower -- translates all alphabetic, uppercase characters in str to lowercase_
    function **tolower**(string _str_): string
    

What first comes to your mind when you think about solving this problem? Perhaps these two considerations crossed your mind:

  1. Every character in _str_ needs to be looked at
  2. A routine for converting a single character to lower case is required

The first point is "obvious" because a character that needs to be converted might appear anywhere in the string. The second point follows from the first because, once we consider each character, we need to do something with it. There are many ways of writing the **tolower** function for characters:
    
    
    function **tolower**(character _c_): character
    

There are several ways to implement this function, including:

  * look _c_ up in a table -- a character indexed array of characters that holds the lowercase version of each character.
  * check if _c_ is in the range 'A' ≤ _c_ ≤ 'Z', and then add a numerical offset to it.

These techniques depend upon the character encoding. (As an issue of separation of concerns, perhaps the table solution is stronger because it's clearer you only need to change one part of the code.)

However such a subroutine is implemented, once we have it, the implementation of our original problem comes immediately:
    
    
    // _tolower -- translates all alphabetic, uppercase characters in str to lowercase_
    function **tolower**(string _str_): string
      let _result_ := ""
      for-each _c_ in _str_:
        _result_.append(**tolower**(_c_))
      repeat
      return _result_
    end
    

This code sample is also available in [Ada](/wiki/Ada_Programming/Algorithms#To_Lower).

The loop is the result of our ability to translate "every character needs to be looked at" into our native programming language. It became obvious that the **tolower** subroutine call should be in the loop's body. The final step required to bring the high-level task into an implementation was deciding how to build the resulting string. Here, we chose to start with the empty string and append characters to the end of it.

Now suppose you want to write a function for comparing two strings that tests if they are equal, ignoring case:
    
    
    // _equal-ignore-case -- returns true if s and t are equal, ignoring case_
    function **equal-ignore-case**(string _s_, string _t_): boolean
    

These ideas might come to mind:

  1. Every character in strings _s_ and _t_ will have to be looked at
  2. A single loop iterating through both might accomplish this
  3. But such a loop should be careful that the strings are of equal length first
  4. If the strings aren't the same length, then they cannot be equal because the consideration of ignoring case doesn't affect how long the string is
  5. A tolower subroutine for characters can be used again, and only the lowercase versions will be compared

These ideas come from familiarity both with strings and with the looping and conditional constructs in your language. The function you thought of may have looked something like this:
    
    
    // _equal-ignore-case -- returns true if s or t are equal, ignoring case_
    function **equal-ignore-case**(string _s_[1.._n_], string _t_[1.._m_]): boolean
      if _n_ != _m_:
        return false               _\if they aren't the same length, they aren't equal\_
      fi
      
      for _i_ := 1 to _n_:
        if **tolower**(_s_[_i_]) != **tolower**(_t_[_i_]):
          return false
        fi
      repeat
      return true
    end
    

This code sample is also available in [Ada](/wiki/Ada_Programming/Algorithms#Equal_Ignore_Case).

Or, if you thought of the problem in terms of functional decomposition instead of iterations, you might have thought of a function more like this:
    
    
    // _equal-ignore-case -- returns true if s or t are equal, ignoring case_
    function **equal-ignore-case**(string _s_, string _t_): boolean
      return **tolower**(_s_).equals(**tolower**(_t_))
    end
    

Alternatively, you may feel neither of these solutions is efficient enough, and you would prefer an algorithm that only ever made one pass of _s_ or _t_. The above two implementations each require two-passes: the first version computes the lengths and then compares each character, while the second version computes the lowercase versions of the string and then compares the results to each other. (Note that for a pair of strings, it is also possible to have the length precomputed to avoid the second pass, but that can have its own drawbacks at times.) You could imagine how similar routines can be written to test string equality that not only ignore case, but also ignore accents.

Already you might be getting the spirit of the pseudocode in this book. The pseudocode language is not meant to be a real programming language: it abstracts away details that you would have to contend with in any language. For example, the language doesn't assume generic types or dynamic versus static types: the idea is that it should be clear what is intended and it should not be too hard to convert it to your native language. (However, in doing so, you might have to make some design decisions that limit the implementation to one particular type or form of data.)

There was nothing special about the techniques we used so far to solve these simple string problems: such techniques are perhaps already in your toolbox, and you may have found better or more elegant ways of expressing the solutions in your programming language of choice. In this book, we explore general algorithmic techniques to expand your toolbox even further. Taking a naive algorithm and making it more efficient might not come so immediately, but after understanding the material in this book you should be able to methodically apply different solutions, and, most importantly, you will be able to ask yourself more questions about your programs. Asking questions can be just as important as answering questions, because asking the right question can help you reformulate the problem and think outside of the box.

## Understanding an Algorithm

Computer programmers need an excellent ability to reason with multiple-layered abstractions. For example, consider the following code:
    
    
    function **foo**(integer _a_):
      if (_a_ / 2) * 2 == _a_:
         print "The value " _a_ " is even."
      fi
    end
    

To understand this example, you need to know that integer division uses truncation and therefore when the if-condition is true then the least-significant bit in _a_ is zero (which means that _a_ must be even). Additionally, the code uses a string printing API and is itself the definition of a function to be used by different modules. Depending on the programming task, you may think on the layer of hardware, on down to the level of processor branch-prediction or the cache.

Often an understanding of binary is crucial, but many modern languages have abstractions far enough away "from the hardware" that these lower-levels are not necessary. Somewhere the abstraction stops: most programmers don't need to think about logic gates, nor is the physics of electronics necessary. Nevertheless, an essential part of programming is multiple-layer thinking.

But stepping away from computer programs toward algorithms requires another layer: mathematics. A program may exploit properties of binary representations. An algorithm can exploit properties of set theory or other mathematical constructs. Just as binary itself is not explicit in a program, the mathematical properties used in an algorithm are not explicit.

Typically, when an algorithm is introduced, a discussion (separate from the code) is needed to explain the mathematics used by the algorithm. For example, to really understand a greedy algorithm (such as Dijkstra's algorithm) you should understand the mathematical properties that show how the greedy strategy is valid for all cases. In a way, you can think of the mathematics as its own kind of subroutine that the algorithm invokes. But this "subroutine" is not present in the code because there's nothing to call. As you read this book try to think about mathematics as an implicit subroutine.

## Overview of the Techniques

The techniques this book covers are highlighted in the following overview.

  * **Divide and Conquer**: Many problems, particularly when the input is given in an array, can be solved by cutting the problem into smaller pieces (_divide_), solving the smaller parts recursively (_conquer_), and then combining the solutions into a single result. Examples include the merge sort and quicksort algorithms.
  * **Randomization**: Increasingly, randomization techniques are important for many applications. This chapter presents some classical algorithms that make use of random numbers.
  * **Backtracking**: Almost any problem can be cast in some form as a backtracking algorithm. In backtracking, you consider all possible choices to solve a problem and recursively solve subproblems under the assumption that the choice is taken. The set of recursive calls generates a tree in which each set of choices in the tree is considered consecutively. Consequently, if a solution exists, it will eventually be found. 

Backtracking is generally an inefficient, brute-force technique, but there are optimizations that can be performed to reduce both the depth of the tree and the number of branches. The technique is called backtracking because after one leaf of the tree is visited, the algorithm will go back up the call stack (undoing choices that didn't lead to success), and then proceed down some other branch. To be solved with backtracking techniques, a problem needs to have some form of "self-similarity," that is, smaller instances of the problem (after a choice has been made) must resemble the original problem. Usually, problems can be generalized to become self-similar.

  * **Dynamic Programming**: Dynamic programming is an optimization technique for backtracking algorithms. When subproblems need to be solved repeatedly (i.e., when there are many duplicate branches in the backtracking algorithm) time can be saved by solving all of the subproblems first (bottom-up, from smallest to largest) and storing the solution to each subproblem in a table. Thus, each subproblem is only visited and solved once instead of repeatedly. The "programming" in this technique's name comes from programming in the sense of writing things down in a table; for example, television programming is making a table of what shows will be broadcast when.
  * **Greedy Algorithms**: A greedy algorithm can be useful when enough information is known about possible choices that "the best" choice can be determined without considering all possible choices. Typically, greedy algorithms are not challenging to write, but they are difficult to prove correct.
  * **Hill Climbing**: The final technique we explore is hill climbing. The basic idea is to start with a poor solution to a problem, and then repeatedly apply optimizations to that solution until it becomes optimal or meets some other requirement. An important case of hill climbing is network flow. Despite the name, network flow is useful for many problems that describe relationships, so it's not just for computer networks. Many matching problems can be solved using network flow.

  


## Algorithm and code example

### Level 1 (easiest)

1\. _[Find maximum](/wiki/Algorithms/Find_maximum)_ With algorithm and several different programming languages

2\. _[Find minimum](/w/index.php?title=Algorithms/Find_minimum&action=edit&redlink=1)_ With algorithm and several different programming languages

3\. _[Find average](/w/index.php?title=Algorithms/Find_average&action=edit&redlink=1)_ With algorithm and several different programming languages

4\. _[Find mode](/w/index.php?title=Algorithms/Find_mode&action=edit&redlink=1)_ With algorithm and several different programming languages

5\. _[Find total](/w/index.php?title=Algorithms/Find_total&action=edit&redlink=1)_ With algorithm and several different programming languages

6\. _[Counting](/w/index.php?title=Algorithms/Counting&action=edit&redlink=1)_ With algorithm and several different programming languages

### Level 2

1\. _[Talking to computer Lv 1](/w/index.php?title=Algorithms/Talking_to_computer_Lv_1&action=edit&redlink=1)_ With algorithm and several different programming languages

2\. _[Sorting-bubble sort](/wiki/Algorithms/Sorting-bubble_sort)_ With algorithm and several different programming languages

3.

### Level 3

1\. _[Talking to computer Lv 2](/w/index.php?title=Algorithms/Talking_to_computer_Lv_2&action=edit&redlink=1)_ With algorithm and several different programming languages

### Level 4

1\. _[Talking to computer Lv 3](/w/index.php?title=Algorithms/Talking_to_computer_Lv_3&action=edit&redlink=1)_ With algorithm and several different programming languages

2\. _[Find approximate maximum](/wiki/Algorithms/Find_approximate_maximum)_ With algorithm and several different programming languages

### Level 5

1\. _[Quicksort](/wiki/Algorithm_Implementation/Sorting/Quicksort)_

# Mathematical Background

Before we begin learning algorithmic techniques, we take a detour to give ourselves some necessary mathematical tools. First, we cover mathematical definitions of terms that are used later on in the book. By expanding your mathematical vocabulary you can be more precise and you can state or formulate problems more simply. Following that, we cover techniques for analysing the running time of an algorithm. After each major algorithm covered in this book we give an analysis of its running time as well as a proof of its correctness

  


## Asymptotic Notation

In addition to correctness another important characteristic of a useful algorithm is its time and memory consumption. Time and memory are both valuable resources and there are important differences (even when both are abundant) in how we can use them.

How can you measure resource consumption? One way is to create a function that describes the usage in terms of some characteristic of the input. One commonly used characteristic of an input dataset is its size. For example, suppose an algorithm takes an input as an array of ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) integers. We can describe the time this algorithm takes as a function ![f](//upload.wikimedia.org/math/8/f/a/8fa14cdd754f91cc6554c9e71929cce7.png) written in terms of ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png). For example, we might write:

    ![f\(n\) = n^2 + 3n + 14](//upload.wikimedia.org/math/0/5/0/050021f28ebab921b207d3b0d55840c1.png)

where the value of ![f\(n\)](//upload.wikimedia.org/math/a/8/9/a8988ce0f88f5292aa28b6e49f114d45.png) is some unit of time (in this discussion the main focus will be on time, but we could do the same for memory consumption). Rarely are the units of time actually in seconds, because that would depend on the machine itself, the system it's running, and its load. Instead, the units of time typically used are in terms of the number of some fundamental operation performed. For example, some fundamental operations we might care about are: the number of additions or multiplications needed; the number of element comparisons; the number of memory-location swaps performed; or the raw number of machine instructions executed. In general we might just refer to these fundamental operations performed as steps taken.

Is this a good approach to determine an algorithm's resource consumption? Yes and no. When two different algorithms are similar in time consumption a precise function might help to determine which algorithm is faster under given conditions. But in many cases it is either difficult or impossible to calculate an analytical description of the exact number of operations needed, especially when the algorithm performs operations conditionally on the values of its input. Instead, what really is important is not the precise time required to complete the function, but rather the degree that resource consumption changes depending on its inputs. Concretely, consider these two functions, representing the computation time required for each size of input dataset:

    ![f\(n\) = n^3-12n^2+20n+110](//upload.wikimedia.org/math/2/7/d/27d4b0bc138cf41ea6b68717ba9eb535.png)
    ![g\(n\) = n^3+n^2+5n+5](//upload.wikimedia.org/math/e/3/1/e3185300c35282c87d2765f827597e58.png)

They look quite different, but how do they behave? Let's look at a few plots of the function (![f\(n\)](//upload.wikimedia.org/math/a/8/9/a8988ce0f88f5292aa28b6e49f114d45.png) is in red, ![g\(n\)](//upload.wikimedia.org/math/e/a/c/eac896151a22d31a60cceba6deea3cbb.png) in blue):

![](//upload.wikimedia.org/wikibooks/en/0/0f/Algorithms-Asymptotic-ExamplePlot1.png)

Plot of f and g, in range 0 to 5

![](//upload.wikimedia.org/wikibooks/en/b/bb/Algorithms-Asymptotic-ExamplePlot2.png)

Plot of f and g, in range 0 to 15

![](//upload.wikimedia.org/wikibooks/en/f/f7/Algorithms-Asymptotic-ExamplePlot3.png)

Plot of f and g, in range 0 to 100

![](//upload.wikimedia.org/wikibooks/en/6/67/Algorithms-Asymptotic-ExamplePlot4.png)

Plot of f and g, in range 0 to 1000

  


In the first, very-limited plot the curves appear somewhat different. In the second plot they start going in sort of the same way, in the third there is only a very small difference, and at last they are virtually identical. In fact, they approach ![n^3](//upload.wikimedia.org/math/e/5/5/e55ad3a069f00d4c8d543e9477467208.png), the dominant term. As n gets larger, the other terms become much less significant in comparison to n3.

As you can see, modifying a polynomial-time algorithm's low-order coefficients doesn't help much. What really matters is the highest-order coefficient. This is why we've adopted a notation for this kind of analysis. We say that:

    ![f\(n\) = n^3-12n^2+20n+110 = O\(n^3\)](//upload.wikimedia.org/math/4/6/3/463bc80434ee9c7fcf4e4242b374c996.png)

We ignore the low-order terms. We can say that:

    ![O\(\\log {n}\) \\le O\(\\sqrt{n}\) \\le O\(n\) \\le O\(n \\log {n}\) \\le O\(n^2\) \\le O\(n^3\) \\le O\(2^n\)](//upload.wikimedia.org/math/b/3/2/b32084fda5112b82f2272944d9278889.png)

This gives us a way to more easily compare algorithms with each other. Running an insertion sort on ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) elements takes steps on the order of ![O\(n^2\)](//upload.wikimedia.org/math/1/8/9/189317b4b935a745fcfaf95940d2b4f0.png). Merge sort sorts in ![O\(n \\log {n}\)](//upload.wikimedia.org/math/7/9/b/79b37ec4ae5768b555aa26efeae487b3.png) steps. Therefore, once the input dataset is large enough, merge sort is faster than insertion sort.

In general, we write

    ![f\(n\) = O\(g\(n\)\)](//upload.wikimedia.org/math/e/c/b/ecb5957b16ba0696c0fcb44a3061686e.png)

when

    ![\\exists c>0, \\exists n_0> 0, \\forall n\\ge n_{0}: 0\\le f\(n\)\\le c\\cdot g\(n\).](//upload.wikimedia.org/math/a/1/0/a10dc691df3a762faf7c69af332d1c25.png)

That is, ![f\(n\) = O\(g\(n\)\)](//upload.wikimedia.org/math/e/c/b/ecb5957b16ba0696c0fcb44a3061686e.png) holds if and only if there exists some constants ![c](//upload.wikimedia.org/math/4/a/8/4a8a08f09d37b73795649038408b5f33.png) and ![n_0](//upload.wikimedia.org/math/7/1/3/713046b065aa81fbe96db237e539e431.png) such that for all ![n>n_0](//upload.wikimedia.org/math/c/4/b/c4b6ab2f66c379f9346f6b80ef336e2c.png) ![f\(n\)](//upload.wikimedia.org/math/a/8/9/a8988ce0f88f5292aa28b6e49f114d45.png) is positive and less than or equal to ![c g\(n\)](//upload.wikimedia.org/math/d/1/8/d181c9833ae70295b494e43e076d3d5d.png).

Note that the equal sign used in this notation describes a relationship between ![f\(n\)](//upload.wikimedia.org/math/a/8/9/a8988ce0f88f5292aa28b6e49f114d45.png) and ![g\(n\)](//upload.wikimedia.org/math/e/a/c/eac896151a22d31a60cceba6deea3cbb.png) instead of reflecting a true equality. In light of this, some define Big-O in terms of a set, stating that:

    ![f\(n\)\\in O\(g\(n\)\)](//upload.wikimedia.org/math/d/9/b/d9b0c3a5fdb436804c7a00f5571443b2.png)

when

    ![f\(n\)\\in \\{f\(n\) : \\exists c>0, \\exists n_0> 0, \\forall n\\ge n_0: 0\\le f\(n\)\\le c\\cdot g\(n\)\\}.](//upload.wikimedia.org/math/4/9/8/49847c6faed608b1d6b88f985b1a29ad.png)

Big-O notation is only an upper bound; these two are both true:

    ![n^3 = O\(n^4\)](//upload.wikimedia.org/math/5/9/a/59a15aac0e201816496a04238ba97235.png)
    ![n^4 = O\(n^4\)](//upload.wikimedia.org/math/0/d/8/0d8cd2d2762161e93b816bbc56b186af.png)

If we use the equal sign as an equality we can get very strange results, such as:

    ![n^3 = n^4](//upload.wikimedia.org/math/c/7/e/c7eb71ec3213a51156fc17756a9ec712.png)

which is obviously nonsense. This is why the set-definition is handy. You can avoid these things by thinking of the equal sign as a one-way equality, i.e.:

    ![n^3 = O\(n^4\)](//upload.wikimedia.org/math/5/9/a/59a15aac0e201816496a04238ba97235.png)

does not imply

    ![O\(n^4\) = n^3](//upload.wikimedia.org/math/b/0/6/b06d17d234e3a5b90dd734931685f3df.png)

Always keep the O on the right hand side.

### Big Omega

Sometimes, we want more than an upper bound on the behavior of a certain function. Big Omega provides a lower bound. In general, we say that

    ![f\(n\) = \\Omega\(g\(n\)\)](//upload.wikimedia.org/math/7/f/d/7fd23648d5ef2a21c2e2027c9af87775.png)

when

    ![\\exists c>0, \\exists n_0> 0, \\forall n\\ge n_{0}: 0\\le c\\cdot g\(n\)\\le f\(n\).](//upload.wikimedia.org/math/a/d/8/ad89fdbff992972fed3fdbeec611ebe6.png)

i.e. ![f\(n\) = \\Omega\(g\(n\)\)](//upload.wikimedia.org/math/7/f/d/7fd23648d5ef2a21c2e2027c9af87775.png) if and only if there exist constants c and n0 such that for all n>n0 f(n) is positive and **greater** than or equal to cg(n).

So, for example, we can say that

    ![n^2-2n = \\Omega\(n^2\)](//upload.wikimedia.org/math/5/7/9/5792b7c1848ed658eee17c5eeaaadd75.png), (c=1/2, n0=4) or
    ![n^2-2n = \\Omega\(n\)](//upload.wikimedia.org/math/b/a/c/bacdbac72089b9fbcb22f83fea6d4e45.png), (c=1, n0=3),

but it is false to claim that

    ![n^2-2n = \\Omega\(n^3\).](//upload.wikimedia.org/math/4/5/c/45ca311f15f098c73e0d8fb9303b922e.png)

### Big Theta

When a given function is both O(g(n)) and Ω(g(n)), we say it is Θ(g(n)), and we have a tight bound on the function. A function f(n) is Θ(g(n)) when

    ![\\exists c_1>0, \\exists c_2>0, \\exists n_0> 0, \\forall n\\ge n_0 : 0\\le c_1\\cdot g\(n\)\\le f\(n\)\\le c_2\\cdot g\(n\),](//upload.wikimedia.org/math/1/8/1/1813e763d50f4a43c21a83dad8e05bde.png)

but most of the time, when we're trying to prove that a given ![f\(n\) = \\Theta\(g\(n\)\)](//upload.wikimedia.org/math/c/7/3/c73335632503a8e2ef79bc5ad686716b.png), instead of using this definition, we just show that it is both O(g(n)) and Ω(g(n)).

### Little-O and Omega

When the asymptotic bound is not tight, we can express this by saying that ![f\(n\) = o\(g\(n\)\)](//upload.wikimedia.org/math/5/f/4/5f454678eb90eb556ecc38b2e613559e.png) or ![f\(n\) = \\omega\(g\(n\)\).](//upload.wikimedia.org/math/e/e/b/eeb4cc03236efa00bcd483e663f4184b.png) The definitions are:

    f(n) is o(g(n)) iff ![\\forall c>0, \\exists n_0> 0, \\forall n\\ge n_0: 0\\le f\(n\) < c\\cdot g\(n\)](//upload.wikimedia.org/math/0/8/9/089ef81ee4f24e6304c5ffc8ba430fe5.png) and
    f(n) is ω(g(n)) iff ![\\forall c>0, \\exists n_0> 0, \\forall n\\ge n_0: 0\\le c\\cdot g\(n\) < f\(n\).](//upload.wikimedia.org/math/b/c/f/bcf3491613ca7f42729a40ed3c6117ab.png)

Note that a function f is in o(g(n)) when for any coefficient of g, g eventually gets larger than f, while for O(g(n)), there only has to exist a single coefficient for which g eventually gets at least as big as f.

[TODO: define what T(n,m) = O(f(n,m)) means. That is, when the running time of an algorithm has two dependent variables. Ex, a graph with n nodes and m edges. It's important to get the quantifiers correct!]

## Algorithm Analysis: Solving Recurrence Equations

Merge sort of n elements: ![T\(n\) = 2*T\(n/2\) + c\(n\)](//upload.wikimedia.org/math/d/a/9/da9a49814d893569d560d14963b8455a.png) This describes one iteration of the merge sort: the problem space ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) is reduced to two halves (![2*T\(n/2\)](//upload.wikimedia.org/math/5/3/e/53eed1a9c9e90aa244a38bef68f7d6df.png)), and then merged back together at the end of all the recursive calls (![c\(n\)](//upload.wikimedia.org/math/6/f/9/6f92aad59cd2c0646a2f0c5844875990.png)). This notation system is the bread and butter of algorithm analysis, so get used to it.

There are some theorems you can use to estimate the big Oh time for a function if its recurrence equation fits a certain pattern.

[TODO: write this section]

### Substitution method

Formulate a guess about the big Oh time of your equation. Then use proof by induction to prove the guess is correct.

[TODO: write this section]

### Summations

[TODO: show the closed forms of commonly needed summations and prove them]

### Draw the Tree and Table

This is really just a way of getting an intelligent guess. You still have to go back to the substitution method in order to prove the big Oh time.

[TODO: write this section]

### The Master Theorem

Consider a recurrence equation that fits the following formula:

    ![T\(n\) = a T\\left\({\\frac{n}{b}}\\right\) + O\(n^k\)](//upload.wikimedia.org/math/8/8/d/88d67a55d33bc1f20a7f74552a4f77a2.png)

for _a_ ≥ 1, _b_ > 1 and _k_ ≥ 0. Here, _a_ is the number of recursive calls made per call to the function, _n_ is the input size, _b_ is how much smaller the input gets, and _k_ is the polynomial order of an operation that occurs each time the function is called (except for the base cases). For example, in the merge sort algorithm covered later, we have

    ![T\(n\) = 2 T\\left\({\\frac{n}{2}}\\right\) + O\(n\)](//upload.wikimedia.org/math/b/b/2/bb2e5486d3a0a18302dcdd70ea32aab1.png)

because two subproblems are called for each non-base case iteration, and the size of the array is divided in half each time. The ![O\(n\)](//upload.wikimedia.org/math/7/b/a/7ba55e7c64a9405a0b39a1107e90ca94.png) at the end is the "conquer" part of this divide and conquer algorithm: it takes linear time to merge the results from the two recursive calls into the final result.

Thinking of the recursive calls of _T_ as forming a tree, there are three possible cases to determine where most of the algorithm is spending its time ("most" in this sense is concerned with its asymptotic behaviour):

  1. the tree can be **top heavy**, and most time is spent during the initial calls near the root;
  2. the tree can have a **steady state**, where time is spread evenly; or
  3. the tree can be **bottom heavy**, and most time is spent in the calls near the leaves

Depending upon which of these three states the tree is in _T_ will have different complexities:

**The Master Theorem**  


Given ![T\(n\) = a T\\left\({\\frac{n}{b}}\\right\) + O\(n^k\)](//upload.wikimedia.org/math/8/8/d/88d67a55d33bc1f20a7f74552a4f77a2.png) for _a_ ≥ 1, _b_ > 1 and _k_ ≥ 0:

  * If ![a < b^k](//upload.wikimedia.org/math/9/f/a/9fa0f59cb5f61746d639ac52774900b6.png), then ![T\(n\) = O\(n^k\)\\ ](//upload.wikimedia.org/math/2/4/d/24dfe716ba4a28c56eb928b5bb82342c.png) (top heavy)
  * If ![a = b^k](//upload.wikimedia.org/math/a/4/6/a46303eecfef670c9e04cd771b08b68a.png), then ![T\(n\) = O\(n^k\\cdot \\log n\)](//upload.wikimedia.org/math/0/a/e/0ae2e7e36b46ea10151b023e7bc7703e.png) (steady state)
  * If ![a > b^k](//upload.wikimedia.org/math/0/9/e/09e52454d505ed55078d6427e1960646.png), then ![T\(n\) = O\(n^{\\log_b a}\)](//upload.wikimedia.org/math/d/7/4/d74876e088d802538656f7b08082cbb2.png) (bottom heavy)

For the merge sort example above, where

    ![T\(n\) = 2 T\\left\({\\frac{n}{2}}\\right\) + O\(n\)](//upload.wikimedia.org/math/b/b/2/bb2e5486d3a0a18302dcdd70ea32aab1.png)

we have

    ![a=2, b=2, k=1\\implies b^k = 2](//upload.wikimedia.org/math/1/1/9/1197d41b015c797288b9550ec1dc7c07.png)

thus, ![a = b^k](//upload.wikimedia.org/math/a/4/6/a46303eecfef670c9e04cd771b08b68a.png) and so this is also in the "steady state": By the master theorem, the complexity of merge sort is thus

    ![T\(n\) = O\(n^1\\log n\) = O\(n \\log n\)](//upload.wikimedia.org/math/c/b/7/cb7344ac4ab22272a557b416e3e77fe0.png).

## Amortized Analysis

[Start with an adjacency list representation of a graph and show two nested for loops: one for each node n, and nested inside that one loop for each edge e. If there are n nodes and m edges, this could lead you to say the loop takes O(nm) time. However, only once could the innerloop take that long, and a tighter bound is O(n+m).]

  


# Divide and Conquer

The first major algorithmic technique we cover is **divide and conquer**. Part of the trick of making a good divide and conquer algorithm is determining how a given problem could be separated into two or more similar, but smaller, subproblems. More generally, when we are creating a divide and conquer algorithm we will take the following steps:

**Divide and Conquer Methodology**  


  1. Given a problem, identify a small number of significantly smaller subproblems of the same type
  2. Solve each subproblem recursively (the smallest possible size of a subproblem is a base-case)
  3. Combine these solutions into a solution for the main problem

The first algorithm we'll present using this methodology is the merge sort.

## Merge Sort

The problem that **merge sort** solves is general sorting: given an unordered array of elements that have a total ordering, create an array that has the same elements sorted. More precisely, for an array _a_ with indexes 1 through _n_, if the condition

    for all _i_, _j_ such that 1 ≤ _i_ < _j_ ≤ _n_ then _a_[_i_] ≤ _a_[_j_]

holds, then _a_ is said to be **sorted**. Here is the interface:
    
    
    _// sort -- returns a sorted copy of array a_
    function **sort**(array _a_): array
    

Following the divide and conquer methodology, how can _a_ be broken up into smaller subproblems? Because _a_ is an array of _n_ elements, we might want to start by breaking the array into two arrays of size _n_/2 elements. These smaller arrays will also be unsorted and it is meaningful to sort these smaller problems; thus we can consider these smaller arrays "similar". Ignoring the base case for a moment, this reduces the problem into a different one: Given two sorted arrays, how can they be combined to form a single sorted array that contains all the elements of both given arrays:
    
    
    _// merge -- given a and b (assumed to be sorted) returns a merged array that_
    // preserves order
    function **merge**(array _a_, array _b_): array
    

So far, following the methodology has led us to this point, but what about the base case? The base case is the part of the algorithm concerned with what happens when the problem cannot be broken into smaller subproblems. Here, the base case is when the array only has one element. The following is a sorting algorithm that faithfully sorts arrays of only zero or one elements:
    
    
    _// base-sort -- given an array of one element (or empty), return a copy of the_
    // array sorted
    function **base-sort**(array _a_[1.._n_]): array
      assert (_n_ <= 1)
      return _a_.copy()
    end
    

Putting this together, here is what the methodology has told us to write so far:
    
    
    _// sort -- returns a sorted copy of array a_
    function **sort**(array _a_[1.._n_]): array
      if _n_ <= 1: return _a_.copy()
      else:
        let _sub_size_ := _n_ / 2
        let _first_half_ := **sort**(_a_[1,..,_sub_size_])
        let _second_half_ := **sort**(_a_[_sub_size_ + 1,..,_n_])
        
        return **merge**(_first_half_, _second_half_)
      fi
    end
    

And, other than the unimplemented merge subroutine, this sorting algorithm is done! Before we cover how this algorithm works, here is how merge can be written:
    
    
    _// merge -- given a and b (assumed to be sorted) returns a merged array that_
    // preserves order
    function **merge**(array _a_[1.._n_], array _b_[1.._m_]): array
      let _result_ := new array[_n_ + _m_]
      let _i_, _j_ := 1
      
      for _k_ := 1 to _n_ + _m_:
        if _i_ >= _n_: _result_[_k_] := _b_[_j_]; _j_ += 1
        else-if _j_ >= _m_: _result_[_k_] := _a_[_i_]; _i_ += 1
        else:
          if _a_[_i_] < _b_[_j_]:
            _result_[_k_] := _a_[_i_]; _i_ += 1
          else:
            _result_[_k_] := _b_[_j_]; _j_ += 1
          fi
        fi
      repeat
    end
    

[TODO: how it works; including correctness proof] This algorithm uses the fact that, given two sorted arrays, the smallest element is always in one of two places. It's either at the head of the first array, or the head of the second.

### Analysis

Let ![T\(n\)](//upload.wikimedia.org/math/5/1/4/514884be093e9ab7909b0d394e7b74d2.png) be the number of steps the algorithm takes to run on input of size ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png).

Merging takes linear time and we recurse each time on two sub-problems of half the original size, so

    ![T\(n\) = 2\\cdot T\\left\(\\frac{n}{2}\\right\) + O\(n\).](//upload.wikimedia.org/math/f/7/2/f72a53c8f8f6d3035c197a35096a0c4e.png)

By the master theorem, we see that this recurrence has a "steady state" tree. Thus, the runtime is:

    ![T\(n\) = O\(n \\cdot \\log n\).](//upload.wikimedia.org/math/f/9/6/f96289c2cbde730474573330629fb8df.png)

This can be seen intuitivey by asking how may times does n need to be divided by 2 before the size of the array for sorting is 1? Why m times of course !

More directly, 2m = n , equivalent to log 2m = log n, equivalent to m x log22 = log 2 n , and since log2 2 = 1, equivalent to m = log2n.

Since m is the number of halvings of an array before the array is chopped up into bite sized pieces of 1-element arrays, and then it will take m levels of merging a sub-array with its neighbor where the sum size of sub-arrays will be n at each level, it will be exactly n/2 comparisons for merging at each level, with m ( log2n ) levels, thus O(n/2 x log n ) <=> **O ( n log n).**

### Iterative Version

This merge sort algorithm can be turned into an iterative algorithm by iteratively merging each subsequent pair, then each group of four, et cetera. Due to a lack of function overhead, iterative algorithms tend to be faster in practice. However, because the recursive version's call tree is logarithmically deep, it does not require much run-time stack space: Even sorting 4 gigs of items would only require 32 call entries on the stack, a very modest amount considering if even each call required 256 bytes on the stack, it would only require 8 kilobytes.

The iterative version of mergesort is a minor modification to the recursive version - in fact we can reuse the earlier merging function. The algorithm works by merging small, sorted subsections of the original array to create larger subsections of the array which are sorted. To accomplish this, we iterate through the array with successively larger "strides".
    
    
    _// sort -- returns a sorted copy of array a_
    function **sort_iterative**(array _a_[1.._n_]): array
       let _result_ := _a_.copy()
       for _power_ := 0 to log2(_n_-1)
         let _unit_ := 2^power
         for _i_ := 1 to _n_ by _unit_*2
           if i+_unit_-1 < n: 
             let _a1_[1.._unit_] := _result_[i..i+_unit_-1]
             let _a2_[1.._unit_] := _result_[i+_unit_..min(i+_unit_*2-1, _n_)]
             _result_[i..i+_unit_*2-1] := **merge**(_a1_,_a2_)
           fi
         repeat
       repeat
       
       return _result_
    end
    

This works because each sublist of length 1 in the array is, by definition, sorted. Each iteration through the array (using counting variable _i_) doubles the size of sorted sublists by merging adjacent sublists into sorted larger versions. The current size of sorted sublists in the algorithm is represented by the _unit_ variable.

### space inefficiency

Straight forward merge sort requires a space of 2 x n , n to store the 2 sorted smaller arrays , and n to store the final result of merging. But merge sort still lends itself for batching of merging.

## Binary Search

Once an array is sorted, we can quickly locate items in the array by doing a binary search. Binary search is different from other divide and conquer algorithms in that it is mostly divide based (nothing needs to be conquered). The concept behind binary search will be useful for understanding the partition and quicksort algorithms, presented in the randomization chapter.

Finding an item in an already sorted array is similar to finding a name in a phonebook: you can start by flipping the book open toward the middle. If the name you're looking for is on that page, you stop. If you went too far, you can start the process again with the first half of the book. If the name you're searching for appears later than the page, you start from the second half of the book instead. You repeat this process, narrowing down your search space by half each time, until you find what you were looking for (or, alternatively, find where what you were looking for would have been if it were present).

The following algorithm states this procedure precisely:
    
    
    _// binary-search -- returns the index of value in the given array, or_
    _// -1 if value cannot be found. Assumes array is sorted in ascending order_
    function **binary-search**(_value_, array _A_[1.._n_]): integer
      return **search-inner**(_value_, _A_, 1, _n_ + 1)
    end
    
    _// search-inner -- search subparts of the array; end is one past the_
    _// last element _
    function **search-inner**(_value_, array _A_, _start_, _end_): integer
      if _start_ == _end_: 
         return -1                   _// not found_
      fi
    
      let _length_ := _end_ - _start_
      if _length_ == 1:
        if _value_ == _A_[_start_]:
          return _start_
        else:
          return -1 
        fi
      fi
      
      let _mid_ := _start_ + (_length_ / 2)
      if _value_ == _A_[_mid_]:
        return _mid_
      else-if _value_ > _A_[_mid_]:
        return **search-inner**(_value_, _A_, _mid_ + 1, _end_)
      else:
        return **search-inner**(_value_, _A_, _start_, _mid_)
      fi
    end
    

Note that all recursive calls made are tail-calls, and thus the algorithm is iterative. We can explicitly remove the tail-calls if our programming language does not do that for us already by turning the argument values passed to the recursive call into assignments, and then looping to the top of the function body again:
    
    
    _// binary-search -- returns the index of value in the given array, or_
    _// -1 if value cannot be found. Assumes array is sorted in ascending order_
    function **binary-search**(_value_, array _A_[1,.._n_]): integer
      let _start_ := 1
      let _end_ := _n_ + 1
      
      loop:
        if _start_ == _end_: return -1 fi                 _// not found_
      
        let _length_ := _end_ - _start_
        if _length_ == 1:
          if _value_ == _A_[_start_]: return _start_
          else: return -1 fi
        fi
      
        let _mid_ := _start_ + (_length_ / 2)
        if _value_ == _A_[_mid_]:
          return _mid_
        else-if _value_ > _A_[_mid_]:
          _start_ := _mid_ + 1
        else:
          _end_ := _mid_
        fi
      repeat
    end
    

Even though we have an iterative algorithm, it's easier to reason about the recursive version. If the number of steps the algorithm takes is ![T\(n\)](//upload.wikimedia.org/math/5/1/4/514884be093e9ab7909b0d394e7b74d2.png), then we have the following recurrence that defines ![T\(n\)](//upload.wikimedia.org/math/5/1/4/514884be093e9ab7909b0d394e7b74d2.png):

    ![T\(n\) = 1\\cdot T\\left\(\\frac{n}{2}\\right\) + O\(1\).](//upload.wikimedia.org/math/6/a/5/6a51f0f28450408d3e83e7bb56b0de56.png)

The size of each recursive call made is on half of the input size (![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png)), and there is a constant amount of time spent outside of the recursion (i.e., computing _length_ and _mid_ will take the same amount of time, regardless of how many elements are in the array). By the master theorem, this recurrence has values ![a=1, b=2, k=0](//upload.wikimedia.org/math/c/6/0/c603c64df2de3b4846131fd3bd788af4.png), which is a "steady state" tree, and thus we use the steady state case that tells us that

    ![T\(n\) = \\Theta\(n^k\\cdot\\log n\) = \\Theta\(\\log n\).](//upload.wikimedia.org/math/2/6/e/26e74401bcd43f9e5f18ff17100fd624.png)

Thus, this algorithm takes logarithmic time. Typically, even when _n_ is large, it is safe to let the stack grow by ![\\log n](//upload.wikimedia.org/math/0/d/2/0d2e858bd7f89eed5461e5637d6e0a50.png) activation records through recursive calls.

#### difficulty in initially correct binary search implementations

The article on wikipedia on Binary Search also mentions the difficulty in writing a correct binary search algorithm: for instance, the java Arrays.binarySearch(..) overloaded function implementation does an interative binary search which didn't work when large integers overflowed a simple expression of mid calculation mid = ( end + start) / 2 i.e. end + start > max_positive_integer . Hence the above algorithm is more correct in using a length = end - start, and adding half length to start. The java binary Search algorithm gave a return value useful for finding the position of the nearest key greater than the search key, i.e. the position where the search key could be inserted.

i.e. it returns _\- (keypos+1)_ , if the search key wasn't found exactly, but an insertion point was needed for the search key ( insertion_point = _-return_value - 1_). Looking at [boundary values](/w/index.php?title=Boundary_values&action=edit&redlink=1), an insertion point could be at the front of the list ( ip = 0, return value = -1 ), to the position just after the last element, ( ip = length(A), return value = _\- length(A) - 1_) .

As an exercise, trying to implement this functionality on the above iterative binary search can be useful for further comprehension.

## Integer Multiplication

If you want to perform arithmetic with small integers, you can simply use the built-in arithmetic hardware of your machine. However, if you wish to multiply integers larger than those that will fit into the standard "word" integer size of your computer, you will have to implement a multiplication algorithm in software or use a software implementation written by someone else. For example, RSA encryption needs to work with integers of very large size (that is, large relative to the 64-bit word size of many machines) and utilizes special multiplication algorithms.[1]

### Grade School Multiplication

How do we represent a large, multi-word integer? We can have a binary representation by using an array (or an allocated block of memory) of words to represent the bits of the large integer. Suppose now that we have two integers, ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png) and ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png), and we want to multiply them together. For simplicity, let's assume that both ![X](//upload.wikimedia.org/math/0/2/1/02129bb861061d1a052c592e2dc6b383.png) and ![Y](//upload.wikimedia.org/math/5/7/c/57cec4137b614c87cb4e24a3d003a3e0.png) have ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) bits each (if one is shorter than the other, we can always pad on zeros at the beginning). The most basic way to multiply the integers is to use the grade school multiplication algorithm. This is even easier in binary, because we only multiply by 1 or 0:
    
    
             x6 x5 x4 x3 x2 x1 x0
          ×  y6 y5 y4 y3 y2 y1 y0
          -----------------------
             x6 x5 x4 x3 x2 x1 x0 (when y0 is 1; 0 otherwise)
          x6 x5 x4 x3 x2 x1 x0  0 (when y1 is 1; 0 otherwise)
       x6 x5 x4 x3 x2 x1 x0  0  0 (when y2 is 1; 0 otherwise)
    x6 x5 x4 x3 x2 x1 x0  0  0  0 (when y3 is 1; 0 otherwise)
      ... et cetera
    

As an algorithm, here's what multiplication would look like:
    
    
    _// multiply -- return the product of two binary integers, both of length n_
    function **multiply**(bitarray _x_[1,.._n_], bitarray _y_[1,.._n_]): bitarray
      bitarray _p_ = 0
      for _i_:=1 to _n_:
        if _y_[_i_] == 1:
          _p_ := **add**(_p_, _x_)
        fi
        _x_ := **pad**(_x_, 0)         _// add another zero to the end of x_
      repeat
      return _p_
    end
    

The subroutine **add** adds two binary integers and returns the result, and the subroutine **pad** adds an extra digit to the end of the number (padding on a zero is the same thing as shifting the number to the left; which is the same as multiplying it by two). Here, we loop _n_ times, and in the worst-case, we make _n_ calls to **add**. The numbers given to **add** will at most be of length ![2n](//upload.wikimedia.org/math/2/1/e/21e2c0c0472b331622877accbe29b91b.png). Further, we can expect that the **add** subroutine can be done in linear time. Thus, if _n_ calls to a ![O\(n\)](//upload.wikimedia.org/math/7/b/a/7ba55e7c64a9405a0b39a1107e90ca94.png) subroutine are made, then the algorithm takes ![O\(n^2\)](//upload.wikimedia.org/math/1/8/9/189317b4b935a745fcfaf95940d2b4f0.png) time.

### Divide and Conquer Multiplication

As you may have figured, this isn't the end of the story. We've presented the "obvious" algorithm for multiplication; so let's see if a divide and conquer strategy can give us something better. One route we might want to try is breaking the integers up into two parts. For example, the integer _x_ could be divided into two parts, ![x_{h}](//upload.wikimedia.org/math/a/0/2/a026dab4c61211a27de40531d9a99a39.png) and ![x_{l}](//upload.wikimedia.org/math/f/3/d/f3d897253574b4388b44258f6f5c637f.png), for the high-order and low-order halves of ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png). For example, if ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) has _n_ bits, we have

    ![x = x_{h}\\cdot 2^{n/2} + x_{l}](//upload.wikimedia.org/math/a/3/c/a3ccd80bed13472ec9d81dc4640c59ea.png)

We could do the same for ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png):

    ![y = y_{h}\\cdot 2^{n/2} + y_{l}](//upload.wikimedia.org/math/8/c/6/8c6acf834f6b7f60fbc1e79d4bd3fb2c.png)

But from this division into smaller parts, it's not clear how we can multiply these parts such that we can combine the results for the solution to the main problem. First, let's write out ![x\\times y](//upload.wikimedia.org/math/8/9/d/89df7401551d525a04db9dc12e4684ba.png) would be in such a system:

    ![x\\times y = x_h\\times y_h\\cdot \(2^{n/2}\)^2 + \(x_h\\times y_l + x_l\\times y_h\)\\cdot \(2^{n/2}\) + x_l\\times y_l](//upload.wikimedia.org/math/1/2/a/12a3ed0209478453aa81a13fe0f05e8b.png)

This comes from simply multiplying the new hi/lo representations of ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png) together. The multiplication of the smaller pieces are marked by the "![\\times](//upload.wikimedia.org/math/9/e/e/9eedd61e32f7a8e70e171028a7e5dc08.png)" symbol. Note that the multiplies by ![2^{n/2}](//upload.wikimedia.org/math/4/a/d/4addf4efa85422bf46470f4c8a39a260.png) and ![\(2^{n/2}\)^2 = 2^n](//upload.wikimedia.org/math/3/e/8/3e89ad3e123416796baf08275856c496.png) does not require a real multiplication: we can just pad on the right number of zeros instead. This suggests the following divide and conquer algorithm:
    
    
    _// multiply -- return the product of two binary integers, both of length n_
    function **multiply**(bitarray _x_[1,.._n_], bitarray _y_[1,.._n_]): bitarray
      if _n_ == 1: return _x_[1] * _y_[1] fi          _// multiply single digits: O(1)_
      
      let _xh_ := _x_[_n_/2 + 1, .., _n_]               _// array slicing, O(n)_
      let _xl_ := _x_[0, .., _n_ / 2]                 _// array slicing, O(n)_
      let _yh_ := _y_[_n_/2 + 1, .., _n_]               _// array slicing, O(n)_
      let _yl_ := _y_[0, .., _n_ / 2]                 _// array slicing, O(n)_
      
      let _a_ := **multiply**(_xh_, _yh_)                 _// recursive call; T(n/2)_
      let _b_ := **multiply**(_xh_, _yl_)                 _// recursive call; T(n/2)_
      let _c_ := **multiply**(_xl_, _yh_)                 _// recursive call; T(n/2)_
      let _d_ := **multiply**(_xl_, _yl_)                 _// recursive call; T(n/2)_
      
      _b_ := **add**(_b_, _c_)                            _// regular addition; O(n)_
      _a_ := **shift**(_a_, _n_)                          _// pad on zeros; O(n)_
      _b_ := **shift**(_b_, _n_/2)                        _// pad on zeros; O(n)_
      return **add**(_a_, _b_, _d_)                       _// regular addition; O(n)_
    end
    

We can use the master theorem to analyze the running time of this algorithm. Assuming that the algorithm's running time is ![T\(n\)](//upload.wikimedia.org/math/5/1/4/514884be093e9ab7909b0d394e7b74d2.png), the comments show how much time each step takes. Because there are four recursive calls, each with an input of size ![n/2](//upload.wikimedia.org/math/a/2/f/a2f070a31330443ceb0dcf352fe50035.png), we have:

    ![T\(n\) = 4T\(n/2\) + O\(n\)](//upload.wikimedia.org/math/4/c/6/4c61b6c528f67b912518c7969afcaf72.png)

Here, ![a=4, b=2, k=1](//upload.wikimedia.org/math/8/f/b/8fb390b1b471c382d30f1bee05731091.png), and given that ![4>2^1](//upload.wikimedia.org/math/3/c/5/3c538367fc6b1b4730094c0f27fbcf56.png) we are in the "bottom heavy" case and thus plugging in these values into the bottom heavy case of the master theorem gives us:

    ![T\(n\)=O\(n^{\\log_2 4}\) = O\(n^2\).](//upload.wikimedia.org/math/a/8/0/a8099bbfe928f65bd19d30753d12a48c.png)

Thus, after all of that hard work, we're still no better off than the grade school algorithm! Luckily, numbers and polynomials are a data set we know additional information about. In fact, we can reduce the running time by doing some mathematical tricks.

First, let's replace the ![2^{n/2}](//upload.wikimedia.org/math/4/a/d/4addf4efa85422bf46470f4c8a39a260.png) with a variable, _z_:

    ![x\\times y = x_h*y_h z^2 + \(x_h*y_l + x_l*y_h\)z + x_l*y_l](//upload.wikimedia.org/math/6/7/5/67523685a5432f740134b41a0fab0020.png)

This appears to be a quadratic formula, and we know that you only need three co-efficients or points on a graph in order to uniquely describe a quadratic formula. However, in our above algorithm we've been using four multiplications total. Let's try recasting ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) and ![y](//upload.wikimedia.org/math/4/1/5/415290769594460e2e485922904f345d.png) as linear functions:

    ![P_x\(z\) = x_h\\cdot z + x_l](//upload.wikimedia.org/math/8/4/2/842944f091d992c6a8c4ebaf1722c417.png)
    ![P_y\(z\) = y_h\\cdot z + y_l](//upload.wikimedia.org/math/4/7/a/47af5f8bb624ab676323d5dfc314c864.png)

Now, for ![x\\times y](//upload.wikimedia.org/math/8/9/d/89df7401551d525a04db9dc12e4684ba.png) we just need to compute ![\(P_x\\cdot P_y\)\(2^{n/2}\)](//upload.wikimedia.org/math/a/d/0/ad093341e2145cdb4d083e35f1e5c636.png). We'll evaluate ![P_x\(z\)](//upload.wikimedia.org/math/c/3/e/c3eabb62407978ba0f90e3d5b82ebb92.png) and ![P_y\(z\)](//upload.wikimedia.org/math/6/0/2/6020abdcae8a0792c4d330ef653786cb.png) at three points. Three convenient points to evaluate the function will be at ![\(P_x\\cdot P_y\)\(1\), \(P_x\\cdot P_y\)\(0\), \(P_x\\cdot P_y\)\(-1\)](//upload.wikimedia.org/math/8/4/1/841da1606b2cb5bb91bcda70f212db40.png):

[TODO: show how to make the two-parts breaking more efficient; then mention that the best multiplication uses the FFT, but don't actually cover that topic (which is saved for the advanced book)]

## Base Conversion

[TODO: Convert numbers from decimal to binary quickly using DnC.]

Along with the binary, the science of computers employs bases 8 and 16 for it's very easy to convert between the three while using bases 8 and 16 shortens considerably number representations.

To represent 8 first digits in the binary system we need 3 bits. Thus we have, 0=000, 1=001, 2=010, 3=011, 4=100, 5=101, 6=110, 7=111. Assume M=(2065)8. In order to obtain its binary representation, replace each of the four digits with the corresponding triple of bits: 010 000 110 101. After removing the leading zeros, binary representation is immediate: M=(10000110101)2. (For the hexadecimal system conversion is quite similar, except that now one should use 4-bit representation of numbers below 16.) This fact follows from the general conversion algorithm and the observation that 8=![2^3](//upload.wikimedia.org/math/6/3/a/63a1e1a5a5a28b0cf5e7687836075240.png) (and, of course, 16=![2^4](//upload.wikimedia.org/math/5/5/f/55fb55173e87cbecee6d8ae1616dc74c.png)). Thus it appears that the shortest way to convert numbers into the binary system is to first convert them into either octal or hexadecimal representation. Now let see how to implement the general algorithm programmatically.

For the sake of reference, representation of a number in a system with base (radix) N may only consist of digits that are less than N.

More accurately, if

    ![\(1\) M = a_kN^k+a_{k-1}N^{k-1}+...+a_1N^1+a_0](//upload.wikimedia.org/math/d/2/c/d2c0912710e206b66c1d2f8f88e4d999.png)

with ![0 <= a_i < N](//upload.wikimedia.org/math/e/7/f/e7fa931c3b9e0975737f7ec41ae98af8.png) we have a representation of M in base N system and write

    ![M = \(a_ka_{k-1}...a_0\)N](//upload.wikimedia.org/math/e/6/9/e697ac6c52214f8b69cc508e44cdcff7.png)

If we rewrite (1) as

    ![\(2\) M = a_0+N*\(a_1+N*\(a_2+N*...\)\)](//upload.wikimedia.org/math/2/e/9/2e97d6709796a736ee343df3b1ff26d2.png)

the algorithm for obtaining coefficients ai becomes more obvious. For example, ![a_0=M\\ modulo\\ n](//upload.wikimedia.org/math/6/2/1/6213514d2ee8e332b5219f82f591eb48.png) and ![a_1=\(M/N\)\\ modulo\\ n](//upload.wikimedia.org/math/b/6/2/b62d8290b3587b53101ae00b2d979e92.png), and so on.

### Recursive Implementation

Let's represent the algorithm mnemonically: (result is a string or character variable where I shall accumulate the digits of the result one at a time)
    
    
    result = "" 
    if M < N, result = 'M' + result. Stop. 
    S = M mod N, result = 'S' + result
    M = M/N 
    goto 2 
    

A few words of explanation.

"" is an empty string. You may remember it's a zero element for string concatenation. Here we check whether the conversion procedure is over. It's over if M is less than N in which case M is a digit (with some qualification for N>10) and no additional action is necessary. Just prepend it in front of all other digits obtained previously. The '+' plus sign stands for the string concatenation. If we got this far, M is not less than N. First we extract its remainder of division by N, prepend this digit to the result as described previously, and reassign M to be M/N. This says that the whole process should be repeated starting with step 2. I would like to have a function say called Conversion that takes two arguments M and N and returns representation of the number M in base N. The function might look like this
    
    
    1 String Conversion(int M, int N) // return string, accept two integers 
    2 {  
    3     if (M < N) // see if it's time to return 
    4         return new String(""+M); // ""+M makes a string out of a digit 
    5     else // the time is not yet ripe 
    6         return Conversion(M/N, N) +
               new String(""+(M mod N)); // continue 
    7 }  
    

This is virtually a working Java function and it would look very much the same in C++ and require only a slight modification for C. As you see, at some point the function calls itself with a different first argument. One may say that the function is defined in terms of itself. Such functions are called recursive. (The best known recursive function is factorial: n!=n*(n-1)!.) The function calls (applies) itself to its arguments, and then (naturally) applies itself to its new arguments, and then ... and so on. We can be sure that the process will eventually stop because the sequence of arguments (the first ones) is decreasing. Thus sooner or later the first argument will be less than the second and the process will start emerging from the recursion, still a step at a time.

### Iterative Implementation

Not all programming languages allow functions to call themselves recursively. Recursive functions may also be undesirable if process interruption might be expected for whatever reason. For example, in the Tower of Hanoi puzzle, the user may want to interrupt the demonstration being eager to test his or her understanding of the solution. There are complications due to the manner in which computers execute programs when one wishes to jump out of several levels of recursive calls.

Note however that the string produced by the conversion algorithm is obtained in the wrong order: all digits are computed first and then written into the string the last digit first. Recursive implementation easily got around this difficulty. With each invocation of the Conversion function, computer creates a new environment in which passed values of M, N, and the newly computed S are stored. Completing the function call, i.e. returning from the function we find the environment as it was before the call. Recursive functions store a sequence of computations implicitly. Eliminating recursive calls implies that we must manage to store the computed digits explicitly and then retrieve them in the reversed order.

In Computer Science such a mechanism is known as LIFO - Last In First Out. It's best implemented with a stack data structure. Stack admits only two operations: push and pop. Intuitively stack can be visualized as indeed a stack of objects. Objects are stacked on top of each other so that to retrieve an object one has to remove all the objects above the needed one. Obviously the only object available for immediate removal is the top one, i.e. the one that got on the stack last.

Then iterative implementation of the Conversion function might look as the following.
    
    
     1 String Conversion(int M, int N) // return string, accept two integers 
     2 {  
     3     Stack stack = new Stack(); // create a stack 
     4     while (M >= N) // now the repetitive loop is clearly seen 
     5     {  
     6         stack.push(M mod N); // store a digit 
     7         M = M/N; // find new M 
     8     }  
     9     // now it's time to collect the digits together  
    10     String str = new String(""+M); // create a string with a single digit M 
    11     while (stack.NotEmpty())  
    12         str = str+stack.pop() // get from the stack next digit 
    13     return str;  
    14 }  
    

The function is by far longer than its recursive counterpart; but, as I said, sometimes it's the one you want to use, and sometimes it's the only one you may actually use.

## Closest Pair of Points

For a set of points on a two-dimensional plane, if you want to find the closest two points, you could compare all of them to each other, at ![O\(n^2\)](//upload.wikimedia.org/math/1/8/9/189317b4b935a745fcfaf95940d2b4f0.png) time, or use a divide and conquer algorithm.

[TODO: explain the algorithm, and show the n^2 algorithm]

[TODO: write the algorithm, include intuition, proof of correctness, and runtime analysis]

Use this link for the original document.

<http://www.cs.mcgill.ca/~cs251/ClosestPair/ClosestPairDQ.html>

## Closest Pair: A Divide-and-Conquer Approach

### Introduction

The brute force approach to the closest pair problem (i.e. checking every possible pair of points) takes quadratic time. We would now like to introduce a faster divide-and-conquer algorithm for solving the closest pair problem. Given a set of points in the plane S, our approach will be to split the set into two roughly equal halves (S1 and S2) for which we already have the solutions, and then to merge the halves in linear time to yield an O(nlogn) algorithm. However, the actual solution is far from obvious. It is possible that the desired pair might have one point in S1 and one in S2, does this not force us once again to check all possible pairs of points? The divide-and-conquer approach presented here generalizes directly from the one dimensional algorithm we presented in the previous section.

### Closest Pair in the Plane

Alright, we'll generalize our 1-D algorithm as directly as possible (see figure 3.2). Given a set of points S in the plane, we partition it into two subsets S1 and S2 by a vertical line l such that the points in S1 are to the left of l and those in S2 are to the right of l.

We now recursively solve the problem on these two sets obtaining minimum distances of d1 (for S1), and d2 (for S2). We let d be the minimum of these.

Now, identical to the 1-D case, if the closes pair of the whole set consists of one point from each subset, then these two points must be within d of l. This area is represented as the two strips P1 and P2 on either side of l

Up to now, we are completely in step with the 1-D case. At this point, however, the extra dimension causes some problems. We wish to determine if some point in say P1 is less than d away from another point in P2. However, in the plane, we don't have the luxury that we had on the line when we observed that only one point in each set can be within d of the median. In fact, in two dimensions, all of the points could be in the strip! This is disastrous, because we would have to compare n2 pairs of points to merge the set, and hence our divide-and-conquer algorithm wouldn't save us anything in terms of efficiency. Thankfully, we can make another life saving observation at this point. For any particular point p in one strip, only points that meet the following constraints in the other strip need to be checked:

  * those points within d of p in the direction of the other strip
  * those within d of p in the positive and negative y directions

Simply because points outside of this bounding box cannot be less than d units from p (see figure 3.3). It just so happens that because every point in this box is at least d apart, there can be at most six points within it.

Now we don't need to check all n2 points. All we have to do is sort the points in the strip by their y-coordinates and scan the points in order, checking each point against a maximum of 6 of its neighbors. This means at most 6*n comparisons are required to check all candidate pairs. However, since we sorted the points in the strip by their y-coordinates the process of merging our two subsets is not linear, but in fact takes O(nlogn) time. Hence our full algorithm is not yet O(nlogn), but it is still an improvement on the quadratic performance of the brute force approach (as we shall see in the next section). In section 3.4, we will demonstrate how to make this algorithm even more efficient by strengthening our recursive sub-solution.

### Summary and Analysis of the 2-D Algorithm

We present here a step by step summary of the algorithm presented in the previous section, followed by a performance analysis. The algorithm is simply written in list form because I find pseudo-code to be burdensome and unnecessary when trying to understand an algorithm. Note that we pre-sort the points according to their x coordinates, and maintain another structure which holds the points sorted by their y values(for step 4), which in itself takes O(nlogn) time.

ClosestPair of a set of points:

  1. Divide the set into two equal sized parts by the line l, and recursively compute the minimal distance in each part.
  2. Let d be the minimal of the two minimal distances.
  3. Eliminate points that lie farther than d apart from l.
  4. Consider the remaining points according to their y-coordinates, which we have precomputed.
  5. Scan the remaining points in the y order and compute the distances of each point to all of its neighbors that are distanced no more than d(that's why we need it sorted according to y). Note that there are no more than 5(there is no figure 3.3 , so this 5 or 6 doesnt make sense without that figure . Please include it .) such points(see previous section).
  6. If any of these distances is less than d then update d.

Analysis:

  * Let us note T(n) as the efficiency of out algorithm
  * Step 1 takes 2T(n/2) (we apply our algorithm for both halves)
  * Step 3 takes O(n) time
  * Step 5 takes O(n) time (as we saw in the previous section)

so,

![T\(n\) = 2T\(n/2\) + O\(n\)](//upload.wikimedia.org/math/2/7/a/27a628ce0934d40b979b734829102a48.png)

which, according the Master Theorem, result

![T\(n\) \\isin O\(nlogn\)](//upload.wikimedia.org/math/b/d/b/bdb5ce0b113654fea48e8dc8086c0d82.png)

Hence the merging of the sub-solutions is dominated by the sorting at step 4, and hence takes O(nlogn) time.

This must be repeated once for each level of recursion in the divide-and-conquer algorithm,

hence the whole of algorithm ClosestPair takes O(logn*nlogn) = O(nlog2n) time.

### Improving the Algorithm

We can improve on this algorithm slightly by reducing the time it takes to achieve the y-coordinate sorting in Step 4. This is done by asking that the recursive solution computed in Step 1 returns the points in sorted order by their y coordinates. This will yield two sorted lists of points which need only be merged (a linear time operation) in Step 4 in order to yield a complete sorted list. Hence the revised algorithm involves making the following changes: Step 1: Divide the set into..., and recursively compute the distance in each part, returning the points in each set in sorted order by y-coordinate. Step 4: Merge the two sorted lists into one sorted list in O(n) time. Hence the merging process is now dominated by the linear time steps thereby yielding an O(nlogn) algorithm for finding the closest pair of a set of points in the plane.

## Towers Of Hanoi Problem

[TODO: Write about the towers of hanoi algorithm and a program for it]

There are n distinct sized discs and three pegs such that discs are placed at the left peg in the order of their sizes. The smallest one is at the top while the largest one is at the bottom. This game is to move all the discs from the left peg

### Rules

1) Only one disc can be moved in each step.

2) Only the disc at the top can be moved.

3) Any disc can only be placed on the top of a larger disc.

### Solution

#### Intuitive Idea

In order to move the largest disc from the left peg to the middle peg, the smallest discs must be moved to the right peg first. After the largest one is moved. The smaller discs are then moved from the right peg to the middle peg.

#### Recurrence

Suppose n is the number of discs.

To move n discs from peg a to peg b,

1) If n>1 then move n-1 discs from peg a to peg c

2) Move n-th disc from peg a to peg b

3) If n>1 then move n-1 discs from peg c to peg a

#### Pseudocode
    
    
    void hanoi(n,src,dst){
      if (n>1)
        hanoi(n-1,src,pegs-{src,dst});
      print "move n-th disc from src to dst";
      if (n>1)
        hanoi(n-1,pegs-{src,dst},dst);
    }
    

#### Analysis

The analysis is trivial. ![ T\(n\) = 2T\(n-1\) + O\(1\) = O\(2^n\)](//upload.wikimedia.org/math/2/5/1/25167f223a9c315d4061359514e6b5e2.png)

  


# Randomization

As deterministic algorithms are driven to their limits when one tries to solve hard problems with them, a useful technique to speed up the computation is **randomization**. In randomized algorithms, the algorithm has access to a _random source_, which can be imagined as tossing coins during the computation. Depending on the outcome of the toss, the algorithm may split up its computation path.

There are two main types of randomized algorithms: Las Vegas algorithms and Monte-Carlo algorithms. In Las Vegas algorithms, the algorithm may use the randomness to speed up the computation, but the algorithm must always return the correct answer to the input. Monte-Carlo algorithms do not have the former restriction, that is, they are allowed to give _wrong_ return values. However, returning a wrong return value must have a _small probability_, otherwise that Monte-Carlo algorithm would not be of any use.

Many approximation algorithms use randomization.

## Ordered Statistics

Before covering randomized techniques, we'll start with a deterministic problem that leads to a problem that utilizes randomization. Suppose you have an unsorted array of values and you want to find

  * the maximum value,
  * the minimum value, and
  * the median value.

In the immortal words of one of our former computer science professors, "How can you do?"

### find-max

First, it's relatively straightforward to find the largest element:
    
    
    _// find-max -- returns the maximum element_
    function **find-max**(array _vals_[1.._n_]): element
      let _result_ := _vals[1]_
      for _i_ from _2_ to _n_:
        _result_ := max(_result_, _vals[i]_)
      repeat
      
      return _result_
    end
    

An initial assignment of ![-\\infty](//upload.wikimedia.org/math/b/e/a/beab416080922c84a90ba092f7734fe5.png) to _result_ would work as well, but this is a useless call to the max function since the first element compared gets set to _result_. By initializing result as such the function only requires _n-1_ comparisons. (Moreover, in languages capable of metaprogramming, the data type may not be strictly numerical and there might be no good way of assigning ![-\\infty](//upload.wikimedia.org/math/b/e/a/beab416080922c84a90ba092f7734fe5.png); using vals[1] is type-safe.)

A similar routine to find the minimum element can be done by calling the min function instead of the max function.

### find-min-max

But now suppose you want to find the min and the max at the same time; here's one solution:
    
    
    _// find-min-max -- returns the minimum and maximum element of the given array_
    function **find-min-max**(array _vals_): pair
      return pair {**find-min**(_vals_), **find-max**(_vals_)}
    end
    

Because **find-max** and **find-min** both make _n-1_ calls to the max or min functions (when _vals_ has _n_ elements), the total number of comparisons made in **find-min-max** is ![2n-2](//upload.wikimedia.org/math/3/3/1/3317d29db4b05b3d1136a5f75203de3e.png).

However, some redundant comparisons are being made. These redundancies can be removed by "weaving" together the min and max functions:
    
    
    _// find-min-max -- returns the minimum and maximum element of the given array_
    function **find-min-max**(array _vals_[1.._n_]): pair
      let _min_ := ![\\infty](//upload.wikimedia.org/math/d/2/4/d245777abca64ece2d5d7ca0d19fddb6.png)
      let _max_ := ![-\\infty](//upload.wikimedia.org/math/b/e/a/beab416080922c84a90ba092f7734fe5.png)
      
      if _n_ is odd:
        _min_ := _max_ := _vals_[1]
        _vals_ := _vals_[2,..,_n_]          _// we can now assume n is even_
        _n_ := _n_ - 1
      fi
      
      for _i_:=1 to _n_ by 2:             _// consider pairs of values in vals_
        if _vals_[_i_] < _vals_[_i_ + _n_ by 2]:
          let _a_ := _vals_[_i_]
          let _b_ := _vals_[_i_ + _n_ by 2]
        else:
          let _a_ := _vals_[_i_ + _n_ by 2]
          let _b_ := _vals_[_i_]            _// invariant: a <= b_
        fi
        
        if _a_ < _min_: _min_ := _a_ fi
        if _b_ > _max_: _max_ := _b_ fi
      repeat
      
      return pair {_min_, _max_}
    end
    

Here, we only loop ![n/2](//upload.wikimedia.org/math/a/2/f/a2f070a31330443ceb0dcf352fe50035.png) times instead of _n_ times, but for each iteration we make three comparisons. Thus, the number of comparisons made is ![\(3/2\)n = 1.5n](//upload.wikimedia.org/math/9/9/7/9979b58480ac5dac2ec8d9cd4dd2a940.png), resulting in a ![3/4](//upload.wikimedia.org/math/4/0/7/40735ef69decd7cebd3e8be7cc186c8f.png) speed up over the original algorithm.

Only three comparisons need to be made instead of four because, by construction, it's always the case that ![a\\le b](//upload.wikimedia.org/math/d/7/3/d7356d20677cd7949b92ae77480fe9fe.png). (In the first part of the "if", we actually know more specifically that ![a < b](//upload.wikimedia.org/math/1/a/3/1a382af93ed4b8a29ebd8e859a0168d7.png), but under the else part, we can only conclude that ![a\\le b](//upload.wikimedia.org/math/d/7/3/d7356d20677cd7949b92ae77480fe9fe.png).) This property is utilized by noting that _a_ doesn't need to be compared with the current maximum, because _b_ is already greater than or equal to _a_, and similarly, _b_ doesn't need to be compared with the current minimum, because _a_ is already less than or equal to _b_.

In software engineering, there is a struggle between using libraries versus writing customized algorithms. In this case, the min and max functions weren't used in order to get a faster **find-min-max** routine. Such an operation would probably not be the bottleneck in a real-life program: however, if testing reveals the routine should be faster, such an approach should be taken. Typically, the solution that reuses libraries is better overall than writing customized solutions. Techniques such as open implementation and aspect-oriented programming may help manage this contention to get the best of both worlds, but regardless it's a useful distinction to recognize.

### find-median

Finally, we need to consider how to find the median value. One approach is to sort the array then extract the median from the position `_vals_[_n_/2]`:
    
    
    _// find-median -- returns the median element of vals_
    function **find-median**(array _vals_[1.._n_]): element
      assert (_n_ > 0)
      
      sort(_vals_)
      return _vals_[_n_ / 2]
    end
    

If our values are not numbers close enough in value (or otherwise cannot be sorted by a radix sort) the sort above is going to require ![O\(n\\log n\)](//upload.wikimedia.org/math/f/4/9/f49341ab621f12e8cb93d0146ea51d34.png) steps.

However, it is possible to extract the _n_th-ordered statistic in ![O\(n\)](//upload.wikimedia.org/math/7/b/a/7ba55e7c64a9405a0b39a1107e90ca94.png) time. The key is eliminating the sort: we don't actually require the entire array to be sorted in order to find the median, so there is some waste in sorting the entire array first. One technique we'll use to accomplish this is randomness.

Before presenting a non-sorting **find-median** function, we introduce a divide and conquer-style operation known as **partitioning**. What we want is a routine that finds a random element in the array and then partitions the array into three parts:

  1. elements that are less than or equal to the random element;
  2. elements that are equal to the random element; and
  3. elements that are greater than or equal to the random element.

These three sections are denoted by two integers: _j_ and _i_. The partitioning is performed "in place" in the array:
    
    
    _// partition -- break the array three partitions based on a randomly picked element_
    function **partition**(array _vals_): pair{_j_, _i_}
    

Note that when the random element picked is actually represented three or more times in the array it's possible for entries in all three partitions to have the same value as the random element. While this operation may not sound very useful, it has a powerful property that can be exploited: When the partition operation completes, the randomly picked element will be in the same position in the array as it would be if the array were fully sorted!

This property might not sound so powerful, but recall the optimization for the **find-min-max** function: we noticed that by picking elements from the array in pairs and comparing them to each other first we could reduce the total number of comparisons needed (because the current min and max values need to be compared with only one value each, and not two). A similar concept is used here.

While the code for **partition** is not magical, it has some tricky boundary cases:
    
    
    _// partition -- break the array into three ordered partitions from a random element_
    function **partition**(array _vals_): pair{_j_, _i_}
      let _m_ := 0
      let _n_ := _vals_.length - 2
      let _irand_ := random(_m_, _n_)   _// returns any value from m to n_
      let _x_ := _vals_[_irand_]
      swap( _irand_,_n_+ 1 ) // n+1 = vals.length-1 , which is the right most element, and acts as store for partition element and sentinel for m
      // values in _vals_[_n_..] are greater than _x_
      // values in _vals_[0.._m_] are less than _x_
      while (m <= n  ) // see explanation in quick sort why should be m <= n instead of m < n
                      // in the 2 element case, vals.length -2 = 0 = n = m, but if the 2-element case is out-of-order vs. in-order, there must be a different action.
                      // by implication, the different action occurs within this loop, so must process the m = n case before exiting.
         while _vals_[_m_] <= _x_
            _m_++
         endwhile
         while _x_ <  _vals_[_n_] && _n_ > 0   // stops if vals[n] belongs in left partition or hits start of array
            _n_--
         endwhile
         if ( m >= n) break;
         swap(_m_,_n_)                // exchange _vals_[_n_] and _vals_[_m_]
         _m_++   // don't rescan swapped elements
         _n_--
         
      endwhile
      // partition: [0.._m_-1]   []   [_n_+1..]   note that _m_=_n_+1
      // if you need non empty sub-arrays:
      swap(_m_,_vals_.length - 1)  // put the partition element in the between left and right partitions
      // partition: [0.._n_-1]   [_n_.._n_]   [_n_+1..]
    end
    

We can use **partition** as a subroutine for a general **find** operation:
    
    
    _// find -- moves elements in vals such that location k holds the value it would when sorted_
    function **find**(array _vals_, integer _k_)
      assert (0 <= _k_ < _vals_.length)        _// k it must be a valid index_
      if _vals_.length <= 1:
        return
      fi
      
      let pair (_j_, _i_) := **partition**(_vals_)
      if _k_ <= _i_:
        **find**(_a_[0,..,_i_], _k_)
      else-if _j_ <= _k_:
        **find**(_a_[_j_,..,_n_], _k_ - _j_)
      fi
      TODO: debug this!
    end
    

Which leads us to the punch-line:
    
    
     _// find-median -- returns the median element of vals_
    function **find-median**(array _vals_): element
      assert (_vals_.length > 0)
      
      let _median_index_ := _vals_.length / 2;
      **find**(_vals_, _median_index_)
      return _vals_[_median_index_]
    end
    

One consideration that might cross your mind is "is the random call really necessary?" For example, instead of picking a random pivot, we could always pick the middle element instead. Given that our algorithm works with all possible arrays, we could conclude that the running time on average for _all of the possible inputs_ is the same as our analysis that used the random function. The reasoning here is that under the set of all possible arrays, the middle element is going to be just as "random" as picking anything else. But there's a pitfall in this reasoning: Typically, the input to an algorithm in a program isn't random at all. For example, the input has a higher probability of being sorted than just by chance alone. Likewise, because it is real data from real programs, the data might have other patterns in it that could lead to suboptimal results.

To put this another way: for the randomized median finding algorithm, there is a very small probability it will run suboptimally, independent of what the input is; while for a deterministic algorithm that just picks the middle element, there is a greater chance it will run poorly on some of the most frequent input types it will receive. This leads us to the following guideline:

**Randomization Guideline:**  
If your algorithm depends upon randomness, be sure you introduce the randomness yourself instead of depending upon the data to be random.

Note that there are "derandomization" techniques that can take an average-case fast algorithm and turn it into a fully deterministic algorithm. Sometimes the overhead of derandomization is so much that it requires very large datasets to get any gains. Nevertheless, derandomization in itself has theoretical value.

The randomized **find** algorithm was invented by C. A. R. "Tony" Hoare. While Hoare is an important figure in computer science, he may be best known in general circles for his quicksort algorithm, which we discuss in the next section.

## Quicksort

The median-finding partitioning algorithm in the previous section is actually very close to the implementation of a full blown sorting algorithm. Building a Quicksort Algorithm is left as an exercise for the reader, and is recommended first, before reading the next section ( Quick sort is diabolical compared to Merge sort, which is a sort not improved by a randomization step ) .

A key part of quick sort is choosing the right median. But to get it up and running quickly, start with the assumption that the array is unsorted, and the rightmost element of each array is as likely to be the median as any other element, and that we are entirely optimistic that the rightmost doesn't happen to be the largest key , which would mean we would be removing one element only ( the partition element) at each step, and having no right array to sort, and a n-1 left array to sort.

This is where **randomization** is important for quick sort, i.e. _choosing the more optimal partition key_, which is pretty important for quick sort to work efficiently.

Compare the number of comparisions that are required for quick sort vs. insertion sort.

With insertion sort, the average number of comparisons for finding the lowest first element in an ascending sort of a randomized array is n /2 .

The second element's average number of comparisons is (n-1)/2;

the third element ( n- 2) / 2.

The total number of comparisons is [ n + (n - 1) + (n - 2) + (n - 3) .. + (n - [n-1]) ] divided by 2, which is [ n x n - (n-1)! ] /2 or about O(n squared) .

In Quicksort, the number of comparisons will halve at each partition step if the true median is chosen, since the left half partition doesn't need to be compared with the right half partition, but at each step , the number elements of all partitions created by the previously level of partitioning will still be n.

The number of levels of comparing n elements is the number of steps of dividing n by two , until n = 1. Or in reverse, 2 ^ m ~ n, so m = log2 n.

So the total number of comparisons is n (elements) x m (levels of scanning) or n x log2n ,

So the number of comparison is O(n x log 2(n) ) , which is smaller than insertion sort's O(n^2) or O( n x n ).

(Comparing O(n x log 2(n) ) with O( n x n ) , the common factor n can be eliminated , and the comparison is log2(n) vs n , which is exponentially different as n becomes larger. e.g. compare n = 2^16 , or 16 vs 32768, or 32 vs 4 gig ).

To implement the partitioning in-place on a part of the array determined by a previous recursive call, what is needed a scan from each end of the part , swapping whenever the value of the left scan's current location is greater than the partition value, and the value of the right scan's current location is less than the partition value. So the initial step is :-
    
    
     Assign the partition value to the right most element, swapping if necessary.
    

So the partitioning step is :-
    
    
     increment the left scan pointer while the current value is less than the partition value.
     decrement the right scan pointer while the current value is more than the partition value , 
     or the location is equal to or more than the left most location.
     exit if the pointers have crossed ( l >= r), 
     OTHERWISE
     perform a swap where the left and right pointers have stopped ,
     on values where the left pointer's value is greater than the partition,
     and the right pointer's value is less than the partition.
    
     Finally, after exiting the loop because the left and right pointers  have crossed,
     _swap the _rightmost_ partition value, _
     with the last location of the **left** forward scan pointer _,   _
     and hence ends up between the left and right partitions. 
    

Make sure at this point , that after the final swap, the cases of a 2 element in-order array, and a 2 element out-of-order array , are handled correctly, which should mean all cases are handled correctly. This is a good debugging step for getting quick-sort to work.

**For the in-order two-element case**, the left pointer stops on the partition or second element , as the partition value is found. The right pointer , scanning backwards, starts on the first element before the partition, and stops because it is in the leftmost position.

The pointers cross, and the loop exits before doing a loop swap. Outside the loop, the contents of the left pointer at the rightmost position and the partition , also at the right most position , are swapped, achieving no change to the in-order two-element case.

**For the out-of-order two-element case**, The left pointer scans and stops at the first element, because it is greater than the partition (left scan value stops to swap values greater than the partition value).

The right pointer starts and stops at the first element because it has reached the leftmost element.

The loop exits because left pointer and right pointer are equal at the first position, and the contents of the left pointer at the first position and the partition at the rightmost (other) position , are swapped , putting previously out-of-order elements , into order.

Another implementation issue, is to how to move the pointers during scanning. Moving them at the end of the outer loop seems logical.
    
    
    partition(a,l,r) {
      v = a[r];
      i = l;
      j = r -1;
     while ( i <= j ) {  // need to also scan when i = j as well as i < j , 
                               // in the 2 in-order case, 
                               // so that i is incremented to the  partition 
                               // and nothing happens in the final swap with the partition at r.
        while ( a[i] < v) ++i;
        while ( v <= a[j] && j > 0  ) --j;
        if ( i >= j) break;
        swap(a,i,j);
        ++i; --j;
     }
     swap(a, i, r);
     return i;
    

With the pre-increment/decrement unary operators, scanning can be done just before testing within the test condition of the while loops, but this means the pointers should be offset -1 and +1 respectively at the start : so the algorithm then looks like:-
    
    
    partition (a, l, r ) {
     v=a[r]; // v is partition value, at a[r]
     i=l-1;
     j=r;
     while(true) {
      while(  a[++i] < v ); 
      while( v <= a[--j]  && j > l );
      if (i >= j) break;
      swap ( a, i, j);
     }
     swap (a,i,r);
     return i;
    }
    

And the qsort algorithm is
    
    
    qsort( a, l, r)  {
      if (l >= r) return ;
      p = partition(a, l, r)
      qsort(a , l, p-1)
      qsort( a, p+1, r)
    

}

Finally, randomization of the partition element.
    
    
    random_partition (a,l,r) {
     p = random_int( r-l) + l;
     // median of a[l], a[p] , a[r]
     if (a[p] < a[l]) p =l;
     if ( a[r]< a[p]) p = r;
     swap(a, p, r);
    }
    

this can be called just before calling partition in qsort().

## Shuffling an Array
    
    
      **This keeps data in during shuffle**
      temporaryArray = { }
      **This records if an item has been shuffled**
      usedItemArray = { }
      **Number of item in array**
      itemNum = 0
      while ( itemNum != lengthOf( inputArray) ){
          usedItemArray[ itemNum ] = false **None of the items have been shuffled**
          itemNum = itemNum + 1
      }
      itemNum = 0 **we'll use this again**
      itemPosition = randdomNumber( 0 --- (lengthOf(inputArray) - 1 ))
      while( itemNum != lengthOf( inputArray ) ){
          while( usedItemArray[ itemPosition ] != false ){
              itemPosition = randdomNumber( 0 --- (lengthOf(inputArray) - 1 ))
          }
          temporaryArray[ itemPosition ] = inputArray[ itemNum ]
      }
      inputArray = temporaryArray
    

  


## Equal Multivariate Polynomials

[TODO: as of now, there is no known deterministic polynomial time solution, but there is a randomized polytime solution. The canonical example used to be IsPrime, but a deterministic, polytime solution has been found.]

## Hash tables

Hashing relies on a hashcode function to randomly distribute keys to available slots evenly. In java , this is done in a fairly straight forward method of adding a moderate sized prime number (31 * 17 ) to a integer key , and then modulus by the size of the hash table. For string keys, the initial hash number is obtained by adding the products of each character's ordinal value multiplied by 31.

The wikibook Data Structures/Hash Tables chapter covers the topic well.

## Skip Lists

[TODO: Talk about skips lists. The point is to show how randomization can sometimes make a structure easier to understand, compared to the complexity of balanced trees.]

Dictionary or Map , is a general concept where a value is inserted under some key, and retrieved by the key. For instance, in some languages , the dictionary concept is built-in (Python), in others , it is in core libraries ( C++ S.T.L. , and Java standard collections library ). The library providing languages usually lets the programmer choose between a hash algorithm, or a balanced binary tree implementation (red-black trees). Recently, skip lists have been offered, because they offer advantages of being implemented to be highly concurrent for multiple threaded applications.

Hashing is a technique that depends on the randomness of keys when passed through a hash function, to find a hash value that corresponds to an index into a linear table. Hashing works as fast as the hash function, but works well only if the inserted keys spread out evenly in the array, as any keys that hash to the same index , have to be deal with as a hash collision problem e.g. by keeping a linked list for collisions for each slot in the table, and iterating through the list to compare the full key of each key-value pair vs the search key.

The disadvantage of hashing is that in-order traversal is not possible with this data structure.

Binary trees can be used to represent dictionaries, and in-order traversal of binary trees is possible by visiting of nodes ( visit left child, visit current node, visit right child, recursively ). Binary trees can suffer from poor search when they are "unbalanced" e.g. the keys of key-value pairs that are inserted were inserted in ascending or descending order, so they effectively look like _linked lists_ with no left child, and all right children. _self-balancing_ binary trees can be done probabilistically (using randomness) or deterministically ( using child link coloring as red or black ) , through local 3-node tree **rotation** operations. A rotation is simply swapping a parent with a child node, but preserving order e.g. for a left child rotation, the left child's right child becomes the parent's left child, and the parent becomes the left child's right child.

**Splay trees** are a random application of rotations during a search , so that a lopsided tree structure is randomized into a balanced one.

**Red-black trees** can be understood more easily if corresponding **2-3-4 trees** are examined. A 2-3-4 tree is a tree where nodes can have 2 children, 3 children, or 4 children, with 3 children nodes having 2 keys between the 3 children, and 4 children-nodes having 3 keys between the 4 children. 4-nodes are actively split into 3 single key 2 -nodes, and the middle 2-node passed up to be merged with the parent node , which , if a one-key 2-node, becomes a two key 3-node; or if a two key 3-node, becomes a 4-node, which will be later split (on the way up). The act of splitting a three key 4-node is actually a re-balancing operation, that prevents a string of 3 nodes of grandparent, parent , child occurring , without a balancing rotation happening. 2-3-4 trees are a limited example of **B-trees**, which usually have enough nodes as to fit a physical disk block, to facilitate caching of very large indexes that can't fit in physical RAM ( which is much less common nowadays).

A **red-black tree** is a binary tree representation of a 2-3-4 tree, where 3-nodes are modeled by a parent with one red child, and 4 -nodes modeled by a parent with two red children. Splitting of a 4-node is represented by the parent with 2 red children, **flipping** the red children to black, and itself into red. There is never a case where the parent is already red, because there also occurs balancing operations where if there is a grandparent with a red parent with a red child , the grandparent is rotated to be a child of the parent, and parent is made black and the grandparent is made red; this unifies with the previous **flipping** scenario, of a 4-node represented by 2 red children. Actually, it may be this standardization of 4-nodes with mandatory rotation of skewed or zigzag 4-nodes that results in re-balancing of the binary tree.

A newer optimization is to left rotate any single right red child to a single left red child, so that only right rotation of left-skewed inline 4-nodes (3 red nodes inline ) would ever occur, simplifying the re-balancing code.

**Skip lists** are modeled after single linked lists, except nodes are multilevel. Tall nodes are rarer, but the insert operation ensures nodes are connected at each level.

Implementation of skip lists requires creating randomly high multilevel nodes, and then inserting them.

Nodes are created using iteration of a random function where high level node occurs later in an iteration, and are rarer, because the iteration has survived a number of random thresholds (e.g. 0.5, if the random is between 0 and 1).

Insertion requires a temporary previous node array with the height of the generated inserting node. It is used to store the last pointer for a given level , which has a key less than the insertion key.

The scanning begins at the head of the skip list, at highest level of the head node, and proceeds across until a node is found with a key higher than the insertion key, and the previous pointer stored in the temporary previous node array. Then the next lower level is scanned from that node , and so on, walking zig-zag down, until the lowest level is reached.

Then a list insertion is done at each level of the temporary previous node array, so that the previous node's next node at each level is made the next node for that level for the inserting node, and the inserting node is made the previous node's next node.

Search involves iterating from the highest level of the head node to the lowest level, and scanning along the next pointer for each level until a node greater than the search key is found, moving down to the next level , and proceeding with the scan, until the higher keyed node at the lowest level has been found, or the search key found.

The creation of less frequent-when-taller , randomized height nodes, and the process of linking in all nodes at every level, is what gives skip lists their advantageous overall structure.

What follows is a implementation of skip lists in python.
    
    
    #a python implementation of SkipLists, using references as pointers
    # copyright 2013 , as much gnu as compatible with wikibooks
    # as taken from reading pugh's paper , and sedgewick
    import random 
    min = 8
    thresh = 6
    SK_MAXV = 16
    class SkNode:
      def __init__(self, x, v):
            self.ht = SK_MAXV
            for i in xrange(1,SK_MAXV):
              if random.randint(0,10) < 5:
                self.ht = i
                break
            self.next = [None] * self.ht
            self.v = v 
            self.x = x
     
      def increase_ht(self, h):
            self.next.extend( [None] * (h - self.ht))
            self.ht = h
     
    class SkipList:
     
      def __init__(self ):
        self.head = None 
        self.level = 0
     
      def insert(self, x, v):
        n = SkNode(x, v)     
        if self.head is None:
          self.head = n
        else:
          if n.ht > self.head.ht:
            self.head.increase_ht(n.ht)   
     
          if x < self.head.x:  
            # the key is less than the head's key, replace the head
            for j in xrange(0,n.ht):
                    n.next[i] = self.head
            self.head = n
          else:
            prev = self.head
     
            #last holds the previous node for each level
            last = [None]* self.head.ht 
     
            # starts at ht-1, scans to 0, stepping down ; this is "skipping" at higher j
            # when j = 0, the lowest level,  there is no skipping , and every next node is traversed.
            # tall nodes are less frequently inserted, and links between taller nodes at higher j skip over more
            # more frequent shorter nodes.
            for j in xrange( self.head.ht-1, -1, -1):
     
              # while there is a next node with smaller x than inserting x, go to next node 
              while   not (prev.next[j] is None) and prev.next[j].x < x:
                prev = prev.next[j]
     
                #print "prev", prev
     
              last[j] = prev #record the previous node for this level which is points to node with higher x
     
            #weave in the node
            #only change pointers for the levels of the inserted node
            for j in xrange ( 0, n.ht):  
              tmp = last[j].next[j]
              last[j].next[j] = n
              n.next[j] =tmp 
     
     
      def find(self, x):
        c = self.find_node(x)
        if c is None or c.x <> x: 
          return None
     
        return c.x
     
     
      def find_node_and_prev(self, x):
        if self.head is None:
          return None
        c = self.head
        prev = [ y for y in self.head ]
        for i in xrange(self.head.ht - 1, -1, -1):
          while c.x < x and not c.next[i] is None and c.next[i].x <= x: # must be <= otherwise won't make c.x = x
            prev[i] = c
            c = c.next[i]
          #print c.x, x
          if c.x >= x:
            return (c, prev)
        return (None, None)
     
      def find_node(self, x):
        return self.find_node_and_prev(x)[0]   
     
      def delete(self, x):
        c, prev = self.find_node_and_prev(x)
     
        if c is None:
          return False
     
        for i in xrange(0, len(c.next) ):
          prev[i] = c.next[i]
        return True
     
      # efficient subranges         
      def find_range_nodes( self, x1, x2):
        c1 = self.find_node(x1)
        c2 = self.find_node(x2)
        l = []
        while c1 <> c2:
          l.append(c1)
          c1= c1.next[0]
        return l 
     
      def find_range_keys( self, x1, x2):
        return [ n.x for n in self.find_range_nodes(x1,x2) ]
     
      def find_range_values( self, x1, x2):
        return [ n.v for n in self.find_range_nodes(x1,x2) ]
     
    if __name__ == "__main__":
      sk = SkipList()
      for i in xrange(0,100000):
        #x = random.randint(0,1000000)
     
        sk.insert(i, i * 10 )
     
      for i in xrange(0,100000):
        print i, sk.find(i)
     
      print sk.find_range_keys(0,100001)     
     
      print sk.find_range_values(75500, 75528)
    

  


### Role of Randomness

The idea of making higher nodes geometrically randomly less common, means there are less keys to compare with the higher the level of comparison, and since these are randomly selected, this should get rid of problems of degenerate input that makes it necessary to do tree balancing in tree algorithms. Since the higher level list have more widely separated elements, but the search algorithm moves down a level after each search terminates at a level, the higher levels help "skip" over the need to search earlier elements on lower lists. Because there are multiple levels of skipping, it becomes less likely that a meagre skip at a higher level won't be compensated by better skips at lower levels, and Pugh claims O(logN) performance overall.

Conceptually , is it easier to understand than balancing trees and hence easier to implement ? The development of ideas from binary trees, balanced binary trees, 2-3 trees, red-black trees, and B-trees make a stronger conceptual network but is progressive in development, so arguably, once red-black trees are understood, they have more conceptual context to aid memory , or refresh of memory.

### concurrent access application

Apart from using randomization to enhance a basic memory structure of linked lists, skip lists can also be extended as a global data structure used in a multiprocessor application. See supplementary topic at the end of the chapter.

### Idea for an exercise

Replace the Linux completely fair scheduler red-black tree implementation with a skip list , and see how your brand of Linux runs after recompiling.

## Treaps

A treap is a two keyed binary tree, that uses a second randomly generated key and the previously discussed tree operation of parent-child rotation to randomly rotate the tree so that overall, a balanced tree is produced. Recall that binary trees work by having all nodes in the left subtree small than a given node, and all nodes in a right subtree greater. Also recall that node rotation does not break this order ( some people call it an invariant), but changes the relationship of parent and child, so that if the parent was smaller than a right child, then the parent becomes the left child of the formerly right child. The idea of a tree-heap or treap, is that a binary heap relationship is maintained between parents and child, and that is a parent node has higher priority than its children, which is not the same as the left , right order of keys in a binary tree, and hence a recently inserted leaf node in a binary tree which happens to have a high random priority, can be rotated so it is relatively higher in the tree, having no parent with a lower priority. See the preamble to skip lists about red-black trees on the details of [left rotation](/wiki/Algorithms/Left_rotation).

A treap is an alternative to both red-black trees, and skip lists, as a self-balancing sorted storage structure.

## Derandomization

[TODO: Deterministic algorithms for Quicksort exist that perform as well as quicksort in the average case and are guaranteed to perform at least that well in all cases. Best of all, no randomization is needed. Also in the discussion should be some perspective on using randomization: some randomized algorithms give you better confidence probabilities than the actual hardware itself! (e.g. sunspots can randomly flip bits in hardware, causing failure, which is a risk we take quite often)]

[Main idea: Look at all blocks of 5 elements, and pick the median (O(1) to pick), put all medians into an array (O(n)), recursively pick the medians of that array, repeat until you have < 5 elements in the array. This recursive median constructing of every five elements takes time T(n)=T(n/5) + O(n), which by the master theorem is O(n). Thus, in O(n) we can find the right pivot. Need to show that this pivot is sufficiently good so that we're still O(n log n) no matter what the input is. This version of quicksort doesn't need rand, and it never performs poorly. Still need to show that element picked out is sufficiently good for a pivot.]

## Exercises

  1. Write a **find-min** function and run it on several different inputs to demonstrate its correctness.

## Supplementary Topic: skip lists and multiprocessor algorithms

Multiprocessor hardware provides CAS ( compare-and-set) or CMPEXCHG( compare-and-exchange)(intel manual 253666.pdf, p 3-188) atomic operations, where an expected value is loaded into the accumulator register, which is compared to a target memory location's contents, and if the same, a source memory location's contents is loaded into the target memories contents, and the zero flag set, otherwise, if different, the target memory's contents is returned in the accumulator, and the zero flag is unset, signifying , for instance, a lock contention. In the intel architecture, a LOCK instruction is issued before CMPEXCHG , which either locks the cache from concurrent access if the memory location is being cached, or locks a shared memory location if not in the cache , for the next instruction.

The CMPEXCHG can be used to implement locking, where spinlocks , e.g. retrying until the zero flag is set, are simplest in design.

Lockless design increases efficiency by avoiding spinning waiting for a lock .

The java standard library has an implementation of non-blocking concurrent skiplists, based on a paper titled "a pragmatic implementation of non-blocking single-linked lists".

The skip list implementation is an extension of the lock-free single-linked list , of which a description follows :-

The **insert** operation is : X -> Y insert N , N -> Y, X -> N ; expected result is X -> N -> Y .

A race condition is if M is inserting between X and Y and M completes first , then N completes, so the situation is X -> N -> Y <\- M

M is not in the list. The CAS operation avoids this, because a copy of -> Y is checked before updating X -> , against the current value of X -> .

If N gets to update X -> first, then when M tries to update X -> , its copy of X -> Y , which it got before doing M -> Y , does not match X -> N , so CAS returns non-zero flag set. The process that tried to insert M then can retry the insertion after X, but now the CAS checks ->N is X's next pointer, so after retry, X->M->N->Y , and neither insertions are lost.

If M updates X-> first, N 's copy of X->Y does not match X -> M , so the CAS will fail here too, and the above retry of the process inserting N, would have the serialized result of X ->N -> M -> Y .

The **delete** operation depends on a separate 'logical' deletion step, before 'physical' deletion.

'Logical' deletion involves a CAS change of the next pointer into a 'marked' pointer. The java implementation substitutes with an atomic insertion of a proxy marker node to the next node.

This prevents future insertions from inserting after a node which has a next pointer 'marked' , making the latter node 'logically' deleted.

The **insert** operation relies on another function , _search_ , returning _2_ **unmarked** , at the time of the invocation, node pointers : the first pointing to a node , whose next pointer is equal to the second.

The first node is the node before the insertion point.

The _insert_ CAS operation checks that the current next pointer of the first node, corresponds to the unmarked reference of the second, so will fail 'logically' if the first node's _next_ pointer has become marked _after_ the call to the _search_ function above, because the first node has been concurrently logically deleted.

_This meets the aim to prevent a insertion occurring concurrently after a node has been deleted._

If the insert operation fails the CAS of the previous node's next pointer, the search for the insertion point starts from the **start of the entire list** again, since a new unmarked previous node needs to be found, and there are no previous node pointers as the list nodes are singly-linked.

![CAS insert.png](//upload.wikimedia.org/wikipedia/commons/thumb/1/18/CAS_insert.png/300px-CAS_insert.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The **delete** operation outlined above, also relies on the _search_ operation returning two _unmarked_ nodes, and the two CAS operations in delete, one for logical deletion or marking of the second pointer's next pointer, and the other for physical deletion by making the first node's next pointer point to the second node's unmarked next pointer.

The first CAS of delete happens only after a check that the copy of the original second nodes' next pointer is unmarked, and ensures that only one concurrent delete succeeds which reads the second node's current next pointer as being unmarked as well.

The second CAS checks that the previous node hasn't been logically deleted because its next pointer is not the same as the unmarked pointer to the current second node returned by the search function, so only an active previous node's next pointer is 'physically' updated to a copy of the original unmarked next pointer of the node being deleted ( whose next pointer is already marked by the first CAS).

If the second CAS fails, then the previous node is logically deleted and its next pointer is marked, and so is the current node's next pointer. A call to _search_ function again, tidies things up, because in endeavouring to find the key of the current node and return adjacent unmarked previous and current pointers, and while doing so, it truncates strings of logically deleted nodes .

#### Lock-free programming issues

Starvation could be possible , as failed inserts have to restart from the front of the list. Wait-freedom is a concept where the algorithm has all threads safe from starvation.

The ABA problem exists, where a garbage collector recycles the pointer A , but the address is loaded differently, and the pointer is re-added at a point where a check is done for A by another thread that read A and is doing a CAS to check A has not changed ; the address is the same and is unmarked, but the contents of A has changed.

  


# Backtracking

**Backtracking** is a general algorithmic technique that considers searching every possible combination in order to solve an optimization problem. Backtracking is also known as **depth-first search** or **branch and bound**. By inserting more knowledge of the problem, the search tree can be pruned to avoid considering cases that don't look promising. While backtracking is useful for hard problems to which we do not know more efficient solutions, it is a poor solution for the everyday problems that other techniques are much better at solving.

However, dynamic programming and greedy algorithms can be thought of as optimizations to backtracking, so the general technique behind backtracking is useful for understanding these more advanced concepts. Learning and understanding backtracking techniques first provides a good stepping stone to these more advanced techniques because you won't have to learn several new concepts all at once.

**Backtracking Methodology**  


  1. View picking a solution as a sequence of **choices**
  2. For each choice, consider every **option** recursively
  3. Return the best solution found

This methodology is generic enough that it can be applied to most problems. However, even when taking care to improve a backtracking algorithm, it will probably still take exponential time rather than polynomial time. Additionally, exact time analysis of backtracking algorithms can be extremely difficult: instead, simpler upperbounds that may not be tight are given.

## Longest Common Subsequence (exhaustive version)

Note that the solution to the longest common subsequence (LCS) problem discussed in this section is not efficient. However, it is useful for understanding the dynamic programming version of the algorithm that is covered later.

The LCS problem is similar to what the Unix "diff" program does. The diff command in Unix takes two text files, _A_ and _B_, as input and outputs the differences line-by-line from _A_ and _B_. For example, diff can show you that lines missing from _A_ have been added to _B_, and lines present in _A_ have been removed from _B_. The goal is to get a list of additions and removals that could be used to transform _A_ to _B_. An overly conservative solution to the problem would say that all lines from _A_ were removed, and that all lines from _B_ were added. While this would solve the problem in a crude sense, we are concerned with the minimal number of additions and removals to achieve a correct transformation. Consider how you may implement a solution to this problem yourself.

The LCS problem, instead of dealing with lines in text files, is concerned with finding common items between two different arrays. For example,
    
    
    let _a_ := array {"The", "great", "square", "has", "no", "corners"}
    let _b_ := array {"The", "great", "image", "has", "no", "form"}
    

We want to find the longest subsequence possible of items that are found in both _a_ and _b_ in the same order. The LCS of _a_ and _b_ is

    "The", "great", "has", "no"

Now consider two more sequences:
    
    
    let _c_ := array {1, 2, 4, 8, 16, 32}
    let _d_ := array {1, 2, 3, 32, 8}
    

Here, there are two longest common subsequences of _c_ and _d_:

    1, 2, 32; and
    1, 2, 8

Note that

    1, 2, 32, 8

is _not_ a common subsequence, because it is only a valid subsequence of _d_ and not _c_ (because _c_ has 8 before the 32). Thus, we can conclude that for some cases, solutions to the LCS problem are not unique. If we had more information about the sequences available we might prefer one subsequence to another: for example, if the sequences were lines of text in computer programs, we might choose the subsequences that would keep function definitions or paired comment delimiters intact (instead of choosing delimiters that were not paired in the syntax).

On the top level, our problem is to implement the following function
    
    
    // _lcs -- returns the longest common subsequence of a and b_
    function **lcs**(array _a_, array _b_): array
    

which takes in two arrays as input and outputs the subsequence array.

How do you solve this problem? You could start by noticing that if the two sequences start with the same word, then the longest common subsequence always contains that word. You can automatically put that word on your list, and you would have just reduced the problem to finding the longest common subset of the rest of the two lists. Thus, the problem was made smaller, which is good because it shows progress was made.

But if the two lists do not begin with the same word, then one, or both, of the first element in _a_ or the first element in _b_ do not belong in the longest common subsequence. But yet, one of them might be. How do you determine which one, if any, to add?

The solution can be thought in terms of the back tracking methodology: Try it both ways and see! Either way, the two sub-problems are manipulating smaller lists, so you know that the recursion will eventually terminate. Whichever trial results in the longer common subsequence is the winner.

Instead of "throwing it away" by deleting the item from the array we use array slices. For example, the slice

    _a_[1,..,5]

represents the elements

    {_a_[1], _a_[2], _a_[3], _a_[4], _a_[5]}

of the array as an array itself. If your language doesn't support slices you'll have to pass beginning and/or ending indices along with the full array. Here, the slices are only of the form

    _a_[1,..]

which, when using 0 as the index to the first element in the array, results in an array slice that doesn't have the 0th element. (Thus, a non-sliced version of this algorithm would only need to pass the beginning valid index around instead, and that value would have to be subtracted from the complete array's length to get the pseudo-slice's length.)
    
    
    // _lcs -- returns the longest common subsequence of a and b_
    function **lcs**(array _a_, array _b_): array
      if _a_.length == 0 OR _b_.length == 0:
        _// if we're at the end of either list, then the lcs is empty_
        
        return new array {}
      else-if _a_[0] == _b_[0]:
        _// if the start element is the same in both, then it is on the lcs,_
        _// so we just recurse on the remainder of both lists._
        
        return append(new array {_a_[0]}, **lcs**(_a_[1,..], _b_[1,..]))
      else
        _// we don't know which list we should discard from. Try both ways,_
        _// pick whichever is better._
        
        let _discard_a_ := **lcs**(_a_[1,..], _b_)
        let _discard_b_ := **lcs**(_a_, _b_[1,..])
        
        if _discard_a_.length > _discard_b_.length:
          let _result_ := _discard_a_
        else
          let _result_ := _discard_b_
        fi
        return _result_
      fi
    end
    

## Shortest Path Problem (exhaustive version)

To be improved as Dijkstra's algorithm in a later section.

## Largest Independent Set

## Bounding Searches

If you've already found something "better" and you're on a branch that will never be as good as the one you already saw, you can terminate that branch early. (Example to use: sum of numbers beginning with 1 2, and then each number following is a sum of any of the numbers plus the last number. Show performance improvements.)

## Constrained 3-Coloring

This problem doesn't have immediate self-similarity, so the problem first needs to be generalized. Methodology: If there's no self-similarity, try to generalize the problem until it has it.

## Traveling Salesperson Problem

Here, backtracking is one of the best solutions known.

  


# Dynamic Programming

**Dynamic programming** can be thought of as an optimization technique for particular classes of backtracking algorithms where subproblems are repeatedly solved. Note that the term _dynamic_ in dynamic programming should not be confused with dynamic programming languages, like Scheme or Lisp. Nor should the term _programming_ be confused with the act of writing computer programs. In the context of algorithms, dynamic programming always refers to the technique of filling in a table with values computed from other table values. (It's dynamic because the values in the table are filled in by the algorithm based on other values of the table, and it's programming in the sense of setting things in a table, like how television programming is concerned with when to broadcast what shows.)

## Fibonacci Numbers

Before presenting the dynamic programming technique, it will be useful to first show a related technique, called **memoization**, on a toy example: The Fibonacci numbers. What we want is a routine to compute the _n_th Fibonacci number:
    
    
    _// fib -- compute Fibonacci(n)_
    function **fib**(integer _n_): integer
    

By definition, the _n_th Fibonacci number, denoted ![\\textrm{F}_n](//upload.wikimedia.org/math/2/b/6/2b62a1786c55d0f4bd1392e5698ddeae.png) is

    ![\\textrm{F}_0 = 0](//upload.wikimedia.org/math/3/2/0/320c31a0e1c5992e108fd6fafbc7e116.png)
    ![\\textrm{F}_1 = 1](//upload.wikimedia.org/math/3/7/e/37e516e560cefe66e15a3d7cc4ef0c7c.png)
    ![\\textrm{F}_n = \\textrm{F}_{n-1} + \\textrm{F}_{n-2}](//upload.wikimedia.org/math/c/1/9/c199668f5ac39af59ec892527a3a8cda.png)

How would one create a good algorithm for finding the nth Fibonacci-number? Let's begin with the naive algorithm, which codes the mathematical definition:
    
    
    _// fib -- compute Fibonacci(n)_
    function **fib**(integer _n_): integer
      assert (n >= 0)
      if _n_ == 0: return 0 fi
      if _n_ == 1: return 1 fi
      
      return **fib**(_n_ - 1) + **fib**(_n_ - 2)
    end
    

This code sample is also available in [Ada](/wiki/Ada_Programming/Algorithms#Simple_Implementation).

Note that this is a toy example because there is already a mathematically closed form for ![\\textrm{F}_n](//upload.wikimedia.org/math/2/b/6/2b62a1786c55d0f4bd1392e5698ddeae.png):

    ![F\(n\) = {\\phi^n - \(1 -\\phi\)^{n} \\over \\sqrt{5}}](//upload.wikimedia.org/math/b/d/e/bde083789da8779ef179982bad6f6745.png)

where:

    ![\\phi = {1 + \\sqrt{5} \\over 2}](//upload.wikimedia.org/math/d/2/6/d261ff480362f4ee9f0dcb9299db11b3.png)

This latter equation is known as the [Golden Ratio](//en.wikipedia.org/wiki/golden_ratio). Thus, a program could efficiently calculate ![\\textrm{F}_n](//upload.wikimedia.org/math/2/b/6/2b62a1786c55d0f4bd1392e5698ddeae.png) for even very large _n_. However, it's instructive to understand what's so inefficient about the current algorithm.

To analyze the running time of `fib` we should look at a call tree for something even as small as the sixth Fibonacci number:

![Algorithms-F6CallTree.png](//upload.wikimedia.org/wikibooks/en/3/37/Algorithms-F6CallTree.png)

Every leaf of the call tree has the value 0 or 1, and the sum of these values is the final result. So, for any _n,_ the number of leaves in the call tree is actually ![\\textrm{F}_n](//upload.wikimedia.org/math/2/b/6/2b62a1786c55d0f4bd1392e5698ddeae.png) itself! The closed form thus tells us that the number of leaves in `**fib**(_n_)` is approximately equal to

    ![\\left\(\\frac{1 + \\sqrt{5}}{2}\\right\)^n\\approx 1.618^n = 2^{\\lg \(1.618^n\)} = 2^{n \\lg \(1.618\)} \\approx 2^{0.69 n}.](//upload.wikimedia.org/math/2/6/9/26957ebee60168dd01c3fdc083befeec.png)

(Note the algebraic manipulation used above to make the base of the exponent the number 2.) This means that there are far too many leaves, particularly considering the repeated patterns found in the call tree above.

One optimization we can make is to save a result in a table once it's already been computed, so that the same result needs to be computed only once. The optimization process is called memoization and conforms to the following methodology:

**Memoization Methodology**  


  1. Start with a backtracking algorithm
  2. Look up the problem in a table; if there's a valid entry for it, return that value
  3. Otherwise, compute the problem recursively, and then store the result in the table before returning the value

Consider the solution presented in the backtracking chapter for the Longest Common Subsequence problem. In the execution of that algorithm, many common subproblems were computed repeatedly. As an optimization, we can compute these subproblems once and then store the result to read back later. A recursive memoization algorithm can be turned "bottom-up" into an iterative algorithm that fills in a table of solutions to subproblems. Some of the subproblems solved might not be needed by the end result (and that is where dynamic programming differs from memoization), but dynamic programming can be very efficient because the iterative version can better use the cache and have less call overhead. Asymptotically, dynamic programming and memoization have the same complexity.

So how would a fibonacci program using memoization work? Consider the following program (_f_[_n_] contains the _n_th Fibonacci-number if has been calculated, -1 otherwise):
    
    
    function **fib**(integer _n_): integer
      if _n_ == 0 **or** n == 1:
        return _n_
      else-if _f_[_n_] != -1:
        return _f_[_n_]
      else
        _f_[_n_] = **fib**(_n_ - 1) + **fib**(_n_ - 2)
        return _f_[_n_]
      fi
    end
    

This code sample is also available in [Ada](/wiki/Ada_Programming/Algorithms#Cached_Implementation).

The code should be pretty obvious. If the value of fib(n) already has been calculated it's stored in f[n] and then returned instead of calculating it again. That means all the copies of the sub-call trees are removed from the calculation.

![Algorithms-F6CallTreeMemoized.PNG](//upload.wikimedia.org/wikibooks/en/f/fb/Algorithms-F6CallTreeMemoized.PNG)

The values in the blue boxes are values that already have been calculated and the calls can thus be skipped. It is thus a lot faster than the straight-forward recursive algorithm. Since every value less than n is calculated once, and only once, the first time you execute it, the asymptotic running time is ![O \(n\)](//upload.wikimedia.org/math/7/b/a/7ba55e7c64a9405a0b39a1107e90ca94.png). Any other calls to it will take ![O \(1\)](//upload.wikimedia.org/math/5/e/0/5e079a28737d5dd019a3b8f6133ee55e.png) since the values have been precalculated (assuming each subsequent call's argument is less than n).

The algorithm does consume a lot of memory. When we calculate fib(_n_), the values fib(0) to fib(n) are stored in main memory. Can this be improved? Yes it can, although the ![O\(1\)](//upload.wikimedia.org/math/5/e/0/5e079a28737d5dd019a3b8f6133ee55e.png) running time of subsequent calls are obviously lost since the values aren't stored. Since the value of fib(_n_) only depends on fib(_n-1_) and fib(_n-2_) we can discard the other values by going bottom-up. If we want to calculate fib(_n_), we first calculate fib(2) = fib(0) + fib(1). Then we can calculate fib(3) by adding fib(1) and fib(2). After that, fib(0) and fib(1) can be discarded, since we don't need them to calculate any more values. From fib(2) and fib(3) we calculate fib(4) and discard fib(2), then we calculate fib(5) and discard fib(3), etc. etc. The code goes something like this:
    
    
    function **fib**(integer _n_): integer
      if _n_ == 0 **or** n == 1:
        return _n_
      fi
    
      let _u_ := 0
      let _v_ := 1
    
      for _i_ := 2 to _n_:
        let _t_ := _u_ + _v_
        _u_ := _v_
        _v_ := _t_
      repeat
      
      return _v_
    end
    

This code sample is also available in [Ada](/wiki/Ada_Programming/Algorithms#Memory_Optimized_Implementation).

We can modify the code to store the values in an array for subsequent calls, but the point is that we don't _have_ to. This method is typical for dynamic programming. First we identify what subproblems need to be solved in order to solve the entire problem, and then we calculate the values bottom-up using an iterative process.

## Longest Common Subsequence (DP version)

This will remind us of the backtracking version and then improve it via memoization. Finally, the recursive algorithm will be made iterative and be full-fledged DP. [TODO: write this section]

## Matrix Chain Multiplication

Suppose that you need to multiply a series of ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) matrices ![M_1,\\ldots, M_n](//upload.wikimedia.org/math/0/d/e/0dec4587d96aba0617cb96a667606ff2.png) together to form a product matrix ![P](//upload.wikimedia.org/math/4/4/c/44c29edb103a2872f519ad0c9a0fdaaa.png):

    ![P = M_1\\cdot M_2 \\cdots M_{n-1}\\cdot M_n](//upload.wikimedia.org/math/3/c/2/3c2bce3fd3622d42cb053a05e399bce2.png)

This will require ![n-1](//upload.wikimedia.org/math/a/4/3/a438673491daae8148eae77373b6a467.png) multiplications, but what is the fastest way we can form this product? Matrix multiplication is associative, that is,

    ![\(A\\cdot B\)\\cdot C = A\\cdot \(B\\cdot C\)](//upload.wikimedia.org/math/a/4/a/a4a6fb9c1d3cf53e2b25dd7d7a382c82.png)

for any ![A, B, C](//upload.wikimedia.org/math/c/e/0/ce04be1226e56f48da55b6c130d45b94.png), and so we have some choice in what multiplication we perform first. (Note that matrix multiplication is _not_ commutative, that is, it does not hold in general that ![A\\cdot B = B\\cdot A](//upload.wikimedia.org/math/4/d/2/4d25559f97a5baea78134b786ea9553e.png).)

Because you can only multiply two matrices at a time the product ![M_1\\cdot M_2\\cdot M_3\\cdot M_4](//upload.wikimedia.org/math/8/a/7/8a78bcbc84c14eb7a68c6af8f599ba27.png) can be paranthesized in these ways:

    ![\(\(M_1 M_2\) M_3\) M_4](//upload.wikimedia.org/math/9/a/d/9ad0290f84f10ca4694845a3d803a199.png)
    ![\(M_1 \(M_2 M_3\)\) M_4](//upload.wikimedia.org/math/0/b/d/0bdf6255ea86c36017ec8762076903ba.png)
    ![M_1 \(\(M_2 M_3\) M_4\)](//upload.wikimedia.org/math/1/b/b/1bb2c25f38b41a515f26b008ea3308a5.png)
    ![\(M_1 M_2\) \(M_3 M_4\)](//upload.wikimedia.org/math/7/a/4/7a4215b90f6830a115c4cf3699521fbb.png)
    ![M_1 \(M_2 \(M_3 M_4\)\)](//upload.wikimedia.org/math/b/3/d/b3ddfa576b919c1eca80237589a1dfa0.png)

Two matrices ![M_1](//upload.wikimedia.org/math/f/2/d/f2da4ca1b046da32d73b4ecc49d58680.png) and ![M_2](//upload.wikimedia.org/math/3/4/a/34a392a9e27dd596c3ed3292b990712f.png) can be multiplied if the number of columns in ![M_1](//upload.wikimedia.org/math/f/2/d/f2da4ca1b046da32d73b4ecc49d58680.png) equals the number of rows in ![M_2](//upload.wikimedia.org/math/3/4/a/34a392a9e27dd596c3ed3292b990712f.png). The number of rows in their product will equal the number rows in ![M_1](//upload.wikimedia.org/math/f/2/d/f2da4ca1b046da32d73b4ecc49d58680.png) and the number of columns will equal the number of columns in ![M_2](//upload.wikimedia.org/math/3/4/a/34a392a9e27dd596c3ed3292b990712f.png). That is, if the dimensions of ![M_1](//upload.wikimedia.org/math/f/2/d/f2da4ca1b046da32d73b4ecc49d58680.png) is ![a \\times b](//upload.wikimedia.org/math/2/d/1/2d1dc88200d501549f9d6edae3d6c195.png) and ![M_2](//upload.wikimedia.org/math/3/4/a/34a392a9e27dd596c3ed3292b990712f.png) has dimensions ![b \\times c](//upload.wikimedia.org/math/6/5/7/657389c8d4e6654c5eebad2f5bf82752.png) their product will have dimensions ![a \\times c](//upload.wikimedia.org/math/5/c/7/5c7ec5b32c36eacca278668ecc18cb88.png).

To multiply two matrices with each other we use a function called matrix-multiply that takes two matrices and returns their product. We will leave implementation of this function alone for the moment as it is not the focus of this chapter (how to multiply two matrices in the fastest way has been under intensive study for several years [TODO: propose this topic for the _Advanced_ book]). The time this function takes to multiply two matrices of size ![a \\times b](//upload.wikimedia.org/math/2/d/1/2d1dc88200d501549f9d6edae3d6c195.png) and ![b \\times c](//upload.wikimedia.org/math/6/5/7/657389c8d4e6654c5eebad2f5bf82752.png) is proportional to the number of scalar multiplications, which is proportional to ![a b c](//upload.wikimedia.org/math/9/0/0/900150983cd24fb0d6963f7d28e17f72.png). Thus, paranthezation matters: Say that we have three matrices ![M_1](//upload.wikimedia.org/math/f/2/d/f2da4ca1b046da32d73b4ecc49d58680.png), ![M_2](//upload.wikimedia.org/math/3/4/a/34a392a9e27dd596c3ed3292b990712f.png) and ![M_3](//upload.wikimedia.org/math/e/4/7/e47fdbf0968587d24cc2817c16b2ba15.png). ![M_1](//upload.wikimedia.org/math/f/2/d/f2da4ca1b046da32d73b4ecc49d58680.png) has dimensions ![5 \\times 100](//upload.wikimedia.org/math/f/f/1/ff138afefd80e558fd6d0650c5ed584b.png), ![M_2](//upload.wikimedia.org/math/3/4/a/34a392a9e27dd596c3ed3292b990712f.png) has dimensions ![100 \\times 100](//upload.wikimedia.org/math/1/0/1/1010487f977eb234f3e40bd658b7bcfc.png) and ![M_3](//upload.wikimedia.org/math/e/4/7/e47fdbf0968587d24cc2817c16b2ba15.png) has dimensions ![100 \\times 50](//upload.wikimedia.org/math/2/e/1/2e10ca6c50aa3dfe622a5350970d39ad.png). Let's paranthezise them in the two possible ways and see which way requires the least amount of multiplications. The two ways are

    ![\(\(M_1 M_2\) M_3\)](//upload.wikimedia.org/math/6/2/4/624a462e588485e047db81007a5afa61.png), and
    ![\(M_1 \(M_2 M_3\)\)](//upload.wikimedia.org/math/0/a/9/0a9ed2da219cc7bab47d32d5e9d7b770.png).

To form the product in the first way requires 75000 scalar multiplications (5*100*100=50000 to form product ![\(M_1 M_2\)](//upload.wikimedia.org/math/7/4/9/749a9031a65d7d25853987bf4dd321be.png) and another 5*100*50=25000 for the last multiplications.) This might seem like a lot, but in comparison to the 525000 scalar multiplications required by the second parenthesization (50*100*100=500000 plus 5*50*100=25000) it is miniscule! You can see why determining the parenthesization is important: imagine what would happen if we needed to multiply 50 matrices!

### Forming a Recursive Solution

Note that we concentrate on finding a how many scalar multiplications are needed instead of the actual order. This is because once we have found a working algorithm to find the amount it is trivial to create an algorithm for the actual parenthesization. It will, however, be discussed in the end.

So how would an algorithm for the optimum parenthesization look? By the chapter title you might expect that a dynamic programming method is in order (not to give the answer away or anything). So how would a dynamic programming method work? Because dynamic programming algorithms are based on optimal substructure, what would the optimal substructure in this problem be?

Suppose that the optimal way to parenthesize

    ![M_1 M_2 \\dots M_n](//upload.wikimedia.org/math/1/8/f/18f0fa99c21c064844735ca7a70d05bc.png)

splits the product at ![k](//upload.wikimedia.org/math/8/c/e/8ce4b16b22b58894aa86c421e8759df3.png):

    ![\(M_1 M_2 \\dots M_k\)\(M_{k+1} M_{k+2} \\dots M_n\)](//upload.wikimedia.org/math/5/4/5/54528282ebc1be7fc0e6328a3c1801ab.png).

Then the optimal solution contains the optimal solutions to the two subproblems

    ![\(M_1 \\dots M_k\)](//upload.wikimedia.org/math/a/9/f/a9f21546d1aff539a13d77edfef760d8.png)
    ![\(M_{k+1} \\dots M_n\)](//upload.wikimedia.org/math/a/e/4/ae4cb612b4c77b9ceff22e633e6ca28f.png)

That is, just in accordance with the fundamental principle of dynamic programming, the solution to the problem depends on the solution of smaller sub-problems.

Let's say that it takes ![c\(n\)](//upload.wikimedia.org/math/6/f/9/6f92aad59cd2c0646a2f0c5844875990.png) scalar multiplications to multiply matrices ![M_n](//upload.wikimedia.org/math/1/5/4/1547a74739c1e2b6be3ebe927017bfbb.png) and ![M_{n+1}](//upload.wikimedia.org/math/b/5/3/b5325dfd3bcbec5eebd582dcd42a0923.png), and ![f\(m,n\)](//upload.wikimedia.org/math/a/5/3/a53a7f70857529f682edcff165e899a4.png) is the number of scalar multiplications to be performed in an optimal parenthesization of the matrices ![M_m \\dots M_n](//upload.wikimedia.org/math/2/b/6/2b6baadb8faab6f829922c9d1367066b.png). The definition of ![f\(m,n\)](//upload.wikimedia.org/math/a/5/3/a53a7f70857529f682edcff165e899a4.png) is the first step toward a solution.

When ![n-m=1](//upload.wikimedia.org/math/2/f/e/2feb6fcae2322bed80afb0b8775e614b.png), the formulation is trivial; it is just ![c\(m\)](//upload.wikimedia.org/math/6/3/8/638fd40dab714afadb4bd56d7dde521c.png). But what is it when the distance is larger? Using the observation above, we can derive a formulation. Suppose an optimal solution to the problem divides the matrices at matrices k and k+1 (i.e. ![\(M_m \\dots M_k\)\(M_{k+1} \\dots M_n\)](//upload.wikimedia.org/math/d/8/c/d8c2c886f78f954c2946e6443deaefcb.png)) then the number of scalar multiplications are.

    ![f\(m,k\) + f\(k+1,n\) + c\(k\)](//upload.wikimedia.org/math/c/5/9/c5998d17549dde20dc4eca0e2dccc602.png)

That is, the amount of time to form the first product, the amount of time it takes to form the second product, and the amount of time it takes to multiply them together. But what is this optimal value k? The answer is, of course, the value that makes the above formula assume its minimum value. We can thus form the complete definition for the function:

    ![f\(m,n\) = \\begin{cases} \\min_{m \\le k < n}f\(m,k\) + f\(k+1,n\) + c\(k\) & \\mbox{if } n-m>1 \\\\ 0 & \\mbox{if } n=m\\end{cases}](//upload.wikimedia.org/math/0/1/b/01b376c226b97035f2be64bf5d87f3ea.png)

A straight-forward recursive solution to this would look something like this _(the language is [Wikicode](http://en.wikipedia.org/wiki/Wikipedia:Wikicode))_:
    
    
    function **f**(_m_, _n_) {
    
        if _m_ == _n_
            return 0
    
        let _minCost_ := ![\\infty](//upload.wikimedia.org/math/d/2/4/d245777abca64ece2d5d7ca0d19fddb6.png)
    
        for _k_ := _m_ to _n_ - 1 {
            v := **f**(_m_, _k_) + **f**(_k_ + 1, _n_) + _c_(_k_)
            if _v_ < _minCost_
                _minCost_ := _v_
        }
        return _minCost_
    }
    

This rather simple solution is, unfortunately, not a very good one. It spends mountains of time recomputing data and its running time is exponential.

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
write an analysis of the straight-forward-recursion method

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
write a memoization version

Using the same adaptation as above we get:
    
    
    function **f**(_m_, _n_) {
    
        if _m_ == _n_
            return 0
    
        else-if _f_[_m,n_] != -1:
          return _f_[_m,n_]
        fi
    
        let _minCost_ := ![\\infty](//upload.wikimedia.org/math/d/2/4/d245777abca64ece2d5d7ca0d19fddb6.png)
    
        for _k_ := _m_ to _n_ - 1 {
            v := **f**(_m_, _k_) + **f**(_k_ + 1, _n_) + _c_(_k_)
            if _v_ < _minCost_
                _minCost_ := _v_
        }
        _f_[_m,n_]=minCost
        return _minCost_
    }
    

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
write a full-fledged DP version

## Parsing Any Context-Free Grammar

Note that special types of context-free grammars can be parsed much more efficiently than this technique, but in terms of generality, the DP method is the only way to go.

  


# Greedy Algorithms

In the backtracking algorithms we looked at, we saw algorithms that found decision points and recursed over all options from that decision point. A **greedy algorithm** can be thought of as a backtracking algorithm where at each decision point "the best" option is already known and thus can be picked without having to recurse over any of the alternative options.

The name "greedy" comes from the fact that the algorithms make decisions based on a single criterion, instead of a global analysis that would take into account the decision's effect on further steps. As we will see, such a backtracking analysis will be unnecessary in the case of greedy algorithms, so it is not greedy in the sense of causing harm for only short-term gain.

Unlike backtracking algorithms, greedy algorithms can't be made for every problem. Not every problem is "solvable" using greedy algorithms. Viewing the finding solution to an optimization problem as a hill climbing problem greedy algorithms can be used for only those hills where at every point taking the steepest step would lead to the peak always.

Greedy algorithms tend to be very efficient and can be implemented in a relatively straightforward fashion. Many a times in O(n) complexity as there would be a single choice at every point. However, most attempts at creating a correct greedy algorithm fail unless a precise proof of the algorithm's correctness is first demonstrated. When a greedy strategy fails to produce optimal results on all inputs, we instead refer to it as a heuristic instead of an algorithm. Heuristics can be useful when speed is more important than exact results (for example, when "good enough" results are sufficient).

## Event Scheduling Problem

The first problem we'll look at that can be solved with a greedy algorithm is the event scheduling problem. We are given a set of events that have a start time and finish time, and we need to produce a subset of these events such that no events intersect each other (that is, having overlapping times), and that we have the maximum number of events scheduled as possible.

Here is a formal statement of the problem:

    _Input_: _events_: a set of intervals ![\(s_i, f_i\)](//upload.wikimedia.org/math/d/1/0/d10f9a5fab981939bf27aafd71cf7653.png) where ![s_i](//upload.wikimedia.org/math/e/5/a/e5a7472d780a5a032c7775cc5e3ce901.png) is the start time, and ![f_i](//upload.wikimedia.org/math/d/b/b/dbb3b84cea7e7015fb1a591964fbd918.png) is the finish time.
    _Solution_: A subset _S_ of _Events_.
    _Constraint_: No events can intersect (start time exclusive). That is, for all intervals ![i=\(s_i, f_i\), j=\(s_j, f_j\)](//upload.wikimedia.org/math/a/b/7/ab764cda65ce85e57e34c554f39a33d7.png) where ![s_i < s_j](//upload.wikimedia.org/math/5/9/f/59fb1c995d82f4ebfb9410249ed96d3a.png) it holds that ![f_i\\le s_j](//upload.wikimedia.org/math/9/4/c/94c75f92873378f40478925a23e4d3af.png).
    _Objective_: Maximize the number of scheduled events, i.e. maximize the size of the set _S_.

We first begin with a backtracking solution to the problem:
    
    
    _// event-schedule -- schedule as many non-conflicting events as possible_
    function **event-schedule**(_events_ array of _s_[1.._n_], _j_[1.._n_]): set
      if _n_ == 0: return ![\\emptyset](//upload.wikimedia.org/math/4/d/f/4df085f70a97244c977b6ff20b1952b4.png) fi
      if _n_ == 1: return {_events_[1]} fi
      let _event_ := _events_[1]
      let _S1_ := union(**event-schedule**(_events_ - set of conflicting events), _event_)
      let _S2_ := **event-schedule**(_events_ - {_event_})
      if _S1_.size() >= _S2_.size():
        return _S1_
      else
        return _S2_
      fi
    end
    

The above algorithm will faithfully find the largest set of non-conflicting events. It brushes aside details of how the set

    _events_ \- set of conflicting events

is computed, but it would require ![O\(n\)](//upload.wikimedia.org/math/7/b/a/7ba55e7c64a9405a0b39a1107e90ca94.png) time. Because the algorithm makes two recursive calls on itself, each with an argument of size ![n - 1](//upload.wikimedia.org/math/a/4/3/a438673491daae8148eae77373b6a467.png), and because removing conflicts takes linear time, a recurrence for the time this algorithm takes is:

    ![T\(n\) = 2\\cdot T\(n - 1\) + O\(n\)](//upload.wikimedia.org/math/7/6/3/7631b7bcfd14d8be580a738ae6bdecf1.png)

which is ![O\(2^{n}\)](//upload.wikimedia.org/math/a/5/b/a5bab29729331b95aeebc96eda2906ad.png).

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
a tighter bound is possible

But suppose instead of picking just the first element in the array we used some other criterion. The aim is to just pick the "right" one so that we wouldn't need two recursive calls. First, let's consider the greedy strategy of picking the shortest events first, until we can add no more events without conflicts. The idea here is that the shortest events would likely interfere less than other events.

There are scenarios were picking the shortest event first produces the optimal result. However, here's a scenario where that strategy is sub-optimal:

![AlgorithmsShortestFirst.png](//upload.wikimedia.org/wikibooks/en/d/db/AlgorithmsShortestFirst.png)

Above, the optimal solution is to pick event A and C, instead of just B alone. Perhaps instead of the shortest event we should pick the events that have the least number of conflicts. This strategy seems more direct, but it fails in this scenario:

![AlgorithmsLeastConflicts.png](//upload.wikimedia.org/wikibooks/en/f/fd/AlgorithmsLeastConflicts.png)

Above, we can maximize the number of events by picking A, B, C, D, and E. However, the events with the least conflicts are 6, 2 and 7, 3. But picking one of 6, 2 and one of 7, 3 means that we cannot pick B, C and D, which includes three events instead of just two.

## Dijkstra's Shortest Path Algorithm

With two (high-level, pseudocode) transformations, Dijsktra's algorithm can be derived from the much less efficient backtracking algorithm. The trick here is to prove the transformations maintain correctness, but that's the whole insight into Dijkstra's algorithm anyway. [TODO: important to note the paradox that to solve this problem it's easier to solve a more-general version. That is, shortest path from s to all nodes, not just to t. Worthy of its own colored box.]

To see the workings of Dijkstra's Shortest Path Algorithm, take an example:

There is a start and end node, with 2 paths between them ; one path has cost 30 on first hop, then 10 on last hop to the target node, with total cost 40. Another path cost 10 on first hop, 10 on second hop, and 40 on last hop, with total cost 60.

The start node is given distance zero so it can be at the front of a shortest distance queue, all the other nodes are given infinity or a large number e.g. 32767 .

This makes the start node the first current node in the queue.

With each iteration, the current node is the first node of a shortest path queue. It looks at all nodes adjacent to the current node;

For the case of the start node, in the first path it will find a node of distance 30, and in the second path, an adjacent node of distance 10. The current nodes distance , which is zero at the beginning, is added to distances of the adjacent nodes, and the distances from the start node of each node are updated , so the nodes will be 30+0 = 30 in the 1st path , and 10+0=10 in the 2nd path.

Importantly, also updated is a previous pointer attribute for each node, so each node will point back to the current node, which is the start node for these two nodes.

Each node's priority is updated in the priority queue using the new distance.

That ends one iteration. The current node was removed from the queue before examining its adjacent nodes.

In the next iteration, the front of the queue will be the node in the second path of distance 10, and it has only one adjacent node of distance 10, and that adjacent node will distance will be updated from 32767 to 10 (the current node distance) + 10 ( the distance from the current node) = 20.

In the next iteration, the second path node of cost 20 will be examined, and it has one adjacent hop of 40 to the target node, and the target nodes distance is updated from 32767 to 20 + 40 = 60 . The target node has its priority updated.

In the next iteration, the shortest path node will be the first path node of cost 30, and the target node has not been yet removed from the queue. It is also adjacent to the target node, with the total distance cost of 30 + 10 = 40.

Since 40 is less than 60, the previous calculated distance of the target node, the target node distance is updated to 40, and the previous pointer of the target node is updated to the node on the first path.

In the final iteration, the shortest path node is the target node, and the loop exits.

Looking at the previous pointers starting with the target node, a shortest path can be reverse constructed as a list to the start node.

Given the above example, what kind of data structures are needed for the nodes and the algorithm ?

  

    
    
    # author , copyright under GFDL
    class Node :
        def __init__(self, label, distance = 32767 ): 
            # a bug in constructor, uses a shared map initializer 
            # , adjacency_distance_map = {} ):
          self.label = label
     
          self.adjacent = {}  # this is an adjacency map, with keys nodes, and values the adjacent distance
     
          self.distance = distance   # this is the updated distance from the start node, used as the node's priority
          # default distance is 32767
     
          self.shortest_previous = None  #this the last shortest distance adjacent node
     
        # the logic is that the last adjacent distance added is recorded , for any distances of the same node added
        def add_adjacent(self, local_distance, node):
           self.adjacent[node]=local_distance
           print "adjacency to ", self.label, " of ", self.adjacent[node], " to ", \
                    node.label
     
        def get_adjacent(self) :
            return self.adjacent.iteritems()      
     
        def update_shortest( self, node):
            new_distance = node.adjacent[self] + node.distance
     
            #DEBUG
            print "for node ", node.label, " updating ", self.label, \
                    " with distance ", node.distance , \
                    " and adjacent distance ", node.adjacent[self]
     
            updated = False
            # node's adjacency map gives the adjacent distance for this node
            # the new distance for the path to this (self)node is the adjacent distance plus the other node's distance
            if new_distance < self.distance :
                    # if it is the shortest distance then record the distance, and make the previous node that node
                    self.distance = new_distance
                    self.shortest_previous= node  
                    updated = True
            return updated
     
    MAX_IN_PQ = 100000   
    class PQ:
           def __init__(self ,  sign  = -1 ): 
              self.q = [None ] * MAX_IN_PQ # make the array preallocated
              self.sign = sign  # a negative sign is a minimum priority queue
              self.end = 1 # this is the next slot of the array (self.q) to be used , 
              self.map = {}
     
           def  insert( self,  priority, data):
               self.q[self.end] = (priority, data)
               # sift up after insert
               p = self.end
               self.end = self.end + 1    
               self.sift_up(p)       
     
           def sift_up(self, p):
               # p is the current node's position
               # q[p][0] is the priority, q[p][1] is the item or node
     
               # while the parent exists ( p >= 1) , and parent's priority is less than the current node's priority
               while  p / 2 != 0 and  self.q[p/2][0]*self.sign  < self.q[p][0]*self.sign:
                  # swap the parent and the current node, and make the current node's position the parent's position
                  tmp = self.q[p]
                  self.q[p] = self.q[p/2]
                  self.q[p/2] = tmp
                  self.map[self.q[p][1]] = p
                  p = p/2
     
               # this map's the node to the position in the priority queue
               self.map[self.q[p][1]] = p
     
               return p
     
     
           def remove_top(self):
     
                if  self.end == 1 :
                  return (-1, None)
     
                (priority, node) = self.q[1]
                # put the end of the heap at the top of the heap, and sift it down to adjust the heap
                # after the heap's top has been removed. this takes log2(N) time, where N iis the size of the heap.
     
                self.q[1] = self.q[self.end-1]
                self.end = self.end - 1
     
                self.sift_down(1)
     
                return (priority, node)
     
           def sift_down(self, p):
               while 1:
                 l = p * 2
     
                 # if the left child's position is more than the size of the heap, 
                 # then left and right children don't exist
                 if ( l > self.end) :
                   break
     
                 r= l + 1
                 # the selected child node should have the greatest priority
                 t = l
                 if r < self.end and self.q[r][0]*self.sign > self.q[l][0]*self.sign :
                   t = r
                 print "checking for sift down of ", self.q[p][1].label, self.q[p][0], " vs child ", self.q[t][1].label, self.q[t][0]
                 # if the selected child with the greatest priority has a higher priority than the current node
                 if self.q[t] [0] * self. sign  >  self.q [p] [0] * self.sign :
                   # swap the current node with that child, and update the mapping of the child node to its new position
                   tmp = self. q [ t ]
                   self. q [ t ] = self.q [ p ]
                   self. q [ p ] = tmp
                   self.map [ tmp [1 ] ] = p
                   p = t
                 else: break    # end the swap if the greatest priority child has a lesser priority than the current node
     
               # after the sift down, update the new position of the current node.
               self.map [ self.q[p][1] ] = p
               return p
     
           def  update_priority(self, priority, data ) :
     
                p = self. map[ data ]
                print "priority prior update", p, "for priority", priority, " previous priority", self.q[p][0]
                if p is None : 
                   return -1
     
                self.q[p]  = (priority, self.q[p][1])
                p = self.sift_up(p)
                p = self.sift_down(p)
                print "updated ", self.q[p][1].label , p, "priority now ", self.q[p][0]
     
                return p
     
    class NoPathToTargetNode ( BaseException):
      pass
     
    def test_1() :
         st =  Node('start', 0)
         p1a =  Node('p1a')
         p1b =  Node('p1b')
         p2a =  Node('p2a')
         p2b =  Node('p2b')
         p2c = Node('p2c')
         p2d = Node('p2d') 
         targ =  Node('target')
         st.add_adjacent ( 30, p1a)
         #st.add_adjacent ( 10, p2a)
         st.add_adjacent ( 20, p2a)
         #p1a.add_adjacent(10, targ)
         p1a.add_adjacent(40, targ)
         p1a.add_adjacent(10, p1b)
         p1b.add_adjacent(10, targ)
         # testing alternative
         #p1b.add_adjacent(20, targ)
         p2a.add_adjacent(10, p2b)
         p2b.add_adjacent(5,p2c)
         p2c.add_adjacent(5,p2d)
         #p2d.add_adjacent(5,targ)
         #chooses the alternate path
         p2d.add_adjacent(15,targ)
         pq =  PQ()
     
         # st.distance is 0, but the other's have default starting distance 32767
         pq.insert( st.distance, st)
         pq.insert( p1a.distance, p1a)
         pq.insert( p2a.distance, p2a)
         pq.insert( p2b.distance, p2b)
         pq.insert(targ.distance, targ)
         pq.insert( p2c.distance, p2c)
         pq.insert( p2d.distance, p2d)
     
         pq.insert(p1b.distance, p1b)
     
         node = None
     
         while  node !=  targ :
          (pr, node ) = pq.remove_top()
          #debug
          print "node ", node.label, " removed from top "
          if  node is None:
                   print "target node not in queue"
                   raise 
          elif pr == 32767:
                   print "max distance encountered so no further nodes updated. No path to target node."
                   raise NoPathToTargetNode
     
          # update the distance to the start node using this node's distance to all of the nodes adjacent to it, and update its priority if 
          # a shorter distance was found for an adjacent node ( .update_shortest(..) returns true ).
          # this is the greedy part of the dijsktra's algorithm, always greedy for the shortest distance using the priority queue.
          for adj_node , dist in node.get_adjacent():
            #debug
            print "updating adjacency from ", node.label, " to ", adj_node.label
            if adj_node.update_shortest( node ):
                    pq.update_priority(  adj_node.distance, adj_node) 
     
          print "node and targ ", node, targ , node <> targ 
         print "length of path", targ.distance
         print " shortest path"
     
         #create a reverse list from the target node, through the shortes path nodes to the start node
         node = targ
     
         path = []
         while node <> None :
            path.append(node)
            node = node. shortest_previous
     
         for node in reversed(path):  # new iterator version of list.reverse()
            print node.label
     
    if __name__ == "__main__":
      test_1()
    

## Minimum spanning tree

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Minimum spanning tree**_](//en.wikipedia.org/wiki/Minimum_spanning_tree)

  


# Hill Climbing

**Hill climbing** is a technique for certain classes of optimization problems. The idea is to start with a sub-optimal solution to a problem (i.e., _start at the base of a hill_) and then repeatedly improve the solution (_walk up the hill_) until some condition is maximized (_the top of the hill is reached_).

**Hill-Climbing Methodology**  


  1. Construct a sub-optimal solution that meets the constraints of the problem
  2. Take the solution and make an improvement upon it
  3. Repeatedly improve the solution until no more improvements are necessary/possible

One of the most popular hill-climbing problems is the network flow problem. Although network flow may sound somewhat specific it is important because it has high expressive power: for example, many algorithmic problems encountered in practice can actually be considered special cases of network flow. After covering a simple example of the hill-climbing approach for a numerical problem we cover network flow and then present examples of applications of network flow.

## Newton's Root Finding Method

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Newton_iteration.png/300px-Newton_iteration.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

An illustration of Newton's method: The zero of the _f(x)_ function is at _x_. We see that the guess _xn+1_ is a better guess than _xn_ because it is closer to _x_. (_from [Wikipedia](//en.wikipedia.org/wiki/Newton%27s_method)_)

Newton's Root Finding Method is a three-centuries-old algorithm for finding numerical approximations to roots of a function (that is a point ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) where the function ![f\(x\)](//upload.wikimedia.org/math/5/0/b/50bbd36e1fd2333108437a2ca378be62.png) becomes zero), starting from an initial guess. You need to know the function ![f\(x\)\\,](//upload.wikimedia.org/math/5/5/0/550f51512f9bb16a0f613ae65e1d3088.png) and its first derivative ![f'\(x\)\\,](//upload.wikimedia.org/math/b/2/b/b2bf76697fa80b174e04943d1777bcf6.png) for this algorithm. The idea is the following: In the vicinity of the initial guess ![x_0](//upload.wikimedia.org/math/0/b/2/0b21a666a81629962ade8afd967826ed.png) we can form the Taylor expansion of the function

    ![f\(x\)=f\(x_0+\\epsilon\)\\,](//upload.wikimedia.org/math/a/3/d/a3dd5b3a5f64ad46380c13edb8d8151d.png)![\\approx f\(x_0\)+\\epsilon f'\(x_0\)](//upload.wikimedia.org/math/9/4/1/941664c61c5c7ee64aec8d04d8df1581.png)![+\\frac{\\epsilon^2}{2} f''\(x_0\)+...](//upload.wikimedia.org/math/b/3/5/b358a1cb96f734c2c6a4791ee180cc2c.png)

which gives a good approximation to the function near ![x_0](//upload.wikimedia.org/math/0/b/2/0b21a666a81629962ade8afd967826ed.png). Taking only the first two terms on the right hand side, setting them equal to zero, and solving for ![\\epsilon](//upload.wikimedia.org/math/c/5/0/c50b9e82e318d4c163e4b1b060f7daf5.png), we obtain

    ![\\epsilon=-\\frac{f\(x_0\)}{f'\(x_0\)}](//upload.wikimedia.org/math/c/a/6/ca6dd883a103f85d31d6026ec39411f8.png)

which we can use to construct a better solution

    ![x_1=x_0+\\epsilon=x_0-\\frac{f\(x_0\)}{f'\(x_0\)}.](//upload.wikimedia.org/math/b/8/5/b856f37cba71272dac9cb76ce208253a.png)

This new solution can be the starting point for applying the same procedure again. Thus, in general a better approximation can be constructed by repeatedly applying

    ![x_{n+1}=x_n-\\frac{f\(x_n\)}{f'\(x_n\)}.](//upload.wikimedia.org/math/4/1/c/41cb7e4f10c06202b86e92c9e1125a81.png)

As shown in the illustration, this is nothing else but the construction of the zero from the tangent at the initial guessing point. In general, Newton's root finding method converges quadratically, except when the first derivative of the solution ![f'\(x\)=0\\,](//upload.wikimedia.org/math/a/c/b/acbe5f509f3b03f4f0e4ddf0a5056360.png) vanishes at the root.

Coming back to the "Hill climbing" analogy, we could apply Newton's root finding method not to the function ![f\(x\)\\,](//upload.wikimedia.org/math/5/5/0/550f51512f9bb16a0f613ae65e1d3088.png), but to its first derivative ![f'\(x\)\\,](//upload.wikimedia.org/math/b/2/b/b2bf76697fa80b174e04943d1777bcf6.png), that is look for ![x](//upload.wikimedia.org/math/9/d/d/9dd4e461268c8034f5c8564e155c67a6.png) such that ![f'\(x\)=0\\,](//upload.wikimedia.org/math/a/c/b/acbe5f509f3b03f4f0e4ddf0a5056360.png). This would give the extremal positions of the function, its maxima and minima. Starting Newton's method close enough to a maximum this way, we climb the hill.

Instead of regarding continuous functions, the hill-climbing method can also be applied to discrete networks.

## Network Flow

Suppose you have a directed graph (possibly with cycles) with one vertex labeled as the source and another vertex labeled as the destination or the "sink". The source vertex only has edges coming out of it, with no edges going into it. Similarly, the destination vertex only has edges going into it, with no edges coming out of it. We can assume that the graph fully connected with no dead-ends; i.e., for every vertex (except the source and the sink), there is at least one edge going into the vertex and one edge going out of it.

We assign a "capacity" to each edge, and initially we'll consider only integral-valued capacities. The following graph meets our requirements, where "s" is the source and "t" is the destination:

![Algorithms-NetFlow1.png](//upload.wikimedia.org/wikibooks/en/9/98/Algorithms-NetFlow1.png)

We'd like now to imagine that we have some series of inputs arriving at the source that we want to carry on the edges over to the sink. The number of units we can send on an edge at a time must be less than or equal to the edge's capacity. You can think of the vertices as cities and the edges as roads between the cities and we want to send as many cars from the source city to the destination city as possible. The constraint is that we cannot send more cars down a road than its capacity can handle.

**The goal of network flow** is to send as much traffic from ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png) to ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png) as each street can bear.

To organize the traffic routes, we can build a list of different paths from city ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png) to city ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png). Each path has a carrying capacity equal to the smallest capacity value for any edge on the path; for example, consider the following path ![p](//upload.wikimedia.org/math/8/3/8/83878c91171338902e0fe0fb97a8c47a.png):

![Algorithms-NetFlow2.png](//upload.wikimedia.org/wikibooks/en/4/46/Algorithms-NetFlow2.png)

Even though the final edge of ![p](//upload.wikimedia.org/math/8/3/8/83878c91171338902e0fe0fb97a8c47a.png) has a capacity of 8, that edge only has one car traveling on it because the edge before it only has a capacity of 1 (thus, that edge is at full capacity). After using this path, we can compute the **residual graph** by subtracting 1 from the capacity of each edge:

![Algorithms-NetFlow3.png](//upload.wikimedia.org/wikibooks/en/3/32/Algorithms-NetFlow3.png)

(We subtracted 1 from the capacity of each edge in ![p](//upload.wikimedia.org/math/8/3/8/83878c91171338902e0fe0fb97a8c47a.png) because 1 was the carrying capacity of ![p](//upload.wikimedia.org/math/8/3/8/83878c91171338902e0fe0fb97a8c47a.png).) We can say that path ![p](//upload.wikimedia.org/math/8/3/8/83878c91171338902e0fe0fb97a8c47a.png) has a flow of 1. Formally, a **flow** is an assignment ![f\(e\)](//upload.wikimedia.org/math/6/5/3/653ffcb912ba48b85050f5b382ddf94b.png) of values to the set of edges in the graph ![G = \(V, E\)](//upload.wikimedia.org/math/9/e/9/9e9992d6bf50b7580f971487c466a8cb.png) such that:

    1\. ![\\forall e\\in E: f\(e\)\\in\\R](//upload.wikimedia.org/math/8/0/f/80f8652530b57b53fe476665f6925293.png)
    2\. ![\\forall \(u,v\)\\in E: f\(\(u,v\)\) = -f\(\(v,u\)\)](//upload.wikimedia.org/math/a/d/0/ad0d6d860b855c29cdc53619e737c290.png)
    3\. ![\\forall u\\in V, u\\ne s,t: \\sum_{v\\in V}f\(u,v\) = 0](//upload.wikimedia.org/math/c/9/b/c9b6eb1aab7e1cd626ae196ef006b1dd.png)
    4\. ![\\forall e\\in E: f\(e\)\\le c\(e\)](//upload.wikimedia.org/math/e/1/8/e18544f9618f690082a7e9c7ecea7c52.png)

Where ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png) is the source node and ![t](//upload.wikimedia.org/math/e/3/5/e358efa489f58062f10dd7316b65649e.png) is the sink node, and ![c\(e\)\\ge 0](//upload.wikimedia.org/math/6/e/f/6efe269944c66a2ac599909ac79c2906.png) is the capacity of edge ![e](//upload.wikimedia.org/math/e/1/6/e1671797c52e15f763380b45e841ec32.png). We define the value of a flow ![f](//upload.wikimedia.org/math/8/f/a/8fa14cdd754f91cc6554c9e71929cce7.png) to be:

    ![\\textrm{Value}\(f\) = \\sum_{v\\in V} f\(\(s, v\)\)](//upload.wikimedia.org/math/3/e/e/3ee4db2aab71af66ddcdedcf4f23994b.png)

The goal of network flow is to find an ![f](//upload.wikimedia.org/math/8/f/a/8fa14cdd754f91cc6554c9e71929cce7.png) such that ![\\textrm{Value}\(f\)](//upload.wikimedia.org/math/0/8/3/08395e38b0fb8ba0944b8d835aa7e0e0.png) is maximal. To be maximal means that there is no other flow assignment that obeys the constraints 1-4 that would have a higher value. The traffic example can describe what the four flow constraints mean:

  1. ![\\forall e\\in E: f\(e\)\\in\\R](//upload.wikimedia.org/math/8/0/f/80f8652530b57b53fe476665f6925293.png). This rule simply defines a flow to be a function from edges in the graph to real numbers. The function is defined for every edge in the graph. You could also consider the "function" to simply be a mapping: Every edge can be an index into an array and the value of the array at an edge is the value of the flow function at that edge.
  2. ![\\forall \(u,v\)\\in E: f\(\(u,v\)\) = -f\(\(v,u\)\)](//upload.wikimedia.org/math/a/d/0/ad0d6d860b855c29cdc53619e737c290.png). This rule says that if there is some traffic flowing from node _u_ to node _v_ then there should be considered negative that amount flowing from _v_ to _u_. For example, if two cars are flowing from city _u_ to city _v_, then negative two cars are going in the other direction. Similarly, if three cars are going from city _u_ to city _v_ and two cars are going city _v_ to city _u_ then the net effect is the same as if one car was going from city _u_ to city _v_ and no cars are going from city _v_ to city _u_.
  3. ![\\forall u\\in V, u\\ne s,t: \\sum_{v\\in V}f\(u,v\) = 0](//upload.wikimedia.org/math/c/9/b/c9b6eb1aab7e1cd626ae196ef006b1dd.png). This rule says that the net flow (except for the source and the destination) should be neutral. That is, you won't ever have more cars going into a city than you would have coming out of the city. New cars can only come from the source, and cars can only be stored in the destination. Similarly, whatever flows out of _s_ must eventually flow into _t_. Note that if a city has three cars coming into it, it could send two cars to one city and the remaining car to a different city. Also, a city might have cars coming into it from multiple sources (although all are ultimately from city _s_).
  4. ![\\forall e\\in E: f\(e\)\\le c\(e\)](//upload.wikimedia.org/math/e/1/8/e18544f9618f690082a7e9c7ecea7c52.png).

## The Ford-Fulkerson Algorithm

The following algorithm computes the maximal flow for a given graph with non-negative capacities. What the algorithm does can be easy to understand, but it's non-trivial to show that it terminates and provides an optimal solution.
    
    
    function **net-flow**(graph (_V_, _E_), node _s_, node _t_, cost _c_): flow
      initialize _f_(_e_) := 0 for all _e_ in _E_
      loop while not _done_
        for all _e_ in _E_:                         _// compute residual capacities_
          let _cf_(_e_) := _c_(_e_) - _f_(_e_)
        repeat
        
        let _Gf_ := (_V_, {_e_ : _e_ in _E_ and _cf_(_e_) > 0})
    
        find a path _p_ from _s_ to _t_ in _Gf_         _// e.g., use depth first search_
        if no path _p_ exists: signal _done_
    
        let _path-capacities_ := map(_p_, _cf_)       _// a path is a set of edges_
        let _m_ := min-val-of(_path-capacities_)    _// smallest residual capacity of p_
        for all (_u_, _v_) in _p_:                    _// maintain flow constraints_
          _f_((_u_, _v_)) := _f_((_u_, _v_)) + _m_
          _f_((_v_, _u_)) := _f_((_v_, _u_)) - _m_
        repeat
      repeat
    end
    

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
explain, hopefully using pictures, what the algorithm is doing. Explain its run time. Prove that it is optimal. Show an optimization, by "remembering" the Depth First Search to cut down the time the algorithm takes.

## Applications of Network Flow

1\. finding out maximum bi - partite matching . 2. finding out min cut of a graph .

# Ada Implementation

## Introduction

Welcome to the Ada implementations of the [Algorithms](/wiki/Algorithms) Wikibook. For those who are new to [Ada Programming](/wiki/Ada_Programming) a few notes:

  * All examples are fully functional with all the needed input and output operations. However, only the code needed to outline the algorithms at hand is copied into the text - the full samples are available via the download links. (Note: It can take up to 48 hours until the cvs is updated).
  * We seldom use predefined types in the sample code but define special types suitable for the algorithms at hand.
  * Ada allows for default function parameters; however, we always fill in and name all parameters, so the reader can see which options are available.
  * We seldom use shortcuts - like using the attributes [Image](/wiki/Ada_Programming/Attributes/%27Image) or [Value](/wiki/Ada_Programming/Attributes/%27Value) for String <=> Integer conversions.

All these rules make the code more elaborate than perhaps needed. However, we also hope it makes the code easier to understand

  


## Chapter 1: Introduction

The following subprograms are implementations of the _[Inventing an Algorithm_ examples](/wiki/Algorithms/Introduction#Inventing_an_Algorithm).

### To Lower

The Ada example code does not append to the array as the algorithms. Instead we create an empty array of the desired length and then replace the characters inside.

File: to_lower_1.adb ([view](http://wikibook-ada.svn.sourceforge.net/viewvc/wikibook-ada/trunk/demos/Source/to_lower_1.adb?view=markup), [plain text](http://wikibook-ada.svn.sourceforge.net/viewvc/*checkout*/wikibook-ada/trunk/demos/Source/to_lower_1.adb), [download page](https://sourceforge.net/project/showfiles.php?group_id=124904), [browse all](http://wikibook-ada.sourceforge.net/html/index.html))
    
    
      [function](/wiki/Ada_Programming/Keywords/function) To_Lower (C : Character) [return](/wiki/Ada_Programming/Keywords/return) Character [renames](/wiki/Ada_Programming/Keywords/renames)
         Ada.Characters.Handling.To_Lower;
    
      --  tolower - translates all alphabetic, uppercase characters
      --  in str to lowercase
      [function](/wiki/Ada_Programming/Keywords/function) To_Lower (Str : String) [return](/wiki/Ada_Programming/Keywords/return) String [is](/wiki/Ada_Programming/Keywords/is)
         Result : String (Str'[Range](/wiki/Ada_Programming/Attributes/%27Range));
      [begin](/wiki/Ada_Programming/Keywords/begin)
         [for](/wiki/Ada_Programming/Keywords/for) C [in](/wiki/Ada_Programming/Keywords/in)  Str'[Range](/wiki/Ada_Programming/Attributes/%27Range) [loop](/wiki/Ada_Programming/Keywords/loop)
            Result (C) := To_Lower (Str (C));
         [end](/wiki/Ada_Programming/Keywords/end) [loop](/wiki/Ada_Programming/Keywords/loop);
         [return](/wiki/Ada_Programming/Keywords/return) Result;
      [end](/wiki/Ada_Programming/Keywords/end) To_Lower;
    

Would the append approach be impossible with Ada? No, but it would be significantly more complex and slower.

### Equal Ignore Case

File: to_lower_2.adb ([view](http://wikibook-ada.svn.sourceforge.net/viewvc/wikibook-ada/trunk/demos/Source/to_lower_2.adb?view=markup), [plain text](http://wikibook-ada.svn.sourceforge.net/viewvc/*checkout*/wikibook-ada/trunk/demos/Source/to_lower_2.adb), [download page](https://sourceforge.net/project/showfiles.php?group_id=124904), [browse all](http://wikibook-ada.sourceforge.net/html/index.html))
    
    
      --  equal-ignore-case -- returns true if s or t are equal,
      --  ignoring case
      [function](/wiki/Ada_Programming/Keywords/function) Equal_Ignore_Case
        (S    : String;
         T    : String)
         [return](/wiki/Ada_Programming/Keywords/return) Boolean
      [is](/wiki/Ada_Programming/Keywords/is)
         O : [constant](/wiki/Ada_Programming/Keywords/constant) Integer := S'[First](/wiki/Ada_Programming/Attributes/%27First) - T'[First](/wiki/Ada_Programming/Attributes/%27First);
      [begin](/wiki/Ada_Programming/Keywords/begin)
         [if](/wiki/Ada_Programming/Keywords/if) T'[Length](/wiki/Ada_Programming/Attributes/%27Length) /= S'[Length](/wiki/Ada_Programming/Attributes/%27Length) [then](/wiki/Ada_Programming/Keywords/then)
            [return](/wiki/Ada_Programming/Keywords/return) False;  --  if they aren't the same length, they
                           --  aren't equal
         [else](/wiki/Ada_Programming/Keywords/else)
            [for](/wiki/Ada_Programming/Keywords/for) I [in](/wiki/Ada_Programming/Keywords/in)  S'[Range](/wiki/Ada_Programming/Attributes/%27Range) [loop](/wiki/Ada_Programming/Keywords/loop)
               [if](/wiki/Ada_Programming/Keywords/if) To_Lower (S (I)) /=
                  To_Lower (T (I + O))
               [then](/wiki/Ada_Programming/Keywords/then)
                  [return](/wiki/Ada_Programming/Keywords/return) False;
               [end](/wiki/Ada_Programming/Keywords/end) [if](/wiki/Ada_Programming/Keywords/if);
            [end](/wiki/Ada_Programming/Keywords/end) [loop](/wiki/Ada_Programming/Keywords/loop);
         [end](/wiki/Ada_Programming/Keywords/end) [if](/wiki/Ada_Programming/Keywords/if);
         [return](/wiki/Ada_Programming/Keywords/return) True;
      [end](/wiki/Ada_Programming/Keywords/end) Equal_Ignore_Case;
    

  


  


## Chapter 6: Dynamic Programming

### Fibonacci numbers

The following codes are implementations of the [Fibonacci-Numbers examples](/wiki/Algorithms/Dynamic_Programming#Fibonacci_Numbers).

#### Simple Implementation

File: fibonacci_1.adb ([view](http://wikibook-ada.svn.sourceforge.net/viewvc/wikibook-ada/trunk/demos/Source/fibonacci_1.adb?view=markup), [plain text](http://wikibook-ada.svn.sourceforge.net/viewvc/*checkout*/wikibook-ada/trunk/demos/Source/fibonacci_1.adb), [download page](https://sourceforge.net/project/showfiles.php?group_id=124904), [browse all](http://wikibook-ada.sourceforge.net/html/index.html))
    
    
    ...
    

To calculate Fibonacci numbers negative values are not needed so we define an integer type which starts at 0. With the integer type defined you can calculate up until `Fib (87)`. `Fib (88)` will result in an `Constraint_Error`.
    
    
      [type](/wiki/Ada_Programming/Keywords/type) Integer_Type [is](/wiki/Ada_Programming/Keywords/is) [range](/wiki/Ada_Programming/Keywords/range) 0 .. 999_999_999_999_999_999;
    

You might notice that there is not equivalence for the `assert (n >= 0)` from the original example. Ada will test the correctness of the parameter _before_ the function is called.
    
    
      [function](/wiki/Ada_Programming/Keywords/function) Fib (n : Integer_Type) [return](/wiki/Ada_Programming/Keywords/return) Integer_Type [is](/wiki/Ada_Programming/Keywords/is)
      [begin](/wiki/Ada_Programming/Keywords/begin)
         [if](/wiki/Ada_Programming/Keywords/if) n = 0 [then](/wiki/Ada_Programming/Keywords/then)
            [return](/wiki/Ada_Programming/Keywords/return) 0;
         [elsif](/wiki/Ada_Programming/Keywords/elsif) n = 1 [then](/wiki/Ada_Programming/Keywords/then)
            [return](/wiki/Ada_Programming/Keywords/return) 1;
         [else](/wiki/Ada_Programming/Keywords/else)
            [return](/wiki/Ada_Programming/Keywords/return) Fib (n - 1) + Fib (n - 2);
         [end](/wiki/Ada_Programming/Keywords/end) [if](/wiki/Ada_Programming/Keywords/if);
      [end](/wiki/Ada_Programming/Keywords/end) Fib;
    
    ...
    

#### Cached Implementation

File: fibonacci_2.adb ([view](http://wikibook-ada.svn.sourceforge.net/viewvc/wikibook-ada/trunk/demos/Source/fibonacci_2.adb?view=markup), [plain text](http://wikibook-ada.svn.sourceforge.net/viewvc/*checkout*/wikibook-ada/trunk/demos/Source/fibonacci_2.adb), [download page](https://sourceforge.net/project/showfiles.php?group_id=124904), [browse all](http://wikibook-ada.sourceforge.net/html/index.html))
    
    
    ...
    

For this implementation we need a special cache type can also store a -1 as "not calculated" marker
    
    
      [type](/wiki/Ada_Programming/Keywords/type) Cache_Type [is](/wiki/Ada_Programming/Keywords/is) [range](/wiki/Ada_Programming/Keywords/range) -1 .. 999_999_999_999_999_999;
    

The actual type for calculating the fibonacci numbers continues to start at 0. As it is a `[subtype`](/wiki/Ada_Programming/Keywords/subtype) of the cache type Ada will automatically convert between the two. (the conversion is - of course - checked for validity)
    
    
      [subtype](/wiki/Ada_Programming/Keywords/subtype) Integer_Type [is](/wiki/Ada_Programming/Keywords/is) Cache_Type [range](/wiki/Ada_Programming/Keywords/range)
         0 .. Cache_Type'[Last](/wiki/Ada_Programming/Attributes/%27Last);
    

In order to know how large the cache need to be we first read the actual value from the command line.
    
    
      Value : [constant](/wiki/Ada_Programming/Keywords/constant) Integer_Type :=
         Integer_Type'Value (Ada.Command_Line.Argument (1));
    

The Cache array starts with element 2 since Fib (0) and Fib (1) are constants and ends with the value we want to calculate.
    
    
      [type](/wiki/Ada_Programming/Keywords/type) Cache_Array [is](/wiki/Ada_Programming/Keywords/is)
         [array](/wiki/Ada_Programming/Keywords/array) (Integer_Type [range](/wiki/Ada_Programming/Keywords/range) 2 .. Value) [of](/wiki/Ada_Programming/Keywords/of) Cache_Type;
    

The Cache is initialized to the first valid value of the cache type — this is `-1`.
    
    
      F : Cache_Array := ([others](/wiki/Ada_Programming/Keywords/others) => Cache_Type'First);
    

What follows is the actual algorithm.
    
    
      [function](/wiki/Ada_Programming/Keywords/function) Fib (N : Integer_Type) [return](/wiki/Ada_Programming/Keywords/return) Integer_Type [is](/wiki/Ada_Programming/Keywords/is)
      [begin](/wiki/Ada_Programming/Keywords/begin)
         [if](/wiki/Ada_Programming/Keywords/if) N = 0 [or](/wiki/Ada_Programming/Keywords/or) [else](/wiki/Ada_Programming/Keywords/else) N = 1 [then](/wiki/Ada_Programming/Keywords/then)
            [return](/wiki/Ada_Programming/Keywords/return) N;
         [elsif](/wiki/Ada_Programming/Keywords/elsif) F (N) /= Cache_Type'First [then](/wiki/Ada_Programming/Keywords/then)
            [return](/wiki/Ada_Programming/Keywords/return) F (N);
         [else](/wiki/Ada_Programming/Keywords/else)
            F (N) := Fib (N - 1) + Fib (N - 2);
            [return](/wiki/Ada_Programming/Keywords/return) F (N);
         [end](/wiki/Ada_Programming/Keywords/end) [if](/wiki/Ada_Programming/Keywords/if);
      [end](/wiki/Ada_Programming/Keywords/end) Fib;
    
    ...
    

This implementation is faithful to the original from the [Algorithms](/wiki/Algorithms) book. However, in Ada you would normally do it a little different:

File: fibonacci_3.adb ([view](http://wikibook-ada.svn.sourceforge.net/viewvc/wikibook-ada/trunk/demos/Source/fibonacci_3.adb?view=markup), [plain text](http://wikibook-ada.svn.sourceforge.net/viewvc/*checkout*/wikibook-ada/trunk/demos/Source/fibonacci_3.adb), [download page](https://sourceforge.net/project/showfiles.php?group_id=124904), [browse all](http://wikibook-ada.sourceforge.net/html/index.html))

when you use a slightly larger array which also stores the elements 0 and 1 and initializes them to the correct values
    
    
      [type](/wiki/Ada_Programming/Keywords/type) Cache_Array [is](/wiki/Ada_Programming/Keywords/is)
         [array](/wiki/Ada_Programming/Keywords/array) (Integer_Type [range](/wiki/Ada_Programming/Keywords/range) 0 .. Value) [of](/wiki/Ada_Programming/Keywords/of) Cache_Type;
    
      F : Cache_Array :=
         (0      => 0,
          1      => 1,
          [others](/wiki/Ada_Programming/Keywords/others) => Cache_Type'First);
    

and then you can remove the first `[if`](/wiki/Ada_Programming/Keywords/if) path.
    
    
    <strike>     [if](/wiki/Ada_Programming/Keywords/if) N = 0 [or](/wiki/Ada_Programming/Keywords/or) [else](/wiki/Ada_Programming/Keywords/else) N = 1 [then](/wiki/Ada_Programming/Keywords/then)
            [return](/wiki/Ada_Programming/Keywords/return) N;
         els</strike>[if](/wiki/Ada_Programming/Keywords/if) F (N) /= Cache_Type'First [then](/wiki/Ada_Programming/Keywords/then)
    

This will save about 45% of the execution-time (measured on Linux i686) while needing only two more elements in the cache array.

#### Memory Optimized Implementation

This version looks just like the original in WikiCode.

File: fibonacci_4.adb ([view](http://wikibook-ada.svn.sourceforge.net/viewvc/wikibook-ada/trunk/demos/Source/fibonacci_4.adb?view=markup), [plain text](http://wikibook-ada.svn.sourceforge.net/viewvc/*checkout*/wikibook-ada/trunk/demos/Source/fibonacci_4.adb), [download page](https://sourceforge.net/project/showfiles.php?group_id=124904), [browse all](http://wikibook-ada.sourceforge.net/html/index.html))
    
    
      [type](/wiki/Ada_Programming/Keywords/type) Integer_Type [is](/wiki/Ada_Programming/Keywords/is) [range](/wiki/Ada_Programming/Keywords/range) 0 .. 999_999_999_999_999_999;
    
      [function](/wiki/Ada_Programming/Keywords/function) Fib (N : Integer_Type) [return](/wiki/Ada_Programming/Keywords/return) Integer_Type [is](/wiki/Ada_Programming/Keywords/is)
         U : Integer_Type := 0;
         V : Integer_Type := 1;
      [begin](/wiki/Ada_Programming/Keywords/begin)
         [for](/wiki/Ada_Programming/Keywords/for) I [in](/wiki/Ada_Programming/Keywords/in)  2 .. N [loop](/wiki/Ada_Programming/Keywords/loop)
            Calculate_Next : [declare](/wiki/Ada_Programming/Keywords/declare)
               T : [constant](/wiki/Ada_Programming/Keywords/constant) Integer_Type := U + V;
            [begin](/wiki/Ada_Programming/Keywords/begin)
               U := V;
               V := T;
            [end](/wiki/Ada_Programming/Keywords/end) Calculate_Next;
         [end](/wiki/Ada_Programming/Keywords/end) [loop](/wiki/Ada_Programming/Keywords/loop);
         [return](/wiki/Ada_Programming/Keywords/return) V;
      [end](/wiki/Ada_Programming/Keywords/end) Fib;
    

#### No 64 bit integers

Your Ada compiler does not support 64 bit integer numbers? Then you could try to use [decimal numbers](/wiki/Ada_Programming/Types/delta) instead. Using decimal numbers results in a slower program (takes about three times as long) but the result will be the same.

The following example shows you how to define a suitable decimal type. Do experiment with the `[digits`](/wiki/Ada_Programming/Keywords/digits) and `[range`](/wiki/Ada_Programming/Keywords/range) parameters until you get the optimum out of your Ada compiler.

File: fibonacci_5.adb ([view](http://wikibook-ada.svn.sourceforge.net/viewvc/wikibook-ada/trunk/demos/Source/fibonacci_5.adb?view=markup), [plain text](http://wikibook-ada.svn.sourceforge.net/viewvc/*checkout*/wikibook-ada/trunk/demos/Source/fibonacci_5.adb), [download page](https://sourceforge.net/project/showfiles.php?group_id=124904), [browse all](http://wikibook-ada.sourceforge.net/html/index.html))
    
    
      [type](/wiki/Ada_Programming/Keywords/type) Integer_Type [is](/wiki/Ada_Programming/Keywords/is) [delta](/wiki/Ada_Programming/Keywords/delta) 1.0 [digits](/wiki/Ada_Programming/Keywords/digits) 18 [range](/wiki/Ada_Programming/Keywords/range)
         0.0 .. 999_999_999_999_999_999.0;
    

You should know that floating point numbers are unsuitable for the calculation of fibonacci numbers. They will not report an error condition when the number calculated becomes too large — instead they will lose in precision which makes the result meaningless.

  


  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

## References

  1. ↑ A (mathematical) integer larger than the largest "int" directly supported by your computer's hardware is often called a "BigInt". Working with such large numbers is often called "multiple precision arithmetic". There are entire books on the various algorithms for dealing with such numbers, such as:
    * [Modern Computer Arithmetic](http://www.loria.fr/~zimmerma/mca/pub226.html), Richard Brent and Paul Zimmermann, Cambridge University Press, 2010.
    * Donald E. Knuth, The Art of Computer Programming , Volume 2: Seminumerical Algorithms (3rd edition), 1997.
People who implement such algorithms may
    * write a one-off implementation for one particular application
    * write a library that you can use for many applications, such as [GMP, the GNU Multiple Precision Arithmetic Library](http://gmplib.org/) or [McCutchen's Big Integer Library](https://mattmccutchen.net/bigint/) or various libraries [[1]](http://www.leemon.com/crypto/BigInt.html) [[2]](https://github.com/jasondavies/jsbn) [[3]](https://github.com/libtom/libtomcrypt) [[4]](http://www.gnu.org/software/gnu-crypto/) [[5]](http://www.cryptopp.com/) used to demonstrate RSA encryption
    * put those algorithms in the compiler of a programming language that you can use (such as Python and Lisp) that automatically switches from standard integers to BigInts when necessary
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Algorithms/Print_version&oldid=2502040](http://en.wikibooks.org/w/index.php?title=Algorithms/Print_version&oldid=2502040)" 

[Categories](/wiki/Special:Categories): 

  * [Algorithms](/wiki/Category:Algorithms)
  * [Ada Programming](/wiki/Category:Ada_Programming)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Algorithms%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Algorithms%2FPrint+version)

### Namespaces

  * [Book](/wiki/Algorithms/Print_version)
  * [Discussion](/wiki/Talk:Algorithms/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Algorithms/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Algorithms/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Algorithms/Print_version&action=edit)
  * [View history](/w/index.php?title=Algorithms/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Algorithms/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Algorithms/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Algorithms/Print_version&oldid=2502040)
  * [Page information](/w/index.php?title=Algorithms/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Algorithms%2FPrint_version&id=2502040)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Algorithms%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Algorithms%2FPrint+version&oldid=2502040&writer=rl)
  * [Printable version](/w/index.php?title=Algorithms/Print_version&printable=yes)

  * This page was last modified on 15 March 2013, at 12:19.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Algorithms/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
