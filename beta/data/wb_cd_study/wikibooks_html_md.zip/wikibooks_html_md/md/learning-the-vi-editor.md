# Learning the vi Editor/Print version

From Wikibooks, open books for an open world

< [Learning the vi Editor](/wiki/Learning_the_vi_Editor)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Learning the vi Editor](/wiki/Learning_the_vi_Editor)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Learning_the_vi_Editor/Print_version&action=purge&printable=yes) this page.

  


# Learning the vi Editor[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=1)]
    
    
    This book aims to teach you how to use the **vi**
    editor, common to many Unix and Unix-like operating systems.
    ~
    ~
    ~
    ~
    ~
    "Learning_the_vi_editor" [New file].
    

The above text is a little example of how the vi editor's screen looks.

  


# Getting acquainted[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=2)]

## Introduction[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-1)]

### Overview[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-2)]

`vi` is a powerful editor that is ubiquitous amongst Unix and Unix-like operating systems, but is available on many other operating systems, even on MS-DOS, Windows and the Macintosh. If not the original vi, there is usually at least a good clone available that runs on your system. Even if you use another editor you must have a passing knowledge of vi as an administrator. Sometimes vi is the only editor available when your computer crashes leaving a minimal system for you to repair.

vi, pronounced like 'vee eye', was originally written by Bill Joy for BSD Unix in Berkeley in 1976 and became quickly part of many vendor-specific versions of the (at that time) original AT&T Unix. It was later directly added to AT&T's System V Unix, too. Bill Joy later went on to co-found [Sun Microsystems](http://www.sun.com), and became the company's Chief Scientist at that time. vi stands for _visual_ and was an enormous improvement of the classic Unix editor called **ed**. **ed** is a line-editor. If you are still familiar with MS-DOS, then you may know the MS-DOS **edlin** editor. ed is similar, although more powerful than edlin, which doesn't mean much.

vi also has a line-mode, called **ex**. In fact, one can argue that the program is indeed two editors in one, one editor called vi, another called ex. It is possible to switch between line and visual mode during editing. It is also possible to choose the mode during startup. However, pure usage of ex is rare. The visual mode is the prevailing mode.

Although vi stands for _visual_, classic vi is mainly operated via the character keys, and not via the mouse or the cursor keys. Once you are used to this, it becomes extremely convenient, because there is less movement of the hands to the cursor keys or mouse involved.

vi also served as a kind of incubator for Unix's terminal control capabilities. Because of vi's need to control the terminal and the many different types of terminals at that time, the _termcap_ (terminal-capabilities) database was introduced (later replaced with the more flexible _terminfo_ database). vi's internal high-level screen control library was later separated, and became _curses_ \- the Unix standard library for CRT screen handling.

### Conventions[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-3)]

<c>
    A single character, such as 'a' or '1'.
<ESC>, <Ctrl-[>
    Indicates that the Escape (Esc) key on your keyboard should be pressed, which is identical to Control and '['.
<CR>
    Indicates that the Return (Enter) key should be pressed.
<TAB>
    Indicates that the Tabulator key should be pressed
<Ctrl-x>, <C-x>
    Indicates that the Control key and the 'x' key should be pressed simultaneously. 'x' can be almost any other key on your keyboard.
<Shift-x>, <S-x>, <X>
    Indicates that the Shift key and the 'x' key should be pressed simultaneously
<Meta-x>, <M-x>
    Indicates that the Meta or Alt key and the 'x' key should be pressed simultaneously.
:quit, :q
    An Ex command. started with <:>, followed by the command and ends with <CR>. For many Ex commands there is a long form (:quit) and a short form (:q).
:set **nocompatible** 
    represents a setting.
**strlen** () 
    represents a function.
/_pattern_/, ?_pattern_?
    A Search pattern. Search pattern in vi are [regular expressions](//en.wikipedia.org/wiki/regular_expression).
:_range_s/_search_/_replace_/_options_, :global /_pattern_/ delete
    A Search pattern combined with an Ex command.

All commands in _vi_ are case sensitive.

  
**unix-command**(section)

    Sometimes references to Unix commands are used in this book. On first occurrence such a name of a command is written in the typical Unix style. This style consists of the command's name followed by the section of the manual pages in which the command description can be found, in brackets. E.g. **sed**(1) refers to Unix's **sed** command which is usually documented in section 1 of the Unix manual pages (sed is the Unix stream editor; a tool for manipulating text without user interaction).

## Getting vi if you don't have it already[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-4)]

If you're running a Unix system, or a Unix-like system (for simplicity from now on we will refer to both as a "Unix system"), such as a BSD or Linux distribution, or even Mac OS X, you're sure to have vi or one of its variants on your system.

If you're running Windows, you can get a version of vi called ["vim"](http://www.vim.org) or ["elvis"](http://elvis.the-little-red-haired-girl.org/whatiselvis/). If you're on an older Mac OS (pre-OS X) system, you can get MacVim Classic [here](http://macvim.swdev.org/MacClassic/).

### Noted vi variants[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-5)]

As mentioned, vi has a number of variants. They have been created because vi was only available on rather expensive Unix operating systems. Although vi itself, as well as nvi, was created in Berkeley for the free BSD Unix variant, usage of BSD Unix required an original AT&T Unix license (this has later changed, see below). Original vi, for example, used code from AT&T's **ed**_(1)_ editor.

Over time, BSD replaced many of the original AT&T code up to the point where today there is no such code any more in BSD, and an original Unix license is no longer needed. As part of the effort to replace all AT&T code in BSD, Keith Bostic undertook the work to create a clone of vi that was free of AT&T code, called nvi. nvi then became BSD's standard vi instead of the original vi. Another vi clone is Elvis, which was written by Steve Kirkendal.

Over time, nvi was enhanced – for example, supporting multiple windows – but originally it was not supposed to be an enhancement, 'just' a pure clone.

BSD's original vi (with the ed code inside) lives on as the vi which is distributed with System V Unix, because AT&T decided a long time ago to take it from BSD and add it to the official Unix. Of course AT&T didn't have a problem with an AT&T Unix license, so they probably never replaced the ed code inside the original vi.

Yet, some find nvi still to be too minimal, and so vim was born. **vim** (vi-i_m_proved), is another effort to extend vi's capabilities. Unlike nvi, vim goes even further to extend vi's capabilities. However some find that vim is often too much. vim comes in two variants, a text-only version, and a GUI version, the latter is called **gvim**.

Other vi clones are the already mentioned **elvis** and **stevie**. These clones were born in the CP/M and home computer area to bring the editor to these platforms, too. Of course, they were later ported to MS-DOS and Windows. These days, however, **vim** seems to be the prevailing vi-clone on free/open platforms and proprietary platforms as well.

_You should choose the version you feel most comfortable with_ – if you have an editor you feel displeased with, it will affect your productivity.

## Getting around vi[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-6)]

### Starting the editor[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-7)]

If you are running a Unix system, you can start up vi by typing
    
    
     vi<CR>
    

at the command line. If you are running X, with a desktop like GNOME, KDE, CDE/Motif or OpenLook you may have a launcher button handy to start the editor - if you have such a setup, you can just click the icon.

If you are running Windows or DOS with elvis, you can start up the Windows editor by double-clicking "winelvis.exe", or in DOS, you can start the editor by typing in "elvis" at the command line.

You will be greeted with a screen similar to:
    
    
    ~
    ~
    ~
    ~
    ~
    ~
    "No File"
    

### Quitting the editor[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-8)]

To quit for now, press the Escape key (the editor should beep), then enter the three characters :q! and press Return:
    
    
    <ESC>:q!<CR>
    

Just before you type the final <CR> the screen will look similar to
    
    
    ~
    ~
    ~
    ~
    ~
    ~
    :q!
    

:q! is the short form of :quit! which quits the editor.

You should be dropped back to your operating system (or, rather, the shell from where you started).

There are other ways to quit, e.g. pressing <Z><Z> (<Shift-z><Shift-z>) will save any unsaved work and quit the editor. Typing :wq will always save, even if there are no unsaved changes, and then quit the editor. :x will write if there are no unsaved changes, and it will quit. :wq and :x requires that you had previously provided a file name, so it will not work for the above simple example. Typing :q will quit if there have been no changes made; if changes have been made, vi will print a warning similar to "No write since last change".

### Don't worry[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-9)]

Many first time vi users stop at this point, and never touch vi again. If you tried to enter some text after you started, you will most likely have been greeted with a series of beeps and rather erratic behavior. Don't worry. This is perfectly normal for vi, and the editor is not broken. You will soon see why this is normal vi behaviour.

## Continue[[edit](/w/index.php?title=Learning_the_vi_Editor/Getting_acquainted&action=edit&section=T-10)]

Now that you know how to start the editor and quit it, let's move on to getting things done in `vi`: see [Learning the vi Editor/Basic tasks](/wiki/Learning_the_vi_Editor/Basic_tasks)

  


# Basic tasks[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=3)]

Now that we know how to invoke the editor and quit it, we can get acquainted with how to _use_ the editor.

Alternatively, you can use the ViM tutor which comes with many modern vim distributions. It contains, essentially the same information as the text below. You can invoke the tutor by entering **vimtutor** at your shell.

## Vi is a _modal_ editor[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-1)]

The vi editor can do two things:

  * accept a command, such as deleting a line
  * accept text, written by you

In the vi editor, each of these tasks is achieved by putting the editor into a particular mode of operation (normally just called a _mode_). When you wish to give vi a command, you enter _command mode_, and when you want to enter text, you enter _insert mode_. We'll cover how to do this below.

It is important to set the correct mode before you begin writing, but this is simple to do. When you first start vi, it is automatically in command mode.

## Entering text[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-2)]

Entering text is the most basic task an editor can do! From command mode (in which the editor starts), press `i` to enter _insert mode_, and you can begin typing. You can use the backspace key to correct mistakes you make. If you make a mistake after a few sentences, leave these errors for now, we will look at correcting them later. To leave insert mode once you're done typing, and return to command mode, press the Escape key on your keyboard (or type Control-[).

### Exercise[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-3)]

Let's have an exercise:

  1. Start the editor.
  2. Enter insert mode.
  3. Type some text
  4. Return to command mode.
  5. Quit the editor.

### Solution[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-4)]

  1. We can start the editor as in the previous section.
  2. Since the editor starts in command mode, we must press the <i> key before we can start typing.
  3. You can make some text up yourself!
  4. Press the <Escape> key.
  5. If you want to quit the editor, you need to be in command mode. Since pressing Escape puts you in command mode, you can just use the method in the previous section to exit: type :q!

## Command mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-5)]

Command mode allows you to perform many useful tasks within vi.

### Moving around[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-6)]

Say you have been writing for some time, and have forgotten something. Pressing <Backspace>, _erasing_ previous work is not the best solution! We would like to move around the document freely, moving the cursor.

  


We can move around in the editor by first entering command mode, and then using the <h>, <j>, <k>, and <l> keys.

Note
    your arrow keys may be set up to work, and you can use them if you like, but for proficiency and for advanced work later, you should learn to use the letter keys.

  * The <h> key, in command mode, moves the cursor one character **left**.
  * The <j> key, in command mode, moves the cursor one character **down**.
  * The <k> key, in command mode, moves the cursor one character **up**.
  * The <l> key, in command mode, moves the cursor one character **right**.

If you have trouble remembering this, keep in mind that <h> is leftmost, the letter <j>goes down below the line, the letter <k>pokes up above the line, and the <l> key is rightmost. (J also resembles an arrow pointing downward, if you squint a bit.)

After you have moved the cursor using those keys, you can enter insert mode again by pressing <i>. When you do this, you insert text at the cursor, inserting text between the character to the **left** of the cursor and the **current** position of the cursor. Let's practice this in an exercise.

  


#### Exercise[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-7)]

You can repeat this exercise with your own sentences. Make sure you are proficient doing this before you continue.

  1. Start the editor.
  2. Enter the text: "The quick fox jumps over the dog"
  3. Insert the word "brown" between "quick" and "fox".
  4. Insert the word "lazy" between "the" and "dog".
  5. Quit the editor.

#### Solution[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-8)]

  1. Use the method in the previous section.
  2. Press <i>, then enter `The quick fox jumps over the dog` normally.
  3. Press <Escape>, then press <h> until the cursor is at the letter "f" of "fox". Press <i>, and then type "brown ".
  4. Press <Escape>, then press <l> until the cursor is at the letter "d". Press <i>, and then type "lazy ".
  5. Press <Escape> again, then type :quit!.

### More on movement[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-9)]

Using `h`, `j`, `k`, and `l` is ok, but vi understands more than rows and columns. These are some commands that move by text objects:

  * `w` moves forward to the beginning of the next word.
  * `b` moves backwards to the beginning of the previous word.
  * `(` and `)` move by sentences, either backward or forward.
  * `{` and `}` move by paragraphs.

### Deleting things[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-10)]

If you have made a mistake after a few lines, for instance, pressing Backspace until you have erased the mistake and starting again isn't always the best solution. We need a method of deleting mistakes that happen in the normal course of editing.

vi allows you several methods of deleting text, based on how much you want to remove. Now that you are familiar with moving around, once you've moved the cursor to where your error is:

  * the `x` key deletes _one_ character
  * pressing `dw` deletes _one_ word.
  * pressing `dd` deletes _one_ line

#### Exercise[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-11)]

From now on, we will omit the steps for you to start and quit the editor - you should be already familiar with those.

  1. Enter the following text: `Sad I been here, I wouldnt ever ever leave.`
  2. Change the word "Sad" to "Had".
  3. Add an apostrophe after "wouldn".
  4. Delete the extra "ever".
  5. Delete the line.

#### Solution[[edit](/w/index.php?title=Learning_the_vi_Editor/Basic_tasks&action=edit&section=T-12)]

  1. Type the text normally. (You should already be familiar with entering insert mode and leaving it.)
  2. Enter command mode, use `h` to move to the start of the line, and then press `x` to delete the "S". Press `i` to enter insert mode, insert the "H", then leave insert mode by pressing Escape.
  3. Now position the cursor on the t, and press `i` to enter insert mode, type the " ' ". Leave insert mode by pressing escape.
  4. Position the cursor over the first "e" in the word "ever" (choose whichever one you like). Type `dw` to delete the word.
  5. Type `dd` to remove the entire line.

  


# Making your work easier[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=4)]

By now you should know the rudiments of using `vi`. However, to really make `vi` work for you, it may be helpful to know the following to make your work easier for you.

## More on commands[[edit](/w/index.php?title=Learning_the_vi_Editor/Making_your_work_easier&action=edit&section=T-1)]

Say you are editing a document, and you wish to delete ten lines - as of now, the only way to do this is to enter `dd` ten times. Or if you want to delete seven characters exactly - you would have to enter `x` seven times. There must be a better way!

### Repetition[[edit](/w/index.php?title=Learning_the_vi_Editor/Making_your_work_easier&action=edit&section=T-2)]

Fortunately, vi lets you augment most of the commands in case you want to repeat that command a certain number of times. This is done by typing in the number of times you want that command repeated, followed by the command.

So, if you want to delete ten lines, you would type `10dd`. Or if you want to delete seven characters, you would type `7x`.

You can also repeat the last action done by typing `.` (this is a single period keystroke), the single-repeat operation over the location you want to repeat the previous operation.

So if you wanted to repeat the deletion of ten lines as in the previous example, you could repeatedly press `.` to perform this operation over and over again.

#### Exercise[[edit](/w/index.php?title=Learning_the_vi_Editor/Making_your_work_easier&action=edit&section=T-3)]

1\. Type the sentence `Good morning Doctor, how are you today?`. Delete "Good morning".

2\. Now using the single-repeat operation, delete "how are".

### Motion[[edit](/w/index.php?title=Learning_the_vi_Editor/Making_your_work_easier&action=edit&section=T-4)]

vi allows you greater flexibility over motion as well. There are a few commands to allow you to quickly jump around your document, such as :

  * `0` moves to the immediate beginning of the line
  * `$` moves to the immediate end of the line
  * `^` moves to the first non-whitespace character of the line

`^` acts in the following way, if the line was
    
    
                hello how are you
    

and your cursor is on the u, if you would enter `^`, the cursor would be upon the h.

Furthermore, the `/` command allows you to jump directly to some pattern in the file. For example, if you're looking for the next occurrence of the word "pomegranate" in your text, if you hit `/`, then type in pomegranate (you need not enter insert mode) and hit enter, the cursor will jump to the next occurrence of the word, if it exists. If you want to search backwards, you would perform the same procedure, but use the `?` command. To repeat either search, enter `//`, `??`, or alternatively, type `/` or `?` and hit Enter.

#### Commands and motion[[edit](/w/index.php?title=Learning_the_vi_Editor/Making_your_work_easier&action=edit&section=T-5)]

We know now that vi lets you enter a number to specify how many times to do something. Consider this example now: you want to delete everything after a certain point on a line - you could enter `dw` for each word from the cursor position to the end of the line, or hold down `x`, but these are cumbersome examples. vi thankfully lets you do something much faster.

With certain commands, vi allows you to specify a position, using the methods in the previous sections. The position is specified after the command. For example, to delete up to the end of the line, you would enter `d$`.

Other examples:

  * `dt;` will delete until the next semicolon (This is helpful in languages like C and perl that use semicolons to finish statements).
  * `d2}` to delete the next two paragraphs.
  * `d4b` to delete the previous four words (alternatively, you could enter `4b4dw`).

  


# Advanced tasks[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=5)]

## Copying and Pasting[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-1)]

Copying and pasting tasks are done with three keys, <y> (for "yank"), <d> (for "delete"), and <p> (for "paste"). In general, you type <y> or <d> to tell vi that you're at the position where you want to start yanking or deleting some text. Then you need to tell vi where to stop, using cursor movement or other commands.

You can also simply use key <v> to enter a visual mode. Then you can highlight text by moving cursor keys. And finally press <y> to copy text to clipboard. And <p> for paste.

### A Word[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-2)]

To delete a single word, move your cursor to the first letter, then type <d><w>. To yank a single word, move your cursor to the first letter, then type <y><w>.

#### Other Methods[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-3)]

Move to the character past the last letter and type <d> <b>.

To delete a word like "can't", which has an apostrophe, move to the first character and type <d><W>. Note the capital W. This tells vi to go all the way to the first whitespace character after the word.

Likewise, try dB.

### A Line[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-4)]

To delete a single line, type <d><d>.

### Other Amounts[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-5)]

One of the great things about vi is that it lets you select a bunch of text without having to move your hand to your mouse.

Type <m><a>. This will mark the current position that your cursor is at as mark **a**. You can go back to this position anytime you want from now on by typing <`><a>. (`a means "move to the character that has been marked as **a**")

Now move to some other position. Type <d><`><a>. This will delete everything from the current position to the position you marked as **a**.

Note that you can use nearly any key in place of the <a> used in this example. For instance, you might use <m><t> to mark the _top_ of a section, or <m><b> to mark the _bottom_. These mnemonics are strictly in the user's head - vi doesn't care that _t_ means _top_ or _b_ means bottom. Vi will remember all unique bookmarks, allowing the user to easily and quickly jump between them. Some users find using <m><m> to be a convenient temporary bookmark, because it can be typed so quickly.

#### To the end or beginning of a line[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-6)]

<d><$> or <d><^>

#### To the end or beginning of the file[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-7)]

<d><G> or <d><1><G>

#### To the next occurrence of a pattern[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-8)]

<d>/myPattern

This is particularly useful when editing HTML files with d/<

## Adjusting the Screen[[edit](/w/index.php?title=Learning_the_vi_Editor/Advanced_tasks&action=edit&section=T-9)]

vi, as a visual screen-oriented editor has a number of useful commands to redraw or adjust the screen in case you find yourself somewhere where you don't want to be.

If you run in a Unix shell, it is possible that some background process writes to the same terminal. This will disturb vi's screen layout. In order to force vi to redraw the complete screen, press <Ctrl-L> or <Ctrl-R>. Both commands do the same.

If you want to adjust what is currently displayed, then the <z> command is rather useful. It's a kind of Swiss army knife, and has a rather complex syntax:
    
    
       [/_pattern_/][_m_]z[_n_](<CR>|.|-)
    

([ ... ] denotes optional items, (...|...) denotes alternatives)

Before we explain the syntax in detail, here are some common applications of the command:

Scroll the screen so the current line becomes the middle line of the screen. The cursor remains on that line:
    
    
       <z><.>   
    

Scroll the screen so the current line becomes the top line on the screen:
    
    
       <z><CR>
    

Scroll the screen, so the current line becomes the bottom line of the screen
    
    
       <z><->
    

If a `/_pattern_/` or a number _m_ is given the cursor is moved further after the adjustment. `/_pattern_/` indicates to move the cursor to the first match of that pattern. _m_ indicates to move the cursor to the _m_th line on the screen. So, for example,
    
    
       /while/z<CR>
    

would first scroll the screen so the current line becomes the top line on the screen, and then move the cursor to the first 'while' in the text from that position on.

The number _n_ is a rather obscure parameter. If provided, it tells vi to behave as if the screen is just _n_ lines high. The result is that only _n_ number of lines are adjusted, and the rest of the screen is either ignored or cleared, presumably useful on slow terminals to avoid redrawing the screen unneccessarily.

  


# Details[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=6)]

This section describes some of the details of the vi program itself (such as command line features), and other advanced vi features for aspiring vi power users.

## Command line invocation[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-1)]

Different vi clones of course have different ways of starting the program (invocation). Usually, however, command-line versions of vi share a common basic set of command line options. These following command line options and flags are typically available. In addition, vi can be started under different names. Depending on the name used to start vi, it may either behave slightly differently or load a different vi clone.

  
The common command line options and flags are

-

or

-s
    Suppress. All interactive user feedback is suppressed (not written to the terminal). This allows to pipe editing commands through the editor, and use it as a kind of stream editor. There are probably better streaming editor tools on Unix, like **sed**(1), **awk**(1), or **Perl**(n).

    Note, "-" is a common Unix notation to indicate standard input. It has been chosen as an alternative to `-s` by the vi authors to provide a familiar look when piping commands. It does not really mean 'read from standard input' since vi does that anyhow.

-C
    En_c_ryption. vi prompts the user for a key (a kind of password), and uses this key to encrypt its files before writing. It also uses this key to decrypt any file opened with vi. This feature is not supported by many clones, and the encryption algorithm is a very weak one (it is based on a 256-element one-rotor algorithm). The algorithm is easy to crack. It is compatible with the Unix **crypt**(1) command. See also `-x`.

-l
    (lower-case letter L) Change some default settings so they are more useful for editing LISP source code.

-L
    (upper case letter L) Lists all files which have been saved during a crash. See `-r`, too.

-r _filename_
    Recover the file _filename_ after a crash. Use `-L` to get a list of files which can be recovered.

-R
    Readonly. Files can only be viewed, not written.

-S
    Tags are not sorted. When a _tag_ file is used, this flag tells vi that the tag file is not sorted, therefore vi will use a slower algorithm to look up tags. See `-t`, too.

-t _tag_
    Edit (open) that file which contains the given _tag_. This of course requires that a tag file (called _tags_) is available.

-v
    Start in visual mode. Only useful if the editor is started under the name **ex** and not **vi**.

-V
    Verbose. Commands read via standard input are echoed to standard error. This is useful for debugging when the editor is used as a streaming editor.

-w_number_
    Window size. Set the editor's number of lines to _number_. vi behaves as if the terminal has only _number_ number of lines. This was used in the old days to speed up things when connecting via a slow terminal or modem line.

-x
    Encryption. Similar to `-C`. The difference is that vi tries to guess if a file that is opened needs decryption or not. `-C` on the other hand always runs the decryption when a file is opened.

+_command_

or

-c _command_
    Execute the command _command_ before allowing the user to enter own commands. The most common usage is to use this to position the editor at some specific line in a file. E.g.
    
    
    vi +10 list.txt
    

    will open the file `list.txt` and position the cursor at line 10. Another common usage is to specify a pattern:
    
    
    vi +/END script.awk
    

    This will open the file `script.awk` and position the cursor at the first occurrence of the pattern 'END'.

As already mentioned, vi can be started using different names (all may not be available depending on the particular clone):

vi
    The usual way to start vi.

view
    vi starts in read-only mode.

vedit
    A few settings are changed to better suit beginners: _magic_ is cleared, _showmode_ and _novice_ are set, and _report_ is set to 1.

ex -v
    Same as just typing `vi`

## Commands: Objects & Operators[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-2)]

### General[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-3)]

Until now, this tutorial has just talked about commands, and that commands can be used in conjunction with things like word counts. E.g. `d2w` has been explained as the operator `d`elete applied to two words. Note the `2w` part. You have learned that this part specifies to which text the operator should apply. And indeed, the `2w` part specifies to which objects of the text (words, lines, characters etc.) the operator is supposed to be applied. And you have seen that the same object specifiers can be used with all types of operators - as long as the combination makes sense.

vi commands in fact follow a general schema. Commands are made up from operators and objects:
    
    
       [[_count_] **operator**] [[_number_] **object**]
    

This means the _operator_ should be executed _count_ times on _number_ of _object_s. Almost all parts are optional. Also, some operators don't take objects at all. This operator/operation syntax is vi's heart. It is why people either love or hate vi. People love it, because it is such a simple schema. Once one knows the few operators (not more than ten), and a few of the objects one can be very productive in vi. People who hate vi simply can't get this schema, and the fact that there is a difference between command and insert mode, into their heads.

### Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-4)]

We told you that things like the `w` command moves one word. We actually cheated a little bit when telling you this. There is no such thing as a `w` command. `w` is an object specification, not a command. The object specification was given without an explicit operator like `d`. In such a case vi uses the implicit default operator. And that operator is _move_.

Whenever you use an object specification without an operator, the operator _move_ will be used. Therefore, object specifiers degrade to move commands. The following is a list and summary of all object specifier. Logically, you can use them in conjunction with operators, or to move around if used stand-alone. You have seen a few of them already:

#### Paragraph, Section, Sentence Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-5)]

}
    Everything until next paragraph end.

{
    Everything until previous paragraph end.

]]
    [Everything until next section end.]
[[
    [Everything until previous section end.]

)
    Everything until next sentence end.

(
    Everything until previous sentence end.

#### Line Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-6)]

[_number_]G
    Everything until line _number_. If _number_ is omitted, last (not first) line in file. The first line can be addressed as `1G` instead.

[_number_]H
    _number_ of lines after the first line currently on screen. If number is not given, the first line on the screen.

[_number_]L
    _number_ of lines before the last line currently on screen. If number is not given, the last line on the screen.

M
    The middle line of the screen.

j
    One line down from current line.

k
    One line up from current line.

_
    (underscore) The current line as a whole.

#### Positions within Lines[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-7)]

0
    (Digit 0). Backward to first column of line. Same as `1|` (not `0|`).

^
    Backward to first non-whitespace character.

$
    Forward to end of line.

[_number_]|
    Column _number_ of the current line. If number is not given, column 1 is used.

t_char_
    Before the next appearance of character _char_ on the current line.

T_char_
    Backwards after the next appearance of character _char_ on the current line.

f_char_
    Next appearance of character _char_ on the current line.

F_char_
    Previous appearance of character _char_ on the current line.

 ;
    Repetition of the last `t`, `T`, `f`, or `F` command.

,
    Repetition of the last `t`, `T`, `f`, or `F` command, but in opposite direction.

+

or

<CR>
    To the first non-whitespace character on the next line.

-
    To first non-whitespace character on the previous line.

  


#### Word Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-8)]

w
    Forward to next begin of a word.

e
    Forward to next end of a word.

b
    Backwards to next begin of a word.

#### Character Object[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-9)]

h

or

<BS>
    Left character.

l

or

<SPACE>
    (lower-case letter L or space) Right character.

  


#### Pattern Matching Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-10)]

/_pattern_/ 
    Forward to the beginning of the first match of pattern _pattern_.
?_pattern_? 
    Backwards to the beginning of the first match of pattern _pattern_.
<n> 
    Repeat the last `/` or `?`.
<N> 
    Repeat the last `/` or `?` in opposite direction.
<%> 
    To next matching (, {, or [.

### Operators[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-11)]

The previously listed objects can be used as arguments to operators. If no operator is given, the default _move_ operator is used. The number of operators in vi is surprisingly small - ten in total. Here is a list of the operators:

_needs better descriptions, a few of them are separately described later in this module_

#### Operators taking Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-12)]

c 
    change - change the addressed objects. In fact, the text is replaced by what is typed in.

d 
    delete - delete the addressed objects. The deleted text is placed in the undo buffer.

y 
    yank - copy the text of the addressed objects into the buffer.

< 
    shift left - object arguments can only be objects which address lines Indenting and Shifting.

> 
    shift right - object arguments can only be objects which address lines Indenting and Shifting.

 ! 
    _bang_ filter-through - filter lines through an external program. Objects can only be objects addressing lines Filtering (stub).

#### Operators not taking Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-13)]

r, s,

x 
    Delete character. Use the _d_ operator for deleting other objects than characters.

~ 
    Flip case of character at cursor position. An uppercase letter becomes its lowercase equivalent, and a lowercase letter becomes its uppercase equivalent.

#### Special Operator Forms[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-14)]

There are two special forms when typing an operator:

  1. Typing the character in upper-case, instead of lower-case. E.g. `Y` instead of `y` , and
  2. doubling the character. E.g. `yy` instead of `y`.

## 'Strange' lines on the screen[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-15)]

vi was written at a time when terminal or modem connections were slow. Therefore, vi used several optimisation techniques to limit the need for redrawing the whole screen. In such cases, vi used to display lines beginning with a special marker. Modern vi's seldom have the need for such performance optimizations any more, but they still have the habit to display such lines.

There are two special markers used:
    
    
    ~_line_
    

A leading '~' indicates that the line is past the end of the file (non-existent). This can be observed, for example, when vi is started on a new or empty file.
    
    
    @_line_
    

The line is only on the screen, not in the file. This happens for deleted lines. If _wrap_ is enabled (the default), this also happens for lines that are too long to show on the screen all at once.

## Indenting and shifting[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-16)]

vi supports auto-indentation of text lines and also provides command for manual indentation. This is useful when editing program source code. It is a common convention in many programming languages to use indentation to increase readability of the source code.

### Options[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-17)]

The option `shiftwidth` (sw) determines how much space is used for indentation. E.g.
    
    
    <ESC>:set shiftwidth=4<CR>
    

or
    
    
    <ESC>:set sw=4<CR>
    

tells vi to use four spaces for indentation.

The option [`no`]`autoindent` (ai) tells vi to use auto identation or not. Auto indentation is turned on by
    
    
    <ESC>:set autoindent<CR>
    

or
    
    
    <ESC>:set ai<CR>
    

And it is turned off by
    
    
    <ESC>:set noautoindent<CR>
    

or
    
    
    <ESC>:set noai<CR>
    

### Command Mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-18)]

Shifting lines is done with the < and > commands. < moves the text one `shiftwidth` to the left (outdenting), while > moves the text one `shiftwidth` to the right (indenting). The number of lines which can be affected are specified in vi's typical way. However, only _objects_ which identify lines, and not _objects_ which identify words or individual characters can be used.

E.g.
    
    
    >G
    

moves all lines from the current line until the end of the file to the right.

Or
    
    
    <}
    

moves all lines from the current line until the end of the paragraph to the left. Of course, the shift commands can be used in conjunction with `%`, which indicates the next opening bracket. E.g. to shift the lines encompassing the current cursor position up to the first line with a matching (, {, or [ to the left one would type:
    
    
    <%
    

Like with all commands it is also possible to specify a line count:

[_number_]<<

or

<[_number_]<
    Moves _number_ of lines, starting at the current line, one `shiftwidth` to the left (outdenting). If _number_ is not given, 1 is assumed - this leads to the shifting of the current line to the left.

[_number_]>>

or

>[_number_]>
    Moves _number_ of lines, starting at the current line, one `shiftwidth` to the right (indenting). If _number_ is not given, 1 is assumed - this leads to the shifting of the current line to the right.

The < and > commands can also be used with a marker. In this case, the reference to the marker is placed between the two characters of the command:

<'m<
    Shifts the lines from the marker _m_ up and including the current line to the left.

>'m>
    Shifts the lines from the marker _m_ up and including the current line to the right.

### Insert Mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-19)]

^t
    Moves _shiftwidth_ to the right. Note, it is a common mistake to use the <TAB> key instead of `^t`. <TAB> inserts a Ctrl-I character and moves to the next multiple of _tabstop_, and not to _shiftwidth_. So <TAB> only works if _tabstop_ and _shiftwidth_ are set to the same value.

    Since it is not a good idea to set _tabstop_ to anything else than 8, <TAB> can only be used instead of `^t` for indenting when _shiftwidth_ is also set to 8.

^d
    In autoindent mode, backtabs one _shiftwidth_. E.g. if autoindent is on, and one wants to enter the follwing text:
    
    
    if(true) {
        printf("done"); // start sw indent
        return;
    } // bracket moved back to the left
    

    one would type
    
    
    if(true) {<CR>
    **^t**printf("done"); // start sw indent<CR>
    return;<CR>
    **^d**} // bracket moved back to the left<CR>
    

There are some special variants of `^d`, too:

^^d
    (the letter _^_ followed by Ctrl-D). When this is typed first on a new line, all autoindent is killed (the insertion point is moved to the beginning of the line). Autoindent is then continued on the next line.

    E.g. to enter the following text when using autoindenting
    
    
            an indented paragraph
            another line in the indented paragraph
    .F roff formating commands have to start at column one with a '.'
            more text in the indented paragraph
    

one would type
    
    
    **^t**an indented paragraph<CR>
    another line in the indented paragraph<CR>
    **^^d**.F roff formating commands have to start at column one with a '.'<CR>
    more text in the indented paragraph<CR>
    

0^d
    (the digit _0_ followed by Ctrl-D). Kills all autoindent (moves cursor to the beginning of the line), and leaves autoindent off, until text is once manually indented (using `^t`).

    E.g. to enter the following text when using autoindenting
    
    
         INTEGER FUNCTION FAC(N)
         FAC = 1
         DO 100 I = 2, N
              FAC = I * FAC
    C
    C PROVIDE LABEL TO END LOOP
    C A HINT FOR THOSE GRASSHOPPERS: THIS IS FORTRAN CODE :-)
    C
    100  CONTINUE
         RETURN
         END
       
    

    one would type
    
    
    <ESC>:set sw=5<CR>
    o**^t**INTEGER FUNCTION FAC(N)<CR>
    FAC = 1<CR>
    DO 100 I = 2, N<CR>
    **^t**FAC = I * FAC<CR>
    **0^d**C<CR>
    C PROVIDE LABEL TO END LOOP<CR>
    C A HINT FOR THOSE GRASSHOPPERS: THIS IS FORTRAN CODE :-)<CR>
    C<CR>
    100  CONTINUE<CR>
    **^t**RETURN<CR>
    END<CR>
    

## Modelines[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-20)]

Modelines are lines in text files which are specially interpreted by vi when such a text file is opened. When the `modeline` (`ml`) (in some version of vi also called `modelines`) option is turned on (e.g. in the users `.exrc` file), vi scans the first and last five lines of each opened file for text of the form
    
    
    _unrelated text_ vi:_command_: _more unrelated text_
    

or
    
    
    _unrelated text_ ex:_command_: _more unrelated text_
    

Each _command_ from such lines is taken and executed as it would have been typed by the user. Any text in front of the modeline-marker (`vi:` or `ex:`) or behind the closing : is ignored for the modeline interpretation. This can be used to place modelines in comments if they are used in some programming source code.

Here is an example Java source code file. It contains a modeline on the second and third line, in a Java comment:
    
    
    /* 
     * vi:set sw=4 ai:
     * vi:set showmatch: 
     */  
    package gnu.freesoftware;
    public class Interpreter {
        public Interpreter() ...
             ...
    

When modelines are turned on, and this file is opened, `shiftwidth` (`sw`) is set to 4, `autoindent` (`ai`) is turned on, and the `showmatch` (`sm`) option is turned on, too. There is no particular reason why two `set` commands on two modelines are used other than to demonstrate that all modeline commands found in the first and last five lines are executed, and not just the first.

Modelines can be used to play some practical jokes. E.g., a file with the modeline
    
    
    vi:q!:
    

immediately closes the editor and makes it impossible to edit the file as long as modelines are turned on.

Modelines get outright dangerous if they mess with system files. E.g., if the super user (administrator) of a Unix system has modelines turned on, and is tricked into opening a file with the following modeline, the important Unix password file is overwritten with the contents of the opened file:
    
    
    vi:2,$w! /etc/passwd:
    root:A shiny new root password:0:0:System Administrator:/:/bin/sh
    anotheruser:Another shiny new password:1:0:Just another user:/home/anotheruser:/bin/sh
    

Therefore modelines should only be turned on in a controlled environment. This is sad, since in principle it is a nice idea that files are able to provide the editor with a configuration best suited to edit that file.

There are some other problems with modelines. Classic vi versions always set a file's status to _modified_ if they find a modeline, even if no editing in the file has taken place. This forces the user to leave the editor with `:q!` instead of just `:q`. If instead `ZZ` is used to leave, the file is written. This causes tools like **make** to think the file has changed if it in fact hasn't.

## _.exrc_ Configuration File[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-21)]

_This module is a stub. You can help Wikibooks by [fixing it](/wiki/Wikibooks:Find_or_fix_a_stub)._ For a start:

.exrc files are files containing vi (and ex) configuration data. The format of the data in such a file is that of ex commands, without the leading ':' (column). Typically, .exrc files are used to load some default mappings (map and map! ex commands) or define particular defaults. E.g. the following .exrc file would set autoindent and the shiftwidth when vi is started:
    
    
    set ai
    set sw=4
    

Normally, a .exrc file is placed in the user's home directory. Since the file name starts with a '.', the file is hidden under Unix-like operating systems. It is possible to place .exrc files in other directories, too. Vi can read the .exrc file in the current directory from which it is started. However, this feature is considered a security risk and turned off by default. It is considered a risk, because similar jokes can be played with .exrc files as with what has been described for modelines. The .exrc file in a user's home directory is considered safe, because on a correctly configured Unix system only the particular user should have write access to it.

There are three important things which should be observed when working with a classic vi and .exrc files:

  1. .exrc files must not contain empty lines. Classic vi chokes on these lines with all kinds of cryptic error messages.
  2. There is no official way to place a comment in .exrc files. However, since the beginning of time the following hack is used and is known to work: A line which starts with a " (quotation character) is ignored by vi.
  3. Classic vi is very picky about map and map! commands. Definitions which by all means should work can trigger strange error messages. This is due to classic vi's limited parser and interpreter for such definitions. Spliting a map or map1 command in several smaller ones can sometimes help.

Many clones have relaxed these rules by allowing empty lines in an .exrc file, and by officially specifying the " as the comment character. Also, good clones should have no problem with map or map! specifications.
    
    
    "
    " This is a comment in an .exrc file
    " A .exrc file must not contain empty lines, so
    " comment lines need to be used to separate entries
    "
    set sm
    set sw=8
    "
    set wm=8
    "
    " map 'g' to go to begin of file
    map g 1G
    " rcs check-out (/co) and check-in (/ci)
    map /co :w! %.co.bak^M:!co -l %^M:e!
    map /ci :w^M:!ci -u %^M:e!^M
    "
    " Abbreviations
    ab Lx Linux
    

## Tags[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-22)]

### Overview[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-23)]

Vi can use so called _tag files_ (or _tags_) to allow for quick navigation (jump) to "interesting" information in a set of files. The most common usage for this is to navigate within source code files. E.g. to jump from the usage of a certain function to the function's definition, possibly in another file.

The mechanism is relatively simple. You tell vi to go to a particular tag. vi looks up the file in which the tag can be found, opens that file and jumps to the location of the tag in that file. In order to find the file and position of a tag, vi consults a _tag file_. A _tag file_ contains an index of tags. A tag is an item (e.g. some programming language object) for which such an index entry can be found in a tag file. When vi is asked to jump to a particular tag, vi looks up the index entry for that tag, and uses the information to jump to the particular item.

In order to use this feature one first has to create a tag file, or a set of tag files, containing entries for all potentially interesting items. These tag file or files then need to be made known to vi - if the default file name is not used. This can e.g. be done by having appropriate commands in an `.exrc` file.

Modern IDEs provide similar navigation features, but without the need to build a tag file separately. IDEs build the necessary index on-the-fly or use fast brute-force full-text search algorithms. The need for the extra step of creating a tag file for vi is annoying by modern standards. Still, vi's tag file system works and is usable.

### Tag File Format, Creation & ctags(1)[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-24)]

The creation of a tag file typically requires to use a tool which analyses the input text files (e.g. programming source code) and generates entries for each item of interest found in the input text file. The most common tool is called **ctags**(1) and is a standard Unix program. Several vi clones come with own versions of ctags, sometimes called differently.

ctags knows the syntax of a number of programming languages and generates index information for items like function names, and macro definitions.

In case ctags is not available, or the available version of ctags does not support the programming language in use it is also possible to generate tag files with text processing tools like **awk**(1), **sed**(1) or **perl**(n) and some clever scripts, because tag files are ASCII files.

Typically an entry in a tag file looks like
    
    
     _tag-name_<TAB>_file-name_<TAB>_ex-command_
    

_tag-name_
    The name of the item. E.g. a function name or macro name.

_file-name_
    The name of the file in which the _tag-name_ item can be found

_ex-command_
    An ex editor command indicating how to locate the item in the file. This can be any ex command. But two types of ex commands make the most sense:

  1. In the simple form _ex-command_ is a line number, which is indeed a valid ex command.
  2. Usually, however, it is a better idea to use a search pattern like `/`_tag-name_`/`. This provides some flexibility if the file is edited later. It reduces the number of times the tag file has to be re-build, because something moved inside a file. ctags also mostly generates pattern search commands and not line numbers.

Typically vi clones allow for some extensions of this format. Check the particular documentation.

A tag file should be sorted in alphabetic order to speed up operation. If this can't be done, vi's -S command line option can be used.

It is usually not a good idea to generate tag files by manually running ctags or an own tool. Instead the building of tag files is usually better integrated into the software build system. For Unix this means using _Makefiles_. Typically, the **make**(1s) targets for generating tag files are called _tags_, because that's the name of the to be created tag file:
    
    
    # Makefile snippet
    SRCS = ... # all source code
    tags: $(SRCS)
            ctags -dt $(SRCS)
    

### Ex Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-25)]

By default, vi looks in a file called `tags` for any tags. This file name can be changed with the following ex command. In fact, more than one file name can be specified. They are all loaded to find tags. The command is maybe best placed in a project-specific `.exrc` file.

:set tags=_filename_[\ _filename ...]<CR>_
    Set name of files which contain tag information. The syntax of the command varies a little bit from vi to vi version if more than one tag _filename_ is supposed to be provided. Filenames have either to be separated by "`\` " (backslash space) or "`;`" (semicolon).

Naviation to tags can be done via the following ex command. There is also a vi command to do this.

:ta _tag-name_<CR>
    or
:tag _tag-name_<CR>
    Look up the _tag-name_ in the tags file(s), open the file named in the index entry and execute the _ex-command_ from the index entry. This effectively positions the user at the file and position where the symbol _tag-name_ is defined. The command also remembers the current file and position on the tag stack.

  


## EX commands in vi[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-26)]

Ex is a line editor that serves as the foundation for the screen editor vi. Ex commands work on the current line or on a range of lines in a file.

_Syntax of Ex commands_  
**:[address] command [options]**  


':' specifies an Ex command.

**Address**  
The 'address' specifies the lines number or range of lines that are the object of command.If no address is given,the current line is the object of the command.  


Address Ranges can be specified by any of the following ways in Ex command syntax.

Syntax Range

** :%**
All the lines in the file.

**:1,$**
All the lines in the file.

**:^,$**
All the lines in the file.

**:X,Y**
All the lines between Line number X to Line number Y.

**:.,.+n**
All the lines between current line and next n lines.

**:.,.-n**
All the lines between current line and previous n lines.

**:X;Y**
Line number X to Line number Y with current line set as Line Number X.

**:X,+n**
All the lines between Line number X and next n lines from Current Line.

**:X,-n**
All the lines between Line number X and previous n lines from Current Line.

**:X**
The Line number X.

**:.**
The Current Line.

**:$**
The Last line of File.

**:0**
The First line of file

**:X-n**
The Line which is n lines before Line number X .

**:X+n**
The Line which is n lines after Line number X .

**:'b**
The Line which is marked by letter b.

**:'**
The Line which is marked.

**:/word**
Next Line containing pattern word

**:?word**
Previous Line containing pattern word

  


**Commands**  


Command Ex Syntax Operation

Substitute
**:%s/str1/str2/g**
Substitute str1 by str2 in the Address range specified as whole file.

Copy and Paste
**:t8**
Copy current line and Paste after Line number 8.

Copy and Paste
**:9t11**
Copy line 9 and Paste after Line number 11.

Copy and Paste
**:5,8t10**
copy lines 5 through 8 and Paste after Line number 5.

Copy and Paste
**:10,14co20**
Copy lines 10 through 14 and Paste after Line number 20.

Move and Paste
**:m8**
Cut current line and Paste after Line number 8.

Move and Paste
**:9m11**
Cut line 9 and Paste after Line number 11.

Move and Paste
**:5,8m10**
Cut lines 5 through 8 and Paste after Line number 5.

Yank/Copy in named buffer.
**:3,10y p**
Copy the text between line number 3 and line number 10 in a buffer p (single lowercase char)

Yank/Copy.
**:3,10y**
Copy the text between line number 3 and line number 10 in a temporary buffer.

Paste/Put
**:10p**
Paste the text in temporary buffer at line number 10.

Paste/Put
**:p**
Paste the text in temporary buffer at Current line .

Paste/Put
**:+10p**
Paste the text in temporary buffer at 10 lines after Current line

Write/Save file
**:w!**
Save the current file.

Write/Save file
**:w fname**
Save the current file as fname. Similar to "Save as" in Windows Operating system.

Write/Save file
**:15,30w fnew**
Saves the Lines between Line number 15 to Line number 30 of current file in a new file named fnew.

Write/Save file
**:15,30w >> fexist**
appends the Lines between Line number 15 to Line number 30 of current file in a file named fexist.

Write/Save file
**:x!**
Save & Quit current file Forcefully.

Quit file
**:q**
Quit the current file.

Quit file
**:q!**
Quit current file Forcefully without saving.

Edit/Refresh
**:e!**
Refresh- Discard changes not saved.

Edit
**:e fname**
Edit file named fname without leaving vi.

Edit
**:n**
Edit next file without leaving vi.

Edit
**:p**
Edit previous file without leaving vi.

Edit
**:rew**
Edit previous file without leaving vi.

Insert file
**:r fname**
Inserts all the text in the file named "fname" at the current cursor location.

Read/Insert
**:r! command**
Inserts the output of command at the current cursor location.

read/Insert
**10:r! command**
Inserts the output of command at Line number 10.

Insert file
** :r fname**
Inserts all the text in the file named "fname" at the current cursor location.

Insert text
**:45i!**
Sets up insert mode at Line number 45.

append text
**:45a!**
Sets up append mode at Line number 45.

Delete Lines
**:d**
Deletes current line.

Delete Line
**:45d**
Delete Line number 45.

Delete Lines
**:.,.+15d**
Delete all the lines between current line and next 15 lines

Delete Lines and put in buffer
**:.,.+15d f**
Delete all the lines between current line and next 15 lines and put them in a buffer named f

mark a Line
**:10ma f**
Mark the Line number 10 with a single lowercase char f.Return later to the mark by 'f.

Shell Command
**10,15:! command**
Execute command in a shell. Treat the text between Line number 10 and Line numner 15 as standard input to command, and replace these lines with the output.

View
**:10z**
Set up a view with Line number 10 at the Top of screen.

View
**:10z+**
Set up a view with Line number 10 at the Top of screen.

View
**:10z-**
Set up a view with Line number 10 at the bottom of screen.

View
**:100z.**
Set up a view with Line number 100 at the center of screen.

View
**:100z^**
Set up a view with Line number 100 at the center of screen and set current line as Line number 100.

View
**:10z+ 5**
Set up a view with Line number 10 at the Top of screen and display next 5 lines from Line number 10.

Status
**:f**
Shows current position and the file name at the bottom of the screen.It also specifies if any changes are made to the file since it has been opened.

  
**Options**

Option Operation

 !
Specifies the command has to be executed forcefully.

destination
Specifies the Line number where the text is to be pasted.Used with Copy and Move commands.

count
Specifies the number of time command is to be repeated.This number always succeed the command.

fname
Specifies that the object is a file name "fname".

### Vi Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-27)]

Navigation to tags can be done via the following vi command:

^]
    Take the _tag-name_ at the cursor position, look it up in the tag file(s) and navigate to it, similar to the `:ta` ex command. The command also remembers the current file and position on the tag stack.

The following command uses the tag stack to go back to the previous position. Older vi's don't have it implemented:

^T
    Get the previous position and file from the tag stack and return to it. The data is removed from the file.

### Command Line[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-28)]

Vi can also be started with a tag name instead of a file name. See the -t command line option.

## Shell escape[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-29)]

While one is working in vi there might arise a need to run another operating system command. In these modern days this is not a big issue. One can open another terminal window and do as pleased. However, this is not necessary when working with vi. Vi, like many of the older interactive Unix tools, contains features to run operating system commands or start a command line interpreter (shell) from within the editor. This dates back to the times when there were no graphical user interfaces and an editor like vi would take up the complete screen of the terminal (a real terminal of course, not a terminal emulation). Being able to run commands from vi spares one the need to first quit the editor just to look something up, e.g. in a manual page.

In addition, vi provides features to insert the text output of other commands directly into the text under editing.

### Ex Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-30)]

The editor commands to run another command from within vi are in fact implemented as ex commands. That is, they start with the familiar ':' in command mode.

To execute one command from within vi, one would type
    
    
    :!_command_<CR>
    <CR>
    

At the end of the _command_ one has to hit Return (the second <CR> shown above) to go back to vi. Vi then repaints the screen and continues where editing was left.

In order to repeat the last _command_, one can simply type
    
    
    :!!<CR>
     <CR>
    

It is possible to append to a previous command by using `:!!`, followed by whatever should be appended. For example, the second of the following two commands
    
    
    :!ls<CR>
     <CR>
     :!! | more<CR>
     <CR>
    

is actually equal to
    
    
    :!ls | more<CR>
     <CR>
    

(Note, **ls** is the Unix command to list a directory, **more** is the Unix command to paginate output, so it doesn't just scroll off the screen).

Once something is appended to a command, it becomes part of the last remembered command. So in the example above, another
    
    
    :!!<CR>
     <CR>
    

would be equal to
    
    
    :!ls | more<CR>
     <CR>
    

and not
    
    
    :!ls<CR>
     <CR>
    

Two placeholders can be used in shell escapes to denote the current file name or the name of the previously edited file name:

 % 
    is a placeholder for the current file name,
# 
    is a placeholder for the previously edited file name.

For example, if one is editing some shell script and wants to try it out, one could type the following commands to save the file (`:w`), set the file's attributes to executable (`!chmod ...`), and run it (`!%`):
    
    
    :w<CR>
     :!chmod 755 %<CR>
     <CR>
     :!%<CR>
     <CR>
    

If the file's name is, e.g. _script.sh_, the above would be equal to typing
    
    
    :w<CR>
     :!chmod 755 script.sh<CR>
     <CR>
     :!script.sh<CR>
     <CR>
    

  
Instead of running a command from within vi it is also possible to start the shell from within vi. vi has an own command for this, which looks up the user's default shell (e.g. the Bourne shell or the C shell) and starts it. It is important to note that a new shell is started. The user is not returned to the shell from which vi was started. The command is called _:sh_, and it can be used as it follows:
    
    
    <ESC>:sh<CR>
    $ #_shell commands, when done exit shells:_
    $ exit<CR>
    

### Vi Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-31)]

It is possible to filter all or parts of a text currently under editing through an external program. The original text is then replaced with the output of the external command.

The classic example for this feature is the usage of the Unix text formatter **fmt**. vi itself doesn't have any specific formating capabilities, however, by running the text or parts of it through an external formater from within vi, the desired formatting is easily achieved.

The vi command for filtering text is `!` (note, as opposed to the ex shell escape command, there is no leading `:`). `!` follows the usual vi command format. So one can specify the scope to which it should apply. E.g. `!!` means to filter the current line, or `!}` means to filter the current paragraph.

The `!` vi command has to be followed by by the name of the external program to be used for filtering. E.g. in order to format the current paragraph with the already mentioned Unix text formatter **fmt**, one would type
    
    
    !}fmt<CR>
    

`!` can also be used to just insert the output of some external command into the currently edited text. To do so, one would first create a new empty line (e.g. with `o`), and then use `!!` to replace the empty line with the output of a command. For example,
    
    
    o<ESC>!!ls<CR>
    

would include a listing of the files in the current directory into the text under Unix.

## Execute command from Buffer[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-32)]

_This module is a stub. You can help Wikibooks by [fixing it](/wiki/Wikibooks:Find_or_fix_a_stub)._

@_b_
    Execute command stored in buffer _b_.

## vi for Programmers[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-33)]

Classic vi provides a number of features which are useful for programmers. Vi was made by programmers for programmers -- but at a time when programming was different. Classic vi's programming support is, by today's standards, not too great, but of course still usable. And it is still more convenient to use vi for editing programming code than any of the _...pad_ editors like **notepad** (Windows) or **dtpad** (CDE/Motif). vi probably works best on Unix systems due to the many text filters that come with Unix and the ease with which additional special-purpose filters can be scripted.

Useful features in vi for programmers are:

### Autoindent and manual Shifting of Lines[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-34)]

See Indenting and shifting

### Modelines[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-35)]

Modelines to set per-language defaults - if security is not an issue (see Modelines)

### Tags for Navigating[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-36)]

See Tags

### Shell Escapes[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-37)]

See Shell escape

  * One way to use shell escapes is to run a _makefile_ or the compiler from within vi. It is in general a good idea to first save the current file before trying to compile it:
    
    
    <ESC>:w<CR>
    :!make<CR>  
    _or_
    <ESC>:w<CR>
    :!cc %<CR>  
    _and afterwards_
    <ESC>:w<CR>
    :!!<CR>
    

  * Another way is filter source code through an external command, e.g. through a comment-reformator for the specific language. For example, the following command will filter the current paragraph through a external comment-reformator called **recomment** (not a standard Unix program, but available as a separate script).
    
    
    !}_recomment_
    

    See [[1]](http://examples.oreilly.com/upt3/split/recomment) for the **recomment** script for Unix.

### Editing multiple Files[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-38)]

vi can be started with a list of files:
    
    
    vi file1 file2 file3 ...
    

Combined with other Unix features, like file matching, this can be a powerful feature. E.g. to open all C source code, including header files in a directory (.h), the following command can be used:
    
    
    vi *.[ch]
    

Or to find all files which contain a certain keyword and open them, something like
    
    
    vi `grep -l Keyword *.txt`
    

can be used.

Once vi has been started with a list of files it is possible to navigate within the list with the following commands:

:n 
    next - Move to the next file in the file list
:rew 
    rewind - rewind the file list and open the first file in the list.

vi clones like vim typically provide more commands, e.g. to go back one file in the file list.

### Flip between two Files[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-39)]

  * Flip between two files using `#` as the name of the last file. E.g. to flip between a C source file and the corresponding header file.
    
    
    :e x.c<CR>
    :e x.h<CR>
    _some changes to x.h, then going back to x.c_
    <ESC>:w<CR>
    :e#<CR>
    

  * Flipping between two files using `CTRL-^`. This is one of the forgotten vi commands.

### The **error**(1) Program[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-40)]

The **error**(1) program on Unix can be used to capture error messages from compilers and later jump from error message to error message in the editor. **error'**s way of working is archaic. It parses error messages from the compiler and inserts them as comments into the source file in which the compiler detected the error. Since **error** marks error messages with `###` and `%%%` in the source file, navigation can be done with vi commands like `/` and `n`.

There are two common ways to use error with vi:

  1. From outside vi and letting error start vi. error can start vi on all files which produced an error during compilation, using the `-v` flag:
    
    
    $ cc *.c 2>&1 | error -v
    # Notes:
    #  cc    - the C compiler
    #  *.c   - all C files in the current directory
    #  2>&1  - Standard error output is redirected to normal standard output
    #  |     - the output is feed to error as input
    

    2\. From inside vi, on the current file. First the file is saved, then it is tried to compile it, processing potential error messages with **error**, then the potentially changed source file is re-read (`:e!`), and finally the first mark is searched with `/###`:
    
    
    _first time_
    <ESC>:w<CR>
    :!cc % 2>&1 | error<CR>
    :e!<CR>
    /###<CR>  
    _and afterwards_
    <ESC>:w<CR>
    :!!<CR>
    :e!<CR>
    /###<CR>
    

Note: 
    **error** is a horrible kludge and can really mess up source code and a version control system! We recommend you try it at least once and form your own opinion. Also have a look at error's man page first. vi clones like vim provide a much more sensible system. Here the editor executes the compiler (or **make**(1s)) and captures the output of the compiler. The information is recorded in an error message file by vim. vim then allows to navigate the source code by extracting file names and line numbers from the error message and jump to these positions. This is the same mechanism as provided by IDEs.

### Macros & Shortcuts[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-41)]

vi's provides the `:map` and `:map!` commands to define useful shortcuts and macros, and `ab` to provide abbreviations.

    _Todo: Provide a few such macros?_

## nroff/troff Typesetting Support[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-42)]

### Overview[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-43)]

vi provides support for editing text files for the Unix typesetters **nroff** and **troff**. The most "common" usage for this typesetter these days is probably to write manual (man) pages for Unix applications.

The support for writing nroff/troff input text files is always active, there is no special vi mode or option which needs to be turned on. Already from this it can be concluded that there aren't too many nroff/troff specific operations in vi. In fact, vi just provides simple ways to navigate between nroff/troff paragraphs and sections. Nevertheless, these features help when editing nroff/troff files.

nroff's/troff's text file format is simple. Normal text and macros are mixed, where macros indicate how the text should be formatted. A macro starts with a '.' in column one, followed by a one or two letter macro name followed by optional macro arguments. A typical nroff/troff text file with some macros might look like:
    
    
    .SH "A SECTION HEADER"
    Some text making up the first paragraph in the section.
    More text in the paragraph.
    .PP
    A new paragraph has been started.
    More text in this second paragraph.
    .PP
    Yet another paragraph.
    .\"
    .\" A comment infront of the next section header
    .\"
    .SH "SECTION HEADER 2"
    Paragraph text.
    

To simplify navigation in such a text file vi knows the common macro names for sections (the `.SH` in the above example) and paragraphs (the `.PP` in the example) and provides commands to move to the next/previous section. The list of macro names is configurable in vi.

Several of the common vi features also help when editing nroff/troff text. E.g. shell escapes to run the typesetter from within vi. The following will format the current file with the manual page macros:
    
    
    <ESC>:w<CR>
    :!nroff -man % | more<CR>
    

### Options[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-44)]

The following options are used to define the nroff/troff macro names as known by vi. Like all options, one changes them by using the `:set` ex command:
    
    
    :set _option_[=_value_]
    

sections 
    List of macro names which vi interprets as section delimiters. Two consecutive characters in the list form one macro name. Typically, vi's default contains `.SH`, `.NH`, `.H`, and `.HU`. So the _sections_ option reads like
    
    
    sections=SHNHH HU
    

paragraphs 
    or
para 
    List of macro names which vi interprets as paragraph delimiters. Two consecutive characters in the list form one macro name. vi's default typically contains `.IP`, `.LP`, `.PP`, `.QP`, `.PL`, `.Ib`, `.p`. So the _paragraphs_ option reads like
    
    
    paragraphs=IPLPPPQPPLIbp
    

### Vi Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/Details&action=edit&section=T-45)]

When in command mode, the following commands relate to working on nroff/troff text:

[[ 
    Moves to the previous section.

]] 
    Moves to the next section.

{ 
    Moves to the previous paragraph.

} 
    Moves to the next paragraph.

And, for completeness:

( 
    Moves to the previous sentence.

) 
    Moves to the next sentence.

  


# Vi clones[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=7)]

The following editors are derived from or share the spirit of the original vi editor, coupled to an easier to learn user interface:

  * [Vim](/wiki/Learning_the_vi_Editor/Vim) ![75 percents developed  as of Feb 7, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png) (Feb 7, 2005)
    * [Basic navigation](/wiki/Learning_the_vi_Editor/Vim/Basic_navigation) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
    * [Modes](/wiki/Learning_the_vi_Editor/Vim/Modes) ![75 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png) (Nov 1, 2006)
    * [Tips and Tricks](/wiki/Learning_the_vi_Editor/Vim/Tips_and_Tricks) ![25 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png) (Nov 1, 2006)
    * [Useful things for programmers to know](/wiki/Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
    * [Enhancing Vim](/wiki/Learning_the_vi_Editor/Vim/Enhancing_Vim) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
    * [VimL Script language](/wiki/Learning_the_vi_Editor/Vim/VimL_Script_language) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
  * [vile](/wiki/Learning_the_vi_Editor/vile) ![0% developed  as of May 28, 2006, just a stub](//upload.wikimedia.org/wikipedia/commons/thumb/8/83/00_percents.svg/9px-00_percents.svg.png) (May 28, 2006, just a stub)
  * [vipe](/wiki/Learning_the_vi_Editor/vipe) ![75 percents developed  as of Oct 11, 2008, wikified man page](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png) (Oct 11, 2008, wikified man page)
  * [BusyBox vi](/wiki/Learning_the_vi_Editor/BusyBox_vi) ![0% developed  as of May 28, 2006, just a stub](//upload.wikimedia.org/wikipedia/commons/thumb/8/83/00_percents.svg/9px-00_percents.svg.png) (May 28, 2006, just a stub)

  


# Vim[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=8)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/28/Vim.png/300px-Vim.png)

![](//bits.wikimedia.org/static-1.22wmf16/skins/common/images/magnify-clip.png)

Graphical Vim under [GTK2](//en.wikipedia.org/wiki/GTK%2B)

## Overview[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim&action=edit&section=T-1)]

  * [Basic navigation](/w/index.php?title=Learning_the_vi_Editor/Print_version/Basic_navigation&action=edit&redlink=1) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
  * [Modes](/w/index.php?title=Learning_the_vi_Editor/Print_version/Modes&action=edit&redlink=1) ![75 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png) (Nov 1, 2006)
  * [Tips and Tricks](/w/index.php?title=Learning_the_vi_Editor/Print_version/Tips_and_Tricks&action=edit&redlink=1) ![25 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png) (Nov 1, 2006)
  * [Useful things for programmers to know](/w/index.php?title=Learning_the_vi_Editor/Print_version/Useful_things_for_programmers_to_know&action=edit&redlink=1) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
  * [Enhancing Vim](/w/index.php?title=Learning_the_vi_Editor/Print_version/Enhancing_Vim&action=edit&redlink=1) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
  * [External Scripts](/w/index.php?title=Learning_the_vi_Editor/Print_version/External_Scripts&action=edit&redlink=1) ![25 percents developed  as of March 24, 2010](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png) (March 24, 2010)
  * [VimL Script language](/w/index.php?title=Learning_the_vi_Editor/Print_version/VimL_Script_language&action=edit&redlink=1) ![50 percents developed  as of Nov 1, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png) (Nov 1, 2006)
  * [Vim on Windows](/w/index.php?title=Learning_the_vi_Editor/Print_version/Vim_on_Windows&action=edit&redlink=1) ![0% developed  as of June 1, 2008](//upload.wikimedia.org/wikipedia/commons/thumb/8/83/00_percents.svg/9px-00_percents.svg.png) (June 1, 2008)

## External links[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim&action=edit&section=T-2)]

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Vim (text editor)**_](//en.wikipedia.org/wiki/Vim_\(text_editor\))

  * [vim.org](http://www.vim.org) \- documentation and many tips and plugins
  * [vi-improved.org](http://www.vi-improved.org) \- Wiki dedicated to vim
  * [vim tutorial](http://www.yolinux.com/TUTORIALS/LinuxTutorialAdvanced_vi.html)
  * [zzapper's Best of Vim Tips](http://www.rayninfo.co.uk/vimtips.html)
  * [Vim Recipes](http://vim.runpaint.org/) \- Free cookbook.

  


  


## Basic navigation[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Basic_navigation&action=edit&section=T-1)]

Basic navigation in vim is covered below.

### Moving around[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Basic_navigation&action=edit&section=T-2)]

We can move around in the editor by first entering command mode, and then using the <h>, <j>, <k>, and <l> keys.

Note
    your arrow keys may be set up to work, and you can use them if you like, but for proficiency and for advanced work later, you should learn to use the letter keys.

  * The <h> key, in command mode, moves the cursor one character **left**.
  * The <j> key, in command mode, moves the cursor one character **down**.
  * The <k> key, in command mode, moves the cursor one character **up**.
  * The <l> key, in command mode, moves the cursor one character **right**.

If you have trouble remembering this, keep in mind that <h> is leftmost, the letter <j>goes down below the line, the letter <k>pokes up above the line, and the <l> key is rightmost. (J also resembles an arrow pointing downward, if you squint a bit.)

After you have moved the cursor using those keys, you can enter insert mode again by pressing <i>. When you do this, you insert text at the cursor, inserting text between the character to the **left** of the cursor and the **current** position of the cursor. Let's practice this in an exercise.

  


### VIM Help system[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Basic_navigation&action=edit&section=T-3)]

vim is a very feature rich application. Unlike the 'vi' editor it includes a help system. Because the help system will allow you to teach yourself much more than any book on vim possibly could, you will benefit from the power of the vim editor much more if you learn to use it. On a normal vim installation you should be able to start the online help by pressing the <HELP> key . If your keyboard does not feature a <HELP> key then you can try <F1> instead. (Some system administrators may have changed how vim behaves. If you cannot get into vim's help system with these commands, perhaps your administrator can help.)
    
    
    :help
    

Start vim and enter command mode by pressing escape. To get help on any command simply type `:help _command_`.

For example, if you would like to learn all the different ways the :x command can be used you could type `:h x`. To move around in the help files the same keys work, <h>, <j>, <k>, <l>. To leave the help files type :quit. If you know you want to do something, but you aren't sure what the command might be you can type partial commands like this `:help cut`. To learn to switch text from upper case to lower case you could type :help lowercase

When you search for help on any subject, vim will (normally by default) create a window (buffer) which you can navigate just like any window in vim. You can close the help window by typing :quit or :q and pressing enter.

The default help file (shown when you type "help") explains basic navigation for vim and for vim's help files.

  


  


## Modes[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-1)]

VIM offers more modes than vi (which offers only the "normal", "insert" and "command–line" modes). Theses additional modes make VIM more powerful and easier to use; because of this, vim users should at least be aware that they exist. (NOTE: _If you ever enter a mode you are unfamiliar with, you can usually press ESC to get back to_ normal _mode._)

Here a short overview of each mode available in vim:

Name Description help page

normal
For navigation and manipulation of text. This is the mode that vim will usually start in, which you can usually get back to with ESC.
`:help Normal-mode`

insert
For inserting new text. The main difference from vi is that many important "normal" commands are also available in insert mode - provided you have a keyboard with enough meta keys (such as Ctrl, Alt, Windows-key, etc.).
`:help Insert-mode`

visual
For navigation and manipulation of text selections, this mode allows you to perform most normal commands, and a few extra commands, on selected text.
`:help visual-mode`

select
Similar to visual but with a more MS-Window like behavior.
`:help select-mode`

command-line
For entering editor commands - like the help command in the 3rd column.
`:help Command-line-mode`

Ex-mode
Similar to the command-line mode but optimized for batch processing.
`:help Ex-mode`

Each mode is described below.

### insert (and replace)[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-2)]

In insert mode you can type new text. In classic vi the insert mode was just that: insert text and nothing else. Vim makes use of many meta keys on modern keyboards; with a correctly configured vim, cursor keys should work in insert mode.

Insert mode can be reached in several ways, but some of the most common ones are <a> (append after cursor), <i> (insert before cursor), <A> (append at end of line), <I> (insert at beginning of line), <C> (change to end of line), and <s> (substitute characters).

If you wish to edit text by selecting and replacing, as is common in many GUI-based editors, <C> does nicely. The selected text is deleted before entering insert mode.

### normal (command)[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-3)]

Unless you use the evim interface this is the standard mode for vim (vim starts in normal mode). Everything the user types in normal mode is interpreted as commands (including those which switch the user to other modes).

If vim is started as evim (_evim_ on the command line), vim keeps the user in insert mode all the time. Normal mode can be reached for individual commands by pressing <Ctrl-O> followed by the desired command. After one command, the user is returned to insert mode. (Each normal command must be started first by pressing <Ctrl-O>).

### visual[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-4)]

There are three different types of highlighting in visual mode. Each allows the user to highlight text in different ways. Commands that normally only affect one character, line, or area will affect the highlighted text (such as changing text to uppercase (<Ctrl-~>), deleting text (<d>), indenting lines (>>, <<, and =), and so forth).

There are three (sub)types of the visual modes which are _visual_, _block-visual_ , and _linewise-visual_

#### plain visual mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-5)]

The plain _visual_ mode is started by pressing 'v' in normal mode. At any point, pressing ESC or <v> will leave VISUAL mode without performing an operation. Movement commands change the selection area, while other commands will generally perform the expected operation on the text (there are some exceptions where the behavior will change or where the command won't work, but if it doesn't do what you hoped you can always undo with <u>).

#### block visual mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-6)]

**block-visual** is started by pressing <Ctrl-V> (or <Ctrl-Q> in some windows versions. If neither of these works use ":help visual-block" to find out how). Visual blocks always maintain a rectangular selection, highlighting only specific columns of characters over multiple lines. In this following example the user wants to put a dash in each phone number between the second and third number fields:

The user first moves the cursor to the top of the column (you could start at the bottom if you want).

![Vim block change example.jpg](//upload.wikimedia.org/wikibooks/en/a/aa/Vim_block_change_example.jpg)

Next, press <Ctrl-V>. This puts you in block-visual mode (VISUAL BLOCK appears at the bottom to tell you what visual mode you're in). Next, move down to the bottom desired line. You can see a single column highlighted in this example, but you could move right or left and highlight more columns.

![Vim block change example2.jpg](//upload.wikimedia.org/wikibooks/en/3/3a/Vim_block_change_example2.jpg)

In this case, the user wants to _change_ the spaces to dashes. To change text, we press 'c'. The spaces all disappear, and the changes are shown only in the current line while we type:

![Vim block change example3.jpg](//upload.wikimedia.org/wikibooks/en/2/28/Vim_block_change_example3.jpg)

when we press <ESC>, though, the change is duplicated on all the lines.

![Vim block change example4.jpg](//upload.wikimedia.org/wikibooks/en/d/d8/Vim_block_change_example4.jpg)

(Note: if you simply want to _insert_ text rather than change it, you will need to use '<I>' or '<A>' rather than '<i>' or '<a>'.)

#### linewise visual mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-7)]

In **linewise-visual** mode, enterd by <Shift-V>, entire lines are highlighted. Otherwise, it generally works like the plain **visual** mode.

### select[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-8)]

like the visual mode but with more [CUA](//en.wikipedia.org/wiki/Common_User_Access) like behavior. This means that if you type a single character it replaces the selection. Of course you lose all the one key operation on selection like <U> to make a selection uppercase.

This mode is usually activated by:
    
    
    :behave mswin
    

which is default for MS-Windows installations. You can get the normal mode with
    
    
    :behave xterm
    

### command-line[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-9)]

Within the command-line you can run [Ex](//en.wikipedia.org/wiki/Ex_\(editor\)) commands, enter search patterns, and enter filter commands. At the bottom a command line appears where you can enter the command. Unlike vi - vim supports cursor keys which makes entering commands a lot easier. After one command the editor returns into normal mode.

You can enter an Ex command by typing a `:` in normal mode. Some examples include:
    
    
    :set number
    :substitute/search/replace/ig
    

You can enter a search pattern by typing `/` to search forward, or `?` to search backward. You can use vim's expanded regular expressions in these search patterns. For example,
    
    
    /word
    

will jump to the next occurrence of "word" (even if it is "sword" or "wordlessly"), but
    
    
    /\<word\>
    

will jump only to a complete word "word" (not "sword" or "wordless").

You can enter a filter by typing ! followed by a motion command, then a shell command to run on the text captured by the motion. For example, typing
    
    
    !22jsort
    

in Linux will sort the current and 22 following lines with the _sort_ system command. The same thing can be done with
    
    
    :.,.+22!sort
    

As a matter of fact, vim creates the above command for you if you follow the first example!

### Ex-mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Modes&action=edit&section=T-10)]

The Ex mode is similar to the command line mode as it also allows you to enter [Ex](//en.wikipedia.org/wiki/Ex_\(editor\)) commands. Unlike the command-line mode you won't return to normal mode automatically. You can enter an Ex command by typing a `Q` in normal mode and leave it again with the `:visual` command. Note that the Ex mode is designed for Batch processing and as such won't support mappings or command-line editing.

For batch processing the Ex-mode is normally started from outside by calling the editor with the "-E" option. Here is a real live example from the [RPM Package Manager](//en.wikipedia.org/wiki/RPM_Package_Manager) specification:
    
    
    vim -E -s Makefile <<-EOF
       :%substitute/CFLAGS = -g$/CFLAGS =-fPIC -DPIC -g/
       :%substitute/CFLAGS =$/CFLAGS =-fPIC -DPIC/
       :%substitute/ADAFLAGS =$/ADAFLAGS =-fPIC -DPIC/
       :update
       :quit
    EOF
    

The RPM uses [Bash](//en.wikipedia.org/wiki/Bash) as script language which make the example a little difficult to understand as two different script languages are mixed in one file.

`vim -E -s` 
    starts vim in improved Ex mode which allows for more advanced commands than the vi compatible Ex-mode (which is started with `vim -e -s`).
`<<-EOF` 
    tells bash to copy all lines that follow into the standard input of the external program just started. The '-' tells the shell to strip the tab characters.
`:` 
    are lines with Ex commands which vim will execute. The `:` is optional but helpful when two script languages are mixed in one file
`:update` 
    A beginners mistake is to forget to actually save the file after the change - falsely assuming that this happens automatically.
`:quit` 
    Last not least: don't forget to actually exit vim again.
`EOF` 
    marks the end of the standard input redirection - from now on bash will execute the command itself again.

If your shell does not allow such nifty redirection of standard input then you can always use a more classic approach to I/O redirection using two files:
    
    
    vim -E -s Makefile <Makefile-Fix1.vim
    

And if have no standard input redirection available then you can try the `-c` option in combination with the `source` command:
    
    
    vim -E -s -c "source Makefile-Fix1.vim" Makefile
    

With the improved Ex mode many tasks classically performed by [awk](//en.wikipedia.org/wiki/AWK_programming_language) or [sed](//en.wikipedia.org/wiki/sed) can be done with vim and often better so:

  * [awk](//en.wikipedia.org/wiki/AWK_programming_language) and [sed](//en.wikipedia.org/wiki/sed) are stream oriented - they only read the file forward from beginning to end while vim is buffer oriented - you can move forward and backward in the file as you like.
  * vim's [regular expressions](//en.wikipedia.org/wiki/Regular_expression) are more powerful than [awk](//en.wikipedia.org/wiki/AWK_programming_language)'s and [sed](//en.wikipedia.org/wiki/sed)'s expressions - for example vim can match over several lines and supports zero matches.

  


The Vim Tipbook is a collection of tips, hints and HowTos for using the [Vim text editor](http://www.vim.org/). It is an outgrowth of the [Vim tips database](http://vim.wikia.com/) in a more flexible format, and also includes some helpful posts from the [Vim mailing lists](http://www.vim.org/maillist.php).

For information on the general use of Vim, please see the [Learning the vi Editor/Vim](/wiki/Learning_the_vi_Editor/Vim).

## About this Book[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Tips_and_Tricks&action=edit&section=T-1)]

### Tips for Editing[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Tips_and_Tricks&action=edit&section=T-2)]

  * Where possible, extensive personal configurations should be avoided. Keep suggestions within the scope of a single tip. You may wish to link to several other tips that might be used alongside, much in the same way a food cookbook would suggest dishes that go well together.
  * Always provide enough information so that a tip can be used from Vim's default `compatible` settings.

### Conventions Used[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Tips_and_Tricks&action=edit&section=T-3)]

<c>
    A single character, such as 'a' or '1'.
<ESC>, <Ctrl-[>
    Indicates that the Escape (Esc) key on your keyboard should be pressed, which is identical to Control and '['.
<CR>
    Indicates that the Return (Enter) key should be pressed.
<TAB>
    Indicates that the Tabulator key should be pressed
<Ctrl-x>, <C-x>
    Indicates that the Control key and the 'x' key should be pressed simultaneously. 'x' can be almost any other key on your keyboard.
<Shift-x>, <S-x>, <X>
    Indicates that the Shift key and the 'x' key should be pressed simultaneously
<Meta-x>, <M-x>
    Indicates that the Meta or Alt key and the 'x' key should be pressed simultaneously.
:quit, :q
    An Ex command. started with <:>, followed by the command and ends with <CR>. For many Ex commands there is a long form (:quit) and a short form (:q).
:set **nocompatible** 
    represents a setting.
**strlen** () 
    represents a function.
/_pattern_/, ?_pattern_?
    A Search pattern. Search pattern in vi are [regular expressions](//en.wikipedia.org/wiki/regular_expression).
:_range_s/_search_/_replace_/_options_, :global /_pattern_/ delete
    A Search pattern combined with an Ex command.

All commands in _vi_ are case sensitive.

  
Where a series of commands are required to be entered, these might be listed in a preformatted block:
    
    
     {{Vi/Ex|set}} {{Vi/set|number}}
     {{Vi/Ex|set}} {{Vi/set|textwidth=70}}
     {{Vi/Ex|set}} {{Vi/set|wrap}}
     
    

Which will produce the following formatted text:
    
    
    set **number**
    set **textwidth**=70
    set **wrap**
    

## Vim Help[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Tips_and_Tricks&action=edit&section=T-4)]

If you are new to vi, try the `vimtutor` command. It's an excellent guide for the beginner.

Vim has an extensive help system. EVERYTHING is covered. This system is so extensive, however, that finding the needed information is sometimes akin to finding one's own little needle in a huge stack of hay. But even for that, there are Vim tools:

  * (assuming `'nocompatible'` is already set)
    
    
    set **wildmenu**
    

  * Help tag completion: if you think 'foo' is part of something which has a hyperlink in the help system, use
    
    
    help foo<Tab>
    

    where <Tab> means "hit the Tab key", and if there is only one possible completion Vim fills it in for you; if there is more than one the bottom status line is replaced by a menu which can be navigated by hitting the <Left> and <Right> arrow keys; accept a selection by hitting <Enter>, abort by hitting <Esc>.

  * The `:helpgrep` function: if you think that some regular expression describe text you want to search for in the text of all the help files, use
    
    
    helpgrep <pattern>
    

    where <pattern> is a Vim regular expression, like what you can use after / or ? . It may take some time for Vim to look up all its help files, and it may or may not display interim information which may require you to hit Enter to clear the `|more-prompt|` (q.v.) When the blinking cursor reappears in your editfile, it means Vim has compiled the list of all help locations where your regexp matches. See them by means of the following
    
    
     cfirst or :cr
     cnext or :cn
     cprevious or :cprev or :cN
     clast or :cla
    

## Inserting Text From a File or Register[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Tips_and_Tricks&action=edit&section=T-5)]

If your text is in a file on its own, you can use `:r` with a line number (the number of the line after which to insert, or `0` for "before first line", or `.` for "after cursor line", or `$` for "after last line"; default is after cursor line) in the "range" position, i.e. just before the `r`. The file name comes as an argument at the end.

Example (after line 5):
    
    
      5r ~/template.txt
    

If your text is in a register, you can use `:put` with a line number (again) in the range position and the register name (including `"`, which must be escaped as `\"`, for the default register; or `+` for the system clipboard) after the `:put`.

Example (before cursor line):
    
    
      .-1put \"
    

You can also insert a string directly using `:put` and direct assignment:
    
    
      :put ='This is text to insert.'
    

See
    
    
      :help :read
      :help :put
    

## Full Screen Mode[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Tips_and_Tricks&action=edit&section=T-6)]

To achieve a full screen editing window on any version of gvim you can do:
    
    
      :set go-=m go-=T go-=l go-=L go-=r go-=R go-=b go-=F
      :set lines=999 columns=999
    

  * `'guioptions'`: We remove the flags one-by-one to avoid problems if they appear in the option in a different order, or if some of them do not appear at all. By choosing which ones to remove (or not) you can customize your own flavour of "full-screen Vim".
    
    
      m   when present, menu bar is present
      T   when present, toolbar is present on versions which support it (W32, GTK1, GTK2, Motif, Photon, kvim)
      l   when present, left scrollbar is always present
      L   when present, left scrollbar is present if there is a vertical split
      r   when present, right scrollbar is always present
      R   when present, right scrollbar is present if there is a vertical split
      b   when present, bottom scrollbar is present
      F   when present, gvim (Motif) will display a footer
    

  * `'lines'`, `'columns'`: setting them to a large value will maximize the window.

For more, see:
    
    
      :help 'guioptions'
      :help 'lines'
      :help 'columns'
    

  


  


## Useful things for programmers to know[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-1)]

There are quite a few things programmers ought to know about vim that will make their experience that much easier. Programmers can save hours and weeks of man-hours over the long haul with effective editors. Here are some tricks and tools that vim provides. With the time you save, you might speed up your work and have some extra time for a quick Quake deathmatch or eventually increase your productivity to help justify a larger wage increase.

### Word, variable, function, and line completion[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-2)]

Sometimes the word you're typing is really long. You shouldn't have to type it all out. If it's in your dictionary, or in the current file, you can save a lot of time with <Ctrl-P> and <Ctrl-N>. Let's take a closer look at how this works:

  * _Word/variable/function name Completion_

Generally, any word in the current file, or any of the other files (buffers) you are editing in the same instance of vim, will match for completion. This means once you've typed it once, you can type the first couple letters next time, and press Ctrl-N (several times if you need to cycle through several options) until you find the word you're looking for.

Technically, this isn't true. You can tell vim where to look for words in the `complete` function. In Vim 7, the `complete` function will generally be set to figure out a lot about what you're typing — drawing information from function libraries (As of the last update on this book, the author knows C and C++ are supported by default). Keyword completion since Vim 7 will also show a popup menu.

You can also define a dictionary of your own for completion. For more detail, you might want to consult the vim help system ":help complete", ":help complete-functions", and so forth.

_**Example 1**_

As an example, you might edit a C program file, "blah.c". You want a function that starts with "str", but you can't remember what it is. You first type "str". It remains regular text until you press <Ctrl-P> or <Ctrl-N>. In vim 7, you will see a menu appear, like this:

![Vim completion1.jpg](//upload.wikimedia.org/wikibooks/en/9/9a/Vim_completion1.jpg)

You can use <Ctrl-N> and <Ctrl-P> to cycle through the entries shown. In Vim versions 7 and higher, you can actually use the arrow keys to cycle through entries in the menu. There might be too many to show on the screen at once (you will notice the black box on the right represents a scroll position on a gray bar--not all the options are shown on-screen in this example.) The files from which the options were drawn are shown, to help you decide if it's what you're looking for.

(You will also notice in this example that words show up from files the author has recently edited, such as 'strict' from 'cgi-bin/ftplist.pl' -- we certainly don't want that.)

_**Example 2**_

Now, suppose you need the sine function, but you know it has an odd name. You type `sin` and press <Ctrl-P>, and it doesn't show up:

![Vim completion2.jpg](//upload.wikimedia.org/wikibooks/en/8/81/Vim_completion2.jpg)

You're not out of luck, you just haven't included the math library yet. All you have to do is add the line
    
    
    #include <math.h>
    

and try again. This time you see the function name you wanted (it wasn't easy to remember since it has an odd name)

![Vim completion3.jpg](//upload.wikimedia.org/wikibooks/en/a/a7/Vim_completion3.jpg)

  * _Line Completion_

You can complete entire lines if you need to, though this is less likely. <Ctrl-X>, <Ctrl-L> will load the matching lines (white space matters!) into the menu, and from there you can move forward and backward with arrows or <Ctrl-P> and <Ctrl-N> (for **P**revious and **N**ext)

### Indentation[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-3)]

Vim can figure out how to indent most common filetypes.

For most of the popular programming languages, vim can detect the file type by the filename's extension, and from there it will decide how to indent your files. If you don't see it automatically creating the proper indentation for you, try
    
    
    :filetype indent plugin on
    

In the GUI version, you might be able to turn it on at the same time you turn syntax highlighting on for that file. Choose Syntax -> on/off for this file, or Syntax -> Show Filetypes in menu, then go back into the syntax menu and choose the appropriate file type from the list.

You might want to put the above-mentioned ":filetype ..." line in your vimrc file (discussed earlier) and open your program file again, though this really shouldn't be necessary.

If you still have problems, you might want to check that your runtimepath variable is set properly (:help runtimepath). It's also possible (though unlikely) that your programming language is rare enough that nobody has written an indent plugin for it yet. The official site for vim, vim.org, may have an indent plugin file that meets your needs, even if it didn't come with your default installation of vim.

For those times when you've pasted some text in and the indentation is wrong, (your indent plugin must be loaded), you can use the = command. It's probably easiest to type '10=' to re-indent the next ten lines, or to use visual mode and press <=>.

If you want, you can indent lines with ">>" and unindent them with "<<".

If you are in insert mode, use <Ctrl-D> and <Ctrl-T> to change the indentation of the line (<Ctrl-D> decreases indentation by one level and Ctrl-T increases it by one level)

If you can't manage to get filetype specific indentation working, you might try setting one or more of the following options: smartindent, autoindent, cindent, and copyindent. Chances are these won't work completely right, so <Ctrl-D> and <Ctrl-T> will be more important. To turn autoindent on, type `:set autoindent`. To turn autoindent off, type `:set noautoindent`

### Repeating commands, or Performing the Same Command Many Times[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-4)]

If you feel comfortable with vim, you might record your keystrokes to an invisible register and repeat them later. It might be easier to write a vim script, or even filter your file with another program (such as a perl script) for complex enough actions.

That said, sometimes it really is easier to record a command and reuse it, or even perform it on any matching line. For more advanced execution patterns (e.g. executing one command on the whole file), see below. You might also consider creating a mapping (discussed below) or running a :global command (also discussed below).

#### Repeating the last single command[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-5)]

Suppose I want to put a semicolon on the end of a few lines, where I forgot:
    
    
    cout << "Hello world\n"
    i = j + k
    cout << "i is " << i << endl
    

On the first line, I type `A;` followed by the `ESC` key. I move to the next line and press `.` (the period tells vim to repeat the last command -- don't worry, it doesn't duplicate movement commands).

#### Recording a command macro[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-6)]

Vim has a powerful form of command repetition available through the use of macros. A user can record a series of commands into a register and run the register as a macro. Macros can be recorded into any of 26 registers (a through z).

To start recording a macro, press `q` followed by a register name (any letter `a` through `z` \-- Registers are defined by only one letter of the alphabet, so only one character may be used as the storage buffer). After performing a series of commands, finish recording the command macro by pressing `q` again. For example to start recording into register z, press `qz` and press `q` again to finish recording.

To run a macro from a register, run it with `@**x**` where **x** is the register with the desired macro recording. Register `q` is the default register for macro recordings, so if you have recorded into register `q` you may simply type `@@` to run the macro.

(Note: Keep in mind that scripts or mappings may sometimes use an arbitrary register--so if you have a conflict, especially with a third party script or mapping, you should consider recording to a different register. You can view the contents of a register with the _:registers_ command.)

##### Example 1[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-7)]

As a simple example, suppose you have the following lines in the buffer, and you want each line to repeat the last word on the line. Initially, the buffer looks like this:
    
    
    The quick brown fox jumps over the lazy dog
    The sly gray fox circles around the unsuspecting rabbit
    The slow gray fox crawls under the rotting fence
    

And you want the buffer to look like this: (where additions are highlighted in bold)
    
    
    The quick brown fox jumps over the lazy dog **dog**
    The sly gray fox circles around the unsuspecting rabbit **rabbit**
    The slow gray fox crawls under the rotting fence **fence**
    

To do this, start recording into the default register with `qq`, then append the line with `A`, type a space, then `Ctrl-P`, then press the `ESC` key. To finish recording, press `q` again. Now the macro has been recorded into register **q**. To repeat the command, move down one line, and repeat the command by typing `@@` or `@q`. You can use `@@` to run this macro because q is the default register for macros.

##### Example 2[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-8)]

In another example, suppose you have the following lines in the register:
    
    
    The quick brown fox jumps over the lazy dog dog
    The sly gray fox circles around the unsuspecting rabbit rabbit
    The slow gray fox crawls under the rotting fence fence
    

and you want to put HTML tags around the animal names (fox, dog and rabbit) to make them bold (eg, `fox` needs to become `<b>fox </b>`). Suppose you want to use register **a** for the macro.

To start, move the cursor onto the first animal name--_fox_. Place the cursor somewhere on the word, such as on the 'o' in fox. Begin recording by typing `qa`. Next, delete the word into register **b** by typing `"bdaw` _(see `:help aw` and `:help d` and `:help "` for an explanation of this command)_. Next, enter insert mode by typing `i` and then type `<b>` followed by `**Ctrl-O**`, then `"bP` _(see `:help i_CTRL-o` for an explanation of this command)_. Next, type `</b>` and press ESC. Finally, stop the recording by typing `q`. To repeat the command, move the cursor over the next word you wanted to surround with the HTML tags and run the macro by typing `@a`. You can see what the macro looks like by examining the register. To do so, you may run the command `:registers a`. In this case, vim will show the following output:
    
    
    --- Registers ---
    "a   "bdawi<b>**^O**"bP</b>**^[**  
    

Note that a recording remembers all your movement commands, so you will need to put the cursor in the correct starting position before you begin recording.

##### Example 2b: fixing a macro[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-9)]

Suppose you made a minor mistake in your macro, but the macro is rather complex and you don't want to repeat all those commands again. We would like to modify the contents of a register. In order to do this, we use the feature that typing `"_x_` in the escape mode uses the contents of register _x_ for the next delete, yank, or put.

Assume that we are using register **a**,

  * create a new line (this line will be eventually deleted) and put the register's contents on the line with `"ap` in the escape mode. This command is pasting (note the p in the command) the contents of register a (via "a) into the line.
  * Make the modifications as needed, and
  * put the modified line back into register **a** by moving to the start of the line (with `|`) and typing `"ad$` in the escape mode. (Do not use `"aD` because D will capture the newline character in the buffer as well.)
  * Test the macro to be sure it is working properly, then use it as needed.

#### Executing a command macro[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-10)]

To execute a macro stored in register `q` once, you can just press `@q`. But often, you would not write a macro to execute it only once and here the full power of Vim kicks in.

To apply the command to the lines 23 through 42, use `:23,42norm! @q`, to apply it to all lines in your document use you can use `:%norm! @q`.

The same also works for single commands that you can access with the dot. If you have forgotten semicolons on some lines in your document, you would just execute `A;` followed by the `ESC` key. Then the command `:23,42norm! .` will apply the same action to the lines 23 to 42 and insert a semicolon at the end of each line.

#### Mapping a command[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Useful_things_for_programmers_to_know&action=edit&section=T-11)]

One of the advantages of mapping a new command is that you can put the mapping into your vimrc file for use later. I have the following mapping
    
    
    map <C-k> :!%:p<C-m>  
    

What this does is maps the _normal_ command Ctrl-K to run the current file as a script. You could also perform the second "Recording a command" exercise from above (encase a word in bold tags) with this mapping:
    
    
    map <C-x>b "bdawi<b><C-o>"bp</b><ESC>  
    

Note that in this case, I can get away with "<b>" because it doesn't match a special character name. However, if I needed to avoid a conflict (if I wanted to map an insertion of "<ESC>") I would use <lt> and <gt> for the less than and greater-than symbols. (See ":help key-codes")

If you want to map a command for insert mode, use imap instead of map.

If you want to prevent any of the commands in your map definitions from being interpreted in other mappings, use noremap (or inoremap for insert mode _inoremap meaning **i**nsert mode **no** **re**-**map**_)

  


  


## Enhancing VIM[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-1)]

### The .vimrc file[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-2)]

You can make a configuration-file called .vimrc in your home directory and save any particular settings. The existence of a **vim**rc has the side effect of making vim enable all of vim's incompatible changes to vi, making it more user-friendly. The name of the file depends on the operation system and userinterface used:

.vimrc
Text-User-Interface on UNIX and VMS

_vimrc
Text-User-Interface on MS-Windows and VMS

.gvimrc
Graphical-User-Interface on UNIX and VMS

_gvimrc
Graphical-User-Interface on MS-Windows and VMS

The alternatives with the underscore are for compatiblity with older filesystem. If you use vim on several operating system and use a modern MS-Windows filesystem you don't have to maintain two configurations files. it is perfectly Ok to set _vimrc to:
    
    
    source ~/.vimrc
    

and do all your configurations in `.vimrc`.

This is an example .vimrc file here:
    
    
    "Everything after a double quote is a comment.
    
    "Wrap text after 72 characters
    set textwidth=72
    
    "Set tabs to 4 spaces
    set tabstop=4
    set shiftwidth=4
    set stselect=4
    set expandtab
    
    "tell vim I use a dark background.  Syntax highlighting (color coded text) will adjust to more appropriate colors.
    set background=dark
    
    "misc overwrites of default color highlighting.
    hi Comment ctermfg=DarkGreen
    hi String ctermfg=DarkMagenta
    hi pythonPreCondit ctermfg=Green
    
    "make sure that bottom status bar is running.
    set ruler
    set laststatus=2
    
    "make a mapping for "Q" which will reformat the current paragraph, comment,
    "or code block according to the formatoptions setting:
    map Q gqap
    

### Syntax Highlighting[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-3)]

Syntax highighting is what allows you to highlight program code and other files for better readability, using colorization, bold, and other font modifications.

You may want to write simple syntax highlighting statements for easily detected patterns in your file. That said, if you are thinking you need syntax highlighting for html, don't worry: most users do not need to define a syntax highlighting file for common filetypes--most of the file types common developers are interested have already been given a default syntax highlighting definition with vim. Even if it doesn't come with vim, you can usually find someone who has shared their work on vim.org. However, if you need to write something simple, this section is for you. (If you need a syntax highlighting definition that will correctly show perl code even inside an HTML "pre" tag inside a perl print statement within a shell heredoc in a shell script, you're probably out of luck and this section probably won't meet your needs--but you might as well search vim.org, just in case someone has done it for you already).

Syntax Highlighting is one of the most powerful features of VIM. However, it can also be one of the most difficult things to set up--if you don't know what you're doing (or if you just don't have the patience, or if you're dealing with complex program language grammars). So lets have a look at some easy highlighting definitions:

#### Lesson 1: Highlight Tabs[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-4)]

    ... or how to highlight a special characters

Say you need to know where in your file are tabs and where are spaces. With the following highlight you make tabs visible:
    
    
    :syntax match Special "\t"
    

syntax match matches a regular expression and applies the given color to it. In this case it is the color "Special". You must make sure that the color "Special" has a non standard background - otherwise you won't see a difference:
    
    
    :highlight Special guifg=SlateBlue guibg=GhostWhite
    

You can also create a map in your .vimrc - so you can always activate the tab highlight:
    
    
    :nnoremap <F12><Tab>      :syntax match Special "\t"<CR>
    :inoremap <F12><Tab> <C-O>:syntax match Special "\t"<CR>
    

Another approach is to use listchars. These would be tabs, trailing spaces and line ends. Note the use of ">-" instead of the default "^I". That prevents the layout change when showing/hidding listchars:
    
    
    :set lcs=tab:>-,trail:%,eol:$ <CR>
    :map <F12> :set list!<CR>
    

#### Lesson 2: Highlight Space errors[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-5)]

    ... or how to highlight spaces at the end of line
    ... or how to find spaces and/or tabs
    
    
    :syntax match Error "\s\+$"
    

#### Lesson 3: Highlight Tab errors[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-6)]

    ... or how to not highlight characters serving as delimiter

Knowing where tabs are is good. But what about spaces before tabs? They just waste space in your file. The following highlight will show them to you:
    
    
    :syntax match Error " \+\t"me=e-1
    

The regular expression `" \\+\t"` searches for one or more space followed by a tab. That alone would solve the problem but would highlight the tab as error as well. Even better would be if we could highlight only the spaces and leave the tab as it is. And indeed this is possible and done by the `me=e-1`. Basically it says: End the highlight one character before the last character found.

#### Lesson 4: Highlight Line length[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-7)]

    ... or how to highlight at a specific column
    ... or how to highlight inside other patterns
    ... or how to allow other pattern inside

The following match will highlight the column 78 when the line is 78 characters long. This can serve as a warning when you have a line which is longer than you wish it to be. Of course, such a highlight should not interfere with any other highlight you might use:
    
    
    :syntax match Error "\(^.\{79\}\)\@<=." contains=ALL containedin=ALL
    

Here is a description of how it works:

  1. The regular expression `\\(^.\\{79}\\)` searches for exactly 79 characters from the beginning of the line `^` and group `\\( \\)` the result.
  2. `\@<=` will now "zero match" the group from 1. "zero match" means the text must be present, but is ignored once found.
  3. with `.` one more character is matched. This character is highlighted using the Error colour.
  4. With `contains=ALL` we allow other highlight patterns to start inside our pattern.
  5. `containedin=ALL` we allow our highlight pattern to start inside another pattern.

An alternative method is suggested by the vim help system. This pair of commands will highlight all characters in virtual column 79 and more:
    
    
    :highlight rightMargin ctermfg=lightblue
    :match rightMargin /.\%>79v/
    

And this will highlight only column 79:
    
    
    :highlight col79 ctermbg=red
    :highlight col79 guibg=red
    :match col79 /\%<80v.\%>79v/
    

Note the use of two items to also match a character that occupies more than one virtual column, such as a TAB. In the last example, a separate ctermbg and guibg definition was added so that col79 does something in both vim and gvim.

### Omni Completion[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-8)]

From version 7 onwards vim supports omni completions. This form of completions should work over several files and support all the twirks of a programming language. However, for it to work you need an appropiate "*complete.vim" script in your "autoload/" directory. This script must define a function called **...#Complete** which does all the completion work for the programming language at hand.

However writing a useful complete function can be a diffcult task. All the provided complete functions span several hundred lines of code.

Here a simple implementation used for the [Ada programming language](/wiki/Ada_Programming) described in detail so you can create your own. This implementation need a "tags" file which - for ada - you can create with `gnat xref -v`.

The full version can be download from the [vim.org side](http://www.vim.org/scripts/script.php?script_id=1609)

#### Step by Step walkthrough[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-9)]

Set completion with <C-X> <C-O> to autoloaded function. This check is in place in case this script is sourced directly instead of using the autoload feature.
    
    
    if **exists** ('+omnifunc') && &omnifunc == ""
        setlocal omnifunc=**adacomplete#Complete**
    endif
    

Omnicompletion and autoload won't work with any vim less then 7.00.
    
    
    if version < 700
        finish
    endif
    
    

All **complete#Complete** functions have to cover two options: `a:findstart == 1` and `a:findstart != 1`.
    
    
        function **adacomplete#Complete** (findstart, base)
    

##### Findstart equals 1[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-10)]

When `a:findstart == 1` then we have to find out how many characters left of the cursor could be a part of an completion:
    
    
       if a:findstart == 1
    

For our simple example finding the beginning of the word is pretty simple. We look left until we find a character wich cannot be part of a word. For most languages searching for “\i” should do the trick. However, for Ada we want to expand [Attributes](/wiki/Ada_Programming/Attributes) as well - hence we add “'” to the list of word characters.
    
    
           let line = **getline** ('.')
                let start = **col** ('.') - 1
                while start > 0 && line[start - 1] =~ '\i\|'''
                    let start -= 1
                endwhile
                return start
    

##### Findstart not equal 1[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-11)]

When `a:findstart != 1` then we need to find possible completions for `a:base`. There are two option open to return the found completions:

  1. returning them all as a List with return.
  2. calling **complete_add** for each completion found.

You can also use a combination of both - they will be merged then - so beware not to create duplicates. A completion can either be a String or a Directory.

In this example we use **complete_add**.
    
    
       else
    

The search pattern should look for a:base at the beginning of the text matched.
    
    
           let l:Pattern    = '^' . a:base . '.*$'
    

In a first step we add all known Ada [Keywords](/wiki/Ada_Programming/Keywords), [Pragmas](/wiki/Ada_Programming/Pragmas), [Attributes](/wiki/Ada_Programming/Attributes) and [Types](/wiki/Ada_Programming/Types). They have been prepared as a List of Directorys by the [Ada file-type plugin](http://www.vim.org/scripts/script.php?script_id=1548). All we have to to is iterate over the list and add all where the Directory entry “word” matches the pattern.
    
    
           if **exists** ('g:Ada_Keywords')
                    for Tag_Item in g:Ada_Keywords
                        if l:Tag_Item['word'] =~? l:Pattern
    

Add the value - incl. simple error handling.
    
    
                       if **complete_add** (l:Tag_Item) == 0
                                return []
                            endif
                            {{vi/Ex|if} **complete_check** ()
                                return []
                            endif
                        endif
                    endfor
                endif
    

##### Searching for matches[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/Enhancing_Vim&action=edit&section=T-12)]

Here the real work is done: We search for matches inside the tag file. Of course you need a tag file first. There are many tools to create vim compatible tag files. Just have a look around for one.
    
    
           let l:Tag_List = **taglist** (l:Pattern)
    

Again we need to iterate over all List elements found.
    
    
           for Tag_Item in l:Tag_List
                    if l:Tag_Item['kind'] == 
                        let l:Tag_Item['kind'] = 's'
                    endif
    

Since the Directory structure for tags and completions are different the data needs to be converted.

The informations available inside the tag depend on the tag-file creation tool. But the minimum is:

“name” 
    Name of the tag.
“filename” 
    Name of the file where the tag is defined.
“cmd” 
    Ex command used to locate the tag in the file.
“kind” 
    Type of the tag. The value for this entry depends on the language specific kind values generated by the ctags tool.

The contest of the completion is fixed and contains the following:

“word” 
    The actual completion
“kind” 
    The type of completion, one character, i.E. “v” for variable.
“menu” 
    Short extra info displayed inside the completion menu.
“word” 
    Long extra info displayed inside an extra window.
“icase” 
    Ignore case

So for simple tags without any extras the conversion could look like this:
    
    
               let l:Match_Item = {
                        \ 'word':  l:Tag_Item['name'],
                        \ 'menu':  l:Tag_Item['filename'],
                        \ 'info':  "Symbol from file " . l:Tag_Item['filename'] . " line " . l:Tag_Item['cmd'],
                        \ 'kind':  l:Tag_Item['kind'],
                        \ 'icase': 1}
                    if **complete_add** (l:Match_Item) == 0
                        return []
                    endif
                    if **complete_check** ()
                        return []
                    endif
                endfor
    

Please note 
    The current Ada plugin has been extended to also support `ctags` which gives more information than `gnat xref -v`. However we have not updated the walkthrough as we want to keep the example simple and easy to follow.

We already added all matches via **complete_add** so we only return an empty list.
    
    
           return []
            endif
        endfunction **adacomplete#Complete**
        finish
    endif
    

One last advice: It your tag tool does not sort the entries then you should sort them separately. Searches on sorted tag-files are significantly faster.

  


VimL (aka [Vimscript, or Vim script](//en.wikipedia.org/wiki/Vimscript)) is a full feature scripting language, meaning it can solve almost any text processing problem.

## Statements[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**The text in its current form is incomplete.**

create a file to use do, while loop to key in person data

## Data types[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-2)]

There are five datatypes:

### Number[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-3)]

A 32 bit signed integer.

### String[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-4)]

A NULL terminated string of 8-bit unsigned characters (bytes). Strings can be created by either ‘'’ or ‘"’ quotes. When using strings quoted with the double quote ‘"’ the text is interpreted i.e. "\n" becomes a new line while strings quoted with a single quote ‘'’ are not interpreted, i.e. '\n' means just that, a backslash and an n. The following two strings are identical:
    
    
    let String_1 = "C:\\WinNT"
    let String_2 = 'C:\WinNT'
    

Any other datatype can be converted into a string using the **string** () function.

### Funcref[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-5)]

A reference to a function. A Funcref can be created from a string by the use of the **function** function.
    
    
    let Function_1 = **function** ("MyFunc")
    

### List[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-6)]

An ordered sequence of items.
    
    
    let List_1 = [
        \ "a",
        \ "b",
        \ "c"]
    

A list can be created from a string by the use of the **split** function.
    
    
    let List_2 = **split** ("a b c")
    

### Dictionary[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-7)]

An associative, unordered array: Each entry has a key and a value.
    
    
    let Dictionary_1 = {
        \ 1: 'one', 
        \ 2: 'two',
        \ 3: 'three'}
    

### Objects[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-8)]

VIM also supports object oriented programming by combining Funcref and Dictionary to an Object:
    
    
    let mydict = {
        \'data': [0, 1, 2, 3]}
    
    function **mydict.len** () dict
       return **len** (self.data)
    endfunction **mydict.len**
    

for more information see Object oriented programming

## Control Structures[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-9)]

The existence of control structures is the main difference between vi's ex commands and vim's scripting language. They make the difference between a simple command set (vi) and a full features script language (vim).

### condition[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-10)]
    
    
    if _condition_
        _operations_
    elseif _condition_
        _operations_ 
    else
        _operations_ 
    endif
    

### loop[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-11)]

#### while[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-12)]
    
    
    while _condition_
        _operations_
    endwhile
    

#### for[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-13)]

For loops are available from vim 7 onwards. They iterate over List or Directory structures.
    
    
    for _var_ in _list_
        _operations_
    endfor
    

### exceptions[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-14)]
    
    
    try
        _operations_
    catch /_pattern_/
        _error handling operations_
    finally
        _clean-up operations_
    endtry
    

## Subprograms[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-15)]

### Simple Subprograms[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-16)]

Like most [Shell-Languages](//en.wikipedia.org/wiki/Shell_\(computing\)) all subprograms are stored in separate files which you load either with the source or runtime command. The difference lies in the use of a search path. runtime uses a search path and allows wildcards to find the sub-program while source need the full path. The following commands do the same - provided that "~/vimfiles" is part of your runtime search path:
    
    
    runtime setup.vim
    source  ~/vimfiles/setup.vim
    

For both commands need to add the `.vim` extension. Since runtime supports both a search path and wildcards more than one match is possible. If you want runtime to load all the matches - and not just the first hit - use runtime!.

### Functions[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-17)]
    
    
    function _f_ ( _parameter_ )
        _operations_
    endfunction
    

New with vim 7 is the autoload option for functions. If you name a function _Filename_#_Functionname_ or _Directory_#_Filename_#_Functionname_ then the function will be automatically loaded on first call. The file containing the function must be placed in one of the "autoload" runtime directories and be named "Filename.vim" or "Directory/Filename.vim". This option is especially useful for functions which you don't always need on in Object oriented programming.

### Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-18)]
    
    
    command **Command** _Command_
    

Command are often used as shortcut for functions and subprograms:
    
    
    command **C** -nargs=* call F ( <f-args> )
    command **C** source ~/vimfiles/s.vim
    

## Object oriented programming[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-19)]

Vim 7 now allows [object oriented programming](/wiki/Object_Oriented_Programming). However, in order to make it real you need to combine several features, namely Dictionaries, Funcrefs and the new function autoload.

The following example class is taken from the gnat compiler plugin for vim. The actual functions implementations have been removed as they are not needed to understand the concept. If you like to have a look at the full version you can download the plugin from [vim.org site](http://www.vim.org/scripts/script.php?script_id=1609).

### Step by Step walk-through[[edit](/w/index.php?title=Learning_the_vi_Editor/Vim/VimL_Script_language&action=edit&section=T-20)]

We add our new class to a autoload script. That way the class is available when and only when needed:
    
    
    if **exists** ("g:loaded_gnat_autoload") || version < 700
        finish
    else
       let g:loaded_gnat_autoload=1
    

Each function we define need to be defined with the "dict" attribute. Apart from that they are just normal scripting functions.
    
    
       function **gnat#Make** () dict
          ...
          return
       endfunction gnat#Make
    
       function **gnat#Pretty** () dict
          ...
          return
       endfunction gnat#Make
    
       function **gnat#Find** () dict
          ...
          return
       endfunction gnat#Find
    
       function **gnat#Tags** () dict
          ...
          return
       endfunction gnat#Tags
    
       function **gnat#Set_Project_File** (...) dict
          ...
          return
       endfunction **gnat#Set_Project_File**
    
       function **gnat#Get_Command** (Command) dict
          ...
          return ...
       endfunction **gnat#Get_Command**
    

The most important step is the composition of the object. In most OO languages this happens automatically - But with vim we have to do this ourselves. For best flexibility the use of a so called constructor function is suggested. The constructor is not marked with "dict":
    
    
       function **gnat#New** ()
    

The constructor creates a dictionary which assigns all the object functions to one element of the dictionary:
    
    
          let Retval = {
             \ 'Make'             : **function** ('gnat#Make'),
             \ 'Pretty'           : **function** ('gnat#Pretty'),
             \ 'Find'             : **function** ('gnat#Find'),
             \ 'Tags'             : **function** ('gnat#Tags'),
             \ 'Set_Project_File' : **function** ('gnat#Set_Project_File'),
             \ 'Get_Command'      : **function** ('gnat#Get_Command'),
             \ 'Project_File'     : _,_
    

We optionally can now add data entries to our object:
    
    
        \ 'Make_Command'     : '"gnat make -P " . self.Project_File . "  -F -gnatef  "',
             \ 'Pretty_Command'   : '"gnat pretty -P " . self.Project_File . " "',
             \ 'Find_Program'     : '"gnat find -P " . self.Project_File . " -F "',
             \ 'Tags_Command'     : '"gnat xref -P " . self.Project_File . " -v  *.AD*"',
             \ 'Error_Format'     : '%f:%l:%c: %trror: %m,'   .
                                  \ '%f:%l:%c: %tarning: %m,' .
                                  \ '%f:%l:%c: (%ttyle) %m'}
    

If needed additional modifications to the object are also possible. At this stage you can already use the OO-way:
    
    
          if **argc**() == 1 && **fnamemodify**(**argv** (0), ':e') == 'gpr'
             call **Retval.Set_Project_File**(argv(0))
          elseif  **strlen**(v:servername) > 0
             call **Retval.Set_Project_File**(v:servername . '.gpr')
          endif
    

The last operation of the constructor is the return of the newly created object.
    
    
          return Retval
       endfunction **gnat#New**
    

It is also possible to defined additional non dict functions. These functions are the equivalent to the "static" or "class" methods of other OO languages.
    
    
       function **gnat#Insert_Tags_Header**()
          ...
          return
       endfunction **gnat#Insert_Tags_Header**
    
       finish
    endif
    

  


# vile[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=9)]

## Vile - vi like Emacs[[edit](/w/index.php?title=Learning_the_vi_Editor/vile&action=edit&section=T-1)]

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[VILE**_](//en.wikipedia.org/wiki/VILE)

### Overview[[edit](/w/index.php?title=Learning_the_vi_Editor/vile&action=edit&section=T-2)]

**vile** is a vi clone which doesn't claim to be a vi clone. The idea behind vile is to have an editor which works similar to vi but provides features for editing multiple files in multiple window-areas like emacs. In fact, vile development started by using MicroEMACS as the base, and not a vi clone, and also not full blown Emacs. MicroEMACS is an emacs-like editor (MicroEMACS's author didn't like full-blown emacs, and the vile authors didn't like (Micro)EMACS mode-less way of working). So vile was developed.

vile provides the most common vi commands (as used by their authors), but not all vi commands. The implemented commands are supposed to work more or less like the original vi commands. The window management and buffer management came from MicroEMACS.

Much work has gone into the vile documentation after the first versions were almost undocumented. It is recommended to consult the documentation to find out the differences and extensions of vile, compared to vi.

### Resources[[edit](/w/index.php?title=Learning_the_vi_Editor/vile&action=edit&section=T-3)]

  * [vile](http://invisible-island.net/vile/)
  * [MicroEMACS](http://uemacs.tripod.com/nojavasc.html)

  


# BusyBox vi[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=10)]

## Overview[[edit](/w/index.php?title=Learning_the_vi_Editor/BusyBox_vi&action=edit&section=T-1)]

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[BusyBox**_](//en.wikipedia.org/wiki/BusyBox)

BusyBox is a very popular program on many embedded Linux systems. In fact, someone working on an embedded Linux system is very likely to encounter BusyBox. BusyBox combines tiny versions of many common UNIX utilities into a single relatively small executable. One of the included utilities is a vi clone.

The BusyBox vi clone is limited. Among the limits are:

  * It does not support all common vi commands.
  * It supports the '!' command to execute a child process, but does not capture process output
  * It also lacks the normal vi crash recovery feature.
  * It always assumes a vt102 type terminal (emulator)
  * Only very few settings are configurable via `:set`
  * `.exrc` configuration and configuration via environment variables are not supported
  * Line marks are not correctly adjusted if lines are inserted or deleted before the mark.
  * Only whole-line undo (uppercase 'U'), no last-change undo (lowercase 'u') is supported.
  * Searches ignore case by default, but can be case sensitive using `:set noignorecase`
  * Command-counts need to prefix a command
  * command counts for `a`, `c`, `i`, `r`, `y` and several other commands are not supported.
  * A limited set of ex commands are supported.

In short, a lot of information in this vi tutorial is not applicable to BusyBox vi.

However, BusyBox vi also has some differences (considered by some to be enhancements) over classic vi:

  * Cursor navigation in insert and command mode
  * <INSERT> key changes to insert mode
  * No wrapping of long lines. Long lines are displayed via side-scrolling.

### Weblinks[[edit](/w/index.php?title=Learning_the_vi_Editor/BusyBox_vi&action=edit&section=T-2)]

  * [BusyBox home page](http://busybox.net)
  * [BusyBox vi source code](http://git.busybox.net/busybox/plain/editors/vi.c)

  


# vi Reference[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=11)]

The following conventions are used in this reference.

  


<c>
    A single character, such as 'a' or '1'.
<ESC>, <Ctrl-[>
    Indicates that the Escape (Esc) key on your keyboard should be pressed, which is identical to Control and '['.
<CR>
    Indicates that the Return (Enter) key should be pressed.
<TAB>
    Indicates that the Tabulator key should be pressed
<Ctrl-x>, <C-x>
    Indicates that the Control key and the 'x' key should be pressed simultaneously. 'x' can be almost any other key on your keyboard.
<Shift-x>, <S-x>, <X>
    Indicates that the Shift key and the 'x' key should be pressed simultaneously
<Meta-x>, <M-x>
    Indicates that the Meta or Alt key and the 'x' key should be pressed simultaneously.
:quit, :q
    An Ex command. started with <:>, followed by the command and ends with <CR>. For many Ex commands there is a long form (:quit) and a short form (:q).
:set **nocompatible** 
    represents a setting.
**strlen** () 
    represents a function.
/_pattern_/, ?_pattern_?
    A Search pattern. Search pattern in vi are [regular expressions](//en.wikipedia.org/wiki/regular_expression).
:_range_s/_search_/_replace_/_options_, :global /_pattern_/ delete
    A Search pattern combined with an Ex command.

All commands in _vi_ are case sensitive.

  


_c_
A single character, such as 'a' or '1'.

_m_
A single lowercase letter, used to mark text.

_string_
Several characters, such as 'abc bed'.

_pattern_
A string used in searching, which may contain regular expressions. For example 'abc' or '^ab[123]'.

_myfile_
The name of a file to be edited.

## Invocation[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-1)]

**vi myfile**
Open the file _myfile_ for editing. If it does not exist, a new file is created. Multiple files can be opened at the same time.

**vi +line myfile**
Open the file _myfile_ with the cursor positioned at the given line. 

  * **vi +5 myfile** opens _myfile_ at line 5.
  * **vi + myfile** opens _myfile_ at the last line.

**vi +/string/ myfile**
Open the file _myfile_ with the cursor positioned at the first line containing the string. If the string has spaces it should be enclosed in quotes. 

  * **vi +/"search string"/ myfile** opens _myfile_ at the first line containing _search string_.

**vi -r**
Lists recovery copies of files. A recovery copy is taken if a **vi** session is killed or the system crashes.

**vi -r myfile**
Opens a recovery copy of the file _myfile_.

**view myfile**
**view** is a read only version of **vi**. All **vi** commands, include those to change the file are allowed and act as in **vi**. The difference is that normal attempts to save, **ZZ** or **:wq** do not work. Instead **:x!** or **:w** need to be used.

## vi Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-2)]

### Movement[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-3)]

**vi** can be set up on most systems to use the keyboard movement buttons, such as _cursor left_, _page up_, _home_, _delete_, etc.

<G>
Move to the last line of the file. Can be preceded by a number indicating the line to move to, <1><G> moves to the first line of the file.

<h>
Move left one character, or cursor left. Can be preceded by a number, <5><h> moves left 5 places.

<j>
Move one line down, or cursor down. Can be preceded by a number, <5><j> moves down 5 lines.

<k>
Move one line up, or cursor up. Can be preceded by a number, **5k** moves up 5 lines.

<l>
Move forward one character, or cursor right. Can be preceded by a number, **5l** moves right 5 places.

* * *

<H>
Moves to the line at the top of the screen.

<M>
Moves to the line in the middle of the screen.

<L>
Moves to the line at the bottom of the screen.

* * *

<->
Moves to the first non-whitespace character of the line above. Can be preceded by a number. 

  * **10-** moves up 10 lines.

<+>
Moves to the first non-whitespace character of the line below. Can be preceded by a number. 

  * **10+** moves down 10 lines.

<CR>
Same as <+>.

<>
Must be preceded by a number. Moves to the specified column on the current line. 

  * **10|** moves to column 10.

* * *

<w>
Moves to the start of the next word, which may be on the next line.

<W>
As **w** but takes into account punctuation.

<e>
Moves to the end of the current word or to the next word if between words or at the end of a word.

<E>
As **e** but takes into account punctuation.

<b>
Moves backwards to the start of the current word or to the previous word if between words or at the start of a word.

<B>
As **b** but takes into account punctuation.

* * *

<f>_c_
Find first occurrence of character _c_ on the same line. 

This command may be repeated using <;> or <,> (reverse direction).

  * <3><f><x> moves forward on the third occurrence of x (if present).

    Same as <f><x><;><;>

<F>_c_
Same as **f** but backward.

<t>_c_
Find the character before the first occurrence of character _c_ on the same line.

<T>_c_
Same as **t** but backward, placing the cursor after character _c_.

* * *

<0>
Moves to the start of the current line.

<^>
Moves to the first non-whitespace character on the current line.

<$>
Moves to the end of the current line.

* * *

<Ctrl-F>
Move forwards one page. 

  * **5<Ctrl-F>** moves forwards five pages.

**<Ctrl-B>**
Move backwards one page. 

  * **5<Ctrl-B>** moves backwards five pages.

**<Ctrl-D>**
Move forwards by half a page.

**<Ctrl-U>**
Move backwards by half a page.

**<Ctrl-E>**
Display one more line at the bottom of the screen.

**<Ctrl-Y>**
Display one more line at the top of the screen.

### Inserting[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-4)]

All insert commands put **vi** into _insert mode_. _Insert mode_ is terminated by the ESC key.

<i>
Enters _insert mode_ at the cursor position.

<I>
Enters _insert mode_ at the start of the current line.

* * *

<a>
Enters _insert mode_ after the cursor, or appends.

<A>
Enters _insert mode_ at the end of the current line, or append to the end of the current line.

* * *

<o>
Inserts a new line underneath the current line and then goes into _insert mode_.

<O>
Inserts a new line above the current line and then goes into _insert mode_.

### Replacing[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-5)]

**r**
Replaces the character underneath the cursor with the next character typed. Can be preceded by a number, **5ra** replaces 5 characters with the letter _a_.

* * *

**R**
Enters _replace mode_. Each time a letter is typed it replaces the one under the cursor and the cursor moves to the next character. _Replace mode_ is terminated by the ESC key. Can be preceded by a number, **5Rab** followed by ESC replaces the character under the cursor by _a_, the next character by _b_ and then inserts another 4 _ab_s. The original line is placed into the buffer, replacing any text already there.

### Deleting[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-6)]

Each time a delete command is used, the deleted text is placed into the buffer, replacing any text already in the buffer. Buffered text can be retrieved by **p** or **P**.

**dd**
Deletes the current line. Can be preceded by a number. 

  * **5dd** deletes five lines. **d5d** is the same as **5dd**.

**de**
Deletes from the character underneath the cursor to the end of the word. Can be preceded by a number. 

  * **5de** deletes five words. **d5e** is the same as **5de**.

**dE**
As **de** but takes into account punctuation.

**dw**
Deletes from the character underneath the cursor to the start of the next word. Can be preceded by a number. 

  * **5dw** deletes five words. **d5w** is the same as **5dw**.

**dW**
As **dw** but takes into account punctuation.

**db**
Deletes from the left of the cursor to the start of the previous word. Can be preceded by a number. 

  * **5db** deletes five words to the left of the cursor.

**dB**
As **db** but takes into account punctuation.

**dt**_c_
Deletes from the cursor position to before the first instance of the character. 

  * **dta** deletes text up and to, but not including, the first letter 'a'.

**df**_c_
Deletes from the cursor position to the first instance of the character. 

  * **dfa** deletes text up and to, and including, the first letter 'a'.

**dG**
Deletes the current line and everything to the end of the file.

**d/string**
Deletes from the cursor to the string, either forwards or backwards.

* * *

**D**
Deletes from the cursor to the end of the line.

**d$**
Same as **D**.

**d^**
Deletes from the left of the cursor to the start of the line.

* * *

**x**
Delete the character underneath the cursor. Can be preceded by a number. 

  * **5x** deletes the character underneath the cursor and the next 4 characters.
  * **xp** swaps the character underneath the cursor with the one to the right of it.

**X**
Delete the character to the left of the cursor, but will not delete the end of line marker or any characters on the next line. Can be preceded by a number. 

  * **5X** deletes 5 characters to the left of the cursor.

### Changing[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-7)]

The change commands all select text to be removed, the end of which is indicated by a **$**. Insert mode is entered and new text overwrites or extends the text. When the <ESC> key is pressed to terminate the insert, any remaining original text is deleted.

Text deleted during a change is placed into the buffer, replacing any text already there. Buffered text can be retrieved by **p** or **P**.

**C**
Change from the cursor position to the end of the line. Can be preceded by a number. 

  * **5C** changes 5 lines, the current line and the next 4 lines.

* * *

**c**_M_
Generally the same as **d**_M_**i**, where _M_ is any movement command.

**cc**
Change the current line. Can be preceded by a number. 

  * **5cc** changes 5 lines, the current line and the next 4 lines.

**ce**
Change the current word. Can be preceded by a number. 

  * **5ce** changes five words. **c5e** is the same as **5ce**.

**cw**
Exactly the same as **ce**.  


This command is inconsistent with the usual vi moving: **cw** and **ce** is the same as **dei** but **dwi** removes also the spaces until the next word.

**ct**_c_
Changes from the cursor position to the first instance of the character. 

  * **cta** changes text up and to, but not including, the first letter 'a'.

**cf**_c_
Changes from the cursor position to the first instance of the character (including the character _c_).

**cG**
Changes from the start of the current line to the end of the file.

* * *

**s**
Change the character underneath the cursor. Can be preceded by a number. 

  * **5s** changes 5 characters, the one under the cursor and the next 4.

### Cut and Paste[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-8)]

The _yank_ commands copy text into the _vi_ buffer. Text is also copied into the buffer by delete and change commands. The _put_ or _place_ commands retrieve text from the buffer.

**yy**
Yanks the current line into the buffer. Can be preceded by a number. 

  * **5yy** yanks five lines.

**Y**
Same as **yy**.

**yw**
Yanks from the cursor to the start of the next word into the buffer. Can be preceded by a number. 

  * **5yw** yanks five words.

* * *

**p**
If the buffer consists of whole lines, they are inserted after the current line. If it consists of characters only, they are inserted after the cursor.

**P**
If the buffer consists of whole lines, they are inserted before the current line. If it consists of characters only, they are inserted before the cursor.

### Searching[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-9)]

Searching uses [regular expressions](//en.wikipedia.org/wiki/regular_expression).

/_pattern_/
Searches for the string, which could be a regular expression. Searching is from the cursor position downwards, stopping at the first match. If not found, it will continue from the start of the file to the cursor position. The trailing slash character is optional. 

  * /abc/ seaches for the first occurrence of _abc_.

/_pattern_/+
Goes to the line after the one containing the search string. 

  * /abc/+3 goes to the third line after the one containing _abc_.

/_pattern_/e
Leaves the cursor on the last character of the string that _pattern_ matched.* By adding **+**_num_ or **-**_num_ after **e** you can supply an offset in characters to where the cursor gets left. For example: /foo/e+3 will leave the cursor 3 characters past the next occurrence of **foo**.* By using **b** instead of **e** you can specify a character offset from the beginning of the matched string.

/**\c**_pattern_/
Does a case insensitive search.

?_pattern_?
As /_pattern_/ but searches upwards. The trailing question mark character is optional.

?_pattern_?-
Goes to the line above the one containing the search string. 

  * ?abc?-3 goes to the third line above the one containing _abc_.

<n>
Repeat last search.

<N>
Repeat last search but in the opposite direction.

<f>_char_
Search forward on the current line for the next occurrence of _char_.

<F>_char_
Search backward on the current line for the next occurrence of _char_.

<t>_char_
Search forward on the current line for the next occurrence of _char_ and leave the cursor on the character before _char_.

<T>_char_
Search backward on the current line for the next occurrence of _char_ and leave the cursor on the character after _char_.

<;>
Repeat the last **f** or **F** search.

### Search and Replace[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-10)]

Search and replace uses [regular expressions](//en.wikipedia.org/wiki/regular_expression) and the Ex command :substitute (short :s) which has syntax similar to the [sed](//en.wikipedia.org/wiki/sed) utility - which is not surprising [sed](//en.wikipedia.org/wiki/sed), [Ex](//en.wikipedia.org/wiki/Ex_\(text_editor\)) and [w:Vi](//en.wikipedia.org/wiki/Vi) have common roots - the [Ed](//en.wikipedia.org/wiki/Ed_\(text_editor\)) editor.

:.s/_pattern_/_replacement_/
Replaces the first occurrence of _pattern_ on the current line with _replacement_.* If _pattern_ contains **\\(** and **\\)** they are used to remember what matched between them instead of matching parenthesis characters. For example **:.s/\\(\d*\\)-\\(\d*\\)/\2:\1/** could match the string **12345-6789** and substitute **6789:12345** for it.

:.s/_pattern_/_replacement_/g
Replaces all occurrences of _pattern_ on the current line with _replacement_.

:%s/_pattern_/_replacement_/g
Replaces all occurrences of _pattern_ in the whole file with _replacement_.

:x,ys/_pattern_/_replacement_/g
Replaces all occurrences of _pattern_ on lines _x_ through _y_ with _replacement_.* For example: :14,18s/foo/bar/g will replace all occurrences of **foo** with **bar** on lines 14 through 18. 

  * The character **.** can be used to indicate the current line and the character **$** can be used to indicate the last line. For example: :.,$s/foo/bar/g will replace all occurrences of **foo** with **bar** on the current line through the end of the file.

The following meta-characters have special meaning in the replacement pattern:

**&**
Replaced by the text that matched the search pattern.

**\n**
Replaced by the text matching the search pattern between _\\(_ and _\\)_, where _n_ is in the range of 1 through 9 with _\1_ being replaced by the match from the first set.

**\u**
Capitalize the next character (if the character is a letter).

**\l**
Lowercase the next character (if the character is a letter).

**\U**
Turn on capitalization mode, where all of the following characters are capitalized.

**\L**
Turn on lowercase mode, where all of the following characters are lowercased.

**\E**
Turn off capitalization or lowercase mode.

**\e**
Turn off capitalization or lowercase mode.

For example **.:s/\\(foo\\) \\(bar\\) \\(baz\\)/\u\1 \U\2\E \3/** could match the string **foo bar baz** and substitute **Foo BAR baz** for it.

### Mark Text[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-11)]

Marked lines can be used when changing or deleting text.

<m>_m_
Mark the current line with the letter. 

  * <m><a> marks the current line with the letter _a_.

<'>_m_
Move to the line marked by the letter. 

  * <'><a> moves to the line marked by _a_.

### Screen Refresh[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-12)]

**<Ctrl-L>**
Refresh the screen.

**z<CR>**
Refreshes the screen so that the current line is at the top. Can be preceded by a line number. 

  * **35z** refreshes the screen so that line 35 is at the top.

**/pattern/z**
Finds the line with the first occurrence of _string_ and then refreshes the screen so that it is at the top.

**z.**
Refreshes the screen so that the current line is in the middle of the screen. Can be preceded by a line number, in which case the line is at the middle. The sequence **zz** also has the same effect. 

  * **35z.** refreshes the screen so that line 35 is in the middle.

**/string/z.**
Finds the line with the first occurrence of _string_ and then refreshes the screen so that it is in the middle.

**z-**
Refreshes the screen so that the current line is at the bottom. Can be preceded by a line number, in which case the line is at the bottom. 

  * **35z-** refreshes the screen so that line 35 is at the bottom.

**/string/z-**
Finds the line with the first occurrence of _string_ and then refreshes the screen so that it is at the bottom.

### Others[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-13)]

<~>
Changes the case of the character underneath the cursor and moves to the next character. Can be preceded by a number, so that **5~** changes the case of 5 characters.

<.>
Repeats the last insert or delete. Can be preceded by a number, **dd** followed by **5.** deletes a line and then deletes another 5 lines.

<%>
Moves the cursor to the matching bracket, any of (), [] or {}.

<Ctrl-G>
Temporarily displays a status line at the bottom of the screen.

:f
Same as <Ctrl-G>.

<J>
Joins the next line to the end of the current line. Can be preceded by a number. Both **1J** and **2J** do the same as **J**. 

  * **3J** joins three lines together, the current line and the next two lines.

<u>
Undoes the last change. A second **u** puts the change back.

<U>
Undoes all changes to the current line.

<Ctrl-Z>
Puts _vi_ into the background, that is control is returned to the operating system. In UNIX, the _vi_ session can be returned to the foreground with **fg**.

### Saving and Quitting[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-14)]

<Z><Z>
Saves and quits. It is symbolic of sleep, indicating the end of work.

:quit  
:q
Quits, but only if no changes have been made.

:quit!  
:q!
Quits without saving, regardless of any changes.

:write  
:w
Saves the current file without quitting. 

  * {Vi/Ex|:write!}} **myfile** saves to the file called _myfile_.

:write!_filename_  
:w!_filename_
Saves to the file, overwriting any existing contents.

:wq  
:write|quit
Saves and quits.

:exit  
:xit  
:x
Saves and quits.

:exit!  
:xit!  
:x!
Used to save and quit in **view**.

### Files[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-15)]

**:e filename**
Quits the current file and starts editing the named file.

**:e + filename**
Quits the current file and starts editing the named file with the cursor at the end of the file. 

  * **:e +5 myfile** quits the current file and begins editing _myfile_ at line 5.

**:e!**
The current file is closed, all unsaved changes discarded, and the file is re-opened for editing.

**:e#**
Quits the current file and starts editing the previous file.

**:n**
When multiple files were quoted on the command line, start editing the next file.

**:n files**
Resets the list of files for **:n**. The current file will be closed and the first file in the list will be opened for editing.

**:r filename**
Read a file, that is insert a file. 

  * **:r myfile** inserts the file named _myfile_ after the cursor.
  * **:5r myfile** inserts the file after line 5.

## vi Options[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-16)]

All options are _ex_ options, and so require an initial colon.

Default options may be placed into a file in the user's home directory called **.exrc**. Options in this file do not have the initial colon, e.g.

    **set ic**

**:set all**
Displays all the current settings.

! Set on
! Set off
! Meaning

**:set ignorecase**  
**:set ic**
**:set noignorecase**  
**:set noic**
Ignore case. Makes searching case insensitive.

**:set list**
**:set nolist**
Shows control characters. _<Ctrl-I>_ is tab, _$_ is linefeed.

**:set number**  
**:set nu**
**:set nonumber**  
**:set nonu**
Turns on line numbering.

**:set term**
Displays the terminal type.

## ex Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-17)]

**ex** commands start with **:**, which puts _vi_ into _last line mode_, entered on the last line of the screen. Spaces within the command are ignored.

**:! command**
Executes the named operating system command and then returns to **vi**. 

  * **:! ls** runs the UNIX _ls_ command.

**:sh**
Starts up a shell. **exit** returns to the **vi** session.

**:vi**
Exit _last line mode_ and return to normal _command mode_.

  


### ex line commands[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-18)]

These commands edit lines and have the following syntax:

  1. No line number, meaning work on the current line.
  2. With **%**, meaning work on all lines.
  3. A pair of line numbers, such as '3,5' meaning work on lines 3 to 5 inclusive. Either number can be replaced with **.**, standing for the current line or **$** standing for the last line. So **.,$** means from the current line to the end of the file and **1,$** means the same as **%**. Additionally simple arithmetic may be used, so **.+1** means the line after the current line, or **$-5** means 5 lines before the last line.

  


**co**
Copy, followed by the line position to copy to. 

  * **:co 5** copies the current line and places it after line 5. 
    * **:1,3 co 4** copies lines 1 to 3 and places after line 4.

**d**
Delete. 

  * **:d** deletes the current line. 
    * **:.,.+5d** delete the current line and the next 5 lines.
    * **:%d** deletes all lines.

**m**
Move, followed by the line position to move to. 

  * **:m 10** moves the current line and places it after line 10. 
    * **:1,3 m 4** moves lines 1 to 3 and places after line 4.

### Mapping / Remapping vi Commands[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-19)]

**:map**
Create new command or overwrite existing in vi command mode. 

  * **:map v i--<Ctrl-[>** new command **v** will insert _\--_ and return to command mode. <Ctrl-[> is the escape character typed as <CTRL-V><ESC>.

**:map!**
Create new command in both command and insert mode. 

  * **:map! ;r <Ctrl-[>** typing _;r_ in insert mode will return to command mode.

## External link[[edit](/w/index.php?title=Learning_the_vi_Editor/vi_Reference&action=edit&section=T-20)]

  * [vim Official Reference Manual](http://vimdoc.sourceforge.net/htmldoc/ref_toc.html)
  * [An introduction to the vi editor](http://planzero.org/tutorials/introduction_to_the_vi_editor.php)
  * [Learning Unix in 10min](http://freeengineer.org/learnUNIXin10minutes.html)

  


# Authors[[edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit&section=12)]

This book has many authors, including the public: it is open for anyone and everybody to improve. Therefore, this is more properly a list of acknowledgements of contributors than a list of authors. Whoever we are, this is where we get to brag about our accomplishments in writing this book.

## List of major contributors[[edit](/w/index.php?title=Learning_the_vi_Editor/Authors&action=edit&section=T-1)]

  * [Dysprosia](/wiki/User:Dysprosia) ([Contributions](/wiki/Special:Contributions/Dysprosia))
  * [Martin Krischik](/wiki/User:Krischik) [Learning the vi Editor/Vim](/wiki/Learning_the_vi_Editor/Vim) ([Contributions](/wiki/Special:Contributions/Krischik))
  * N.N.(anonymous): The advanced/Power User/Extra Details part ([Learning the vi Editor/Details](/wiki/Learning_the_vi_Editor/Details)) - whatever it is currently called .
  * Others (add your name and description if you made a major contribution)
  * Various anonymous persons
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Learning_the_vi_Editor/Print_version&oldid=1893697](http://en.wikibooks.org/w/index.php?title=Learning_the_vi_Editor/Print_version&oldid=1893697)" 

[Category](/wiki/Special:Categories): 

  * [Learning the vi Editor](/wiki/Category:Learning_the_vi_Editor)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Learning+the+vi+Editor%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Learning+the+vi+Editor%2FPrint+version)

### Namespaces

  * [Book](/wiki/Learning_the_vi_Editor/Print_version)
  * [Discussion](/w/index.php?title=Talk:Learning_the_vi_Editor/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Learning_the_vi_Editor/Print_version)
  * [Edit](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=edit)
  * [View history](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Learning_the_vi_Editor/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Learning_the_vi_Editor/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Learning_the_vi_Editor/Print_version&oldid=1893697)
  * [Page information](/w/index.php?title=Learning_the_vi_Editor/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Learning_the_vi_Editor%2FPrint_version&id=1893697)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Learning+the+vi+Editor%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Learning+the+vi+Editor%2FPrint+version&oldid=1893697&writer=rl)
  * [Printable version](/w/index.php?title=Learning_the_vi_Editor/Print_version&printable=yes)

  * This page was last modified on 18 July 2010, at 23:51.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Learning_the_vi_Editor/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
