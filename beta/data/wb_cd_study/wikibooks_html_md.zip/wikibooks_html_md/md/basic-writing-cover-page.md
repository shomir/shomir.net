# Basic Writing/Print version

From Wikibooks, open books for an open world

< [Basic Writing](/wiki/Basic_Writing)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Basic writing2.png](//upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Basic_writing2.png/350px-Basic_writing2.png)

## Contents

  * 1 Introduction
  * 2 Contents
  * 3 Invention
    * 3.1 Invention:
    * 3.2 Questions:
      * 3.2.1 What do they want from me?
      * 3.2.2 What do I know?
      * 3.2.3 What do I need to find out?
      * 3.2.4 What is the point of the paper?
    * 3.3 Sources of Inspiration
    * 3.4 Use Pre-writing to:
    * 3.5 Prewriting/Writing Activiites
    * 3.6 Why Prewrite?
  * 4 Drafting
    * 4.1 Introduction to Drafting
      * 4.1.1 Nobody gets it right the first time
      * 4.1.2 The importance of just getting it on the page
    * 4.2 Pre-writing
      * 4.2.1 Brainstorming
      * 4.2.2 Free writing
      * 4.2.3 Outlines
    * 4.3 Types of Drafts
      * 4.3.1 Rough draft
        * 4.3.1.1 Form: intro, body, conclusion and paragraph
        * 4.3.1.2 Process: getting started, getting past writing blocks
      * 4.3.2 Process between drafts: Intermediate drafts, editing, MLA, etc.
      * 4.3.3 Final draft
  * 5 Revising
    * 5.1 Definition
    * 5.2 When to Revise
    * 5.3 Steps
    * 5.4 The Recommended Exercises
    * 5.5 Peer Revision
  * 6 Editing
    * 6.1 What is editing?
    * 6.2 What should I edit for?
    * 6.3 An editing example
      * 6.3.1 Scrooge McDuck _(pre-editing)_
      * 6.3.2 Scrooge McDuck: the Money and the Mayhem (_edited version_)
    * 6.4 An editing exercise
    * 6.5 Editing and the Writing Process:
  * 7 Proofreading
    * 7.1 Definition of Proofreading
    * 7.2 Proofreading vs. Editing
    * 7.3 Examples of Common Errors
    * 7.4 Strategies for Finding Errors
    * 7.5 Common Errors and Correction Strategies
      * 7.5.1 Spelling
      * 7.5.2 Punctuation
      * 7.5.3 Fragments
      * 7.5.4 Subject-Verb Agreement
    * 7.6 More
    * 7.7 Proofreading with a Word Processor
    * 7.8 Proofreading Examples
    * 7.9 Corrections and commentary for the above examples
  * 8 Narrative and Memoir
  * 9 Creative Writing
    * 9.1 Poetry
      * 9.1.1 Poetry Without Punctuation
    * 9.2 Narrative and Memoir
      * 9.2.1 Defining _Narrative_ and _Memoir_
      * 9.2.2 Common Approaches
      * 9.2.3 Sample Assignment
      * 9.2.4 Examples:
  * 10 Writing about reading
    * 10.1 Summary
      * 10.1.1 Format
    * 10.2 Critique
      * 10.2.1 Literary critique
      * 10.2.2 Format
      * 10.2.3 Argument critique
    * 10.3 Conclusion
    * 10.4 Essay exams
    * 10.5 Citations
  * 11 Public Affairs writing
    * 11.1 Definition
    * 11.2 Importance of Public Affairs Writing
    * 11.3 Examples of Public Affairs Writing
    * 11.4 Writing an Editorial: A Journey Through the Writing Process
    * 11.5 Writing a Letter to the Editor
      * 11.5.1 Letter to the Editor Exercise
    * 11.6 Writing to a Policy Maker
      * 11.6.1 Composing Your Letter
    * 11.7 Resources
    * 11.8 Practice Assignment
    * 11.9 Another Practice Assignment
  * 12 Investigative writing
    * 12.1 Introduction to Investigative Writing
      * 12.1.1 Definition
      * 12.1.2 Well known examples
      * 12.1.3 Oh, the possibilities
    * 12.2 Forming Your Question
      * 12.2.1 Those all important wh- words, and how!
      * 12.2.2 Inspiration for finding the question
      * 12.2.3 Questions in all fields of study
    * 12.3 Research
      * 12.3.1 Credibility
      * 12.3.2 Sources
        * 12.3.2.1 Primary Sources
        * 12.3.2.2 Secondary Sources
    * 12.4 Thesis/Topic Sentence
      * 12.4.1 Form and place
      * 12.4.2 General v. specific
      * 12.4.3 Examples from various disciplines
    * 12.5 Form
      * 12.5.1 Introduction
        * 12.5.1.1 Thesis
        * 12.5.1.2 Good and bad beginnings
      * 12.5.2 Body/middle
        * 12.5.2.1 Main points
        * 12.5.2.2 Supporting evidence
        * 12.5.2.3 Other side of the argument and your argument against it
      * 12.5.3 Conclusion
        * 12.5.3.1 Restating of the thesis
        * 12.5.3.2 Summarizing
        * 12.5.3.3 Example Assignment

## Introduction[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=1)]

The [authors](/wiki/Basic_Writing/Authors) of this book for the most part are the graduate students in Theory of Basic Writing at [Missouri State University](http://english.missouristate.edu/gradprograms.htm). Others are welcome to contribute to the project or to suggest areas overlooked. Future classes in Theory of Basic Writing and current or future ENG 100 instructors will continue the project. This is still open to anyone interested in Basic Writing.

* * *

## Contents[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/49/Comment.jpg/400px-Comment.jpg)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Sometimes writing takes time and help from others. Let this book help you get the most out of your writing class.

**Part One: Process**

# Invention[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=3)]

## Invention:[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-1)]

Determining the subject and focus of a writing project; the foundation upon which a composition is constructed. Or, in two words or less: idea discovery.

  


## Questions:[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-2)]

### What do they want from me?[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-3)]

Many people begin college composition class assignments with this question, although not many will say it out loud. Well, what do they want from you? First, ask yourself, who is "they"? For many people the only possible "they" is the instructor, but that is not completely true. Behind that instructor is every writing teacher the instructor ever had; the university's general education goals for that class, which can be quite specific; writing theorists the instructor may have read; and of course, the other people in your class who will certainly be reading your writing in peer revision groups. In other words, instead of a single instructor to please, you have an audience.

Luckily, as spokesperson for this audience your instructor has given you a map of sorts -- the assignment sheet. Read this carefully. After reading it, read it again, only this time use a colored marker to highlight key points such as when it's due, page count, type of writing (genre), style (MLA, APA...), and most importantly, anything resembling an ingredients list. If your instructor has given you a bulleted list, you're home free. This is honestly what "they" want.

What if the assignment is vague or uses terms you find unfamiliar? That can happen. What you do then is ask questions, preferably in class when the instructor is going over the assignment for the first time. This may sound obvious, but some students enter college with remnants of the "be cool" attitude left over from high school where sometimes, not always, but sometimes, asking questions was seen as "dumb" or "sucking up" and greeted by eye-rolling or worse by other students. A university is different. Asking questions is what successful students do, and if you have thought of the question, chances are many others in the class have thought of it too and will be grateful that someone spoke up. The instructor will be glad too--questions mean you're paying attention and care whether or not the class goes well for you.

### What do I know?[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-4)]

In anything that you choose to write about, you will have some sort of advanced knowledge. It may not be much, but it will give you a spring-board to a starting point in your research. For instance, if your topic is World War II, think about the key names of leaders and maybe some places involved: Winston Churchill, D-Day, Blitzkrieg. You don't have to know much about a topic, but you can get a start without opening a book if you just think about what you already know. You will probably not know specific statistics or dates at first, but you will know where to start.

### What do I need to find out?[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-5)]

Once you have your general topic—like World War II (WWII), for instance—and you’ve established what you already know about it, then you need to determine what it is you would like to know _more_ about it. Because WWII is too vast a subject to read or write about with any detail for the purposes of your instructor’s assignment, you need to narrow your focus to something more specific about WWII. For instance, you may have jotted down “symbols” when writing down what you already know about the topic. Therefore, you might decide that you want to know more about what kind of symbols were used during WWII and, even more specifically, what kind of symbols were used by the Nazis to mark their enemies. So you look through a book about WWII, or you google “WWII symbols,” and you learn that the colors and shapes determined what the wearer's offense was according to the Nazis. If you decide at this point that you want this to be the specific subject of your paper, then you need to learn as much as you can about the symbols as it relates to WWII, but be wary still that even this topic may be too large for a short paper (i.e. 5-10 pages). Your subsequent research can be narrowed, however, by asking yourself questions like some of the following: When and why were they designed? What was its function for the wearer and the Nazis? What were the different symbols used for? Which symbol was most used and why? and so on. From there you need to decide on a specific question that you wish to answer in your paper, do the necessary research for that question, and then begin the writing process.

### What is the point of the paper?[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-6)]

Have you ever seen a preview for a movie that was misleading? You thought you were going to see a movie about guys having an adventure in the wilderness and how they survive only to discover the movie is really a documentary about a family of ants. The disappointment and misunderstanding that follows is what your audience will feel like if your topic is not specific, and if the rest of your paper does not make good on the promise of your introductory paragraph, which should give a clear preview of the rest of your paper.

The point of your paper is to reveal to your audience the details and information about your particular topic. The specific question that you want to answer about your topic will therefore guide your entire paper. The answer is sometimes called a thesis, and much of the writing you will do in university classes is thesis-driven writing. Once you know what your thesis is, you can then make sure that everything in the paper connects to it in some way. The goal is for your paper to look and sound like a crystal stream instead of a muddy ocean. There may be many things that you are interested in discussing in your paper. However, a paper must have one focus (or thesis) to sound clear.

Once you have your thesis, some of the following brainstorming ideas may be helpful to determine what best fits under your topic. Brainstorming will also help you expand the sub-points. Every topic has the option of a variety of sub-topics, but not all sub-topics go together. You need to decide which sub-topics answer the main question that you are trying to answer. Even if you are really attached to a particular sub-topic -- which at some point you will be -- cut it out! Think of it as the bad boyfriend or girlfriend that you can't seem to let go of, yet you know that letting go is the best choice for everyone involved. Break up with that sub-topic and never look back!

## Sources of Inspiration[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-7)]

Many times an instructor will give you the option of choosing your topic for an assignment. This can be a daunting task for anyone. Sometimes having a choice of everything is so big that you end up not being able to think of anything to write about! However, just look around. Something is bound to spark your interest and give you a good starting idea for your assignment. Any of the following can be sources rich with inspiration for topics to write about:

  * Media: 
    * Art
    * Literature
    * Music
    * Movies
    * Other Media (i.e. newspapers, magazines, television, internet-browsing, etc.)
  * Dreams: 
    * Your dreams, whether real-life occupational/career goals, personal wishes/wants, or even those you have while sleeping or staring out the window while driving, can frequently contain topics or ideas worthy of writing about.
  * Memories/Experiences: 
    * Thinking about who you are and the experiences that inform your identity can be a fruitful exercise for coming up with writing topics or ways to approach a particular topic.
  * Journalling: 
    * Keep track of your ideas and emotions on a regular basis. These thoughts can be the starting point for an assignment or may provide those extra details needed to make the paper more effective. Through tons of research, keeping a journal has been proven to help your writing for personal or academic papers. Reflecting on things around you as well as things you read and talk about in class will point you in the direction you need to go to improve your writing skills.
  * Personal Interests
  * Discussions with family, friends, colleagues, etc.
  * Research
  * Imagination
  * Browsing: 
    * "Staring down the Spines": Go to the library. Stand amongst the shelves of the topic you are going to write about. Staring at or reading the spines of these books can often initiate an inspiration or two.

## Use Pre-writing to:[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-8)]

  * think more clearly
  * establish the beginning of your paper
  * keep track of your ideas
  * organize your ideas into a conducive paper
  * practice expressing yourself in writing

## Prewriting/Writing Activiites[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-9)]

The following are techniques that can aid in the composition process, either in coming up with ideas or in working through various obstacles along the way:

  * Listing: 
    * Listing allows the writer to accomplish several important tasks: 
      * Finding a topic
      * Determining whether you have enough information for a topic before proceeding: After narrowing down your topic, create a list with everything
      * Narrowing the topic: If writing about World War II, for example, the focus will need to be on a specific component of WWII or there will be too much information. Make a list of everything you know about WWII. Then decide which topic interests you the most by crossing of those topics that don't interest you as much. 
        * **Example**:

WWII

Hitler
concentration camps

D-Day
<del>Jews</del>

<del>Churchill</del>
yellow stars

Axis and Allied forces
air raids

tanks: M4 tanks, Sherman tanks
<del>Pearl Harbor</del>

<del>machine guns</del>
atomic bomb

symbols
Blitzkrieg

  * Freewriting: 
    * Similar to listing, only in this case you simply start writing in sentence form literally anything that comes to mind in context of thinking about your topic and/or assignment.
  * Napping: 
    * Seriously! Taking a 5-10 minute nap can help rejuvenate the mind and relax you enough to release the tension that comes with writing.
  * Meditation: 
    * Finding a place where you can sit in silence for 5-10 minutes and simply focusing on nothing but your breathing can be a surprisingly effective means of "silencing the noise" in your mind prior to writing, allowing you to better focus on the task at hand without internal distractions.
  * Mini-computer games: 
    * When stuck on a topic or during writing, playing simple but repetitive computer games like Minesweeper can help relax the mind (i.e. it serves as a kind of meditation).
  * Outline 
    * This form of prewriting is geared more toward organization. It groups your thoughts into a definite main point and the supporting detail. So using the topic of "Badges," the outline would being as follows:

I. Beginnings

  * A. When 
    * 1\. November 1939 
      * a. following Kristallnacht in 1938
      * b. Reinhard Heydrich's recommendation
  * B. Why 
    * 1\. easy separation of Jews
    * 2\. needed to give rations
  * C. Who 
    * 1\. Jews 
      * a. First all Jews wore yellow stars
      * b. In concentration camps 
        * i. colored triangle with yellow triangle behind
    * 2\. Later, all undesirables

II. Rebellions

> The thing to remember about outlining is that you can't have a support with only one compliment. If you have an "A." then you have to have a "B."

  * Clustering/Brainstorming/Mapping 
    * Clustering is a primarily visual form of pre-writing. You start out with a central idea written in the middle of the page. You can then form main ideas which stem from the central idea. In this case, you've narrowed the topic down to "Badges." The ideas stemming from that central idea are all having to do with the central idea, but different aspects of that idea. Once the main ideas contain enough information for you to write about, you can determine in what order you will present the ideas in your paper.
  * Storyboarding: 
    * Storyboarding functions in much the same way as Clustering-Brainstorming. It has definite advantages, though. In storyboarding, the ideas are written on note cards in much the same way a Hollywood screenplay is organized. In this instance, you can write information you have gathered about World War II symbols/badges. For instance, say in your research, you find information on rebellions against badges. You can write all of that information on a note card, but make sure you make a note as to where the information came from so that you can easily go back and check your sources and cite them properly. The next note card will cover another topic, say, types of badges and the employment of those badges. The next card can cover the beginnings of their use, and so on.

## Why Prewrite?[[edit](/w/index.php?title=Basic_Writing/Invention&action=edit&section=T-10)]

Prewriting for even 5 to 20 minutes can help you establish what you already know about a paper topic, as well as aid you in discovering where you would like to go with a paper (i.e. what you want to know). Doing so can often help prevent you from committing to superficial and/or mundane responses. Prewriting can help you find strong, thoughtful, and clear answers to questions posed by either the assignment or by your consideration of it. It can reveal to you those potential areas of personal interest within the writing task: in a manner of speaking, prewriting enables you to "discover" yourself within the context of your topic. It can also help you nail down responses--to move ideas from short-term memory into long-term or written memory--so that you can get to the work of writing rather than trying to remember what it is you want to say. That is, your thinking is often more clear and better focused when engaged in actual writing. As such, prewriting can act as a tool to stave off or break through what is commonly called "writer's block."

# Drafting[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=4)]

## Introduction to Drafting[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-1)]

**Drafting** is writing and drafting is a vital part of successful writing. The reason you will need to use drafting is that it can lay the fundamental framework of your final paper. If you lay the framework well, you'll have a good chance of writing a beautiful paper, however, if you do a poor job on the framework, success could be much more difficult to attain. The following section will take you through the drafting process(es) with instructions and handy tips.

### Nobody gets it right the first time[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-2)]

Whether a writer is the next Ernest Hemingway or a student at any level, drafting must be done as a part of successful writing. If a professional writer says that he/she never writes more than one draft you can pretty much bet they are joking or not telling the truth. Even when writers work to deadline and write at a single sitting, they return to parts of it again and again in order to get it just right. Also, a deadline doesn't always mean done; writers can and do return to an already published piece and revise to make it better.

It does not matter whether the work is a research paper or a poem, all forms of writing need to be drafted. Since a professional writer almost never gets a piece of writing perfect in the first draft, don't feel bad if you need several drafts too. So, if you find yourself very unhappy about your first try at a paper think of it as just the start of something better, i.e. the rough draft. Another advantage to multiple drafts is that the more drafting you do the more chances you have of catching mistakes and improving the paper. This is why it is so important to make time for multiple drafts during the writing process. The time spent drafting will bring you closer to than ever to a more glorious version of your final draft.

### The importance of just getting it on the page[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-3)]

Not much can be done for a piece of writing until it is on paper or computer screen. You may worry that the paper will not be very good or even think that it will be awful, yet you won't really know until you've actually written it. Not only will you and your reader(s) not be able to see what you have written, but there is no chance of working to fix what has not yet been written. For more ideas of how to actually get your words down look at the pre-writing section below.

## Pre-writing[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-4)]

### Brainstorming[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-5)]

Brainstorming is one of the most effective pre-writing techniques you can use. It’s virtually painless and can be pretty fun, if you let it! Brainstorming is easy because there are NO RULES. Let your mind wander and think about things that you would like to explore more. Try to create a mental web of things you can connect to one another. Let the lightning of ideas strike you as they may. Ask yourself a few starter questions such as:

What interests me?

If I choose this subject can I meet the word/page requirements?

Are there other researchers out there thinking like me?

What topics are related to my topic of interest?

What about the topic can I make into a thesis?

Where is there an arguable side of this topic?

Can I see and argue both sides?

What other topics interest me?

Is there anything in the media that I can make into a paper?

How might this affect my daily life?

What kind of examples can illustrate my point?

Is this a fresh/creative topic? Has it become too common?

These questions and others you might create will help you get started on your writing process. Before you even put pen to paper or fingers to keys (If you do have a good idea, WRITE IT DOWN, that way you don’t forget it!). Once you have a topic in mind then you’re ready to move on to the harder stuff.

### Free writing[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-6)]

Free writing can also be pretty fun if you let it. Once you have the main topic of your argument, then it is time to begin getting your ideas on paper. The purpose of free writing is to do just that. Again, with free writing, there are no set rules as to how to proceed. Many teachers will use this technique as a way to jumpstart your creativity and get you thinking. In doing free writing before your paper you will need to write for several (8-10) minutes about your topic. Even if you jump off topic continue writing because you might come back around to the topic or discover a new way in which you might consider going with your topic.

You might want to begin by writing down all the ideas you have about your topic. Write down things you think will eventually serve as your main points. Think about how you would argue with someone who disagreed with your point of view. What would you tell them? Could you back it up with actual evidence? Note: at this point you won’t necessarily need actual evidence, but you will want to have a good idea of the kinds of things out there that you can use to back up your claim.

This is the point where your argument starts to pull together and you will probably find that you have more ideas and points than will ever fit into your argument, but then you can choose the best of the points and make your argument even stronger.

### Outlines[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-7)]

Outlines and rough outlines are where you begin to form the skeleton of your paper. They will be the pattern from which you write your argument. The outline serves as a way to organize you thoughts into a comprehensive process that flows smoothly from one point to another.

The formatting of an outline also helps you to create organization within your paper. Here is an example outline to help you learn the format and organization it will give your argument. I. This is your main topic. It can also be your title. What are you going to talk about?

A. This is your introductory paragraph. Give your intro topic sentence.

1\. State your thesis. You should have a clear and developed thesis by now.

B. This is the body of your argument.

1\. Main point #1

a. Supporting evidence for main point #1

b. More supporting evidence for point #1

c. Acknowledge and dismiss the other side of the argument

2\. Main point #2

a. Supporting evidence for point #2

b. More supporting evidence for point #2

c. Acknowledge and dismiss other side of the argument

C. This is the conclusion of your argument

a. Restate your thesis

b. Summarize your argument

Note: you may have several more main points than this outline has, but they all follow the same basic structure.

## Types of Drafts[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-8)]

### Rough draft[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-9)]

A rough draft is a very important step in the writing process. Writing more than one draft gives you the opportunity to catch problems and see where the paper may not be working. So, it is a very good idea to leave yourself with enough time to write at least two or three drafts of your paper. You may want to do an outline to plan your paper beforehand, but doing that is not always necessary. After you get your thoughts, any possible research and or sources needed in order you can begin actually writing. While you write your rough draft you may not feel completely satisfied about the paper, but that's okay because that is what a rough draft is for. You want to give yourself a chance to work to get to the best arrangement of ideas and find different ways of expressing them.

#### Form: intro, body, conclusion and paragraph[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-10)]

Start it, say it, finish it--that's an academic writing draft in its simplest form.

Start it. The introduction starts it all. That's where you get the reader involved in what you are writing about and along the way, also get them interested in what you have to say. At the end of the introduction section, many forms of academic writing have a thesis--the main idea or claim.

Say it. Say what you have to say, and don't forget to set up a sequence of ideas that will eventually lead to the conclusion. Each idea or "point" needs room to breathe, so give it its own paragraph, at the very least. Supporting details and examples will also help.

Finish it. The conclusion wraps it all up in a way that doesn't just repeat the thesis--it makes it both bigger and more specific. The terminology for this kind of writing is "synthesis." In synthesis, the whole is greater than its parts, and that is exactly what a good conclusion does.

Needless to say, each part involves using paragraphs, but it's helpful at the drafting stage to think more about "sections." An introduction can be more than one paragraph. A body needs to be more than one paragraph. A conclusion can be one paragraph, but can be more. If your natural tendency when drafting is to move full-steam ahead in one long paragraph with the intention of breaking it up later, it's worth the effort to slow down a bit and make those paragraph breaks as you write. Your draft will be better organized in the long run, a good thing for you and your future reader.

#### Process: getting started, getting past writing blocks[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-11)]

All writers can suffer from those horrible writing blocks, but there are ways around them. If you are having a hard time with the beginning, work on other sections of the paper and come back to the beginning later. You do not have to write strictly from beginning to conclusion. If you have an idea for a certain section write it first. Get that idea out of your head and onto the paper because in doing so, you just might think of a brilliant way to begin your paper. Also, depending on how much time you have to work you may want to take an hour or a day to get away from your paper. Sometimes a little time away from a project can help clear your head and give your ideas more definitions as well as clarity.

### Process between drafts: Intermediate drafts, editing, MLA, etc.[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-12)]

Here the process between drafts is kind of overlapping with two of the other sections, they are, **Revising** and **Editing**. Actually, the intermediate drafts are a process of revising your former drafts again and again. You need to look at what you think is not proper or good enough and think of ways that better explain your points to your readers. For more details, you may want to refer to the other two sections about how you could make better draft amendments step by step.

### Final draft[[edit](/w/index.php?title=Basic_Writing/Drafting&action=edit&section=T-13)]

Yes! You are coming to the final draft now! However, this is not the end of your final paper yet! The overall structure of the writing construction has already been done, so we could say that you've achieved a half-success! Still, you need to go beyond drafting to the further sections which will be sure to guide you to completion of your paper! Keep up the hard work and you will be glad you went through so many drafts, all that hard work just might eventually pay off in a big way!

# Revising[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=5)]

## Definition[[edit](/w/index.php?title=Basic_Writing/Revising&action=edit&section=T-1)]

**Revising is re-vision--seeing your paper again**. Revising is more than correcting spelling errors, it's finding clarity of thought. It could even be finding new thoughts you didn't have before you started the paper. You might find yourself getting rid of extra fluff.

**As you were writing you were revising** if you think about it. You had concerns about the paper as you were constructing it. Write those concerns down (make notes in the margin, highlight, make familiar marks) so that you can return to them. Identify what you think are strengths too and bring the rest of your paper to the level you are seeking.

Remember, "A work of art is not a matter of thinking beautiful thoughts or experiencing tender emotions but of intelligence, skill, taste, proportion, knowledge, discipline and industry; especially discipline," according to Evelyn Waugh, 1903-1966, English novelist, travel writer, and biographer.

## When to Revise[[edit](/w/index.php?title=Basic_Writing/Revising&action=edit&section=T-2)]

Your first draft shouldn't be your final draft. No draft is ever perfect; there's always room for improvement. You have to have content to work with before you revise. You may want to allow yourself to finish a complete draft before you hamper the "creative springs" with revisions. After you have completed drafting your ideas and have established what you consider to be a complete product of the thoughts you intend to convey, then delve into the revision process.

## Steps[[edit](/w/index.php?title=Basic_Writing/Revising&action=edit&section=T-3)]

**Read carefully** over your draft several times, with a different purpose in mind to check a specific problem each time (this is where it helps to know your common downfalls with writing). Look first for content (what you said), then organization (your arrangement of ideas), and finally style (the way you use words).

**Listen carefully** to your paper aloud for confusing statements or awkward wording. Listen for the paper's flow and pay attention to details one idea to the next. Each idea should come to some sort of conclusion while introducing the next idea, and each idea should relate to the one before it and the one after it.

**Take time** between readings. Allow yourself time to finish a paper (avoid procrastination if possible) so you can put it aside and read it fresh when you go back to it later, to be more objective.

**Identify the specific problems** with your weaker elements: _content, organization, or style_. Proofreading of mechanical errors, spelling, and punctuation will follow later.

The **essential components of content** are the intended purpose, sufficient support, and that all the details are related to the main idea of your paper.

  * Achieving the intended purpose--does it provide explanation, details, argument, or narration?
  * Providing sufficient support--does it need more detail, facts, examples to support the topic?
  * Including relevant details--do you need to cut any irrelevant "fluff" information?

The **importance of organization** is to arrange ideas and details to make the most effective order, and to connect ideas to show a clear logic of thought process.

  * Ideas and details are arranged in the most effective order--ideas and details should make your meaning more clear.
  * Ideas are logical and clear--use of appropriate transition words to relay the connection of thoughts (such as "therefore", "for example") and any use of sentence combining techniques.

The **power of your style** will make the meaning clear, interesting for the audience with purpose, and insure the sentences read smoothly.

  * Is the meaning clear--did you use vague or general terms where you need to be precise?
  * Is the language interesting, appropriate for audience and purpose--is the language to be formal or informal, did you avoid slang and cliches?
  * Is it smooth--did you use a variety of sentence structures?

**Four steps to revising**: add, cut, replace, and reorder. These are the words you can use in the margin of your paper as you read and make decisions to revise. If you know the standard editing marks you can make revision directly to the writing context. [Standard Editing Marks](http://www.teenlit.com/workshop/editing.htm) (with additional common writing errors)

Questions you might ask of your final paper:

  * Are you saying what you mean to say?
  * Will your audience understand it?
  * Will it accomplish the purpose?

If you want to be more critical of your writing, judge its readability, clarity, and interest to its audience.

## The Recommended Exercises[[edit](/w/index.php?title=Basic_Writing/Revising&action=edit&section=T-4)]

  1. As you write, keep notes of questionable areas. An easy way to do this is to write the page number and a portion of the line of text that you find questionable.
  2. Read the paper aloud several times and listen for mistakes. Once you are satisfied with your "read aloud" revisions, ask a couple of other people to read it. You will be surprised by the feedback that you may receive.
  3. Divide your readings looking for content, organization, continuity, and style.
  4. Mark your paper where you want to add, cut, replace, and reorder. Sometimes it also helps to get out your scissors and literally cut up your paper into chunks so that you can rearrange at random to see what order looks and sounds best to you.
  5. Take time between readings. This might mean a short break to eat or walk the dog, for instance, or it might mean a longer break such as returning to your paper in twenty-four hours. Everyone is different. Do what works for you.
  6. Take time while reading. In other words, take time to reflect on your thoughts. Read one paragraph at a time, envisioning what you intended to say while keeping your audience in mind. Sometimes it is helpful to stare at a blank wall while reflecting instead of staring at your paper or computer screen. This will give your brain a chance for little cat naps, giving it an escape from the chaos of words, information, and eyestrain caused by staring at a computer screen (assuming that you are revising electronically).

## Peer Revision[[edit](/w/index.php?title=Basic_Writing/Revising&action=edit&section=T-5)]

Peer revision has added benefits over revising by yourself. Other people can notice things in your paper that you didn't. Some instructors set aside class time for peer review, but even if your instructor doesn't, it's a good idea to seek out feedback from a classmate, roommate, or anyone at all who can offer a fresh perspective.

If you're the one who wrote the paper, make sure you tell your peer what your biggest concern with the paper is. If you need help writing a conclusion, you don't want your peer to spend time circling grammatical mistakes in a paragraph you were thinking about deleting anyway. Remember, your peer isn't just there to catch your mistakes, she might have some ideas about new material you can add to make your paper more exciting.

On the other hand, if you're the one who is reviewing your peer's paper, think about what you'd want in her place. Ask if there's anything she's having trouble with. Be nice, of course, but don't be so nice that you aren't helpful. She may like to hear "Good job," but make sure to explain what you liked about the paper and where you think it could be even better. Remember, it's not about whether the paper is good or bad, it's about how it can be improved.

You have a responsibility to the student whose paper you are reading. Be familiar with the qualities and requirements of the assignment. Consider its merits and shortcomings to provide a complete evaluation and then ask those questions that ask the author about particular segments or certain evidence to support arguments to encourage discussion over the paper.

Possible list of peer revision questions:

  1. What is the writer's purpose?
  2. Does the writing include all the necessay characteristics of its particular type (cause-and-effect, narrative, research, etc.)?
  3. Is the writing organized logically?
  4. Has the writer used language that enhances her message?
  5. Is the writing unified/coherent?
  6. Did you point out the strength(s) or part(s) you found interesting?
  7. Is there any part that required more information?
  8. Is there any part that was irrelevant?
  9. Did you answer any questions the reader had about her writing?

Talking with someone else about your paper will always help you re-evaluate your content. Sometimes it reassures you that you've got it right; sometimes it reveals to you the places that need work. It is always a good idea to share your work before submitting the final draft.

# Editing[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=6)]

## What is editing?[[edit](/w/index.php?title=Basic_Writing/Editing&action=edit&section=T-1)]

Editing is sometimes confused with [Revising](/wiki/Basic_Writing/Revising), or with [Proofreading](/wiki/Basic_Writing/Proofreading). After you feel you've revised the draft as much as is needed, editing comes into play. Editing involves a number of small changes in a draft that can make a big difference in the draft's readability and coherence. Editing can happen at several points in the drafting process--not just at the end to "fix" things that are wrong. When it comes to writing, it isn't so much about making mistakes that you have to correct. No, there is always an assortment of options, many of which are right. Experienced writers learn which choices fit together well for them, and luckily for you, the secret to becoming an experienced writer is to practice. You can do that.

  
So, what kinds of things happen when editing? Here are a few.

  * word changes
  * minor sentence rearrangement
  * added transitions
  * changes for clarity
  * minor deletions

## What should I edit for?[[edit](/w/index.php?title=Basic_Writing/Editing&action=edit&section=T-2)]

Three main areas that should be addressed in editing are: Content, Structure, and Mechanics.

When editing the **content** of your writing, it is important to make sure your work has a clear focus or main idea. By asking yourself a few questions, you can avoid incomplete thoughts and/or irrelevant material. The following is a checklist you can use in editing your content:

  * I have discovered what is important about my topic.
  * I have expressed the main idea clearly.
  * I have removed material that is unnecessary, confusing, or irrelevant.

  


Editing for **structure** ensures that your ideas are presented in a logical order. A single idea should be represented in each paragraph. Transitions serve to make the relationships between ideas clear. The following checklist is helpful in editing structure:

  * My ideas are logically connected to one another.
  * Each paragraph deals with only one major idea.
  * I have included appropriate transitional words or phrases.

  
Refining the **mechanics** in the editing phase prevents the reader from being distracted from your ideas. Grammar and usage errors may be avoided by keeping a dictionary or grammar handbook nearby. A checklist can also help you catch these errors in your writing.

  * I have used punctuation marks and capitalization correctly.
  * I have checked the spelling of unfamiliar words.
  * All subjects and verbs agree.
  * I have corrected run-ons and sentence fragments.
  * I have used words with the correct meanings in their proper context.

  


Let's look at a paragraph that is ready for editing.

## An editing example[[edit](/w/index.php?title=Basic_Writing/Editing&action=edit&section=T-3)]

### Scrooge McDuck _(pre-editing)_[[edit](/w/index.php?title=Basic_Writing/Editing&action=edit&section=T-4)]

> Scrooge McDuck is a rich and famous lucky duck that has it all: the luxurious mansion, 3 intelligent and athletic nephews (and one niece that gets in the way), a global industry in his name that sells anything and everything, and skyscraper sized vault of gold coins, rubies, and iconic bags of money. Scrooge McDuck would have it all if it weren’t for one minute problem. Every other day someone tries to steal his money. People have moved it into the ocean and tried to claim salvage rights. They’ve moved it away with magic, futuristic helicopters, and old-fashioned diesel trucks. Scrooge has researched every possible idea to keep people out of his money bin. Now he needs to solve that problem once and for all.

_This is a pretty good introduction to an essay that's about finding the best possible solution to a problem for a fictional character. However, taking a closer look and making a few small changes could make it even better._

### Scrooge McDuck: the Money and the Mayhem (_edited version_)[[edit](/w/index.php?title=Basic_Writing/Editing&action=edit&section=T-5)]

> Scrooge McDuck is a rich and famous lucky duck that has it all: the luxurious mansion, **three** intelligent and athletic nephews**,** and one niece that gets in the way**. Owner of** a global industry in his name that sells anything and everything **as well as a** skyscraper sized vault of gold coins, rubies, and iconic bags of money**,** Scrooge McDuck would have it all if it weren’t for one **tiny** problem. Every other day someone tries to steal his money. People have moved it into the ocean and tried to claim salvage rights. They’ve moved it away with magic, futuristic helicopters, and old-fashioned diesel trucks. **Viewers of _Ducktales_ know that** Scrooge has researched every possible idea to keep people out of his money bin. Now he needs to solve that problem once and for all.

## An editing exercise[[edit](/w/index.php?title=Basic_Writing/Editing&action=edit&section=T-6)]

**Word Choice**

Sample Sentence: Technology is bad for people.

Edited Sentence: Technology harms our sense of community.

The edited sentence is an improvement because it uses more specific language. We learn that technology is not only harmful, but we also learn what it harms.

**Transitions**

Sample Sentence: I hated multiplication. I failed my math class.

Edited Sentence: I hated multiplication; therefore I failed my math class.

The transition "therefore" makes a connection between the two thoughts, making the reader see that failing the math class was a result of hating multiplication.

**Sentence Structure**

Sample Sentence: There was two boys in the hall.

Edited Sentence: There were two boys in the hall.

In the sample sentence, the subject and verb do not agree. In the edited sentence, the subject and the verb agree.

* * *

## Editing and the Writing Process:[[edit](/w/index.php?title=Basic_Writing/Editing&action=edit&section=T-7)]

A major question that students will probably find themselves asking is this: How do I know when to edit a paper? As a matter of fact, there is no simple answer to that question. Writing is a process that involves several steps, and these steps do not always occur in a straight line. Writing any sort of text is a circular rather than a linear process. Writers are rarely completely finished with one step, even after they move onto the next.

Most people tend to think that editing tends to happen sometime near the completion of the paper. In fact, that is not always the case. While the most important part of writing is simply the ability to express yourself and get ideas across, it can sometimes be helpful to take a quick break from drafting or revising and to spend some time editing. Sometimes, playing with word choice, sentence structure, or transitions can help stimulate your mind, leading to new ideas. Thus, it's important to realize that editing is not necessarily a one-step action, but rather something that can be done throughout the entire writing process.

# Proofreading[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=7)]

## Definition of Proofreading[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-1)]

Proofreading is the process of carefully reviewing a text for errors, especially surface errors such as spelling, punctuation, grammar, formatting, and typing errors.

## Proofreading vs. Editing[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-2)]

While the terms _proofreading_ and _editing_ are often used interchangeably, they do differ slightly.

[Editing](/wiki/Basic_Writing/Editing) is typically completed throughout the writing process—especially between drafts—and often suggests contextual changes that affect the overall meaning and presentation. The focus is on changes that affect style, point-of-view, organization of content, audience, etc.

Proofreading occurs later in the writing process, usually just after the final editing and before the final draft that will be presented for publication (or turned in to a professor). The focus is on correcting errors in spelling, syntax, grammar, punctuation, and formatting.

While some editing will inevitably be done during the proofreading process and vice versa—the writing process is not perfectly linear, after all—focusing on proofreading too early in the writing process is often inefficient because with each revision new errors are introduced. In other words, one does not want to spend a lot of time correcting sentences and paragraphs that may soon be rewritten or even deleted completely.

## Examples of Common Errors[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-3)]

While many types of errors exist in writing, there are some that are more common and definitely more noticeable. Some of these errors include spelling, capitalization, punctuation, grammar, subject\verb agreement, and word usage.

A word processor's spell-checker will detect most **spelling** mistakes. However, if you are writing a paper out longhand, using a good college-edition dictionary can help you prevent many of these mistakes (unless of course, you also can't guess which letter begins the word). If you lack a spelling-bone (I think it's near the funny bone because it is another bone that hurts when it bumps against something), a good strategy to use is to keep a notebook of problem words. You can add words to it each time you have to look a word up in the dictionary, and eventually you will have your own mini-dictionary of words to check more closely. Some people still prefer to do the old grade-school thing and write the word out in longhand twelve times, sounding it out as you write. For example, _surprise_. Sounded out, it is _sǔr_ (as in Big Sur in California) _prise_ (where the _i_ sounds like a French _ee_ vowel sound, and you can picture yourself being surprised while sipping espresso on the _Rive Gauche_ in Paris. The sound and the image combined may help you remember the spelling.

Punctuation errors most often involve the **comma**, which means knowing when and how to use one. Of course, that's easier said than done. The **comma splice** seems to be an especially common error among writers. A _comma splice_ is defined as a sentence that contains two or more complete sentences joined together by a comma. American university professors tend to see it as a major mechanical error. Rumor has it that once in the distant past there was a university in Colorado where any paper with even a single comma splice would receive an automatic F with no exceptions allowed. Hopefully, no extreme cases like that exist now, but avoid comma splices if you're writing for an American audience. If you are in Great Britain, that's another story—comma splices are cheerfully ignored for the most part. Audience truly matters in writing, even on the grammatical/mechanical level.

Although some style guides list nearly two dozen comma rules, there are basically five comma rules you need to know:

1\. Use a comma with a coordinating conjunction to join two independent clauses. In Layman's terms, fix a comma splice by adding one of the following: and, but, for, so, or, nor, or yet.

2\. Use a comma to set off non-essential information in a sentence. Basically, put commas around extra information that is not part of the main idea.

3\. Use a comma in lists or items in a series.

4\. Use commas in addresses and dates.

5\. Use a comma between adjectives if they make sense with the order reversed or with "and" inserted in between them.

  
The Wildcard Rule: There are always exceptions to the rules, and often it is just a matter of personal preference and style. Think about your purpose and your audience; then decide whether or not a comma makes the sentence clearer or is just an extra mark on the page. Sometimes having too many commas is a worse problem than not having enough commas.

**Verb tense** and **subject/verb agreement** are also key errors that should be looked for when proofreading a paper. The subject should always agree with the verb in tense and number. These verb issues are often overlooked or unnoticed while writing an initial draft but can usually be caught with a good proofread.

Methods on how to find these verb tense problems, among with other mistakes, will be discussed in the next section.

## Strategies for Finding Errors[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-4)]

It's often difficult to find your own errors. In this section we will discuss how to look at your own work carefully to spot errors.

The first thing to do is to allow some time between writing and proofreading. Some people recommend letting a text set as long as two weeks before looking over it for mistakes, but that is usually not practical. Instead, try to give yourself at least one full day between finishing your draft and proofreading. In other words, sleep on it. If the deadline is quickly approaching or it is due the next morning, take as much time as you can--an hour or two will do wonders. At minimum, try to take at least take fifteen minutes after the completion of the paper before going back and proofreading. This allows you to look at the same piece of work with a clear eye and a fresh mind.

Second, the paper should be read aloud. Can you make it through without stumbling over anything? Many grammar or word usage errors are not picked up on until the piece is read aloud. Also, have someone else read your work for you (aloud, if possible, so you can hear where the words or punctuation are leading the reader away from your intended meaning). A peer or family member with some distance can also let you know if the progression of the paper needs help, or if something doesn't quite make sense. Do not be afraid to strike out a passage that you thought sounded great, but others are having a hard time understanding.

You can also read the work backwards, one sentence at a time. This helps determine if each sentence, independent of anything else, makes sense. Ask yourself these questions: Are the sentences complete? Does each sentence have a subject (who or what the sentence is about) and a predicate (what's happening in the sentence)? Note which ones need to be changed and why.

Finally, get help! If you're not sure about something, such as the use of a comma or spelling, find a resource or assistance. You can use the writing center at your school, a tutor, the internet, or something as convenient and portable as a grammar book or dictionary!

## Common Errors and Correction Strategies[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-5)]

### Spelling[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-6)]

Don't forget to use your word processor's spell-check feature to identify spelling mistakes. Do a quick visual check for squiggly lines, run the actual spell-check function, and then do a closer check for misspellings or wrong word choices that the spell-checker missed. Although spell-checking is important and should not be skipped, a real-live human can often catch errors that computer software will miss because people are more capable of understanding words in context. For example, spell-check software can't always tell whether _their_, _there_, or _they're_ fits in a specific sentence, but a person can always figure it out by looking at the definitions for these homonyms.

Don't forget the low-tech solution: always use a dictionary to confirm any word you're unsure about. Although the built-in dictionary that comes with your word processor is a great time-saver, it falls far short of a college-edition dictionary in paper or CD form. So, if spell-check suggests bizarre corrections for one of your words, it could be that you know a word it doesn't. When in doubt, check a dictionary to be sure.

### Punctuation[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-7)]

This section will provide useful information on Standard American punctuation: its usage, pitfalls, etc.

### Fragments[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-8)]

By definition, a fragment is a group of words that is punctuated like a sentence, but that lacks either a subject or a verb. For example: "Full five year warranty and free oil changes!" People use fragments like this in advertisements all the time, but when you are writing for an academic audience, which is far less forgiving of purposeful fragments, your readers may assume that you just don't know the sentence is a fragment. They may conclude that if you got that wrong, you might be wrong about your content too.

So, how can you do find fragments in your own writing? First, find the main verb. Then, find the subject for that verb.

You could correct the example sentence in the following way:

  * **Original:** Full five year warranty and free oil changes!
  * **Add verb:** Receive a full five year warranty and free oil changes!
  * **Add subject and verb:** New customers receive a full five year warranty and free oil changes!

Built-in grammar-checkers are fairly good at spotting fragments, but occasionally go overboard and mark a sentence as a fragment when it is not. Use your own judgment and read each one independently while asking the questions provided above.

### Subject-Verb Agreement[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-9)]

Below are some examples of errors with subject/verb agreement. Take some time and see if you can figure out what the error is in these sentences.

**Original:** The dog need to go on a walk.

**Revised**: The dog needs to go on a walk.

\--The subject in the original sentence (dog) is singular. The verb (need) is plural. The verb needs to be changed from plural to singular form in order to agree with the subject.

**Original:** Chris and Molly goes for walks often in the evening.

**Revised:** Chris and Molly go for walks often in the evening.

\--In this case the verb started out as a singular form. It needed to be changed to plural to fit with Chris and Molly (plural subject).

A quick way to check for subject/verb agreement is to circle the verb and underline the subject of each sentence. Make sure that if the subject is plural, you use a plural form of the verb. If you can not identify subjects and verbs this method will not be practical, and you should seek guidance online, at your school's writing center, or from an instructor first.

One last source for finding tips on correcting common errors is online tutors and workshops. Use internet searches to help you with anything you might be struggling with!

## More[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-10)]

If it feels like you keep repeating the same words throughout your writing, pull out a thesaurus for ideas on different, more creative choices. A thesaurus can add just enough color and depth to a piece that otherwise seems mundane. Be careful, though, that the word you substitute has the intended meaning. Thesauruses provide words with similar meanings, not identical meanings--so if you are unsure look up the new word in the dictionary!

## Proofreading with a Word Processor[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-11)]

There are many word processing programs available, and probably the most popular and most commonly used one so far is Microsoft Word. However, with the advent of Microsoft Vista and the lack of easy back-compatibility between new Word and even past versions of Word (including Word from Office 2003), that may change and open source alternatives such as [Open Office](http://openoffice.org/) may gain popularity. That issue aside, one thing all word processors have in common is this: although a word processor is a great tool for writing and includes many special functions that can help a student check for errors such as spelling, punctuation, grammar, repeated words, formatting, and so on, it is not a perfect solution for all problems. When students write, they should be especially aware of the errors the software does not find. This can be a real problem when an assignment is graded for all aspects of the writing process. One of the biggest mistakes a student can make is thinking, "No problem, my word processor will catch all the mistakes for me."

There is no computer program written that can look at every word in context. As great as word processing software is, compared to the human mind it is still extremely limited when it comes to processing language. Even the simple task of spell-checking using a spell-checker tool is not error-free. Although it can find misspelled or unrecognized words, it cannot always differentiate between homonyms. For example, it does not always distinguish between the words _to_, _too_, or _two_. Another problem can arise if your word processor is not set up to correct a certain error. For instance, many spell-checkers are set by default to disregard words in all capital letters because many people do not want it to spell check acronyms. In this case, the word PROOFREEDING would not be caught as a misspelled word because it is in all capital letters.

Despite their many limitations, spelling and grammar-checkers, while not perfect, do help find common errors. However, the best tool that you can use to spot errors is your own eye. Spend the time to look over your writing carefully to make an honest attempt at turning in that elusive error-free paper, AKA by editors as _clean copy._

## Proofreading Examples[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-12)]

In the earlier section about proofreading using a word processor, it was mentioned that although software can correct spelling errors or alert you to unrecognized words, it cannot distinguish between words that sound alike (homonyms). Take a look at the examples containing misspelled words below and see if you can find the wrong word in each sentence. Although there are no spelling mistakes, each sentence does contain a mistake in word usage.

  1. What will today's students listen to when they are in their 40s? Is disco music in there future as well?
  2. Coach Thompson's team won ten consecutive Big Twelve Conference crowns, and tied the NCAA record with nine consecutive NCAA champion from 1978-1986.
  3. Life experience sometimes plays an important roll in how and what a student may write about.
  4. During the parade, they band members marched in unison.
  5. Do you think computers have changed are everyday life?
  6. The store at the end of the block does not except checks any longer.
  7. One study showed that of the countries 250 million people, almost 10% still smoke.
  8. As evidence has shone, the crime rate in the city has dropped in the last decade.
  9. If writing is such an important part of the school curriculum, than why are so many students having problems with the essay assignment.
  10. I was raised in a home were rock and roll music was not allowed.

By understanding that proofreading requires a slow, deliberate analysis of what you have written, you will be able to recognize the trouble with the sentences above, and be better prepared to recognize the same type of problems in the future.

  


## Corrections and commentary for the above examples[[edit](/w/index.php?title=Basic_Writing/Proofreading&action=edit&section=T-13)]

  1. What will today's students listen to when they are in their 40s? Is disco music in **their** future as well? _"There" should be "their" because the second form shows possession. It is their future because it belongs to them._
  2. Coach Thompson's team won ten consecutive Big Twelve Conference crowns, and tied the NCAA record with nine consecutive NCAA **championships** from 1978-1986. "champion" should be "championships" because champions win championships. The former refers to the players, the latter to the titles they hold.
  3. Life experience sometimes plays an important **role** in how and what a student may write about. _"Roll" should be "role." The first "roll" refers to the verb roll or the rolls you eat at Thanksgiving, someone's role is the part they play in something._
  4. During the parade, **the** band members marched in unison. _"They" should be "the," and is a common typo--the type that suggests sloppiness on the part of the writer, nonetheless._
  5. Do you think computers have changed **our** everyday life? _"Are" should be "our." Although some people pronounce them alike, "are" is a verb (a form of be) while "our" shows the possession of a group. (People are busy during the holidays. Our family still manages to get together.)_
  6. The store at the end of the block does not **accept** checks any longer. _"except" should be "accept." "Except" forms the base for the word "exception" and shares a similar meaning; "accept" forms the base for the word "acceptance" and shares a similar meaning._
  7. One study showed that of the **country's** 250 million people, almost 10% still smoke. _"Countries" should be "country's." "Countries" is the plural form (i.e., more than one country); "country's" is the possessive form and shows that something belongs to the country._
  8. As evidence has **shown**, the crime rate in the city has dropped in the last decade. _"shone" should be "shown." "Shone" is a form of the verb "shine," while "shown" is a form of the verb "show."_
  9. If writing is such an important part of the school curriculum, **then** why are so many students having problems with the essay assignment? _"Than" should be "then." "Than" shows relationship when comparing two things, while "then" shows a time relationship. Ex: First I went to the store. Then, I went home._
  10. I was raised in a home **where** rock and roll music was not allowed. _"Were" should be "where." Were is a form of the verb "be," while "where" indicates a location or speech._

# Narrative and Memoir[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=8)]

**Narrative and Memoir**

  


  


# Creative Writing[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-1)]

While other forms of writing ask that you to find research in external source before you begin, creative writing does not require this of you. More often than not, creative writing projects only require you to use your memory and imagination to tackle your project. This ability to just sit down and write without having to perform research allows you to practice writing whenever you want. You can try writing a poem on your coffee break or during a bus or subway ride. You can spend an afternoon writing a memoir about your favorite childhood pet, or you could begin to keep a journal where describe the events of your day, the weather, the books you are reading, or television shows you like to watch. For creative and personal writing, the possibilities are endless.

Now you may be asking yourself if you have anything worth writing about, and the simple answers is yes you do! Every day provides an infinite number of topics to write about, whether that be having dinner with a friend, the taste of your coffee, or the beauty of a painting you saw in a museum. The activities in this section will help you jump-start your creativity, and before you know it you will have written some great poems, short stories, and memoirs.

## Poetry[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-2)]

More so than any other form of writing, poetry is known for its ability to express ideas and emotions or tell stories using very few words. Though some poems can be long, in general the best poems are those that help us appreciate mankind and nature by condensing a scene or event into short poem full of specific details. With these poetry exercises, you will attempt to write poems that are short but specific. Like every other kind of writing, the most successful pieces of poetry help us clearly imagine what the poet is talking about by using concrete images or facts. The following exercises will also help you practice writing clear sentences, think about grammar, and practice using punctuation, but most of all have fun writing.

### Poetry Without Punctuation[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-3)]

Have you ever got tired of having to use punctuation and wish you could write without having to worry about periods, commas, and quotations? Well many poets have become famous for writing pieces that do not use any punctuation to make their sentences clear. However do not be fooled, writing without punctuation can be just as difficult as writing with it. For this exercise, read Lucille Clifton's ["the garden of delight"](http://www.poetryfoundation.org/archive/poem.html?id=176011) and then write a poem about a garden or park you like to visit without using any punctuation. Keep in mind that you want the reader to be able to easily understand the poem, so like Clifton insert line breaks or spaces to help the reader understand how to read the poem.

Then on a separate piece of paper, try writing the same poem again, but this time use punctuation. Notice how the poem changes and the punctuation can help you. After you have written the second version of the poem, spend a few moments and journal about writing both poems. Which poem was easier to write? What made it easier to write? Do you like this poem better and why? Which do you think is easier for the reader to understand? Why? Be sure to have both poems in front of you when you journal so that you can easily compare them, noticing where you used punctuation in the second poem and how that might or might have clarified what you wrote in the first poem.

## Narrative and Memoir[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-4)]

### Defining _Narrative_ and _Memoir_[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-5)]

  * Narrative:

1.ACTION 2.REACTION 3.DIALOGUE this three must be needed when writing a memoir ---(narrative lead)---

> Simply stated, narrative is a style of writing that tells a story. It can be fiction or nonfiction and is typically told from a first- or third-person point of view. Narratives can be in the form of short stories, poetry, personal essays, novels, monologues, folktales, fables, legends, etc. The characteristic hallmark of narrative is that there is a character or voice telling the reader or viewer "what happened," as with the "narrators" of most novels and short stories, and many movies or television programs. Well-known and popular TV examples of this would include the late 1980s/early 1990s drama, _[The Wonder Years](http://imdb.com/title/tt0094582/),_ or more recently the prime-time shows _[Scrubs](http://imdb.com/title/tt0285403/)_, and _[Desperate Housewives](http://www.imdb.com/title/tt0410975/)_. A narrative may or may not have dialogue, depending on whether or not the event or action taking place is simply an observation from a distance (like the narrator of a nature documentary) or, for instance, a kind of _I said_ or _he/she said_ situation (like J.D. Salinger's _[The Catcher in the Rye](http://en.wikipedia.org/wiki/Catcher_in_the_rye)_ and F. Scott Fitzgerald's _[The Great Gatsby](http://en.wikipedia.org/wiki/Great_Gatsby)_). Some narratives have multiple narrators, or more than one character/voice, each of whom is responsible for either telling one part of a larger story, or who tell different versions of the same story. Several narrative examples of the use of multiple narrators can be found in William Faulkner's novel _[The Sound and the Fury](http://en.wikipedia.org/wiki/The_Sound_and_the_Fury),_ Ernest J. Gaines's novel _[A Gathering of Old Men](http://en.wikipedia.org/wiki/A_Gathering_of_Old_Men),_ and Akira Kurosawa's film _[Rashomon](http://www.imdb.com/title/tt0042876/)._

  * Memoir:

> Memoir is a specific type of narrative. It is autobiographical in nature but it is not meant to be as comprehensive as biography (which tells the _entire_ life story of a person). Instead, a memoir is usually only a specific "slice" of one's life. The time span within a memoir is thus frequently limited to a single memorable event or moment, though it can also be used to tell about a longer series of events that make up a particular period of one's life (as in Cameron Crowe's film memoir _[Almost Famous](http://www.imdb.com/title/tt0181875/)_). It is narrative in structure, usually describing people and events that ultimately focuses on the emotional significance of the story to the one telling it. Generally, this emotional significance is the result of a resolution from the conflict within the story. Though a memoir is the retelling of a true account, it is not usually regarded as being completely true. After all, no one can faithfully recall every detail or bit of dialogue from an event that took place many years ago. Consequently, some creative license is granted by the reader to the memoirist recounting, say, a significant moment or events from his childhood some thirty years or more earlier. (However, the memoirist who assumes too much creative license without disclosing that fact is vulnerable to censure and public ridicule if his deception is found out, as recently happend with James Frey and his alleged memoir, [A Million Little Pieces](http://en.wikipedia.org/wiki/Million_Little_Pieces)._) Furthermore, names of people and places are often changed in a memoir to protect those who were either directly or indirectly involved in the lives and/or event(s) being described._

### Common Approaches[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-6)]

Below you will find some typical writing prompts that will allow you to begin writing a narrative or memoir. Remember to stay focused and to tell a story when writing in this genre.

  * "Write about someone significant in your life."
  * "Write about the worst/best, most significant/exciting/boring day of your life."
  * "If you had a chance to talk with a historical/famous/legendary/etc. person, what would you talk about? Explain why."

### Sample Assignment[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-7)]

There is not one right or best way to write a narrative or memoir. However, there are certainly better ways to write in this genre than others. Read the following short samples of an "excellent," "needs a little work," and "needs a lot of work" narrative writing assignment! Because it should be a narrative, remember that the writer should be telling a story. All grammar, spelling, and punctuation errors should be cleared up when editing. See [Basic Writing/Editing](/wiki/Basic_Writing/Editing) for more help. So the focus will be on content.

Assignment: "Write about someone significant in your life."

**Needs a lot of work:**

> My mom is a significant person in my life. She has always taken good care of me. She looks after my family and does a lot of hard work. My family couldn't make it without my mom. I really love my mom a lot because of all she has done for me. She's a great person. I tell my mom everything. She is probably my closest friend.

> *****_This narrative needs a lot of work. There are very few specific details. Questions that need to be answered are: How does she take good care of you? What kind of hard work does she do? Why is she a great person? What kind of a person is she? What does she do with the information you give her? What kind of sacrifices has she made for the family?_

> _Answering these questions will really improve the writing. The audience wants to know as much interesting information as you can tell them about this topic. Think about all the details you see and hear in a movie or really good book. You don't need to reach that level, but that should be your goal. Giving some specific, personal examples will help the audience understand the writing and enjoy reading it. See the next example for a better response to this assignment._

**Needs a little work:**

> When I was young, I didn't get along very well with my mom. We used to fight a lot and I just didn't understand her. She always seemed to be in my business and trying to snoop around. I've always had really dry eyes. Sometimes they water to compensate or get really red because they're so dry. My mom used to think I'd been crying and bug me to death asking me if someone had hurt my feelings at school! I was a teenager!

> But now me and my mom are best friends. I tell her everything and she tells me everything. Sometimes we still disagree, but we've learned to understand and repsect each other. We're very different people, but I don't know what I'd do without my mom. She has always supported me and stood behind whatever I've wanted to do or be. She's my biggest fan. In my mom's eyes, I could be the next great world leader, or a famous ballerina, or the first astronaut to live on Mars. It took me a while to realize just how significant my mom is to me, but now that I know, nothing will ever change the way I feel about her.

> *****_This narrative is better than the first one because it has more details and gives some specific examples regarding the writer's relationship to her mom. However, it still needs a little work because even more details could be provided to give the reader a clearer picture of their relationship. For example, the reader doesn't know what has changed in this relationship that led to the two of them becoming like "best friends."_

**Excellent:**

> When I was a teenager, I didn't get along very well with my mom. It seemed like we fought on a daily basis and we rarely if ever understood where the other was coming from. I felt so seperate from her and it was impossible to tell her about my problems because all she would ever do is freak out.  
  
I remember one particular fight in perfect clarity. We were having one of our good days - that should've been the first warning sign. I was helping her weed the flower beds, telling her about a conversation that I had had with my boyfriend's mom the previous night. When I was finished telling her about the advice that Janice shared with me about how to reconcile with a friend of mine, my mom grew very quiet. I asked her if something was wrong but she continued to stare at a stubborn dandelion in the middle of her peony bed.  
  
Finally, she looked up at me. Frustration and anger filled her face and tears spilled down her cheeks. "How come you never come to me anymore?" she spat. "Why do you have to go to other moms to talk about your problems? Am I not good enough?"  
  
I didn't really know what to say. I tried to reason with her, explaining that it's normal for teenagers to talk to other parents about personal problems, but all she did was storm off.  
  
That was the day that I realized how much my mom actually meant to me. I knew from her reaction that she felt devalued and even though we had our issues, I also knew that I had a great mom. She had always taken care of me, provided for me, and as a young child, she was my best friend. I wanted that back and from that day on, the two of us worked on communcating better and getting to know each other all over again.

> *****_This is an excellent example of a narrative because it provides necessary details to help the reader understand the relationship between the mother and daughter. In the "needs a little work" example, the writer did not explain how the mom and daughter became "best friends." This is an important and significant detail. It is important to explain the important details as much as possible in a story. To continue this writing, the writer will probably give another example of how things were after they began to understand each other better. This will give the audience a clear picture of the progress of the relationship._

### Examples:[[edit](/w/index.php?title=Basic_Writing/Narrative_and_memoir&action=edit&section=T-8)]

The following are example compositions written for an assignment where students were asked to write narrative descriptions about a day they consider to be one of their worst. (Note: Even though two of the following three examples have death as a theme, personal narratives and memoirs can just as easily be written about smaller, less dramatic events from one's life.)

**Example 1:**

> It was the worst day of my life, and it was only 10:00am. Sitting in my dorm room sobbing into the phone, my mom tried to calm me down. But she couldn't erase the pain and misery, hurt and disappointment I was currently feeling. What had gone wrong? Why was everyone against me? How would I get through the rest of the day... the week with my injuries? Let me start from the beginning.  
  
It was a cold, blustery day at Evangel University. I had spent the last few days preparing for a presentation for my Children's Literature class, and I would soon go to the preschool just down the road to teach a lesson for the preschoolers. I had made beautiful little magnetic snowflakes that the students could take home with them. The snowflakes went along with the story I'd be reading in about an hour.  
  
I was completely prepared and had spent a lot of time thinking through the lesson and carefully paying attention to detail. As I was about to leave, I recognized how miserably cold it was outside and wondered if I could find a ride, even though the preschool was actually on campus. I asked my roommate if I could borrow her car, knowing there was little chance since it was a leased vehicle and her dad had forbidden her to let anyone drive it. But I thought it wouldn't hurt to ask. She turned me down. She also wasn't able to take me because she had to go to class herself. She apologized, but didn't seem too sympathetic. (What really irked me was that I found out later that she had let her boyfriend borrow her car for a much longer drive than the one I needed to take! I've since forgiven her... I think.)  
  
Next I tried to call my brother, but couldn't get a hold of him. He was probably in class as well. Due to the early hour, most everyone was in class, so no one else was around to ask either. So I bundled up in my warmest, flannel-lined overalls and fur coat and trekked down to the preschool. The snow swirled around me in fury and I was near to tears with my own inner-fury at my roommate who could have helped me avoid this situation.  
  
Gladly arriving at the preschool, I barged in ready to teach my well-prepared lesson, only to discover that another classmate was there teaching her lesson. I couldn't believe it! I knew I had written down the correct date, but something went wrong. The regular teachers didn't have time to fill me in that day, so instead of teaching my beautifully created lesson, I left to trudge back up the hill in the angry snow. Tears streaming down my face, I arrived back at the dorm. I was wearing my clunky wooden clogs and ran up the stairs as I had done a thousand times before. But I slipped...

> *****_This example is a memoir because it's a slice of life as opposed to a complete autobiography. It shows a picture of one day in the life of this person. It is the emotional retelling of a story from the narrator's perspective. Notice that the narrator does not focus on relationships or events surrounding this one event, but just on the event itself. The focus is all of the details that caused this day to be the worst of this person's life. If other threads such as the relationship with the roommate or details about the Children's Literature class had been added, the focus would have been lost in the muddle of too many details._

> _In a memoir, the focus must stay tight. Think of taking a picture with a camera. Think about what you want to be in the picture and what would distract from the picture. Have you ever taken a picture where there was a lot of white space at the top and what was supposed to be the focus: the people, are just tiny dots at the bottom? This is what happens to a story when the focus is too broad. See the [Basic Writing/Invention](/wiki/Basic_Writing/Invention) section of this book wikitext for help on narrowing your topic._

**Example 2:**

> On my worst day I was supposed to get up early so I could get out to my folks’ house on account that my mama needed me to help her take our old dog to the vet. My mama needed my help because she’s not a very big person and our dog is really big. She also has a bad knee. My mama, I mean, not the dog. Well anyway our dog is one of them Great Pyrenees, a great big white monster of a thing, and she’s got arthritis in her hips and spine something bad. So my mama had to make an appointment to have her put down because our dog couldn’t even stand to eat or pee anymore. That’s how bad off she was, you see.  
  
So here I was supposed to get up early to help my mama load the dog into her car and my alarm doesn’t go off. Luckily I wake up on my own and I’m not all that late yet so I hurry up and get dressed and run out of the house to my truck. Then I take off towards my folks’ house kind of fast because I’m already behind schedule and I’m about half way there when all of a sudden I get a flat tire. Making matters worse is the fact that it’s raining outside, been raining all night in fact and I guess that’s why my alarm didn’t work. So I pull half into the ditch because the road doesn’t have a shoulder and of course the flat tire is on the passenger side which means that I have to work in the mud. Even worse my little bottle jack won’t lift the truck on account it keeps sinking into the ground. Well lately I’d had some bricks in the bed of my pick-up but when I go to get them out they aren’t there. Now I’m pissed because I’m late, I’ve got a flat tire, I can’t get the jack to work because it’s raining and the ground is too soft, and some jackass has stolen a handful of worthless bricks from the bed of my truck. This on top of the fact that our old dog’s got to be put down and my mama needs me to be there. Still determined to make it, I root around in the ditch till I find a couple of rocks I can put under the jack. I finally get my tire changed but by then I’m soaked to the bone and covered in mud, which means that I get my seat all wet and muddy too.  
  
Finally I make it out to my folks’ place and my mama is sitting in the front yard with our dog and holding an umbrella over her. I can plainly see that she’s in pretty bad shape, worse than the last time I saw her. The dog, I mean, not my mama, although she’s looking pretty down herself. She doesn’t bother to ask why I’m all wet and muddy, so I know things are bad for sure. When I try to pick our old dog up to put her in the back of my mama’s Jimmy she yelps real loud and snaps at me. I decided then and there that getting her to the vet wasn’t going to work. She was too heavy and in too much pain to be messing with. So I went and got my old red wagon out of my dad’s shop and carefully my mama and me lifted her onto it.  
  
My mama knew what had to be done and so she says her goodbyes to our old dog. Then I roll her slowly around the house to where we’ve buried other pets in the past and I dig a fairly large hole. When I am finished I sit on the ground beside the old red wagon and talk to our dog for a bit, tell her what she’s meant to me all these years and that I am going to miss her. I’d rather not say what happened after that other than I like to believe she understood it all and that it came as a relief to her.  
  
When I get back to my place later I realize that I’d left in such a hurry earlier that I’d locked myself out of the house. It had stopped raining by then, though, so I just sit for a while in a lawn chair there on my porch. Then I look over and see the bricks still lying there where I’d stacked them a few days before and forgotten. Suddenly I start laughing then and can’t stop, keep laughing till tears run down my cheeks. Looking back on it now that seems pretty weird since it had been such a terrible day.

> *****_This example, like the one above it, is also memoir. It is similar in that it also describes a day in the writer's life and is necessarily limited only to those details that are relevant to the story and that move the narrative forward. A good exercise, though, might be to examine how these two samples from the same genre are different. Do both sound as if they are spoken by the same "voice"? What details from each might you use to argue the speakers' gender? Does either "sound" female/male? Also note that Example 2 reads much more like spoken language--is that appropriate for this genre, or should the writer have written in a more academic or formal manner?_

  
**Example 3:**

> I was standing in the middle of Dollar Tree, leaning on my cart, when I said, "What?" to my mom telling me about my little black cat, Baby, being found dead a few days earlier. "Baby's dead, honey." I couldn't say anything. What could I say? I had been the one to take her to the farm thinking that she would adjust and be happier as a farm cat. Besides, I had too many cats, six actually, and Baby and Ginger had been the most logical choices to relocate. Both of them were unhappy living in such a small environment with four other cats. Baby suffered from anxiety problems and Ginger just wanted more territory. She was always so bitchy, hissing like she owned everything and everyone. Adorable, yes, but incredibly bitchy. Baby just wanted to be alone, or with me. The only way I could get her to come out of hiding is if I'd sing to her - any song with her name in it. Her favorite one was the one from the movie _Dirty Dancing_ "Ba-byyy, ohh-ohhh ba-byyy, my sweet ba-byyy, you're the one. . ." When I'd sing it to her, she'd roll 'on the floor and rub against me as if to say, "I reeeaaallly love you!" I'll never be able to listen to that song without missing her now.  
  
"Honey, are you alright?" my mom asked quietly. No, I'm not alright. I knew something was wrong. I had a feeling several days ago - one of those feelings that tell you something is wrong, but I chose to ignore it. "How did she die?" I ask, trying to keep my emotions under control. It's no use though, tears start streaking my face and Dollar Tree customers are beginning to stare. "They found her dead in the cabin," mom said, her voice choking, "I'm so sorry, hon." "She was still in the cabin?!" I practically shout into the phone. "I thought Laura picked her up to take her to her house." Mom grew quiet. After a few moments she said, "They never could catch her. Dad said that they looked for her every day. They moved the furniture and everything but they couldn't find her. Now they think that maybe she might have climbed behind the fridge to hide."  
  
I was livid, but I knew it would just kill mom and dad if I blamed them for this. Despite this fact, I had to ask one last question, "Mom, why didn't you guys call me and tell me that you were having problems with her? I could've come home to take care of her. I told you that I smelled natural gas or something on the day that we dropped her off at the cabin. Why didn't someone call me?!" At this point I was hysterical and customers were steering their shopping carts way around me. When my mom finally answered her comforting voice was gone. Replacing it was one of defense and insensitivity. "We did the best we could! Dad's been so depressed lately and this almost pushed him over the edge. He knows how much you love your cats and he's blaming himself. It's not his fault and it's not yours either! Do you hear me?"  
  
All I could do was cry. I didn't want to hurt them, but I just couldn't understand why they chose not to call me. And I do blame myself. I knew that something was wrong, and knowing that she was alone in that cabin for two weeks, going through god knows what, thinking god knows what, well it just killed me inside. I was filled with guilt. I had rescued her as a baby, beaten and left for dead and now, seven years later I just pawn her off on someone else and she dies alone? I don't even want to know how much pain she may have been in. How in the world will I deal with the guilt of knowing that all of this could've been avoided? How?

> *****_This example is also similar to the above examples so the same comments apply. It is a narrative memoir, however there are two elements within this memoir that set it apart from the above examples. First of all, it includes dialogue which is somewhat tricky when writing. The most important thing to remember is that dialogue should sound natural - like the voice of the person speaking. Practice saying it out loud as if reading a script for an audition. Also, when using dialogue make sure the reader can understand who is saying what.  
  
Another element that was included in this example was a specific use of stylized writing during the recitation of Baby's favorite song and her response to that song. This style of writing is becoming more popular in mainstream writing - especially comedic novels. An example of this style of writing can be found throughout the novel, _The Nanny Diaries_, by Emma McLaughlin and Nicola Kraus._

# Writing about reading[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=9)]

A common form of writing is a basic reading response paper. Short of an essay or longer thesis analyzing text, the **summary** and **critique** are often employed to identify details or provide support to a more lengthy assignment to the reading. Teachers assign summaries to ensure students' understanding of the reading material or build a composite of background knowledge for future assignment. When teachers assign critique, they are looking for a reaction to the reading material that involves specific detail. Summary and critique are common elements in many assignments other than formal papers, including reading response journals, book reports, and essay exams.

## Summary[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-1)]

A basic report on a reading is a summary.

A summary is generally a shorter paper, detailing the action of a text. Summaries are used in order for you to prove you have read the text and have thought about the content. Since summaries are generally shorter works, they may be a part of a larger project in the course.

Students sometimes write summaries with their teacher in mind as the audience, although the teacher has read the text several times. However, when you write a summary, assume you are writing the paper for someone who has not read the book you are describing.

Think about the type of text you are reading and take notes.

Make highlights. If you are reading a story, you will want to keep track of the order of events. If you are reading a persuasive article, you will want to keep track of main ideas and arguments. These notes will make quick reference when it is time to write the summary.

Assignment sheets can be helpful.

If you have an assignment sheet, look over the content carefully to see what the teacher expects. Your instructor may have listed a specific question that you need to answer or some specific issue for focus. If the instructor hasn't provided an assignment sheet, don't be afraid to ask questions to better understand what is expected of you. Don’t go into the writing assignment without understanding of the expectations or guidelines (always ask!).

### Format[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-2)]

In the summary, name or make reference to the text and the focus of your writing. For instance, if you are writing a paper summarizing the _Odyssey_ with a focus on the conflict between Poseidon and Odysseus, consider this opening sentence:

    In the _Odyssey_, Odysseus struggles against Poseidon in order to get back home.

This sentence makes direct reference to the assignment and the reading. The following summary will detail the action with a focus on the conflict of Odysseus and Poseidon. The teacher is aware of the focus since the topic is outlined in the opening sentence. The rest of the essay will be a summary of the action with reference to the opening sentence.

Here's an example of a complete (very brief) reading summary responding to the prompt, “Summarize the conflict between Odysseus and Poseidon in the _Odyssey_.”

> In the _Odyssey_, Odysseus struggles against Poseidon to return to Ithaca. Zeus, at the request of Athena, calls for a consensus among the gods to allow Odysseus to return home safely. Missing from the meeting atop Mt. Olympus is Poseidon who is still angry with Odysseus for blinding his son Polyphemus. As Odysseus sails from the shores of the Cyclops Polyphemus prays to his father to bestow the curse that if Odysseus is to return home that it be many darks years before it happens. Polyphemus curse is granted by Poseidon, his father, and the consequence for Odysseus’ action is to suffer wind, wave, and storm on his every return to sea for ten long years.

Always use specific names of places, people, and references in your writing as evidence to your teacher that you have read the material closely. If you have time, it is never a bad idea to work through drafts to use more precise terms and language. Develop your sentences by using sentence combining techniques to connect more ideas and details to your thoughts.

## Critique[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-3)]

**Critique is also called evaluation, analysis, or interpretation.** Teachers will often ask for a response to a reading assignment which goes beyond summary, one which analyzes a text and explains why it works (or doesn't). A summary is assigned to make sure you understand the reading, but for a critique you are showing your ability to think critically and make judgments about the assigned reading using details, support, evidence.

### Literary critique[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-4)]

A literary critique is an analysis of a story or poem.

Sample assignment:

> Critique Homer's presentation of courage in the _Odyssey_.

### Format[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-5)]

A good way to approach your critique is to begin with a thesis in order to layout your argument.

Sample thesis:

> In Homer's _Odyssey_, courage is the risk of self for ideals.

This thesis works as a statement that can be supported. The sentence is put forward as a statement of argument to move forward with elaboration. Notice this claim of courage can be supported by examples from the reading.

Supporting the thesis requires finding those details that support your claim. Finding details can includes using notes, rereading the text, or class discussion to provide evidence to the claim of the thesis. Any details should serve as direct evidence: quotes, summary, paraphrase in direct support to the thesis statement.

Samples of evidence:

> In direct reaction to Eurylochus's objection of possibly being consumed by Circe and saving themselves, Odysseus charges up to save his men who have been turned to pigs by the witch.

> To allow his men to escape the Sirens, he has his men tie him to the mast and endures the Siren song.

Even so, evidence by itself is insufficient. Show how it fits together by providing explanation of your evidence to the thesis statement.

Sample paragraph:

> In Homer's _Odyssey_, courage is the risk of self for ideals. Odysseus puts the life of his crew before the concern for self in his actions. In Eurylochus's return from the witch Circe, where twenty-three men have been lost to her sorcery, he reasons they should put out to sea in order to avoid further loss. Odysseus, without reservation, goes after his men (book 10). His thought is for his men and not his self, similar to his selfless action of exposure to the Sirens' song. As his men safely row past the harpies with beeswax in their ears, Odysseus endures the torturous song until they have gone a safe distance (book 12). Homer presents Odysseus's courage as sacrifice for those important to him.

It is a good practice to use quotations where the exact words are necessary. Do not rely too heavily upon direct quotation, pure summary, or paraphrase - use explanation to show relationship between ideas. This is where an assignment sheet or discussion with your teacher may be helpful to clarify the expectation.

### Argument critique[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-6)]

In the academic world, argument doesn't mean fighting--it means making a point using reasoning. The example above of the _Odyssey_ analyzes literature rather than an argument. Literary analysis may be familiar from high school assignments, but college assignments more frequently require you to analyze an argument--to critique someone's reasoning. Instead of looking at plot, characters, and setting, you'll look at the author's reasons, evidence, and how it supports her main point. Besides this, the process of analysis is much the same: you will need a thesis about the author's argument and supporting details drawn from their reasons and evidence.

Although a good critique often starts with a relevant summary, keep in mind your goal--making your own point about the author's argument. Also ask your professor whether you are supposed to take a side on the issue the author is arguing about. Unless your instructor asks you to take a stance, concentrate on the author's presentation of the issue, not whether you agree with the stance he or she takes. Remember, a person may have bad reasons for believing right things or good reasons for believing wrong things.

Some elements to focus on:

  * The writer's credibility: Does the writer seem reasonable? Is she an expert in the field?
  * Underlying assumptions: Does the writer seem to assume everyone holds her viewpoint?
  * Emotional appeals: Does the author play on the reader's emotions? Does that work?
  * Evidence: Does the author have good reasons and examples to support her conclusion?
  * Room for improvement: What would have made the argument more convincing?

Sample assignment:

> Analyze one of the articles we read for this unit and explain whether or not the author does a good job making his or her case.

Sample thesis:

> Martin Luther King successfully defends himself against the criticisms of white clergymen through sensitivity to his audience.

Samples of evidence:

> King builds credibility by referring to the Bible.

> King concedes that his audience has good points.

Sample paragraph:

> In "Letter from Birmingham Jail," Martin Luther King successfully defends himself against the criticisms of white clergymen through sensitivity to his audience. He does this first by building his credibility as a fellow clergyman, quoting and alluding to the Bible throughout the letter. He also avoids making his audience confrontational by conceding his reader's most reasonable points: King admits that negotiation is a better approach than protest, but he argues that negotiation isn't possible until people are willing to listen. By setting himself up as a reasonable, Godly man, King does his best to gain the sympathy of the white clergy who opposed his methods.

Notice how the critique focuses on how King argues rather than whether he was right or wrong. It also does more than simply summarize the letter--it makes a specific point about it and backs that point up with examples from the text.

## Conclusion[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-7)]

After a whole process of content-writing, you still need to draw a natural and complete conclusion of what you've already written down to restate and strengthen your points of view with which the readers could get a better understanding of the central idea of your paper. Just make it a beautiful final stroke on your paper!

## Essay exams[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-8)]

In many courses, you may find yourself asked to write an in-class essay, or essay exam. An essay exam will often ask for a summary or critique of readings for the class, so the major techniques are the same. The common "five paragraph essay" is at its most useful in the essay exam: write an introduction with a clear thesis, about three subpoints which prove or illustrate your point, and a conclusion that ties it all together. This doesn't mean you can't be creative, but an essay exam is most different from take-home essays in the amount of time you have to work on it. You can't do anything too complicated. There are a few tips we can share with you to get through an essay exam:

  * Many instructors will give you a list of possible questions on the test. Study them! There is no substitute for understanding the assigned reading.
  * Find out if you are allowed to use your reading material or notes during the exam. 
    * If you are allowed to use notes and the instructor has shared questions that may appear on the exam, write an outline for each question ahead of time. You don't want to waste time during the actual exam trying to think of good examples.
    * If you are not allowed to use notes, write outlines anyway. Study them at home and review them before the exam. You can write them down as soon as you begin the exam. (Even if the exam begins with multiple choice, you can turn it over and write it down before you forget.)
  * Prewrite. Think about the question and figure out what you want to say. 
    * If you already know the questions that will be on the exam, do your prewriting at home so you can spend more time writing during the exam.
    * If you didn't know the questions ahead of time, read the question carefully and prewrite on a piece of scrap paper or on the exam itself. (You can erase it afterward.) Write an outline.
  * Don't ramble. Have a clear structure in mind before you start writing. Stick to this outline.
  * After you finish, check to make sure your main point is clear and stays the same throughout the essay. Remember, even a summary has a main point.
  * If you are writing a critique, check to make sure your line of reasoning is clear and makes sense.
  * Fix major errors, but don't spend all your time on grammar--your instructor wants you to show you understand the material.

## Citations[[edit](/w/index.php?title=Basic_Writing/Writing_about_reading&action=edit&section=T-9)]

Don't forget about [citations](http://owl.english.purdue.edu/owl/resource/557/01/). When your writing refers to texts written by others, citations help the readers of your paper to locate the information from your source. When you don't cite your source, your reader assumes that everything you wrote came out our your own mind. A basic rule of thumb with citations is that if the idea is not your own, you should cite the source. This will help protect you from plagiarism. Consequences for plagiarism can be quite severe, so always ask your instructor for advice if you're not sure when or how to cite.

# Public Affairs writing[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=10)]

Public Affairs Writing:

## Definition[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-1)]

Public affairs writing is the term used for publications written with the purpose of expressing comments, ideas or concerns to a target audience. It is also used simply as a source of informing. Some common forms of public affairs writing include letters to the editor, letters to your congressman, or the more recent genre of e-mails and blogs. The content is usually opinion driven with the purpose of informing or persuading the audience.

  


## Importance of Public Affairs Writing[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-2)]

What kind of government would we have if our citizens didn't get involved? If you are reading this, there's a good chance you have the intention of improving your writing, and therefore yourself. You are probably also aware of your political, educational and economic circumstances. Chances are you've also got your own opinions of them. Public affairs writing can be used constructively on a personal or public level to share your thoughts and experiences to a broad range of audiences. It's important to become involved on a civil level with your community and peers. What would you write a letter to your congressman about? What would you say to the editor of that last newspaper article you read? Learning the correct forms of public affairs writing can give you the tools you need to make a difference in the public arena.

## Examples of Public Affairs Writing[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-3)]

Editorial or Op-Ed: An editorial or op-ed is an opinion piece that is typically found in newspapers, magazines, journals, newsletters, or other types of periodical publications. A writer will select a controversial, generally topical or relevant issue and then compose a persuasive piece in which they express their beliefs about the issue. Usually editorials are written by professional writers, but sometimes a magazine or newspaper will publish editorials by “regular people”—even college students, for that matter.

Letter to the Editor: Nearly all periodical publications—newspapers, magazines, online publications—offer the opportunity for the public to interact with the ideas expressed in the publication, allowing their own voices to be heard. The forum for this exchange of information is generally called the “Letters to the Editor” section. The format for these writing samples is similar to ordinary letters that you would perhaps send to a friend or a relative, except the style is usually more formal, the writing more polished, the tone is generally persuasive, and the content involves a reaction to something printed in the publication. Sometimes a letter to the editor is simply a congratulations on a job well done for a particular article or feature. Other times (more frequently) the letter writer takes issue with something printed.

Letter to a Policy Maker (i.e. Congressman, Governor, etc...): A significant part of being an active member of your community is taking an interest in public policy. After all, public policy affects _everyone_. Thus, it is important to make your voice be heard (an opportunity we all have in our democratic society), and writing to the public officials who directly contribute to the intricacies of daily life is one significant method in achieving this goal.

Proposal: A proposal is a stated plan of action or suggested solution to a problem. Proposals are common in the business world and politics. Examples would include a proposal for a to counter negative employment trends or to improve student performance in education.

Flyer/Brochure/Pamphlet/Advertisement: These are all examples of materials distributed to the public in the hopes of influencing public opinion. These materials often try to appeal to emotion and they tend to include an emphasis on visual literacy.

Internet Journal/Weblog: Welcome to the Information Age! These days the Internet and electronic media are far more prevalent in our society than print material. If you really have an interest in social issues that affect the public, and you want a large audience to read and respond to your ideas, then a weblog or "blog" is the way to go.

## Writing an Editorial: A Journey Through the Writing Process[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-4)]

The following is a sample writing process that details a student's writing process for writing an editorial. The assignment states to write a 2-3 page editorial about a controversial issue that interests her.

1\. Inventing:

A. The first step is to come up with ideas for the editorial. The student (let's call her Mary) begins by brainstorming a list of topics that she considers interesting. She lists such various topics as educational issues, birth control rights, and environmental problems. After briefly considering each issue separately, she decides on education, a topic that interests her a great deal.

B. Next, Mary realizes that she will have to narrow her topic down. After all education is a huge topic that includes any number of controversial issues. Once again she brainstorms a list of topics: teacher salaries, standardized testing, student uniforms. Mary considers the scope of her assignment-the page length is 2-3 pages, and she understands that some issues are probably to complex to sufficiently tackle in such a short amount. She decides to write about school uniforms.

C. Finally, before drafting Mary realizes that she will need to have a preliminary thesis in order to begin. After all, the thesis is the main point of a paper, so she needs to have a goal for her paper. Mary decides that she will argue that school uniforms will be beneficial to student performance.

2\. Drafting:

A. Next Mary begins the process of drafting, or actually writing, her paper. She begins with an introduction that incorporates her personal experience of attending a high school that did not require uniforms. She briefly details her high school experience as being problematic: poor student behavior, low grades, a surprising high dropout rate.

B. Mary then focuses on her body in which she discusses the possible benefits of school uniforms: more discipline, less focus on materialism and superficial appearances, a more responsible student outlook.

C. Finally, Mary drafts a conclusion in which she reiterates her main thesis and ends by calling her audience to action.

3\. Revising:

A. After writing a complete first draft, Mary goes back and considers her paper. She decides that while some personal experience is okay, she has used too much personal narrative and she eliminates some of it. Then she decides to tighten her argument and add more examples of evidence.

B. Then, Mary decides to improve her thesis statement by qualifying it slightly. She writes that school uniforms may improve student performance if integrated into problem schools.

4\. Editing:

A. Finally, Mary turns her attention to editing. She reads through everything, catches a few grammatical errors and changes some words in order to clarify her meaning.

B. At last, the assignment is complete.

## Writing a Letter to the Editor[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-5)]

If a local issue is weighing heavily on your mind, a letter to the editor can serve as a means to make your voice heard. The following are examples of issues that may prompt a letter to the editor:

  * Local school issues (bond issues, board of education decisions, etc.)
  * Local electoral races
  * Environmental issues
  * A public "thank you"

When writing your letter, think about your audience and reasons one may have to disagree with your opinion. In considering those opinions, address the anticipated disagreements in your letter. Consider what points would make a convincing case, and build your letter to support these points.

### Letter to the Editor Exercise[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-6)]

Choose an issue which affects you at the local level. Determine what stance you will take on the issue. Organize your thoughts clearly and concisely. Do not make personal attacks; they make you seem small and petty, and may, in fact, negate your position.

## Writing to a Policy Maker[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-7)]

Be brief. Limit your letter to one page if possible, but no more than two pages. Get to the point. Address one issue if possible but never more than two different issues. You can add an attachment to your letter that contains more detail if you wish.

Make no demands. But give the member of congress and staff a recommended course of action to support. Never condemn, threaten or inject partisan politics into your letter. Doing so can only undermine your credibility. Keep your eye on the ball and stick to the points you want to make.

All politics is local. Remember to make the link to your member’s district or state. Stress the contributions that your institution can make and the benefits the community and country receives from supporting biomedical research.

Timing matters. A letter arriving by mail or fax after the House or Senate has taken action is meaningless. Get your facts right and make certain your letter is considered in time.

Use caution with e-mail. While many offices are increasingly relying on e-mail for constituent contact, surveys show it is not as effective as a typewritten letter. Members receive a great deal of e-mail from non-constituents, which are dismissed. E-mail correspondence also tends to be written in a faster and more informal style than letters, increasing errors in grammar and syntax and making your message unclear.

### Composing Your Letter[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-8)]

  * Know what your purpose is and make it clear early in the letter.
  * Collect all the information you will need for your letter and jot down the basic order in which you plan to cover this information. Organize your material in the most persuasive order.
  * Keep your reader in mind as you write. Select a tone for your letter which is appropriate for the reader. Always be courteous and use positive rather than negative words.
  * Avoid the use of words and phrases which are stiff, technical, or overused. Use a writing style which is natural and easy to read.
  * Read your first draft out loud to test it for overall "sound" and effectiveness. Be sure your letter states clearly what it is you want your reader to know after he or she reads your letter.
  * Follow the correct form for the kind of letter you are writing and use that form throughout your letter.
  * Make sure your final copy is typed or written neatly and is attractive in appearance.
  * Revise and proofread your letter the same way you would any other piece of writing. Look for errors in sentence structure, usage, punctuation, spelling, and capitalization.

  


## Resources[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-9)]

If you are ready to become politically involved but are unsure of who to contact or where here are some resources you can use.

\--To find your local congressman or state senators you could go to a major search engine (such as yahoo) and type in the city, county or state which you are targeting and the word "government" or try www.congress.org

\--To write a letter to the editor or an opinion piece in your local newspaper, check the publication you are writing to. They will each usually have their own specific instructions.

\--To submit a piece to a magazine, it is important to be familiar with the publication. You need to be sure you are addressing your target audience. Instructions for submission are usually found within the magazine itself. Be sure to include a brief description of yourself on a separate paper.

\--One resource of influence that is not often thought of in our high-tech society is that of local bulletin boards. We've all seen these at local businesses and government offices, usually those old-fashioned cork boards. Why not use them? You can get your point or idea across to many people quite cheaply if you utilize these free advertising spaces. Once you have your flyer or pamphlet ready don't be shy! Use those public notification spaces. This is especially applicable to government related issues.

  


## Practice Assignment[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-10)]

Let's get a good feel for becoming involved with this assignment-to complete a letter to your local congressman. Follow the suggested steps below to create a letter of your own.

  
1\. First, identify an issue in the current news that has some impact or influence on your life. Also, your teacher may assign a current topic to you.

2\. Second, make an outline of your personal ideas on the subject. You may ask questions like: Do I agree with the current actions or issues? How does this affect me or my family? What can be done to improve the situation? Or, you could consider how to thank your representative for a job well done.

3\. Follow the outline in the Public Affairs Writing section entitled Formats for your letter.

4\. Write your letter!

5\. Proofread or revise as necessary. You may workshop these letters in class and focus on issues such as; Is the point clearly stated? Is the wording polite and courteous? Is it an effective argument or could it use some clarification?

6\. Send your letters in the mail! This assignment is pointless unless you truly feel that your voice will be heard. Take that final step of dropping it in the mail and know that your hard work will be recognized not only by your instructor, but also by your political representation. Good job!

  
Example: There are different format ideals for different types of public affairs writing. A letter to your state congressman would be a good format to learn for the public affairs arena . It should look something like this:

  


The Honorable (Full Name here)

US House of Representatives

Washington, DC 20515

Dear Representative (Last name here),

  


  
This is where you put the content of your letter. It's a good idea to begin with your name and city of residence. Be sure the purpose of your letter is addressed in this first paragraph. Be polite and to the point. Remember to use an appropriate tone for a political representative (you're not talking to your classmate).

  
Keep the letter one page or less and only address one issue per letter. You only have one chance here to be heard so be sure not to ramble. Use specific real-life examples related to your issue, if possible.

In conclusion be sure to thank your congressman for their time.

  
Sincerely, Your constituent (your name here)

## Another Practice Assignment[[edit](/w/index.php?title=Basic_Writing/Public_Affairs_writing&action=edit&section=T-11)]

The Internet Assignment: The Discussion Board

Due to the rapidly expanding use of technology in our society, many instructors are beginning to incorporate technology into the writing class. One common practice is the use of the Internet discussion board in order to stimulate class discussion in an environment that is outside the classroom. Some students actually feel more comfortable with virtual discussion than regular discussion because they have the chance to express their ideas using an assumed name--thus, they have the freedom of anonymity. Other students who have problems with speaking up in class due to shyness or insecurities have the ability to gather their thoughts before they release them into the public.

The Discussion Board assignment is designed to get students to think about important issues and to express their ideas in an environment where they will get responses to their writing.

Assignment: Let's practice using this medium. Pretend that your instructor has created a discussion board. (Or perhaps he or she actually has.) The discussion board instructs the class to debate whether or not technology has had a positive effect on society as a whole. How would you respond? What aspects of the question should you explore? How would you support your argument?

What makes for effective online discussion? Effective online discussion involves a thoughtful and mature discussion of the question in which each party contributes something worthwhile and bounces ideas off each other. You should be prepared to have other people disagree with you. You should also be prepared to support your own opinions and to not take anything personally.

Rules of Online Discussion:

-Do not take disagreements personally and do not respond to arguments that you disagree with by attacking the person who made them. Do not respond to personal attacks. Keep the discussion on topic.

-Stay focused on the question. Avoid getting off track by asking personal questions or bringing up irrelevant topics.

-Keep your language friendly and appropriate. Avoid profanity, derogatory language, and sexist, racist, or homophobic remarks.

-Do not type your responses in all capital letters. This gives the impression that you are shouting and it is considered rude.

-Keep emoticons such as the smiley face :) to a minimum. One or two is okay, but if you use them constantly then you will appear very unprofessional, and people may not take you seriously.

-Try to use proper spelling and grammar. A few abbreviations are okay, but if you use too many, then other people may become confused and not understand what you are saying. The discussion board should be more formal than an Internet chat with friends.

# Investigative writing[[edit](/w/index.php?title=Basic_Writing/Print_version&action=edit&section=11)]

## Introduction to Investigative Writing[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-1)]

### Definition[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-2)]

**Investigative writing** is writing that is meant to defend a thesis while exploring various areas of a topic.

Investigative writing sets out to investigate a topic and report the findings to the reader. It is an extremely versatile form of writing that can span all kinds of topics and genres. It can be anything from a newspaper article to an entire book based on one specific research subject. Investigative writing provides a chance to help answer questions for the readers and the writer.

### Well known examples[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-3)]

Investigative writing is the basis of some very intriguing works in many genres including books, film, television, and other media.

Investigative reporting on television programs, like _60 Minutes_ or _20/20_, features some of the most obvious examples of investigative writing. Although viewers do not physically read the shows' scripts for themselves, the writing done to prepare for each show is investigative writing nonetheless.

Truman Capote's _In Cold Blood_ is an example of book-length investigative nonfiction. Capote investigated the murder of a family in Kansas. There have also been a few film versions, like the recent _Capote_.

Many documentaries on film or television are investigative as well. The documentary _Super Size Me_ was a way for documentarian Morgan Spurlock to explore the correlation between obesity and fast food in the United States. The film sought after the answer to the question: What would happen if someone ate nothing but McDonald's for a month?

### Oh, the possibilities[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-4)]

Many students dread the assignment of a research project or paper, but there is great potential for such an assignment to involve your own interest and still satisfy the teachers' requirements.

Every single field has the need for research and for questions to be asked. Whether you are interested in math, military, literature, history, or something you saw in the media, you can let your questions about the topic lead you to an interesting research project.

## Forming Your Question[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-5)]

If you read the previous section, you know that investigative writing can play an important role in all fields, yet you may not be certain how to begin your own assignment. The simple way to begin is with a question or preferably many questions.

### Those all important wh- words, and how![[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-6)]

What, who, when, where, why, and how are key words that can help you get started. Your initial question may be, "What political factors would have influenced Dickens depiction of London in _David Copperfield_?" You could also ask when, where, why, how, or even more what questions based on that topic. The key is to ask many questions and keep an eye out for a question that could lead you to a solid thesis.

### Inspiration for finding the question[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-7)]

It depends on how wide a variety of subjects your teacher allows, but in general, questions can come from your class reading or something you observe in your daily life. If you have the chance it is best to get your questions written down as soon as possible--a bit of a brainstorming session can be a good way to get your ideas down so you do not forget them! You could compile a list of the questions or map out your questions and ideas to see other possible links.

You do not necessarily need to know the answer to any of the questions when you begin, but the question you choose to answer should be something that you find interesting and that you could answer after a little research and reflection.

Also, try to ask open-ended questions or questions that are going to require some explanation.

SIMPLE: Who was the first president of the United States?

SIMPLE: When did George Washington serve as president of the United States?

EXPLORATORY: Why was George Washington chosen to be the first president of the United States?

Note: While all of the wh- questions probably need to be answered, "why" or "how" questions are often the best questions on which to base your entire paper.

### Questions in all fields of study[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-8)]

What do people use that gives off the most carbon emissions? (Science: Ecology)

Who caused the Great Chicago Fire? (History)

When did blues music first start in America? (Music)

Where is gasoline sold at the cheapest price to the public? (Economics)

Why is Italy the setting for so many of Shakespeare's plays? (Literature)

How did cavemen make their cave paintings? (Art)

## Research[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-9)]

**Why Perform Research?**

During research, you often discover new information.

You probably perform some type of research more often than you realize. When you make a decision to take a class for college, you might look through the college catalog to find out information on the class description. When you decide to purchase a car, you will probably want to review information related to different models. When you are assigned a paper on a specific topic in one of your classes, you will perform research to obtain as much information on the subject as possible.

#### Credibility[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-10)]

After you have obtained the necessary information through your research, you need to decide which sources of information are credible enough to use in your paper. You may have sifted through an enormous amount of data, and now it is time to put everything together--but is that article from "Reader's Digest" as credible as the one from "The Journal of the American Medical Association"? The latter information would probably be more credible for your piece than the other.

One good rule of thumb to use when deciding on credibility is to ask yourself: "Does this information come from a peer-reviewed journal or other peer-reviewed text?" Peer-reviewed simply means experts in that field of study have read the article and approved its publication. If you are investigating an article that deals with contamination in the Ozarks' ground water supply and one source is the Springfield News-letter and the other is the peer-reviewed "Scientific Journal," the journal article probably holds more credibility because it is peer-reviewed. This is not to say that the contents of the newspaper article are incorrect, but it helps your own article seem more reliable if you have researched information that is considered first-class in its field.

Also beware of information garnished from websites, blogs, forums, and other types of internet sources that are written by people with complete autonomy. Much of the information found on the internet is based on unqualified opinions or misinterpretations of facts. Information on the internet runs the risk of being highly biased and outright inaccurate.

### Sources[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-11)]

#### Primary Sources[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-12)]

Determining if your sources are primary or secondary means determining what is first-hand information and what is merely the re-telling of that information through a third party of some type.

First, let's look at primary sources. Primary sources present first-hand knowledge about a certain topic. In other words, these sources are presented by someone who experienced something first hand. Elie Wiesel's _Night_ and the diary of Anne Frank are both first-hand accounts of the horrors of the Holocaust. On the other hand, a play based on Anne Frank's life written by someone who read her diary and an encyclopedia article about Nazi death camps written by a historian not present at the time they existed would be considered secondary sources.

First-hand documents might include court records, original interviews, diaries giving first-hand accounts of information, journals, etc. You can also say that primary sources keep records of events as they have been described--without the use of interpretation or commentary by someone else. They can also include information gathered from data that has not been manipulated or interpreted by someone else.

#### Secondary Sources[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-13)]

Secondary sources are an analysis of the primary source through a restatement, restructuring, or re-interpretation. All subsequent material, such as interpretations or studies that are based on the primary source, are considered secondary sources. Primary sources are often used as a base for secondary sources in order to argue a point or persuade an audience towards a certain outcome or opinion. Examples of secondary sources might include encyclopedias, textbooks, dictionaries, and books and articles whose main purpose is to interpret or review work done in the field of research. Examples of primary and secondary sources:

**Primary Source**

Art: Original artwork, History: "The Diary of Anne Franke," Literature: An original poem, Political Science Original: "The Bill of Rights," Theatre: A taping of a live play production.

**Secondary Source**

Art: An article reviewing the original work, History: A Book about Jews escaping Nazi terrorism, Literature: A critique of the original poetry, Political Science: An essay on the founding fathers' work on the Bill, Theatre: An article about the author of the play.

**Citation and documentation**

Although citations and documentation can be confusing, it is not as complicated as one might think. The best thing to remember is: If you use a statement, piece of an article, or basically more than three consecutive words that have been written, taped, or stated by anyone other than you in your paper or article, then it needs to be placed inside quotation marks and given a parenthetical citation. However, even if you put the information into your own words, if it is someone else's idea or it is information from another source, you must use a parenthetical citation. A parenthetical citation means you include the authors name and page number in parenthesis within the text. This form may differ between the Modern Language Association (MLA) and the American Psychological Association (APA), and this is covered in other sections of this text, but the rules are hard-fast and set so that you do not find yourself committing plagiarism (see the next topic for more).

**Plagiarism**

The definition of plagiarism is very simple: if you use information from a source other than yourself in your investigative writing, YOU MUST GIVE THE SOURCE CREDIT! There is no way around this, and not doing so is cheating, and if detected by your instructor will likely result in harsh consequences. Because of its etymology, many people think of plagiarism in terms of kidnapping the offspring of another person's mind.

In order to avoid plagiarism, you must give credit to the source whenever any of the following are used:

  1. An idea, opinion, or theory that belongs to someone else.
  2. Anything that falls beyond the realm of common knowledge, such as statistics, facts, graphs, charts, or drawings that you include in your paper but did not design or calculate yourself.
  3. Quotations that have been taken from another person's written, taped or spoken words, or any paraphrasing of these words.

In short, if you use information in your paper that you did not come up with on your own, make sure you give proper credit or you will be plagiarizing.

  


**Types of documentation: MLA, APA, etc.**

The two most popular forms of documenting sources and creating citations are outlined by the Modern Language Association (MLA) and the American Psychological Association (APA). These organizations publish manuals that provide clear instructions on how to cite sources and how to embed citations. However, keep in mind that since these are separate organizations, their rules of documentation are slightly different. The information contained in their manuals is too voluminous to include here, but you can purchase an MLA or APA style guide for use as reference, or you can visit many websites on the Internet that explain the guidelines of the MLA and APA in detail. One that I highly recommend is [The OWL](http://owl.english.purdue.edu/) (The Online Writing Laboratory) at Purdue University. You can also find help on documentation at many more sites. Here are just a few you may want to check out.

[Research and Documentation Online](http://www.dianahacker.com/resdoc/)

[EasyBib](http://www.easybib.com/reference/)

[BYU MLA/APA](http://abish.byui.edu/library/htw_MLaApa.cfm)

[The Style Wizard](http://www.stylewizard.com/)

[University of Massachusetts Library](http://www.umassd.edu/specialprograms/info_lit/cite.html)

[The University of California at Berkeley Library](http://http://www.lib.berkeley.edu/TeachingLib/Guides/Internet/Style.html)

**Ways to take notes: 3x5 cards, etc.**

When you are doing your investigative paper, you will almost certainly find a need to keep notes. This can be done in many ways. The simplest is to keep a notebook or journal of information and interviews that you may want to include in your paper. Another is to use note cards to organize your notes. You may also find that videotaping or use of a tape recorder can be handy tools that allow you to ask questions at any time and then transcribe the notes later. Just remember that note-taking should be performed as the investigative process is taking place. It is easy to forget or lose track of information if it is not recorded in a timely and organized fashion.

## Thesis/Topic Sentence[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-14)]

A thesis statement is a statement that expresses the main idea of your paper. It is usually one sentence, but it can be longer if necessary. Think of a thesis statement as a topic sentence for your entire paper.

### Form and place[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-15)]

A good thesis statement needs to establish a purpose (to analyze, to explain, to persuade, etc.) and state as clearly as possible the terms of your argument. Everything in your paper should serve to support your thesis statement.

A thesis statement is usually the last sentence of the first paragraph of a paper. However, a thesis can appear anywhere in your paper: it can be the first sentence, the very last sentence, or anywhere in between. It is uncommon in academic writing, however, to find a thesis beyond the first page of a paper. Nonetheless, some writers feel that the thesis should be presented later in the paper (such as at the end of a persuasive argument that builds up to a sort of grand finale). Still, unless you have an extremely good reason for withholding the thesis, it is a good idea to present it as soon as possible to the reader, so they understand exactly what it is you are trying to say about your topic. It is also customary to restate the main idea of your paper in the conclusion, so that your paper leaves a clear impression on the reader.

### General v. specific[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-16)]

Naturally, you want your thesis to be very specific in the sense that it exactly states your main idea. However, how specific or general you make that idea can be very important to the outcome of the paper. A thesis that is too broad will not provide enough direction, and a thesis that is to narrow may keep you from discussing some key issues related to the topic.

  
Example A: Television has had a negative impact on American society.

Example B: Violent television has caused some teenagers to change the way they perceive violence in real life.

Example C: South Park has influenced some teenagers to commit violent acts.

Unless you are planning on writing a book, Example A simply covers too much territory. Example B is probably ideal for a longer research paper. Example C, on the other hand, might be too restrictive if you were aiming to write a longer paper because it only allows you to discuss one negative effect of one specific television program, but just right for a short essay. Essentially, there is no such thing as "too general" or "too specific." It is simply a matter of matching the thesis to the ideal length.

If the scope changes or your focus shifts (or even if you change your mind completely) while you are researching or writing, it is fine to change your thesis statement so it better reflects what you want to say about the topic, but you must be sure that all the information in the final draft supports the new thesis.

### Examples from various disciplines[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-17)]

It is probably worth noting that the above examples are probably a bit too simple to be reppresentative of actual thesis statements, but the following are examples of reasonable thesis statements one might use to address a wide variety of topics and for a variety of purposes:

1\. Math/Natural Science (to explain): Although Fibonacci sequences are most often applied to mathematical contexts, the sequences play an interesting role in nature as well.

2\. Art (to explain): Pablo Picasso's innovative approach to art led to a new movement, not only in art, but in music and literature as well.

3\. Psychology/Criminal Justice (to persuade): It is unethical to sentence serial killers to the death penalty because they are essentially mentally ill.

4\. Literature (to analyze): A different aspect of the American dream motivates each of the main characters in John Stienbeck's _Of Mice and Men_.

5\. Agriculture (to persuade): The USDA's current procedure for detecting mad cow disease in cattle earmarked for human consumption is grossly inadequate.

6\. Astronomy (to analyze): There are valid arguments on both side of the controversy regarding the recent reclassification of Pluto.

7\. Business (to explain): The quantity theory of money emphasizes the positive relationship of overall prices with the quantity of money.

## Form[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-18)]

### Introduction[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-19)]

The introduction is important because it sets the tone for the rest of the piece and gives the reader an idea about where your writing is going and what points you will make along the way. In short, your introduction is your time to ease your readers into your topic and let them know what it is you are going to tell them about it. The introduction is also important because you will give the reader your thesis, the sentence on which your entire paper will be based.

  


#### Thesis[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-20)]

A thesis, in its most basic form, is the topic sentence of the entire paper. It serves as the compass for what is to come within a given work. You will need a specific thesis statement because you are setting up the argument that will be supported within your paper.

#### Good and bad beginnings[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-21)]

It takes time to develop a thesis, but the thesis should be well-developed (if not completely developed) before you begin writing your paper. A fully developed thesis can help you maintain a sense of direction within your paper. It will help you to develop your main topic and remind you which points you are going to use to support the argument you are making.

A thesis by a beginning writer will usually contain a general statement such as: In Greek mythology Zeus was portrayed as a god with many human qualities.

While this is a very good topic statement which lets the reader know that you are going to be discussing, the fact that Zeus possesses “human characteristics,” it does not provide a sense of the specific direction that will guide the entire paper.

In order to give your paper more direction and the reader more of an idea of what types of “human qualities” might be discussed, you should expand your thesis into something more specific, like: In Greek mythology Zeus was portrayed as a god, however he had many human qualities such as: his creation from parents, his lust for women, his displays of anger, an ego which he did not like to have bruised, the ability to show compassion, and on occasion he was known to be disloyal.

The second thesis is more clear, indicating to the reader that Zeus was a god who had many human qualities, and that the paper will be discussing at least six of those qualities. By actually listing the human qualities of Zeus, the writer has set up an expectation for the argument which is to follow and indicated the basic organization for their paper in an easy to follow manner to which the reader can now refer.

### Body/middle[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-22)]

The body of your paper is where you will get to support the argument that you made in your thesis, and it is the largest and most laborious part of the paper. In the body of your paper you will support your thesis by stating the main points and then supporting them with the factual evidence which you have found. Each of your main points should be clear to the reader and support your thesis argument. Your supporting evidence should also be clear and used with the correct main point in order to form a cohesive and organized essay body.

#### Main points[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-23)]

The main points of your argument will be contained in the body of your paper. There can be as few as two main points or as many as are needed to complete the argument depending on complexity of the subject, word or page limits, and the thesis itself. The main points serve as a more specific overview of the ways in which you will begin to support your thesis claim. They act as a further filter for your evidence and will keep your paper organized and comprehensive.

In the thesis statement above you already have your main points organized and set up for the reader within the thesis. You points are:

1) Zeus had parents, he did not always exist

2) Zeus is lusty and often pursues women

3) Zeus gets angry and exhibits his anger through behavior

4) Zeus has an ego

5) Zeus has the ability to show compassion

6) Zeus can be disloyal

Your job now is to discuss each of your points in more detail and use contextual evidence to support the main points.

#### Supporting evidence[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-24)]

Supporting evidence is the key to successfully making the argument set forth in your thesis. You will need to use several different sources within your supporting evidence to keep the paper from being too monotonous. Having several different sources as supporting evidence for any given point assures the reader that there are others out there who are researching the same topic as you and finding similar conclusions.

Supporting evidence can be found in a number of sources and arranged in just as many ways. For any given main point you might find a quote from a researcher, some statistics, or textual evidence which you can use as supporting evidence for your main point.

For example in the main points above you might look at some of the Greek myths and use specific incidents within a myth to support your claim that Zeus had parents. In fact, you could site an entire story as your evidence, however DO NOT place the story in your paper. Simply state briefly the idea of the story and in what book you found it, you do not need to completely retell the reader about the birth of Zeus. The fact that there is an entire myth based on his birth should be proof enough.

You will also need to find some quotes from authors who have credibility (see credibility section) and who have researched on the same subject which you are arguing. For example, in main point number 4 of the Zeus argument you will want to find quotes from psychologists or possibly myth scholars who are familiar with the idea of an ego. A quote from Sigmund Freud or supporting evidence of his studies of the id, ego, and superego, will serve as a basis for the idea that an ego is a human quality. Freud can offer some context within your argument, then you can use texts from myths to provide some further evidence of Zeus’ ego.

#### Other side of the argument and your argument against it[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-25)]

Within your argument you want to, at some point, acknowledge that there is another side to your subject. You are only arguing one side of the thesis, however there is always another way to approach the subject which you are arguing. A good writer will acknowledge the other side (or sides) of the argument and then dismiss them with his or her evidence. It is hard to do within a paper that is so strongly placed in the argument of just one side of a subject, but when acknowledgement and dismissal are executed correctly they will actually enhance the argument of the writer.

For example, if you are giving supporting evidence for the main point number 6 in the Zeus argument, you might want to acknowledge that some scholars (if in fact, you have found it to be true in your research) contend that Zeus’ “disloyalty” is not a function of his humanness, but rather a function of the way people might feel about his actions, you will want to refute that statement in your argument.

Simply acknowledge that someone has said this (give them proper credit) and then show another scholar who has argued against it. Your argument should look something like this: Professor Z of Such and Such University has written an article titled “Loyal Zeus” in which he argues that Zeus was not disloyal, but humans see his actions as disloyal, however Dr. X, argues that Zeus is in fact disloyal because….”

Thus you have successfully acknowledged and dismissed a counterpoint of your argument. However, do not try to counter all arguments against your thesis, because it will prove to be exhausting, non productive, and can possibly confuse readers as to which side you are actually arguing.

### Conclusion[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-26)]

The conclusion of your paper is what ties everything together. You want the reader to see what it is you set out to do, how you proved it and what it all means to them. The reader should know, at this point, where you stand on your argument and should be winding down from reading your paper. You can let your reader know that you are ready to end the paper by using some of the following words as signposts for your conclusion: 1) In retrospect 2) In conclusion 3) As can be seen

You are letting your reader know that the end of the paper is near and that you are about to give them a quick overview of what they have just finished reading to remind them of what it is you want them to take away form the paper.

  


#### Restating of the thesis[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-27)]

In your conclusion you want to restate your thesis in order to remind the reader of what it is you were arguing. You can restate your thesis exactly as it is in the introduction of you may choose to alter it slightly. In any case, do not alter it so much that it becomes unrecognizable as the thesis of your paper, or the reader may lose sight of what is was that you set out to argue to begin with.

#### Summarizing[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-28)]

After you have restated your thesis you will summarize your main points briefly in order to remind your reader of the basic outline of your argument. You do not need to go into supporting evidence in your conclusion because you will have thoroughly explained it already within the body of the paper. The summarization of your paper will mentally guide the reader back through your argument so they may begin to think about their own ideas on the subject and form a conclusion of their own.

#### Example Assignment[[edit](/w/index.php?title=Basic_Writing/Investigative_writing&action=edit&section=T-29)]

Genealogy Project

You choose a family member or family event that you want to write about and learn more about the person or situation. You interview at least three of your family members about the person or event you chose. You should also try to collect any mementos or documents about your subject as additional sources. Then you report your findings into a paper in third person narrative.

The following is a similar essay on family history which won the 2005 "My Turn" contest sponsored by Newsweek Education Program: ["Family Tree"](http://www.newsweekeducation.com/myturn2005/sung.php) by By Nami Sung of Stuyvesant High School in New York, New York.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Basic_Writing/Print_version&oldid=1273791](http://en.wikibooks.org/w/index.php?title=Basic_Writing/Print_version&oldid=1273791)" 

[Category](/wiki/Special:Categories): 

  * [Basic Writing](/wiki/Category:Basic_Writing)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Basic+Writing%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Basic+Writing%2FPrint+version)

### Namespaces

  * [Book](/wiki/Basic_Writing/Print_version)
  * [Discussion](/w/index.php?title=Talk:Basic_Writing/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Basic_Writing/Print_version)
  * [Edit](/w/index.php?title=Basic_Writing/Print_version&action=edit)
  * [View history](/w/index.php?title=Basic_Writing/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Basic_Writing/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Basic_Writing/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Basic_Writing/Print_version&oldid=1273791)
  * [Page information](/w/index.php?title=Basic_Writing/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Basic_Writing%2FPrint_version&id=1273791)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Basic+Writing%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Basic+Writing%2FPrint+version&oldid=1273791&writer=rl)
  * [Printable version](/w/index.php?title=Basic_Writing/Print_version&printable=yes)

  * This page was last modified on 9 September 2008, at 16:02.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Basic_Writing/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
