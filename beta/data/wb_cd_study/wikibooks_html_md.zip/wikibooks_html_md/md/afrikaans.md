# Afrikaans/Print version

From Wikibooks, open books for an open world

< [Afrikaans](/wiki/Afrikaans)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Afrikaans/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Afrikaans/Print_version) on _28 November 2010_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Afrikaans/Print_version&oldid=1796787&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


# 

# Afrikaans

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Afrikaans](/wiki/Afrikaans)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Afrikaans/Print_version&action=purge&printable=yes) this page.

# Main Contents

  * Introduction
  * Pronounciation
  * Lessons 
    * Lesson One: The Basics
    * Lesson Two: Descriptions
    * Lesson Three: Numbers
  * Appendix 
    * External Links
    * Newspapers in Afrikaans
  * Contributors
  * GFDL

* * *

# Introduction

_This page has 2 sentences and 6 words for you to learn_

## The youngest Germanic language

![Flag of South Africa.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/af/Flag_of_South_Africa.svg/100px-Flag_of_South_Africa.svg.png)

The name "Afrikaans" means literally "African". Afrikaans has its roots in 17th-century Dutch, but has since developed its own distinctive character and flavour in the three centuries that it developed mostly in South Africa and in parts of Namibia. Being a Germanic language, it is closely related to Dutch, English and to a lesser extent German. Compare the following:

  * English: _I eat an apple._
  * Afrikaans: _Ek eet 'n appel._
  * Dutch: _Ik eet een appel._
  * German: _Ich esse einen Apfel._

English has many more words of a Latin or French origin than Afrikaans, but a more archaic word can often show the similarities between the two languages.

  * English: _hound, fowl, house, milk_
  * Afrikaans: _hond, voël, huis, melk_

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/78/Afrikaansdistrib.png/150px-Afrikaansdistrib.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Provinces of South Africa where Afrikaans is in the majority. Note that Afrikaans is spoken all over the country and also in Namibia.

Most interestingly, consider these two sentences:

  * _My hand is in warm water._
  * _My pen is in my hand._

These two sentences can be either English or Afrikaans, and both have exactly the same meaning in both languages. But despite this, Afrikaans has significant differences from English. It might not be as easy to learn for an English speaker as, say, Esperanto, but it is still considered a relatively easy language to learn, and is advocated by some as a good introduction to learning Dutch and other Germanic languages in general.

## Can Afrikaans people and Dutch people understand each other?

Afrikaans and Dutch are very closely related and are more or less mutually understandable. More about that [here](/wiki/Dutch/Lesson_Afrikaans). Dutch's grammar is a bit more complex than Afrikaans', but they share a lot of the same vocabulary, albeit with slightly different spellings and pronunciations. Comparing Afrikaans and Dutch is somewhat like comparing Norwegian Bokmål and Danish.

It is a commonly held belief that Afrikaans people tend to understand Dutch quite well, and Dutch people generally need more time to understand Afrikaans. The truth of this claim may vary from individual to individual. Some Afrikaans people claim to understand written Dutch better than spoken Dutch.

## Language of the oppressor?

Afrikaans is seen by some in a negative light because it was the language promoted by the apartheid regime. Some even claim that it should be forgotten. We acknowledge the terrible atrocities of that regime but still regard Afrikaans language and culture as beautiful and worthy of preservation. The past is the past; it cannot be changed. The future is what really counts. Should German language and culture be done away with because it was once advocated by the Nazi party?

Besides, many speakers of the language (about half!) were not white and were victims of the regime's many manipulations, including ripping apart families and forcefully moving whole communities.

## Trivia

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/AfrikaanseTaalmonumentSlogan.jpg/220px-AfrikaanseTaalmonumentSlogan.jpg)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

The Afrikaans monument.

  * [Several English words](//en.wikipedia.org/wiki/List_of_English_words_of_Afrikaans_origin), such as "commando" and "aardvark", are of Afrikaans origin.
  * The Arabic script [has been used to write Afrikaans](//en.wikipedia.org/wiki/Arabic_Afrikaans).
  * Afrikaans is the only [Indo-European](//en.wikipedia.org/wiki/Indo-European) language to have developed in Africa.
  * Afrikaans is the most commonly used language among non-black South Africans.

_<<[Back to the main page](/wiki/Afrikaans)_

_On to [Pronunciation!>>](/wiki/Afrikaans/Pronunciation)_

* * *

# Pronunciation

![Afrikaans1.jpg](//upload.wikimedia.org/wikibooks/en/b/be/Afrikaans1.jpg)

Afrikaans uses the same alphabet as English. Notable differences include _diacritics_ on the letters (like ê), while certain letters, such as c, exist but are infrequently used.

You'll soon find Afrikaans has a very _phonetic_ (phonemic) spelling; that is, unlike in English, French or even its parent language Dutch, Afrikaans words are almost always spelled the way they sound.

This chart uses IPA - the international phonetic alphabet to show the exact Afrikaans pronunciation. You can read more about it [here](//en.wikipedia.org/wiki/IPA). The English words are only an approximate guide. Afrikaans pronunciation can be a bit tricky for English speakers because the language has quite a few sounds that don't exist in English. The best way to learn is to listen to native Afrikaans speakers. You can listen to streaming Afrikaans radio [here](http://www.rsg.co.za/) and hear Afrikaans sound recordings at [this site](http://www.openlanguages.net/afrikaans/).

**Letter** **IPA** **English Approximation** **Example Word**

a
ʌ, a, ɑː
pl**u**s, j**u**mp, **a**wesome
kap

aa
ɑː
**a**wesome
daad

aai
aːɪ
wh**y**
laai

ai
aɪ
th**ai**
baie

au
ou
g**oa**t
auditorium

b
b, p (final position)
**b**at, ma**p**p
bevat

ch
x
lo**ch**
chemie

c
s (before e, i, and y), k
**s**un, **k**ick
Celsius

d
d, t (final position)
**d**ark, ha**t**
daar

dj
c
no English approximation
djihad

e
ɛ, iˑǝ, ə, æ
b**e**d, **e**rie, **a**bout, c**a**t
bed

ê
ɛː (final position), æ
h**ai**r, c**a**t
hê

ee
iˑe
**eerie**
een

eeu
iːu
**ea**st + t**oo**k
leeu

ei
əi
pl**ay**
seil

ey
əi
pl**ay**
ceylon

eu
øː
f**ew**
euforie

f
f
**f**ox
familie

g
x, g, ç
lo**ch**, **g**olf, **h**ue
geld

gh
g, k (final position)
**g**olf, **k**ick
gholf

h
h
**h**igh
hoe

i
i, ə
s**ee**, **a**bout
idee

i.e.
i
s**ee**
dankie

j
j
**y**es
ja

k
k
**k**ick
kat

l
l
**l**et
lughawe

m
m
**m**all
maak

n
n, ŋ (before c, k, q, and x)
**n**ice, si**ng**
van

ng
ŋ
si**ng**
vang

ns
the n is silent, and the previous vowel is nasalized
no English approximation
Afrikaans

o
ɔ, oˑǝ
b**o**g, w**i**sdom
obligasie

ô
ɔ
c**au**se
môre

oe
u
l**oo**t
voet

oei
uiː
ph**ooey**
koei

oi
oj
r**ow** \+ **y**es
boikot

oo
uˑo
l**oo**t
soom

ooi
ɔiː
**oi**l
strooi

ou
ɔʊ
t**ow**
mou

p
p
ma**p**
paar

r
ɾ
ve**r**y
rooi

s
s
**s**un
sein

sj
ʃ
**sh**in
sjoe

t
t
**t**op
taal

tj
tʃ (initial position), kj
**t**op + **sh**in, **k**ick + **y**es
tjek

u
ɵ
**u**rn
uit

uu
y
br**ee**d
duur

û
œː
no English approximation
brûe

ui
œy
pl**ay**
lui

uy
œy
**u**rn + **ea**st
ly

v
f
**f**ox
voël

w
v, w (after consonant)
**v**isit, **w**inter
water

y
əi
pl**ay**
ys

z
z
**z**ulu
zirkonium

  
_<<[Back to Introduction](/wiki/Afrikaans/Introduction)_

_[On to Lesson One!>>](/wiki/Afrikaans/Lesson01)_

* * *

# Lesson One

_This page has 34 words and 3 sentences that you can learn_  
**Afrikaans Les Een: The Basics**

![Flag of South Africa.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/af/Flag_of_South_Africa.svg/100px-Flag_of_South_Africa.svg.png)

## Vocabulary

These vocabulary words can be found through this lesson, in the examples, in the dialogues, and to assist you in doing the exercises. Anytime there is a word you don't know in the lesson, refer to this comprehensive list.

**English** **Afrikaans**

and
en

be
wees (present tense: is)

eat
eet

food
kos

good afternoon
goeiemiddag

goodbye
totsiens

good evening
goeienaand

good morning
goeiemôre

goodnight
goeienag

hello
hallo/goeiedag

hi
haai

How are you?
Hoe gaan dit (met jou/U/julle)?

I'm fine
Ek is goed/ Dit gaan goed met my

My name is...
My naam is.../ Ek is...

see
sien

sleep
slaap

thanks
dankie

  
==**Vocabulary similarities between English and Afrikaans** **==**

One can take just a few simple transformations to your English vocabulary and then acquire an Afrikaans vocabulary easily. Afrikaans is a part of the Indo-European language group thus its shares a lot of history that in language development as the its European counterparts. Take for example that all words in English ending in **-tion** you can replace with **-sie** to have the Afrikaans equivalent of the word. So the English words _position, action, condition,_ etc. will be _posisie, aksie, kondisie_ etc. And then with minor changes to the spelling such as replacing the c with k, because in Afrikaans the c changes to a k-sound. These are only a few of the "language tricks" that you can use to trans from your English into Afrikaans and gain a few nouns to your vocabulary.

## Dialogue

Each lesson's dialogue will provide a conversation with features that will be discussed in the lesson, so that by the time you finish the lesson you should be able to understand without looking at the translation why the conversation is structured the way it is.

Valerie
Goeiemôre!

Johan
Hallo! Hoe gaan dit met u?

Valerie
Dit gaan goed dankie. My naam is Valerie, en u?

Johan
My naam is Johan.

Valerie
Totsiens, Johan!

### Translation

Valerie
Good morning!

Johan
Hello! How are you?

Valerie
I'm fine, thanks. I'm Valerie, and you?

Johan
My name is Johan.

Valerie
Goodbye, Johan!

## Greetings

Afrikaans greetings are used in the same way as English ones are. What this means is that when speaking informally, you will usually greet someone with a **haai** rather than saying **hallo** or **goeiedag** to them. It is important to know that goeienaand is how you greet someone in the evening while **goeienag** is something you say when you're leaving someone at nighttime. Finally, the informal way to ask how someone it is **Hoe gaan dit** with the addition of **met jou** at the end being optional. If you are in a formal situation, or speaking to more than one person, you will add **met u** (formal) or **met julle** (plural). The pronoun section will clarify when to use jou/u/julle, which all translate into English as you.

## Pronouns

### Subject Pronouns

The subject of a sentence corresponds to who is doing the action (**She** loves him).

**English** **Afrikaans**

I
ek

you (singular, familiar)
jy

you (singular/plural/polite)
u

he
hy

she
sy

it
dit

we
ons

you (plural)
julle

they
hulle

### Object Pronouns

The object of a sentence is who the action is directed towards (She loves **him**, I gave **it** to **her**).

**English** **Afrikaans**

me
my

you (singular, familiar)
jou

you (singular/plural/polite)
u

him
hom

her
haar

it
dit

us
ons

you (plural)
julle

them
hulle

The most obvious difference is the three forms of "you". **Jy** is most like the English "you", and is used more generally and when addressing a friend. **U** is the formal or polite version of "you", and is used when addressing an elder, your boss, a stranger or anyone whom you wish to show respect. Note that it is capitalized when referring to the Christian God. **Julle** is used when addressing more than one person.

## Word Order

In Afrikaans, simple, present tense sentences are in SVO word order. English is an SVO language too. SVO stands for subject-verb-object. This means who does the verb comes first, then the verb comes next, and lastly, if the verb is directed towards something or someone it comes last. For example, in the sentence "I eat fruit" "I" is the person doing the action so it is first. "Eating" is what I'm doing so it comes second, and the eating is done to the fruit, so it's the object. So "I'm eating food" in Afrikaans is therefore "Ek eet kos".

### Verb "To Be"

The infinitive is the form of a verb when it has no subject. In English this is to+verb, or just the verb. In Afrikaans the infinitive is the "regular" form you'll find in the dictionary, but even easier than English, the present tense and the infinitive are the same so the only difference between them is one has a subject and one doesn't. What this means is that while in many languages the verb changes forms when talking about different people ("I love-->She love**s**"), in Afrikaans we depend on the subject. There are two big exceptions to this, and we're going to learn the first one in this lesson. "To be" in Afrikaans is "wees" (infinitive form). The present form of "wees" is "is"—similar to English.

Another important thing to know is that the Afrikaans present can be both regular present and the present continuous ("Sally eet" can mean either "Sally eats" or "Sally is eating").

## Exercises

Translate these sentences into English.

  * Jy is Johan.
  * Hoe gaan dit?
  * Valerie slaap.
  * Goeienag!
  * Ek sien hulle.
  * Sy is goed.
  * Ek eet kos.

Translate these sentences into Afrikaans.

  * I am Sally.
  * My name is Johan.
  * You (plural) eat it.
  * We are sleeping.
  * Hi!
  * You (formal) see him.

### Exercise Answers

Answers to the above exercises.

  * You (singular) are Johan.
  * How are you? (informal)
  * Valerie sleeps/is sleeping.
  * Goodnight
  * I see them.
  * She's fine.
  * I eat food.

  


  * Ek is Sally.
  * My naam is Johan.
  * Julle eet dit.
  * Ons slaap.
  * Hallo!
  * U sien hom.

_<<[Back to Pronunciation](/wiki/Afrikaans/Pronunciation)_

_[On to Lesson Two!>>](/wiki/Afrikaans/Lesson02)_

* * *

# Lesson Two

**Afrikaans Les Twee: Descriptions**

## Definite and Indefinite Articles

### Gender

Many languages will give words grammatical gender, but this is not the case for Afrikaans, just like English, there is no gender and thus nouns have no classification.

### The

In English we use the word "the" to point out a specific thing. If someone says, "I ate all of the cake", they aren't referring to any cake, it's a specific one. Afrikaans has the same thing. In Afrikaans this word is "die", and just like in English, it can be used for the singular and the plural.

English: the dogs, the tree, the walls

Afrikaans: die honde, die boom, die mure.

### A/An

The Afrikaans word for "a" or "an" is "'n". This is called the indefinite article because it means one thing, but it cannot refer to a specific thing such as in the sentence "I ate a cake". This could be any cake. 'n Is **always** written with an apostrophe (') and is **never** capitalized, even if it starts a sentence. If it starts a sentence, then the first letter of the following word gets capitalized.

## Forming Questions

There are two main ways of forming question words: by starting out with a question word (What language are you learning?) or by turning a statement into a question (You are learning Afrikaans becomes Are you learning Afrikaans?).

### _Question Words_

English Afrikaans

what
wat

who
wie

whose
wie se

why
hoekom / waarom

where
waar

when
wanneer

which
watter

how
hoe

how much/many
hoeveel

When making simple sentences, these questions will have question word-verb-object word order.

  * English: Who is the president of South Africa?
  * Afrikaans: Wie is die president van Suid-Afrika?
  * English: Where do you live?
  * Afrikaans: Waar woon jy?

### _Questions Beginning with Verbs_

Often we ask questions that don't start with question words, but with verbs. Afrikaans does this too. The difference in word order: in English we say "Do you write letters?" but in Afrikaans it would read "Write you letters?". The verb comes first, followed by the subject, than the object. It is important to remember however that word order will change when we add more complex elements.

  * English: Do you smoke cigars?
  * Afrikaans: Rook julle sigare?

### _Adjectives_

When adjectives are used with the verb wees ("She is sick", "He is blonde") you can use the form of the adjective you'll find in the dictionary. However, when an adjective is directly modifying a noun (as in "She is a sick girl", "He has blonde hair") their form usually alter somewhat. This change is called inflection. As a general rule, polysyllabic adjectives are normally inflected; monosyllabic adjectives may or may not be inflected though, depending mostly on a set of rather complex phonological rules. When an adjective is inflected, it usually takes the ending -e and a series of morphological changes may result. For example, the final t following an /x/ sound, which disappears in uninflected adjectives like reg, is restored when the adjective is inflected (regte). A similar phenomenon applies to the addition of t after /s/. For example, the adjective vas becomes vaste when inflected. Conversely, adjectives ending in -d (pronounced /t/) or -g (pronounced /x/) following a long vowel or diphthong, lose the -d and -g when inflected.

Adjectives come before nouns, like in English.

English Afrikaans

Uninflected Inflected

black
swart
swarte

fast
vinnig
vinnige

deaf
doof
dowe

cold
koud
koue

low
laag
lae

high
hoog
hoë

Adjectives ending in a 'g' — add a 'te'

bad
sleg
slegte

Adjectives ending in 'f' — change it to two 'w's

stupid
laf
lawwe

Irregulars

good
goed
goeie

old
oud
ou, oue

new
nuut
nuwe

### _Possessive Pronouns_

  * "mine" - "myne"
  * "yours" (singular)- "jou" or "u" (joune?)
  * "his" - "sy"
  * "her" - "haar"
  * "our" - "ons" (onse?)
  * "yours" (plural) - "julle"
  * "their" - "hulle"

  


  


_<<[Back to Lesson One](/wiki/Afrikaans/Lesson01)_

_[On to Lesson Three!>>](/wiki/Afrikaans/Lesson03)_

* * *

# Lesson Three

**Afrikaans Les Drie: Nommers**  


Number Afrikaans English

0
Nul
Zero

1
Een
One

2
Twee
Two

3
Drie
Three

4
Vier
Four

5
Vyf
Five

6
Ses
Six

7
Sewe
Seven

8
Agt
Eight

9
Nege
Nine

10
Tien
Ten

11
Elf
Eleven

12
Twaalf
Twelve

13
Dertien
Thirteen

14
Veertien
Fourteen

15
Vyftien
Fifteen

16
Sestien
Sixteen

17
Sewentien
Seventeen

18
Agtien
Eighteen

19
Negentien
Nineteen

20
Twintig
Twenty

With this knowledge, you can count up to twenty.

30
Dertig
Thirty

40
Veertig
Forty

50
Vyftig
Fifty

60
Sestig
Sixty

70
Sewentig
Seventy

80
Tagtig
Eighty

90
Negentig
Ninety

To find other numbers, the format is _<ONES> en <TENS>_. Replace _<ONES>_ with a number between one and nine. Replace _<TENS>_ with twintig, dertig, veertig, vyftig, sestig, sewentig, tagtig, or negentig. For example, _een en twintig_ translates to _twenty one_. Now you can count up to ninety nine!

* * *

_<<[Back to Lesson Two](/wiki/Afrikaans/Lesson02)_

_[On to Lesson Four!>>](/wiki/Afrikaans/Lesson04)_

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Afrikaans/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

* * *

# External Links

[Afrikaans/External Links](/w/index.php?title=Afrikaans/External_Links&action=edit&redlink=1)

* * *

# Newspapers

Here is a list of newspapers in South Africa and Namibia.

## ![Flag of South Africa.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/af/Flag_of_South_Africa.svg/25px-Flag_of_South_Africa.svg.png) Suid-Afrikaanse koerante (Afrikaans), South African newspapers

  * <http://www.news24.com/Beeld/Home/> \- Beeld
  * <http://www.dieburger.com/> \- Die Burger
  * <http://www.news24.com/Die_Volksblad/Home/0,8521,5,00.html> \- Volksblad
  * <http://www.news24.com/Rapport/Home/0,7719,752,00.html> \- Rapport
  * <http://www.dieson.co.za/> \- Die son

## ![Flag of Namibia.svg](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Flag_of_Namibia.svg/25px-Flag_of_Namibia.svg.png) Namibiese koerante (Afrikaans), Namibian newspapers

  * <http://www.republikein.com.na/> -Republikein

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A reader has identified this page or section as an undeveloped draft or outline.**  
You can help to [develop the work](//en.wikibooks.org/w/index.php?title=Afrikaans/Print_version&action=edit), or you can ask for assistance in the [project room](/wiki/Wikibooks:PROJECTS).

* * *

# Contributors

The Afrikaans Language textbook was first started on [June 12](//en.wikipedia.org/wiki/June_12), [2005](//en.wikipedia.org/wiki/2005). Add yourself to the list below if you feel you've made a significant contribution to this textbook.

  * [Icelandic Hurricane](/wiki/User:Icelandic_Hurricane) ([discuss](/wiki/User_talk:Icelandic_Hurricane) **·** [email](/wiki/Special:EmailUser/Icelandic_Hurricane) **·** [contribs](/wiki/Special:Contributions/Icelandic_Hurricane) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Icelandic+Hurricane) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Icelandic+Hurricane&lang=en&wiki=wikibooks))
  * [Rakuten06](/wiki/User:Rakuten06) ([discuss](/wiki/User_talk:Rakuten06) **·** [email](/wiki/Special:EmailUser/Rakuten06) **·** [contribs](/wiki/Special:Contributions/Rakuten06) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Rakuten06) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Rakuten06&lang=en&wiki=wikibooks))
  * [Delano](/wiki/User:Delano) ([discuss](/wiki/User_talk:Delano) **·** [email](/wiki/Special:EmailUser/Delano) **·** [contribs](/wiki/Special:Contributions/Delano) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Delano) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Delano&lang=en&wiki=wikibooks))
  * [Solstici](/wiki/User:Solstici) ([discuss](/wiki/User_talk:Solstici) **·** [email](/wiki/Special:EmailUser/Solstici) **·** [contribs](/wiki/Special:Contributions/Solstici) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Solstici) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Solstici&lang=en&wiki=wikibooks))
  * [ThePCKid](/w/index.php?title=User:ThePCKid&action=edit&redlink=1) ([discuss](/wiki/User_talk:ThePCKid) **·** [email](/wiki/Special:EmailUser/ThePCKid) **·** [contribs](/wiki/Special:Contributions/ThePCKid) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=ThePCKid) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=ThePCKid&lang=en&wiki=wikibooks))

  


* * *

# GNU FREE DOCUMENTATION LICENSE

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Afrikaans/Print_version&oldid=1796787](http://en.wikibooks.org/w/index.php?title=Afrikaans/Print_version&oldid=1796787)" 

[Category](/wiki/Special:Categories): 

  * [Afrikaans](/wiki/Category:Afrikaans)

Hidden category: 

  * [Stubs](/wiki/Category:Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Afrikaans%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Afrikaans%2FPrint+version)

### Namespaces

  * [Book](/wiki/Afrikaans/Print_version)
  * [Discussion](/wiki/Talk:Afrikaans/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Afrikaans/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Afrikaans/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Afrikaans/Print_version&action=edit)
  * [View history](/w/index.php?title=Afrikaans/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Afrikaans/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Afrikaans/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Afrikaans/Print_version&oldid=1796787)
  * [Page information](/w/index.php?title=Afrikaans/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Afrikaans%2FPrint_version&id=1796787)

### In other languages

  * [Español](//es.wikibooks.org/wiki/Afrik%C3%A1ans/Introducci%C3%B3n)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Afrikaans%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Afrikaans%2FPrint+version&oldid=1796787&writer=rl)
  * [Printable version](/w/index.php?title=Afrikaans/Print_version&printable=yes)

  * This page was last modified on 16 May 2010, at 13:43.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Afrikaans/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
