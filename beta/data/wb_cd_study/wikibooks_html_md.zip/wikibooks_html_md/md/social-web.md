# Social Web/Print version

From Wikibooks, open books for an open world

< [Social Web](/wiki/Social_Web)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Social_Web/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Social_Web/Print_version) on _17 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Social_Web/Print_version&oldid=2502705&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Social_Web](/wiki/Social_Web)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Social_Web/Print_version&action=purge&printable=yes) this page.

  


* * *

  


# Preface

This book/class is supposed to give a hands-on experience related to the social web. Different aspects will be looked at, new forms of teaching (maybe not new to others, but new to me) will be tested and students participation is essential. Most likely this book will be outdated as soon as it is finished, but for a little while it may serve as an entrance to the world of the social web.

The idea behind this class project came from a colleague who suggested that most class projects produce really nice results, but usually disappear in some instructors' drawers. After reading on the possibility of using Wikibooks for class projects, we just had to give it a try.

  


## Getting Started

If you are new to Wikibooks, you might first want to look at [Using Wikibooks](/wiki/Using_Wikibooks). Details for creating a class project can be found at [Class_Project_Guidelines](/wiki/Using_Wikibooks/Class_Project_Guidelines). If you are completely new to Wikipedia, the [Wikipedia tutorial](http://de.wikipedia.org/wiki/Wikipedia:Tutorial) maybe helpful to you. If you like to upload images to wikipedia, use the [File Upload Wizard](http://en.wikipedia.org/wiki/Wikipedia:File_Upload_Wizard). However, only upload images if you created them and you own the copyright!

  


## Other Wikibooks

There are also other wikibooks on subjects related that are quite useful:

  * [Computers_&_Society](/wiki/Computers_%26_Society)
  * [Social_Media](/wiki/Social_Media)
  * [Introduction_to_Sociology](/wiki/Introduction_to_Sociology)

Not related to the subject, but helping me to get the editing right:

  * [Game_Creation_with_XNA](/wiki/Game_Creation_with_XNA)

  


## Other Class Projects

Inspiration from successful class projects can be drawn here, which by themselves are also quite interesting and maybe helpful for this project:

  * [Basic Writing](/wiki/Basic_Writing)
  * [Handbook for Doctoral Students in Education](/wiki/Handbook_for_Doctoral_Students_in_Education)

  


## Experience from the First Iteration

The first iteration of this course just finished this July 2012. From my perspective it was definitely a success. From the students perspective, it seems a bit mixed, when looking at the evaluations given [online](http://www.meinprof.de/uni/kurs/110750). For me, most interesting were the blogs, also called 'learning journals'. They all started of a little weak, but after three or four weeks, some turned into real gems, full of wit, information and compassion. Important here was, I think, that students had to comment on blogs of their colleagues. [Twitter](http://www.twitter.com/SocialWebOhm) was totally useless, but this is more of my fault then that of Twitter, same for Moodle. [Facebook](http://www.facebook.com/SocialWebClass) also turned out to be quite useful, but much less than what I hoped for. As for [YouTube](http://www.youtube.com/socialwebclass), I guess there was just a handful of students watching the videos, and considering the effort that goes into producing them, it is not worth while. From my part most disappointing was the [Wikibook](http://en.wikibooks.org/wiki/Social_Web): Since I had positive experience with a wikibook previously ([Game_Creation_with_XNA](/wiki/Game_Creation_with_XNA)), I was really looking forward to it. Instead, I found some passages just copied and pasted, poor referencing, and overall a rather minimalistic effort. Although in some cases I was very pleasently surprised. But, as mentioned before, the blogs more than made up for it. In the fall there will be second iteration, with a very different group of students (distance learners), let's see how this turns out.

  


  


# Introduction

This class will be a tour of the Social Web. It will cover many topics, mostly just touching the surface. But there will be plenty of opportunity to digg deeper and learn more by doing.

  


## Idea behind this Class

There are two reasons for this class:

  * learn about the social web, social media and social networks
  * find out about new ways of teaching and learning

For me the second aspect is actually the more important one. The first time I noticed that something is different with todays students, was when we had a problem in one of our labs, and some of the students used YouTube instead of Google to find the solution.

### Activity:

To see that not only I thought something is different, watch the following two videos:

  1. Pay Attention ([http://teachertube.com/viewVideo.php?video_id=448&title=Pay_Attention](http://teachertube.com/viewVideo.php?video_id=448&title=Pay_Attention))
  2. A Vision of Students Today (<http://www.youtube.com/watch?v=dGCJ46vyR9o>)

Actually, the website ’Digital Ethnography’ has quite a few interesting videos.

What does this mean for us?

  


## Social Web is Big

A very nice way to visualize the social web is the ’Social Media Prisma’ (based on The Conversation Prism):

image here

Social Media Prisma, (<http://www.ethority.de/weblog/social-media-prisma/>)

  


## Social Web changes quickly

Compare the popularity of the sites MySpace, studiVZ, Facebook, Google and Twitter over time, for example by using Google Trends. Especially when looking at MySpace and studiVZ you notice the short half-life of social web sites: image here myspace studivz facebook google twitter

The same is true for a class on the Social Web. As soon as I would have finished preparing the class, it would be outdated.

So instead, this class will be mostly based on student participation, interaction, living, researching and documenting the social web. We use the social web to learn about the social web.

  


## Definition of Terms

### Activity:

What do you think of, when you hear the word ’Social Web’?

  


## Definition of Terms

The Wikipedia defines it as

    "The Social Web is a set of social relations that link people through the World Wide Web." [1]

It has to be distinguished from what is called the Web 2.0 [2], a phrase termed by Tim O’Reilly [3]. Whereas Web 2.0 is about technology, the social web is about people.

So for instance, the map of the internet, maps machines: <http://en.wikiversity.org/wiki/File:Internet_map_1024.jpg>

Whereas, a maps of friends on facebook (a social network) maps people: <http://en.wikipedia.org/wiki/File:Kencf0618FacebookNetwork.jpg>

### Activity:

Consider the following web sites. Which one is Web 2.0 and which one is Social Web?

    Facebook, Google Maps, eBay, Amazon, Google Search, Flickr, Yahoo Mail, OpenStreetMap, Prezi, YouTube, iGoogle

## On the Structure of this Class

In the beginning I will guide you, tell you the little I know, and point you to resources that will help you further. In case you have not been using much of the social web (maybe with the exception of Facebook), I will get you started.

You will start writing a personal learning journal (Blog), detailing your learning progress during the semester. You will comment on the blogs of other students. You will work in groups, research and write a chapter in a wikibook (<http://en.wikibooks.org/wiki/Social_Web>). You will read and review books, and you will give a presentation.

You will become a responsible net citizens: not only consuming content, but also creating content. Don’t ask what the net can do for you, but ask what can you do for the net. What can you contribute to your country, society, culture, the net? The social web is about sharing.

  


## Assignments

### Ex.1: Google Trends

Use Google Trends to see how the popularity of the keywords ’MySpace, studiVZ, Facebook, Google’ has changed over the years. Restrict your search to Germany.

Do the same for ’apple, microsoft, ibm’. How could this tool be useful to you or your company?

### Ex.2: Web 2.0 vs Social Web

List all the websites you have been using in the last 2 weeks. Try to determine which one’s are Web 2.0 type sites, and which one’s are Social Web sites. On which did you spend more time?

Read the Wikipedia articles on Web 2.0 [2] and on the Social Web [1].

Interesting may also be the talks by Randy Komisar, ’Beyond the Social Web’ (ecorner.stanford.edu/authorMaterialInfo.html?mid=2424) only 3 minutes.

### Ex.3: Rethinking Education

Watch the video Rethinking Education (<http://www.youtube.com/watch?v=5Xb5spS8pmE>). In your blog (next chapter) write what you think about this video.

  


  


# Blogs, Microblogs and Podcasts

In this class we will heavily use blogs and microblogs. They are a big help in documenting and in communicating. We may also record the lectures and post them on YouTube.

  


## Blogs

In previous centuries, people wrote personal, private diaries. In our day and age this has become the public blog. The Wikipedia says that

    "A blog (web log) is a personal journal published on the World Wide Web consisting of discrete entries ("posts") typically displayed in reverse chronological order so the most recent post appears first." [4]

The spectrum of blogs is very wide, ranging from personal blogs, corporate blogs and journalism blogs (’citizen journalism’ [5]). In the exercises you will learn how to write your own blog in case you haven’t started one already.

  


### The History of Blogging

While the term "blog" was not coined until the late 1990s, the history of blogging starts with several digital precursors to it.

#### 1983–1993

At this time Usenet was the primary serial medium included in the original definition of the Internet. It featured moderated newsgroup which allowed all posting in a newsgroup to be under the control of an individual or small group. In the early 1990s, when Tim Berners-Lee coined the term "world wide web" and defined the first standards for HTML and URLs, the specifications although included "USENET newsgroups for serial publishing and discussions."

#### 1994–2001

The modern blog itself evolved from the online diary, where people would keep a running account of their personal lives. The first weblogs were simply manually updated components of common websites. However, the evolution of tools to facilitate the production and maintenance of web articles posted in reverse chronological order made the publishing process feasible to a much larger, less technical, population. Ultimately, this resulted in the distinct class of online publishing that produces blogs we recognize today. For instance, the use of some sort of browser-based software is now a typical aspect of "blogging". Blogs can be hosted by dedicated blog hosting services, or they can be run usingblog software, such as WordPress, Movable Type, Blogger or LiveJournal, or on regular web hosting services.

The term "weblog" was first-used by Jorn Barger on 17 December 1997. The (“more popular”) short form, "blog," was coined by Peter Merholz, who jokingly broke the word weblog into the phrase we blog in the sidebar of his blog Peterme.com in April or May 1999. Shortly thereafter, Evan Williams atPyra Labs used "blog" as both a noun and verb ("to blog," meaning "to edit one's weblog or to post to one's weblog") and devised the term "blogger" in connection with Pyra Labs' Blogger product, leading to the popularization of the terms.

After a slow start, blogging rapidly gained in popularity. Blog usage spread during 1999 and the years following, being further popularized by the near-simultaneous arrival of the first hosted blog tools:

Blogging combined the personal web page with tools to make linking to other pages easier — specifically permalinks, blogrolls and TrackBacks. This, together with weblog search engines enabled bloggers to track the threads that connected them to others with similar interests.

#### 2001–2004

By 2001, blogging was enough of a phenomenon that how-to manuals began to appear, primarily focusing on technique. The importance of the blogging community (and its relationship to larger society) increased rapidly. Established schools of journalism began researching blogging and noting the differences between journalism and blogging. Since 2002, blogs have gained increasing notice and coverage for their role in breaking, shaping, and spinning news stories. The Iraq war saw bloggers taking measured and passionate points of view that go beyond the traditional left-right divide of the political spectrum. Blogging was established by politicians and political candidates to express opinions on war and other issues and cemented blogs' role as a news source. Meanwhile, an increasing number of experts blogged, making blogs a source of in-depth analysis. Blogging was used to draw attention to obscure news sources. For example, bloggers posted links to traffic cameras in Madrid as a huge anti-terrorism demonstration filled the streets in the wake of the March 11 attacks. Bloggers began to provide nearly-instant commentary on televised events, creating a secondary meaning of the word "blogging": to simultaneously transcribe and editorialize speeches and events shown on television. Real-time commentary is sometimes referred to as "liveblogging."

#### 2004–present

In 2004 Merriam-Webster (Publisher american dictionary) voted Blog the "Word of the Year"

By 2010 about 8.4% of the german internetusers had their own blog. Worldwide there were about 200 million Blogs and min. 200 free bloghoster

  


### Technical Characteristics

#### Software

Typical for most Weblog-Publishing-Systeme is that it is very easy to publicate websites using them. They are Content-Management-Systeme allowing you to create new content as well as changing and commenting for new and amateur users, without giving you a lot of variation in the Webdesign. Most the time the Design is only made once with the installation by choosing one of the Designspatterns availabe. Most Blogsystems allow you to change your Design later. You cann choose whether you host your weblog-software from your own webspace or you use it via ASP-service from a free or charged hoster. Most famous blog-softwaresystems are Serendipity, WordPress, Movable Type and Textpattern, mostly using PHP. The most famous blog-hoster are Wordpress.com, Blogger.dom/Blogspot.com, Twoday.net or Blog.de

#### Elements

**Posts/Postings**

The articles,which are the main component of a blog,are called posts or postings. They are usually listed chronologically in reversed order.

**Thread**

All posts made about one specified topic inside one Blog

**Comments**

Many blogs give you the opportunity to submit your opinion on a topic. This comment is then placed right on the same page as the original thread. On most Blogs you have the option whether you want to moderate the comment or you want to show them by instant. Moderating helps to avoid Spam or vandalism.

**Feed**

A Feed holds the whole content of a weblog in a unified form. It can be read and subscribed to via a feedreader. Best known formats are RSS and Atom

**Blogroll**

The Blogroll is a linkcollection open to everyone which refers to other weblogs. Normally it´s made clearly visible on the mainpage and all subpages.

**Tag Clouds**

Tag Clouds list and prioritise the tags used in the Blog in a very visual way.

  


### The Blogosphere

The blogosphere is made up of all blogs and their interconnections. The term implies that blogs exist together as a connected community (or as a collection of connected communities) or as a social network in which everyday authors can publish their opinions. Since the term has been coined, it has been referenced in a number of media and is also used to refer to the Internet. There is no Study that can show a global view over the whole blogosphere

  


### About the Bloggers

  * In the german language area about 66% of all Bloggers are female but the men´s blogs are the more read
  * It´s nearly the same in the U.S
  * About 72% of the english-speaking bloggers write a personal Blog
  * Only about 28% write their blogs for the reason of commenting and giving Information. But they have the bigger audience and are the far more active bloggers

  


### Blogging niches

**Political blogs** These blogs are often tied to a large media or news corporation, such as "The Caucus" (affiliated with The New York Times), "CNN Political Ticker", and the National Review's "The Corner."

**Gossip blogs** These blogs can greatly be attributed to the popularity of Perez Hilton, a celebrity and entertainment media gossip blogger. His blog posts tabloid photographs of celebrities, accompanied by captions and comments. Web traffic to the often controversial and raunchy Perez Hilton site skyrocketed in 2005, prompting similar gossip blogs, such as TMZ.com, Jezebel, and the Superficial, to gain popularity.

**Food blogs** These blogs allow foodies and aspiring chefs alike to share recipes, cooking techniques, and food porn, for others to enjoy. Food blogs serve as a sort of online cookbook for followers, often containing restaurant critiques, product reviews, and step-by-step photography for recipes.

**Fashion blogs**

These blogs became their own larger than life sub-community following the explosive growth of the blogosphere. Besides fashion news blogs, street style blogs have also become exceedingly popular. Many Bloggers consider updating their blog a full time job. These style mavens are able to earn considerable livings through advertising, selling their photos and even providing their services as photographers, stylists, and guest designers.

**Health blogs** These blogs cover health topics, events and/or related content of the health industry and the general community. They can cover diverse health related concerns such as nutrition and diet, fitness, weight control, diseases, disease management, societal trends affecting health, analysis about health, business of health and health research.

  


### Political Impact

  * Human Rights Defenders especially in Iran or China write about censoring, human rights violations and the social or political states in their countries
  * Many politicians use blogs for their PR
  * Political bloggers like Alexey Navalny in Russia started to challenge the official pro-government media ending in Navalny beeing called "the man Vladimir Putin fears most" by the "Wall Street Journal" in March 2012

  


### Legal and Social Consequences

Blogging can result in a range of legal liabilities and other unforeseen consequences.

**Defamation or liability**

Several cases have been brought before the national courts against bloggers concerning issues of defamation or liability. U.S. payouts related to blogging totaled $17.4 million by 2009; in some cases these have been covered by umbrella insurance. The courts have returned with mixed verdicts. Internet Service Providers (ISPs), in general, are immune from liability for information that originates with third parties (U.S. Communications Decency Act and the EU Directive 2000/31/EC).

**Employment**

Employees who blog about elements of their place of employment can begin to affect the brand recognition of their employer. In general, attempts by employee bloggers to protect themselves by maintaining anonymity have proved ineffective.

**Political Dangers**

Blogging can sometimes have unforeseen consequences in politically sensitive areas. Blogs are much harder to control than broadcast or even print media. As a result, totalitarian and authoritarian regimes often seek to suppress blogs and/or to punish those who maintain them.

**Personal Safety**

One consequence of blogging is the possibility of attacks or threats against the blogger, sometimes without apparent reason. While a blogger's anonymity is often tenuous, Internet trolls who would attack a blogger with threats or insults can be emboldened by anonymity.

**Behavior**

Tim O'Reilly proposed the Blogger's Code of Conduct for bloggers to enforce civility on their blogs by being civil themselves and moderating comments on their blog. O'Reilly and others came up with a list of seven proposed ideas:

  1. Take responsibility not just for your own words, but for the comments you allow on your blog.
  2. Label your tolerance level for abusive comments.
  3. Consider eliminating anonymous comments.
  4. Ignore the trolls.
  5. Take the conversation offline, and talk directly, or find an intermediary who can do so.
  6. If you know someone who is behaving badly, tell them so.
  7. Don't say anything online that you wouldn't say in person.

  


### Activity:

  1. Take a look at some popular blogs and judge for yourself: Blogbar, Bildblog, Spreeblick, Basicthinking, Schockwellenreiter, Ehrensenf, Netzpolitik, Fefes Blog taken from [6].
  2. Use the blog search engine Technorati (<http://technorati.com/>) to search for ’social web’ or any other thing you may want to look for in blogs.

## Microblogs

Microblogs are a relatively new phenomenon and are a special form of blogging.

The most famous microblog is Twitter, but also alternatives like Tumblr or Google Buzz exist. The main idea behind a microblog is to restrict the size of a message to 140 characters. This comes from its original connection to texting (SMS) [7]. In todays society with its general tendency toward information overflow this is a welcome trend. This is also why it is very popular with mobile devices.

Microblogging [8] is essentially a broadcast medium, meaning you write a message, which then will be broadcast to all your followers. It is not unusual that you also follow your followers. It can not only be used to exchange textual messages, but also links, images and videos.

In our class we will use it to primarily communicate class announcements.

  


### Messages

Sent messages, sometimes also referred to as “microposts”, can either be public, so for the whole world to see, or private, i.e. only viewable for a specified group of people. Depending on the service used these options are either preset, or can be changed in settings. As an example, when using twitter all your posts are public, while in Facebook you are able to decide for yourself with whom you’re going to share your news. You can even change publicity settings for every post individually right before sending.

Microblog messages can be submitted via SMS, instant messengers, e-mail, digital audio or simply typed straight into the web interface, and will then be sent out by the service of your choice. One aspect that made microblogs popular as they are today for sure is mobility. Not being bound to a computer and instead being able to send out your message the moment you feel the need to has been one of the biggest selling points since the beginning. So it’s no big surprise that, when microblogs first became popular, one of the most common ways to submit messages was via SMS. And that however is the origin of the microblogs length restrictions, adjusting the size of microposts to traditional text messages. An additional theory says another reason of choosing the length of the traditional SMS was that people are used to consuming these short texts quickly and so would more easily adopt the new online equivalent.

Nowadays clearly the most popular method of submitting is through the use of service-specific smartphone applications. Being able to quickly share messages, and pictures about events, experiences or whatever as they’re happening is what really makes up the charm.

  


### History

The first microblogs documented were known as tublelogs, and weren’t actually microblogs as we know them today. Moreover they where based no using the regular blog services, but instead of long meaningful posts they were simply being filled with hundreds of short, sometimes seeming randomly put together, text messages about the authors life, certain events or just about anything imaginable. From that example emerged basically all the microblog services we know today. In fact the idea was spreading like a wildfire so that by May 2007 there already existed 111 microblogging sites.

Founded in March 2006, Twitter is today’s most popular pure microblog service, but also Tumblr, which is focused on posting an collecting pictures, is enjoying great popularity. But also social networks contain micropost features, usually referred to as “status update”. The most popular representatives here are Facebook and Google+. Twitter is sometimes being referred to as some type of time shifted instant messaging, since it doesn’t require you to be online and allows you to filter whose posts you want to receive.

The posts content comes from a wide range of topics covering probably every aspect of life. The most popular and posted about are personal actions and interests as well as occurring events, be it organized or natural. Beyond that microblogs are also commonly used for communication and basic conversation. People share ideas with others of the same interests, concerns or professions.

  


### Criticism

Critics say that the majority of microposts being sent only contain dull, meaningless messages documenting people eating, waiting, etc… But opposing this argument, it’s not every bit of information sent through these channels that is important, but the potential it has in general. For example it is the fastest way to spread news nowadays. In recent events there occurred several natural catastrophes and the first reports about what’s happening always reached people via twitter being posted by random people experiencing said events at the very moment. And that’s long before news stations were able to produce and publish/send their first reports.

  


### Other services

There are a huge number of microblogging services similar to the ones mentioned above. Additionally there are free software packages that can be used to implement microblogging services inside a private network. The most popular ones here are identi.ca and present.ly, which are often used by companies to set up a new channel for intern communication.

Services like Lifestream and Profilactic will aggregate microblogs from multiple social networks into a single list, while Ping.fm will send out your microblog to multiple networks and services.

  


### Usage

As recent studies have shown 10% of Twitter users account for 86% of all activity on the network. Marketers running commercial microblogs for promotion of products, websites or simply their brand seem to be much more active and follow a lot more people than noncommercial equivalents.

  


### Video

Finally for everyone interested in more about microblogs I’d like to recommend the video “[Twitter in Plain English](http://www.youtube.com/watch?v=ddO9idmax0o&feature=player_embedded)”, where the phenomenon of Twitter gets explained easily understandable for everyone.

## Podcasts

A podcast is a type of digital media consisting of an episodic series of audio or video files subscribed to and downloaded through web syndication or streamed online to a computer or mobile device. The word is a neologism derived from "broadcast" and "pod" from the success of the iPod, as podcasts are often listened to on portable media players.

### Variants:

Video podcast: The same as a normal podcast, but it includes video.

Podcast novels: A podcast novel is a mix of the traditional podcast and a format called audiobook. It’s like a traditional novel but it’s delivered via RSS. The recording process is made continuously. Every time an episode is done it will be released online. Podcast novels are distributed over the Internet, commonly on a weblog.

Enhanced podcast: Enhanced podcast is also an expansion of the traditional podcast format. It includes some extra information like images displayed simultaneously. Links are also allowed to provide extra information and content.

### Platform:

The most used platform is called iTunes. iTunes is a media player computer program, used for playing, downloading, saving, and organizing digital music content and video files on personal computers. It can also manage contents on iDevices. Other software not that popular is also available for different platforms. A list can be viewed on: <http://www.buzzmaven.com/podcast-software-list.html#Macintosh_Podcast_Software>.

### Most popular Podcasts in Germany:

The most popular podcast(audio) on iTunes is actual because of the european championship, Jogis Jungs provided by SWR 3, a bavarian radio station. 2nd is Quarks and Co(video podcast) a scientific TV format explaining the world from the eyes of a scientist. 3rd is Wissen macht Ah! the same format like the previous one from Westdeutscher Rundfunk.

## Assignments

### Ex.1: Start your Blog

For your personal learning journal it makes sense to start a blog. If you already have one, and you want to use it that is fine. However, it may make sense to create a new one, just for this class. You may use any blog web site you like, only it should be publicly accessible, and it should allow others to leave comments. In case you have difficulties setting up a blog, check the ’HowTo’ pages. Note that your blog can be anonymous, but we the class need to know about your blog. My blog can be found under ’Social Web Ohm’ (<http://socialwebohm.blogspot.com/>). If you need more help, check out [9].

### Ex.2: Micro-Blogs: Twitter

For communications relating to the whole class we will be using Twitter. Follow the ’HowTo’ pages and see how to set up a Twitter account. Again, you may not want to use your real name for it. If you have already an account, you are more than welcome to use that. I have set up an account for the class: ’@SocialWebOhm’ (<https://twitter.com/SocialWebOhm>). Make sure you become a follower of that account, if you don’t know how to do that ask a friend. If you need some introduction / help with Twitter reference [6] maybe a good starter. If your interested in some interesting Twits, reference [10] maybe interesting.

### Ex.3: Podcasts

Read the wikipedia article on podcasts [11]. Find podcasts in an area that interests you and listen to one or two. Write about your favorite podcasts in your blog.

  


  


# Collaboration

The Wikipedia is a very good example for collaboration. Although the edits are done by individuals, the result is a team effort, a collaboration. Today we will learn about group sizes and team building.

  


## Group Sizes

Usually, small groups are considered to be of the size of 3 to 20 individuals [8] . Generally one should distinguish between groups

  * with 5 or less individuals (primary group)[10]
  * with 6 to 20 individuals (secondary group)

The tiny groups are not really groups. They are basically individuals teaming up in pairs. Their advantage is, that their structure becomes clear very fast and they can start performing in a very short period of time.

  


## Stages of Group Development

For small groups with 6 or more individuals, things get a little more complicated. Before those groups can perform, they have to go through several stages of group development [11]:

    "The Forming – Storming – Norming – Performing model of group development was first proposed by Bruce Tuckman in 1965, who maintained that these phases are all necessary and inevitable in order for the team to grow, to face up to challenges, to tackle problems, to find solutions, to plan work, and to deliver results. "

This model has become widely accepted and is the basis for subsequent models.

Some teams reach the Performing phase very quickly, some never. In such cases the Interaktionsprozessanalysis [12] maybe helpful.

  


### Activity:

Take a quick look at reference [11] to learn what is meant by forming, by storming, by norming and by performing. Later on you should be able to observe how your team goes through those different stages.

  


## Group Members

Another interesting thing to observe about teams is the role types a team allows for. Every member of a team can belong to one or more of the following role types [13]:

  * der positiv eingestellte Teilnehmer
  * der Redselige
  * der Dickfellige
  * der Streitsüchtige
  * der Alleswisser
  * der Ablehnende
  * der Erhabene
  * der Ausfragende
  * der Vielredner
  * der Blocker
  * der Zurückhaltende
  * der Clown

By allowing or disallowing some of the above role types, the team communicates in which state it currently is. For instance, a team that is in the performing phase, will not allow for a blocker, but since it is in the performing phase has no issue with allowing for the clown.

  


## Hierarchy in Groups

Raoul Schindler [14] made a couple of interesting observations about groups, which led him to an interesting theory [15]. Assume a group has a certain goal ’G’. This may be climbing a montain, for instance. Then the group members quite often take on certain roles, as Schindler calls them: Alpha, Gamma, Omega and Beta:

  * Alpha: is the leader, the one wanting to climb the mountain the most, representing the group against the outside ’enemy’
  * Gamma: are the team members that support the goal of the leader, interesting however, is that the Gammas are the decision makers
  * Omega: he or she is not really interested in climbing the mountain, i.e. usually objects to the goal of the group, sometimes sympathizes with the ’enemy’
  * Beta: they are the experts of the group, e.g. experienced mountaineers, a group does not always have Betas

A group always has an Alpha, and always has an Omega. Further, even more interesting is that as the goal of the group changes, an Alpha may turn into an Omega and vice versa [16].

  


## Teambuilding

With what you have learned so for, it now is time to get a little more practical and personally experience some group dynamics. As part of this course you will have to write a chapter in our wikibook. For this you need to form teams of 4 to 5 students per team.

### Activity:

Think of possible ways to form teams such that all topics are covered, and none of the teams are larger than 5 students, and no two teams cover the same topic.

### Activity:

Follow your ideas and form teams. Experience shows that mixed teams (in terms of gender, age, nationality, etc) tend to have a little more difficulty in the beginning, but have overall better performances [source needed].

  


## Team Building Activities

The following activities help your new team to get to know each other, and experience some group dynamics in action.

### Activity: Marshmallow Challenge [4]

Build the Tallest Freestanding Structure: The winning team is the one that has the tallest structure measured from the table top surface to the top of the marshmallow. That means the structure cannot be suspended from a higher structure, like a chair, ceiling or chandelier.

If you want to know how other teams did on the marshmallow challenge, watch the TED video by Tom Wujec: Build a tower, build a team, (www.ted.com/talks/lang/en/tom_wujec_build_a_tower.html)

### Activity: Tower Building

Reference [9] also has a very nice team building actvity. In groups of 6-7 students you build a tower out of sheets of paper.

### Activity: Sin Obelisk

In reference [6] is more of a detective work, in which the team members have only partial information about an ancient tower.

  


## Tools for Collaboration and Communication

There are many tools for collaborating. Especially creating documents and managing projects. Tools that have shown to work are:

  * Google Docs: creating documents together.
  * Teamlab: (<http://www.teamlab.com/>): is geared towards project management.
  * Zoho: (<http://www.zoho.com/collaboration-apps.html>): take a look at their collaboration apps.

### Activity:

In your team create a common document on Google Docs. Have different members of your team edit it. What happens if two members edit the same document simultaneously?

  


## Wikis

Wikis are a crazy idea, the first one was started by Ward Cunningham [17]. The most popular wiki is the Wikipedia. Basically it is an online collaboration tool for creating documentation.

    "A wiki is a website whose users can add, modify, or delete its content via a web browser using a simplified markup language or a rich-text editor." [17]

For our class project we will write a Wikibook, which is using the same software as Wikipedia (and also using the same logins).

### Activity:

Check out our Wikibook: ’Social Web’ (<http://en.wikibooks.org/wiki/Social_Web>). As you can see there is still lots of work to be done. To get started:

  1. get a login for Wikibooks or Wikipedia, which is the same. (See the HowTo for details)
  2. learn how to use Wikibooks: <http://en.wikibooks.org/wiki/Using_Wikibooks>
  3. identify the topics which you and your team are responsible for
  4. get started with filling contents

Everything you enter into Wikibooks or Wikipedia must be under the Creative Commons license [18]. If you like to see how such a wikibook looks like after a semester, take a look at the book that a previous class created: ’Game Creation with XNA’ (<http://en.wikibooks.org/wiki/Game_Creation_with_XNA>).

Be aware of copyright issues - do never copy and paste! Every article you write can be tracked back to you. If you violate somebody else's copyright, you can be certain that you get their lawyer’s call and that will not be cheap!

  


## Assignments

### Ex.1: Forming – Storming – Norming – Performing

Read the Wikipedia article on Tuckman’s stages of group development [11]. Make sure that you identify this phases also in your own experiences with groups. Write about this in your blog.

### Ex.2: Group Dynamics

Read the article ’Grundlagen der Gruppendynamik’ by M. Burger [15]. In your team can you identify the Alpha, Gamma, Omega and Beta? Write about what you think of this theory in your blog.

### Ex.3: Team Building

Take a look at the Teampedia [7] and the Sandstone [5] websites. Read through some of the activities. Pick a couple that you feel interesting. In your group then decide on one that seems fun for everyone and go ahead and do it. Again tell us about your experience in your blog.

### Ex.4: Creative Commons

Learn about the creative commons license and rephrase it in your own words. Write what you have learned in your blog.

### Ex.5: The new Power of Collaboration

Watch Howard Rheingold TED talk ’The new power of collaboration’ (www.ted.com/talks/howard_rheingold_on_collaboration.html).

  


## Coworking

### Definition of Coworking

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Coworking_Space_in_Berlin.jpg/220px-Coworking_Space_in_Berlin.jpg)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Coworking Space in Berlin

Coworking is a concept that describes a new style of work coming up all over the world. As you might already mentioned, the term coworking means working together, but it signifies more than just this. Coworking is a new trend that involves a shared working environment, a so-called working space, comparable to an office. In distinction from a typical office environment, coworkers are usually not employed by the same company. Quite often, they don’t even practise in the same professional field. The term coworking was first characterised by Bernie DeKoven, an American game designer in 1999 to describe computer-supported collaborative work. Six years later in 2005 Brad Neuberg, a software engineer focused on web technologies, used this term to describe a physical space, which he called “9 to 5 group” before than.

### History of Coworking

It cannot be clearly said, where exactly coworking has its origin. Some say the whole coworking movement started in New York. Because of the horrendous rents there, many people weren’t able to afford these for an own office. So they weren’t able to rent an office, and they also weren’t able to work at home because of various reasons, i.e. they just didn’t have enough place to work efficiently or they had their kids at home and couldn’t concentrate with all that noise or maybe they just don’t want to be at home all day. What to do now? So these people began to think about alternatives of an own office and home office. They recognized that quite a few people had the same problem and they realised that there is only one way for a solution. Like persons who live together in a living community to save money, they wanted to create an office community to save money too.

Others say that it all began in California, more precisely in San Francisco. Brad Neuberg, we already get to know him, organized the first coworking loft with the name “Hat Factory” in the middle of San Francisco. It was a live-work loft and home to three technology workers. During the day it was open to everyone who wants to work in. He was also one of the founders of “Citizen Space”, the first “work only” coworking space.

### The Coworker's profile

What kind of people participate in coworking? In 2011 deskmag.com presented the results of the 2nd Global Coworking Survey (661 participants of 24 countries). Here are the most interesting facts:

\- Most coworkers are in the mid twenties to late thirties.  
\- The average age is 34 years.  
\- Nearly two-third of them are men and one-third women.  
\- More than half of all coworkers are Freelancers.  
\- Four of five coworkers began their career with a university degree.  
\- The majority work in the field of creative industries and new media. Most of them are web developer, programmers, web designer and/or graphic designer. The boundary between these jobs is fluid.  
\- Other professional fields of coworkers that are mentioned in the survey are journalism, writing, architecture, marketing and PR.  
\- More than 40% of all coworkers are interested in the concept of Coworking Visa. That allows them to visit working spaces in other cities. One in five already worked at least once in another working space.  


  


### Coworking and Web 2.0

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/39/Zonaspace-coworking-atmosphere.jpg/220px-Zonaspace-coworking-atmosphere.jpg)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Zonaspace-coworking-atmosphere

So what is Coworking concerned with Web 2.0? Well, theoretically nothing. Practically everything. Coworkers need a working space to work. If they have one, they are happy. No need of Web 2.0 so far. But most of them work in a team and that team is not in-house. So if they want to collaborate with their teammates, they have to use a medium. And the only one, which is qualified for this, is the Internet with its Web 2.0 features. A famous collaboration tool is Google Docs. With Google Docs you are able to write and edit together same documents in real time with others. Another interesting online service for collaboration is teamlab.com. This service can much more than Google Docs. It gives you the possibility of working together on documents, managing projects, creating blogs and wikis, using an integrated calendar and sending emails directly on the portal. But the best webpage, I think, is zoho.com. It combines all the abovementioned tools and applications and provides even still more to the user, like a chat function, a comment box, a meeting function and a lot more. More than 6 million people are using zoho and the number increases. So if you consider to join the coworking movement keep zoho in mind. You won’t regret it.

### Related Links

<http://www.coworking.de/> Here is a list of all 72 German working spaces.

<http://www.coworking-news.de/> Here you can find current news about the European coworking scene

<http://www.coworking-nuernberg.de/> Website of the local working space in Nuremberg

## **C**reative **C**ommons Licence (johannes kiesel)

Chances are at some point or another one has seen this license on works of some kind on the web. Creative Commons is a non-profit developed out of the collaboration movement on the internet. Since 2001 it has strengthened in numbers reaching a couple hundred million projects/works that are licensed Creative Common. Since it is a non-profit organization, they are not a editor or anyhow commercially involved in their license-holders works. The basic idea behind the CC license is that it replaces the “All Rights Reserved” label, each individual has on their intellectual property. By doing so , people can choose which rights they want to keep and which they are willing to give up in order to create a more voluminous creative mass on the internet. It stands under the Motto to give back from where you took. Everybody can create new out of old and change new to make better.

Lawrence Lessig from the Stanford Law School is said to be the founding head behind the CC spreading a revolutionary idea which was honored by the Prix Ars Electronica for the category “Net Vision”.

Originally only available in the United States it has quickly managed to spread all over the world. There are six specific licenses protecting works internationally. Attribution CC BY: This license allows people to distribute, remix, tweak, and build upon your work for personal and commercial use as long as they Credit you in their creation. This is the most common license issued by the CC. Here is a list of the other Licenses issued. For detail visit: [creativecommons](http://www.creativecommons.org/licenses).

Attribution-NoDerivs CC BY-ND

Attribution-NonCommercial-ShareAlike CC BY-NC-SA

Attribution-ShareAlike CC BY-SA

Attribution-NonCommercial CC BY-NC

Attribution-NonCommercial-NoDerivs CC BY-NC-ND

If there is a need for specifications due to individual legal issues in certain countries, the CC has developed additions to these six in order to accommodate legal issues that might still be outstanding.

Originally there have been other licenses apart from these six; however, they have either come under fire and have been dropped or they were not used and were therefore abandoned. When licensed by CC one can always give special permissions to individuals using their work under otherwise prohibited conditions. One cannot however, add more CC licensing after they been used by others in order to restrict them due to special interests.

In 2004 the Creative Commons license has entered Germany and fighting a hard battle against the notoriously conservative GEMA, which just recently commented that it will not accept CC licensing for their members. Besides the obvious effect the GEMA has on the web and its content, they also suppress up and coming creatives and musicians that rely on self- marketing and the viral properties of the world wide web. The CC's “Music Sharing license” is nothing else but the Attribution-NonCommercial-NoDerivs license. It's their most restrictive license which basically only allows the the downloading and sharing of the works, but restricts any commercial use or change to the existing peace.

Besides the obvious advantage to small time creatives and common internet users, big industry entities have started to incorporate the CC licensing to share their work and also be able to rely on the work of others. Probably one of the most well known non-profit of modern time, Wikipedia, have changed their GNU license to a Creative Commons one in 2009. Wikipedia fully relies on collaboration on the internet and with its business plan created the most voluminous encyclopedia of modern time. With the help of the mass, articles are kept organized and prove read making it a very reliable source. The Encyclopedia Britannica, most popular one over the past 244 years, was replaced by Wikipedia and has stopped printing as of 2012 and is only available in the 2010 paper form.

Besides Wikipedia, big names such as MIT-OpenCourseWare, Al Jazeera, Google, Flickr and many others have utilized the potential of the Creative Commons license. Even though governments are usually rather conservative and slow on the draw using modern media and their concepts, Whitehouse.gov, the internet presentation of the United States government, have issued photos, press-releases and other documentation with the CC license. More recently William Noel an ancient book curator has revealed the lost Codex of Archimedes. A very important manuscript written by ancient mathematician Archimedes. To make the text readable he and his team spend countless man-hours and used the Stanford particle accelerator. Once the text was readable and they were able to translate and interpret it, he put in online for free under a CC license to be used for any commercial purpose. This adds tremendous value to modern culture. More to the story at: [Ted Talks](http://www.ted.com/talks/william_noel_revealing_the_lost_codex_of_archimedes.html) In order to let the internet reach its full potential, it is important that the idea of free collaboration is supported and developed heavily over the next few decades. The Creative Commons have started different projects in multiple categories such as Culture, Education, Science and Government. The hope is that the efforts in each category can improve in content, efficiency and transparency. The economical growth that can come from this is enormous and well worth pursuing.

As the internet is spreading and developing into a huge pool of information it is important to organize and mark your work in a way to gain the most out of your own work and the work of others. All rights reserved is not always the most lucrative way to spread your ideas nor is giving it away without being mentioned or credited. With the CC label one has the ability to customize the the rights they would like to reserve. Your idea might just be the initial spark to something bigger on which you can then add to if you so choose to. Professionals, dilettantes, amateurs, corporations, governments, non-profits and any other group of people or entities can maximize their personal profits using online collaboration.

## Social collaboration at the office (Christian Siemer)

Today Social media is one of the top words in the commercial departments. Every big company talks about Social Media and tries to be a part of it. The budget for using Social Media grows exorbitant, but only few companies know the power of Social Media for the office.

Social Media has an enormous potential for the office which can be used in a lot of ways. Over the years, the main problem at the company is the existing information overload. Just by adding another information channel, will not bring you the answer. Social Media could be much more than only an information channel, which in addition has to be checked by employees every day. This could provoke a stress situation and have an effect on the work habits.

_For instance, not having internet in Norway for Christmas is quite relaxing to me._ Not checking or answering my mails, not posting on facebook or other Social platforms, is stress relieving and soothing.

But there are not only risks. Social Media has the power to revolutionize the collaboration. The integration of Social Technology is not only making the It-infrastructure available. There is much more strategy and organization to it. It`s inescapable to change how the work is done, to use this technology efficiently. This is a long procedure which needs an integration of Social Technology in the operating process. The problem of the first generation social tools was decoupling the workflow. When the first curiosity was over, the interest of the employees sank immediately. But when the tools were integrated in the process, application and data, the Social technology became an important instrument with four main criteria, as followed.

  * Integration with mission-critical applications
  * Organization and maintenance of content
  * IT management functionality to comply with governance and compliance
  * Social analysis

One really powerful application is Wiki, a corporate online collaboration tool.

## Can general group models be applied to groups in social networks? (Rolf Thoma)

At the beginning of this topic, we heard a lot about general group phases and group roles. Now, the question arises as to what extent these models can be applied to groups in social networks. I chose the model below to analyze our course Facebook group.

**Group of phases:** (<http://wulv.uni-greifswald.de/2006_mw_gruppen_paedagogik/userdata/Handout%20-%20Rollen.pdf>)

Groups go through various stages of development which have a crucial influence on each group situation Depending on the group phase, specific behaviors, actions and interests can be expected. These again co-determine the success of group programs in coordination with the group phase. (cf B. Langmaack)

**Phase 1: Arriving – Orientating – making contacts**

  * Keeping distance and search proximity
  * Wishing to remain anonymous and showing yourself
  * Looking for guidance, safety and structure

**Phase 2: fermentation and clarification**

  * Developing a social hierarchy (own position is clarified, potential for conflict rises)
  * Looking for rules and standards

**Phase 3: Passion for work and productivity**

  * Recognizing similarities
  * Effective and energetic work
  * Climate of mutual "giving" and "taking "
  * Well developed group structure with an established expectation of modes of conduct and secure interpersonal relationships

**Phase 4: transfer, graduation and farewell**

  * Complete the substantive work
  * Foreign interests increase
  * Review and evaluation

  
**For the Facebook group "Meida Engineering":**

The group was founded by first semester students on October 11, 2010, shortly after the beginning of the semester.

_Phase 1: Arrive – Orientation - making contacts_

There is not yet any clear group goal. For now, efforts are made to call together all the students and discuss a cover image. At first, everyone writes a comment regarding their membership number. For example: "20! I would have found it heaps cooler to be number 21, since that’s how old I turned some days ago =)" Basically, everyone introduces themselves to the group. Simultaneously, the same thing happens in class in real life. A joint meeting is the first practical use of the Facebook group. An initial conversation with a total of 35 comments from 10 different individuals begins. The roles, the individual participants are taking, are just as varied and complex as in real life. There are those who say “yes” to everything and subscribe to the previous speaker’s opinion. On Facebook this is simply done by clicking on "like". Others try to press forward by making comments like: "the only question is when and where" ... "Beautiful weather, ‘whörder meadow’, crate of beer?" Then there are those who have a generally negative attitude "it is getting colder and colder though. How about doing it next week?” And finally there are those who try to mediate “That’s a good idea although I can imagine it to be quite cold :)" The only thing missing in a conversation online are facial expressions and gestures. The smileys that are used cannot replace them. They are rather used to underline fundamental attitudes towards the topic. "I share this opinion :-)" In other cases the smileys imply that the comment is not meant to be taken too seriously, "The word ‘lazy’ seems to be perfect for you guys ;-)".

_Phase 2: fermentation and clarification_

The joint meeting was never successfully organised. Even passing around a piece of paper during class did not work out. So even in real life planning a meeting failed. The first organisational success took place when the Facebook group started to disseminate information such as "According to an email, the PS-course DOES take place" or "Registration for the Exams starts today, do not forget". The closer to exams time the students get, the more comments like this are written: "I still don’t understand the exercise for programming... can anyone help me with it tomorrow?" However, instead of making an appointment, there are usually just explanations or solutions attached as comments. That way, all the others that have the same problem can also benefit. Just like in the real world, different characters and personalities with different talents evolve. Some are experts in certain subjects like programming and share their knowledge by posting summaries and solutions, while others take care of organising parties, or keeping an eye on administrative matters such as enrollments and exam registrations. Others make entertaining the group their aim.

_Phase 3: passion for work and productivity_

Already during the first period of exams, an effective system of cooperation has emerged within the group. Approximately 20 people are actively involved in answering the questions that arise concerning the examination subjects and ask their own questions.

_The 4th phase "transfer, graduation and farewell"_ has not yet begun. It is expected to begin at the end of the course.

_The addition of new members_ is of interest. After the first year of the Facebook group, students from the lower or upper semesters also joined. Overall, the group has a current total of 87 members. However most of them do not actively take part in group events. They are either silent observers or still in the first group stage "Arrive - orientating – making contacts".

**Conclusion**

A social group within the Internet works in the same way as in "real" life. Groups that meet both on the Internet and in real life become a community much faster than solely virtual groups. In both kinds of groups there will always be outsiders and observers. New members always have to find their own position within the group first and the closer the group already is the more difficult it is for new members.

  


## _How to use wikis as online team document collaborations_

### **Defining a wiki**

A wiki is a web page where users can modify or delete the online content. Anyone can participate, which is both fun and scary. A wiki is different from a blog, because as the owner of this blog I control the content. A blog post is a compilation of thoughts and cannot be edited by anyone directly via the page. When it comes to a wiki anyone can edit or update posts, phrases, or information contained within the wiki.

### **Company wikis as project collaboration tools**

Wikis are also a great way to share knowledge with a group of individuals in companies of organizations. For example, you can use wikis as project manager where the team can share, edit, and update information. Wikis offer a solution where you can invite your team to make proposed changes to a document as they see it. Once the changes are made, you can approve them or reject them, and even allow group consensus. Wiki is a really easy method to create a book, like documentations. You can collect information’s and impressions. It`s the same principle why we write this wiki. If everyone in your team writes some pages you have easily a full complex documentation in short time.

### **Document collaboration and sharing tools**

When it comes to internal social networks and company collaboration, having an internal social network or wiki can be helpful to employees as well as work teams who are working from home. Often wikis are a piece of an internal social networking platform, where companies can chat, share files, use wikis, and post blogs using a platforms like SharePoint.

As you can see, this collaboration tool allows for multiple users to edit and make changes to a single document or page quickly and easily. Edited changes show on the wiki as yellow highlighted words.

  


  


# Social Networks

The social networks are the most popular form of the social web. They range from personal, professional to dating networks and many more.

Basic idea of social networks is the community of people who shares all kinds of information together. Social Network Researchers studied the behavior of people and influence on our psychology with the help of Social Networking Services.

## Social Networking Service (SNS)

A SNS is a online service, platform with Web 2.0 Applications. Fundamental functions of Social Networking Service are:

  * All users get an profile with personal Information which can be seen by other users.
  * Users can be searched after their names or profile in Internet
  * Users can publish and upload own text messages, photos and videos
  * Sending messages
  * Finding new friends and connect with them
  * Playing social games
  * Subscription of pages (RSS)
  * Setting up of privacy and data protection [19]

The reason of using SNS could be same religion, career, interests like Music, Sport, lifestyle and common friends of community members. Traditionally, social networks were built face-to-face, but today's social networks are primarily online and via mobile device technology.

## Definition

The Wikipedia defines social networks as [5]:

    "A social networking service is an online service, platform, or site that focuses on building and reflecting of social networks or social relations among people, who, for example, share interests and/or activities. A social network service consists of a representation of each user (often a profile), his/her social links, and a variety of additional services"

Some of the internationally more networks are: Facebook, Google+, Orkut, MySpace, LinkedIn, and many more. Interesting, is that the popularity depends strongly on countries.

## Social Networking Services(SNS's)

![A social networks](//upload.wikimedia.org/wikipedia/commons/thumb/3/36/Socialnetworks.jpg/220px-Socialnetworks.jpg)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Popular Social Networks, Gavin Llewellyn, CC

The first social networking sites were Classmates.com (1995) and SixDegrees.com (1997). There are many different types of SNS's in the world. For example XING and LinkedIn are for education and career and Twitter is for short Messages and Releases there is Twitter.

### Facebook.com

_"Giving people the power to share and make the world more open and connected."_

Facebook is the most successful and popular SNS worldwide. Facebook was founded in 2004 by Mark Zuckerberg with his college roommates and some other students Eduardo Saverin, Dustin Moskovitz and Chris Hughes. Today Facebook has over 900 million active users and more than half of them using Facebook on a mobile device. It used in 77 languages.[20]

### Plus.google.com

_"Real-life sharing rethought for the web."_

It is one of the biggest competitors of Facebook. Google+ was launched in 2011. Today, it has 250 million registered users and it is available in 44 languages. it offers compared to Facebook new services and features like Circles, Hangouts and Sparks. An important advantage of Google+ is, it gives you a possibility to syncronize data with google account and other google applications. For example videos in YouTube, photos in Picasa, documents in Google Docs and blogs in blogger.com.[21]

### Xing.com

_"Easy. Professional. Networks."_

XING is the SNS for professional contacts and more popular in Europe. XING was founded in 2003 by Lars Hinrichs. Today over 12 million members worldwide use the platform for business, job and career. XING is one of the few fee required SNS and users can upgrade their free account to premium account.[22]

### Activity:

As I assume most of you will have one or two accounts in a social network, let us find out the following:

  * which social networks do you use?
  * how much time do you spend in each one?
  * what do you do there, i.e. what functionality of the social network are you using?

## Popularity Changes

A problem many social networks face (like MySpace and studiVZ for instance) is their short half-life, meaning that it is difficult for them to keep their customers happy. Popular social networks in Germany at the time of this writing (2012) were [6]:

  * Facebook, studiVZ, Google+, wer-kennt-wen, Jappy, Lokalisten, StayFriends

As you can see the popularity changes over time (Facebook has been excluded in this diagram):

image here studivz google+ wer-kennt-wen lokalisten jappy

If you are interested in the current numbers, you can easily create the following diagram yourself using Google’s ’doubleclick ad planner’:

images here (Unique visitors to select social networks for Germany in January of 2012, data source: doubleclick ad planner, estimates)

  


## User groups and user motives

The new Internet-based communication changed the interpersonal communication dramatically. It moved from the private one-to-one communication to an one-to-many communication because of emailing and chats but also because of the „new media“ like social networks, blogs, forums etc. There are so many social media offers which meanwhile belong to the everyday life.

  
_The reasons why people use the social web:_

\- to gather information (about companys, products, people,.. and for studies)

\- to gather information for private affairs (people, recipes, activities, holidays,..)

\- to exchange information

\- to maintain contacts or finding new friends

\- to make promotion for something

\- to present something or someone

\- for pasttime (games, watching videos and films,...)

\- for shopping

  
_Who are this social media users?_

Social media users are almost everyone: women and men, adults and children. In Germany there are about 74,7 million people online. And the trend being online increased during the last years.

Most of the users are between 14 and 50+ years old. In the year 2011 97,3 % of the 14 to 29 years old people were online, 89,7 % of the people between 30 to 49 years and even 52,5 % of the 50+ years old people.[23]

  


_You can divide the social media users in some user groups:_

  
**1\. The digital outsider**

\- mean age 62,5 years

\- mainly femal

\- mainly not working

They are at the age of 60 years and don't see any reason why they should use the new media., maybe because they are intimidated by the diversity.

  
**2\. The occasional users**

\- mean age 46,8 years

\- mainly femal

\- slight ratio of working people

This people use the social web very rarely. They know about the basic components and use the social web only for gather information. These people are citical and not in social networks because this social networks are to universal. At best they are in forums or on blogs to read something. They are the passive ones!

  
**3\. The occupational users**

\- mean age 47,8 years

\- mainly femal

\- a high ratio of working persons

They use social web and networks mainly at work and do everyday stuff like gather information and writing email. They focus on trends, producs and companys, frequently in forums and exchange information with friends, unknown persons and companys. Social networks facilitating the contact between each other, they think, and it is good for the promotion of companys.

  
**4\. The trend users**

\- mean age 37,5 years

\- mainly men

\- working persons

On the other side there are people who use social web very intense. They have a good technical equipment at home and use social web for pasttime and to have contact to their friends. Most of them are members of social networks, but they don't care about the promotion of products and companys.They want to come in contact with other people, find new friends and maintain their contact to old friends. Some also have a mobile internet.

  
**5\. The digital professionals**

\- mean age 37,2 years

\- mainly men

\- a high ratio of working persons

This people have a high digital competence. They have the best IT-infrastructure at work, use mobile internet and social web for mainly everything, gather and exchange information in forums and blogs, be up to date because of using social networks like facebook, twitter, xing,etc.

  
**6\. The digital avant-garde**

\- mean age 34,0 years

\- mainly men

\- a very high ratio of workking persons

Only a small part of the people are such digital avant-garde. Computer and internet define their daily schedule what makes them to very active people in the social web.They are the mentors in forums, maybe wirte blogs and exchange information about technical problems with other online users. Towards technical progress, companys, products and trademarks they are very open-minded, but they don't use social networks so often.

## Risk & Abuse of Social Networks

Internet social networks are nowadays great places to meet and for people sharing similar interests. But Facebook and similar Social Network sites can also pose serious security threats to the users, and ways for others to abuse these lacks of security.

For a little practice-relevant demonstration read this short story about a student, who is very active in social networks and got into much trouble.

[Short Story](/w/index.php?title=Wikibooks:Short_Story_index&action=edit&redlink=1)

    

    _Mario is 23 years old and he is a big fan of social Networks. So its not surprising that he is signed on many differed networks like Facebook, Myspace and Twitter. Like his friends, Mario posts all “news” on the various platforms for each and every one available. He posts YouTube videos, uploads funny pictures, which he found at Google and publishes them on his friends “walls”, to sweeten their day. Of course he also shares many party-snapshot of him and his friends with users of the social networks. Mario also used to receive many friend requests, application-requests and much of that what the different social networks offer._

    

    _But then it happened, Mario realized the dark side of his beloved social networks._
    _At first Mario was terminated without notice, because he slandered about a colleague on facebook. Mario went to court, but they’ve seen the termination justified. So Mario had no other chance than to apply for a new job. He wrote numerous applications, but never received an invitation for an interview. A friend of him made him consider that personal managers nowadays look through social network profiles of the potential employees. If personal managers find party-snapshots, where the applier seems to be drunk etc., those won't be that much considered._
    _But it got worse. Mario had to realize that social Networks are also used by people with criminal intent. Short before his trip to South Africa Mario set his status to "14 days South Africa, I come!”._
    _As he came back, his flat was mugged. The burglars got with targeted search query’s to Mario’s post, and found his name in the telephone book with his associated address. He sustained a huge financial damage, but his insurance paid no cent cause of his post._

    

    _After this happened, it hit Mario even harder, as he received a warning form a lawyer. The lawyer charged him for 15.000€, because he published various pictures of athletes, series and so on which he used to enrich his profile. Mario did not know that he acted with his behavior against the law. But that’s not all.. Because Mario also uploaded pictures on his friends walls, this led to other warnings form lawyers with a big charge._

    

    _One of his friends was so upset that he starts mobbing Mario through the social networks. Others followed up so that Mario is receiving day in day out insulting messages. They also presented pictures of Mario, which he already deleted for a long time ago._
    _Mario is devastated. Who though that his beloved social Networks would harm him that much?_

Social Networks can cause a lot of damage to their users, but in most cases the users are themselves to blame for wrong behaviour.

  * **Harm for Job & Applications** : If profiles are public to every one, personal managers also have access to the posts, photos and interests of the employee or applier. If there are compromising contents to find, this might have consequences to the employees job or appliers consideration.
  * **Crime** : Social Networks are places for people with criminal intent, they clan collect data of a targeted person and can narrow down when and where this person is located at a specific time. This leads to an easier way for burglar to commit adultery.
  * **Violation of copyright**: If a user uploads a picture, which is protected by copyright, he can get charged for this violation of copyright. Even if a user uploads a picture to a friends wall, the friend might has to deal with the emerging consequences.
  * **Online - Mobbing**: Exclusion form groups, insulting or offending posts on walls, informations are used to expose targeted person (Cyber-Stalking).
  * **Lack of data privacy protection**: some Social Networks collect every data they can get from the user. The networks sell this information to companies which want to personalize the adds for the user to generate buying power. Some not only collect data of the registered user, they are also collection data of non-registered users. An example is the facebook app, which allows the users to sync their phonebook with their facebook contacts.
  * **Social Engineering/Phishing** : Through phishing third persons get login data to acounts to impersonate the specific person. Most of the time the intent is to ask for financial support of the person’s friends.

## Social and Behavioral Sciences

The term ’Social Network’ is a theoretical concept as used in the social and behavioral sciences [5]. It is about the study of relationships, connections, and interactions of individuals or organizations. It models the structure of social groups, how it is influences, and how it changes over time.

### Activity:

There is a web site called Google Flu (<http://www.google.org/flutrends/>) which predicts flu epidemics based on search term people enter into their browser. However, another interesting approach is to use social networks:

  * Nicholas Christakis: How social networks predict epidemics, (<http://www.ted.com/talks/lang/en/nicholas_christakis_how_social_networks_predict_epidemics.html>) (17:55 min)

## Ethnography

"Ethnography is a qualitative research method aimed to learn and understand cultural phenomena which reflect the knowledge and system of meanings guiding the life of a cultural group." [10]

In her talk at TED Stefana Broadbent tells us how communication technology is capable of cultivating deeper relationships, bringing love across barriers like distance and workplace rules.

## Advantages and Disadvantages

**Networking with friends**

One advantage of Social Networks is the network of friends. It is always possible to be informed about the current activities of your contacts. In addition you can keep in contact with friends, which live far away. Or you can find friends, which you have not seen since school days.

  
**Communication**

Facebook and the other Social Networks give you the opportunity to communicate with others. The easy way to write massages and answer it, makes it possible that every day many messages and comments will send. To stay in contact with friend form other countries isn’t a problem because 798.9 million users from about the world are at least once a day on facebook [12]: . If you agree with someone and you want to publish it, the easiest way is to switch the like-button. On facebook you can also use the live chat or the video chat for communicating.

  
**Fun and Entertainment**

Another reason for using social networks is the offered fun and entertainment. For example you can play Social Games with your friends.

  
**Career-orientation**

The network XING gives you many positive feedback when you searching for a job. On XING you can create your own profile with working data for example which programming language you know. Employer can use a search option to find qualified employees and they can also easily get in contact with them. As opposed to facebook where an open profile can be a disadvantages for a career-orientated person. Your boss can get too much private information on you and this may have consequences for you. If you looking for a job in another country the network linkedin will be the right choice.

  
**Mobility**

With the modern achievement of smartphones it’s easy to reach people every time and everywhere. You can quickly get every new of your friends on your mobile device. In contrast to the conventional short messages on a mobile phone you have to pay nothing per send message. But there is also a disadvantage due to the constant accessibility expect many users a fast response.

  
**Marketing**

Another advantage of Social Networks for companies is the advertising. It’s possible to create a profile for your company or for a product that you want to promote. People who had made a good experience with this product used to click on the like-button and everybody of her or his friends see it. So it allows reaching many people you on an easy way. It’s also possible to create your own user-related advertising. You can define you target group with age, gender, hobbies, interests etc.

  
**Privacy**

A major disadvantage of the Social Network usage is the lack of privacy. If it is your first time on facebook you should check your privacy settings. These settings are often confusing and opaque. It is also important to think carefully about which parts of the profile is published on the internet. Something that is published once in the internet cannot be undone.

  


  


### Activity:

Watch Stefana Broadbent’s talk at TED:

  * Stefana Broadbent: How the Internet enables intimacy, (www.ted.com/talks/stefana_broadbent_how_the_internet_enables_intimacy.html) (9:54 min)

  


## Assignments

### Ex.1: Social Networking Service

Read the Wikipedia article on Social Networking Services [5] and write about it in your blog.

### Ex.2: Try another Network

For this class, become a member of a new social network that you have not used before. Make sure that other members of this class become your friends (what happens if they are in a different network?). If you are in Facebook try to connect to the classes account.

### Ex.3: Small World Experiment

Stanley Milgram small world experiment [9][7] is about the average distance of the relationship of two arbitrary persons, and its result is often stated as the "six degrees of separation" experiment. Either read Milgram’s original paper [9] or read the Wikipedia article [8]. Write about it in your blog.

If you are interested in this experiment, you may also want to read p.73ff of Amy Shuen’s book [11], where she also describes how this plays out in business networks like LinkedIn.

(Note, Milgram as also known for another famous experiment [8])

### Ex.4: Web 2.0 vs Social Media

Use Google trends, to see how the popularity of the terms ’web 2.0’ vs ’social media’ has changed over the years. Can you add that graph to your blog?

### Ex.5: Visualization of Your Social Network (optional)

In case you are on Facebook, the tool TouchGraph may be interesting: it visualizes your social network, (<http://www.touchgraph.com/TGFacebookBrowser.html>). (Note, I am not sure about the privacy issues here, if you are worried about privacy, then it is better not to use this software.)

### Ex.6: Two more TED Talks (optional)

The following two TED talks, are related to real social networks between people. They are very intriguing, and watching them is highly recommended:

  1. Nicholas Christakis: The hidden influence of social networks, (www.ted.com/talks/nicholas_christakis_the_hidden_influence_of_social_networks.html)
  2. Dan Ariely gave a wonderful talk on TED about ’our buggy moral code’ (www.ted.com/talks/lang/en/dan_ariely_on_our_buggy_moral_code.html).

If you liked these videos, write about them in your blog.

### Ex.7: Doubleclick Ad Planner (optional)

Google for ’doubleclick ad planner’ and enter with your normal Google account credentials. Go to the ’Research’ tab, and there select ’Search by site’. Then enter ’facebook.com’ for instance. You get quite a bit of information relating to that domain. This information might be helpful for advertising or for creating diagrams like the one above.

  


  


# Social Gaming

Social games have been around for some 5000 years. Basically any game involving more than one player is a social game. But that is not what we mean by social game.  
  
Definition:  
Social Games are Games in Social Communities, which are for free and have a browser based interface. The Casual Games segments are mainly focused on the analysis of social interaction between people.  
Social Games are easy to understand and lives on a social network, so you playing it with your friends if you want. You can choose to play with or against them.  
Social Games are not a reinvention, but a combination of Browser games with Social Networks.  
Beginning:  
\- 2007, 3 Years after the establishment of Facebook  
\- Zynga -> 'Evening of gaming in the Internet'  
  
Data:  
\- 510 million, Group Members worldwide play Social Games  
\- double size in 2010&2015  
\- Facebook: 61% / Google+: 17% / MySpace: 15%  
\- 70 millon Users worldwide play Farmville  
  
Gaming was quickly becoming one of the most popular category of applications on Facebook. Other platforms launched this genre of games too. To the lead market of Online-Gaming belong Great Britain and Germany. In 2011 one-fifth of duration users in England played Social Games. They invested only more time in console games.[24]  


  
The proportion of the gamers which played and paid for casual and social games was in the year 2011 the most worldwide. For the USA was in 2011 an expansion of social gaming expected. Overall, 40% of the Internet users played this type of online games. The favorite website for these games was Pogo and Yahoo! Games, in December 2011.[25]  
  
The Global Online Report 2012 had predicted that the gamblers in Brazil would play the most time in social networks and casual games. In France 15% of duration play social games.  
  
The rapid rise of Social Gaming starts with the makers of Zynga. Mark Pincus and his co-founders get the ‘Evening of gaming’ to the internet. In principle it was nothing new, the user could play games at the internet, but now they can play with their friends.  
Zynga buy an online poker game called “Texas Hold’Em”. This game initiates a viral distribution because previously it was forbidden in America to play online poker for money. Zynga circumvent the gambling guidelines by don’t changing back the money that they play with. So it is not against the gambling guidelines. The first Cash Cow was born.  
[26]  
One of the first colleagues was SGN (Social Gaming Network) and then came Playfish. Playfish Games were very complex, had many details and an extravagant design. Electronic Arts (EA) buy the young company for estimated 400 million US Dollar. At this time Playfish had about 60 million users per month.  
  
  


  


  


## Social Network Games

Hence to be a little more exact, let us talk about social network games. The Wikipedia says that it is a game that is played inside a social network, such as Facebook, and "typically features multi-player and asynchronous game play mechanics." [9] Usually they are casual games for the occasional player. The most important feature is that you play the game with your friends within the social network.

  


## Facebook Games are Popular

Just so that you understand, how popular games on Facebook are, look at the following numbers:

Name DAU

2.
Words With Friends
8,900,000

3.
CityVille
8,700,000

4.
Hidden Chronicles
7,200,000

5.
CastleVille
7,000,000

6.
Texas HoldEm Poker
6,800,000

8.
FarmVille
5,700,000

9.
Bubble Witch Saga
5,300,000

10.
Astrology
4,700,000

11.
Daily Horoscope
4,700,000

(Daily Active Users (DAU) for leading applications on Facebook for 02.03.2012, source <http://www.appdata.com>)

  


## Monetization of Social Games

Although almost all of these games are free to play, many people actually spend real money to buy virtual goods. The average user spends about $50 per year. For instance, Zynga partners with Facebook and is responsible for 12 percent of Facebooks revenues (Facebook gets 30%) [5]. In addition, there are revenues through all sorts of advertisement.

(Advertisement in CityVille)

  


## A few Examples

Just to get a rough idea what kind of games people play on Facebook, we briefly describe three popular games.

### CityVille (2nd)

Published by Zynga it is a game about building a city. Player can open restaurants, build hotels, construct bridges, collect rent, etc.

(Screenshot, CityVille)

### The Sims Social (18th)

In this Electronic Arts game you create Sim (a person) and develop relationships, make friends and foes, where friends are other players.

(Screenshot, The Sims Social)

### Bejeweled Blitz (20th)

By Electronic Arts, this is a quick, but addictive puzzle game, the idea is to get a row of three or more of the same stones.

(Screenshot, Bejeweled Blitz)

### Gardens of Time (43rd)

A game by Playdom, here the player uses a time machine to locate hidden objects throughout history.

(Screenshot, Garden of Time)

  


## Second Life

In 2007 and 2008 everybody talked about Second Life [4] and even in 2012 it is quite popular. It is a free 3D virtual world, where players through a 3D avatar can socialize, and interact with other players using voice and text chat.

(AttributionNoncommercialShare Alike Some rights reserved by Daana Kira)

### Activity:

To get an impression of how good the graphics of Second Life have become, either become a member, or

  1. Using Google look for ’flickr second life’ and view some of the images created from Second Life.
  2. For those images check out their respective licenses (for the above images you find the details on Creative Commons: <http://creativecommons.org/licenses/by-nc-sa/2.0/deed.en>)
  3. If you like a ’how to get started’ you can check out the tutorials at <https://www.socialtext.net/socialmediaberkeley/introduction_to_second_life>.

  


## MMORPG

Massively multiplayer online role-playing games (MMORPG) [7] are usually video games with a very large number of players interacting. They are role playing games, where the players take on the role of a character in the game and interact with other characters. Although not consider to be real social network games, because of their social interaction they should be considered as such. For instance, World of Warcraft has more than 10 million subscribers. The MMORPGing is a multi-billion dollar industry.

### Activity:

There is a wonderful talk about World of Warcraft and its psychological engagement and implications by Byron Reeves at the Stanford seminar on ’Human-Computer Interaction’: www.youtube.com/watch?v=RFmG_2e4R4U&list=PL32A089D3E2DFB65D&index=9&feature=plpp_video (1:23:55)

### Multi-User Dungeons

Forerunners of MMORPGs, MUDs (Multi-User Dungeon) paved the way of modern online [RPGs (role-playing games)](http://en.wikipedia.org/wiki/Role-playing_game). As such, they deserve some reflection from a historical point of view.

MUDs are different from a modern MMORPG in that:

  * A MUD has a text-based interface, so the world is described with text instead of pictures and other types of media.
  * Players type textual commands rather than clicking a mouse.
  * MUDs have smaller player bases, typically dozens of players rather than thousands.
  * MUDs are usually hosted at universities or other not-for-profit institutions, and there is no fee required to play.

#### Types & Variants

While the original acronym simply denoted a generic kind of game and not a particular style of play, inveterate experts of the matter distinguish several types of MUDs that have been known to exist to this day. According to the teachings of these authorities, MUD denotes a kind of online game in which it is the characters’ primary goal to explore the virtual world they find themselves in. All along the way, they solve various kinds of riddles, perform quests, thereby proving themselves worthy by gaining experience, skills and power. After having played and labored for several years, and having gained enough power to reach the highest level a character can obtain, a status usually referred to as a Wizard, the player may start to forge the game world according to his will. To do so, the player is bestowed responsibility for a part of that world.

On the other hand, MUSHs (Multi-User Shared Hallucination) tend to focus on the social interaction of the characters that are involved in the game. The idea of a MUSH is that players, actors actually, thrive by just expressing themselves, and interacting with one another when meeting in the same (virtual) room. MUSH players tend to lack the teeth grinding sobriety of MUD players, and usually just hang out together to discuss (virtual) matters instead of teaming up to slay monsters.

There are other types of MUDs, like MOOs, MUXs, and derivatives that describe slightly different variants of the types above. However, most of these variants describe differences of the software that runs on the game server rather than differences of what players or characters spend their time with.

#### Delimitation & Popularity

According to many [P&P role-players](http://en.wikipedia.org/wiki/Pen-and-paper_role-playing_game), MUDs come closest to what a computer-based RPG should look and feel like. Unlike Adventures, another kind of text-based computer game where players control just a single alter ego, and, while exploring the game world, must solve countless riddles and interact with more or less creative computer-controlled entities, MUDs simulate the interaction of multiple characters controlled by real humans – protagonists as well as antagonists – within the virtual world. A similar distinction applies to the type of game (also employing the ambiguous term [Role-Playing Game](http://en.wikipedia.org/wiki/Role-playing_game)) in which a single player controls an entire party that sets out to confront wave after wave of malicious monsters.

The golden age of MUDs was during the late 1980s and early 1990s. MUDs mainly thrived in university networks were students flocked to black & white (green, actually) terminals to celebrate and socialize. Due to the lack of Internet access for the major part of the populace at that time, MUDs were usually considered an academic phenomenon, and featured a high percentage of people with geekish finesse. When the Internet reached the masses in the middle of the 1990s, and was recognized as the commercial platform it is today, this development went hand in hand with a change of the type of online entertainment people spend their time with. As far as games were concerned, media-heavy, resource-greedy applications swept away the former charm of text-based adventuring, and although the mudding-culture never really died it never received the quantitative push that the vastly increasing online community could have brought. It therefore quietly lingers on relatively isolated from the eyes of masses.

#### Portals & Resources

  * [International portal](http://mudconnect.com/)
  * [German derivative](http://www.mud.de/)

  


## Advantages of Social Games

Social Games have advantages both for the user and the provider.

### Advantages for users

For the user is one of the best causes the social Cooperation: Users play in groups and not alone. They can play together or against each other and also help their neighbors.[27]  
Social games are most very easy to play. For example they can play with their friends on Facebook because almost all own an account on Facebook so they don't have to sign up for a new online portal.  
Yet another advantage for the user is that most of the social games are for free. They don't have to pay money for the registration.  
But if some user likes to get faster to the next level he can also buy with real money some items which are important to get step forward.[28]  
Another advantage is that users play with each other worldwide. Every player can play from his home because of the global networking.  
The most important thing for a user is to have fun on playing, of course.  
Spending just a few minutes a day is enough to get quickly in higher levels.[29] Further advantage is that users have an easy interaction with their friends, with a circle of acquaintances or actually with  
unknowns. Maybe some people contract a friendship with someone in real life.  
  


### Advantages for the providers

For the provider are also many advantages. At first, Social Games are a huge business with enormous profits. That is fantastic for the providers, so they earn a lot of money.  
Social Games are running like a kind of snowball system. In fact all starts with one user who likes a social game. This user canvasses friends by sending a friend request or telling his friends about the game.  
Then one friend also plays the game and in return the player receives the virtual neighborhood. Now they send themselves gifts to get faster in higher levels. This new user acts with the same strategy.  
The world occurrence is very quick and rapid. so the useres accomplish much more person all over the world. [30]  
As mentioned earlier users can buy virtual goods. That is also an advantage for the provider, of course because he earns the money which is spending on it. By advertising circuit most social gaming  
providers also earn money. The advertisement is designed more specific to every single person of the age class.[31]  
The rapid spread of certain games, the company´s reputation increases in the industry. The providers can also use the social games for an certain department in their company, for example in the area of marketing.[32]  
  


### The result for user and provider

Because of the rapid world occurrence the companies will earn much more money and they can spend more for the development of social games and presented new games.  
Rapid developments in technology have resulted in new ways to communicate and socialise.[33] The offer of the games gets higher and that’s really nice for the users because they will have more variety  
of social games.  
  


## Criticism

Social Games can be criticized in a few different areas. These areas are psychology, spam, data and deception.  


But before going into detail there is a famous example of criticizing Social Games that has to be mentioned as well.  


### Cow Clicker

Cow Clicker [34] is a Social Game for Facebook developed by Ian Bogost in July 2010 that originally was supposed to criticize all the other Social Games on Facebook, especially the ones developed by Zynga.  


The rules of the game are very simple. After starting the game the player gets a cow and has to place it on his virtual farm. He can click the cow and harvest it. That’s all the player can do at first because for harvesting the cow again he has to wait 6 hours. After 6 hours the player can click his cow again and also earn some clicks. That’s all there is to do in that very simple game. Interestingly it was a hit. 2 months after its release Cow Clicker already had 50.000 players, who apparently didn’t understand the humorous side of it and became serious players, also investing money into the game to buy extra clicks. To make his point clear, Bogost also placed different cows, at least in their looks, into the virtual market. The new cows were offered for real money but that didn’t stop the players from buying them. In the end, Bogost wanted to bring an end to Cow Clicker and announced the “Cowpocalypse” for July 2011 exactly a year after its release. There was as well a possibility to delay the end of the game by clicking on cows, one click delayed the countdown, or by investing money, 1$ delayed the countdown by one hour. The end of this crazy story was that the players managed to delay the “Cowpocalypse” until September 2011 by investing 700$ and clicking many many times on virtual cows.  


### Psychology

Now, starting with the real aspects of criticizing Social Games psychological methods have to be regarded. Social Games can be compared with the [Skinner-Box](http://de.wikipedia.org/wiki/). In that experiment rats and pigeons were conditioned to press a button and in exchange be rewarded with feed. The parallels to Social Games are very obvious, the player has to click on an object and be rewarded with success in the game. The intention behind this is to bind the players and encourage them to advertise new players by inviting their friends to play as well. And of course this Skinner-Box method is doing the job pretty well as quick success by doing only little clicking makes the players happy.  


### Spam

What is Spam? [Spam_(electronic)](http://en.wikipedia.org/wiki/) is all the unwanted messages and alerts somebody receives.  


In case of the Social Games, for example on the platform Facebook, members who do not play any Social Games have friends on their list who do play them. These friends sometimes automatically, sometimes deliberately post game alerts on their walls. Users who turn on their social network and check out the news of their friends automatically are confronted with a long list of game alerts. Sometimes this can work as a advertisement and can allure non-players to play the game. But all the others who strictly don’t want to be annoyed by these posts have to block all the social game applications one by one so they won’t see any of their posts.  


But even if the non-players decide to play the Social Game, the spamming doesn’t stop. It only turns to “social-spam”, that means friends are no longer just friends but a way to improve the game success of oneself. Friends are regarded as “game neighbors” meaning they are resources to be exploited.  


### Data

The abuse of data is a whole different and serious story. Every player of Social Games has to accept, before being able to play, their terms of usage. In most cases that means the application has access to the players personal data like name, birthday, relationship, interests and so on. This data can be used to fade in advertisements that interest the players so they are allured to click on them. The data is also transferred to the company of the certain Social Network so they can as well collect information about their users.  


Another problem of these advertisements is that sometimes they are X-rated and thus the underage users are not protected enough as for example Facebook allows memberships beginning at the age of 13.  


### Fraud

The innocent appearance of Social Games is used by criminals as well. They mock an add of a Social Game but behind that add the clueless user is lead to a [Phishing](http://de.wikipedia.org/wiki/) website. On that website the criminals try to allure the innocent people to pay for all kinds of things but normally there is nothing behind those promises. Social Games represent a perfect method for phishing as there are millions of fans.  
  


  


## Dangers of Social Games

### Social Gaming Addiction

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/ab/Maslowsche_Bed%C3%BCrfnispyramide.png/220px-Maslowsche_Bed%C3%BCrfnispyramide.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Maslow's hierarchy of needs: Many addicts are trying to satisfy their basic psychological needs in social games.

In general social network games contain a high potential for addiction especially real-time games like Farmville.[35]

Most theories of social gaming addiction still focus on built-in reward systems to explain its causes although it is known that players play for more reasons than fun alone. So it is believed that social games satisfy some basic psychological needs and users play these games by reason of boredom, a feeling of freedom or a connection to other people.[36] Social Games promote not only a strong collective feeling, by cooperation and the joint handling of group tasks, but also competition between players and their friends. It can be said that the stronger the social environment, the higher the potential for addiction.[37]

According to experts, psychological problems like anti-social personality, depressions or social phobia also promote social gaming addiction,[38] which might be explained by the fact that many addicts try to escape from ordinary life including their problems. In a virtual world created by such games, they become confident and gain satisfaction, which they may not get in daily life. As a result of new friends and rising influence in-game they like there virtual life more and more than reality.[39]

Moreover, existing approaches consider neurobiological and learning theory mechanisms. The main cause of addictive behavior here is the positive experience with these games of those concerned. According to that theory learning processes in human brain are responsible for the maintenance of excessive gaming.[40] In this case games are played for the reason of repression of negative emotions, worries and stress. This leads to reinforcement of behavior, because a negative emotion like loneliness is offset by playing these games. Additional there is a dramatic increase in the likelihood of repetition. Therefore, learning theory mechanisms linking games with relaxation and escape from ordinary life, despite the possible negative consequences like loss of employment. That would mean an improper use, because players play no more for the reason of amusement, but to compensate negative feelings. If there is additionally a lack of alternative coping strategies the potential for addiction is increased.

Furthermore, human emotions like fun, happiness, might and excitement also play an important role in development of an addiction.

### Expense factor

Although social games on Facebook obvious free-to-play, Zynga a social network game development company has sales of close to 250 million US Dollar.

One of the reasons for this must be the principle of social games, whereupon regular usage is free, but players can buy additional content, items and features for a game by credit card or Paypal. These items are particularly popular among players and often act as prestige objects.[41]

This is where extra care is needed, because some players in the USA apparently become victims of doubtful debits. Therefore, Consumer protection agency recommends users to regularly check their bank account movements.

In addition, in the form of a class action of a U.S. law firm, Facebook and Zynga were accused to have a 'fraudulent business model'.[42] Accordingly, players are lured through completion of questionnaires to earn additional points. Their evaluation is then communicated via SMS. By divulging the phone number, users subscribe to a fee-based subscription, even without knowing or wanting to. The same applies to the IQ tests of the company; their results are also communicated via SMS and causes partly high, unplanned, expenses.

As a result of the scandal, Facebook removed about 100 such applications at the end of 2009.

### Data transfer

To be allowed to play social games on Facebook users have to confirm a read access to their profile data and their friends list in the form of Zynga's General Terms and Conditions.

It is not known what kind of information Zynga collects and how long they remain in the company. According to the company's own information, these data are used for personalized advertising.

This approach is very controversial, at least from the perspective of German law.[43]

## Assignments

### Ex.1: Social Network Games

Read the social network game article in Wikipedia [9], follow some of the game links mentioned there and see if one or another interests you. In your blog, either write about a social network game you have already played, or about your experience just trying one for fun.

### Ex.2: What makes Games successful

Jesse Schell looks at many different games and finds interesting commonalities, he also draws interesting conclusions about ’When games invade real life’: www.ted.com/talks/jesse_schell_when_games_invade_real_life.html (28:19) Do write about his talk in your blog.

### Ex.3: MMORPG

Read the two Wikipedia articles on MMORPG [7] and World of Warcraft [8]. If you have experience with MMORPG please write about it in your blog.

### Ex.4: Second Life Founder Philip Rosedale (optional)

If you like to know a little more about Second Life and its founder, watch this video on TED: ( www.ted.com/talks/the_inspiration_of_second_life.html) (28:27)

### Ex.5: Psychology of Gaming (optional)

There are many talk on the psychology of gaming, a nice discussion is the following: Your Brain on Games: The Hidden Psychology of Gaming, (www.youtube.com/watch?v=AnRq1up3E2s&feature=related) (56:11)

  


  


# Teaching and Learning

As we have seen already in the first class, the revolution that is currently under way is not only restricted to the net, but is also entering the class room. Let’s see how teaching and learning are affected by the social web and its technologies.

## Learning Styles and Multiple Intelligences

Each person is different, even in the way how to learn things best. The educational psychologists have discovered this already in the 70s and developed a concept with different learning styles [44]. In total there are over 80 learning styles which are all a bit different.

Well-known models are:

### Neil Fleming's VAK/VARK model

Fleming distinguished four basic types of learners:

  * Visual learners (learning by seeing)
  * Auditory learners (learning by hearing)
  * Reading- or writing-preference learners (learning by processing text)
  * Kinesthetic learners (learning by doing, by motion)

### David Kolb's model

  * **Convergers** are characterized by abstract conceptualization and active experimentation. They are good at making practical applications of ideas and using deductive reasoning to solve problems.
  * **Divergers** tend toward concrete experience and reflective observation. They are imaginative and are good at coming up with ideas and seeing things from different perspectives.
  * **Assimilators** are characterized by abstract conceptualization and reflective observation. They are capable of creating theoretical models by means of inductive reasoning.
  * **Accommodators** use concrete experience and active experimentation. They are good at actively engaging with the world and actually doing things instead of merely reading about and studying them.

### Honey and Mumford's model

  * Activists: Having an experience
  * Reflectors: Reviewing the experience
  * Theorists: Concluding from the experience
  * Pragmatists: Planning the next steps

### Howard Gardner's theory of multiple intelligences

Gardner's theory [45] has evolved out of the conviction that traditional intelligence tests are not sufficient to identify and promote skills.

Initially he distinguishes between seven intelligences:

  * **Logical-mathematical**: People who are able to recognize abstract patterns, to think scientifically and have the ability to perform complex calculations.
  * **Spatial**: People possessing a spatial judgment and be able to visualize with the mind's eye.
  * **Linguistic**: People who are usually good at reading, writing, telling and memorizing. Those people learn foreign languages very easily as they have high verbal memory and recall, and an ability to understand and manipulate syntax and structure.
  * **Bodily-kinesthetic**: The core elements of the bodily-kinesthetic intelligence are in control of one's physical movements and the ability to handle objects skillfully.
  * **Musical**: People who have a sensitivity to sounds, rhythms and music.
  * **Interpersonal**: Interpersonal intelligence is the ability to understand others. In other words the people who have a high degree of interpersonal intelligence and a sensitivity to foreign moods, feelings, motivations and an ability to distinguish cooperation.
  * **Intrapersonal**: People who are able to reflect about themselves and identify their strengths and weaknesses. Philosophical and critical thinking is common with this intelligence.

### How to reach different types of learners?

When you see how many different types of learners there are, it quickly becomes clear that the traditional teaching methods can only reach a fraction of the students. At this point the Web 2.0 offers many more possibilities. Students have the opportunity to actively shape content and get involved. A short summary which tool for which learning type suits best can be found under [46].

## Khan Academy

The way teaching is done in schools and universities is all wrong. ;-) When a teacher gives a class or lecture he or she is actually doing a broadcast. The students are supposed to be quiet and listen. However, this is not using any of the group dynamics, group learning that could be leveraged here. On the opposite side, homework and assignments are done at home, when the students are alone and have no help available when they might need it. Thus it should be exactly the opposite way round, do the homework in class, and watch the lectures at home. This is what Mr. Khan [9] is telling us, and it seems Bill Gates agrees with him.

### Activity:

Watch the following video on TED: ’Salman Khan: Let’s use video to reinvent education’ (www.ted.com/talks/salman_khan_let_s_use_video_to_reinvent_education.html).

Please discuss the video, and write about what you think of it in your blog.

## Open Source Learning

### Connexions

Connexions is a dynamic digital educational ecosystem consisting of an educational content repository and a content management system optimized for the delivery of educational content.[13]

The content is structured as a standalone modules, so that others can easily use the tools provided by the platform to combine them into collections and context, specific to a certain class. These custom collections are specially designed to meet the needs of their students.

This is the advantage of Connexions to another creative-commons platform - "frictionless remixing". Another great thing about this side it, that it can be used as pdf, as online library, books can be orders in a printed form and by cutting the middle man - publishing, they cost less.

Everything is published under the creative commons licence. A global community of authors continuously converts and adapts information in the Connexions repository. Connexions promotes communication between content creators and provides various means of collaboration through author feedback and shared Work Areas. Collaboration helps knowledge grow more quickly, advancing the possibilities for new ideas from which we all benefit.[12]

### Udacity

Udacity[18] is a private online academy which makes it possible to attend free lectures and tests. So far, all the course topics are in computer science and programming. The good thing is that the lectures are not just filmed, but the students are always asked questions about the recently explained, to which they can then enter the solution directly on the screen. Depending on whether the answer was right or wrong, the video goes further then. If there is a wrong answer for example, then it is explained how you get to the correct solution.

In addition, there is a discussion forum where you can ask questions about courses, or get advice from other students.

The courses are spread over 7 weeks and end with a final exam that extends over the thematic content of the whole course. In Germany students can pass the exams at a real university in some cases and get a very regular confirmation.

The founders of Udacity, Sebastian Thrun, and David Evans wanted to democratize higher education with their online portal and provide education for all, regardless of race, wealth, age and gender.

Udacity now is financed through sponsorship and working with people from academia and countless volunteers.[47]

## Podcasts

Not only Feynman’s lectures are now available online, but many, many more. As it turns out iTunes, YouTube and others has an incredible number of free high quality lectures available.

On iTunes you find podcasts for children, but also lectures from universities:

  * Wissen macht Ah!, itunes.apple.com/de/podcast/wissen-macht-ah!-zum-mitnehmen/id211720164
  * Grundlagen digitaler Medien, K-U. Barthel, itunes.apple.com/de/podcast/grundlagen-digitaler-medien/id252560499#

Stanford, MIT and others have channels on YoutTube with their course offerings:

  * Stanford, <http://www.youtube.com/user/StanfordUniversity/featured>
  * MIT, <http://www.youtube.com/user/MIT>

There are search engines specialized to listing / finding open course ware:

  * Academic Earth: Online courses from the world’s top scholars, <http://academicearth.org/>
  * Coursera, <https://www.coursera.org/saas/auth/welcome>
  * OCWSearch, <http://www.ocwsearch.com/>

But not only courses are offered, but also research seminars, as for instance

  * Human-Computer Interaction Seminar (2009-2010), <http://www.youtube.com/view_play_list?p=F4A01617834A0FB6>

Finally, as we have seen already, also conferences become available to the public, as for instance is TED:

  * TED, <http://www.ted.com/>

Another new thing is Udacity, coming out of Stanford. They believe university-level education can be both high quality and low cost. Using the economics of the Internet, they have connected some of the greatest teachers to hundreds of thousands of students all over the world:

  * Udacity, <http://www.udacity.com/> (also at <http://www.golem.de/1201/89251.html>)

## Moodle

Many schools have Moodle [10] as a Course Management System. Its typical features are [9]

  * Assignment submission
  * Discussion forum
  * Files download
  * Grading
  * Moodle instant messages
  * Online calendar
  * Online news and announcement (College and course level)
  * Online quiz
  * Wiki

## Web Conferences with Adobe Connect

Adobe Connect [6] is a web conferencing tool that uses Flash and runs in a browser. It is relatively straightforward to use and has an excellent audio and video quality, especially in conferencing mode. Alternatives are Skype, but conferences have a very poor quality last time I tried.

### Activity for Participants:

Watch the video ’Attending a meeting’ (tv.adobe.com/watch/learn-adobe-connect-8/attending-a-meeting/) to get an idea on how to use Adobe Connect as a participant. Help can be found here <https://www.vc.dfn.de/webkonferenzen.html>.

### Activity for Presenters:

  * Overview of all tutorials: <http://tv.adobe.com/show/learn-adobe-connect-8/>
  * Creating a meeting: tv.adobe.com/watch/learn-adobe-connect-8/creating-a-meeting/
  * Recording a meeting: tv.adobe.com/watch/learn-adobe-connect-8/recording-a-meeting/
  * Sharing screens and applications tv.adobe.com/watch/learn-adobe-connect-8/sharing-screens-and-applications/
  * Sharing PowerPoint presentations: tv.adobe.com/watch/learn-adobe-connect-8/sharing-powerpoint-presentations/
  * Using VoIP audio: tv.adobe.com/watch/learn-adobe-connect-8/using-voip-audio/
  * Sharing Flash content: tv.adobe.com/watch/learn-adobe-connect-8/sharing-flash-content/

For public universities in Germany, the DFN (Deutsche Forschungsnetz) (<https://webconf.vc.dfn.de>) provides accounts to be used for online classes.

## Gamification of Teaching

Today, students are expected to pay attention and learn in an environment that is completely foreign to them. In their personal time they are active participants with the information they consume; whether it be video games or working on their Facebook profile, students spend their free time contributing to, and feeling engaged by, a larger system. Yet in the classroom setting, the majority of teachers will still expect students to sit there and listen attentively, occasionally answering a question after quietly raising their hand. [15]

Gamification, if handled properly, could be what is needed to make the classrooms more supportive of creativity while still teaching traditional academics.

### What is gamification?

Gamification is the concept of applying game-design thinking to non-game applications to make them more fun and engaging. [14] There are two ways games can be included in training regardless of whether they are instructor led or computer based

  * Gamifing the course(s) or parts thereof
  * Creating a game for the course(s) or parts thereof

Depending on how much game like features are required, one or more of the following can be done. [16]

  * Add points to tasks that need to be completed
  * Define badges/rewards to be given out after a criteria is met
  * Create a Leader board to show top performers
  * Define levels to repeat tasks or to perform harder tasks
  * Earning of badges can be tied to unlocking higher levels

Instead of only getting grades students get experience or points. At a later time they can use this points to "buy items" - for example "one free pass at a wrong question". Applying the multiplayer principle from games - a group of people work for a common goal, students are not competing against each other, but helping - because if one person gets the "high score" on the exam, they all get a "goodie"...

Mr. Pai [16] is an elementary school teacher. For his 3rd graders in math and reading he has created a website, where he posts links to easy and fun games, related to his class. The games are online games, that the kids play against kids from other countries. He is tracing the progress of every student and grouping them to help each other learn faster. This way kids learn multiplying, fractures and other math problems using fun games with names like - Flower Power. In only four months Mr. Pai's class went from being bellow 3rd grade average to above 4rd grade average.

## Coursera

Three IVY League colleges - University of Pennsylvania, Stanford, Princeton and the University of Michigan gather in the online platform Coursera and offer courses from world-class professors, that are free and open to use from everyone.

This site isn't like your average library of videos about interesting topics, it is actually a course, you can sign in to do, with professors from top universities. The course videos are not long lectures, that have been recorded, but are short video segments, which are easy to process, without losing concentration.

When you join a Coursera class, you’ll also join a global community of thousands of students learning alongside you. At any time, you’ll be able to ask questions, make suggestions, and get feedback on course topics from both peers and experts in the field. This community using the site organizes study-groups, discussion boards etc, and it is really easy to ask any class related question any time of the day.

And since this is an online class, they may even be the possibility of getting credits at your university for those courses - "Some students who are currently enrolled at other universities have been able to get credit for taking these courses at their own university (sometimes as individual research units). If you are a currently enrolled student, you might want to check with your university to see if this is an option." [17]

  


### E- Learning

eLearning is the big buzz word used in the context of teaching and learning in the Web 2.0 era. It has received a lot of hype, but if you look at it critically, it has failed the expectations, mostly. Because it fails to focus on the social aspects of learning.

Most of us are social beings, with the exception of a few hermits. That means everything we do, we like to do in groups. And at least since the days of Plato [4] teaching and learning was a social activity, where teachers and students meet at a given time in a given place to learn about a certain subject.

However, eLearning does have its little niche. It does solve the problem of two scarce resources:

  * good teachers
  * time

The Nobel laureate Richard Feynman was said to be one of the best teachers. Unfortunately, only very few students at Caltech had the luck of attending his lectures live. Fortunately for us, they have been recorded and made available [7], hence now everybody can listen to the best physics teacher.

In today's information society is to convey knowledge of paramount importance. E-learning acquired in addition to traditional teaching and learning opportunities a growing influence. This applies not only to the university context. In economic terms, the e-learning market in Germany point to strong gains. For example, increased the total revenue from e-learning industry, according to survey by the MMB Institute for Media and Competence Research in 2007 to around 139 million euros, representing an increase of about 15 percent compared to last year. Overall, e-learning is on everyone's lips. But what means e-learning at all?

### Definiton E- Learning:

The literature contains different definitions of this term. The following should be understood as e-learning teaching and learning through various electronic media. For e-learning are found to be synonymous terms include: on-line learning (online learning), distance learning, multimedia learning, computer-aided learning, computer-based training, Open and Distance Learning. Since the definition of e-learning has not yet been covered a widely accepted definition, they tried e-learning to be described by different facets. Multimedia, Multicodalität, multimodality and interactivity.

### E-learning and related technology

E-learning can be based on very different technologies and are implemented in different educational scenarios. Are often discussed the following options:

## Web-based training and computer applications

The term CBT (Computer Based Training) is the work of learning programs (educational software), the learner can be used flexibly in time and space, and where learners are not in direct contact with the teachers and other learners. These programs can include educational multimedia content (eg animations or video documents) and are usually distributed on CD-ROM or DVD. In CBTis a form of e-learning, where the self-study is more important then communication, if any, takes place in an asynchronous manner. CBT has been around since the 80s. For older computer-assisted learning systems, there are also a variety of other names. For example,. are the CAT (English: Computer Aided Teaching), CAI (Computer Aided Instruction and Computer Assisted Instruction) and many more. The basic building block of network-based learning opportunities is the so-called WBT (Web Based Training) - a development of the CBT. These learning units are not distributed on a disk, but accessed by a web server online via the Internet or an intranet. The embedding into the network provides a variety of advanced methods of communication and interaction of the learner with the teacher / tutor and other learners. Thus, mail, news, chats and discussion forums associated with the WBT and audio and video signals are streamed live. A further development of the WBT towards a more communicative use the learning platform. It supports different types of communication, such as Chat and forums, so as to encourage the users of the learning platform for direct exchange and application of the learned (eg, Babbel (software)).

## Simulations

Simulations are models, which depict important features of the real world trying to get students through free or targeted experimentation or observation of knowledge on structural or functional properties of the original convey. Complicated issues and processes of reality can thus be simplified and reduced to the essentials are presented, especially when real experiments are too expensive or too dangerous.

## Video conference / distance education

The videoconferencing creates virtual classrooms by geographically distributed students and lecturers can communicate with each other. To be known as distance education version of the e-learning is mainly characterized by the transmission of image and sound. It allows for the classroom teaching similar communication between teachers and learners who can rely on verbal statements as well as to gestures and facial expressions. The distance education is limited by the relatively high technical requirements. With increasing bandwidth of Internet connections new technology eVideo formats develop.

## Learning Management Systems

As a learning platform (English Learning Management System, LMS) systems are known that can support the on-line and / or classroom courses to complete (or parts of) the work flow of the event management of accounting processes, teaching and learning processes to the resources administration.

## Learning Content Management Systems

The purpose of an LCMS (Learning Content Management System) is to create, reuse, locate, finishing and delivery of learning content. The content is often kept in a central repository in the form of 'reusable' learning objects (RLOs). Objects can be referenced by several different courses, so that in case of a one-time adjustment only change needed to bring all incarnations up to date. The LCMS has (as opposed to authoring tools) via a user management that allows different people and groups to assign certain rights so that, for example, for subject-matter experts, media designers, project administrators have different access functions defined / can be realized. A multi-user functionality allows you to manage concurrent access, so that it can not happen that two users can simultaneously carry (contradictory) changes to the same object. Furthermore LCMS have usually have a version control that allows to track changes made. One of the most important tasks of an LCMS is to support reusable learning objects (RLOs). The goal is to prevent unwanted redundancies and conflicting information widely.

## Content catalogs

Content catalogs support the exchange of learning objects - from complete courses to raw materials. Provider can specify range conditions. Requests are documented and, if charged. These catalogs are often very specific to a particular grade (in this case higher education) are aligned.

## Digital Learning Games

The concept of educational video game refers to games that are in a hard-and software-based virtual environment and place the desirable to encourage learning. Digital learning games are typically used in education and training system. They are indeed, as entertainment-oriented computer game "fun" too, is their primary goal, however, the acquisition of knowledge and skills.

  


  


### Forms of e-learning

## Virtual Education

Virtual teaching called teaching that is conducted primarily through the Internet and does not include significant amounts of classroom teaching. The spectrum of presentation forms of virtual teaching include webinars, web-supported textbook courses, hypertext courses (eg text books, multimedia, animations and exercises), video-based courses (eg lectures, including slides) or audio-based courses and podcasts. Since virtual teaching as opposed to classroom teaching and "blended learning" is little opportunity for direct interaction, teachers and students often use to communicate electronic media such as chat rooms, discussion boards, voice mail or e-mail or special platforms. Virtual Education plays a growing role in the context of the introduction of further fine-line master's degree programs at many universities.

## Blended Learning

If the benefits of classroom events are linked with those of e-learning, it is called blended Clearing. Blended learning combines both forms of learning in an54 common curriculum. Blended learning is used, in particular, if in addition to pure knowledge and the practical implementation is to be trained (eg in health and safety).

## Content sharing

There are now websites that allow you to exchange learning units. Such initiatives exist as a commercial or free offers. An example of a commercial initiative is UNIDOG.DE - here are monetary incentives for the preparation of teaching content set. This should increase the quality of the published notes, flashcards or summaries. As a typical example of a non-commercial forum for example can the Student Council Forum for Business Engineering at the University of Duisburg-Essen used (Wiing-DU). Even with such local initiatives, often shows a high demand, as documented by traffic-Wiing show you as an example.

## Learning Communities

Groups have the same goals and / or professional interests, to build an information and communication system is a common knowledge base. Each member of this learning community can contribute their own knowledge and thus the knowledge basis of common learning processes and adapted.

## Computer-Supported Cooperative Learning

Computer-Supported Cooperative Learning (CSCL) describes approaches to learning, which is supported collaborative learning through the use of computer-based information and communication systems.

## Web-Based Collaboration

The term Web Based Collaboration describes the cooperation of a learning task of a group of people over the Internet.

## Virtual Classroom

The Virtual Classroom is used the Internet as a communication medium to connect geographically separated students and teachers together. The virtual classroom allows thus a synchronous form of learning. A extreme form of the distance learning is Tele-Teaching.

## Whiteboard

A whiteboard is like a blackboard or a flip chart. Users have the ability to create a network to share and view sketches. These are both Zeichen-/Mal- and text tools at your disposal.

## Business TV

Business TV is a precisely tailored to the television audience. Business TV is a very effective way to stimulate a group (employees, suppliers and customers) to learn.

## Microlearning

When it comes to micro-learning learning in many small learning units and short steps, often through web or mobile phone.

## Modular process visualization content within the e-Learning

This is a visual representation of teaching units with the aim of a cognitive process - which can lead to new knowledge - prepare step by step in film, image, text and sound.

## 3-D infrastructure platforms

Increasingly, 3D infrastructure platforms such as Second Life and Twinity gain in importance for e-learning applications. Due to the nature of these virtual worlds experience a very high degree of immersion is achieved. This is intended to a correspondingly higher learning efficiency, because games are growing together and learning. Through simulated worlds of experience you can now immerse themselves in these situations and experience. A high level of immersion (virtual reality) is achieved, inter alia, if the user enters a strong identification with their avatar and the user feels as part of the world. Thus, the term is extended by the concept of Action Learning e-Learning action. Another significant advantage of the networking team in virtual worlds is to see where teams need to interact seamlessly, for example, in actions by the police, fire and rescue services, etc. The parties may now log in from anywhere in the world and regularly in scenarios a virtual world through play. In particular orientation training can be conducted in more frequent and regular intervals, which can increase the effectiveness and efficiency of such operations. The foreign language learning, according to an employee of Linden Lab, the most common form of education in Second Life.

  


### Advantages and disadvantages of e-learning

Some advantages of e-learning are so obvious: The overcoming of geographical boundaries and time-and location-independent learning is enabled. Thus, the e-learning ensures that content is delivered to date and complete. The learner can be divided his time freely and develop their own learning pace. He can access it from anywhere - whether from home or from work. It eliminates the transportation cost for tuition.

But a well-known proverb says: "Where is light, there is shadow." E-learning also has to contend with disadvantages. First, it requires the learner to an even higher degree of self-discipline and personal responsibility than in the case face learning. There it is because of the class structures and the roles of student / teacher there are strong liabilities. In addition there are for example complaints about the lack of presence effect "that critical, intersubjectively-established cognitive and communication routines on non-and para-verbal signals are processed, are not available.

  


  


## Critical Look

At this stage let us take a critical look at our own class. Are the tools really helping us to learn? Are we not just wasting time? Is it because we have this beautiful golden hammer, that everything we see looks like a nail to us?

### Activity:

Start a class discussion. List all the tools you have been using and tell us what you think helped you and what is just a waste of your time. Thinking of Mr. Khan’s talk, what might be more effective. Would you prefer a classical lecture (one-to-many) type scenario?

  


## Assignments

### Ex.1: Evaluation: MeinProf.de (RateMyProfessor)

Please go to the website MeinProf.de and register if you have not done so. Then look for this course and rate it.

### Ex.2: Evaluation: GoogleDocs

The evaluation for this course will be done with GoogleDocs. Follow this URL to fill out the evaluation from for this course. Note that the questionnaire is anonymous.

### Ex.3: Adobe Connect

Schedule a meeting time that is suitable to most of the class using Doodle [5]. Also from your instructor get the URL to connect to for the web conference. Attend the virtual class and explore the possibilities. Talk about your experience and how you feel about virtual classes in your blog.

### Ex.4: Stanford’s ’Introduction to Computer Science’

Take a look at the Stanford course ’introduction to computer science | programming methodology’ (see.stanford.edu/see/courseinfo.aspx?coll=824a47e1-135f-4508-a5aa-866adcae1111). Watch a few of the videos and be amazed how Mehran Sahami mesmerizes his students.

### Ex.5: Virtuelle Hochschule Bayern

The ’Virtuelle Hochschule Bayern’ [11] is the possibility for any registered college or university student in Bavaria to take online courses and get credit for it. If you have not done so, take a look at their website, and look for classes that might interest you. List those courses in your blog.

### Ex.6: Web 2.0 and Emerging Learning Technologies (optional)

Take a look at the wikibook ’Web 2.0 and Emerging Learning Technologies’ started by Curt Bonk [8]. It discusses many aspects related to learning with the technologies.

  


  


  


  


# Corporations and Marketing

If you expect to read about how companies can make lots of money using the social web here, you have come to the wrong place. There is tons of good books on that subject, so no need for another one. Instead we learn a little about new ways to raise and save money, and a few facts about marketing in the social web.

  


## Amazon and eBay

To get started, let us take a look at two giants: Amazon and eBay. Although, they are not really social web companies (rather Web 2.0 companies), despite their size, they also rely in one critical feature on the social web:

  * A core feature of Amazon is their customer reviews created by customers. Many users read those to get a feeling for the quality of the product.
  * Can you trust a seller (or buyer) on eBay? The eBay reputation system usually gives the answer. Again, this system relies on users giving evaluations.

Both of these features are an important part of the continued success of these companies.

Aside: How do you evaluate a company (startup)? Well, Google took $13 per user per year and multiplied it by the number of users. Hence, for Flickr’s 2 million users that made about 26 million dollars and that’s what they got paid by Yahoo (almost).

### Activity:

Can you think of another example, similar to the customer review or reputation system above?

  


## **Crowdfunding**

Crowdfunding is a way of raising money for financing a certain project , usually initioned on the world wide web. These projects, as certain instances reveal, can be of any type but they always appeal to an artistic motivation.

The variety of those projects span music- and filmmaking but also game- and appdevelopment. Especially the latter one, gamedevelopment gained most recently the most attention due to the invocation for a new Point and Click Adventure Game by famous Game Designer Tim Schaefer and his company Double Fine Productions, who got four times as much than he originally asked for.

### Background

Crowdfunding is a term that hasn't been used a few years ago but started gaining popularity by 2006 and kept growing after that. Back in 2000 Brian Camelio, a music producer created ArtistShare.com that was trying to invoke the music industry to prosecute against piracy and have against it laws digitally manged. Six years later the first real crowdfunding platform was created, called SellaBand.com and encoureged fans of indipendent music to support new upcomming Artists. One of them was Nemesea who found enough supporters to record their debut album "In Control" and many more Bands followed.

Olthough Crowdfunding was supposed to help Newcomers to make a first step in the business, many already established artists and performers apply to their fans to get direct support. For instance the famous Hip Hop Act "Public Enemy" tried to raise some money over SellaBand.com to produce their new record. Unfortunately the platform announced 2010 bankruptcy and the band had to correct their target sum.

An other more fortunate example of crowdfunding was famous Stand Up Comedian Louis C.K.'s attempt to sell one of his latest stage shows on DVD directly to his fans, not having any publisher involved. He completely produced and recorded his stage performance himself and eventually offered a DVD copy of it for only 5 $ via twitter, facebook and paypal to his fans. This Way he made much more money with this direct and "non-professional" disposal than he would have made if he assigned a publisher. A publisher would have charged the consumer 5 times as much money and the actual performer only would have gotten a small percentage of the whole business volume.

### Kickstarter

Asking people or fans for money over social Networks or blogs is one kind of crowdfunding but there are also special platformes, only designed to raise money over the web. SellaBand was one of them but only limited to musicians. Right now kickstarter.com, which was created in 2008 is the most popular crowdfunding platform that can be used to invoke any kind of artistic project. The most popular instance was Tim Schaefer, famous Game Designer who worked on several Adventure Games by Lucas Arts, Psychonauts and Brütal Legend, who couldn't find any publisher to finance his ideas for a new Graphic Adventure Game and that way appealed to the fans to finance the production of the game. Originally he asked for 400.000 $ and eventually earned outstanding 3.3 Million $.

As a special feature the amount of money is categorized: the more you donate the more extras on the endproduct you get. Starting by getting a free download link to the final game over autograms and and documentation meterial up to being credited in the game.

### How Kickstarter works

Kickstarter.com is not an altruistic platform which means, that sucessfully reached amounts of money are not fully going to the original fundraiser but 5 % of the sum goes to kickstarter while another 3-5% flows to amazon payments that is responsible for the actual money collecting. Also not every project is approved but can be declined if it doesn't meet certain requirements in terms of reliability or national laws. Therefore fundraisers are supposed to describe their ideas for their project in order to get approved but more importantly to convince the potential donators. Also a certain amount of money has to be defined that must be earned within a given deadline.

Only if the target sum is reached in time, money is eventually being charged by Amazon Payments which means that the donators don't advance money on loan until the deadline is over. It's kind of like a promise saying "This is how much I'm willing to spend". This way no money has to be retransfered if the whole funding call wasn't successful.

Also kickstarter.com only registers crowdfunders with an american bankaccount which means foreign people would have to meet certain additional rules of action in terms of international laws.

### Criticism

The most notable thing about kickstarter is that it's either well known funders or popular brands (at least for special fan circles) that tend to come out quite successfull on kickstarter while unknown private people with completely new ideas are badly off trying to get their projects funded.

People like Tim Schafer are known and respected by a lot of fans for their work in the past and use their names to advertise their new ideas. On the other hand popular brands like videogame franchises that have been quite successful back in old days but haven't experienced any new sequels for a long time and are strongly desired by the fans are usually good arguments to get money raised. But if yor're neither a famous developer nor you have an old established brand to revitalize it's hard to convince people or more importantly to reach them with your message. That's why there are also lots of "epic fails" on kickstarter with funding projects that came out with embarrassing low numbers, even a "0".

Apart from this dilemma many main publishers critisize those crowdfunding platforms for thinking they are comepletely better off without them. While using crowdfunded money developers are completely free to unfold artistically without meeting any compromises in terms of design and content. Publishers critisize those people for thinking leading producers would only corrupt the developers' efforts.

## Collaboration to Save Money

Another interesting aspect of the social web, is that people use it to save money. It kind of started with eBay, where you could get rid of your junk for money. But it turns out you can’t sell all you junk on eBay. But how about trading your junk for other people’s junk? Well, that’s the idea behind Online Bartering.

### What is Online Bartering?

Bartering is a very simple and today more and more popular swap business. Everybody knows this situation: kids in school swap their lunches. They swap cookies for chocolate or the vegetable for an apple with another kid. Exactly this phenomenon describes bartering!

Trading own things or services without needing money is called bartering. You can barter used objects, like second-hand-clothes or toys from your children, you can barter self-made work, like designed art or you can also barter services, like cleaning a room or painting a car. The principle behind barter, is that somebody offers a thing, he don`t need and somebody else, who is interested in this thing, can offers you something that you want. This is a very good alternative to all the money-based systems like ebay, amazon or any other webshops.

The idea of bartering becomes generally known by a guy named Kyle MacDonald. He arranged the craziest internet-barter-deal. "MacDonald bartered a single red paperclip to a whole house in a series of 14 online trades over the course of a year."[48]

A important part of this trading is the value of the products or the services. How much the trade-object is of value is relative and depends on somebodies personal relationship to this object and his preferences.

### Advantages

The Bartering is not only good for the Users. Also, it`s good for the government and the general population. Because of the no-money-deal, there is no fluctuation in the value of money.

For example, while an apple costs 50 cent 5 years ago, it may cost 1 euro this year.[49] These means disaffection and diversity for the economy. This is why people should do bartering: You don`t deal with money, you only deal f.e. with your services.

These services are the second big advantage. Poor people, families, students etc. haven`t much money to pay for professional job performance, like installing the computer or repair the washing machine. But somebody else is very good in this job. And this one for example need someone, who repairs his car or bakes a birthday-cake. So you don`t have to pay money, you only pay with services your good at.

The problem in finding a proper deal-partner is much more easier in the internet. Because there is no geographical limit and you can deal with international people. The transport in another country is no problem, today. So you have a brighter audience as for example on a garage sale.

So, A bartering network is a service to find someone who is interested in what you have and at the same time finding someone who has what you want. And this with international people, but without geographical barriers. So this is very helpful for you.

### Disadvantages

One disadvantage is, that you need a lot of time and work to make a good deal. So you have to find a good product or service to deal and then you have to find the perfect partner for this barter-trade. You need someone, who search exactly this product and is up to make a deal with you. And the third part is, that he also has to offer you a thing, that you need and you`re interested in.

Another disadvantage is the problem with unfair deals. It`s very difficult to find a deal-partner, who has a barter-object with the same value as your object. So the risk is, that you have to change your 50€ picture with a 25€ bag, because you don`t find anything else you like in this 50€-price-league. This means, you have to be a little flexible and you should accept, targeting a more prized product with a lower prized, but usually for you important product.

But this is the principle behind the no-money-system. It`s not about an exactly 1-to-1-deal, it`s more about the idea: “I have something you need and you have something I need, so let us deal!”

### Examples

There are many examples of popular branding-sites in the internet. Here`s a little abstract:

  * Craigslist (<http://www.craigslist.org/about/sites>): You can choose a city nearest you and then look, what other people offers there. You can find things like jobs, holidays or antique furniture. But attention: There also deals, with a fix price, so you have to pay sometimes.
  * CareToTrade (<http://www.caretotrade.com/>): They advertise with the slogan “What you want for what you`ve got”[50]. It`s a free platform for service providers.
  * Swap Market (<http://market.swap.com/>): This is a Site, where people can turn what they have into things they need. This swapping is for free, you only have to pay for the postage, if you sent your package away. But you have also the opportunity to pick up the product at your dealing-partners home.
  * HelpBuddy (<http://www.hbuddy.com/>): Help Buddy is a social bartering network specially for students. There`s a blog, where you can post what you have and what you need. One positive thing about HelpBuddy is, that it is all private. For example you can give private lessons in math or help a new student to move in his apartment. So this is a big social effect and you can easy find friends on your campus.

## Social Media Marketing

If you have a product or a service you want to market it. There are many channels, but social media have become very interesting in this respect. Traditional are ads placed in Google’s search or on Facebook. More subtle is what is called viral marketing.

### Activity:

  * The following commercial was originally intended to be shown at the 2011 super-bowl. However, Volkswagen placed it a few days before on YouTube. Through word-of-mouth (viral) it spread very quickly: The Force: Volkswagen Commercial, (www.youtube.com/watch?v=R55e-uHQna0)
  * In case you haven’t seen it, there is a funny take on viral marketing: look for ’Todesstern Stuttgart’ on YouTube (in German)

However, social media also can easily turn against a company. So happened to Dell in 2004. More about the so called "Dell Hell" in the next paragraph about Social Media Monitoring.[6][10].

Naturally, a company should be present in as many social media channels as possible, not only for advertisement, but also for communication with customers. A nice example is the Social Media Buch [11], which can be found under:

  * <https://twitter.com/#!/SocialMediaBuch/following>
  * <http://socialmediabuch.com/>
  * <http://socialmediabuch.com/blog/>
  * <http://www.youtube.com/user/SocialMediaBuch?feature=sub_widget_1>

Hence, besides the traditional ways of internet marketing (usually ads and SEO), the social web provides plenty of mostly inexpensive ways for additional marketing, like blogs, microblogs, podcasts and social networks.

  


## Social Media Monitoring

Today only few people are left not having a Social Web Account e.g. at facebook, twitter and so on. But Corporations also have to follow this trend to stay in business. And for these the Social Web carries a risk in form of the freedom of expression in the World Wide Web. Everybody can write about what went wrong with a special product or the customer service of a company in his blog, twitter about problems or even comment directly on the facebook page.

As Dell has learned the hard way,it is dangerous not to know what is going on in the social media world. In addition to the usual web monitoring, companies should also start a social media monitoring.

Social Media Monitoring means that companies watch an analyze social media entries in forums, weblogs, micro-blogs (e.g. twitter) and social communities like facebook or myspace. The monitoring is needed to get a fast overview of topics and opinions of the social web and it is done continuous.

### Tools

Free tools available for just that are Google Alerts, Social Mentions and Icerocket. If you like to specialize for Twitter there is Twitscoop, for Facebook there is Open Facenook Search, and for forum search there is Boardreader and Omgili [9][6].

Among others, you can use monitoring tools

  * to manage your reputation
  * for customer relation management
  * for market analysis
  * and to watch the competition

### Dell Hell

To get back to the example of Dell: There was one of the biggest social media crisis. In case of Dell it was afterwards called the "Dell Hell". In 2004 a Journalist, Professor and Blogger, Jeff Jarvis, wrote about his frustration with the customer service and the products of Dell in his weblog. Dell ignored him. But many others shared the fate of Jeff Jarvis und were angry at Dell and called for justice. The case of Dell got viral and the story also reached the mass media. The social media disaster of Dell was perfect. Sales and share prices fell down, the image was badly hit and in the consequence Michael Dell took over the management again.

The only positive aspect about Dell Hell is that Dell now uses social media for innovations (customers can suggest new functions for the products) and customer support. Dell also uses twitter now and made $2 million with it. [5]

## Assignments

### Ex.1: Kickstarter

Look for a couple of projects on Kickstarter (<http://www.kickstarter.com/>). You should be able to find at least two or three. It is also fine to find projects from the past. Write about them in your blog.

### Ex.2: Flattr

Start to look for the Flattr button. Especially many blogs have such a button. Think about adding one to your blog.

### Ex.3: Flattr (optional)

Before you do this exercise, make sure you have experience with spending money on the internet. For instance, only use a pre-paid credit card when making payments on the internet.

Register with Flatr and send them a one-time payment of let’s say 10 Euro. Then tell them that you want to spend 2 Euro per month. Now you can start flattering as many people (their websites, that is) as you like. You should also add a Flattr button to your blog, so people also can flatter you [8].

### Ex.4: Dell Hell

Use your favorite search engine and look for "dell hell". How many search results does Google list? Read some of the articles, and write about what you found in your blog. Dell actually has learned and started something called IdeaStorm (<http://www.ideastorm.com/>) to get customer feedback and improve its products.

### Ex.5: Google Alerts (optional)

Use Google Alerts to do social media monitoring for the ’Social Media Buch’ and/or for the Volkswagen commercial ’The Force’. Write about what you learned in your blog.

  


  


# Government

With the advent of Web 2.0 and especially the social web, democracy has reached the internet. Where before a few companies owned all the information, controlled all the access, and the primary medium was broadcast, this has changed. But even more, not only has the idea of democratization reached the internet, also, the ideas of the social web start to have an influence on democracy. The Social Web especially social networks are a helpful medium to publish informations about the government and a very good Service. These mediums gives also a very good possibility to communicate and interact with the world. Most of the Parties today use social web or social networks. With these mediums they can quickly inform people about new Informations. But the Citizen are afraid because of their privacy. Maybe the privacy is not protect enough. With the Social Web and social network people easily cast a shadow on a party. Good but also bad news can easy spread like the wind. On side of the government there is a high effort because of the security.

  


## Journalism

Of the three branches of government (legislative, executive, judicial) only the fourth one, namely free press has established itself firmly in the internet. After a long struggle, blogging has become a valid form of journalism. Now if even we in the ’Free West’ have trouble recognizing bloggers as journalists (mostly out of economic interests), we can imagine that less free societies have even more issues with them. The Committee to Protect Journalists [51] also fights for the rights of bloggers.

### Citizen Journalism

If you look in the dictionary for the definition of **citizen journalism**, you should see a picture of Dan Gillmore. Gillmore wrote the first blog at a newspaper website. He also wrote the book 'We the Media' on the subject of grassroots media and now he runs the Center for Citizen Media, a joint project of the Graduate School of Journalism at UC Berkely and Harvard's Berkman Center for Internet & Society.

The Idea behind citizen journalism is that people without professional journalism training can use the tools of modern technology and the global distribution of the Internet to create, augment or fact-check media on their own or in collaboration with others.

Although these acts don't go beyond simple observation at the scene of an important event, they might be considered acts of journalism. The average citizen can now make news and distribute it globally, thanks to the wide spreading of so many tools for capturing live events. An act that was once reserved for established journalists and media companies.

According to Jay Rosen, citizen journalists are "the people formerly known as the audience," who "were on the receiving end of a media system that ran one way, in a broadcasting pattern, with high entry fees and a few firms competing to speak very loudly while the rest of the population listened in isolation from one another— and who today are not in a situation like that at all. ... The people formerly known as the audience are simply the public made realer, less fictional, more able, less predictable."[52]

### Criticism

Citizen journalist often get accused of not being objective enough, they get blamed by traditional media institutions of abandoning the goal of 'objectivity'.

An Article published in 2005 also revealed that many citizen journalism sites are lacking quality and content.

David Simon, a former Baltimore Sun reporter criticized the concept of citizen journalism: _"I am offended to think that anyone, anywhere believes American institutions as insulated, self-preserving and self-justifying as police departments, school systems, legislatures and chief executives can be held to gathered facts by amateurs pursuing the task without compensation, training or for that matter, sufficient standing to make public officials even care to whom it is they are lying to."_ [53]

Though citizen journalists often receive criticism about the accuracy of their reporting, the fact remains, that these journalists can report in real time and are not subjected to oversight. That way it played an immense role in the uprisings of the Arab Spring. The use of mobile technology by citizen journalists during the 2011 Egyptian revolution caused the government to briefly terminate cellular and Internet services. Occupy protest were also influenced by live interactive media coverage through citizen journalists.

## Cyberwar

When you hear the term “_cyberwar_“[54] you probably think of movie-scenes like „_Terminator_“ or computergames like “_Call of Duty_”. Well, we haven’t used cyborgs or battlemechs yet to conquer another country, but cyberwar is not a thing of the future. Cyberwar is defined by two parts. On the one hand it describes the martial conflict in the virtual space – the cyberspace. On the other hand it’s about the high-tech forms of modern warfare (entire computerization and cross-linking in almost every military range). In contrast to conventional weapons cyberwar uses weapons of information technology. Simple assaults try to prevent communication between two systems – the more complex assaults try to assume control of an external system. In both cases it’s the aim to keep up the own chains of communication and command.

### Methods

There are different methods of cyber warfare which I want to introduce. One of these methods is the so-called “_cyber-spying_”[55]. Cyber-spying is a modern form of espionage. It’s the act of obtaining information without the permission of the information holder by using spyware like Trojan horses or computer worms. Moreover cyber-spying involves analysis of public activities on websites like Facebook and Twitter. Another method is the so-called “_defacement_”[56] which describes the act of changing the content of a website without the permission of its holder. With modern social engineering tools like “_phishing_”, it’s possible to acquire information like usernames, passwords, credit card details by pretending, for example, as a trustworthy concern. Many hacker groups try to get a website offline by using the so-called “_DDos_[57]” –Attacks, which stands for **d**istributed **d**enial **o**f **s**ervice attacks. With this attack the website will be overloaded with external communication requests so that it can’t respond to legitimate traffic or it responds so slowly as to be rendered effectively unavailable.

### Kosovo War

The Kosovo War in 1999 was the first cyberwar which was registered in history. The NATO attacked a Serbian anti-aircraft system by using high-frequency microwave radiation. Furthermore they attacked the Serbian telephone-system and hacked several Russian and Serbian bank accounts of the dictator Milosevic to close them. On the other hand Serbia intercepted the insecure NATO-communication; forced a Swiss provider to shut down his “pro Serbia”-website and blanked out several NATO-servers. After bombing the Chinese embassy in Belgrade, Chinese hackers attacked various US websites like nps.gov, whitehouse.gov and energy.gov. Additionally they sent virus-infested emails.

### National Cyber Security Cnter

It’s a fact that there are 30.000 attacks on the German Government every month[58], that’s why they founded a National Cyber Security on July 23rd 2011, which has been in action since April 2011. The NCAZ ( Nationales Cyber Abwehr Zentrum) is located at the BSI (Bundesamt für Sicherheit in der Informationstechnik) in Bonn. Ten members have the assignement to detect, prevent and gather information about cyber war activities. However the NCAZ has to take flak shortly after its founding. Ten members are not adequate to this task. It needed about ten times more workforce than it has at the moment. Furthermore the hacker group “No-Name” managed to spy confidential data of the PATRAS (tracking transmitter observation system) by using 42 Trojan horses just a few days after NCAZ’s founding.[59]

## Revolutions

We have just been witnessing the Arab Spring [5], a revolution started and/or supported through social media, such as Facebook and Twitter. For repressive regimes it becomes more and more difficult to control the flow of information. Even the Great Wall (firewall) of China is trembling.

  


##### A short summary

Weeks before the world’s mainstream media woke up to the story, tweets, posts and pictures began popping up on the internet from Tunisia, warning of trouble to come. A fruit and vegetable seller has set himself on fire on December 18th and suddenly reactions on the “universe” of twitter were exploding. Following the hash tag “#sidibouzid” hundreds of videos and photos were posted, showing students protesting, police abuses and sporadic gunfire. As the messages were virtual protest broke out across the world showing solidarity with Tunisia.

  
The Begin of a revolution was unfolding and the mainstream media was just beginning to catch up. The Tunisian Government began hacking into and deleting Facebook accounts. Protesters called for help from hacktivist groups like Anonymous. Soon enough another twitter hash tag appeared across the network: #anonymous

  
Within a matter of hours Anonymous launched Operation Tunisia, paralyzing the president site, several key ministries and the stock exchange. The group also shared a cyber-war survival guide to, among other things, teach the Tunisians to use proxy servers and avoid arrests by the police and army. The government quickly countered with a phishing operation stealing Facebook and email passwords to spy on activists. But tweets continued to spread documenting a society’s breakdown. Although the mainstream media started to report about the processes, the social media networks had the best coverage and documentation of it. A new power structure had emerged and protests had spread to other countries.

  
But the anger had already routed itself inside Arabians’ minds. Through social networks, Egyptians had begun drawing connections in late December. Inspired by Tunisia’s success the fear factor had finally been broken. One of the regimes last tries was it to shut down the internet, but it was too late. The World Wide Web was against them. The accounts of police abuse and violence circulated online including footage that the mainstream media picked up. A coalition of volunteers, organizations and activists set up platforms to get the message out. Even journalists in Egypt used their cellphones to send tweets to friends who relate their messages. This shows how much power today’s Social Media possesses.

  


##### A little breakdown

It’s very complicated to investigate the exact influence and every little development in detail because the whole situation is very complex. You would need lots of special tools to measure it approximately.

  
_But there are a few facts that are relatively obvious and easy to understand:_

  


  * The recent demonstrations and subversions especially showed that Social Media instruments like Blogs, Facebook, YouTube and Twitter can generate a huge impact on the mobilization of crowds of people. Additionally the Web 2.0 – nowadays sometimes even called Web 3.0 - helps to gather information, ignoring the limitation of borders, cultural and ethnic differences.
  * It provides the possibility to call attention to grievances independent from the conventional and regime-controlled media in an easy and direct way. Even Al Jazeera picked up the messages and tweets from activists to spread their word in the world.
  * It showed the importance for governments to be active and ever-present in the Social Media channels.
  * Activists used for the main part Facebook to schedule protest, Twitter to coordinate actions and YouTube to tell the world about it.

  
_On the other hand Social Media also owns a potential “dark side”:_

  


  * There is always the possibility for ministries to spy out data from users and even to infiltrate them.
  * Social Media has the potential to control people in their actions and opinions by targeted distribution of incorrect information or ideologies.

  
References. [15][14][16]

## Campaigning and Lobbying

President Obama’s campaign has shown how social media have become indispensable in today’s campaigning [ref needed]. But in the same way that social media can make careers, the social swarm can also destroy them as has happened in the causa Guttenberg [7].

Meanwhile, the social web also starts to get used for lobbying. An interesting web site is campact (<http://campact.de/campact/home>), that wants to influence political decisions.

  


## The Future

In her lecture at Stanford University, Beth Noveck that if law and technology get brought closer together, this could lead to a new type of collaborative democracy. It's not clear what will happen in the future. There is a future for the E-Government in Germany but in the south of european the people need to reach the Internet-age-time. The Internet everytime reach more influence and gets more and more User. And the Government also use the Internet again and again. It's cheap and the government has to spend less time to inform the people. But there is a high potential to make the E-Government palatable to the citizen.

### Activity:

Watch the lecture by Beth Noveck: ’Technologies for Collaborative Democracy’ (www.youtube.com/watch?v=QIHUGO4HAmQ&list=PL27C635EE182143CE&index=10&feature=plpp_video)

  


## Assignments

### Ex.1: Citizen Journalism

Some blogs are referred to as ’citizen journalism’ [9]. Find some of the more popular one, and start to follow them for a few days/weeks/months. Write about it in your blog.

### Ex.2: Cyber War

Find trust worthy sources in the internet that report about cyber war activity, and also about activities of governmental intelligence agencies.

### Ex.3: Social Media make History (optional)

After an introduction, some remarks on a major earthquake in China, Clay Shirky talks about how Facebook, Twitter and TXTs help citizens in repressive regimes to report on real news, bypassing censor (<http://www.ted.com/talks/clay_shirky_how_cellphones_twitter_facebook_can_make_history.html>)

### Ex.4: Reading (optional)

Read the article ’Kooperativen Technologien im zivilgesellschaftlichen Einsatz’ and tell us what you think about it. (<http://blog.kooptech.de/>) (<http://pb21.de/files/2010/02/Schulzki_Zivilgesellschaft.pdf>)

  


  


# Privacy And Security

With the advent of the Internet, with search engines and the increased importance of WEB in banking, hacking and social networks, the terms privacy and security has been increasingly in the spotlight. To protect and control users and their use of the infrastructure has become an important issue.

## Privacy

Usually comfort, i.e. ease of use, and privacy are two opposites. We actually want to get perfect search results from Google, but on the other hand, we do not want Google to collect any information about us. We want to share private information with friends, but not with strangers. We want to have as much control as possible of information about ourselves, but on the other hand want to learn as much gossip about strangers as possible. Naturally, this dichotomy can not be resolved, so we have to live with a reasonable compromise.

### Awareness

Before thinking of counter measures of how to deal with the imminent dangers of the Net, it takes understanding, and, more importantly, _awareness_ for the risks at hand. It’s imperative to avoid overacting, to refrain from seeing evil in each and every corner, but skepticism and caution, paired with a healthy gut feeling of when to spread personal information and when not to, can and will improve privacy and security.

A good place to start is to be aware of the fact that one is leaving traces all around the Net, and that _others_ try to track these traces to make use of them. Contrary to popular belief (as it is unwittingly being conveyed by Hollywood movies), it’s not so much the governmental agencies that track individuals and groups, but people whose intend is to make profit based on the collected data. In theory, each click, each move, each action is of interest for these people, especially if it helps to deduce and create a profile of the person that is being examined. Willingly or not, the [netizen](//en.wikipedia.org/wiki/Netizen) leaves his traces[60], only to be followed and analyzed by those that serve the purpose of categorizing and structuring his habits and customs. By using the Web, and as a result of participating in its various services, [netizens](//en.wikipedia.org/wiki/Netizen) accumulate measurable digital footprints.[61].

### Activity:

  1. First, read the article on how to protect your privacy in Facebook : ’So funktioniert das neue Facebook’ (www.spiegel.de/netzwelt/web/0,1518,811390,00.html)
  2. Then go to your Facebook account, and check if your privacy settings are sufficient for your needs.
  3. If you want to know why Google is collecting all this information, you may want to read ’Warum Googles Datensammeln gar nicht so böse ist’ (www.golem.de/news/imho-warum-googles-datensammeln-gar-nicht-so-boese-ist-1203-90241.html)

  


## Personal Marketing

The opposite of privacy is personal marketing. When you start looking for a job, sites like Xing (<https://www.xing.com/>) and LinkedIn (<http://www.linkedin.com/>) become very important. Many jobs are no longer advertised, but instead head hunters use those sites for recruitment.

### Activity:

Use Google and look up your own name. Follow some of the sites, is that you? Would a possible employer like what he or she sees? Do an image search for your name. Is that really you?

In case you don’t like what you see, don’t despair, but take control. By consciously posting information about yourself, you can actually influence the noise.

  


## Security

The most secure computer is one that is locked in a safe, with no cables going in or out. Although very secure, such a computer is not very useful. Already a power cable going in, is for some experts enough to determine which keys you pressed.

The other opposite are Internet cafes. No matter if you use your own computer or someone else's, you should expect, that everything you enter (especially credentials) can be observed by others.

For your own computer viruses, trojans, root kits and the like are a primary security risk. Here some simple precautions can help, like the use of a secure operating system, a decent browser, and a little care with the installation of applications that come from trust worthy sources. The choice of good passwords, and a reasonable secure network environment are also important.[62]

As for web browsing, not all browsers are equal with respect to security, so pick the right one. As for the browser settings, it is recommended to disable any applications such as ActiveX, Flash, Java and the like. Also disabling JavaScript and Cookies is recommended. But once you start browsing with such a browser the Internet becomes pretty boring (like the computer in the safe).

However, even the safest browsing environment does not help you much, if the provider screws up, like in the case of the PlayStation network outage [6].

### Activity:

  1. Read the article ’Tipps für mehr Sicherheit So schützen sich Profis vor Computer-Kriminellen’ (www.spiegel.de/netzwelt/web/0,1518,808814-2,00.html)
  2. Discuss means for increasing your security in the web (Incognito, [Knoppix](http://www.knopper.net/knoppix/)[63], ...)

### Cryptography

Cryptography[64][65], Also called [ciphering](//en.wikipedia.org/wiki/Ciphering), encryption is about obfuscating the content of a message or [data stream](//en.wikipedia.org/wiki/Data_stream). Without secondary meta information, such as a decryption key or password, a third party that gains access to the encrypted information is (or should) not be able to extract or deduce its content.

Encrypting a message does not render the sender anonymous against an observing party. To achieve that kind of anonymity, the (logical) transmission channel, with all or some of its intermediate network entities, would have to be obfuscated as well. However, it guarantees not only the privacy of the transmission (see above), but also the integrity and authenticity of the message, and thus, its sender.

#### Symmetric Ciphering

[Symmetric ciphering](//en.wikipedia.org/wiki/Symmetric_encryption) is based on the fact that the same key is used for both, encryption and decryption of a message.

Compared to [asymmetric encryption](//en.wikipedia.org/wiki/Asymmetric_encryption), [symmetric key algorithms](//en.wikipedia.org/wiki/Symmetric_encryption) tend to be fast. Their major drawback is that both, sender and receiver, need access to the same key, which must somehow be shared over a secure communication channel in the first place.

#### Asymmetric Ciphering

[Asymmetric ciphering](//en.wikipedia.org/wiki/Asymmetric_encryption), also known as [public-key cryptography](//en.wikipedia.org/wiki/Public-key_cryptography), means that the key of an encryption consists of two parts, a so-called key pair: a private key, and a public key.

The _public key_ is transferred openly to the communication partner or party. Once used to encrypt a message, the resulting cipher text can only be decrypted by using the _private key_. That way, the public key can be used to send an encrypted message to the owner of the private key. Only the owner will be able to decrypt the message and read its content.

On the other hand, the _private key_ can be used to prove authenticity. Once used to encrypt a message, any party in possession of the _public key_ (virtually everyone) can validate the authenticity of the message, i. e. verify that the message has been encrypted by the owner of the private key. That way, a mechanism to “sign” a message is provided. In fact, [public-key encryption](//en.wikipedia.org/wiki/Public-key_cryptography) provides the basis for [digital signatures](//en.wikipedia.org/wiki/Digital_signature).

### Anonymity

Being anonymous means not to expose distinguishing features that would permit an onlooker, casual as well as intentional, to identify the observed subject or party.[66] As far as the internet is concerned, the anonymity of a [netizen](//en.wikipedia.org/wiki/Netizen) means that the person responsible for an action performed throughout the infrastructure of the net can not be identified, and thus can not be held accountable for what has been done. Anonymity differs from encryption in that it obscures a user’s identity rather than ciphering the channel of communication, though the latter is often a technical means to achieve the ends of the former.

The technical basis of [anonymization networks](//en.wikipedia.org/wiki/Anonymizer) is usually that of a proxy. Instead of connecting directly to a remote host, a participant of a [anonymization network](//en.wikipedia.org/wiki/Anonymizer) channels all communication through a local proxy, a piece of software that runs on the user’s computer. The proxy encrypts the outgoing message, picks a router of the (anonymization) network, and passes the packet on to it. From that point on, all messages passed between two subsequent routers are encrypted. An observer who extracts the contents of a packet routed through the [anonymization network](//en.wikipedia.org/wiki/Anonymizer) will see encrypted data instead of clear-text messages. Moreover, neither the identity (i. e. IP-address) of the original sender, nor that of the final destination is reveiled, since the entire routing information of the underlying packet is encrypted as well.

Examples of [anonymization networks](//en.wikipedia.org/wiki/Anonymizer) deployed throughout the internet:

  * [Tor](https://www.torproject.org/), formerly known as _The Onion Router_
  * [I2P](http://www.i2p2.de/), formerly known as the _Invisible Internet Protocol_

## Assignments

### Ex.1: Protect your Privacy

Read the following two articles:

  * Googles Super-Profil Datenschützer empfiehlt Streubesitz www.spiegel.de/netzwelt/netzpolitik/0,1518,811359,00.html
  * So löschen Sie Googles Erinnerung an Ihre Web-Suchen, www.spiegel.de/netzwelt/web/0,1518,818287,00.html
  * Tipps für mehr Sicherheit So schützen sich Profis vor Computer-Kriminellen www.spiegel.de/netzwelt/web/0,1518,808814-2,00.html

Find similar articles or web sites. Decide for yourself what you consider useful/helpful, and write about it in your blog.

### Ex.2: Xing or LinkedIn

If you have not signed up with one of the professional networks, you should do so. For Germany, Xing is very popular, for internationals, LinkedIn is the better choice. Try to connect to your friends, and teachers.

### Ex.3: Yasni and 123people

You may have notices, when you did the search for your name on Google, that some web sites (like Yasni (<http://www.yasni.de/>) or 123people (<http://www.123people.de/>)) show up quite often and claim to know a whole lot about you. Actually, you can register with those sites, and influence what they show about you.

### Ex.4: Social Engineering

Watch the interview with Sharon Conheady about Social Engineering (video.golem.de/internet/6440/interview-sharon-conheady.html). Try to find web sites related to social engineering, maybe you also stumble upon a certain Mr. Mitnick. Write about what you find in your blog.

  


  


# The Sciences and the Arts

The social web also influences the sciences and the arts. We only mention a few interesting projects, although there are many, many more.

  


## Science

Already in 1991, Paul Ginsparg [9] started arxiv.org. It is an open access e-print library for physics, mathematics, computer science, quantitative biology, quantitative finance and statistics. Scientist submit their papers and read the papers of their peers.

The next step in the direction social web is Mendeley [6], a free desktop and web program for managing and sharing research papers, discovering research data and collaborating online.

Another plattform (not only) for science is Wikipedia [10]. As you know it is a free, collaboratively edited and multilingual Internet encyclopedia supported by the non-profit Wikimedia Foundation. There are about 4 million articles, that have been written by volunteers around the world. Almost all of this articles can be edited by anyone with access to the site. However, these will be checked on correctness by experts. Actually wikipedia has about 100,000 regularly active contributors and a variety of daily visitors. For more information you can explore wikipedia's statistic site [11].

## Shared / Distributed Computing

The basic idea is to use many desktop computers to replace super computers. To my knowledge it really became popular with Seti@home, the search for extra-terrestrial life. Since they wouldn’t get any funding to do their data analysis on super computers (nobody wanted to spend taxpayers money for that) they came up with the idea of running the data analysis as a screen saver on peoples computers, while those are idle. Interesting enough it worked (well they haven’t found life yet), and so now there are many similar projects:

  * Seti@home, setiathome.berkeley.edu
  * Distributed Computing, <http://www.distributed.net/Main_Page>
  * Folding@home, <http://folding.stanford.edu/>

Although not really social, they are still interesting projects.

  


## Human Computing

In the above example, many little computers were doing the work of a super computer. Well, how about using the best super computer of the world, the human brain, to do calculations? Watch the following talk:

### Activity:

Watch the first 10 minutes of Luis von Ahn’s talk on human computing at Google: video.google.com/videoplay?docid=-8246463980976635143. Tell us what you think. If you like, watch the rest of the talk and write about it in your blog.

  


## Crowdsourcing

"Crowdsourcing is a distributed problem-solving and production process that involves outsourcing tasks to a network of people, also known as the crowd" [7]. An often quoted example is the Goldcorp Challenge. Goldcorp was a gold mining company that wasn’t doing so well. Their CEO (inspired by Linux and OpenSource) had the following idea:

    "In 2000, Goldcorp abandoned the industry’s tradition of secrecy, making thousands of pages of complex geological data available online, and offering $575,000 in prize money to those who could successfully identify where on the Red Lake property the undiscovered veins of gold might lie. Retired geologists, graduate students and military officers around the world chipped in. They recommended 110 targets, half of which Goldcorp hadn’t previously identified. Four-fifths of them turned out to contain gold. Since then, the company’s value has rocketed from $100m to $9bn, and disaster has been averted." ([5])

More details on the story can be found, for instance, in [4].

  


## Art

Naturally, the social web also inspires the arts. There are two funny and intriguing videos on TED:

  * Ze Frank’s nerdcore comedy: 
    * www.ted.com/talks/ze_frank_s_nerdcore_comedy.html,
    * www.ted.com/talks/ze_frank_s_web_playroom.html)

  


## Crowdfunding

Crowd funding - as the name implies - the financing of a project, product or even a company with a large - often anonymous - amount of sponsors. The support of each sponsor can also be very small, but through the mass of supporters, a large sums of money will come together. Crowd funding occurs for any variety of purposes,from disaster relief to citizen journalism to artists seeking support from fans, to political campaigns, to funding a startup company, movie or small business or creating free software or to supporting art.

Examples of Crowdfunding:

**Kickstarter** [8] is a web site to fund art projects. As they say ’A new way to fund and follow creativity’. Through Kickstarter more than ten thousand people pledge several million dollars to fund projects from the worlds of music, film, art, technology, design, food, publishing and other creative fields.

_All-or-nothing funding?_[12]

Every Kickstarter project must be fully funded before its time expires or no money changes hands. Why? -It's less risk for everyone. If you need $5,000, it's tough having $2,000 and a bunch of people expecting you to complete a $5,000 project. -It allows people to test concepts (or conditionally sell stuff) without risk. If you don't receive the support you want, you're not compelled to follow through. This is huge! -It motivates. If people want to see a project come to life, they're going to spread the word.

_Why do people support projects?_[12]

REWARDS! Project creators inspire people to open their wallets by offering smart, fun, and tangible rewards (products, benefits, and experiences). STORIES! Kickstarter projects are efforts by real people to do something they love, something fun, or at least something of note. These stories unfold through blog posts, pics, and videos as people bring their ideas to life. Take a peek around the site and see what we're talking about. Stories abound.

  


Also the game designer **Tim Schafer** asked for support funding to his fans.

Tim Schafer [46] is sometimes referred to Tim Burton, cause his games are quirky, funny, full of bizarre beauty - and they almost always flop. For his latest title "Double Fine Adventure" Schafer turned to crowd-funding website Kickstarter and his loyal fan base for help. His goal was to raise $400,000 and a modest number for a modern day video game budget. The project was fully funded in just over 8 hours, it raised a record-breaking $1 million by the end of the first day. After all he got $3,336,371 [67]

The best-known German Crowdfunding platform is **Startnext**.[44] Since 2010 Startnext has distributed almost 600 000 Euro to projects, for example an album of medieval music, post-production for an art house film or for a special print of comic strip.

## Art Community

**Saatchi-Gallery**[15]

According to his own statement "Showcase your art to thousands of visitors every day". Artists can participate in this virtual gallery show, a spinoff of the famous Saatchy Gallery, their work to a worldwide audience and they can participate on competitions.

**Devian Art**[16]

Devian Art is the world's largest online art community, showing variety pieces of art from over 22 million registered artists and art appreciators. Everyone can set up a profile there, create galleries, build a fan base and make money selling his art in the devianART Shop.

**CastYourArt**[17]

CastYourArt has set a target to be a Rapporteur of contemporary art and culture scene. Artists, cultural workers posts audio and video in form of podcasts for an interested audience.

**Wooloo**[18]

Wooloo is a nonprofit international platform, which wants to bring artists into contact to eachothers and also promote the exchange among them. Artists of all media, as well as curators and interdisciplinary groups are invited to publish their works and projects at this platform. The presentations may take place in form of exhibitions, competitions and project ideas.

**Artreview**[47]

in this network are more than 25,000 artists represented, who upload their artwork and make friends with each other

**Artbreak** [44]

Artbreak is a global community for artists and art lovers. It's a place for artists to share their art, sell it commission-free, tell the world about themselves, get feedback, and make connections with buyers, fans and other artists. It's a place for art lovers to find incredible work from emerging artists from all over the world.

## Becoming famous with social networks

Nowadays to become famous, artists should represent themselves on social networks like facebook, twitter and co. As well as being present, artists will need to create content of interest so that people have something to read or watch and enjoy. They should upload they works and also update their personal information constantly. If this information is not interesting, users will click to the next page and move on. People need to feel that the artist on his own - and not an anonymous webmaster - are personally available at least on a regular basis, if not daily. And once if an aritst have built a fanbase, he should reward them for their time and dedication – run competitions, give away goodies like CD's, signed photos and posters, give them a chance to meet him. Hier is a catalogue of the main social networks, that are important in this case:

-Homepage

-Facebook

-Twitter

-Blog

-Youtube

-Flickr

-RSS

-Devian Art

-Kickstarter

## Examples of individual artists in social web

**Sebastian Bieniek**[68]

In the book "Realfake" [14]the artist Sebastian Bieniek describes about his experiences with facebook. He had built up over the last three years, an empire of fake profiles. Then he linked up the profiles to each other and became friends with Robert de Niro (for example) and connect him with other famous artist.

Within a short time, he communicated with thousands of people around the world and they became - without being aware of it - his fans too.

**Ben Heine**[45]

Ben Heine is a Belgian multidisciplinary visual artist. He became more widely known in 2011 for his original series "Pencil Vs Camera", "Digital Circlism" and "Flesh and Acrylic". He is present on nearly every social network named above. His homepage has links leading to other social network plattforms. Even on wikipedia exsists an issue about him.[69] "How to become famous in social networks?". Bens engagement on social networds gives the answer about this question

**Yaniv (Nev) Schulman**[70] Yaniv (Nev) Schulman is a New Yorker photographer. He started also a film/photography production company with his brother Ariel. In 2010 they made together with their friend Henry Joost a film named „Catfish“.[71] It is a documetary film wich involves Nev, who is being filmed as he builds a romantic relationship with a young woman on the social networking website, Facebook. And the incredible ending of it.

### Activity:

Use the internet to find out more about Kickstarter and some of its successful projects, especially art projects. Tell us what you found in your blog. Look for a project you like, and spend 10 Euro on it (if you like).

## Assignments

### Ex.1: Crowdsourcing

Read the Wikipedia article on crowdsourcing [7] and write about it in your blog.

### Ex.2: Ben Shneiderman: Science 2.0

Watch the inspiring talk ’Science 2.0: The Design Science of Collaboration’ by the distinguished Ben Shneiderman (www.youtube.com/watch?v=nxBmKkLJCEc) and tell us what he was talking about in your blog.

  


  


# Additional Chapters

# Social Bookmarking and Tagging

Bookmarks exist since the start of the internet. Yahoo in the beginning was nothing but a collection of bookmarks. All of us keep bookmarks, some in our favorite browsers, some as simple text or html files, and some of us share them and tag them.

  


## Social Bookmarks

Bookmarking services such as Delicious (www.delicious.com) allow you to store, manage, organize and search bookmarks to internet resources (usually web pages) online [9]. A central aspect is the tagging: you describe a resource with either a word, words or a sentence. When many people do that, then this collection of tags is called folksonomy. Tagging is actually a very valuable service, which help especially search engines in providing better search results. This is actually a form of ’human computing’.

Delicious is one of the more popular social bookmarking services, others are StumbleUpon, MisterWong and many more.

### Activity:

  * Go to the Delicious web site (www.delicious.com) and search for ’3d printers’. Note that it can be used like a human-powered search engine.
  * A nice way to visualize tag relationsships (and hence folksonomy) can be done with the Del.icio.us tag browser (<http://www.hubmed.org/touchgraphs/deltags.php>).

  


## Social News

Slashdot [5] (<http://slashdot.org/>) was one of the first social news websites [6], where users submit stories and editors pick the best stories for the front page. Digg (<http://digg.com/>) took that idea further, and instead of editors used a voting system. Users can ’digg’ (i.e. like) or ’bury’ (i.e. dislike) articles. Other popular social news sites are Reddit and Newsvine. A similar idea is behind Facebooks’s ’Like’ button, Google’s ’+1’ or the ’Tweet’ button from Twitter.

### Activity:

  * Visit Slashdot (<http://slashdot.org/>) and read some of the stories posted there. If you have a real interesting story to tell, then you may also post one to Slashdot. If you do, and if makes it to the front page, tell us, you will get an immediate ’A’ for the class!
  * Go to one of the large news web sites, such as CNN, BBC World, or Spiegel Online. Click on one of the featured articles and look for the ’Share’ button or small icons for the respective web sites such as Delicious or Digg. Click on one to see what happens.

  


## Assignments

### Ex.1: Bookmarking

For this class start an account on Delicious or MisterWong or similar bookmarking service. During this semester, collect and share links related or unrelated to this class.

  


  


# HowTo

Since this class is hands-on, you will need to sign up for a couple of web sites. Required are a blog (not neccessarily at blogger.com) and a wikibooks account, all others are optional. If you prefer, you can create an ’alter ego’ for this class and basically stay completely anonymous. In that case you should follow the setups as described below.

**Important: You may NOT want to use your real name in any of the accounts below.**

  


## Setup a Yahoo Email Account

  1. Go to <http://www.yahoo.com/> and click on the ’Sign Up’ icon (usually in the upper. Enter the information suggested.
  2. Make sure you go to settings and change them to your needs. You should notice that by default much of the information of your account is public.

  


## Setup a Google Account

  1. Go to <https://mail.google.com/> and click on ’CREATE AN ACCOUNT’. Enter the information suggested.
  2. Make sure you go to account settings and change them to your needs. You should notice that by default much of the information of your account is public.

  


## Setup a Blog at Blogger

  1. Go to the homepage of Blogger (<http://www.blogger.com>). Enter your Google email account and password. There are alternatives like blog.de and many more, which one you use does not really matter.
  2. The next page will show you your existing blogs (in case you have any) and allows you to create a new blog. For this class you may want to create a new blog. Remember the name, because the other students in class need to know your blog, so that they can write comments to your posts. In the next step you have to select a template, and you are ready to blog.
  3. My blog for this course is available at <http://SocialWebOhm.blogspot.com>.

  


## Setup a Twitter Account

  1. First, go to <https://twitter.com/>. On the right you will find the SignUp area. Fill in your name, email and pick a decent password.
  2. Once you’re signed in, go to the help pages, go to Twitter Basics, and follow the Twitter Tour (<https://support.twitter.com/groups/31-twitter-basics/topics/182-announcements-and-new-stuff/articles/20169519-twitter-tour-let-us-show-you-around>).
  3. Also read the help article about ’How To Use Twitter Lists’.
  4. Now that you are setup, search for ’socialwebohm’ in the search box. Under people you should find me and a tweet related to the class. You can become a follower by clicking on my profile (image) and click on the ’Follow’ button.

  


## Setup a Wikibooks Account

  1. For writing articles to the wikipedia or wikibooks (they use the same database), you can either make edits anonymously, your computer current IP-address is then used as your user name, or you can signup with wikipedia, which is the preferred way.
  2. Go to the main page of the English version of Wikibooks: <http://en.wikibooks.org/wiki/Main_Page>. In the upper right corner, you can click on ’Log in / create account’ to create a new account. You may pick anything for your username.
  3. You can actually create your own ’homepage’ by simply clicking on your user name.

  


  


# Appendices

# Authors

This book is a class project, thus the original authors were students who participated in the class.

## List of Authors

[Rplano](/wiki/User:Rplano); [P. M.](/w/index.php?title=User:B.baggins&action=edit&redlink=1);

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

_Note: current version of this book can be found at <http://en.wikibooks.org/wiki/Social_Web>_

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Social_Web/Print_version&oldid=2502705](http://en.wikibooks.org/w/index.php?title=Social_Web/Print_version&oldid=2502705)" 

[Category](/wiki/Special:Categories): 

  * [Social Web](/wiki/Category:Social_Web)

Hidden category: 

  * [No references for citations](/wiki/Category:No_references_for_citations)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Social+Web%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Social+Web%2FPrint+version)

### Namespaces

  * [Book](/wiki/Social_Web/Print_version)
  * [Discussion](/wiki/Talk:Social_Web/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Social_Web/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Social_Web/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Social_Web/Print_version&action=edit)
  * [View history](/w/index.php?title=Social_Web/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Social_Web/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Social_Web/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Social_Web/Print_version&oldid=2502705)
  * [Page information](/w/index.php?title=Social_Web/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Social_Web%2FPrint_version&id=2502705)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Social+Web%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Social+Web%2FPrint+version&oldid=2502705&writer=rl)
  * [Printable version](/w/index.php?title=Social_Web/Print_version&printable=yes)

  * This page was last modified on 17 March 2013, at 08:07.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Social_Web/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
