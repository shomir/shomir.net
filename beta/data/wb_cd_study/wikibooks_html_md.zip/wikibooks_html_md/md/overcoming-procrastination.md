# Overcoming Procrastination/Print version

From Wikibooks, open books for an open world

< [Overcoming Procrastination](/wiki/Overcoming_Procrastination)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Overcoming Procrastination](/wiki/Overcoming_Procrastination)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Overcoming_Procrastination/Print_version&action=purge&printable=yes) this page.

# Introduction

**Procrastination** or "task aversion" is the irrational delay of an intended course of action, even while expecting to be worse off for the delay (compare [temporisation](//en.wiktionary.org/wiki/temporize)). The procrastinator deviates from the task, usually in favor of another more enjoyable (or less unenjoyable) activity. This behavior is pervasive throughout society - everyone procrastinates to some degree - but some people are so chronically affected as to be severely debilitated.

Procrastination is typically caused by the association of pain or discomfort with the prospective course of action; that is: stress. This may be physical (such as that experienced during hard labor or vigorous exercise) or psychological (such as in the form of frustration or anxiety). The task or the situation requiring the task may be perceived as dangerous, painful, overwhelming, difficult, tedious, uncomfortable, or boring; basically, unenjoyable; that is: stressful. Once habitualized, procrastination can be triggered at any time. Procrastination can also be a symptom of a serious psychiatric disorder such as [depression](//en.wikipedia.org/wiki/clinical_depression) or ADHD ([attention-deficit hyperactivity disorder](//en.wikipedia.org/wiki/attention-deficit_hyperactivity_disorder)), and may be greatly reduced when the underlying condition is properly treated.

Traditionally, in the field of psychology, procrastination has been associated with [perfectionism](//en.wikipedia.org/wiki/perfectionism_\(psychology\)) (a tendency to negatively evaluate one's own performance). However, research indicates that perfectionists are not any more likely to procrastinate, though they feel worse about it when they put things off.[_[citation needed](/wiki/Wikibooks:OR)_]

The word **procrastination** comes from Latin, _Pro_, "in favor of", and _Cras_, "tomorrow".

# Consequences

Some of the Consequences:

  * **Lost opportunities:** for example, somebody else buys the car the procrastinator wanted because they put off making a simple phone call. Or somebody else patents an invention the procrastinator thought of first, because they never got around to patenting it themselves.
  * **Tardiness:** being late to meetings, showing up late at special events, and being late to pick up a date. Missing the beginning of the movie at the theater, and getting bad seats, because the procrastinator did not leave the house on time.
  * **Missed deadlines:** from failing a school assignment by not turning it in on time to missing a flight at the airport because the procrastinator talked on the phone too long.
  * **Irresponsibility towards others:** like failing to keep promises because they kept getting put off until later. Or causing others to be late for their commitments because the procrastinator didn't pick them up on time.
  * **Lack of preparedness:** such as when the basement floods unnecessarily because the procrastinator kept putting off installing a sump pump.
  * **Poor performance:** failing an exam, because the student waited until the night before the test to begin studying.
  * **Career troubles:** repeatedly missing deadlines on projects at work, making promotion unlikely and potentially leading to getting demoted or fired.
  * **Unnecessary expenses:** like having to pay late fees because the procrastinator didn't pay the bills on time even though they did have the money. Or having a huge liability from an automobile accident because the person at fault wasn't covered because they put off paying their insurance bill.
  * **Financial difficulties:** such as the inability to pay the bills due to putting off generating new sales or finding new customers for the business.
  * **Medical problems:** like having to make a painful visit to the dentist to have cavities filled or teeth pulled because the patient kept putting off brushing their teeth. Or having a heart attack because the victim kept delaying the start of their personal health program.
  * **Dissatisfaction about oneself**.
  * **Dissatisfaction of others about one's procrastination**. A spouse may even end the marriage because their partner put off getting a better paying job as promised.

# Characteristics

Procrastination can be seen as both a behavior and the lack of a behavior. The behavior is the act of turning away and doing something else in place of what the procrastinator should be doing. The lacking behavior is of course the task or activity that the procrastinator should be working on, such as homework. There are three ways to procrastinate: skip it, do it last, and escape.

  1. **Skipping it:** here, even though the task is foregone forever, it is the program that is being put off. When a person skips brushing their teeth, they are putting off their whole "keep the teeth clean so they won't get cavities" program. It's like they are saying "I'll start brushing my teeth tomorrow."
  2. **Doing it last:** easiest / most pleasant tasks tend to be done first. When there's a big job to do, and a long list of things to accomplish in order for that job to be completed, the tendency is to work on the simplest tasks. As long as the items on the list are getting done, the job _feels like_ it is being completed, and the procrastinator lulls themself into a false sense of security. This approach becomes a problem when all the easy chores are done but there isn't enough time left to complete the hardest tasks because they were put off until last! Also, new alternative tasks may come up again and again, so that the main task is never started.
  3. **Escape:** the procrastinator instead does something they enjoy doing, choosing short-term gratification over long-term gain, at the cost of the benefits that they would receive from doing the task they put off. This takes their mind off the (stressful) task that they should be doing, or the situation they should be dealing with. This can lead to a pattern of addiction, where the more the procrastinator escapes, the more guilty they feel about not doing what they are supposed to be doing, creating more stress to escape from, leading them to continue the alternate activity so they don't have to think about it.

But procrastination isn't necessarily the mere lack of doing something, it is something that is causing the procrastinator not to do it. In this sense procrastination isn't the behaviors done or not done, but is a behavior unto itself. As a distinct behavior, procrastination can be characterized in several ways...

### Procrastination as poor judgement

At the core of procrastination is a faulty decision. Either the decision is made not to do something that should be done, or the decision is made to do something else. Since that is the wrong decision, and the person is aware of it but follows it anyway, that is poor judgment. A term for acting against one’s better judgement is [akrasia](//en.wikipedia.org/wiki/Akrasia). If the person makes the decision out of course with no thought to the outcome, then they are acting without thinking, and that too is poor judgement.

    **Poor judgement and laziness**

    Rest and relaxation is important to maintain health and to occasionally distance oneself from one's work so it can be seen more clearly or from a different perspective. But relaxation can be taken too far, and when it is, it's called [laziness](//en.wikipedia.org/wiki/laziness). When resting beyond the need to maintain health interferes with responsibilities or life dreams, that is another example of poor judgement. There is much debate as to whether a value judgement such as laziness can be attributed to the procrastinator, since in many cases the procrastinator wishes to be active and productive but is held back by an inability to follow through.

    **Poor judgement and leisure**

    While [leisure](//en.wikipedia.org/wiki/leisure) and [recreation](//en.wikipedia.org/wiki/recreation) go hand-in-hand with rest and relaxation, and can provide therapeutic refreshment of body and mind, it becomes too much of a good thing when it interferes with what a person should be doing. [Playing](//en.wikipedia.org/wiki/Play_\(activity\)) is useful for learning and can provide exposure to new things, and is an important component of open-mindedness, but when it is engaged in to the detriment of things needing to get done, it is yet another manifestation of poor judgement. The procrastinator has chosen doing what they want to do over what they _have_ to do. It is often necessary to let work come before play. But leisure doesn't have to be sacrificed completely: there's a section about scheduling fun breaks below.

### Procrastination as being distracted

When something isn't enjoyable, it is very easy for a person to get distracted from a pending task. In this case, a procrastinator may feel blameless. The more susceptible a person is to [distraction](//en.wikipedia.org/wiki/distractions), the more prone the conditions are for procrastination.

If a person allows himself or herself to be distracted, and the distraction is not warranted (that is, it isn't more important than what what was being done), then that person has implicitly made the decision to procrastinate by choosing to do something other than what was intended.

The less thought that goes into making choices, the harder it is for a person to avoid the consequences of procrastinating. The more distracting elements (people, toys, etc.) there are in a person's immediate environment, the more opportunity there is for poor choices to occur.

### Procrastination as a phobia

An irrational aversion to something is a [phobia](//en.wikipedia.org/wiki/phobia). Not only can phobias cause procrastination, a phobia can be a component of procrastination itself and therefore go unnoticed as a phobia. A strong and irrational aversion to something is usually a sign of a phobia.

### Procrastination as bad habit

When the decision to avoid a task is repeated automatically—even when it is the wrong decision—making the wrong decision becomes habit; the decision maker has acquired a habit of making bad decisions. Keep in mind that a decision is implicit to every action taken, even if the person taking the action did not consciously decide anything.

Since habits are repetitive in nature, a habit cannot usually be overridden by a single decision: it takes a new habit to do this. A simple decision could easily be overwhelmed by the force of habit and therefore may need to be implemented as a habit itself before it can compete effectively with the old habit.

### Procrastination as a complex

Unfortunately, procrastination isn't simply a habit, it is a complex pattern of recurring behaviors including emotions, thoughts, and actions. Many of these are habitual, and in order to get rid of them, each one needs to be replaced, circumvented, or deactivated by new habits; though not necessarily on a one-to-one ratio: sometimes a single habit can replace several others.

### Procrastination as a symptom

Procrastination can be the result of a more serious underlying condition such as [depression](//en.wikipedia.org/wiki/clinical_depression) or [ADHD](//en.wikipedia.org/wiki/Attention-deficit_hyperactivity_disorder). See below.

# Causes

Procrastination is always based on a dysfunctional worldview, such as that "short term relief or pleasure is better than sacrifice for long-term rewards," along with irrational disregard for negative consequences. The procrastinator fails to engage in the appropriate course of action either due to a [distraction](//en.wikipedia.org/wiki/distraction) of some sort or an inadequacy in their own behavior. Various distractions and incompetencies that can cause procrastination include, but are not limited to:

  * Addiction
  * Anxiety and fear
  * Arrogance, pride
  * Aversion
  * Bad habits
  * Discouragement
  * Disorganization
  * [Distraction](//en.wikipedia.org/wiki/Distraction)
  * Family problems
  * Fear of failure
  * Feeling overwhelmed
  * Frustration
  * Guilt
  * Ill-conceived goals and unconscious motives
  * Indecision
  * Lack of awareness
  * Lack of morals
  * Lack of time management skills
  * Low ambition
  * Low frustration tolerance
  * Low self-esteem
  * Low tolerance to stress
  * Objective conflict (competing goals)
  * Paranoia
  * Perception of difficulty
  * Phobia
  * Poor attitude
  * Poor self-control skills
  * Poor study skills
  * Rebellion
  * Resentment
  * Self-centeredness
  * Self-deception
  * Uncertainty

### Expectancy-Value Theory

    _Laziness pays off today, work only tomorrow._

In motivational psychology, a mathematical formula can be used to determine what task should be pursued first. According to [this model](http://www.tcw.utwente.nl/theorieenoverzicht/Theory%20clusters/Public%20Relations,%20Advertising,%20Marketing%20and%20Consumer%20Behavior/Expectancy_Value_Theory.doc/), we complete first those tasks which have the highest "usefulness"-value. This model is able to explain why we would rather be watching our favorite television program than writing the soon to be due term paper from your hardest college class, and it says that _everybody_ is procrastinating, although each of us to differing degrees.

![U=\\frac{P\\times V}{D}](//upload.wikimedia.org/math/1/7/6/1761802f9043dbaa56c93e1ec8bd05ee.png)

where

    U = the usefulness of the task.
    P = Probability of profiting from the task
    V = Value of the profit gained from the task
    D = Delay between doing the task and receiving the reward for it

This formula is saying that, we (generally speaking) tend to prefer (depending on an individualized perception and perspective, that can not be fully generalized but can be normalized in test trials):

  * immediate rewards over delayed benefits
  * bigger rewards over smaller prizes
  * sure rewards over rewards that are only probable

The important question now is: Under what circumstances would someone put off their work? If the increase in U would be significant (e.g. when P, V or both values are high), every procrastinator stops procrastinating. By introducing an additional factor to the equation (S, the sensitivity of the subject toward the delay between action and reward), the behavior of different people could be compared.

# Eliminating Procrastination

One would think that the solution to procrastination (not doing it) is its exact opposite: doing it! That the cure is doing the very thing that is being avoided.

[Note: We must be careful using the word "cure" in regard to procrastination. We ought to think of procrastination itself as a cure. Trying to "cure" procrastination is identical to trying to cure a fever. Fever is the body's attempt to "cure" an infection. A physician tries, instead, to eliminate the infection. Likewise, procrastination is an attempt (if misguided) to "cure" a personal difficulty. The underlying problem, for which a person uses procrastination as a solution, must be the focus. Curing procrastination--or concentrating on procrastination, then, distracts and delays an efficacious solution to the true emotional problem.]

Well it is, and then some. Since procrastination is the cause of not doing (rather than merely the lack of action), simply doing that which is being procrastinated may not be psychologically possible while the mental obstacle or technical problem causing the procrastination is in place. Also, as explained above, procrastination can be a powerful psychological force in its own right. Therefore, the procrastinator needs to get over, go around, or somehow plow through these mental barriers in order to get on with it. This is dependent upon the very nature of procrastination itself...

In essence, procrastination is a form of incompetence. To cure it is to eliminate it. Since incompetence is the opposite or lack of competence, _the only way to eliminate it is to replace it with competence._

**Personal competence** comprises five elements: emotional strength, well-directed thought, time-management skills, control over habits, and task completion abilities. Therefore, most strategies for overcoming procrastination are based on improving these five skill areas, and involve: improving emotional control and adjusting one's underlying attitude, focusing attention and thinking rationally, learning executive (self-management) procedures like planning and scheduling, learning habit-changing methods, and acquiring better task completion and problem solving skills.

### Increasing emotional control

To the extent that procrastination is an emotional problem, acquiring control over emotions brings the problem under control. Emotions are invoked by perception, which in turn is dependent on attitude, stress tolerance, and moods (which are simply sustained emotions that become trends). Therefore, by rebuilding or improving these foundations, emotional strength can be increased to handle the problems and opportunities encountered everyday, emotional or otherwise. There are both psychological and physiological methods of doing this.

#### Attitude adjustment

Personal attitude is the foundation of an individual's emotions. If a person believes that the world is out to get them and that they have been dealt a losing hand in life, they are likely to walk around with a frown on their face feeling sorry for themselves or being mad at everyone else, saying things like "why try anything at all, it won't matter anyways". But, on the other hand, if they believe that they have a great many things to be thankful for, that the world is a great place, and opportunity abounds, then they are more likely to work hard and greet everyone with a smile just because they feel good about themselves and others too.

Attitude isn't a static set of personal beliefs that a person is stuck with for the rest of their life. Attitude is an approach: at anytime, anyone can decide to look on the bright side of things, or not. The former engenders hope, enthusiasm, and joy, while the latter invites fear, loathing and misery. The choice on how to perceive the world is up to each person. Below are some of the perceptions of which a positive attitude may be comprised...

  * **A positive mental [attitude](//en.wikipedia.org/wiki/attitude)** inspires ongoing action, especially when it includes a strong [work ethic](//en.wikipedia.org/wiki/work_ethic). Adopting an **uplifting personal philosophy** can provide the basis for such an attitude, especially when it emphasizes the importance of [virtues](//en.wikipedia.org/wiki/Forty-nine_character_virtues). This usually entails pondering the [meaning of life](//en.wikipedia.org/wiki/meaning_of_life) to determine what is important in life, and what approach to take. A positive outlook on life engenders positive emotion in life, which in turn inspires action.
  * **Dream envisioning** is daring to imagine the desired future. The stronger it is (through repetition) and the more detailed its outcome is, the more compelling the dream becomes as a road map for action. Making dreams come true is what success is all about, and a well-envisioned dream which remains "in view" at all times is one of the most powerful motivators there is. That's why visionaries are called visionaries. To live a life's dream is to think about it all the time, to continually think about everything _in terms of_ that dream.
  * **Determining self-worth** on one's own rather than by the opinions of others makes for a more stable emotional base. Psychologists are divided between endorsing unconditional self-love, personal potential, and earned self-worth as the best approach through which to evaluate one's self-worthiness. With unconditional self-love personal value is inherent: the individual holds themself in highest regard regardless of their actions, which is believed to provide the best environment to nurture the psyche for personal growth ("I am great because I exist"). When personal potential is the benchmark, it is one's personal skills and traits which matter, which focuses value on one's personal inventory (including ambition and willpower) in preparation for accomplishment ("I am capable of great things therefore I am worthy" and "I can accomplish anything I put my mind to, therefore I am worthy"). While in the earned self-worth model, self-worth is used as part of a reward structure: one must do great deeds if one is to see themself as great ("I have done great things, therefore I am worthy"). But all three of these approaches to self-imaging work better than caving in to the criticisms of others.
  * **Maintaining a positive mental voice** means refraining from self-criticism, keeping critiques directed upon actions and strategies rather than one's person, and replacing self-putdowns with uplifting self-encouragement. The main character in the children's tale [The Little Engine that Could](//en.wikipedia.org/wiki/The_Little_Engine_That_Could) provides a perfect example of this approach. While everyone else told the Little Engine that he would never make it up the mountain track, the Little Engine kept telling himself "I think I can, I think I can", even in the face of overwhelming odds, until his belief in himself carried him through. Then, on his way down the other side of the mountain he shouted in victory "I knew I could, I knew I could, I knew I could!" Now that's attitude in motion!
  * **Rebounding after a defeat**, like getting back in the saddle after falling off the horse, is usually better than giving up and not trying anything that big again. Volitional depression, a fancy term for discouragement, is where a person, after a big failure (like losing a fortune on the stock market, a divorce, going bankrupt, or a failed start-up company) retreats into themself or into an addiction (like drugs, becoming obsessed with the [internet](//en.wikipedia.org/wiki/internet), collecting things, or engaging in sex as often as possible) instead of taking on another big project to go after success yet again. The resilience to get back up after a failure and go for "it" again is much more conducive to success, and as a character trait is diametrically opposed to procrastination. The average successful entrepreneur fails six times before making it big. Keeping this in mind makes getting started again a lot easier, because it is a reminder that interim failure is temporary and is just part of the learning process of achievement -- winners keep going.
  * **Counting blessings** \- One aspect of ‘looking on the bright side’ is inventorying opportunities, skills, and strengths, rather than bemoaning problems, inadequacies, and weaknesses. Seeing a situation as a ‘glass half full’ rather than a ‘glass half empty’, is the more inspiring approach. It is easy to take everpresent things for granted, while complaining about things that are missing. Remember the saying “I felt really bad that I had no shoes, until I met a man who had no feet!” Appreciating those things that are usually taken for granted makes for a much better starting point than feeling sorry for oneself, plus it increases awareness of what resources there are to work with.
  * **Building on strengths** \- Make a list of all the things you already master. Ask yourself how you got to be an expert in doing these things - and then, try to explain the differences between your "can't-dos" and "can-dos". To what feelings and circumstances are they attached? You may be able to apply the same approaches you used on acquiring your current skills to attain the new skills you need.
  * **Building self-confidence** \- The only one source of self-confidence is enjoying success. But, the problem is that often you can only succeed against other people, e.g. by having equal or better marks than others. The problem is that you did procrastinate for such a long time that you are like a child which is learning to walk - but having put off the walking courses, it can only succeed when compared against a much younger baby. Stop comparing yourself with others - set your own goals! Get to know other people who find themselves in a like situation; you can learn from them that they did not fare better by comparing themselves with successful people.
  * **Being progressive** helps to put down your old feelings and habits. Remove old things from your room or apartment - they _are_ associated with your old personality. If you possess something that vigorously reminds you of a sad, unlucky era - then get rid of it.

Another way to beat procrastination is by leading a healthy lifestyle. An unhealthy lifestyle makes a person much more susceptible to stress, which leads to feelings of being overwhelmed, which can lead to procrastination. By making a few adjustments to their lifestyle, like how much they exercise, a person can greatly increase how much stress they can handle...

#### Increasing stress tolerance

Some people are more susceptible to stress than others. In other words, those others are more tolerable to stress than those susceptible. The greater your tolerance, the more stress it takes to get you down. Stress falling below one's tolerance threshold is "no big deal", and is easy to deal with. What many don't realize is that this tolerance level is adjustable -- it can be strengthened...

  * **Vigorous cardiovascular exercise** increases resistance to stress, boosts the immune system, and improves oxygen supply to the brain and general mental performance (including intellectual performance, ability to focus, memory, etc.). Such exercise include walking, speed walking, running, swimming, biking, hiking, and aerobics.
  * **Good nutrition**, including nutrient supplementation, improves cognitive performance, boosts the immune system, and provides the brain with the precursors necessary for it to make the stress-coping neurotransmitters it needs. **Abstaining from poor nutrition**, such as by cutting down on sweets and sugar drinks, reduces hyperactivity, difficulty focusing, and obesity (which hampers the immune system, general performance, and proclivity to exercise).
  * **Relaxation methods** such as [fractional relaxation](//en.wikipedia.org/wiki/fractional_relaxation), [progressive relaxation](//en.wikipedia.org/wiki/progressive_relaxation), trance induction, and meditation reduce the effects of stress: tension and anxiety. The ability to remain calm and worry-free in the face of stressful situational factors is called self-composure. The ability to stay tension-free during a stressful situation, including using only as much energy and muscle tension required to complete motions, is called relaxed poise. Combined together, these skills are called grace under pressure.

#### Enhancing mood control

Emotions, including moods, drive behavior. But our moods are our responsibility, and concerning each of them we can choose to feel that way or not. We can feel like throwing a tantrum and putting things off, or we can feel like doing something useful...

  * **Being alert to one's own moods** is preferable to not paying attention to what one is feeling (and consequentially to what one is doing because of these moods). The first step to changing a mood is to be aware of it. Here is a simple ABC of bad moods to keep a look out for: **a**ngry, **b**ored, **c**ranky, **d**readful, **e**asily distracted, **f**rustrated, **g**rumpy, **h**urt, **i**ll-tempered, **j**ustified, **k**icked, **l**azy, **m**ean, **n**osy, **o**bsolete, feeling like **p**utting it off until later, feeling like **q**uitting, **r**obbed, **s**elfish, **t**ired, **u**sed, **v**exed, **w**hipped, feeling like **y**elling at someone, **z**eroed in on (or **z**eroed out). When you spot one, you can catch yourself, and change your emotional approach: your mood.
  * **Positive filter** is to retain the positive thoughts and actions and ignore or keep out the negative ones. Negative thoughts tend to build up and often become pervasive in one's life. When we continuously encourage positive thoughts and suppress negative ones, we develop a better outlook towards life and ourselves.
  * **Changing expression** (such as one's facial expression) can change a person's mood. When you feel good, you smile. Conversely, and very useful for lifting one's own spirits is the fact that smiling (on purpose) generally makes people feel good. This is referred to in psychology as the 'facial feedback' hypothesis. And smiles are contagious, so others can catch them from you, and in turn, you can catch "smilitis" back from them. It's a synergistic arrangement. And when we're feeling good, we are much more likely to feel like getting started.
  * **Adjusting taste** is changing how you feel about something, like learning to love what you hate. This is accomplished by changing how you think about it: dwelling on the benefits and good traits of an activity may lead to actually liking it. Finding fun ways to do it, like turning it into a game, may also make it more enjoyable.
  * **Self-psyching**, or "psyching yourself up", is the self-administered pep-talk. You are your own coach delivering the motivational speech before the big game.
  * **Managing fear** \- One way to overcome fear is to face it. Usually, the more exposure one has to a stressful stimulus, the more used to it he gets. This is called desensitization.

### Improving thinking

If you've ever wondered "What was I thinking?!" after doing something really stupid (like putting off a very important project to the last minute, or playing when you should have been studying), maybe you weren't thinking at all. Or maybe your reasons weren't very good, because you didn't put enough thought into them. These problems are the result of a lack of concentration. The solution to distractions and opportunities competing for attention involves improving concentration and how one concentrates: acquiring better focusing and decision-making abilities. Here also, there are psychological and physiological approaches.

#### Paying attention

  * **Improving attention span** can be as easy as taking nutrient supplements called [nootropics](//en.wikipedia.org/wiki/nootropics). Below are a few nutrients which generally increase a person's ability to concentrate and enhance cognition in other ways as well, such as improving reasoning capacity and memory,[_[citation needed](/wiki/Wikibooks:OR)_] and which are available for sale at nutrition shops, drug stores and online, and are often available at grocery stores: 
    * **[DMAE](//en.wikipedia.org/wiki/DMAE)** (dimethylaminoethanol) - originally available as a prescription drug called Deaner, used for helping hyperactive children concentrate, DMAE is now available as a nutrient over the counter. [[1]](http://www.lef.org/magazine/mag2004/nov2004_aas_01.htm)
    * **[Choline](//en.wikipedia.org/wiki/Choline)** \- the precursor to acetylcholine, one of the brain's primary [neurotransmitters](//en.wikipedia.org/wiki/neurotransmitter) essential for higher cognitive processes including reasoning and memory.
    * **[Vitamin B-5](//en.wikipedia.org/wiki/Pantothenic_acid)** \- used as a cofactor in the brain's production of acetylcholine and essential for that process. Also a key component of the [Krebs acid cycle](//en.wikipedia.org/wiki/Krebs_cycle), an important step in the [aerobic metabolism](//en.wikipedia.org/wiki/aerobic_metabolism) of carbohydrates into chemical energy in the form of ATP ([Adenosine triphosphate](//en.wikipedia.org/wiki/Adenosine_triphosphate)), and thus capable of increasing energy available to brain cells, improving mental stamina.
  * **Focusing and refocusing** -

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Overcoming_Procrastination/Print_version&action=edit).

  * **Presence of mind** \-- It's not a coincidence that International Brain Awareness Week follows National Procrastination week.

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Overcoming_Procrastination/Print_version&action=edit).

  * **Removing, or getting away from, distractions** \-- distractions often cause people to procrastinate, by presenting the option to do something else, or by triggering deviations. To prevent this from happening, minimize the chance of distractions occurring: 
    * **Sometimes the thing causing the distraction can be removed.** If it is the TV or a video game, you can either turn it off, wear earplugs and/or hearing protectors, or go somewhere where you cannot hear it. If you find yourself turning the TV or video game on and watching or playing when you really shouldn't, then perhaps the most effective approach would be to get rid of the TV and video game console (including the game cartridges) by giving them away, or taking them to the dump. If it is a computer video game that has you hooked, maybe you can unload the program from your computer, and if that doesn't deter you, perhaps you can break the game disk! Sometimes removing the source of the distraction isn't an option, usually when other people are involved...
    * **If the distraction isn't allowed to be removed**, or if the distractions are caused by people, such as by family or roommates, maybe you can find somewhere quiet in which to continue your project. If there isn't anywhere in your home, then consider somewhere outside, in your car, at the library, etc. For some people, renting an office or apartment for a place to escape to, or moving out and living alone are options to consider.
    * **Remove distracting thoughts**. Perhaps you just can't begin your work because your mind is infested with distracting or energy-consuming thoughts, e.g. about a conflict with a friend or a "better" idea on how to use your time. Make a list of all these subjects - written down, you don't forget all your precious ideas and you can concentrate on them later. Never work on these thoughts first - they are the reason why you are procrastinating! If your hindering thoughts are too strong to have them removed or postponed by yourself, get the help of a clinical psychologist or a psychiatrist.

#### Thinking rationally

  * **Thinking it through** \-- this is reasoning through an intended course of action, going over why each step needs to be done, and predicting what benefits will likely result if they are completed. Also, making a mental list of the consequences that will be suffered if the tasks are not completed is part of this exercise. The virtual carrot and the stick. The goal here is to work out one's reservations and talk oneself into doing what needs to be done, taking care not to get stuck in transition (such as setting a time limit).
  * **Consciously deciding what to do** means switching off one's auto-pilot and actively applying intelligence with presence of mind: being aware of what you are doing and why, while remaining alert for opportunities to adapt and improve one's approach. Don't just go through the motions, actively think about what you are doing.

#### Improving problem solving skills

Try one or more of the techniques given in the [problem solving](//en.wikipedia.org/wiki/Problem_solving#Some_Problem_Solving_Techniques) article.

### Acquiring self-management skills

Since the tendency to procrastinate on a project is roughly proportional to the difficulty of the project, and since its difficulty is relative to our skill in handling such projects, it follows that improving our self-management and organizing skills (e.g. by breaking the project down into small parts) decreases relative difficulty of the project and therefore also reduces its likelihood of intimidating us into procrastinating it. Simply put, simple jobs aren't scary. The more skilled you are at handling projects, the easier such jobs become.

Self-management systems provide simple procedures to help focus efforts and may assist you in mastering your projects and your situation. Nobody plans to fail, but many people fail to plan. Self-management systems help to keep plans in clear focus. Following are some components of a typical self-management system...

#### Goal vision

This is a form of goal setting, but more involved. It entails choosing the goal and writing down the goal statement as usual. Then the goal is mentally envisioned as vividly as possible, in as much detail as possible, as often as free time allows, and in every spare moment that becomes available. The more the goal is thought about and the actions for achieving it mentally rehearsed, the more likely the goal will become a driving force of the person's behavior. This method is best suited for important projects and life goals.

#### Planning

  * Goal setting - write down your goal statement. Be as detailed as you can.
  * Setting selection criteria - what features must your plan have to be successful? These are the plan's selection criteria.
  * Generating strategies - figure out as many ways as you can that the goal could be achieved. Research it if needed. These are the action plans to choose from.
  * Selecting a course of action - based on your selection criteria, pick a strategy, your plan of action.
  * Develop the chosen plan in more detail - detail the plan down to the task level.
  * Putting the plan into action - see below.

Also, see the article on [managing goals](//en.wikipedia.org/wiki/goal_\(management\)).

#### Scheduling

Schedules help organizing your daily and weekly life. Though some people profit more than others from a scheduled working life, two things are common to good schedules: They are be both feasible and flexible.

A feasible schedule allows you, for example, to begin working without forcing yourself to get up early. When studying for an important exam, beginning to study at 9 AM each morning is feasible. It allows you to stay up until midnight, depending on your sleeping needs, and lets you enjoy the social life in the evening. A typical student is mentally able to learn 6-8 hours per day for an exam, so he or she should schedule this amount of study time maximally.

A flexible schedule is a schedule which is immune to disturbances. You should schedule your work around such things as mealtime (in order not to be interrupted by colleagues which want to have dinner with you) or your favorite TV program which you may or may not watch. If you are working and a relative or a neighbor asks for your help, your schedule should allow for catching up with the lost time.

This said, a good schedule meets your abilities and provides enough reserve time. A schedule which you cannot trust is one you should not follow. In case of failure, you pay with your precious time.

#### Capturing tasks on a general to-do list

A general [to-do list](//en.wikipedia.org/wiki/task_list) is a place to store tasks until you are ready to schedule them. It is typically a note pad that you keep handy (or a computer file that you keep open) for recording tasks as you think of them, to get them down in a central list where they won't be forgotten and can be easily referred to later. Tasks are regularly chosen from the general to-do list for inclusion in a more specific daily task list (see below).

#### Prioritizing tasks

Each task has a relative importance (cutting the grass is less important than studying for an exam). Tasks also have an expected duration (cutting the grass takes less time than studying for an exam). Most tasks are also time-sensitive (cutting the grass is flexible whereas studying must be complete before a fixed time). Prioritizing is the skill of reconciling these often conflicting attributes to determine which task ought to be performed first. In the context of a college exam, you could prioritize items as follows:

  * A: mandatory subjects. Knowing these certainly gives you a sufficient mark.
  * B: items which improve your understanding of the "A" topics. Studying them gives you probably, but not certainly, a good mark.
  * C: all other things. These will be studied last.

In an environment where more than one task is undertaken at once, and completion of some tasks is a prerequisite for starting other tasks, then a [Critical path](//en.wikipedia.org/wiki/Critical_path) is formed of tasks which have the highest priority.

#### Making and using a daily task list

At the end of the day, before you go to bed, or at the very beginning of the day, just after you wake up, prepare a to-do list for the day. List all the tasks you need or plan to get done that day. Place the tasks in order of priority, or grade their priority in the left-hand column with numbers. Throughout the day, focus on executing each task on the list, one task at a time, highest priority tasks first. When you accomplish one of the items on the list, you _check_ it off or _cross_ it off.

  
An alternative method is a task list, where each task is in a category of urgent/not urgent and important/not important. Take a sheet of paper and draw a 2x2 column table so that you have four each corresponding categories.

→ Whatever is in the category urgent/important: do it now, by yourself.

→ Whatever is in the category not urgent/important: delay/procrastinate (and enjoy), till category one is empty

→ Whatever is in the category urgent/not important: try to find someone to do it for you or at least help you do it.

→ Whatever is in the category not urgent/not important: forget it or accomplish one of these tasks as a gratification for a task completed in the first category, as these tasks have a tendency to be of the type "cut grass", "have barbecue", "buy stuff I really like" etc..

  
The traditional method is to write these on a piece of paper with a [pen](//en.wikipedia.org/wiki/pen) or [pencil](//en.wikipedia.org/wiki/pencil), usually on a note pad or clip-board. Loose hole-punched paper is often used to allow such lists to be inserted into loose-leaf binders for record-keeping. However, numerous software equivalents are now available, and many popular [e-mail](//en.wikipedia.org/wiki/e-mail) clients include task list applications, as do most [PDAs](//en.wikipedia.org/wiki/Personal_digital_assistant).

This is information about a wiki which one can edit as a personal organiser and store on the computer using just one file [A wiki-style possible personal organiser](//en.wikipedia.org/wiki/Tiddlywiki)

#### Keeping a journal

Making a record of what you have done (while you are doing it) can help you evaluate your performance and spot trouble-areas in your abilities and behaviors, like procrastinating. If you keep notes on task completion on your daily task lists, those can serve as your journal. Simply make note of situations that arose that you handled, and any tasks or significant activities that you did that were not on the list.

### Changing habits

In one sense, procrastination is the habit of not getting started. It is not an action, so much as the lack of an action. It is not a habit, so much as the lack of a habit: the habit of getting started. If one acquires the habit of getting started, then not getting started is no longer an issue. Another word for "get started" is initiate. It is the exact opposite of procrastinate, as long as it is applied to the right task, and not an evasion.

At the same time, an ongoing problem of procrastination is a complex of bad habits. Luckily, old bad ways can be replaced by new good ways. Acquiring new good habits through self-training is key to eliminating the bad habits of evasion and putting things off.

#### The 21-day principle

There are commercial workbooks available concerning this "21-day rule", especially from Essi Systems, which provides workbooks. In general: If one can maintain a new habit for 21 days, the chances that this new routine would be forgotten are dim. This alludes to the [detox](//en.wikipedia.org/wiki/detox) or deprivation methods in curing drug dependencies.

#### Identifying specific behaviors to change

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Overcoming_Procrastination/Print_version&action=edit).

#### Practicing replacement behaviors

  * Scheduling time for practice
  * Practicing new behaviors - mentally rehearse doing the task, and physically rehearse starting the task.

#### Quitting behavioral addictions

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**This section is a stub.**  
You can help Wikibooks by [expanding it](//en.wikibooks.org/w/index.php?title=Overcoming_Procrastination/Print_version&action=edit).

### Completing tasks

The above strategies are aimed at preventing procrastination, or replacing it while on "down-time". But no defense is infallible, and because the opportunities, temptations, and tendencies to put things off may occur at any time and place, due to a myriad factors, this calls for a collection of front-line coping and problem-solving methods to deal with these factors head-on. Like a "tackle" box for tackling tasks and situations, right here, right now...

#### Snapping out of it

Procrastination is really nothing more than confined thinking. All you see is the tiny little box you are trapped in, and all you can think about is how to escape. But in reality, you are already free. Free to work on your life's dreams, free to plan, free to achieve. The trick to overcoming procrastination is to look to the horizon of your life (your dreams), travel there, and enjoy the journey along the way. Focus on that always, and procrastination fades away like an early morning fog.

#### Maintaining perspective

Thinking about your dreams in terms of what you are willing to do right now, rather than what you'll do or be someday is a call to action. Transformation is an active process. You are on a journey this very moment. The question is, are you on the right journey? If you aren't going anywhere, or you are heading in the wrong direction (towards failure because you are putting things off), simply adjust course, and live the life you want to live. And if that means making a sacrifice, then go for it! Put in the time and effort required, using all the methods you've learned about above, all the while keeping in mind what it is you are working towards. Always look to the horizon: focus on your dreams, how to make them come true, and actually make them come true one moment and one task at a time.

#### Maintaining grace under pressure

The most effective way to overcome fear is to face it. Veterans are generally more stable under combat conditions simply because they've been through it before. One method for overcoming fear of heights is practicing climbing ladders, for instance. Stepping up to the first rung, repeated over and over, then two, repeated, and so on, proceeding to the next level only after mastering the one before.

Thrill activities may be good training in this regard. [Roller-coaster](//en.wikipedia.org/wiki/Roller-coaster) rides, [river rafting](//en.wikipedia.org/wiki/river_rafting), and [skydiving](//en.wikipedia.org/wiki/skydiving) can all lower sensitivity to perceived threats. Once you've jumped out of an airplane a few times, asking a girl out on a date may not seem that intimidating anymore. Perhaps an easier way of getting over fear of talking to girls is talking to them every chance you get.

Some drugs which are purported to cure phobias or treat anxiety have side effects that defeat the purpose if not used with extreme caution. [Propranolol](//en.wikipedia.org/wiki/Propranolol), for instance, a [beta blocker](//en.wikipedia.org/wiki/beta_blocker) which helps to turn off the fight-flight response has the side effect of causing depression, because it is also an [acetylcholine](//en.wikipedia.org/wiki/acetylcholine) [inhibitor](//en.wikipedia.org/wiki/inhibitor).

#### Tending the task list at all times

The task list doesn't do any good if it is not referred to, or if it is not updated frequently. Once using a task list and completing the items on it have become habit, placing a task on the list practically ensures it getting done. Relying continuously on this key tool is a core management skill and executive process. It is a standard method of operation in business for getting things done, and is a central component of competence. Frequently forgetting to do something may be a consequence of not writing it down (and keeping track of it) in the first place.

#### Focusing on one task at-a-time

  * **Find the highest priority task**, and then concentrate yourself on that one task and _forget_ all the others. Only when you have finished the first, move on to the next item on the list.
  * **Do something, but plan your time**: Do not just "do something", but do something in a defined time frame. Wash the dishes for exactly 15 minutes, and write a letter for 30 minutes. Control your time with a timer (most modern [cell phones](//en.wikipedia.org/wiki/cell_phone) have one); and fulfilling a (dreaded) task is a lot easier if you know how much time you'll spend.

#### Removing uncertainty

Often, a person will hesitate on or avoid a task because he or she just doesn't know where to begin. How to complete the task isn't obvious, therefore making the task undoable in its present form. The key here is task selection. Switch to the task's prerequisites: whatever other tasks need to be accomplished before this one can be started.

If you don't know what to do or how to do it, then your default task is to figure it out. If you don't know enough to solve a problem, then finding and learning the required information are the default tasks.

#### Dividing and conquering

  * **Breaking a project down** into its component pieces and subpieces will eventually reach a level of detail where the specific actions that need to be taken can be seen. Once action has started on a specific task, [flow](//en.wikipedia.org/wiki/Flow_\(psychology\)) may take over and the project may seem like it takes on a life of its own and actually becomes fun. And time flies when you're having fun.
  * **Take bite-sized morsels** \-- rather than sit down to "write your book", write one page. Writing one page is easy. When you are done with that page, then you can set about writing the next page. In general, try to plan your work in such a fashion that you've accomplished _something_ in a 30 or 60 minute's time, not only _a little bit of something_. Or, said in a better example: Instead of just learning hours and hours of chemistry, you specialize on a subject - like "I have problems understanding pH values, so I'll read the relevant chapter about it. Then I make a pause." In this approach, you _know_ that your ordeal has become manageable.

#### Easing into the task

You're faced with a task that will take you 20 hours, and you just aren't relishing it. Seen as one big step, the chore is rather ominous. Instead of approaching it like this, try committing to 5 minutes. Now the pressure is off. Five minutes is easy. During that five minutes you will likely see that your evasion was pointless, and that the activity isn't as bad as you thought it was. Once you begin a task and work on it for awhile, the initial stress goes away, and you are very likely to feel like continuing.

#### Stopping at the point of diminishing returns

  * **Avoiding [perfectionism](//en.wikipedia.org/wiki/perfectionism)** saves a lot of time. Try to do _sufficient_ works, not perfect ones - a start is a start. [Perfectionists](//en.wikipedia.org/wiki/Perfectionist) aren't any more likely to put things off than other procrastinators, but they are likely to spend much more time putting the finishing touches on a task than they need to. By avoiding perfectionism and by striving for "good" or at least "sufficient" work, you lower the bar of your expectations. The lower the bar, the greater the chance that you succeed - and having success is the only thing in the world that can give you a better self-esteem.

#### Feedback and record keeping

  * **Check off tasks as they are completed** \-- in the left-hand margin of your task list, use check-marks to keep track of which tasks you have completed. This provides a visual indicator of progress.

#### Scheduling breaks

Most people will, under normal circumstances, work at their best if they take a 10 minute break from their work each hour. Also make limits on your total daily work - when you're learning for an exam, you _can't_ learn more than 6 to 8 hours a day. Being a good student or co-worker does not force you to suffer from overworking or sleeplessness. If you can't adhere to a maximal working time per day, then you should learn to begin earlier instead of trying to work faster.

A lot of scientific work has shown that good learning - be it practical work that needs fine motorics of your hands or learning for a college exam - requires [sleep](//en.wikipedia.org/wiki/sleep), as the brain seems to fine-tune and rearrange what you've learned the day before. Try it out: Learn to [juggle](//en.wikipedia.org/wiki/juggle) balls or other [objects](//en.wikipedia.org/wiki/Egg_\(food\)); and when you begin the next learning period the day after, you magically appear to have less trouble in spite of the fact that you did _not_ practice during the night.

Remember: Like a musician has to _play_ so that you _hear_ the [rests](//en.wikipedia.org/wiki/Rest_\(music\)), you should work to let the pauses appear like pauses. "I didn't work" alone does not constitute a rest from work. It is the conscious doing of "anti-work" - when you did read texts to learn, then you don't read anything during your pause. When you worked half a day in your office, then escape your prison to enjoy the break.

#### Self-rewards

Another method of self-motivation is self-administered rewards - a method which reminds of [reinforcement](//en.wikipedia.org/wiki/reinforcement) in psychology. In this approach, even the smallest accomplishment deserves an appropriate reward, due _after_ a task is completed, not _before_. There are several approaches:

  * **Applying a reward structure** for spending given amounts of time working on a chore. For five hours of doing something you otherwise detest, make yourself a [fine meal](//en.wikipedia.org/wiki/obesity). For twenty hours, you go out for a movie, etc. You can even display your rewards symbolically: Take a post-it note, write down your reward, and with checkboxes define how many hours you want to work to achieve that reward. And remind yourself not to do the rewarding thing until you've filled all the checkboxes.
  * **Assigning someone else to give out the rewards** helps remove the temptation of taking the reward anyway. Of course they shouldn't be expected to provide the rewards - they should be unbribable, impartial people who effectively judge your efforts.

You should make a clear difference between the rewards and all the other things you receive (e.g. your meals at the cantina or watching the TV news). A good reward is something you enjoy and something you don't get every day. If the borderline blurs, a reward is no reward anymore; and so you tend to procrastinate even more because you get the "reward" anyway.

If you exercise a reward system strictly without cheating, there is a high chance that you'll be conquering your procrastination - this is because you get more and more accustomed to working and because you are needing less and smaller rewards over the time.

#### Recruiting peer support

  * **Do your work in a group** and start being used to tell your colleagues what you did and what you did not do. Start having friends you care for - and then, begin to fulfill their expectations. This works best if you are working together - being lazy on the group work often means losing your colleagues. Get a feeling for teamwork and that everyone has to fulfill their part. Working in a team is exciting, too. There are always ideas stemming from other minds, and by using them you can extend the scope of your own work without expending a lot of your own energy.
  * **Form a group of Procrastinators Anonymous.** You surely heard of other people who are "lazy". Now: Try to contact them. Suffering from procrastination means that one often is not respected by others; and so they are very shy to tell you about their problems. Telling others that you have a problem is the first part of _any_ cure; it connects your inner world to the perception of your friends and family members. Telling others about your problems raises the expectations of your fellow human beings, and last but not least fulfilling expectations is something very rewarding.

Seeking professional help should always be considered in addition to the above options.

# Chronic Procrastination

When procrastination grows so prevalent that it becomes a personality trait, its severity is said to be chronic. In this form of procrastination, the problem has become a generalized habitual self-destructive pattern. Putting tasks off has become a core habit. The chronic procrastinator cannot get anything accomplished on time, resulting in serious career struggles, persistent financial problems, and a diminished quality of life. Chronic procrastination may cause psychological disability and dysfunction in many dimensions of life, and may result in a persistent sense of [shame](//en.wikipedia.org/wiki/shame) and low [self-esteem](//en.wikipedia.org/wiki/self-esteem). It may be that the procrastinator never learned the habit of completing tasks from his or her parents, and since some scientists assume that every form of [behaviour](//en.wikipedia.org/wiki/behaviour) is a [learned](//en.wikipedia.org/wiki/Learning) one, such an environment could have coined his or her habits. The solution is for the procrastinator to rebuild his behavior complex upon the foundation of a new core habit of taking action. Unfortunately, the procrastinator is prone to procrastinate from this too, so the condition of chronic procrastination usually continues until the procrastinator cannot bear it any longer, and seeks out help or spontaneously realizes the willingness and determination to change his or her ways.

Many individuals who consider themselves "chronic procrastinators" are actually suffering from an underlying mental health problem such as [depression](//en.wikipedia.org/wiki/clinical_depression) or Attention Deficit Disorder ([ADD](//en.wikipedia.org/wiki/Attention-deficit_hyperactivity_disorder)). These individuals often do not understand why they cannot "get it together", and can become resigned to a life of struggle, frustration, and underachievement. There is, unfortunately, widespread ignorance about this constituent to procrastination, even amongst mental health professionals, some of whom see procrastination as simply a "bad habit".

In addition, some people are predisposed to [monotropism](//en.wikipedia.org/wiki/monotropism), a condition associated with [autism](//en.wikipedia.org/wiki/autism) in which there is a tendency to allocate attention to one task at a time, and to be less able than usual to multi-task or allocate segments of time for different priorities as may be needed. This may stem from many causes, including [obsessional](//en.wikipedia.org/wiki/obsession) disorders and [Asperger syndrome](//en.wikipedia.org/wiki/Asperger_syndrome). To these individuals, tasks perceived as less important or less urgent may be excessively deferred behind other tasks which receive undue attention or priority.

These disorders can be treated with medication and [psychotherapy](//en.wikipedia.org/wiki/psychotherapy), whereby the individual can learn new behaviors and achieve a greatly improved quality of life. Thus it is important for people who chronically struggle with debilitating procrastination to see a trained [therapist](//en.wikipedia.org/wiki/psychotherapy) or [psychiatrist](//en.wikipedia.org/wiki/psychiatry) to see if an underlying mental health issue may be present.

### Procrastination and addiction

Severe procrastination, and the intense desire to escape from it, can lead to [addictions](//en.wikipedia.org/wiki/addiction) such as [internet addiction](//en.wikipedia.org/wiki/internet_addiction) or [computer addiction](//en.wikipedia.org/wiki/computer_addiction). In this instance the individual has a compulsion to elude reality by surfing the web or playing video games (see [Game addiction](//en.wikipedia.org/wiki/Game_addiction)) or looking at pornography (see [Pornography addiction](//en.wikipedia.org/wiki/Pornography_addiction)).

Some of these relatively new phenomena are already being considered as valid psychiatric diagnoses by mental health professionals.

# Resources

![Search Wikiquote](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/34px-Wikiquote-logo.svg.png)
[Wikiquote](//en.wikiquote.org/wiki/) has a collection of quotations related to: _**[Procrastination](//en.wikiquote.org/wiki/Procrastination)**_

### Wikipedia articles

From [Wikipedia](//en.wikipedia.org/wiki/Main_Page), the free encyclopedia:

  * [Academic procrastination](//en.wikipedia.org/wiki/Academic_procrastination)
  * [Dynamic inconsistency](//en.wikipedia.org/wiki/Dynamic_inconsistency)
  * [Decision making](//en.wikipedia.org/wiki/Decision_making)
  * [Decision theory](//en.wikipedia.org/wiki/Decision_theory)
  * [Getting Things Done](//en.wikipedia.org/wiki/Getting_Things_Done)
  * [Goal (management)](//en.wikipedia.org/wiki/Goal_\(management\))
  * [Leadership](//en.wikipedia.org/wiki/Leadership)
  * [Skurfing](//en.wikipedia.org/wiki/Skurfing)

#### Methods used for overcoming procrastination

  * [Autosuggestion](//en.wikipedia.org/wiki/Autosuggestion)
  * [Hypnotherapy](//en.wikipedia.org/wiki/Hypnotherapy)
  * [Neuro-linguistic programming](//en.wikipedia.org/wiki/Neuro-linguistic_programming)
  * [Personal development](//en.wikipedia.org/wiki/Personal_development)
  * [Self-help](//en.wikipedia.org/wiki/Self-help)
  * [Silva method](//en.wikipedia.org/wiki/Silva_method)

### Web

#### Web books

  * _[Psychological Self-Help_](http://mentalhelp.net/psyhelp/); by Clayton E. Tucker-Ladd; Mental Health Net. Click _[here_](http://mentalhelp.net/psyhelp/chap4/chap4r.htm/) to turn directly to the section on procrastination.

#### Web articles

  * _[Causes of Procrastination_](http://wwwadmin.cl.uh.edu/ssc/sca/lss/causproc.htm); University of Houston Counselling Services
  * _[A Company’s Number One Killer: Procrastination_ (causes and cures)](http://www.winstonbrill.com/bril001/html/article_index/articles/551-600/article577_body.html); by Donald L. Caruth, Ph. D. and Gail D. Handlogten-Caruth
  * _[Deadlines and Procrastination Don’t Mix_](http://www.nationalseminarstraining.com/Articles/Category/Stress_Organization_Time_Management%20/DEADLINEPR/); National Seminars Group
  * _[Procrastination_ (causes & cures)](http://www.psu.edu/dept/altoonalrc/feb00.htm); Tutoring Times. Penn State LRC
  * _[Procrastination: Habit or Disorder?_](http://serendip.brynmawr.edu/bb/neuro/neuro02/web1/jmaryasis.html); by Jenny Maryasis
  * _[Putting things off (procrastinating)_](http://www.keele.ac.uk/depts/aa/studentsupport/counselling/problems/procrastination.htm); Keele University Student Support Division
  * _[Overcoming Procrastination_](http://www.stevepavlina.com/articles/overcoming-procrastination.htm); by [Steve Pavlina](/w/index.php?title=Steve_Pavlina&action=edit&redlink=1)
  * _[Overcoming Procrastination_](http://www.utexas.edu/student/utlc/learning_resources/motivation_procrastination/Overcoming_Procrastination.pdf); (University of Texas at Austin handout in PDF format. [Click this for Word format.](http://www.utexas.edu/student/utlc/learning_resources/motivation_procrastination/Overcoming_Procrastination.doc))
  * _[Design Your Own Anti Procrastination Plan_](http://www.utexas.edu/student/utlc/learning_resources/motivation_procrastination/Design_Your_Own_Anti_Procrastination_Plan.pdf); (University of Texas at Austin handout in PDF format. [Click this for Word format.](http://www.utexas.edu/student/utlc/learning_resources/motivation_procrastination/Design_Your_Own_Anti_Procrastination_Plan.doc))
  * _[7 Little Known Goal Setting Tips!_](http://www.cholawengue.com/tatu/forum/viewtopic.php?p=42&sid=fa0bae8e5f633939db2509cc6c023efe)
  * _[Some Facts Psychologists Know About… PROCRASTINATION_](http://www.uc.edu/psc/sh/SH_Procrastination.htm); University of Cincinnati Psychological Services Center (Broken link)
  * _[Stand and Deliver_ (causes of procrastination)](http://cms.psychologytoday.com/articles/pto-20030826-000017.html); by Maia Szalavitz. Psychology Today
  * _[Procrastination: Ten Things To Know_](http://www.psychologytoday.com/rss/index.php?term=pto-20030823-000001.xml&print=1); by Hara Estroff Marano. Psychology Today
  * _[Tips on Managing Procrastination_](http://www.kwantlen.bc.ca/counadvs/counselling/pdf/tips_on_managing_procrastination.pdf); Kwantlen University Counselling Services
  * _[Structured Procrastination_](http://www-csli.stanford.edu/~john/procrastination.html); by John Perry
  * _[There's Always Tomorrow. Interview with Joseph.R.Ferrari_](http://chronicle.com/colloquy/2005/12/procrastination/); The Chronicle of Higher Education

#### Websites

  * [Procrastinators Anonymous](http://www.procrastinators-anonymous.org/)
  * [Procrastination Support](http://www.procrastinationsupport.com/)
  * [Procrastination Research](http://www.procrastinus.com/)
  * [Structured Procrastination](http://www-csli.stanford.edu/~john/procrastination.html)

  


#### Bibliographies, reference lists

  * [References for Books, Journal Articles and Theses about Procrastination](http://http-server.carleton.ca/~tpychyl/prg/research/research_complete_biblio.html) (Procrastination Research Group).

### Books

  * _Awaken the Giant Within: How to Take Immediate Control of Your Mental, Emotional, Physical, & Financial Destiny_; by [Anthony Robbins](//en.wikipedia.org/wiki/Tony_Robbins). Simon & Schuster Adult Publishing Group, 1991. [ISBN 0671727346](/wiki/Special:BookSources/0671727346)
  * _The Complete Idiot's Guide to Overcoming Procrastination_; by Michelle Tullier. Alpha Publishing. 1999. [ISBN 0028636376](/wiki/Special:BookSources/0028636376)
  * _Do It Now!: Break the Procrastination Habit_; by William J. Knaus, with John W. Edgerly. Wiley, John & Sons, 1997. [ISBN 0471173991](/wiki/Special:BookSources/0471173991)
  * _Getting Things Done: The Art of Stress-Free Productivity_; by [David Allen](//en.wikipedia.org/wiki/David_Allen_\(author\)). Viking Adult, 2001. [ISBN 0670899240](/wiki/Special:BookSources/0670899240)
  * _The Now Habit_; by Neil Fiore. Tarcher, 1988. [ISBN 0874775043](/wiki/Special:BookSources/0874775043)
  * _Overcoming Procrastination: Or How to Think and Act Rationally in Spite of Life's Inevitable Hassles_; by Albert Ellis and William J. Knaus. Penguin Group (USA) Incorporated. 1979. [ISBN 0451087585](/wiki/Special:BookSources/0451087585)
  * _Procrastination: Why You Do It, What to Do about It_; by Jane B. Burka and Lenora Yuen, with Lenora M. Yuen. Perseus Publishing. 1990. Paperback, 227pp. [ISBN 020155089X](/wiki/Special:BookSources/020155089X)
  * _The Seven Habits of Highly Effective People_; by Stephen Covey. Simon & Schuster Adult Publishing Group, 2004. [ISBN 0743272455](/wiki/Special:BookSources/0743272455)
  * _Unlimited Power: The New Science of Personal Achievement_; by [Anthony Robbins](//en.wikipedia.org/wiki/Tony_Robbins). Random House Publishing Group, 1987. [ISBN 0449902803](/wiki/Special:BookSources/0449902803)
  * _Procrastination and Blocking: A Novel, Practical Approach_; by Robert Boice. Praeger Publishers, 1996. [ISBN 0275956571](/wiki/Special:BookSources/0275956571)
  * _Eat That Frog! 21 Great Ways to Stop Procrastinating and Get More Done in Less Time_; by Brian Tracy. Berrett-Koehler Publishers, 2001. [ISBN 1583762027](/wiki/Special:BookSources/1583762027)

### Audio Publications

  * _The On-Time, On-Target Manager: How a Last-Minute Manager Conquered Procrastination_; by Ken Blanchard and Steve Gotty, read by Brian Corrigan. HarperCollins, 2004. [ISBN 0060584815](/wiki/Special:BookSources/0060584815)
  * _The Procrastinator's Handbook: Mastering the Art of Doing It Now_; by Rita Emmett. Audio Renaissance. [ISBN 1593978472](/wiki/Special:BookSources/1593978472)

  


# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Overcoming_Procrastination/Print_version&oldid=2451628](http://en.wikibooks.org/w/index.php?title=Overcoming_Procrastination/Print_version&oldid=2451628)" 

[Categories](/wiki/Special:Categories): 

  * [Overcoming Procrastination](/wiki/Category:Overcoming_Procrastination)
  * [Section stubs](/wiki/Category:Section_stubs)

Hidden category: 

  * [Pages needing sources](/wiki/Category:Pages_needing_sources)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Overcoming+Procrastination%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Overcoming+Procrastination%2FPrint+version)

### Namespaces

  * [Book](/wiki/Overcoming_Procrastination/Print_version)
  * [Discussion](/w/index.php?title=Talk:Overcoming_Procrastination/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Overcoming_Procrastination/Print_version)
  * [Edit](/w/index.php?title=Overcoming_Procrastination/Print_version&action=edit)
  * [View history](/w/index.php?title=Overcoming_Procrastination/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Overcoming_Procrastination/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Overcoming_Procrastination/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Overcoming_Procrastination/Print_version&oldid=2451628)
  * [Page information](/w/index.php?title=Overcoming_Procrastination/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Overcoming_Procrastination%2FPrint_version&id=2451628)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Overcoming+Procrastination%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Overcoming+Procrastination%2FPrint+version&oldid=2451628&writer=rl)
  * [Printable version](/w/index.php?title=Overcoming_Procrastination/Print_version&printable=yes)

  * This page was last modified on 1 December 2012, at 15:07.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Overcoming_Procrastination/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
