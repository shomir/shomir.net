# Kicad/Print version

From Wikibooks, open books for an open world

< [Kicad](/wiki/Kicad)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Kicad](/wiki/Kicad)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Kicad/Print_version&action=purge&printable=yes) this page.

**KiCad** is an open source software suite for EDA (Electronic Design Automation)

# Table of contents

## Kicad

    [Introduction](/wiki/Kicad/Kicad#Introduction)
    [Installation and configuration](/wiki/Kicad/Kicad#Installation_and_configuration)
    [Use](/wiki/Kicad/Kicad#Introduction)

## File Formats

    [Schematic Files Format](/wiki/Kicad/file_formats#Schematic_Files_Format)
    [Schematic Libraries Files Format](/wiki/Kicad/file_formats#Schematic_Libraries_Files_Format)
    [Board File Format](/wiki/Kicad/file_formats#Board_File_Format)

# License

* * *

# Kicad

**Kicad Navigation**  


* * *

[Introduction](/wiki/Kicad/Introduction)  
[KiCad](/wiki/Kicad/Kicad)  
[eeschema](/wiki/Kicad/eeschema)  
[Introduction to eeschema](/wiki/Kicad/eeschema/Introduction)  
[eeschema commands](/wiki/Kicad/eeschema/General_Commands)  
[eeschema hierarchical sheets](/wiki/Kicad/eeschema/Hierarchical_Sheets)  
[File Formats](/wiki/Kicad/file_formats)  
[FAQ](/wiki/Kicad/FAQ)  
[Installing on Mac OS](/wiki/Kicad/Installing_on_Mac_OS)  


* * *

[Edit this box](http://en.wikibooks.org/w/index.php?title=Template:Kicad/Navigation&action=edit)

# Installation and configuration

## Display options

It is recommended to set your display/graphics card to use 24 or 32 bits per pixel. The 16-bit mode will work for Eeschema, but in Pcbnew the display will not function correctly under Linux in this mode.

## Initialization of the default configuration

A default configuration file (kicad.pro) is supplied in kicad/template. It serves as the template for each new project. It can be modified or added to if necessary, usually for the list of libraries to load. Run Eeschema via kicad or directly (Linux command; /usr/local/kicad/bin/eeschema). Update the configuration and then save it in /usr/local/kicad/template/kicad.pro

With Windows, to add a new library with Eeschema, go to **Preferences** \--> **Library** \--> Click on the **Add** button. Find the new library file (.lib extension), highlight it & click the **Open** button. Click the **OK** button when done.

## Principles of use

In order to manage simply a project, i.e. all the files it constitutes (representing schematics, printed circuit boards, supplementary libraries, manufacturing files for phototracing, drilling and automatic component placement), it is recommended to create a project: Create a working directory for the project (using kicad or by other means). In this directory, use kicad to create the project file (file .pro) via the icon.
    
    
     **It is strongly recommended to use the same name for the project and its directory.**
    

Kicad creates a file with a .pro extension that maintains a number of parameters relating to project management (such as the filename of the principal schematic, list of libraries used in the schematics and PCBs). The default names of both the principal schematic and the printed circuit board are based upon the name of the project. Thus, if a project called example was created in a directory called example, the default files created would be:

**example.pro** project management file.

**example.sch** principal schematic file.

**example.brd** printed circuit board file.

**example.xxx** various files created by the other utility programs.

**example.cache.lib** cache file of the libraries used in the schematic (backup of the components used)

# Use

## Main Window

The main window is composed of a tree view of the project, a pane containing buttons used to run the various utilities, and a message window.

The menu and the toolbar can be used to create, read and save project files (*.pro).

![Kicad utility main window BZR3976.png](//upload.wikimedia.org/wikipedia/commons/7/7c/Kicad_utility_main_window_BZR3976.png)

## Utility launch pane

![](//upload.wikimedia.org/wikipedia/commons/b/b8/Kicad_utility_launch_pane_BZR3976.png)

The launch pane

  * Pane actions
  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Kicad_utility_run_eeschema_BZR3976.png/46px-Kicad_utility_run_eeschema_BZR3976.png)

Run Eeschema

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Kicad_utility_run_cvpcb_BZR3976.png/46px-Kicad_utility_run_cvpcb_BZR3976.png)

Run Cvpcb

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Kicad_utility_run_pcbnew_BZR3976.png/46px-Kicad_utility_run_pcbnew_BZR3976.png)

Run Pcbnew

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/2/27/Kicad_utility_run_gerbview_BZR3976.png/46px-Kicad_utility_run_gerbview_BZR3976.png)

Run Gerbview

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/4/44/Kicad_utility_run_Bitmap2Component_BZR3976.png/46px-Kicad_utility_run_Bitmap2Component_BZR3976.png)

Run Bitmap2Component

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Kicad_utility_run_PCB-Calculator_BZR3976.png/46px-Kicad_utility_run_PCB-Calculator_BZR3976.png)

Run PCB Calculator

## Project tree view

![The project tree](//upload.wikimedia.org/wikipedia/commons/b/b7/Kicad_utility_tree_view.png)

Double-clicking on ![Kicad utility tree view eeschema file.png](//upload.wikimedia.org/wikipedia/commons/b/bb/Kicad_utility_tree_view_eeschema_file.png) runs the schematic editor, in this case opening the file interf_u.sch

Double-clicking on ![Kicad utility tree view pcbnew file.png](//upload.wikimedia.org/wikipedia/commons/4/44/Kicad_utility_tree_view_pcbnew_file.png) runs the layout editor, in this case opening the file interf_u.brd

Double-clicking on ![Kicad utility tree view cvpcb file.png](//upload.wikimedia.org/wikipedia/commons/7/78/Kicad_utility_tree_view_cvpcb_file.png) runs the footprint assign program (Cvpcb), in this case opening the file interf_u.net

Right (image) clicking allows files operations

## Toolbar

![Kicad utility toolbar new project.png](//upload.wikimedia.org/wikipedia/commons/b/b7/Kicad_utility_toolbar_new_project.png)

Create a configuration file for a new project. If the template kicad.pro is found in kicad/template, it is copied into the working directory.

![Kicad utility toolbar open project.png](//upload.wikimedia.org/wikipedia/commons/6/65/Kicad_utility_toolbar_open_project.png) Open an existing project.

![Kicad utility toolbar save project.png](//upload.wikimedia.org/wikipedia/commons/1/1a/Kicad_utility_toolbar_save_project.png) Update (save) the current configuration.

![Kicad utility toolbar archive project.png](//upload.wikimedia.org/wikipedia/commons/d/df/Kicad_utility_toolbar_archive_project.png) Create a zip archive of the whole project (schematic files, libraries, pcb, etc).

![Kicad utility toolbar refresh tree.png](//upload.wikimedia.org/wikipedia/commons/b/be/Kicad_utility_toolbar_refresh_tree.png) Redraw the tree list (useful after a tree change).

  


# File Formats

**Kicad Navigation**  


* * *

[Introduction](/wiki/Kicad/Introduction)  
[KiCad](/wiki/Kicad/Kicad)  
[eeschema](/wiki/Kicad/eeschema)  
[Introduction to eeschema](/wiki/Kicad/eeschema/Introduction)  
[eeschema commands](/wiki/Kicad/eeschema/General_Commands)  
[eeschema hierarchical sheets](/wiki/Kicad/eeschema/Hierarchical_Sheets)  
[File Formats](/wiki/Kicad/file_formats)  
[FAQ](/wiki/Kicad/FAQ)  
[Installing on Mac OS](/wiki/Kicad/Installing_on_Mac_OS)  


* * *

[Edit this box](http://en.wikibooks.org/w/index.php?title=Template:Kicad/Navigation&action=edit)

# file formats

Kicad creates and uses files of several different formats.

  * Files that end in ".sch" are schematics.
  * Files that end in ".lib" are schematic part library files.
  * Files that end in ".cache.lib" are schematic part library files, too. But the parts are only a cache for parts used in the current project the file is named for.
  * Files that end in ".pro" are project files
  * Files that end in ".dcm" add documentation to parts in the library file with the same name. The ".dcm" file contains the description, keywords and docfilename whereas the ".lib" file contains information about how the part is drawn, the pins etcetera.
  * Files that end in ".bak" ... are old backup files ... (Don't archive).
  * Files that end in ".bck" ... are old backup files ... (Don't archive).
  * Files that end in ".brd" are PCB layout files.

  


  * Files that end in ".000" ...
  * Files that end in ".cmp" ... are footprint information files that are modified by the PCBNew program
  * Files that end in ".erc" are output from the schematic electronic rules check (ERC).
  * Files that end in ".gcd" ...
  * Files that end in ".lst" are netlist output from the schematic. (Don't archive).
  * Files that end in ".net" are netlist output from the schematic. (Don't archive).
  * Files that end in ".mod" are module libraries (a KiCad "module" is called a "footprint" or a "decal" in other CAD software)
  * Files that end in ".mdc" ...
  * Files that end in ".dsn" are regenerated from the ".kicad_pcb" file every time you hit the "autoroute" button and then hit the "Export a Specctra Design (*.dsn) file". (Don't archive).
  * Files that end in ".ses" are session files output from the autorouter. (Don't archive).

# Schematic Files Format

## Units

Sizes and coordinates are given in mils (1/1000 inch)

## Header

**EESchema Schematic File Version 1**

**LIBS**: libraries list (not used, for information only).

**EELAYER** nn mm (nn mm not used, reserved)

**EELAYER END**

**$Descr** Sheet size dimx dimy (sheet size = A4..A0 ou A..E)

Title block description (Texts of the title block)

**$EndDescr**
    
    
    EESchema Schematic Spins Version 1
    LIBS:brooktre, cypress, ttl, power, linear, memory, xilinx, idiot, aaci, INTEL, special, device, dsp
    EELAYER 20 0
    EELAYER END
    $Descr A3 16535 11700
    Sheet 1 4
    ""
    Date “28 DEC 1996”
    Rev ""
    Comp ""
    Comment1 ""
    Comment2 ""
    Comment3 ""
    Comment4 ""
    $EndDescr
    

A later example:

**$Descr size w h** (size = A4..A0, A..E, or User. w = width(mils), h = height(mils), w and h are ignored unless size = User)

**Sheet m n** (m is the current sheet number, n is the total number of sheets. It appears that a sheet will not appear in the project list unless it is m = 1)
    
    
    EESchema Schematic File Version 2  date 4/15/2011 3:59:54 PM
    LIBS:mylib
    LIBS:transistors
    LIBS:someotherlib
    EELAYER 25 0
    EELAYER END
    $Descr A4 11700 8267
    Sheet 1 1
    Title "DC Supply"
    Date "15 apr 2011"
    Rev "1"
    Comp "Circuits R Us"
    Comment1 ""
    Comment2 ""
    Comment3 ""
    Comment4 ""
    $EndDescr
    

## Description of a component

**Format:**

$Comp

L name reference

U N mm time_stamp

P _posx_ _posy_

_List of fields:_

F _field_number_ “_text_” _orientation_ posX posY size Flags (see below)

1 posx posy (redundant: not used)

A B C D ( orientation matrix with A, B, C, D = - 1, 0 or 1)

$EndComp

**Description of the fields:**

F n “text” orientation posX posY dimension flags

with n = field number (reference field = 0, value field = 1, N = 0..11)

orientation = H (horizontal) or V (vertical).

**Example:**
    
    
    $Comp
    L CONN_3 JP3
    U 1 1 329879E1
    P 1200 2000
    F 0 “JP3” H 1250 2200 60 0000
    F 1 “CONN_3” V 1350 2000 50 0000
    1 1200 2000
    - 1 0 0 - 1 
    $EndComp
    

## Description of a NoConnect symbol

**Format:**

NoConn ~ posx posy

**Example:**
    
    
    NoConn ~ 13400 5500
    

## Description of a hierarchical sheet symbol

**Format:**

$Sheet

S posx posy dimx dimy

List of Sheet Labels

$EndSheet

**Format of Sheet Labels:**

Fn “text” forms side posx posy dimension

With:

n = sequence number (0..x).

n = 0: name of the corresponding schematic file.

n = 1: name of the sheet of hierarchy.

form = I (input) O (output)

side = R (right) or L (left).

**Example:**
    
    
    $Sheet
    S 1800 1600 1500 1500
    F0 “PROGALIM.SCH” 60
    F1 “PROGALIM.SCH” 60
    F2 “CLK” O R 3300 1800 60 
    F3 “/RESET” O R 3300 2000 60 
    F4 “VPWR” O R 3300 2700 60 
    F5 “/HALT” O R 3300 2100 60 
    F6 “TRANSF1” I L 1800 1900 60 
    F7 “TRANSF2” I L 1800 2000 60 
    F8 “3.84MH” O R 3300 2200 60 
    $EndSheet
    

## Description of a text note

**Format:**

Text Notes posx posy orientation dimension ~ _Text_

**Example:**
    
    
    Text Notes 2100 3250 1 60 ~
    TOTO
    

## Description of a Global Label

**Format:**

Text GLabel posx posy orientation dimension shape

Text

**Example:**
    
    
    Text GLabel 3100 2500 2 60 UnSpc
    TITI
    Text GLabel 3150 2700 1 60 3State
    3STATES
    Text GLabel 2750 2800 0 60 UnSpc
    BIDI
    Text GLabel 2750 2650 0 60 Output
    GLABELOUT
    Text GLabel 2750 2400 0 60 Input
    RESET
    

## Description of a Hierarchical label

**Format:**

Text HLabel _posx posy orientation dimension shape_

_Text_

**Example:**
    
    
    Text HLabel 3400 2000 0 60 Input
    /RESET
    

## Description of a label

**Format:**

Text Label _posx posy orientation dimension_ ~

_Text_

**Example:**
    
    
    Text Label 3400 2000 0 60 ~
    /RESET
    

## Description of a junction

**Format:**

Connection ~ _posx posy_

**Example:**
    
    
    Connection ~ 13300 6500
    

## Description of a wire segment (Wire)

**Format:**

Wire Wire Line

_startx starty endx endy_

**Example:**
    
    
    Wire Wire Line
    3300 1800 3900 1800
    

## Description of a Bus segment

**Format:**

Wire Bus Line

_startx starty endx endy_

**Example:**
    
    
    Wire Bus Line
    3900 5300 4500 5300
    

## Description of a dotted line segment

**Format:**

Wire Notes Line

_startx starty endx endy_

**Example:**
    
    
    Wire Notes Line 
    2850 3350 2850 3050
    

## Description of a bus entry

**Format:**

For an entry wire/bus :

Wire Wire Bus

_startx starty endx endy_

  
For an entry bus/bus :

Wire Bus Bus

_startx starty endx endy_

  
**Example:**

Wire/Bus:
    
    
    Entry Wire Bus
    4100 2300 4200 2400
    

Bus/Bus:
    
    
    Entry Bus Bus
    4400 2600 4500 2700
    

# Schematic Libraries Files Format

## Units

Sizes and coordinates are given in mils (1/1000 inch)

## Headings

**Format:**
    
    
    EESchema-LIBRARY Version 2.0 24/1/1997-18:9:6
    description of the components
    # End Library
    

## Description of a component

**The format is as follows :**

**DEF** name reference unused text_offset draw_pinnumber draw_pinname unit_count units_locked option_flag

**F0** reference posx posy text_size text_orient visibility htext_justify vtext_justify

**F1** name posx posy text_size text_orient visibility htext_justify vtext_justify

**F2** ???

**F3** ???

**$FPLIST**

footprint list

**$ENDFPLIST**

**ALIAS** name1 name2 name3 fields list

**DRAW**

list graphic elements and pins

**ENDDRAW**

**ENDDEF**

**Example:**
    
    
    DEF BNC P 0 40 Y NR 1 L NR
    F0 “P” 10.120 60 H V L C
    F1 “BNC” 110 - 60 40 V V L C
    DRAW
    C 0 0 70 0 1 0
    C 0 0 20 0 1 0
    X Ext. 2 0 - 200 130 U 40 40 1 1 P
    X In 1 - 150 0.130 R 40 40 1 1 P
    ENDDRAW
    ENDDEF
    

  


### Description of DEF

This is the component definition line.

**Format:**

**DEF** _name reference unused text_offset draw_pinnumber draw_pinname unit_count units_locked option_flag_

  * name = component name in library (74LS02 ...)
  * reference = Reference ( U, R, IC .., which become U3, U8, R1, R45, IC4...)
  * unused = 0 (reserved)
  * text_offset = offset for pin name position
  * draw_pinnumber = Y (display pin number) or N (do not display pin number).
  * draw_pinname = Y (display pin name) or N (do not display pin name).
  * unit_count = Number of part ( or section) in a component package. Limit is 26 (shown as chars form A to Z).
  * units_locked = = L (units are not identical and cannot be swapped) or F (units are identical and therefore can be swapped) (Used only if unit_count > 1)
  * option_flag = N (normal) or P (component type "power")

### Description of F0 and F1

F0 is the component reference line. F1 is the component name line.

**Format:**

**F0** _reference posx posy text_size text_orient visibile htext_justify vtext_justify_

**F1** _name posx posy text_size text_orient visibility htext_justify vtext_justify_

  * reference = Reference ( U, R, IC .., which become U3, U8, R1, R45, IC4...)
  * name = component name in library (74LS02 ...)
  * posx, posy = position of the text label
  * text_size = Size of the displayed text
  * text_orient = Displayed text orientation (V=Vertical, H=Horizontal(default))
  * visible = Is label displayed (I=Invisible, V=Visible(default))
  * htext_justify = Horizontal text justify (L=Left, R=Right, C=Centre(default))
  * vtext_justify = Vertical text justify (T=Top, B=Bottom, C=Centre(default))

### Description of $FPLIST

This line exists if one or more footprints are specified. Footprint names can have wildcards.

### Description of ALIAS

This line exists only if the component has alias names.

**Format:**

**ALIAS** _name1 name2 name3…_

### Description of DRAW

Lists graphic elements and pins. Each line defines a single element. The line starts with a single character indicating the type e.g. P indicates a polygon. The following items are commonly used in some of the elements:

  * posx, posy = Position of the graphic element
  * unit = unit no. in case of multiple units
  * convert = In case of variations in shape for units, each variation has a number. 0 indicates no variations. For example, an inverter may have two variations - one with the bubble on the input and one on the output.
  * thickness = line thickness
  * fill = fill colour (F=filled with foreground colour, f=filled with background colour, N=Not filled(default))

#### A record (Arc)

**A** _posx posy radius start_angle end_angle unit convert thickness fill startx starty endx endy_

  * posx, posy = centre of the circle part of which is the arc
  * radius = radius of the lost arc
  * start_angle = start angle of the arc in tenths of degrees
  * end_angle = end angle of the arc in tenths of degrees
  * startx, starty = coordiantes of the start of the arc
  * endx, endy = coordinates of the end of the arc

#### C record (Circle)

**C** _posx posy radius unit convert thickness fill_

  * posx, posy = centre of the circle
  * radius = radius of the circle

#### P record (Polyline)

The polyline has a series of points. It need not described a closed shape i.e. a polygon. To do this make the first pair the same as the last pair.

**P** _point_count unit convert thickness (posx posy)* fill_

  * point_count = no. of coordinate pairs. posx and posy are repaeated these many times.

#### S record (Rectangle)

**S** _startx starty endx endy unit convert thickness fill_

  * startx, starty = Starting corner of the rectangle
  * endx, endy = End corner of the rectangle

#### T record (Text)

**T** _direction posx posy text_size text_type unit convert text_

  * direction = Direction of text(0=Horizintal, 900=Vertical(default))
  * text_size = Size of the text
  * text_type = ???
  * text = Text to be displayed. All ~ characters are replaced with spaces.

#### X record (Pin)

**X** _name num posx posy length direction name_text_size num_text_size unit convert electrical_type pin_type_

  * name = name displayed on the pin
  * num = pin no. displayed on the pin
  * posx = Position X same units as the length
  * posy = Position Y same units as the length
  * length = length of pin
  * direction = R for Right, L for left, U for Up, D for Down
  * name_text_size = Text size for the pin name
  * num_text_size = Text size for the pin number
  * electrical_type = Elec. Type of pin (I=Input, O=Output, B=Bidi, T=tristate,P=Passive, U=Unspecified, W=Power In, w=Power Out, C=Open Collector, E=Open Emitter, N=Not Connected)
  * pin_type = Type of pin or "Graphic Style" (N=Not Visible, I=Invert (hollow circle), C=Clock, IC=Inverted Clock, L=Low In (IEEE), CL=Clock Low, V=Low Out (IEEE), F=Falling Edge, NX=Non Logic). Optional (when not specified uses "Line" graphic style).

# Board File Format

## General Informations

## Layer numbering

1\. Back - Solder

2\. Inner

3\. Inner

5\. Inner

6\. Inner

7\. Inner

8\. Inner

9\. Inner

10\. Inner

11\. Inner

12\. Inner

13\. Inner

14\. Inner

15\. Front - Component

16\. Adhestive/glue Back

17\. Adhestive/glue Front

18\. Solder Paste Back

19\. Solder Paste Front

20\. SilkScreen Back

21\. SilkScreen Front

22\. SolderMask Back

23\. SolderMask Front

24\. Drawings

25\. Comments

26\. ECO1

27\. ECO2

28\. Edge Cuts

## First line of description

## $GENERAL

## $SHEETDESCR

## $SETUP block

## $EQUIPOT

## $MODULE

### General description

### Field Description

### Drawings

All physical units are in mils (1/1000th inch) unless otherwise noted. The default layer number for graphic segments is 21, which corresponds to SilkS_Front.

**DS** _x1 y1 x2 y2 width layer_

    Draws a line segment from (_x1_, _y1_) to (_x2_, _y2_) with width _width_ on the _layer_ number specified.

**DC** _x1 y1 x2 y2 width layer_

    Draws a circle whose center is (_x1_, _y1_), and whose radius is specified by the segment (_x1_, _y1_) - (_x2_, _y2_) with line width _width_ on the _layer_ number specified.

**DA** _x1 y1 x2 y2 angle width layer_

    Draws a circular arc. Center is at (_x1_, _y1_). The arc's starting point is (_x2_, _y2_). The length of the arc sweeps clockwise (for positive angles) from here by the number of degrees specified by (_angle_ / 10).

### Pad Descriptions

### $SHAPE3D

### $PAD

## Graphic items

### $DRAWSEGMENT

#### Line

#### Circle

### Arc

### $TEXTPCB

### $MIRE

### $COTATION

## Track, vias and Zone section

### $TRACK

Comes in **Po**, **De** pairs. Example:

    **Po** 0 38900 95200 39500 95800 80 -1
    **De** 0 0 1 0 80000

  
**Po** _?_ _x1_ _y1_ _x2_ _y2_ _width_ _?_

**De** _layer_ _?_ _net_ _?_ _flags_

    flags bitfield: Unknown length (probably 32 bit), printed as hex with leading 0's truncated. 

    Binary: ???? ???? al?? ????  ???? ????  ???? ???? 

    a = Autorouted Flag
    l = (Segment?) Locked Flag

 

**Example:** _(open a new .brd file, add a track, save it - and then insert/replace the changes below in a text editor; no nets are assigned)_
    
    
    PCBNEW-BOARD Version 1 date 2012-03-18T07:15:54 CET
    # Created by Pcbnew(2010-00-09 BZR 23xx)-stable
    $GENERAL
    LayerCount 6
    Ly 1FFF801F
    EnabledLayers 1FFF801F
    ....
    $TRACK
    # gray track (Inner4 - jumper layer):
    Po 0 32000 25250 32000 23250 80 -1
    De 3 0 0 0 0
    #
    # red track (front layer):
    Po 0 24250 10750 24250 25250 80 -1
    De 15 0 0 0 0
    #
    # green track (back layer):
    Po 0 24250 25250 30000 25250 80 -1
    De 0 0 0 0 0
    #
    # via between red and green track:
    Po 3 24250 25250 24250 25250 350 -1
    De 15 1 0 0 0
    #
    $EndTRACK
    ...
    

### $ZONE

### $CZONE_OUTLINE

## $EndBOARD

# License

# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Kicad/Print_version&oldid=1231103](http://en.wikibooks.org/w/index.php?title=Kicad/Print_version&oldid=1231103)" 

[Category](/wiki/Special:Categories): 

  * [Kicad](/wiki/Category:Kicad)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Kicad%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Kicad%2FPrint+version)

### Namespaces

  * [Book](/wiki/Kicad/Print_version)
  * [Discussion](/w/index.php?title=Talk:Kicad/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Kicad/Print_version)
  * [Edit](/w/index.php?title=Kicad/Print_version&action=edit)
  * [View history](/w/index.php?title=Kicad/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Kicad/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Kicad/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Kicad/Print_version&oldid=1231103)
  * [Page information](/w/index.php?title=Kicad/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Kicad%2FPrint_version&id=1231103)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Kicad%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Kicad%2FPrint+version&oldid=1231103&writer=rl)
  * [Printable version](/w/index.php?title=Kicad/Print_version&printable=yes)

  * This page was last modified on 16 July 2008, at 12:41.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Kicad/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
