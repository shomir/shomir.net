# Annotations of The Complete Peanuts/Print version

From Wikibooks, open books for an open world

< [Annotations of The Complete Peanuts](/wiki/Annotations_of_The_Complete_Peanuts)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Annotations_of_The_Complete_Peanuts/Print_version) on _21 October 2010_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&oldid=1953900&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Annotations of The Complete Peanuts](/wiki/Annotations_of_The_Complete_Peanuts)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&action=purge&printable=yes) this page.

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Charles_Schulz_NYWTS.jpg/220px-Charles_Schulz_NYWTS.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Charles M. Schulz, creator of _Peanuts_.

Since 2004, Fantagraphics Books has been republishing the complete run of the comic strip _[Peanuts](//en.wikipedia.org/wiki/Peanuts)_ in hardcover form, starting from the origin of the strip in October 1950.

[Charles M. Schulz](//en.wikipedia.org/wiki/Charles_M._Schulz) made frequent topical references within the strip to the events and popular culture of the time, which would have required no explanation for a contemporary reader. Some of these references are now rather obscure, and might not be understood by someone not versed in the popular culture of the period. These annotations aim to provide background for such references, and explain their significance.

Each chapter corresponds with a separate volume from the Fantagraphics series, corresponding to two years of the published strips. The original publication dates of the strips are given in addition to the page numbers of the collection, so this reference work can also be used by people with access to the original archives.

## Contents

  * 1 1950–1952
  * 2 1953–1954
  * 3 1955–1956
  * 4 1957–1958
  * 5 1959–1960
  * 6 1961–1962
  * 7 References

## 1950–1952

Annotations to _**The Complete Peanuts: 1950 to 1952**_ by Charles M. Schulz (Fantagraphics Books, 2004. [ISBN 156097589X](/wiki/Special:BookSources/156097589X))

  * p. 9 (October 31, 1950). One of the games of [marbles](//en.wikipedia.org/wiki/marbles) involves shooting one marble out of a ring with another.
  * p. 11 (November 17, 1950). Although _Peanuts_ is famous for its complete absence of adults, they were occasionally seen and heard in the earliest years of the strip (see June 3, 1952).
  * p. 24 (December 21, 1950). First appearance of Charlie Brown's famous zig-zag striped shirt. (See p. 278, December 8 1952, for the "negative" of this shirt.)
  * p. 25 (December 25, 1950). "Through the woods to grandmother's house" is from Lydia Maria Child's 1844 song "[Over the River and Through the Woods](//en.wikipedia.org/wiki/Over_the_River_and_Through_the_Woods)", which the children also sing at the end of the 1973 television special _[A Charlie Brown Thanksgiving](//en.wikipedia.org/wiki/A_Charlie_Brown_Thanksgiving)_.
  * p. 30 (January 11, 1951). A [filibuster](//en.wikipedia.org/wiki/filibuster) is an attempt to delay the proceedings of a legislature. Shermy is stalling for time to get his homework done.
  * p. 38 (February 9, 1951). [George Washington](//en.wikipedia.org/wiki/George_Washington), [Thomas Jefferson](//en.wikipedia.org/wiki/Thomas_Jefferson), and [Abraham Lincoln](//en.wikipedia.org/wiki/Abraham_Lincoln) were three of America's greatest presidents. (Along with [Theodore Roosevelt](//en.wikipedia.org/wiki/Theodore_Roosevelt), they are the faces on [Mount Rushmore](//en.wikipedia.org/wiki/Mount_Rushmore).)
  * p. 46 (March 8, 1951). Patty is using a [typewriter](//en.wikipedia.org/wiki/typewriter).
  * p. 49 (March 21, 1951). "Mad dog" refers to a dog with [rabies](//en.wikipedia.org/wiki/rabies). Rabid dogs are usually killed by local authorities (c.f. _[To Kill a Mockingbird](//en.wikipedia.org/wiki/To_Kill_a_Mockingbird)_).
  * p. 67 (May 23, 1951). "Second childhood" refers to mental impairment as a result of old age. It was a [euphemism](//en.wikipedia.org/wiki/euphemism) for such things as what we now know to be [Alzheimer's disease](//en.wikipedia.org/wiki/Alzheimer%27s_disease).
  * p. 71 (June 4, 1951). In the early 20th century, people unhappy with the squalor and crime of big cities went "back to the soil" and became farmers. It was an attempt to re-connect with nature and enjoy "the simple life." What Charlie Brown was referring to was playing in his sandbox.
  * p. 79 (July 4, 1951). It is generally thought that the convention of a man walking nearest the curb is so that he and not the lady would be splashed by passing carriages or by someone above emptying a [chamber pot](//en.wikipedia.org/wiki/chamber_pot).
  * p. 84 (July 21, 1951). In the early part of the 20th century, when a young lady went out on a date, she didn't need to bring any money since the man would pay for everything. But it was recommended that she carry some "mad money", in case the man did something that angered her (made her mad), so she could end the date and have her own money to take a [street car](//en.wikipedia.org/wiki/tram) or [taxi](//en.wikipedia.org/wiki/taxicab) home.
  * p. 91 (August 13, 1951). "Comic magazine" and "[comic book](//en.wikipedia.org/wiki/comic_book)" are used interchangeably throughout the early days of the strip, with the former eventually dropping out of use. (See p. 17, November 29, 1950 for the first use of "comic book".)
  * p. 93 (August 21, 1951). [Neptune](//en.wikipedia.org/wiki/Neptune_\(mythology\)) is the ancient Roman god of the seas.
  * p. 103 (September 26, 1951). Charlie Brown misunderstood; it's the [New York _Phil_harmonic](//en.wikipedia.org/wiki/New_York_Philharmonic), one of America's finest symphony [orchestras](//en.wikipedia.org/wiki/orchestra).
  * p. 105 (October 2, 1951). Schroeder is playing the slow movement (Grave) from [Beethoven's](//en.wikipedia.org/wiki/Ludwig_van_Beethoven) Piano Sonata No. 8 op. 13, "Pathetique."
  * p. 108 (October 13, 1951). In a less politically sensitive time (white) children would play "Cowboys and Indians," a game in which they would chase and pretend to shoot each other, with either imaginary guns—a child's index finger being the gun's barrel and the thumb the hammer (See Volume 2's August 7 1954, p. 250, for Lucy's clever take on this "hand gun") -- or using toy weapons. (See p. 148, February 10 1952, for a full-scale production of the game.)
  * p. 114 (November 1, 1951). Children in the United States used to ask for money or candy on [Halloween](//en.wikipedia.org/wiki/Halloween). In the 21st century, it's become almost exclusively candy.
  * p. 124 (December 6, 1951). The proper technique for [ice fishing](//en.wikipedia.org/wiki/ice_fishing) is to cut a hole in the ice—which is what Charlie Brown does six days later in the December 13, 1951 strip, p. 126.
  * p. 125 (December 10, 1951). Someone else has drawn a picture of Charlie Brown on the sidewalk. He adds the legend "Don't Tread on Me" so that people won't scuff up his picture (scuffing him in effigy). The phrase "Don't Tread on Me" along with the image of a rattlesnake became popular during the [American Revolution](//en.wikipedia.org/wiki/American_Revolution) and is seen on the [Gadsden flag](//en.wikipedia.org/wiki/Gadsden_flag). It remains a symbol of defiance against oppression.
  * p. 135 (January 12, 1952). Charlie Brown is "driving" a [soapbox car](//en.wikipedia.org/wiki/Soapbox_\(car\)), a car made of wooden boxes, with no motor, that only goes downhill due to gravity.
  * p. 136 (January 13, 1952). [Alexander Graham Bell](//en.wikipedia.org/wiki/Alexander_Graham_Bell) is generally credited with the invention of the telephone.
  * p. 137 (January 15, 1952). The expression "Born on the wrong side of the (railroad) tracks" means to be poor, but Charlie Brown is using it here to mean unlucky. The snow man was unlucky enough to be born where it's sunny (because it's melted him).
  * p. 137 (January 16, 1952). Prelude in C major from [Johann Sebastian Bach](//en.wikipedia.org/wiki/Johann_Sebastian_Bach)'s [Well-Tempered Clavier](//en.wikipedia.org/wiki/Well-Tempered_Clavier) (Book 1), [BWV846](//en.wikipedia.org/wiki/BWV).
  * p. 140 (January 23, 1952). This musical piece is more commonly referred to as Beethoven's _[Piano Sonata No. 29 in B flat major_](//en.wikipedia.org/wiki/Piano_Sonata_No._29_\(Beethoven\)). This is also the music for March 25 and April 14. A Hammer-Klavier (in correct German, _Hammerklavier_) is simply the German word for piano. Schulz lettered those German words in [blackletter script](//en.wikipedia.org/wiki/Blackletter), which was still in use in Germany at the time. (See also p. 206, June 24, 1952, below).
  * p. 144 (February 1, 1952). The large disc they are listening to is a [phonograph record](//en.wikipedia.org/wiki/Gramophone_record), the precursor to a [compact disc](//en.wikipedia.org/wiki/compact_disc).
  * p. 146 (February 4, 1952). [Albert Payson Terhune](//en.wikipedia.org/wiki/Albert_Payson_Terhune) was the author of many stories and novels about dogs, most notably _Lad, a Dog_.
  * p. 148 (February 10, 1952). Charlie Brown is mis-singing [Stephen Foster](//en.wikipedia.org/wiki/Stephen_Foster)'s "[Old Folks at Home](//en.wikipedia.org/wiki/Old_Folks_at_Home)" (More commonly know by its first line, "Way down upon the Swanee River"). "Old Chisel Home Trail" is the [Chisholm Trail](//en.wikipedia.org/wiki/Chisholm_Trail), a cattle drive route from Texas to Kansas in the 19th Century.
  * p. 159 (March 7, 1952). Charlie Brown and Snoopy are playing [William Tell](//en.wikipedia.org/wiki/William_Tell), the legendary Swiss hero who shot an apple from his son's head with an arrow.
  * p. 160 (March 9, 1952). The joke is that in the three hours they played (a common length of time for a round of [golf](//en.wikipedia.org/wiki/golf)), they only made it as far as the 1st (of 18) holes.
  * p. 162 (March 13, 1952). [Banbury Cross](//en.wikipedia.org/wiki/Banbury) is a real place in England, but Charlie Brown is undoubtedly thinking of the nursery rhyme "[Ride a Cock Horse to Banbury Cross](//en.wikipedia.org/wiki/Ride_a_cock_horse_to_Banbury_Cross)."
  * p.169 (March 30, 1952). The songs Lucy wants to hear are "[Three Blind Mice](//en.wikipedia.org/wiki/Three_Blind_Mice)" and "[Twinkle Twinkle Little Star](//en.wikipedia.org/wiki/Twinkle_Twinkle_Little_Star)."
  * p. 171 (April 3, 1952). Charlie Brown is delivering the traditional whistle of appreciation for feminine beauty (though it usually has two notes: [WEEEET-WOOO](//en.wikipedia.org/wiki/Wolf-whistling)), and Patty takes offense. Schroeder, being more musical, delivers a mini-concert to Violet and gets to walk off with her. It is the melody to "Traumerei" from [Schumann's](//en.wikipedia.org/wiki/Robert_Schumann) "Scenes from Childhood" for piano.
  * p. 179 (April 21, 1952). "Rubbers" is another term for [galoshes](//en.wikipedia.org/wiki/galoshes).
  * p. 182 (April 29, 1952). Charlie Brown thinks they need him to play the card game [bridge](//en.wikipedia.org/wiki/Contract_bridge), which requires four people. (Six months later, p. 257, October 22 1952, that is what he's needed for.)
  * p. 194 (May 27, 1952). Snoopy's first words in the strip, as opposed to "Smack Smack" (see p. 2,1 December 11, 1950, 2nd panel) and other animal noises.
  * p. 197 (June 3, 1952). The first time that adults (except for [Beethoven](//en.wikipedia.org/wiki/Ludwig_van_Beethoven)) are seen in the strip, even if only on TV. (See Volume 2, pp. 215, 218, and 221 for whole crowds of adults as Lucy plays in a golf tournament.)
  * p. 201 (June 14, 1952). "Sweetmeats" is just another term for [confectionery](//en.wikipedia.org/wiki/confectionery) products, including candy.
  * p. 202 (June 15, 1952). Patty is misquoting [William Congreve](//en.wikipedia.org/wiki/William_Congreve)'s line from his 1697 play _The Mourning Bride_: "Musick has Charms to sooth a savage _Breast_. . ."
  * p. 203 (June 17, 1952). "The [Gay Nineties](//en.wikipedia.org/wiki/Gay_Nineties)" refers to the economic expansion and rapid wealth gains experienced in parts of America in the 1890s. Likewise, "The [Roaring Twenties](//en.wikipedia.org/wiki/Roaring_Twenties)" refers to American in the 1920s, a period of rapid social change and economic prosperity that only ended with [The Great Depression](//en.wikipedia.org/wiki/The_Great_Depression).
  * p. 205 (June 22, 1952). The violent names and nature of some comic books at the time were epitomized by [EC Comics](//en.wikipedia.org/wiki/EC_Comics) and criticized by [Fredric Wertham](//en.wikipedia.org/wiki/Fredric_Wertham) in his book _[Seduction of the Innocent](//en.wikipedia.org/wiki/Seduction_of_the_Innocent)_.
  * p. 206 (June 24, 1952). "[Eine Kleine Nachtmusik](//en.wikipedia.org/wiki/Eine_Kleine_Nachtmusik)" is famous musical piece by [Wolfgang Amadeus Mozart](//en.wikipedia.org/wiki/Wolfgang_Amadeus_Mozart). _Jawohl_ is German for an emphatic "Yes" (similar to "of course" or "you bet").
  * p. 206 (June 25, 1952). Both 33 and 20 are terrible scores for any hole in [golf](//en.wikipedia.org/wiki/golf).
  * p. 218 (July 21, 1952). Because he wrote about collies, these are almost certainly [Albert Payson Terhune](//en.wikipedia.org/wiki/Albert_Payson_Terhune) books again (see p. 146 above).
  * p. 225 (August 7, 1952). Schroeder is playing the first movement of [Beethoven's](//en.wikipedia.org/wiki/Ludwig_van_Beethoven) Piano Sonata No. 14 op. 27 No. 2, "Moonlight."
  * p. 228 (August 15, 1952). A [shutout](//en.wikipedia.org/wiki/shutout) is a game in which one team wins without allowing the opposing team to score at all. So, yes, their opponents having scored 63 runs, Charlie Brown's team has no chance of shutting them out.
  * p. 231 (August 22, 1952). Lucy is confusing checkers with the card game [bridge](//en.wikipedia.org/wiki/Contract_bridge), where a _[coup_ and _grand coup_](//en.wikipedia.org/wiki/Coup_\(bridge\)) are various sophisticated card plays. Charlie Brown doesn't appear to know the difference either. But he soon learns to play (See p. 257, below).
  * p. 243 (September 19, 1952). Linus's first appearance (although his name wouldn't be mentioned until September 22). Schulz: "[O]ne day I was doodling on a piece of paper and I drew this little character with some wild hair straggling down from the top of his head and I showed it to a friend of mine... whose name was Linus Maurer. For no reason at all I had written his name under it... [t]hen I thought, why not put this character in the strip and make him Lucy's brother?"[1]
  * p. 246 (September 25, 1952). [Vasco Núñez de Balboa](//en.wikipedia.org/wiki/Vasco_N%C3%BA%C3%B1ez_de_Balboa) was the first European to see the Pacific Ocean from the New World. [Daniel Boone](//en.wikipedia.org/wiki/Daniel_Boone) was an 18th century American frontiersman and Indian-fighter.
  * p. 248 (October 1, 1952). [Perfect pitch](//en.wikipedia.org/wiki/Perfect_pitch) (also called absolute pitch) is ability to sing any individual note on command and/or recognize any individual note upon hearing it played. It is often thought to be a sign of musical genius. Charlie Brown is confusing it the [pitching](//en.wikipedia.org/wiki/pitching) in [baseball](//en.wikipedia.org/wiki/baseball).
  * p. 264 (November 7, 1952). The strip's first use of "fuss-budget", a term seldom seen outside of _Peanuts._ It means one who fusses over insignificant matters; a complainer.
  * p. 267 (November 15, 1952). Note the use of "[deep focus](//en.wikipedia.org/wiki/deep_focus)" on both Lucy and the telephone. Quite dramatic. Right out of _[Citizen Kane](//en.wikipedia.org/wiki/Citizen_Kane)_, which the strip would refer to frequently in later years.
  * p. 268 (November 16, 1952). The first time Lucy pulls the football away from Charlie Brown.
  * p. 278 (December 9, 1952). Schroeder is playing the Prelude in C major from Book One of [J. S. Bach's](//en.wikipedia.org/wiki/Johann_Sebastian_Bach) "Well Tempered Clavier."
  * p. 282 (December 18, 1952). [Carnegie Hall](//en.wikipedia.org/wiki/Carnegie_Hall) is one of the finest American venues for the performance of classical music. In the 1950s and 60s especially it was considered the height of musical accomplishment to perform there.

  


* * *

Annotations to other volumes: [1950-1952](/wiki/Annotations_of_The_Complete_Peanuts/1950_to_1952) | [1953–1954](/wiki/Annotations_of_The_Complete_Peanuts/1953_to_1954) | [1955–1956](/wiki/Annotations_of_The_Complete_Peanuts/1955_to_1956) | [1957–1958](/wiki/Annotations_of_The_Complete_Peanuts/1957_to_1958) | [1959–1960](/wiki/Annotations_of_The_Complete_Peanuts/1959_to_1960) | [1961–1962](/wiki/Annotations_of_The_Complete_Peanuts/1961_to_1962) | [1963–1964](/wiki/Annotations_of_The_Complete_Peanuts/1963_to_1964) | [1965–1966](/wiki/Annotations_of_The_Complete_Peanuts/1965_to_1966) | [1967–1968](/wiki/Annotations_of_The_Complete_Peanuts/1967_to_1968) | [1969–1970](/wiki/Annotations_of_The_Complete_Peanuts/1969_to_1970) | [1971–1972](/wiki/Annotations_of_The_Complete_Peanuts/1971_to_1972) | [1973–1974](/wiki/Annotations_of_The_Complete_Peanuts/1973_to_1974) | [1975–1976](/wiki/Annotations_of_The_Complete_Peanuts/1975_to_1976) | [1977–1978](/wiki/Annotations_of_The_Complete_Peanuts/1977_to_1978) | [1979–1980](/wiki/Annotations_of_The_Complete_Peanuts/1979_to_1980) | [1981–1982](/wiki/Annotations_of_The_Complete_Peanuts/1981_to_1982) | [1983–1984](/wiki/Annotations_of_The_Complete_Peanuts/1983_to_1984) | [1985–1986](/wiki/Annotations_of_The_Complete_Peanuts/1985_to_1986) |

## 1953–1954

Annotations to _**The Complete Peanuts: 1953 to 1954**_ by Charles M. Schulz (Fantagraphics Books, 2004. [ISBN 1560976144](/wiki/Special:BookSources/1560976144))

  * p. 11 (January 25, 1953). Schroeder is playing the Piano Sonata No. 29 in B-flat, op. 106 "Hammerklavier" by [Beethoven](//en.wikipedia.org/wiki/Ludwig_Van_Beethoven). This appears again on p. 110 (September 13, 1953).
  * p. 16 (February 5, 1953). [Bela Bartok](//en.wikipedia.org/wiki/B%C3%A9la_Bart%C3%B3k) was one of [Hungary's](//en.wikipedia.org/wiki/Hungary) greatest composers.
  * p. 52 (May 1, 1953). Schroeder is singing from the 4th movement of the Symphony No. 9 in d, Op. 125 "Choral" by [Beethoven](//en.wikipedia.org/wiki/Ludwig_Van_Beethoven).
  * p. 63 (May 26, 1953). "[Doggie in the Window](//en.wikipedia.org/wiki/The_Doggie_In_The_Window)" was [Patti Page's](//en.wikipedia.org/wiki/Patti_Page) #1 hit song in 1953.
  * p. 122 (October 11, 1953). [Ben Hogan](//en.wikipedia.org/wiki/Ben_Hogan) was a famous professional golf player. (It is interesting to note that in these pre-1960s strips, Charlie Brown can sometimes be quite self-confident.)
  * p. 130 (October 31, 1953). A contour sheet is a fitted [bed sheet](//en.wikipedia.org/wiki/bed_sheet).
  * p. 133 (November 5, 1953). Lucy is exercising her rights as guaranteed by the [Fifth Amendment to the United States Constitution](//en.wikipedia.org/wiki/Fifth_Amendment_to_the_United_States_Constitution).
  * p. 149 (December 13, 1953). Schroeder is playing the waltz "[On the Beautiful Blue Danube](//en.wikipedia.org/wiki/The_Blue_Danube)" op. 314 by [Johann Strauss Jr.](//en.wikipedia.org/wiki/Johann_Strauss_II).
  * p. 207 (April 26, 1954). Schroeder is smiling, and has a [candelabra](//en.wikipedia.org/wiki/candelabra) on his piano, as [Liberace](//en.wikipedia.org/wiki/Liberace) did in his television show at the time.
  * p. 215 (May 16, 1954). [Sam Snead](//en.wikipedia.org/wiki/Sam_Snead) and [Ben Hogan](//en.wikipedia.org/wiki/Ben_Hogan) were famous professional golfers. "Ike" refers to [President Dwight D. Eisenhower](//en.wikipedia.org/wiki/Dwight_Eisenhower), well-known for his love of golf.
  * p. 225 (June 8, 1954). [Miss Frances](//en.wikipedia.org/wiki/Miss_Frances) was the host of a popular children's television program. She invented the approach of talking to her young viewers as if they were in the room with her.
  * p. 232 (June 24, 1954). [Stan Musial](//en.wikipedia.org/wiki/Stan_Musial), [Ted Williams](//en.wikipedia.org/wiki/Ted_Williams), [Roy Campanella](//en.wikipedia.org/wiki/Roy_Campanella) were popular baseball players of the era.
  * p. 274 (October 2, 1954). After Lucy does some meaningless [graffiti](//en.wikipedia.org/wiki/graffiti), Charlie Brown crosses the t.
  * p. 280 (October 15. 1954). [Handballs](//en.wikipedia.org/wiki/American_handball) are quite small: 1⅞ inches (4.8 centimeters) in diameter.
  * p. 281 (October 17, 1954). Outing [flannel](//en.wikipedia.org/wiki/) is particularly soft, having a nap on both sides.

* * *

Annotations to other volumes: [1950-1952](/wiki/Annotations_of_The_Complete_Peanuts/1950_to_1952) | [1953–1954](/wiki/Annotations_of_The_Complete_Peanuts/1953_to_1954) | [1955–1956](/wiki/Annotations_of_The_Complete_Peanuts/1955_to_1956) | [1957–1958](/wiki/Annotations_of_The_Complete_Peanuts/1957_to_1958) | [1959–1960](/wiki/Annotations_of_The_Complete_Peanuts/1959_to_1960) | [1961–1962](/wiki/Annotations_of_The_Complete_Peanuts/1961_to_1962) | [1963–1964](/wiki/Annotations_of_The_Complete_Peanuts/1963_to_1964) | [1965–1966](/wiki/Annotations_of_The_Complete_Peanuts/1965_to_1966) | [1967–1968](/wiki/Annotations_of_The_Complete_Peanuts/1967_to_1968) | [1969–1970](/wiki/Annotations_of_The_Complete_Peanuts/1969_to_1970) | [1971–1972](/wiki/Annotations_of_The_Complete_Peanuts/1971_to_1972) | [1973–1974](/wiki/Annotations_of_The_Complete_Peanuts/1973_to_1974) | [1975–1976](/wiki/Annotations_of_The_Complete_Peanuts/1975_to_1976) | [1977–1978](/wiki/Annotations_of_The_Complete_Peanuts/1977_to_1978) | [1979–1980](/wiki/Annotations_of_The_Complete_Peanuts/1979_to_1980) | [1981–1982](/wiki/Annotations_of_The_Complete_Peanuts/1981_to_1982) | [1983–1984](/wiki/Annotations_of_The_Complete_Peanuts/1983_to_1984) | [1985–1986](/wiki/Annotations_of_The_Complete_Peanuts/1985_to_1986) |

## 1955–1956

Annotations to _**The Complete Peanuts: 1955 to 1956**_ by Charles M. Schulz (Fantagraphics Books, 2005. [ISBN 1560976470](/wiki/Special:BookSources/1560976470))

  * p. 6 (January 11, 1955). A [mambo](//en.wikipedia.org/wiki/mambo) is a very fast piece of dance music.
  * p. 6 (January 12, 1955). A [metronome](//en.wikipedia.org/wiki/metronome) is a device for keeping a regulated beat to assist in the playing of music.
  * p. 7 (January 13, 1955). You break the [sound barrier](//en.wikipedia.org/wiki/sound_barrier) by traveling faster than the [speed of sound](//en.wikipedia.org/wiki/speed_of_sound): approximately 343 [m/s](//en.wikipedia.org/wiki/metre_per_second), 1,087 [ft/s](//en.wikipedia.org/wiki/feet_per_second), 761 [mph](//en.wikipedia.org/wiki/Miles_per_hour) or 1,235 [km/h](//en.wikipedia.org/wiki/kilometre_per_hour) in air at sea level. The person generally credited with first doing this is [Chuck Yeager](//en.wikipedia.org/wiki/Chuck_Yeager) on October 14, 1947.
  * p. 10 (January 22, 1955). This may be inspired by the 1940 film, _Edison, the Man_, which starred [Spencer Tracy](//en.wikipedia.org/wiki/Spencer_Tracy) and told the story of the earlier years of inventor [Thomas Edison](//en.wikipedia.org/wiki/Thomas_Edison).
  * p. 16 (February 4, 1955). An egotist is someone self-centered, who thinks they are "the center of the universe."
  * p. 21 (February 15, 1955). In actual [farming](//en.wikipedia.org/wiki/farming), "parity" was the ratio of farm income to farm expenditure with 1910-1914 as a base. Farm interests from 1920s to 1960s wanted federal programs to raise their income to parity.
  * p. 33 (March 15, 1955). Lucy is playing with some famous sayings. "There's a sucker born every minute," (i.e. you can always find someone to con) is attributed to showman [P.T. Barnum](//en.wikipedia.org/wiki/P.T._Barnum). "Two's company, but three's a crowd." "If at first you don't succeed, try, try again."
  * p. 45 (April 11, 1955). [Davy Crockett](//en.wikipedia.org/wiki/Davy_Crockett) was a 19th-century American folk hero and frontiersman. The Walt Disney-produced [television show about him](//en.wikipedia.org/wiki/Davy_Crockett#Television) launched Crockett mania in the U.S. and England. The show's theme song, "[The Ballad of Davy Crockett](//en.wikipedia.org/wiki/The_Ballad_of_Davy_Crockett)" was a number #1 hit record and children starting wearing [coonskin caps](//en.wikipedia.org/wiki/coonskin_cap).
  * p. 48 (April 19, 1955). Charlie Brown is reading a [Pogo](//en.wikipedia.org/wiki/Pogo) comic book.
  * p. 57 (May 10, 1955) Buffalo Bill was an army scout and frontiersman who later went into the entertainment business, running his "[Wild West](//en.wikipedia.org/wiki/Wild_West)" show. [Annie Oakley](//en.wikipedia.org/wiki/Annie_Oakley) was a female [sharpshooter](//en.wikipedia.org/wiki/sharpshooter) and part of the show. She was so talented that she is generally considered American's first female superstar. Although she wasn't actually part of the settling of the West, she dressed in buckskins to play up that image. It would not be too far a stretch to say that this strip is commentary on the rise of [feminism](//en.wikipedia.org/wiki/feminism) that occurred after [World War II](//en.wikipedia.org/wiki/World_War_II).
  * p. 60 (May 16, 1955) Almost all clovers have three leafs. Due to their rarity, a [four-leaf clover](//en.wikipedia.org/wiki/four-leaf_clover) is considered a good luck charm.
  * p. 66 (June 1, 1955). The first appearance of one of the 1950's hottest fads, the [Davy Crockett](//en.wikipedia.org/wiki/Davy_Crockett) [coonskin cap](//en.wikipedia.org/wiki/coonskin_cap).(See p. 45, above.) / [Sam Snead](//en.wikipedia.org/wiki/Sam_Snead) was a professional golfer famous for his large straw hats.
  * p. 69 (June 6, 1955). The song "[The Ballad of Davy Crockett](//en.wikipedia.org/wiki/The_Ballad_of_Davy_Crockett)" claims many fantastic things about the man, among them that he killed a bear "when he was only three."
  * p. 69 (June 8, 1955). "[The Ballad of Davy Crockett](//en.wikipedia.org/wiki/The_Ballad_of_Davy_Crockett)" begins, "Davy! Davy Crockett, King of the Wild Frontier . . ." Modern readers may find it odd that Schulz devoted so many strips to such a trivial phenomenon, but Davy Crockett and coonskin caps really were seemingly everywhere at the time. (See p. 78, June 28, 1955)
  * p. 70 (June 9, 1955). [Minnesota](//en.wikipedia.org/wiki/Minnesota) is Chales Schulz' home state.
  * p. 73 (June 17, 1955). A [white-collar worker](//en.wikipedia.org/wiki/white-collar_worker) is a professional, someone who's work is supposedly more intellectual than physical. People in manufacturing are said to be [blue collar workers](//en.wikipedia.org/wiki/blue_collar_worker). The joke is that even Pig Pen's white collar is bound to be dirty.
  * p. 75 (June 21, 1955). "But is it art?" is an age-old question that really has no answer. What makes a [drip painting](//en.wikipedia.org/wiki/Abstract_Expressionism) by [Jackson Pollock](//en.wikipedia.org/wiki/Jackson_Pollock) worthy of the [Metropolitan Museum of Art](//en.wikipedia.org/wiki/Metropolitan_Museum_of_Art), but not a similar painting by a chimp?
  * p. 76 (June 25, 1955). Most [recreation rooms](//en.wikipedia.org/wiki/recreation_room) in suburban homes are in the basement to keep the noise down.
  * p. 79 (July 2, 1955). [Willie Mays](//en.wikipedia.org/wiki/Willie_Mays) and [Duke Snider](//en.wikipedia.org/wiki/Duke_Snider) were popular baseball players of the 1950s.
  * p. 98 (August 14, 1955). To "clear the table" in the game of [pool|](//en.wikipedia.org/wiki/Eight_ball) is to sink all the balls on one turn and thus win the game.
  * p. 99 (August 15, 1955). The umlauts over the o's would actually be pronounced "boo-woo." According the [International Phonetic Alphabet](//en.wikipedia.org/wiki/International_Phonetic_Alphabet), the correct way to represent "bow wow" is: bau wau.
  * p. 105 (August 30, 1955) [Miss Frances](//en.wikipedia.org/wiki/Miss_Frances) was the host of a popular children's television program. She inventing the approach of talking to the her young viewers as if they were in the room with her.
  * p. 131 (October 31, 1955). The trick-or-treaters are, in order, Patty, Lucy, Shermy, Violet, Schroeder and Linus. 
    * Lucy's hair and shoes are visible on in panel #4, even though she had planned on dressing as a ghost on Oct 29/30.
    * On November 14, Pig-Pen says he was "away" on Hallowe'en, so he is not in this strip.
    * Linus is behind Schroeder in panel #9; even though Charlie Brown admired Davy Crockett earlier, Linus produces a Crockett snowman on December 12.
  * p. 106 (November 2, 1955). This will be [Sputnik](//en.wikipedia.org/wiki/Sputnik), the first artificial satellite, launched by the then-[Soviet Union](//en.wikipedia.org/wiki/Soviet_Union) on October 4, 1957, signaling the start of the [Space Age](//en.wikipedia.org/wiki/Space_Age) and the [Space Race](//en.wikipedia.org/wiki/Space_Race).
  * p. 117 (September 27, 1955). Charlie Brown is shown as "small." The expression "to feel small" means to be embarrassed.
  * p. 142 (November 26, 1955). Snoopy is imitating [Mickey Mouse](//en.wikipedia.org/wiki/Mickey_Mouse).
  * p. 147 (No date in strip, but is December 7, 1955). Lucy is reading a variation on the [Dick and Jane](//en.wikipedia.org/wiki/Dick_and_Jane) readers popular at the time. Schulz is being sarcastic. Not much really happens in the stories, so they are far from "fascinating."
  * p. 149 (December 11, 1955). The snow man is (who else?) [Davy Crockett](//en.wikipedia.org/wiki/Davy_Crockett).
  * p. 156 (December 28, 1955). All fads pass, and so did Davy Crocket mania. (See p. 187, March 8, 1956, for what became of at least one old coonskin cap.)
  * p. 159 (January 5, 1956). [Nuclear fallout](//en.wikipedia.org/wiki/Nuclear_fallout) is [radioactive contamination](//en.wikipedia.org/wiki/radioactive_contamination) from a nuclear attack.
  * p. 162 (January 10, 1956). [Private first class](//en.wikipedia.org/wiki/Private_first_class) is the "rank" immediately above Linus' current one. (See p. 159, January 4, 1956)
  * p. 163 ( January 13, 1956). [Juvenile delinquency](//en.wikipedia.org/wiki/Juvenile_delinquency) is anti-social and criminal activity by those under the age of 18. It came into the public eye and interest in the 1950s (see _[West Side Story](//en.wikipedia.org/wiki/West_Side_Story)_).
  * p. 166 (January 19, 1956). To "read between the lines" means to understand the [subtext](//en.wikipedia.org/wiki/subtext) of something—not what is actually said, but rather implied.
  * p. 167 ( January 22, 1956). Charlie Brown is putting sand (or maybe salt, if he's trying to melt it) on the ice to prevent anyone from slipping on it ¿ which is exactly what Snoopy wants to do.
  * p. 170 (January 30, 1956). A "fair weather friend" is one who is your friend during good times ("fair weather"), but abandons you when in times of trouble ("rough weather").
  * p. 178 (February 16, 1956). [Rin-Tin-Tin](//en.wikipedia.org/wiki/Rin-Tin-Tin) and [Lassie](//en.wikipedia.org/wiki/Lassie_\(1954_tv_series\)) were the heroic canine stars of popular television shows and movies.
  * p. 178 (February 18, 1956). [Static electricity](//en.wikipedia.org/wiki/Static_electricity#.27Static.27_electricity) seems to build up more during winter months.
  * p. 180 (February 20, 1956). _Ding Dong School_ was the television program hosted by [Miss Frances](//en.wikipedia.org/wiki/Miss_Frances). [Howdy Doody](//en.wikipedia.org/wiki/Howdy_Doody) was arguably the pre-eminent children's television show of the 1950s. [Lassie](//en.wikipedia.org/wiki/Lassie_\(1954_tv_series\)) was a very popular television program starring a dog.
  * p. 184 (March 3, 1956). Lucy is describing a scene from [Peter Pan](//en.wikipedia.org/wiki/Peter_Pan). Most likely the book was read to her or she saw the 1954 musical starring [Mary Martin](//en.wikipedia.org/wiki/Mary_Martin) on stage, since she was too young to have seen the [Disney film version](//en.wikipedia.org/wiki/Peter_Pan_\(1953_film\)) in 1953.
  * p. 190 ( March 15, 1956). "[Asia minor](//en.wikipedia.org/wiki/Asia_minor)" the old term for [Southwest Asia](//en.wikipedia.org/wiki/Southwest_Asia) which corresponds today to the [Asian](//en.wikipedia.org/wiki/Asian) portion of [Turkey](//en.wikipedia.org/wiki/Turkey). Lucy has confused the term with "[Toccata and Fugue in D Minor](//en.wikipedia.org/wiki/Toccata_and_Fugue_in_D_minor,_BWV_565)" by [Johann Sebastian Bach](//en.wikipedia.org/wiki/Johann_Sebastian_Bach).
  * p. 208 (April 26, 1956). In the 1950s the government paid farmers not to use their land. The idea was that this would prevent [soil erosion](//en.wikipedia.org/wiki/soil_erosion) and build up healthier soil when crops were eventually planted.
  * p. 210 ( April 30, 1956). Unlike the previous greens, which were all legitimate shades of the color, the ones in this panel are jokes. [Evergreen](//en.wikipedia.org/wiki/Evergreen) and [wintergreen](//en.wikipedia.org/wiki/wintergreen), are types of plants. Herb Green was a cartoonist, and [Graham Greene](//en.wikipedia.org/wiki/Graham_Greene) a novelist.
  * p. 217 (May 18, 1956). Linus has transformed his blanket into an [ascot tie](//en.wikipedia.org/wiki/ascot_tie), a very sophisticated look in the 1950s, frequently worn by sporty celebrities.
  * p. 226 (June 8, 1956). [Stephen Foster](//en.wikipedia.org/wiki/Stephen_Foster) was arguably the most popular American composer of the 19th Century. His works include "[Oh! Susanna](//en.wikipedia.org/wiki/Oh!_Susanna)," "[Camptown Races](//en.wikipedia.org/wiki/Camptown_Races)" and "[Beautiful Dreamer](//en.wikipedia.org/wiki/Beautiful_Dreamer)."
  * p. 232 ( June 22, 1956). [Elvis Presley](//en.wikipedia.org/wiki/Elvis_Presley), "the King of Rock and Roll" had just made his first television appearances earlier that year and was a riding a huge crest of popularity. At age 21, was also, arguably, at the height of his attractiveness. And, naturally, Schroeder cares not a whit for [rock music](//en.wikipedia.org/wiki/rock_music).
  * p. 233 (June 24, 1956). A [dust bowl](//en.wikipedia.org/wiki/dust_bowl) is an area where, due to drought and/or poor soil management, the soil has lost all nutrients turned to dust, and blown away.
  * p. 244 (July 19, 1956). The automatic [dishwasher](//en.wikipedia.org/wiki/dishwasher) as we know it wasn't invented until the 1920s. With the privations imposed by the [Great Depression](//en.wikipedia.org/wiki/Great_Depression) and then [World War II](//en.wikipedia.org/wiki/World_War_II), it didn't become a common domestic appliance until the 1950s. And, so, of course, Violet's great-grandmother, who was probably born in the 1880s or 1890s, didn't have one.
  * p. 247 (July 27, 1956). Usually, one sticks up for the [under_dog_](//en.wikipedia.org/wiki/Underdog_\(competition\)), the person or thing not generally favored.
  * p. 247 (July 28, 1956). The [suburban](//en.wikipedia.org/wiki/suburb) population in North America exploded after [World War II](//en.wikipedia.org/wiki/World_War_II). Returning [veterans](//en.wikipedia.org/wiki/veteran) wishing to start a settled life moved _en masse_ to the suburbs. Between 1950 and 1956 the resident population of all U.S. suburbs increased by 46%. And, since new suburbs were built from scratch, very few had mature trees. (Though Charlie Brown's kites never seem to have a problem finding large trees to crash into.)
  * p. 249 (July 30, 1956). The titles are all variations on popular books or types of books. _From Rags to Fuss-Budget_ is a spin on any "[Rags to Riches](//en.wikipedia.org/wiki/Rags_to_Riches)" tale (how someone started out poor but became rich; see the [Horatio Alger](//en.wikipedia.org/wiki/Horatio_Alger) novels). _The Power of Positive Fussing_ is from [Norman Vincent Peale's](//en.wikipedia.org/wiki/Norman_Vincent_Peale) _The Power of Positive Thinking_, one of most popular inspirational books of the 1950s. _Great Fuss-Budgets of Our Time_: the are lots of "of Our Time" books published every year. _I Was a Fuss-Budget for the F.B.I._ is a take on [I Was a Communist for the FBI](//en.wikipedia.org/wiki/I_Was_a_Communist_for_the_FBI), the radio show and, later, film about an undercover agent infiltrating [communist](//en.wikipedia.org/wiki/communist) organizations in order to disrupt them. The [F.B.I.](//en.wikipedia.org/wiki/F.B.I.) is the Federal Bureau of Investigations, America's internal criminal investigation organization. In the 1950s America was particularly interested in hunting domestic communists, something which was [carried to the extremes](//en.wikipedia.org/wiki/McCarthyism) by U.S. senator [Joseph McCarthy](//en.wikipedia.org/wiki/Joseph_McCarthy).
  * p. 253 (August 4, 1956). [Dr. (Benjamin) Spock](//en.wikipedia.org/wiki/Benjamin_Spock) Was a leading pediatrician. The main message of his best-selling _[The Common Sense Book of Baby and Child Care](//en.wikipedia.org/wiki/The_Common_Sense_Book_of_Baby_and_Child_Care)_ was for parents to be more affectionate with their children, and to treat them as individuals. (See p. 300, November 26, 1956, below.)
  * p. 271 (September 20, 1956). Compatible color was a television broadcast standard that allowed color broadcasts to appear on black and white televisions without distortions or flickers (but still, of course, in black and white). Incompatible color was a previous color television standard developed by CBS that would have rendered all existing televisions obsolete.
  * p. 275 (September 30, 1956). Schroeder is playing the Prelude in C major from Book I of [J. S. Bach's](//en.wikipedia.org/wiki/Johann_Sebastian_Bach) Well-Tempered Clavier.
  * P. 283 (October 18, 1956). There's no particular reason why Charlie Brown yelled this except that it's dog-related and in the movie _[Lassie Come Home](//en.wikipedia.org/wiki/Lassie_Come_Home)_ it gets yelled, which is what Charlie Brown is really after.
  * p. 300 (November 26, 1956). Lucy is reading from [Dr. Benjamin Spock's](//en.wikipedia.org/wiki/Benjamin_Spock) _[The Common Sense Book of Baby and Child Care](//en.wikipedia.org/wiki/The_Common_Sense_Book_of_Baby_and_Child_Care)_.

* * *

Annotations to other volumes: [1950-1952](/wiki/Annotations_of_The_Complete_Peanuts/1950_to_1952) | [1953–1954](/wiki/Annotations_of_The_Complete_Peanuts/1953_to_1954) | [1955–1956](/wiki/Annotations_of_The_Complete_Peanuts/1955_to_1956) | [1957–1958](/wiki/Annotations_of_The_Complete_Peanuts/1957_to_1958) | [1959–1960](/wiki/Annotations_of_The_Complete_Peanuts/1959_to_1960) | [1961–1962](/wiki/Annotations_of_The_Complete_Peanuts/1961_to_1962) | [1963–1964](/wiki/Annotations_of_The_Complete_Peanuts/1963_to_1964) | [1965–1966](/wiki/Annotations_of_The_Complete_Peanuts/1965_to_1966) | [1967–1968](/wiki/Annotations_of_The_Complete_Peanuts/1967_to_1968) | [1969–1970](/wiki/Annotations_of_The_Complete_Peanuts/1969_to_1970) | [1971–1972](/wiki/Annotations_of_The_Complete_Peanuts/1971_to_1972) | [1973–1974](/wiki/Annotations_of_The_Complete_Peanuts/1973_to_1974) | [1975–1976](/wiki/Annotations_of_The_Complete_Peanuts/1975_to_1976) | [1977–1978](/wiki/Annotations_of_The_Complete_Peanuts/1977_to_1978) | [1979–1980](/wiki/Annotations_of_The_Complete_Peanuts/1979_to_1980) | [1981–1982](/wiki/Annotations_of_The_Complete_Peanuts/1981_to_1982) | [1983–1984](/wiki/Annotations_of_The_Complete_Peanuts/1983_to_1984) | [1985–1986](/wiki/Annotations_of_The_Complete_Peanuts/1985_to_1986) |

## 1957–1958

Annotations to _**The Complete Peanuts: 1957 to 1958**_ by Charles M. Schulz (Fantagraphics Books, 2005. [ISBN 1560976705](/wiki/Special:BookSources/1560976705))

  * p. 4 (January 7, 1957) 3rd panel (and subsequent days). [Stereo](//en.wikipedia.org/wiki/Stereo) and [Hi-Fi](//en.wikipedia.org/wiki/Hi-Fi) equipment were the latest innovations in home audio at the time.
  * p. 6 (January 13, 1957) This is a reference to the [nursery rhyme](//en.wikipedia.org/wiki/nursery_rhyme) "[Three Little Kittens](//en.wikipedia.org/wiki/Three_Little_Kittens)."
  * p. 7 (January 16, 1957). [Bastille Day](//en.wikipedia.org/wiki/Bastille_Day) is the [French](//en.wikipedia.org/wiki/France) national holiday symbolizing the start of French democracy.
  * p. 20 (February 15, 1957). [Hennepin county](//en.wikipedia.org/wiki/Hennepin_County,_Minnesota) is in [Charles M. Schulz](//en.wikipedia.org/wiki/Charles_M._Schulz)'s home state of [Minnesota](//en.wikipedia.org/wiki/Minnesota).
  * p. 22 (February 19, 1957). Undoubtedly [Lawrence Welk](//en.wikipedia.org/wiki/Lawrence_Welk), whose show first aired nationally in 1955.
  * p. 23 (February 21, 1957). Having "both feet on the ground" means having a firm grip on reality. This pun is likely a reference to the fact that the accordion is played while standing, whereas the piano is played while seated and often with a foot on the pedals. (The accordion is also a less widely respected instrument than the piano, explaining Schroeder's disgust at the remark.)
  * p. 23 (February 22, 1957). This is the first reference in _[Peanuts](//en.wikipedia.org/wiki/Peanuts)_ to the name [Joseph Shlabotnik](//en.wikipedia.org/wiki/Joe_Shlabotnik), later to be [Charlie Brown](//en.wikipedia.org/wiki/Charlie_Brown)'s [baseball](//en.wikipedia.org/wiki/baseball) hero.
  * p. 33 (March 17, 1957) 1st panel and following. Charlie Brown is engaged in the ancient game of [hoop rolling](//en.wikipedia.org/wiki/hoop_rolling). It's exactly what it looks like: rolling a hoop with a stick.
  * p. 34 (March 20, 1957). [Skywriting](//en.wikipedia.org/wiki/Skywriting) is when a small airplane, expelling special smoke during flight, flies in certain patterns, creating "writing" readable from the ground.
  * p.41 (April 6, 1957). A [fiscal year](//en.wikipedia.org/wiki/fiscal_year) is a 12-month period used for calculating annual ("yearly") financial reports in businesses and other organizations. It covers a full 365 days, but does not begin on January 1 nor end on December 31.
  * p. 47 (April 20, 1957) 4th panel [Casey Stengel](//en.wikipedia.org/wiki/Casey_Stengel) was the manager of the [New York Yankees](//en.wikipedia.org/wiki/New_York_Yankees) in the 1950s and led them to many [World Series](//en.wikipedia.org/wiki/World_Series) victories.
  * p. 53 (May 4, 1957). Old fashioned [roller skates](//en.wikipedia.org/wiki/roller_skates) did not have their own uppers. They were essentially mini skateboards that you attached to your shoes with a set of clamps that you tightened using a skate key.
  * p. 56 (May 10, 1957). [Washboards](//en.wikipedia.org/wiki/Washboard), used to wash clothes, were, of course, hand-operated.
  * p. 58 (May 13, 1957). [Calypso music](//en.wikipedia.org/wiki/Calypso_music) is [Caribbean](//en.wikipedia.org/wiki/Caribbean) [folk music](//en.wikipedia.org/wiki/folk_music). It entered the American mainstream in 1956 with [Harry Belafonte](//en.wikipedia.org/wiki/Harry_Belafonte)'s very popular rendition of the "[Banana Boat Song](//en.wikipedia.org/wiki/Banana_Boat_Song)", a traditional [Jamaican](//en.wikipedia.org/wiki/Jamaica) folk tune.
  * p. 62 (May 23, 1957). 33 1/3 and 78 rpm were common speeds for [phonograph](//en.wikipedia.org/wiki/phonograph) records. (The implication is that Lucy speaks very quickly indeed!).
  * p. 77 (June 29, 1957). Buttons proclaiming "[I Like Ike](//en.wikipedia.org/wiki/I_Like_Ike)" were common in 1951-1952. They proclaimed support for [Dwight D. Eisenhower](//en.wikipedia.org/wiki/Dwight_D._Eisenhower) for U.S. president. He was president from 1953 to 1961, during the time this panel ran.
  * p. 82 (July 9, 1957). Barrel staves are curved, wooden parts that make up a [barrel](//en.wikipedia.org/wiki/barrel).
  * p. 83 (July 13, 1957). "Slacker" is a term from [World War I](//en.wikipedia.org/wiki/World_War_I) and [World War II](//en.wikipedia.org/wiki/World_War_II) describing men who were avoiding the military draft.
  * p. 89 (July 25, 1957). The quotation is from the _[Rubaiyat of Omar Khayyam](//en.wikipedia.org/wiki/Rubaiyat_of_Omar_Khayyam)_.
  * p. 91 (July 29, 1957). Lucy has confused "[phonetic](//en.wikipedia.org/wiki/phonetic)" (word sounds) with "[psychic](//en.wikipedia.org/wiki/psychic)" (having the ability to read minds).
  * p. 98 (August 17, 1957). According to the U.S. Census Bureau 16.1 million men and women served in the U.S. armed forces from Dec. 1, 1941, and Dec. 31, 1946. So practically every U.S. family has a [World War II](//en.wikipedia.org/wiki/World_War_II) veteran in it.
  * p. 99 (August 18, 1957). "Geronimo!" is the traditional cry of [paratroopers](//en.wikipedia.org/wiki/paratrooper) and others as they jump out of planes. It comes from a film about the Apache leader [Geronimo](//en.wikipedia.org/wiki/Geronimo).
  * p. 101 (August 23, 1957). "Thar She Blows!" is the traditional yell of [whale hunters](//en.wikipedia.org/wiki/whaling) when they spot a whale or, more often, a whale spouting water from its blow hole.
  * p. 112 (September 17, 1957). Snoopy is holding his fist in the air like [Benito Mussolini](//en.wikipedia.org/wiki/Benito_Mussolini), suggesting that Lucy is behaving like the [fascist](//en.wikipedia.org/wiki/fascism) dictator.
  * p. 118 (October 2, 1957). Lucy makes this statement just two days before the launch of [Sputnik](//en.wikipedia.org/wiki/Sputnik)!
  * p. 139 (November 18, 1957). According to [Billboard](//en.wikipedia.org/wiki/Number-one_hits_of_1957_\(USA\)), the number one song in the [United States](//en.wikipedia.org/wiki/United_States) that week was "[Jailhouse Rock](//en.wikipedia.org/wiki/Jailhouse_Rock)" by [Elvis Presley](//en.wikipedia.org/wiki/Elvis_Presley). Note: Schulz drew his strip weeks in advance. Even though he didn't know exactly which song would be number one, he knew it would undoubtedly be a [rock and roll](//en.wikipedia.org/wiki/rock_and_roll) tune, which Schroeder naturally dislikes.
  * p. 151 (December 16, 1957). The first movement of [Beethoven's](//en.wikipedia.org/wiki/Ludwig_van_Beethoven) Piano Sonata No. 1, op. 2 No. 1.
  * p. 152 (December 20, 1957). [Pat Boone](//en.wikipedia.org/wiki/Pat_Boone) was a popular singer of the time. His songs were usually sweet love songs, more conventional and "middle of the road" than the raucous [rock and roll](//en.wikipedia.org/wiki/rock_and_roll) of [Elvis Presley](//en.wikipedia.org/wiki/Elvis_Presley). Boone had two number one songs in 1957, "Love Letters In the Sand" and "April Love".
  * p. 157 (December 30, 1957). Snoopy's ears are forming a square. "[Square](//en.wikipedia.org/wiki/Square_\(slang\))" is a slang term for someone who is old fashioned and not "[hip](//en.wikipedia.org/wiki/Hip_\(slang\))." Schroeder's love of classical music marks him as definite square.
  * p. 160 (January 8, 1958). Another reading from the gentle and encouraging [Dr. Benjamin Spock's](//en.wikipedia.org/wiki/Benjamin_Spock) revolutionary book, _[The Common Sense Book of Baby and Child Care](//en.wikipedia.org/wiki/The_Common_Sense_Book_of_Baby_and_Child_Care)_.
  * p. 164 (January 17, 1958). _[Peter Rabbit](//en.wikipedia.org/wiki/Peter_Rabbit)_ by [Beatrix Potter](//en.wikipedia.org/wiki/Beatrix_Potter) and _[Alice in Wonderland](//en.wikipedia.org/wiki/Alice_in_Wonderland)_ by [Lewis Carroll](//en.wikipedia.org/wiki/Lewis_Carroll) are both children's books, and so easy reads (though _Alice_ is actually a complex satire, although it is doubtful that Charlie Brown would get the references).
  * p. 164 (January 18, 1958). "Pioneer Days" would be the 1800s when the [American Old West](//en.wikipedia.org/wiki/American_Old_West) was first settled by white men ("pioneers"). That would anywhere from 50 to 150 years before [World War II](//en.wikipedia.org/wiki/World_War_II).
  * p. 170 (February 2, 1958). This appears to be a reference to the movie _[I Was a Teenage Werewolf](//en.wikipedia.org/wiki/I_Was_a_Teenage_Werewolf)_ from 1957.
  * p. 172 (February 4, 1958). Another reference to [Sputnik](//en.wikipedia.org/wiki/Sputnik), the first artificial satellite.
  * p. 175 (February 10, 1958). Linus knows that carrying around a blanket makes him look crazy, and crazy people are not drafted into the army.
  * p. 175 (February 11, 1958). Lucy is mis-quoting [Karl Marx](//en.wikipedia.org/wiki/Karl_Marx) who said, "Religion is the _[opium_ of the people](//en.wikipedia.org/wiki/opium_of_the_people)." Like most people, she has mis-interpreted that saying to mean that religion is a tool used by the bourgeoisie to keep the masses quiet and complacent.
  * p. 181 (February 25, 1958). To be "[blackballed](//en.wikipedia.org/wiki/Blackball_\(blacklist\))" is to forbidden to join an organization. The Blue Birds were a children's club, part of the [Camp Fire Organization](//en.wikipedia.org/wiki/Camp_Fire_USA) (similar to [Scouting](//en.wikipedia.org/wiki/Scouting)), and so, theoretically not _that_ picky. (Blue Birds were started in 1913 as an organization for girls. In 1989 the Blue Bird level became the "Starflight" level serving both boys and girls.)
  * p. 186 (March 9, 1958). The [Asian Flu](//en.wikipedia.org/wiki/Asian_Flu) was a strain of [influenza](//en.wikipedia.org/wiki/influenza) that caused a [pandemic](//en.wikipedia.org/wiki/pandemic) in 1957-58.
  * p. 188 (March 13, 1958). A [strop](//en.wikipedia.org/wiki/Strop#Disciplinary_strapping) is a piece of leather used to sharpen an old-fashioned [straight razor](//en.wikipedia.org/wiki/straight_razor). They were also used to spank children with when they misbehaved. Schroeder's grandfather is arguing for more discipline. Electric razors don't have strops.
  * p. 190 (March 17, 1958). Jim Hagerty was [President Eisenhower's](//en.wikipedia.org/wiki/Eisenhower) press secretary. As such, any reporter would love to interview him.
  * p. 196 (March 31, 1958). The quotation is from the chlidren's book _[Little Black Sambo](//en.wikipedia.org/wiki/Little_Black_Sambo),_ which would now be considered racially offensive.
  * p. 199 (April 8, 1958). A parasol can not be [hi-fi](//en.wikipedia.org/wiki/hi-fi), but, like the term "[high tech](//en.wikipedia.org/wiki/high_tech)", "hi-fi" was bandied about in lots of inappropriate places in attempts to suggest that whatever was being sold was on the cutting edge of science.
  * p. 200 (April 10, 1958). See above.
  * p. 221 (May 30, 1958). The [Beat Generation](//en.wikipedia.org/wiki/Beat_Generation) refers to a group of American writers of the 1950s, most notably [Jack Kerouac](//en.wikipedia.org/wiki/Jack_Kerouac). But here Charlie Brown is referring to himself as beaten down by life in general.
  * p. 222 (June 1, 1958). "Dear Agnes" is a play on [Dear Abby](//en.wikipedia.org/wiki/Dear_Abby), the advice columnist (or "[agony aunt](//en.wikipedia.org/wiki/agony_aunt)"), whose column began running in 1956.
  * p. 224 (June 6, 1958). A [gila monster](//en.wikipedia.org/wiki/gila_monster) is a venomous lizard found in the Southwestern United States and Northern Mexico.
  * p. 238 (July 8, 1958). Fugue in C major from [Johann Sebastian Bach](//en.wikipedia.org/wiki/Johann_Sebastian_Bach)'s [Well-Tempered Clavier](//en.wikipedia.org/wiki/Well-Tempered_Clavier) (Book 1), [BWV846](//en.wikipedia.org/wiki/BWV).
  * p. 239 (July 12, 1958). [Van Cliburn](//en.wikipedia.org/wiki/Van_Cliburn) was a well known classical pianist of the late fifties.
  * p. 268 (September 17, 1958). See p. 232, June 25, 1958. Odd that Schulz recycles an idea not four months after he first uses it.
  * p. 269 (September 19, 1958). "The fastest _gun_ in the west" was a claim made by many an [Old West](//en.wikipedia.org/wiki/Old_West) [gunslinger](//en.wikipedia.org/wiki/gunslinger). It literally meant that you were able to draw your gun and shoot faster than any opponent, thus killing them.
  * p. 217 (September 22, 1958). "I don't pretend to be able to give advice." All that would change with the coming of her psychiatric advice booth (Vol. 5, p. 37, March 27, 1959).
  * p. 274 (September 29, 1958) [Hula hoops](//en.wikipedia.org/wiki/Hula_hoop)! The only thing more ubiquitous than [Davy Crockett](//en.wikipedia.org/wiki/Davy_Crockett) in the 1950s was hula hoops. _Peanuts_ is a veritable index to the pop culture of the second half of the 20th century.
  * p. 275 (October 3, 1958). The ticking of a clock supposedly simulates the heartbeat of the mother, which a puppy would have heard in the womb and while snuggled up against the mother after birth, in order to reassure it.
  * p. 289 (November 3, 1958). The [underdog](//en.wikipedia.org/wiki/underdog_\(competition\)) is the person or team not expected to win a contest. The word's origin, in ship construction, actually does make its opposite "overdog."
  * p. 289 (November 4, 1958). [Beethoven](//en.wikipedia.org/wiki/Beethoven) did not belong to a [country club](//en.wikipedia.org/wiki/country_club), so he never had the chance to become "club champion": the member of the club who is the best at a particular sport, usually [golf](//en.wikipedia.org/wiki/golf) or [tennis](//en.wikipedia.org/wiki/tennis).
  * p. 289 (November 5, 1958). [Irving Berlin](//en.wikipedia.org/wiki/Irving_Berlin) was a well known American composer and lyricist, author of, among other songs, "[God Bless America](//en.wikipedia.org/wiki/God_Bless_America)," "[White Christmas](//en.wikipedia.org/wiki/White_Christmas_\(song\))," and '"[There's No Business Like Show Business](//en.wikipedia.org/wiki/There%27s_No_Business_Like_Show_Business)."
  * p. 307 (December 16, 1958). Johann is the first name of classical composer (and, along with [Mozart](//en.wikipedia.org/wiki/Mozart), rival of [Beethoven](//en.wikipedia.org/wiki/Beethoven)'s for the title of greatest classical composer) [Johann Sebastian Bach](//en.wikipedia.org/wiki/Bach). Note: there are [several Johann Bachs](//en.wikipedia.org/wiki/Bach_\(disambiguation\)) who were composers, including a [Johann Ludwig Bach](//en.wikipedia.org/wiki/Johann_Ludwig_Bach).
  * p. 310 (December 24, 1958). The [age of accountability](//en.wikipedia.org/wiki/age_of_accountability) is the age at which a child knows right from wrong and is responsible for his/her own actions. In the Catholic Church it's 7.

* * *

Annotations to other volumes: [1950-1952](/wiki/Annotations_of_The_Complete_Peanuts/1950_to_1952) | [1953–1954](/wiki/Annotations_of_The_Complete_Peanuts/1953_to_1954) | [1955–1956](/wiki/Annotations_of_The_Complete_Peanuts/1955_to_1956) | [1957–1958](/wiki/Annotations_of_The_Complete_Peanuts/1957_to_1958) | [1959–1960](/wiki/Annotations_of_The_Complete_Peanuts/1959_to_1960) | [1961–1962](/wiki/Annotations_of_The_Complete_Peanuts/1961_to_1962) | [1963–1964](/wiki/Annotations_of_The_Complete_Peanuts/1963_to_1964) | [1965–1966](/wiki/Annotations_of_The_Complete_Peanuts/1965_to_1966) | [1967–1968](/wiki/Annotations_of_The_Complete_Peanuts/1967_to_1968) | [1969–1970](/wiki/Annotations_of_The_Complete_Peanuts/1969_to_1970) | [1971–1972](/wiki/Annotations_of_The_Complete_Peanuts/1971_to_1972) | [1973–1974](/wiki/Annotations_of_The_Complete_Peanuts/1973_to_1974) | [1975–1976](/wiki/Annotations_of_The_Complete_Peanuts/1975_to_1976) | [1977–1978](/wiki/Annotations_of_The_Complete_Peanuts/1977_to_1978) | [1979–1980](/wiki/Annotations_of_The_Complete_Peanuts/1979_to_1980) | [1981–1982](/wiki/Annotations_of_The_Complete_Peanuts/1981_to_1982) | [1983–1984](/wiki/Annotations_of_The_Complete_Peanuts/1983_to_1984) | [1985–1986](/wiki/Annotations_of_The_Complete_Peanuts/1985_to_1986) |

## 1959–1960

Annotations to _**The Complete Peanuts: 1959 to 1960**_ by Charles M. Schulz (Fantagraphics Books, 2006. [ISBN 1560976713](/wiki/Special:BookSources/1560976713))

  * p. 3 (January 6, 1959) 4th panel. [Popular songs](//en.wikipedia.org/wiki/Popular_music) were the music that "everybody" was familiar with during the first half of the 20th century, until rock and roll replaced it as the music of the general public. 
    * "[Stardust](//en.wikipedia.org/wiki/Stardust_\(song\))", written by [Hoagy Carmichael](//en.wikipedia.org/wiki/Hoagy_Carmichael), and recorded thousands of times, was one of the most popular of these "popular songs." During the 1940s - 50s many older pieces of music (including some classical) were jazzed up, given lyrics and became "hits." For example, "[Stranger in Paradise](//en.wikipedia.org/wiki/Stranger_in_Paradise)" from the 1953 musical _[Kismet](//en.wikipedia.org/wiki/Kismet)_ is based on [Alexander Borodin](//en.wikipedia.org/wiki/Alexander_Borodin)'s _[Polovetsian Dances](//en.wikipedia.org/wiki/Polovetsian_Dances)_ and [Tchaikovsky](//en.wikipedia.org/wiki/Pyotr_Ilyich_Tchaikovsky)’s Piano Concerto in B-Flat Minor became “Tonight We Love.” The joke is that the children are so young that they don't know "Stardust" has already been around a while and in fact started out as a pop song.
  * p. 18 (February 11, 1959) 3rd panel. "Tennessee Ernie" is [Tennessee Ernie Ford](//en.wikipedia.org/wiki/Tennessee_Ernie_Ford), a popular singer and TV variety show host.
  * p. 30 (March 9, 1959) 2nd panel. [Deep focus](//en.wikipedia.org/wiki/Deep_focus) again. (See also Vol. 1, p. 267, November 15, 1952.)
  * p. 34 (March 20, 1959). [Joseph Haydn's](//en.wikipedia.org/wiki/Joseph_Haydn) Symphony No. 94 is nicknamed [the Surprise Symphony](//en.wikipedia.org/wiki/Symphony_No._94_\(Haydn\)) due to the sudden appearance of a loud chord during the second movement.
  * p. 37 (March 27, 1959). The first appearance of Lucy's psychiatric help booth.
  * p. 38 (March 29, 1959). Commercial use of jet aircraft in the United States began with the [Boeing 707](//en.wikipedia.org/wiki/Boeing_707), first used in international service in October 1958 and for domestic flights in January 1959. Jets were louder than the propeller-driven aircraft they replaced, and in many places, people living near airports distributed petitions in an attempt to reduce the number of jet flights and/or reroute jet traffic away from their homes.
  * p. 42 (April 6, 1959) 3rd and 4th panels. Almost certainly _[Peter Gunn](//en.wikipedia.org/wiki/Peter_Gunn),_ which had premiered on TV the year before. Gunn was a cool detective, [hip](//en.wikipedia.org/wiki/Hip_\(slang\)) to all the lingo. “Mommy-O” is a spin on "Daddy-O", what one [cool](//en.wikipedia.org/wiki/Cool_\(aesthetic\)) cat might call another. The 1958 film _[Daddy-O](//en.wikipedia.org/wiki/Daddy-O)_ features a truck driver who turns detective.
  * p. 60 (May 18, 1959). [Telephone booth stuffing](//en.wikipedia.org/wiki/Phonebooth_stuffing), in which as many people as possible tried to cram into the same glass-walled phone booth, was a fad in the late 1950s, primarily on college campuses.
  * p. 67 (June 6, 1959). "I was an only dog." Schulz would later change his mind on this (or, he simply forgot the line). Over the years (see May 5, 1965), we would learn that Snoopy had [seven siblings](//en.wikipedia.org/wiki/Snoopy%27s_siblings).
  * p. 68 (June 7, 1959). The first movement of [Beethoven's](//en.wikipedia.org/wiki/Ludwig_van_Beethoven) Piano Sonata No. 1, op. 2 No. 1.
  * p. 79 (July 4, 1959) 4th panel. Charlie Brown is suggesting that his father will have to drastically raise the price of haircuts at his barber shop in order to cover the increased cost of living that comes with an expanded family. At the time, haircuts typically cost less than $2.00.
  * p. 81 (July 6, 1959). The Soviet Union was well-known for [sending dogs into space](//en.wikipedia.org/wiki/Soviet_space_dogs), experiments which were continuing as of this date. The American space program had actually sent mice into space in the early 1950s; by 1959, they had moved on to monkeys, with a pair surviving a flight in May of that year. [Various other animals also made space flights](//en.wikipedia.org/wiki/Animals_in_space).
  * p. 87 (July 20, 1959). The back sides of boxes of [breakfast cereals](//en.wikipedia.org/wiki/Breakfast_cereal) aimed at children often had brief stories or comic strips printed on them.
  * p. 87 (July 22, 1959). The [Continental League](//en.wikipedia.org/wiki/Continental_League) was proposed in 1959 as a competitor to the [American](//en.wikipedia.org/wiki/American_League) and [National](//en.wikipedia.org/wiki/National_League) baseball leagues. It was to have begun play in 1961, but the existing leagues soon announced plans for [expansion teams](//en.wikipedia.org/wiki/Expansion_team) in some of the Continental League cities, thus eliminating much of the new league's reason for being.
  * p. 99 (August 19, 1959). "Hot summer nights": the name given to racial riots of the 1950s and 60s.
  * p. 101 (August 23, 1959). Note that it was three months between the first mention of Charlie Brown's new baby sister (May 26, 1959) and this, her first actual appearance in the strip.
  * p. 120 (October 6, 1959). First mention of "Miss Othmar."
  * p. 124 (October 16, 1959) 4th panel. The [Brothers Grimm](//en.wikipedia.org/wiki/Brothers_Grimm) popularized the legend of [the Pied Piper](//en.wikipedia.org/wiki/The_Pied_Piper_of_Hamelin), who is reputed to have used his pipe to play music to lure an infestation of rats out of the town of Hamelin, Germany; when he was not paid by the townspeople, he later returned and lured the town's children away.
  * p. 126 (October 21, 1959). Lucy is reading the mythological story of [King Midas](//en.wikipedia.org/wiki/Midas#Myth). Linus is correct that things backfired for the king.
  * p. 129 (October 26, 1959). First mention of "[the Great Pumpkin](//en.wikipedia.org/wiki/The_Great_Pumpkin)."
  * p. 131 (November 1, 1959) 5th through 7th panels. [Dr. Benjamin Spock's](//en.wikipedia.org/wiki/Benjamin_Spock) bestselling book _[Baby and Child Care](//en.wikipedia.org/wiki/The_Common_Sense_Book_of_Baby_and_Child_Care),_ first published in 1946, advocated a more loving approach -- some would say "permissive" -- to raising a baby than had previously been in vogue.
  * p. 137 (November 15, 1959) 4th and 5th panels. The [Soviet Union](//en.wikipedia.org/wiki/Soviet_Union) launched several [Sputnik](//en.wikipedia.org/wiki/Sputnik_program) satellites between 1957 and 1960, apparently enough that Charlie Brown and Lucy could use "Sputnik" as a generic term meaning "artificial satellite."
  * p. 138 (November 17, 1959) 1st panel. A [score of 300](//en.wikipedia.org/wiki/Perfect_game_\(bowling\)) \-- 12 strikes in a row -- is the best possible score in a single game of [ten-pin bowling](//en.wikipedia.org/wiki/Ten-pin_bowling).
  * p. 142 (November 26, 1959) 3rd panel. [Babylon](//en.wikipedia.org/wiki/Babylon) was a city in ancient [Mesopotamia](//en.wikipedia.org/wiki/Mesopotamia).
  * p. 142 (November 27, 1959) 2nd panel. [Solomon](//en.wikipedia.org/wiki/King_Solomon) \-- king of the [United Kingdom of Israel](//en.wikipedia.org/wiki/United_Monarchy), approximately 970 to 928 BCE. [Nebuchadnezzar](//en.wikipedia.org/wiki/Nebuchadrezzar_II) \-- more common name of Nebuchadrezzar II, ruler of Babylon (see previous strip) from about 605 to 562 BCE. [Genghis Khan](//en.wikipedia.org/wiki/Genghis_Khan) \-- founder of the [Mongol Empire](//en.wikipedia.org/wiki/Mongol_Empire) circa 1206.
  * p. 145 (December 5, 1959) 2nd and 3rd panels. Horsehide is another name for a [baseball](//en.wikipedia.org/wiki/Baseball_\(ball\)) and pigskin is another name for [an American football](//en.wikipedia.org/wiki/Pigskin#American_and_Canadian_football), in both cases due to the material traditionally used for each ball's cover. Both are now much more commonly made from either [cow leather](//en.wikipedia.org/wiki/Leather) or synthetic materials.
  * p. 150 (December 14, 1959) 4th panel. Beethoven's first name was actually [Ludwig](//en.wikipedia.org/wiki/Ludwig_van_Beethoven).
  * p. 152 (December 20, 1959) 6th panel. Linus's quote is [Luke 2:10](http://www.bartleby.com/108/42/2.html) from the [King James Version](//en.wikipedia.org/wiki/Authorized_King_James_Version) of the Bible. He expands upon it in _[A Charlie Brown Christmas](//en.wikipedia.org/wiki/A_Charlie_Brown_Christmas),_ quoting verses 8 through 14.
  * p. 160 (January 7, 1960) 4th panel. Indoor antennas intended primarily for receiving [VHF](//en.wikipedia.org/wiki/Very_high_frequency) television broadcasts were frequently in the form of a [dipole antenna](//en.wikipedia.org/wiki/Dipole_antenna#Set-top_TV_antenna) placed on top of the TV set, each pole a separate telescoping metal rod. Often set at a 45-degree angle to the set and a 90-degree angle to each other, these antennas were nicknamed "rabbit ears."
  * p. 162 (January 12, 1960). "Rabbit ears" antennas often had to be adjusted to a different position in order to improve the quality of the television picture, when changing to a channel that was transmitting from a different location than the previous channel, or as a result of changing atmospheric conditions.
  * p. 164 (January 17, 1960). The first iteration of what would become a recurring theme: Snoopy and his doomed relationship with a snowman. See also February 2, 1961; January 15–20, 1962; and, most memorably, February 18, 1962.
  * p. 174 (February 8, 1960). Snoopy's doghouse had not previously been shown as being this close to a house -- see January 2, 1960, for example.
  * p. 189 (March 14, 1960). "Whirlybird" is a nickname for [helicopters](//en.wikipedia.org/wiki/Helicopter).
  * p. 207 (April 25, 1960) 4th panel. The phrase "happiness is a warm puppy" led to an explosion in _Peanuts_ merchandise and entered the consciousness of the public at large, even inspiring [a Beatles song](//en.wikipedia.org/wiki/Happiness_Is_a_Warm_Gun). (Also see the April 27 and April 30 strips.)
  * p. 224 (June 5, 1960). Linus starts singing the traditional spiritual "[Dem Bones](//en.wikipedia.org/wiki/Dem_Bones)."
  * p. 240 (July 12, 1960). The [picture tube](//en.wikipedia.org/wiki/Cathode_ray_tube) is the main part of a traditional television set.
  * p. 243 (July 18, 1960). [Uncle Sam](//en.wikipedia.org/wiki/Uncle_Sam) is the traditional personification of the United States. The elephant is a symbol for the [Republican party](//en.wikipedia.org/wiki/Republican_Party_\(United_States), and the donkey is a symbol for its counterpart, the [Democratic party](//en.wikipedia.org/wiki/Democratic_Party_\(United_States\)). A snake with the phrase "Don't tread on me" is an image from early American history, most notably seen on the [Gadsden flag](//en.wikipedia.org/wiki/Gadsden_flag). All of this means that Lucy has crammed a bunch of symbols commonly used by editorial cartoonists into the same cartoon.
  * p. 245 (July 24, 1960) 13th panel. Lucy's [microphone](//en.wikipedia.org/wiki/Microphone) is a [lavalier](//en.wikipedia.org/wiki/Lavalier)-type condenser microphone, commonly worn by television personalities who would have to move around too much to use a fixed microphone and didn't need to use a handheld type. This type of microphone later became much smaller, to the point where it can now be clipped to a lapel or even hidden beneath a shirt.
  * p. 253 (August 11, 1960). The [spitball](//en.wikipedia.org/wiki/Spitball) was banned in professional baseball in 1920. Schulz and/or his syndicate may have worried about some client newspapers' acceptance of the word "spit" on their comics page, hence the use of the [euphemism](//en.wikipedia.org/wiki/Euphemism) "expectorate ball."
  * p. 254 (August 14, 1960) 4th panel. [British Honduras](//en.wikipedia.org/wiki/British_Honduras) is now known as [Belize](//en.wikipedia.org/wiki/Belize), after having become a self-governing colony in 1964 and fully independent of the United Kingdom in 1981.
  * p. 257 (August 21, 1960) 6th panel. "[Rain Rain Go Away](//en.wikipedia.org/wiki/Rain_Rain_Go_Away)" is a traditional nursery rhyme that normally doesn't work this quickly. (Also see the following two Sunday strips, August 28 and September 4.)
  * p. 264 (September 6, 1960). This storyline may have been inspired by an upgrade of [U.S. 101](//en.wikipedia.org/wiki/U.S._Route_101) through [Sonoma County, California](//en.wikipedia.org/wiki/Sonoma_County,_California), upgraded to a [freeway](//en.wikipedia.org/wiki/Freeway) in the 1960s. Since freeways are wider than traditional roads and require additional space for grade-separated interchanges at intersections, their construction often results in the need for the local government to use [eminent domain](//en.wikipedia.org/wiki/Eminent_domain) powers to purchase significant amounts of land on and around the route of the road.
  * p. 273 (September 28, 1960). Comedian [Mort Sahl](//en.wikipedia.org/wiki/Mort_Sahl) took much of his material from current events.
  * p. 282 (October 17, 1960). "Population explosion" was a term commonly used to describe conditions that could be leading to [overpopulation](//en.wikipedia.org/wiki/Overpopulation), in the news at the time due to the [baby boom](//en.wikipedia.org/wiki/Post-World_War_II_baby_boom) following World War II.
  * p. 287 (October 30, 1960). This strip was rewritten, with Sally put in place of Charlie Brown, and used as the climax of _[It's the Great Pumpkin, Charlie Brown](//en.wikipedia.org/wiki/It%27s_the_Great_Pumpkin,_Charlie_Brown)._
  * p. 305 (December 11, 1960), p. 308 (December 18, 1960), and p. 311 (December 25, 1960). This year, Linus's piece to memorize for the Christmas program is [Luke 2:1](http://www.bartleby.com/108/42/2.html), and Charlie Brown has Luke 2:8.
  * p. 313 (December 30, 1960). A container for [restaurant leftovers](//en.wikipedia.org/wiki/Leftovers) is sometimes known as a doggie bag.

* * *

Annotations to other volumes: [1950-1952](/wiki/Annotations_of_The_Complete_Peanuts/1950_to_1952) | [1953–1954](/wiki/Annotations_of_The_Complete_Peanuts/1953_to_1954) | [1955–1956](/wiki/Annotations_of_The_Complete_Peanuts/1955_to_1956) | [1957–1958](/wiki/Annotations_of_The_Complete_Peanuts/1957_to_1958) | [1959–1960](/wiki/Annotations_of_The_Complete_Peanuts/1959_to_1960) | [1961–1962](/wiki/Annotations_of_The_Complete_Peanuts/1961_to_1962) | [1963–1964](/wiki/Annotations_of_The_Complete_Peanuts/1963_to_1964) | [1965–1966](/wiki/Annotations_of_The_Complete_Peanuts/1965_to_1966) | [1967–1968](/wiki/Annotations_of_The_Complete_Peanuts/1967_to_1968) | [1969–1970](/wiki/Annotations_of_The_Complete_Peanuts/1969_to_1970) | [1971–1972](/wiki/Annotations_of_The_Complete_Peanuts/1971_to_1972) | [1973–1974](/wiki/Annotations_of_The_Complete_Peanuts/1973_to_1974) | [1975–1976](/wiki/Annotations_of_The_Complete_Peanuts/1975_to_1976) | [1977–1978](/wiki/Annotations_of_The_Complete_Peanuts/1977_to_1978) | [1979–1980](/wiki/Annotations_of_The_Complete_Peanuts/1979_to_1980) | [1981–1982](/wiki/Annotations_of_The_Complete_Peanuts/1981_to_1982) | [1983–1984](/wiki/Annotations_of_The_Complete_Peanuts/1983_to_1984) | [1985–1986](/wiki/Annotations_of_The_Complete_Peanuts/1985_to_1986) |

## 1961–1962

Annotations to _**The Complete Peanuts: 1961 to 1962**_ by Charles M. Schulz (Fantagraphics Books, 2006. [ISBN 1560976721](/wiki/Special:BookSources/1560976721))

  * p. 1 (January 1, 1961). In [ten pin bowling](//en.wikipedia.org/wiki/Ten-pin_bowling), the bowler gets two tries to knock down ten pins; if he/she gets the remainder of pins on the second roll, it is called a “spare”. Lucy is “picking up the spare” by knocking down Charlie Brown, the last boy standing.
  * p. 2 (January 2, 1961). This strip begins what would be the longest continued narrative in _Peanuts_ up to that time: three weeks.
  * p. 3 (January 6, 1961). The end of this strip and the following three dailies are sly references to drug withdrawal, specifically [heroin](//en.wikipedia.org/wiki/heroin)—an amusingly mature theme for the comics pages, especially at a time where comics were expected to have nothing to do with political and social issues, although not surprising for _Peanuts_, as it would explicitly tackle those kinds of issues later on, such as the Vietnam War and tear gas at campaign protests of the early 70's and late 60's, runaway licensing, and once in 1985, even triple bypass surgery.
  * p. 4 (January 11, 1961). Hyannis Port (sometimes written “Hyannisport”) is an affluent residential village southwest of [Hyannis](//en.wikipedia.org/wiki/Hyannis,_Massachussetts). It is best known as the ancestral home of the [Kennedy family](//en.wikipedia.org/wiki/Kennedy_family), including then–President-elect [John F. Kennedy](//en.wikipedia.org/wiki/John_F._Kennedy), who would be inaugurated nine days later, on January 20.
  * p. 10 (January 22, 1961). A reference to the biblical story of [David and Goliath](//en.wikipedia.org/wiki/David_and_Goliath). The diminutive Israeli shepherd [David](//en.wikipedia.org/wiki/David) slew the giant Philistine warrior [Goliath](//en.wikipedia.org/wiki/Goliath) with a rock hurled from a sling, as Linus does here with a snowball from his blanket.
  * p. 11 ([January 24, 1961](http://www.gocomics.com/peanuts/1961/01/24)). [Higher Criticism](//en.wikipedia.org/wiki/Historical_Criticism), which in the context of this strip is synonymous to [Source Criticism](//en.wikipedia.org/wiki/Source_Criticism), is a Bible study method that is based on pulling apart the traditional text into component pieces. Richard Elliot Friedman, a modern-day practitioner of Higher Criticism, has published [a book that reprints the Bible with each source distinguished by typeface and formatting](http://en.wikipedia.org/wiki/The_Bible_with_Sources_Revealed).
  * p. 12 (January 28, 1961). The second appearance of Lucy’s psychiatric booth (the first was on [March 27, 1959](/wiki/Annotations_of_The_Complete_Peanuts/1959_to_1960#p37)), and the first time it is drawn with its familiar canopy. Also note the redundant “5¢” sign at the bottom; this would later be replaced.
  * p. 14 (January 30, 1961). Linus is tabulating the combined gifts from the song “[The Twelve Days of Christmas](//en.wikipedia.org/wiki/The_Twelve_Days_of_Christmas_\(song\))”. The song has twelve verses, each listing the gifts given by “my true love”; the gifts cumulate with each day/verse. Linus’s math is correct; however, the song is more commonly sung to refer to “drummers drumming” rather than “fiddlers fiddling”.
  * p. 17 (February 8, 1961). [Pasteurization](//en.wikipedia.org/wiki/Pasteurization) is the process of heating liquids for the purpose of destroying viruses and harmful organisms, named for its inventor, chemist [Louis Pasteur](//en.wikipedia.org/wiki/Louis_Pasteur) (1822–1895). It is most commonly used on milk, hence Lucy’s pun here. Puns of this sort would later be almost completely delegated to Snoopy once he began typing.
  * p. 18 (February 11, 1961). Speculating on the effects of television on American culture, which Snoopy parodies here, was a common theme in the early days of the Kennedy administration. It would culminate three months later with [Federal Communications Commission](//en.wikipedia.org/wiki/Federal_Communications_Commission) chairman [Newton N. Minow](//en.wikipedia.org/wiki/Newton_N._Minow)’s “[Television and the Public Interest](//en.wikipedia.org/wiki/Wasteland_Speech)” speech, where he famously argued that television was often a “vast wasteland” with detrimental effects on the viewing public.
  * p. 21 (February 16, 1961). For the rest of 1961, Linus and (less often) the other characters will sometimes be wearing [American Civil War](//en.wikipedia.org/wiki/American_Civil_War)–style hats, due to its centennial (specifically referred to on July 8 and November 23, 1961).
  * p. 21 (February 16, 1961). First instance of a note in Linus' lunch.
  * p. 29 (March 6, 1961). The first appearance of Frieda. Like Charlie Brown and Linus, she was named after one of Schulz’s fellow instructors at the Art Instruction School in Minneapolis[2].
  * p. 34 (March 19, 1961). A [flannelgraph](//en.wikipedia.org/wiki/flannelgraph) is a method of telling stories, used in real life as Lucy does here. It is generally associated with American evangelical Sunday school lessons, as a means of telling Bible stories to young children. Schulz was undoubtedly aware of the practice from his own experiences teaching Sunday school. Christian writer John Fischer said, “[t]hough it has largely disappeared from the scene, flannelgraph may very well be the closest thing to a strictly evangelical art form, for I never encountered it anywhere but in Christian endeavors, and I haven’t seen it anywhere else since. It was an evangelical quirk of the 1950s that soon went the way of sword drills and the family altar”[3].
  * p. 36 (March 23, 1961). In 1961, a television small enough to be portable was still a relative novelty.
  * p. 47 (April 17, 1961). [National Library Week](//en.wikipedia.org/wiki/National_Library_Week) was started in 1958 amid concerns that television was reducing reading by children[4].
  * p. 48 (April 21, 1961). [Theodor “Dr. Seuss” Geisel](//en.wikipedia.org/wiki/Dr._Seuss) (1904–1991) was a popular American children’s book author, best known for his 1957 book _The Cat in the Hat_.
  * p. 54 (May 4, 1961). Lucy’s psychiatrist booth takes on its final appearance with the addition of the “The doctor is in” sign.
  * p. 60 (May 19, 1961). The H-Bomb is the common form of referring to [hydrogen bombs](//en.wikipedia.org/wiki/hydrogen_bomb).
  * p. 62 (May 23, 1961). Frieda’s cat Faron was the only cat that would ever appear in _Peanuts_. Schulz wrote later: “One day, while searching for some kind of new story to work on, I decided to have the character named Frieda... threaten Snoopy with bringing a cat into the neighborhood. Snoopy was horrified, and, when the cat arrived, did not like it at all. Fortunately for him, I also discovered that _I_ didn’t care much for the cat. For one thing, I realized that I don’t draw a cat very well, and secondly, if I were to keep up the relationship, I would have a traditional cat-and-dog strip, which was something I certainly wanted to avoid... the cat brought Snoopy back to being too much of a real dog. By the time the cat had come into the strip, Snoopy was drifting further and further into his fantasy life, and it was important that he continue in that direction. To take him back to his earlier days would not work, so I did the obvious and removed the cat. (My only regret was that I had named the cat after Faron Young, a country-and-western singer whom I admired very much...)”[2] Schulz would later introduce an “offstage” cat.
  * p. 63 (May 26, 1961). “[Sandbagging](//en.wikipedia.org/wiki/Sandbagging)” is a term mainly used in gaming or sporting contexts, meaning to feign weakness to obtain an advantage.
  * p. 64 (May 28, 1961). “[Just Before the Battle](//en.wikipedia.org/wiki/Just_Before_the_Battle,_Mother)” was an 1864 song written by [George F. Root](//en.wikipedia.org/wiki/George_Frederick_Root); it was a pro-Union song but was popular throughout America, including in the Confederacy. Linus is singing it in keeping with his Civil War centennial interest. He has gotten the lyrics wrong slightly: the second line is actually “I am thinking most of you”. 

Schulz would often refer to this strip as one of his favorites, and also as one of the few that was based on an idea he had gotten from his children: “We were at the dinner table and Amy was talking away on a real talking streak and finally I said, ‘Can’t you _please_ be quiet?’ and she was silent for a moment and then picked up a piece of bread and began to butter it, saying, ‘Am I buttering too loud for you?’”[5] The punchline would be repeated by Schulz on August 5, 1998, in honor of Amy’s birthday[6].

  * p. 66 (June 1, 1961). See [May 16, 1954](/wiki/Annotations_of_The_Complete_Peanuts/1953_to_1954#d19540516).
  * p. 67 (June 4, 1961). In keeping with Schulz’s attention to detail, all of Lucy’s definitions are accurate.
  * p. 75 (June 22, 1961). The “little girl” referred to in this and the next two strips is President Kennedy’s daughter [Caroline](//en.wikipedia.org/wiki/Caroline_Kennedy), who was three years old at the time they were published.
  * p. 80 (July 4, 1961). Shrimp Louie (or Louis) is a type of salad with shrimp and hard-boiled eggs. The recipe is based on the better-known [Crab Louie](//en.wikipedia.org/wiki/Crab_Louie).
  * p. 81 (July 8, 1961). Another reference to the Civil War Centennial. Charlie Brown is singing the “[Battle Cry of Freedom](//en.wikipedia.org/wiki/Battle_Cry_of_Freedom)”, a pro-Union song written by George F. Root in 1862; it was the most popular song of its day. Schroeder is singing “[The Bonnie Blue Flag](//en.wikipedia.org/wiki/The_Bonnie_Blue_Flag)”, a pro-Confederacy song written by [Harry McCarthy](//en.wikipedia.org/wiki/Harry_McCarthy) in 1861. See also May 28, 1961.
  * p. 83 (July 10, 1961). _The Flabby American_ was a television program about the physical fitness of Americans broadcast on May 30, 1961.
  * p. 85 (July 16, 1961). Snoopy's first appearance as a [vulture](//en.wikipedia.org/wiki/Vulture).
  * p. 102 (August 25, 1961). "Clam diggers" are pants that are longer than shorts but are not as long as long pants.
  * p. 121 (October 8, 1961). [Blackbeard](//en.wikipedia.org/wiki/Blackbeard) refers to the famous 18th century pirate Edward Teach, best known as Blackbeard.
  * p. 139 (November 19, 1961). The first reference to Charlie Brown’s unrequited love, The Little Red-Haired Girl. Schulz based her on Donna Johnson, a fellow teacher of his at the Art Instruction School, whom he dated in 1950. He had wanted to marry her, but later that year she married another man. 

Schulz said in 1997, “I was sitting home one night with my kids, and I was listening to some Hank Williams songs, and I was listening to Joni James singing, ‘Today I met you on the street, my heart fell at your feet,’ you know, and those songs were so depressing. And that was the mindset that got me going on Charlie Brown sitting at the playground, eating his lunch, and he looks across the playground, and he sees the Little Red-Haired Girl, and from that, that whole series came, one thing after another.”[7]

  * p. 151 and 154 (December 17 and 24, 1961). Linus' quotation is Matthew 2:17-18.
  * p. 170 (January 31, 1962). Linus refers to a [queen snake](//en.wikipedia.org/wiki/Queen_snake) for the first time.
  * p. 204 (April 20, 1962). Myopic refers to [myopia](//en.wikipedia.org/wiki/Myopia), or nearsightedness, which is presumably why Linus requires glasses.
  * p. 212 (May 8, 1962). "A pretty girl is like a melody" is the title of a popular song by [Irving Berlin](//en.wikipedia.org/wiki/Irving_Berlin), originally published in 1919.
  * p. 204 (June 28, 1962). An SC-54 is the [search and rescue](//en.wikipedia.org/wiki/Search_and_rescue) variant of the [C-54 Skymaster](//en.wikipedia.org/wiki/C-54_Skymaster) transport aircraft. Lieutenant Commander Carpenter is [Mercury](//en.wikipedia.org/wiki/Project_Mercury) astronaut [Scott Carpenter](//en.wikipedia.org/wiki/Scott_Carpenter), rescued under similar circumstances on May 24, 1962.
  * p. 240 (July 21, 1962). [Sam Snead](//en.wikipedia.org/wiki/Sam_Snead) was a legendary professional golfer from the thirties into the sixties, while [Don Carter](//en.wikipedia.org/wiki/Don_Carter_\(bowler\)) was a well known professional bowler during the fifties and early sixties.
  * p. 251 (August 6, 1962). [Casey Stengel](//en.wikipedia.org/wiki/Casey_Stengel) was a [baseball](//en.wikipedia.org/wiki/Baseball) player and manger, best known for managing the [New York Yankees](//en.wikipedia.org/wiki/New_York_Yankees) between 1949 and 1960, and the [New York Mets](//en.wikipedia.org/wiki/New_York_Mets) from 1962 to 1965.
  * p. 258 (August 25, 1962). Atmospheric testing refers to the testing of [nuclear weapons](//en.wikipedia.org/wiki/Nuclear_weapons) within the atmosphere, as opposed to underground testing. Atmospheric testing was banned under the [Limited Test Ban Treaty](//en.wikipedia.org/wiki/Limited_Test_Ban_Treaty), signed in August 1963.
  * p. 264 (September 8, 1962). [Knute Rockne](//en.wikipedia.org/wiki/Knute_Rockne) was a well known football coach at [Notre Dame University](//en.wikipedia.org/wiki/University_of_Notre_Dame) from 1918 to 1930.
  * p. 270 (September 20, 1962). The quotation is by [Anatole France](//en.wikipedia.org/wiki/Anatole_France).
  * p. 273 (September 27, 1962). [Gargoyles](//en.wikipedia.org/wiki/Gargoyle) are ornamental sculptures of grotesque figures, used to convey rainwater away from a building.
  * p. 281 (October 15, 1962). The Sabin oral polio vaccine was a [poliomyelitis](//en.wikipedia.org/wiki/Poliomyelitis) vaccine developed by [Albert Sabin](//en.wikipedia.org/wiki/Albert_Sabin) that could be taken orally. It replaced the earlier [Salk](//en.wikipedia.org/wiki/Jonas_Salk) vaccine, which needed to be injected with a syringe.
  * p. 288 (November 2, 1962). Linus is alluding to the expression "Hell hath no fury like a woman scorned". The original phrase is "Heaven has no rage like love to hatred turned / Nor hell a fury like a woman scorned.", taken from "The Mourning Bride" (1697) by [William Congreve](//en.wikipedia.org/wiki/William_Congreve).
  * p. 293 (November 12, 1962). [Rachel Carson](//en.wikipedia.org/wiki/Rachel_Carson) was the author of the early environmentalist book [Silent Spring](//en.wikipedia.org/wiki/Silent_Spring). As a well known author and scientist at the time, Carson will be frequently referenced in future strips as a female role model.
  * p. 309 (December 22, 1962). Charlie Brown is referring to the last game of the [1962 World Series](//en.wikipedia.org/wiki/1962_World_Series), in which the [San Francisco Giants](//en.wikipedia.org/wiki/San_Francisco_Giants) lost to the New York Yankees in the seventh game, after [Willie McCovey's](//en.wikipedia.org/wiki/Willie_McCovey) line drive was caught by [Bobby Richardson](//en.wikipedia.org/wiki/Bobby_Richardson).

  


* * *

Annotations to other volumes: [1950-1952](/wiki/Annotations_of_The_Complete_Peanuts/1950_to_1952) | [1953–1954](/wiki/Annotations_of_The_Complete_Peanuts/1953_to_1954) | [1955–1956](/wiki/Annotations_of_The_Complete_Peanuts/1955_to_1956) | [1957–1958](/wiki/Annotations_of_The_Complete_Peanuts/1957_to_1958) | [1959–1960](/wiki/Annotations_of_The_Complete_Peanuts/1959_to_1960) | [1961–1962](/wiki/Annotations_of_The_Complete_Peanuts/1961_to_1962) | [1963–1964](/wiki/Annotations_of_The_Complete_Peanuts/1963_to_1964) | [1965–1966](/wiki/Annotations_of_The_Complete_Peanuts/1965_to_1966) | [1967–1968](/wiki/Annotations_of_The_Complete_Peanuts/1967_to_1968) | [1969–1970](/wiki/Annotations_of_The_Complete_Peanuts/1969_to_1970) | [1971–1972](/wiki/Annotations_of_The_Complete_Peanuts/1971_to_1972) | [1973–1974](/wiki/Annotations_of_The_Complete_Peanuts/1973_to_1974) | [1975–1976](/wiki/Annotations_of_The_Complete_Peanuts/1975_to_1976) | [1977–1978](/wiki/Annotations_of_The_Complete_Peanuts/1977_to_1978) | [1979–1980](/wiki/Annotations_of_The_Complete_Peanuts/1979_to_1980) | [1981–1982](/wiki/Annotations_of_The_Complete_Peanuts/1981_to_1982) | [1983–1984](/wiki/Annotations_of_The_Complete_Peanuts/1983_to_1984) | [1985–1986](/wiki/Annotations_of_The_Complete_Peanuts/1985_to_1986) |

  


# References

  1. ↑ Wilson, Kenneth (September 1967). "A Visit with Charles Schulz". _Christian Herald_. 
  2. ↑ _**a**_ _**b**_ Schulz, Charles M. (1975). _Peanuts Jubilee: My Life and Art with Charlie Brown and Others_. New York: Holt, Rinehart and Winston. [ISBN 0030150817](/wiki/Special:BookSources/0030150817). 
  3. ↑ Fischer, John (2003-02-03). ["In Praise of Flannelgraph"](http://web.archive.org/web/20070929195035/http://pfm.activematter.com/AM/Template.cfm?Section=Home&TEMPLATE=/CM/ContentDisplay.cfm&CONTENTID=4709). Prison Fellowship Ministries. Archived from [the original](http://pfm.activematter.com/AM/Template.cfm?Section=Home&TEMPLATE=/CM/ContentDisplay.cfm&CONTENTID=4709) on 2007-09-29. [http://web.archive.org/web/20070929195035/http://pfm.activematter.com/AM/Template.cfm?Section=Home&TEMPLATE=/CM/ContentDisplay.cfm&CONTENTID=4709](http://web.archive.org/web/20070929195035/http://pfm.activematter.com/AM/Template.cfm?Section=Home&TEMPLATE=/CM/ContentDisplay.cfm&CONTENTID=4709). Retrieved 2007-05-18. 
  4. ↑ ["National Library Week Fact Sheet"](http://www.ala.org/ala/pio/mediarelationsa/factsheets/NationalLibraryWeek.htm). American Library Association. <http://www.ala.org/ala/pio/mediarelationsa/factsheets/NationalLibraryWeek.htm>. Retrieved 2007-05-18. 
  5. ↑ Conrad, Barnaby (1967-04-16). "You’re a Good Man, Charlie Schulz". _The New York Times Magazine_. 
  6. ↑ Bang, Derrick (2007-04-29). ["alt.comics.peanuts FAQ"](http://www.peanutscollectorclub.com/peantfaq.txt) (plaintext). <http://www.peanutscollectorclub.com/peantfaq.txt>. Retrieved 2007-06-02. 
  7. ↑ "An Interview with Cartoonist Charles M. Schulz". Interviewer: Charlie Rose. _Charlie Rose_. PBS. 1997-05-09. 20:30 minutes in.
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&oldid=1953900](http://en.wikibooks.org/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&oldid=1953900)" 

[Category](/wiki/Special:Categories): 

  * [Annotations of The Complete Peanuts](/wiki/Category:Annotations_of_The_Complete_Peanuts)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Annotations+of+The+Complete+Peanuts%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Annotations+of+The+Complete+Peanuts%2FPrint+version)

### Namespaces

  * [Book](/wiki/Annotations_of_The_Complete_Peanuts/Print_version)
  * [Discussion](/w/index.php?title=Talk:Annotations_of_The_Complete_Peanuts/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&action=edit)
  * [View history](/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Annotations_of_The_Complete_Peanuts/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Annotations_of_The_Complete_Peanuts/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&oldid=1953900)
  * [Page information](/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Annotations_of_The_Complete_Peanuts%2FPrint_version&id=1953900)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Annotations+of+The+Complete+Peanuts%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Annotations+of+The+Complete+Peanuts%2FPrint+version&oldid=1953900&writer=rl)
  * [Printable version](/w/index.php?title=Annotations_of_The_Complete_Peanuts/Print_version&printable=yes)

  * This page was last modified on 21 October 2010, at 14:19.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Annotations_of_The_Complete_Peanuts/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
