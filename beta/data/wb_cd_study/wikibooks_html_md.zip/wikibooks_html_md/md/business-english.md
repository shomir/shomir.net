# Business English/Print version

From Wikibooks, open books for an open world

< [Business English](/wiki/Business_English)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Business_English/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Business_English/Print_version) on _9 March 2009_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Business_English/Print_version&oldid=1438745&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


## Contents

  * 1 Work
  * 2 Branding
  * 3 Marketing
  * 4 Finance
  * 5 Big business
  * 6 Home office
  * 7 Computers and technology
  * 8 Engineering
  * 9 Sports
  * 10 Business books and magazines
  * 11 Cold calling
    * 11.1 The cold call
    * 11.2 Planning the call: Establish your objectives & prepare the conversation
    * 11.3 Just before the call: Prepare your mind and body for a positive attitude
    * 11.4 Ending the call: Finish with definite goals & confirm information
    * 11.5 Business English lessons on cold calling
  * 12 Starting Your Own Business
    * 12.1 Don't go for what looks easy or flashy
    * 12.2 Start slowly
    * 12.3 Build your network
    * 12.4 Expect the unexpected
  * 13 American culture
  * 14 American business culture
    * 14.1 Work comes first
    * 14.2 Be very clear in what you say
    * 14.3 Honesty is the best policy
    * 14.4 Logic rules over emotion
    * 14.5 Respect the old guys
    * 14.6 New values: women are equal players
    * 14.7 Businessmen and sports
    * 14.8 Taboos: don’t go there
    * 14.9 Topics to talk about
  * 15 Time management
  * 16 Bad News Letters
  * 17 Routine and Good News Letters
  * 18 Grammar
  * 19 Reading and Writing
    * 19.1 Topics for Mini-Research Papers
    * 19.2 English Language and Grammar Topics
    * 19.3 Suggested writing topics
    * 19.4 Reading
  * 20 Speaking and Listening
  * 21 Interviewing
    * 21.1 Interview Questions
    * 21.2 Conversation Topics
  * 22 Idioms
    * 22.1 Business Acronyms
    * 22.2 Common English idioms
    * 22.3 Sports-derived idioms
  * 23 Phrasal Verbs
  * 24 Get
    * 24.1 Basic
    * 24.2 Intermediate
    * 24.3 Advanced
  * 25 Turn
  * 26 Up
  * 27 Slang
  * 28 English Proverbs
  * 29 Activities and Dynamics
    * 29.1 Games
      * 29.1.1 Guess the person
  * 30 Areas of English Proficiency
  * 31 Making a Personal Plan to Improve Your English
    * 31.1 Where to go
      * 31.1.1 SMART Goals
    * 31.2 How to get there (personalizing your plan)
      * 31.2.1 Vocabulary (passive and active vocab)
      * 31.2.2 Fluency (finding words quickly)
      * 31.2.3 Natural speech patterns
      * 31.2.4 Written English (grammar and spelling)
      * 31.2.5 Pronunciation
      * 31.2.6 Flow of speech
      * 31.2.7 Culture
  * 32 Getting More Practice
  * 33 Tips for Teachers
    * 33.1 Link
  * 34 Course Outlines
    * 34.1 Class 1
    * 34.2 Class 2
    * 34.3 Class 3
    * 34.4 Class 4
    * 34.5 Class 5
    * 34.6 Class 6
    * 34.7 Class 7
    * 34.8 Class 8
    * 34.9 Class 9
    * 34.10 Class 10
    * 34.11 Class 11
    * 34.12 Class 12
    * 34.13 Class 13
    * 34.14 Class 14
    * 34.15 Note
  * 35 Links

# Work

Working is good for your life. You might say, "I knew that".

  


# Branding

That's the special name. The one word which brings to mind images associated with it. Say "Coke" and you have defined refreshment in essence.

  


# Marketing

[Business English/Topics/Marketing](/w/index.php?title=Business_English/Topics/Marketing&action=edit&redlink=1)

  


# Finance

[Business English/Topics/Finance](/w/index.php?title=Business_English/Topics/Finance&action=edit&redlink=1)

  


# Big business

[Business English/Topics/Big business](/w/index.php?title=Business_English/Topics/Big_business&action=edit&redlink=1)

  


# Home office

[Business English/Topics/Home office](/w/index.php?title=Business_English/Topics/Home_office&action=edit&redlink=1)

  


# Computers and technology

[Business English/Topics/Computers and technology](/w/index.php?title=Business_English/Topics/Computers_and_technology&action=edit&redlink=1)

  


# Engineering

[Business English/Topics/Engineering](/w/index.php?title=Business_English/Topics/Engineering&action=edit&redlink=1)

  


# Sports

To deal with American business persons it is a good idea to understand something about American sports. Many businessmen were athletes in high school and college and have had their way of thinking formed by team sports. It is important to know a little about the most popular sports: football (not soccer), basketball, baseball, golf, and even hockey in some areas.

Sports metaphors and jargon permeate even polite speech. Below are some common expressions:a

  * "Run with it" or "Take the ball and run with it"
  * "Homerun", "That's a homerun", or "Hit a homerun"
  * "Punt", "It's time to punt", "I think we'll have to punt", or "We punted"
  * "Hole in one" or "You hit a hole in one"
  * "Hail Mary" or "Throw a Hail Mary"
  * "Slam dunk" or "It was a slam dunk"

It is expected that conversational partners will understand these. Only those speakers who reflect on the cultural derivation of these expressions will modify their speech for those who do not share similar cultural backgrounds. However, the savvy listener can usually comprehend the meaning of these expressions when heard in context of a discussion.

  


# Business books and magazines

[Business English/Topics/Business books and magazines](/w/index.php?title=Business_English/Topics/Business_books_and_magazines&action=edit&redlink=1)

  


# Cold calling

## The cold call

Cold calls are telephone calls to anyone that you do not know and have not spoken with before. We often make cold calls to try to establish business contacts; to get a job, find a new client, seek someone else’s services, or initiate any other business relationship. Following are some tips on how to make effective cold calls.

  


## Planning the call: Establish your objectives & prepare the conversation

Plan your call. This requires a conscious effort to sit down, think, and plan out what it is you want to achieve with the call. After you determine your goals, go over them in your mind until they are very clear to you.

Then, imagine how a conversation might be with the person or business that you plan to call. Rehearse it in your mind and get ready to give a quick and confident presentation of your ideas. Prepare yourself so that you do not stutter or hesitate; you should know exactly what it is you want to say, and be able to say it backwards and forwards. Decide how you want the conversation to flow.

General goals to have for a cold call are to establish contact. You will want the person to remember you the next time you call, and have positive feelings towards you. Plan for the call to be as short as possible and focus on setting up an appointment. All negotiation or in-depth talking should take place later, when you are with the other party in person.

## Just before the call: Prepare your mind and body for a positive attitude

You may not realize it, but the position of your body influences how your mind works, what hormones are flowing through your veins, and ultimately, how others perceive you. This is true when you talk with someone face to face as well as over the phone. The reason is that your physical state affects your mental state: your thinking, your attitude, and your voice. Remember that your voice is your only tool to communicate your ideas over the telephone. How can you prepare your body? Make the call sitting down in a chair and leaning slightly forward. This puts you in a state for a positive attitude. Then smile. The person on the other end of the line will be able to hear it. Making the call: Be brief, be polite When you are duly prepared, pick up the phone and dial. Identify yourself confidently by name and ask if the person has a moment to take your call. It is possible that the person is in a meeting or is otherwise unable to talk with you at the moment, even if they answered your call. Be considerate and allow them to end the call immediately if needed.

Remember to be as brief as possible when calling. Your goal is not to chat up anyone, but rather establish contact and a specific time to meet. The person you are calling is a busy professional who would much rather be doing something productive than chewing the fat with strangers cold-calling them on the phone.

## Ending the call: Finish with definite goals & confirm information

The end of the call is a time to be very concrete and confirm the next steps that you will take. Ideally this will mean an appointment to meet with the person you called. If the person is too busy to speak with you , set a specific time for you to call them back, for example five minutes, an hour, two days. If the time is excessively large, this is a clear signal that the person really has little interest in speaking with you. If you have set up an appointment, repeat the time and date, so there is no confusion.

When you say goodbye, do so quickly and confidently, thank the person for their time and repeat your name. It is possible that even in a short call the person has forgotten your name, and repeating it helps avoid awkwardness, and helps assure that they will remember it next time as well.

  
Based on a presentation by Edgar Flores, English student in Mexico City.

## Business English lessons on cold calling

[Business English Pod](http://www.businessenglishpod.com/) has a series of free podcast lessons providing clear guidance on the techniques and language for cold calling in English:

  
[Part 1 - Starting the cold call](http://www.businessenglishpod.com/2007/05/09/bep-46-adv-cold-calling-getting-off-to-a-good-start/)  
[Part 2 - Clarifying benefits and making a pitch](http://www.businessenglishpod.com/2007/05/13/bep-47-adv-cold-calling-clarifying-benefits-and-making-a-pitch/)  
[Part 3 - Dealing with objections and closing the call](http://www.businessenglishpod.com/2007/05/16/bep-48-adv-cold-calling-dealing-with-objections-and-closing-the-call/)

  


# Starting Your Own Business

## Don't go for what looks easy or flashy

Do something that you know well, where you have experience and are an expert. You should thoroughly understand all of the issues related to the activity.

Sometimes people can be tempted to do something that looks simple to start and deal with. The fact is that in any activity that you can imagine there are many things that are impossible to predict until they come up:

a) Certain unexpected situations  
b) Once in the situation, how to deal with it

You will need to plan to be effective, and you can´t plan what you don´t know. You can react to the unexpected but usually, that is an easy way to get in trouble.

  


## Start slowly

In the beginning of your business try, if you can, to deal with it as a side-line, so you are not depending on it for an income. That way you will only risk time, effort and maybe little money as you begin to test your idea in the real world, and learn a lot from it.

If things are going well pehaps it is the moment to move forward and be very conscious of the consecuences of your decisions. That will help you a lot in the future, when you will have to make decisions that may imply risks. Experience is the most powerful tool that you can rely on in this situation.

A gradual transition will allow you to think, plan, execute without risk and see and work on potential problems that perhaps you woulden´t realize from the beginning.

## Build your network

Relations will help you in the beginning of your operations, and in countries like Mexico contacts are the main source of opportunities to make business.

There are many methods to develop a business network, and it depends on your capability to invest some money to obtain results. In the beginning the best practice is to establish contacts on a one-to-one basis. This means that you should approach your contacts to offer them some benefits if they are able to offer you potential business opportunities. This doesn´t mean an attempt to bribe them (at least not necesarily), but instead you can offer your complete help to obtain results oriented to their positioning in their field of action. An example of this is to offer your organization as manpower to solve some of their concerns without any additional charge if in exchange you can get the opportunity to show your abilities and results. It is very good to develop a “partnership” relation with people that know you and is aware of your efforts to create your company.

Another way to do this, but much more expensive is to organize (and therefore to pay for) some events (business breakfast, perhaps) in which you will have the opportunity to present your products or services, and after your presentation provide some brochures to the audience, and most important, to collect data from them in order to establish further contact on one to one basis again, to work on those issues that have interested them more.

Those things mentioned above would allow you to keep in contact with the people that can provide you business opportunities. For instance, once you have identified a group of executives that would represent a solid network, you can invite them to some periodic events in which they will have opportunity to keep contact among themselves (to establish their own network), and also receive information about topics that should be very interesting for them in their activity (products or services presentations, some recognized speaker... etc.). Doing that three times a year will provide you reasons to be in contact with them and take advantage of that to expect the chance to be in the right place in the right moment.

  


## Expect the unexpected

Reality will show you all those things that you didn´t consider in your previous planning activity. Yes, shit happens, and Murphy is relentless. Be prepared and deal with it, whatever, without hessitation and tune up your reaction abilities. That will protect you until you get the experience to know in advance what will happen according to the signs that always appear to trained eye.

* * *

The original version of this page was written by [Juan Enrique Pérez](http://capital-humano.com/contacto.htm) of [Capital Humano](http://capital-humano.com/).

  


# American culture

[Business English/Topics/American culture](/w/index.php?title=Business_English/Topics/American_culture&action=edit&redlink=1)

  


# American business culture

**When in Rome, do as American tourists do everywhere** – American proverb

Sometimes etiquette is easily explained to the non-native in a clear set of rules that any decent member of the culture follows. For example, in Japan it is considered impolite to show the soles of one’s shoes toward another person. However, sometimes the rules are not clear, and the polite person has to improvise to figure out the most polite thing to do. An example of this might be when the elder President Bush ducked below the table before vomiting at a state dinner. No book about culture or etiquette would have prepared him for that one, although now all American presidents place a strategically sited bowl beneath their chair at official events.

That said, the following is a simple explanation of the basic points of American Business Etiquette. This is a tool aimed at helping you do as Americans do when working with them on their own soil, over the telephone or even by email.

  


## Work comes first

Americans and businessmen and women in particular are very task-oriented. They get a goal in mind and work until achieving it. An American is likely to avoid chit-chat as idle chatter and in a business meeting want to talk about business and little else. “Let’s get our focus on the bottom line” is an Americanism that reflects this tendency. Therefore be careful to not distract the conversation from the business at hand. Direct your comments towards identifying, and especially, solving problems. The people will feel more confidence in you when they feel that you are putting your heart behind the project at hand, whatever it may be. A big part of Americans’ lives revolve closely around their work, and although they may politely complain about it, the truth is that they like it like that. Americans do love to have fun, but it has its place, and that place should not interfere with work or a man (or woman) earning his (or her) livelihood.

## Be very clear in what you say

Something that will madden your American partners is if they think that you beat around the bush in what you say. US culture values a person who says what he means and means what he says. "Get to the point!", angry teammates may demand. Americans value clarity many times over what other cultures view as tact. It is better to lay everything out on the table, and not leave key points unmentioned for politeness’ sake. Not following this policy could be interpreted as rudeness or as gravely as dishonesty by your peers.

## Honesty is the best policy

Related to the previous point, you will do well to avoid any kind of dishonesty in word or deed with your American partners. Do not suggest bribes, kickbacks, any other kind of illegal or unlawful payoffs, or anything else that goes against the law of the US or wherever it is that you are. Play by the rules. In the US, people get ahead while respecting the rules of the game. It has been said many times that, unlike other places, in the US it is easier to make money following the law than by breaking it, although this does not necessarily apply to US corporations operating abroad. Americans realize that if you are dishonest with the government or with anyone else, you are a dishonest person and will probably be dishonest with everyone or anyone that you work with, and are not to be trusted. That is, unless you are in a completely powerless situation where your every move can be controlled and all risk can be eliminated. But you don’t want to be in that situation, do you?

## Logic rules over emotion

One of the worst things that you can do is appear emotional, or unable to make a cold, hard decision. It’s OK to get angry, and show it, about certain things, especially things that affect the bottom line. Don’t change your mind a lot of times if you don’t want to exasperate your coworkers.

## Respect the old guys

First off, don’t call them old guys. At least not to their faces. The senior partners at the firm have worked a long time to get there and although American entertainment may make fun of older citizens as worn-out or useless, the business world certainly does not treat them that way. They are to be respected as the wisest and most seasoned individuals on the team, which they likely are. When dealing with them, speak to them and otherwise treat them with respect. Depending on the culture of the corporation, this may mean not to speak with them at all. Allow them to speak to you if they want something, otherwise it may be a good idea to not speak to them at all. A special note: if the executive is concerned about his advancing age and wants to be seen as younger than he really is, it may be better to speak to him more casually. In most cases, avoid using slang because it magnifies the difference between the generations and it may make the exec feel old or out of place, or worse yet, he may not even understand you.

  


## New values: women are equal players

In US law, women are granted equal rights with men. Business women expect to be treated with the same respect as their male counterparts. They are considered to be equal to men in character and ability. Their gender is considered to be irrelevant in business settings.

It is absolutely inappropriate to make any sexual advances, make suggestive comments, or try to get them to go out for personal time not related to work. Do not treat them like secretaries unless, in fact, they are a secretary. Treat them with the same consideration as you would treat any co-worker.

Unfortunately, gender equality has not yet been fulfilled in the workplace. On average, women earn about twenty percent less than men for the same work, and are many are still held down in pay and position by an unofficial upper limit called the glass ceiling. Women have been gradually breaking through this glass ceiling, and are increasingly holding senior management and board positions within corporations.

## Businessmen and sports

A lot of business persons were athletes in high school and college. There are many things that are similar between team sports and business activities, and both attract many of the same people. It is a good idea to become familiar with the basics of baseball, football, and basketball at least in order to make semi-intelligent sports-related small talk. Beyond small talk, business talk is filled with sports-related idioms. These are used so comfortably in American speech that the speaker probably will not even realize that he is using them.

  


## Taboos: don’t go there

The two main subjects that Americans agree not to discuss much in polite conversation are 1: politics and 2: religion. That is because they are areas where people have deep-rooted beliefs that are not easily changed, and there is a great potential for misunderstanding or hurt feelings, besides the fact that outside of church or a political rally, many people view them as unrelated to the whatever task you have on your plate at the time.

Besides this, avoid criticizing the US, US culture, Americans in general or US policy, unless they have recently invaded your country. Americans for the most part deeply love their country and may be offended and confused by comments that do not reflect a similar love and respect, and may take the comments personally. However, there is also a great diversity in their view of themselves; therefore do not expect them all to respond in the same way.

## Topics to talk about

There are certain topics that are common to talk about in casual business situations. Feel free to talk about the rich, sports, entertainment like movies, music, celebrities and books, and current events or business trends. Try to keep things general and not too personal. Nobody wants to know about your grandmother or problems with your spouse. When in doubt, talk business.

  


# Time management

[Business English/Topics/Time management](/w/index.php?title=Business_English/Topics/Time_management&action=edit&redlink=1)

  


# Bad News Letters

[Business English/Topics/Bad news letters](/w/index.php?title=Business_English/Topics/Bad_news_letters&action=edit&redlink=1)

  


# Routine and Good News Letters

[Business English/Topics/Routine and good news letters](/w/index.php?title=Business_English/Topics/Routine_and_good_news_letters&action=edit&redlink=1)

  


# Grammar

Check out [this grammatical information](/wiki/English) while we write new content for the Business English book.

  


# Reading and Writing

Both reading and writing are important skills for anyone who wants to do business in English. Here is a list of suggested writing topics.

## Topics for Mini-Research Papers

  * MBTI / Myers-Briggs Personality Type Indicator
  * The Campbell-Stone Restoration Movement [World Convention National Profile Pages](http://www.worldconvention.org/nationalprofiles.php)
  * Peter Drucker
  * The de Vinci Code
  * Stephen Covey and the Seven Habits of Highly Effective People
  * Moore’s Law
  * Different styles of leadership and leaders
  * Rasputin
  * Wal-Mart
  * Nonverbal communication
  * The origins of English
  * Today’s weather in (you choose the location)
  * Choose your own topic!

  
Use the Internet or traditional printed materials to find information about your chosen topic. Write like a reporter or historiographer and remember the six w’s: who, what, when, where, why, and how. The length of the paper should reflect the complexity of the issue, your English fluency, and your time available. One to two typewritten pages is typically an appropriate length.

Include a bibliography citing the Internet pages that you used as reference.

Use ONLY your own words, except for short, cited quotations. It is usually better to read about the subject, but the material aside, and write from your own memory. That is, don’t read your source material and write your essay at the same time.

## English Language and Grammar Topics

  * Correct use of adjectives
  * Present simple vs. present progressive (continuous) tense
  * Using articles (a, an, the, …)
  * When to use “what” and when to use “that”

The directions are the same as above. Include examples whenever possible.

I saw an article in a newspaper of yesterday requesting for readers to put comments on the passage.

The whole group was against my sister for not turning up to a meeting which was very important to her.

We had an accident on our way to Zomba.

What happened to your sister who is now in prison?

When is the next meeting taking place?

That place is not good for your health.

## Suggested writing topics

  * Describe your line of work and your responsibilities.
  * Write a history of your family.
  * Tell about a favorite memory, perhaps a childhood memory.
  * Describe the office or facilities where you work.
  * Describe a system or process that you are familiar with in your work.
  * Write a plan and analysis describing your goals in studying English.
  * Write up a business plan for a business that you might think about starting.
  * Write about something that you are passionate about.
  * Describe a visit to an English-speaking area.
  * Choose a topic and write about it for this [Business English](/wiki/Business_English) book.
  * Write about your favorite music, group, or artist.
  * What important things have you accomplished in your life?
  * What would you like to do when you retire?
  * What do you regret doing or not doing?
  * Read an article from the [Wikipedia](//en.wikipedia.org/wiki/Main_Page) or other source and write a summary of it.

## Reading

You can get practice reading at many places. Some websites that you might like to visit are the [Wikipedia](//en.wikipedia.org/wiki/Main_Page), [New York Times](http://www.nytimes.com/) (free and painless registration required, really, it's worth it), [The Economist](http://www.economist.com/), (a British newsmagazine), and various English magazines that may be available where you live.

  


# Speaking and Listening

[Free Business English Podcast Lessons](http://www.businessenglishpod.com) \- MP3 lessons that feature all kinds of useful business English phrases and vocabulary. Listening comprehension questions included in each podcast.

    [Business English/Interviewing](/wiki/Business_English/Interviewing)

  


# Interviewing

It is great practice to do one-on-one conversations on specific topics. Here is a starter list of interview questions and conversational topics.

### Interview Questions

  * Where do you work?
  * What is the best part of your job?
  * What's the worst part?
  * What are three adjectives that describe you?
  * Why do you want to study Business English?
  * What is your dream job and why?
  * What is your competency?

### Conversation Topics

  * Sports
  * Television
  * Entertainment (movies, music, celebrities and books)
  * Business ethics
  * Food and drinks
  * Money
  * The rich
  * Current events
  * Business trends
  * Work
  * Branding
  * Marketing
  * Finance
  * Big business
  * Home office
  * Computers and technology
  * Engineering
  * Business books and magazines
  * Cold calling
  * Starting your own business
  * American culture
  * American business culture♠
  * Time management
  * Bad news letters
  * Routine and good news letters

  


# Idioms

## Business Acronyms

ASAP  : As Soon As Possible

COB  : Close Of Business

COP  : Close Of Play

EOD.  : End Of Day

PO  : Purchase Order

GR  : Goods Receipt

IR  : Invoice Receipt

R/E  : Rate of Exchange (also called FX exchange)

TOR  : Terms of Reference

P/C  : Price, Current

O/S  : Out of Stock, differs from...

OS  : ...On Sample

EBIT  : Earnings Before Interests and Taxes; Shows the result of the company before Interest expenditures and Income Taxes. It differs from...

EBITDA : Earnings Before Interests, Taxes, Depreciation and Amortization; ...that gives a more precise idea of final result (earnings or loss). It takes into account these two aspects of business in addition.

BOY  : Beginning Of the Year; Generally January, but in any case is considered the beginning of the financial year (for statements purpose).

EOY  : End Of the Year; Generally December, but in any case is considered the end of the financial year (for statements purpose).

YTD  : Year To Date; term generally used to indicate all the expenses a firm incurred in during a year (P&L)

WIP  : Work In Progress; Especially used for assets under construction.

**Company Departments - Functional Areas**

MKT  : Marketing R&D  : Research and Development H&S  : Health and Security M&R  : Maintenance and Repair HR  : Human Resources IT  : Information Technology AR  : Account Receivable

SG&A  : Selling, General & Administrative (regroups many depts. generally excluding manufacturing only, or manuf. + R&D)

## Common English idioms

**Black Tie** \- Not a true idiom; however, it can be misleading. It does not mean 'Wear a black tie', but rather a '**DJ**' or dinner jacket and bow tie (alternatively a tuxedo)

**e.g.** or **eg.** \- _exempli gratia_, for example

**et al.** \- _et alii_, and others

**i.e.** or **ie.** \- _id est_, that is; in other words

**NB** \- _Nota Bene_, note well

**PS** \- _Post Script_, Written after the end of an informal letter. Used in order to include a piece of information forgotten to be included at the beginning of the letter

**RSVP** \- _Repondez s'il vous plait_, is an abbreviation for ‘répondez s’il vous plaît’, which means ‘please reply’. It is written on the bottom of a card inviting you to a party or special occasion.

**CV** \- _Curriculum Vitae_, Latin expression meaning "course of life" in other words, a resumee.

**N/A** \- _Not Applicable_

**RGDS** \- _Regards_

## Sports-derived idioms

  


# Phrasal Verbs

English is filled with phrasal verbs, which are phrases made of **one verb** with one or more **other words** (usually prepositions) that work together to form a **single, multi-word verb**. You need to learn these in order to speak English naturally as well as to understand natural English.

    [Be](/w/index.php?title=Business_English/Print_version/Be&action=edit&redlink=1)
    [Come](/w/index.php?title=Business_English/Print_version/Come&action=edit&redlink=1)
    [Get](/w/index.php?title=Business_English/Print_version/Get&action=edit&redlink=1)
    [Go](/w/index.php?title=Business_English/Print_version/Go&action=edit&redlink=1)
    [Keep](/w/index.php?title=Business_English/Print_version/Keep&action=edit&redlink=1)
    [Make](/w/index.php?title=Business_English/Print_version/Make&action=edit&redlink=1)
    [Turn](/w/index.php?title=Business_English/Print_version/Turn&action=edit&redlink=1)
    [Up](/w/index.php?title=Business_English/Print_version/Up&action=edit&redlink=1)

    [Miscellaneous phrasal verbs](/w/index.php?title=Business_English/Print_version/Miscellaneous&action=edit&redlink=1)

  


# Get

The verb “to get” can be used in many ways. It means to obtain, have or receive, and can be used sometimes in place of the verbs, “to be” and “to become”. The verb is very flexible and sometimes, when combined with other words, can take on a whole different meaning. Following is a short list of some common verb phrases using “to get”. Note: s/b means “somebody”, s/th means “something”

  


## Basic

(to) get drunk: to drink until intoxicated with alcohol The college boys lived to get drunk every weekend.

(to) get in s/th: to enter (a car, a body of water, a group, trouble ...) Come on, get in the car so we can go. That boy is always getting in trouble.

(to) get lost: to lose one’s way Goldilocks wandered far into the forest and soon got very lost, and had no idea how to leave.

(to) get mad: to become angry The girl got real mad when she found out that her boyfriend had forgotten to pick her up.

(to) get off s/th: to leave, especially an elevated or isolated place such as a bus, elevator or island. Opposite of “get on” We were so glad to get off of that elevator after being trapped there for over two hours in the heat.

(to) get on s/th: to enter, especially public transportation or small, elevated place. Opposite of “get off” The little girl was afraid to get on the ride at the carnival.

(to) get out: to do fun or enriching activities That lady never gets out, so has no idea what is going on in this world.

(to) get rained on: to be rained on It was a real bummer that the picnic had gotten rained on.

(to) get together (with s/b): to meet with one or more other people They got together every Thursday to play cards and catch up on each other’s lives. Spongebob got together with Patrick to plan their escape.

(to) get up: to arise, leave the bed It sure was hard to get up in the morning after drinking so much the night before.

## Intermediate

(to) get along with s/b: refers to the quality of a relationship with someone I have not been getting along with my brother since he wrecked my car.

(to) get around: to be familiar with many places or things She needs some time to get around and see all that the city has to offer.

(to) get around to: to do something when time allows I’ll get in shape and pay my bills just as soon as I can get around to it.

(to) get away: to escape from work or stress to relax The family planned their vacations to get away from the city.

(to) get away with: to do something bad without consequence Not paying any taxes is like getting away with murder.

(to) get back to: to return to do something I should get back to work. We have been here at lunch for too long!

(to) get back at: to get revenge, act against a person who did one wrong After they insulted his mother, all Harry could think about was how to get back at those mean girls.

(to) get behind: to fall behind or not complete something, especially a responsibility, on time The work flow is so steady that it is easy to get behind if you do not plan and discipline yourself.

(to) get by: to live without luxury or extra money In this difficult economy it is all many families can do to get by.

(to) get down: to lower oneself from a higher position, to dance or have fun Chris hurt himself when he was trying to get down off of the bucking bronco. This warehouse party is a great place to get down with my friends.

(to) get revenge: like “to get back at”

(to) get shot (at): to be shot at Help me, I got shot! The last thing I expected walking through those woods was to get shot at.

(to) get through (to): to reach someone by telephone, to help someone understand something I finally got through when the cell phone signal got stronger. I’ve tried to get through to her for years so she can understand how she is messing up her life.

(to) get to: to be able or have the opportunity to do something, possibly in the future The children were so excited for the chance to get to go to the zoo. Emma will write a thank-you note as soon as she is able to get to it.

(to) get under s/th: to put oneself below something It sure was a good idea to get under the tree, because it kept them from getting rained on.

(to) get to: to be able to do, to arrive at The kids got to go to the zoo during the weekend. When the ambulance got to the crime scene, the driver was already dead.

(to) get wasted: to get drunk

## Advanced

(to) get across s/th: to reach the other side, to communicate an idea The dead hoped to get across the River Styx in the phantom boat. The dentist hoped to get across to the students the importance of brushing their teeth.

(to) get ahead: to advance, often materially Billy was working two jobs trying to get ahead and save some money for his family.

(to) get ahead of oneself: to think or act too quickly or without thinking Now, you are starting to get ahead of yourself son, you should make a good business plan before you start sending flyers around town advertising your idea.

(to) get at (s/th): to say, often directly What are you getting at, that I am not doing enough valuable work here?

(to) get down to s/th: to eliminate the outer parts of something, to arrive at the important part of a discussion or activity We were getting down to our last bits of food when the rescue team finally arrived. Gentlemen, let’s leave the small talk to the side and get down to the business that we came for.

(to) get into s/th: to become interested in something, or to get in Grandma Moses began to get into art when she was well into her eighties.
    
    
    (to) get it together: to organize or discipline one’s affairs
    

If that guy doesn’t get it together, he is going to have some serious problems to deal with.

(to) get out of s/th: to stop a continuing action such as a social activity or business, leave a place It was time to get out of the business when the customers all switched to the new product. Get out of here, you are driving me crazy!

(to) get over s/th: to recover from It may take Marge years to get over her divorce from Frank.

(to) get up to s/th: to reach an age, milestone or distant place The team finally got up to its goal of selling one million products.

(to) get with s/th, get “with it”: to come to understand current customs or way of thinking Come on man, get with the times, you should be wearing newer, more stylish clothes. Son, it is time for you to get with the program or you are going to get the boot.

  


# Turn

turn in, turn on, turn out, turn over, turn off

  


# Up

to bang up – maltratar (equipo); hacer algo muy bien  
Be careful not to bang up my bike too much please.  
Great work, that was a real bang-up job!  


to beat up – pegar, dar una paliza  
The New Cork cops beat up more than one innocent person.

to bottle up – no dejar salir a las emociones  
People who bottle up their feelings can develop emotional problems later on.

to box up – poner en cajas

to bring up – mencionar, traer hasta arriba

to brush up – repasar

to call up – llamar por telephono (esp. después de tiempo);

to chop up – cortar en pedazos

to clean up – limpiar

to come up with – imaginar

to crop up – aparecer de repente

to cross up – condundirse entre varias cosas

to dance up a storm – bailar mucho o con gusto

to dig up – encontrar, sacar desde el pasado

to do up – preparer

to draw up – preparer (planos)

to dream up – imaginar

to drink up – tomar

to eat up – comer, comerse to do

to feel up to – tener ganas o fuerzas para hacer algo

to flare up – empeorar de repente, llenarse de llamas

to fold up – doblar

to freeze up – congelar (maquinas); quedarse callado por miedo

to freshen up –

to hang up – colgar (ropa, el teléfono)

to hold up – detener, robar

to hook up – hacer conección

to keep up – hacer siguimiento;

to kick up – generar (usu. problemas)

to kiss up – hacer halagos inmerecidos

to laugh it up – reírse de algo

to light up – encender

to lighten up – tomar una actitud más positiva

to line up – poner en fila

to link up – hacer liga entre

to liven up – hacer más divertido

to loosen up – relajarse

to mess up – equivocarse

to own up – confesar

to pack up – preparar equipaje

to pile up – amontonar

to polish up – poner brillo

to pull up – llegar (en coche)

to roll up – enroller

to run up – gastar (una cuenta)

to screw up – confundir, hacer problemas con algo

to shoot up – injector (esp. drogas illegales)

to show up – aparecer

to snuggle up – acercarse cariñosamente

to speed up – accelerarse

to split up – divider; terminar (con novio/a)

to stir up – mezclar, causar (problemas)

to sum up – sumar

to talk up – hablar de las virtudes de

to think up – imaginar

to tighten up – apretar

to turn up – subir (volumen); aparecer

to wash up – lavarse

  


# Slang

No content here yet. Please look at this [slang and idioms link](http://www.speak-read-write.com/idiom.html) while we get started on this page. empty

A Ambulance chaser: An unskilled and unethical lawyer. B Ball park: A baseball term: To estimate how close something is to an accurate number. If something is in the ball park it is close enough to be acceptable. Basement Betty: A woman that runs a business from her home. Belt tightening: To reduce expenses. To save money. Bite the bullet: To make a difficult decision. (a) Bitter pill to swallow: To receive bad news. To hear something you don’t want to hear. Bottom line: The truth behind what is being said. Being honest even if other people do not want to hear it. Brownie points: Receiving credit for a good deed or giving a compliment. C Cash cow: A product or service that creates a lot of money without much investment. (to) cash in: To make money from or to benefit from financial or social investment. (to) Climb the corporate ladder: To get promoted. To move upwards in the organization. Crunch time A short period of time when there is a lot of work to do and a lot of responsibility. D Didn’t go over well: When a plan or activity did not happen as planned and was not successful. (a) Dog eat dog world: A mean and tough world where people only help themselves. Dot your i’s and cross your t’s: Check your work. Pay attention to the details. Down to the wire: Working to the last minute. To finish just before the deadline. (to) Drum up business: To find new customers. (to) Face the music: To admit there is a problem. To prepare for disciplinary action. E Egg on the face: When something embarrassing happens to a person. When a person looks foolish. Elevator pitch: A very short speech that explains yourself or your product in less than ten seconds. F Fast track: To speed up a project. To give something a higher priority. Fly by the seat of your pants: To do something without any planning and just react to what is happening. G Glitch: A mistake or when something is not working correctly. This usually refers to a piece of technology. Golden parachute: When a high member of management is fired and is given a very generous severance package. Gut feeling An instinct or intuition that makes you expect how something will happen. H Hard sell: Pushing hard to sell a product or service that is usually difficult to sell. (to) Have a lot on your plate: To have a lot of work to do. To have a lot of responsibilities. Heads will roll: An expression that means people will be disciplined harshly for a mistake. This may mean people will be fired. I I hear you: I understand. J (to) Jump the gun: To start something too soon or to begin before everyone else. K (to) Keep your eye on the prize: To stay focused on the final results of a plan or project. (to) Keep it under wraps: To keep a secret. To not tell other people about something. (to) Kick the bucket: When something like a machine or a project is finished. It is used to suggest that something has died. L Lateralled: A lateral transfer. To move to a new position without moving up or down the organization’s ranking. People often take lateral transfers to learn new skills. Lemon: A product, usually a car, which has a problem and does not work properly. M N O Off the top of my head: To think up ideas without and planning time. On the tip of my tongue: When you know a word but can’t remember how to say it Out in left field: A baseball term. To not understand what is happening. To not pay attention. Out of the loop: To not understand what is happening because a person is not involved in the proper communications. P Page: To call someone over the phone system in the office. (to) pass the buck: To blame someone else for a problem or mistake. Playing ball: A baseball term: Cooperating with clients and associates. Working together to complete a task. Playing hardball: A baseball term. To get mean and tough. (to) Plug (a product): To talk positively about a product socially (to) Pull the plug: To stop or kill a project. (to) Pull your weight: To do your share of the work. (at a) Premium: To buy or sell something at the best price. (to) Push the envelope: To move faster, work harder and do better than expected. Q R (to) Rally the troops: To motivate the people around you. To energize people for a better performance. Reality check: To think about how something will really work or if it will not work at all. Right off the bat: A baseball term. To start something immediately. Right on target: When a plan or activity happens perfectly. S (to) Scale back: To reduce the number of something. This could be the number of hours worked, the number of employees, the amount of money paid in salaries, etc. (to)Shake on it: Making a promise with a handshake. Show him/her the door: To get rid of someone. To fire a person. Slam Dunk: A basketball term: When something is perfect. (the) Squeaky wheel gets the grease: Bringing attention to a problem so people will work to fix it. Stay on your toes: Be careful. Be ready for trouble. (to) Step up to the plate: A baseball term. This term is now often shortened so people will say ‘to step up.’ It means to take on a challenge, to do your best or to volunteer. T Temp: A temporary worker. Someone that is hired by a staffing agency for a short time. Through the roof: Numbers are higher than expected. U Use some elbow grease: To work hard to get something done. V

W (to) wear many hats: To have different jobs and responsibilities in one or more organization. (to) Wing it: To explain something without any planning. This could be giving a speech or explaining an idea. (the) Whole nine yards: A football term: To ‘go the whole distance.’ To see a project through from start to end. (to) work out the kinks: To solve the problems. To make sure something works properly. X Y Yes man: An employee that always agrees with the boss. Z

  


# English Proverbs

A fool and his money are soon parted. - Franklin

The early bird gets the worm. - Franklin

Waste not, want not. - American proverb

Rome was not built in a day. - American proverb

Necessity is the mother of invention. - American proverb

If you want something done right, you have to do it yourself. - American saying

Early to bed, early to rise, makes a man healthy, wealthy and wise. - Benjamin Franklin, an American writing in Poor Richard's Almanac

Cheaters never prosper. - American proverb

It's not whether you win or lose, but how you play the game. - American proverb

Nice guys finish last. - American proverb

When in Rome, do as the Romans do. - American proverb

It's Greek to me. - Shakespeare

There's a sucker born every minute. - P.T. Barnum, American

  


# Activities and Dynamics

## Games

Tip: A good goal for games is that the game in itself is fun enough to play even if you are not trying to practice a language.

### Guess the person

Have each student write the names of about eight famous people on slips of paper, fold up the slips and collect them in one pile. Form teams of at least two people. One person takes a slip of paper and tries to get his team to guess the name written there without saying the name or its spelling. Each team should have about one minute per round. For every name that the team guesses correctly, it receives one point (they can keep the slip of paper to count). At the end of the time, the team that guessed the most names correctly, wins.

  


# Areas of English Proficiency

  1. **Vocabulary**: Passive and active vocabulary. Passive vocabulary is words that you understand. Active vocabulary is words that you use.
  2. **Fluency**: How fast you find words when speaking.
  3. **Natural speaking patterns**: Choosing the right word and the right word order.
  4. **Written English**: Formal grammar and spelling.
  5. **Pronunciation**: Speaking with the correct consonant and vowel sounds, and stressed syllables.
  6. **Flow of speech**: How fast to speak, when your voice should raise or lower in pitch or in volume, where to pause and for how long.
  7. **Culture**: Understanding and reacting appropriately to situations and expectations of English-speaking cultures.

Another way to divide the areas of language is the following:

  1. **Listening** (receiving oral messages)
  2. **Speaking** (giving oral messages)
  3. **Reading** (receiving written messages)
  4. **Writing** (giving written messages)

  


# Making a Personal Plan to Improve Your English

Your personal plan should be made up of two parts: 1. Where to go, and 2. How to get there.

## Where to go

### SMART Goals

When we set out to do something, it is to our benefit to set clear goals and to make a plan that will help us reach them. The “SMART” acronym below is a tool that we can use to make sure that we are covering all of the appropriate areas in the process. More information can be found in the [time management on Wikipedia](//en.wikipedia.org/wiki/Time_management). Just remember that if you don’t make your goals specific, measurable, achievable, results-oriented, and time-limited, they are not really goals, but intentions, no more.

    S Specific
    M Measurable
    A Achievable
    R Results-oriented
    T Time-limited

An example:

    Specific I want to improve my natural speech patterns, active vocabulary, fluency, and correct written form.
    Measurable Improve my TOEFL score by 10 percent. (Use on-line or offline testing tools to determine beginning numbers, then set a goal for improvement.)
    Achievable (The improvement in the measured numbers to be within reason.)
    Results-oriented I want practical, real-world improvement in my levels of oral and written English.
    Time-limited The follow-up testing will be done two months after the first testing.

Now, using the above example as a guide, write out your own SMART goals for improving your English. Decide which [areas of English proficiency](/wiki/Business_English/Areas_of_English_Proficiency) will be your priorities. Write down **how much you would like to improve in each of the areas.**

## How to get there (personalizing your plan)

Following are specific steps that you can take to improve each of your targeted [areas of English proficiency](/wiki/Business_English/Areas_of_English_Proficiency).

### Vocabulary (passive and active vocab)

  * Daily reading (news and online articles, books, NYTimes, HBR, Give and Take, Wikipedia.org, The Millionaire Next Door …)
  * Writing summaries of articles and mini research papers

### Fluency (finding words quickly)

  * Conversation with others
  * Your internal mental conversation
  * Reading (news, business literature, novels, magazines, blogs …)
  * Writing
  * Presentations (make up your own or imitate someone else’s)

4113321

### Natural speech patterns

  * Reading regularly in English. Daily is a good goal, even if it is only fifteen minutes. Look for topics on interest on the Internet or in English books or magazines.
  * Conversation and contact in English with native speakers, or at least with others who are learning.
  * Watching TV and movies in English (news, entertainment, documentaries…)
  * Online audio news (NYTimes, VOANews, BBC News …)
  * Presentations of speeches copied from native presenters
  * Listening to and reading CD magazines like English2Go and Speak Up for natural flow and inflection

### Written English (grammar and spelling)

  * Grammar book exercises
  * Reading
  * Writing
  * test

### Pronunciation

  * Conversation
  * TV, music and movies
  * Listening to and reading passages at the same time
  * In general, all oral communication: listening and speaking

### Flow of speech

  * Conversation
  * TV, music and movies
  * Listening to and reading passages at the same time
  * In general, all oral communication: listening and speaking
  * Reading newspapers in front of mirror.

### Culture

  * Reading about culture explicitly in Internet, books, and magazines
  * Observing culture implicit in written materials
  * Entertainment from target countries
  * Interacting with natives

Focus your attention on the activities that will help you improve primarily in the top areas on your personalized list. This takes a bit of discipline, but allow your actions to be guided by where you want to go in your learning. Don’t spend all of your time reading articles about current news if your main objective is to improve your pronunciation.

  


# Getting More Practice

If you live in the United States, the UK, Canada, Australia or another English-speaking country it is easy for you to practice all of the time watching TV, going to the store, making new friends. If you do not live in an English-speaking area, it may be harder to get practice.

Several magazines are published internationally and will help you practice your reading and listening skills.

    [English2Go](http://www.rdenglish.com/), published by Reader's Digest
    [Speak Up](http://www.speakup.com.br/), published in Brazil and in [Italy](http://www.speakuponline.it/).
    [Hot English](http://www.hotenglishmagazine.com/), this one is OK too

You can also try listening to podcasts - free MP3 lessons you can download to you computer or MP3 player:

[Business English Pod](http://www.businessenglishpod.com) \- Business English lessons by podcast for intermediate and advanced learners featuring useful phrases and vocabulary. Listening quizzes, transcripts and online exercises available for extra practice.

  


# Tips for Teachers

## Link

  * [http://www.google.com/search?hl=en&q=most+common+english+words&meta=](http://www.google.com/search?hl=en&q=most+common+english+words&meta=) Lists of Common Vocabulary

  


# Course Outlines

These are sample class plans originally developed for a Business English converstion class in Mexico City, Mexico.

## Class 1

    Introduction of the teacher and the class
    Personal chatting

## Class 2

    Discussion of course policies
    Students present selves to teacher
    Students explain company-related activities to teacher
    French systems and soil treatment
    “Being (held) accountable for something”
    Discussion of book

## Class 3

    Topic for discussion: the company; what makes it different, market challenges, biggest future opportunities.
    Student experiences with international (English-speaking) clients and any travels into English-speaking parts of the world.
    Student motivations for speaking English, related to and besides current work-related issues.
    Answer any specific language or culture questions.
    Assigned homework: Module 1, Business Grammar Book. Due on .

## Class 4

    Discuss grammar homework.
    First student presentation (?)
    Students bring technical documents related to their work. These can be from professional magazines, Internet or books, but should be in English.
    Discuss significance of the documents, any practical application to current work, any difficult words, phrases or contstructions.
    Discuss handout on business idioms.
    Answer any specific language or culture questions.
    Assigned homework: Module 2, Business Grammar Book. Due on .

## Class 5

    Discuss grammar homework.
    Student presentation, followed by questions and answers by the class.
    Discuss Christmas/holiday plans and traditions in Mexico and US, in individual families, holiday food and/or recipies.
    Students bring articles about international trade.
    Answer any specific language or culture questions.
    Assigned homework: Module 3, Business Grammar Book. Due on .

## Class 6

    Discuss grammar homework.
    Student presentation, followed by questions and answers by the class.
    Students bring articles about finance.
    Answer any specific language or culture questions.
    Assigned homework: Module 4, Business Grammar Book. Due on .

## Class 7

    Discuss grammar homework.
    Student presentation, followed by questions and answers by the class.
    Students bring articles about business and organizational management.
    Discuss unfulfilled dreams.
    Answer any specific language or culture questions.
    Oral exams.
    Assigned homework: Module 5, Business Grammar Book. Due on .

## Class 8

    Discuss grammar homework.
    Student presentation, followed by questions and answers by the class.
    Students bring articles about technology.
    Discuss, “What is the best advice that someone can give another person”.
    New year´s resolutions.
    Answer any specific language or culture questions.
    Oral exams for those who did not take it on .
    Assigned homework: Module 6, Business Grammar Book. Due on .

## Class 9

    Students bring articles about sports and sports heroes.
    Telephoning excercize.
    Student presentation by ______________________, followed by questions and answers by the class.
    Discuss grammar homework, Module 4, Business Grammar Book.
    Assigned homework: Module 5, Business Grammar Book.
    Answer any student questions about language, grammar, culture, etc.

## Class 10

    Students bring articles about hobbies.
    Students bring any reports and proposals that they have written in English.
    Discuss, “Basic business letter formats”.
    Student presentation by ______________________, followed by questions and answers by the class.
    Discuss grammar homework, Module 5, Business Grammar Book.
    Assigned homework: Module 6, Business Grammar Book.
    Answer any student questions about language, grammar, culture, etc.

## Class 11

    Students bring articles about culture and society.
    Discuss general values and customs in US and abroad (cultures working with the company).
    Student presentation by ______________________, followed by questions and answers by the class.
    Discuss grammar homework, Module 6, Business Grammar Book.
    Assigned homework: Module 7, Business Grammar Book.
    Answer any student questions about language, grammar, culture, etc.

## Class 12

    Students bring articles about business etiquette.
    Discuss taboos in the US and other cultures doing business with the company.
    Student presentation by ______________________, followed by questions and answers by the class.
    Discuss grammar homework, Module 7, Business Grammar Book.
    Assigned homework: Module 8, Business Grammar Book.
    Answer any student questions about language, grammar, culture, etc.

## Class 13

    Students bring articles about English and English learning.
    Review English résumés, students bring own résumés.
    Oral exams.
    Discuss grammar homework, Module 8, Business Grammar Book.
    No grammar homework assigned.
    Answer any student questions about language, grammar, culture, etc.

## Class 14

    Students bring articles about branding.
    Discuss, “What is the best advice that someone can give another person”.
    Oral exams for those who did not take it on .
    Discuss grammar homework, Module 9, Business Grammar Book.
    No grammar homework assigned.
    Teacher/class feedback form.

The class will include surprise topics along the way as well, and the teacher is willing to be flexible and include specially suggested topics and/or deviate from the official class plans as the students request.

## Note

You can search for great articles at the following websites: nytimes.com, economist.com, wikipedia.org, news.google.com, etc.

  


# Links

Web resources on business English:

  * [Arlyn Freed's ESL/EFL English for Specific Purposes (ESP)](http://www.eslhome.com/esl/esp/#BE) \- Business English links
  * Language tools for learners - Dictionary, Idioms, and Phrasal Verbs search
  * [English dictionary, translator and Idioms search](http://www.tjtaylor.net/reference2.htm)
  * [ESL Business News](http://www.eslbusinessnews.com) \- a weekly podcast of international business news read in slow, clear English. Listen to the podcast and follow along in the accompanying script.
  * [Business English Exercises: Michael's ESP-EFL British Civilisation Home Page](http://www.lapasserelle.com/lm)
  * [Free Business English Exercises](http://www.businessenglishsite.com) \- A collection of exercises arranged by topic.
  * [Free Business English Podcast Lessons](http://www.businessenglishpod.com) \- Business English lessons by podcast for intermediate and advanced learners featuring useful phrases and vocabulary. Transcripts and online exercises available.
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Business_English/Print_version&oldid=1438745](http://en.wikibooks.org/w/index.php?title=Business_English/Print_version&oldid=1438745)" 

[Category](/wiki/Special:Categories): 

  * [Business English](/wiki/Category:Business_English)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Business+English%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Business+English%2FPrint+version)

### Namespaces

  * [Book](/wiki/Business_English/Print_version)
  * [Discussion](/wiki/Talk:Business_English/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Business_English/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Business_English/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Business_English/Print_version&action=edit)
  * [View history](/w/index.php?title=Business_English/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Business_English/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Business_English/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Business_English/Print_version&oldid=1438745)
  * [Page information](/w/index.php?title=Business_English/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Business_English%2FPrint_version&id=1438745)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Business+English%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Business+English%2FPrint+version&oldid=1438745&writer=rl)
  * [Printable version](/w/index.php?title=Business_English/Print_version&printable=yes)

  * This page was last modified on 9 March 2009, at 08:48.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Business_English/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
