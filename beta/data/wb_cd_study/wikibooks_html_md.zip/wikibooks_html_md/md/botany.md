# Botany/Print version

From Wikibooks, open books for an open world

< [Botany](/wiki/Botany)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Botany](/wiki/Botany)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Botany/Print_version&action=purge&printable=yes) this page.

  
_Note: current version of this book can be found at <http://en.wikibooks.org/wiki/Botany>_

# Table of contents

Introduction

* * *

# Introduction

<< [Contents Page](/wiki/Botany)

* * *

## Introduction to the Botany Study Guide

This _Study Guide to the Science of Botany_ is a textbook at _**Wikibooks**_ shelved at the [Wikibooks:biology bookshelf](/wiki/Wikibooks:Biology_bookshelf) and intended to establish a course of study in the subject of Botany, utilizing articles provided in _**[Wikipedia](http://www.Wikipedia.org/)**_, with links to other relevant web sites and other Wikibooks as appropriate. In some cases, portions of the text from _Wikipedia_ articles have been used to materially develop introductory text within the Guide.

For the new user, it need be pointed out that _Wikipedia_ differs from a standard encyclopedia in two important respects: 1) it is a **hypertext** document, and 2) it is open and editable, and therefore **constantly changing**. For the student following this or any guide through _Wikipedia_ to cover a specific subject, it is recommended that each article (page) be read first in its entirety, before any hyperlinks are followed to other topics or explanations. It is too easy, otherwise, to simply become lost in a maze of links, and miss the main thrust of an article presented as an assignment from the Guide. Because _Wikipedia_ is constantly changing (and, it is believed, improving) the quality of each article encountered will be variable. Some articles are well written and go to adequate depth, whereas others, lacking a proponent, are shallow and incomplete. Short or sloppy looking articles may contain questionable facts. These short-comings should diminish with time, but can be a problem for the student.

One clear advantage to using this Guide linked to a hypertext like _Wikipedia_ is the "circular redundancy with serendipity" factor that arises when an article is read and its hyperlinks followed; this factor can be a powerful learning tool. The persistent reader is subjected to a fairly high degree of repetitive reading, often presenting slightly differing perspectives on the same general topic, with the result that learning comes from redundancy and seeing difficult concepts presented in more than one way. At the same time, some hyperlinks lead down less relevant paths, bringing new and unanticipated knowledge. If, as a student, you are truly interested in mastering the subject of botany, you must be prepared to read beyond the basic assignments; in some cases, beyond Wikipedia to explore other, "outside" web sites.

It seems likely that the typical user of the _Study Guide to the Science of Botany_ is not necessarily an active student taking a course in botany at the high school (AP) or college level, but a person with a strong interest in plants—an amateur naturalist or a gardener. Therefore the guide must incorporate both the basic biological and physiological aspects of plants as well as extensive taxonomy-based coverage of the diversity of plants and related organisms. The amount of material now available on the web covering the latter subject is becoming nothing short of phenomenal. In effect, one now has access to much of the world's plant diversity, with photographs and descriptions, in many cases from web sites maintained by specialists. One goal of the guide is to provide a systematics-based approach to capturing this kind of information, hopefully giving the student a strong background in plant systematics. The importance of this approach is not that everyone should become a taxonomist—or become more familiar with plant taxonomy, a specialized field of botanical science with a relatively narrow following—but that appreciation for (and understanding of) species diversity is most critical at this time in our earth's history marked by accelerated species extinctions and destruction of native ecosystems by both human population expansion and man-induced spread of non-native species.

The _Study Guide to the Science of Botany_ includes two other "parallel" documents intended to enhance the usefulness of the Guide. These could also be used separately or independently as source documents for a beginning course in Botany. They are the _Discussion_ pages and the _Laboratory Exercise_ pages. Both are explained in detail in the next Section titled _[How to use this Guide](/wiki/Botany/How_to_use)_.

# How to use

<< [Contents Page](/wiki/Botany)

* * *

How to Use the _Botany Study Guide_

The purpose of the _Study Guide to the Science of Botany_ is to weave - out of the information on Life Science and especially Botany contained in _Wikipedia_ \- a course of study for the student or layman. It is anticipated that this course will be either supplemental to instruction being received at a school or college, or will be self-directed. In either case, the Guide is not a novel and should not be approached as one. A smooth flow of dialogue is simply not possible and should not be anticipated. The Guide may be closer to the sometimes disjointed notes generated by a student from a lecture or careful reading of a detailed textbook.

Within each subsection of a Chapter, introductory text is followed by one or more "reading assignments" of the form:

  * Read [Botany](//en.wikipedia.org/wiki/en:Botany) (Links need not be pursued at this time)

Following (that is _clicking_ on) the link (to _Wikipedia_ "Botany" in this case) will open an article intended to provide the details of the Chapter subsection. Recommended articles should be read from top to bottom, and then re-read following some or all of the links embedded in the article to other articles for expanded elucidation or to clarify terms; that is, in most cases, completion of an "assignment" (recommended article) includes at least some or all articles linked to the first. Obviously, it cannot be the case that all links are followed to articles, whose links are then followed to articles, and so on until no new material is encountered. It is likely there would be no quick end to such a pursuit. The amount of time spent wandering beyond the original article is partly a personal matter of how much the reader is getting out of the foray than anything else. Realize it is certainly possible to wander well off the subject at hand. As in the example above, notes are provided with assignments giving some direction for pursuing links. An instruction NOT to follow links simply means the additional material will be encountered later in the course of instruction, and going beyond the assigned article may provide too much detail for a beginning student. The following example:

  * Read [Science](//en.wikipedia.org/wiki/en:Science) (The following links are included:) 
    * [Scientific Method](//en.wikipedia.org/wiki/en:Scientific_method)
    * [Philosophy of Science](//en.wikipedia.org/wiki/en:Philosophy_of_science)

specifies that two other links ARE part of the assignment. Other links encountered may be followed to expand your knowledge or, as always, to aid in understanding of technical terms encountered. Hyperlinks included with the text in the Guide are there simply for convenience, usually to topics somewhat peripheral to the main one. In all cases, finding your way back to the Guide may become tricky, but we have to leave this up to you to establish, beyond pointing out that your browser's _Back_ button is intended for this purpose.

## Discussion Questions

At the end of each subsection are posted one to several questions. In general, you will get more out of these questions if you write out your answer on a piece of paper. You may wish to accomplish this on the re-read, allowing each question to guide your quest for an answer. A discussion page for each chapter provides answers to the questions posed. However, the questions are intended to be thought-provoking, and may not have a single straight-forward answer. Answers on the discussion pages are also necessarily much longer than would be expected of any one student; it is expected that each student answer will fit somewhere within the broad discussion presented.

## Laboratory Exercises

A natural sciences course laboratory unit is supposed to provide hands-on experience in exploring topics raised in the text and lecture units. The best that a website can give towards this goal is a manual that is liberally provided with pictures and diagrams. The student must provide the "hands on" from the neighboring natural world. Fortunately, in botany, this is much easier to accomplish than in almost any other field of science. Both the outdoors, the local market, and (if available) a botanical garden can be sources of materials for study. Indeed, we may teach the structure of a _pome_ using an apple in the hope that the student will end up with a pear.

In using any of the Laboratory Exercises, it is always best to read through the entire module before actually doing anything. Resist the temptation to view the material as an instruction manual to be followed in a specific order. For one thing it is difficult to write a module that covers, at each step, all that the student should know before proceeding on to the next step. The value of any exercise will be significantly enhanced if you have a pretty good idea where it is going in advance.

## General Navigation

The _Study Guide_ is divided into Sections and Chapters which define the subject material of each module. At the bottom of each text page (main text of a module), is a short version of the Table of Contents, allowing the reader to jump between chapters within a Section. Here is an example of the "Wiki Contents Table" for Section I:

**_Botany Study Guide_ ~ Wiki Contents Table**  
Section I

[Chapter 1 - Introduction](/wiki/Botany/Introduction_Botany) ~ [Chapter 2 - Plant cells](/wiki/Botany/Plant_cells)  
[Chapter 3 - Plant Tissues](/wiki/Botany/Plant_tissues) ~ [Chapter 4 - Plant Organs](/wiki/Botany/Plant_structure)  
[Chapter 5 - Plant Reproduction](/wiki/Botany/Plant_reproduction) ~ [Chapter 6 - Plant Morphology](/wiki/Botany/Plant_morphology)

Note that at the beginning of each module, links are provided to both the previous chapter and the succeeding chapter, as well as to the main Table of Contents. Links to units associated with a module, as for example to a Laboratory Exercise, appear near the end of the module

## Final Note

As [a final note](/wiki/Botany/A_final_note_about_the_Guide), read the next Section and consider how you might make a contribution to the Guide.[Botany](/wiki/Botany)

* * *

Both this Guide and all articles in _Wikipedia_ are [free content](//en.wikipedia.org/wiki/en:free_content) that can be added to or edited by anyone. It is an opportunity for the user of these documents to contribute information, or even state given information more clearly, simply by editing a page. As a student with a textbook and a lecturer (teacher), you may find yourself in possession of useful facts, another point of view on existing facts, or a report you prepared of exceptional quality. Any of these can be added to an appropriate page in this Guide or the _Wikipedia_. However, this caution is strongly advised: _Do not place into the Guide any text or pictures taken verbatim (or close to verbatim) from a text book, web site, or other copyrighted source without permission of the copyright holder_. In general, this means, anything you submit should be your own work.

**To learn how to edit or contribute material to this textbook, first read the introduction at:** _[How to Edit](//en.wikipedia.org/wiki/en:Wikipedia:introduction)_.

<< [Contents Page](/wiki/Botany#Detailed_contents) | Chapter 1 | [Chapter 2](/wiki/Botany/Plant_cells) >>|

* * *

Chapter 1. Introduction to Botany

* * *

## Botany as a Science

**Botany** is the branch of **biology** concerned with the scientific study of plants. Traditionally, botanists studied all organisms that were not generally regarded as animal. However, advances in our knowledge about the myriad forms of life, especially microbes (viruses and bacteria), have led to spinning off from Botany the specialized field called **Microbiology**. Still, the microbes are usually covered in introductory Botany courses, although their status as neither animal nor plant is firmly established.

  
Plants are living entities, and material presented within _Biology_ will have relevance here, most particularly at the cellular and subcellular levels of organization (Chapter 2). Both plants and animals deal with the same problems of maintaining life on planet Earth — their approaches seem quite different, but the end result is the same: continued existence in an organized state, as part of a universe whose tendency is towards greater disorganization. Back on Earth, however, it is a fact that microbes, plants, and animals comprise a very interdependent system. We divide them apart, because our minds work best that way. We categorize and learn common features or properties of the categories. This approach is neither right nor wrong, but is clearly efficient for our minds. Nonetheless, it is desirable to regularly step back and realize that the boundaries between categories are often just constructs, and exceptions to our categories usually abound.

It was alluded to in the opening definition that Botany is a **science**. Just what makes Botany, or anything else a science? It is important to acquire a grasp of the fundamentals of science itself to fully appreciate both how botanical knowledge was gained as well as how it can be used. It is usually quickly disinteresting to acquire facts simply for the sake of knowing. Humans do not just appreciate mountains _because they are there_, they climb them because they are there!

## Living Systems

Biology is defined as the study of life, and Botany is that discipline within Biology concerned with the study of living organisms called **plants** and with certain other living things that are not plants (but are not animals either).

### Defining 'Plant'

Like many words in common usage that apply to biological entities or concepts, the term _**plant**_ is more difficult to define than might be at first obvious. Although botanists describe a **Kingdom Plantae**, the boundaries defining members of Plantae are more inclusive than our common concept of a "plant". We are tempted to regard _plant_ as meaning a multicellular, eukaryotic organism that generally does not have sensory organs or voluntary motion and has, when complete, a root, stem, and leaves. However, botanically only vascular plants have a root, stem, and leaves, and even some vascular plants, such as certain carnivorous plants and duckweed, fall afoul of that definition. But to be fair, the vascular plants are the plants we tend to encounter every day and that most people would readily regard as "plants".

A more significant point of departure between Plantae and plants occurs among the seaweeds. Technically, only a relatively minor group of seaweeds (the chlorophytes or green algae) are members of the Kingdom Plantae. The majority of seaweeds, like the kelps (very large brown algae from the Order Laminariales), despite a superficial appearance of such, lack true stems, leaves, roots, and any kind of vascular systems as found in higher plants. Thus, the kelps are not Plantae; but are they plants? Certainly if we regard the green algae as plants, it is difficult to exclude the more prominent red and brown algae of our coastal waters.

Another, much broader definition for _plant_ is that it refers to any organism that is _**photoautotrophic**_—produces its own food from raw inorganic materials and sunlight. This is not an unreasonable definition, and is one that focuses on the role plants typically play in an ecosystem. However, there are photoautotrophs among the **Prokaryotes**, specifically photoautotrophic bacteria and cyanophytes. The latter are sometimes called (for good reasons) blue-green algae. Then there arises the problem that many people would consider that a mushroom is a plant; a mushroom is the fruiting body of a fungus (Kingdom Fungi) and not _photoautotrophic_ at all, but _saprophytic_. However, there are more than a few species of flowering plants, fungi, and bacteria that are not autotrophic, but _parasitic_.

We cannot hope to offer a firm answer. The list of characteristics that separate the Plantae from the other biological kingdoms provides at least a technical definition, but realize it is only a technical definition. The problem this lack of precision or agreement in the definition of "plant" presents is one of understanding statements, often encountered in _Wikipedia_ (and other) articles, of the sort: _...xylem is one of the two transport tissues of plants_. In general it cannot be assumed this means all plants, algae through flowering plants. It very probably does not include fungi or bacteria. Indeed, it is usually safest to assume the discussion is about vascular plants (essentially the ferns, conifers, flowering plants, and a few others; see discussion below on "General Terminology") unless stated differently (e.g., _...in vascular and non-vascular plants this is_ such and such).

### Plants as Organisms

The distinction between life and non-life is not as easily made as you might think. There exist intracellular "parasites" that are progressively less alive in terms of being metabolically active:

## Plants and their Uses

There can be no disputing the fundamental significance of plants to the ecology of our planet. Photosynthetic plants utilize energy arriving from the sun to create complex organic molecules from inorganic substances, and by this process contribute oxygen to the atmosphere. Advanced animal life is very much dependent upon this source of oxygen, as well as the organic molecules that form the basis of nearly every food web on the planet. However, humans utilize plants in many ways, especially as sources of pleasure, food, and material for shelter, clothing, and more. Consider here the role plants play in our everyday lives and in our economy.

## Introduction to Plant Classification

At the beginning of this chapter it was suggested that each of us categorizes information we encounter on a daily basis. Our minds seem to want to find relationships between facts and observations, to erect mental bins in which to place new items with previous "facts". This natural human process is the basis for prejudice, in as much as "facts" categorized together can become strongly associated. But these are personal constructs. In order for scientists of many races, speaking many languages, and coming from all manner of backgrounds and experiences to work productively together to solve common problems, the objects with which they work must be classified within a universally accepted framework.

The classification of living things is called **systematics**, or **taxonomy**, and ideally should reflect the evolutionary history (phylogeny) of the different organisms.

Taxonomy arranges organisms in groups called **taxa**, while systematics seeks clues to their relationships. The dominant system of _Scientific Classification_ is called **Linnaean taxonomy**, and includes classification ranks as well as an organism naming convention called **binomial nomenclature**.

Traditionally, all living things were divided into five kingdoms:

    [Monera](//en.wikipedia.org/wiki/en:Monera) — [Protista](//en.wikipedia.org/wiki/En:Protist) — [Fungi](//en.wikipedia.org/wiki/en:Fungi) — [Plantae](//en.wikipedia.org/wiki/En:Plantae) — [Animalia](//en.wikipedia.org/wiki/en:Animal)

However, this five-kingdom system has been replaced by Carl Woese's three-domain system, which focuses on phylogenic roots and comparison of DNA structures. The older approach utilized visual observation as the basis of classification. The three domains reflect whether cells have nuclei (**eukaryotic**) or not (**prokaryotic**), as well as differences in cell membranes and cell walls.

    [Archaea](//en.wikipedia.org/wiki/en:Archaea) — [Eubacteria](//en.wikipedia.org/wiki/en:Eubacteria) — [Eukaryota](//en.wikipedia.org/wiki/en:Eukaryota)

Recall (and review as necessary) how these groupings relate to the sequence of events in the evolutionary history of life as summarized in [Timeline of Evolution](//en.wikipedia.org/wiki/en:Timeline_of_evolution). You will return to the subject of Scientific Classification to consider in much more detail the groups of organisms studied in Botany, beginning with Chapter 7. First, however, we shall turn our attention to the structure and function of cells and eventually to gain an understanding of plant structure (_plant anatomy_) and function (_plant physiology_).

### General Terminology

In Section II of this text we will delve much deeper into "plant" systematics. But you should be aware of some general terms related to classificatory schemes that are used regularly in discussing plants. You have probably encountered these terms many times, although may not be aware of their exact definitions. For example, much of the material in Section I of this textbook is biased towards **flowering plants**. That is, much of the descriptive material here as well as at Wikipedia refers specifically to these. Flowering plants are angiosperms; plants that have flowers and produce seeds, and comprise the majority of the plants we would normally encounter in say a nursery if not on the street, field, or empty lot. **Seed-bearing plants** include both the angiosperms and the gymnosperms, the latter now treated as a modern group called **conifers**. The conifers are also common plants, especially in higher latitudes, but bear cones instead of flowers. Both conifers and flowering plants develop vascular tissues internally that conduct fluids (especially water) throughout the plant. Included in the **vascular plants** are ferns. Ferns have vascular tissue, but reproduce by spores. They do not produce seeds and do not bear flowers.

## See Also

  * _[Discussion](/wiki/Botany/Introduction_discussion) of this chapter_

<< [Contents Page](/wiki/Botany#Detailed_Contents) | << [Chapter 1](/wiki/Botany/Introduction_Botany) | Chapter 2 | [Chapter 3](/wiki/Botany/Plant_tissues) >>|

* * *

Chapter 2. Plant Cells

* * *

## Introduction

![](//upload.wikimedia.org/wikibooks/en/thumb/2/2b/Lupe.jpg/200px-Lupe.jpg)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

A loupe (left) and a hand-lens (right) - tools used by botanists in the field

A **cell** is a very basic structure of all living systems, consisting of **protoplasm** within a containing **cell membrane**. Only entities such as viruses—literally on the boundary between non-living chemicals and living systems—lack cells or basic cell structure. All plants, including very simple plants called _algae_, and all animals are made up of cells, and these are organized in various ways to create structure and function in an organism. Biologists recognize two basic types of cells: **prokaryotic** and **eukaryotic**. _Prokaryotic cells_ are structurally more simple. They are found only in single-celled and some simple, multicellular organisms (all bacteria and some algae, which all belong to Bacteria and Archaea domains). _Eukaryotic cells_ are found in most algae, all higher plants, fungi, and animals (Eukarya domain). Thus, differences between these two cell types are critical to how an organism is classified, and an important consideration in the evolutionary sequence of life on the planet Earth.

## Plant Cell Structure

Nearly all cells are too small to be seen with the unaided eye. As always there are some exceptions, but generally magnification is required to detect a cellular structure. In plants, a good hand-lens or loupe (see photo at right) will sometimes suffice, but in working with cells or observing how cells are organized to form tissues and structures, a high power **[microscope](//en.wikipedia.org/wiki/en:Microscope)** is used.

  * Read about [Cells](//en.wikipedia.org/wiki/en:Cell_\(biology\)) ~ You may wish to follow some or all links to "Main articles" as these provide detail that may interest you; or you might return to explore further should questions arise later in the course.
  * Read [Plant cells](//en.wikipedia.org/wiki/en:Plant_cell) and, at minimum, articles at the following links (but ignore, for now, the topic of _Plant Cell Types_):
    * [Cell Wall](//en.wikipedia.org/wiki/en:Cell_wall)
    * [Protoplasm and cytoplasm](//en.wikipedia.org/wiki/en:Protoplasm)
    * [Vacuole](//en.wikipedia.org/wiki/en:Vacuole)
    * [Ergastic substances](//en.wikipedia.org/wiki/en:Ergastic_substances)
    * [Plastids](//en.wikipedia.org/wiki/en:Plastid)
    * [Chloroplasts](//en.wikipedia.org/wiki/en:Chloroplast)

    Also note that the textbook, _[Cell Biology](/wiki/Cell_Biology)_, is available at _WikiBooks_ and can be used as a more detailed reference. You should read the [Introductory Chapter](/wiki/Cell_Biology/Introduction) (all subsections) at this time.

`Questions`:

  1. _Can you think of reasons why_ macroscopic _organisms are multicellular?_ (Macroscopic means large, in the sense of "not microscopic")

## Basic Cell Function

You should, by now, have a general appreciation for the complexity of cellular structure. Improvements in microscopy, especially development of the [Electron microscope](//en.wikipedia.org/wiki/en:Electron_microscope), have revealed that cells are not merely membranous sacks containing fluid of gel-like consistency. The degree of organization of the **cytoplasm** into **organelles** and their **membranes** should have you convinced that much (perhaps most) of what is really going on around you on this planet is occurring at a scale that is simply inaccessible to your eyes. And while you cannot be expected to directly observe chemical reactions at a molecular scale, contemplate that you cannot, even with powerful optics, directly observe most of the structure where these reactions are somehow controlled to produce outcomes favorable to life—indeed, are life. Hopefully, as you acquire knowledge and become a biologist—a botanist—you will learn to recognize the relevant phenomena by their macroscopic expressions (that which you can readily observe with the unaided eye).

To appreciate basic cell function, it is necessary to first list the processes or outcomes that cells must accomplish to further existence. More specialized functions will be discussed under plant cell structure, as our interest must eventually focus on plants. For now, recall that in your reading you have already encountered these several basic abilities of cells:

  * **Metabolism** involves taking in of raw material to use in building cell components and breaking down of other molecules to provide energy for various growth processes; byproducts may be released.
  * **Protein biosynthesis** by transcription of DNA to RNA and then translation to protein, used in growth or released for use elsewhere by the organism.
  * **Reproduction** by cell division.

Now explore each in turn. Think initially of a single-celled organism with no special abilities, only a "will" to stay alive and perpetuate itself. Remember, the environment will not be kind. The cell must grow and reproduce to counter the tendency of outside forces to breakdown molecular structure and destroy life. Then consider the situation where a cell is part of a multicellular organism, and may be performing more limited and specialized functions.

  * Read [Cell metabolism](//en.wikipedia.org/wiki/en:Cell_metabolism) (Follow links and read at least these articles): 
    * [Metabolic pathway](//en.wikipedia.org/wiki/en:Metabolic_pathway) (Links need not be followed)
    * [Cell respiration](//en.wikipedia.org/wiki/en:Cellular_respiration) (Follows all links)
  * Read [Protein biosynthesis](//en.wikipedia.org/wiki/en:Protein_biosynthesis) (Follow links as necessary to understand process and terminology; Also included is:) 
    * [Gene expression](//en.wikipedia.org/wiki/en:Gene_expression)
  * Read [Cell reproduction](//en.wikipedia.org/wiki/en:Cell_division) (The following links are included:) 
    * [Mitosis](//en.wikipedia.org/wiki/en:Mitosis)
    * [Cell cycle](//en.wikipedia.org/wiki/en:Cell_cycle)

`Questions`:

  1. _Have you been able to discern a relationship between genes and basic cell function? If so, is this also a basic cell function, and where do we list it?_

## Plant Cell Specializations

We will learn about the cells of algae and other organisms (e.g., bacteria and fungi) traditionally covered within Botany in later chapters on those organisms (Chapters 5 - 7). Here, we concentrate on the cells of plants.

The simplest type of plant cell is called a **parenchyma cell** and most of the basic metabolic and reproductive processes of the plant occur in these cells. A term for _parenchyma_ cells with chloroplasts, is **chlorenchyma cells**. Other plant cell types that we shall be considering are:

  * **Collenchyma** ~ living cells with thickened walls for increased support
  * **Sclerenchyma** ~ lignified dead cells forming fibers for increased support
  * **Epidermal** ~ surface covering
  * **Cork**
  * **Xylem tracheid** ~ single long (up to 1 mm) thin cells for transporting water and support
  * **Xylem vessel** ~ cells form individual elements in an even longer (up to 1 meter in extreme cases) tube for transporting water
  * **Meristematic cells** ~ growth
  * Read [Parenchyma cell](//en.wikipedia.org/wiki/en:Parenchyma)

* * *

[Laboratory Exercises](/wiki/Botany/Microscopy_laboratory) for Chapter 2 >>  
[Discussion of questions](/wiki/Botany/Plant_cells_discussion) for Chapter 2 >>>

* * *

**_Botany Study Guide_ ~ Wiki Contents Table**  
Section I

[Chapter 1 - Introduction](/wiki/Botany/Introduction_Botany) ~ [Chapter 2 - Plant cells](/wiki/Botany/Plant_cells)  
[Chapter 3 - Plant Tissues](/wiki/Botany/Plant_tissues) ~ [Chapter 4 - Plant Organs](/wiki/Botany/Plant_structure)  
[Chapter 5 - Plant Reproduction](/wiki/Botany/Plant_reproduction) ~ [Chapter 6 - Plant Morphology](/wiki/Botany/Plant_morphology)

<< [Contents Page](/wiki/Botany#Detailed_Contents) | << [Chapter 2](/wiki/Botany/Plant_cells) | Chapter 3 | [Chapter 4](/wiki/Botany/Plant_structure) >>|

* * *

Chapter 3. Plant Tissues

* * *

## Introduction

## Plant Tissues

Most plant cells are specialized to a greater or lesser degree, and arranged together in **tissues**. A plant tissue can be simple or complex depending upon whether it is composed of one or more than one type of cell. The simplest tissue found in plants is called **parenchyma**. The cells are not very specialized, more or less rounded or angular where packed together, and thin-walled. A type of parenchyma called **chlorenchyma** because the cells contain chloroplasts forms tissue (usually in the leaves) responsible for most of the photosynthesis occurring in the plant. Note that in simple tissues at least (tissues comprised mostly of one cell type), the tissue name follows from the cell type. However, tissues may also have unique anatomical names related to where in the plant they occur.

### Meristems

The growth of a plant requires a source of undifferentiated cells located in places where growth is needed and can be initiated to further the body plan (in comparison to animals, plants are rather open in this regard). Some enlargement in size is always possible by elongation or enlargement of existing cells, or by existing cells simply dividing. But differentiation of one cell type into another is only possible if the initial cell (mother cell) is not very specialized. Tissues comprised of cells that remain undifferentiated and supply, by their divisions, cells to form new tissues and organs, are called **meristems**. Meristem tissue occurs in places that allow for a very orderly pattern of growth.

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
Mine or import and merge [Wikipedia:Meristem](//en.wikipedia.org/wiki/Meristem)

* * *

**_Botany Study Guide_ ~ Wiki Contents Table**  
Section I

[Chapter 1 - Introduction](/wiki/Botany/Introduction_Botany) ~ [Chapter 2 - Plant cells](/wiki/Botany/Plant_cells)  
[Chapter 3 - Plant Tissues](/wiki/Botany/Plant_tissues) ~ [Chapter 4 - Plant Organs](/wiki/Botany/Plant_structure)  
[Chapter 5 - Plant Reproduction](/wiki/Botany/Plant_reproduction) ~ [Chapter 6 - Plant Morphology](/wiki/Botany/Plant_morphology)

<< [Contents Page](/wiki/Botany#Contents) | << [Chapter 3](/wiki/Botany/Plant_tissues) | Chapter 4 | [Chapter 5](/wiki/Botany/Plant_reproduction) >>|

* * *

Chapter 4. Plant Vegetative Organs

* * *

![Myriophyllum aquaticum](//upload.wikimedia.org/wikibooks/en/0/08/Parrotfeather_reduced.jpg)  
_The parrot's feather, an aquatic plant (Myriophyllum aquaticum)  
Click to [enlarge](//upload.wikimedia.org/wikibooks/en/1/10/Parrotfeather.jpg) picture_

## Introduction

As was noted in the previous [chapter](/wiki/Botany/Plant_tissues), most plant cells are specialized to a greater or lesser degree, and arranged together in **tissues**. A tissue can be _simple_ or _complex_ depending upon whether it is composed of one or more than one type of cell. Tissues are further arranged or combined into **organs** that carry out life functions of the organism. Plant organs include the **leaf**, **stem**, **root**, and **reproductive structures**. The first three are sometimes called the _vegetative organs_ and are the subject of exploration in this chapter. Reproductive organs will be covered in [Chapter 5](/wiki/Botany/Plant_reproduction).

The relationships of the organs within a plant body to each other remains an unsettled subject within plant morphology. The fundamental question is whether these are truly different structures, or just modifications of one basic structure (Eames, 1936; Esau, 1965). The plant body is an integrated, functional unit, so the division of a plant into organs is largely conceptual, providing a convenient way of approaching plant form and function. A boundary between stem and leaf is particularly difficult to make, so botanists sometimes use the word **shoot** to refer to the stem and its appendages (Esau, 1965).

## The Leaf

The plant leaf is an organ whose shape promotes efficient gathering of light for photosynthesis, but the form of the leaf must also be balanced against the fact that most of the loss of water a plant might suffer is going to occur at its leaves. Leaves are extremely variable in details of size, shape, and adornments like hairs.

Although the leaves of most plants carry out the same very basic functions, there is nonetheless an amazing variety of leaf sizes, shapes, margin types, forms of attachment, ornamentation (hairs), and even color. Examine the [Leaves (forms)](/wiki/Botany/Leaves_\(forms\)) page to learn the extensive terminology used to describe this variation. Consider that there are functional reasons for the modifications from a "basic" type.

## The Stem

The stem arises during development of the embryo as part of the _hypocotyl-root axis_, at the upper end of which are one or more cotyledons and the shoot primordium.

  * Read: [Stem](//en.wikipedia.org/wiki/en:Plant_stem)

## The Root

The root is the (typically) underground part of the plant axis specialized for both anchoring the plant and absorbing water and minerals.

  * Read: [Root](//en.wikipedia.org/wiki/en:Root) (Follow any links for terms you do not understand and to gain a complete picture of root structural variation)

    

    Be sure to read about and understand the meaning of each (at a minimum) of the following terms: **adventitious roots**, **endodermis**, **epidermis**, **gravitropism**, **root cap**, **root hair**, **stele**, **taproot**.

Most of the material you have read discusses the root organ as found in the angiosperms (flowering plants). However, among the vascular plants, only Psilotales lack such an organ, having instead rhizomes that bear hair-like absorbing structures called **rhizoids** (Eames, 1936 in Esau, 1965).

  
**Questions**:
    
    
    4-1. At this point the conceptual differences between cell types, tissues, organs,
         and organisms may be somewhat confusing. Using the leaf as an example, describe
         this structure in a way that considers the cell types, tissues, and organs for
         that part of the leaf where photosynthesis is concentrated.
    

* * *

    [Laboratory Exercises](/wiki/Botany/Plant_structure_laboratory) for Chapter 4 >>
    [Discussion of questions](/wiki/Botany/Plant_structure_discussion) for Chapter 4 >>>

* * *

**_Botany Study Guide_ ~ Wiki Contents Table**  
Section I

[Chapter 1 - Introduction](/wiki/Botany/Introduction_Botany) ~ [Chapter 2 - Plant cells](/wiki/Botany/Plant_cells)  
[Chapter 3 - Plant Tissues](/wiki/Botany/Plant_tissues) ~ [Chapter 4 - Plant Organs](/wiki/Botany/Plant_structure)  
[Chapter 5 - Plant Reproduction](/wiki/Botany/Plant_reproduction) ~ [Chapter 6 - Plant Morphology](/wiki/Botany/Plant_morphology)

<< [Contents Page](/wiki/Botany#Contents) | [Chapter 4](/wiki/Botany/Plant_structure) | Chapter 5 | [Chapter 6](/wiki/Botany/Plant_morphology) >>

* * *

Chapter 5. Plant Reproduction

* * *

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/P_Morc_D1252.JPG/360px-P_Morc_D1252.JPG)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Noni (_Morinda citrifolia_) flowers and fruit. Note stages of progressive maturation shown from a cluster of flowers to an accessory fruit.

## Vegetative Reproduction

Vegetative reproduction is a type of **asexual reproduction**—other terms that apply are _vegetative propagation,_ _clonal growth_, or _vegetative multiplication_. Vegetative **growth** is enlargement of the individual plant; vegetative reproduction is any process that results in new plant "individuals" without production of seeds (see _The Seed_ below) or spores. It is both a natural process in many, many species as well as one utilized or encouraged by horticulturists and farmers to obtain quantities of economically valuable plants. In this respect, it is a form of cloning that has been carried out by humankind for thousands of years and by "plants" for hundreds of millions of years.

  * Read [Vegetative Reproduction](//en.wikipedia.org/wiki/en:Vegetative_reproduction) (Follow all links)

## Sexual Reproduction

### The Flower

The **flower** is the reproductive organ of plants classified as _angiosperms_—that is, the flowering plants comprising the **Division Magnoliophyta**. All plants have the means and corresponding structures for reproducing sexually, and these other cases will be explored in later chapters. However, because **flowering plants** are the most conspicuous plants in almost all terrestrial environments, we justifiably devote this chapter to the flowering plants alone. You will learn how other plant groups (and non-plant groups, such as fungi) reproduce sexually in Section II of the _The Guide_.

The basic function of a flower is to produce **seeds** through **sexual reproduction**. Seeds are the next generation, and serve as the primary method in most plants by which individuals of the species are dispersed across the landscape. Actual dispersal is, in most species, a function of the **fruit**: structural parts that typically surround the seed. But the seed contains the germ of life of the next generation.

  * Read [Plant sexuality](//en.wikipedia.org/wiki/en:Plant_sexuality) (Follow links you find interesting, concentrating on acquiring a grasp of the terminology)
  * Read [The Flower](//en.wikipedia.org/wiki/en:Flower) (Follow links you find interesting, but at minimum read each of the following articles) 
    * Read [calyx](//en.wikipedia.org/wiki/en:Sepal) \- the sepals
    * Read [corolla](//en.wikipedia.org/wiki/en:Petal) \- the petals
    * Read [androecium](//en.wikipedia.org/wiki/en:Stamen) \- the stamens
    * Read [gynoecium](//en.wikipedia.org/wiki/en:Carpel) \- the pistil(s)

    

    Be sure to read about and understand the meaning of each of the following terms: **androecium**, **anthesis**, **calyx**, **carpel**, **corolla**, **gynoecium**, **inferior ovary**, **nectary**, **perigynous**, **petal**, **pistil**, **pollen**, **sepal**, **stamen**, **superior ovary**, **syncarpous**.

  * Read [Inflorescence](//en.wikipedia.org/wiki/en:Inflorescence)

    

    Be sure to read about and understand the meaning of each of the following terms: **bract**, **inflorescence**, **panicle**, **raceme**, **spadix**, **spikelet**.

**Questions**:
    
    
    5-1. Do you think the flower structure is in any way responsible for the considerable
         success of flowering plants in populating the earth? 
    

### The Seed and Germination

the primary purpose of the seed is one of preserving the continuity of life—starting a new generation in a new physical location. For large plants (shrubs and trees), this can be especially important because successful germination and growth close to the parent may be difficult or impossible; the established plant monopolizes light and water resources in its immediate vicinity. Seeds can also serve the function of overwintering or surviving harsh conditions. The entire generation—every individual—may die in the Fall or the dry season. In many annual species, only the seed exists during unfavorable dry or cold conditions.

  * [The Seed](//en.wikipedia.org/wiki/en:Seed) (Follow all links on anatomy and function) 
    * Read [Germination](//en.wikipedia.org/wiki/en:Germination)

**needed here an explanation of clonal reproduction of plants... through genets, rhizomes or whatever. I am not a botanist, please, if you are, explain this.**

### The Fruit

The fruit is the actual agent of dispersal in most flowering plants.

  * [The Fruit](//en.wikipedia.org/wiki/en:Fruit)

* * *

    [Laboratory Exercises (flowers)](/wiki/Botany/Plant_reproduction_laboratory_flower) for Chapter 5 >>
    [Laboratory Exercises (seeds)](/wiki/Botany/Plant_reproduction_laboratory_seed) for Chapter 5 >>
    [Discussion of questions](/w/index.php?title=Botany/Plant_reproduction_discussion&action=edit&redlink=1) for Chapter 5 >>

* * *

**_Botany Study Guide_ ~ Wiki Contents Table**  
Section I

[Chapter 1 - Introduction](/wiki/Botany/Introduction_Botany) ~ [Chapter 2 - Plant cells](/wiki/Botany/Plant_cells)  
[Chapter 3 - Plant Tissues](/wiki/Botany/Plant_tissues) ~ [Chapter 4 - Plant Organs](/wiki/Botany/Plant_structure)  
[Chapter 5 - Plant Reproduction](/wiki/Botany/Plant_reproduction) ~ [Chapter 6 - Plant Morphology](/wiki/Botany/Plant_morphology)

## Chapter 5. Plant Reproduction Laboratory ~ Flowers

![Spathoglottis plicata](//upload.wikimedia.org/wikibooks/en/8/8e/Orchid_lab_smver.jpg)  
_Infloresence of the orchid,_ Spathoglottis plicata _([enlarge to examine](//upload.wikimedia.org/wikibooks/en/c/c1/Orchid_lab.jpg))._

### An orchid flower

This first laboratory exercise for Chapter 4 deals with the flowers of a ground orchid from Southeast Asia. The photograph on the right demonstrates the descriptive terminology that can be applied to this species. You may wish to read about [orchids](//en.wikipedia.org/wiki/en:Orchidaceae) to place this plant taxonomically and better understand unusual aspects of the structure of this flower. In reading the description below, be sure you understand how or why each bolded word applies to this specimen. Also, observe that the flowering-through-fruiting sequence is well demonstrated in the photograph because each flower is in a slightly different phase of its life cycle from bud to fruit.

    _Spathoglottis plicata_ Blume — The flowers of this orchid are carried on an erect **raceme** growing out of the pseudobulb, each flower subtended by a green to purplish **bract** that becomes strongly **reflexed** with age. The purple **sepals** and **petals** are similar and **spreading**, elliptic to elliptic-ovate; the **labellum** is in three distinct parts: the lateral lobes narrow and erect, the middle lobe horizontal and cleft or 2-lobed. Lying above the latter is the narrowly **clavate** **column**. The **inferior ovary** in _Spathoglottis_ develops into a cylindrical **capsule** (fruit) as the **perianth** withers.

* * *

**4-1**. Review the photograph of the inflorescence of the orchid. _Which one of these statements is true_:

    a) this inflorescence demonstrates _determinate_ growth
    b) this inflorescence could as well be called a _spike_
    c) the uppermost flower shows _anthesis_.
    d) there are five petals, therefore this is a dicot.

![PHOTOGRAPH 1](//upload.wikimedia.org/wikibooks/en/7/7e/FlowerLab3_reduced.jpg)  
_Photograph 1:_ Bidens torta _([Examine](//upload.wikimedia.org/wikibooks/en/b/b0/FlowerLab3.jpg))_

Following are a series of photographs of flowers from various plants. _Note that by clicking on the word_ "Examine" _in each title, you can enlarge the particular photograph for closer examination_. Read each question and the offered answers carefully. All parts of answer choice must be correct for that choice to be correct.

**4-2**. _The structure at **B** is_:

    a) leaf
    b) corolla
    c) ligule
    d) sepal
    e) petiole

![PHOTOGRAPH 2](//upload.wikimedia.org/wikibooks/en/thumb/9/92/FlowerLab1_reduced.jpg/300px-FlowerLab1_reduced.jpg)  
_Photograph 2. Hibiscus_ ([Examine](//upload.wikimedia.org/wikibooks/en/9/98/FlowerLab1.jpg))

**4-3**. _Although the flowers in these three photographs appear very different, the following parts or floral structures are essentially the same_:

    a) AA and F
    b) BB and C
    c) G and H
    d) F and B
    e) D and BB

**4-4**. _Which statement of the following applies to the structure indicated at **E**_ :

    a) Pollen grains have landed on this pistil
    b) Androecium of a monoecious plant
    c) This is a spathe
    d) E is an anther releasing pollen
    e) This flower head is on a dioecious plant

![PHOTOGRAPH 3](//upload.wikimedia.org/wikipedia/commons/6/6f/Arum_flower_labeled.jpg)  
_Photograph 3._ Xanthosoma _or 'Ape ([Examine](//upload.wikimedia.org/wikipedia/commons/2/2f/Arum_flower.jpg))_

<< [Return to Chapter 5](/wiki/Botany/Plant_reproduction)

* * *

Answers to Chapter 4 Laboratory Questions:

    **4-1** ~ c (this flower alone is capable of pollination)
    **4-2** ~ b (A flower head with tubular disk corollas)
    **4-3** ~ d (both **F** and **B** indicate petals of their respective flowers)
    **4-4** ~ d (the androecium is supported on a tubular structure (**G**) that surrounds the pistil (**H**)

## Chapter 5. Plant Reproduction Laboratory ~ Seeds

## A monocot seedling

![Pritchardia remota](//upload.wikimedia.org/wikibooks/en/thumb/2/2c/Monocot_seedling.jpg/400px-Monocot_seedling.jpg)

The photograph at the right shows two germinating seeds. These are seeds of the fan palm, _Pritchardia remota_, a species found naturally only on (endemic to) the remote island of Nihoa in the Hawaiian islands. The seed on the left is in the proper orientation in the planting medium (only a part of the fruit coat covering the seed is visible), while the one on the right (in a slightly earlier stage) has been laid on the surface in order to better reveal development of the root. The following structures are labeled:

    **co** \- _coleoptile_ or shoot pole of plant axis; essentially a cap within which the plumule (first leaf) is developing, to eventually project through as in the seedling on the left.
    **ra** \- _radicle_; primordial root or root pole of axis (note tiny root cap), buried in the medium in the seedling on the left.
    **sc** \- _scuttelum_; that part of the cotyledon that remains inside the seed to absorb food stored in an endosperm.

  
([enlarge to examine](//upload.wikimedia.org/wikibooks/en/2/2c/Monocot_seedling.jpg)).

  
<< [Return to Chapter 5](/wiki/Botany/Plant_reproduction)

* * *

# License

## GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Botany/Print_version&oldid=1955841](http://en.wikibooks.org/w/index.php?title=Botany/Print_version&oldid=1955841)" 

[Category](/wiki/Special:Categories): 

  * [Botany](/wiki/Category:Botany)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Botany%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Botany%2FPrint+version)

### Namespaces

  * [Book](/wiki/Botany/Print_version)
  * [Discussion](/w/index.php?title=Talk:Botany/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Botany/Print_version)
  * [Edit](/w/index.php?title=Botany/Print_version&action=edit)
  * [View history](/w/index.php?title=Botany/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Botany/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Botany/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Botany/Print_version&oldid=1955841)
  * [Page information](/w/index.php?title=Botany/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Botany%2FPrint_version&id=1955841)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Botany%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Botany%2FPrint+version&oldid=1955841&writer=rl)
  * [Printable version](/w/index.php?title=Botany/Print_version&printable=yes)

  * This page was last modified on 23 October 2010, at 12:06.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Botany/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
