# Signals and Systems/Print version

From Wikibooks, open books for an open world

< [Signals and Systems](/wiki/Signals_and_Systems)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Signals and Systems](/wiki/Signals_and_Systems)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Signals_and_Systems/Print_version&action=purge&printable=yes) this page.

# Introduction

**[Signals and Systems](/wiki/Signals_and_Systems)**

## What is this book for?

The purpose of this book is to begin down the long and winding road of Electrical Engineering. Previous books on electric circuits have laid a general groundwork, but again: that is not what electrical engineers usually do with their time. Very complicated integrated circuits exist for most applications that can be picked up at a local circuit shop or hobby shop for pennies, and there is no sense creating new ones. As such, this book will most likely spend little or no time discussing actual circuit implementations of any of the structures discussed. Also, this book will not stumble through much of the complicated mathematics, instead opting to simply point out and tabulate the relevant results. What this book will do, however, is attempt to provide some insight into a field of study that is considered very foreign and arcane to most outside observers. This book will be a theoretical foundation that future books will build upon. This book will likely not discuss any specific implementations (no circuits, transceivers, filters, etc...), as these materials will be better handled in later books.

## Who is this book for?

This book is designed to accompany a second year of study in electrical engineering at the college level. However, students who are not currently enrolled in an electrical engineering curriculum may also find some valuable and interesting information here. This book requires the reader to have a previous knowledge of differential calculus, and assumes familiarity with integral calculus as well. Barring previous knowledge, a concurrent course of study in integral calculus could accompany reading this book, with mixed results. Using Laplace Transforms, this book will avoid differential equations completely, and therefore no prior knowledge of that subject is needed.

Having a prior knowledge of other subjects such as physics (wave dynamics, energy, forces, fields) will provide a deeper insight into this subject, although it is not required. Also, having a mathematical background in probability, statistics, or random variables will provide a deeper insight into the mechanics of noise signals, but that also is not required.

## What will this book cover?

This book is going to cover the theory of LTI systems and signals. This subject will form the fundamental basis for several other fields of study, including signal processing, [Digital Signal Processing](/wiki/Digital_Signal_Processing), [Communication Systems](/wiki/Communication_Systems), and [Control Systems](/wiki/Control_Systems).

This book will provide the basic theory of LTI systems and mathematical modeling of signals. We will also introduce the notion of a stochastic, or random, process. Random processes, such as noise or interference, are so common in the studies of these systems that it's impossible to discuss the practical use of filter systems without first discussing noise processes.

Later sections will introduce some more advanced topics, such as digital signals and systems, and filters. This book will not discuss these topics at length, however, preferring to direct the reader to more comprehensive books on these subjects.

This book will attempt, so far as is possible, to provide not only the materials but also discussions about the importance and relevance of those materials. Because the information in this book plays a fundamental role in preparing the reader for advanced discussions in other books.

## Where to go from here

Once a basic knowledge of signals and systems has been learned, the reader can then take one of several paths of study.

  * Readers interested in the use of electric signals for long-distance communications can read [Communication Systems](/wiki/Communication_Systems) and [Communication Networks](/wiki/Communication_Networks). This path will culminate in a study of [Data Coding Theory](/wiki/Data_Coding_Theory).
  * Readers more interested in the analysis and processing of signals would likely be more interested in reading about [Signal Processing](/wiki/Signal_Processing) and [Digital Signal Processing](/wiki/Digital_Signal_Processing). These books will focus primarily on the "signals".
  * Readers who are more interested in the use of LTI systems to exercise control over systems will be more interested in [Control Systems](/wiki/Control_Systems). This book will focus primarily on the "systems".

All three branches of study are going to share certain techniques and foundations, so many readers may find benefit in trying to follow the different paths simultaneously.

# MATLAB

**[Signals and Systems](/wiki/Signals_and_Systems)**

## What is MATLAB?

MATLAB - MATrix LABoratory is an industry standard tool in engineering applications. Electrical Engineers, working on topics related to this book will often use MATLAB to help with modeling. For more information on programming MATLAB, see [MATLAB Programming](/wiki/MATLAB_Programming).

## Obtaining MATLAB

MATLAB itself is a relatively expensive piece of software. It is available for a fee from the Mathworks website.

## MATLAB Clones

There are, however, free alternatives to MATLAB. These alternatives are frequently called "MATLAB Clones", although some of them do not mirror the syntax of MATLAB. The most famous example is **Octave**. Here are some resources if you are interested in obtaining Octave:

  * [SPM/MATLAB](/wiki/SPM/MATLAB)
  * [Octave Programming Tutorial](/wiki/Octave_Programming_Tutorial)
  * [MATLAB Programming/Differences between Octave and MATLAB](/wiki/MATLAB_Programming/Differences_between_Octave_and_MATLAB)
  * ["Scilab / Scicoslab"](//en.wikipedia.org/wiki/Scilab)

## MATLAB Template

This book will make use of the `{{[MATLAB CMD](/wiki/Template:MATLAB_CMD)}}` template, that will create a note to the reader that MATLAB has a command to handle a particular task. In the individual chapters, this book will not discuss MATLAB outright, nor will it explain those commands. However, there will be some chapters at the end of the book that will demonstrate how to perform some of these calculations, and how to use some of these analysis tools in MATLAB.

# Signal and System Basics

## Signals

What is a signal? Of course, we know that a signal can be a rather abstract notion, such as a flashing light on our car's front bumper (turn signal), or an umpire's gesture indicating that a pitch went over the plate during a baseball game (a strike signal). One of the definitions of signal in the Merrian-Webster dictionary is:

"A detectable physical quantity or impulse (as a voltage, current, or magnetic field strength) by which messages or information can be transmitted." or

"A signal is a function of independent variables that carry some information."

"A signal is a source of information generaly a physical quantity which varies with respect to time, space, temperature like any independent variable"

"A signal is a physical quantity that varies with time,space or any other independent variable.by which information can be conveyed"

These are the types of signals which will be of interest in this book. We will focus on two broad classes of signals, _discrete-time_ and _continuous-time_. We will consider discrete-time signals later. For now, we will focus our attention on continuous-time signals. Fortunately, continuous-time signals have a very convenient mathematical representation. We represent a continuous-time signal as a function _x(t)_ of the real variable _t_. Here, _t_ represents **continuous time** and we can assign to _t_ any unit of time we deem appropriate (seconds, hours, years, etc.). We do not have to make any particular assumptions about _x(t)_ such as "boundedness" (a signal is bounded if it has a finite value). Some of the signals we will work with are in fact, not bounded (i.e. they take on an infinite value). However most of the continuous-time signals we will deal with in the real world are bounded.

Signal: a function representing some variable that contains some information about the behavior of a natural or artificial system. Signals are one part of the whole. Signals are meaningless without systems to interpret them, and systems are useless without signals to process.

Signal: the energy (a traveling wave) that carries some information.

Signal example: an electrical circuit signal may represent a time-varying voltage measured across a resistor.

A signal can be represented as a function x(t) of an independent variable t which usually represents time. If t is a continuous variable, x(t) is a continuous-time signal, and if t is a discrete variable, defined only at discrete values of t, then x(t) is a discrete-time signal. A discrete-time signal is often identified as a sequence of numbers, denoted by x[n], where n is an integer.

Signal: the representation of information.

## Systems

A **System**, in the sense of this book, is any physical set of components that takes a signal, and produces a signal. In terms of engineering, the input is generally some electrical signal X, and the output is another electrical signal(response) Y. However, this may not always be the case. Consider a household thermostat, which takes input in the form of a knob or a switch, and in turn outputs electrical control signals for the furnace.

A main purpose of this book is to try and lay some of the theoretical foundation for future dealings with electrical signals. Systems will be discussed in a theoretical sense only.

  


**[Signals and Systems](/wiki/Signals_and_Systems)**

## Basic Functions

Often times, complex signals can be simplified as linear combinations of certain basic functions (a key concept in Fourier analysis). These basic functions, which are useful to the field of engineering, receive little or no coverage in traditional mathematics classes. These functions will be described here, and studied more in the following chapters.

## Unit Step Function

The unit step function and the impulse function are considered to be fundamental functions in engineering, and it is strongly recommended that the reader becomes very familiar with both of these functions.

![](//upload.wikimedia.org/wikipedia/commons/e/e0/Unit_Step_function_u%28t%29_-_SST_-_08DEC05.png)

Unit Step Function

![](//upload.wikimedia.org/wikipedia/commons/6/67/Unit_Step_function_u%28t-to%29_-_SST_-_08DEC05.png)

Shifted Unit Step function

The unit step function, also known as the [Heaviside function](//en.wikipedia.org/wiki/Heaviside_step_function), is defined as such:

    ![u\(t\) = \\left\\{ 
               \\begin{matrix} 
                 0, & \\mbox{if }t < 0 
               \\\\ 
                 1, & \\mbox{if }t > 0
               \\\\
                 \\frac{1}{2}, & \\mbox{if }t = 0
               \\end{matrix}
             \\right.
](//upload.wikimedia.org/math/9/e/9/9e985371a8e600858db84e9c8f88e616.png)

Sometimes, u(0) is given other values, usually either 0 or 1. For many applications, it is irrelevant what the value at zero is. u(0) is generally written as undefined.

### Derivative

The unit step function is level in all places except for a discontinuity at t = 0. For this reason, the derivative of the unit step function is 0 at all points t, except where t = 0. Where t = 0, the derivative of the unit step function is infinite.

The derivative of a unit step function is called an **impulse function**. The impulse function will be described in more detail next.

### Integral

The integral of a unit step function is computed as such:

    ![\\int_{-\\infty}^t u\(s\)ds = 

\\left\\{ 
    \\begin{matrix}  0, & \\mbox{if }t < 0   \\\\ 
                   \\int_0^t ds = t, & \\mbox{if }t \\ge 0 
    \\end{matrix}
\\right\\} = tu\(t\)](//upload.wikimedia.org/math/3/9/4/39496ed4fecbbb0126502ccb52de78f9.png)

In other words, the integral of a unit step is a "ramp" function. This function is 0 for all values that are less than zero, and becomes a straight line at zero with a slope of +1.

### Time Inversion

if we want to reverse the unit step function, we can flip it around the y axis as such: u(-t). With a little bit of manipulation, we can come to an important result:

    ![u\(-t\) = 1 - u\(t\)](//upload.wikimedia.org/math/c/f/a/cfa55ed9d5724d6b5931f49932a40e72.png)

### Other Properties

Here we will list some other properties of the unit step function:

  * ![u\(\\infty\) = 1](//upload.wikimedia.org/math/7/7/b/77ba003bb619d296ca27ea3fadc10b3e.png)
  * ![u\(-\\infty\) = 0](//upload.wikimedia.org/math/3/7/5/375a44e3a2c75b93f093d8f29b35212e.png)
  * ![u\(t\) + u\(-t\) = 1](//upload.wikimedia.org/math/d/3/b/d3b8b29200b2146bf45f08965a642023.png)

These are all important results, and the reader should be familiar with them.

## Impulse Function

An impulse function is a special function that is often used by engineers to model certain events. An impulse function is not realizable, in that by definition the output of an impulse function is infinity at certain values. An impulse function is also known as a "delta function", although there are different types of delta functions that each have slightly different properties. Specifically, this _unit-impulse function_ is known as the Dirac delta function. The term "Impulse Function" is unambiguous, because there is only one definition of the term "Impulse".

Let's start by drawing out a rectangle function, D(t), as such:

![Dirac Delta.svg](//upload.wikimedia.org/wikibooks/en/thumb/d/dd/Dirac_Delta.svg/300px-Dirac_Delta.svg.png)

We can define this rectangle in terms of the unit step function:

    ![D\(t\) = \\frac{1}{A}\[u\(t + A/2\) - u\(t - A/2\)\]](//upload.wikimedia.org/math/6/1/3/6131bce1649aa9212e040e9bd22eb4ef.png)

Now, we want to analyze this rectangle, as A becomes infinitesimally small. We can define this new function, the **delta function**, in terms of this rectangle:

    ![\\delta\(t\) = \\lim_{A \\to 0}\\frac{1}{A}\[u\(t + A/2\) - u\(t - A/2\)\]](//upload.wikimedia.org/math/e/a/0/ea0aef056eaa250da10efea887c06247.png)

We can similarly define the delta function piecewise, as such:

  1. ![\\delta\(t\) = 0\\mbox{ for } t \\ne 0 ](//upload.wikimedia.org/math/f/d/d/fdd4733c095463763d70180d351aee68.png).
  2. ![\\delta\(t\) > 0\\mbox{ for } t = 0 ](//upload.wikimedia.org/math/c/d/9/cd99f3ecce0196c7f110140f59618d56.png).
  3. ![\\int_{-\\infty}^\\infty \\delta\(t\) dt = 1 ](//upload.wikimedia.org/math/2/4/6/2462eaa93ac7268f9a311f36db8a57ea.png).

Although, this definition is less rigorous than the previous definition.

### Integration

From its definition it follows that the integral of the impulse function is just the step function:

    ![\\int \\delta\(t\)dt = u\(t\)](//upload.wikimedia.org/math/7/a/f/7afcd4f6ded78b4109964f404f9056fb.png)

Thus, defining the derivative of the unit step function as the impulse function is justified.

### Shifting Property

Furthermore, for an integrable function _f_:

    ![\\int_{-\\infty}^\\infty \\delta\(t - A\) f\(t\)dt = f\(A\)](//upload.wikimedia.org/math/b/d/a/bda8075bafcd2da1e3b76c39c69c6c7f.png)

This is known as the **shifting property** (also known as the **sifting property** or the **sampling property**) of the delta function; it effectively samples the value of the function _f_, at location _A_.

The delta function has many uses in engineering, and one of the most important uses is to sample a continuous function into discrete values.

Using this property, we can extract a single value from a continuous function by multiplying with an impulse, and then integrating.

### Types of Delta

There are a number of different functions that are all called "delta functions". These functions generally all look like an impulse, but there are some differences. Generally, this book uses the term "delta function" to refer to the **Dirac Delta Function**.

  * [w:Dirac delta function](//en.wikipedia.org/wiki/Dirac_delta_function)
  * [w:Kronecker delta](//en.wikipedia.org/wiki/Kronecker_delta)

## Sinc Function

There is a particular form that appears so frequently in communications engineering, that we give it its own name. This function is called the "Sinc function" and is discussed below:

The Sinc function is defined in the following manner:

    ![\\operatorname{sinc}\(x\) = \\frac{\\sin\(\\pi x\)}{\\pi x} \\mbox{ if } x \\neq 0](//upload.wikimedia.org/math/3/1/b/31b3b489cbafb683c317fde9483367eb.png)

and

    ![\\operatorname{sinc}\(0\) = 1 ](//upload.wikimedia.org/math/0/4/4/044e29ab85daea193d587fe40d133302.png)

The value of sinc(x) is defined as 1 at x = 0, since

    ![\\lim_{x \\rightarrow 0}\\operatorname{sinc}\(x\) = 1](//upload.wikimedia.org/math/a/4/1/a417f6bda8f06d3fff7a63cd47a71678.png).

This fact can be proven by noting that for x near 0,

    ![1 > \\frac{\\sin{\(x\)}}{x} > \\cos{\(x\)}](//upload.wikimedia.org/math/f/e/b/feb02bb0b60d912c00928249e9b145e0.png).

Then, since cos(0) = 1, we can apply the _[Squeeze Theorem_](/wiki/Calculus/Limits/An_Introduction_to_Limits#The_Squeeze_Theorem) to show that the sinc function approaches one as x goes to zero. Thus, defining sinc(0) to be 1 makes the sinc function continuous.

Also, the Sinc function approaches zero as x goes towards infinity, with the envelope of sinc(x) tapering off as 1/x.

## **Rect Function**

The Rect Function is a function which produces a rectangular-shaped pulse with a width of 1 centered at t = 0. The Rect function pulse also has a height of 1. The Sinc function and the rectangular function form a Fourier transform pair.

A Rect function can be written in the form:

    ![\\operatorname{rect}\\left\(\\frac{t-X}{Y} \\right\)](//upload.wikimedia.org/math/c/7/b/c7b2dac0b530121578bc7af8c59b68ea.png)

where the pulse is centered at X and has width Y. We can define the impulse function above in terms of the rectangle function by centering the pulse at zero (X = 0), setting it's height to 1/A and setting the pulse width to A, which approaches zero:

    ![\\delta\(t\) = \\lim_{A \\to 0} \\frac{1}{A}\\operatorname{rect}\\left\(\\frac{t-0}{A}\\right\)](//upload.wikimedia.org/math/8/a/f/8af9418fc57036230c6dbcdd45864a54.png)

We can also construct a Rect function out of a pair of unit step functions:

    ![\\operatorname{rect}\\left\(\\frac{t-X}{Y} \\right\) = u\(t - X + Y/2\) - u\(t - X - Y/2\)](//upload.wikimedia.org/math/e/9/8/e9813fdb1f27b8e488c6a3ee00b716d9.png)

Here, both unit step functions are set a distance of Y/2 away from the center point of (t - X).

## Square Wave

A square wave is a series of rectangular pulses. Here are some examples of square waves:

![Square Wave T.svg](//upload.wikimedia.org/wikibooks/en/thumb/e/e5/Square_Wave_T.svg/300px-Square_Wave_T.svg.png)

![Square Wave 2T.svg](//upload.wikimedia.org/wikibooks/en/thumb/f/fb/Square_Wave_2T.svg/300px-Square_Wave_2T.svg.png)

These two square waves have the same amplitude, but the second has a lower frequency. We can see that the period of the second is approximately twice as large as the first, and therefore that the frequency of the second is about half the frequency of the first.

![Square Wave T.svg](//upload.wikimedia.org/wikibooks/en/thumb/e/e5/Square_Wave_T.svg/300px-Square_Wave_T.svg.png)

![Square Wave Offset.svg](//upload.wikimedia.org/wikibooks/en/thumb/e/ea/Square_Wave_Offset.svg/300px-Square_Wave_Offset.svg.png)

These two square waves have the same frequency and the same peak-to-peak amplitude, but the second wave has no DC offset. Notice how the second wave is centered on the _x_ axis, while the first wave is completely above the _x_ axis.

**[Signals and Systems](/wiki/Signals_and_Systems)**

There are many tools available to analyze a system in the time domain, although many of these tools are very complicated and involved. Nonetheless, these tools are invaluable for use in the study of linear signals and systems, so they will be covered here.

![Warning icon WikiBooks.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Warning_icon_WikiBooks.svg/35px-Warning_icon_WikiBooks.svg.png)

This book contains mathematical formulae that look better **[rendered as PNG](/wiki/Wikibooks:Render_as_PNG)**.

  


## Linear Time-Invariant (LTI) Systems

This page will contain the definition of a LTI system and this will be used to motivate the definition of convolution as the output of a LTI system in the next section. To begin with a system has to be defined and the LTI properties have to be listed. Then, for a given input it can be shown (in this section or the following) that the output of a LTI system is a convolution of the input and the system's impulse response, thus motivating the definition of convolution.

Consider a system for which an input of _xi(t)_ results in an output of _yi(t)_ respectively for _i = 1, 2_.

### Linearity

There are 3 requirements for _linearity_. A function must satisfy all 3 to be called "linear".

  1. **Additivity**: An input of ![x_3\(t\) = x_1\(t\) + x_2\(t\)](//upload.wikimedia.org/math/4/6/6/4664dd969b782668f7a6ed911b618e91.png) results in an output of ![y_3\(t\) = y_1\(t\) + y_2\(t\)](//upload.wikimedia.org/math/2/1/2/21224043d657ced23f4ba85fb88553e4.png).
  2. **Homogeneity**: An input of ![ax_1](//upload.wikimedia.org/math/7/6/e/76edc6be4a9cd5093eead1f3b423e95b.png) results in an output of ![ay_1](//upload.wikimedia.org/math/8/5/4/8541d392e564542539717bbb99ea1ffb.png)
  3. If x(t) = 0, y(t) = 0.

"Linear" in this sense is not the same word as is used in conventional algebra or geometry. Specifically, linearity in signals applications has nothing to do with straight lines. Here is a small example:

    ![y\(t\) = x\(t\) + 5](//upload.wikimedia.org/math/c/2/5/c25afd898fdaa6404fc8b46da16440a6.png)

This function is not linear, because when x(t) = 0, y(t) = 5 (fails requirement 3). This may surprise people, because this equation is the equation for a straight line!

Being linear is also known in the literature as "satisfying the principle of superposition". **Superposition** is a fancy term for saying that the system is additive and homogeneous. The terms linearity and superposition can be used interchangably, but in this book we will prefer to use the term linearity exclusively.

We can combine the three requirements into a single equation: In a linear system, an input of ![a_1x_1\(t\)+a_2x_2\(t\)](//upload.wikimedia.org/math/2/1/3/2139438da09778ba9ef88014eeb7444c.png) results in an output of ![a_1y_1\(t\)+a_2y_2\(t\)](//upload.wikimedia.org/math/a/2/2/a22ebb98c042d923331e75327da87423.png).

### Additivity

A system is said to be additive if a sum of inputs results in a sum of outputs. To test for additivity, we need to create two arbitrary inputs, _x1(t)_ and _x2(t)_. We then use these inputs to produce two respective outputs:

    ![y_1\(t\) = f\(x_1\(t\)\)](//upload.wikimedia.org/math/2/0/2/202ad94c2ea5b0aabe453b1e279f729c.png)
    ![y_2\(t\) = f\(x_2\(t\)\)](//upload.wikimedia.org/math/8/7/0/87004b94d9baf99788598fa1da7c18bd.png)

Now, we need to take a sum of inputs, and prove that the system output is a sum of the previous outputs:

    ![y_1\(t\) + y_2\(t\) = f\(x_1\(t\) + x_2\(t\)\)](//upload.wikimedia.org/math/9/1/8/9182b3758f128954a7e203079cb20668.png)

If this final relationship is not satisfied for _all possible inputs_, then the system is not additive.

### Homogeneity

Similar to additivity, a system is homogeneous if a scaled input (multiplied by a constant) results in a scaled output. If we have two inputs to a system:

    ![y_1\(t\) = f\(x_1\(t\)\)](//upload.wikimedia.org/math/2/0/2/202ad94c2ea5b0aabe453b1e279f729c.png)
    ![y_2\(t\) = f\(x_2\(t\)\)](//upload.wikimedia.org/math/8/7/0/87004b94d9baf99788598fa1da7c18bd.png)

Where

    ![x_1\(t\) = cx_2\(t\)](//upload.wikimedia.org/math/8/d/3/8d32ce0e40e28ee79f378af50f0c32e4.png)

Where _c_ is an arbitrary constant. If this is the case then the system is homogeneous if

    ![y_1\(t\) = cy_2\(t\)](//upload.wikimedia.org/math/9/5/b/95b106eb85dc3f94940c7c8eef74f4cc.png)

for any arbitrary _c_.

### Time Invariance

If the input signal _x(t)_ produces an output _y(t)_ then any time shifted input, _x(t + δ)_, results in a time-shifted output _y(t + δ)_.

This property can be satisfied if the transfer function of the system is not a function of time except expressed by the input and output.

### Example: Simple Time Invariance

To demonstrate how to determine if a system is time-invariant then consider the two systems:

  * System A: ![y\(t\) = t\\, x\(t\)](//upload.wikimedia.org/math/c/2/5/c255c19c2be31236c570ec23f9c7af79.png)
  * System B: ![\\,\\!b\(t\) = 10 x\(t\)](//upload.wikimedia.org/math/5/9/e/59e7c6a12b4597f5c105a3db8c6a2148.png)

Since system A explicitly depends on _t_ outside of _x(t)_ and _y(t)_ then it is **time-variant**. System B, however, does not depend explicitly on _t_ so it is time-invariant.

### Example: Formal Proof

A more formal proof of why systems A & B from above are respectively time varying and time-invariant is now presented. To perform this proof, the second definition of time invariance will be used.

System A
    Start with a delay of the input ![x_d\(t\) = \\,\\!x\(t + \\delta\)](//upload.wikimedia.org/math/8/f/f/8ff6661ce59f730759c8e8e0453f6145.png)

    ![y\(t\) = t\\, x_d\(t\)](//upload.wikimedia.org/math/d/e/e/deecb093b2558e6db7df0bd982b96fe0.png)
    ![y_1\(t\) = t\\, x_d\(t\) = t\\, x\(t + \\delta\)](//upload.wikimedia.org/math/0/6/8/068a7d039ece72a67b239be9f457601e.png)
    Now delay the output by δ 

    ![y\(t\) = t\\, x\(t\)](//upload.wikimedia.org/math/c/2/5/c255c19c2be31236c570ec23f9c7af79.png)
    ![y_2\(t\) = \\,\\!y\(t + \\delta\) = \(t + \\delta\) x\(t + \\delta\)](//upload.wikimedia.org/math/d/1/6/d1661cf739e40b29e04dc86bd0507ecd.png)
    Clearly ![y_1\(t\) \\,\\!\\ne y_2\(t\)](//upload.wikimedia.org/math/7/b/2/7b284ca1924d2ab4c6ecf98498f5984f.png), therefore the system is not time-invariant.

System B
    Start with a delay of the input ![x_d\(t\) = \\,\\!x\(t + \\delta\)](//upload.wikimedia.org/math/8/f/f/8ff6661ce59f730759c8e8e0453f6145.png)

    ![y\(t\) = 10 \\, x_d\(t\)](//upload.wikimedia.org/math/d/d/0/dd05316199f19b45fd78241284b924e6.png)
    ![y_1\(t\) = 10 \\,x_d\(t\) = 10 \\,x\(t + \\delta\)](//upload.wikimedia.org/math/e/e/a/eea9479c47e1e1bf51717900ac757636.png)
    Now delay the output by δ 

    ![y\(t\) = 10 \\,x\(t\)](//upload.wikimedia.org/math/3/2/1/32125fdec36cf128420d8e4a54757641.png)
    ![y_2\(t\) = y\(t + \\delta\) = 10 \\,x\(t + \\delta\)](//upload.wikimedia.org/math/3/3/7/337869ac51cab7f97f56d6bac9f0db17.png)
    Clearly ![y_1\(t\) = \\,\\!y_2\(t\)](//upload.wikimedia.org/math/2/f/2/2f2c373b72288ea3146ae6d2ba6a000f.png), therefore the system is time-invariant.

## Linear Time Invariant (LTI) Systems

The system is linear time-invariant (LTI) if it satisfies both the property of linearity and time-invariance. This book will study LTI systems almost exclusively, because they are the easiest systems to work with, and they are ideal to analyze and design.

## Other Function Properties

Besides being linear, or time-invariant, there are a number of other properties that we can identify in a function:

### Memory

A system is said to have memory if the output from the system is dependent on past inputs (or future inputs) to the system. A system is called **memoryless** if the output is only dependent on the current input. Memoryless systems are easier to work with, but systems with memory are more common in digital signal processing applications. A memory system is also called a dynamic system whereas a memoryless system is called a static system.

### Causality

Causality is a property that is very similar to memory. A system is called **causal** if it is only dependent on past or current inputs. A system is called **non-causal** if the output of the system is dependent on future inputs. Most of the practical systems are casual.

### Stability

Stability is a very important concept in systems, but it is also one of the hardest function properties to prove. There are several different criteria for system stability, but the most common requirement is that the system must produce a finite output when subjected to a finite input. For instance, if we apply 5 volts to the input terminals of a given circuit, we would like it if the circuit output didn't approach infinity, and the circuit itself didn't melt or explode. This type of stability is often known as "Bounded Input, Bounded Output" stability, or BIBO.

Studying BIBO stability is a relatively complicated course of study, and later books on the Electrical Engineering bookshelf will attempt to cover the topic.

## Linear Operators

Mathematical operators that satisfy the property of linearity are known as **linear operators**. Here are some common linear operators:

  1. Derivative
  2. Integral
  3. Fourier Transform

### Example: Linear Functions

Determine if the following two functions are linear or not:

  1. ![y\(t\) = \\int^\\infty_{-\\infty} x\(t\) dt](//upload.wikimedia.org/math/a/4/3/a434c367d82da62637df574915a79651.png)
  2. ![y\(t\) = \\frac{d}{dt}x\(t\)](//upload.wikimedia.org/math/6/4/b/64b5d50faf9b3c9f2bb5bec6f343d6ef.png)

## Impulse Response

### Zero-Input Response

    ![x\(t\)=u\(t\)](//upload.wikimedia.org/math/b/c/c/bcc3bcd42444dfa296eea5ef1f20ebc9.png)
    ![h\(t\)=e^{-x}u\(t\)](//upload.wikimedia.org/math/8/2/2/8225e9f8435ad4af2dbf3b9f1cb3a13a.png)

### Zero-State Response

zero state response means transient response or natural response.

### Second-Order Solution

  * [Example](/w/index.php?title=Signals_and_Systems/Print_version/System_Response&action=edit&redlink=1). Finding the total response of a driven RLC circuit.

## Convolution

This operation can be performed using this [MATLAB](/wiki/MATLAB_Programming) command:  
**conv**

Convolution (folding together) is a complicated operation involving integrating, multiplying, adding, and time-shifting two signals together. Convolution is a key component to the rest of the material in this book.

The convolution _a * b_ of two functions _a_ and _b_ is defined as the function:

    ![\(a*b\)\(t\) = \\int_{-\\infty}^\\infty a\(\\tau\)b\(t - \\tau\)d\\tau](//upload.wikimedia.org/math/4/4/c/44c15554e0a2a43f610d93211718889f.png)

The greek letter τ (tau) is used as the integration variable, because the letter _t_ is already in use. τ is used as a "dummy variable" because we use it merely to calculate the integral.

In the convolution integral, all references to _t_ are replaced with τ, except for the _-t_ in the argument to the function _b_. Function _b_ is _time inverted_ by changing τ to -τ. Graphically, this process moves everything from the right-side of the _y_ axis to the left side and vice-versa. Time inversion turns the function into a mirror image of itself.

Next, function _b_ is _time-shifted_ by the variable _t_. Remember, once we replace everything with τ, we are now computing in the _tau domain_, and not in the time domain like we were previously. Because of this, _t_ can be used as a shift parameter.

We multiply the two functions together, time shifting along the way, and we take the area under the resulting curve at each point. Two functions overlap in increasing amounts until some "watershed" after which the two functions overlap less and less. Where the two functions overlap in the _t_ domain, there is a value for the convolution. If one (or both) of the functions do not exist over any given range, the value of the convolution operation at that range will be zero.

After the integration, the definite integral plugs the variable _t_ back in for remaining references of the variable τ, and we have a function of _t_ again. It is important to remember that the resulting function will be a combination of the two input functions, and will share some properties of both.

### Properties of Convolution

The convolution function satisfies certain conditions:

Commutativity
    ![f * g = g * f \\,](//upload.wikimedia.org/math/1/1/b/11b51e9549bdd014374d4cec71946806.png)

Associativity
    ![f  * \(g  * h\) = \(f  * g\)  * h \\,](//upload.wikimedia.org/math/e/2/5/e2500afa2d6c138445991bbec0666787.png)

Distributivity
    ![f  * \(g + h\) = \(f  * g\) + \(f  * h\) \\,](//upload.wikimedia.org/math/8/3/5/8354b5716c90f000dd10ad7e9860a829.png)

Associativity With Scalar Multiplication
    ![a \(f  * g\) = \(a f\)  * g = f  * \(a g\) \\,](//upload.wikimedia.org/math/0/9/0/090117ee83d0c45ed1bda898529f1e2f.png)

for any real (or complex) number _a_.

Differentiation Rule
    ![\(f  * g\)' = f' * g = f * g' \\,](//upload.wikimedia.org/math/a/a/b/aabf7d54f06884ba21f0ffe695989b8b.png)

### Example 1

Find the convolution, _z(t)_, of the following two signals, _x(t)_ and _y(t)_, by using (a) the integral representation of the convolution equation and (b) muliplication in the Laplace domain.

![Convolution Example 1 Signals.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/da/Convolution_Example_1_Signals.svg/600px-Convolution_Example_1_Signals.svg.png)

The signal _y(t)_ is simply the [Heaviside step](//en.wikipedia.org/wiki/Heaviside_step), _u(t)_.

The signal _x(t)_ is given by the following infinite sinusoid, _x0(t)_, and windowing function, _xw(t)_:

    

    ![x_0\(t\)=\\sin\(t\)\\,](//upload.wikimedia.org/math/d/b/3/db384cefe1c5ca2e70c01f57eaa14a87.png)

    

    ![x_w\(t\)=u\(t\)-u\(t-2\\pi\)\\,](//upload.wikimedia.org/math/d/1/4/d1473fba41ae07f56ac0158c194b0359.png)

![Convoution Example 1 x-Signal, Window.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/25/Convoution_Example_1_x-Signal%2C_Window.svg/600px-Convoution_Example_1_x-Signal%2C_Window.svg.png)

Thus, the convolution we wish to perform is therefore:

    

    ![z\(t\)=x\(t\) * y\(t\) \\,](//upload.wikimedia.org/math/a/4/9/a4942d834aebbd99eee16a0dc36cd9e0.png)

    

    ![z\(t\)=\\sin\(t\) \\left\[ u\(t\)-u\(t-2\\pi\) \\right\] * u\(t\) \\,](//upload.wikimedia.org/math/4/1/f/41f25b6aa3141bfb70016efb53311d19.png)

    

    ![z\(t\)=\\left\[ \\sin\(t\) u\(t\)- \\sin\(t\)u\(t-2\\pi\) \\right\] * u\(t\) \\,](//upload.wikimedia.org/math/7/d/a/7da1997a7cb15ee6f3f35716ceece04f.png)

From the distributive law:

    

    ![z\(t\)=\\sin\(t\) u\(t\) * u\(t\) - \\sin\(t\)u\(t-2\\pi\) * u\(t\) \\, ](//upload.wikimedia.org/math/4/5/2/4522c435028b89c221e22003ec79e64f.png)

![Convolution Example 1 Output.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Convolution_Example_1_Output.svg/600px-Convolution_Example_1_Output.svg.png)

## Correlation

This operation can be performed using this [MATLAB](/wiki/MATLAB_Programming) command:  
**xcorr**

Akin to Convolution is a technique called "Correlation" that combines two functions in the time domain into a single resultant function in the time domain. Correlation is not as important to our study as convolution is, but it has a number of properties that will be useful nonetheless.

The correlation of two functions, _g(t)_ and _h(t)_ is defined as such:

    ![R_{gh}\(t\) = \\int_{-\\infty}^\\infty g\(\\tau\)h\(t + \\tau\) d\\tau](//upload.wikimedia.org/math/2/9/4/2941cba86d5c7647dfa49dfa7c3c52b3.png)

Where the capital _R_ is the **Correlation Operator**, and the subscripts to _R_ are the arguments to the correlation operation.

We notice immediately that correlation is similar to convolution, except that we don't time-invert the second argument before we shift and integrate. Because of this, we can define correlation in terms of convolution, as such:

    ![R_{gh}\(t\) = g\(t\) * h\(-t\)](//upload.wikimedia.org/math/5/b/5/5b5e7e167acd0a2b6b0102850e3ee9d9.png)

### Uses of Correlation

Correlation is used in many places because it demonstrates one important fact: Correlation determines how much similarity there is between the two argument functions. The more the area under the correlation curve, the more is the similarity between the two signals.

### Autocorrelation

The term "autocorrelation" is the name of the operation when a function is correlated with itself. The autocorrelation is denoted when both of the subscripts to the Correlation operator are the same:

    ![R_{xx}\(t\) = x\(t\) * x\(-t\)](//upload.wikimedia.org/math/7/8/e/78e0eeedb9391e0a5cb15287f99340be.png)

While it might seem ridiculous to correlate a function with itself, there are a number of uses for autocorrelation that will be discussed later. Autocorrelation satisfies several important properties:

  1. The maximum value of the autocorrelation always occurs at _t = 0_. The function always decreases (or stays constant) as _t_ approaches infinity.
  2. Autocorrelation is symmetric about the _x_ axis.

### Crosscorrelation

Cross correlation is every instance of correlation that is not considered "autocorrelation". In general, crosscorrelation occurs when the function arguments to the correlation are not equal. Crosscorrelation is used to find the similarity between two signals.

### Example: RADAR

RADAR is a system that uses pulses of electromagnetic waves to determine the position of a distant object. RADAR operates by sending out a signal, and then listening for echos. If there is an object in range, the signal will bounce off that object and return to the RADAR station. The RADAR will then take the cross correlation of two signals, the sent signal and the received signal. A spike in the cross correlation signal indicates that an object is present, and the location of the spike indicates how much time has passed (and therefore how far away the object is).

**[Signals and Systems](/wiki/Signals_and_Systems)**

Noise is an unfortunate phenomenon that is the greatest single enemy of an electrical engineer. Without noise, digital communication rates would increase almost to infinity.

## White Noise

White Noise, or Gaussian Noise is called white because it affects all the frequency components of a signal equally. We don't talk about Frequency Domain analysis till a later chapter, but it is important to know this terminology now.

## Colored Noise

Colored noise is different from white noise in that it affects different frequency components differently. For example, Pink Noise is random noise with an equal amount of power in each frequency octave band.

## White Noise and Autocorrelation

White Noise is completely random, so it would make intuitive sense to think that White Noise has zero autocorrelation. As the noise signal is time shifted, there is no correlation between the values. In fact, there is no correlation at all until the point where t = 0, and the noise signal perfectly overlaps itself. At this point, the correlation spikes upward. In other words, the autocorrelation of noise is an [Impulse Function](/w/index.php?title=Signals_and_Systems/Engineering_Functions/Impulse_Function&action=edit&redlink=1) centered at the point t = 0.

    ![\\mathcal{C}\[n\(t\), n\(t\)\] = \\delta\(t\)](//upload.wikimedia.org/math/3/1/b/31b1a3b2eb24f8a097e739e927bbe7ed.png)

Where n(t) is the noise signal.

## Noise Power

Noise signals have a certain amount of energy associated with them. The more energy and transmitted power that a noise signal has, the more interference the noise can cause in a transmitted data signal. We will talk more about the power associated with noise in later chapters.

## Thermal Noise

Thermal noise is a fact of life for electronics. As components heat up, the resistance of resistors change, and even the capacitance and inductance of energy storage elements can be affected. This change amounts to noise in the circuit output. In this chapter, we will study the effects of thermal noise.

The _thermal noise_ or _white noise_ or _Johnson noise_ is the random noise which is generated in a resistor or the resistive component of a complex impedance due to rapid and random motion of the molecules, atoms and electrons. According to the kinetic theory of thermodynamics, the temperature of a particle denotes its internal kinetic energy. This means that the temperature of a body expresses the rms value of the velocity of motion of the particles in a body. As per this kinetic theory, the kinetic energy of these particles becomes approximately zero (i.e. zero velocity) at absolute zero. Therefore, the noise power produced in a resistor is proportional to its absolute temperature. Also the noise power is proportional to the bandwidth over which the noise is measured. Therefore the expression for maximum noise power output of a resistor may be given as:

    ![Pn=k \\cdot T \\cdot B](//upload.wikimedia.org/math/0/6/c/06cc5e8f70a7a083e6d43039d25cce5e.png)

where

    k is Boltzmann's constant
    T is the absolute temperature, in Kelvin degrees
    B is the bandwidth of interest, in Hertz.

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Periodic Signals

A signal is a periodic signal if it completes a pattern within a measurable time frame, called a period and repeats that pattern over identical subsequent periods. The completion of a full pattern is called a cycle. A period is defined as the amount of time (expressed in seconds) required to complete one full cycle. The duration of a period represented by T, may be different for each signal but it is constant for any given periodic signal.

## Terminology

We will discuss here some of the common terminology that pertains to a periodic function. Let _g(t)_ be a periodic function satisfying _g(t + T) = g(t)_ for all _t_.

### Period

The **period** is the smallest value of _T_ satisfying _g(t + T) = g(t)_ for all _t_. The period is defined so because if _g(t + T) = g(t)_ for all _t_, it can be verified that _g(t + T') = g(t)_ for all _t_ where _T' = 2T, 3T, 4T, ..._ In essence, it's the smallest amount of time it takes for the function to repeat itself. If the period of a function is finite, the function is called "periodic". Functions that never repeat themselves have an infinite period, and are known as "aperiodic functions".

The period of a periodic waveform will be denoted with a capital _T_. The period is measured in seconds.

### Frequency

The frequency of a periodic function is the number of complete cycles that can occur per second. Frequency is denoted with a lower-case _f_. It is defined in terms of the period, as follows:

    ![f = \\frac{1}{T}](//upload.wikimedia.org/math/c/f/5/cf56377ea780a8ce1586d2abed17482c.png)

Frequency has units of _hertz_ or cycle per second.

### Radial Frequency

The radial frequency is the frequency in terms of radians. it is defined as follows:

    ![\\omega = 2 \\pi f](//upload.wikimedia.org/math/e/e/f/eefe9093ec365c277ea859d088715133.png)

### Amplitude

The amplitude of a given wave is the value of the wave at that point. Amplitude is also known as the "Magnitude" of the wave at that particular point. There is no particular variable that is used with amplitude, although capital A, capital M and capital R are common.

The amplitude can be measured in different units, depending on the signal we are studying. In an electric signal the amplitude will typically be measured in volts. In a building or other such structure, the amplitude of a vibration could be measured in meters.

### Continuous Signal

A continuous signal is a "smooth" signal, where the signal is defined over a certain range. For example, a sine function is a continuous signal, as is an exponential function or a constant function. A portion of a sine signal over a range of time 0 to 6 seconds is also continuous. Examples of functions that are not continuous would be any discrete signal, where the value of the signal is only defined at certain intervals.

### DC Offset

A _DC Offset_ is an amount by which the average value of the periodic function is not centered around the _x_-axis.

A periodic signal has a DC offset component if it is not centered about the _x_-axis. In general, the DC value is the amount that must be subtracted from the signal to center it on the _x_-axis. by definition:

    ![A_0 = \(1/T\)*\\int_{-T/2}^{T/2} f\(x\)dx](//upload.wikimedia.org/math/1/d/f/1dfdafb0178f544c9ea4540a1a40c14d.png)

With _A0_ being the DC offset. If _A0 = 0_, the function is centered and has no offset.

### Half-wave Symmetry

To determine if a signal with period 2_L_ has half-wave symmetry, we need to examine a single period of the signal. If, when shifted by half the period, the signal is found to be the negative of the original signal, then the signal has half-wave symmetry. That is, the following property is satisfied:

    

    ![f \(t-L\) = - f \(t\)\\,](//upload.wikimedia.org/math/6/1/a/61a00ab552b6100272a58fb448899967.png)

![Half-wave Symmetry.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/21/Half-wave_Symmetry.svg/600px-Half-wave_Symmetry.svg.png)

Half-wave symmetry implies that the second half of the wave is exactly opposite to the first half. A function with half-wave symmetry does not have to be even or odd, as this property requires only that the shifted signal is opposite, and this can occur for any temporal offset. However, it does require that the DC offset is zero, as one half must exactly cancel out the other. If the whole signal has a DC offset, this cannot occur, as when one half is added to the other, the offsets will add, not cancel.

Note that if a signal is symmetric about the the half-period point, it is _not_ necessarily half-wave symmetric. An example of this is the function _t_3, periodic on [-1,1), which has no DC offset and odd symmetry about _t_=0. However, when shifted by 1, the signal is _not_ opposite to the original signal.

### Quarter-Wave Symmetry

If a signal has the following properties, it is said to quarter-wave symmetric:

  * It is half-wave symmetric.
  * It has symmetry (odd or even) about the quarter-period point (i.e. at a distance of L/2 from an end or the centre).

![Quarter-wave Symmetry Even.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Quarter-wave_Symmetry_Even.svg/400px-Quarter-wave_Symmetry_Even.svg.png)

![Quarter-wave Symmetry Odd.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/38/Quarter-wave_Symmetry_Odd.svg/400px-Quarter-wave_Symmetry_Odd.svg.png)

**Even Signal with Quarter-Wave Symmetry**
**Odd Signal with Quarter-Wave Symmetry**

Any quarter-wave symmetric signal can be made even or odd by shifting it up or down the time axis. A signal does not have to be odd or even to be quarter-wave symmetric, but in order to find the quarter-period point, the signal will need to be shifted up or down to make it so. Below is an example of a quarter-wave symmetric signal (red) that does not show this property without first being shifted along the time axis (green, dashed):

![Quarter-wave Symmetry Assymmetric.svg](//upload.wikimedia.org/wikipedia/commons/thumb/7/71/Quarter-wave_Symmetry_Assymmetric.svg/400px-Quarter-wave_Symmetry_Assymmetric.svg.png)

**Asymmetric Signal with Quarter-Wave Symmetry**

An equivalent operation is shifting the interval the function is defined in. This may be easier to reconcile with the formulae for Fourier series. In this case, the function would be redefined to be periodic on (_-L+Δ_,_L+Δ_), where Δ is the shift distance.

### Discontinuities

**Discontinuities** are an artifact of some signals that make them difficult to manipulate for a variety of reasons.

In a graphical sense, a periodic signal has discontinuities whenever there is a vertical line connecting two adjacent values of the signal. In a more mathematical sense, a periodic signal has discontinuities anywhere that the function has an undefined (or an infinite) derivative. These are also places where the function does not have a limit, because the values of the limit from both directions are not equal.

## Common Periodic Signals

There are some common periodic signals that are given names of their own. We will list those signals here, and discuss them.

### Sinusoid

The quintessential periodic waveform. These can be either Sine functions, or Cosine Functions.

### Square Wave

The square wave is exactly what it sounds like: a series of rectangular pulses spaced equidistant from each other, each with the same amplitude.

### Triangle Wave

The triangle wave is also exactly what it sounds like: a series of triangles. These triangles may touch each other, or there may be some space in between each wavelength.

### Example: Sinusoid, Square, and Triangle Waves

Here is an image that shows some of the common periodic waveforms, a triangle wave, a square wave, a sawtooth wave, and a sinusoid.

![Waveforms.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Waveforms.png/400px-Waveforms.png)

## Classifications

Periodic functions can be classified in a number of ways. one of the ways that they can be classified is according to their symmetry. A function may be Odd, Even, or Neither Even nor Odd. All periodic functions can be classified in this way.

### Even

Functions are even if they are symmetrical about the _y_-axis.

    ![f\(x\) = f\(-x\)](//upload.wikimedia.org/math/0/5/2/05267a29229b9a7b24f79e187032c08b.png)

For instance, a cosine function is an even function.

### Odd

A function is odd if it is inversely symmetrical about the _y_-axis.

    ![f\(x\) = -f\(-x\)](//upload.wikimedia.org/math/e/3/b/e3b7d1063b28c9a487d9ae7b4b396622.png)

The Sine function is an odd function.

### Neither Even nor Odd

Some functions are neither even nor odd. However, such functions can be written as a sum of even and odd functions. Any function _f(x)_ can be expressed as a sum of an odd function and an even function:

    ![ f\(x\) = 1/2 \\{f\(x\) + f\(-x\)\\} + 1/2 \\{f\(x\) - f\(-x\)\\} ](//upload.wikimedia.org/math/b/5/8/b589cf1b6d04ea25a5ed49cd245c5705.png)

We leave it as an exercise to the reader to verify that the first component is even and that the second component is odd. Note that the first term is zero for odd functions and that the second term is zero for even functions.

# Frequency Representation

**[Signals and Systems](/wiki/Signals_and_Systems)**

## The Fourier Series

The Fourier Series is a specialized tool that allows for any periodic signal (subject to certain conditions) to be decomposed into an infinite sum of everlasting sinusoids. This may not be obvious to many people, but it is demonstrable both mathematically and graphically. Practically, this allows the user of the Fourier Series to understand a periodic signal as the sum of various frequency components.

## Rectangular Series

The rectangular series represents a signal as a sum of sine and cosine terms. The type of sinusoids that a periodic signal can be decomposed into depends solely on the qualities of the periodic signal.

### Calculations

If we have a function f(x), that is periodic with a period of 2_L_, we can decompose it into a sum of sine and cosine functions as such:

    ![f\(x\) = \\frac{1}{2}a_0 + \\sum_{n=1}^\\infty\\left\[a_n\\cos\\left\( \\frac{n \\pi x}{L} \\right\)+b_n\\sin\\left\( \\frac{n \\pi x}{L} \\right\)\\right\]](//upload.wikimedia.org/math/d/e/6/de696eb65c2756be315a0beea6f68b54.png)

The coefficients, a and b can be found using the following integrals:

    ![a_n = \\frac{1}{L}\\int_{-L}^L f\(x\)\\cos \\left\( \\frac{n \\pi x}{L} \\right\)\\,dx](//upload.wikimedia.org/math/b/2/1/b2131ceabd7cd377433f88aa7cb87e2d.png)

    ![b_n = \\frac{1}{L}\\int_{-L}^L f\(x\)\\sin \\left\( \\frac{n \\pi x}{L} \\right\)\\,dx](//upload.wikimedia.org/math/6/0/2/602a9f572709dcb274bc5944a430a88c.png)

"n" is an integer variable. It can assume positive integer numbers (1, 2, 3, etc...). Each value of n corresponds to values for A and B. The sinusoids with magnitudes A and B are called _harmonics_. Using Fourier representation, a harmonic is an atomic (indivisible) component of the signal, and is said to be _orthogonal_.

When we set n = 1, the resulting sinusoidal frequency value from the above equations is known as the **fundamental frequency**. The fundamental frequency of a given signal is the most powerful sinusoidal component of a signal, and is the most important to transmit faithfully. Since n takes on integer values, all other frequency components of the signal are integer multiples of the fundamental frequency.

If we consider a signal in time, the period, _T0_ is analagous to 2_L_ in the above definition. The fundamental frequency is then given by:

    

    ![f_0=\\frac{1}{T_0}](//upload.wikimedia.org/math/3/e/f/3efe6827d99d0a7ebdef98d7e95d3001.png)

And the fundamental angular frequency is then:

    

    ![\\omega_0=\\frac{2 \\pi}{T_0}](//upload.wikimedia.org/math/c/a/7/ca778ac66dfa92a1b289e69f342e451b.png)

Thus we can replace every ![\\left\( \\frac{n \\pi x}{L} \\right\)](//upload.wikimedia.org/math/2/2/d/22dfffafd95e9520ebea2384b73e8846.png) term with a more concise ![\(n \\omega_0 x\)](//upload.wikimedia.org/math/6/8/a/68a9594c297357b46849641711a8a12e.png).

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

The fundamental frequency is the repetition frequency of the periodic signal

### Signal Properties

Various signal properties translate into specific properties of the Fourier series. If we can identify these properties before hand, we can save ourselves from doing unnecessary calculations.

#### DC Offset

If the periodic signal has a DC offset, then the Fourier Series of the signal will include a _zero frequency component_, known as the **DC component**. If the signal does not have a DC offset, the DC component has a magnitude of 0. Due to the linearity of the Fourier series process, if the DC offset is removed, we can analyse the signal further (e.g. for symmetry) and add the DC offset back at the end.

#### Odd and Even Signals

If the signal is even (symmetric over the reference vertical axis), it is composed of cosine waves. If the signal is odd (anti-symmetric over the reference vertical axis), it is composed out of sine waves. If the signal is neither even nor odd, it is composed out of both sine and cosine waves.

#### Discontinuous Signal

If the signal is discontinuous (i.e. it has "jumps"), the magnitudes of each harmonic _n_ will fall off proportionally to 1/_n_.

#### Discontinuous Derivative

If the signal is continuous but the derivative of the signal is discontinuous, the magnitudes of each harmonic _n_ will fall off proportionally to 1/_n2_.

#### Half-Wave Symmetry

If a signal has half-wave symmetry, there is no DC offset, and the signal is composed of sinusoids lying on only the _odd harmonics_ (1, 3, 5, etc...). This is important because a signal with half-wave symmetry will require twice as much bandwidth to transmit the same number of harmonics as a signal without:

    

    ![a_0=0\\,](//upload.wikimedia.org/math/9/f/4/9f4cb29f148273f632379cd339a319d0.png)

    

    ![a_n=
\\begin{cases} 
  0,  & \\mbox{if }n\\mbox{ is even} \\\\
  \\frac{2}{L}\\int_0^L f\(x\) \\cos\(n \\omega_0 x\) dx, & \\mbox{if }n\\mbox{ is odd} 
\\end{cases}
](//upload.wikimedia.org/math/e/a/7/ea7b3b1451a107a82dbdcac3dd84c8ed.png)

    

    ![b_n=
\\begin{cases} 
  0,  & \\mbox{if }n\\mbox{ is even} \\\\
  \\frac{2}{L}\\int_0^L f\(x\) \\sin\(n \\omega_0 x\) dx, & \\mbox{if }n\\mbox{ is odd} 
\\end{cases}
](//upload.wikimedia.org/math/a/a/2/aa2cfd2698f32c2e227dfd791e7cdeff.png)

#### Quarter-Wave Symmetry of an Even Signal

If a 2_L_-periodic signal has quarter-wave symmetry, then it must also be half-wave symmetric, so there are no even harmonics. If the signal is even and has quarter-wave symmetry, we only need to integrate the first quarter-period:

    

    ![a_n=
\\begin{cases} 
  0,  & \\mbox{if }n\\mbox{ is even} \\\\
  \\frac{4}{L}\\int_0^{L/2} f\(x\) \\cos\(n \\omega_0 x\) dx, & \\mbox{if }n\\mbox{ is odd} 
\\end{cases}
](//upload.wikimedia.org/math/9/4/5/9459792a17614659e0eab8c3ec97acac.png)

We also know that because the signal is half-wave symmetric, there is no DC offset:

    

    ![a_0=0\\,](//upload.wikimedia.org/math/9/f/4/9f4cb29f148273f632379cd339a319d0.png)

Because the signal is even, there are are no sine terms:

    

    ![b_n = 0\\,](//upload.wikimedia.org/math/7/7/1/771bdfa20c2a69eee3fedd6c5df09c6b.png)

#### Quarter-Wave Symmetry of an Odd Signal

If the signal is odd, and has quarter wave symmetry, then we can say:

Because the signal is odd, there are no cosine terms:

    

    ![a_0=0\\,](//upload.wikimedia.org/math/9/f/4/9f4cb29f148273f632379cd339a319d0.png)
    ![a_n=0\\,](//upload.wikimedia.org/math/9/3/8/9388d9e31b3c8795445e80896411277f.png)

There are no even sine terms due to half-wave symmetry, and we only need to integrate the first quarter-period due to quarter-wave symmetry.

    

    ![b_n=
\\begin{cases} 
  0,  & \\mbox{if }n\\mbox{ is even} \\\\
  \\frac{4}{L}\\int_0^{L/2} f\(x\) \\sin\(n \\omega_0 x\) dx, & \\mbox{if }n\\mbox{ is odd} 
\\end{cases}
](//upload.wikimedia.org/math/d/a/4/da4ed98a784d2db02759ca626c9749f7.png)

### Summary

By convention, the coefficients of the cosine components are labeled "_a_", and the coefficients of the sine components are labeled with a "_b_". A few important facts can then be mentioned:

  * If the function has a DC offset, _a0_ will be non-zero. There is no _B0_ term.
  * If the signal is even, all the _b_ terms are 0 (no sine components).
  * If the signal is odd, all the _a_ terms are 0 (no cosine components).
  * If the function has half-wave symmetry, then all the even coefficients (of sine and cosine terms) are zero, and we only have to integrate half the signal.
  * If the function has quarter-wave symmetry, we only need to integrate a quarter of the signal.
  * The Fourier series of a sine or cosine wave contains _a single harmonic_ because a sine or cosine wave cannot be decomposed into other sine or cosine waves.
  * We can check a series by looking for discontinuities in the signal or derivative of the signal. If there are discontinuities, the harmonics drop off as 1/_n_, if the derivative is discontinuous, the harmonics drop off as 1/_n_2.

## Polar Series

The Fourier Series can also be represented in a polar form which is more compact and easier to manipulate.

If we have the coefficients of the rectangular Fourier Series, _a_ and _b_ we can define a coefficient _x_, and a phase angle _φ_ that can be calculated in the following manner:

    ![x_0 = a_0 \\,](//upload.wikimedia.org/math/c/b/a/cba988ab2e0f3782b61f1a03ce826d37.png)

    ![x_n = \\sqrt{a_n^2 + b_n^2}](//upload.wikimedia.org/math/0/3/6/036f97fe16717688861e4fbe546f4785.png)

    ![\\phi_n = \\tan^{-1}\\left\(\\frac{b_n}{a_n}\\right\)](//upload.wikimedia.org/math/e/7/d/e7ddf78160d390727a7225a419ab9712.png)

We can then define _f(x)_ in terms of our new Fourier representation, by using a **cosine basis function:**

    ![f\(x\) = x_0 + \\sum_{n=1}^\\infty x_n\\cos\(n\\omega x - \\phi_n\)](//upload.wikimedia.org/math/6/6/b/66bfed92ecf3e71bc3a73e9457dd0a2d.png)

The use of a cosine basis instead of a sine basis is an arbitrary distinction, but is important nonetheless. If we wanted to use a sine basis instead of a cosine basis, we would have to modify our equation for φ, above.

### Proof of Equivalence

We can show explicitly that the polar cosine basis function is equivalent to the "Cartesian" form with a sine and cosine term.

    ![f\(x\) = x_0 + \\sum_{n=1}^\\infty x_n\\cos\(n\\omega x - \\phi_n\)](//upload.wikimedia.org/math/6/6/b/66bfed92ecf3e71bc3a73e9457dd0a2d.png)

By the double-angle formula for cosines:

    ![f\(x\) = x_0 + \\sum_{n=1}^\\infty x_n \\left \[ \\cos\(n\\omega x\)\\cos\(-\\phi_n\)-\\sin\(n\\omega x\)\\sin\(-\\phi_n\) \\right\]](//upload.wikimedia.org/math/8/d/5/8d5edbe0cd2cbeff0142c68d9a151b56.png)

By the odd-even properties of cosines and sines:

    ![f\(x\) = x_0 + \\sum_{n=1}^\\infty x_n \\left \[ \\cos\(n\\omega x\)\\cos\(\\phi_n\)+\\sin\(n\\omega x\)\\sin\(\\phi_n\) \\right\]](//upload.wikimedia.org/math/2/b/5/2b50b9d422a831331f2cc2d96e292499.png)

Grouping the coefficents:

    ![f\(x\) = x_0 + \\sum_{n=1}^\\infty \[x_n \\cos\(\\phi_n\) \\cos\(n\\omega x\) + x_n \\sin\(\\phi_n\)\\sin\(n\\omega x\)\]](//upload.wikimedia.org/math/9/a/7/9a77bba14cab83d5423c672a09c76b15.png)

This is equivalent to the rectangular series given that:

    ![a_n=x_n \\cos\(\\phi_n\)\\,](//upload.wikimedia.org/math/8/2/1/8213a224c30019953a535133dd27a95d.png)
    ![b_n=x_n \\sin\(\\phi_n\)\\,](//upload.wikimedia.org/math/5/5/0/5508455cdbaadcfe48e006e397d11d7a.png)

Dividing, we get:

    ![\\frac{b_n}{a_n}=\\frac{x_n \\sin\(\\phi_n\)}{x_n \\cos\(\\phi_n\)}=\\tan\(\\phi_n\)](//upload.wikimedia.org/math/2/e/2/2e2ac5c738b8630f86f6648606156adc.png)

    ![\\phi_n = \\tan^{-1}\\left\( \\frac{b_n}{a_n} \\right\)](//upload.wikimedia.org/math/e/7/d/e7ddf78160d390727a7225a419ab9712.png)

Squaring and adding, we get:

    ![a_n^2+b_n^2=x_n^2 \\left\[ \\cos^2\(\\phi_n\) + sin^2\(\\phi_n\) \\right\]](//upload.wikimedia.org/math/8/1/a/81a9883b00ac2bba7fd9fc3f42bd6df7.png)
    ![a_n^2+b_n^2=x_n^2 \\,](//upload.wikimedia.org/math/e/6/7/e6778ba7410c67257a953729a7797b73.png)
    ![x_n=\\sqrt{a_n^2+b_n^2}](//upload.wikimedia.org/math/0/3/6/036f97fe16717688861e4fbe546f4785.png)

Hence, given the above definitions of _xn_ and _φn_, the two are equivalent. For a sine basis function, just use the sine double-angle formula. The rest of the process is very similar.

## Exponential Series

Using Eulers Equation, and a little trickery, we can convert the standard Rectangular Fourier Series into an exponential form. Even though complex numbers are a little more complicated to comprehend, we use this form for a number of reasons:

  1. Only need to perform one integration
  2. A single exponential can be manipulated more easily than a sum of sinusoids
  3. It provides a logical transition into a further discussion of the Fourier Transform.

We can construct the exponential series from the rectangular series using Euler's formulae:

    ![\\sin\(x\)=\\frac{-i}{2}\\left\( e^{ix} - e^{-ix} \\right\); \\quad \\quad \\cos\(x\)=\\frac{1}{2}\\left\( e^{ix} + e^{-ix} \\right\)](//upload.wikimedia.org/math/9/8/8/98840f925aeb5cda78d32d5310cdc073.png)

The rectangular series is given by:

    ![f\(x\) = a_0 + \\sum_{n=1}^{\\infty} \\left\[a_n \\cos\(n \\omega x \)+ b_n \\sin\(n \\omega x\)\\right\]](//upload.wikimedia.org/math/5/7/d/57ddeaa6a337a47f29f0594c006313e5.png)

Substituting Euler's formulae:

    ![f\(x\) = a_0 + \\sum_{n=1}^{\\infty} \\left \[ \\frac{a_n}{2} e^{i n \\omega x} + \\frac{a_n}{2} e^{- i n \\omega x} - \\frac{i b_n}{2} e^{i n \\omega x} + \\frac{ib _n}{2} e^{- i n \\omega x } \\right\]](//upload.wikimedia.org/math/f/1/5/f15ee0c41ed227c4966664af685a8239.png)

Splitting into "positive _n_" and "negative _n_" parts gives us:

    ![f\(x\) = a_0 + \\sum_{n=1}^{\\infty} \\left \[ \\frac{a_n}{2} e^{i n \\omega x} - \\frac{i b_n}{2} e^{i n \\omega x} \\right\] + 
\\sum_{n=-\\infty}^{-1} \\left \[ \\frac{a_{-n}}{2} e^{i n \\omega x}  + \\frac{ib _{-n}}{2} e^{i n \\omega x } \\right\]](//upload.wikimedia.org/math/4/a/3/4a3d6d5b5d0d5a448d47280d79906b57.png)

    ![f\(x\) = a_0 + \\sum_{n=1}^{\\infty}\\frac{1}{2} \(a_n-i b_n\) e^{i n \\omega x} + 
\\sum_{n=-\\infty}^{-1} \\frac{1}{2} \(a_{-n}+i b_{-n}\) e^{i n \\omega x}](//upload.wikimedia.org/math/0/7/3/073234ff6d0a574103c48cb64a1faa99.png)

We now collapse this into a single expression:  


[Exponential Fourier Series]

    ![f\(x\) = \\sum_{n=-\\infty}^{\\infty} c_n e^{i n \\omega x}](//upload.wikimedia.org/math/0/3/a/03a11991e4aad3c7563a506de1fbd91a.png)

Where we can relate _cn_ to _an_ and _bn_ from the rectangular series:

    ![c_n =
\\begin{cases}
    \\frac{1}{2} \(a_{-n}+i b_{-n}\), & n<0\\\\
    a_0, & n=0\\\\
   \\frac{1}{2} \(a_n-i b_n\), & n>0
\\end{cases}
](//upload.wikimedia.org/math/e/8/e/e8e6bb0ac7419b35d8c0d5ded750ab5e.png)

This is the exponential Fourier series of _f(x)_. Note that _cn_ is, in general, complex. Also note that:

    

  * ![\\Re\(c_n\)=\\Re\(c_{-n}\)](//upload.wikimedia.org/math/6/1/c/61c188caef62c53abdbd4ae744033c93.png)
  * ![\\Im\(c_n\)=-\\Im\(c_{-n}\)](//upload.wikimedia.org/math/4/1/3/413040143b6a0960a78dedbf6c8e9fd2.png)

We can directly calculate _cn_ for a _2L_-periodic function:

    ![c_n = \\frac{1}{2L} \\int_{-L}^{L} f\(x\) e^{-i n \\pi x / L } dx](//upload.wikimedia.org/math/c/4/8/c48321abd6061e2acd393c0a1e85a41f.png)

This can be related to the _an_ and _bn_ definitions in the rectangular form using Euler's formula: ![e^{ix}=\\cos{x} + i \\sin{x}](//upload.wikimedia.org/math/b/4/7/b47914060bfaa315af4cf782746ce38d.png).

## Negative Frequency

The Exponential form of the Fourier series does something that is very interesting in comparison to the rectangular and polar forms of the series: it allows for negative frequency components. To this effect, the Exponential series is often known as the "Bi-Sided Fourier Series", because the spectrum has both a positive and negative side. This, of course, prods the question, "What is a negative Frequency?"

Negative frequencies seem counter-intuitive, and many people would be quick to dismiss them as being nonsense. However, a further study of electrical engineering (which is outside the scope of this book) will provide many examples of where negative frequencies play a very important part in modeling and understanding certain systems. While it may not make much sense initially, negative frequencies need to be taken into account when studying the Fourier Domain.

Negative frequencies follow the important rule of symmetry: For real signals, negative frequency components are _always_ mirror-images of the positive frequency components. Once this rule is learned, drawing the negative side of the spectrum is a trivial matter once the positive side has been drawn.

However, when looking at a bi-sided spectrum, the effect of negative frequencies needs to be taken into account. If the negative frequencies are mirror-images of the positive frequencies, and if a negative frequency is analogous to a positive frequency, then the effect of adding the negative components into a signal is the same as doubling the positive components. This is a major reason why the exponential Fourier series coefficients are multiplied by one-half in the calculation: because half the coefficient is at the negative frequency.

Note: The concept of negative frequency is actually unphysical. Negative frequencies occur in the spectrum only when we are using the exponential form of the Fourier series. To represent a cosine function, Euler's relationship tells us that there are both positive and negative exponential required. Why? Because to represent a real function, like cosine, the imaginary components present in exponential notation must vanish. Thus, the negative exponent in Euler's formula makes it appear that there are negative frequencies, when in fact, there are not.

### Example: Ceiling Fan

Another way to understand negative frequencies is to use them for mathematical completeness in describing the physical world. Suppose we want to describe the rotation of a ceiling fan directly above our head to a person sitting nearby. We would say "it rotates at 60 RPM in an anticlockwise direction". However, if we want to describe its rotation to a person watching the fan from above then we would say "it rotates at 60 RPM in a clockwise direction". If we customarily use a negative sign for clockwise rotation, then we would use a positive sign for anticlockwise rotation. We are describing the same process using both positive and negative signs, depending on the reference we choose.

## Bandwidth

Bandwidth is the name for the frequency range that a signal requires for transmission, and is also a name for the frequency capacity of a particular transmission medium. For example, if a given signal has a bandwidth of 10kHz, it requires a transmission medium with a bandwidth of _at least_ 10kHz to transmit without attenuation.

Bandwidth can be measured in either Hertz or Radians per Second. Bandwidth is only a measurement of the positive frequency components. All real signals have negative frequency components, but since they are only mirror images of the positive frequency components, they are not included in bandwidth calculations.

### Bandwidth Concerns

It's important to note that most periodic signals are composed of _an infinite sum_ of sinusoids, and therefore require an infinite bandwidth to be transmitted without distortion. Unfortunately, no available communication medium (wire, fiber optic, wireless) have an infinite bandwidth available. This means that certain harmonics will pass through the medium, while other harmonics of the signal will be attenuated.

Engineering is all about trade-offs. The question here is "How many harmonics do I _need_ to transmit, and how many can I safely get rid of?" Using fewer harmonics leads to reduced bandwidth requirements, but also results in increased signal distortion. These subjects will all be considered in more detail in the future.

### Pulse Width

Using our relationship between period and frequency, we can see an important fact:

    ![f_0 = \\frac{1}{T}](//upload.wikimedia.org/math/f/2/6/f26422db29eca70d860c4f253d4069e6.png)

As the period of the signal _decreases_, the fundamental frequency increases. This means that each additional harmonic will be spaced further apart, and transmitting the same number of harmonics will now require more bandwidth! In general, there is a rule that must be followed when considering periodic signals: _Shorter periods in the time domain require more bandwidth in the frequency domain. Signals that use less bandwidth in the frequency domain will require longer periods in the time domain._

## Examples

### Example: x3

Let's consider a repeating pattern based on a cubic polynomial:

    ![f \\left\( x \\right\)=x^3, \\quad -\\pi \\le x < \\pi \\,](//upload.wikimedia.org/math/1/6/9/1691ee02ee8575413a1988084d664d15.png)

and _f(x)_ is 2π periodic:

![XCubed Periodic \(-pi, pi\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e3/XCubed_Periodic_%28-pi%2C_pi%29.svg/720px-XCubed_Periodic_%28-pi%2C_pi%29.svg.png)

By inspection, we can determine some characteristics of the Fourier Series:

  * The function is odd, so the cosine coefficients (_an_) will all be zero.
  * The function has no DC offset, so there will be no constant term (_a0_).
  * There are discontinuities, so we expect a 1/_n_ drop-off.

We therefore just have to compute the _bn_ terms. These can be found by the following formula:

    ![b_n  = {1 \\over \\pi }\\int\\limits_{ - \\pi }^\\pi  {f\\left\( x \\right\)\\sin \\left\( {nx} \\right\)dx}](//upload.wikimedia.org/math/3/4/9/34994ec4e8ebeefde406018159e89854.png)

Substituting in the desired function gives

    ![b_n  = {1 \\over \\pi }\\int\\limits_{ - \\pi }^\\pi  {x^3 \\sin \\left\( {nx} \\right\)dx} ](//upload.wikimedia.org/math/8/3/a/83ab457045846f0daad268ab5442870f.png)

Integrating by parts,

    ![b_n  = {1 \\over \\pi }\\left\( {\\left\[ { - x^3 {{\\cos \\left\( {nx} \\right\)} \\over n}} \\right\]_{-\\pi} ^\\pi   + \\int\\limits_{ - \\pi }^\\pi  {3x^2 {{\\cos \\left\( {nx} \\right\)} \\over n}dx} } \\right\)](//upload.wikimedia.org/math/0/a/c/0ac5dea08f42a241e3751f67c2276839.png)

Bring out factors:

    ![b_n  = {1 \\over {n\\pi }}\\left\( {\\left\[ { - x^3 \\cos \\left\( {nx} \\right\)} \\right\]_{-\\pi} ^\\pi   + 3\\int\\limits_{ - \\pi }^\\pi  {x^2 \\cos \\left\( {nx} \\right\)dx} } \\right\)](//upload.wikimedia.org/math/8/d/c/8dc02d43e20db08708ae2b20915da0d5.png)

Substitute limits into the square brackets and integrate by parts again:

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - \\left\( {\\pi ^3 \\cos \\left\( {n\\pi } \\right\) + \\pi ^3 \\cos \\left\( { - n\\pi } \\right\)} \\right\) + 3\\left\( {\\left\[ {x^2 {{\\sin \\left\( {nx} \\right\)} \\over n}} \\right\]_{-\\pi} ^\\pi   - \\int\\limits_{ - \\pi }^\\pi  {2 x{{\\sin \\left\( {nx} \\right\)} \\over n}dx} } \\right\)} \\right\)](//upload.wikimedia.org/math/4/9/a/49a6026a84b8ed25363e7dbcf18355ce.png)

Recall that _cos(x)_ is an even function, so _cos(-nπ) = cos(nπ)_. Also bring out the factor of _1/n_ from the integral:

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - \\left\( {\\pi ^3 \\cos \\left\( {n\\pi } \\right\) + \\pi ^3 \\cos \\left\( {n\\pi } \\right\)} \\right\) + {3 \\over n}\\left\( {\\left\[ {x^2 \\sin \\left\( {nx} \\right\)} \\right\]_{-\\pi} ^\\pi   - 2\\int\\limits_{ - \\pi }^\\pi  {x\\sin \\left\( {nx} \\right\)dx} } \\right\)} \\right\)](//upload.wikimedia.org/math/d/1/9/d1994248b12beead45ebba6352728db9.png)

Simplifying the left part, and substituting in limits in the square brackets,

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - 2\\pi ^3 \\cos \\left\( {n\\pi } \\right\) + {3 \\over n}\\left\( {\\left\( {\\pi ^2 \\sin \\left\( {n\\pi } \\right\) - \\pi \\sin \\left\( { - n\\pi } \\right\)} \\right\) - 2\\int\\limits_{ - \\pi }^\\pi  {x\\sin \\left\( {nx} \\right\)dx} } \\right\)} \\right\)](//upload.wikimedia.org/math/7/6/7/76743c8863d7616e6cd8452713e8f3e0.png)

Recall that _sin(nπ)_ is always equal to zero for integer _n_:

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - 2\\pi ^3 \\cos \\left\( {n\\pi } \\right\) + {3 \\over n}\\left\( {0 - 2\\int\\limits_{ - \\pi }^\\pi  {x\\sin \\left\( {nx} \\right\)dx} } \\right\)} \\right\)](//upload.wikimedia.org/math/4/1/1/4117421cd159daf9b3faaddc40670d3b.png)

Bringing out factors and integrating by parts:

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - 2\\pi ^3 \\cos \\left\( {n\\pi } \\right\) - {6 \\over n}\\left\[ {-\\left\[ {x{{\\cos \\left\( {nx} \\right\)} \\over n}} \\right\]_{-\\pi} ^\\pi   + \\int\\limits_{ - \\pi }^\\pi  {{{\\cos \\left\( {nx} \\right\)} \\over n}dx} } \\right\]} \\right\)](//upload.wikimedia.org/math/4/4/3/4434865bcc1a702c2908e0fb8588f1ca.png)

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - 2\\pi ^3 \\cos \\left\( {n\\pi } \\right\) - {6 \\over {n^2 }}\\left\[ -{\\left\[ {x\\cos \\left\( {nx} \\right\)} \\right\]_{-\\pi} ^\\pi   + \\int\\limits_{ - \\pi }^\\pi  {\\cos \\left\( {nx} \\right\)dx} } \\right\]} \\right\)](//upload.wikimedia.org/math/3/5/e/35e9da0f3d42f3116e295752ba3d49fc.png)

Solving the now-simple integral and substituting in limits to the square brackets,

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - 2\\pi ^3 \\cos \\left\( {n\\pi } \\right\) - {6 \\over {n^2 }}\\left\[ { - \\left\( {\\pi \\cos \\left\( {n\\pi } \\right\) + \\pi \\cos \\left\( {-n\\pi } \\right\)} \\right\) + \\left\[ {\\sin \\left\( {nx} \\right\)} \\right\]_{-\\pi} ^\\pi  } \\right\]} \\right\)](//upload.wikimedia.org/math/0/6/e/06e3b7e5707befa90c3864ee96b890b3.png)

Since the area under one cycle of a sine wave is zero, we can eliminate the integral. We use the fact that _cos(x)_ is even again to simplify:

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - 2\\pi ^3 \\cos \\left\( {n\\pi } \\right\) - {6 \\over {n^2 }}\\left\[ { - 2\\pi \\cos \\left\( {n\\pi } \\right\) + 0} \\right\]} \\right\)](//upload.wikimedia.org/math/b/e/a/beaaeb2295b4252dc702c3e7a3ce8a7e.png)

Simplifying:

    ![b_n  = {1 \\over {n\\pi }}\\left\( { - 2\\pi ^3 \\cos \\left\( {n\\pi } \\right\) + {{12\\pi } \\over {n^2 }}\\cos \\left\( {n\\pi } \\right\)} \\right\)](//upload.wikimedia.org/math/8/c/e/8ce1603469a73897b0dc6fb262d27ecf.png)

    ![b_n  = {{ - 2\\pi ^2 \\cos \\left\( {n\\pi } \\right\)} \\over n} + {{12\\cos \\left\( {n\\pi } \\right\)} \\over {n^3 }}](//upload.wikimedia.org/math/9/b/b/9bb419bef1678ffe50a81ebd397aceda.png)

    ![b_n  = \\cos \\left\( {n\\pi } \\right\)\\left\( {{{ - 2\\pi ^2 n^2 } \\over {n^3 }} + {{12} \\over {n^3 }}} \\right\)](//upload.wikimedia.org/math/5/1/d/51d9d2fccfbbe8c950b6f96eb3bffd1f.png)

    ![b_n  = {{ - 2\\cos \\left\( {n\\pi } \\right\)} \\over {n^3 }}\\left\( {\\pi ^2 n^2  - 6} \\right\)](//upload.wikimedia.org/math/d/f/e/dfe81d132c1b18508b4c893d16b60012.png)

Now, use the fact that _cos(nπ)_=(-1)_n__:_

    ![b_n  = {{ - 2\\left\( { - 1} \\right\)^n } \\over {n^3 }}\\left\( {\\pi ^2 n^2  - 6} \\right\)](//upload.wikimedia.org/math/9/5/9/9599da02629d15c346ace4eacbc50fc7.png)

This is our final _bn_. We see that we have a approximate 1/_n_ relationship (the constant "6" becomes insignificant as _n_ grows), as we expected. Now, we can find the Fourier approximation according to

    ![f\\left\( x \\right\) = {1 \\over 2}a_0  + \\sum\\limits_{n = 1}^\\infty  {\\left\[ {a_n \\cos \\left\( {nx} \\right\) + b_n \\sin \\left\( {nx} \\right\)} \\right\]}](//upload.wikimedia.org/math/b/c/a/bca7fec769b4fcf3d6eeae113918b4e3.png)

Since all _a_ terms are zero,

    ![f\\left\( x \\right\) = \\sum\\limits_{n = 1}^\\infty  {b_n \\sin \\left\( {nx} \\right\)}](//upload.wikimedia.org/math/a/a/b/aabfce65dbfdd61422cf96f4626d6ed1.png)

So, the Fourier Series approximation of _f(x) = x3_ is:

    ![
f\\left\( x \\right\) = \\sum\\limits_{n = 1}^\\infty  {\\left\[ {{{ - 2\\left\( { - 1} \\right\)^n } \\over {n^3 }}\\left\( {\\pi ^2 n^2  - 6} \\right\)\\sin \\left\( {nx} \\right\)} \\right\]} ](//upload.wikimedia.org/math/e/e/a/eea3ac5e2325fc8cc68ef6b138d6618a.png)

The graph below shows the approximation for the first 7 terms (red) and the first 15 terms (blue). The original function is shown in black.

![XCubed Fourier Series Approximation n=7,15.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/XCubed_Fourier_Series_Approximation_n%3D7%2C15.svg/720px-XCubed_Fourier_Series_Approximation_n%3D7%2C15.svg.png)

### Example: Square Wave

We have the following square wave signal, as a function of voltage, traveling through a communication medium:

![General Square Wave \(Odd, Offset\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/83/General_Square_Wave_%28Odd%2C_Offset%29.svg/720px-General_Square_Wave_%28Odd%2C_Offset%29.svg.png)

We will set the values as follows: _A = 4_ volts, _T = 1_ second. Also, it is given that the width of a single pulse is _T/2_.

Find the rectangular Fourier series of this signal.

First and foremost, we can see clearly that this signal does have a DC value: the signal exists entirely above the horizontal axis. DC value means that we will have to calculate our _a0_ term. Next, we can see that if we remove the DC component (shift the signal downward till it is centered around the horizontal axis), that our signal is an odd signal. This means that we will have _bn_ terms, but no _an_ terms. We can also see that this function has discontinuities and half-wave symmetry. Let's recap:

  1. DC value (must calculate _a0_)
  2. Odd Function (_an = 0_ for _n > 0_)
  3. Discontinuties (terms fall off as 1/_n_)
  4. Half-wave Symmetry (no even harmonics)

Now, we can calculate these values as follows:

    ![a_0 = \\frac{1}{T}\\int_0^T f\(t\)dt](//upload.wikimedia.org/math/8/c/7/8c761dc8d29cc14a6612368acc72dffe.png)
    ![a_0 = \\frac{1}{T}\\int_0^{T/2} 4 dt ](//upload.wikimedia.org/math/0/2/8/02827ff4d383df5785fe46ceb237c937.png)
    ![a_0 = \\frac{1}{T} \\left\[ 4 t \\right\]_0^{T/2}=\\frac{4 \\times T}{T \\times 2}=2](//upload.wikimedia.org/math/c/d/6/cd63f85e19f74458e0e6f389f4f4ce17.png)

This could also have been worked out intuitively, as the signal has a 50% duty-cycle, meaning that the average value is half of the maximum.

Due to the oddness of the function, there are no cosine terms:

    ![a_n = 0 \\quad \\mbox{ for all } n > 0](//upload.wikimedia.org/math/2/8/3/28350ce6bac6ad3c8b70eb12029ce027.png).

Due to the half-wave symmetry, there are only odd sine terms, which are given by:

    ![b_n = \\frac{1}{T/2} \\int_0^T f\(t\) \\sin \\left\( \\frac{2 n \\pi t}{T} \\right\) dt ](//upload.wikimedia.org/math/9/a/a/9aa130a71cb84b3fadba5eaa5917b145.png)
    ![b_n = \\frac{2}{T} \\int_0^{T/2}4 \\sin \\left\( 2 n \\pi t \\right\) dt](//upload.wikimedia.org/math/0/1/6/016cfa1c34cdf9923b46f361f3b3f3b1.png)
    ![b_n = -2 \\left\[ \\frac{4}{2 n \\pi} \\cos \\left\( 2 n \\pi t \\right\) \\right\]_0^{1/2}](//upload.wikimedia.org/math/d/d/8/dd809f8063d5fe4aa61e1f19cf8dcb39.png)
    ![b_n = -2 \\left\[ \\frac{4}{2 n \\pi} \\cos \\left\( \\frac{2n \\pi}{2} \\right\) - \\frac{4}{2 n \\pi} \\cos \\left\(2 n \\pi \\times 0 \\right\) \\right\] ](//upload.wikimedia.org/math/4/a/f/4aff7eac77ad5d7f3f325f6d21626721.png)
    ![b_n = -\\frac{4}{n \\pi} \\left\[\\cos \\left\( n \\pi \\right\) - 1 \\right\] ](//upload.wikimedia.org/math/3/d/b/3db9d70717a5675c22cc14c70bfaf841.png)

Given that cos(_nπ_)=(-1)_n_:

    ![b_n = -\\frac{4 \\left\(\(-1\)^n - 1 \\right\)}{n \\pi} ](//upload.wikimedia.org/math/9/1/0/910ff9a0d7fcd65ceb10da816f33820b.png)

For any even _n_, this equals zero, in accordance with our predictions based on half-wave symmetry. It also decays as 1/_n_, as we expect, due to the presence of discontinuities.

Finally, we can put our Fourier series together as follows:

    ![f\(t\) = a_0 + \\sum_{n=1}^\\infty{ b_n \\sin \\left\(\\frac {\\pi n t}{\\frac{L}{2}} \\right\)}](//upload.wikimedia.org/math/0/a/f/0af78fbfb5e55acddc6b962a693e0d03.png)
    ![f\(t\) = 2 - \\frac{4}{\\pi}\\sum_{n=1}^\\infty{\\frac{\(-1\)^n - 1}{n} \\sin\(2 \\pi n t\)}](//upload.wikimedia.org/math/7/d/b/7dbeee58723f3ac40c20d23532b68598.png)

This is the same as

    ![f\(t\) = 2 + \\frac{8}{\\pi}\\sum_{n=1,3,5,\\ldots}^\\infty{\\frac{1}{n} \\sin\(2 \\pi n t\)}](//upload.wikimedia.org/math/8/6/2/862f77b21e4609524fdb697c4eb260b5.png)

We see that the Fourier series closely matches the original function:

![Square Wave Fourier Series.svg](//upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Square_Wave_Fourier_Series.svg/720px-Square_Wave_Fourier_Series.svg.png)

## Further Reading

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Fourier series**_](//en.wikipedia.org/wiki/Fourier_series)

Wikipedia has an article on the Fourier Series, although the article is very mathematically rigorous.

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Periodic Inputs

### System Response

## Plotting Results

From the polar form of the Fourier series, we can see that essentially, there are 2 quantities that that Fourier series provides: Magnitude, and Phase shift. If we simplify the entire series into the polar form, we can see that instead of being an infinite sum of different sinusoids, we get simply an infinite sum of cosine waves, with varying magnitude and phase parameters. This makes the entire series easier to work with, and also allows us to begin working with different graphical methods of analysis.

### Magnitude Plots

It is important to remember at this point that the Fourier series turns a continuous, periodic time signal into a discrete set of frequency components. In essence, any plot of Fourier components will be a _stem_ plot, and will not be continuous. The user should never make the mistake of attempting to **interpolate** the components into a smooth graph.

The magnitude graphs of a Fourier series representation plots the magnitude of the coefficient (either ![X_n](//upload.wikimedia.org/math/8/3/7/837c9f1adf5d0e370c9a8972e0ccde69.png) in polar, or ![C_n](//upload.wikimedia.org/math/8/4/9/849f9df2d516521b9163ae28c1fbc16a.png) in exponential form) against the frequency, in radians per second. The X-axis will have the independent variable, in this case the frequency. The Y-axis will hold the magnitude of each component. The magnitude can be a measure of either current or voltage, depending on how the original signal was represented. Keep in mind, however, that most signals, and their resulting magnitude plots, are discussed in terms of voltage (not current).

### Phase Plots

Similar to the magnitude plots, the phase plots of the Fourier representation will graph the phase angle of each component against the frequency. Both the frequency (X-axis), and the phase angle (Y-axis) will be plotted in units of radians per seconds. Occasionally, Hertz may be used for one (or even both), but this is not the normal case. Like the magnitude plot, the phase plot of a Fourier series will be discrete, and should be drawn as individual points, not as smooth lines.

## Power

Frequently, it is important to talk about the **power** in a given periodic wave. It is also important to talk about how much power is being transmitted in each different harmonic. For instance, if a certain channel has a limited bandwidth, and is filtering out some of the harmonics of the signal, then it is important to know how much power is being removed from the signal by the channel.

### Normalization

Let us now take a look at our equation for power:

    ![P = iv](//upload.wikimedia.org/math/9/b/a/9bab72d7f8aaf3274ae131e0c82e30ad.png)

Ohm's Law:  
![v = ir](//upload.wikimedia.org/math/9/7/9/97961f86133424825ddb1e7a4dd1881d.png)

If we use Ohm's Law to solve for v and i respectively, and then plug those values into our equation, we will get the following result:

    ![P = i^2R = \\frac{v^2}{R}](//upload.wikimedia.org/math/2/c/3/2c3d9dd104d58c01fb418894ead33a5d.png)

If we **normalize** the equation, and set R = 1, then both equations become much easier. In any case where the words "normalized power" are used, it denotes the fact that we are using a normalized resistance (R = 1).

To "de-normalize" the power, and find the power loss across a load with a non-normalized resistance, we can simply divide by the resistance (when in terms of voltage), and multiply by the resistance (when in terms of current).

### Power Plots

Because of the above result, we can assume that all loads are normalized, and we can find the power in a signal simply by squaring the signal itself. In terms of Fourier Series harmonics, we square the magnitude of each harmonic separately to produce the **power spectrum**. The power spectrum shows us how much power is in each harmonic.

## Parsevals Theorem

If the Fourier Representation and the Time-Domain Representation are simply two different ways to consider the same set of information, then it would make sense that the two are equal in many ways. The power and energy in a signal when expressed in the time domain should be equal to the power and energy of that same signal when expressed in the frequency domain. **Parseval's Theorem** relates the two.

Parsevals theorem states that the power calculated in the time domain is the same as the power calculated in the frequency domain. There are two ways to look at Parseval's Theorem, using the one-sided (polar) form of the Fourier Series, and using the two-sided (exponential) form:

    ![P = \\int_{0}^T f^2\(t\)dt 
        = X_0^2 + \\sum_{n=1}^\\infty \\frac{X_n^2}{2}](//upload.wikimedia.org/math/e/9/6/e9678008ba9901835fbf9727580f3a25.png)

and

    ![P = \\sum_{-\\infty}^\\infty C_nC_{-n} = \\sum_{-\\infty}^\\infty |C_n|^2](//upload.wikimedia.org/math/f/e/d/fedcb4a7eb8d4d31050054eac2eaeeaf.png)

By changing the upper-bound of the summation in the frequency domain, we can limit the power calculation to a limited number of harmonics. For instance, if the channel bandwidth limited a particular signal to only the first 5 harmonics, then the upper-bound could be set to 5, and the result could be calculated.

## Energy Spectrum

With Parseval's theorem, we can calculate the amount of energy being used by a signal in different parts of the spectrum. This is useful in many applications, such as filtering, that we will discuss later.

We know from Parseval's theorem that to obtain the energy of the harmonics of the signal that we need to square the frequency representation in order to view the energy. We can define the **energy spectral density** of the signal as the square of the Fourier transform of the signal:

    ![\\mathcal{E}_F\(\\theta\) = \\mathcal{F}^2\(\\theta\)](//upload.wikimedia.org/math/6/1/9/6192299115b0b0301044b07ec993568f.png)

The magnitude of the graph at different frequencies represents the amount energy located within those frequency components.

## Power Spectral Density

Akin to energy in a signal is the amount of power in a signal. To find the power spectrum, or **power spectral density** (PSD) of a signal,

take the Fourier Transform of the Auto Correlation of the signal(which is in frequency domain).

## Signal to Noise Ratio

In the presence of noise, it is frequently important to know what is the ratio between the signal (which you want), and the noise (which you don't want). The ratio between the noise and the signal is called the **Signal to Noise Ratio**, and is abbreviated with the letters **SNR**.

There are actually 2 ways to represent SNR, one as a straight-ratio, and one in decibels. The two terms are functionally equivalent, although since they are different quantities, they cannot be used in the same equations. It is worth emphasizing that decibels cannot be used in calculations the same way that ratios are used.

    ![SNR = \\frac{Signal}{Noise}](//upload.wikimedia.org/math/f/8/a/f8a4a7d4bd5e6e58c8ea410fac15a698.png)

Here, the SNR can be in terms of either power or voltage, so it must be specified which quantity is being compared. Now, when we convert SNR into decibels:

    ![SNR_{db} = 10log_{10} \\left\(\\frac{Signal}{Noise}\\right\)](//upload.wikimedia.org/math/5/9/e/59e054a327341f8c11ca1c81eaf65394.png)

For instance, an SNR of 3db means that the signal is twice as powerful as the noise signal. A higher SNR (in either representation) is always preferable.

**[Signals and Systems](/wiki/Signals_and_Systems)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Fourier transform**_](//en.wikipedia.org/wiki/Fourier_transform)

## Aperiodic Signals

The opposite of a periodic signal is an **aperiodic signal**. An aperiodic function never repeats, although technically an aperiodic function can be considered like a periodic function with an infinite period.

## Background

If we consider aperiodic signals, it turns out that we can generalize the Fourier Series sum into an integral named the **Fourier Transform**. The Fourier Transform is used similarly to the Fourier Series, in that it converts a time-domain function into a frequency domain representation. However, there are a number of differences:

  1. Fourier Transform can work on Aperiodic Signals.
  2. Fourier Transform is an infinite sum of **infinitesimal sinusoids**.
  3. Fourier Transform has an _inverse transform_, that allows for conversion from the frequency domain back to the time domain.

## Fourier Transform

This operation can be performed using this [MATLAB](/wiki/MATLAB_Programming) command:  
**fft**

The Fourier Transform is the following integral:

    ![\\mathcal{F}\(f\(t\)\) = F\(j\\omega\) = \\int_{-\\infty}^\\infty f\(t\)e^{-j\\omega t}dt](//upload.wikimedia.org/math/9/2/6/926dc463e8a4d9658f2850b0cee853e8.png)

## Inverse Fourier Transform

And the inverse transform is given by a similar integral:

    ![\\mathcal{F}^{-1}\\left\\{F\(j\\omega\) \\right\\}
        = f\(t\) 
        = \\frac{1}{2\\pi}\\int_{-\\infty}^\\infty F\(j\\omega\) e^{j\\omega t} d\\omega](//upload.wikimedia.org/math/a/1/a/a1a42d6483a0d6108ba73236a870038a.png)

Using these formulas, time-domain signals can be converted to and from the frequency domain, as needed.

### Partial Fraction Expansion

One of the most important tools when attempting to find the inverse fourier transform is the **Theory of Partial Fractions**. The theory of partial fractions allows a complicated fractional value to be decomposed into a sum of small, simple fractions. This technique is highly important when dealing with other transforms as well, such as the Laplace transform and the Z-Transform.

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Signals_and_Systems/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

## Duality

The Fourier Transform has a number of special properties, but perhaps the most important is the property of **duality**.

We will use a "double-arrow" signal to denote duality. If we have an even signal f, and it's fourier transform F, we can show duality as such:

    ![f\(t\) \\Leftrightarrow F\(j\\omega\)](//upload.wikimedia.org/math/7/4/7/747c538f5f5a5af20aff4d3059f24cda.png)

This means that the following rules hold true:

    ![\\mathcal{F}\\{f\(t\)\\} = F\(j \\omega\)](//upload.wikimedia.org/math/6/e/b/6eb5400b58e75c7b95cf0391e8855084.png) AND ![\\mathcal{F}\\{F\(t\)\\} = f\(j\\omega\)](//upload.wikimedia.org/math/6/8/3/6833f5d1b259e069342aad3b0974b7b7.png)

Notice how in the second part we are taking the _transform of the transformed equation_, except that we are starting in the time domain. We then convert to the original time-domain representation, except using the frequency variable. There are a number of results of the Duality Theorem.

### Convolution Theorem

The **Convolution Theorem** is an important result of the duality property. The convolution theorem states the following:

Convolution Theorem
    _Convolution in the time domain is multiplication in the frequency domain. Multiplication in the time domain is convolution in the frequency domain._

Or, another way to write it (using our new notation) is such:

    ![A \\times B \\Leftrightarrow A * B](//upload.wikimedia.org/math/5/b/2/5b2efccb8c35fc73462ddd5a893e7394.png)

### Signal Width

Another principle that must be kept in mind is that signal-widths in the time domain, and bandwidth in the frequency domain are related. This can be summed up in a single statement:

    _Thin signals in the time domain occupy a wide bandwidth. Wide signals in the time domain occupy a thin bandwidth_.

This conclusion is important because in modern communication systems, the goal is to have thinner (and therefore more frequent) pulses for increased data rates, however the consequence is that a large amount of bandwidth is required to transmit all these fast, little pulses.

## Power and Energy

### Energy Spectral Density

Unlike the Fourier Series, the Fourier Transform does not provide us with a number of discrete harmonics that we can add and subtract in a discrete manner. If our channel bandwidth is limited, in the Fourier Series representation, we can simply _remove_ some harmonics from our calculations. However, in a continuous spectrum, we do not have individual harmonics to manipulate, but we must instead examine the entire continuous signal.

The Energy Spectral Density (ESD) of a given signal is the square of its Fourier transform. By definition, the ESD of a function _f(t)_ is given by _F2(jω)_. The power over a given range (a limited bandwidth) is the integration under the ESD graph, between the cut-off points. The ESD is often written using the variable _Ef(jω)_.

    ![E_f\(j\\omega\) = F^2\(j\\omega\)](//upload.wikimedia.org/math/a/2/0/a209ad341f0a0e70e9e93ca1cd742903.png)

### Power Spectral Density

The **Power Spectral Density** (PSD) is similar to the ESD. It shows the distribution of power in the spectrum of a particular signal.

    ![P_f\(j\\omega\) = \\int_{-\\infty}^\\infty F\(j \\omega\) d\\omega](//upload.wikimedia.org/math/7/f/1/7f16e6f394e4a272d06836d78f139c3e.png)

Power spectral density and the autocorrelation form a Fourier Transform duality pair. This means that:

    ![P_f\(j\\omega\) = \\mathcal{F}\[R_{ff}\(t\)\]](//upload.wikimedia.org/math/5/8/8/58815a7a5b5420d6220e985494c3d4a5.png)

If we know the autocorrelation of the signal, we can find the PSD by taking the Fourier transform. Similarly, if we know the PSD, we can take the inverse Fourier transform to find the autocorrelation signal.

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Frequency Response

Systems respond differently to inputs of different frequencies. Some systems may amplify components of certain frequencies, and attenuate components of other frequencies. The way that the system output is related to the system input for different frequencies is called the _frequency response_ of the system.

The frequency response is the relationship between the system input and output in the Fourier Domain.

![Fourier Transfer Block.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Fourier_Transfer_Block.svg/240px-Fourier_Transfer_Block.svg.png)

In this system, X(jω) is the system input, Y(jω) is the system output, and H(jω) is the frequency response. We can define the relationship between these functions as:

    ![Y\(j\\omega\) = H\(j\\omega\)X\(j\\omega\)](//upload.wikimedia.org/math/2/3/2/2320ca76e23a6fc02026b2c79fac8899.png)

    ![\\frac{Y\(j\\omega\)}{X\(j\\omega\)} = H\(j\\omega\)](//upload.wikimedia.org/math/5/1/b/51bebbee1ae3a5e1b3abdf1749db6612.png)

## The Frequency Response Functions

Since the frequency response is a complex function, we can convert it to polar notation in the complex plane. This will give us a magnitude and an angle. We call the angle the _phase_.

### Amplitude Response

For each frequency, the magnitude represents the system's tendency to amplify or attenuate the input signal.

    

    ![A\\left\( \\omega  \\right\) = \\left| {H\\left\( {j\\omega } \\right\)} \\right|](//upload.wikimedia.org/math/8/5/c/85c4415d56ddb6a538c699915b0d726f.png)

### Phase Response

The phase represents the system's tendency to modify the phase of the input sinusoids.

    

    ![\\phi \\left\( \\omega  \\right\) = \\angle H\\left\( {j\\omega } \\right\)](//upload.wikimedia.org/math/5/a/a/5aaf1b02743c3253b27d5ddf1608c047.png).

The phase response, or its derivative the group delay, tells us how the system delays the input signal as a function of frequency.

## Examples

### Example: Electric Circuit

Consider the following general circuit with phasor input and output voltages:

![General Filter Circuit.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d3/General_Filter_Circuit.svg/300px-General_Filter_Circuit.svg.png)

Where

    ![V_o \\left\( {j\\omega } \\right\) = V_{om} \\cos \\left\( {\\omega t + \\theta_o } \\right\)=V_{om} \\angle \\theta _o](//upload.wikimedia.org/math/6/e/b/6ebd74ded973a50d2322695e315797ec.png)
    ![V_i \\left\( {j\\omega } \\right\) = V_{im} \\cos \\left\( {\\omega t + \\theta_i } \\right\)=V_{im} \\angle \\theta _i](//upload.wikimedia.org/math/f/3/e/f3e753ef68974e57c572390379aff441.png)

As before, we can define the system function, _H(jω)_ of this circuit as:

    ![H\\left\( {j\\omega } \\right\) = {{V_o \\left\( {j\\omega } \\right\)} \\over {V_i \\left\( {j\\omega } \\right\)}}](//upload.wikimedia.org/math/8/9/b/89be62ca4ae22815d00e513322133a38.png)

    ![
A\\left\( \\omega  \\right\) = \\left| {H\\left\( {j\\omega } \\right\)} \\right| = {{\\left| {V_o \\left\( {j\\omega } \\right\)} \\right|} \\over {\\left| {V_i \\left\( {j\\omega } \\right\)} \\right|}} = {{V_{om} } \\over {V_{im} }}](//upload.wikimedia.org/math/f/e/d/fed588d57aa85adb0e34d19b217d4117.png)

    ![\\phi \\left\( \\omega  \\right\) = \\angle H\\left\( {j\\omega } \\right\) = \\angle \\left\( {{{V_o \\left\( {j\\omega } \\right\)} \\over {V_i \\left\( {j\\omega } \\right\)}}} \\right\) = \\angle V_o \\left\( {j\\omega } \\right\) - \\angle V_i \\left\( {j\\omega } \\right\) = \\theta _o  - \\theta _i](//upload.wikimedia.org/math/8/a/4/8a447e4c5d494ef2ac849da942f77278.png)

Rearranging gives us the following transformations:

    ![V_{om}=A \\left\( \\omega \\right\) V_{im}](//upload.wikimedia.org/math/6/c/5/6c55c3f5052ab614a1b1724274f7cf72.png)
    ![\\theta_o=\\theta_i + \\phi \\left\( \\omega \\right\)](//upload.wikimedia.org/math/1/3/9/139299092270e6eb281d03b77f9428cb.png)

### Example: Low-Pass Filter

We will illustrate this method using a simple low-pass filter with general values as an example. This kind of circuit allows low frequencies to pass, but blocks higher ones.

Find the frequency response function, and hence the amplitude and phase response functions, of the following RC circuit (it is already in phasor form):

![1st Order Lowpass Filter \(Phasor\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/22/1st_Order_Lowpass_Filter_%28Phasor%29.svg/350px-1st_Order_Lowpass_Filter_%28Phasor%29.svg.png)

Firstly, we use the voltage divider rule to get the output phasor in terms on the input phasor:

    

    ![V_o \\left\( {j\\omega } \\right\) = V_i \\left\( {j\\omega } \\right\) \\cdot {{{1 \\over {j\\omega C}}} \\over {R + {1 \\over {j\\omega C}}}}](//upload.wikimedia.org/math/a/a/0/aa0e09f3a9819c47d7444b509b975e8a.png)

Now we can easily determine the frequency response:

    

    ![H\\left\( {j\\omega } \\right\) = {{V_o \\left\( {j\\omega } \\right\)} \\over {V_i \\left\( {j\\omega } \\right\)}} = {{{1 \\over {j\\omega C}}} \\over {R + {1 \\over {j\\omega C}}}}](//upload.wikimedia.org/math/f/4/f/f4fc2d8be93972515ec0b5601cbc25c9.png)

This simiplifies down to:

    

    ![H\\left\( {j\\omega } \\right\) = {1 \\over {1 + j\\omega RC}}](//upload.wikimedia.org/math/c/0/f/c0f62783ed29a3ee1a515c6ddc136692.png)

From here we can find the amplitude and phase responses:

    

    ![A\\left\( \\omega  \\right\) = \\left| {H\\left\( {j\\omega } \\right\)} \\right| = {1 \\over {\\sqrt {1 + \\left\( {\\omega CR} \\right\)^2 } }}](//upload.wikimedia.org/math/7/5/d/75d6f0cc963d44276b728f90e81116a8.png)

    

    ![\\phi \\left\( \\omega  \\right\) = \\angle H\\left\( {j\\omega } \\right\) = \\tan ^{ - 1} \\left\( {{0 \\over 1}} \\right\) - \\tan ^{ - 1} \\left\( {{{\\omega RC} \\over 1}} \\right\) =  - \\tan ^{ - 1} \\left\( {\\omega RC} \\right\)](//upload.wikimedia.org/math/9/9/8/998151cb5829803650b45e2de9724e99.png)

The frequency response is pictured by the plots of the amplitude and phase responses:

![1st Order Lowpass Filter ARF Lin.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e6/1st_Order_Lowpass_Filter_ARF_Lin.svg/400px-1st_Order_Lowpass_Filter_ARF_Lin.svg.png)

![1st Order Lowpass Filter PRF Lin.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f6/1st_Order_Lowpass_Filter_PRF_Lin.svg/400px-1st_Order_Lowpass_Filter_PRF_Lin.svg.png)

It is often easier to interpret the graphs when they are plotted on suitable logarithmic scales:

![1st Order Lowpass Filter ARF Log.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/1st_Order_Lowpass_Filter_ARF_Log.svg/400px-1st_Order_Lowpass_Filter_ARF_Log.svg.png)

![1st Order Lowpass Filter PRF Log.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/bc/1st_Order_Lowpass_Filter_PRF_Log.svg/400px-1st_Order_Lowpass_Filter_PRF_Log.svg.png)

This shows that the circuit is indeed a filter that removes higher frequencies. Such a filter is called a _lowpass filter_.

The amplitude and phase responses of an arbitrary circuit can be plotted using an instrument called a **spectrum analyser** or **gain and phase test set**. See [Practical Electronics](/wiki/Practical_Electronics) for more details on using these instruments.

## Filters

An important concept to take away from these examples is that by desiging a proper system called a **filter**, we can selectively attenuate or amplify certain frequency ranges. This means that we can minimize certain unwanted frequency components (such as noise or competing data signals), and maximize our own data signal

We can define a "received signal" _r_ as a combination of a data signal _d_ and unwanted components _v_:

    ![r\(t\) = d\(t\) + v\(t\)](//upload.wikimedia.org/math/f/5/a/f5a757ef693a951720531271ee05a3af.png)

We can take the energy spectral density of _r_ to determine the frequency ranges of our data signal _d_. We can design a filter that will attempt to amplify these frequency ranges, and attenuate the frequency ranges of _v_. We will discuss this problem and filters in general in the next few chapters. More advanced discussions of this topic will be in the book on [Signal Processing](/wiki/Signal_Processing).

# Complex Frequency Representation

## The Laplace Transform

Whilst the [Fourier Series](/wiki/Signals_and_Systems/Fourier_Series) and the [Fourier Transform](/wiki/Signals_and_Systems/Aperiodic_Signals#Fourier_Transform) are well suited for analysing the frequency content of a signal, be it periodic or aperiodic, the Laplace transform is the tool of choice for analysing and developing circuits such as filters.

The Fourier Transform can be considered as an extension of the Fourier Series for aperiodic signals. The Laplace Transform can be considered as an extension of the Fourier Transform to the complex plane.

### Unilateral Laplace Transform

The _[Laplace Transform](http://en.wikipedia.org/wiki/Laplace_transform)_ of a function _f_(_t_), defined for all real numbers _t_ ≥ 0, is the function _F_(_s_), defined by:

    ![F\(s\) = \\mathcal{L} \\left\\{f\(t\)\\right\\}=\\int_0^{\\infty} e^{-st} f\(t\) \\,dt. ](//upload.wikimedia.org/math/2/9/1/291f841863bc17cdcbb7fc75d0a2ec14.png)

The parameter _s_ is the complex number:

    ![s = \\sigma + j \\omega, \\, ](//upload.wikimedia.org/math/8/7/c/87c2edb3670450dbde93f721c8d5630e.png) with a real part σ and an imaginary part ω.

### Bilateral Laplace Transform

The _Bilateral Laplace Transform_ is defined as follows:

    ![F\(s\)  = \\mathcal{L}\\left\\{f\(t\)\\right\\}  =\\int_{-\\infty}^{\\infty} e^{-st} f\(t\)\\,dt.](//upload.wikimedia.org/math/f/2/a/f2a613fc61132e4b8f053ed85030a651.png)

Comparing this definition to the one of the [Fourier Transform](/wiki/Signals_and_Systems/Aperiodic_Signals#Fourier_Transform), one sees that the latter is a special case of the Laplace Transform for ![s = j \\omega](//upload.wikimedia.org/math/a/8/5/a85b8a883b07d53a9bf9d8c408de5c5c.png).

In the field of electrical engineering, the Bilateral Laplace Transform is simply referred as the Laplace Transform.

### Inverse Laplace Transform

The _Inverse Laplace Transform_ allows to find the original time function on which a Laplace Transform has been made.:

    ![f\(t\) = \\mathcal{L}^{-1} \\{F\(s\)\\} = \\frac{1}{2 \\pi i} \\lim_{T\\to\\infty}\\int_{ \\gamma - i T}^{ \\gamma + i T} e^{st} F\(s\)\\,ds,](//upload.wikimedia.org/math/a/9/e/a9e6454f0de3496620bdf86400ad3d52.png)

## Differential Equations

### Integral and Derivative

The [properties of the Laplace transform](/wiki/Signals_and_Systems/Table_of_Laplace_Transforms#Laplace_Transform_Properties) show that:

  * the transform of a derivative corresponds to a multiplcation with ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png)
  * the transform of an integral corresponds to a division with ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png)

This is summarized in the following table:

Time Domain Laplace Domain

![x\(t\) ](//upload.wikimedia.org/math/f/d/5/fd5f9e2ee180a439aaec015692916a1c.png) ![X\(s\) = \\mathcal{L} \\left\\{ x\(t\) \\right\\}](//upload.wikimedia.org/math/4/c/c/4cc48462bc9662d9edf093e2e4ce145d.png)

![ \\dot{x}\(t\) ](//upload.wikimedia.org/math/4/c/1/4c10c5c4be8fb5e2c776260b36f4fe92.png)
![ s \\cdot X\(s\) ](//upload.wikimedia.org/math/c/3/6/c36556bd02f62e588413321186483592.png)

![ \\int x\(t\)dt ](//upload.wikimedia.org/math/1/8/f/18f7a8ebe660ff85d8963e84f065c8e0.png)
![ \\frac{1}{s} \\cdot X\(s\) ](//upload.wikimedia.org/math/d/5/1/d51fdd45bbf218d9fe0c5e6e35fd7984.png)

With this, a set of differential equations is transformed into a set of linear equations which can be solved with the usual techniques of linear algebra.

### Lumped Element Circuits

Lumped elements circuits typically show this kind of integral or differential relations between current and voltage:

    

    ![ U_C = \\frac{1}{sC} \\cdot I_C ](//upload.wikimedia.org/math/2/9/6/2967064e084aa494a7c2fd58c6bab6f2.png)

    

    ![ U_L = sL \\cdot I_L ](//upload.wikimedia.org/math/0/e/f/0ef88af3bda0afd7063bb11d1624cf9a.png)

This is why the analysis of a lumped elements circuit is usually done with the help of the Laplace transform.

## Example

### Sallen-Key Lowpass Filter

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/9/93/Evolution-tasks.png/40px-Evolution-tasks.png)

The [Sallen-Key](http://en.wikipedia.org/wiki/Sallen_Key_filter) circuit is widely used for the implementation of analog second order sections. 

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Sallen-Key_Lowpass_General.svg/400px-Sallen-Key_Lowpass_General.svg.png)

Sallen–Key unity-gain lowpass filter

The image on the side shows the circuit for an all-pole second order function.

Writing ![v_1](//upload.wikimedia.org/math/1/7/5/175fb02dc71571bb97cf42967a26105c.png) the potential between both resistances and ![v_2](//upload.wikimedia.org/math/4/3/0/43078bbe67ed8d55801deec58a70f40b.png) the input of the op-amp follower circuit, gives the following relations:

    ![ \\begin{cases}
R_1 I_{R1} = V_{in} - V_1 \\\\
R_2 I_{R2} = V_1 - V_2 \\\\
I_{C2} = s C_2 V_2 \\\\
I_{C1} = s C_1 \(V_1 - V_{out}\) \\\\
I_{R1} = I_{R2} + I_{C1} \\\\
I_{R2} = I_{C2} \\\\
V_2 = V_{out}
 \\end{cases} ](//upload.wikimedia.org/math/3/7/f/37f804a9bd8bb356583699645edf81f2.png)

Rewriting the current node relations gives:

    ![ \\begin{cases}
R_1 R_2 I_{R1} = R_1 R_2 I_{R2} +R_1 R_2 I_{C1} \\\\
R_2 I_{R2} = R_2 I_{C2}
 \\end{cases} ](//upload.wikimedia.org/math/3/8/7/3879f60c2d9669e1e05738e6308dbec3.png)

    ![ \\begin{cases}
R_2 \(V_{in} - V_1\) = R_1 \(V_1 - V_{out}\) + R_1 R_2 s C_1 \(V_1 - V_{out}\) \\\\
V_1 - V_{out} = R_2 s C_2 V_{out}
 \\end{cases} ](//upload.wikimedia.org/math/8/a/1/8a1e88ad71696b85aad8c70e837e7194.png)

    ![ \\begin{cases}
R_2 V_{in} = \(R_1 + R_2 + R_1 R_2 s C_1\) V_1 - \(R_1  + R_1 R_2 s C_1\) V_{out} \\\\
V_1 = \(1 + s R_2 C_2\) V_{out}
 \\end{cases} ](//upload.wikimedia.org/math/f/a/0/fa029b8bb96551f2a1a18021e1173ec6.png)

    ![ R_2 V_{in} = \\begin{bmatrix} \(1 + s R_2 C_2\) \(R_1 + R_2 + R_1 R_2 s C_1\) - R_1  - R_1 R_2 s C_1 \\end{bmatrix} V_{out} ](//upload.wikimedia.org/math/e/5/b/e5bbd7c54532a5a2db32bfccc6078960.png)

    ![ V_{in} = \\begin{bmatrix} \(1 + s R_2 C_2\) \(R_1/R_2 + 1 + s R_1 C_1 - R_1/R_2  - s R_1 C_1 \\end{bmatrix} V_{out} ](//upload.wikimedia.org/math/6/8/f/68fab848916b1aa0ba4e71827dd1c0ea.png)

    ![ \\frac{V_{in}}{ V_{out}} = R_1/R_2 + 1 + s R_1 C_1 + s R_1 C_2 + s R_2 C_2 + s^2 R_1 R_2 C_1 C_2 - R_1/R_2  - s R_1 C_1 ](//upload.wikimedia.org/math/2/3/6/236c23c42eda024facbb78fac73acee6.png)

and finally:

    ![ \\frac{V_{out}}{ V_{in}} = \\frac{1}{1 + s \(R_1 + R_2\) C_2 + s^2 R_1 R_2 C_1 C_2} ](//upload.wikimedia.org/math/9/1/e/91e9cc650ae4cfa22bef88b61d58fd3c.png)

Thus, the transfer function is:

    ![ H\(s\) = \\frac{\\frac{1}{R_1 R_2 C_1 C_2}}{s^2 + \\frac{R_1 + R_2}{R_1 R_2} \\frac{1}{C_1} s +  \\frac{1}{R_1 R_2 C_1 C_2}} ](//upload.wikimedia.org/math/c/e/3/ce3d70fa32f1a6b133bc3897ea27d487.png)

# Random Signals

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Probability

![Warning icon WikiBooks.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Warning_icon_WikiBooks.svg/40px-Warning_icon_WikiBooks.svg.png)

This book requires that you first read **[Probability](/wiki/Probability)**.

This section of the [Signals and Systems](/wiki/Signals_and_Systems) book will be talking about probability, random signals, and noise. This book will not, however, attempt to teach the basics of probability, because there are dozens of resources (both on the internet at large, and on Wikipedia mathematics bookshelf) for probability and statistics. This book will assume a basic knowledge of probability, and will work to explain random phenomena in the context of an Electrical Engineering book on signals.

## Random Variable

A random variable is a quantity whose value is not fixed but depends somehow on chance. Typically the value of a random variable may consist of a fixed part and a random component due to uncertainty or disturbance. Other types of random variables takes their values as a result of the outcome of a random experiment.

Random variables are usually denoted with a capital letter. For instance, a generic random variable that we will use often is _X_. The capital letter represents the random variable itself and the corresponding lower-case letter (in this case "_x_") will be used to denote the observed value of _X_. _x_ is one particular value of the process _X_.

## Mean

The mean or more precise the expected value of a random variable is the central value of the random value, or the average of the observed values in the long run. We denote the mean of a signal _x_ as μx. We will discuss the precise definition of the mean in the next chapter.

## Standard Deviation

The standard deviation of a signal _x_, denoted by the symbol σx serves as a measure of how much deviation from the mean the signal demonstrates. For instance, if the standard deviation is small, most values of _x_ are close to the mean. If the standard deviation is large, the values are more spread out.

The standard deviation is an easy concept to understand, but in practice it's not a quantity that is easy to compute directly, nor is it useful in calculations. However, the standard deviation is related to a more useful quantity, the **variance**.

## Variance

The variance is the square of the standard deviation and is more of theoretical importance. We denote the variance of a signal _x_ as σx2. We will discuss the variance and how it is calculated in the next chapter.

## Probability Function

The probability function _P_ is the probability that a certain event will occur. It is calculated based on the **probability density function** and **cumulative distribution function**, described below.

We can use the _P_ operator in a variety of ways:

    ![P\[\\mbox{A coin is heads}\] = \\frac{1}{2}](//upload.wikimedia.org/math/b/2/1/b21817696985d60ddf6465af4f98d930.png)
    ![P\[\\mbox{A dice shows a 3}\] = \\frac{1}{6}](//upload.wikimedia.org/math/b/6/8/b6838642b6467e37b22fb3baf9035c6d.png)

## Probability Density Function

The Probability Density Function (PDF) of a random variable is a description of the distribution of the values of the random variable. By integrating this function over a particular range, we can find the probability that the random variable takes on a value in that interval. The integral of this function over all possible values is 1.

We denote the density function of a signal _x_ as _fx_. The probability of an event _xi_ will occur is given as:

    ![P\[x_i\] = f_x\(x_i\)](//upload.wikimedia.org/math/2/4/3/243856635d8e9c98dfa884ac56b00b29.png)

## Cumulative Distribution Function

The Cumulative Distribution Function (CDF) of a random variable describes the probability of observing a value at or below a certain threshold. A CDF function will be nondecreasing with the properties that the value of the CDF at negative infinity is zero, and the value of the CDF at positive infinity is 1.

We denote the CDF of a function with a capital F. The CDF of a signal _x_ will have the subscript _Fx_.

We can say that the probability of an event occurring less then or equal to _xi_ is defined in terms of the CDF as:

    ![P\[x \\le x_i\] = F_x\(x_i\)](//upload.wikimedia.org/math/8/9/7/897ca4ea35f60081a2376e03909a4909.png)

Likewise, we can define the probability that an event occurs that is greater then _xi_ as:

    ![P\[x > x_i\] = 1 - F_x\(x_i\)](//upload.wikimedia.org/math/8/4/5/8459bae018ead635ea726672b01f8d8c.png)

Or, the probability that an event occurs that is greater then or equal to _xi_:

    ![P\[x \\ge x_i\] = 1 - F_x\(x_i\) + f_x\(x_i\)](//upload.wikimedia.org/math/5/7/1/571eb0836d7ae26f3106277a1212a652.png)

### Relation with PDF

The CDF and PDF are related to one another by a simple integral relation:

    ![F_x\(x\) = \\int_{-\\infty}^x f_x\(\\tau\)d\\tau](//upload.wikimedia.org/math/e/7/1/e71169fd3ad8632fe8e47080e26afb4d.png)
    ![f_x\(x\) = \\frac{d}{dx}F_x\(x\)](//upload.wikimedia.org/math/0/1/e/01ec9d6a308afd5531549c15435f4721.png)

### Terminology

Several book sources refer to the CDF as the "Probability Distribution Function", with the acronym PDF. To avoid the ambiguity of having both the distribution function and the density function with the same acronym (PDF), some books will refer to the density function as "pdf" (lower case) and the distribution function as "PDF" upper case. To avoid this ambiguity, this book will refer to the distribution function as the CDF, and the density function as the PDF.

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Expected Value Operator

The Expected value operator is a linear operator that provides a mathematical way to determine a number of different parameters of a random distribution. The downside of course is that the expected value operator is in the form of an integral, which can be difficult to calculate.

The expected value operator will be denoted by the symbol:

    ![\\mathbb{E}\[\\cdot\]](//upload.wikimedia.org/math/2/8/d/28d4f764d77e614abe65836fc4568a7c.png)

For a random variable _X_ with probability density _fx_, the expected value is defined as:

    ![\\mathbb{E}\[X\] = \\int_{-\\infty}^\\infty x f_X\(x\)dx](//upload.wikimedia.org/math/6/b/2/6b270f0731c76902fbf340230b4673c5.png).

provided the integral exists.

The **Expectation** of a signal is the result of applying the expected value operator to that signal. The expectation is another word for the mean of a signal:

    ![\\mu_x = \\mathbb{E}\[X\]](//upload.wikimedia.org/math/4/9/1/491a6c7bd93ced1f12ad395a0756ded2.png)

## Moments

The expected value of the _N_-th power of _X_ is called the _N_-th moment of _X_ or of its distribution:

    ![\\mathbb{E}\[X^N\] = \\int_{-\\infty}^\\infty x^N f_X\(x\)dx](//upload.wikimedia.org/math/5/e/c/5ec1c3c2e888c7682f2981ebf0c64fbb.png).

Some moments have special names, and each one describes a certain aspect of the distribution.

## Central Moments

Once we know the expected value of a distribution, we know its location. We may consider all other moments relative to this location and calculate the _N_th moment of the random variable _X_ \- E[X]; the result is called the **Nth central moment** of the distribution. Each central moment has a different meaning, and describes a different facet of the random distribution. The _N_-th central moment of _X_ is:

    ![\\mathbb{E}\[\(X-\\mathbb{E}\[X\]\)^N\] = \\int_{-\\infty}^\\infty \(x-\\mathbb{E}\[X\]\)^N f_X\(x\)dx](//upload.wikimedia.org/math/1/c/a/1ca3f36c7edd5cf39a0ea267276caa76.png).

For sake of simplicity in the notation, the first moment, the expected value is named:

    ![\\mathbb{E}\[X\] = \\mu_X](//upload.wikimedia.org/math/6/4/a/64a9f6ac523a2687edb6be698794433b.png),

The formula for the _N_-th central moment of _X_ becomes then:

    ![\\mathbb{E}\[\(X-\\mu_X\)^N\] = \\int_{-\\infty}^\\infty \(x-\\mu_X\)^N f_X\(x\)dx](//upload.wikimedia.org/math/b/8/3/b83a7c13756b38a04231c2fcd489e472.png).

It is obvious that the first central moment is zero:

    ![\\mathbb{E}\[\(X - \\mu_X\)\] = 0](//upload.wikimedia.org/math/8/d/1/8d17038c37f1ae6649722183c3d68fc4.png)

The second central moment is the variance,

    ![\\mathbb{E}\[\(X - \\mu_X\)^2\] = \\sigma^2](//upload.wikimedia.org/math/4/8/6/4862fe4e1f27a5915f1ef100fe325417.png)

  


### Variance

The variance, the second central moment, is denoted using the symbol σx2, and is defined as:

    ![\\sigma_x^2 =\\mathrm{var}\(X\)= \\mathbb{E}\[X - \\mathbb{E}\[X\]\]^2= \\mathbb{E}\[X^2\] - \\mathbb{E}\[X\]^2](//upload.wikimedia.org/math/4/9/5/495c590137a05d2cb5cea7c73bb4808d.png)

### Standard Deviation

The standard deviation of a random distribution is the square root of the variance, and is given as such:

    ![\\sigma_x = \\sqrt{\\sigma_x^2}](//upload.wikimedia.org/math/3/8/5/3859048fe249aa3038a5b3bee5e9a7e0.png)

## Moment Generating Functions

## Time-Average Operator

The time-average operator provides a mathematical way to determine the average value of a function over a given time range. The time average operator can provide the mean value of a given signal, but most importantly it can be used to find the average value of a small sample of a given signal. The operator also allows us a useful shorthand way for taking the average, which is used in many equations.

The time average operator is denoted by angle brackets (< and >) and is defined as such:

    ![\\langle f\(t\) \\rangle = \\frac{1}{T} \\int_0^T f\(t\) dt](//upload.wikimedia.org/math/6/e/5/6e5896db012a4b8eedd8a0642cb3b6cf.png)

**[Signals and Systems](/wiki/Signals_and_Systems)**

There are a number of different random distributions in existence, many of which have been studied quite extensively, and many of which map very well to natural phenomena. This book will attempt to cover some of the most basic and most common distributions. This chapter will also introduce the idea of a distribution transformation, which can be used to turn a simple distribution into a more exotic distribution.

## Uniform Distribution

One of the most simple distributions is a Uniform Distribution. Uniform Distributions are also very easy to model on a computer, and then they can be converted to other distribution types by a series of transforms.

A uniform distribution has a PDF that is a rectangle. This rectangle is centered about the mean, <μx, has a width of _A_, and a height of _1/A_. This definition ensures that the total area under the PDF is 1.

## Gaussian Distribution

This operation can be performed using this [MATLAB](/wiki/MATLAB_Programming) command:  
**randn**

The Gaussian (or normal) distribution is simultaneously one of the most common distributions, and also one of the most difficult distributions to work with. The problem with the Gaussian distribution is that it's pdf equation is _non-integratable_, and therefore there is no way to find a general equation for the cdf (although some approximations are available), and there is little or no way to directly calculate certain probabilities. However, there are ways to approximate these probabilities from the Gaussian pdf, and many of the common results have been tabulated in table-format. The function that finds the area under a part of the Gaussian curve (and therefore the probability of an event under that portion of the curve) is known as the Q function, and the results are tabulated in a Q table.

### PDF and CDF

The PDF of a Gaussian random variable is defined as such:

    ![f\(x\) = \\frac{1}{\\sqrt{2\\pi\\sigma^2}} e^{-\\frac{\(x - \\mu\)^2}{2\\sigma^2}}](//upload.wikimedia.org/math/7/9/4/7948d7c585cb3f4e2041a46127e4c06f.png)

The CDF of the Gaussian function is the integral of this, which any mathematician will tell you is impossible to express in terms of regular functions.

### The Functions Φ and Q

The normal distribution with parameters μ = 0 and σ = 1, the so-called standard normal distribution, plays an important role, because all other normal distributions may be derived from it. The CDF of the standard normal distribution is often indicated by Φ:

    ![\\Phi\(x\) = \\frac{1}{2\\pi}\\int_{-\\infty}^x e^{-\\frac{t^2}{2}}dt](//upload.wikimedia.org/math/c/8/7/c873be5fb6e654b15704ee1a115bfa27.png).

It gives the probability for a standard normal distributed random variable to attain values less than x.

The Q function is the area under the right tail of the Gaussian curve and hence nothing more than 1 - Φ. The Q function is hence defined as:

    ![Q\(x\) = 1 - \\Phi\(x\)= \\frac{1}{2\\pi}\\int_x^\\infty e^{-\\frac{t^2}{2}}dt](//upload.wikimedia.org/math/2/3/9/2396960858fee22dafed6f8062701ded.png)

Mathematical texts might prefer to use the erf(x) and erfc(x) functions, which are similar. However this book (and engineering texts in general) will utilize the Q and Phi functions.

## Poisson Distribution

The Poisson Distribution is different from the Gaussian and uniform distributions in that the Poisson Distribution only describes discrete data sets. For instance, if we wanted to model the number of telephone calls that are traveling through a given switch at one time, we cannot possibly count fractions of a phone call; phone calls come only in integer numbers. Also, you can't have a negative number of phone calls. It turns out that such situations can be easily modeled by a Poisson Distribution. Some general examples of Poisson Distribution random events are:

  1. The telephone calls arriving at a switch
  2. The internet data packets traveling through a given network
  3. The number of cars traveling through a given intersection

## Transformations

If we have a random variable that follows a particular distribution, we would frequently like to transform that random process to use a different distribution. For instance, if we write a computer program that generates a uniform distribution of random numbers, and we would like to write one that generates a Gaussian distribution instead, we can feed the uniform numbers into a transform, and the output will be random numbers following a Gaussian distribution. Conversely, if we have a random variable in a strange, exotic distribution, and we would like to examine it using some of the easy, tabulated Gaussian distribution tools, we can transform it.

## Further Reading

  * [Statistics/Distributions](/wiki/Statistics/Distributions)
  * [Probability/Important Distributions](/wiki/Probability/Important_Distributions)
  * [Engineering Analysis/Distributions](/wiki/Engineering_Analysis/Distributions)

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Frequency Analysis

Noise, like any other signal, can be analyzed using the Fourier Transform and frequency-domain techniques. Some of the basic techniques used on noise (some of which are particular to random signals) are discussed in this section.

Gaussian white noise, one of the most common types of noise used in analysis, has a "flat spectrum". That is, the amplitude of the noise is the same at all frequencies.

## Stationary vs Ergodic Functions

## Power Spectral Density (PSD) of Gaussian White Noise

White noise has a level magnitude spectrum, and if we square it, it will also have a level [Power Spectral Density](http://en.wikipedia.org/wiki/Power_spectrum) (PSD) function. The value of this power magnitude is known by the variable _N0_. We will use this quantity later.

## Wiener Khintchine Einstein Theorem

Using the duality property of the Fourier Transform, the Wiener-Khintchine-Einstein Theorem gives us an easy way to find the PSD for a given signal.

if we have a signal _f(t)_, with autocorrelation _Rff_, then we can find the PSD, _Sxx_ by the following function:

    ![S_{xx} = \\mathcal{F}\(R_{ff}\)](//upload.wikimedia.org/math/f/a/8/fa8f517462a62f5f221efa7e1130da01.png)

Where the previous method for obtaining the PSD was to take the Fourier transform of the signal _f(t)_, and then squaring it.

## Bandwidth

The bandwidth of a random function.

### Noise-Equivalent Bandwidth

### Band limited Systems

### Narrow band Systems

## Windowing

Many random signals are infinite signals, in that they don't have a beginning or an end. To this effect, the only way to really analyze the random signal is take a small chunk of the random signal, called a **sample**.

Let us say that we have a long random signal, and we only want to analyze a sample. So we take the part that we want, and destroy the part that we don't want. Effectively, what we have done is to multiply the signal with a rectangular pulse. Therefore, the frequency spectrum of our sampled signal will contain frequency components of the noise _and the rectangular pulse_. It turns out that multiplying a signal by a rectangular pulse is rarely the best way to sample a random signal. It also turns out that there are a number of other **windows** that can be used instead, to get a good sample of noise, while at the same time introducing very few extraneous frequency components.

Remember duality? multiplication in the time domain (multiplying by your windowing function) becomes _convolution in the frequency domain._ Effectively, we've taken a very simple problem (getting a sample of information), and created a very difficult problem, the deconvolution of the resultant frequency spectrum. There are a number of different windows that we can use.

### Rectangular Window

### Triangular Window

### Hamming Window

# Introduction to Filters

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Frequency Response

Systems respond differently to inputs of different frequencies. Some systems may amplify components of certain frequencies, and attenuate components of other frequencies. The way that the system output is related to the system input for different frequencies is called the _frequency response_ of the system.

The frequency response is the relationship between the system input and output in the Fourier Domain.

![Fourier Transfer Block.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Fourier_Transfer_Block.svg/240px-Fourier_Transfer_Block.svg.png)

In this system, X(jω) is the system input, Y(jω) is the system output, and H(jω) is the frequency response. We can define the relationship between these functions as:

    ![Y\(j\\omega\) = H\(j\\omega\)X\(j\\omega\)](//upload.wikimedia.org/math/2/3/2/2320ca76e23a6fc02026b2c79fac8899.png)

    ![\\frac{Y\(j\\omega\)}{X\(j\\omega\)} = H\(j\\omega\)](//upload.wikimedia.org/math/5/1/b/51bebbee1ae3a5e1b3abdf1749db6612.png)

## The Frequency Response Functions

Since the frequency response is a complex function, we can convert it to polar notation in the complex plane. This will give us a magnitude and an angle. We call the angle the _phase_.

### Amplitude Response

For each frequency, the magnitude represents the system's tendency to amplify or attenuate the input signal.

    

    ![A\\left\( \\omega  \\right\) = \\left| {H\\left\( {j\\omega } \\right\)} \\right|](//upload.wikimedia.org/math/8/5/c/85c4415d56ddb6a538c699915b0d726f.png)

### Phase Response

The phase represents the system's tendency to modify the phase of the input sinusoids.

    

    ![\\phi \\left\( \\omega  \\right\) = \\angle H\\left\( {j\\omega } \\right\)](//upload.wikimedia.org/math/5/a/a/5aaf1b02743c3253b27d5ddf1608c047.png).

The phase response, or its derivative the group delay, tells us how the system delays the input signal as a function of frequency.

## Examples

### Example: Electric Circuit

Consider the following general circuit with phasor input and output voltages:

![General Filter Circuit.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d3/General_Filter_Circuit.svg/300px-General_Filter_Circuit.svg.png)

Where

    ![V_o \\left\( {j\\omega } \\right\) = V_{om} \\cos \\left\( {\\omega t + \\theta_o } \\right\)=V_{om} \\angle \\theta _o](//upload.wikimedia.org/math/6/e/b/6ebd74ded973a50d2322695e315797ec.png)
    ![V_i \\left\( {j\\omega } \\right\) = V_{im} \\cos \\left\( {\\omega t + \\theta_i } \\right\)=V_{im} \\angle \\theta _i](//upload.wikimedia.org/math/f/3/e/f3e753ef68974e57c572390379aff441.png)

As before, we can define the system function, _H(jω)_ of this circuit as:

    ![H\\left\( {j\\omega } \\right\) = {{V_o \\left\( {j\\omega } \\right\)} \\over {V_i \\left\( {j\\omega } \\right\)}}](//upload.wikimedia.org/math/8/9/b/89be62ca4ae22815d00e513322133a38.png)

    ![
A\\left\( \\omega  \\right\) = \\left| {H\\left\( {j\\omega } \\right\)} \\right| = {{\\left| {V_o \\left\( {j\\omega } \\right\)} \\right|} \\over {\\left| {V_i \\left\( {j\\omega } \\right\)} \\right|}} = {{V_{om} } \\over {V_{im} }}](//upload.wikimedia.org/math/f/e/d/fed588d57aa85adb0e34d19b217d4117.png)

    ![\\phi \\left\( \\omega  \\right\) = \\angle H\\left\( {j\\omega } \\right\) = \\angle \\left\( {{{V_o \\left\( {j\\omega } \\right\)} \\over {V_i \\left\( {j\\omega } \\right\)}}} \\right\) = \\angle V_o \\left\( {j\\omega } \\right\) - \\angle V_i \\left\( {j\\omega } \\right\) = \\theta _o  - \\theta _i](//upload.wikimedia.org/math/8/a/4/8a447e4c5d494ef2ac849da942f77278.png)

Rearranging gives us the following transformations:

    ![V_{om}=A \\left\( \\omega \\right\) V_{im}](//upload.wikimedia.org/math/6/c/5/6c55c3f5052ab614a1b1724274f7cf72.png)
    ![\\theta_o=\\theta_i + \\phi \\left\( \\omega \\right\)](//upload.wikimedia.org/math/1/3/9/139299092270e6eb281d03b77f9428cb.png)

### Example: Low-Pass Filter

We will illustrate this method using a simple low-pass filter with general values as an example. This kind of circuit allows low frequencies to pass, but blocks higher ones.

Find the frequency response function, and hence the amplitude and phase response functions, of the following RC circuit (it is already in phasor form):

![1st Order Lowpass Filter \(Phasor\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/22/1st_Order_Lowpass_Filter_%28Phasor%29.svg/350px-1st_Order_Lowpass_Filter_%28Phasor%29.svg.png)

Firstly, we use the voltage divider rule to get the output phasor in terms on the input phasor:

    

    ![V_o \\left\( {j\\omega } \\right\) = V_i \\left\( {j\\omega } \\right\) \\cdot {{{1 \\over {j\\omega C}}} \\over {R + {1 \\over {j\\omega C}}}}](//upload.wikimedia.org/math/a/a/0/aa0e09f3a9819c47d7444b509b975e8a.png)

Now we can easily determine the frequency response:

    

    ![H\\left\( {j\\omega } \\right\) = {{V_o \\left\( {j\\omega } \\right\)} \\over {V_i \\left\( {j\\omega } \\right\)}} = {{{1 \\over {j\\omega C}}} \\over {R + {1 \\over {j\\omega C}}}}](//upload.wikimedia.org/math/f/4/f/f4fc2d8be93972515ec0b5601cbc25c9.png)

This simiplifies down to:

    

    ![H\\left\( {j\\omega } \\right\) = {1 \\over {1 + j\\omega RC}}](//upload.wikimedia.org/math/c/0/f/c0f62783ed29a3ee1a515c6ddc136692.png)

From here we can find the amplitude and phase responses:

    

    ![A\\left\( \\omega  \\right\) = \\left| {H\\left\( {j\\omega } \\right\)} \\right| = {1 \\over {\\sqrt {1 + \\left\( {\\omega CR} \\right\)^2 } }}](//upload.wikimedia.org/math/7/5/d/75d6f0cc963d44276b728f90e81116a8.png)

    

    ![\\phi \\left\( \\omega  \\right\) = \\angle H\\left\( {j\\omega } \\right\) = \\tan ^{ - 1} \\left\( {{0 \\over 1}} \\right\) - \\tan ^{ - 1} \\left\( {{{\\omega RC} \\over 1}} \\right\) =  - \\tan ^{ - 1} \\left\( {\\omega RC} \\right\)](//upload.wikimedia.org/math/9/9/8/998151cb5829803650b45e2de9724e99.png)

The frequency response is pictured by the plots of the amplitude and phase responses:

![1st Order Lowpass Filter ARF Lin.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e6/1st_Order_Lowpass_Filter_ARF_Lin.svg/400px-1st_Order_Lowpass_Filter_ARF_Lin.svg.png)

![1st Order Lowpass Filter PRF Lin.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f6/1st_Order_Lowpass_Filter_PRF_Lin.svg/400px-1st_Order_Lowpass_Filter_PRF_Lin.svg.png)

It is often easier to interpret the graphs when they are plotted on suitable logarithmic scales:

![1st Order Lowpass Filter ARF Log.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/1st_Order_Lowpass_Filter_ARF_Log.svg/400px-1st_Order_Lowpass_Filter_ARF_Log.svg.png)

![1st Order Lowpass Filter PRF Log.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/bc/1st_Order_Lowpass_Filter_PRF_Log.svg/400px-1st_Order_Lowpass_Filter_PRF_Log.svg.png)

This shows that the circuit is indeed a filter that removes higher frequencies. Such a filter is called a _lowpass filter_.

The amplitude and phase responses of an arbitrary circuit can be plotted using an instrument called a **spectrum analyser** or **gain and phase test set**. See [Practical Electronics](/wiki/Practical_Electronics) for more details on using these instruments.

## Filters

An important concept to take away from these examples is that by desiging a proper system called a **filter**, we can selectively attenuate or amplify certain frequency ranges. This means that we can minimize certain unwanted frequency components (such as noise or competing data signals), and maximize our own data signal

We can define a "received signal" _r_ as a combination of a data signal _d_ and unwanted components _v_:

    ![r\(t\) = d\(t\) + v\(t\)](//upload.wikimedia.org/math/f/5/a/f5a757ef693a951720531271ee05a3af.png)

We can take the energy spectral density of _r_ to determine the frequency ranges of our data signal _d_. We can design a filter that will attempt to amplify these frequency ranges, and attenuate the frequency ranges of _v_. We will discuss this problem and filters in general in the next few chapters. More advanced discussions of this topic will be in the book on [Signal Processing](/wiki/Signal_Processing).

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Terminology

When it comes to filters, there is a large amount of terminology that we need to discuss first, so the rest of the chapters in this section will make sense.

Order (Filter Order) 
    The order of a filter is an integer number, that defines how complex the filter is. In common filters, the order of the filter is the number of "stages" of the filter. Higher order filters perform better, but they have a higher delay, and they cost more.

Pass Band 
    In a general sense, the passband is the frequency range of the filter that allows information to pass. The passband is usually defined in the specifications of the filter. For instance, we could define that we want our passband to extend from 0 to 1000 Hz, and we want the amplitude in the entire passband to be higher than -1 db.

Transition Band 
    The transition band is the area of the filter between the passband and the stopband. Higher-order filters have a thinner transition band

Stop Band 
    The stop band of a filter is the frequency range where the signal is attenuated. Stop band performance is often defined in the specification for the filter. For instance, we might say that we want to attenuate all frequencies above 5000 Hz, and we want to attenuate them all by -40 db or more

Cut-off Frequency
    The cut-off frequency of a filter is the frequency at which the filter "breaks", and changes (between pass band and transition band, or transition band and passband, for instance). The cut-off of a filter _always has an attenuation of -3db_. The -3 db point is the frequency that is cut in power by exactly 1/2.

## Lowpass

Lowpass filters allow low frequency components to pass through, while attenuating high frequency components.

Lowpass filters are some of the most important and most common filters, and much of our analysis is going to be focused on them. Also, transformations exist that can be used to convert the mathematical model of a lowpass filter into a model of a highpass, bandpass, or bandstop filter. This means that we typically design lowpass filters and then transform them into the appropriate type.

### Example: Telephone System

As an example of a lowpass filter, consider a typical telephone line. Telephone signals are **bandlimited**, which means that a filter is used to prevent certain frequency components from passing through the telephone network. Typically, the range for a phone conversation is 10Hz to 3˙000Hz. This means that the phone line will typically incorporate a lowpass filter that attenuates all frequency components above 3˙000Hz. This range has ben chosen because it includes all the information humans need for clearly understanding one another, so the effects of this filtering are not damaging to a conversation. Comparatively, CD recordings comprise most of the human hearing and their frequency components range up to 20˙000Hz or 20kHz.

## Highpass

Highpass filters allow high frequency components to pass through, while attenuating low frequency components.

### Example: DSL Modems

Consider DSL modems, which are high-speed data communication devices that transmit over the existing telephone network. DSL signals operate in the high frequency ranges, above the 3000Hz limit for voice conversations. In order to separate the DSL data signal from the regular voice signal, the signal must be sent into two different filters: a lowpass filter to amplify the voice for the telephone signal, and a highpass filter to amplify the DSL data signal.

## Bandpass

A bandpass filter allows a single band of frequency information to pass the filter, but will attenuate all frequencies above the band and below the band.

A good example of a bandpass filter is an FM radio tuner. In order to focus on one radio station, a filter must be used to attenuate the stations at both higher and lower frequencies.

## Bandstop

A bandstop filter will allow high frequencies and low frequencies to pass through the filter, but will attenuate all frequencies that lay within a certain band.

## Gain/Delay equalizers

Filters that cannot be classified into one of the above categories, are called gain or delay equalizers. They are mainly used to equalize the gain/phase in certain parts of the frequency spectrum as needed. More discussion on these kinds of advanced topics will be in [Signal Processing](/wiki/Signal_Processing).

**[Signals and Systems](/wiki/Signals_and_Systems)**

Filter design mostly bases on a limited set of widely used transfer functions. Optimization methods allow to design other types of filters, but the functions listed here have been studied extensively, and designs for these filters (including circuit designs to implement them) are readily available. The filter functions presented here are of lowpass type, and [transformation methods](/wiki/Signals_and_Systems/Filter_Transforms) allow to obtain other common filter types such as highpass, bandpass or bandstop.

## Butterworth Filters

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Butterworth_Filter_Orders.svg/350px-Butterworth_Filter_Orders.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Plot of the amplitude response of the normalized Butterworth lowpass transfer function, for orders 1 to 5

The [Butterworth filter function](http://en.wikipedia.org/wiki/Butterworth_filter) has been designed to provide a maximally flat amplitude response. This is obtained by the fact that all the derivatives up to the filter order minus one are zero at DC. The amplitude response has no ripple in the passband. It is given by:

    ![A\(j\\omega\) = |H\(j\\omega\)| = \\sqrt{ \\frac{1}{1+\\omega^{2n}} }](//upload.wikimedia.org/math/6/e/6/6e668271494d2403271ef3a7d7477f25.png)

It should be noted that whilst the amplitude response is very smooth, the step response shows noticeable overshoots. They are due to the phase response which is not linear or, in other words, to the group delay which is not constant.

The amplitude response plot shows that the slope is 20_n_ dB/decade, where _n_ is the filter order. This is the general case for all-pole lowpass filters. Zeroes in the transfer function can accentuate the slope close to their frequency, thus masking this general rule for zero-pole lowpass filters.

The plot also shows that whatever the order of the filter, all the amplitudes cross the same point at ![A\(\\omega = 1\) = \\frac {1}\\sqrt{2}](//upload.wikimedia.org/math/6/4/1/6417c1d0cebe023cdd641e00717c656d.png), which coresponds to approximatively -3 db. This -3 db reference is often used to specify the cutoff frequency of other kinds of filters.

Butterworth filters don't have a particularly steep drop-off but, together with [Chebyshev type I](/wiki/Signals_and_Systems/Filter_Implementations#Chebyshev_Type_I) filters, they are of all-pole kind. This particularity results in reduced hardware (or software, depending on the implementation method), which means that for a similar complexity, higher order Butterworth filters can be implemented, compared to functions with a steeper drop-off such as elliptic filters.

### Zeroes of the Butterworth function

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/5d/Butterworth_poles_4.svg/150px-Butterworth_poles_4.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Poles of a 4th order Butterworth filter

The normalized Butterworth function is indirectly defined by:

    ![H\(s\) \\cdot H\(-s\) = \\frac{1}{1+\\omega^{2n}}](//upload.wikimedia.org/math/e/0/d/e0d629ef6c6fc8712604793c1e4128a5.png)

This functions has zeroes regularily placed on the unit circle. Knowing that a stable filter has all of its poles on the left half s-plane, it is clear that the left half poles on the unit circle belong to ![H\(s\)](//upload.wikimedia.org/math/f/6/8/f68021749ff69bf0b89869d4358ea300.png), whilst the right half poles on the right belong to ![H\(-s\)](//upload.wikimedia.org/math/8/d/3/8d352740397761c68dee92599002b850.png).

The normalized Butterworth function has a cutoff frequency at ![f_c = \\omega_c / \(2 \\pi\) = 1/ \(2 \\pi\) \[Hz\]](//upload.wikimedia.org/math/8/9/a/89ac5d85f7ee5f2f5322a64ac76e361d.png). A different cutoff frequency is achieved by [scaling](/wiki/Signals_and_Systems/Filter_Transforms#Lowpass_to_Lowpass) the circle radius to ![\\omega_c = 2 \\pi f_c](//upload.wikimedia.org/math/9/c/b/9cb5455e55fe868942a6a8dc050338a8.png).

### Butterworth Transfer Function

The transfer function of a Butterworth filter is of the form:

    ![H\(s\) = \\frac{1}{den\(s\)}](//upload.wikimedia.org/math/7/0/2/7027e2bcac7b75686b2d52bba68a4909.png)

It can also be written as a function of the poles:

    ![H\(s\) = \\frac{k}{\\prod_{i=1}^N \(s-p_i\)}](//upload.wikimedia.org/math/0/6/e/06ea0d64be0c1d6ee7406e668c4d538e.png)

With this, the denominator ploynom is found from the values of the poles.

## Chebyshev Filters

In comparison to Butterworth filters, [Chebyshev filters](http://en.wikipedia.org/wiki/Chebyshev_filter) have a supplemental parameter: a ripple in amplitude. This ripple, wich could be considered as non ideal, has the tremendous advantage to allow a steeper roll-off between passband and stopband.

The ripple can happen in the passband, which is the case for Type I Chebyshev filters, or in the stopband for Type II filters.

### Chebyshev Polynomials

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Chebyshev_Polynomials_of_the_1st_Kind_%28n%3D0-5%2C_x%3D%28-1%2C1%29%29.svg/300px-Chebyshev_Polynomials_of_the_1st_Kind_%28n%3D0-5%2C_x%3D%28-1%2C1%29%29.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Chebyshev polynomials in the domain −1 < _x_ < 1

[Chebyshev Polynomials](http://en.wikipedia.org/wiki/Chebyshev_polynomials) have the property to remain in the range ![-1 < T_n\(x\) < 1](//upload.wikimedia.org/math/7/5/e/75ec7c972a2c01c4df27657d46190a72.png) for an input in the range −1 < _x_ < 1 and then rapidly grow outside this range. This characteristic is a good prerequisite for devising transfer functions with limited oscillations in a given frequency range and steep roll-offs at its borders.

The Chebyshev polynomials of the first kind are defined by the recurrence relation:

    ![
\\begin{align}
T_0\(x\) & = 1 \\\\
T_1\(x\) & = x \\\\
T_{n+1}\(x\) & = 2x \\cdot T_n\(x\) - T_{n-1}\(x\).
\\end{align}
](//upload.wikimedia.org/math/8/8/6/886ff6362145db703410a99f0dce61dc.png)

The first Chebyshev polynomials of the first kind are:

    ![ T_0\(x\) = 1](//upload.wikimedia.org/math/8/c/9/8c91124e07a4fe0ea6aa827b15305c2d.png)

    ![ T_1\(x\) = x](//upload.wikimedia.org/math/9/9/e/99ec780549f1436bc2b55543be68dc02.png)

    ![ T_2\(x\) = 2x^2 - 1](//upload.wikimedia.org/math/a/0/2/a0262b66497ce717194c3659471664e2.png)

    ![ T_3\(x\) = 4x^3 - 3x](//upload.wikimedia.org/math/c/7/5/c756b7012acc269f637e7577e345e2ee.png)

    ![ T_4\(x\) = 8x^4 - 8x^2 + 1](//upload.wikimedia.org/math/f/b/2/fb2c38c78b44dd01e9d8fffa37109488.png)

### Chebyshev Type I

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Chebyshev_Type_I_Filter_Response_%284th_Order%29.svg/350px-Chebyshev_Type_I_Filter_Response_%284th_Order%29.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Frequency response of a fourth-order type I Chebyshev filter

Chebyshev type I filters show a ripple in the passband. The [amplitude response](/wiki/Signals_and_Systems/Frequency_Response#Amplitude_Response) as a function of angular frequency ![\\omega](//upload.wikimedia.org/math/4/d/1/4d1b7b74aba3cfabd624e898d86b4602.png) of the _n_th-order low-pass filter is:

    ![G_n\(\\omega\) = \\left | H_n\(j \\omega\) \\right | = \\frac{1}{\\sqrt{1+\\varepsilon^2 T_n^2\\left\(\\frac{\\omega}{\\omega_0}\\right\)}}](//upload.wikimedia.org/math/e/4/b/e4b804935e6108bf5211850abc3ff2ce.png)

where ![\\varepsilon](//upload.wikimedia.org/math/c/6/9/c691dc52cc1ad756972d4629934d37fd.png) is the ripple factor, ![\\omega_0](//upload.wikimedia.org/math/d/4/d/d4df4d2cdd8cdb93b8868b4d5c22bcc2.png) is the [cutoff frequency](/w/index.php?title=Cutoff_frequency&action=edit&redlink=1) and ![T_n\(\)](//upload.wikimedia.org/math/a/1/0/a100f6eb66a5905be6dec68954174b0f.png) is a [Chebyshev polynomial](/wiki/Signals_and_Systems/Filter_Implementations#Chebyshev_Polynomials) of order ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png).

The passband exhibits equiripple behavior, with the ripple determined by the ripple factor ![\\varepsilon](//upload.wikimedia.org/math/c/6/9/c691dc52cc1ad756972d4629934d37fd.png). In the passband, the Chebyshev polynomial alternates between 0 and 1 so the filter gain will alternate between maxima at _G_ = 1 and minima at ![G=1/\\sqrt{1+\\varepsilon^2}](//upload.wikimedia.org/math/d/5/2/d52313d996fea16284987a50a3396b3c.png). At the cutoff frequency ![\\omega_0](//upload.wikimedia.org/math/d/4/d/d4df4d2cdd8cdb93b8868b4d5c22bcc2.png) the gain again has the value ![1/\\sqrt{1+\\varepsilon^2}](//upload.wikimedia.org/math/a/c/3/ac331d4dd5f075df7d57481023c9d283.png) but continues to drop into the stop band as the frequency increases. This behavior is shown in the diagram on the right. The common practice of defining the cutoff frequency at −3 [dB](/w/index.php?title=Decibel&action=edit&redlink=1) is usually not applied to Chebyshev filters; instead the cutoff is taken as the point at which the gain falls to the value of the ripple for the final time.

### Chebyshev Type II

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/ba/ChebyshevII_response.png/350px-ChebyshevII_response.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Frequency response of a fifth-order type II Chebyshev filter

Chebyshev Type II filters have ripples in the stopband. The amplitude response is:

    ![G_n\(\\omega,\\omega_0\) = \\frac{1}{\\sqrt{1+ \\frac{1} {\\varepsilon^2 T_n ^2 \\left \( \\omega_0 / \\omega \\right \)}}}.](//upload.wikimedia.org/math/6/2/9/62928e0d4d2d7c33197ebf6cfe075bfc.png)

In the stopband, the gain will always be smaller than

    ![\\frac{1}{\\sqrt{1+ \\frac{1}{\\varepsilon^2}}}](//upload.wikimedia.org/math/0/4/4/04442ec242d4506092f6bc05660f4722.png)

Also known as inverse Chebyshev, this filter function is less common because it does not roll-off as fast as type I, and requires more components. Indeed, the transfer function exhibits not only poles but also zeroes.

## Elliptic Filters

[Elliptic filters](http://en.wikipedia.org/wiki/Cauer_filter), also called Cauer filters, suffer from a ripple effect like Chebyshev filters. However, unlike the type 1 and Type 2 Chebyshev filters, Elliptic filters have ripples in both the passband and the stopband. To counteract this limitation, Elliptic filters have a very aggressive rolloff, which often more than makes up for the ripples.

## Comparison

The following image shows a comparison between 5th order Butterworth, Chebyshev and elliptic filter amplitude responses.

![Electronic linear filters.svg](//upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Electronic_linear_filters.svg/500px-Electronic_linear_filters.svg.png)

## Bessel Filters

## Filter Design

Using what we've learned so far about filters, this chapter will discuss filter design, and will show how to make decisions as to the type of filter (Butterworth, Chebyshev, Elliptic), and will help to show how to set parameters to acheive a set of specifications.

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Normalized Lowpass Filter

When designing a filter, it is common practice to first design a normalized low-pass filter, and then use a spectral transform to transform that low-pass filter into a different type of filter (high-pass, band-pass, band-stop).

The reason for this is because the necessary values for designing lowpass filters are extensively described and tabulated. From this, filter design can be reduced to the task of looking up the appropriate values in a table, and then transforming the filter to meet the specific needs.

## Lowpass to Lowpass Transformation

Converting a normalized lowpass filter to another lowpass filter allows to set the cutoff frequency of the resulting filter. This is also called [frequency scaling](http://en.wikipedia.org/wiki/Prototype_filter#Frequency_scaling).

### Transformation

Having a normalized transfer function, with cutoff frequency of 1 Hz, one can modify it in order to move the cutoff frequency to a specified value ![f_c](//upload.wikimedia.org/math/e/8/b/e8bb47f19d155ab9dd7fcd948f365e60.png).

This is done with the help of the following replacement:

    ![s \\to f_c \\cdot s ](//upload.wikimedia.org/math/d/9/1/d912a79709fa258f0925717c37427096.png)

### Transfer Function

As an example, the [biquadratic transfer function](/wiki/Signals_and_Systems/Second_Order_Transfer_Function#Biquadratic_Second_Order_Transfer_Function)

    ![H\(s\) = \\frac{Y\(s\)}{X\(s\)} = \\frac{b_2 s^2 + b_1 s + b_0}{a_2 s^2 + a_1 s + a_0}](//upload.wikimedia.org/math/f/2/0/f20b5ada1a06241d367c1b526ea43148.png)

will be transformed into:

    ![H\(s\) = \\frac{Y\(s\)}{X\(s\)} = \\frac{b_2 f_c^2 s^2 + b_1 f_c s + b_0}{a_2 f_c^2 s^2 + a_1 f_c s + a_0}](//upload.wikimedia.org/math/6/6/8/6686c201817c70c368d3008caa96d1af.png)

In the transfer function, all coefficients are multiplied by the corresponding power of ![f_c](//upload.wikimedia.org/math/e/8/b/e8bb47f19d155ab9dd7fcd948f365e60.png).

### Analog Element Values

If the filter is given by a circuit and its R, L and C element values found in a table, the transfer function is scaled by changing the element values.

The resistance values will stay as they are (a further impedance scaling can be done).

The capacitance values are changed according to:

    ![\\frac{1}{sC} \\to \\frac{1}{s f_c \\frac{C}{f_c}} ](//upload.wikimedia.org/math/6/a/7/6a764ddbf8e3bcbc512a7e56af878718.png)

The inductance values are changed according to:

    ![sL \\to s f_c \\frac{L}{f_c} ](//upload.wikimedia.org/math/c/8/9/c898f769f39a987ebcf17d56abff9a5d.png)

In the circuit, all capacitances and inductances values are divided by ![f_c](//upload.wikimedia.org/math/e/8/b/e8bb47f19d155ab9dd7fcd948f365e60.png).

## Lowpass to Highpass

This operation can be performed using this [MATLAB](/wiki/MATLAB_Programming) command:  
**lp2hp**

Converting a lowpass filter to a highpass filter is one of the easiest transformations available. To transform to a highpass, we will replace all S in our equation with the following:

![S = \\frac{\\Omega_p \\hat{\\Omega_p}}{\\hat{S}}](//upload.wikimedia.org/math/f/0/1/f0107ecc92e3d4f080f3162ec920adb0.png)

## Lowpass to Bandpass

This operation can be performed using this [MATLAB](/wiki/MATLAB_Programming) command:  
**lp2bp**

To Convert from a low-pass filter to a bandpass filter requires that we replace S with the following:

![S = ](//upload.wikimedia.org/math/1/9/b/19bc6aa0522d3238dcd2ad02c995999d.png)

## Lowpass to Bandstop

This operation can be performed using this [MATLAB](/wiki/MATLAB_Programming) command:  
**lp2bs**

To convert a lowpass filter to a bandstop filter, we replace every reference to S with:

![S = ](//upload.wikimedia.org/math/1/9/b/19bc6aa0522d3238dcd2ad02c995999d.png)

**[Signals and Systems](/wiki/Signals_and_Systems)**

The [Laplace transform](/wiki/Signals_and_Systems/LaPlace_Transform) has shown to allow to analyse the [frequency response](/wiki/Signals_and_Systems/Frequency_Response) of circuits based on the differential equations of their capacitive and inductive components. Filter design starts with finding the proper transfer function in order to ampify selected parts of a signal and to damp other ones as a function of their frequency.

Choosing the proper filter structure and deriving the coefficient values is a further topic prensented in the wikibook [Signal Processing](http://en.wikibooks.org/wiki/Signal_Processing/Filter_Design) which deals with the application of signal and systems.

## Brick-wall filters

Separating signal from noise or different signals in the same transmission channel basing on their frequency content is best done with a [brick-wall filter](http://en.wikipedia.org/wiki/Sinc_filter#Brick-wall_filters) which shows full transmission in the passband and complete attenuation in the nearby stopbands, with abrupt transitions.

This can be done with the help of the [Fourier transform](/wiki/Signals_and_Systems/Aperiodic_Signals) which provides complete information of the frequency content of a given signal. Having calculated a Fourier transform, one can zero out unwanted frequency contents and calculate the [inverse Fourier Transform](/wiki/Signals_and_Systems/Aperiodic_Signals#Inverse_Fourier_Transform), in order to provide the signal filtered with a brick-wall gauge.

The [Fourier transform](/wiki/Signals_and_Systems/Aperiodic_Signals#Fourier_Transform) being given by:

    ![\\mathcal{F}\(f\(t\)\) = F\(j\\omega\) = \\int_{-\\infty}^\\infty f\(t\)e^{-j\\omega t}dt](//upload.wikimedia.org/math/9/2/6/926dc463e8a4d9658f2850b0cee853e8.png)

one finds out that the Fourier transform integral, with its infinite bounds, would have to be calculated from the day of the creation of our universe and all the way up to the day of its decay before the integral could have been fully calculated. And only then can the ideal brick-wall filtered signal be delivered.

In more technical terms, the ideal brick-wall filter suffers from an infinite latency.

## Analog filters

The analysis of analog circuits shows that their outputs are related to their input by a set of differential equations. The [Laplace transform](/wiki/Signals_and_Systems/LaPlace_Transform) rewrites these differential equations as a set of linear equations of the complex variable ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png). With this, a polynomial function multiplying the Laplace transform of the input signal can be equated to another polynomial function multiplying the Laplace transform of the ouput signal:

    ![\(b_m s^{m} + b_{m-1} s^{m-1} + \\ldots + b_1 s + b_0\) \\cdot X\(s\) = \(a_n s^{n} + a_{n-1} s^{n-1} + \\ldots + a_1 s + a_0\) \\cdot Y\(s\)](//upload.wikimedia.org/math/3/f/e/3fef5f760c72a42c0c556745b76c33bb.png)

Thus, the transfer function of a realizable analog filter can be written as the ratio of two polynomial functions of ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png):

    ![H\(s\) = \\frac{Y\(s\)}{X\(s\)} = \\frac{b_m s^{m} + b_{m-1} s^{m-1} + \\ldots + b_1 s + b_0}{a_n s^{n} + a_{n-1} s^{n-1} + \\ldots + a_1 s + a_0}](//upload.wikimedia.org/math/a/a/d/aadaa9611cdc54503dbeae0acf01578c.png)

Hence, the problem of analog filter design is to find a pair of polynomial functions which, put together, best approximate the ideal but not realizable brick-wall transfer function.

In the early days of electric signal processing, scientists have come up with [filter functions](/wiki/Signals_and_Systems/Filter_Implementations) which are still largely used today. The functions they have devised are all of lowpass type. [Frequency transformation](/wiki/Signals_and_Systems/Filter_Transforms) techniques allow to find polynomials for other [filter types](/wiki/Signals_and_Systems/Filter_Terminology) such as highpass and bandpass.

## The Complex Plane

The transfer function of an analog filter is the ratio of two polynomial functions of ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png):

    ![H\(s\) = \\frac{Y\(s\)}{X\(s\)} = \\frac{num\(s\)}{den\(s\)}](//upload.wikimedia.org/math/8/7/b/87bcb4bb68aa464d0735fe5a12639ea3.png)

![](//upload.wikimedia.org/wikibooks/en/thumb/2/2a/S_Plane.svg/220px-S_Plane.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

The complex plane of ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png)

The variable ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png) is a complex number which can be written as ![s = \\sigma + i \\cdot \\omega](//upload.wikimedia.org/math/5/8/c/58c407eebff81f0ccc09b30c78ff9f5b.png). The complex plane is a plane with the imaginary axis vertical and the horizontal axis as the real part.

The roots of the transfer function numerator polynom are called the transfer function _zeroes_. The roots of the transfer function denominator polynom are called the transfer function _poles_.

The transfer function can be written as a function of its zeroes ![z_i](//upload.wikimedia.org/math/b/7/2/b72ebeb95f4bb3e84afd94141a57b13b.png), its poles ![p_i](//upload.wikimedia.org/math/8/a/4/8a4bbd153c74655abb7ca04c0fa901d8.png) and an additional gain factor ![k](//upload.wikimedia.org/math/8/c/e/8ce4b16b22b58894aa86c421e8759df3.png) in the form:

    ![H\(s\) = k \\cdot \\frac{\\prod_{i=1}^M \(s-z_i\)}{\\prod_{i=1}^N \(s-p_i\)}](//upload.wikimedia.org/math/6/d/2/6d2b98737ed8a9224ab5d8dc15e4576f.png)

The poles and the zeroes of a transfer function can be drawn in the complex plane. Their position provide information about the [frequency response](/wiki/Signals_and_Systems/Frequency_Response) of the system. Indeed, the frequency response is equal to the transfer function taken for ![s = i \\omega](//upload.wikimedia.org/math/b/2/d/b2dc29acea1f518874489dfbc1f4da92.png), which is along the imaginary axis.

    ![\\frac{Y\(i \\omega\)}{X\(i \\omega\)} = H\(s = i \\omega\)](//upload.wikimedia.org/math/a/0/c/a0cd02423ca4eb8f3939fae7f40d8881.png)

### Effect of Poles

A stable [LTI system](/wiki/Signal_Processing/Fourier_Analysis#LTI_Systems) has all its poles on the left side half plane of ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png).

If a pole would be located on the imaginary axis, at ![p = i \\omega_p](//upload.wikimedia.org/math/a/5/f/a5ffe32be3987fb776cbc4d172313ecd.png), then the factor ![1/{\(s-p\)}](//upload.wikimedia.org/math/2/1/c/21c0880763e81bfea9fd276d8829ab9d.png) of the transfer function would be infinite at the point ![s = i \\omega_p](//upload.wikimedia.org/math/6/6/f/66f1de6e4ab65afeaf773b4016dbabda.png) and so would the global frequency response ![H\(s = i \\omega_p\)](//upload.wikimedia.org/math/8/2/5/825151c9e66167b79b2e99ba774558ff.png).

For poles close to the imaginary axis, the frequency response takes a large amplitude for frequencies close to them. In other words, poles close to the imaginary axis indicate the passband.

### Effect of Zeros

If a zero is located on the imaginary axis, at ![z = i \\omega_z](//upload.wikimedia.org/math/6/4/5/64564a3ad448f4875725041cbe9be00b.png), then the factor ![\(s-z\)](//upload.wikimedia.org/math/1/f/1/1f1a4b0938e6581af059a2e0df894629.png) of the transfer function is zero at the point ![s = i \\omega_z](//upload.wikimedia.org/math/b/7/7/b77a1674ec9ddfd42f9016e5eacd82d3.png) and so is the global frequency response ![H\(s = i \\omega_z\)](//upload.wikimedia.org/math/1/b/8/1b898646a5c0325e698e8469ce77ca77.png).

Zeroes on, or close to the imaginary axis indicate the stopband.

## Designing Filters

Devising the proper transfer function for a given filter function goes through the following steps:

  * selecting a normalized [filter function](/wiki/Signals_and_Systems/Filter_Implementations)
  * [transforming and scaling](/wiki/Signals_and_Systems/Filter_Transforms) the function for the particular needs

The coefficients of the numerator and denominator coefficients are finally used to calculate the element values of a selected [filter circuit](http://en.wikibooks.org/wiki/Signal_Processing/Analog_Filters).

### Example: Lowpass Filter

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/G712-Butterworth.svg/220px-G712-Butterworth.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

CCITT G712 input lowpass filter specification

A reduced version of CCITT G712 input filter specification, giving only the lowpass part, is shown in the plot on the side.

The passband goes up to ![3 kHz](//upload.wikimedia.org/math/8/7/b/87ba05db0cfbb7bbd37632da26cd24ad.png) and allows a maximal ripple of ![0.125 dB](//upload.wikimedia.org/math/9/f/2/9f22b61311a65b7a2e5aadd6f13671cf.png). The stopband requires an attenuation of ![14 dB](//upload.wikimedia.org/math/9/c/a/9ca6b9c6316f93fcb3a38cb32b9cc1fc.png) at ![4 kHz](//upload.wikimedia.org/math/e/3/e/e3ed0c30c71127b70fcde9b057cbff3c.png) and an attenuation of ![32 dB](//upload.wikimedia.org/math/5/a/3/5a3b93daed69a3f852fd560c5711a7c4.png) above ![4.6 kHz](//upload.wikimedia.org/math/1/1/f/11f1993f622c35272bf4500f77669e3b.png).

#### Filter Function

As a first step, we have to choose a [filter function](/wiki/Signals_and_Systems/Filter_Implementations).

Programs such as [Octave](/wiki/Octave_Programming_Tutorial) or Matlab provide functions which allow to determine the minimal filter order required to fulfill a given specification. This is a good help when choosing from the possible functions.

Let's however here arbitrarily choose a [Butterworth transfer function](/wiki/Signals_and_Systems/Filter_Implementations#Butterworth_Filters).

#### Normalized Filter Function

The following [Octave](http://en.wikibooks.org/wiki/Octave_Programming_Tutorial) script allows to plot the amplitudes of normalized Butterworth transfer functions from order 8 to 16.
    
    
    #-------------------------------------------------------------------------------
    # Specifications
    #
    fs = 40E3;
    fPass = 3000;
    rPass = 0.125;
    fStop1 = 4000;
    rStop1 = 14;
    fStop2 = 4600;
    rStop2 = 32;
    
    pointNb = 1000;
    AdbMin = 40;
    
    makeGraphics = 1;
    figureIndex = 0;
    
    #===============================================================================
    # Normalized filter function
    #
    wLog = 2*pi*logspace(-1, 1, pointNb);
    fc = 0.87;
    Adb = [];
    for order = 8:16
      [num, den] = butter(order, 2*pi, 's');
      while ( length(num) < length(den) )
        num = [0, num];
      endwhile;
      Adb = [Adb; 20*log10(abs(freqs(num, den, wLog)))];
    endfor
    Adb(Adb < -AdbMin) = -AdbMin;
    
    figureIndex = figureIndex+1;
    figure(figureIndex);
    
    semilogx(wLog/(2*pi), Adb);
    hold on;
    semilogx([wLog(1)/(2*pi), fc, fc], -[rPass, rPass, AdbMin], 'r');
    semilogx([fStop1*fc/fPass, fStop1*fc/fPass, fStop2*fc/fPass, fStop2*fc/fPass, wLog(length(wLog))/(2*pi)], ...
            -[0     , rStop1, rStop1, rStop2, rStop2            ], 'r');
    hold off;
    axis([wLog(1)/(2*pi), wLog(length(wLog))/(2*pi), -AdbMin, 0]);
    grid;
    xlabel('frequency [Hz]');
    ylabel('amplitude [dB]');
    
    if (makeGraphics != 0)
      print -dsvg g712_butterworth_normalized.svg
    endif
    

The following figure shows the result: one needs at least a 13th order Butterworth filter to meet the specifications.

![G712 butterworth normalized](//upload.wikimedia.org/wikipedia/commons/thumb/b/b4/G712_butterworth_normalized.svg/512px-G712_butterworth_normalized.svg.png)

On the graph, one can note that all the amplitude responses go through the same point at -3 dB.

The specification frequencies have been scaled down to fit to the normalized cutoff frequency of 1 Hz. In the script, one might have noted an additional scaling factor of `fc = 0.87`: this is due to the fact that the corner cutoff amplitude is -0.125 dB and not -3 dB. That value has been adjusted by hand for this example. Again, Octave or Matlab scripts automate this task.

#### Denormalized Filter Function

The [frequency scaling](/wiki/Signals_and_Systems/Filter_Transforms#Lowpass_to_Lowpass) of the normalized transfer function is done by replacing

![s \\to f_c \\cdot s ](//upload.wikimedia.org/math/d/9/1/d912a79709fa258f0925717c37427096.png)

The following Octave script does this by multiplying the numerator and denominator coefficients by the appropriate power of ![f_c](//upload.wikimedia.org/math/e/8/b/e8bb47f19d155ab9dd7fcd948f365e60.png).
    
    
    #-------------------------------------------------------------------------------
    # Denormalized filter function
    #
    order = 13;
    wLog = 2*pi*logspace(2, 5, pointNb);
    fc = 0.87;
    
    [num, den] = butter(order, 2*pi, 's');
    while ( length(num) < length(den) )
      num = [0, num];
    endwhile;
    for index = 1:order+1
      num(index) = num(index) * (fPass/fc)^(index-1);
      den(index) = den(index) * (fPass/fc)^(index-1);
    endfor
    Adb = 20*log10(abs(freqs(num, den, wLog)));
    Adb(Adb < -AdbMin) = -AdbMin;
    
    figureIndex = figureIndex+1;
    figure(figureIndex);
    
    semilogx(wLog/(2*pi), Adb);
    hold on;
    semilogx([wLog(1)/(2*pi), fPass, fPass], -[rPass, rPass, AdbMin], 'r');
    semilogx([fStop1, fStop1, fStop2, fStop2, wLog(length(wLog))/(2*pi)], ...
            -[0     , rStop1, rStop1, rStop2, rStop2            ], 'r');
    hold off;
    axis([wLog(1)/(2*pi), wLog(length(wLog))/(2*pi), -AdbMin, 0]);
    grid;
    xlabel('frequency [Hz]');
    ylabel('amplitude [dB]');
    
    if (makeGraphics != 0)
      print -dsvg g712_butterworth.svg
    endif
    

![G712 butterworth](//upload.wikimedia.org/wikipedia/commons/thumb/9/95/G712_butterworth.svg/512px-G712_butterworth.svg.png)

The coefficients of the numerator and denominator coefficients are now ready to be used to calculate the element values of a selected [filter circuit](http://en.wikibooks.org/wiki/Signal_Processing/Analog_Filters).

# Introduction to Digital Signals

## Sampled Systems

Digital signals are by essence sampled signals. In a circuit node, the numbers change at a given rate: the _sampling rate_ or _sampling frequency_. The time between two changes of the signal is the inverse of the sampling frequency: it is the _sampling period_.

In processor systems, samples are stored in memory. In logic ciruits, they correspond to register outputs. The sampling period is used to compute the next value of all signals in the system.

Digital circuits are not the only sampled systems: analog circuits such as switched capacitor filters also rely on switches and are sampled too.

## Sampling a signal

### The Nyquist Rate

Sampling a signal raises a major question: does one lose information during this process?

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/9/93/Evolution-tasks.png/40px-Evolution-tasks.png)

**Example:** Checking (= sampling) the traffic lights once an hour certainly makes one erratically react to their signalling (= lose information). 

On the other side, sampling the traffic lights once per microsecond doesn't bring much more information than sampling it every millisecond.

Obviously, the traffic lights, as any other signals, have to be sampled at a faster rate than they change, but sampling them very much faster doesn't bring more information.

The [Nyquist rate](http://en.wikipedia.org/wiki/Nyquist_rate) is the minimum sampling rate required to avoid loss of information.

    ![f_N \\ \\stackrel{\\mathrm{def}}{=}\\   2 f_b](//upload.wikimedia.org/math/f/7/0/f70f5b2315f3dde99f39a3e7b539d928.png)

where ![f_b](//upload.wikimedia.org/math/1/6/9/16915332fbd2ebd4469e49d8bf3184ad.png) is the highest frequency of the signal to be sampled, also called _bandwidth_.

To avoid losing information, the sampling rate must be higher than the Nyquist rate:

    ![f_s > f_N](//upload.wikimedia.org/math/5/b/4/5b42107a6e1535c91d5ffe4ecc710b37.png)

In practice, the sampling rate is taken with some margin, in order to more easily reconstruct the original signal.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/9/93/Evolution-tasks.png/40px-Evolution-tasks.png)

**Example:** [audio content sampling rates](http://en.wikipedia.org/wiki/Sampling_rate)

The full range of human hearing is between 20 Hz and 20 kHz. Thus, audio content has to be sampled at more than 40 kHz.

And indeed:

  * CD audio samples the signals at 44.1 kHz.
  * Professional digital video equipment samples them at 48 kHz.
  * DVD audio samples them at 96 kHz.
  * High end DVD audio doubles this frequency to 192 kHz.

### Aliasing

Sampling a signal with a rate lower than the Nyquist Rate produces [aliasing](http://en.wikipedia.org/wiki/Aliasing) or _folding_.

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/28/AliasingSines.svg/350px-AliasingSines.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Effect of aliasing.

The picture on the right shows a red sinewave of frequency 0.9 (and thus of a period close to 1.1). This signal should be sampled with a frequency larger than 1.8. However, the signal has been sampled with a rate of 1 (vertical lines and black dots). If one tries to draw a line between the samples, the result will look like the blue curve wich is a sinewave of period 10, or of frequency 0.1.

If the signal would have been sampled at a rate of 0.9, the sampling points would always fall on the same point in the sine function and the resulting signal would seem to be a constant.

Sampling a signal of frequency 0.9 with a rate of 1 creates an alias with the frequency of ![1 - 0.9 = 0.1](//upload.wikimedia.org/math/e/f/5/ef525280e6e725f9ac05c6b178f2b403.png).

Sampling a signal of frequency 0.9 with a rate of 0.9 creates an alias at DC, and so with the frequency of ![0.9 - 0.9 = 0](//upload.wikimedia.org/math/0/1/6/01659eee3c82660c6cba6bb004d69b8e.png).

Sampling a signal of frequency 0.9 with a rate of 0.8 also creates an alias with the frequency of ![0.9 - 0.8 = 0.1](//upload.wikimedia.org/math/9/7/b/97b398a427a8d96ec4d4d44e6da6bc10.png), but with a different phase.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/9/93/Evolution-tasks.png/40px-Evolution-tasks.png)

**Example:** A well known example of aliasing is the stroboscope. 

Illuminating a motor turning at a frequency of 90 Hz with a stroboscope switching at 100 Hz gives us the impression that is it turning at 100 Hz - 90 Hz = 10 Hz.

Illuminating a motor turning at a frequency of 90 Hz with a stroboscope switching at 90 Hz gives us the impression that is it standing still.

Illuminating a motor turning at a frequency of 90 Hz with a stroboscope switching at 80 Hz gives us the impression that is it turning at 90 Hz - 80 Hz = 10 Hz, but in the opposite direction.

This is the same effect seen in many American Western movies containing stagecoach scenes. At various rotational rates, the wheels on the stagecoach will appear to rotate forward, stand still, or rotate backward. See [Wagon-wheel effect](http://en.wikipedia.org/wiki/Wagon-wheel_effect).

It is as if the spectrum of the signal has been folded back down at a point equal to half the sampling frequency.

### Undersampling

Sampling a a frequency lower than the Nyquist rate, also called _undersampling_, creates sinewave aliases at a lower frequency. If the original signal also has content at these lower frequencies, then they will be mixed and there is a loss of information.

However, if the signal has only high-frequency content, then the undersampling process modulates the signal at a lower frequency.

This is a cheap alternative to modulating by the multiplication with a modulation sinewave.

### Oversampling

Oversampling corresponds to sampling with a frequency much higher (typically 100 to 1000) than the Nyquist rate. The interest of oversampling is to be able to represent the signal with a smaller amount of bits.

This can be explained by the mechanism used to gain the additional bits back: a signal sampled at 10 kHz can be downsampled at 5 kHz as long as the new sampling frequency remains greater than the Nyquist frequency. The downsampling implies having two times fewer samples. Rather than throwing every second sample away, one can calculate the mean value of two consecutive samples and use this result to build one sample of the new signal. Calculating the mean value corresponds to add the values and divide them by two. Rather than dividing the result by two and throwing away the bit after the decimal point, one can only add the consecutive samples two by two. With this, the amplitude of the 5 kHz signal is twice the one of the original 10 kHz signal. In other words, it has to be represented by 1 more bits.

A largely used application of oversampling is [Pulse Width Modulation](http://en.wikipedia.org/wiki/Pulse_width_modulation) (PWM). The modulated signal is represented with a single bit switching at a frequency equal to ![{2^n} \\cdot f_N](//upload.wikimedia.org/math/1/1/8/11871257330c9cfca976582da76108a6.png), where ![f_N](//upload.wikimedia.org/math/2/5/7/2578b6443fa2df37c771d42a0df6fcea.png) is the Nyquist frequency of the original signal and ![n](//upload.wikimedia.org/math/7/b/8/7b8b965ad4bca0e41ab51de7b31363a1.png) the number of bits with which it is represented. This one bit signal is ideal to drive high-current loads with a single power switch. PWM is typically used for driving electric motors.

A more complex coding scheme for a result on a single bit is found in every CD player: [sigma-delta](http://en.wikipedia.org/wiki/Delta-sigma_modulation) modulation. There is more theory required for understanding its working. Let us state that it is able to represent a signal on a single bit at a lower sampling frequency than the PWM. On the other hand, the one bit signal switches back and forth more frequently at its sampling frequency and is thus less indicated for driving slower high-current switches. Sigma-delta modulation is used for driving lighter loads such as the cable between the CD player and the audio amplifier.

![Example](//upload.wikimedia.org/wikipedia/commons/thumb/9/93/Evolution-tasks.png/40px-Evolution-tasks.png)

**Example:** [Super Audio CD](http://en.wikipedia.org/wiki/Super_Audio_CD) (SACD) 

The SACD codes the audio in the form of a [Direct Stream Digital](http://en.wikipedia.org/wiki/Direct_Stream_Digital) signal coded on a single bit at 64 times the CD sampling rate of 44.1 kHz.

## Z Transform

The _Z Transform_ is used to represent sampled signals and [Linear Time Invariant](/wiki/Signals_and_Systems/Time_Domain_Analysis#Linear_Time_Invariant_.28LTI.29_Systems) (LTI) systems, such as filters, in a way similar to the Laplace transform representing continuous-time signals.

### Signal representation

The _Z Transform_ is used to represent sampled signals in a way similar to the Laplace transform representing continuous-time signals.

A sampled signal is given by the sum of its samples, each one delayed by a different multiple of the sampling period. The Laplace transform represents a delay of one sampling period ![T_s](//upload.wikimedia.org/math/7/9/8/7982e3501002a129d3be46449ae95129.png) by:

    ![z^{-1} \\stackrel{\\mathrm{def}}{=} e^{-sT_s}](//upload.wikimedia.org/math/3/f/4/3f4591ef3771e2b40ae2f8957b02fa27.png)

With this, the Z-transform can be represented as

    ![X\(z\) = \\mathcal{Z}\\{x\[n\]\\} = \\sum_{n=0}^{\\infty} x\[n\] z^{-n} ](//upload.wikimedia.org/math/4/1/6/416110fb1f727d6e9c2c17e3047786f9.png)

where the ![x\[n\]](//upload.wikimedia.org/math/d/3/b/d3baaa3204e2a03ef9528a7d631a4806.png) are the consecutive values of the sampled signal.

### Linear time invariant systems

Continuous-time Linear Time Invariant (LTI) systems can be represented by a transfer function which is a fraction of two polynomials of the complex variable ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png).

    ![H\(s\) = \\frac{num\(s\)}{den\(s\)}](//upload.wikimedia.org/math/2/0/1/2016e28b97d4c8c54c0b3784b141fb8d.png)

Their frequency response is estimated by taking ![s = j\\omega](//upload.wikimedia.org/math/a/8/5/a85b8a883b07d53a9bf9d8c408de5c5c.png), this is by estimating the transfer function along the imaginary axis.

In order to ensure stability, the poles of the transfer function (the roots of the denominator polynomial) must be on the left half plane of ![s](//upload.wikimedia.org/math/0/3/c/03c7c0ace395d80182db07ae2c30f034.png).

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/48/Z-transform_unit_circle.svg/220px-Z-transform_unit_circle.svg.png)

![](//bits.wikimedia.org/static-1.22wmf17/skins/common/images/magnify-clip.png)

Z-plane unit circle

Discrete-time LTI systems can be represented by the fraction of two polynomials of the complex variable ![z](//upload.wikimedia.org/math/f/b/a/fbade9e36a3f36d3d676c1b808451dd7.png):

    ![H\(z\) = \\frac{num\(z\)}{den\(z\)}](//upload.wikimedia.org/math/6/6/e/66e8f8284ffd54441359f6d030f31790.png)

From the definition:

    ![z \\stackrel{\\mathrm{def}}{=} e^{sT_s}](//upload.wikimedia.org/math/c/a/5/ca500ae060268422a42870e246449cbe.png)

we find that their frequency response can be estimated by taking ![z = e^{j\\omega T_s}](//upload.wikimedia.org/math/7/0/9/709510274420fb123f7c39c908c73606.png), this is by estimating the transfer function around the unit circle.

In order to ensure stability, the poles of the transfer function (the roots of the denominator polynomial) must be inside the unit circle.

### Transfer function periodicity

The transfer function is estimated around the unit circle:

  * The point at coordinate ![z = 1 +  j 0](//upload.wikimedia.org/math/c/7/9/c794e08260e53f3be52d5f22e8145d96.png) corresponds to frequency ![f = 0](//upload.wikimedia.org/math/9/0/3/9030c9fdd1390d3ed9f1a55b1611aa74.png), which is DC.
  * The point at coordinate ![z = 0 +  j 1](//upload.wikimedia.org/math/2/8/3/28396e53454eae4bcea3a75258f9e880.png) corresponds to frequency ![f = f_s / 4](//upload.wikimedia.org/math/3/1/5/315cf330d1f510663e75b8e1c601a918.png), the quarter of the sampling frequency.
  * The point at coordinate ![z = -1 +  j 0](//upload.wikimedia.org/math/0/f/3/0f3a94503613e7496fae0be9c1d4f122.png) corresponds to frequency ![f = f_s / 2](//upload.wikimedia.org/math/7/9/6/796658a368059bafeb8ee3c50717e82b.png), half the sampling frequency.
  * The point at coordinate ![z = 0 -  j 1](//upload.wikimedia.org/math/3/6/3/36313ea17d11eb5f24ac6a6d2adaa4a0.png) corresponds to frequency ![f = 3 / 4 f_s](//upload.wikimedia.org/math/e/d/d/edd690f4b9e31a8f2947bcb967983c30.png).
  * The point at coordinate ![z = 1 +  j 0](//upload.wikimedia.org/math/c/7/9/c794e08260e53f3be52d5f22e8145d96.png) corresponds to frequency ![f = f_s](//upload.wikimedia.org/math/0/c/c/0ccc51fe716857016883f4c3929293bd.png) which is the sampling frequency.

So having turned once around the unit circle, one falls back to the starting point ![z = 1 +  j 0](//upload.wikimedia.org/math/c/7/9/c794e08260e53f3be52d5f22e8145d96.png). From there, one can make another turn from ![f_s](//upload.wikimedia.org/math/8/6/5/8653b0fc6514069daddc75ff8fa12b72.png) to ![2 f_s](//upload.wikimedia.org/math/3/c/a/3caff823cb9c040d8be5b754b7860f69.png), and one more from ![2 f_s](//upload.wikimedia.org/math/3/c/a/3caff823cb9c040d8be5b754b7860f69.png) to ![3 f_s](//upload.wikimedia.org/math/0/b/4/0b4f23fa31a6f48760e95c9e0fad7115.png) and so on... On each of these turns, the frequency response will be the same. In other words, the transfer function of a sampled system is periodic of period equal to the sampling frequency.

With real (as opposed to complex) signals, the transfer function is symmetric around half the sampling frequency: ![f = f_s / 2](//upload.wikimedia.org/math/7/9/6/796658a368059bafeb8ee3c50717e82b.png). So the transfer function of a sampled system is usually only considered between ![f = 0](//upload.wikimedia.org/math/9/0/3/9030c9fdd1390d3ed9f1a55b1611aa74.png) and ![f = f_s / 2](//upload.wikimedia.org/math/7/9/6/796658a368059bafeb8ee3c50717e82b.png).

# Appendices

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Fourier Transform

    ![F\(j\\omega\) = \\mathcal{F} \\left\\{f\(t\) \\right\\} = \\int_{-\\infty}^\\infty f\(t\) e^{-j\\omega t}dt](//upload.wikimedia.org/math/7/3/2/73212f721ae8a37e74d75c50a0349eda.png)

## Inverse Fourier Transform

    ![\\mathcal{F}^{-1}\\left\\{F\(j\\omega\) \\right\\}
        = f\(t\) 
        = \\frac{1}{2\\pi}\\int_{-\\infty}^\\infty F\(j\\omega\) e^{j\\omega t} d\\omega](//upload.wikimedia.org/math/a/1/a/a1a42d6483a0d6108ba73236a870038a.png)

## Table of Fourier Tranforms

This table contains some of the most commonly encountered Fourier transforms.

  Time Domain Frequency Domain

![x\(t\) = \\mathcal{F}^{-1}\\left\\{ X\(\\omega\) \\right\\}](//upload.wikimedia.org/math/8/6/3/863d9d4e736928e10d7ad65b7485d018.png) ![X\(\\omega\) = \\mathcal{F} \\left\\{ x\(t\) \\right\\}](//upload.wikimedia.org/math/1/9/a/19ac5b86c65955c254a2bab21f9d4fc2.png)

1
![ X\(j \\omega\)=\\int_{-\\infty}^\\infty x\(t\) e^{-j \\omega t}d t ](//upload.wikimedia.org/math/9/9/e/99e095cbd5d46519bbe946a96a968f4e.png)
![ x\(t\)=\\frac{1}{2 \\pi} \\int_{-\\infty}^{\\infty} X\(j \\omega\)e^{j \\omega t}d \\omega ](//upload.wikimedia.org/math/8/0/a/80a3a92bda3fffd3dc08a19fb1e790dd.png)

2
![ 1 \\,](//upload.wikimedia.org/math/d/0/6/d06c48671eacd7f1e2afde7289e483d5.png)
![ 2\\pi\\delta\(\\omega\) \\,](//upload.wikimedia.org/math/3/b/2/3b2c95111f6044909e22218f1654b8c8.png)

3
![ -0.5 + u\(t\) \\,](//upload.wikimedia.org/math/2/3/d/23dadbc4e1d17e834c8a06bd09afa351.png)
![ \\frac{1}{j \\omega} \\,](//upload.wikimedia.org/math/4/7/9/47941d5693cbbb44a8fc455ebee84a6f.png)

4
![ \\delta \(t\) \\,](//upload.wikimedia.org/math/7/8/3/783045e83c1e5537366bd7c85dd9af27.png)
![ 1 \\,](//upload.wikimedia.org/math/d/0/6/d06c48671eacd7f1e2afde7289e483d5.png)

5
![ \\delta \(t-c\) \\,](//upload.wikimedia.org/math/9/6/1/9612adfd67b92667001afb555e7f0941.png)
![ e^{-j \\omega c} \\,](//upload.wikimedia.org/math/0/9/1/0915a1195d628164f0ac562aa08a6f03.png)

6
![ u\(t\) \\,](//upload.wikimedia.org/math/f/e/e/fee9613c4c57044904af0c6e64555bd4.png)
![ \\pi \\delta\(\\omega\)+\\frac{1}{j \\omega} \\,](//upload.wikimedia.org/math/c/c/b/ccb0d388b4dc557348f84a5482f27298.png)

7
![ e^{-bt}u\(t\) \\, \(b > 0\) ](//upload.wikimedia.org/math/7/8/f/78f3662d1365d3192ae3b0da2f53cc70.png)
![ \\frac{1}{j \\omega+b} \\, ](//upload.wikimedia.org/math/0/a/7/0a77983531fec211037e295a8bdb9bf9.png)

8
![ \\cos \\omega_0 t \\,](//upload.wikimedia.org/math/d/2/c/d2c43097f89ee7c790d9f9510b7aab5a.png)
![ \\pi \\left\[ \\delta\(\\omega+\\omega_0\)+\\delta\(\\omega-\\omega_0\) \\right\] \\,](//upload.wikimedia.org/math/5/3/3/5335b55ebf83994da78821ab770278b3.png)

9
![ \\cos \(\\omega_0 t + \\theta\) \\,](//upload.wikimedia.org/math/9/8/6/9866cbac8e887ef674032f14abeffcbb.png)
![ \\pi \\left\[ e^{-j \\theta}\\delta\(\\omega+\\omega_0\)+e^{j \\theta}\\delta\(\\omega-\\omega_0\) \\right\] \\, ](//upload.wikimedia.org/math/6/e/3/6e32dd379a3a604a5220abaececaeed7.png)

10
![ \\sin \\omega_0 t \\,](//upload.wikimedia.org/math/b/c/9/bc9a442b422dc51562e01105e2555589.png)
![ j \\pi \\left\[ \\delta\(\\omega +\\omega_0\)-\\delta\(\\omega-\\omega_0\) \\right\] \\,](//upload.wikimedia.org/math/7/1/3/71354846c8c7115466143984c0e63a88.png)

11
![ \\sin \(\\omega_0 t + \\theta\) \\,](//upload.wikimedia.org/math/7/8/a/78a40053e5c02e3d3eb6f2aa41908d54.png)
![ j \\pi \\left\[ e^{-j \\theta}\\delta\(\\omega +\\omega_0\)-e^{j \\theta}\\delta\(\\omega-\\omega_0\) \\right\] \\,](//upload.wikimedia.org/math/7/2/5/725cafff5c36ddf0be2bb7ccecd6e0a1.png)

12
![ \\mbox{rect} \\left\( \\frac{t}{\\tau} \\right\) \\,](//upload.wikimedia.org/math/d/9/c/d9c5fca10a083e40e0aa2397b4ec1652.png)
![ \\tau \\mbox{sinc} \\left\( \\frac{\\tau \\omega}{2 \\pi} \\right\) \\,](//upload.wikimedia.org/math/2/0/5/205073624e0905d492082423b2816611.png)

13
![ \\tau \\mbox{sinc} \\left\( \\frac{\\tau t}{2 \\pi} \\right\) \\,](//upload.wikimedia.org/math/3/f/5/3f52e0c4dbefbec5daafbbf06dcd6a76.png)
![ 2 \\pi p_\\tau\(\\omega\)\\, ](//upload.wikimedia.org/math/f/c/5/fc5cd3dce67989b2aa8bad6567c977a1.png)

14
![ \\left\( 1-\\frac{2 |t|}{\\tau} \\right\) p_\\tau \(t\) \\,](//upload.wikimedia.org/math/8/8/9/889997f4e36de0a225a7c5fc12e29cb2.png)
![ \\frac{\\tau}{2} \\mbox{sinc}^2 \\left\( \\frac{\\tau \\omega}{4 \\pi} \\right\) \\,](//upload.wikimedia.org/math/1/a/8/1a8f16a499c8fd2ca613314e6bf88116.png)

15
![ \\frac{\\tau}{2} \\mbox{sinc}^2 \\left\( \\frac{\\tau t}{4 \\pi} \\right\) \\,](//upload.wikimedia.org/math/0/7/e/07ed35f1e673c7529ef2298a1a7969f4.png)
![ 2 \\pi \\left\( 1-\\frac{2|\\omega|}{\\tau} \\right\) p_\\tau \(\\omega\) \\,](//upload.wikimedia.org/math/5/a/d/5ad966ee51023d22c576714ea29161f8.png)

16
![ e^{-a|t|}, \\Re\\{a\\}>0 \\,](//upload.wikimedia.org/math/c/9/5/c95ed6585b2c4ba1653d9b280f390037.png)
![ \\frac{2a}{a^2 + \\omega^2} \\,](//upload.wikimedia.org/math/0/4/9/0490fedfc2a96b61b5d6476d4cfaea8b.png)

Notes:

  1. ![ \\mbox{sinc}\(x\)=\\sin\(x\)/x ](//upload.wikimedia.org/math/4/e/f/4ef893a5c2fcfc6a726873ecfd96eaf4.png)
  2. ![ p_\\tau \(t\) ](//upload.wikimedia.org/math/1/b/e/1be513b7d38d793f3078dd33b933c130.png) is the rectangular pulse function of width ![ \\tau ](//upload.wikimedia.org/math/8/1/a/81a69207104f00baaabd6f84cafd15a0.png)
  3. ![ u\(t\) ](//upload.wikimedia.org/math/a/0/d/a0d664fdd9965ace52f10dd8d03aea2d.png) is the Heavyside step function
  4. ![ \\delta \(t\) ](//upload.wikimedia.org/math/e/e/1/ee1e78bea7f1ee978c7bb1de848f9354.png) is the Dirac delta function

This box: [view](/wiki/Engineering_Tables/Fourier_Transform_Table) • [talk](/w/index.php?title=Talk:Engineering_Tables/Fourier_Transform_Table&action=edit&redlink=1) • [edit](//en.wikibooks.org/w/index.php?title=Engineering_Tables/Fourier_Transform_Table&action=edit)

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Laplace Transform

    ![F\(s\) 
  = \\mathcal{L} \\left\\{f\(t\)\\right\\}
  =\\int_{0^-}^\\infty e^{-st} f\(t\)\\,dt.](//upload.wikimedia.org/math/8/9/9/899a5d5fabb113be09e909385fa432b8.png)

## Inverse Laplace Transform

    ![ 
\\mathcal{L}^{-1} \\left\\{F\(s\)\\right\\}
  = {1 \\over {2\\pi i}}\\int_{c-i\\infty}^{c+i\\infty} e^{ft} F\(s\)\\,ds = f\(t\)](//upload.wikimedia.org/math/5/b/9/5b99bec12e12248a1f13328d70637701.png)

## Laplace Transform Properties

Property Definition

Linearity
![\\mathcal{L}\\left\\{a f\(t\) + b g\(t\) \\right\\}  = a F\(s\)  + b G\(s\) ](//upload.wikimedia.org/math/b/a/5/ba5734c6ec8403527041a87da32cfcc2.png)

Differentiation
![\\mathcal{L}\\{f'\\}  = s \\mathcal{L}\\{f\\} - f\(0^-\)](//upload.wikimedia.org/math/2/b/a/2bab5fb42e5b180c974c181af242047a.png)  


![\\mathcal{L}\\{f''\\}  = s^2 \\mathcal{L}\\{f\\} - s f\(0^-\) - f'\(0^-\)](//upload.wikimedia.org/math/0/0/2/002cf255758c5f8f4695077bfc1324e3.png)  
![\\mathcal{L}\\left\\{ f^{\(n\)} \\right\\}  = s^n \\mathcal{L}\\{f\\} - s^{n - 1} f\(0^-\) - \\cdots - f^{\(n - 1\)}\(0^-\)](//upload.wikimedia.org/math/5/5/2/552f59dcde0dd6999f21035d02f1ec79.png)

Frequency Division
![\\mathcal{L}\\{ t f\(t\)\\}  = -F'\(s\)](//upload.wikimedia.org/math/6/8/5/685124a191b3f32eb6c9143d90bdc081.png)  


![\\mathcal{L}\\{ t^{n} f\(t\)\\}  = \(-1\)^{n} F^{\(n\)}\(s\)](//upload.wikimedia.org/math/a/4/9/a49b9498f5fdd16e27fe2a7e33fc24ea.png)

Frequency Integration
![\\mathcal{L}\\left\\{ \\frac{f\(t\)}{t} \\right\\} = \\int_s^\\infty F\(\\sigma\)\\, d\\sigma](//upload.wikimedia.org/math/2/4/c/24c4ce8df84a3f60c25a9a121eb64273.png)

Time Integration
![\\mathcal{L}\\left\\{ \\int_0^t f\(\\tau\)\\, d\\tau \\right\\}  = \\mathcal{L}\\left\\{ u\(t\) * f\(t\)\\right\\} = {1 \\over s} F\(s\) ](//upload.wikimedia.org/math/b/f/7/bf74c78a07ce65f563ef7ef2fa61fa28.png)

Scaling
![ \\mathcal{L} \\left\\{ f\(at\) \\right\\} = {1 \\over a} F \\left \( {s \\over a} \\right \)](//upload.wikimedia.org/math/f/f/5/ff5fae499ac22bd31f62cdb12fb4a52e.png)

Initial value theorem
![f\(0^+\)=\\lim_{s\\to \\infty}{sF\(s\)}](//upload.wikimedia.org/math/6/d/f/6dfea25a80f0fce69ed569f804d36510.png)

Final value theorem
![f\(\\infty\)=\\lim_{s\\to 0}{sF\(s\)}](//upload.wikimedia.org/math/9/1/4/914166f18d1365289e125d6943058554.png)

Frequency Shifts
![\\mathcal{L}\\left\\{ e^{at} f\(t\) \\right\\}  = F\(s - a\)](//upload.wikimedia.org/math/2/7/7/277ba9926f989f9f548958fef428b5d5.png)  


![\\mathcal{L}^{-1} \\left\\{ F\(s - a\) \\right\\}  = e^{at} f\(t\)](//upload.wikimedia.org/math/f/3/2/f32d5eded3f085faf0877fe315d2756a.png)

Time Shifts
![\\mathcal{L}\\left\\{ f\(t - a\) u\(t - a\) \\right\\}  = e^{-as} F\(s\)](//upload.wikimedia.org/math/8/3/b/83bd66730dd2e3d0ae1c7687034195c2.png)  


![\\mathcal{L}^{-1} \\left\\{ e^{-as} F\(s\) \\right\\}  = f\(t - a\) u\(t - a\)](//upload.wikimedia.org/math/d/4/b/d4b962800623d110572aa5526f30edf3.png)

Convolution Theorem
![\\mathcal{L}\\{f\(t\) * g\(t\)\\}  = F\(s\) G\(s\)  ](//upload.wikimedia.org/math/d/6/1/d6108211f0b5804ee13954345656734a.png)

**Where:**

    ![ f\(t\) = \\mathcal{L}^{-1} \\{  F\(s\) \\} ](//upload.wikimedia.org/math/b/f/a/bfa48a9ec64283dadf4b96ec7a64efce.png)
    ![ g\(t\) = \\mathcal{L}^{-1} \\{  G\(s\) \\} ](//upload.wikimedia.org/math/e/4/9/e49b0518568d40dc72376680063808d2.png)
    ![s = \\sigma + j\\omega](//upload.wikimedia.org/math/7/a/d/7addd3c9d3736265ecd7dbea420b1190.png)

## Table of Laplace Transforms

  Time Domain Laplace Domain

![x\(t\) = \\mathcal{L}^{-1}\\left\\{ X\(s\) \\right\\}](//upload.wikimedia.org/math/9/7/7/97715cac48677db9513a824cc732e7e0.png) ![X\(s\) = \\mathcal{L} \\left\\{ x\(t\) \\right\\}](//upload.wikimedia.org/math/4/c/c/4cc48462bc9662d9edf093e2e4ce145d.png)

1
![ \\frac{1}{2\\pi j} \\int_{\\sigma-j\\infty}^{\\sigma+j\\infty} X\(s\)e^{st}ds ](//upload.wikimedia.org/math/f/f/7/ff715206fafc4e2556b31482da509c82.png)
![ \\int_{-\\infty}^\\infty x\(t\)e^{-st}dt ](//upload.wikimedia.org/math/1/1/1/111d6af8202ea0c70f485b04307d33e3.png)

2
![ \\delta \(t\) \\,](//upload.wikimedia.org/math/7/8/3/783045e83c1e5537366bd7c85dd9af27.png)
![ 1 \\,](//upload.wikimedia.org/math/d/0/6/d06c48671eacd7f1e2afde7289e483d5.png)

3
![ \\delta \(t-a\)\\, ](//upload.wikimedia.org/math/0/9/8/098c8275c33d49e28f5a3a5d6be3d3dd.png)
![ e^{-as}\\, ](//upload.wikimedia.org/math/1/0/6/106f4bad1ed1b345fdf766f7ef20b663.png)

4
![ u\(t\) \\,](//upload.wikimedia.org/math/f/e/e/fee9613c4c57044904af0c6e64555bd4.png)
![ \\frac{1}{s} ](//upload.wikimedia.org/math/5/a/d/5adcb727a6c3c48aa06153263b9b1c05.png)

5
![ u\(t-a\)\\, ](//upload.wikimedia.org/math/e/3/4/e341130fc421885dbef90f46c17d32c5.png)
![ \\frac{e^{-as}}{s} ](//upload.wikimedia.org/math/b/c/2/bc2e9d7fc1360d2feca996cc86a57d39.png)

6
![ t u\(t\) \\,](//upload.wikimedia.org/math/5/a/9/5a9a399691ffeaaa5ab397a3d9dc1e0e.png)
![ \\frac{1}{s^2} ](//upload.wikimedia.org/math/9/4/5/9457e81a7d049d27d6c143c62672694e.png)

7
![ t^nu\(t\) \\,](//upload.wikimedia.org/math/d/a/c/dac27cffbda56ab5484e41a0b50a0165.png)
![ \\frac{n!}{s^{n+1}} ](//upload.wikimedia.org/math/b/e/8/be87eaca633da5ef05214506abca024e.png)

8
![ \\frac{1}{\\sqrt{\\pi t}}u\(t\) ](//upload.wikimedia.org/math/3/5/0/350cb6d939ab8c9c27e3b4a71ca245b7.png)
![ \\frac{1}{\\sqrt{s}} ](//upload.wikimedia.org/math/2/8/e/28edaa5fc96024e0e5015d465178535c.png)

9
![ e^{at}u\(t\) \\,](//upload.wikimedia.org/math/0/e/9/0e95363b81bb11da9e84b0c86804d75d.png)
![ \\frac{1}{s-a} ](//upload.wikimedia.org/math/8/b/0/8b00853fc4c3b7d3910b5c8907335125.png)

10
![ t^n e^{at}u\(t\) \\,](//upload.wikimedia.org/math/2/1/3/213cee8cbaa0a1a9a046f2d7bb3c7cdf.png)
![ \\frac{n!}{\(s-a\)^{n+1}} ](//upload.wikimedia.org/math/6/8/5/685e7a6eb82221ef4f1e7de6a904f375.png)

11
![  \\cos \(\\omega t\) u\(t\) \\,](//upload.wikimedia.org/math/9/1/d/91dadfc0fe72221687a1bb91f0545a5b.png)
![ \\frac{s}{s^2+\\omega^2} ](//upload.wikimedia.org/math/f/a/3/fa3d0e339398c680f87c097bac9ada03.png)

12
![  \\sin \(\\omega t\) u\(t\) \\, ](//upload.wikimedia.org/math/3/7/3/373529d9d68438ffe5b049a8a50eb7a5.png)
![ \\frac{\\omega}{s^2+\\omega^2} ](//upload.wikimedia.org/math/c/b/c/cbc9ca6ebcbce4f35a22cd52f7e846bd.png)

13
![  \\cosh \(\\omega t\) u\(t\) \\,](//upload.wikimedia.org/math/3/6/0/360e77184f5b0907f2ce1a88571daac8.png)
![ \\frac{s}{s^2-\\omega^2} ](//upload.wikimedia.org/math/3/3/e/33e44cab094800c2667ae9ba812dc201.png)

14
![ \\sinh \(\\omega t\) u\(t\) \\,](//upload.wikimedia.org/math/f/9/5/f951b7e0c097b2caf9fdb695b91c9856.png)
![ \\frac{\\omega}{s^2-\\omega^2} ](//upload.wikimedia.org/math/6/4/3/6436b17da473681239ff310241771419.png)

15
![ e^{at}  \\cos \(\\omega t\) u\(t\) \\,](//upload.wikimedia.org/math/e/5/3/e53b846bd64a4a187201d1a9d4b9b9a0.png)
![ \\frac{s-a}{\(s-a\)^2+\\omega^2} ](//upload.wikimedia.org/math/8/9/9/8991c6bfb001dd0a5f6243c7c264c3dd.png)

16
![ e^{at} \\sin \(\\omega t\) u\(t\) \\,](//upload.wikimedia.org/math/3/2/e/32e96d1ab8d07d78d07d77332c53e415.png)
![ \\frac{\\omega}{\(s-a\)^2+\\omega^2} ](//upload.wikimedia.org/math/3/2/0/3207eae9307dc1f63db785e0bafd9f31.png)

17
![ \\frac{1}{2\\omega^3}\(\\sin \\omega t-\\omega t \\cos \\omega t\) ](//upload.wikimedia.org/math/f/3/3/f331bfd6a49d613e8abdb8ff5ddc8e5f.png)
![ \\frac{1}{\(s^2+\\omega^2\)^2} ](//upload.wikimedia.org/math/f/f/0/ff0af5120265d4aa876b615674fe6a24.png)

18
![ \\frac{t}{2\\omega} \\sin \\omega t ](//upload.wikimedia.org/math/c/2/a/c2aa086f5063a33d55245bfd800830e3.png)
![ \\frac{s}{\(s^2+\\omega^2\)^2} ](//upload.wikimedia.org/math/d/a/f/daf8f747db19bb10717c7c87b25c27f5.png)

19
![ \\frac{1}{2\\omega}\(\\sin \\omega t+\\omega t \\cos \\omega t\) ](//upload.wikimedia.org/math/c/f/1/cf128173ba50817195800594ebf9dfcc.png)
![ \\frac{s^2}{\(s^2+\\omega^2\)^2} ](//upload.wikimedia.org/math/8/6/1/861f57fef332552542612f38a1fb6475.png)

**[Signals and Systems](/wiki/Signals_and_Systems)**

## Useful Mathematical Identities

![ \\sin^2 \\theta + \\cos^2 \\theta = 1 ](//upload.wikimedia.org/math/0/0/0/00015b6ff16beaa60e2c82b7b890d91d.png)
![ 1+  \\tan^2 \\theta = \\sec^2 \\theta ](//upload.wikimedia.org/math/1/7/6/1762d84f2f493e208973748bd94b54e8.png)

![ \\sin \( \\frac{ \\pi}{2}- \\theta\)= \\cos \\theta ](//upload.wikimedia.org/math/8/d/f/8df322100063e2acc989d99d27e36765.png)
![ \\cos \( \\frac{ \\pi}{2}- \\theta\)= \\sin \\theta ](//upload.wikimedia.org/math/4/1/d/41d876ed33e35c59673de27b0e872310.png)

![ \\sec \( \\frac{ \\pi}{2}- \\theta\)= \\csc \\theta ](//upload.wikimedia.org/math/8/a/f/8af15d51f4ec78613bd012c5e940e48b.png)
![ \\csc \( \\frac{ \\pi}{2}- \\theta\)= \\sec \\theta ](//upload.wikimedia.org/math/8/7/1/87147c40fe8019339c5409482f0b3e09.png)

![ \\sin \(- \\theta\)=- \\sin \\theta ](//upload.wikimedia.org/math/5/1/5/5159a1ace7c5f3382627492f5f1d3f9e.png)
![ \\cos \(- \\theta\)= \\sin \\theta ](//upload.wikimedia.org/math/7/4/2/742141b9517b63f26f1da89a603a2c95.png)

![ \\sin 2 \\theta = 2 \\sin \\theta \\cos \\theta ](//upload.wikimedia.org/math/d/f/0/df033fe8135bcec2ce7117f6f2878d49.png)
![ \\cos 2 \\theta = \\cos^2- \\sin^2=2 \\cos^2 \\theta -1=1-2 \\sin^2 \\theta ](//upload.wikimedia.org/math/a/e/3/ae32c42584332f9f9a361c06bff0c510.png)

![ \\sin^2 \\theta= \\frac{1- \\cos 2 \\theta}{2} ](//upload.wikimedia.org/math/f/4/1/f414e6733b62a214262aafaac398cfb9.png)
![ \\cos^2 \\theta= \\frac{1+ \\cos 2 \\theta}{2} ](//upload.wikimedia.org/math/e/f/3/ef310c8009906b7b0a7a5c09cb795816.png)

![ \\sin \\alpha + \\sin \\beta = 2 \\sin \(\\frac{ \\alpha + \\beta}{2}\) \\cos \(\\frac{ \\alpha - \\beta}{2}\) ](//upload.wikimedia.org/math/f/c/e/fce58b20826bc9d1c14e7475c98ddf5f.png)
![ \\sin \\alpha - \\sin \\beta = 2 \\cos \(\\frac{ \\alpha + \\beta}{2}\) \\sin \(\\frac{ \\alpha - \\beta}{2}\) ](//upload.wikimedia.org/math/a/4/b/a4bbdfad233e4d6327f6a9d67da26e60.png)

![ \\cos \\alpha + \\cos \\beta = 2 \\cos \(\\frac{ \\alpha + \\beta}{2}\) \\cos \(\\frac{ \\alpha - \\beta}{2}\) ](//upload.wikimedia.org/math/f/6/0/f60a51ea036ec02d4e13148840b816e5.png)
![ \\cos \\alpha - \\cos \\beta = -2 \\sin \(\\frac{ \\alpha + \\beta}{2}\) \\sin \(\\frac{ \\alpha - \\beta}{2}\) ](//upload.wikimedia.org/math/6/0/9/60923fe64aa304c3c7f7ec029d04b0f9.png)

![ \\sin \\alpha \\sin \\beta = \\frac{1}{2}\[\\cos\( \\alpha - \\beta\) - \\cos\( \\alpha + \\beta\)\] ](//upload.wikimedia.org/math/3/6/3/363505684c5672bf60461420a6ef4825.png)
![ \\cos \\alpha \\cos \\beta = \\frac{1}{2}\[\\cos\( \\alpha - \\beta\) + \\cos\( \\alpha + \\beta\)\] ](//upload.wikimedia.org/math/f/c/2/fc2d1c6eb25b8f650098384b0e922987.png)

![ \\sin \\alpha \\cos \\beta = \\frac{1}{2}\[\\sin\( \\alpha + \\beta\) + \\sin\( \\alpha - \\beta\)\] ](//upload.wikimedia.org/math/6/f/b/6fbe88c2b838aa0bc3f1ab827e05a30d.png)
![ 1+ \\cot^2= \\csc^2 ](//upload.wikimedia.org/math/a/2/1/a217f8f5b4b81006a73bccf0bf8b023b.png)

![ e^{j \\theta}= \\cos \\theta + j \\sin \\theta ](//upload.wikimedia.org/math/4/7/a/47aba9d4ec49797dc60ae15b5e94e9a0.png)
![ \\cos \\theta = \\frac{e^{j \\theta} + e^{-j \\theta} } {2} ](//upload.wikimedia.org/math/0/2/5/02514b320a9932c5fae7da275b2f2ea1.png)

![  e^{-j \\theta} = \\cos \\theta - j\\sin \\theta ](//upload.wikimedia.org/math/d/5/8/d583379044ca9a0015180c9d72016e13.png)
![ \\sin \\theta = \\frac{e^{j \\theta} - e^{-j \\theta}} {2j} ](//upload.wikimedia.org/math/c/b/b/cbb3af89f10af06973bd4bb1a42e26a0.png)

![ \\tan \( \\frac{ \\pi}{2} - \\theta\)= \\cot \\theta ](//upload.wikimedia.org/math/f/2/8/f2889848f93371794969da6a96ab4d28.png)
![ \\cot \( \\frac{ \\pi}{2}- \\theta\)= \\tan \\theta ](//upload.wikimedia.org/math/0/6/d/06d98783f2011ee21447ece656b29a6a.png)

![ \\tan \(- \\theta\)= -\\tan \\theta ](//upload.wikimedia.org/math/8/8/b/88bb6ac40a9c280559e483bdea3fbd65.png)

![ \\tan^2 \\theta= \\frac{1- \\cos 2 \\theta}{1+ \\cos 2 \\theta} ](//upload.wikimedia.org/math/e/c/c/ecc6555cf90d8c9b16a77bb257e3dc6e.png)
![ \\tan 2 \\theta= \\frac{2 \\tan \\theta}{1-tan^2 \\theta} ](//upload.wikimedia.org/math/d/c/9/dc95f67f8f1443c6f6a14047291a6ef5.png)
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Signals_and_Systems/Print_version&oldid=1893950](http://en.wikibooks.org/w/index.php?title=Signals_and_Systems/Print_version&oldid=1893950)" 

[Category](/wiki/Special:Categories): 

  * [Signals and Systems](/wiki/Category:Signals_and_Systems)

Hidden category: 

  * [Requests for expansion](/wiki/Category:Requests_for_expansion)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Signals+and+Systems%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Signals+and+Systems%2FPrint+version)

### Namespaces

  * [Book](/wiki/Signals_and_Systems/Print_version)
  * [Discussion](/w/index.php?title=Talk:Signals_and_Systems/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Signals_and_Systems/Print_version)
  * [Edit](/w/index.php?title=Signals_and_Systems/Print_version&action=edit)
  * [View history](/w/index.php?title=Signals_and_Systems/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Signals_and_Systems/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Signals_and_Systems/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Signals_and_Systems/Print_version&oldid=1893950)
  * [Page information](/w/index.php?title=Signals_and_Systems/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Signals_and_Systems%2FPrint_version&id=1893950)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Signals+and+Systems%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Signals+and+Systems%2FPrint+version&oldid=1893950&writer=rl)
  * [Printable version](/w/index.php?title=Signals_and_Systems/Print_version&printable=yes)

  * This page was last modified on 19 July 2010, at 10:14.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Signals_and_Systems/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
