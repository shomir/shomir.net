# Engineering Analysis/Print version

From Wikibooks, open books for an open world

< [Engineering Analysis](/wiki/Engineering_Analysis)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Engineering Analysis](/wiki/Engineering_Analysis)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Engineering_Analysis/Print_version&action=purge&printable=yes) this page.

  


  


# Vector Spaces

**[Engineering Analysis](/wiki/Engineering_Analysis)**

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

Before reading this chapter, students should know the terms _vector_, _scalar_, and _matrix_. These terms are discussed in [Linear Algebra](/wiki/Linear_Algebra).

## Vectors and Scalars

A **scalar** is a single number value, such as 3, 5, or 10. A **vector** is an ordered set of scalars.

A vector is typically described as a matrix with a row or column size of 1. A vector with a column size of 1 is a **row vector**, and a vector with a row size of 1 is a **column vector**.

  


[Column Vector]

    ![\\begin{bmatrix}a \\\\ b\\\\ c\\\\ \\vdots\\end{bmatrix}](//upload.wikimedia.org/math/6/e/5/6e50232bb1eaa1b5dd99c9bb7fe94ca8.png)

  


[Row Vector]

    ![\\begin{bmatrix}a & b & c &\\cdots\\end{bmatrix}](//upload.wikimedia.org/math/d/5/d/d5d6e71d20d96ac560ce5cf91eeec3fa.png)

A "common vector" is another name for a column vector, and this book will simply use the word "vector" to refer to a common vector.

## Vector Spaces

A vector space is a set of vectors and two operations (addition and multiplication, typically) that follow a number of specific rules. We will typically denote vector spaces with a capital-italic letter: _V_, for instance. A space _V_ is a vector space if all the following requirements are met. We will be using x and y as being arbitrary vectors in _V_. We will also use c and d as arbitrary scalar values. There are 10 requirements in all:

Given: ![x, y \\in V](//upload.wikimedia.org/math/7/f/b/7fb76f92d83bbdc57cf799129161e977.png)

  1. There is an operation called "Addition" (signified with a "+" sign) between two vectors, x + y, such that if both the operands are in _V_, then the result is also in _V_.
  2. The addition operation is commutative for all elements in _V_.
  3. The addition operation is associative for all elements in _V_.
  4. There is a unique **neutral element**, φ, in _V_, such that x + φ = x. This is also called a **zero** element.
  5. For every x in _V_, then there is a negative element -x in _V_ such that -x + x = φ.
  6. ![cx \\in V](//upload.wikimedia.org/math/f/4/0/f401c4746e687b561e4ebebfa4c8ae92.png)
  7. ![c\(x + y\) = cx + cy](//upload.wikimedia.org/math/a/6/a/a6a53ac9640f58dd9dff5aff3b267702.png)
  8. ![\(c + d\)x = cx + dx](//upload.wikimedia.org/math/8/3/5/8359147ff31dd747320f81d4e4407243.png)
  9. ![c\(dx\) = cdx](//upload.wikimedia.org/math/b/4/4/b445db8014f8d40a6af08fdbdada9b6b.png)
  10. 1 × x = x

Some of these rules may seem obvious, but that's only because they have been generally accepted, and have been taught to people since they were children.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

## Scalar Product

A scalar product is a special type of operation that acts on two vectors, and returns a scalar result. Scalar products are denoted as an ordered pair between angle-brackets: <x,y>. A scalar product between vectors must satisfy the following four rules:

  1. ![\\langle x, x\\rangle \\ge 0, \\quad \\forall x \\in V](//upload.wikimedia.org/math/e/a/9/ea95b6e1fbfe317c18b02b8dfdfce5e5.png)
  2. ![\\langle x, x\\rangle = 0](//upload.wikimedia.org/math/d/a/6/da6541f64e1ff2cea3834153bc252a1b.png), only if x = 0
  3. ![\\langle x, y\\rangle = \\langle y, x\\rangle](//upload.wikimedia.org/math/1/b/0/1b02bd74dc3640b30879b887e20a6eee.png)
  4. ![\\langle x, cy_1 + dy_2\\rangle = c\\langle x, y_1\\rangle + d\\langle x, y_2\\rangle](//upload.wikimedia.org/math/c/6/c/c6c762d953a6ab3b806675cefeb3069a.png)

If an operation satisifes all these requirements, then it is a scalar product.

### Examples

One of the most common scalar products is the **dot product**, that is discussed commonly in [Linear Algebra](/wiki/Linear_Algebra)

## Norm

The **norm** is an important scalar quantity that indicates the magnitude of the vector. Norms of a vector are typically denoted as ![\\|x\\|](//upload.wikimedia.org/math/2/4/c/24c8538e32f233a9a540389ab367b02e.png). To be a norm, an operation must satisfy the following four conditions:

  1. ![\\|x\\| \\ge 0](//upload.wikimedia.org/math/9/6/a/96a5294c735a8a3f34a37863c12b6a45.png)
  2. ![\\|x\\| = 0](//upload.wikimedia.org/math/c/e/6/ce61a6f0bf156f8a40779f9dea9b9de8.png) only if x = 0.
  3. ![\\|cx\\| = |c|\\|x\\|](//upload.wikimedia.org/math/0/6/c/06c8b5e74d7f734ae741ce9fc62ed2b5.png)
  4. ![\\|x + y\\| \\le \\|x\\| + \\|y\\|](//upload.wikimedia.org/math/e/2/8/e2885a3bc7dadb2d2b73c2adeb840e63.png)

A vector is called **normal** if it's norm is 1. A normal vector is sometimes also referred to as a **unit vector**. Both notations will be used in this book. To make a vector normal, but keep it pointing in the same direction, we can divide the vector by its norm:

    ![\\bar{x} = \\frac{x}{\\|x\\|}](//upload.wikimedia.org/math/e/b/1/eb157d2dff21edd95267e136269af012.png)

### Examples

One of the most common norms is the **cartesian norm**, that is defined as the square-root of the sum of the squares:

    ![\\|x\\| = \\sqrt{x_1^2 + x_2^2 + \\cdots + x_n^2}](//upload.wikimedia.org/math/5/e/9/5e995ece57d5941ec6f138f904dfff46.png)

### Unit Vector

A vector is said to be a **unit vector** if the norm of that vector is 1.

## Orthogonality

Two vectors x and y are said to be **orthogonal** if the scalar product of the two is equal to zero:

    ![\\langle x,y\\rangle = 0](//upload.wikimedia.org/math/b/2/c/b2cd48e64eb035144854f45216592a19.png)

Two vectors are said to be **orthonormal** if their scalar product is zero, and both vectors are unit vectors.

## Cauchy-Schwartz Inequality

The cauchy-schwartz inequality is an important result, and relates the norm of a vector to the scalar product:

    ![|\\langle x,y\\rangle | \\leq \\|x\\|\\|y\\|](//upload.wikimedia.org/math/2/1/d/21d4c71f8a9313970c203046d30e47d5.png)

## Metric (Distance)

The distance between two vectors in the vector space _V_, called the **metric** of the two vectors, is denoted by d(x, y). A metric operation must satisfy the following four conditions:

  1. ![d\(x,y\) \\ge 0](//upload.wikimedia.org/math/b/6/d/b6dd3fa3ead499ef4a46ab944221cc98.png)
  2. ![d\(x,y\) = 0](//upload.wikimedia.org/math/a/f/5/af57aa245c85ecb6c92e3a9075946486.png) only if x = y
  3. ![d\(x,y\) = d\(y, x\)](//upload.wikimedia.org/math/f/2/c/f2c22a820b8b5b12bc093e1124767772.png)
  4. ![d\(x,y\) \\le d\(x,z\) + d\(z, y\)](//upload.wikimedia.org/math/f/0/3/f03319eeb2d72421c45856be709772d6.png)

### Examples

A common form of metric is the distance between points a and b in the cartesian plane:

    ![d\(a, b\)_{{cartesian}} = \\sqrt{\(x_a - x_b\)^2 + \(y_a - y_b\)^2}](//upload.wikimedia.org/math/b/5/8/b582c5dd8d48d93c33a17006c10d1d16.png)

**[Engineering Analysis](/wiki/Engineering_Analysis)**

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

Before reading this chapter, students should know how to take the _transpose_ of a matrix, and the _determinant_ of a matrix. Students should also know what the _inverse_ of a matrix is, and how to calculate it. These topics are covered in [Linear Algebra](/wiki/Linear_Algebra).

## Linear Independance

A set of vectors ![V = {v_1, v_2, \\cdots, v_n}](//upload.wikimedia.org/math/0/c/2/0c265a3448ce5bae83a281e84bad627c.png) are said to be linearly dependant on one another if any vector v from the set can be constructed from a linear combination of the other vectors in the set. Given the following linear equation:

    ![a_1v_1 + a_2v_2 + \\cdots + a_nv_n = 0](//upload.wikimedia.org/math/8/f/1/8f112cb55c48b427404531a58893ecf7.png)

The set of vectors V is linearly independent only if all the a coefficients are zero. If we combine the v vectors together into a single row vector:

    ![\\hat{V} = \[v_1 v_2 \\cdots v_n\]](//upload.wikimedia.org/math/4/7/e/47ef0b94838eaa5cfe026bf930bf92c7.png)

And we combine all the a coefficients into a single column vector:

    ![\\hat{a} = \[a_1 a_2 \\cdots a_n\]^T](//upload.wikimedia.org/math/9/b/7/9b7be9cc18dfc2d8beed7e7e18fa8416.png)

We have the following linear equation:

    ![\\hat{V}\\hat{a} = 0](//upload.wikimedia.org/math/b/6/8/b688512a0bd404bab23d3b1ee17f7a92.png)

We can show that this equation can only be satisifed for ![\\hat{a} = 0](//upload.wikimedia.org/math/1/1/4/114e26424016ea0d75cc6275dc4a8ba7.png), the matrix ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png) must be invertable:

    ![\\hat{V}^{-1}\\hat{V}\\hat{a} = \\hat{V}^{-1}0](//upload.wikimedia.org/math/c/3/3/c331eccd3097bad7952c512e210a5395.png)

    ![\\hat{a} = 0](//upload.wikimedia.org/math/1/1/4/114e26424016ea0d75cc6275dc4a8ba7.png)

Remember that for the matrix to be invertable, the determinate must be non-zero.

### Non-Square Matrix V

If the matrix ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png) is not square, then the determinate can not be taken, and therefore the matrix is not invertable. To solve this problem, we can premultiply by the transpose matrix:

    ![\\hat{V}^T\\hat{V}\\hat{a} = 0](//upload.wikimedia.org/math/a/6/1/a6148df910f8c5715242c895f4f5b6a3.png)

And then the square matrix ![\\hat{V}^T\\hat{V}](//upload.wikimedia.org/math/1/0/0/1009ec045f25a56ed017f7c9e84dfa57.png) must be invertable:

    ![\(\\hat{V}^T\\hat{V}\)^{-1}\\hat{V}^T\\hat{V}\\hat{a} = 0](//upload.wikimedia.org/math/5/e/8/5e8bcba8186557508edac87cc6f13ac3.png)

    ![\\hat{a} = 0](//upload.wikimedia.org/math/1/1/4/114e26424016ea0d75cc6275dc4a8ba7.png)

### Rank

The rank of a matrix is the largest number of linearly independent rows or columns in the matrix.

To determine the Rank, typically the matrix is reduced to row-echelon form. From the reduced form, the number of non-zero rows, or the number of non-zero columns (whichever is smaller) is the rank of the matrix.

If we multiply two matrices A and B, and the result is C:

    ![AB = C](//upload.wikimedia.org/math/0/9/2/092f8f64a9f22aecebf06f80be05df3b.png)

Then the rank of C is the minimum value between the ranks A and B:

    ![\\operatorname{Rank}\(C\) = \\operatorname{min}\[\\operatorname{Rank}\(A\), \\operatorname{Rank}\(B\)\]](//upload.wikimedia.org/math/7/5/9/7596f6a939cba16f5a52872894425fc0.png)

## Span

A **Span** of a set of vectors _V_ is the set of all vectors that can be created by a linear combination of the vectors.

## Basis

A **basis** is a set of linearly-independent vectors that span the entire vector space.

### Basis Expansion

If we have a vector ![y \\in V](//upload.wikimedia.org/math/0/a/6/0a6dd1ec55a668d7e84633f49faf281e.png), and _V_ has basis vectors ![{v_1 v_2 \\cdots v_n}](//upload.wikimedia.org/math/c/b/2/cb27e2b8f252c41f194bd9c481c0001e.png), by definition, we can write y in terms of a linear combination of the basis vectors:

    ![a_1v_1 + a_2v_2 + \\cdots + a_nv_n = y](//upload.wikimedia.org/math/c/7/1/c710bee3f45cf227958e72cdcebd4afe.png)

or

    ![\\hat{V}\\hat{a} = y](//upload.wikimedia.org/math/a/9/a/a9a865da314aab4b1c4f56afcaeaaf43.png)

If ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png) is invertable, the answer is apparent, but if ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png) is not invertable, then we can perform the following technique:

    ![\\hat{V}^T\\hat{V}\\hat{a} = \\hat{V}^Ty](//upload.wikimedia.org/math/c/a/5/ca5e2b3eff8a28236a49074a5b98c5a0.png)

    ![\\hat{a} = \(\\hat{V}^T\\hat{V}\)^{-1}\\hat{V}^Ty](//upload.wikimedia.org/math/4/5/b/45b05cb074f0d577cecf40eb8a19f193.png)

And we call the quantity ![\(\\hat{V}^T\\hat{V}\)^{-1}\\hat{V}^T](//upload.wikimedia.org/math/c/d/4/cd4b86519690608b7fd2f17b41733065.png) the **left-pseudoinverse** of ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png).

### Change of Basis

Frequently, it is useful to change the basis vectors to a different set of vectors that span the set, but have different properties. If we have a space _V_, with basis vectors ![\\hat{V}](//upload.wikimedia.org/math/5/d/5/5d5845368b04aac01b6156e6998d2967.png) and a vector in _V_ called x, we can use the new basis vectors ![\\hat{W}](//upload.wikimedia.org/math/a/2/b/a2b56d255a8325740256744209bad862.png) to represent x:

    ![x = \\sum_{i = 0}^na_iv_i = \\sum_{j = 1}^n b_jw_j](//upload.wikimedia.org/math/b/3/f/b3f85cef2af49478f23e14c40a2f1ba3.png)

or,

    ![x = \\hat{V}\\hat{a} = \\hat{W}\\hat{b}](//upload.wikimedia.org/math/3/6/f/36f872ceb8fb8215f70f42d4598bc5fa.png)

If V is invertable, then the solution to this problem is simple.

## Grahm-Schmidt Orthogonalization

If we have a set of basis vectors that are not orthogonal, we can use a process known as **orthogonalization** to produce a new set of basis vectors for the same space that are orthogonal:

    Given: ![\\hat{V} = {x_1 v_2 \\cdots v_n}](//upload.wikimedia.org/math/d/8/c/d8cec7af53ecd98a624a98fca865f48b.png)
    Find the new basis ![\\hat{W} = {w_1 w_2 \\cdots w_n}](//upload.wikimedia.org/math/f/1/2/f12d48b1b900c86290524a360dfa3b59.png)
    Such that ![\\langle w_i, w_j\\rangle = 0\\quad\\forall i, j](//upload.wikimedia.org/math/8/5/6/85689c31f986a68d875bae66d162ed2c.png)

We can define the vectors as follows:

  1. ![w_1 = v_1](//upload.wikimedia.org/math/a/4/c/a4cce6064a1aa55e12ff5ad988e9ace3.png)
  2. ![w_m = v_m - \\sum_{i = 1}^{m-1}\\frac{\\langle v_m, u_i\\rangle }{\\langle u_i, u_i\\rangle }u_i](//upload.wikimedia.org/math/a/8/5/a85e92d73fd65f8b5abc13310c0ec286.png)

Notice that the vectors produced by this technique are orthogonal to each other, but they are not necessarily orthonormal. To make the _w_ vectors orthonormal, you must divide each one by its norm:

    ![\\bar{w} = \\frac{w}{\\|w\\|}](//upload.wikimedia.org/math/7/4/1/741fb559dcdc9305afa7bf98655ed854.png)

## Reciprocal Basis

A Reciprocal basis is a special type of basis that is related to the original basis. The reciprocal basis ![\\hat{W}](//upload.wikimedia.org/math/a/2/b/a2b56d255a8325740256744209bad862.png) can be defined as:

    ![\\hat{W} = \[\\hat{V}^T\]^{-1}](//upload.wikimedia.org/math/c/5/e/c5e35fcf854f28d91e9c92e5b9aa8c68.png)

  


# Linear Transformations

**[Engineering Analysis](/wiki/Engineering_Analysis)**

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

Some sections in this chapter require that the student know how to take the _derivative_ of a function with respect to a particular variable. This is commonly known as _partial differentiation_, and is covered in [Calculus](/wiki/Calculus).

## Linear Transformations

A linear transformation is a matrix M that operates on a vector in space _V_, and results in a vector in a different space _W_. We can define a transformation as such:

    ![T:V\\to W](//upload.wikimedia.org/math/1/6/1/1613f48b6e25817f7df33fa935d2c918.png)

In the above equation, we say that _V_ is the **domain space** of the transformation, and _W_ is the **range space** of the transformation. Also, we can use a "function notation" for the transformation, and write it as:

    ![M\(x\) = Mx = y](//upload.wikimedia.org/math/8/0/1/80145aae05d51a211736af2ba283c814.png)

Where x is a vector in _V_, and y is a vector in _W_. To be a linear transformation, the principle of superposition must hold for the transformation:

    ![M\(av_1 + bv_2\) = aM\(v_1\) + bM\(v_2\)](//upload.wikimedia.org/math/3/0/7/307241502ca36086f5f6abe0c011ddda.png)

Where a and b are arbitrary scalars.

## Null Space

The Nullspace of an equation is the set of all vectors x for which the following relationship holds:

    ![Mx = 0](//upload.wikimedia.org/math/4/f/9/4f94b57c87436f0efd6f72ef75fa1b6a.png)

Where M is a linear transformation matrix. Depending on the size and rank of M, there may be zero or more vectors in the nullspace. Here are a few rules to remember:

  1. If the matrix M is invertable, then there is no nullspace.
  2. The number of vectors in the nullspace (N) is the difference between the rank(R) of the matrix and the number of columns(C) of the matrix:

    ![N = R - C](//upload.wikimedia.org/math/5/5/9/559f4dba3603d8d623d57a7ded469521.png)

If the matrix is in row-eschelon form, the number of vectors in the nullspace is given by the number of rows without a leading 1 on the diagonal. For every column where there is not a leading one on the diagonal, the nullspace vectors can be obtained by placing a negative one in the leading position for that column vector.

We denote the nullspace of a matrix A as:

    ![\\mathcal{N}\\{A\\}](//upload.wikimedia.org/math/f/4/7/f4761197acb55cd934bff4ba0c7ed6be.png)

## Linear Equations

If we have a set of linear equations in terms of variables x, scalar coefficients a, and a scalar result b, we can write the system in matrix notation as such:

    ![Ax = b](//upload.wikimedia.org/math/8/1/e/81e6d45a28385d9454465ee4551bd9c7.png)

Where x is a m × 1 vector, b is an n × 1 vector, and A is an n × m matrix. Therefore, this is a system of n equations with m unknown variables. There are 3 possibilities:

  1. If Rank(A) is not equal to Rank([A b]), there is no solution
  2. If Rank(A) = Rank([A b]) = n, there is exactly one solution
  3. If Rank(A) = Rank([A b]) < n, there are infinitely many solutions.

### Complete Solution

The complete solution of a linear equation is given by the sum of the **homogeneous solution**, and the **particular solution**. The homogeneous solution is the nullspace of the transformation, and the particular solution is the values for x that satisfy the equation:

    ![A\(x\) = b](//upload.wikimedia.org/math/4/b/2/4b220e14469bab5657dcaae125ca621c.png)
    ![A\(x_h + x_p\) = b](//upload.wikimedia.org/math/1/f/1/1f1a891156f6402aafe7f04a7adb3a50.png)

Where

    ![x_h](//upload.wikimedia.org/math/4/5/7/457c1b29401ad4001229e96de8c6fa37.png) is the homogeneous solution, and is the nullspace of A that satisfies the equation ![A\(x_h\) = 0](//upload.wikimedia.org/math/7/2/b/72bcf54ddca8ed6b3efbb303e7b22061.png)
    ![x_p](//upload.wikimedia.org/math/0/a/7/0a7e1bde4d211ea4031143461dd5bb03.png) is the particular solution that satisfies the equation ![A\(x_p\) = b](//upload.wikimedia.org/math/f/9/d/f9de408add2a5dd4e2d879ded2c73f6f.png)

### Minimum Norm Solution

If Rank(A) = Rank([A b]) < n, then there are infinitely many solutions to the linear equation. In this situation, the solution called the **minimum norm** solution must be found. This solution represents the "best" solution to the problem. To find the minimum norm solution, we must minimize the norm of x subject to the constraint of:

    ![Ax - b = 0](//upload.wikimedia.org/math/9/d/e/9defa1d3c0c4df450f123a84cd96ea10.png)

There are a number of methods to minimize a value according to a given constraint, and we will talk about them later.

## Least-Squares Curve Fit

If Rank(A) doesnt equal Rank([A b]), then the linear equation has no solution. However, we can find the solution which is the closest. This "best fit" solution is known as the Least-Squares curve fit.

We define an error quantity E, such that:

    ![E = Ax - b \\ne 0](//upload.wikimedia.org/math/4/a/5/4a590a4323d5e64b8da3aab3b54f527b.png)

Our job then is to find the minimum value for the norm of E:

    ![\\|E\\|^2 = \\|Ax - b\\|^2 = <Ax -b, Ax-b>](//upload.wikimedia.org/math/3/4/f/34f73b1f2278281080c9fb52c420d4e0.png)

We do this by differentiating with respect to x, and setting the result to zero:

    ![\\frac{\\partial \\|E\\|^2}{\\partial x} = 2A'\(Ax - b\) = 0](//upload.wikimedia.org/math/7/b/c/7bc6255f756a6248c55a2745316baaa2.png)

Solving, we get our result:

    ![x = \(A^TA\)^{-1}A^Tb](//upload.wikimedia.org/math/c/3/a/c3a37663be6d5ac6db3a413962255927.png)

  


# Minimization

**[Engineering Analysis](/wiki/Engineering_Analysis)**

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

Before reading this chapter, the student should know what _minimization_ is, and how to minimize a function. Students should also know _partial differentiation_, and how to solve systems of equations.

## Khun-Tucker Theorem

The Khun-Tucker Theorem is a method for minimizing a function f(x) under the constraint g(x). We can define the theorem as follows:

    ![L\(x\) = f\(x\) + \\langle \\Lambda, g\(x\)\\rangle](//upload.wikimedia.org/math/d/2/d/d2d5dc06f19ac148ce63aaa68028a03f.png)

Where Λ is the _lagrangian vector_, and < , > denotes the **scalar product** operation. We will discuss scalar products more later. If we differentiate this equation with respect to x first, and then with respect to Λ, we get the following two equations:

    ![\\frac{\\partial L\(x\)}{\\partial x} = x + A\\Lambda](//upload.wikimedia.org/math/a/8/4/a84413b3debf187665b5bd453cdbe34f.png)

    ![\\frac{\\partial L\(x\)}{\\partial \\Lambda} = Ax - b](//upload.wikimedia.org/math/1/2/0/1201131b520ef9288300d37bf5134b6f.png)

We have the final result:

    ![x = A^T\[AA^T\]^{-1}b](//upload.wikimedia.org/math/5/2/4/52408bcef2d3d88d71a76e11d4915a8d.png)

  


# Projections

**[Engineering Analysis](/wiki/Engineering_Analysis)**

## Projection

The projection of a vector ![v \\in V](//upload.wikimedia.org/math/f/5/9/f597bb2e018f9feb80df75d899613dbe.png) onto the vector space ![W \\in V](//upload.wikimedia.org/math/a/d/0/ad0be5457c6682a3efe5f8424346935f.png) is the minimum distance between v and the space _W_. In other words, we need to minimize the distance between vector v, and an arbitrary vector ![w \\in W](//upload.wikimedia.org/math/6/f/8/6f846d30c0fcf12b596c68eabf0716aa.png):

    ![\\|w - v\\|^2 = \\|\\hat{W}\\hat{a} - v\\|^2](//upload.wikimedia.org/math/8/a/e/8aeed05dd6e9acb7a032df3730a57843.png)

    ![\\frac{\\partial \\|\\hat{W} \\hat{a} - v\\|^2}{\\partial \\hat{a}} = \\frac{\\partial \\langle \\hat{W}\\hat{a} - v, \\hat{W}\\hat{a} - v\\rangle }{\\partial \\hat{a}} = 0](//upload.wikimedia.org/math/b/e/4/be46fa3555b94cd1b1c93df83d6207b8.png)

  


[Projection onto space W]

    ![\\hat{a} = \(\\hat{W}^T\\hat{W}\)^{-1}\\hat{W}^Tv](//upload.wikimedia.org/math/5/b/9/5b93f2ac13962109b728b5478e82cb4b.png)

For every vector ![v \\in V](//upload.wikimedia.org/math/f/5/9/f597bb2e018f9feb80df75d899613dbe.png) there exists a vector ![w \\in W](//upload.wikimedia.org/math/6/f/8/6f846d30c0fcf12b596c68eabf0716aa.png) called the projection of v onto W such that <v-w, p> = 0, where p is an arbitrary element of _W_.

### Orthogonal Complement

    ![w^\\perp = {x \\in V: \\langle x, y \\rangle = 0, \\forall y \\in W}](//upload.wikimedia.org/math/6/e/c/6ec3972aa55d9b1ed44502137f11fb12.png)

## Distance between v and W

The distance between ![v \\in V](//upload.wikimedia.org/math/f/5/9/f597bb2e018f9feb80df75d899613dbe.png) and the space _W_ is given as the minimum distance between v and an arbitrary ![w \\in W](//upload.wikimedia.org/math/6/f/8/6f846d30c0fcf12b596c68eabf0716aa.png):

    ![\\frac{\\partial d\(v, w\)}{\\partial \\hat{a}} = \\frac{\\partial\\|v - \\hat{W}\\hat{a}\\|}{\\partial \\hat{a}} = 0](//upload.wikimedia.org/math/7/2/a/72aaab9ad4c69cbae65d254ea3003f1c.png)

## Intersections

Given two vector spaces _V_ and _W_, what is the overlapping area between the two? We define an arbitrary vector z that is a component of both _V_, and _W_:

    ![z = \\hat{V} \\hat{a} = \\hat{W} \\hat{b}](//upload.wikimedia.org/math/4/9/e/49e6ff25360019060c5d1df139aa650d.png)

    ![\\hat{V} \\hat{a} - \\hat{W} \\hat{b} = 0](//upload.wikimedia.org/math/4/9/4/4948b3d84d0b3782c3ccedd40480d8af.png)

    ![\\begin{bmatrix}\\hat{a} \\\\ \\hat{b}\\end{bmatrix}= \\mathcal{N}\(\[\\hat{v} - \\hat{W}\]\)](//upload.wikimedia.org/math/3/8/7/3871fbf7a299e566804ab8f7a6b8af66.png)

Where N is the nullspace.

  


# Linear Spaces

{{:Engineeing Analysis/Linear Spaces}

  


# Matrices

**[Engineering Analysis](/wiki/Engineering_Analysis)**

## Norms

### Induced Norms

### n-Norm

### Frobenius Norm

### Spectral Norm

## Derivatives

Consider the following set of linear equations:

    ![a = bx_1 + cx_2](//upload.wikimedia.org/math/5/e/9/5e94e0bd714af049d7244504f106bcfc.png)
    ![d = ex_1 + fx_2](//upload.wikimedia.org/math/8/8/f/88f16b17c1c53f84b9cf9268ff066f99.png)

We can define the matrix A to represent the coefficients, the vector B as the results, and the vector x as the variables:

    ![A = \\begin{bmatrix}b &  c \\\\ e & f\\end{bmatrix}](//upload.wikimedia.org/math/a/4/a/a4a27bfb244e6ebb0d711b7e9e7c6ec5.png)
    ![B = \\begin{bmatrix}a \\\\ d\\end{bmatrix}](//upload.wikimedia.org/math/3/e/d/3edce1143a623004e7a342e409bf7afa.png)
    ![x = \\begin{bmatrix}x_1 \\\\ x_2\\end{bmatrix}](//upload.wikimedia.org/math/e/9/c/e9c3146da0f1bc29636da9ba00838127.png)

And rewriting the equation in terms of the matrices, we get:

    ![B = Ax](//upload.wikimedia.org/math/c/a/2/ca25466893d2f13e4d9fb85ace5f8ded.png)

Now, let's say we want the derivative of this equation with respect to the vector x:

    ![\\frac{d}{dx}B = \\frac{d}{dx}Ax](//upload.wikimedia.org/math/e/7/5/e75ab8a3e9ab18fbf9f8a296a9950263.png)

We know that the first term is constant, so the derivative of the left-hand side of the equation is zero. Analyzing the right side shows us:

## Pseudo-Inverses

There are special matrices known as **pseudo-inverses**, that satisfies some of the properties of an inverse, but not others. To recap, If we have two square matrices A and B, that are both n × n, then if the following equation is true, we say that A is the inverse of B, and B is the inverse of A:

    ![AB = BA = I](//upload.wikimedia.org/math/b/0/5/b0599feb0f6c9dc90bafbf8b55af7de3.png)

### Right Pseudo-Inverse

Consider the following matrix:

    ![R = A^T\[AA^T\]^{-1}](//upload.wikimedia.org/math/e/c/e/ecea6e29317a847bbdd69279c926c2fc.png)

We call this matrix R the **right pseudo-inverse** of A, because:

    ![AR = I](//upload.wikimedia.org/math/0/7/2/07280da5397203ca42cbd0d14bda7fe0.png)

but

    ![RA \\ne I](//upload.wikimedia.org/math/a/e/0/ae00abe72444c2fe08ab0c9021b08447.png)

We will denote the right pseudo-inverse of A as ![A^\\dagger](//upload.wikimedia.org/math/2/c/9/2c9f3e92d48086c6b9c241db2ebe9736.png)

### Left Pseudo-Inverse

Consider the following matrix:

    ![L = \[A^TA\]^{-1}A^T](//upload.wikimedia.org/math/b/f/0/bf0ed7205f5918fff0e0e318f2c8db8f.png)

We call L the **left pseudo-inverse** of A because

    ![LA = I](//upload.wikimedia.org/math/1/a/d/1ad1f0866263dac06481e3ee0ae359c4.png)

but

    ![AL \\ne I](//upload.wikimedia.org/math/1/4/2/142525d3f9841af8524c88e9ed1cb1af.png)

We will denote the left pseudo-inverse of A as ![A^\\ddagger](//upload.wikimedia.org/math/9/3/4/93447684053d72de4b98faf949c9b868.png)

**[Engineering Analysis](/wiki/Engineering_Analysis)**

Matrices that follow certain predefined formats are useful in a number of computations. We will discuss some of the common matrix formats here. Later chapters will show how these formats are used in calculations and analysis.

## Diagonal Matrix

A diagonal matrix is a matrix such that:

    ![a_{ij} = 0, i \\ne j](//upload.wikimedia.org/math/4/9/5/495ab83cc92e5c3c40e129ad4129378b.png)

In otherwords, all the elements off the main diagonal are zero, and the diagonal elements may be (but don't need to be) non-zero.

## Companion Form Matrix

If we have the following characteristic polynomial for a matrix:

    ![|A - \\lambda I| = \\lambda^n + a_{n-1}\\lambda^{n-1} + \\cdots + a_1\\lambda^1 + a_0](//upload.wikimedia.org/math/5/4/6/54637ea7f9fbbf122a422c147df0da17.png)

We can create a **companion form** matrix in one of two ways:

    ![\\begin{bmatrix} 0 & 0 & 0 & \\cdots & 0 & -a_0 \\\\
                       1 & 0 & 0 & \\cdots & 0 & -a_1 \\\\
                       0 & 1 & 0 & \\cdots & 0 & -a_2 \\\\
                       0 & 0 & 1 & \\cdots & 0 & -a_3 \\\\
                       \\vdots & \\vdots & \\vdots &\\ddots & \\vdots & \\vdots \\\\
                       0 & 0 & 0 & \\cdots & 1 & -a_{n-1} 
       \\end{bmatrix}](//upload.wikimedia.org/math/9/7/d/97d332ba2e41fa06538326169d01eeda.png)

Or, we can also write it as:

    ![\\begin{bmatrix} -a_{n-1} & -a_{n-2} & -a_{n-3} & \\cdots & a_1 & a_0 \\\\
                       0 & 0 & 0 & \\cdots & 0 & 0 \\\\
                       1 & 0 & 0 & \\cdots & 0 & 0 \\\\
                       0 & 1 & 0 & \\cdots & 0 & 0 \\\\
                       0 & 0 & 1 & \\cdots & 0 & 0 \\\\
                       \\vdots & \\vdots & \\vdots &\\ddots & \\vdots & \\vdots \\\\
                       0 & 0 & 0 & \\cdots & 1 & 0 
       \\end{bmatrix}](//upload.wikimedia.org/math/1/c/a/1cad91fe68e25b94a822f2b19be64d92.png)

## Jordan Canonical Form

To discuss the Jordan canonical form, we first need to introduce the idea of the **Jordan Block**:

### Jordan Blocks

A jordan block is a square matrix such that all the diagonal elements are equal, and all the super-diagonal elements (the elements directly above the diagonal elements) are all 1. To illustrate this, here is an example of an n-dimensional jordan block:

    ![\\begin{bmatrix} a & 1 & 0 & \\cdots & 0 \\\\
                       0 & a & 1 & \\cdots & 0 \\\\
                       0 & 0 & a & \\cdots & 0 \\\\
                       \\vdots & \\vdots & \\vdots &\\ddots & \\vdots \\\\
                       0 & 0 & a & \\cdots & 1 \\\\
                       0 & 0 & 0 & \\cdots & a 
       \\end{bmatrix}](//upload.wikimedia.org/math/c/2/0/c205480bf18f486350a85bc175e67fc9.png)

### Canonical Form

A square matrix is in **Jordan Canonical form**, if it is a diagonal matrix, or if it has one of the following two block-diagonal forms:

    ![\\begin{bmatrix}D & 0 & \\cdots & 0 \\\\
                      0 & J_1 & \\cdots & 0 \\\\
                      \\vdots & \\vdots &\\ddots & \\vdots \\\\
                      0 & 0 & \\cdots & J_n
       \\end{bmatrix}](//upload.wikimedia.org/math/1/9/4/1940a663d9019943dc913c134ab1703c.png)

Or:

    ![\\begin{bmatrix}J_1 & 0 & \\cdots & 0 \\\\
                      0 & J_2 & \\cdots & 0 \\\\
                      \\vdots & \\vdots &\\ddots & \\vdots \\\\
                      0 & 0 & \\cdots & J_n
       \\end{bmatrix}](//upload.wikimedia.org/math/8/4/2/84215a0df74a22bdf57d5fe920bc2501.png)

The where the D element is a diagonal block matrix, and the J blocks are in Jordan block form.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

If we have an n × 1 vector x, and an n × n symmetric matrix M, we can write:

    ![x^TMx = a](//upload.wikimedia.org/math/a/5/7/a57617bf95281d1a5dab5e4b5d55e762.png)

Where a is a scalar value. Equations of this form are called **quadratic forms**.

## Matrix Definiteness

Based on the quadratic forms of a matrix, we can create a certain number of categories for special types of matrices:

  1. if ![x^TMx > 0](//upload.wikimedia.org/math/2/1/d/21d08a96dfe552341dc461756dd5a8e9.png) for all x, then the matrix is **positive definite**.
  2. if ![x^TMx \\ge 0](//upload.wikimedia.org/math/5/a/8/5a8a5c6c2c6539613a318003194e9d3b.png) for all x, then the matrix is **positive semi-definite**.
  3. if ![x^TMx < 0](//upload.wikimedia.org/math/5/a/b/5ab25496972e7cdb58605dd8dde088f0.png) for all x, then the matrix is **negative definite**.
  4. if ![x^TMx \\le 0](//upload.wikimedia.org/math/3/8/1/38156b1a31b53766b14051c71cf964b8.png) for all x, then the matrix is **negative semi-definite**.

These classifications are used commonly in control engineering.

  


# Eigenvalues and Eigenvectors

**[Engineering Analysis](/wiki/Engineering_Analysis)**

## The Eigen Problem

This page is going to talk about the concept of **Eigenvectors** and **Eigenvalues**, which are important tools in linear algebra, and which play an important role in State-Space control systems. The "Eigen Problem" stated simply, is that given a square matrix A which is n × n, there exists a set of n scalar values λ and n corresponding non-trivial vectors v such that:

    ![Av = \\lambda v](//upload.wikimedia.org/math/d/a/3/da3ae989b4475b7e0343aad33cc51d8d.png)

We call λ the **eigenvalues** of A, and we call **v** the corresponding **eigenvectors** of A. We can rearrange this equation as:

    ![\(A - \\lambda I\)v = 0](//upload.wikimedia.org/math/c/2/9/c299e55bca1749bc57b442af0172ba04.png)

For this equation to be satisfied so that v is non-trivial, the matrix (A - λI) must be singular. That is:

    ![|A - \\lambda I| = 0](//upload.wikimedia.org/math/e/9/0/e90ee34c6e59f033a1b4a6e76502df1b.png)

## Characteristic Equation

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Characteristic polynomial**_](//en.wikipedia.org/wiki/Characteristic_polynomial)

The characteristic equation of a square matrix A is given by:

  


[Characteristic Equation]

    ![|A - \\lambda I| = 0](//upload.wikimedia.org/math/e/9/0/e90ee34c6e59f033a1b4a6e76502df1b.png)

Where I is the identity matrix, and λ is the set of **eigenvalues** of matrix A. From this equation we can solve for the eigenvalues of A, and then using the equations discussed above, we can calculate the corresponding eigenvectors.

In general, we can expand the characteristic equation as:

  


[Characteristic Polynomial]

    ![|A - \\lambda I| = \(-1\)^n\(\\lambda^n + c_{n-1}\\lambda^{n-1} + \\cdots + c_1\\lambda^1 + c_0\)](//upload.wikimedia.org/math/6/4/4/644e6a414e6c3a20da43a017ee1ac2ee.png)

This equation satisfies the following properties:

  1. ![|A| = \(-1\)^n c_0](//upload.wikimedia.org/math/c/7/b/c7bb64643aec6bdf5f6ba5a54e3e5636.png)
  2. A is nonsingular if c0 is non-zero.

### Example: 2 × 2 Matrix

Let's say that X is a square matrix of order 2, as such:

    ![X = \\begin{bmatrix}a & b \\\\c & d\\end{bmatrix}](//upload.wikimedia.org/math/4/9/e/49e5203f6bbcb184d8bca29664f63d36.png)

Then we can use this value in our characteristic equation:

    ![\\begin{vmatrix}a - \\lambda & b \\\\ c & d- \\lambda\\end{vmatrix} = 0](//upload.wikimedia.org/math/7/a/a/7aa61955e9f82789c8d60caebf7c48c5.png)

    ![\(a - \\lambda\)\(d - \\lambda\) - \(b\)\(c\) = 0](//upload.wikimedia.org/math/9/a/2/9a29d7232ad3e2b5e13859a13d18ce13.png)

The roots to the above equation (the values for λ that satisfies the equality) are the eigenvalues of X.

## Eigenvalues

The solutions, λ, of the characteristic equation for matrix X are known as the **eigenvalues** of the matrix X.

Eigenvalues satisfy the following properties:

  1. If λ is an eigenvalue of A, λn is an eigenvalue of An.
  2. If λ is a complex eigenvalue of A, then λ* (the complex conjugate) is also an eigenvalue of A.
  3. If any of the eigenvalues of A are zero, then A is singular. If A is non-singular, all the eigenvalues of A are nonzero.

## Eigenvectors

The characteristic equation can be rewritten as such:

    ![Xv = \\lambda v](//upload.wikimedia.org/math/8/5/b/85be9f4e81fa2378f6fa88110a0acb84.png)

Where X is the matrix under consideration, and λ are the eigenvalues for matrix X. For every unique eigenvalue, there is a solution vector v to the above equation, known as an **eigenvector**. The above equation can also be rewritten as:

    ![|X - \\lambda I|v = 0](//upload.wikimedia.org/math/d/3/c/d3c3de8dea0274ade24107717c0785af.png)

Where the resulting values of v for each eigenvalue λ is an eigenvector of X. There is a unique eigenvector for each unique eigenvalue of X. From this equation, we can see that the eigenvectors of A form the nullspace:

    ![v = \\mathcal{N}\\{A - \\lambda I\\}](//upload.wikimedia.org/math/7/5/e/75ebc64994bbedf1c0e8e8139cf671ef.png)

And therefore, we can find the eigenvectors through row-reduction of that matrix.

Eigenvectors satisfy the following properties:

  1. If v is a complex eigenvector of A, then v* (the complex conjugate) is also an eigenvector of A.
  2. Distinct eigenvectors of A are linearly independent.
  3. If A is n × n, and if there are n distinct eigenvectors, then the eigenvectors of A form a complete basis set for ![\\mathcal{R}^n](//upload.wikimedia.org/math/3/3/f/33f601d6597191d124a14c5b45e977ab.png)

## Generalized Eigenvectors

Let's say that matrix **A** has the following characteristic polynomial:

    ![\(A - \\lambda I\) = \(-1\)^n\(\\lambda - \\lambda_1\)^{d_1}\(\\lambda - \\lambda_2\)^{d_2} \\cdots \(\\lambda - \\lambda_s\)^{d_s}](//upload.wikimedia.org/math/c/b/8/cb8f3e97211bea6d2fe1708d18549664.png)

Where d1, d2, ... , ds are known as the **algebraic multiplicity** of the eigenvalue λi. Also note that d1 \+ d2 \+ ... + ds = n, and s < n. In other words, the eigenvalues of A are repeated. Therefore, this matrix doesnt have n distinct eigenvectors. However, we can create vectors known as **generalized eigenvectors** to make up the missing eigenvectors by satisfying the following equations:

    ![\(A-\\lambda I\)^k v_k = 0](//upload.wikimedia.org/math/7/a/b/7ab7879b0a7d6817881c4255484faeae.png)
    ![\(A-\\lambda I\)^{k-1} v_k = 0](//upload.wikimedia.org/math/2/3/5/2353fa4c3a53aeeccecfe0d5df3b9576.png)

## Right and Left Eigenvectors

The equation for determining eigenvectors is:

    ![\(A - \\lambda I\) v = 0](//upload.wikimedia.org/math/c/2/9/c299e55bca1749bc57b442af0172ba04.png)

And because the eigenvector _v_ is on the right, these are more appropriately called "right eigenvectors". However, if we rewrite the equation as follows:

    ![u\(A - \\lambda I\) = 0](//upload.wikimedia.org/math/a/2/d/a2d6415ee34fb0beec05145a7884ea5f.png)

The vectors _u_ are called the "left eigenvectors" of matrix A.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

## Similarity

Matrices _A_ and _B_ are said to be similar to one another if there exists an invertable matrix _T_ such that:

    ![T^{-1}AT = B](//upload.wikimedia.org/math/5/1/e/51eb262289379b79f3e83611ad67a945.png)

If there exists such a matrix _T_, the matrices are similar. Similar matrices have the same eigenvalues. If _A_ has eigenvectors _v1_, _v2_ ..., then _B_ has eigenvectors _u_ given by:

    ![u_i = Tv_i](//upload.wikimedia.org/math/c/3/b/c3b4ca4e3f0ac113e033045845dae5ba.png)

## Matrix Diagonalization

Some matricies are similar to diagonal matrices using a **transition matrix**, _T_. We will say that matrix _A_ is diagonalizable if the following equation can be satisfied:

    ![T^{-1}AT = D](//upload.wikimedia.org/math/6/9/4/69468265e50074f11afaffb484245046.png)

Where _D_ is a diagonal matrix. An _n × n_ square matrix is diagonalizable if and only if it has _n_ linearly independent eigenvectors.

## Transition Matrix

If an _n × n_ square matrix has _n_ distinct eigenvalues λ, and therefore _n_ distinct eigenvectors _v_, we can create a transition matrix _T_ as:

    ![T = \[v_1 v_2 ... v_n\]](//upload.wikimedia.org/math/1/d/c/1dc65be842059939a1b8ef827977c628.png)

And transforming matrix X gives us:

    ![T^{-1}AT = \\begin{bmatrix}\\lambda_1 & 0 & \\cdots & 0 \\\\
                                 0 & \\lambda_2 & \\cdots & 0 \\\\
                                 \\vdots & \\vdots & \\ddots & \\vdots \\\\
                                 0 & 0 & \\cdots & \\lambda_n\\end{bmatrix}](//upload.wikimedia.org/math/7/3/5/735f3916cf09e92a2dff809f159dbd73.png)

Therefore, if the matrix has _n_ distinct eigenvalues, the matrix is diagonalizable, and the diagonal entries of the diagonal matrix are the corresponding eigenvalues of the matrix.

## Complex Eigenvalues

Consider the situation where a matrix _A_ has 1 or more complex conjugate eigenvalue pairs. The eigenvectors of _A_ will also be complex. The resulting diagonal matrix _D_ will have the complex eigenvalues as the diagonal entries. In engineering situations, it is often not a good idea to deal with complex matrices, so other matrix transformations can be used to create matrices that are "nearly diagonal".

## Generalized Eigenvectors

If the matrix _A_ does not have a complete set of eigenvectors, that is, that they have _d_ eigenvectors and _n - d_ generalized eigenvectors, then the matrix _A_ is not diagonalizable. However, the next best thing is acheived, and matrix _A_ can be transformed into a Jordan Cannonical Matrix. Each set of generalized eigenvectors that are formed from a single eigenvector basis will create a jordan block. All the distinct eigenvectors that do not spawn any generalized eigenvectors will form a diagonal block in the Jordan matrix.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

If λ_i_ are the _n_ distinct eigenvalues of matrix _A_, and _vi_ are the corresponding n distinct eigenvectors, and if _wi_ are the _n_ distinct left-eigenvectors, then the matrix _A_ can be represented as a sum:

    ![A = \\sum_{i = 1}^n \\lambda_i v_i w_i^T](//upload.wikimedia.org/math/2/e/d/2ed8daa1d82869866c031f6ab65f215e.png)

this is known as the **spectral decomposition** of _A_.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

Consider a scenario where the matrix representation of a system A differs from the actual implementation of the system by a factor of ΔA. In other words, our system uses the matrix:

    ![A + \\Delta A](//upload.wikimedia.org/math/0/f/8/0f88d3dc27b2d958621e4fe58c4ed595.png)

From the study of [Control Systems](/wiki/Control_Systems), we know that the values of the eigenvectors can affect the stability of the system. For that reason, we would like to know how a small error in A will affect the eigenvalues.

First off, we assume that ΔA is a _small_ shift. The definition of "small" in this sense is arbitrary, and will remained open. Keep in mind that the techniques discussed here are more accurate the smaller ΔA is.

If ΔA is the error in the matrix A, then Δλ is the error in the eigenvalues and Δv is the error in the eigenvectors. The characteristic equation becomes:

    ![\(A + \\Delta A\)\(v + \\Delta v\) = \(\\lambda + \\Delta \\lambda\)\(v + \\Delta v\)](//upload.wikimedia.org/math/4/3/9/439dfa5f363fc0f5ab5348c4fd696b3e.png)

We have an equation now with two unknowns: Δλ and Δv. In other words, we don't know how a small change in A will affect the eigenvalues and eigenvectors. If we multiply out both sides, we get:

    ![Av + \\Delta A v + A \\Delta v + O\(\\Delta^2\) = \\lambda v + \\Delta \\lambda v + v \\Delta \\lambda + O\(\\Delta^2\)](//upload.wikimedia.org/math/c/4/2/c42ed944f5977003716c7d00450e4752.png)

This situation seems hopeless, until we multiply both sides by the corresponding left-eigenvector w from the left:

    ![w^TAv + w^T\\Delta A v + w^Tv \\Delta A = w^T\\lambda v + w^T\\Delta \\lambda v + w^T v \\Delta \\lambda + O\(\\Delta^2\)](//upload.wikimedia.org/math/0/1/4/0142dc3e036b92a2c1e0297681c79894.png)

Terms where two Δs (which are known to be small, by definition) are multiplied together, we can say are negligible, and ignore them. Also, we know from our right-eigenvalue equation that:

    ![w^TA = \\lambda w^T](//upload.wikimedia.org/math/f/e/6/fe69d7378aa4968c36a4d1d7c4753414.png)

Another fact is that the right-eigenvectors and left eigenvectors are orthogonal to each other, so the following result holds:

    ![w^T v = 0](//upload.wikimedia.org/math/b/3/9/b39b0ab503cb1924fe1ff977636f16bd.png)

Substituting these results, where necessary, into our long equation above, we get the following simplification:

    ![w^T \\Delta A v =  \\Delta \\lambda w^T\\Delta v](//upload.wikimedia.org/math/1/2/7/127327ef4d7384491baec1b0ef11c9fd.png)

And solving for the change in the eigenvalue gives us:

    ![\\Delta \\lambda = \\frac{w^T \\Delta A v}{w^T \\Delta v}](//upload.wikimedia.org/math/f/b/7/fb77c05c36516386f3946cb81bb044f3.png)

This approximate result is only good for small values of ΔA, and the result is less precise as the error increases.

  


# Functions of Matrices

**[Engineering Analysis](/wiki/Engineering_Analysis)**

If we have functions, and we use a matrix as the input to those functions, the output values are not always intuitive. For instance, if we have a function _f(x)_, and as the input argument we use matrix _A_, the output matrix is not necessarily the function _f_ applied to the individual elements of _A_.

## Diagonal Matrix

In the special case of diagonal matrices, the result of _f(A)_ is the function applied to each element of the diagonal matrix:

    ![A = \\begin{bmatrix} 
             a_{11} & 0 & \\cdots & 0 \\\\
             0 & a_{22} & \\cdots & 0 \\\\
             \\vdots & \\vdots & \\ddots & \\vdots \\\\
             0 & 0 & \\cdots & a_{nn}
           \\end{bmatrix}](//upload.wikimedia.org/math/a/7/9/a7976d43da1d0797de971fb45cc71eae.png)

Then the function _f(A)_ is given by:

    ![f\(A\) = \\begin{bmatrix} 
             f\(a_{11}\) & 0 & \\cdots & 0 \\\\
             0 & f\(a_{22}\) & \\cdots & 0 \\\\
             \\vdots & \\vdots & \\ddots & \\vdots \\\\
             0 & 0 & \\cdots & f\(a_{nn}\)
           \\end{bmatrix}](//upload.wikimedia.org/math/b/4/f/b4fba45c1447ec3cacd72ed9da398bc2.png)

## Jordan Cannonical Form

Matrices in Jordan Canonical form also have an easy way to compute the functions of the matrix. However, this method is not nearly as easy as the diagonal matrices described above.

If we have a matrix in Jordan Block form, _A_, the function _f(A)_ is given by:

    ![f\(A\) = \\begin{bmatrix} 
             \\frac{f\(a\)}{0!} & \\frac{f'\(a\)}{1!} & \\cdots & \\frac{f^{\(r-1\)}\(a\)}{\(r-1\)!} \\\\
             0 &  \\frac{f\(a\)}{0!} & \\cdots &  \\frac{f^\(r-2\)\(a\)}{\(r-2\)!} \\\\
             \\vdots & \\vdots & \\ddots & \\vdots \\\\
             0 & 0 & \\cdots &  \\frac{f\(a\)}{0!}
           \\end{bmatrix}](//upload.wikimedia.org/math/8/6/d/86dbcb76a44cc3c30a63a976bcc0fb0e.png)

The matrix indices have been removed, because in Jordan block form, all the diagonal elements must be equal.

If the matrix is in Jordan Block form, the value of the function is given as the function applied to the individual diagonal blocks.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

If the characteristic equation of matrix _A_ is given by:

    ![\\Delta\(\\lambda\) = |A-\\lambda I| = \(-1\)^n\(\\lambda^n + a_{n-1}\\lambda^{n-1} + \\cdots + a_0\) = 0](//upload.wikimedia.org/math/d/5/8/d58a588c2570c5f08eaac38ae821fae7.png)

Then the Cayley-Hamilton theorem states that the matrix _A_ itself is also a valid solution to that equation:

    ![\\Delta\(A\) = \(-1\)^n\(A^n + a_{n-1}A^{n-1} + \\cdots + a_0\) = 0](//upload.wikimedia.org/math/e/e/4/ee4fbaff2c5d8543c47519b8d2f79ffc.png)

Another theorem worth mentioning here (and by "worth mentioning", we really mean "fundamental for some later topics") is stated as:

If λ are the eigenvalues of matrix _A_, and if there is a function _f_ that is defined as a linear combination of powers of λ:

    ![f\(\\lambda\) = \\sum_{i = 0}^\\infty b_i \\lambda^i](//upload.wikimedia.org/math/4/a/8/4a8c205968999ce09c02469953eb432e.png)

If this function has a radius of convergence _S_, and if all the eigenvectors of _A_ have magnitudes less then _S_, then the matrix _A_ itself is also a solution to that function:

    ![f\(A\) = \\sum_{i = 0}^\\infty b_i A^i](//upload.wikimedia.org/math/7/7/4/7742396c913590a8b8057c0023b0e6e7.png)

**[Engineering Analysis](/wiki/Engineering_Analysis)**

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

Before reading this chapter, students should know what the _taylor series_ of a function is, and how to obtain it. This is discussed in [Calculus](/wiki/Calculus).

## Matrix Exponentials

If we have a matrix _A_, we can raise that matrix to a power of _e_ as follows:

    ![e^{A}](//upload.wikimedia.org/math/f/b/7/fb717fb0abd184c4dd3706f13a98b606.png)

It is important to note that this is not necessarily (not usually) equal to each individual element of _A_ being raised to a power of _e_. Using taylor-series expansion of exponentials, we can show that:

    ![e^{A} = I + A + \\frac{1}{2}A^2 + \\frac{1}{6}A^3 + ...  = \\sum_{k=0}^\\infty{1 \\over k!}A^k](//upload.wikimedia.org/math/0/1/6/0165656313d8f7d17f025d1eb5049cf7.png).

In other words, the matrix exponential can be reducted to a sum of powers of the matrix. This follows from both the taylor series expansion of the exponential function, and the cayley-hamilton theorem discussed previously.

However, this infinite sum is expensive to compute, and because the sequence is infinite, there is no good cut-off point where we can stop computing terms and call the answer a "good approximation". To alleviate this point, we can turn to the [Cayley-Hamilton Theorem](/wiki/Engineering_Analysis/Cayley_Hamilton_Theorem). Solving the Theorem for _An_, we get:

    ![A^n = -c_{n-1}A^{n-1} - c_{n-2}A^{n-2} - \\cdots - c_1A - c_0I](//upload.wikimedia.org/math/9/0/a/90afbe02cc548259cda727c81716e7b8.png)

Multiplying both sides of the equation by _A_, we get:

    ![A^{n+1} = -c_{n-1}A^n - c_{n-2}A^{n-1} - \\cdots - c_1A^2 - c_0A](//upload.wikimedia.org/math/6/7/c/67c711bb973064a8b47e73afd185c77d.png)

We can substitute the first equation into the second equation, and the result will be _An+1_ in terms of the first _n - 1_ powers of _A_. In fact, we can repeat that process so that _Am_, for any arbitrary high power of m can be expressed as a linear combination of the first _n - 1_ powers of _A_. Applying this result to our exponential problem:

    ![e^A = \\alpha_0I + \\alpha_1A + \\cdots + \\alpha_{n-1}A^{n-1}](//upload.wikimedia.org/math/1/0/3/103eec4258bbae708f3b8cb564cac685.png)

Where we can solve for the α terms, and have a finite polynomial that expresses the exponential.

## Inverse

The inverse of a matrix exponential is given by:

    ![\(e^{A}\)^{-1} = e^{-A}](//upload.wikimedia.org/math/7/0/2/7029a873e2a08c4261026932c96fdd9e.png)

## Derivative

The derivative of a matrix exponential is:

    ![\\frac{d}{dx}e^{Ax} = Ae^{Ax} = e^{Ax}A](//upload.wikimedia.org/math/b/4/8/b4839a89f38e4fe5958c947c860d2cac.png)

Notice that the exponential matrix is commutative with the matrix _A_. This is not the case with other functions, necessarily.

## Sum of Matrices

If we have a sum of matrices in the exponent, we cannot separate them:

    ![e^{\(A+B\)x} \\ne e^{Ax}e^{Bx}](//upload.wikimedia.org/math/8/1/2/812fc34c0bf52cc0e80959e1bf0d0e1d.png)

## Differential Equations

If we have a first-degree differential equation of the following form:

    ![x'\(t\) = Ax\(t\) + f\(t\)](//upload.wikimedia.org/math/b/8/5/b85c8b61f6c720efa968ad99569b4e7d.png)

With initial conditions

    ![x\(t_0\) = c](//upload.wikimedia.org/math/1/9/9/1996cfa6499ec9bcf92600049635044c.png)

Then the solution to that equation is given in terms of the matrix exponential:

    ![x\(t\) = e^{A\(t - t_0\)}c + \\int_{t_0}^t e^{A\(t - \\tau\)}f\(\\tau\)d\\tau](//upload.wikimedia.org/math/9/0/b/90b7705869c1932653cbbfb98662a38c.png)

This equation shows up frequently in control engineering.

## Laplace Transform

As a matter of some interest, we will show the Laplace Transform of a matrix exponential function:

    ![\\mathcal{L}\[e^{At}\] = \(sI - A\)^{-1}](//upload.wikimedia.org/math/e/0/c/e0cccf0f134fc7a0dd52e1ceec968af4.png)

We will not use this result any further in this book, although other books on engineering might make use of it.

  


# Function Spaces

**[Engineering Analysis](/wiki/Engineering_Analysis)**

## Function Space

A function space is a linear space where all the elements of the space are functions. A function space that has a norm operation is known as a **normed function space**. The spaces we consider will all be normed.

## Continuity

_f(x)_ is continuous at _x0_ if, for every ε _> 0_ there exists a δ(ε) _> 0_ such that _|f(x) - f(x0)| <_ &epsilon when _|x - x0| <_ δ(ε).

## Common Function Spaces

Here is a listing of some common function spaces. This is not an exhaustive list.

### C Space

The _C_ function space is the set of all functions that are continuous.

The metric for _C_ space is defined as:

    ![\\rho\(x, y\)_{L_2} = \\max|f\(x\) - g\(x\)|](//upload.wikimedia.org/math/2/6/5/2653a3ebeb122827adda437c97d1bd2b.png)

Consider the metric of _sin(x)_ and _cos(x)_:

    ![\\rho\(sin\(x\), cos\(x\)\)_{L_2} = \\sqrt{2}, x = \\frac{3\\pi}{4}](//upload.wikimedia.org/math/5/9/a/59a9bdcfad8cfd4169faceadc12b0096.png)

### Cp Space

The _Cp_ is the set of all continuous functions for which the first _p_ derivatives are also continuous. If ![ p = \\infty](//upload.wikimedia.org/math/4/0/8/408b711e5b12e3b7a40c58bb23458f3a.png) the function is called "infinitely continuous. The set ![C^\\infty](//upload.wikimedia.org/math/0/c/5/0c582a21481872f0a89dcc6a3c224581.png) is the set of all such functions. Some examples of functions that are infinitely continuous are exponentials, sinusoids, and polynomials.

### L Space

The _L_ space is the set of all functions that are finitely integrable over a given interval _[a, b]_.

_f(x)_ is in _L(a, b)_ if:

    ![\\int_a^b |f\(x\)|dx < \\infty](//upload.wikimedia.org/math/d/0/7/d0743ece99f509cd7d08ef07128b3eec.png)

### L p Space

The _Lp_ space is the set of all functions that are finitely integrable over a given interval _[a, b]_ when raised to the power _p_:

    ![\\int_a^b |f\(x\)|^pdx < \\infty](//upload.wikimedia.org/math/5/9/5/595c789bf3136123f7601adb00eb346c.png)

Most importantly for engineering is the _L2_ space, or the set of functions that are "square integrable".

**[Engineering Analysis](/wiki/Engineering_Analysis)**

The _L2_ space is very important to engineers, because functions in this space do not need to be continuous. Many discontinuous engineering functions, such as the delta (impulse) function, the unit step function, and other discontinuous finctions are part of this space.

## L2 Functions

A large number of functions qualify as _L2_ functions, including uncommon, discontinuous, piece-wise, and other functions. A function which, over a finite range, has a finite number of discontinuties is an _L2_ function. For example, a unit step and an impulse function are both _L2_ functions. Also, other functions useful in signal analysis, such as square waves, triangle waves, wavelets, and other functions are _L2_ functions.

In practice, most physical systems have a finite amount of noise associated with them. Noisy signals and random signals, if finite, are also _L2_ functions: this makes analysis of those functions using the techniques listed below easy.

## Null Function

The null functions of _L2_ are the set of all functions φ in _L2_ that satisfy the equation:

    ![\\int_a^b |\\phi\(x\)|^2dx = 0](//upload.wikimedia.org/math/a/d/f/adfee8dcd7fa050bf521740a52102897.png)

for all _a_ and _b_.

## Norm

The _L2_ norm is defined as follows:

  


[L2 Norm]

    ![\\|f\(x\)\\|_{L_2} = \\sqrt{\\int_a^b |f\(x\)|^2dx}](//upload.wikimedia.org/math/e/d/d/edd5e8ccdedb98770fd4a65d67032ea4.png)

If the norm of the function is 1, the function is normal.

We can show that the derivative of the norm squared is:

    ![\\frac{\\partial \\|x\\|^2}{\\partial x} = 2x](//upload.wikimedia.org/math/d/b/9/db97c00fd0387d084b0c2e85a6534685.png)

## Scalar Product

The scalar product in _L2_ space is defined as follows:

  


[L2 Scalar Product]

    ![\\langle f\(x\), g\(x\)\\rangle_{L_2} = \\int_a^bf\(x\)g\(x\)dx](//upload.wikimedia.org/math/b/6/4/b641c4e02122d1037f8612e04a658ac6.png)

If the scalar product of two functions is zero, the functions are orthogonal.

We can show that given coefficient matrices _A_ and _B_, and variable _x_, the derivative of the scalar product can be given as:

    ![\\frac{\\partial}{\\partial x}\\langle Ax, Bx\\rangle = A^TBx + B^TAx](//upload.wikimedia.org/math/3/7/d/37d8308c962bac226218b4eccd643430.png)

We can recognize this as the product rule of differentiation. Generalizing, we can say that:

    ![\\frac{\\partial}{\\partial x}\\langle f\(x\), g\(x\)\\rangle = f'\(x\)g\(x\) + f\(x\)g'\(x\)](//upload.wikimedia.org/math/8/4/8/848b1035bc83ea8a4da0d957c014082d.png)

We can also say that the derivative of a matrix _A_ times a vector _x_ is:

    ![\\frac{d}{dx}Ax = A^T](//upload.wikimedia.org/math/c/0/d/c0dab5570216307d76c886555bed087f.png)

## Metric

The metric of two functions (we will not call it the "distance" here, because that word has no meaning in a function space) will be denoted with ρ_(x,y)_. We can define the metric of an _L2_ function as follows:

  


[L2 Metric]

    ![\\rho\(x, y\)_{L_2} = \\sqrt{\\int_a^b|f\(x\) - g\(x\)|^2dx}](//upload.wikimedia.org/math/d/e/0/de070aeee989f0d3e53f0f263fd9901d.png)

## Cauchy-Schwarz Inequality

The Cauchy-Schwarz Inequality still holds for _L2_ functions, and is restated here:

    ![|\\langle f\(x\), g\(x\)\\rangle| \\le \\|f\\|\\|g\\|](//upload.wikimedia.org/math/6/a/a/6aa857804b496e08149bdc8317bf2660.png)

## Linear Independance

A set of functions in _L2_ are linearly independent if:

    ![a_1f_1\(x\) + a_2f_2\(x\) + \\cdots + a_nf_n\(x\) = 0](//upload.wikimedia.org/math/d/b/9/db920466237f70d8a15c9bd77e4023b1.png)

If and only if all the _a_ coefficients are 0.

## Grahm-Schmidt Orthogonalization

The Grahm-Schmidt technique that we discussed earlier still works with functions, and we can use it to form a set of linearly independent, orthogonal functions in _L2_.

For a set of functions φ, we can make a set of orthogonal functions ψ that space the same space but are orthogonal to one another:

  


[Grahm-Schmidt Orthogonalization]

    ![\\psi_1 = \\phi_1](//upload.wikimedia.org/math/f/2/a/f2a81ecdee23df2d8e099b62e91de24b.png)
    ![\\psi_i = \\phi_i - \\sum_{n=1}^{i-1}\\frac{\\langle \\psi_n, \\phi_{i}\\rangle}{\\langle \\psi_n, \\psi_n\\rangle}\\psi_n](//upload.wikimedia.org/math/1/f/1/1f1a03bea23801d4cc999f2311fe827c.png)

## Basis

The _L2_ is an infinite-basis set, which means that any basis for the _L2_ set will require an infinite number of basis functions. To prove that an infinite set of orthogonal functions is a basis for the _L2_ space, we need to show that the null function is the only function in _L2_ that is orthogonal to all the basis functions. If the null function is the only function that satisfies this relationship, then the set is a basis set for _L2_.

By definition, we can express any function in _L2_ as a linear sum of the basis elements. If we have basis elements φ, we can define any other function ψ as a linear sum:

    ![\\psi\(x\) = \\sum_{n = 1}^\\infty a_n\\phi_n\(x\)](//upload.wikimedia.org/math/6/6/6/6660ad30e36649636e0db5d16a5f051f.png)

We will explore this important result in the section on [Fourier Series](/wiki/Engineering_Analysis/Fourier_Series).

**[Engineering Analysis](/wiki/Engineering_Analysis)**

There are some special spaces known as **Banach** spaces, and **Hilbert** spaces.

## Convergent Functions

Let's define the piece-wise function φ(x) as:

    ![\\phi_n\(x\) = \\left\\{\\begin{matrix}0 &  x \\le 0 \\\\
                                         nx & 0 < x \\le \\frac{1}{n} \\\\
                                         1 & \\frac{1}{n} < x 
                           \\end{matrix}\\right. ](//upload.wikimedia.org/math/6/9/6/696b586c162d47dbbba1663844e1dabd.png)

We can see that as we set ![n \\to \\infty](//upload.wikimedia.org/math/d/3/a/d3a3154c093175197f6594a7db2f1b2f.png), this function becomes the unit step function. We can say that as n approaches infinity, that this function converges to the unit step function. Notice that this function only converges in the L2 space, because the unit step function does not exist in the C space (it is not continuous).

### Convergence

We can say that a function φ converges to a function φ* if:

    ![\\lim_{n \\to \\infty}\\|\\phi_n - \\phi^*\\| = 0](//upload.wikimedia.org/math/f/7/8/f78903bd36c350f3326b3292c83f9930.png)

We can call this sequences, and all such sequences that converge to a given function as n approaches infinity a **cauchy sequence**.

### Complete Function Spaces

A function space is called complete if all sequences in that space converge to another function in that space.

## Banach Space

A Banach Space is a complete normed function space.

## Hilbert Space

A Hilbert Space is a Banach Space with respect to a norm induced by the scalar product. That is, if there is a scalar product in the space X, then we can say the norm is induced by the scalar product if we can write:

    ![\\|f\\| = g\(\\langle f, f\\rangle\)](//upload.wikimedia.org/math/c/f/2/cf25baacf0c50357658c1d7797a17862.png)

That is, that the norm can be written as a function of the scalar product. In the L2 space, we can define the norm as:

    ![\\|f\\| = \\sqrt{\\langle f, f\\rangle}](//upload.wikimedia.org/math/3/5/e/35ec7e3416a3a69ef4d04ec9706dd4d7.png)

If the scalar product space is a Banach Space, if the norm space is also a Banach space.

In a Hilbert Space, the Parallelogram rule holds for all members f and g in the function space:

    ![\\|f + g\\|^2 + \\|f - g\\|^2 = 2\\|f\\|^2 + 2\\|g\\|^2](//upload.wikimedia.org/math/2/d/b/2db550a8a38a88696fbece9cd7089443.png)

The L2 space is a Hilbert Space. The C space, however, is not.

  


# Fourier Series

**[Engineering Analysis](/wiki/Engineering_Analysis)**

![Information](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Information_icon.svg/32px-Information_icon.svg.png)

Before reading this chapter, students should be familiar with the _fourier series_ decomposition method. Information about this can be found in [Signals and Systems](/wiki/Signals_and_Systems).

The L2 space is an infinite function space, and therefore a linear combination of any infinite set of orthogonal functions can be used to represent any single member of the L2 space. The decomposition of an L2 function in terms of an infinite basis set is a technique known as the **Fourier Decomposition** of the function, and produces a result called the **Fourier Series**.

## Fourier Basis

Let's consider a set of L2 functions, ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png), as follows:

    ![\\phi = \\{1, \\sin\(\\pi x\), \\cos\(\\pi x\), \\sin\(2\\pi x\), \\cos\(2\\pi x\), \\sin\(3\\pi x\), \\cos\(3\\pi x\) ...\\}. \\ ](//upload.wikimedia.org/math/f/1/e/f1ea3f2ce5194b23ff4032c9601cb994.png)

We can prove that over a range ![\[0, 2\\pi\]](//upload.wikimedia.org/math/5/8/c/58c9a5de0cb1a343ae0acd1fb191eea1.png), all of these functions are orthogonal:

    ![\\int_0^{2\\pi} 1 \\cdot \\cos\(n\\pi x\) dx = 0](//upload.wikimedia.org/math/b/7/b/b7b1d063eaa61562f2e399e28e3612f6.png)
    ![\\int_0^{2\\pi} 1 \\cdot \\sin\(n\\pi x\) dx = 0](//upload.wikimedia.org/math/1/a/c/1ac9c1a03f87410361dc265e986856ee.png)
    ![\\int_0^{2\\pi} \\sin\(n\\pi x\) \\sin\(m\\pi x\)dx = 0, n \\ne m](//upload.wikimedia.org/math/b/8/8/b88d1c5ef656bae99d3d4ae4cc85d53e.png)
    ![\\int_0^{2\\pi} \\sin\(n\\pi x\) \\cos\(m\\pi x\)dx = 0](//upload.wikimedia.org/math/e/b/3/eb3de7af4c6ff35aab71314083fd0141.png)
    ![\\int_0^{2\\pi} \\cos\(n\\pi x\) \\cos\(m\\pi x\)dx = 0, n \\ne m](//upload.wikimedia.org/math/5/4/6/5460e30d0f293fbfcdfc1166aad72051.png)

Because ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png) is as an infinite orthogonal set in L2, ![\\phi](//upload.wikimedia.org/math/7/f/2/7f20aa0b3691b496aec21cf356f63e04.png) is also a valid basis set in the L2 space. Therefore, we can decompose any function in L2 as the following sum:

  


[Classical Fourier Series]

    ![\\psi\(x\) = a_0\(1\) + \\sum_{n=1}^\\infty a_n \\sin\(n\\pi x\) + \\sum_{m=1}^\\infty b_m\\cos\(m\\pi x\)](//upload.wikimedia.org/math/7/7/c/77c0f71c5fe57c95f9f257cde00403aa.png)

However, the difficulty occurs when we need to calculate the a and b coefficients. We will show the method to do this below:

## a0: The Constant Term

Calculation of a0 is the easiest, and therefore we will show how to calculate it first. We use the value of a0 which minimizes the error in approximating ![f\(x\)](//upload.wikimedia.org/math/5/0/b/50bbd36e1fd2333108437a2ca378be62.png) by the Fourier series.

First, define an error function, E, that is equal to the squared norm of the difference between the function f(x) and the infinite sum above:

    ![E = \\frac{1}{2}\\int_0^{2\\pi}\\|f\(x\) - a_0\(1\) - \\sum_{n=1}^\\infty a_n \\sin\(n\\pi x\) - \\sum_{m=1}^\\infty b_m\\cos\(m\\pi x\)\\|^2dx](//upload.wikimedia.org/math/a/2/c/a2ce03558a5d8c4e637c8c8289028a55.png)

For ease, we will write all the basis functions as the set φ, described above:

    ![\\sum_{i=0}^\\infty a_i\\phi_i = a_0 + \\sum_{n=1}^\\infty a_n \\sin\(n\\pi x\) + \\sum_{m=1}^\\infty b_m\\cos\(m\\pi x\)](//upload.wikimedia.org/math/b/6/3/b63bc8b90ccdf37ef2e9d24369457c29.png)

Combining the last two functions together, and writing the norm as an integral, we can say:

    ![E = \\frac{1}{2}\\int_0^{2\\pi}|\\sum_{i=0}^\\infty a_i\\phi_i|^2dx](//upload.wikimedia.org/math/b/a/8/ba821ccf26ee643f341e27f58ca8f4d1.png)

We attempt to minimize this error function with respect to the constant term. To do this, we differentiate both sides with respect to a0, and set the result to zero:

    ![0 = \\frac{\\partial E}{\\partial a_0} = \\int_0^{2\\pi} \(f\(x\) - \\sum_{i=0}^\\infty a_i\\phi_i\(x\)\)\(-\\phi_0\(x\)\)dx](//upload.wikimedia.org/math/b/5/8/b58546416217b55e59953a4afba57a69.png)

The φ0 term comes out of the sum because of the chain rule: it is the only term in the entire sum dependant on a0. We can separate out the integral above as follows:

    ![\\int_0^{2\\pi} \(f\(x\) - \\sum_{i=0}^\\infty a_i\\phi_i\)\(-\\phi_0\)dx = -\\int_0^{2\\pi}f\(x\)\\phi_0\(x\)dx + a_0\\int_0^{2\\pi}\\phi_0\(x\)\\phi_0\(x\)dx](//upload.wikimedia.org/math/a/a/1/aa1ced3e44ebe6bebe7761cccf76bbca.png)

All the other terms drop out of the infinite sum because they are all orthogonal to φ0. Again, we can rewrite the above equation in terms of the scalar product:

    ![0 = -\\langle f\(x\), \\phi_0\(x\)\\rangle + a_0\\langle \\phi_0\(x\), \\phi_0\(x\)\\rangle](//upload.wikimedia.org/math/6/e/1/6e11bc42d1968e7ba6274eddd5e17858.png)

And solving for a0, we get our final result:

    ![a_0 = \\frac{\\langle f\(x\), \\phi_0\(x\)\\rangle}{\\langle \\phi_0\(x\), \\phi_0\(x\)\\rangle}](//upload.wikimedia.org/math/4/8/d/48dd279257fa92287701ce1550ae442e.png)

## Sin Coefficients

Using the above method, we can solve for the an coefficients of the sin terms:

    ![a_n = \\frac{\\langle f\(x\), \\sin\(n\\pi x\)\\rangle}{\\langle \\sin\(n\\pi x\), \\sin\(n\\pi x\)\\rangle}](//upload.wikimedia.org/math/b/4/1/b414ce18b57244f907fc2a087f57533d.png)

## Cos Coefficients

Also using the above method, we can solve for the bn terms of the cos term.

    ![b_n = \\frac{\\langle f\(x\), \\cos\(n\\pi x\)\\rangle}{\\langle \\cos\(n\\pi x\), \\cos\(n\\pi x\)\\rangle}](//upload.wikimedia.org/math/f/6/5/f6584e88ca325d0098c85e148a03c686.png)

**[Engineering Analysis](/wiki/Engineering_Analysis)**

The classical Fourier series uses the following basis:

    ![\\phi\(x\) = {1, \\sin\(n\\pi x\), \\cos\(n \\pi x\)}, n = 1, 2, ...](//upload.wikimedia.org/math/4/6/a/46a17c29753ea52c5033ff4d84c5ea56.png)

However, we can generalize this concept to extend to any orthogonal basis set from the L2 space.

We can say that if we have our orthogonal basis set that is composed of an infinite set of arbitrary, orthogonal L2 functions:

    ![\\phi = {\\phi_1, \\phi_2, \\cdots, }](//upload.wikimedia.org/math/8/e/c/8ecc1e555a681bb2b5106228a9b68710.png)

We can define any L2 function f(x) in terms of this basis set:

  


[Generalized Fourier Series]

    ![f\(x\) = \\sum_{n=1}^\\infty a_n\\phi_n\(x\)](//upload.wikimedia.org/math/1/0/6/106b146bfa9b54fb5ab2a1f914b1d365.png)

Using the method from the previous chapter, we can solve for the coefficients as follows:

  


[Generalized Fourier Coefficient]

    ![a_n = \\frac{\\langle f\(x\), \\phi_n\(x\)\\rangle}{\\langle \\phi_n\(x\), \\phi_n\(x\)\\rangle}](//upload.wikimedia.org/math/7/d/9/7d9e579e90b50581b4e2414a6f6e703b.png)

**[Engineering Analysis](/wiki/Engineering_Analysis)**

Bessel's equation relates the original function to the fourier coefficients an:

  


[Bessel's Equation]

    ![\\sum_{n=1}^\\infty a_n^2 \\le \\|f\(x\)\\|^2](//upload.wikimedia.org/math/5/6/5/5657cb31961541da441db531e8b2cd62.png)

If the basis set is infinitely orthogonal, and if an infinite sum of the basis functions perfectly reproduces the function f(x), then the above equation will be an equality, known as Parseval's Theorem:

  


[Parseval's Theorem]

    ![\\sum_{n=1}^\\infty a_n^2 = \\|f\(x\)\\|^2](//upload.wikimedia.org/math/e/5/5/e55d062c5c780996d19550441efc3efe.png)

Engineers may recognize this as a relationship between the energy of the signal, as represented in the time and frequency domains. However, parseval's rule applies not only to the classical Fourier series coefficients, but also to the generalized series coefficients as well.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

The concept of the fourier series can be expanded to include 2-dimensional and n-dimensional function decomposition as well. Let's say that we have a function in terms of independent variables x and y. We can decompose that function as a double-summation as follows:

    ![f\(x,y\) = \\sum_{i=1}^\\infty\\sum_{j=1}^\\infty a_{ij}\\phi_{ij}\(x,y\)](//upload.wikimedia.org/math/0/8/9/089fb266387a9eac707a58d82ffd80c2.png)

Where φij is a 2-dimensional set of orthogonal basis functions. We can define the coefficients as:

    ![a_{ij} = \\frac{\\langle f\(x,y\), \\phi_{ij}\(x,y\)\\rangle}{\\langle \\phi_{ij}\(x,y\),\\phi_{ij}\(x,y\)\\rangle}](//upload.wikimedia.org/math/f/0/d/f0d5f39b6a4e39012981091872dc433a.png)

This same concept can be expanded to include series with n-dimensions.

## further reading

  * [Basic Physics of Nuclear Medicine/Fourier Methods](/wiki/Basic_Physics_of_Nuclear_Medicine/Fourier_Methods) discusses using 2D and 3D Fourier reconstruction to get images of the interior of the human body.
  * [Kevin Cowtan's Book of Fourier](http://www.ysbl.york.ac.uk/~cowtan/fourier/fourier.html): a book of pictorial 2-d Fourier Transforms.

  


# Miscellany

**[Engineering Analysis](/wiki/Engineering_Analysis)**

  


[Lyapunov's Equation]

    ![AM + MB = C](//upload.wikimedia.org/math/2/c/3/2c334a38188241b88a1c7944b23bcafd.png)

Where _A_, _B_ and _C_ are constant square matrices, and M is the solution that we are trying to find. If _A_, _B_, and _C_ are of the same order, and if _A_ and _B_ have no eigenvalues in common, then the solution can be given in terms of matrix exponentials:

    ![M = -\\int_0^\\infty e^{Ax}Ce^{Bx}dx](//upload.wikimedia.org/math/a/3/d/a3dd34ad69db4103b376c57b26eabfe9.png)

**[Engineering Analysis](/wiki/Engineering_Analysis)**

Leibniz' rule allows us to take the derivative of an integral, where the derivative and the integral are performed using different variables:

**[Engineering Analysis](/wiki/Engineering_Analysis)**

Wavelets are orthogonal basis functions that only exist for certain windows in time. This is in contrast to sinusoidal waves, which exist for all times t. A wavelet, because it is dependant on time, can be used as a basis function. A wavelet basis set gives rise to wavelet decomposition, which is a 2-variable decomposition of a 1-variable function. Wavelet analysis allows us to decompose a function in terms of time and frequency, while fourier decomposition only allows us to decompose a function in terms of frequency.

## Mother Wavelet

If we have a basic wavelet function ψ(t), we can write a 2-dimensional function known as the **mother wavelet function** as such:

    ![\\psi_{jk} = 2^{j/2}\\psi\(2^jt - k\)](//upload.wikimedia.org/math/a/1/a/a1ac1f1fd048b86d4c1c66cfd7392443.png)

## Wavelet Series

If we have our mother wavelet function, we can write out a fourier-style series as a double-sum of all the wavelets:

    ![f\(t\) = \\sum_{j=0}^\\infty\\sum_{k=0}^\\infty a_{jk}\\psi_{jk}\(t\)](//upload.wikimedia.org/math/0/7/e/07e8a6ca9b27f8ce21f0d3f62baff8bd.png)

## Scaling Function

Sometimes, we can add in an additional function, known as a **scaling function**:

    ![f\(t\) = \\sum_{i=0}^\\infty c_i\\phi_i + \\sum_{j=0}^\\infty\\sum_{k=0}^\\infty a_{jk}\\psi_{jk}\(t\)](//upload.wikimedia.org/math/6/c/4/6c40831f77c674e871f49571ee751990.png)

The idea is that the scaling function is larger than the wavelet functions, and occupies more time. In this case, the scaling function will show long-term changes in the signal, and the wavelet functions will show short-term changes in the signal.

**[Engineering Analysis](/wiki/Engineering_Analysis)**

## Optimization

**Optimization** is an important concept in engineering. Finding any solution to a problem is not nearly as good as finding the one "optimal solution" to the problem. Optimization problems are typically reformatted so they become **minimization problems**, which are well-studied problems in the field of mathematics.

Typically, when optimizing a system, the costs and benefits of that system are arranged into a **cost function**. It is the engineers job then to minimize this cost function (and thereby minimize the cost of the system). It is worth noting at this point that the word "cost" can have multiple meanings, depending on the particular problem. For instance, cost can refer to the actual monetary cost of a system (number of computer units to host a website, amount of cable needed to connect Philadelphia and New York), the delay of the system (loading time for a website, transmission delay for a communication network), the reliability of the system (number of dropped calls in a cellphone network, average lifetime of a car transmission), or any other types of factors that reduce the effectiveness and efficiency of the system.

Because optimization typically becomes a mathematical minimization problem, we are going to discuss minimization here.

### Minimization

Minimization is the act of finding the numerically lowest point in a given function, or in a particular range of a given function. Students of mathematics and calculus may remember using the derivative of a function to find the maxima and minima of a function. If we have a function _f_(_x_), we can find the maxima, minima, or saddle-points (points where the function has zero slope, but is not a maxima or minima) by solving for _x_ in the following equation:

    ![\\frac{df\(x\)}{dx} = 0](//upload.wikimedia.org/math/f/b/8/fb84f0f88715e4172be440feb1227416.png)

In other words, we are looking for the roots of the derivative of the function _f_ plus those points where _f_ has a corner. Once we have the so called critical points of the function (if any), we can test them to see if they are relatively high (maxima), or relatively low (minima). Some words to remember in this context are:

Global Minima
    A global minimum of a function is the lowest value of that function anywhere. If the domain of the function is restricted, say _A_ < _x_ < _B_, then the minima can also occur at the boundary, here _A_ or _B_.

Local Minima
    A local minimum of a function is the lowest value of that function within a small range. A value can thus be a local minimum even though there are smaller function values, but not in a small neighborhood.

## Unconstrained Minimization

**Unconstrained Minimization** refers to the minimization of the given function without having to worry about any other rules or caveats. **Constrained Minimization**, on the other hand, refers to minimization problems where other relations called _constraints_ must be satisfied at the same time.

Beside the method above (where we take the derivative of the function and set that equal to zero), there are several numerical methods that we can use to find the minima of a function. For these methods there are useful computational tools such as **Matlab**.

### Hessian Matrix

The function has a local minima at a point _x_ if the Hessian matrix _H_(_x_) is positive definite:

    ![H\(x\) = \\frac{\\partial^2 f\(x\)}{\\partial x^2}](//upload.wikimedia.org/math/d/7/e/d7ef32b9b904bde627ad7d2a5fdaab97.png)

Where _x_ is a vector of all the independant variables of the function. If _x_ is a scalar variable, the hessian matrix reduces to the second derivative of the function _f_.

### Newton-Raphson Method

The **Newton-Raphson Method** of computing the minima of a function _f_ uses an iterative computation. We can define the sequence:

    ![x^{n+1} = x^n - \\frac{f'\(x\)}{f''\(x\)}](//upload.wikimedia.org/math/8/5/a/85a56c1c32a9c86d4d019db20cb8684d.png)

Where

    ![f'\(x\) = \\frac{df\(x\)}{dx}](//upload.wikimedia.org/math/9/5/c/95cb4a766d906c406542091305ea468b.png)

    ![f''\(x\) = \\frac{d^2f\(x\)}{dx^2}](//upload.wikimedia.org/math/0/7/5/075b564f880c9baaee0342853ca2fcf1.png)

As we repeat the above computation, plugging in consecutive values for _n_, our solution will converge on the true solution. However, this process will take infinitely many iterations to converge, but if an approximation of the true solution will suffices, you can stop after only few iterations, because the sequence converges rather quickly (quadratic).

### Steepest Descent Method

The Newton-Raphson method can be tricky because it relies on the second derivative of the function _f_, and this can oftentimes be difficult (if not impossible) to accurately calculate. The **Steepest Descent Method**, however, does not require the second derivative, but it does require the selection of an appropriate scalar quantity ε, which cannot be chosen arbitrarily (but which can also not be calculated using a set formula). The Steepest Descent method is defined by the following iterative computation:

    ![x^{n+1} = x^n - \\epsilon \\frac{df\(x\)}{dx}](//upload.wikimedia.org/math/4/3/3/43392478ee04c55b94946a0b91168b5d.png)

Where epsilon needs to be sufficiently small. If epsilon is too large, the iteration may diverge. If this happens, a new epsilon value needs to be chosen, and the process needs to be repeated.

### Conjugate Gradient Method

## Constrained Minimization

_Constrained Minimization'_ is the process of finding the minimum value of a function under a certain number of additional rules called constraints. For instance, we could say "Find the minium value of _f_(_x_), but _g_(_x_) must equal 10". These kinds of problems are more difficult, but the **Khun-Tucker** theorem, and also the **Karush-Khun-Tucker** theorem help to solve them.

There are two different types of constraints: equality constraints and inequality constraints. We will consider them individually, and then mixed constraints.

### Equality Constraints

The Khun-Tucker Theorem is a method for minimizing a function _f_(_x_) under the equality constraint _g_(_x_). The theorem reads as follows:

Given the cost function _f_, and an equality constraint _g_ in the following form:

    ![g\(x\) = 0](//upload.wikimedia.org/math/c/3/6/c36a0c4a611d3144a5e9078a3aa481ac.png),

Then we can convert this problem into an unconstrained minimization problem by constructing the **Lagrangian** function of _f_ and _g_:

    ![L\(x\) = f\(x\) + \\langle \\Lambda, g\(x\)\\rangle](//upload.wikimedia.org/math/d/2/d/d2d5dc06f19ac148ce63aaa68028a03f.png)

Where Λ is the _lagrange multiplier_, and < , > denotes the **scalar product** of the vector space R_n_ (where _n_ is the number of equality constraints). We will discuss scalar products in more detail later. If we differentiate this equation with respect to _x_, we can find the minimum of this whole function _L_(_x_,_Λ_), and that will be the minimum of our function _f_.

    ![\\frac{df\(x\)}{dx} + \\left\\langle\\Lambda,\\frac{dg\(x\)}{dx}\\right\\rangle = 0](//upload.wikimedia.org/math/c/3/6/c368a843a30b0053889ae45a0c4759ce.png)
    ![g\(x\) = 0](//upload.wikimedia.org/math/c/3/6/c36a0c4a611d3144a5e9078a3aa481ac.png)

This is a set of _n+k_ equations with _n+k_ unknown variables (_n_ Λs and _k_ _x_s).

  


### Inequality Constraints

Similar to the method above, let us say that we have a cost function _f_, and an inequality constraint in the following form:

    ![g\(x\) \\le 0](//upload.wikimedia.org/math/a/8/1/a81a930b6c97bcfb51a382039cec53e7.png)

Then we can take the Lagrangian of this again:

    ![L\(x\) = f\(x\) + \\langle \\Lambda, g\(x\)\\rangle](//upload.wikimedia.org/math/d/2/d/d2d5dc06f19ac148ce63aaa68028a03f.png)

But we now must use the following three equations/ inequalities in determining our solution:

    ![\\frac{df}{dx} = 0](//upload.wikimedia.org/math/7/d/6/7d66d2b6e52a1467c8d70fc01e38ee4f.png)
    ![\\langle\\Lambda , g\(x\)\\rangle = 0](//upload.wikimedia.org/math/1/e/a/1ea6d635459918d769c5984f41bbc2d3.png)
    ![\\Lambda \\ge 0](//upload.wikimedia.org/math/d/b/3/db39a836efb985373f4614d326e51f04.png)

These last second equation can be interpreted in the following way:

    if ![g\(x\) < 0](//upload.wikimedia.org/math/8/7/2/87297c7aa79942fee74bd0aca0e21b5a.png), then ![\\Lambda = 0](//upload.wikimedia.org/math/d/7/e/d7eabe60b22993e777c99c38408c0596.png)
    if ![g\(x\) \\le 0](//upload.wikimedia.org/math/a/8/1/a81a930b6c97bcfb51a382039cec53e7.png), then ![\\Lambda \\ge 0](//upload.wikimedia.org/math/d/b/3/db39a836efb985373f4614d326e51f04.png)

Using these two additional equations/ inequalities, we can solve in a similar manner as above.

### Mixed Constraints

If we have a set of equality and inequality constraints

    ![g\(x\) = 0](//upload.wikimedia.org/math/c/3/6/c36a0c4a611d3144a5e9078a3aa481ac.png)
    ![h\(x\) \\le 0](//upload.wikimedia.org/math/2/2/b/22bb7366806b4ad3012332ef01c5577e.png)

we can combine them into a single Lagrangian with two additional conditions:

    ![L\(x\) = f\(x\) + \\langle\\Lambda, g\(x\)\\rangle + \\langle \\mu, h\(x\)\\rangle](//upload.wikimedia.org/math/c/8/8/c886b346971b74d730d316009d92a141.png)
    ![g\(x\)=0](//upload.wikimedia.org/math/c/3/6/c36a0c4a611d3144a5e9078a3aa481ac.png)
    ![\\langle\\mu, h\(x\)\\rangle = 0](//upload.wikimedia.org/math/6/5/e/65eedb386e642df4836762b71046e4f3.png)
    ![\\mu \\ge 0](//upload.wikimedia.org/math/e/e/9/ee91b8704b1716fcc68e89d3e5edf413.png)

## Infinite Dimensional Minimization

The above methods work well if the variables involved in the analysis are finite-dimensional vectors, like those in the **R**_N_. However, when we are trying to minimize something that is more complex than a vector, i.e. a function we need the following concept. We consider functions that live in a subspace of L2(**R**_N_), which is an infinite-dimensional vector space. We will define the term **functional** as follows:

Functional
    A functional is a map that takes one or more functions as arguments, and which returns a scalar value.

Let us say that we consider functions _x_ of time _t_ (_N_=1). Suppose further we have a fixed function _f_ in two variables. With that function, we can associate a cost functional _J_:

    ![J\[x\] = \\int_a^b f\(x,t\) dt](//upload.wikimedia.org/math/4/1/5/4158810ae4808fda90be2ebf8812424c.png)

Where we are explicitly taking account of _t_ in the definition of _f_. To minimize this function, like all minimization problems, we need to take the derivative of the function, and set the derivative to zero. However, we need slightly more sophisticated version of derivative, because _x_ is a function. This is where the **Gateaux Derivative** enters the field.

### Gateaux Derivative

We can define the **Gateaux Derivative** in terms of the following limit:

    ![\\delta F\(x, h\) = \\lim_{\\epsilon \\to 0} \\frac{1}{\\epsilon} \[F\(x + \\epsilon h\) - F\(x\)\]](//upload.wikimedia.org/math/7/7/1/7719cca56585159a217b78d645865d30.png)

Which is similar to the classical definition of the derivative in the direction _h_. In plain words, we took the derivative of _F_ with respect to _x_ in the direction of _h_. _h_ is an arbitrary function of time, in the same space as _x_ (here we are talking about the space L2). Analog to the one-dimensional case a function is differentiable at _x_ iff the above limit exists. We can use the Gateaux derivative to find the minimization of our functional above.

### Euler-Lagrange Equation

We will now use the Gateaux derivative, discussed above, to find the minimizer of the following types of function:

    ![J\(x\(t\)\) = \\int_a^b f\(x\(t\), x'\(t\), t\)dt](//upload.wikimedia.org/math/a/7/5/a75b7b916261cd65996ffe4b1978855d.png)

We thus have to find the solutions to the equation:

    ![\\delta J\(x\) = 0](//upload.wikimedia.org/math/8/a/8/8a808d22c9f83d747a0e2872983f0687.png)

The solution is the **Euler-Lagrange Equation**:

    ![\\frac{\\partial f}{\\partial x} - \\frac{d}{dt}\\frac{\\partial f}{\\partial x'} = 0](//upload.wikimedia.org/math/7/7/3/773e11069edf8ae30cd71ec99dbfb965.png)

The partial derivatives are done in an ordinary way ignoring the fact that _x_ is a function of _t_. Solutions to this equation are either maxima, minima, or saddle points of the cost functional _J_.

### Example: Shortest Distance

We've heard colloquially that the shortest distance between two points is a straight line. We can use the Euler-Lagrange equation to prove this rule.

If we have two points in **R**2, _a_, and _b_, we would like to find the minimum curve _(x,y(x))_ that joins these two points. Line element _ds_ reads:

    ![ds = \\sqrt{dx^2 + dy^2}](//upload.wikimedia.org/math/8/2/4/824bcd4d26478e40fe2c3a96e2cc072a.png)

Our function that we are trying to minimize then is defined as:

    ![J\[y\] = \\int_a^b ds](//upload.wikimedia.org/math/5/c/e/5cea6ef132816650136137a5c944a262.png)

or:

    ![J\[y\] = \\int_a^b \\sqrt{1 + \\left\(\\frac{dy}{dx}\\right\)^2}dx](//upload.wikimedia.org/math/a/8/9/a89880c6d9f5896aed6f37f7ab1992d5.png)

We can take the Gateaux derivative of the function J and set it equal to zero to find the minimum function between these two points. Denoting the square root as _f_, we get

    ![0=\\frac{\\partial f}{\\partial y}-\\frac{d}{dx}\\left\(\\frac{\\partial f}{\\partial y'}\\right\)=y''\\frac{1}{\\left\(1+y^{\\prime2}\\right\)^{3/2}} \\;.](//upload.wikimedia.org/math/e/7/a/e7a33fd4e6c6ba36d15eea75ef4e833a.png)

Knowing that the line element will be finite this boils down to the equation

    ![\\frac{d^2y}{dx^2}=0](//upload.wikimedia.org/math/d/1/0/d1065022a26cc4b6667d1881f21955f9.png)

with the well known solution

    ![y\(x\)=mx+n=\\frac{b_y-a_y}{b_x-a_x}\(x-a_x\)+a_y \\;.](//upload.wikimedia.org/math/a/1/f/a1f16c0b5ea43cf22d55472a416e85d6.png)

# License

# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Engineering_Analysis/Print_version&oldid=793609](http://en.wikibooks.org/w/index.php?title=Engineering_Analysis/Print_version&oldid=793609)" 

[Category](/wiki/Special:Categories): 

  * [Engineering Analysis](/wiki/Category:Engineering_Analysis)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Engineering+Analysis%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Engineering+Analysis%2FPrint+version)

### Namespaces

  * [Book](/wiki/Engineering_Analysis/Print_version)
  * [Discussion](/w/index.php?title=Talk:Engineering_Analysis/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Engineering_Analysis/Print_version)
  * [Edit](/w/index.php?title=Engineering_Analysis/Print_version&action=edit)
  * [View history](/w/index.php?title=Engineering_Analysis/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Engineering_Analysis/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Engineering_Analysis/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Engineering_Analysis/Print_version&oldid=793609)
  * [Page information](/w/index.php?title=Engineering_Analysis/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Engineering_Analysis%2FPrint_version&id=793609)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Engineering+Analysis%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Engineering+Analysis%2FPrint+version&oldid=793609&writer=rl)
  * [Printable version](/w/index.php?title=Engineering_Analysis/Print_version&printable=yes)

  * This page was last modified on 20 March 2007, at 01:35.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Engineering_Analysis/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
