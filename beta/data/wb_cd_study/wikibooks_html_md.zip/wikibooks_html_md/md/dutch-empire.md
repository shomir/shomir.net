# Dutch Empire/Print Version

From Wikibooks, open books for an open world

< [Dutch Empire](/wiki/Dutch_Empire)

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Dutch Empire](/wiki/Dutch_Empire)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Dutch_Empire/Print_Version&action=purge&printable=yes) this page.

  
  


# Introduction

Hello, and welcome to the History of the Dutch Empire. Here we will cover the history of the Dutch colonies, as well as the Netherlands itself. I encourage anyone to contribute, as many sections currently do not cover enough material. So any help would be appreciated, particularly with my spelling which is not that good.

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Dutch_Empire35.PNG/600px-Dutch_Empire35.PNG)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

A map of the Dutch Empire, dark green is the Dutch West India Company, and light green in the Dutch East India Company. It is important to note that not all of these territories were held at once.

  


  


Pre-Independence (1543-1567)

  


  
  


# Origins of an Empire

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Plakkaat_van_Verlatinghe.jpg/120px-Plakkaat_van_Verlatinghe.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Oath of Abjuration, the Dutch declaration of Independence

The coastal provinces of Holland and Zeeland had for a long time prior to Spanish rule been important hubs of the European maritime trade network. Their geographical location provided convenient access to the markets of France, Germany, England and the Baltic. The war with Spain led many financiers and traders to emigrate from Antwerp, capital of Flanders and then one of Europe's most important commercial centres, to Dutch cities, particularly Amsterdam, which became Europe's foremost centre for shipping, banking, and insurance. Efficient access to capital enabled the Dutch in the 1580s to extend their trade networks beyond northern Europe to new markets in the Mediterranean and the Levant. In the 1590s, Dutch ships began to trade with Brazil and the Gold Coast of Africa, and towards the Indian Ocean and the source of the lucrative spice trade. This brought the Dutch into direct competition with Portugal, which had dominated these trade networks for several decades, and had established colonial outposts on the coasts of Brazil, Africa and the Indian Ocean to facilitate them. The rivalry with Portugal, however, was not entirely economic: from 1580 the Portuguese crown had been joined to that of Spain in an "Iberian Union" under Phillip II. By attacking Portuguese overseas possessions, the Dutch forced Spain to divert financial and military resources away from its attempt to quell Dutch independence. Thus this began the Dutch-Portuguese War, which would last until the 1650's.

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Dutch-Port_War_Result.PNG/250px-Dutch-Port_War_Result.PNG)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Results of the Dutch Portuguese War, Green is Dutch

In 1594, a "Company of Far Lands" was founded in Amsterdam, with the aim of sending two fleets to the spice islands of Maluku. The first fleet sailed in 1596 and returned in 1597 with a cargo of pepper, which more than covered the costs of the voyage. The second fleet, departing in 1598 and returning in 1599, returned its investors a 400% profit. The success of these voyages led to the founding of a number of companies competing for the trade. The competition was counterproductive to the companies' interests as it threatened to drive up the price of spices at their source in Indonesia while driving them down in Europe.

  


  


The Rise of the Dutch (1567-1652)

  


  
  


# Dutch Revolt

_One need not hope in order to undertake, nor succeed in order to persevere.-William the Silent_

## Origins of the Revolt

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/43/19-_Rei_D._Filipe_I_-_O_Prudente.jpg/220px-19-_Rei_D._Filipe_I_-_O_Prudente.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Philip II

### Religion

During the 16th century, Protestantism rapidly gained ground in the Dutch Provinces. Initially the Spanish repressed the Protestants, but eventually the local officials tolerated them. At the time the Protestants only formed a minority.

### Taxation

The Dutch provinces were always a very wealthy region. Under Charles V the Habsburg empire became a worldwide empire with large American and European territories. Due to the wealth of the Dutch, they were taxed heavily, to defend the Habsburg possessions in Europe.

### Philip II

In 1566, Philip II became the King of Spain. Charles, despite his harsh actions, had been seen as a ruler empathetic to the needs of the Netherlands. As soon as Philip became King, he began to suppress Protestantism by sending Spanish Troops, and imposing heavy taxes onto the Dutch. In an effort to build a stable and trustworthy government in the Netherlands, Philip appointed several members of the high nobility of the Netherlands to the States General, the governing body of the seventeen Netherlands. However already in 1558 the states started to contradict Philip’s wishes, by objecting to his tax proposals and demanding the withdrawal of Spanish troops. Petitions to King Philip by the high nobility went unanswered.

## The Revolt Begins

Early in August of 1566, a mob stormed the church of Hondschoote in Flanders (now in Northern France). This relatively small incident spread North and led to a massive iconoclastic movement by Calvinists, who stormed churches and other religious buildings to desecrate and destroy statues and images of Catholic saints all over the Netherlands. The Calvinists said that they were idols. As the nobles began to turn against Spain, Philip realized he had lost control of the Dutch. On August 22, 1567, Fernando Álvarez de Toledo, 3rd Duke of Alba, marched into Brussels with 10,000 troops.

Alba took terrible measures against the Dutch and quickly established his own court. Over one thousand people were executed in the following months, even nobles who tolerated Protestantism were not safe. The large number of executions led the court to be nicknamed the "Blood Court" in the Netherlands, and Alba to be called the "iron duke". Rather than pacifying the Netherlands, these measures helped to fuel the unrest.

### William of Orange

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/46/WilliamOfOrange1580.jpg/250px-WilliamOfOrange1580.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

William the Silent

William I of Orange, also known as William the Silent, was Stadtholder of the provinces of Holland, Zeeland and Utrecht, and Margrave of Antwerp; and one of the most influential nobles in the States General. After the arrival of Alba he was forced to flee, and his lands were forfeited to the Spanish king.

However, he returned in 1568, and attempted to drive Alba out of Brussels. William said he remained loyal to Philip, but thought Alba was a misguided minister. Though the campaign ended in failure, it saw a Dutch Victory at Battle of Heiligerlee before William's army ran out of money.

William would continue to be the leader of the revolt for the remainder of his life. Today, he is still remembered in the Netherlands, as _"Vader des Vaderlands"_ which in English means _"Father of the Fatherland"_.

### Another Uprising

By 1570 the Spanish had more or less suppressed the rebellion throughout the Netherlands. It was also a year of disaster. On All Saints Day a big storm hit the low lieing areas of the coast of Zeeland and Holland. It wiped away most of the dykes and killed thousands. This flood stands out as one of the more severe ones in the long litany of such events in the country's history.

There was little help from the authorities. On the contrary, in an attempt to finance the Spanish Army against the Ottoman Empire, Alba proposed the "Tenth Penny", a 10 per cent levy on all sales other than landed property. At first it was rejected by the States, but soon after a compromise was agreed upon. in 1571, Alba decided to press forward with the collection of the Tenth Penny regardless of the States' opposition. Catholics and Protestants protested together against this Tenth Penny, in vain. A band of _Geuzen_, licensed pirates, led mostly by dispossessed members of the lower gentry that had lost their welcome in English ports, attacked and captured the coastal town of Brill on April first 1572. They were welcomed as heroes, particularly by the Protestants. Members of the Catholic clergy did not fare as well. To give their exploits an aura of respectability the pirates decided to declare themselves 'for the prince', referring to the Prince of Orange who had tried to inspire rebellion from his exile in Dillenburg in Germany. This was the first permanent foothold for the Dutch in the War.

It would have been a relatively unimportant event if most of the important cities in the provinces of Holland and Zeeland had not declare loyalty to the prince as well, often prodded by their own population's rallies. Notable exceptions were Amsterdam and Middelburg, which would remain loyal to the Catholic cause until 1578. William the Silent was put at the head of the revolt. He was recognized as Governor-General and Stadtholder of Holland, Zeeland, Friesland and Utrecht. In an attempt to encourage the people to revolt against Spain, William converted to Calvinism, as the Calvinists wanted above all other religions, to revolt.

### The response

The rebellion was still limited to what, in the Burgundian-Habsburg Netherlands, were considered provinces of lesser importance. The rich provinces of Flanders and Brabant, with their ports and textile industry, remained quiet. This allowed the Spanish to attempt to quell the new rebellion. This proved a tedious and expensive process in the marshy lowlands. Naarden fell and its population was decimated. Haarlem underwent a long and horrible siege and its fall cut the rebels' territory in half. In 1573, Alba attempted to take the city of Alkmaar to the north, but he failed. Leyden to the south also withstood the Spanish onslaught. The _Geuzen_ pierced the dykes to flood the Spanish troops' positions and finished them off in flat-bottom boats.

### Bankruptcy

Alba's failure caused him to be replaced by Luis de Requesens, because his failing policies meant a considerable strain on the Spanish finances. De Requesens, however, did not manage to broker a policy acceptable to both the Spanish king and the Netherlands when he died in early 1576. Spain was forced to declare bankruptcy and the Spanish troops, angered and unpaid, sacked Antwerp, leaving some 8,000 dead.

This pierced the heart of the body politic. The rich merchants of Antwerp who had politely refused to take any political action so far did not like marauding soldiers invading their houses. They used their influence to do what the absentee king least of all wanted: they insisted upon the convening of the parliament, the States General.

The States General convened and decided to do what they had always refused to do for the king: they raised enough money to buy off the marauding troops. Their efforts reunited the provinces in what is known as the Pacification of Ghent. This meant that the other 14 provinces besides Holland, Zeeland and Utrecht were now de facto part of the rebellion because -whether intentional or not- the mercenaries were now in _their_ service rather than the king's. The king was furious because losing control to the parliament was the last thing he wanted.

He sent an ultimatum to submit to his control immediately and a fresh army from Spain to underline his resolve.

## Independence and Partition

On January 6, 1579, prompted by the new Spanish governor Alexander Farnese and upset by the aggressive Calvinism of the Northern States, some of the Southern States, the so-called Walloon Flanders located in what is now France and Wallonia, signed the Union of Arras, expressing their loyalty to the Spanish king.

In response to the treaty, William united the northern states of Holland, Zeeland, Utrecht, Guelders and the province of Groningen in the Union of Utrecht on January 23, 1579. Other southern cities like Bruges, Ghent, Brussels and Antwerp joined the Union of Utrecht. The 17 provinces of the Netherlands were now divided and this partition into what is now the Netherlands and Belgium would prove permanent, despite a brief and emphatically unsuccessful attempt at reunification from 1814-1831.

### The leadership question

William of Orange, was declared an outlaw by Philip II in March 1580. Four years later he was assassinated by Balthasar Gérard, a Catholic and supporter of the Spanish King, on July 10, 1584. Gérard was later tortured to death. William's dying words were "Oh my God, have mercy on this poor people". William would be succeeded as leader of the rebellion by his son Maurice of Nassau, Prince of Orange, but the question about the political structure and the leadership of the rebellious Union remained unsettled for a long time

In the late 16th century, it was not conceivable that a country could be governed by anyone but high nobility, if not a king, so the States General tried to find a suitable replacement for Philip. They asked Queen Elizabeth of England, but she declined the offer. On July 26, 1581 the Oath of Abjuration was issued, in which the Netherlands proclaimed that the King of Spain had not upheld his responsibilities to the Netherlands population and would therefore no longer be accepted as rightful king. A few years later, in 1585, Elizabeth agreed to aid the Dutch, but as no one would be their king, the rebellious provinces decided for a rather unlikely option at the time: they became a republic: the Republic of the Seven United Netherlands. Many nations recognized the fledgling country shortly after, including France and England.

### Spain's response. Capitalist beginnings

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Plakkaat_van_Verlatinghe.jpg/250px-Plakkaat_van_Verlatinghe.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Oath of Abjuration

Immediately after the oath of abjuration, Spain sent a new army to recapture the Dutch Republic and a process of reconquest began, concentrating on the 'important' provinces like the cities of Flanders. Ghent fell and all of its Protestants fled north. This process led to the expulsion of an estimated 10-15% of the population of the South who would flee to the North, often the more elite part of the population.

In 1585 the Spanish succeeded in capturing Antwerp. They may have believed they had won the war with that, but they allowed most of the merchants to leave, not realizing that without the people who made the trade work all they conquered were brick and stone. The merchants soon set up shop in Amsterdam. Meanwhile Spain had gained control over Portugal and what had been the major port for colonial goods: Lisbon. The merchants of the rebellious Netherlands therefore had no choice but to find ways to acquire the precious spices themselves as they were no longer welcome in Lisbon. They cooperated to raise enough capital for such a risky venture. To do so they developed instruments like shareholdership and insurance. The result was that the rebellious provinces rapidly developed into a merchant dominated oligarchy driven by colonial enterprise based on capitalist -rather than government controlled- principles. All colonies until 1795 would be strictly under control of the VOC or WIC companies. Dutch colonial enterprise was very profitable and quickly made it financially impossible for the Spanish to reconquer the lost provinces, although they would persist until 1648 in trying. However the Dutch model of colonial enterprise also had its drawbacks. Many decisions were strictly based on short-term bottom-line considerations. For example, when Mauritius -unsettled until the Dutch took it- suffered damage from a typhoon the island was simply abandoned because the leadership of the VOC did not deem it profitable to restore the damage. Few on the island speak Dutch today.

## International involvement

Both England and France had followed the developments in the Netherlands with a keen eye. After all Spain was the sole superpower of its day, but one that seemed rather mired in Dutch peat and clay.

After finding out about English support for the Dutch in 1588, Philip ordered the Spanish Armada to invade England, the mission failed and the Spanish navy was crippled. Under financial and military pressure, in 1598, Philip ceded the Netherlands to his favorite daughter Isabella and to her husband, his nephew Archduke Albert of Austria.

Around this time, Maurice, son of William, launched a number of campaigns and over the next 12 years captured the cities of Breda (1590), Zutphen, Deventer, Delfzijl and Nijmegen (1591), Steenwijk, Coevorden (1592) Geertruidenberg (1593) Groningen (1594) Grol, Enschede, Ootmarsum, Oldenzaal (1597) and Grave (1602). It was during this time when the fighting had left the heart of the republic, that the Dutch advanced into their Golden Age.

After a decisive Dutch victory at the Battle of Gibraltar, Spain and the Dutch Republic agreed to a ceasefire. This resulted in the 12 Years Truce.

## 12 Years Truce

1609 saw the start of a ceasefire, afterwards called the Twelve Years' Truce, between the United Provinces and the Spanish controlled southern states, mediated by France and England at The Hague. It was during this ceasefire the Dutch made great efforts to build their navy, which was later to have a crucial bearing on the course of the war.

Negotiations for a permanent peace went on throughout the truce. Two major issues could not be resolved. First, the Spanish demand for religious freedom of Catholics in the northern Netherlands was countered by a Dutch demand for a similar religious freedom for Protestants in the southern Netherlands. Second, there was a growing disagreement over the trade routes to the different colonies which could not be resolved.

## War Breaks Out Again

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Piet_Hein.jpg/250px-Piet_Hein.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Piet Pieterszoon Hein

In 1622, a Spanish attack on the important fortress town of Bergen op Zoom was repelled, but the countries were at war again. This part of the war would be a part of the more extensive Thirty-Years War. In 1625 the Spanish laid siege to the city of Breda, and Maurice died during the siege. After the English failed to relieve the siege, the city was surrendered to the Spanish.

Despite this major victory, the Spanish would face a string of losses, including the Dutch capture of the cities of Groenlo, and Hertogenbosch. The Dutch, led by Piet Pieterszoon Hein, captured a Spanish treasure fleet off the coast of present day Cuba.

As more European countries began to build their empires, the war between the countries extended to colonies as well. Battles for profitable colonies were fought as far away as Macau, East Indies, Ceylon, Formosa (Taiwan), the Philippines, Brazil, and others. The most important of these conflicts would become known as the Dutch-Portuguese War. The Dutch carved out a trading empire all over the world, using their dominance at sea to great advantage.

### Spain's Decline at Sea

In 1639, Spain sent an armada bound for Flanders, carrying 20,000 troops in a last attempt to end what they still thought was a "Revolt". The armada was defeated by Lieutenant-Admiral Maarten Tromp in the Battle of the Downs. This battle was so crushing to the Spanish naval power, it would never fully recover.

## Peace

On January 30, 1648, the war ended with the Treaty of Münster between Spain and the Dutch Republic. In the treaty, Spain agreed to recognize Dutch Independence, and finally, after an 80 year struggle, the Dutch Republic was an independent country, recognized by all.

The treaty also confirmed that the new republic was formally independent from the Holy Roman Empire. This was a mere formality because a century before Charles V, both lord of the Netherlands and Emperor, had created the Netherlands as a separate entity in what is known as the Pragmatic Sanction. The 17 provinces were to be inherited together and had their own parliament, not subservient to the German Diet. To squeeze some more money out of the provinces, Charles had insisted that they pay a yearly sum of money to 'the emperor' (himself) in exchange for 'his protection', but that summed up what little relationships left with the Empire. A century later, in 1648, the Empire was little more than a rubble heap and the Republic the richest state in Europe. The Emperor knew that he needed to drop all expensive pretenses, if even Spain needed to.

The relations between Spain and the Republic would quickly improve and a few years later they were allies, particularly against French aspirations.

  


  


# The Beginning

“
You probably have to have redundant levee systems with canals in between them, like the Dutch have, to make sure that incoming water is channeled off to areas where you deal with it rather than have it drown you.
”

—Billy Tauzin

As a result of the problems caused by intercompany rivalry, the Dutch East India Company (or VOC, from the Dutch Verenigde Oost-Indische) was founded in 1602. The charter awarded to the Company by the States-General granted it sole rights, for an initial period of twenty-one years, to Dutch trade and navigation east of the Cape of Good Hope and west of the Straits of Magellan. The directors of the company, the "Heeren XVII" were given the legal authority to establish "fortresses and strongholds", to sign treaties, to enlist its own army and navy, and to wage defensive war. The company itself was founded as a joint stock company, similarly to the English East India Company, that had been founded two years earlier. In 1621 the Dutch West India Company was set up and given a twenty-five year monopoly to those parts of the world that were not controlled by its East India counterpart: the Atlantic, the Americas and the west coast of Africa.

  


  


# Asia

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/45/Dutch_and_Portuguese_in_Asia_c_1665.png/350px-Dutch_and_Portuguese_in_Asia_c_1665.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Dutch and Portuguese possessions in the East Indies 1665

The VOC began immediately to take away the string of coastal fortresses that at the time comprised the Portuguese Empire. The settlements were isolated, difficult to reinforce if attacked, and prone to being picked off one by one, and the Dutch enjoyed great success attacking these forts. Amboina was captured from the Portuguese in 1605, but an attack on Malacca the following year narrowly failed in its objective to provide a more strategically located base in the East Indies with favorable monsoon winds. The Dutch found what they were looking for in Jakarta, conquered by Jan Coen in 1619, later renamed Batavia after the Latin name for Holland, and which would become the capital of the Dutch East Indies. Meanwhile, the Dutch continued to drive out the Portuguese from their bases in Asia. Malacca succumbed in 1641 (the first attempt had failed), Colombo in 1656, Ceylon in 1658, Nagappattinam in 1662 and Cranganore and Cochin in 1662. Goa, the capital of the Portuguese Empire in the East, was attacked by the Dutch twice in 1603 and 1610, on both occasions unsuccessfully. While the Dutch were unable in four attempts to capture Macau from where Portugal monopolised the lucrative China-Japan trade, the Japanese shogunate's increasing suspicion of the intentions of the Catholic Portuguese led to their expulsion in 1639. Under the subsequent sakoku policy, for two hundred years the Dutch were the only European power allowed to operate in Japan, confined in 1639 to Hirado and then from 1641 at Deshima.

In 1624 the VOC established Fort Zeelandia in Taiwan. The Dutch originally sought to use their castle Fort Zeelandia at Tayowan (Anping) as a trading base between Japan and China, but soon realized the potential of the huge deer populations that roamed in herds of thousands along the alluvial plains of Taiwan's western regions. The Dutch built a second administrative castle on the main island of Taiwan in 1633 and set out to turn Taiwan into a Dutch colony. They surprssed the villages who resisted them. In 1661, a naval fleet of 1000 warships, led by the Ming loyalist Koxinga, landed at Lu'ermen to attack Taiwan in order to destroy and oust the Dutch from Zeelandia. Following a nine month siege, Koxinga captured the Dutch Fort Zeelandia and defeated the Dutch. Koxinga then forced the Dutch Government to sign a peace treaty at Zeelandia on February 1, 1662, and leave Taiwan.

By the middle of the seventeenth century, the Dutch had overtaken Portugal as the dominant player in the spice and silk trade, and in 1652 founded a colony at Cape Town on the coast of South Africa, as a way-station for its ships on the route between Europe and Asia.

  


  


# The Atlantic

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/55/Dutch_Conquests_Brazil_Caribbean.png/350px-Dutch_Conquests_Brazil_Caribbean.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Dutch conquests in Brazil and the Caribbean

In the Atlantic, the West India Company concentrated on wresting from Portugal its grip on the sugar and slave trade, and on opportunistic attacks on the Spanish treasure fleets on their homeward bound voyage. Bahia on the north east coast of Brazil was captured in 1624 but only held for a year before it was recaptured by a joint Spanish-Portuguese expedition. In 1628, Piet Heyn captured the entire Spanish treasure fleet, and made off with a vast fortune in precious metals and goods that enabled the Company two years later to pay its shareholders a cash dividend of 70%, though the Company was to have relatively few other successes against the Spanish. In 1630, the Dutch occupied the Portuguese sugar-settlement of Pernambuco and over the next few years pushed inland, annexing the sugar plantations that surrounded it. In order to supply the plantations with the manpower they required, an expedition was launched in 1637 from Brazil to capture the Portuguese slaving post of Elmina., and in 1641 successfully captured the Portuguese settlements in Angola. By 1650, the West India Company was firmly in control of both the sugar and slave trades, and had occupied the Caribbean islands of Sint Maarten, Curaçao, Aruba and Bonaire in order to guarantee access to the islands' salt-pans.

Unlike in Asia, Dutch successes against the Portuguese in Brazil and Africa were short-lived. Years of settlement had left large Portuguese communities under the rule of the Dutch, who were by nature traders rather than colonisers. In 1645, the Portuguese community at Pernambuco rebelled against their Dutch masters, and by 1654, the Dutch had been ousted from Brazil. In the intervening years, a Portuguese expedition had been sent from Brazil to recapture Luanda in Angola, by 1648 the Dutch were expelled from there also.

On the north-east coast of North America, the West India Company took over a settlement that had been established by the Company of New Netherland (1614-18) at Fort Orange at Albany on the Hudson River, relocated from Fort Nassau which had been founded in 1614. The Dutch had been sending ships annually to the Hudson River to trade fur since Henry Hudson's voyage of 1609. In order to protect its precarious position at Albany from the nearby English and French, the Company founded the fortified town of New Amsterdam in 1625 at the mouth of the Hudson, encouraging settlement of the surrounding areas of Long Island and New Jersey. The fur trade ultimately proved impossible for the Company to monopolise due to the massive illegal private trade in furs, and the settlement of New Netherland was unprofitable. In 1655, the nearby colony of New Sweden on the Delaware River was forcibly absorbed into New Netherland after ships and soldiers were sent to capture it by the Dutch governor, Peter Stuyvesant.

Ever since its inception, the Dutch East India Company had been in competition with its counterpart, the English East India Company, founded two years earlier but with a capital base eight times smaller, for the same goods and markets in the East. In 1619, the rivalry resulted in the Amboyna massacre, when several English Company men were executed by agents of the Dutch. The event remained a source of English resentment for several decades, and in the late 1620s the English Company shifted its focus to from Indonesia to India.

  


  


Rivalry with England and France (1652-1795)

  


  
  


# Dutch Culture During the Golden Age

“
The thrifty maxim of the wary Dutch, Is to save all the Money they can touch.
”

—Benjamin Franklin

The Dutch Golden Age was an age of wealth and prosperity in the Dutch Republic roughly from 1590-1715. Along with wealth, Dutch trade, science, and art were among the most acclaimed in the world.

## Wealth

During a large part of the 17th century the Dutch, traditionally able seafarers and keen mapmakers, dominated world trade, a position which before had been occupied by the Portuguese and Spaniards, and which later would be lost to England. With the VOC dominating trade in Asia, their wealth came into the Netherlands. The Dutch also dominated trade between European countries. The Low Countries were favorably positioned on a crossing of east-west and north-south trade routes and connected to a large German hinterland through the Rhine river. Dutch traders shipped wine from France and Portugal to the Baltic lands and returned with grain destined for countries around the Mediterranean Sea. The Trip brothers, arms traders, built the Trippenhuis in Amsterdam, currently the seat of the Royal Netherlands Academy of Arts and Sciences, which is a typical example of 17th century architecture.

## Social Structure and Religion

Dutch society promoted freedom of expression and religious tolerance, with a wide array of religions from atheists to Catholics. There was a large and well-established middle class, and an excellent educational system.

## Science

## Culture

As a result of their trade, the Dutch were the wealthiest and most prosperous nation. There was a vast appreciation for the arts, and some of the most famous Baroque artists were Dutch, such as Vermeer, Rembrandt, and Reubens.

  


  


# Anglo-Dutch Wars

“
The rise of the Dutch Republic must ever be regarded as one of the leading events of modern times.
”

—John L. Motley

## First Anglo-Dutch War(1652-1654)

The trading rivalry between the Dutch Republic and England broke out into war in May of 1652. Maarten Tromp, commander of the Dutch Navy, was slow to dip his flag in his salute, an English ship fired warning shots, hitting a Dutch Ship. This led to the Battle of Goodwin Sands and the start of the First Anglo-Dutch War. One Dutch diplomat stated _"The English are about to attack a mountain of gold; we are about to attack a mountain of iron."_ The war would be costly for both sides.

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Maarten_Harpertszoon_Tromp.jpg/200px-Maarten_Harpertszoon_Tromp.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Maarten Tromp

At the Battle of Plymouth, the English attempted to destroy the Dutch fleet, however they were beaten back, and pursed by Michiel de Ruyter. It was the beginning of a Dutch legend. Soon after the Battle of Plymouth, the English and Dutch fleets clashed again in the North Sea at the Battle of the Kentish Knock. The English routed the Dutch fleet commanded by Tromp, and mistakingly believing that the Dutch fleet was destroyed, did not pursue.

The English, very confident they had won the war, sent most of their fleet to the Mediterranean. The Dutch then launched a surprise attack on the remaining English Fleet in the North Sea, which gave control of the North Sea and the English Channel back to the Dutch. By spring, the English fleet had returned and defeated the Dutch at the Battle of Portland. Several days later, however, a small portion of each sides' fleets met in the Battle of Leghorn in Italy and the Dutch chased the English out of the Mediterranean. The English fleet won another major victory at the Battle of the Gabbard. The Dutch fleet was too weak to challenge the English and therefore a blockade was put on the Dutch Republic, which crippled the Dutch economy.

The Dutch broke the English blockade at the Battle of Scheveningen, but during the fight Tromp was killed. At this point, both sides were completely exhausted from war and signed the Treaty of Westminster (1654). The treaty failed to resolve the dispute between the two countries, and only set the stage for the next war.

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Beerstraaten%2C_Battle_of_Scheveningen.jpg/200px-Beerstraaten%2C_Battle_of_Scheveningen.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Battle of Scheveningen

## Second Anglo-Dutch War(1665-1667)

The issues that started the First-Anglo Dutch War, still remained and were not resolved by the peace treaty. The English still wanted the Dutch trading routes, and to end the world domination of Dutch trade. As tensions increased the English seized the Dutch colony of New Netherland and took many Dutch trading posts on the coast of Africa. The Dutch quickly responded by sending Michiel de Ruyter to recapture their trading posts in Africa. After recapturing the trading posts, he sailed across the Atlantic, where the Dutch Fleet was attacked and forced to withdraw. Shortly after, on March 4, 1665, England declared war on the Dutch Republic.

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/30/Bol%2C_Michiel_de_Ruyter.jpg/200px-Bol%2C_Michiel_de_Ruyter.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Michiel de Ruyter

In June of 1665 the two fleets met in the North Sea. This would result in the Battle of Lowestoft. The English routed the Dutch fleet, destroying 17 Dutch warships at a cost of only one of their own. Even to this day it is the worst defeat in Dutch Naval History. The next conflict between the two sides was a minor encounter in Norwegian Port. At the Battle of Vågen, the English attempted to seize a few Dutch merchant ships. However, the merchant ships were being escorted by war ships and the English attack was driven back.

In June of 1666, the Dutch fleet under the control of De Ruyter, was attacked by the English fleet in the North Sea at the Four Days Battle. It was one of the largest Naval engagements in history, lasting four days (hence the name). After four days of constant engagement, De Ruyter, seeing that he had inflicted considerable damage on the English fleet, ordered his fleet to withdraw. The English lost 10 ships, the Dutch 4.

Later that summer the two fleets would clash again at St. James Day Battle. De Ruyter as once again in control of the Dutch fleet, his goal was to attack the English fleet while it was anchored in the Medway. On his way there, he discovered an English fleet of 89 ships and pursued it. The battle was a clear English Victory, inflicting heavy casualties onto the Dutch, however, De Ruyter was able to withdraw losing only 2 ships, while the results could have been much worse.

The English quickly decided to attack while the Dutch fleet was unable to fight back due to the losses it received in the St. James Day Battle. English Rear-Admiral Robert Holmes, attacked a large fleet of Dutch merchant ships. The English were successful in setting fire to, and destroying, 150 of the merchant ships.

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Van_Soest%2C_Attack_on_the_Medway.jpg/300px-Van_Soest%2C_Attack_on_the_Medway.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Raid on the Medway

In June of 1667, the Dutch Fleet under De Ruyter, decided to launch a daring attack on the English fleet while it was still docked. De Ruyter ordered an attack on June 10. The Dutch fleet quickly captured the English forts, and defeated the English ships guarding the Medway. On June 13, the whole of the Thames side as far up as London was in a panic — some spread the rumor that the Dutch were launching a full scale invasion of the country. Many citizens fled, taking their possessions with them. On June 14 the Dutch fleet withdrew, but they had sunk 13 English Ships, and captured 2 ships. The HMS Unity and the HMS Royal Charles, pride and normal flagship of the English fleet, while total losses for the Dutch were eight spent fireships and about fifty casualties. The Battle is now called Raid on the Medway, it was a decisive Dutch victory and is considered the Greatest Naval Victory in Dutch History, and the worst Naval Defeat in English. Commenting on the defeat, Samuel Pepys, English Naval Administrator and member of Parliament, said _"The Devil Shits Dutchmen"_.

After the raid on the Medway, the English fleet was crippled and England was forced to sue for peace. Pepys making another comment about the war, said _"Thus in all things, in wisdom, courage, force, knowledge of our own streams, and success, the Dutch have the best of us, and do end the war with victory on their side"_. During negotiations, the English offered to return New Netherland if the Dutch would return Suriname (which they had seized in 1667). The Dutch declined. On July 31, 1667 the Treaty of Breda (1667) was signed. The Dutch were now at the zenith of their power.

  


## Franco-Dutch War(1672-1678) and the Third-Anglo-Dutch War(1672-1674)

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Debruijn_holland_map.gif/250px-Debruijn_holland_map.gif)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Dutch position in the Summer of 1672, Black is French and their allies territory

France led a coalition including Münster and England. Louis XIV was annoyed by the Dutch refusal to cooperate in the destruction and division of the Spanish Netherlands. After making a secret agreement with England in 1672, France invaded the Dutch Republic. Today, 1672 is still remembered as Rampjaar in the Netherlands, which means "year of disasters". The French soon marched into the Heart of the Dutch Republic, taking Utrecht. To stop the French advance, the Dutch flooded the countryside (Dutch Water Line) which stopped the French advance. At this time, Prince William III of Orange is assumed to have had the leading Dutch politician Johan de Witt deposed and murdered and was acclaimed stadtholder.

On the western front, where the Dutch had been attacked by Munster, the Dutch defeated Munster at the Siege of Groningen. After the Dutch victory the Dutch liberated some territory and drove Munster out of the country.

Meanwhile, the sea war with England was going much better for the Dutch than the land war. The Dutch, lead by De Ruyter, defeated the English and French fleets at the Battle of Solebay and Schooneveld. The French and English then came up with a plan to invade the Republic by Sea. However, after their fleet was defeated at the Battle of Texel, they were unable to land troops. The war was becoming very unpopular at home in England, thus, the English withdrew signing the Treaty of Westminster (1674). In the treaty the Dutch agreed to return New Orange (formerly New Netherland) to England, which they had seized in 1673.

In 1673 Spain joined the war on the side of the Dutch. De Ruyter sailed the Dutch Fleet into the Mediterranean to destroy the French naval supremacy there. The Dutch were victorious in the Battles of Stromboli and Mt. Etna (1676); however, Admiral de Ruyter was mortally wounded in the latter. Respect for De Ruyter extended far beyond the borders of the Republic. When his body was shipped home, the late Lieutenant-Admiral-General was saluted by canon shots fired on the coasts of France, by the direct orders of the French King Louis XIV.

The War was not only in Europe, it extended to Canada. Jurriaen Aernoutsz, a navy captain from Curaçao, captured the French colony of Acadia in 1674. A Dutch fleet attacked, but failed to take Martinique 1674. In May 1676 Dutch Admiral Jacob Blinck took Cayenne and Tobago. The French would soon retake these possessions. In December 1676 French Vice-Admiral Jean d'Estrees retook Cayenne. The French also recaptured Tobago in 1677.

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/BattleOfTexel.jpg/350px-BattleOfTexel.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Battle of Texel

In Europe, the French had begun a slow withdrawal from the Republic. Negotiations began in 1676, and the Treaty of Nijmegen was signed in 1678. The war had been very costly for the Republic, but they had defended their land and kept all of their territory across the world.

## Fourth Anglo-Dutch War(1781-1784)

Britain declared war before the Dutch could join a group of neutral countries sworn to mutual assistance. The direct cause of the war was the discovery of a secret trade treaty proposed by the city of Amsterdam to the Americans. The Dutch had not at all expected such a severe reaction; they had given the British a perfect pretext to reduce Dutch power even more. This Fourth Anglo-Dutch War (1780–1784) proved a disaster for the Netherlands, particularly economically.

Dutch naval power had been in decline since 1714. The Dutch navy, now having only twenty ships of the line, was no match for the British navy. Britain had already gained supremacy of the high seas over France long before, in the Seven Years' War. The Dutch fought a minor skirmish with the British at the Battle of Dogger Bank, but had to avoid any other fighting. The Dutch had already hastily embarked on a major shipbuilding project of 84 warships between 1777 and 1789. Due to all kinds of misfortune (storms, collisions, strandings), about a third of the Dutch fleet sank between 1782 and 1784. Coordination with its war allies, France and Spain, was poor. The new ships were not ready in time to prevent Britain from taking effective control of the Dutch colonies and making William V a puppet, only able to rule with Prussian military assistance in the Triple Alliance (1788). The Republic joined a cease fire between Britain and France in January 1783. The signing of the Treaty of Paris (1784) made Negapatnam, in India, a British colony. Ceylon, though taken, was nominally given back. The British gained the right of free trade with part of the Dutch East Indies.

  


  


# Wars With Sweden

“
We cannot forget that our flag received its first foreign salute from a Dutch officer, nor that the Province of Friesland gave to our independence its first formal recognition.
”

—[Seth Low](//en.wikipedia.org/wiki/Seth_Low)

## Dutch-Swedish War

The Dutch-Swedish War began with the 1658 Swedish invasion of Denmark, during which Copenhagen was put under siege. The Dutch, worried about their trade in the Baltic, sent a fleet of 75 ships to break the siege resulting in the Battle of the Sound. The Danish ships were unable to help their Dutch allies due to unfavorable wind conditions. The Dutch fleet sunk 4 Swedish ships and forced the Swedish to abandon the siege of the city. In 1659, the Dutch, led by Michiel De Ruyter, liberated the other Danish isles under Swedish control, once more guaranteeing the essential supply of grain, wood, and iron from the Baltic region.

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/76/Battleofthesound.jpg/250px-Battleofthesound.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Battle of the Sound

## Scanian War

The Dutch were drawn into the Scanian War in 1676, when France asked for Swedish help in the Franco-Dutch War (see _[Anglo-Dutch Wars_](/wiki/Dutch_Empire/Anglo-Dutch_Wars)). In reply, the Dutch asked for Danish help. Denmark agreed and launched an invasion of Sweden.

At the Battle of Bornholm(1676), the Dutch-Danish fleet, half the size of the Swedish fleet, attacked and forced the fleet to retreat. The Dutch admiral Cornelis Tromp, with a squadron of 16 warships pursued the Swedish navy. The Swedish withdrew and tried to make it back to various Swedish ports but Tromp found the Swedish fleet near Öland. 14,000 Dutch-Danish troops were released from the ships and attacked the Swedish fortresses. At sea,the Swedish Navy was once again forced to withdraw. The Dutch and Danish troops soon captured the cities of Helsingborg and Landskrona, while taking other Swedish fortresses in the area within a month. These two battles gave control of the Baltic to the Dutch-Danish Navy.

After the Franco-Dutch war ended in 1678, the Dutch had a reduced role in the war. A French-dictated peace was negotiated at the Treaty of Fontainebleau on August 23, 1679, stipulating that all territory lost by Sweden be returned. Thus the terms formulated at the Treaty of Roskilde remained in force. It was reaffirmed by the Treaty of Lund, signed by Denmark-Norway and Sweden themselves.

  


  


# Later Wars

“
The residence of the Plymouth settlers in the Netherlands, and the later conquest of the Dutch colonies, had brought the Americans into contact with the singularly wise and free institutions of the Dutch.
”

—Albert B. Hart

## Nine Years War

In 1686 the Dutch joined The League of Augsburg along with Portugal, Spain, Sweden and the Holy Roman Empire. The goal of the alliance was to resist growing French aggression in Europe. France had expected a benevolent neutrality on the part of James II's England, but after James's deposition and replacement by his son-in-law William of Orange, Louis's inveterate enemy, England declared war on France in May of 1689, and the League of Augsburg became known as the "Grand Alliance", with England, Portugal, Spain, the United Provinces, and most of the German states joined together to fight France.

At the start of the War, the French had enormous success especially in the Spanish Netherlands. They began to push into the Spanish Netherlands, until they were finally stopped at the Battle of Walcourt. The French quickly recovered from their defeat with a victory at the Battle of Fleurus. The French were also successful in the Alps in 1690, with Marshal Catinat defeating the Duke of Savoy at the Battle of Staffardand occupying Savoy. The French were also successful at sea in 1691, defeating an Anglo-Dutch fleet at the Battle of Beachy Head. The French followed up on their success in 1691 with victories Mons and Halle. Also at this time the French continued their advance into Italy. The Dutch and English, very worried about Frances success, attempted to drive the French out of the Spanish Netherlands but were defeated at the Battle of Steenkerque in 1692.

Despite astounding French success on continental Europe, they were less successful in Ireland. An Army comprised of mostly Dutch troops under the command of Godert de Ginkell, defeated the Irish and French troops at the Battle of Aughrim, which resulted in the surrender of the French and Irish troops in Ireland.

French success in the seas would soon end. After an Anglo-Dutch victory at Battle of La Hougue the French lost control of the Channel for good. The allies were now free to make full use of their own, to harass the French coast, to intercept French commerce, and to cooperate with the armies acting against France.

For the next 6 years the Dutch role in the war was very minor. The Treaty of Ryswick was signed on September 20, 1697. In the Treaty the French paid the Dutch a sum of 16,000 pagodas.

## War of Spanish Succession

The War of Spanish Succession would be the last war that the Dutch would be a major power in. Spanish King Carlos II.,of the Habsburg Dynasty, died in 1700 and was without a male heir. France wanted to see a new dynasty on the throne. Europe's other powers were interested in both preventing France from extending her influence, and in preventing another long and costly war. In February 1701 Philip of Bourbon, 17 years old and named heir to the throne by Carlos II, entered a cheering Madrid; he was crowned King Philip V.

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/45/Duke-of-Marlborough-signing-Despatch-Blenheim-Bavaria-1704.jpg/250px-Duke-of-Marlborough-signing-Despatch-Blenheim-Bavaria-1704.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Battle of Belnheim

The Austrians, English the Dutch and the Portuguese, stood together against France and Spain. In 1702 the French had occupied the Spanish Netherlands in order to keep it safe for Spain. The Duke of Marlborough, commanding English-Dutch-Danish and Austrian troops, was victorious in the Battle of Blenheim 1704, Austrian forces in the Battles of Ramillies 1706, Oudenaarde 1708, and an Austro-English-Dutch force was also victorious at the Battle of Malplaquet in 1709.

The Anglo-Dutch fleet inflicted major damaged on the Spanish and French navies at the Battle of Vigo Bay.

In 1701 Austria had invaded Lombardy. Over the next six years, with the Anglo-Dutch Navies in control of the Medderteranian, the Austrians would push the French and Spanish troops off Italy.

The peace treaties of Utrecht and Rastatt formally ended the war in 1714. The Spanish Netherlands, for the most part, had gone to Austrian Control, Spain ceded most of its possessions in Italy and Philip V was still on the Spanish throne.

## War of the Quadruple Alliance

On August 2nd 1718, Great Britain, Austria, France and the Dutch Republic concluded the Quadruple Alliance, formed in order to contain Spain.

Spain began hostilities against the Holy Roman Empire by invading the island of Sardinia, given to Austria by the Treaty of Utrecht ending the War of the Spanish Succession. Shortly thereafter, the Spanish advanced, invading Sicily, which had been awarded to the Duke of Savoy.

The Dutch joined the war in 1719. Spain fared poorly in the war. A French army under the Duke of Berwick invaded the Basque provinces of Spain almost without resistance in April 1719, before being forced back by disease. Meanwhile, British and Dutch fleets captured Vigo and Pontevedra in October, and that same month,Messina surrendered to the Austrians.

Spain made peace with the allies at the Treaty of The Hague on February 17, 1720. Included in the terms of this treaty, the Duke of Savoy was forced to exchange his throne in Sicily for that of the less important Kingdom of Sardinia

  


  


Napoleonic Era (1795-1815)

  


  
  


# Batavian Republic

![](//upload.wikimedia.org/wikipedia/commons/c/c7/Dutch_Cape_Colony.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Dutch expansion of Cape Colony

The Batavian Republic was proclaimed on January 19, 1795, a day after the fled to England. The invading French revolutionary army, however, found quite a few allies in the Netherlands. Eight years before, the Orange faction had won the upper hand in a small, but nasty civil war. Many of the revolutionaries, who where full of the ideals from the American and French Revolutions, had fled to France and now returned eager to realize their ideals.

The new Republic took its name from the Batavi, a Germanic tribe who had lived in the area of the Netherlands in Roman times and who were then romantically regarded as the ancestors of the Dutch nation.

The new Republic did not experience a reign of terror or become a dictatorship. Changes were imposed from outside after Napoleon Bonaparte's rise to power. In 1805 Napoleon installed the shrewd politician Schimmelpenninck as raadspensionaris ("Grand Pensionary", President of the republic) to strengthen the executive branch.

In 1801, Napoleon imposed a new constitution on the republic, which was financially drained by French requisitions.

As a French vassal state, the Batavian Republic was an ally of France in its wars against Great Britain. This led to the loss of most of the Dutch Empire and a defeat of the Dutch fleet in the Battle of Camperdown in 1797. South Africa (cape colony), Sri Lanka, India and Berbice wer occupied by the British between 1795 and 1802. After peace was made between Britain and France in 1802, Berbice and South Africa were returned to the Dutch. However, after the outbreak of war again in 1803, Berbice was occupied and South Africa followed a few years later, in 1806. The collapse of Dutch trade caused a series of economic crises. Only in the second half of the 19th century would Dutch wealth be restored to its previous level.

In 1806 Napoleon forced Schimmelpenninck to resign and declared his brother, Louis Bonaparte, King, of the new Kingdom of Holland.

  


  


# Kingdom of Holland

“
To play Holland, you have to play the Dutch.
”

—Ruud Gullit

Kingdom of Holland was set up by Napoleon Bonaparte as a puppet kingdom for his third brother, Louis Bonaparte, in order to better control the Netherlands in 1806. The name of the leading province, Holland, was now taken for the whole country. In 1807 Prussian East Frisia and Jever were added to the kingdom but in 1809, after an English invasion, Holland had to give over all territories south of the river Rhine to France.

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f9/LouisBonaparte_Holland.jpg/200px-LouisBonaparte_Holland.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Louis Bonaparte, King of Holland

King Louis did not perform to Napoleon's expectations, he tried to serve Dutch interests instead of his brother's . Louis had learned the Dutch language, and proclaimed himself to be a "Hollander" as soon as he stepped into the country. In 1810, under heavy pressure from his brother, Louis abdicated and the Kingdom was annexed into the French Empire.

The kingdom of Holland covered the area of present day Netherlands, with the exception of Limburg, and parts of Zeeland, which were French territory. East Frisia (in present day Germany) was also part of the kingdom.

In 1810 the British invaded the Dutch island of Java, and their other possessions in the East Indies. This started the Anglo-Dutch Java War. By the end of 1811 the entire island was under British control.

  


  


# Under the French

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/99/Sadler%2C_Battle_of_Waterloo.jpg/300px-Sadler%2C_Battle_of_Waterloo.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Battle of Waterloo

In 1810 the Kingdom of Holland was dissolved by Napoleon. The 1812 campaign in Russia proved to be calamitous for Napoleon, but it was a complete disaster for the Dutch army. Of the 20,000+ Dutch soldiers serving in Russia, only a few hundred returned home (most had served with the rearguard at the Beresina). As Russian troops crossed the Dutch borders in 1813, a full-scale rebellion against the French broke out and the son of William V (who had since died), Willam Frederik, returned and became Willam I of a new Kingdom of the Netherlands. He went to The Hague to be granted the title Sovereign of The Netherlands on 2 December, 1813.

When Napoleon returned for the 100 Days, Dutch troops were sent to the front under control of William Frederick George Louis, future King of the Netherlands. During the Congress of Vienna, King William I succesfully won the peace and completed his dream of a United Netherlands by uniting the Southern Netherlands in the Kingdom. Java and Dutch Guiana(Suriname) were both returned to the Dutch, but Berbice, today Guyana, was ceded to Britain.

  


  


Post-Napoleonic Era (1815-1942)

  


  
  


# Belgian Revolution

## Background

The revolution had many causes; principally the treatment of the French-speaking Catholic Walloons in the Dutch-dominated United Kingdom of the Netherlands, and the difference of religion between the Belgians and their Dutch king. The King William I was a Calvinist. The Belgians had little influence over the economy and resented Dutch control. The Belgians also felt that they were under-represented Lower Assembly.

## The Riot

Catholic partisans watched with excitement the unfolding of the July Revolution in France, details of which were swiftly reported in the newspapers.On the night of August 25, 1830, following a performance of Daniel Auber's sentimental and patriotic opera La Muette de Portici. The crowd poured into the streets after the performance, shouting patriotic slogans, and swiftly took possession of government buildings.

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/90/Wappers_belgian_revolution.jpg/275px-Wappers_belgian_revolution.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The 10 Days Campaign

King William I attempted to restore the established order by force, but the royal army under Prince Frederick was unable to retake Brussels in bloody street fighting, September 23 to 26. The following day a provisional government was declared in Brussels September 26, 1830; a declaration of independence followed on October 4. In November a National Congress assembled in Brussels, and on February 7, 1831, the Belgian constitution was proclaimed. After Louis, Duke de Nemours had refused an offer of the Belgian crown, Erasme Louis Surlet de Chokier was appointed regent of Belgium on February 25, 1831. He served as regent until Leopold I took the oath as King of the Belgians on July 21, 1831.

## The Ten Days Campaign

In the morning of August 2, 1831, the Dutch crossed the "border" near Poppel. The Belgian scouts had noticed the troops and a number of roads were blocked by cutting the trees around them. Within the first two days the Dutch Army has retaken Nieuwenkerk, Zondereigen, Ravels and Turnhout. On August 4 Dutch troops took Antwerp, and the Brabantic flag was taken down and the Dutch flag was hoisted. The Prince of Orange however demanded that the flag be taken down again, because it would symbolise occupation rather than a restoration of the Dutch power.

During this time the Dutch army continued its advance, capturing the cities of Geel, Diest, Boutersem, Hasselt, and Leuven. It appeared for the Belgians that the revolt was over and they would fall back under Dutch control, however they asked for help from the French on August 9th, and on the next day French troops crossed the border. With Russia being unable to give help,(they were busy surprssing the Polish Revolution) the Dutch were forced to agree to a ceasfire on August 12th. The last Dutch troops returned to the Netherlands around August 20th although Antwerp would remain occupied until 1832.

## European Reaction

The European Powers were divided over the Belgian cry for independence. France supported Belgian Independence, while Russia, Prussia, Austria, and Great Britain all supported the Dutch. However, in the end, none of the European powers sent troops to aid the Dutch government, partly because of rebellions within some of their own borders.

## Independence

On December 20, 1830, the European powers recognized Belgium's de facto independence from the Kingdom of the Netherlands. It was not until April 19, 1839 however, that the Treaty of London signed by the European powers (including the Netherlands) recognized Belgium as an independent and neutral country comprising West Flanders, East Flanders, Brabant, Antwerp, Hainaut, Namur, and Liège, as well as half of Luxembourg and Limburg. The Dutch held onto Maastricht, and Limburg with its large coalfields.

  


  


# Expansion in the East Indies

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Evolution_of_the_Dutch_East_Indies.png/300px-Evolution_of_the_Dutch_East_Indies.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Dutch Expansion in the East Indies

## VOC Conquests

By 1669, the VOC was the richest private company the world had ever seen, with over 150 merchant ships, 40 warships, 50,000 employees, a private army of 10,000 soldiers, and a dividend payment of 40% on the original investment.

The VOC was temporarily forced to halt trade in Europe during the Third Anglo-Dutch War, and this resulted in the spike in the price of pepper, and the shares of the VOC dropped. During the later 1600's the VOC gained monopolies over the sugar, rice, opium trade in the East Indies. The VOC was able to control trade on the island of Celebes (present day Sulawesi). Around 1720, the VOC began to decline, and would never again be as powerful as they were in the 1600's.

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Flag_of_the_Dutch_East_Indies_Company.svg/250px-Flag_of_the_Dutch_East_Indies_Company.svg.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The VOC flag

During the early 1700's the VOC fought three wars of Javanese Succession. The first one resulted in the Dutch being allowed by the Sultan of Mataram to build forts anywhere on the Island of Java. The Second War of Javanese Succession resulted in further concessions on Java to the Dutch. The Third, and most decisive war, resulted in the Northern Coast of Java being put under control by the VOC, and Mataram was divided into different kingdoms. Banten, meanwhile, had become a territory of the VOC in 1753. During the end of the 1700's the VOC was able to establish control over a few small parts of Celebes.

## Agreement With Britain

The bankrupt Dutch East India Company was liquidated on 1 January 1800, and its territorial possessions were nationalised as the Dutch East Indies. Anglo-Dutch rivalry in Southeast Asia continued to fester over the port of Singapore, which had been ceded to the British East India Company in 1819 by the sultan of Johore. The Dutch claimed that a treaty signed with the sultan's predecessor the year earlier had granted them control of the region. However, the impossibility of removing the British from Singapore, which was becoming an increasingly important centre of trade, became apparent to the Dutch, and the disagreement was resolved with the Anglo-Dutch Treaty of 1824. Under its terms, the Netherlands ceded Malacca and their bases in India to the British, and recognised the British claim to Singapore. In return, the British handed over Bencoolen, all of its property on Sumatra and agreed not to sign treaties with rulers in the "islands south of the Straits of Singapore". Thus the archipelago was divided into two spheres of influence: a British one, on the Malay Peninsula, and a Dutch one in the East Indies.

## Java

By 1800 all of Java was under Dutch rule excluding two Dutch vassal states. During the VOC period, the Dutch depended on the cooperation of the Javanese aristocratic class, which allowed them to rule indirectly. After the brief British rule, the Dutch came back and many Javanese found that they were in debt.

In 1825 tensions broke out, Pangeran Diponegoro had started the revolt in 1825 after the Dutch decision to build a road across a sacred tomb. The troops of Diponegoro were very successful in the beginning, controlling the middle of Java and besieging Yogyakarta. Furthermore the Javanese population was supportive of Diponegoro's cause, whereas the Dutch colonial authorities were initially very indecisive. However, as the Java war prolonged, Diponegoro had difficulties in maintaining the numbers of his troops, and Dutch colonial army was able to fill its ranks with troops from Celebes and later on with troops from the Netherlands. The Dutch commander, General De Kock, was able to end the siege of Yogyakarta on September 25, 1825. In 1827 a guerrilla war began after the Dutch had gained the upperhand.

In 1830 the Dutch invited Diponegoro to come and negotiate, but he was arrested during the meeting, and later exiled. After his exile, the rebellion fell apart. It is estimated 8,000 Dutch were killed, and possibly as many as 200,000 Javanese killed.

## Sumatra

Dutch expansion began first in Sumatra. By 1823, the eastern part of the island, including the important city of Palembang, was under Dutch control. In 1821 the Padri War broke out, and by the 1830's, western Sumatra had also fallen under Dutch control. Between the 1870s and the end of the century, colonial troops also defeated the fierce Batak ethnic group, living north of the Minangkabau.

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/57/Batavia_harbour_canal.jpg/250px-Batavia_harbour_canal.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Batavia, 1870

The Dutch colonial government declared war on Aceh on 26 March 1873. Aceh is located on the Northern part of Sumatra. An expedition under Major General Köhler was sent out in 1874, which was able to occupy most of the coastal areas of the country. The Sultan requested received military aid from Italy and the United Kingdom in Singapore, and the army was therefore rapidly modernized. Aceh soldiers managed to kill Köhler. A second expedition led by General Van Swieten managed to capture the kraton (sultan's palace): the Sultan had however been warned, and had escaped capture. Intermittent guerrilla warfare continued in the region for ten years, with many victims on both sides. Around 1880 the Dutch strategy changed, and rather than continuing the war, they now concentrated on defending areas they already controlled, which were mostly limited to the capital city (modern Banda Aceh), and the harbor town of Ulee Lheue.

In 1880 the Dutch declared the war as over, however, it broke out again in 1883. A British ship had crashed in Aceh, and the Sultan had used the sailors as hostages. Infuriated, the Dutch and British launched a joint invasion and forced the Sultan to had over the hostages. Open war was declared soon after.

The Dutch achevied little success over the next few years, and an attempt to ally with a local failed. During the early 1890's the Dutch managed to gather valuable information from the Aceh government after Dr Snouck Hurgronje of the University of Leiden, then the leading Dutch expert on Islam, gained the trust of many Aceh leaders. He turned his information over to the Dutch.

In 1898 Major J.B. van Heutsz, was proclaimed governor of Aceh, and with his lieutenant, later Dutch Prime Minister Hendrikus Colijn, would finally conquer most of Aceh. In an attempt to crush remaining resistance, a few villages were burned and about 3,000 Acehnese were killed. By 1904 Aceh was under Dutch control(although a limited guerrilla resistance remained), and had an indigenous government that cooperated with the colonial state. Estimated total casualties on the Aceh side range from 50,000 to 100,000 dead, and over a million wounded.

## Celebes

At the time of the end of the VOC, only a small part of Celebes, mostly the coasts, were under Dutch rule. The Dutch gradually expanded into the island, by means of treaties and wars, and by the late 1800s only the two states of Bone, and Gowa were still independent. Both states were largely dominated by the Dutch. In 1905 Bone lost its independence, and in 1911 the same happened with Gowa.

## Borneo

Although the VOC had controlled the trade of Borneo for some time, they did not have any control over the island itself. Dutch influence was established on the west coast in the early 1800s. During the early to mid 1800's the Dutch conquered the Malay city-states on the south coast of Borneo. The Dutch called their new colony Kalimantan, from a native word that means "River of Diamonds." In 1850, the Dutch launched an offensive into western Borneo. Over the next few decades the Dutch gradually pushed deeper into the huge island of Borneo. In 1905 the final borders were established with the British to separate North and South Borneo.

## New Guinea

In 1828 the Dutch formally claimed the west part of the island. The first establishment was in Merkusoord/Fort Du Bus, in 1828 and abandoned in 1836. The Netherlands established trading posts in the area after Britain and Germany recognised the Dutch claims in treaties of 1885 and 1895. The first permanent administrative posts, at Fakfak and Manokwari, were not set up until 1898.

In 1923, the Nieuw Guinea Beweging (New Guinea Movement) was created in the Netherlands by ultra right-wing supporters calling for Dutchmen to create a tropical Netherlands in Papua. This prewar movement without full government support was largely unsuccessful in its drive, but did coincide with the development of a plan for Eurasian settlement of the Dutch Indies to establish Dutch farms in northern West New Guinea.

## Smaller Islands

During this time, the lesser islands came under Dutch control. Islands, such as the Moluccas had been under Dutch control for centerius. Other islands such as Nias had resisted attempts by the Dutch to force them under their control. Nias would finally fall in 1863. It was not until 1908 that Bali, just off the east coast of Java, would fall. The island of Sumba would not fall until even a year later.

It was by this time that the Dutch East Indies would reach their greatest extent, stretching over 3,000 miles from Sumatra, to New Guinea.

  


  


# Suriname and the Caribbean

The Dutch West India company was abolished in 1791, and its colonies in Suriname and the Caribbean brought under the direct rule of the state. The economies of the Dutch colonies in the Caribbean had been based on the smuggling of goods and slaves into Spanish America, but with the end of the slave trade in 1814 and the independence of the new nations of South and Central America from Spain, profitability rapidly declined. Dutch traders moved en masse from the islands to the United States or Latin America, leaving behind a small populations with little income and which required subsidies from the Dutch government. The Antilles were combined under one administration with Suriname from 1828 to 1845. Slavery was not abolished in the Dutch Caribbean colonies until 1863, long after those of Britain and France, though by this time only 6,500 slaves remained. In Suriname, slave holders demanded compensation from the Dutch government for freeing slaves, whilst in Sint Maarten, abolition of slavery in the French half in 1848 led slaves in the Dutch half to take their own freedom. In Suriname, after the abolition of slavery, Chinese workers were encouraged to immigrate as indentured labourers, as were Javanese, between 1890 and 1939.

  


  


Decolonization (1942-1975)

  


  
  


# German Invasion of the Netherlands

## The Invasion

On the morning of May 10, 1940 the Dutch awoke to the sound of aircraft engines roaring in the sky. Nazi Germany had commenced operation Fall Gelb and attacked the Netherlands, Belgium, France and Luxembourg: in the case of the Low Countries without a declaration of war given before hostilities.

The Luftwaffe was guaranteed air superiority over the Netherlands. The Dutch Air Force, the Militaire Luchtvaartafdeling (ML), had a strength of 144 combat aircraft, half of which were destroyed within the first day of operations. The remainder was dispersed and accounted for only a handful of Luftwaffe aircraft shot down. In total the ML flew a mere 332 sorties losing 110 of its aircraft.

The German 18th Army secured all the strategically vital bridges in and toward Rotterdam, which penetrated Fortress Holland(The main area of Dutch defence) and bypassed the New Water Line from the south. However, an operation organised separately by the Luftwaffe to seize the Dutch seat of government, Battle for The Hague, ended in complete failure. The airfields surrounding the city (Ypenburg, Ockenburg, and Valkenburg) were taken with heavy casualties and transport aircraft losses, only to be lost that same day to counterattacks by the two Dutch reserve infantry divisions. The Dutch captured or killed 1,745 Fallschirmjäger, shipping 1,200 prisoners to England. The Luftwaffe's Transportgruppen also suffered heavily. Transporting the German paratroops had cost it 125 Ju 52 destroyed and 47 damaged, representing 50 percent of the fleet's strength. Most of these transports were destroyed on the ground, and some whilst trying to land under fire, as German forces had not properly secured the airfields and landing zones.

![](//upload.wikimedia.org/wikipedia/commons/2/2c/Netherlands-map1-en.gif)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The German Advance Day by Day

The French 7th Army failed to block German armoured reinforcements of the 9th Panzer Division; they reached Rotterdam on 13 May. That same day in the east the Dutch retreated from the Grebbe Line to the New Water Line, when a counter-offensive to contain a German breach had failed.

An attempt by the Germans to cross the Afsluitdijk in the North, a thin dike that stretches from Friesland to North-Holland, failed. The German troops were unable to pass the Dutch fortifications and had to withdraw to their original positions.

The Dutch Army, still largely intact, surrendered in the evening of 15 May after the Bombing of Rotterdam by Heinkel He 111s of Kampfgeschwader 54 on the 14th killing about 900 civilians, and threats to do the same to other major Dutch Cities. They considered their strategic situation to have become hopeless and feared a further destruction of the major Dutch cities. However, the Dutch troops in Zealand and the colonies continued the fight while Queen Wilhelmina established a government-in-exile in Britain.

  


  


# Japanese Invasion

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/15/Dutch_Empire_preWWII.PNG/350px-Dutch_Empire_preWWII.PNG)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Dutch Empire prior to WWII

Dutch, Australian, British and United States forces fought the Japanese during the Dutch East Indies campaign. From January 1, 1942, Allied forces in South East Asia formed the American-British-Dutch-Australian Command (ABDACOM), under the British General Archibald Wavell. ABDACOM's control of the "Malay Barrier" (also known as the "East Indies Barrier") was considered vital to the Allies' global strategy. However, Japanese advances over the next several weeks split the Allied forces, and ABDACOM was dissolved on February 25. Allied operations in Indonesia (except Sumatra) were later controlled by the South West Pacific Area command, under General Douglas MacArthur.

## Borneo

In 1941, Borneo was divided between the Dutch East Indies and British crown colonies. The northern part was udner British control and the southern, and larger part, war under Dutch control.

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Pacific_War_-_Dutch_East_Indies_1941-42_-_Map.jpg/300px-Pacific_War_-_Dutch_East_Indies_1941-42_-_Map.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Japanese Invasion

On December 13, 1941 the invasion began, soon after the Japanese bombing of Peral Harbor. The lightly defended North Borneo was overrun by the Japanese in early January.

On December 22, the Japanese bombed the Dutch defences, and occupied their oil fields. The Dutch, and remaining British troops retreated into the Jungle covered mountains where they began a 10 week long Gurellia War campaign before surrendering in April of 1942. During January, on an island off of Boerno, 1,300 Dutch troops who had burned oil fields to prevent them from falling into Japanese hands, were all exuecuted, many of them were killed by samurais.

## Manado

On the island of Celebes (now known as Sulawesi),1,500 Dutch troops were attacked by a much larger force of Japanese on the Minahasa peninsula. The Japanese launched a combined air and ground attack, in an attempt to capture a strategic airfield. After two days of fighting, seeing that the battle was lost, the Dutch troops retreated inland and started a Gurillea War. By the end of February, most had been captured and many of them were executed.

## Ambon

On January 30 the Japanese launched an attack on the island of Ambon. The island was first bombed, and the invaded by sea. Within a day of the Japanese landings, the Dutch detachments in their vicinity were overrun and/or had withdrawn. On January 31, after the fall of Batugong, the Japanese surrounded the Dutch troops, and they were forced to surrender.

After dawn on February 2, the main Australian force on Nona plateau, commanded by Lieutenant Bill Jinkins, was in danger of encirclement. Jinkins ordered a withdrawal to Amahusu, where he became aware that the Dutch had surrendered. By the morning of February 3, the Australians around Eri were struggling to cope with increasing air and naval attacks, wounded Australians, the influx of Dutch personnel, diminishing supplies and widespread fatigue. Soon after it was agreed that they would surrender.

Allied casualties in the battle were relatively light. However, at intervals for a fortnight after the surrender, Imperial Japanese Navy personnel chose more than 300 Australian and Dutch prisoners of war at random and executed them. This was in revenge for the sinking of a Japanese Minesweeper.

## Palembang

On February 13 the Japanese launched an attack on Palembang, Sumatra. They dropped paratroopers over strategic airfields around the area. Although they failed to take the Airfield, they did manage to take the entire complex of an oil refinery, undamaged. The Allies launched a counter attack an retook the refinery, but with heavy casualties.

On the morning of February 13, a river boat commandeered by the British Royal Navy, HMS Li Wo — under Lieutenant Thomas Wilkinson — ferrying personnel and equipment between Singapore and the Dutch East Indies, ran into the Japanese fleet carrying the main invasion force. On February 15, an ABDA naval force of five cruisers, HNLMS De Ruyter, HNLMS Java and HNLMS Tromp, HMS Exeter, HMAS Hobart and 10 destroyers, under Admiral Karel Doorman, made an abortive attempt to intercept the Japanese force. Planes from Ryujo and land-based aircraft made a series of attacks on the Allied ships, forcing them to withdraw to the south of Sumatra.

As the Japanese landing force approached Sumatra. The remaining Allied aircraft attacked it, and the Japanese transport ship Otawa Maru was sunk. Hurricanes flew up the rivers, machine-gunning Japanese landing craft.

However, on the afternoon of February 15, it was ordered that all Allied aircraft were ordered to Java, where a major Japanese attack was anticipated, and the Allied air units had withdrawn from southern Sumatra by the evening of February 16, 1942. Other personnel were evacuated by ships to Java or India.

## Timor

During the night of February 19–February 20, the Imperial Japanese Army's 228th Regimental Group, under the command of Col. Sadashichi Doi, began landing in Timor. Portuguese Timor had been occupied by the Dutch in the previous year. During the night, Dutch and Australian troops managed to inflict heavy casualties onto the Japanese invaders, but failed to stop them. The Australian commandos withdrew south and east into the mountainous interior, and about 200 Dutch East Indies troops, headed southwest toward the border with Dutch Timor. It is believed that all but one of the POW's was exucuted.

On the same night, Allied forces in Netherlands Timor were under extremely intense air attacks. This caused the Australian Airforce to withdraw to Australia. The bombing was followed up by the landing of the main body of the Japanese invasion force, on the undefended southwest side of the island. Light tanks were landed to support the Japanese infantry, and the force advanced north, cutting off the Dutch positions in the west.

As the Dutch retreated, the destruction of an airfield was ordered, however, Japanese Paratroops were dropped onto the field. Despite killing most of the Japanese paratroopers, the Dutch surrendered due to the fact they were low on ammunition.

By the end of February, the Japanese controlled most of Netherlands Timor. However, many Australian and Dutch troops had withdrawn to the South part of the island and began a Guerrilla War. During August, Japanese forces began to burn and/or bomb villages believed to have assisted the Allies, with huge civilian casualties. During the summer of 1942 the Japanese launched an assault deeper into the island, and difficult campaign, forced the remaining allied troops to withdraw in February of 1943. By the end of the campaign, between 40,000-70,000 civilians of Timor had been killed.

## 1st Java Sea

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/de/Hr._Ms._De_Ruyter_%281936%29.jpg/250px-Hr._Ms._De_Ruyter_%281936%29.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Dutch Ship _De Ruyter_

In an attempt to stop the Japanese fleet, which was going to land at Java, the Dutch-American-British-Australian fleets set off to find the Japanese fleet. The fleets sighted each other on February 27. During the engagement, the allied ships _Kortenaer_ and _Electra_ were both sunk. Within two hours after engagement, the Allied Fleet broke off from battle covered by a smoke screen laid by 4 American destroyers. As they withdrew, the allied ships ran into mines, which sunk _Jupiter_ . During the night the two fleets encountered each other again, and the Dutch ships _De Ruyter_(named after Michiel de Ruyter) and _Java_ were sunk. During this time, the Dutch commander Karel Doorman was killed.

## Java

The Japanese troops landed at three points on Java shore on March 1, 1942. The West Java invasion convoy landed on Bantam Bay near Merak and Eretan Wetan. The West Java convoy had previously fought in the Battle of Sunda Strait, a few hours prior to the landings.

### West Java Campaign

On March 1, the invaders set up new headquarters at Serang. On March 2nd, a Japanese detachment was sent to cut off an allied escape route. The detachment arrived at Rangkasbitung and continued to Leuwiliang, 24 kilometres (15 mi) west of Buitenzorg. The Australian and American troops put up stiff resistance, destroying many Japanese trucks and tanks and holding up the Japanese for two days before being forced to withdraw.

Around the same time, two other detachments headed westwards to Madja (Maja) and Balaradja(Balaraja). They found many of the bridges already destroyed by the retreating Dutch and were forced to find other routes; some units took the opportunity to make for Buitenzorg.

On March 4, the Dutch commander decided to withdraw his forces from Batavia and Buitenzorg to reinforce the defence of Bandoeng. The following evening Dutch troops in Batavia surrendered. By dawn of March 6, the Japanese troops had attacked Buitenzorg, which was guarded by the KNIL(Royal Dutch East Indies Army). In the morning Buitenzorg was occupied, while a large number of Allied soldiers had retreated to Bandoeng. The Japanese continued to pursue the Dutch troops for the next 3 days, capturing Tjiandjoer and Tjimahi. On the same day Bandoeng was also occupied by the Japanese.

### East Java Campaign

The Japanese first landed on March 1,on Kragan, a small village in East Java. The Dutch forces who resisted the landing were quickly subdued.

The Japanese occupied Tjepoe on March 2 and occupied Bodjonegoro on March 3. The Japanese proceeded further and overwhelmed the Dutch defences at the Ngawi Regency, Tjaroeban, Ngandjoek, Kertosono, Kediri and Djombang.

At Porong, near Surabaya, Dutch and American troops gave fierce resistance to the incoming Japanese. Eventually the Allied troops under Major-General Gustav A. Ilgen had to retreat to the island of Madura upon the completion of demolition of the city's infrastructure. On the evening of March 9, Major-General Ilgen, commander of the KNIL in East Java, signed the instrument of surrender.

The Japanese moved southward with main objective to occupy Tjilatjap in order to capture the harbour and block the retreat to Australia. In one week, they advanced rapidly and overcame all Dutch army defence found in Blora, Soerakarta, Bojolali, Jogjakarta, Magelang, Salatiga, Ambarawa and Poerworedjo. Also during this time the invades captured Keboemen and Purwokerto.

## Dutch Surrender

By March 7, defeat was inevitable, with Tjilatjap already in Japanese hands. Soerabaja was being evacuated while Japanese troops were rapidly converging on Bandoeng from both the north and the west. At 09:00 on March 8 the Commander-in-Chief of the Allied forces, Ter Poorten, announced the surrender of the Royal Netherlands East Indies Army in Java.

The Dutch Governor, Jonkheer Dr. A.W.L. Tjarda Van Starkenborgh Stachouwer and Lieutenant-General Ter Poorten, together with Major-General Jacob J. Pesman, the commander of the Bandoeng District, met the Japanese Commander-in-Chief, Lieutenant-General Hitoshi Imamura at Kalidjati that afternoon and agreed to the capitulation of all the troops.

On March 12, 1942, the senior British, Australian and American commanders were summoned to Bandoeng where the formal instrument of surrender was signed in the presence of the Japanese commander in the Bandoeng area, Lieutenant-General Masao Maruyama, who promised them the rights of the Geneva Convention for the protection of prisoners of war.

## Aftermath

Initially Japanese occupation was welcomed by the Indonesians as liberators. During the occupation, the Indonesian nationalist movement increased in popularity. In July 1942, leading nationalists like Sukarno accepted Japan's offer to rally the public in support of the Japanese war effort. Both Sukarno and Mohammad Hatta were decorated by the Emperor of Japan in 1943.

During the occupation, the Japanese encouraged and backed Indonesian nationalistic feeling, created new Indonesian institutions and promoted nationalist leaders such as Sukarno. In the decades before the war, the Dutch had been overwhelmingly successful in suppressing the small nationalist movement in Indonesia such that the Japanese proved fundamental for the coming Indonesian independence.

  


  


# Indonesian Independence

## Initial Declaration

Two days after the Japanese surrender in August 1945, Sukarno and fellow nationalist leader, Mohammad Hatta, declared Indonesian independence. The Netherlands, only very recently freed from German occupation itself, initially lacked the means to respond, allowing Republican forces to establish de facto control over parts of the huge archipelago, particularly in Java and Sumatra. On the other hand, in the less densely populated outer islands, no effective control was established by either party, leading at times to chaotic conditions.

## British Military Action

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Soekarno.jpg/150px-Soekarno.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Sukarno, the leader of Indonesian Independence

Initially the United Kingdom sent in troops to take over from the Japanese and soon found itself in conflict with the fledgling government. British forces brought in a small Dutch military contingent which it termed the Netherlands Indies Civil Administration (NICA). When a member of the NICA raised a Dutch flag on a hotel in the country's second-largest city, Surabaya, Indonesian nationalists overran the Japanese proxies guarding the hotel and tore the blue stripe off the flag, forming the red-and-white Indonesian flag.

On November 10, 1945, Surabaya was attacked by British forces, leading to a bloody street-to-street battle. The battle for Surabaya was the bloodiest single engagement in the war and had successfully demonstrated the determination of the rag-tag nationalist forces. It also made the British reluctant to be sucked into a war it did not need, considering how outstretched their resources in southeast Asia were during the period after the Japanese surrender.

## Dutch Military action

As a consequence, the Dutch were asked to take back control, and the number of NICA forces soon increased dramatically. Initially the Netherlands negotiated with the Republic and came to an agreement at Linggarjati, in which the 'United States of Indonesia' were proclaimed, a semi-autonomous federal state keeping as its head the Queen of the Netherlands. Both sides increasingly accused each other of violating the agreement, and as consequence the hawkish forces soon won out on both sides. A major point of concern for the Dutch side was the fate of members of the Dutch minority in Indonesia, most of whom had been held under deplorable conditions in concentration camps by the Japanese. The Indonesians were accused (and guilty) of not cooperating in liberating these prisoners.

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/55/Nederlandsindie.png/300px-Nederlandsindie.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Situation in Indonesia/Dutch East Indies, 1949

The Netherlands government then mounted a large military force to regain what it believed was rightfully its territory. The two major military campaigns that followed were declared as ere 'police actions' to downplay the extent of the operations. There were atrocities and violations of human rights in many forms by both sides in the conflict. Some 6,000 Dutch and 150,000(including civilians) Indonesians are estimated to have been killed.

Although the Dutch and their indigenous allies managed to defeat the Republican Army in almost all major engagements and during the second campaign even to arrest Sukarno himself, Indonesian forces continued to wage a major guerrilla war under the leadership of General Sudirman who had escaped the Dutch onslaught. A few months before the second Dutch offensive, communist elements within the independence movement had staged a failed coup, known as Madiun Affair, with the goal of seizing control of the republican forces.

## Independence and Netherlands New Guinea

With the United States government threatening to withdraw the Marshall Plan funds, which were vital to the Dutch rebuild after the Second World War, the Netherlands government was forced back into negotiations, and after the Round Table conference in The Hague, the Dutch finally recognised Indonesian independence on December 27, 1949. At the time, other than most of Sumatra, and small parts of Java, all of Indonesia was under Dutch control. New Guinea was the only part of the East Indies not given up. Elections were held across Dutch New Guinea in 1959 and an elected New Guinea Council officially took office on April 5, 1961, to prepare for full independence by the end of that decade. The Dutch endorsed the council's selection of a new national anthem and the Morning Star as the new national flag on December 1, 1961.

Indonesia attempted to invade the region on December 18, 1961. Following some skirmishes between Indonesian and Dutch forces an agreement was reached and the territory was placed under United Nations administration in October 1962. It was subsequently transferred to Indonesia in May 1963. The territory was formally annexed by Indonesia in 1969.

  


  


# Suriname Independence

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/60/Flag_of_Suriname.svg/300px-Flag_of_Suriname.svg.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Flag of Suriname

In 1954, under the "_Statute of the Realm_", the Netherlands, Suriname and the Netherlands Antilles (at the time comprising Aruba) became a composite kingdom. The former colonies were granted autonomy save for certain matters including defense, foreign affairs and citizenship, which were the responsibility of the Realm. In 1969, unrest in Curaçao led to Dutch marines being sent to quell rioting. In 1973, negotiations started in Suriname for independence, and full independence was granted on November 25, 1975. Henk Arron became the first Prime Minister of Suriname. 60,000 immigrants took the opportunity of moving to the Netherlands because many feared Suriname could not survive as an independent country.

  


  


Legacy

  


  
  


# Language

“
Let us work toward greater cooperation with all Caribbean Countries, whether we speak English, Dutch, French or Spanish, whether we are independent or not, and whether we be island or continental territories.
”

—Said Musa

A small minority of Indonesians can speak a degree of Dutch. Many Indonesian lawyers and historians can speak Dutch due to historical ties, as do those of the older generation who were schooled in Dutch. Many Indonesian words have come from Dutch. One scholar argues that 20% of Indonesian words can be traced back to Dutch words.

The century and half of Dutch rule in Ceylon and southern India left few to no traces of the Dutch language. In Suriname, Dutch has left its mark as it is the official language of the country. About 60% of the population speaks it as their first language, and most of the remaining 40% know Dutch as well. In Aruba, Bonaire, and Curaçao, Dutch is the official language but spoken as a first language by only by seven to eight percent of the population, although most people on the islands can speak the language and the education system on these islands is in Dutch at some or all levels. The lingua franca of Aruba, Bonaire and Curaçao is Papiamento, a creole language that originally developed among the slave population of the islands. The population of the three northern Antilles, Sint Maarten, Saba, and Saint Eustatius, is predominantly English-speaking.

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Dutch_Language.png/300px-Dutch_Language.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Dutch language today.

In New Jersey in the United States, a dialect of Dutch, Jersey Dutch, spoken by descendants of seventeenth century Dutch settlers in Bergen and Passaic counties, was noted to still be spoken as late as 1921. Former American President Franklin Roosovelt said he remembered hearing Dutch spoken when he was growing up in the Hudson Valley.

Arguably, greatest linguistic legacy of the Netherlands was in its colony in South Africa, which attracted large numbers of Dutch farmer (in Dutch, Boer) settlers, who spoke a simplified form of Dutch called Afrikaans, which is largely mutually intelligible with Dutch. After the colony passed into British hands, the settlers spread into the hinterland, taking their language with them. Today, there are 10 million people for whom Afrikaans is either a primary and secondary language, compared with 25 million worldwide speakers of Dutch.

  


  


# Place Names

New York City was once called New Amsterdam. Parts of New York City are named after original Dutch colonial settlements: Brooklyn, after Breukelen, Harlem after Haarlem. Staten Island, was originally called Staten Eylandt after the Dutch parliament (Staten) who paid for the expeditions up the Hudson River. The place Old Town on Staten Island was originally called Oude Dorp, which in English means Old Town.

The last Director-General of the colony of New Netherland, Peter Stuyvesant, has given his name to a street, a neighborhood and a few schools in New York City. In Columbia County, near Albany, there is a town named Stuyvesant.

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/94/Stuyvesant_Wolvega_05c.JPG/250px-Stuyvesant_Wolvega_05c.JPG)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Monument of Peter Stuyvesant, it reads "Pieter Stuyvesant, Director General of New Netherland and Aruba"

The following towns in New York have names that were derived from Dutch: Claverack, Cobleskill, Greenbush (East and North), Kinderhook, Plattekill, Nassau, Poestenkill, Rensselaer, Saugerties, Valatie, Voorheesville, Watervliet, and Wynantskill.

Many towns and cities in Suriname share names with cities in the Netherlands, such as Alkmaar, and Groningen.

  


  


# Architecture

In the Surinamese Capital of Paramaribo, the Dutch Fort Zeelandia still stands today. In the centre of Malacca, Malaysia, the Stadhuys Building and Christ Church still stand. There are still some archaeological remains of Fort Goede Hoop (modern Hartford) and Fort Orange (modern Albany).

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Willemstad_harbor.jpg/299px-Willemstad_harbor.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Dutch styled houses in Willemstad

Dutch architecture is easy to see in Aruba, Curaco, and Bonaire. The Dutch style buildings are especially visible in Willemstad, with its steeply pitched gables, large windows and soaring finials.

  


  


Appendices

  


  


# Dutch Kings and Queens

Here are the Kings and Queens of the Netherlands, since the modern government was formed in 1815.

  Name Reign Notes

1
King William I
1815-1840
William I, born Willem Frederik Prins van Oranje-Nassau (The Hague, August 24, 1772 - Berlin, December 12, 1843), was the first King of the Netherlands. He succeeded his father as head of the House of Orange-Nassau in 1805, was named 'Sovereign Prince' of the Netherlands in 1813, proclaimed himself King in 1815, and abdicated in 1840. William I was also the Grand Duke of Luxembourg after 1815 and Duke of Limburg after 1839 until his abdication in 1840.

2
King William II
1840-1849
William II (William Frederick George Louis) (December 6, 1792 – March 17, 1849) was King of the Netherlands, Grand Duke of Luxembourg, and Duke of Limburg from October 7, 1840 until his death.

3
King William III
1849-1890
William III (Willem Alexander Paul Frederik Lodewijk van Oranje-Nassau) (February 19, 1817 – November 23, 1890) was from 1849 King of the Netherlands and Grand Duke of Luxembourg until his death and the Duke of Limburg until the abolition of the Duchy in 1866.

4
Queen Wilhelmina
1890-1948
Wilhelmina (Wilhelmina Helena Pauline Marie of Orange-Nassau; August 31, 1880 – November 28, 1962) was queen regnant of the Kingdom of the Netherlands from 1890 to 1948. She ruled the Netherlands for fifty-eight years, longer than any other Dutch monarch. Her reign saw many turning points in both Dutch and world history: World War I and World War II, the Great Crisis of 1933, as well as the decline of the Netherlands as a major colonial empire. Outside the Netherlands she is primarily remembered for her role in the Second World War, in which she proved to be a great inspiration to the Dutch resistance, as well as a prominent leader of the Dutch government in exile.

5
Queen Juliana
1948-1980
Juliana (Juliana Emma Louise Marie Wilhelmina van Oranje-Nassau; April 30, 1909 – March 20, 2004) was Queen regnant of the Kingdom of the Netherlands from her mother's abdication in 1948 to her own abdication in 1980.

6
Queen Beatrix
1980-2013
Beatrix (Beatrix Wilhelmina Armgard); born January 31, 1938) was the Queen regnant of the Kingdom of the Netherlands April 30, 1980 - April 30, 2013, when she abdicated.

  


  


# Stadtholders of Holland

This is a list of Stadtholders of Holland since Independence was declared in 1581.

  Name In Office Notes

1
William I of Orange
(1572)1581-1584
William I of Orange, also known as William the Silent, was the main leader of the Dutch revolt against the Spanish that set off the Eighty Years' War and resulted in the independence of the Dutch Republic. He was elected as Stadtholder in 1572, although Phillip II, the King of Spain, had appointed another one. William the Silent was assassinated in 1584. In the Netherlands, he is also known as the Vader des Vaderlands, "Father of the Fatherland", and the Dutch national anthem, Het Wilhelmus, is written in his honor.

2
Maurits of Nassau
1585-1625
Became stadtholder of Holland in 1585. He was appointed captain-general of the army in 1587. He led many campaigns that turned the tide of the revolt against Spain. Died in 1625.

3
Frederik Hendrik of Orange
1635-1647
Brother of Maurits of Nassau. Frederick Henry proved himself almost as good a general as his brother, and a far more capable statesman and politician. For twenty-two years he remained at the head of government in the United Provinces, and in his time the power of the stadtholderate reached its highest point. On Frederick Henry's death, he was buried with great pomp beside his father and brother at Delft.

4
William II Prince of Orange
1647-1650
Opposed acceptance of the Treaty of Münster, despite the fact that it recognized the independence of the Netherlands. Died from smallpox in 1650.

-
First Stadtholderless Period
1650-1672

5
William III of Orange
1672-1702
Became Stadtholder in 1672 after the murder of Johan de Witt. He lead the Dutch in the Franco-Dutch War. He invaded England in 1688 and became King. He served as Stadtholder and King until his death in 1702.

-
Second Stadtholderless Period
1702-1747

6
William IV of Orange
1747-1751
Was appointed Stadtholder after the French Army entered Flanders. He was very popular among the people, and served until his death in 1751.

7
William V of Orange
1751-1795
The last Stadtholder of the Dutch Republic. His reign was longer than any other Stadtholder of Holland. He became Stadtholder at age 3. He served at Stadtholder until 1795 when France invaded and conquured the country. In 1795 he fled to the safety of his former enemy, England. He died in exile at Brunswick, now in Germany in 1806.

  


  


# Governors-General of the Dutch East Indies

This is a list of the Governors-General of the Dutch east Indies. From 1610-1796 it was under control of the Dutch East India Company.

  Name In Office Notes

1
Pieter Both
1610-1614
First Governor-General of the East Indies, after relenquishing his position he drowned on his way back to the Netherlands.

2
Gerard Reynst
1614-1615
Died from dysentery

3
Laurens Reael
1615-1619
Reael resigned following a dispute with the VOC's leadership.

4 and 6
Jan Pieterszoon Coen
1619-1623, 1627-1629
Returned to the Netherlands in 1623, but was reapointed a few years later. He died in 1629.

5
Pieter de Carpentier
1623-1627
Left after being named head of the VOC. The Gulf of Carpentaria in northern Australia is named after him.

7
Jacques Specx
1629-1632

8
Hendrik Brouwer
1632-1636

9
Anthony van Diemen
1636-1645

10
Cornelis van der Lijn
1645-1650

11
Carel Reyniersz
1650-1653

12
Joan Maetsuycker
1653-1678

13
Rijkloff van Goens
1678-1681

14
Cornelis Speelman
1681-1684

15
Johannes Camphuys
1684-1691

16
Willem van Outhoorn
1691-1704

17
Joan van Hoorn
1704-1709

18
Abraham van Riebeeck
1709-1713
From 1709 until his death in 1713, he was the Governor-General of the Dutch East Indies. He was a keen explorer, who undertook several smaller and a few larger voyages in the Indies.

19
Christoffel van Swoll
1713-1718

20
Hendrick Zwaardecroon
1718-1725

21
Mattheus de Haan
1725-1729

22
Diederik Durven
1729-1732

23
Dirk van Cloon
1732-1735

24
Abraham Patras
1735-1737

25
Adriaan Valckenier
1737-1741

26
Johannes Thedens
1741-1743

27
Gustaaf Willem baron van Imhoff
1742-1750

28
Jacob Mossel
1750-1761

29
Petrus Albertus van der Parra
1761-1775

30
Jeremias van Riemsdijk
1775-1777

31
Reinier de Klerk
1777-1780

32
Willem Alting
1780-1796

33
Pieter Gerardus van Overstraten
1796-1801

34
Johannes Siberg
1801-1805

35
Albertus Wiese
1805-1808

36
Herman Willem Daendels
1808-1811

37
Jan Willem Janssens
1811

-
Under British rule
1811-1816

38
G.A.G.Ph. Baron van der Capellen
1816-1826

39
L.P.J. Burggraaf du Bus de Gisignies / Hendrik Merkus de Kock
1826-1830

40
Graaf van den Bosch
1830-1833

41
J.C. Baud
1833-1836

42
D.J. de Eerens
1836-1840

43
C.S.W. Graaf van Hogendorp
1840-1841

44
P. Merkus
1841-1844

45
jhr J.C. Reijnst
1844-1845

46
J.J. Rochussen
1845-1851

47
A.J. Duijmaer van Twist
1851-1856

48
C.F. Pahud
1856-1861

49
L.A.J.W. Baron Sloet van de Beele
1861-1866

50
P. Mijer
1866-1872

51
J. Loudon
1872-1875

52
J.W. van Lansberge
1875-1881

53
F. s'Jacob
1881-1883

54
O. van Rees
1883-1888

55
C. Pijnacker Hordijk
1888-1893

56
jhr. C.H.A. van Wijck
1893-1899

57
W. Rooseboom
1899-1904

58
Johannes Benedictus van Heutsz
1904-1909

59
A.F.W. Idenburg
1909-1916

60
J.P. Graaf van Limburg Stirum
1916-1921

61
D. Fock
1921-1926

62
jhr. A.C.D. de Graeff
1926-1931

63
jhr. B.C. de Jonge
1931-1936

64
Alidius Warmoldus Lambertus Tjarda van Starkenborgh Stachouwer
1936-1942
On September 16, 1936, he became Governor-General of the Netherlands East Indies. When the Netherlands surrendered to Germany on May 10, 1940, Jhr. van Starkenborgh declared martial law in the East Indies. He was taken prisoner by the Japanese after their conquest.

65
Hubertus Johannes van Mook
1942, 1945-1948

66
Louis Beel
1948-1949
Went on to become the Prime Minister of the Netherlands.

67
A.H.J. Lovink
1949

  


  


# Director-General of New Netherland

  Name In Office Notes

1
Cornelis Jacobszoon May
1624- 1625
May was the captain of the ship New Netherland who delivered the first boat load of colonists to New Netherland on Governors Island in June of 1624. Having transformed the New Netherland territory to a province, he was named the province's first director.

2
Willem Verhulst
1625-1626
Oversaw the decision to locate the company's main fortress and town on the tip of Manhattan Island in the colony of New Netherland.

3
Peter Minuit
1626-1632
Was the founder of the Swedish colony of New Sweden in 1638, and purchased the Island of Manhattan from the Canarsee Native Americans on May 24, 1626.

4
Sebastiaen Jansen Krol
1632-1633
Was commander of Fort Orange(present day Albany) previous to this post.

5
Wouter van Twiller
1633-1638
Twiller purchased 'Noten Eylant', later called Governors Island from a tribe of Native Americans.

6
Willem Kieft
1638-1647
Started a war with the Native Americans in 1643(which became known as Kiefts War), and was fired in 1647.

7
Peter Stuyvesant
1647-1664
Last, greatest, and most famous, Director-General. Expanded the size of New Netherland, settled disputes with Native Americans and the English, and ordered the construction of the protective wall on Wall Street, the canal that became Broad Street, and Broadway. He did not want to surrender the colony to the English in 1664, but under pressure from the Colonists and overwhelming odds, he was forced to. See, "place names" for places named after Stuyvesant.

8
Anthony Colve
1673-1674
Anthony Colve was commissioned as the Governor of New York when the Netherlands reclaimed New York City after nine years of British rule.

  


  


# Governors of Cape Colony

The Governors of Cape Colony. From 1651-1691 they were called Commanders.

  Name In Office Notes

1
Jan van Riebeeck
1652-1662
Was the founder of Cape Town, he was charged with building a fort, with improving the natural anchorage at Table Bay, planting fruit and vegetables and obtaining livestock from the indigenous Khoi people.

2
Zacharias Wagenaer
1662-1666

3
Cornelis van Quaelberg
1666-1668

4
Jacob Borghorst
1668-1670

5
Pieter Hackius
1670-1671

6
Albert van Breugel
1672

7
Isbrand Goske
1672-1676

8
Johan Bax dit van Herenthals
1676-1678

9
Hendrik Crudop
1678-1679

10
Simon van der Stel
1679-1699
He became Commander at the Cape in 1679. The following year the town of Stellenbosch was founded, and named after him. In 1691 he was promoted to Governor of the Cape. He retired in 1699

11
Willem Adriaan van der Stel
1699-1707
During his rule, van der Stel was viewed as corrupt and dictatorial. He spent much of the VOC money granted to him on his private estate. Fearing that the discontent might cause some burghers to become spies for the French, the VOC dismissed van der Stel, and ordered his return to the Netherlands

12
Johannes Cornelis d’Ableing
1707-1708

13
Louis van Assenburg
1708-1711

14
Willem Helot
1711-1714

15
Maurits Pasques de Chavonnes
1714-1724

16
Jan de la Fontaine
1724-1727

17
Pieter Gijsbert Noodt
1727-1729

18
Jan de la Fontaine
1729-1737

19
Adriaan van Kervel
1737
Died after 3 weeks in office.

20
Daniël van den Henghel
1737-1739

21
Hendrik Swellengrebel
1739-1751

22
Ryk Tulbagh
1751-1771
As a 16-year old, he enlisted with the VOC and in 1716 embarked on the ship Terhorst to South Africa. The town of Tulbagh was named after him.

23
Joachim van Plettenberg
1771-1785
The town of Plettenberg Bay was named after him in 1779.

24
Cornelis Jacob van de Graaff
1785-1791

25
Johannes Izaac Rhenius
1791-1792

26
Sebastiaan Cornelis Nederburgh and Simon Hendrik Frijkenius
1792-1792

27
Abraham Josias Sluysken
1793-1795

-
British Rule
1795-1803

28
Jacob Abraham Uitenhage de Mist
1803-1804

29
Jan Willem Janssens
1803-1806
Upon another war between Britain and France, Janssens attempted to strengthen the defenses of the colony, but found resources lacking, having few trained troops at his disposal and the political situation tenuous at best. During this time, he was promoted to Lieutenant-General. Janssens was under no impression that he had the ability to defeat the British force, led by Lieutenant-General Sir David Baird, yet he mobilized his forces and engaged the British on January 8, 1806, at the Battle of Blaauwberg, near Cape Town. His force was defeated and he was forced to surrender Cape Colony to the British, this time permanently.

  


  


# Authors

Original Author-[Red4tribe](/wiki/User:Red4tribe)

## Looking to Expand

I am looking to expand the following sections-

Batavian Republic  
Kingdom of Holland  
Surinamese Independence  


If you have any useful information at all, either contact me or feel free to add it into the article yourself. Also, if you wish to add your name to this list, you may, and become a full-time contributor to this book.

  


  


# Glossary

Contents:
Top \- 0–9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z

## A

[Amsterdam](//en.wikipedia.org/wiki/Amsterdam)-One of the two Dutch Capitals(the other is The Hague), was one of the main centers of trade during the 16th, 17th and 18th cetneries.  
  
[Anglo-Dutch Wars](//en.wikipedia.org/wiki/Anglo-Dutch_Wars)-Four wars between England and the Dutch Republic over trade in the Baltic and the Atlantic.  
  
[Aruba](//en.wikipedia.org/wiki/Aruba)-An island in the Caribbean that has been a Dutch possession since 1634, and is currently part of the Kingdom of the Netherlands.

## B

[Batavia](//en.wikipedia.org/wiki/Batavia)-A city that was conquered in 1619, and renamed Batavia by the Dutch. It was the center of the Dutch possessions in the East Indies until Indonesian independence 1949.  
  
[Battle of the Downs](//en.wikipedia.org/wiki/Battle_of_the_Downs)-Battle during the Dutch Revolt in 1639, that permanently crippled the Spanish Navy.  
  
[Battle of Waterloo](//en.wikipedia.org/wiki/Battle_of_Waterloo)-Battle against Napoleon led France, in which the Dutch Troops were led by William II.  
  
[Berbice](//en.wikipedia.org/wiki/Berbice)-A former colony that is today Guyana. It was under Dutch rule from 1627-1712, 1713-1781, 1784-1796 and 1802-1803. It was formally ceded in 1814, to the British.  
  
[Borneo](//en.wikipedia.org/wiki/Borneo)-The third largest island in the world, located in present-day Indonesia. The Dutch ruled the southern and middle parts of the island, while the British ruled to Northern.

## C

[Cape Colony](//en.wikipedia.org/wiki/Cape_Colony)-A Dutch settlement in present-day South Africa, on the Cape of Good Hope. The first settlement was in 1652, and it would remain under Dutch control until 1795, and from 1803-1806.

## D

[Deshima](//en.wikipedia.org/wiki/Deshima)-A Dutch trading post in the bay of Nagasaki on an artificial island, and the only European trading post in Japan for 200 years.  
  
[Dutch Acadia](//en.wikipedia.org/wiki/Dutch_Acadie)-Area in Eastern Canada briefly occupied by the Dutch in 1674, but they continued to claim the colony until 1678.  
  
[Dutch East India Company](//en.wikipedia.org/wiki/Dutch_East_India_Company)-A Dutch company(also known as the VOC) that was established in 1602. It would start colonies in India, Indonesia, Formosa(Taiwan), South Africa and a number of other places. It was one of the most successful companies ever, but was dissolved in 1800.  
  
[Dutch East Indies](//en.wikipedia.org/wiki/Dutch_East_Indies)-The largest, and most important, Dutch possession in the Empire. It was held from 1602-1949, expanding over time. It was given independence in 1949, after a 4 year war, and is today known as Indonesia.  
  
[Dutch Guiana](//en.wikipedia.org/wiki/Dutch_Guiana)-Presently known as Suriname. Was taken from the English in 1667 following the Second Anglo-Dutch War, in exchange for New Netherland. Independence was granted in 1975.  
  
[Dutch West India Company](//en.wikipedia.org/wiki/Dutch_West_India_Company)-A Dutch company founded in 1621. It established colonies in the Atlantic region including New Netherland, Suriname and Berbice. IT was dissolved in 1791.

## E

## F

## G

## H

## I

## J

[Java](//en.wikipedia.org/wiki/Java_Island)-An island that was the center of the Dutch East Indies. It was the most valuable island in the East Indies as well.

## K

## L

## M

[Maarten Tromp](//en.wikipedia.org/wiki/Maarten_Tromp)-One of the most famous Dutch Naval Admiral in their history. He served during the end of the Revolt, and during the First Anglo-Dutch War.  
  
[Maurice of Nassau](//en.wikipedia.org/wiki/Maurice_of_Nassau,_Prince_of_Orange)-Son of William the Silent, led major campaigns, that were successful, against the Spanish during the revolt.  
  
[Michiel de Ruyter](//en.wikipedia.org/wiki/Michiel_de_Ruyter)-One of the most famous, and arguably the greatest, Dutch Naval Admiral in their history. Led the Dutch in the "Raid on the Medway" and was recently voted the 7th greatest Dutchman ever.

## N

[Netherlands Antilles](//en.wikipedia.org/wiki/Netherlands_Antilles)-A group of islands in the Caribbean that has been a possession of the Dutch since 1634 and is currently part of the Kingdom of the Netherlands.  
  
[Netherlands New Guinea](//en.wikipedia.org/wiki/Netherlands_New_Guinea)-A Dutch possession on the island of Guinea which remained under Dutch control until 1962, unlike the rest of the East Indies. It was passed to UN control in 1963 and handed over to Indonesia soon after.  
  
[New Amsterdam](//en.wikipedia.org/wiki/New_Amsterdam)-A city founded by Peter Minuit in 1626 on the southern tip of Manhattan Island. It is today New York City.  
  
[New Netherland](//en.wikipedia.org/wiki/New_Netherland)-The Dutch colony that occupied present day New York, New Jersey, and some of the surrounding states. It was first explored in 1609, and in 1624 the permanent settlement was founded. It was surrednered to the British in 1664.  
  
[New Orange](//en.wikipedia.org/wiki/New_Orange)-The name of the Dutch city in New York and New Jersey after they had re-taken New Netherland from the English from 1673-1674.

## O

## P

[Paramaribo](//en.wikipedia.org/wiki/Paramaribo)-The capital and largest city of Suriname. It was established by the English, but taken by the Dutch after the 2nd Anglo-Dutch War.  
  
[Peter Stuyvesant](//en.wikipedia.org/wiki/Peter_Stuyvesant)-Last, greatest, and most famous, Director-General of New Netherland. Expanded the size of the colony, in numbers and territory.

## Q

## R

[Raid on the Medway](//en.wikipedia.org/wiki/Raid_on_the_Medway)-A battle during the Second Anglo-Dutch war in which the Dutch crippled the English fleet and forced them to sure for peace.

## S

[Sumatra](//en.wikipedia.org/wiki/Sumatra)-The largest island entirely in Indonesia. The Duch began to settle it in the late 1700's but the entire island was not under Dutch control until 1904.

## T

[The Hague](//en.wikipedia.org/wiki/The_Hague)-One of the two Dutch Capitals(the other is Amsterdam), and is currently the seat of Government.  
  
[West Timor](//en.wikipedia.org/wiki/West_Timor)-The west part of the island of Timor. It was originally controlled by the Portuguese but the Dutch ousted them in the 1600's.  
  
[Treaty of Munster](//en.wikipedia.org/wiki/Treaty_of_Munster)-A treaty signed in 1648, that ended the Thirty-years war and the Dutch Revolt. In it, Spain and the Holy Roman empire recognized Dutch independence.

## U

[Utrecht](//en.wikipedia.org/wiki/Utrecht)-City in the center of the Netherlands.

## V

## W

[William I](//en.wikipedia.org/wiki/William_I_of_the_Netherlands)-The first King of the Netherlands from 1815-1840, established the present day government of the Netherlands.  
  
[William II](//en.wikipedia.org/wiki/William_II_of_the_Netherlands)-The second King of the Netherlands, son of King William I. He began the transition towards democracy. Ruled form 1840-1849.  
  
[William III](//en.wikipedia.org/wiki/William_III_of_the_Netherlands)-The third King fo the Netherlands that ruled from 1849 to 1890.  
  
[William the Silent](//en.wikipedia.org/wiki/William_the_Silent)-Father of the Netherlands, led the starting stages of the Revolt against Spain, but was murdered in 1584.

## X

## Y

## Z

  


# Bibliography

  * Wedgwood, C.V. (1944). _William the Silent_. Weidenfeld & Nicolson History. 
  * Boxer, C.R. (1965). _The Dutch Seaborne Empire 1600-1800_. Hutchinson. 
  * Boxer, C.R. (1969). _The Portuguese Seaborne Empire 1415-1825_. Hutchinson. 
  * Davies, K.G. (1974). _The North Atlantic World in the Seventeenth Century_. University of Minnesota. 
  * Schama, Simon (1987). _The Embarrassment of Richies_. Vintage Books. 
  * McEvedy, Colin (1988). _The Penguin Historical Atlas of the North America_. Viking. 
  * McEvedy, Colin (1998). _The Penguin Historical Atlas of the Pacific_. Penguin. 
  * Ostler, Nicholas (2005). _Empires of the Word: A Language History of the World_. Harper Collins. 
  * Rogozinski, Jan (2000). _A Brief History of the Caribbean_. Plume. 
  * SarDesai, D.R. (1997). _Southeast Asia: Past and Present_. Westview. 
  * Scammel, G.V. (1989). _The First Imperial Age: European Overseas Expansion c. 1400-1715_. Routledge. 
  * Shipp, Steve (1997). _Macau, China: A Political History of the Portugese Colony's Transition to Chinese Rule_. McFarland. 
  * Taylor, Alan (2001). _American Colonies: The Settling of North America_. Penguin. 
  * Vickers, Adrian (2005). _A History of Modern Indonesia_. Cambridge University Press. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-521-54262-6](/wiki/Special:BookSources/0-521-54262-6). 
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Dutch_Empire/Print_Version&oldid=1716425](http://en.wikibooks.org/w/index.php?title=Dutch_Empire/Print_Version&oldid=1716425)" 

[Category](/wiki/Special:Categories): 

  * [Dutch Empire](/wiki/Category:Dutch_Empire)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Dutch+Empire%2FPrint+Version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Dutch+Empire%2FPrint+Version)

### Namespaces

  * [Book](/wiki/Dutch_Empire/Print_Version)
  * [Discussion](/wiki/Talk:Dutch_Empire/Print_Version)

### 

### Variants

### Views

  * [Read](/wiki/Dutch_Empire/Print_Version)
  * [Edit](/w/index.php?title=Dutch_Empire/Print_Version&action=edit)
  * [View history](/w/index.php?title=Dutch_Empire/Print_Version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Dutch_Empire/Print_Version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Dutch_Empire/Print_Version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Dutch_Empire/Print_Version&oldid=1716425)
  * [Page information](/w/index.php?title=Dutch_Empire/Print_Version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Dutch_Empire%2FPrint_Version&id=1716425)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Dutch+Empire%2FPrint+Version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Dutch+Empire%2FPrint+Version&oldid=1716425&writer=rl)
  * [Printable version](/w/index.php?title=Dutch_Empire/Print_Version&printable=yes)

  * This page was last modified on 8 February 2010, at 16:37.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Dutch_Empire/Print_Version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
