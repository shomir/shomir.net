# Wikijunior:Small Numbers/Print version

From Wikibooks, open books for an open world

< [Wikijunior:Small Numbers](/wiki/Wikijunior:Small_Numbers)

![Edits to this page require review.](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/doc-magnify.png)![This is a reviewed version of this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/2.png)This is the [latest reviewed version](/wiki/Wikibooks:REVIEW), [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Wikijunior:Small_Numbers/Print_version) on _10 January 2013_.(+)

 **Quality**: minimal  

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Wikijunior:Small Numbers](/wiki/Wikijunior:Small_Numbers)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Wikijunior:Small_Numbers/Print_version&action=purge&printable=yes) this page.

## Contents

  * 1 0
  * 2 1
  * 3 2
  * 4 3
  * 5 4
  * 6 5
  * 7 6
  * 8 7
  * 9 8
  * 10 9
  * 11 10

  


  


# 0

![Caligrafia do número 0 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Caligrafia_do_n%C3%BAmero_0_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_0_%28recorte%29.svg.png)

Some examples of the number 0

![Disc Plain red.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/13/Disc_Plain_red.svg/200px-Disc_Plain_red.svg.png)
A circle has _**zero**_ corners

![AD2009Aug07 Natrix natrix 01.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/4/43/AD2009Aug07_Natrix_natrix_01.jpg/200px-AD2009Aug07_Natrix_natrix_01.jpg)
A snake has _**zero**_ legs

0:00
When it's midnight, the time on a digital clock is twelve (or _**zero**_ depending on where you live) hours and _**zero**_ minutes

  


# 1

![Caligrafia do número 1 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Caligrafia_do_n%C3%BAmero_1_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_1_%28recorte%29.svg.png)

Some examples of the number 1

![Tongue.agr.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Tongue.agr.jpg/200px-Tongue.agr.jpg)
Humans have **one** tongue and **one** mouth.

![Mond-galileo-farbig.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Mond-galileo-farbig.jpg/200px-Mond-galileo-farbig.jpg)
Earth has **one** natural satellite: the moon.

![Couronne Louis XV.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Couronne_Louis_XV.jpg/200px-Couronne_Louis_XV.jpg)
Many rulers rule **one** country with **one** crown.

  


# 2

![Caligrafia do número 2 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/49/Caligrafia_do_n%C3%BAmero_2_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_2_%28recorte%29.svg.png)

Some examples of the number 2

![Rabbit small.JPG](//upload.wikimedia.org/wikipedia/commons/thumb/2/25/Rabbit_small.JPG/200px-Rabbit_small.JPG)
Rabbits have **two** ears.

![10 playing cards.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e4/10_playing_cards.jpg/200px-10_playing_cards.jpg)
Playing cards come in **two** colors (red and black).

![Mountainbike.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Mountainbike.jpg/200px-Mountainbike.jpg)
Bikes have **two** wheels.

  


# 3

![Caligrafia do número 3 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Caligrafia_do_n%C3%BAmero_3_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_3_%28recorte%29.svg.png)

Some examples of the number 3

![Velbon-dx-888.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Velbon-dx-888.jpg/200px-Velbon-dx-888.jpg)
Tripods that hold cameras have **three** legs.

![MP MTB Szczawno-Zdroj 2007 - kat. orlik.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/4/48/MP_MTB_Szczawno-Zdroj_2007_-_kat._orlik.jpg/200px-MP_MTB_Szczawno-Zdroj_2007_-_kat._orlik.jpg)
Sports have **three** champions most of the time.

![Manchas.png](//upload.wikimedia.org/wikipedia/commons/thumb/a/af/Manchas.png/200px-Manchas.png)
There are **three** primary colors.

  


# 4

![Caligrafia do número 4 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/99/Caligrafia_do_n%C3%BAmero_4_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_4_%28recorte%29.svg.png)

Some examples of the number 4

![Girafe Kenya.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/7/75/Girafe_Kenya.jpg/200px-Girafe_Kenya.jpg)
This giraffe has **four** legs, like many other large animals.

![Vinter i danmark.jpg](//upload.wikimedia.org/wikipedia/commons/6/6a/Vinter_i_danmark.jpg)
The year has **four** **seasons: winter, spring, summer, and autumn. Winter is the coldest of them all.**

![Simple compass rose.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/8d/Simple_compass_rose.svg/200px-Simple_compass_rose.svg.png)
There are **four** directions on a map: North, South, East, and West.

  


# 5

![Caligrafia do número 5 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Caligrafia_do_n%C3%BAmero_5_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_5_%28recorte%29.svg.png)

Some examples of the number 5

![Starfish.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Starfish.jpg/200px-Starfish.jpg)
A starfish has **five** arms.

![Noah's hand.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Noah%27s_hand.jpg/200px-Noah%27s_hand.jpg)
Each hand has **five** **fingers.**

![Olympic flag.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Olympic_flag.svg/200px-Olympic_flag.svg.png)
The Olympic flag is made of **five** circles.

  


# 6

![Caligrafia do número 6 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Caligrafia_do_n%C3%BAmero_6_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_6_%28recorte%29.svg.png)

Some examples of the number 6

![Kytara a ruka.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Kytara_a_ruka.jpg/200px-Kytara_a_ruka.jpg)
Classic guitar has **six** strings.

![Flag of Israel.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Flag_of_Israel.svg/200px-Flag_of_Israel.svg.png)
In the center of the flag of Israel there's a star with **six** **points.**

![Rhynchophorus ferrugineus.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Rhynchophorus_ferrugineus.jpg/200px-Rhynchophorus_ferrugineus.jpg)
All ants, bees, and flies have **six** legs. Such creatures are called "insects".

  


# 7

![Caligrafia do número 7 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/14/Caligrafia_do_n%C3%BAmero_7_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_7_%28recorte%29.svg.png)

Some examples of the number 7

![PianoDiagram.gif](//upload.wikimedia.org/wikipedia/commons/thumb/7/76/PianoDiagram.gif/200px-PianoDiagram.gif)
Do, re, mi, fa, sol, la, ti are the **seven** musical notes.

![WhereRainbowRises.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/2/27/WhereRainbowRises.jpg/200px-WhereRainbowRises.jpg)
The **seven** colors of the rainbow are: red, orange, yellow, green, blue, indigo, and violet.

![PSM V04 D306 Ursa major.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/PSM_V04_D306_Ursa_major.jpg/200px-PSM_V04_D306_Ursa_major.jpg)
The Big Dipper is an asterism of **seven** stars.

  


# 8

![Caligrafia do número 8 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Caligrafia_do_n%C3%BAmero_8_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_8_%28recorte%29.svg.png)

Some examples of the number 8

![Umbrella.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/06/Umbrella.png/200px-Umbrella.png)
An umbrella often has **eight** ribs.

![Octopus vulgaris 02.JPG](//upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Octopus_vulgaris_02.JPG/200px-Octopus_vulgaris_02.JPG)
The octopus has **eight** arms.

![Opening chess position from black side.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Opening_chess_position_from_black_side.jpg/200px-Opening_chess_position_from_black_side.jpg)  
![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)![Chess pawn.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Chess_pawn.png/25px-Chess_pawn.png)
In the game of chess, each player has **eight** pawns.

  


# 9

![Caligrafia do número 9 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/19/Caligrafia_do_n%C3%BAmero_9_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_9_%28recorte%29.svg.png)

Some examples of the number 9

![Expecting mother.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/3/30/Expecting_mother.jpg/200px-Expecting_mother.jpg)
Human pregnancy lasts for **nine** months.

![Beethoven.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Beethoven.jpg/200px-Beethoven.jpg)
One of the most famous compositions of Beethoven is his **Ninth** **Symphony.**

![Tic tac toe.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/32/Tic_tac_toe.svg/200px-Tic_tac_toe.svg.png)
In the game of tic-tac-toe, there are **nine** fields on the board.

  


# 10

![Caligrafia do número 10 \(recorte\).svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Caligrafia_do_n%C3%BAmero_10_%28recorte%29.svg/716px-Caligrafia_do_n%C3%BAmero_10_%28recorte%29.svg.png)

Some examples of the number 10

![Bowling-pins.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/9/92/Bowling-pins.jpg/200px-Bowling-pins.jpg)
In the game of bowling, the goal is to strike at once all the **ten** pins!

0123456789
It is possible to write any number, no matter how great, with only **ten** **types of digits.**

![Soft ruler.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Soft_ruler.jpg/200px-Soft_ruler.jpg)
A centimeter is divided into **ten** equal parts, called millimeters.

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Wikijunior:Small_Numbers/Print_version&oldid=2476003](http://en.wikibooks.org/w/index.php?title=Wikijunior:Small_Numbers/Print_version&oldid=2476003)" 

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3ASmall+Numbers%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3ASmall+Numbers%2FPrint+version)

### Namespaces

  * [Wikijunior](/wiki/Wikijunior:Small_Numbers/Print_version)
  * [Discussion](/w/index.php?title=Wikijunior_talk:Small_Numbers/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Wikijunior:Small_Numbers/Print_version)
  * [Edit](/w/index.php?title=Wikijunior:Small_Numbers/Print_version&action=edit)
  * [View history](/w/index.php?title=Wikijunior:Small_Numbers/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Wikijunior:Small_Numbers/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Wikijunior:Small_Numbers/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Wikijunior:Small_Numbers/Print_version&oldid=2476003)
  * [Page information](/w/index.php?title=Wikijunior:Small_Numbers/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Wikijunior%3ASmall_Numbers%2FPrint_version&id=2476003)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Wikijunior%3ASmall+Numbers%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Wikijunior%3ASmall+Numbers%2FPrint+version&oldid=2476003&writer=rl)
  * [Printable version](/w/index.php?title=Wikijunior:Small_Numbers/Print_version&printable=yes)

  * This page was last modified on 10 January 2013, at 23:30.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Wikijunior:Small_Numbers/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
