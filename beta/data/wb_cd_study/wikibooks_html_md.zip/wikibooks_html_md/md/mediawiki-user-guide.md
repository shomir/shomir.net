# MediaWiki User Guide/Print version

From Wikibooks, open books for an open world

< [MediaWiki User Guide](/wiki/MediaWiki_User_Guide)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

This is a user guide to MediaWiki, the software that runs Wikipedia, Wikibooks andother Wikimedia projects. The book focuses on Mediawiki markup. Topics out of scope of the book include administration and development of Mediawiki.

## Contents

  * 1 Text Formatting
    * 1.1 HTML
    * 1.2 Source code
  * 2 Hyperlinks
    * 2.1 Internal hyperlinks
    * 2.2 External hyperlinks
    * 2.3 Redirecting
  * 3 Sections and Headings
    * 3.1 Start level: 2
    * 3.2 Maximum level: 6
    * 3.3 Spaces
    * 3.4 Table of contents
    * 3.5 Headings not in TOC
    * 3.6 Customizing TOC
    * 3.7 Editability of sections
  * 4 Lists
  * 5 Tables
  * 6 Images
    * 6.1 Placing images
    * 6.2 Galleries
    * 6.3 Uploading images
  * 7 Categories
    * 7.1 Linking
    * 7.2 Templates
  * 8 Templates
    * 8.1 Parameters
    * 8.2 Documentation
    * 8.3 Control structures
    * 8.4 Transcluding any page
    * 8.5 Substitution
  * 9 References
  * 10 Mathematics
    * 10.1 Examples
    * 10.2 Greek and symbols
  * 11 Namespaces
  * 12 Glossary
    * 12.1 C
    * 12.2 N
    * 12.3 P
    * 12.4 W

  


# Text Formatting

The following is an overview of text formatting available in Mediawiki:

Basic text formatting

Formatting Markup Note

Boldface
`'''text'''`

Italics
`''text''`

Boldface and italics
`'''''text'''''`

Boldface combined with wikilink
`'''[[text]]'''`
The reverse order of ticks and brackets does not work: `[['''text''']]`

Other text formatting such as underline or blockquote needs to be done using HTML tags, including U for underline, TT for typewriter text, S for strikethrough, SUB for lower index and SUP for upper index.

## HTML

Text formatting can also be done using HTML and CSS. Some of the most useful HTML elements are:

Most needed HTML markup

Task Markup Note

Preformatted text
`<pre> preformatted </pre>`
The effect in wiki differs from the one in HTML; in wiki, the text within the PRE element is treated as within NOWIKI element, leaving all the HTML and wiki markup uninterpreted.

Blockquote
`<blockquote>Longer passage.</blockquote>`

Comments
`<!-- comment -->`
Avoid nesting, such as <!-- <!-- comment --> \-->

Generic inline element
`<span style="TODO"></span>`
Can be styled arbitrarily using cascading style sheets - CSS.

Generic block element
`<div style="TODO"></div>`
Can be styled arbitrarily using cascading style sheets - CSS.

Some HTML elements are not allowed, such as A and IMG.

## Source code

Source code of various programming and markup languages can be formatted using <source> element, which leads to **colored syntax** of the code.

An example of wiki markup:
    
    
    <source lang="html4strict">
    <html>
      <body>
        <p>Hello <span style="font-weight: bold;">world</span>!
        </p>
      </body>
    </html>
    </source>
    

The rendering of that markup:
    
    
    <html>
      <body>
        <p>Hello <span style="font-weight: bold;">world</span>!
        </p>
      </body>
    </html>
    

  


# Hyperlinks

There are two types of hyperlinks in MediaWiki: internal, also called wikilinks, and external.

## Internal hyperlinks

Task Markup Note

Internal hyperlink
[[keyword]]

Internal hyperlink 2
[[keyword]]s

Internal hyperlink to a section
[[keyword#section_heading|link title]]

Internal hyperlink showing a different word
[[keyword|its appearance]]

Internal hyperlink with a tooltip
[[keyword|<span title="A tooltip">its appearance</span>]]

Internal hyperlink in bold
'''[[keyword]]'''

## External hyperlinks

Task Markup Note

External hyperlink
[URL_containing_no_spaces title of the URL]

## Redirecting

Readers and editors from different backgrounds search for the same topic under different titles, such as TODO. To avoid replication of similar content and confusion of editors and readers, the editors of a wiki website usually choose one topic title as the authorized one, under which the content is to be created, and let one or more alternative topic titles redirect to it.

To **let a page title redirect** to another one, create a page with the unauthorized (or minor) title, containing only the following text:
    
    
    #REDIRECT [[Authorized topic title]]
    

An alternative markup; notice the additional ":":
    
    
    #REDIRECT: [[Authorized topic title]]
    

If an unauthorized topic title has more possible target authorized topic titles, redirecting does not do. In that case, a **disambiguation page** can be created, such as:
    
    
    The term '''unauthorized term''' may refer to:
    * [[Authorized topic title 1]]
    * [[Authorized topic title 2]]
    

The exact wording depends on the kind of content of the wiki website.

  


# Sections and Headings

Headings are created using sequences of "=" characters, placed before the heading title and after the heading title, on the same line. The level of headings is determined by the number of "=" characters.

Examples:

Level Example

2.
==Plants==

3.
===Plants===

4.
====Plants====

## Start level: 2

Do not use headings of level 1, such as "=Title="; start with level 2 instead. The heading at level 1 is used for the title of the page.

## Maximum level: 6

The maximum level of a heading is 6, rendered using ======Heading L6======. Entering a heading with 7 equals-signs such as =======Heading L7======= results in the creation of a heading of the level 6, with one equal-sign becoming part of the text of the heading: "=Heading L7=".

## Spaces

Depending on the convention that users and editors adopt, there can be any number of spaces between the "=" characters and the title.

An example without spaces:
    
    
    ==Plants==
    

An example with spaces:
    
    
    == Plants ==
    

## Table of contents

By default, the titles of headings appear in the table of contents, shown at the top of the page. To prevent having a table of contents, put the "__NOTOC__" sequence of characters into the page. To force the presence of table of contents on a specific place of the page, use "__TOC__".

## Headings not in TOC

There is no simple way to make a heading not appear in the table of contents. For a complex way requiring the adjustment of the MediaWiki software, see [Meta:Help:Section](//meta.wikimedia.org/wiki/Help:Section).

## Customizing TOC

There are various ways how to customize the table of contents. For instance, to place it to the right, use:
    
    
    <div style="float:right; clear:both; margin-left:0.5em;">__TOC__</div>
    

## Editability of sections

By default, all sections are editable separately, without the need to see the complete text of the page.

To make all the sections on a page non-editable, place __NOEDITSECTION__ anywhere on the page.

There is no simple way to make a single section non-editable, AFAIK.

  


# Lists

Lists formatting:

Bullet lists:
    
    
    * a
    ** b
    ** c
    *** d
    

Numbered lists:
    
    
    # a
    ## b
    ## c
    ### d
    

Definition lists:
    
    
    ; defined term : definition
    ; defined term 2 : definition 2
    

Mixed lists:
    
    
     * a
     *# b
     *# c
    

Lists inside tables:
    
    
    {|
    ! Heading a
    ! Heading b
    |-
    |
    * a1
    * a2
    |
    |}
    

  


# Tables

Tables:
    
    
    {|
    |+ Caption of the table
    ! Heading 1
    ! Heading 2
    |-
    | Cell 1 in row 1
    | Cell 2 in row 1
    |-
    | Cell 1 in row 2
    | Cell 2 in row 2
    |}
    

Dense format:
    
    
    {|
    |+ Caption of the table
    ! Heading 1
    ! Heading 2
    |-
    | Cell 1 in row 1 || Cell 2 in row 1
    |-
    | Cell 1 in row 2 || Cell 2 in row 2
    |}
    

Lists in tables:
    
    
    {|
    ! Heading a
    ! Heading b
    |-
    |
    * a1
    * a2
    |
    |}
    

  


# Images

Mediawiki supports the use of images in various formats. In order to be used in a wiki, image first needs to be uploaded, to which we come later.

## Placing images

The following is an overview of placing images into pages, such images that have already been uploaded.

Placing of images

Task Markup Default Frame Note

Image
[[Image:image_name.png]]
No
The image is shown in its full size as found in the file.

Image with thumb
[[Image:image_name.png|thumb|A caption text of the image.]]
Yes
Thumbs are always scaled down so as not to exceed an upper limit on the size.

Image without thumb, with restricted size
[[Image:image_name.png|150px]]
No

**Location:**

  * 'right'
  * 'left'
  * 'center'
  * 'none'

## Galleries

Images can be put into a gallery as follows. Notice the absent "[[" and "]]" around the names of the image files.
    
    
    <gallery>
    Image:name_1.png
    Image:name_2.jpeg
    </gallery>
    

Images in galleris can be given captions, as follows.
    
    
    <gallery>
    Image:name_1.png | Caption 1.
    Image:name_2.jpeg | Caption 2.
    </gallery>
    

## Uploading images

![Clipboard](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Clipboard.svg/45px-Clipboard.svg.png)

**To do:**  
Create this section.

  


# Categories

Pages in wiki can be put into categories, by placing a category assignment anywhere in them. An example:
    
    
     [[Category:Birds]]
    

Categories have their own namespace "Category:", and are pages of sorts too. A category can be put into another category, so the categories can form a hierarchy or other structures.

A list of uncategorized pages can be shown by Mediawiki software.

There is no easy way to rename a category; all its pages need to be edited and the line of category assignment changed.

## Linking

A wikilink to a category needs to start with ":", such as
    
    
    See also [[:Category:Birds]]
    

Otherwise, the page is put into the category instead of linking to it, and the wikilink is not shown.

## Templates

Categories can be used in templates, just like in mainspace pages. However, when you put a category assignment into a template, all the pages using that template become a member of that category. That is sometimes the required effect, but it may be unwanted, for instance when you want to categorize the templates rather than the pages that use the templates. For that case, embrace the category assignment into <noinclude> tag, such as:
    
    
    <noinclude>
    [[Category:Maintenance templates]]
    </noinclude>
    

  


# Templates

Templates provide a means to repeat the same text on several pages. More advanced templates make use of parameters, and even of control structures as found in programming languages. That said, basic templates are quite easy to create, requiring no knowledge of programming.

Templates have their own "Template:" namespace.

To create a template called "header", edit the page "Template:header" and place the text to be repeated into that template.

To use the template in a page, type "{{header}}". What marks the use of the template are the "{" and "}" characters, also known as curly brackets.

To replace the name of the template with its contents directly in the source wikitext before the text is saved, use "{{subst:header}}".

## Parameters

Templates can have unnamed and named parameters. The unnamed parameters are automatically numbered.

To use an unnamed parameter inside a template, refer to it using {{{1}}}, {{{2}}}, and the like. Notice the _three_ curly brackets.

To use a named parameter inside a template, refer to it using the same curly brackets and the name, instead of a number, like {{{parameter_name}}}.

To pass a parameter to a template when you use it in a mainspace page:
    
    
    {{header|apple}}
    {{header|parameter=apple}}
    

To pass equality sign (=) in the value of an unnamed parameter, you need a workaround: use, for the parameter number one, {{template|1=text=with=equality=sign}}.

## Documentation

Templates that are to be used by many users are worth documenting. One option is to document them on their talk pages. Another is to document them in their main text, and surround the documentation with <noinclude> tag. A plus of placing the documentation to the talk page is that the wiki software does not need to parse the documentation when a user changes the template.

## Control structures

Control structures such as _if_ and _switch_ are available, if the [ParserFunctions](//www.mediawiki.org/wiki/Extension:ParserFunctions) extension of MediaWiki is installed.

Overview of control structures

Keyword Syntax Note

#SWITCH
    
    
    {{#switch: <comparison value>
     | <value1> = <result1>
     | <value2> = <result2>
     | ...
     | <valuen> = <resultn>
     | <default result>
    }}
    

#IF
    
    
    {{ #if: <condition string> | <code if true> }}
    {{ #if: <condition string> | <code if true>
                               | <code if false> }}
    

The condition string is considered true if it is non-empty and not consisting only of whitespace.

#IFEQ
    
    
    {{ #ifeq: <text 1> | <text 2> | <code if equal> }}
    {{ #ifeq: <text 1> | <text 2> | <code if equal>
                                  | <code if not equal> }}
    

#IFEXISTS
    
    
    {{ #ifexist: <page name> 
                 | <wikitext if page exists>
                 | <wikitext if page does not exist> }}
    

## Transcluding any page

Above, you have learned how to use a template, that is, to let MediaWiki replace the name of the template surrounded by curly brackets with the contents of the template. In similar fashion, you can _transclude_ any page, not just a template, by writing the following:
    
    
    {{:Pagename}}
    

This works for pages in the mainspace. To include any page in any namespace, use:
    
    
    {{Namespace:Pagename}}
    

The use of a template is in fact a special case of this use, just that, as you do not specify any namespace, the Template namespace is used as the default one.

This does not work with some namespaces, such as the Special and Category namespaces.

## Substitution

The method of using templates described in the preceding sections leads to an _inclusion_ of templates, meaning that the source text of the page contains the name of the template surrounded by curly bracket, not its content. There is however another use of templates, in which the content of the template is written directly into the wiki page before the page is saved. This use is called _substitution_ and is achieved as follows:
    
    
    {{subst:Template}}
    

In a more advanced use, it may be required that control structures such as #if that are present in the substituted template are substituted too, which would seem to be achieved using {{subst:#if ...}}. However, this would lead to a substitution at the time of saving the template, which is undersirable. A solution: {{<includeonly></includeonly>subst:#if ...}}.

  


# References

References can be used to cite sources.

To **refer to a source** in the middle of the text, follow this example:
    
    
    <ref name="Ref06">Reference text</ref>
    

or if a named reference has already been used before in the same page:
    
    
    <ref name="Ref06"/>
    

To **list all the sources referred** to in the text, after a second level heading titled "References":
    
    
    ==References==
    <references/>
    

  


# Mathematics

You can enter mathematical formulas into a wiki, using a `math` tag, such as:
    
    
    <math>\sqrt{2}</math>
    

The formulas are marked up in the TeX markup, the markup of a complex typesetting system specialized on mathematics.

Before you start writing formulas in this markup, you can consider writing the simpler ones in HTML and wiki markup, such as:

    _f_(x) = _b_ \+ _c_ / _d_

which is marked up as
    
    
     ''f''(x) = ''b'' + ''c'' / ''d''
    

## Examples

To get started, follow the examples below.

Examples of mathematical markup

No. Desired Effect Markup

1.
![\\alpha\\,\\!](//upload.wikimedia.org/math/4/b/c/4bc6c42bbabe567d1f2516326e52b775.png)
`<math>\alpha\,\\!</math>`

2.
![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png)
`<math>\sqrt{2}</math>`

3.
![\\sqrt{1-e^2}](//upload.wikimedia.org/math/e/6/1/e61a3eb61789c2f90eb8ae52a315d1e8.png)
`<math>\sqrt{1-e^2}</math>`

4.
![\\frac{2}{4}=0.5](//upload.wikimedia.org/math/4/6/d/46dc0b34e0ab4e944a437720a4431d6c.png)
`<math>\frac{2}{4}=0.5</math>`

5.
![\\sum_{k=1}^N k^2](//upload.wikimedia.org/math/3/1/8/3187b0dd4e53e474d81e26f775c1cdfa.png)
`<math>\sum_{k=1}^N k^2</math>`

6.
![\\int\\limits_{1}^{3}\\frac{e^3/x}{x^2}\\, dx](//upload.wikimedia.org/math/4/0/7/40764d04d428b630657f305cba34c985.png)
`<math>\int\limits_{1}^{3}\frac{e^3/x}{x^2}\, dx</math>`

7.
![\\begin{bmatrix}
  0      & \\cdots & 0      \\\\
  \\vdots & \\ddots & \\vdots \\\\ 
  0      & \\cdots & 0
\\end{bmatrix}](//upload.wikimedia.org/math/8/1/a/81a12a09ac84853e3d25323b8643c630.png)
    
    
    <math>\begin{bmatrix}
      0      & \cdots & 0      \\
      \vdots & \ddots & \vdots \\ 
      0      & \cdots & 0
    \end{bmatrix}</math>
    

8.
![\\begin{pmatrix}
  x & y \\\\
  z & v 
\\end{pmatrix}](//upload.wikimedia.org/math/4/4/4/444df88e616def4e275b4e920c7b872e.png)
    
    
    <math>\begin{pmatrix}
      x & y \\
      z & v 
    \end{pmatrix}</math>
    

## Greek and symbols

There is a way of marking up Greek characters and special symbols, as the following table shows.

Markup of Greek alphabet and some symbols

Desired Effect Markup

α β γ δ ε ζ  
η θ ι κ λ μ ν  
ξ ο π ρ σ ς  
τ υ φ χ ψ ω  
Γ Δ Θ Λ Ξ Π  
Σ Φ Ψ Ω
    
    
    &alpha; &beta; &gamma; &delta; &epsilon; &zeta;
    &eta; &theta; &iota; &kappa; &lambda; &mu; &nu;
    &xi; &omicron; &pi; &rho;  &sigma; &sigmaf;
    &tau; &upsilon; &phi; &chi; &psi; &omega;
    &Gamma; &Delta; &Theta; &Lambda; &Xi; &Pi;
    &Sigma; &Phi; &Psi; &Omega;
    

∫ ∑ ∏ √ − ± ∞  
≈ ∝ = ≡ ≠ ≤ ≥  
× · ÷ ∂ ′ ″  
∇ ‰ ° ∴ Ø ø  
∈ ∉ ∩ ∪ ⊂ ⊃ ⊆ ⊇  
¬ ∧ ∨ ∃ ∀  
⇒ ⇔ → ↔ ↑  
ℵ - – —
    
    
    &int; &sum; &prod; &radic; &minus; &plusmn; &infin;
    &asymp; &prop; {{=}} &equiv; &ne; &le; &ge; 
    &times; &middot; &divide; &part; &prime; &Prime;
    &nabla; &permil; &deg; &there4; &oslash; &oslash;
    &isin; &notin; 
    &cap; &cup; &sub; &sup; &sube; &supe;
    &not; &and; &or; &exist; &forall; 
    &rArr; &hArr; &rarr; &harr; &uarr; 
    &alefsym; - &ndash; &mdash; 
    

  


# Namespaces

Namespace is the part of the name of the page before the first ":". The typical page has no ":" in its name, and is thus said to be in the _mainspace_.

Some namespaces--native ones--are automatically created by the MediaWiki software while others can be created by the administrators of the particular wiki site. The native namespaces include "Talk:", "User:", "Category:", "Template:", and others; they total 18 namespaces.

When searching the wiki, you can restrict the search to a particular namespace.

  


# Glossary

This is a glossary of the book.

Contents:
Top \- 0–9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z

## C

category 
    TODO

## N

namespace 
    The part of the name of the page before the first ":".

## P

piped link 
    An internal link or interwiki link where the link target and link label are both specified.

## W

wikilink 
    An internal link; a link pointing to another page of the same wiki or knowledge base, marked up using [[target word]], contrasting to links to other web sites.

wikitext 
    Text containing wiki markup, such as '''text''' for boldface.
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=MediaWiki_User_Guide/Print_version&oldid=1277911](http://en.wikibooks.org/w/index.php?title=MediaWiki_User_Guide/Print_version&oldid=1277911)" 

[Category](/wiki/Special:Categories): 

  * [MediaWiki User Guide](/wiki/Category:MediaWiki_User_Guide)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=MediaWiki+User+Guide%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=MediaWiki+User+Guide%2FPrint+version)

### Namespaces

  * [Book](/wiki/MediaWiki_User_Guide/Print_version)
  * [Discussion](/w/index.php?title=Talk:MediaWiki_User_Guide/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/MediaWiki_User_Guide/Print_version)
  * [Edit](/w/index.php?title=MediaWiki_User_Guide/Print_version&action=edit)
  * [View history](/w/index.php?title=MediaWiki_User_Guide/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/MediaWiki_User_Guide/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/MediaWiki_User_Guide/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=MediaWiki_User_Guide/Print_version&oldid=1277911)
  * [Page information](/w/index.php?title=MediaWiki_User_Guide/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=MediaWiki_User_Guide%2FPrint_version&id=1277911)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=MediaWiki+User+Guide%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=MediaWiki+User+Guide%2FPrint+version&oldid=1277911&writer=rl)
  * [Printable version](/w/index.php?title=MediaWiki_User_Guide/Print_version&printable=yes)

  * This page was last modified on 14 September 2008, at 17:58.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/MediaWiki_User_Guide/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
