# Geometry for Elementary School/Print version

From Wikibooks, open books for an open world

< [Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Geometry_for_Elementary_School/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Geometry_for_Elementary_School/Print_version) on _10 May 2010_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Geometry_for_Elementary_School/Print_version&oldid=1791249&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Geometry_for_Elementary_School/Print_version&action=purge&printable=yes) this page.

![Geom compass ruler.png](//upload.wikimedia.org/wikipedia/commons/thumb/3/32/Geom_compass_ruler.png/300px-Geom_compass_ruler.png)

  


Geometry for Elementary School

The current, editable version of this book is available in Wikibooks, the open-content textbooks collection, at  
<http://en.wikibooks.org/wiki/Geometry_for_Elementary_School>

Permission is granted to copy, distribute, and/or modify this document under the terms of the [Creative Commons Attribution-ShareAlike 3.0 License](/wiki/Wikibooks:Creative_Commons_Attribution-ShareAlike_3.0_Unported_License).

  


## Table of contents

![Geometry for elementary school cover.png](//upload.wikimedia.org/wikipedia/commons/d/da/Geometry_for_elementary_school_cover.png)

  


  * [Introduction](/wiki/Geometry_for_Elementary_School/Introduction) ![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
  * [Concepts](/wiki/Geometry_for_Elementary_School/Concepts)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    * [Points](/wiki/Geometry_for_Elementary_School/Points)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Lines](/wiki/Geometry_for_Elementary_School/Lines)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Angles](/wiki/Geometry_for_Elementary_School/Angles)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Plane shapes](/wiki/Geometry_for_Elementary_School/Plane_shapes)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Solids](/wiki/Geometry_for_Elementary_School/Solids)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Measurements](/wiki/Geometry_for_Elementary_School/Measurements)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Parallel lines](/wiki/Geometry_for_Elementary_School/Parallel_lines)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Symmetry](/wiki/Geometry_for_Elementary_School/Symmetry)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Transformation](/wiki/Geometry_for_Elementary_School/Transformation)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    * [Coordinates](/wiki/Geometry_for_Elementary_School/Coordinates)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
  * [Construction](/wiki/Geometry_for_Elementary_School/Construction)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    * [Our tools: Ruler and compasses](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compasses)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Constructing equilateral triangle](/wiki/Geometry_for_Elementary_School/Constructing_equilateral_triangle)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Copying a line segment](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Copying a triangle](/wiki/Geometry_for_Elementary_School/Copying_a_triangle)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Copying an angle](/wiki/Geometry_for_Elementary_School/Copying_an_angle)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Constructing a triangle](/wiki/Geometry_for_Elementary_School/Constructing_a_triangle)![50 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    * [Why the constructions are not correct?](/wiki/Geometry_for_Elementary_School/Why_the_constructions_are_not_correct%3F)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Bisecting an angle](/wiki/Geometry_for_Elementary_School/Bisecting_an_angle)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Bisecting a segment](/wiki/Geometry_for_Elementary_School/Bisecting_a_segment)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
  * [Congruence and similarity](/wiki/Geometry_for_Elementary_School/Congruence_and_similarity)![25 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
    * [Congruence](/wiki/Geometry_for_Elementary_School/Congruence)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    * [The Side-Side-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Side-Side_congruence_theorem)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    * [The Side-Angle-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Angle-Side_congruence_theorem)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    * [The Angle-Side-Angle congruence theorem](/wiki/Geometry_for_Elementary_School/The_Angle-Side-Angle_congruence_theorem)![50 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
    * [The Side-Angle-Angle congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Angle-Angle_congruence_theorem)![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
    * [The Right angle-Hypotenuse-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Right_angle-Hypotenuse-Side_congruence_theorem)![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
    * [Corresponding Parts of Congruent Triangles are Congruent (CPCTC)](/wiki/Geometry_for_Elementary_School/Corresponding_Parts_of_Congruent_Triangles_are_Congruent)![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
    * [Similarity](/wiki/Geometry_for_Elementary_School/Similarity)![75 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
  * [Extras](/wiki/Geometry_for_Elementary_School/Extras)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Some impossible constructions](/wiki/Geometry_for_Elementary_School/Some_impossible_constructions)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Pythagorean theorem](/wiki/Geometry_for_Elementary_School/Pythagorean_theorem)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [A proof of irrationality](/wiki/Geometry_for_Elementary_School/A_proof_of_irrationality)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    * [Fractals](/wiki/Geometry_for_Elementary_School/Fractals)![100 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
  * [What next?](/wiki/Geometry_for_Elementary_School/What_next%3F) ![25 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  * [Glossary](/wiki/Geometry_for_Elementary_School/Glossary)![0% developed](//upload.wikimedia.org/wikipedia/commons/thumb/d/d6/00%25.svg/9px-00%25.svg.png)
  * [Conventions](/wiki/Geometry_for_Elementary_School/Conventions)![50 percents developed](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)

  
  


# Introduction

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**Print version**
**[Concepts](/wiki/Geometry_for_Elementary_School/Concepts)**

## Why geometry?

Geometry is one of the most elegant fields in mathematics. It deals with visual shapes that we know from everyday life.

## Who should use this book?

This book is intended for use by a parent (or a teacher) and a child. It is recommended that the parent have some familiarity with geometry, but this is not necessary. The parent can simply read the chapter before teaching the child and then learn it together.

## Book guidelines

The classic book about geometry is [Euclid's _Elements_](//en.wikisource.org/wiki/The_Elements_of_Euclid). This book helped teach geometry for hundreds of years, so we feel that writing this book based on the Elements is a correct step.

We will adapt parts of the book for children and modify the order of some topics in order to make the book clearer.

The learning will be based on constructions and proofs. A construction is a method of creating a geometric object (such as a triangle) using a set of tools. In the case of this book, the tools we will be using are a compass and a ruler. A proof is a logical trail where we can prove one fact by starting with some given information and make a series of conclusions based on that information. Oftentimes it is more difficult to prove a result than to simply find the result.

The constructions are useful for letting the child experience geometric ideas and get visual results.

The proofs are a good way to understand geometry and are a good basis for future study of logic.

Since the book is for children, we omit some of the proof details and use intuition instead of precise definition. On the other hand, we insist on correct and elegant proofs. Precise definitions and exact proofs can be found in regular geometry books and can be used to extend to material to some of the children.

## Notation

The notation that is used in the book is defined the first time it is used. However, in order to simplify its use, it is also summarized in [the _notation_ section of the _conventions_ chapter](/wiki/Geometry_for_Elementary_School/Conventions#Notation) at the end of the book.

## How to contribute to this book

This book uses British English as a primary language; however, there is a table provided at the end of this book that summarises all the American terms that readers may come across.

## Before using this book

Make sure that these resources are available before using this book:

  * A protractor
  * A compass
  * A ruler
  * Graph paper
  * Single-lined paper

  


# Ruler and Compass

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Construction](/wiki/Geometry_for_Elementary_School/Construction)**
**Our Tools: Ruler and compasses**
**[Constructing equilateral triangle](/wiki/Geometry_for_Elementary_School/Constructing_equilateral_triangle)**

## Introduction

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/32/Geom_compass_ruler.png/300px-Geom_compass_ruler.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

This is a picture of a pair of compasses and a ruler.

## How to draw a line

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/22/Geom_draw_line.png/300px-Geom_draw_line.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Using a ruler (based on [Book I, Postulate 1](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/post1.html)), we can draw a segment of a straight line.

We will use the notation ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) for the line segment the starts at **A** and ends at **B**. Note that we don't care about the segment direction and therefore ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) is the same as ![\\overline{BA}](//upload.wikimedia.org/math/7/8/6/786006e8962400f9aa9f826fe2020a88.png).

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Geom_line_ab.png/300px-Geom_line_ab.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Line segment ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png)

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/73/Geom_line_ba.png/300px-Geom_line_ba.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Line segment ![\\overline{BA}](//upload.wikimedia.org/math/7/8/6/786006e8962400f9aa9f826fe2020a88.png)

## How to draw a circle

  * Using the compass (based on [Book I, Postulate 3](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/post3.html)).

We use the notation ![\\circ A,\\overline{AB} ](//upload.wikimedia.org/math/e/5/0/e5005e2d05d7febd05139c9302cd93c1.png) for the circle whose centre is the point **A** and its radius length equals that of the segment ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).

![Geom draw circle sequence.png](//upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Geom_draw_circle_sequence.png/300px-Geom_draw_circle_sequence.png)

Note that in other sources, such as [Euclid's Elements](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/defI15.html), a circle is described by any 3 points on its circumference, **ABC**.

The center-radius notation was chosen because of its suitability for constructing circles with a ruler and a compass.

  


# Points

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Concepts](/wiki/Geometry_for_Elementary_School/Concepts)**
**Points**
**[Lines](/wiki/Geometry_for_Elementary_School/Lines)**

A **point** is a dot that is so small that its height and width are actually zero! This may seem too small. So small that no such thing could ever really exist. But it does fit with our intuition about the world. Even though everything in the physical world around us of things larger than atoms, it is still very useful to talk about the centers of these atoms, or electrons. A point can be thought of as the limit of dots whose size is decreasing.

You might be surprised to know, but these are not points:

![Disc Plain black.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/27/Disc_Plain_black.svg/32px-Disc_Plain_black.svg.png)

The reason that this shape is not a point is that it is too large, it has area. This is a 'ball'.

![Disc Plain black.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/27/Disc_Plain_black.svg/16px-Disc_Plain_black.svg.png)

Even when taking a ball of half that size we don't get a point.

![Disc Plain black.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/27/Disc_Plain_black.svg/8px-Disc_Plain_black.svg.png)

And that is too large as well...

A point is so small that even if we divide the size of these dots by 100, 1,000 or 1,000,000 it would still be much larger than a point. A point is considered to be _infinitely small_. In order to get to the size of a point we should keep dividing the ball size by two – forever. Don't try it at home.

A point has no length, width, or depth. In fact, a point has no size at all. A point seems to be too small to be useful. Luckily, as we will see when discussing [lines](/wiki/Geometry_for_Elementary_School/Lines) we have plenty of them. It may be best to think of a point as a location, as in a location where two lines cross.

Why define a point as an infinitely small dot? For one thing it has a very precise location, not just the center of a rough dot, but the point itself. Another reason is that if the drawing is made much bigger or smaller the point stays the same size. A point which is an infinitely small dot would be too small to see, so we must use a big old visible normal dot, or where two lines cross to represent it and its approximate location on paper.

When we name a point, we always use an uppercase letter. Often we will use ![P](//upload.wikimedia.org/math/4/4/c/44c29edb103a2872f519ad0c9a0fdaaa.png) for "point" if we can, and if have more than one dot, we will work our way through the alphabet and use ![Q](//upload.wikimedia.org/math/f/0/9/f09564c9ca56850d4cd6b3319e541aee.png), ![R](//upload.wikimedia.org/math/e/1/e/e1e1d3d40573127e9ee0480caf1283d6.png), and so on. However, nowadays many people will start with any letter they like, although the ![P](//upload.wikimedia.org/math/4/4/c/44c29edb103a2872f519ad0c9a0fdaaa.png) still remains the best way.

If some points are on the same line, we call them 'colinear'. If they are on the same plane, they are 'coplanar'. Two points are always colinear. Two to three points are always coplanar. Of course this is tautological since the definition of a 'line' is 'two connected points', and the definition of a 'plane' is 'the surface specified by three points'.

  


# Lines

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Points](/wiki/Geometry_for_Elementary_School/Points)**
**Lines**
**[Angles](/wiki/Geometry_for_Elementary_School/Angles)**

## Lines

A line is as wide as a point, infinitely thin, having an infinite number of points, (in a straight row), extending forever in both the directions. Remember that this is impossible to be constructed in real life, so usually we would simply draw a line (with thickness!) with an arrow on both ends. Any two lines can intersect at only a single point. Lines that are on the same plane are 'coplanar'.

![Geom lines lines 01.png](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Geom_lines_lines_01.png/300px-Geom_lines_lines_01.png)

![Geom lines lines 02.png](//upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Geom_lines_lines_02.png/300px-Geom_lines_lines_02.png)

## Line segments

A line segment, or segment, is a part of a line, which has two endpoints. The endpoints give the line segment a fixed, or finite length.

![Geom lines seg 01.png](//upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Geom_lines_seg_01.png/300px-Geom_lines_seg_01.png)

![Geom lines seg 02.png](//upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Geom_lines_seg_02.png/300px-Geom_lines_seg_02.png)

Line segments AB, and CD, can be written as ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) , and ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png)

![Geom lines seg 03.png](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Geom_lines_seg_03.png/300px-Geom_lines_seg_03.png)

![Geom lines seg 04.png](//upload.wikimedia.org/wikipedia/commons/thumb/7/71/Geom_lines_seg_04.png/300px-Geom_lines_seg_04.png)

![Geom lines seg 05.png](//upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Geom_lines_seg_05.png/300px-Geom_lines_seg_05.png)

![Geom lines seg 06.png](//upload.wikimedia.org/wikipedia/commons/thumb/1/18/Geom_lines_seg_06.png/300px-Geom_lines_seg_06.png)

## Rays

A ray is a line segment that has only one endpoint. A ray is infinite in one direction. That means that it goes on forever in one direction. As they are impossible to construct in real life, usually we will just draw a line with an arrowhead on one end. They can be expressed as ![\\overrightarrow{A B}](//upload.wikimedia.org/math/9/d/8/9d873d9d5aca82f8439a25404dcc820a.png).

![Geom lines ray 02.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Geom_lines_ray_02.png/300px-Geom_lines_ray_02.png)

## Intersecting lines

Two lines **intersect** when they cross each other. They form vertically opposite angles, which we will learn later. The point where the lines intersect is called the point of intersection. If the angles produced are all right angles, the lines are called perpendicular lines. If two lines never intersect, they are called parallel lines. Parallel lines will be discussed in detail later.

## Axiom: there is only a single straight line between two points

Axiom: there is only a single straight line between two points.

![Geom lines axiom 1.png](//upload.wikimedia.org/wikipedia/commons/thumb/7/71/Geom_lines_axiom_1.png/300px-Geom_lines_axiom_1.png)

![Geom lines axiom 2.png](//upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Geom_lines_axiom_2.png/300px-Geom_lines_axiom_2.png)

  * show by halving that there are infinite number of points in a line
  * show that the number of points in a long line and a short line is equal

  


# Angles

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Lines](/wiki/Geometry_for_Elementary_School/Lines)**
**Angles**
**[Plane shapes](/wiki/Geometry_for_Elementary_School/Plane_shapes)**

![Elements title page.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Elements_title_page.jpg/50px-Elements_title_page.jpg)
The corresponding material in Euclid's elements can be found on [page 26 of Book I](//en.wikisource.org/wiki/Page:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu/26) in Issac Todhunter's 1872 translation, _[The Elements of Euclid for the Use of Schools and Colleges](//en.wikisource.org/wiki/Index:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu)_.

In this section, we will talk about angles.

## Angles

![Geom for elem angle.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/87/Geom_for_elem_angle.svg/300px-Geom_for_elem_angle.svg.png)

An angle (∠) is made up of a **vertex** (a point), two **arms** (rays), and an arc. They are arranged so that the endpoint of the arms are the same as the vertex, and the arc runs from one arm to another. The size of an angle depends on how big the arms are opened, and they are measured in degrees. You can measure them by putting your protractor on the vertex and looking at the degrees your second arm has reached.

An angle that is less than 90° is known as an acute angle. A 90° angle is known as a right angle. Those between 90° and 180° are obtuse angles. Exactly 180° angles are called straight angles. Those between 180° and 360° are reflex angles, while angles at 360° are round angles

An angle is usually named by the points it contains. The format is as follows:

> "∠" + _a point on one arm_ \+ _vertex_ \+ _a point on the other arm_

However, sometimes there are no angles on that vertex, and we can omit the point on the arms. In fact, when we are lazy, we can even use a lowercase letter to represent a certain angle. Note that in this case, ∠ must be omitted. Although the lowercase letter represents the value of the angle, all of these names can be used as unknowns in equations.

**Adjacent angles** (adj. ∠s) are angles where:

  1. Their opposite arms coincide (overlap);
  2. Their arcs do not coincide (overlap);
  3. Their vertices coincide (overlap).

Sometimes, two angles may add up to 90° or 180°. They are called complementary angles and supplementary angles respectively. As many angles have such properties, these will be quite handy in the future.

## Angles at a point

![Angles at a pt.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Angles_at_a_pt.svg/250px-Angles_at_a_pt.svg.png)

Sometimes, two or more angles share a common vertex, and their sizes add up to 360o. They are called angles at a point (∠s at a pt.). This can be very useful when we write proofs or find out angles.

For example, imagine that _O_ is a point in the figure. The three points, _A_, _B_, and _C_ are around the point _O_, and a ray shoots out of _O_ to _A_, _B_ and _C_ respectively. Given that ∠AOB = 120° and ∠BOC = 150°,

![\\begin{align}\\angle AOB + \\angle BOC + \\angle COA &= 360^\\circ \(\\angle s \\text{ at a pt.}\)\\\\
120^\\circ + 150^\\circ + \\angle COA &= 360^\\circ \\\\
\\angle COA&= 360^\\circ - 120^\\circ - 150^\\circ \\\\
&= 90^\\circ \\end{align}](//upload.wikimedia.org/math/d/6/5/d65db69a75ba9d5b68aff5a871d5b30f.png)

## Adjacent angles on a straight line

![Angle obtuse acute straight.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/ee/Angle_obtuse_acute_straight.svg/300px-Angle_obtuse_acute_straight.svg.png)

When the sizes of adjacent angles add up to 180°, they are adjacent angles on a straight line. They are used when finding out the value of one of the angles. (Or more, for that matter, when you have angles that are equal or related.) The abbreviation, adj. ∠s on st. line, can be used as a reference that the angles add up to 180°.

Look at the image on the right as an example. Here, _b_ and _a_ are supplementary. The sum of _b_ and _a_ is equal to _c_. _b_ and _a_ are adjacent angles on a straight line. If we know the value of _b_, we can find out the value of _a_ easily. Note that _a_, _b_, and _c_ are angles at a point.

## Vertically opposite angles

![Vertical Angles.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/13/Vertical_Angles.svg/150px-Vertical_Angles.svg.png)

Vertically opposite angles are very simple. If two straight lines run into each other, the opposite angles produced must be vertically opposite angles (vert. opp. ∠s). They must be equal to each other. Note that you cannot assume that something is a straight line just by observation, so be sure that it's mentioned in the question before you do anything. Vertically opposite angles is a very common reference and will come in handy in many situations, so before you are stuck on a problem, see if you can find some vertically opposite angles first.

Look at the figure on the right. As indicated in this figure, _D_ is equal to _C_ and _A_ is equal to _B_. This is because they are vertically opposite angles. Note that here, _D_ and _A_, _A_ and _C_, _C_ and _B_, and _D_ and _B_ are all pairs of adjacent angles on a straight line. Also, the four angles are angles at a point.

  


# Plane shapes

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Angles](/wiki/Geometry_for_Elementary_School/Angles)**
**Plane shapes**
**[Solids](/wiki/Geometry_for_Elementary_School/Solids)**

In this section, we will talk about plane figures, which are formed with coplanar (on the same plane) points joined together. When planes run into each other, the intersect. The line produced in between is called the line of intersection.

## Plane figures

Any shape that can be drawn in the plane is called a plane figure. A shape with only straight sides as edges is called a polygon(POL-ee-gone). Polygons must have at least three sides, thus the polygons with the fewest number of sides are triangles. Circles and semicircles are not polygons because they have curved sides.

When all the sides of a polygon are equal, it is equilateral (ee-quee-LAH-teh-roll). When all the angles of a polygon are equal, it is equiangular (ee-quee-ANG-ger-lah). When a polygon is both equilateral and equiangular, it is a regular shape. When doing mathematics problems, it is very important that an equilateral shape may not be equiangular (such as a rhombus), and an equiangular shape may not be equilateral (such as a rectangle). However, an equilateral triangle is always both (see below).

When dealing with plane figures, there are two measurements that are important to find: the area and the perimeter. The perimeter is the length around the shape while the area is the size of the shape. They can be calculated with different formulae.

## Triangles

![Elements title page.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Elements_title_page.jpg/50px-Elements_title_page.jpg)
The corresponding material in Euclid's elements can be found on [page 27 of Book I, Definition(s) 24-29](//en.wikisource.org/wiki/Page:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu/27) in Issac Todhunter's 1872 translation, _[The Elements of Euclid for the Use of Schools and Colleges](//en.wikisource.org/wiki/Index:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu)_.

A triangle is a shape with three sides. It can be classified according to its sides or angles, with three kinds each. Here they are:

  * **Equilateral triangles**, which are also **equiangular triangles**, have three sides equal and three angles equal. Their angles are always 60°.
  * **Isosceles triangles** are triangles in which two of the sides are equal. The non-included angles of the sides are also equal.
  * **Scalene triangles** have no equivalence in any way.
  * **Right triangles** are triangles with a right angle. The longest side of such triangles is called a hypotenuse.
  * **Obtuse triangles** are triangles with an obtuse angle.
  * **Acute triangles** are triangles with no right or obtuse angle.

It is interesting to note that the interior angles of triangles must add up to 180°. This is commonly used in proofs and other problems. Imagine a triangle whose points are marked A, B and C, angle A is 60 degrees, and angle B is 70 degrees:

![\\begin{align}\\angle BAC + \\angle ABC + \\angle ACB &= 180^\\circ \(\\angle \\text{ sum of } \\triangle\)\\\\
60^\\circ + 70^\\circ + \\angle ACB &= 180^\\circ \\\\
\\angle ACB&= 180^\\circ - 60^\\circ - 70^\\circ \\\\
&= 50^\\circ \\end{align}](//upload.wikimedia.org/math/9/e/6/9e6867e7c1d3d4e4c2061e060f70bc99.png)

  
Usually, when drawing a triangle, we draw one side horizontally. This side is usually called the **base**. There is nothing special about the base. By turning your paper you can make any side into the base. There is no mathematical reason to call one side a base; we do it to make talking about the triangle easier. When you have a triangle and think of one of the sides as the base, then there is one corner of the triangle that is not on the base and this point is the furthest point on the triangle from the base. The **height** of the triangle is the line that is perpendicular to the base and goes through that furthest point. Sometimes instead of being called the **height** it is called the **altitude** of the triangle. (So if your teacher calls it an altitude, don't worry, it's really the same thing.) The length of the base and the height are the only two numbers you need to know when calculating the area of any triangle. Just multiply base and height and divide by two (or multiply it by a half if you like.) and you have the area of the triangle!

The perimeter of the triangle is easy: just add up all the sides and voilà, you have the perimeter. You can multiply one side of an equilateral triangle by three as well. As for isosceles triangles, simply multiply one of the equal sides by two and add the shorter one. There we go.

## Quadrilaterals

A quadrilateral is a shape with four sides. You will spend a lot of time with these. They can be classified into many different categories:

  * **Parallelograms** are shapes where opposite sides and angles are equal. The opposite sides are parallel, hence the name. 
    * **Rectangles** are parallelograms where the angles are all 90°. Its width or breadth refers to the shorter sides, while its length refers to its longer ones.
    * **Rhombuses** are parallelograms where all the sides are equal, and opposite angles are equal.
    * **Squares** are parallelograms that are both rectangles and rhombuses, i.e. all angles are right and all sides are equal.
  * **Trapeziums**, called **trapezoids** in American English, have two opposite sides that are parallel. The parallel sides are sometimes called the upper and lower bases. 
    * **Right-angles trapeziums** are trapeziums with a right angle.
    * **Isosceles trapeziums** are trapeziums where the laterals sides are equal but not parallel.
    * **Scalene trapeziums** are trapeziums that fall into neither category.
  * **Kites** are quadrilaterals where two pairs of adjacent sides are equal and one pair of opposite angles is equal.
  * **Irregular quadrilaterals** are any quadrilaterals that do not fit into one of the groups above.

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Area_of_triangle.JPG/200px-Area_of_triangle.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

An example of how filling can be put to use.

Calculating the area of these shapes can be very easy. For parallelograms, simply multiply the base with the height, the way with do with triangles, except we don't need to divide by two. The square is especially easy: just square one of the sides, which would be the length. For the others, we can cut them up into bite-sized pieces before we calculate. For example, we can dissect the right-angled trapeziums into a right-angled triangle and a rectangle.

The perimeter of these shapes are just as easy. For rectangles, we simply add up the length and the width, then multiply by two. You can simply multiply the length of a square by four. The isosceles trapeziums are just as easy: multiply one of the lateral sides by two, then add it up with the other two. The kite is easy as well: Just add up the two different sides and multiply that by two. For the rest, you can just add up everything.

## Other polygons

Many other polygons have a name. The following are the ones you need to know in elementary school:

  * **Pentagons** have five sides.
  * **Hexagons** have six sides.
  * **Heptagons** or septagons have seven sides.
  * **Octagons** have eight sides.
  * **Nonagons** have nine sides.
  * **Decagons** have ten sides.

And here are two more extras:

  * **Hendecagons** (also known as **undecagons**) have eleven sides.
  * **Dodecagons** have twelve sides.

Calculating the perimeter and area of these shapes can be more difficult. Sometimes you have to come up with ways of doing it yourself. When you come across an equilateral polygon, you can of course multiply one of the sides by the number of sides of the shape. In other cases, you may need to find some dimensions yourself. Keep your eyes peeled for equivalences, and the problems cannot be that difficult.

When calculating the area of these shapes, there are two main ways of doing so: dissecting and filling. With dissecting, you cut up the figure into many pieces, such as parallelograms, squares and triangles. Then you can simply add up all those areas to find out the total. With filling, you add extra bits to shapes so as to make it look like the shapes you usually come across with. For example, when you don't known the altitude of a triangle, you can put three surrounding triangles around it. Then you can calculate the area of the rectangle formed and the surrounding triangles, thereby finding the area of the triangle.

## Circles and other plane figures

Apart from polygons, there are other shapes that have wavy sides, round corners or other peculiarities that disqualify them as polygons. Among them, the most famous are the circle, the ellipse, and the semicircle. These shapes are different from polygons, and have their special formulae that you must learn by heart. Let's start with the most basic: the circle.

![Elements title page.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Elements_title_page.jpg/50px-Elements_title_page.jpg)
The corresponding material in Euclid's elements can be found on [page 27 of Book I, Definition(s) 15-17](//en.wikisource.org/wiki/Page:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu/27) in Issac Todhunter's 1872 translation, _[The Elements of Euclid for the Use of Schools and Colleges](//en.wikisource.org/wiki/Index:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu)_.

Circles are shapes with infinite loci around its centre. Its perimeter is called the circumference. The line running from one side of the circle, through the centre and to the other side is called the diameter. The line running from the centre to any point on the circumference is called the radius. Any other line running from one point of the circumference to another is called a chord. An arc is any part of the circumference.

For thousands of years, mathematicians have been trying to find out the relationship between the circumference and the diameter. When we divide the circumference by the diameter, we get a number that is slightly larger than 3. That number is called π (spelt pi and pronounced pie). Supercomputers have discovered millions of digits of π, but you only need to remember that π is roughly 3.14 or 22/7. That is close enough. If you know the circumference of a circle, dividing that by π will result in the diameter; multiplying the diameter by π will result in the circumference. To find out the area of a circle, calculate πr2.

You don't really get to know much about ellipses and semicircles in elementary school. Ellipses look like ovals, except they have a stricter way of constructing that is more than a crushed circle. They have two 'centres' called foci. Semicircles are circles cut along the diameter, and if you draw a line from one end to a point on the circumference, then to another end, you always get a right angle. These two shapes are seldom taught in elementary school, and aside from knowing their names you don't need to study them.

  


# Constructing an Equilateral Triangle

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Our tools: Ruler and compasses](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compasses)**
**Constructing equilateral triangle**
**[Copying a line segment](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment)**

## Introduction

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Geom_constr_eqtr00.svg/300px-Geom_constr_eqtr00.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Equilateral triangle

In this chapter, we will show you how to draw an equilateral triangle. What does "equilateral" mean? It simply means that all three sides of the triangle are the same length.

Any triangle whose vertices (points) are **A**, **B** and **C** is written like this: ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png).

And if it's equilateral, it will look like the one in the picture.

  


## The construction

![Elements title page.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Elements_title_page.jpg/50px-Elements_title_page.jpg)
The corresponding material in Euclid's elements can be found on [page 31 of Book I, Proposition 1](//en.wikisource.org/wiki/Page:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu/31) in Issac Todhunter's 1872 translation, _[The Elements of Euclid for the Use of Schools and Colleges](//en.wikisource.org/wiki/Index:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu)_.

  1. Using your ruler, [Draw a line segment](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line.3F) whatever length you want the sides of your triangle to be.  
Call one end of the line segment **A** and the other end **B**.  
Now you have a line segment called ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).  
It should look something like the drawing below.  
![Geom constr eqtr01.svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/41/Geom_constr_eqtr01.svg/300px-Geom_constr_eqtr01.svg.png)
  2. Using your compass, [Draw the circle](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_circle.3F) ![\\circ A, ](//upload.wikimedia.org/math/0/a/5/0a54a96f384980845a72901d0bc83d98.png) whose center is **A** and radius is ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).  
![Geom constr eqtr02.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Geom_constr_eqtr02.svg/300px-Geom_constr_eqtr02.svg.png)
  3. Again using your compass [Draw the circle](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_circle.3F) ![\\circ B,\\overline{AB} ](//upload.wikimedia.org/math/4/8/8/48865f0eeb97263dda6ff669b89fad2d.png), whose center is **B** and radius is ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).  
![Geom constr eqtr03.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Geom_constr_eqtr03.svg/300px-Geom_constr_eqtr03.svg.png)
  4. Can you see how the circles intersect (cross over each other) at two points?  
The points are shown in red on the picture below.  
![Geom constr eqtr04.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Geom_constr_eqtr04.svg/300px-Geom_constr_eqtr04.svg.png)
  5. Choose one of these points and call it **C**.  
We chose the upper point, but you can choose the lower point if you like. If you choose the lower point, your triangle will look "upside-down", but it will still be an equilateral triangle.  
![Geom constr eqtr05.svg](//upload.wikimedia.org/wikipedia/commons/thumb/7/71/Geom_constr_eqtr05.svg/300px-Geom_constr_eqtr05.svg.png)
  6. [Draw a line segment](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line) between **A** and **C** and get line segment ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png).  
![Geom constr eqtr06.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Geom_constr_eqtr06.svg/300px-Geom_constr_eqtr06.svg.png)
  7. [Draw a line segment](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line) between **B** and **C** and get line segment ![\\overline{BC}](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png).  
![Geom constr eqtr07.svg](//upload.wikimedia.org/wikipedia/commons/thumb/8/88/Geom_constr_eqtr07.svg/300px-Geom_constr_eqtr07.svg.png)
  8. Construction of ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) is completed.

## Claim

The triangle ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) is an equilateral triangle.

## Proof

  1. The points **B** and **C** are both on the circumference of the circle ![\\circ A,\\overline{AB} ](//upload.wikimedia.org/math/e/5/0/e5005e2d05d7febd05139c9302cd93c1.png) and point **A** is at the center.  
![Geom eqtriangle proof01.svg](//upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Geom_eqtriangle_proof01.svg/300px-Geom_eqtriangle_proof01.svg.png)
  2. So the line segment ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) is the same length as the line segment ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png). Each is a radius of circle ![\\circ A](//upload.wikimedia.org/math/0/0/f/00f3e1f62e78a2ef93c2b86f0b37daf2.png), or more simply ![\\overline{AB}=\\overline{AC}](//upload.wikimedia.org/math/6/8/6/686c3693c8e065c3ad7df8a976b65aff.png). 

![Geom eqtr proof05b.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Geom_eqtr_proof05b.svg/300px-Geom_eqtr_proof05b.svg.png)

  3. We do the same for the other circle:  
The points **A** and **C** are both on the circumference of the circle ![\\circ B,\\overline{AB} ](//upload.wikimedia.org/math/4/8/8/48865f0eeb97263dda6ff669b89fad2d.png) and point **B** is at the center.  
![Geom eqtriangle proof06b.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a1/Geom_eqtriangle_proof06b.svg/300px-Geom_eqtriangle_proof06b.svg.png)  

  4. So we can say that ![\\overline{AB}=\\overline{BC}](//upload.wikimedia.org/math/0/9/5/09573765719524ef491a13c94007b559.png). 

![Geom eqtr proof09b.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Geom_eqtr_proof09b.svg/300px-Geom_eqtr_proof09b.svg.png)

  5. We've already shown that ![\\overline{AB}=\\overline{AC}](//upload.wikimedia.org/math/6/8/6/686c3693c8e065c3ad7df8a976b65aff.png) and ![\\overline{AB}=\\overline{BC}](//upload.wikimedia.org/math/0/9/5/09573765719524ef491a13c94007b559.png). Since ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) and ![\\overline{BC}](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png) are both equal in length to ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), they must also be equal in length to each other. This can be shown by substitution. So we can say ![\\overline{AC}=\\overline{BC}](//upload.wikimedia.org/math/b/9/3/b930676ac3fe55cdf93038e7f9b7abe5.png)

![Geom eqtr proof05b.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Geom_eqtr_proof05b.svg/300px-Geom_eqtr_proof05b.svg.png)

  6. Therefore, the line segments ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png), and ![\\overline{BC}](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png) are all equal. ![\\overline{AB}=\\overline{AC}=\\overline{BC}](//upload.wikimedia.org/math/e/3/3/e3324835bfb3d7d28c3b21ea7c1ef7bc.png)  
![Geom eqtr proof11.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Geom_eqtr_proof11.svg/300px-Geom_eqtr_proof11.svg.png)
  7. We proved that all sides of ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) are equal, so this triangle is an equilateral triangle by definition.

## Problems with the proof

The construction above is simple and elegant. One can imagine how children, using their legs as compass, accidentally find it.

However, Euclid’s proof was wrong.

In mathematical logic, we assume some postulates. We construct proofs by advancing step by step. A proof should be made only of postulates and claims that can be deduced from the postulates. Some useful claims are given names and called theorems in order to enable their use in future proofs.

There are some steps in its proof that cannot be deduced from the postulates. For example, according to the postulates he used, the circles ![\\circ A,\\overline{AB} ](//upload.wikimedia.org/math/e/5/0/e5005e2d05d7febd05139c9302cd93c1.png) and ![\\circ B,\\overline{AB} ](//upload.wikimedia.org/math/4/8/8/48865f0eeb97263dda6ff669b89fad2d.png) do not have to intersect.

Although the proof was wrong, the construction is not necessarily wrong. One can make the construction valid, by extending the set of postulates. Indeed, in later years, different sets of postulates were proposed in order to make the proof valid. Using these sets, the construction that works so well using pencil and paper is also logically sound.

This error of Euclid, the gifted mathematician, should serve as an excellent example of the difficulty in mathematical proof and also the difference between proof and our intuition.

  


# Copying a Line Segment

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Constructing equilateral triangle](/wiki/Geometry_for_Elementary_School/Constructing_equilateral_triangle)**
**Copying a line segment**
**[Copying a triangle](/wiki/Geometry_for_Elementary_School/Copying_a_triangle)**

  
This construction copies a line segment ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) to a target point **T**. The construction is based on [Book I, prop 2](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/propI2.html).

## The construction

  1. Let **A** be one of the end points of ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png). Note that we are just giving it a name here. (We could replace **A** with the other end point **B**).  
![Geom copyseg 01.png](//upload.wikimedia.org/wikibooks/en/thumb/e/e4/Geom_copyseg_01.png/225px-Geom_copyseg_01.png)  
  
  

  2. [Draw a line segment](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line.3F) ![\\overline{AT}](//upload.wikimedia.org/math/b/f/4/bf4c81ed1ceeab42f4b900f8ae1a9d76.png)  
![Geom copyseg 02.png](//upload.wikimedia.org/wikibooks/en/thumb/2/28/Geom_copyseg_02.png/225px-Geom_copyseg_02.png)  
  
  

  3. [Construct an equilateral triangle](/wiki/Geometry_for_Elementary_School/Constructing_equilateral_triangle) ![\\triangle ATD ](//upload.wikimedia.org/math/6/d/3/6d3a4877f1dffd23e829a818280f935e.png) (a triangle that has ![\\overline{AT}](//upload.wikimedia.org/math/b/f/4/bf4c81ed1ceeab42f4b900f8ae1a9d76.png) as one of its sides).  
![Geom copyseg 03.png](//upload.wikimedia.org/wikibooks/en/thumb/e/e5/Geom_copyseg_03.png/225px-Geom_copyseg_03.png)  
  
  

  4. [Draw the circle](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_circle.3F) ![\\circ A,\\overline{AB} ](//upload.wikimedia.org/math/e/5/0/e5005e2d05d7febd05139c9302cd93c1.png), whose center is **A** and radius is ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).  
![Geom copyseg 04.png](//upload.wikimedia.org/wikibooks/en/thumb/7/74/Geom_copyseg_04.png/225px-Geom_copyseg_04.png)  
  
  

  5. [Draw a line segment](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line) starting from **D** going through **A** until it intersects ![\\circ A,\\overline{AB} ](//upload.wikimedia.org/math/e/5/0/e5005e2d05d7febd05139c9302cd93c1.png) and let the intersection point be **E** . Get segments ![\\overline{AE}](//upload.wikimedia.org/math/f/0/f/f0fef0db8e72847d2683619ad824ff4e.png) and ![\\overline{DE}](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png).  
![Geom copyseg 05.png](//upload.wikimedia.org/wikibooks/en/thumb/7/72/Geom_copyseg_05.png/225px-Geom_copyseg_05.png)  
  
  

  6. [Draw the circle](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_circle.3F) ![\\circ D,\\overline{DE} ](//upload.wikimedia.org/math/0/8/7/0872e02a59b52f3fbd639a75c30e63d5.png), whose center is **D** and radius is ![\\overline{DE}](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png).  
![Geom copyseg 06.png](//upload.wikimedia.org/wikibooks/en/thumb/a/ae/Geom_copyseg_06.png/225px-Geom_copyseg_06.png)  
  
  

  7. [Draw a line segment](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line) starting from **D** going through **T** until it intersects ![\\circ D,\\overline{DE} ](//upload.wikimedia.org/math/0/8/7/0872e02a59b52f3fbd639a75c30e63d5.png) and let the intersection point be **F**. Get segments ![\\overline{TF}](//upload.wikimedia.org/math/c/3/d/c3d1694aee29bc6e41b655fc4a1b157c.png) and ![\\overline{DF}](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png).  
![Geom copyseg 07.png](//upload.wikimedia.org/wikibooks/en/thumb/8/88/Geom_copyseg_07.png/225px-Geom_copyseg_07.png)

## Claim

The segment ![\\overline{TF}](//upload.wikimedia.org/math/c/3/d/c3d1694aee29bc6e41b655fc4a1b157c.png) is equal to ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) and starts at **T**.  
![Geom copyseg claim.png](//upload.wikimedia.org/wikibooks/en/thumb/f/fb/Geom_copyseg_claim.png/225px-Geom_copyseg_claim.png)

## Proof

  1. Segments ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) and ![\\overline{AE}](//upload.wikimedia.org/math/f/0/f/f0fef0db8e72847d2683619ad824ff4e.png) are both from the center of ![\\circ A,\\overline{AB} ](//upload.wikimedia.org/math/e/5/0/e5005e2d05d7febd05139c9302cd93c1.png) to its circumference. Therefore they equal to the circle radius and to each other.  
![Geom copyseg proof01.png](//upload.wikimedia.org/wikibooks/en/thumb/8/81/Geom_copyseg_proof01.png/225px-Geom_copyseg_proof01.png)  
  
  

  2. Segments ![\\overline{DE}](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png) and ![\\overline{DF}](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png) are both from the center of ![\\circ D,\\overline{DE} ](//upload.wikimedia.org/math/0/8/7/0872e02a59b52f3fbd639a75c30e63d5.png) to its circumference. Therefore they equal to the circle radius and to each other.  
![Geom copyseg proof02.png](//upload.wikimedia.org/wikibooks/en/thumb/c/c0/Geom_copyseg_proof02.png/225px-Geom_copyseg_proof02.png)  
  
  

  3. ![\\overline{DE}](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png) equals to the sum of its parts ![\\overline{DA}](//upload.wikimedia.org/math/c/a/9/ca96340701ca4ea58f69aedafce96748.png) and ![\\overline{AE}](//upload.wikimedia.org/math/f/0/f/f0fef0db8e72847d2683619ad824ff4e.png).  
![Geom copyseg proof03.png](//upload.wikimedia.org/wikibooks/en/thumb/3/30/Geom_copyseg_proof03.png/225px-Geom_copyseg_proof03.png)  
  
  

  4. ![\\overline{DF}](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png) equals to the sum of its parts ![\\overline{DT}](//upload.wikimedia.org/math/6/9/3/693f8f053f39a9975a04d585f32ed21a.png) and ![\\overline{TF}](//upload.wikimedia.org/math/c/3/d/c3d1694aee29bc6e41b655fc4a1b157c.png).  
![Geom copyseg proof04.png](//upload.wikimedia.org/wikibooks/en/thumb/4/4d/Geom_copyseg_proof04.png/225px-Geom_copyseg_proof04.png)  
  
  

  5. The segment ![\\overline{DA}](//upload.wikimedia.org/math/c/a/9/ca96340701ca4ea58f69aedafce96748.png) is equal to ![\\overline{DT}](//upload.wikimedia.org/math/6/9/3/693f8f053f39a9975a04d585f32ed21a.png) since they are the sides of the equilateral triangle ![\\triangle ATD ](//upload.wikimedia.org/math/6/d/3/6d3a4877f1dffd23e829a818280f935e.png).  
![Geom copyseg proof05.png](//upload.wikimedia.org/wikibooks/en/thumb/6/67/Geom_copyseg_proof05.png/225px-Geom_copyseg_proof05.png)  
  
  

  6. Since the sum of segments is equal and two of the summands are equal so are the two other summands ![\\overline{AE}](//upload.wikimedia.org/math/f/0/f/f0fef0db8e72847d2683619ad824ff4e.png) and ![\\overline{TF}](//upload.wikimedia.org/math/c/3/d/c3d1694aee29bc6e41b655fc4a1b157c.png).  
![Geom copyseg proof06.png](//upload.wikimedia.org/wikibooks/en/thumb/9/93/Geom_copyseg_proof06.png/225px-Geom_copyseg_proof06.png)  
  
  

  7. Therefore ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) equals ![\\overline{TF}](//upload.wikimedia.org/math/c/3/d/c3d1694aee29bc6e41b655fc4a1b157c.png).  
![Geom copyseg proof07.png](//upload.wikimedia.org/wikibooks/en/thumb/9/99/Geom_copyseg_proof07.png/225px-Geom_copyseg_proof07.png)  
  
  


  


# Constructing a Triangle

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

This module may require a complete rewrite in order to suit its intended audience.  
You can help rewrite it. Please see the [relevant discussion](/wiki/Talk:Geometry_for_Elementary_School/Print_version).

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Copying an angle](/wiki/Geometry_for_Elementary_School/Copying_an_angle)**
**Constructing a triangle**
**[Why are the constructions not correct?](/wiki/Geometry_for_Elementary_School/Why_are_the_constructions_not_correct%3F)**

  
In this chapter, we will show how to construct a triangle from three segments. The construction is based on [Book I, proposition 22](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/propI22.html)

## The construction

Given three line segments ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png) and ![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png) we build a triangle whose sides equal the segments.

  1. [Copy the line](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment) ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png) to point **A**.  
![GEOM constr triangle 01a.png](//upload.wikimedia.org/wikibooks/en/thumb/0/0d/GEOM_constr_triangle_01a.png/225px-GEOM_constr_triangle_01a.png)  
If you have forgotten how to do this, follow the instructions in the previous section. Your construction should look like the grey lines in the picture below. Call the new line ![\\overline{AG}](//upload.wikimedia.org/math/f/1/0/f10828e083ea518a2d0563a8ab7ea87b.png)  
  
![GEOM constr triangle 01b.png](//upload.wikimedia.org/wikibooks/en/thumb/3/31/GEOM_constr_triangle_01b.png/225px-GEOM_constr_triangle_01b.png)  
It's a good idea to erase your construction lines now, so all that's left are the four line segments shown below.  
  
![GEOM constr triangle 01c.png](//upload.wikimedia.org/wikibooks/en/thumb/a/ae/GEOM_constr_triangle_01c.png/225px-GEOM_constr_triangle_01c.png)  
  

  2. [Copy the line](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment) ![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png) to point **B**  
![GEOM constr triangle 02a.png](//upload.wikimedia.org/wikibooks/en/thumb/1/16/GEOM_constr_triangle_02a.png/225px-GEOM_constr_triangle_02a.png)  
  
Your construction should look like the grey lines in the picture below. Call the new line ![\\overline{BH}](//upload.wikimedia.org/math/5/1/f/51f22d804200b60bd9203d7dc1beb5cc.png)  
![GEOM constr triangle 02b.png](//upload.wikimedia.org/wikibooks/en/thumb/b/b7/GEOM_constr_triangle_02b.png/300px-GEOM_constr_triangle_02b.png)  
  

  3. [Draw the circle](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_circle.3F) ![\\circ A,\\overline{AG}](//upload.wikimedia.org/math/f/6/4/f644dd177e3e79e64ce840e61bf58beb.png), whose center is **A** and radius is ![\\overline{AG}](//upload.wikimedia.org/math/f/1/0/f10828e083ea518a2d0563a8ab7ea87b.png).
  4. [Draw the circle](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_circle.3F) ![\\circ B,\\overline{BH} ](//upload.wikimedia.org/math/d/5/7/d571494ed09a237de75b2061e7c67900.png), whose center is **B** and radius is ![\\overline{BH}](//upload.wikimedia.org/math/5/1/f/51f22d804200b60bd9203d7dc1beb5cc.png).
  5. Let **J** be an intersection point of ![\\circ A,\\overline{AG} ](//upload.wikimedia.org/math/f/6/4/f644dd177e3e79e64ce840e61bf58beb.png) and ![\\circ B,\\overline{BH} ](//upload.wikimedia.org/math/d/5/7/d571494ed09a237de75b2061e7c67900.png).  
![GEOM constr triangle 03 first.png](//upload.wikimedia.org/wikibooks/en/thumb/a/a9/GEOM_constr_triangle_03_first.png/300px-GEOM_constr_triangle_03_first.png)  
  

  6. [Draw a line](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line.3F) ![\\overline{AJ}](//upload.wikimedia.org/math/a/2/7/a27bb98418bffbacae96954c30b5108f.png).
  7. [Draw a line](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line.3F) ![\\overline{BJ}](//upload.wikimedia.org/math/a/0/a/a0a6cfe05b2e074ced1ac2f5dc2ea025.png).  
![GEOM constr triangle 03.png](//upload.wikimedia.org/wikibooks/en/thumb/f/f7/GEOM_constr_triangle_03.png/300px-GEOM_constr_triangle_03.png)

## Claim

The sides of the triangle ![\\triangle ABJ](//upload.wikimedia.org/math/8/a/8/8a8f996a71bae2e95e851949994ff4c5.png) equal to ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png) and ![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png).

## Proof

  1. The segment ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) is a side of the triangle and equal to itself.
  2. The segment ![\\overline{AJ}](//upload.wikimedia.org/math/a/2/7/a27bb98418bffbacae96954c30b5108f.png) is equal to ![\\overline{AG}](//upload.wikimedia.org/math/f/1/0/f10828e083ea518a2d0563a8ab7ea87b.png) because they are both radii of circle![\\circ A,\\overline{AG}](//upload.wikimedia.org/math/f/6/4/f644dd177e3e79e64ce840e61bf58beb.png). And because it was copied, ![\\overline{AG}](//upload.wikimedia.org/math/f/1/0/f10828e083ea518a2d0563a8ab7ea87b.png)=![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png). Therefore ![\\overline{AJ}](//upload.wikimedia.org/math/a/2/7/a27bb98418bffbacae96954c30b5108f.png) is also equal to ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png)
  3. The segment ![\\overline{BJ}](//upload.wikimedia.org/math/a/0/a/a0a6cfe05b2e074ced1ac2f5dc2ea025.png) is equal to ![\\overline{BH}](//upload.wikimedia.org/math/5/1/f/51f22d804200b60bd9203d7dc1beb5cc.png) because they are both radii of circle![\\circ B,\\overline{BH}](//upload.wikimedia.org/math/d/5/7/d571494ed09a237de75b2061e7c67900.png). And because it was copied, ![\\overline{BH}](//upload.wikimedia.org/math/5/1/f/51f22d804200b60bd9203d7dc1beb5cc.png)=![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png). Therefore ![\\overline{BJ}](//upload.wikimedia.org/math/a/0/a/a0a6cfe05b2e074ced1ac2f5dc2ea025.png) is also equal to ![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png)
  4. Hence the sides of the triangle ![\\triangle ABJ](//upload.wikimedia.org/math/8/a/8/8a8f996a71bae2e95e851949994ff4c5.png) are equal to ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png) and ![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png).

## Testing the procedure

  1. [Draw a line](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line.3F) ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) of some length.
  2. [Copy the line](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment) ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) to an arbitrary point **C** and get ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png).
  3. Draw a line ![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png) such that it length is three times the length of ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png). (We didn't specify how to construct such a segment and we give it as an exercise. Use chapter [Copy the line](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment) as a guide for the solution.
  4. Construct a triangle from ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), ![\\overline{CD}](//upload.wikimedia.org/math/9/0/2/902da46b57b0eb05676eaca711664a2e.png) and ![\\overline{EF}](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png).

## Why you couldn't construct the triangle in the test?

The reason we couldn’t build the triangle in the test is that the circles we constructed did not intersect. One cannot use any three segment to construct a triangle. The length of the segments must obey a condition called “The triangle inequality”. The triangle inequality states that any of the segments should be shorter that the sum of the length of the other two segments. If one of the segments is longer the circles do not intersect. If one segment equals to the sum of the other two, we get a line instead of a triangle.

Therefore, the construction is correct but one should condition the segments on which it can be applied. Note that the original construction was conditioned by Euclid, hence there is no error in the construction or in its proof.

  


# Why the Constructions are not Correct

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Copying an angle](/wiki/Geometry_for_Elementary_School/Copying_an_angle)**
**Why are the constructions not correct?**
**[Bisecting an angle](/wiki/Geometry_for_Elementary_School/Bisecting_an_angle)**

  
In the previous chapters, we introduced constructions and proved their validity. Therefore, these constructions should work flawlessly. In this chapter, we will check whether the construction are indeed foolproof.

## Testing a construction

  1. [Draw a line](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_line) of ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) of length 10cm.
  2. [Copy the line segment](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment) to a different point **T**.
  3. Measure the length of the segment you constructed.

## Explanation

I must admit that I never could copy the segment accurately. Some times the segment I constructed was of the length 10.5cm, I did even worse. A more talented person might get better results, but probably not exact.

How come the construction didn't work, at least in my case?

Our proof of the construction is correct. However, the construction is done in an ideal world. In this world, the lines and circles drawn are also ideal. They match the mathematical definition perfectly.

The circle I draw doesn't match the mathematical definition. Actually, many say that they don't match any definition of circle. When I try to use the construction, I'm using the wrong building blocks.

However, the construction are not useless in our far from ideal world. If we use approximation of a circle in the construction, we are getting and approximation of the segment copy. After all, even my copy is not too far from the original.

## Note

In the Euclidian geometry developed by the Greek the rule is used only to draw lines. One cannot measure the length of segments using the rulers as we did in this test. Therefore our test should be viewed as a criticism of the use of Euclidian geometry in the real world and not as part of that geometry.

  


# Congruence

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Congruence and similarity](/wiki/Geometry_for_Elementary_School/Congruence_and_similarity)**
**Congruence**
**[The Side-Side-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Side-Side_congruence_theorem)**

In this chapter, we will start the discussion of congruence and congruence theorems. We say the two figures are congruent if they have the same shape and size. Congruent figures have three things in common: corresponding sides (corr. sides), corresponding angles (corr. ∠s) and corresponding points (corr. points). We will only talk about congruent triangles.

## Congruent triangles

The triangles ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle DEF ](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png) are congruent if and only if all the following conditions hold:

  1. The side ![\\overline {AB} ](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) equals ![\\overline {DE} ](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png). (Corresponding sides)  
![Geom side congr 01.png](//upload.wikimedia.org/wikibooks/en/thumb/8/8f/Geom_side_congr_01.png/560px-Geom_side_congr_01.png)  
  
  

  2. The side ![\\overline {BC} ](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png) equals ![\\overline {EF} ](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png). (Corresponding sides)  
![Geom side congr 02.png](//upload.wikimedia.org/wikibooks/en/thumb/f/f8/Geom_side_congr_02.png/560px-Geom_side_congr_02.png)  
  
  

  3. The side ![\\overline {AC} ](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) equals ![\\overline {DF} ](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png). (Corresponding sides)  
![Geom side congr 03.png](//upload.wikimedia.org/wikibooks/en/thumb/9/9b/Geom_side_congr_03.png/560px-Geom_side_congr_03.png)  
  
  

  4. The angle ![\\angle ABC ](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png) equals ![\\angle DEF ](//upload.wikimedia.org/math/4/e/1/4e143e84a7a5356e818cdffa5b52652c.png). (Corresponding angles)  
![Geom side congr 04.png](//upload.wikimedia.org/wikibooks/en/thumb/4/4e/Geom_side_congr_04.png/560px-Geom_side_congr_04.png)  
  
  

  5. The angle ![\\angle BCA ](//upload.wikimedia.org/math/1/9/c/19c933652de87275f0e139aabff4f6e8.png) equals ![\\angle EFD ](//upload.wikimedia.org/math/a/f/e/afe25ec4a1738193ba05fa0c9118c8ff.png). (Corresponding angles)  
![Geom side congr 05.png](//upload.wikimedia.org/wikibooks/en/thumb/2/29/Geom_side_congr_05.png/560px-Geom_side_congr_05.png)  
  
  

  6. The angle ![\\angle CAB ](//upload.wikimedia.org/math/c/d/3/cd361f16f3abea2f52d8de0a21c05520.png) equals ![\\angle FDE ](//upload.wikimedia.org/math/5/1/5/5150f9dcc9e600c79939a348c800cc60.png). (Corresponding angles)  
![Geom side congr 06.png](//upload.wikimedia.org/wikibooks/en/thumb/b/b4/Geom_side_congr_06.png/560px-Geom_side_congr_06.png)  
  
  


Note that the order of vertices is important. It is possible that ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle ACB ](//upload.wikimedia.org/math/d/9/7/d97cd6767e63d9d880398285b0803606.png) are not congruent even though both refer to the same triangle. Remember that the place where corresponding points are must be the same on both triangles.

Congruence theorems give a set of the fewest conditions that are sufficient in order to show that two triangles are congruent. They are SSS, SAS, ASA, AAS and RHS. We will talk about them later on.

## Finding the value of unknowns in triangles whose congruence is given

Let's say we have two triangles, ![\\triangle ABC](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle DEF](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png), and they are congruent. AB=3, ∠F=90° and ∠E=60°. We need to find DE and ∠A. Here's how:

![\\begin{align}\\angle F + \\angle E + \\angle D &= 180^\\circ \\text{ \(}\\angle \\text{ sum of } \\triangle \\text{\)}\\\\
90^\\circ + 60^\\circ + \\angle D &= 180^\\circ \\\\
\\angle D&= 180^\\circ - 90^\\circ - 60^\\circ \\\\
&= 30^\\circ \\end{align}](//upload.wikimedia.org/math/1/d/9/1d98718f0a6b609db9dcca174ed388bb.png)

  
![\\begin{align}
\\because \\triangle ABC &\\cong \\triangle DEF \\text{ \(given\)}\\\\
\\therefore DE&=AB \\text{ \(corr. sides, } \\cong \\triangle \\text{s\)}\\\\
DE&=3\\\\
\\And \\angle A &= \\angle D \\text{ \(corr. } \\angle \\text{s, } \\cong \\triangle \\text{s\)}\\\\
\\angle A &= 30^\\circ
\\end{align}](//upload.wikimedia.org/math/d/c/c/dcc7f32f8386febeff3a0d444a606fcc.png)

  


# Side-Side-Side Congruence Theorem

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Congruence](/wiki/Geometry_for_Elementary_School/Congruence)**
**The Side-Side-Side congruence theorem**
**[The Side-Angle-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Angle-Side_congruence_theorem)**

The first congruence theorem we will discuss is the Side-Side-Side theorem.

## The Side-Side-Side congruence theorem

Given two triangles ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle DEF ](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png) such that their sides are equal, hence:

  1. The side ![\\overline {AB} ](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) equals ![\\overline {DE} ](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png).  
![Geom side conth 01.png](//upload.wikimedia.org/wikibooks/en/thumb/4/4f/Geom_side_conth_01.png/374px-Geom_side_conth_01.png)  
  
  

  2. The side ![\\overline {BC} ](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png) equals ![\\overline {EF} ](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png).  
![Geom side conth 02.png](//upload.wikimedia.org/wikibooks/en/thumb/5/5a/Geom_side_conth_02.png/374px-Geom_side_conth_02.png)  
  
  

  3. The side ![\\overline {AC} ](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) equals ![\\overline {DF} ](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png).  
![Geom side conth 03.png](//upload.wikimedia.org/wikibooks/en/thumb/4/40/Geom_side_conth_03.png/374px-Geom_side_conth_03.png)  
  
  


Then the triangles are congruent and their angles are equal too.  
![Geom side conth 04.png](//upload.wikimedia.org/wikibooks/en/thumb/0/05/Geom_side_conth_04.png/374px-Geom_side_conth_04.png)  
  
  


## Method of Proof

In order to prove the theorem we need a new postulate. The postulate is that one can move or flip any shape in the plane without changing it. In particular, one can move a triangle without changing its sides or angles. Note that this postulate is true in plane geometry but not in general. If one considers geometry over a ball, the postulate is no longer true.

  
Given the postulate, we will show how can we move one triangle to the other triangle location and show that they coincide. Due to that, the triangles are equal.

### The construction

  1. [Copy The line Segment](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment) side ![\\overline {AB} ](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) to the point **D**.
  2. [Draw the circle](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compass#_how_to_draw_a_circle.3F) ![\\circ D,\\overline{AB} ](//upload.wikimedia.org/math/6/6/8/66841a820772c51fe14f5664db8bc352.png).
  3. The circle ![\\circ D,\\overline{AB}](//upload.wikimedia.org/math/6/6/8/66841a820772c51fe14f5664db8bc352.png) and the segment ![\\overline{DE} ](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png) intersect at the point **E** hence we have a copy of ![\\overline {AB} ](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) such that it coincides with ![\\overline{DE} ](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png).
  4. [Construct a triangle](/wiki/Geometry_for_Elementary_School/Constructing_a_triangle) with ![\\overline{DE} ](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png) as its base, ![\\overline{BC} ](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png), ![\\overline{AC} ](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) as the sides and the vertex at the side of the vertex **F**. Call this triangle triangles ![\\triangle DEG ](//upload.wikimedia.org/math/8/9/0/89003f2db12ce5afd6fe3682e4546eaa.png)

### The claim

The triangles ![\\triangle DEF ](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png) and ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) congruent.

  


### The proof

  1. The points **A** and **D** coincide.
  2. The points **B** and **E** coincide.
  3. The vertex **F** is an intersection point of ![\\circ D,\\overline{DF} ](//upload.wikimedia.org/math/5/c/f/5cf0519d10d6dae58d27ec88631c084c.png) and ![\\circ E,\\overline{EF} ](//upload.wikimedia.org/math/4/9/a/49aef1549d0a5c2a84a936ae83309ef0.png).
  4. The vertex **G** is an intersection point of ![\\circ D,\\overline{AC} ](//upload.wikimedia.org/math/a/2/e/a2e9f8d2d20ddbc51e50f62a6d16aecb.png) and ![\\circ E,\\overline{BC} ](//upload.wikimedia.org/math/2/8/7/28706f452fd5157cc61bf075389c2d54.png).
  5. It is given that ![\\overline{DF} ](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png) equals ![\\overline{AC} ](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png).
  6. It is given that ![\\overline{EF} ](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png) equals ![\\overline{BC} ](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png).
  7. Therefore, ![\\circ D,\\overline{DF} ](//upload.wikimedia.org/math/5/c/f/5cf0519d10d6dae58d27ec88631c084c.png) equals ![\\circ D,\\overline{AC} ](//upload.wikimedia.org/math/a/2/e/a2e9f8d2d20ddbc51e50f62a6d16aecb.png)and ![\\circ E,\\overline{EF} ](//upload.wikimedia.org/math/4/9/a/49aef1549d0a5c2a84a936ae83309ef0.png) equals ![\\circ E,\\overline{BC} ](//upload.wikimedia.org/math/2/8/7/28706f452fd5157cc61bf075389c2d54.png).
  8. However, circles of different centers have at most one intersection point in one side of the segment that joins their centers.
  9. Hence, the points **G** and **F** coincide.
  10. [There is only a single straight line between two points](/wiki/Geometry_for_Elementary_School/Lines#_Axiom:_there_is_only_a_single_straight_line_between_two_points), therefore ![\\overline {EG} ](//upload.wikimedia.org/math/d/4/1/d414e03948eb582d9e548697e2829c10.png) coincides with ![\\overline {EF} ](//upload.wikimedia.org/math/1/7/b/17b9d1cfae131088111ad8129c88b75f.png) and ![\\overline {GD} ](//upload.wikimedia.org/math/3/0/4/304294ac78189ff3c6130b4bb879f9c5.png) coincides with ![\\overline {DF} ](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png).
  11. Therefore, the ![\\triangle DEG ](//upload.wikimedia.org/math/8/9/0/89003f2db12ce5afd6fe3682e4546eaa.png) coincides with ![\\triangle DEF ](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png) and the two are congruent.
  12. Due to the postulate ![\\triangle DEG ](//upload.wikimedia.org/math/8/9/0/89003f2db12ce5afd6fe3682e4546eaa.png) and ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) are equal and therefore congruent.
  13. Hence, ![\\triangle DEF ](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png) and ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) are congruent.
  14. Hence, ![\\angle ABC ](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png) equals ![\\angle DEF ](//upload.wikimedia.org/math/4/e/1/4e143e84a7a5356e818cdffa5b52652c.png), ![\\angle BCA ](//upload.wikimedia.org/math/1/9/c/19c933652de87275f0e139aabff4f6e8.png) equals ![\\angle EFD ](//upload.wikimedia.org/math/a/f/e/afe25ec4a1738193ba05fa0c9118c8ff.png) and ![\\angle CAB ](//upload.wikimedia.org/math/c/d/3/cd361f16f3abea2f52d8de0a21c05520.png) equals ![\\angle FDE ](//upload.wikimedia.org/math/5/1/5/5150f9dcc9e600c79939a348c800cc60.png).

## Note

The Side-Side-Side congruence theorem appears as [Book I, prop 8](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/propI8.html) at the Elements. The proof here is in the spirit of the original proof. In the original proof Euclid claims that the vertices **F** and **G** must coincide but doesn’t show why. We used the assumption that “circles of different centers have at most one intersection point in one side of a segment that joins their centers”. This assumption is true in plane geometry but doesn’t follows from Euclid’s original postulates. Since Euclid himself [had to use such an assumption](/wiki/Geometry_for_Elementary_School/Constructing_equilateral_triangle), we preferred to give a more detailed proof, though the extra assumption.

  


# Copying a Triangle

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Copying a line segment](/wiki/Geometry_for_Elementary_School/Copying_a_line_segment)**
**Copying a triangle**
**[Copying an angle](/wiki/Geometry_for_Elementary_School/Copying_an_angle)**

  
In this chapter, we will show how to copy a triangle ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) to other triangle ![\\triangle CDE ](//upload.wikimedia.org/math/7/9/4/7941817d28fd1a7e5b645baa97ed1ae0.png) . The construction is an excellent example of the **reduction** technique – solving a problem by solution to a previously solved problem.

## The construction

  1. [Construct a triangle](/wiki/Geometry_for_Elementary_School/Constructing_a_triangle) from the sides of ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) : ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png), ![\\overline{BC}](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png) and get ![\\triangle CDE ](//upload.wikimedia.org/math/7/9/4/7941817d28fd1a7e5b645baa97ed1ae0.png).

## Claim

The triangles ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle CDE ](//upload.wikimedia.org/math/7/9/4/7941817d28fd1a7e5b645baa97ed1ae0.png) are congruent.

## Proof

  1. ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png), ![\\overline{BC}](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png) are sides of the triangle ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and therefore obey the triangle inequality.
  2. Therefore one can build a triangle whose sides equal these segments.
  3. The sides of the triangle ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle CDE ](//upload.wikimedia.org/math/7/9/4/7941817d28fd1a7e5b645baa97ed1ae0.png) are equal.
  4. Due to the [The Side-Side-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Side-Side_congruence_theorem) the triangles ![\\triangle ABC](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle CDE](//upload.wikimedia.org/math/7/9/4/7941817d28fd1a7e5b645baa97ed1ae0.png) congruence.

  


# Copying an Angle

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Copying a triangle](/wiki/Geometry_for_Elementary_School/Copying_a_triangle)**
**Copying an angle**
**[Constructing a triangle](/wiki/Geometry_for_Elementary_School/Constructing_a_triangle)**

  
In this chapter, we will show how to copy an angle ![\\angle ABC](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png) to other angle ![\\angle CDE](//upload.wikimedia.org/math/d/6/d/d6dc70acd0c2ef15834de3bcbab65ea2.png). The construction is based on [Book I, proposition 23](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/propI23.html).

## The construction

  1. [Draw a line](/wiki/Geometry_for_Elementary_School/Our_tools:_Ruler_and_compasses#_how_to_draw_a_line.3F) between **A** and **C** and get ![\\triangle ABC](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png).
  2. [Copy the triangle](/wiki/Geometry_for_Elementary_School/Copying_a_triangle) ![\\triangle ABC](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and get ![\\triangle CDE](//upload.wikimedia.org/math/7/9/4/7941817d28fd1a7e5b645baa97ed1ae0.png)

## Claim

The angles ![\\angle ABC](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png) and ![\\angle CDE](//upload.wikimedia.org/math/d/6/d/d6dc70acd0c2ef15834de3bcbab65ea2.png) are equal.

## Proof

  1. The triangles ![\\triangle ABC](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle CDE](//upload.wikimedia.org/math/7/9/4/7941817d28fd1a7e5b645baa97ed1ae0.png) congruence.
  2. Therefore the angles of the triangles equal.
  3. Hence, ![\\angle ABC](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png) and ![\\angle CDE](//upload.wikimedia.org/math/d/6/d/d6dc70acd0c2ef15834de3bcbab65ea2.png) are equal.

Note that any two points on the rays can be used to create a triangle.

  


# Bisecting an Angle

[Geometry for Elementary School/ Bisecting an angle](/w/index.php?title=Geometry_for_Elementary_School/_Bisecting_an_angle&action=edit&redlink=1)

  


# Side-Angle-Side Congruence Theorem

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[The Side-Side-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Side-Side_congruence_theorem)**
**The Side-Angle-Side congruence theorem**
**[The Angle-Side-Angle congruence theorem](/wiki/Geometry_for_Elementary_School/The_Angle-Side-Angle_congruence_theorem)**

![Elements title page.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Elements_title_page.jpg/50px-Elements_title_page.jpg)
The corresponding material in Euclid's elements can be found on [page 33 of Book I, Proposition 4](//en.wikisource.org/wiki/Page:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu/33) in Issac Todhunter's 1872 translation, _[The Elements of Euclid for the Use of Schools and Colleges](//en.wikisource.org/wiki/Index:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu)_.

In this chapter, we will discuss another congruence theorem, this time the Side-Angle-Side theorem. The angle is called the included angle.

## The Side-Angle-Side congruence theorem

Given two triangles ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle DEF ](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png) such that their sides are equal, hence:

  1. The side ![\\overline {AB} ](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) equals ![\\overline {DE} ](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png).
  2. The side ![\\overline {CA} ](//upload.wikimedia.org/math/8/4/8/848333dfa71d31e8d75c5ec482d374f7.png) equals ![\\overline {DF} ](//upload.wikimedia.org/math/d/4/4/d447dfe1ea8ff5b132592dc6e954e084.png).
  3. The angle ![\\angle CAB ](//upload.wikimedia.org/math/c/d/3/cd361f16f3abea2f52d8de0a21c05520.png) equals ![\\angle FDE ](//upload.wikimedia.org/math/5/1/5/5150f9dcc9e600c79939a348c800cc60.png) (These are the angles between the sides).

Then the triangles are congruent and their other angles and sides are equal too. Success!

## Proof

We will use the method of superposition – we will move one triangle to the other one and we will show that they coincide. We won’t use the construction we learnt to copy a line or a segment but we will move the triangle as whole.

  1. ![\\text{Superpose } \\triangle ABC \\text{ on } \\triangle DEF \\text{ such that } A \\text { is placed on } D \\text { and } \\overline {AB} \\text{ is placed on } \\overline {DE}](//upload.wikimedia.org/math/2/f/5/2f55fbe8f31d2241177954e2a58be439.png)
  2. ![\\because \\overline {AB} = \\overline {DE} \\text{ \(given\)}](//upload.wikimedia.org/math/8/c/3/8c31845fd365e9ffd0425d7890a3a9b1.png)
  3. ![\\therefore B \\text{ coincides with } E ](//upload.wikimedia.org/math/6/8/d/68d7c9654002f26f69e77d25e467bf1e.png)
  4. ![\\because \\angle CAB = \\angle FDE \\text{ \(given\)}](//upload.wikimedia.org/math/f/4/2/f42aca664601a62fdc02207a46e5152c.png)
  5. ![\\therefore \\overline {CA} = \\overline {FD} ](//upload.wikimedia.org/math/2/e/4/2e4037303fb7b8bc90703123ade1d8cb.png)
  6. ![\\because \\overline {CA} = \\overline {DF} \\text{ \(given\)}](//upload.wikimedia.org/math/f/9/a/f9a559986fe533f999263fadd7c7dea0.png)
  7. ![\\therefore C \\text{ coincides with } F ](//upload.wikimedia.org/math/c/c/f/ccffac0593e1d3104d7e14151f197ff6.png)
  8. ![\\therefore \\overline {CB} = \\overline {EF} ](//upload.wikimedia.org/math/4/9/8/498e17acfeee09e481d3d23d49cd0306.png)
  9. ![\\therefore \\triangle ABC = \\triangle DEF ](//upload.wikimedia.org/math/f/3/4/f34bb2289ab9fc683f1142c4a8c4bb15.png)
  10. ![\\therefore \\triangle ABC \\cong \\triangle DEF ](//upload.wikimedia.org/math/b/7/9/b79dd28609f68b5e784693852ac078d9.png)

  


# Angle-Side-Angle Congruence Theorem

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[The Side-Angle-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Angle-Side_congruence_theorem)**
**The Angle-Side-Angle congruence theorem**
**[The Side-Angle-Angle congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Angle-Angle_congruence_theorem)**

In this chapter, we will discuss another congruence theorem, this time the Angle-Side-Angle theorem, usually shortened as ASA. The side in this theorem is called the included side.

## The Angle-Side-Angle congruence theorem

![Asa congruence.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Asa_congruence.svg/400px-Asa_congruence.svg.png)

Given two triangles ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle DEF ](//upload.wikimedia.org/math/3/e/3/3e39eb121ee9eb5a4106ef376cb1df52.png) such that their sides are equal, hence:

  1. The angle ![\\angle BAC ](//upload.wikimedia.org/math/b/8/d/b8d7a7847dcba2f1d40731cfeb648e9f.png) equals ![\\angle EDF ](//upload.wikimedia.org/math/f/0/8/f0849440484778156922ed9e3ee2d980.png).
  2. The side ![\\overline {BA} ](//upload.wikimedia.org/math/7/8/6/786006e8962400f9aa9f826fe2020a88.png) equals ![\\overline {ED} ](//upload.wikimedia.org/math/9/1/c/91cddad81a8e5602bf0991a8bd51230e.png).
  3. The angle ![\\angle ABC ](//upload.wikimedia.org/math/7/0/c/70c612060bb4c336ea559881305cfcaf.png) equals ![\\angle DEF ](//upload.wikimedia.org/math/4/e/1/4e143e84a7a5356e818cdffa5b52652c.png) (These are the angles between the sides, or the included angle).

  
Then the triangles are congruent and their other angles and sides are equal too. Note that the side must be the included side of the two angles.

  


# Bisecting a Segment

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Bisecting an angle](/wiki/Geometry_for_Elementary_School/Bisecting_an_angle)**
**Print version**
**[Congruence and similarity](/wiki/Geometry_for_Elementary_School/Congruence_and_similarity)**

In this chapter, we will learn how to bisect a segment. Given a segment ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png), we will divide it to two equal segments ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) and ![\\overline{CB}](//upload.wikimedia.org/math/5/0/e/50e8b7f6d66fdb514da6488ae2ec60c3.png). The construction is based on [book I, proposition 10](http://aleph0.clarku.edu/~djoyce/java/elements/bookI/propI10.html).

## The construction

  1. [Construct the equilateral triangle](/wiki/Geometry_for_Elementary_School/Constructing_equilateral_triangle) ![\\triangle ABD ](//upload.wikimedia.org/math/c/1/e/c1e8c7e3a1cdb064f0f7599446b7e935.png) on ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).
  2. [Bisect an angle](/wiki/Geometry_for_Elementary_School/Bisecting_an_angle) on ![\\angle ADB ](//upload.wikimedia.org/math/3/e/9/3e917e8983576ccf9fc945352d101dbe.png) using the segment ![\\overline{DE}](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png).
  3. Let **C** be the intersection point of ![\\overline{DE}](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png) and ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).

## Claim

  1. Both ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) and ![\\overline{CB}](//upload.wikimedia.org/math/5/0/e/50e8b7f6d66fdb514da6488ae2ec60c3.png) are equal to half of ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png).

## The proof

  1. ![\\overline{AD}](//upload.wikimedia.org/math/6/f/0/6f069ce6986738cc7ea7f375f4811069.png) and ![\\overline{BD}](//upload.wikimedia.org/math/7/a/8/7a8947a4f4651a2ada90d7a1eb76545f.png) are sides of the equilateral triangle ![\\triangle ABD ](//upload.wikimedia.org/math/c/1/e/c1e8c7e3a1cdb064f0f7599446b7e935.png).
  2. Hence, ![\\overline{AD}](//upload.wikimedia.org/math/6/f/0/6f069ce6986738cc7ea7f375f4811069.png) equals ![\\overline{BD}](//upload.wikimedia.org/math/7/a/8/7a8947a4f4651a2ada90d7a1eb76545f.png).
  3. The segment ![\\overline{DC}](//upload.wikimedia.org/math/a/8/9/a89e80f4a2bde7cc3e1bc0d1bf64229b.png) equals to itself.
  4. Due to the construction ![\\angle ADE ](//upload.wikimedia.org/math/7/4/1/741d28e463036f41c626b38c813d0340.png) and ![\\angle EDB ](//upload.wikimedia.org/math/e/c/3/ec352a9b7e707de7eb23c3cb78092b59.png) are equal.
  5. The segments ![\\overline{DE}](//upload.wikimedia.org/math/b/1/a/b1a3c71b34ec10fa7400c0b541d40d80.png) and ![\\overline{DC}](//upload.wikimedia.org/math/a/8/9/a89e80f4a2bde7cc3e1bc0d1bf64229b.png) lie on each other.
  6. Hence, ![\\angle ADE ](//upload.wikimedia.org/math/7/4/1/741d28e463036f41c626b38c813d0340.png) equals to ![\\angle ADC](//upload.wikimedia.org/math/e/3/f/e3f7468bf45edda8edf88f94efb02762.png) and ![\\angle EDB ](//upload.wikimedia.org/math/e/c/3/ec352a9b7e707de7eb23c3cb78092b59.png) equals to ![\\angle CDB ](//upload.wikimedia.org/math/a/e/6/ae656dca9fa870ce7c905314fde8f85a.png).
  7. Due to [the Side-Angle-Side congruence theorem](/wiki/Geometry_for_Elementary_School/The_Side-Angle-Side_congruence_theorem) the triangles ![\\triangle ADC ](//upload.wikimedia.org/math/4/3/c/43c5170f2ff6663b0540c3db59e9489f.png) and ![\\triangle CDB ](//upload.wikimedia.org/math/1/b/d/1bdbeb8cd6279d058e702fac84fc8e14.png) congruent.
  8. Hence, ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) and ![\\overline{CB}](//upload.wikimedia.org/math/5/0/e/50e8b7f6d66fdb514da6488ae2ec60c3.png) are equal.
  9. Since ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) is the sum of ![\\overline{AC}](//upload.wikimedia.org/math/4/d/0/4d03743f4bccc17274f384b62e2f448e.png) and ![\\overline{CB}](//upload.wikimedia.org/math/5/0/e/50e8b7f6d66fdb514da6488ae2ec60c3.png), each of them equals to its half.

  


# Some Impossible Constructions

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[The Angle-Side-Angle congruence theorem](/wiki/Geometry_for_Elementary_School/The_Angle-Side-Angle_congruence_theorem)**
**Some impossible constructions**
**[Pythagorean theorem](/wiki/Geometry_for_Elementary_School/Pythagorean_theorem)**

  
In the previous chapters, we discussed several construction procedures. In this chapter, we will number some problems for which there is no construction using only ruler and compass.

The problems were introduced by the Greek and since then mathematicians tried to find constructions for them. Only in 1882, it was proven that there is no construction for the problems.

Note that the problems have no construction when we restrict ourself to constructions using ruler and compass. The problems can be solved when allowing the use of other tools or operations, for example, if we use [Origami](//en.wikipedia.org/wiki/Origami).

The mathematics involved in proving that the constructions are impossible are too advanced for this book. Therefore, we only name the problems and give reference to the proof of their impossibility at the further reading section.

## Impossible constructions

### Squaring the circle

The problem is to find a construction procedure that in a finite number of steps, to make a square with the same area as a given circle.

### Doubling the cube

To "double the cube" means to be given a cube of some side length _s_ and volume _V_, and to construct a new cube, larger than the first, with volume 2_V_ and therefore side length ³√2_s_.

### Trisecting the angle

The problem is to find a construction procedure that in a finite number of steps, constructs an angle that is one-third of a given arbitrary angle.

## Further reading

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A Wikibookian has nominated this page for cleanup.**  
You can [help make it better](//en.wikibooks.org/w/index.php?title=Geometry_for_Elementary_School/Print_version&action=edit). Please review any [relevant discussion](/wiki/Talk:Geometry_for_Elementary_School/Print_version).

Proving that the constructions are impossible involve mathematics that is not in the scope of this book.

The interested reader can use these links to learn why the constructions are impossible.

The [Four Problems Of Antiquity](http://www.cut-the-knot.org/arithmetic/antiquity.shtml) has no solution since their solution involves constructing a number that is not a [constructible number](http://www.cut-the-knot.org/arithmetic/rational.shtml). The numbers that should have being constructed in the problems are defined by [these cubic Equations](http://www.cut-the-knot.org/arithmetic/cubic.shtml).

It is recommended to read the references in this order:

  1. [Four Problems Of Antiquity](http://www.cut-the-knot.org/arithmetic/antiquity.shtml)
  2. [Constructible numbers](http://www.cut-the-knot.org/arithmetic/rational.shtml)
  3. [Cubic Equations](http://www.cut-the-knot.org/arithmetic/cubic.shtml)

  


# Pythagorean Theorem

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Some impossible constructions](/wiki/Geometry_for_Elementary_School/Some_impossible_constructions)**
**Print version**
**[A proof of irrationality](/wiki/Geometry_for_Elementary_School/A_proof_of_irrationality)**

In this chapter, we will discuss the Pythagorean theorem. It is used the find the side lengths of right triangles. It says:

    

    _In any right triangle, the area of the square whose side is the hypotenuse (the side of a right triangle opposite the right angle) is equal to the sum of areas of the squares whose sides are the two legs (i.e. the two sides other than the hypotenuse)._

This means that if ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) is a right triangle, the length of the hypotenuse, c, squared eqauls the sum of a squared plus b squared. Or:

    ![a^2 + b^2 = c^2 \\,](//upload.wikimedia.org/math/3/a/e/3ae71ab3eb71d3d182a3b9e437fba6ee.png)

Here's an example:

In a right-angled triangle, a=5cm and b=12cm, so what is c?

    ![a^2 + b^2 = c^2 \\,](//upload.wikimedia.org/math/3/a/e/3ae71ab3eb71d3d182a3b9e437fba6ee.png)
    ![c = \\sqrt{ 5^2 + 12^2 }\\,](//upload.wikimedia.org/math/0/b/6/0b676d85a6f008aeec797f0546f86630.png)
    ![c = \\sqrt{ 25 + 144 }\\,](//upload.wikimedia.org/math/6/c/d/6cdb3ec2cb90f2caa6e3ff9b355efe7e.png)
    ![c = \\sqrt{ 169 }\\,](//upload.wikimedia.org/math/2/5/6/25648e4d350774094736b9ea17d4602a.png)
    ![c = 13 \\,](//upload.wikimedia.org/math/7/9/6/796c03047242e65122b2072049f3d107.png)

If c is **not larger** than a or b, your answer is incorrect. There may be a number of reasons that your answer is incorrect. The first is that you have calculated the sums wrong, the second is that the triangle you are trying to find the hypotenuse of is not a right angled triangle or the third is you have mixed up the measurements. There may be more finer points to having a wrong answer but the three stated are the most common

## Exercise

  * Write about [Pythagorean Theorum](//en.wikipedia.org/wiki/Pythagorean_Theorum) and its use to prove that ![\\sqrt{0.5}](//upload.wikimedia.org/math/d/a/b/dab072f66251dce396449a0ca779afc4.png) is an [irrational number](//en.wikipedia.org/wiki/Irrational_number).

  


# Parallel Lines

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Measurements](/wiki/Geometry_for_Elementary_School/Measurements)**
**Parallel lines**
**[Symmetry](/wiki/Geometry_for_Elementary_School/Symmetry)**

## Definition

![Elements title page.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Elements_title_page.jpg/50px-Elements_title_page.jpg)
The corresponding material in Euclid's elements can be found on [page 29 of Book I, Definition(s) 35](//en.wikisource.org/wiki/Page:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu/29) in Issac Todhunter's 1872 translation, _[The Elements of Euclid for the Use of Schools and Colleges](//en.wikisource.org/wiki/Index:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu)_.

Let us recall what we learnt from the lines chapter. Parallel lines are straight lines that never intersect, which means that they never cross. Notice that when we look at parallel parts of shapes there is no place where they intersect even if we extend the lines.

As we have learnt from the plane shapes chapter, parallelograms, including squares, rhombi and rectangles, have two pairs of parallel sides. Also, there is one pair in trapeziums. Can you name any other polygons that contain parallel lines?

## Transversals

![Elements title page.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Elements_title_page.jpg/50px-Elements_title_page.jpg)
The corresponding material in Euclid's elements can be found on [page 55 of Book I, Proposition 27](//en.wikisource.org/wiki/Page:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu/55) in Issac Todhunter's 1872 translation, _[The Elements of Euclid for the Use of Schools and Colleges](//en.wikisource.org/wiki/Index:The_Elements_of_Euclid_for_the_Use_of_Schools_and_Colleges_-_1872.djvu)_.

A **transversal** is a line segment that cut through two line segments. (They can, of course, be lines and rays as well.) When the two line segments are parallel, the eight angles produced will have some special properties.

In such a case, imagine that one of the angles on one of the segments is called _x_. It is the top left angle. The top left angle of the other segment would be its corresponding angle, or corr. ∠. Corresponding angles are always the same size. Then imagine the vertically opposite angle of angle _x_. Let's call it _y_. The corresponding angle of _y_ would be the alternate angle, or alt. ∠, of _x_. Bear in mind that alternate angles are also the same in size as they are vertically opposite angles with the corresponding angles.

![Theorem 11.GIF](//upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Theorem_11.GIF/400px-Theorem_11.GIF)

What about the adjacent angles of _x_? As you can see, these angles are adjacent angles on a straight line with _x_, so they must be supplementary. These are called interior angles on the same side of the transversal (int. ∠s). They are different from the kind of interior angle in a polygon, so do not mix them up.

When you are doing your sums, you will find out that these three kinds of angles pop up very commonly and are very useful. The reference for these angles are corr./alt./int. ∠s, AB//CD. When you want to prove that two lines are congruent, then use corr./alt. ∠s equal or int. ∠s supp..

Look at the figure. Given that _m_ and _n_ are parallel, angles 1 and 5, 2 and 6, 3 and 7, 4 and 8 are corresponding angles, and are therefore equal. 5 and 3, 6 and 4 are alternate angles, so they must be equal as well. 5 and 4, 3 and 6 are interior angles, so they must be supplementary. Note that there are also two sets of angles at a point and eight pairs of adjacent angles on a straight line.

![Transversals problem.GIF](//upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Transversals_problem.GIF/250px-Transversals_problem.GIF)

Let us look at an example. Given that _DE_ and _GB_ are parallel, how can we find _x_, _y_ and _z_?

![\\begin{align} \\angle EFC &= \\angle BGC \\text{ \(corr. } \\angle \\text{s, DE} / / \\text{GB\)} \\\\
z &= 125^\\circ \\end{align}
](//upload.wikimedia.org/math/e/b/d/ebd29aa9a2d9a1aa390d8b11104ff8bc.png)  
  
![\\begin{align} \\angle AFD &= \\angle BGC \\text{ \(alt. } \\angle \\text{s, DE} / / \\text{GB\)} \\\\
y &= 125^\\circ \\end{align}
](//upload.wikimedia.org/math/4/9/7/497b21051059a3bca3fbd33e83d92539.png)  
  
![\\begin{align} \\angle AGB + \\angle BGC &= 180^\\circ \\text{ \(adj. } \\angle \\text{s on st. line\)}\\\\
\\angle AGB + 125^\\circ &= 180^\\circ \\\\
\\angle AGB &= 180^\\circ - 125^\\circ \\\\
&= 55^\\circ \\end{align}](//upload.wikimedia.org/math/5/f/1/5f1e8fbff57d3bf75128a5600c9ae5b0.png)  
  
![\\begin{align} \\angle AGB + \\angle EFC &= 180^\\circ \\text{ \(int. } \\angle \\text{s, DE} / / \\text{GB\)} \\\\
55^\\circ + x &= 180^\\circ \\\\
x &= 180^\\circ - 55^\\circ \\\\
&= 125^\\circ \\end{align}
](//upload.wikimedia.org/math/e/0/8/e0856d110b4e4e6d1441d742a8fa4103.png)

  


# Symmetry

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Parallel lines](/wiki/Geometry_for_Elementary_School/Parallel_lines)**
**Print version**
**[Transformation](/wiki/Geometry_for_Elementary_School/Transformation)**

In this section, we will talk about symmetry. Symmetry is when a figure has certain properties. There are many kinds of symmetry, but you only need to learn two in elementary school. Note that a figure with any kind of symmetry is called a symmetrical figure.

## Reflectional symmetry

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Symmetry.png/100px-Symmetry.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The three with axes are shapes with reflectional symmetry. The last one is not.

A figure is considered to have reflectional symmetry when a half of the figure coincides with the other half when folded in half (an easier way to say it would be saying it looks exactly the same on both sides). The line produced by folding is called the axis of symmetry, also known as the line of symmetry. The line must be dotted and must reach outside the figure. Common figures with reflectional symmetry are the English letters A, C, D, E, H, I, K, M, O, and so on. Regular polygons always have reflectional symmetry. The square, for example, has four axes of symmetry. Reflectional symmetry is also known as line symmetry, since it is symmetrical across a line.

## Rotational symmetry

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7b/Recycling_symbol.svg/100px-Recycling_symbol.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The recycling sign has only rotational symmetry.

Rotational symmetry is when a figure returns to its original shape after rotating at a certain angle. The point around which it is rotated is called the centre of rotation, and is marked with an 'x'. The centre of rotation is also the centre of the shape, so you can find the centre of rotation easily. Many figures with reflectional symmetry have also rotational symmetry. Common figures with _only_ rotational symmetry are the recycling sign and fan blades. If a figure coincides with the original twice in one full turn, it has two-fold rotational symmetry, or rotational symmetry order two. Regular polygons always have rotational symmetry. The square, for example, has four-fold rotational symmetry.

## Examples

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Rotational.svg/120px-Rotational.svg.png)

A figure with rotational symmetry. What should we add to its centre?

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Rotational_w_centre.svg/120px-Rotational_w_centre.svg.png)

We should add a cross.

  


# A Proof of Irrationality

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Pythagorean theorem](/wiki/Geometry_for_Elementary_School/Pythagorean_theorem)**
**Print version**
**[Fractals](/wiki/Geometry_for_Elementary_School/Fractals)**

In mathematics, a rational number is a real number that can be written as the ratio of two integers, i.e., it is of the form

    _a_/_b_ where _a_ and _b_ are integers and _b_ is not zero. An **irrational number** is a number that cannot be written as a ratio of two integers, i.e., it is not of the form
    _a_/_b_ .

  


## History of the theory of irrational numbers

The discovery of irrational numbers is usually attributed to Pythagoras, more specifically to the Pythagorean Hippasus of Metapontum, who produced a proof of the irrationality of the ![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png). The story goes that Hippasus discovered irrational numbers when trying to represent the square root of 2 as a fraction (proof below). However, Pythagoras believed in the absoluteness of numbers, and could not accept the existence of irrational numbers. He could not disprove their existence through logic, but his beliefs would not accept the existence of irrational numbers and so he sentenced Hippasus to death by drowning. As you see, mathematics might be dangerous.

## Irrationality of the square root of 2

In this section we attempt to explain why ![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png) is irrational. Irrational is a fancy word for a number that cannot be written as a fraction where the top and bottom of the fraction are whole numbers. At one point in time it was once believed that every number could be written as a fraction.

Before we start the proof we first should recall a few familiar facts. First, is that when we write fractions we can always _reduce_ them so they have no common factors. Just to remind ourselves how this goes, let's think about the fraction ![\\frac{15}{21}](//upload.wikimedia.org/math/c/1/2/c12256314e3ed63b738a8badf315097e.png). Since 3 divides into 15 evenly, and 3 divides into 21 evenly, then we can make this fraction have a smaller numerator and denominator. In this example see this by the following calculation:

    ![\\frac{15}{21}=\\frac{3\\cdot 5}{3\\cdot 7}=\\frac{3}{3}\\cdot\\frac{5}{7}=1\\cdot \\frac{5}{7}=\\frac{5}{7}](//upload.wikimedia.org/math/8/c/2/8c2af0992ddfab269dffbb8bf9dc1313.png).

The exact same calculation will let us get rid of any number that divides both the numerator and denominator. Imagine we have a fraction ![\\frac{p}{q}](//upload.wikimedia.org/math/5/8/5/5859e7cb616f2bd444f2ff5df3783f89.png) and there is a number _r_ so that _r_ divides evenly into _p_, and _r_ divides evenly into _q_. We can then write ![p=r\\cdot a](//upload.wikimedia.org/math/d/4/0/d400575a323db2237cf6ee89e7e4fcd5.png) (just like we wrote ![15=3\\cdot 5](//upload.wikimedia.org/math/6/a/e/6ae24970d2efb6f5afa8e8a1d173b65e.png)). We can also write ![q=r\\cdot b](//upload.wikimedia.org/math/5/7/e/57e104968a624ce9b8fe3fd2afdae9c5.png). Then the calculation looks like:

    ![\\frac{p}{q}=\\frac{r\\cdot a}{r\\cdot b}=\\frac{r}{r}\\cdot\\frac{a}{b}=1\\cdot \\frac{a}{b}=\\frac{a}{b}](//upload.wikimedia.org/math/b/8/b/b8bdd9438042c256220e0c2d851c6e07.png).

So whenever we have a fraction where the numerator and denominator are numbers we don't know yet (so we need to use letters like _p_ and _q_), we can assume we have already gotten rid of all the numbers that divide both _p_ and _q_.

The other thing that we need to remember is our facts about even and odd numbers. First every even number is really 2 times some smaller number. This is easy to see if you list out the even numbers:

    

even number
2
4
6
8
10
12
14
16
18
20
…

the same even number  
as 2·"something"
2·1
2·2
2·3
2·4
2·5
2·6
2·7
2·8
2·9
2·10
…

Finally we need to remember that the product of two even numbers is again and even number, and the product of two odd numbers is again an odd number. In fact this is just the familiar rules:

  * "even times even is even"
  * "odd times odd is odd"
  * "even times odd is even"

  
Now we can start thinking about the proof. The proof is a "proof by contradiction". For us this means we will start by assuming ![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png) can be written as a fraction. We will try to investigate and see what this means for the fraction, being careful that every step follows from the last step by something we know to be true. At the last step we will contradict ourselves. This will mean that we had to make a mistake somewhere. Since we were careful about all of the steps, the only possible place for a mistake will be that we assumed ![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png) can be written as a fraction.

  1. Assume that ![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png) can be written as a fraction. This means ![\\sqrt{2}=\\frac{a}{b}](//upload.wikimedia.org/math/e/f/0/ef0b0c9e80274955f0898042e63611bf.png). We will assume that this fraction is reduced, so no number could divide both _a_ and _b_. Specifically 2 cannot divide both _a_ and _b_.
  2. We now square both sides of your equation, that is we write ![2=\\left\(\\frac{a}{b}\\right\)^2](//upload.wikimedia.org/math/c/5/6/c56dd57083de841954055fe6e1d98685.png), which is the same as ![2=\\frac{a^2}{b^2}](//upload.wikimedia.org/math/5/9/3/593b401fe9a9451df647dbf8756b7c00.png).
  3. By multiplying both sides by ![b^2](//upload.wikimedia.org/math/a/9/6/a96f0cb529028f4b4e8c9848f247dc4e.png), it follows that ![a^2=2\\cdot b^2 ](//upload.wikimedia.org/math/1/6/7/167f81c65b6072abcc99f81167eb67b3.png).
  4. Therefore ![a^2](//upload.wikimedia.org/math/a/4/7/a4791fd2e334993453b00d036ab792af.png) is even, because it is equal to ![2\\cdot b^2](//upload.wikimedia.org/math/d/2/a/d2a5c9eece62664627918f5b19580dd4.png) which is even.
  5. If ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) were odd, then ![a^2=a\\cdot a](//upload.wikimedia.org/math/9/a/c/9ac661a4326dbbb4105e15861f269d86.png) would be odd, because "an odd times an odd is odd". So, it follows that ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) must be even.
  6. Because ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) is even, and every even number is 2 times something, we can write ![a = 2\\cdot k](//upload.wikimedia.org/math/3/c/b/3cb6792b620a559ec383a04a0c019faf.png), for some whole number ![k](//upload.wikimedia.org/math/8/c/e/8ce4b16b22b58894aa86c421e8759df3.png).
  7. If we substitute ![2\\cdot k](//upload.wikimedia.org/math/b/4/d/b4d60a42337096529531e1855e16a209.png) in for ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) in the equation in line 3, we get ![\(2\\cdot k\)^2 = 2\\cdot b^2](//upload.wikimedia.org/math/d/d/5/dd5ac1d58a1b0abcadb0586afae79b4a.png). Now ![\(2\\cdot k\)^2=\(2\\cdot k\)\\cdot\(2\\cdot k\)=4\\cdot k^2](//upload.wikimedia.org/math/d/5/b/d5b09df92e0340907a97dfcc959f26ba.png). So, ![4\\cdot k^2=2\\cdot b^2](//upload.wikimedia.org/math/c/6/0/c60769306f1248912e829b3348fb47b8.png).
  8. Because ![2\\cdot k^2](//upload.wikimedia.org/math/5/c/0/5c02ceb7150f2b0152782f9076f4b19b.png) is even then ![b^2](//upload.wikimedia.org/math/a/9/6/a96f0cb529028f4b4e8c9848f247dc4e.png) is also even. Just like we saw with ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) in line 5, this means that _b_ is even.
  9. In line 5 we saw that ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) was even and so 2 divides ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png). In line 8 we saw that ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) was even, so 2 divides ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png). But in line 1 we said that 2 cannot divide both ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) and ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png). This is a contradiction.

Since we have found a contradiction, the assumption in line 1 must be false. That is, it must be false that ![\\sqrt{2}=\\frac{a}{b}](//upload.wikimedia.org/math/e/f/0/ef0b0c9e80274955f0898042e63611bf.png) where ![a](//upload.wikimedia.org/math/0/c/c/0cc175b9c0f1b6a831c399e269772661.png) and ![b](//upload.wikimedia.org/math/9/2/e/92eb5ffee6ae2fec3ad71c777531578f.png) are whole numbers. So we cannot write ![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png) has a fraction. The fancy way of saying this is to say that ![\\sqrt{2}](//upload.wikimedia.org/math/e/f/5/ef5590434a387b3c4427e09d5b08baaf.png) is irrational.

  


# Fractals

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[A proof of irrationality](/wiki/Geometry_for_Elementary_School/A_proof_of_irrationality)**
**Print version**
**[What next?](/wiki/Geometry_for_Elementary_School/What_next%3F)**

All the previous constructions we considered had one thing in common. The constructions were ended after a final number of steps. When one recalls that mathematicians actually used a ruler and compass in order to execute the constructions, this requirement seems to be in place. However, when we remove this requirement we can construct new interesting geometric shapes. In this chapter we will introduce two of them. Note that these shapes are not part of Euclidian geometry and were considered only years after its development.

## Cantor Set

For a full overview of Cantor set [see the article](http://en.wikipedia.org/wiki/Cantor_set) at wikipedia on which this section is based. The **Cantor set** was introduced by German mathematician Georg Cantor.

The Cantor set is defined by repeatedly removing the middle thirds of line segments. One starts by removing the middle third from the unit interval [0, 1], leaving [0, 1/3] ∪ [2/3, 1]. Next, the "middle thirds" of all of the remaining intervals are removed. This process is continued for ever. The Cantor set consists of all points in the interval [0, 1] that are not removed at any step in this infinite process.

### What's in the Cantor set?

Since the Cantor set is defined as the set of points not excluded, the proportion of the unit interval remaining can be found by total length removed. This total is the geometric series

    ![\\frac{1}{3} + \\frac{2}{9} + \\frac{4}{27} + \\frac{8}{81} + \\cdots = \\sum_{n=0}^\\infty \\frac{2^n}{3^{n+1}} = \\frac{1}{3}\\left\(\\frac{1}{1-\\frac{2}{3}}\\right\) = 1.](//upload.wikimedia.org/math/1/1/1/1117c0bec70561e996f4129771172f25.png)

So that the proportion left is 1 – 1 = 0. Alternatively, it can be observed that each step leaves 2/3 of the length in the previous stage, so that the amount remaining is 2/3 × 2/3 × 2/3 × ..., an infinite product which equals 0 in the limit.

From the calculation, it may seem surprising that there would be anything left — after all, the sum of the lengths of the removed intervals is equal to the length of the original interval. However a closer look at the process reveals that there must be something left, since removing the "middle third" of each interval involved removing open sets (sets that do not include their endpoints). So removing the line segment (1/3, 2/3) from the original interval [0, 1] leaves behind the points 1/3 and 2/3. Subsequent steps do not remove these (or other) endpoints, since the intervals removed are always internal to the intervals remaining. So we know for certain that the Cantor set is not empty.

### The Cantor set is a fractal

The Cantor set is the prototype of a [fractal](http://en.wikipedia.org/wiki/Fractal). It is [self-similar](http://en.wikipedia.org/wiki/Self-similar), because it is equal to two copies of itself, if each copy is shrunk by a factor of 1/3 and translated.

## Koch curve

For a full overview of Koch curve [see the article](http://en.wikipedia.org/wiki/Koch_curve) at wikipedia on which this section is based.

The **Koch curve** is a one of the earliest [fractal](http://en.wikipedia.org/wiki/Fractal) curves to have been described. It was published during 1904 by the Swedish mathematician Helge von Koch. The better known **Koch snowflake** (or **Koch star**) is the same as the curve, except it starts with an equilateral triangle instead of a line segment.  
![Geom koch 01.png](//upload.wikimedia.org/wikibooks/en/thumb/a/a6/Geom_koch_01.png/387px-Geom_koch_01.png)  


One can imagine that it was created by starting with a line segment, then recursively altering each line segment as follows:

  1. divide the line segment into three segments of equal length.
  2. draw an equilateral triangle that has the middle segment from step one as its base.
  3. remove the line segment that is the base of the triangle from step 2.

After doing this once the result should be a shape similar to the Star of David.  
![Geom koch 02.png](//upload.wikimedia.org/wikibooks/en/thumb/4/42/Geom_koch_02.png/387px-Geom_koch_02.png)  


The Koch curve is in the limit approached as the above steps are followed over and over again.  
![Geom koch 03.png](//upload.wikimedia.org/wikibooks/en/thumb/a/a6/Geom_koch_03.png/387px-Geom_koch_03.png)  
  
![Geom koch 04.png](//upload.wikimedia.org/wikibooks/en/thumb/5/5f/Geom_koch_04.png/387px-Geom_koch_04.png)  
  
![Geom koch 05.png](//upload.wikimedia.org/wikibooks/en/thumb/2/29/Geom_koch_05.png/387px-Geom_koch_05.png)  
  
![Geom koch 06.png](//upload.wikimedia.org/wikibooks/en/thumb/d/d6/Geom_koch_06.png/387px-Geom_koch_06.png)  


The Koch curve has infinite length because each time the steps above are performed on each line segment of the figure its length increases by one third. The length at step n will therefore be (4/3)n.

The area of the Koch snowflake is 8/5 that of the initial triangle, so an infinite perimeter encloses a finite area.

  


# What's Next?

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Fractals](/wiki/Geometry_for_Elementary_School/Fractals)**
**Print version**
**[Glossary](/wiki/Geometry_for_Elementary_School/Glossary)**

Congratulations! You have read through your elementary school geometry areas. That does not mean that your studies of geometry are over! When you get to higher forms, you will come across more complex mathematics, such as deductive geometry. When you get to those areas, don't be afraid! Remember your basics, and anything is possible.

Now that you have finished the entire course, you may want to try out the advanced geometry course, [Geometry](/wiki/Geometry). Although some topics may be less easy to understand, some are already covered in this book, so you will be revising some of your basics before starting on more difficult topics.

  


# Notation

**[Geometry for Elementary School](/wiki/Geometry_for_Elementary_School)**

**[Glossary](/wiki/Geometry_for_Elementary_School/Glossary)**
**Print version**

This appendix summarises the conventions used in this book. There is also a British-American English differences table provided.

## Language

All the language in this book uses simple British English. Alternative names in American English are listed below.

British English American English Other names

Vertically opposite angles
Vertical angles
/

The right angle-hypotenuse-side congruence theorem (RHS)
The hypotenuse-leg congruence theorem (HL)
The hypotenuse-leg-right angle theorem (HLR)

Centre
Center
/

Compass
Compass
A pair of compasses (British)

Trapezium
Trapezoid
/

Centimetre / Millimetre / Metre / Kilometre
Centimeter / Millimeter / Meter / Kilometre
/

Millilitre / Litre
Milliliter / Liter
/

## Notation

This appendix summarises the notation used in the book. An effort was made to use common conventions in the notation. However, since many conventions exist the reader might see a different notation used in other books.

Point

A point will be named by an uppercase letter in italics, as in the point _A_. In some equations though, it will look like this: ![A](//upload.wikimedia.org/math/7/f/c/7fc56270e7a70fa81a5935b72eacbe29.png).

Line segment

We will use the notation ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) for the line segment that starts at _A_ and ends at _B_. Note that we don't care about the segment direction and therefore ![\\overline{AB}](//upload.wikimedia.org/math/4/d/5/4d5f1f7b8a17c2052c4351dc169ac1bb.png) is similar to ![\\overline{BA}](//upload.wikimedia.org/math/7/8/6/786006e8962400f9aa9f826fe2020a88.png).

Angles

We will use the notation ![\\angle{ABC}](//upload.wikimedia.org/math/a/d/2/ad203420aca40c86253a6722c21f4e2f.png) for the angle going from the point _B_, the intersection point of the segments ![\\overline{BA}](//upload.wikimedia.org/math/7/8/6/786006e8962400f9aa9f826fe2020a88.png) and ![\\overline{BC}](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png). Sometimes the angle may also be represented by a lowercase letter or even a number, but this is only used in the main text for ease and not in the exercises.

Triangles

A triangle whose vertices are _A_, _B_ and _C_ will be noted as ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png). Note that for the purpose of triangles' congruence, the order of vertices is important and ![\\triangle ABC ](//upload.wikimedia.org/math/6/3/5/635759e23aaf6e02541e3b72d65268d0.png) and ![\\triangle BCA ](//upload.wikimedia.org/math/c/0/d/c0d8ce2fbc80c9df35d7b0a30715481b.png) are not necessarily congruent.

Circles

We use the notation ![\\circ A,\\overline{BC} ](//upload.wikimedia.org/math/f/2/4/f24adae0b02e8eaf74dba23d88b1675e.png) for the circle whose center is the point **A** and its radius length equals that of the segment ![\\overline{BC}](//upload.wikimedia.org/math/e/9/1/e9198af4810f8cedcc22256209b20024.png).

Note that in other sources, a circle is described by any 3 points on its circumference, _ABC_. The center, radius notation was chosen since it seems to be more suitable for constructions.

External links

If you are interested seeing an example of past notation, you might be interested in [Byrne's edition of Euclid's Elements](http://www.sunsite.ubc.ca/DigitalMathArchive/Euclid/byrne.html). See for example the [equilateral triangle construction](http://www.sunsite.ubc.ca/DigitalMathArchive/Euclid/bookI/images/bookI-1.html).

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Geometry_for_Elementary_School/Print_version&oldid=1791249](http://en.wikibooks.org/w/index.php?title=Geometry_for_Elementary_School/Print_version&oldid=1791249)" 

[Category](/wiki/Special:Categories): 

  * [Geometry for Elementary School](/wiki/Category:Geometry_for_Elementary_School)

Hidden category: 

  * [Pages needing attention](/wiki/Category:Pages_needing_attention)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Geometry+for+Elementary+School%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Geometry+for+Elementary+School%2FPrint+version)

### Namespaces

  * [Book](/wiki/Geometry_for_Elementary_School/Print_version)
  * [Discussion](/wiki/Talk:Geometry_for_Elementary_School/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Geometry_for_Elementary_School/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Geometry_for_Elementary_School/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Geometry_for_Elementary_School/Print_version&action=edit)
  * [View history](/w/index.php?title=Geometry_for_Elementary_School/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Geometry_for_Elementary_School/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Geometry_for_Elementary_School/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Geometry_for_Elementary_School/Print_version&oldid=1791249)
  * [Page information](/w/index.php?title=Geometry_for_Elementary_School/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Geometry_for_Elementary_School%2FPrint_version&id=1791249)

### In other languages

  * [Italiano](//it.wikibooks.org/wiki/Geometria_per_scuola_elementare/Introduzione)
  * [Polski](//pl.wikibooks.org/wiki/Geometria_dla_szko%C5%82y_podstawowej/Przyrz%C4%85dy:_cyrkiel_i_linijka)
  * [Português](//pt.wikibooks.org/wiki/Matem%C3%A1tica_elementar/Geometria_plana/Constru%C3%A7%C3%B5es_geom%C3%A9tricas_usando_r%C3%A9gua_e_compasso)
  * [Русский](//ru.wikibooks.org/wiki/%D0%93%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D1%8F_%D0%B4%D0%BB%D1%8F_%D1%81%D1%80%D0%B5%D0%B4%D0%BD%D0%B5%D0%B9_%D1%88%D0%BA%D0%BE%D0%BB%D1%8B/%D0%9D%D0%B0%D1%88%D0%B8_%D0%B8%D0%BD%D1%81%D1%82%D1%80%D1%83%D0%BC%D0%B5%D0%BD%D1%82%D1%8B:_%D0%9B%D0%B8%D0%BD%D0%B5%D0%B9%D0%BA%D0%B0_%D0%B8_%D1%86%D0%B8%D1%80%D0%BA%D1%83%D0%BB%D1%8C)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Geometry+for+Elementary+School%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Geometry+for+Elementary+School%2FPrint+version&oldid=1791249&writer=rl)
  * [Printable version](/w/index.php?title=Geometry_for_Elementary_School/Print_version&printable=yes)

  * This page was last modified on 10 May 2010, at 15:45.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Geometry_for_Elementary_School/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
