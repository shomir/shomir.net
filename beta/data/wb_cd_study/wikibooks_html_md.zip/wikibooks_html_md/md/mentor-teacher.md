# Mentor teacher/Print version

From Wikibooks, open books for an open world

< [Mentor teacher](/wiki/Mentor_teacher)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Mentor_teacher/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Mentor_teacher/Print_version) on _20 May 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Mentor_teacher/Print_version&oldid=2527521&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

## Contents

  * 1 PART 1 - TOOLS
  * 2 The first mentor-mentee meeting
    * 2.1 Characteristics
    * 2.2 Sources
  * 3 Written reflection tools in mentoring
    * 3.1 Mentoring agreement
      * 3.1.1 What is a mentoring agreement?
      * 3.1.2 Topics to include in a mentoring agreement
    * 3.2 Individual strategy document
      * 3.2.1 Written lesson plan
      * 3.2.2 Personal narratives
    * 3.3 Log writing in mentoring
    * 3.4 Sources
  * 4 Observation in mentoring
    * 4.1 What is observation
    * 4.2 Observation in mentoring
    * 4.3 Sources
  * 5 Oral reflection tools in mentoring
    * 5.1 Sources
  * 6 To talk about the conversation in mentoring
    * 6.1 What does it mean to metacommunicate?
    * 6.2 Different types of strategic metacommunication
      * 6.2.1 To talk about the professional form of communication
      * 6.2.2 To talk about the mentoring relationship
      * 6.2.3 To ask questions that will clarify a conversation
      * 6.2.4 To sum up the mentorship conversation
      * 6.2.5 To talk about what not to talk about
    * 6.3 Empirical research on the value of metacommunication
    * 6.4 Sources
  * 7 Active listening
    * 7.1 What is active listening?
    * 7.2 Conversational techniques related to active listening
      * 7.2.1 Paraphrasing
      * 7.2.2 Open questions
      * 7.2.3 Support through non-verbal communication
      * 7.2.4 Mirroring
    * 7.3 Historical background of active listening
      * 7.3.1 Genuineness
      * 7.3.2 Unconditional positive regard
      * 7.3.3 Empathy
    * 7.4 Is active listening about technique or attitude?
    * 7.5 Sources
  * 8 PART 2 - THEORIES ABOUT MENTORING
  * 9 Action-reflection model
    * 9.1 Origins
    * 9.2 Theoretical sources of inspiration
    * 9.3 Criticism
    * 9.4 References
  * 10 Apprenticeship model
    * 10.1 What is the apprenticeship model?
    * 10.2 Usage
    * 10.3 Characteristics
    * 10.4 Central theorists
    * 10.5 The importance of the apprenticeship model in many professions
    * 10.6 Criticism of the apprenticeship model
    * 10.7 Integration of the apprenticeship model in teacher education
    * 10.8 References
    * 10.9 Sources
    * 10.10 Video resources
  * 11 Systemic mentoring
    * 11.1 Characteristics
    * 11.2 Question techniques in systemic mentoring
      * 11.2.1 Questions that explore differences
        * 11.2.1.1 Questions that explore differences on a personal level
        * 11.2.1.2 Questions that explore differences in relations
        * 11.2.1.3 Questions that explore differences in opinions, ideas, values and motives
        * 11.2.1.4 Questions that explore differences between the present and the future
      * 11.2.2 Questions that explore behavioural effect
      * 11.2.3 Triadic questions
      * 11.2.4 Hypothetical questions
    * 11.3 Example – To se oneself from the outside
    * 11.4 Sources
  * 12 Appreciative Inquiry
    * 12.1 What is Appreciative Inquiry?
    * 12.2 The four phases of Appreciative Inquiry
    * 12.3 Use and examples
    * 12.4 Sources
    * 12.5 Relevant books
    * 12.6 Relevant internet resources
  * 13 Coaching
    * 13.1 What is coaching?
    * 13.2 Origins
    * 13.3 Source
  * 14 Dreyfus model of skill acquisition
    * 14.1 Different stages of skill acquisition
    * 14.2 Examples
    * 14.3 How to become an expert?
    * 14.4 Sources

# PART 1 - TOOLS[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=1)]

# The first mentor-mentee meeting[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=2)]

## Characteristics[[edit](/w/index.php?title=Mentor_teacher/The_first_mentor-mentee_meeting&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/31/Nusfjord_road%2C_2010_09.jpg/220px-Nusfjord_road%2C_2010_09.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Where is the student in the mentoring landscape?

The first mentor-mentee meeting is often characterized by anticipation and nervousness. Both parties want to make a good first impression. Clarification of roles and responsibilities, formal aspects of the mentoring relationship, and perhaps cooperation and collaboration with other mentees at the school are topics of discussion in this meeting. It is the mentor's responsibility to tell the mentee about the school and the students that she will teach. This article focuses on the first meeting between mentor and student teacher. It is relevant to the first meeting between mentor and beginning teacher as well.

Nilssen (2010) argues that the mentee should not be overwhelmed with practical information during the first meeting. She also argues that the mentor should elicit information about the student teachers' experiences, thoughts and attitudes regarding what it means to be a teacher. Students who choose the teaching profession often have experience coaching children in sports or other extra curricular activities. One mentor explains: _“Learning about a student's personal and professional experience gives me an indication of where the student is in the “teaching and mentoring landscape”. I also think it is important that students have some background information about me as mentor. That they know what my intentions are, who I am as a teacher, and the reasons I have for the kind of mentoring I wish to give. Thus, we “speak the same language” and everything becomes more predictable”_ (Nilssen 2010: 72).

This example illustrates that it is a good idea for the mentor to explain which form she would like the mentoring to have.

The mentor and student teacher frequently have different opinions about the purpose of the practicum period, perhaps due to different understandings of the teaching profession. Alternative questions for discussion could be:

  * What is good teaching?
  * What does it mean to be a teacher?
  * What is good mentoring?

The answers to these questions will determine the nature of mentoring. Many student teachers focus on their lesson-by-lesson performance. One mentor explains: _“The students often expect me to provide them with specific help and advice on how to handle a classroom situation. I saw that the group that I was mentoring expected me to tell them how things could have been handled differently”_ (Nilssen 2010:73).

Student teachers are commonly preoccupied with their own teaching during practicum. Below are some examples (Nilssen 2010: 60):

  * The teacher's physical movement in the classroom and interaction with students at work.
  * Handling chaotic situations.
  * Using a language that children/youth understand.
  * The expression of ideas and opinions to the students.
  * Explaining pedagogical choices.

The student teachers have responsibilities beyond improving their performance in the classroom. They should discuss student assignments, observe various situations and participate in parent-teacher conferences.

## Sources[[edit](/w/index.php?title=Mentor_teacher/The_first_mentor-mentee_meeting&action=edit&section=T-2)]

  * Nilssen, V. (2010) Praksislæreren. Oslo: Universitetsforlaget.

# Written reflection tools in mentoring[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=3)]

In this chapter we present a few written reflection tools that are useful in mentoring. The ideas are based on tools used in Norwegian mentoring systems. The mentor-mentee framework is different in other jurisdictions, but we believe some aspects of the presented model can have application to teacher mentoring in these other jurisdictions.

In Norway the mentor and mentee enter into a written mentoring agreement. The agreement sets the groundwork for mentorship conversations to follow. In addition to the agreement, the mentee authors a document that is personal to the mentee. We will refer to this document as an "individual strategy document". This document could consist of a teaching plan and/or aspects of personal narrative. The purpose of the document is to assist the mentee in communicating individual goals. As the mentorship continues, it is typically recommended for the mentee to write a regular log of her practicum experiences in order to develop goals that are personal to her.

The examples in this chapter are from the mentoring of student teachers, but are also relevant to the mentoring of beginning teachers.

## Mentoring agreement[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-1)]

### What is a mentoring agreement?[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-2)]

A mentoring agreement is a written agreement between mentor and mentee. Its purpose is to establish and maintain a beneficial collaboration during practicum. When creating a mentoring agreement it is essential that both parties put forward their expectations. Topics such as punctuality, deadlines, schedules for mentoring, development goals, work effort and mentoring pedagogy are often discussed. The teacher education institution has usually put in place guidelines for implementation of practicum as well. The mentoring agreement should be revised regularly. Follow-up questions could be: “will we be able to achieve what we decided in the plan?” or “is there something we should follow up on or change?”

### Topics to include in a mentoring agreement[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-3)]

Below we present some of the areas that should be covered by a written agreement:

**Formal information**

There should be some formal information about both mentor and mentee in the mentoring agreement. This can for instance include the student's name, field of study and the duration of practicum. The minimum information provided about the mentor should be name and contact information (i.e. telephone number, e-mail address etc.).

**Mentor's responsibilities**

The mentor should describe her responsibilities so that the mentee knows how much follow-up to expect. Such descriptions vary. Some examples are:

  * The mentor may choose to say something about the mentee's induction into the school culture, for instance that she will be an integrated part of the school. In addition, the mentor should provide practical information, e.g. individual measures aimed at specific students in the classroom. The mentee will also need information about the borrowing/use of equipment and teaching aids. Some of this information can be provided orally, some should be put down in writing.
  * The mentor could outline the nature of the mentor-mentee relation. For instance, that the mentor will look after the student and contribute to the student's inclusion in the community of colleagues.
  * The mentor could outline a possible organization of the mentoring. The agreement could, for instance, state that it is the mentor's responsibility to arrange mentoring before and after teaching. This will ensure that the mentor-mentee relationship has a more formal supportive structure. It may also be beneficial to specify how much of the mentee's teaching the mentor is planning to observe.

**Mentor's expectations of the mentee**

A mentoring agreement should include expectations of the student teacher. Often there are written institutional guidelines. These guidelines are in part provided by the teacher education institution and in part by the school where the student teacher does her practicum. It is also recommended to specify positive work habits the student teacher is expected to develop. For instance, the student teacher could be asked to draft a detailed lesson plan and make it available for the mentor so that it can be used for mentoring purposes before a lesson. The student teacher could also be asked to write a reflection log following each mentoring session. In addition, it could be put in writing that the student teacher be prepared and punctual.

The mentor and the mentee may not necessarily have the same expectations when it comes to the extent of the mentee's responsibilities. It is useful to include the student teacher's work hours (typically the equivalent of a full time job), and to include expectations of the student teacher beyond teaching (e.g. teacher collaboration, the nature of role of classroom teacher, teacher-student conversations, planning, the use of learning platforms and extra-curricular activities). The agreement should include legal information about confidentiality aspects of the student teacher's job.

**Goals and objectives for practicum**

The goals and objectives in a mentoring agreement must be closely linked with the goals of the teacher education and local plans for practicum. In studies of education the student teacher should for instance gain subject didactic, social, occupational ethics and/or development and change competencies. The following are examples of a few general goals in an agreement:

  * Planning, execution and evaluation of teaching according to the curriculum;
  * Reflection on and explanation of one's own teaching;
  * Understanding the connection between theory and practice;
  * Attending to typical teaching tasks and being part of the school's day-to-day operation.

It may be difficult to establish if these general goals have been fulfilled. However, mentor and mentee could collaborate on more specific goals within different areas of competence. In addition, the student teacher's own expectations should be part of the agreement, and a separate item in the agreement could contain her own development goals. When an agreement takes the student teacher's preferences into consideration, it is more likely that the agreement will be seen as mutually binding.

**Time management**

As a rule, the local education institution lays down guidelines regarding the amount of mentoring provided. For that reason it is common to specify the number of mentoring sessions in the agreement. Other questions regarding time use can be agreed upon with the student teacher. One could for instance discuss whether the mentoring take place at a regular time or when the student feels the need for it. The agreement could look like this: pre-lesson mentoring sessions Mondays 8 – 9.30 am, debriefing sessions Fridays 3.30-4.30 pm. The mentor can decide the time in advance, or the mentor and mentee can arrange a time that fits both parties' schedules when they first meet. Most importantly, the time table must be mutually binding. The student teacher furthermore follows a plan for the practicum period that contains information about lessons, planned mentoring sessions, as well as other tasks such as staff meetings, yard duty, team meetings etc. All plans should be flexible, so that they can be adjusted throughout the practicum period.

**Evaluation**

Evaluation of practicum should be a separate item in the mentoring agreement. Some agreements, for instance, state that the student teacher during a mid-point evaluation will receive feedback on areas of strength and areas that need improvement. It might be beneficial to mention that the student teacher must show a will to change and develop and be prepared to tolerate honest feedback (from students, mentor and others). For instance, it could be stated that the student teacher must be able to constructively receive mentoring, and actively reflect on her own and other's teaching. Additionally, it should be mentioned that the mentor will be evaluating the student teacher. The evaluation will assess that student teacher's skills and aptitude for the teaching profession. The mentor will in addition write a report on the student teacher's practicum.

## Individual strategy document[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-4)]

A key principle in most theories on mentoring is to first and foremost consider the mentee's mentoring needs. In order to do this, it is recommended to create an individual strategy document. An individual strategy document is simply a memo that specifies the areas individual to the mentee where she wants or needs mentoring. There are few restrictions regarding format and content. The mentor should, however, encourage the mentee to be as specific as possible. For instance, she should avoid too many general phrases such as: “I want to focus on a sense of community in the classroom”, as they do not refer to specific situations. The individual strategy document does not necessarily need to describe a problem, but can be a question or an issue the mentee would like to reflect upon. The individual strategy document usually takes the form of a personal narrative and/or a personalized written lesson plan.

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/52/Interview.jpg/220px-Interview.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The mentor should not go about the mentor-mentee meeting as if it was an interview.

An individual strategy document makes it easier for both mentor and mentee to prepare for a mentoring session. The mentor should read the individual strategy document before the first mentor-mentee meeting, thus helping the mentoring process off to a good start. The mentor should not, however, go about the meeting as if it was an interview, where all the questions have been created beforehand. This would impede the mentee's prospects of presenting her own thoughts. While being prepared, it is important to free oneself from one's own notes and to let oneself be guided by the dynamic of the conversation (Carson and Birkeland 2009: 75-76).

In a mentorship conversation the mentor will be able to follow up on several different topics. In the early stages of mentoring it is therefore important that the mentee has time to develop her own thoughts. If the mentor focuses on one main topic right from the start, it makes it difficult for the mentee to bring up other topics in later conversations. The mentor is encouraged to use principles of [active listening](//en.wikipedia.org/wiki/active_listening) (Carson and Birkeland 2009:80).

### Written lesson plan[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-5)]

A written lesson plan is a document that is used to help prepare a particular lesson. A written lesson plan is often used in the mentorship conversation prior to the mentee implementing the plan in her teaching in the classroom. Prior to the lesson, the plan can form the basis of discussion between the mentor and the mentee. This will allow the mentee to reflect extensively on the classroom teaching that is to come and to evolve as a teacher. Working on a specific lesson plan makes it easier to focus on concrete topics in the mentorship conversation.

According to Nilssen (2010), many student teachers are of the opinion that planning documents are unnecessary and difficult to use. This applies to their form, required use and perceived lack of benefits. There are several reasons for this opposition. First of all, some student teachers claim that the mentors do not use such documents in their own teaching. The document is therefore not seen as an authentic planning tool. Second, some mentors claim that student teachers are not capable of filling out such forms in a satisfactory manner. Sometimes there are both student teachers and mentors who find it difficult to place the content in the various didactic categories. When asked about the lesson plan in a survey, a mentor named Sara expresses it like this: ''_After several occasions where the students expressed discontent and confusion about how to complete the documents they were required to use, I started to wonder: “What do I get out of this, and equally important, what do the student teachers get out of this?” (...)“_ (Nilssen 2010: 106-107). She considered the didactic relation model as having little to do with practicum, since the students did not get the opportunity to study examples of the model in actual use. Thus, she started filling out the document along with the students before lessons. She then thought out loud about her own teaching while asking questions of the students: What are we planning to do? Afterwards she started drawing. _“I drew circles and arrows while saying for instance, I have to remember which classroom to go to, are my students familiar with this subject matter, what have they learned previously, what are they going to learn now? - I drew while we talked – and we ended up with the didactic relation model”_ (Nilssen 2010: 107-108).

Even though many teachers do not use a lesson plan for their own teaching, one could suggest that this thinking has been internalized as [tacit knowledge](//en.wikipedia.org/wiki/Tacit_knowledge). The lesson plan is also meant to further the student teacher's didactic competence. Additionally, it can be used as a starting point for a pedagogical discussion regarding what the student teacher is thinking. A mentor who has actively used this kind of document with her student teachers explain:

_This spring my students handed in a lesson plan for “it's learning” two days before the lesson was to be held. I gave feedback that same evening. The day before the lesson we sat down with the lesson plan, where both my and the students' comments where written down. Everyone was responsible for reading the lesson plan and prepare. This lead to many useful conversations and input regarding theories etc. At the end of the practicum period the students expressed that this method made them work on a different level when planning. I realized that it was a good way to make the pre-lesson mentoring more useful on a professional level_ (Nilssen 2010: 109).

According to Nilssen (2010), however, many mentors claim not to know how to use the lesson plan. There is a danger that this planning document serve only as a ritual document. For instance, many student teachers hand in their documents too late for the mentor to be able to make changes before lessons. The students may also be opposed to the lesson plan because they merely see it as a document to be assessed by the mentor and not as as a learning tool (Nilssen 2010: 107-108). Another disadvantage is that some inexperienced students may follow the plan too strictly, the consequence being that the teaching becomes too rigid with less room for improvisation and adjustment of the plan during the course of the lesson.

### Personal narratives[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-6)]

The term “personal narrative” refers to a story from someone's professional life in a daycare, school or healthcare facility. The narratives describe central and selected episodes from the daily life of the organization. The individuals working in the facility tell the stories, and the stories are being told in ordinary language (Mørch 2004). They are told in the same chronological and logical order as the actual episodes. The narratives have a beginning, a culmination and an end.

A good personal narrative gives insight into a person's feelings, thoughts and values. When the narrative conveys specific episodes from day-to-day life, it can add life and zeal to our experiences. In addition, the narrative provides an opportunity to discuss ethical and moral dilemmas that face professionals in their daily work (Birkeland 1999; Mørch 2004). The complexity and dynamic of a situation are more easily recognized.

Some argue that personal narratives represent a different tradition of knowledge that the theoretical. A personal narrative refers to personal experiences from a work situation, but does not attempt to describe the experiences as objective reality. The personal narrative attempts to interpret the experiences. (Fennefoss & Jansen 2004). Personal narratives do not necessarily say anything about how reality should be, but consists of experiences that a participant or observer find significant in one way or another.

There are many different kinds of personal narratives: sunshine stories, success stories, routine stories, turning point stories, blunder stories, hero stories, problem stories, humour stories, exception stories. By using different kinds of personal narratives in a teaching context, we create different conditions for reflection. For instance, a turning point story is a story that turns established conceptions upside down and enables the narrator to develop new ways of thinking or to make new conceptions (Birkeland 2004).

Our understanding of the personal narrative builds on amongst others [Jerome Bruner](//en.wikipedia.org/wiki/Jerome_Bruner)'s idea (1986) that identity is created and maintained with narratives. He describes the narrative as an inherently different form of knowledge than paradigmatic rationality. Our knowledge about who we are, our personal abilities, values and principles are upheld by our self-stories. The life of an individual consists of a diverse landscape, made up of various acts and occurrences. These all bear witness of the person's abilities, values and experiences. Only a small part of these accumulated experiences end up as a part of the person's self-stories. Specific coherent occurrences are tied together by a plot. A plot can be considered an organizing dimension that transform occurrences into stories with a beginning, a middle and an end. This constitutes the story's core. When the narrator decides on a plot, she decides at the same time which aspects of the occurrence she wants to talk about and the interpretation she wants to give (Kvernbekk 2001).

Personal narratives can be used in different ways. Fennefoss and Jansen (2004; 2008) suggest that personal narratives can be a source for both insight and understanding, as well as a method for pedagogical documentation. The significance of a story does not lie in the fact that something happened, but the way it happened. By writing down the personal narrative we might be able to discern other perspectives and possible ways of handling a situation, and turn them into subjects of reflection and eventually new attempts.

A mentor in a daycare narrates: _Tore thought so much about what he stands for. I asked him to write a personal narrative based on an interaction with the children. Tore described a situation where a friendship between two girls was central. Some of the staff thought that the girls should be kept more apart, for instance by being placed at different tables during meals. Tore, on the other hand, had defended the friendship and tried to protect it. I asked Tore to explain why he thought the girls' friendship was so important. He quickly started talking about his own experiences with friendship and why he felt that friendship was so important. In the course of the conversation, Tore became more aware of the knowledge, experiences and values that were at the base of his actions_ (Carson and Birkeland 2009:73).

Birkeland (1998) refers to how personal experiences inspire mutual reflection among colleagues in the daycare. Susanne Mørch (2004) argues that the purpose of the personal narrative is to understand, develop or document the work situation in an organization. The personal narratives in this context are stories told by members of the staff, and written down so that the staff can use them to work on joint problem solving. When raising dilemmas, conflicts and concerns in the pedagogical work, colleagues will bring different perspectives to the table, and help us move on. When articulating a narrative from the workplace we also contribute to a joint reality.

Personal narratives are also used in various [action learning projects](//en.wikipedia.org/wiki/action_learning). In this type of setting, before writing down the personal narrative, teachers collect data using logs, videos, observations, interviews, etc. These are documenting acts and occurrences related to the topic. The personal narratives can then serve as a starting point for discussion and reflection on ethical and moral dilemmas in the pedagogical practice.

## Log writing in mentoring[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-7)]

A [logbook](//en.wikipedia.org/wiki/logbook) is originally a maritime tool used to record direction and variation in weather and wind conditions, as well as progression and other events. Originally, the logbook would contain short descriptions of central incidents and observation in the course of a day. The purpose of the log was to make this information available for other travellers.

As a research method, log writing has been used extensively within ethnography. Today we also find it within education. In this context log writing is used to support cognitive development. When writing academic texts students are faced with strict requirements regarding structure and content. Log writing is different in that it gives room for a greater degree of exploring. Nilssen (2010) refers to Torlaug Løkensgard Hoel who distinguishes between _spontaneous logs_ and _reflection logs_.

The spontaneous log deals for the most part with a specific incident or observation. The content is written down in the midst of the situation and the notes are often unstructured. The focus is on the person's feelings at the moment. It can be an expression of frustration or happiness. A student teacher describes the use of spontaneous log like this: _“There was no need for fancy expressions, which made the task less complicated and time-consuming. I used key words, complete and incomplete sentences, mind maps, forms as well as reflections tied to theory, or not”_ (Nilssen 2010:101).

The reflection log is written when time is more available. In this log we can continue working on episodes from the spontaneous log. We can add academic terms and relevant theory that will throw light on the episode, with greater reflective distance. The language in the reflection log is usually revised and has a more pronounced structure. The two kinds of logs therefore represent two different reflection levels (Nilssen 2010:101). A student explains the interplay between the use of the spontaneous log and the reflection log: _"Often when I look at old notes I notice how I was about to discover something that I had not yet understood. I can read between the lines or in my use of words and the issues that I raised that I was moving towards understanding. Often writing my thoughts down on paper made it possible for me to understand that I knew things I didn't think I knew"_ (Nilssen 2010:102).

At the same time, mentors have mixed experience with the use of logs. Nilssen (2010) refers to a mentor named Anna who finds it difficult to motivate all students to write a log and to make them see its usefulness. She asks herself several questions:

  * Is it necessary to give the log a specific structure?
  * What requirements should I ask regarding form and content?
  * Whose responsibility is it to provide instruction in log writing?
  * How do I motivate the student teachers to use different log structures?
  * To what degree should I have access to the writing?
  * Can too much access affect the log writing?
  * Should the other student teachers have access to the log writing?
  * What type of log gives the best base for reflection?

Anna's group of student teachers has mixed experiences with log writing. Two of the students had written every day and received feedback from their mentor once a week. They found it useful and were hoping to continue with the log writing. Another student wrote a log exclusively for herself. She did not understand its purpose. The fourth student published his logs in the group's online project room, where he received comments from both mentor and fellow students (Nilssen 2010:98).

The pedagogical idea behind log writing is that we develop a better understanding of a matter if we put our thoughts into words. Oral communication will make us aware of our thoughts, but it is through writing that we develop the skill to reflect systematically. We become more aware of what we do, and better at separating the essential from the nonessential in our daily lives. For a reader the log text can appear incoherent by reason of it being unfinished, informal, fragmentary and associative. The purpose of the log is to put thoughts into words. A student teacher describes her own writing like this: _"I knew beforehand that I had gained valuable experience from practicum and learned a lot. But I was not aware of what I had learned specifically. By writing and sorting my thoughts I was able to become more aware. This is crucial if the experience is to be of use later on”_ (Nilssen 2010: 100).

The log writing can help bring together theory and practical experience. For instance, the mentor can include the use of theory in log assignments. In addition, the log writing can contribute to a better communication between mentor and student teacher. The log will help the mentor understand the student teacher's thoughts and reflections. The mentor Sarah describes it like this: _"Even though we try to include everyone in the mentorship conversations, some have a tendency to hold back. That is when the log comes in. In their log writing the students tend to express themselves clearer, and we can use what they have written in the mentorship conversations. It is of course a prerequisite that they are okay with sharing their log writing. The logbooks often give me as much knowledge about the students as the mentorship conversations. I can se that Irene focuses on herself, she is describing her feelings and experiences. The same is true with Ina. Iver focuses on his role as a teacher – that is new for him. Erik is mostly concerned with small things that have not worked and that will need to be adjusted before the next lesson. Eli says a lot that shows that she sees the students and reflects on her encounter with them”_ (Nilssen 2010: 103).

In order for the log to become a useful tool in the learning process, it is important to give feedback to the student teachers. The feedback can widen the student teacher's perspective. Below are some examples of how a mentor can give feedback on the logs (Nilssen 2010:103):

  * Questions (“You say it is difficult, do you have any thoughts on how to go about it?”)
  * Refer to theory (“This is a good example of...” “You can read more about that...”)
  * Point to other alternatives, other ways of thinking, what do I as a mentor usually do? (“I understand that you find transitions difficult. With these students I find that it helps to...)

The type of feedback will depend on several factors:

  * What is the purpose of the text?
  * What are the requirements that the group has decided upon?
  * What is the purpose of the log? Who is the student teacher?
  * What kind of feedback will benefit the individual student teacher?
  * How much time has been set aside for this process?
  * Is the log accessible for everyone in the group?

Some student teachers feel insecure about log writing. The abovementioned points can therefore be discussed with the mentee in order to get a common understanding of its purpose.

To get the most out of log writing it is a good idea to share the logs with fellow students. Online file sharing has made this easier. With shared logs students have a place to get advice and vent frustration, while also having access to a source of professional knowledge and development. With this kind of openness challenges are easier to share and are made less private. On the other hand, some may consider an open log difficult or threatening. A student puts it this way: _"I see the advantage in addressing my thoughts through a log, but I find the idea threatening that others can read about what I feel that I don't master. It is difficult when one is doing the practicum and is a person that likes to excel"_ (Nilssen 2010: 104). One mentor has therefore let the log sharing be optional: _“The logs don't necessarily have to be accessible. With some groups of student teachers I have made it optional. In some cases, if the logs are very personal, I let the communication regarding the log be solely between the student and me. I have for instance a young student who is struggling with reading and writing difficulties, and who because of this has struggled with self-esteem. Our goal was that she in her 2nd year would dare to publish her logs in the online sharing room"_ (Nilssen 2010: 104).

## Sources[[edit](/w/index.php?title=Mentor_teacher/Written_reflection_tools_in_mentoring&action=edit&section=T-8)]

  * Baltzersen, Rolf K (2007). IKT - mirakelkur eller tynn suppe? En kritisk analyse av sentrale teknologibegreper innenfor skolefeltet. Halden: Høgskolen i Østfold (HiØ. Rapport. 2007:9). Rapport
  * Baltzersen, Rolf K (2007). Digitale fortellinger i skolen (Versjon april 2012). Mainz: PediaPress (121 sider). PDF-versjon
  * Carson, Nina og Åsta Birkeland (2009). Veiledning for førskolelærere. Kristiansand: Høgskoleforlaget
  * Birkeland, L (1998). Pedagogiske erobringer. Om praksisfortellinger og vurdering i barnehagen. Oslo: Pedagogisk Forum
  * Birkeland, L. (2004). Fortællinger som fænger og fanger. Praksisfortællinger og personaleudvikling i børnehaven. Mørch, Susanne Idun (Red.). Pædagogiske praksisfortællinger. Systime Academic.
  * Bruner, J.S. (1986). Actual Minds, Possible Worlds. Cambridge, MA: Harvard University Press.
  * Bruner, J.S. (1990). Acts of Meaning. Cambridge: Harvard University Press.
  * Czarniawska, B. (2004). Narratives in social science research. London: Sage.
  * Epston, D.; White, M. & Murray, K. (1992). A Proposal for Re-authoring Therapy: Rose's Revisoning of her Life and a Commentary. McNamee, S. & Gergen, K.J. (Red). Therapy as Social Construction. London-Newbury Park-New Delhi: Sage Publications.
  * Fennefoss, A.T. & Jansen, K.E. (2004). Praksisfortellinger – på vei til innsikt og forståelse. Bergen: Fagbokforlaget.
  * Fennefoss, A.T. & Jansen, K.E. (2008). Småbarnspedagogikk og praksisfortellinger. Bergen: Fagbokforlaget.
  * Gergen, K. & Gergen, M. (2004). Social Construction: Entering the Dialogue. Chagrin Falls, Ohio: Taos Institute Publications.
  * Kvernbekk, T. (2001). Is this a narrative? Vol. nr 66/2001: Lillehammer: Høgskolen på Lillehammer.
  * Labov, W. (1972). Language in the Inner City. Philadelphia: University of Pennsylvania.
  * Lundby, G. (1998) . Historier og terapi. Om narrativer, konstruksjonisme og nyskriving av historier. Oslo: Tano Aschehoug
  * Mishler, E.G. (1999). Storylines: Crafts artists’ narratives of identity. Cambridge: Harvard Univ. Press.
  * Morgan, A. (2005). Narrative samtaler. København: Hans Reitzels Forlag.
  * Mørch, Susanne Idun (2004). Pædagogiske praksisfortællinger. Systime Academic.
  * Nilssen, V. (2010) Praksislæreren. Oslo: Universitetsforlaget.
  * Polkinghorne, D. E. (1995). Narrative configuration in narrative analysis. I A.J. Hatch & R. Wisniewsky (Eds.). Life, History and Narrative. London: The Falmer Press.
  * Rasmussen, J. (2004). Undervisning i det refleksivt moderne: Politik, profession, pædagogik. Hans Reitzels Forlag.
  * Ricoeur, P. (1984). Time and Narrative. London: The Falmer Press.
  * Riessman, C. K. (2008). Narrative methods for the human sciences. Thousand Oaks: Sage.
  * Rogoff, B. (2003). The Cultural Nature of Human Development. Oxford: Oxford University Press.
  * Winslade, J.M. & Monk, G.D. (2008). Narrativ vejledning i skolen. Corwin Press Inc. & Dansk Psykologisk Forlag.
  * White, M. & Epston. D. (1990). Narrative Means to Therapeutic Ends. New York: Norton.
  * White, M. & Morgan, A. (2007). Narrativ terapi med børn og deres familier. København: Akademisk Forlag.
  * White, M. (2006). Narrativ praksis. København: Hans Reitzels Forlag.
  * White, M. (1995). Re-Authoring Lives. Adelaide, Australia: Dulwich Centre Publications.

# Observation in mentoring[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=4)]

## What is observation[[edit](/w/index.php?title=Mentor_teacher/Observation_in_mentoring&action=edit&section=T-1)]

There is a big difference between seeing and observing. Observing is watching something or someone in a particularly attentive manner. In first-order observation the observation itself is the main task (Bjørndal 2002). This can for instance be a student teacher observing a lesson.

Good observation can be challenging. Student teachers may choose a focus that is too broad. For instance, they might try to observe too many students at a time. In order to refine the focus of observation, they will need the mentor's help. If the aim is to observe the collaboration between students in a classroom, some indicators of collaboration should be established in advance (Nilssen 2010).

There are two different kinds of observation methods: unsystematic and systematic. Unsystematic methods can be used to create a first impression that will help us decide what we want to focus on. With systematic methods the observation is planned and we focus on specific activities. We can use an observation form or other kinds of running records to write down observations. Observations can be written down during a situation, immediately after a situation, or a combination of during and after.

There is a difference between the description of an observation and its interpretation. One idea is to create an observation form and divide it into two columns: one column of what we see and the other column of what we think. If we want to know what a particular student spends her time doing, we can make note of an activity at a particular time. If we want to know about the prevalence of a particular behaviour, we can make a note on a form every time this behaviour occurs (Nilssen 2010).

The learning potential is greater if the student teachers create the observation forms themselves instead of simply copying them from a book. Their attitude towards the observation changes, and they get a chance to practice how to refine their focus.

Other things to consider regarding observations are: where the observations should take place (outside or inside?), and how long the observations should be. An observation of interplay processes will take longer than for example charting a student's reading level. A year's observation of a student's reading development is a long stretch of time, but every single observation does not necessarily take long. It is important to remember that the time available is limited (Nilssen 2010).

We need to be aware that bias may influence the observations. For instance, Nilssen (2010) argues that there are commonly norms in daycares and schools that emphasize the positive. The student teachers also tend to seek out positive relationships, and consequently have a more positive than negative attitude. Furthermore, we have a tendency to remember the first and last impression of the people we meet. It is easy to generalize these observations and give them too much weight. Finally, the observer's previous experiences and prejudice will influence what we see.

## Observation in mentoring[[edit](/w/index.php?title=Mentor_teacher/Observation_in_mentoring&action=edit&section=T-2)]

According to Nilssen (2010) observation is a central part of a teacher's daily job, and a prerequisite for the exercise of the teaching profession. It is therefore imperative that the student teacher develop observation skills that enable her to see the individual student. In order to teach children we need to learn from them. We need to know who the children are, how they think and feel, how they cooperate and develop knowledge in different fields. Through observation we develop a more varied picture of the students. Additionally, observation can be used as a documentation method, for students in education working on written assignments.

Beginning teachers tend not to see how different their students are. The mentor Sara finds that new student teachers hardly see the difference between students and subject matter. They often take on the role of a teacher who is merely there to transfer knowledge. However, if the student teachers get to observe the students, they will be able to see the class as a group of individuals who are entitled to challenges and possibilities adapted to their level and pace of learning. Sara stresses the importance of the student teachers not only observing the students, but that they also talk to them and get to know them (Nilssen 2010). The following is an example where a student teacher has observed a student:

_"I found the observation of Per and Jan particularly interesting. Per started out by being the first to guess the name of a hexagon. This made him more certain of himself, and he started enjoying the game more as he felt that he mastered something. In the end he was very eager and finally won the game. For the first time since I came to this class I noticed that Per was among those who were in control! It was fun to see. After they finished the game, they started embroidering. As usual, Jan had some problems with this activity. I suggested that perhaps Per could teach him how to do it. Per, who was still excited that he had done better at the game than the others, immediately took on this challenge and taught Jan to embroider in no time! Both of them were very proud of this accomplishment, and while Per sat there with a big smile on his face and was pleased with himself, Jan went over to Mari to show her what he had made. It was exciting to see two different ways of showing how they were proud of themselves._

_I have many thoughts about this; how important self-esteem is for learning, how much the students can learn from each other, how many roles a student can inhabit etc. I have to absorb these impressions before I can elaborate any further, but I have to say that it was a really fun and exciting experience. It was obvious how Per blossomed when he felt that he mastered the game, and he performed better than I have ever seen him perform before. I think that a feeling of success has implications in other areas as well”_ (Nilssen 2010:117).

Nilssen (2010) argues that it is important for student teachers to observe teaching practice and in particular the interaction between teacher and student. They need to see how students learn. Otherwise they risk concentrating solely on keeping discipline in the classroom, not on ensuring that the students learn. If they do, their focus will be on how they themselves perform, not on the teacher-student interaction.

It is worth noticing that Eli, one of the student teachers, feels that what she has learned the most from during practicum, is observing the interaction between Sara, her mentor, and the students in the classroom. Eli notices that the students are not holding back as much when Sara is there. This is particularly apparent when they are doing mathematics, where a lot of students often have performance anxiety. For Sara it is important that the student teachers watch her teach. She knows that she is a role model, but she makes it clear that she does not want to force a particular teaching style onto them (cf. the importance of talking about the conversation in mentoring). Sara wants the student teachers to not only observe her, but also other mentors with different teaching styles. Within the apprenticeship model, there is an emphasis on the observation and imitation of experienced professionals.

It is important to preserve the integrity of the persons we are observing. This is particularly important with children. When systematically collecting data over a long period of time we need the permission of parents or caregivers. Parents or caregivers should also be made aware that the student teachers have signed an agreement of confidentiality. Observations done in connection with the theoretical part of the education, should be anonymous right from the start (Nilssen 2010).

## Sources[[edit](/w/index.php?title=Mentor_teacher/Observation_in_mentoring&action=edit&section=T-3)]

  * Nilssen, V. (2010) _Praksislæreren._ Oslo: Universitetsforlaget.

# Oral reflection tools in mentoring[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/FN_Marktfrauengruppe_6.jpg/220px-FN_Marktfrauengruppe_6.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Active listening is important

Good conversational skills are important in any kind of mentoring. According to Kristiansen (2008: 36-37), mentoring requires the mentor to use appropriate linguistic techniques to assist both with how to ask the mentee questions and how to answer her questions. Use of appropriate linguistic techniques by the mentor will have a positive impact on the mentee's development. In this book we describe four different skill areas that a mentor should be familiar with.

The most important conversation skill is the ability to listen. This book discusses listening skills with reference to the “active listening” concept that has been academically developed. Metacommunication is a second important conversation skill (Baltzersen 2008). By finding better ways to “talk about the conversation” the mentorship conversation is made more efficient and systematic. The final two skills are with respect to the giving of advice and how and when confrontation is appropriate during mentoring. Many mentors struggle with whether giving advice is the right thing to do and secondly to what degree should they confront a mentee. The last point on confrontation is important as many mentees perceive their situation as one of vulnerability.

Many of the conversational skills presented in the literature on mentoring were inspired by the literature on the use of conversational skills in therapeutic settings. This book seeks to identify the most important of these skills.

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/81/Martin_Buber_portrait.jpg/220px-Martin_Buber_portrait.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The philosopher Martin Buber developed the idea that human beings will always be in an I-It or an I-You relation

We must be aware that too much focus on conversational skills or techniques can impede authenticity in a mentorship conversation. The mentor needs to pay constant attention to ensure her conversational techniques are not interfering with her having a dynamic, open and assured conversation with the mentee. In his book “I and Thou” (1967), [Martin Buber](//en.wikipedia.org/wiki/Martin_Buber) writes that a person can not be understood as an isolated “I”. Human beings will always be in an I-It relation or an I-You (Thou) relation. These different relations indicate different ways of relating to the world. In an I-It relation we relate to the world and other human beings with distance or control. We describe, analyze, define, create diagnoses and compare. A person is described as an “exemplar”, a “thing”, an “object”, a “potential” or a “resource”. We will quickly make up our mind whether the mentee is interested and engaged. In an “I-It” relation we see the mentee in light of what we already know about the person. In an I-You relation, on the other hand, we will always be confronted with the fact that the other person is different than expected or what we thought we knew about her (Kristiansen 2009).

The skilled mentor knows how to use the mentoring tools, what kind of effect they will have, and when to use them. Some mentors, but far from all, inform the mentee at the start of their relationship that specific conversational techniques will be applied. The danger in not letting the mentee know, is that she might refuse to participate in future mentorship conversations if she becomes aware that the mentor uses hidden conversational techniques. Kristiansen (2008) argues that this can interfere with the reciprocity in the mentor-mentee relation. Conversational techniques can be perceived as strategies to ensure that one of the parties gets control of the conversation.

Based on these considerations, we have attempted to include conversational techniques in a broader pedagogical context. This pertains to the presentation of both “active listening” and “to talk about the conversation”.

  


## Sources[[edit](/w/index.php?title=Mentor_teacher/Oral_reflection_tools_in_mentoring&action=edit&section=T-1)]

  * Baltzersen, Rolf K (2008) _Å samtale om samtalen_. Bergen: Fagbokforlaget.
  * Kristiansen, Aslaug (2008). Hva skiller en veiledningssamtale fra andre samtaler? : Veiledningssamtalens egenart og etiske utfordringer. I Eide, Solveig Botnen, Grelland, Hans Herlof, Kristiansen, Aslaug, Sævareid, Hans Inge og Aasland, Dag G. (red.) _Til den andres beste : En bok om veiledningens etikk_ s. 24-40. Oslo, Gyldendal akademisk.
  * Kristiansen, Aslaug (2008). “Hva hører du når du lytter? Hvem blir du når du svarer?” I Eide, Solveig Botnen, Grelland, Hans Herlof, Kristiansen, Aslaug, Sævareid, Hans Inge og Aasland, Dag G. (red.) _Til den andres beste : En bok om veiledningens etikk_. Oslo, Gyldendal akademisk.
  * Lauvås og Handal (2000). _Veiledning og praktisk yrkesteori_. Oslo: Cappelen Akademisk forlag.

# To talk about the conversation in mentoring[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=6)]

## What does it mean to metacommunicate?[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-1)]

Verbal [metacommunication](//en.wikipedia.org/wiki/meta-communication) is a form of communication where we talk about and analyze an ongoing conversation by taking a step out of it. In this article we discuss different ways to metacommunicate in professional mentorship conversations.

At first, metacommunication resembles an ordinary conversation in that it has a content, a dialogue form and a time frame. Baltzersen (2008) argues that we can start out by asking the following three questions:

  * What do we metacommunicate about?
  * How do we metacommunicate?
  * When do we metacommunicate?

With regard to the “what-dimension”, Baltzersen (2008) argues that the metacommunicative content can be divided into three subcategories. Firstly, we can _talk about the conversational content_. This is not the same as the fact that all conversations have a content; we don't always make the _content of conversation_ into a _subject of conversation_. For instance, the mentee might say: _"We have talked so much about the structure of my thesis, perhaps we could proceed to discuss my choice of theory?”_ The focus is not on subject matters, but rather on conversation subjects to discuss during mentoring.

Secondly, we can _talk about the conversational relationship_. How well does the conversation work? Some examples: “I think we should talk more openly” (nearness/distance), “You don't have to tell me what to do!” (symmetry/asymmetry). We can also comment on other people's behavioural communication: “Why do you need to be so harsh when talking to me? (evaluation of the other), “I guess I seem a little uncertain when I talk to you” (evaluation of oneself).

Thirdly, we can _talk about the use of conversational time_. This can be done in different ways, for instance by discussing how often the conversations should take place: “Perhaps we could meet more often?”, speaking order: “I would like to speak first this time,” length of conversation: “I'm running out of time, can we make this conversation as short as possible?” or speed: “I have another meeting to go to, you will need to get to the point.” Below is a chart showing how we can categorize various metacommunicative statements and questions based on Baltzersen's (2008) definition.

**Example** **What can we metacommunicate about** **How can we metacommunicate** **When can we metacommunicate**

_“How would you sum up the conversation; what did we agree on?”_
To talk about the conversational content
Dialogical
The past conversation

_“Do you constantly have to tell me what to do?”_
To talk about the conversational relationship (symmetry-asymmetry)
Monological
The past conversation

_“Yes, Per, if I understand you right, you would like advice on how to handle some of the more difficult students in your class. You are disappointed that they are so disruptive.”_
To talk about the conversational content (paraphrase)
Monological
The “here-and-now” conversation

_“What do you mean by saying that?”_
To talk about the conversational content
Monological
The "here-and-now" conversation

_“There are many questions that are difficult to put into words. You simply feel uneasy. Remember that you don't need a well formulated question in order to come talk to me (...)”_
To talk about the use of conversational time (degree of accessibility)
Monological
The future conversation

Furthermore, writing can be used as a tool when talking about the conversation. We can for instance make an appointment, write a summary or write an individual strategy document.

In the literature on mentoring it is commonly recommended that the mentor and mentee enter into a written cooperation agreement early on in the mentoring process (see for instance Nilssen 2010). Such agreements can be of varied content, form and length. Some institutions that offer mentoring have also created a general template with suggested topics to include in the agreement.

The advantage of this kind of agreement is that both parties get a chance to present their expectations. If the agreement is specific, one is more likely to avoid misunderstandings later on. Furthermore, the agreement makes it easier to stay professional when faced with sensitive subjects. By making an agreement, the collaboration will likely feel more binding. Besides, by putting more in writing the systematic reflection in the mentorship conversation is strengthened.

## Different types of strategic metacommunication[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-2)]

In professional mentoring there are different ways to metacommunicate. Some of them are:

  * To talk about the professional form of communication
  * To talk about the mentoring relationship
  * To ask questions that will clarify a conversation
  * To sum up the mentorship conversation
  * To talk about what not to talk about

### To talk about the professional form of communication[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-3)]

In mentoring, an interesting question of principle is who should decide the topics of discussion. Carson and Birkeland (2009) argue the importance of talking about the mentoring pedagogy that will guide the mentoring. A reason for this is that almost all mentees want to get advice (ibid: 37). Many would like the mentor to make choices for them, and they get frustrated when she does not immediately want to do this. By talking about mentoring pedagogy, it is easier to avoid the frustration that emerges because of this.

Carson and Birkeland (2009: 126) are also of the opinion that the choice of mentoring method should build on an informed consent from the mentee. If the mentee decides against a specific mentoring approach, this decision should be taken into account. In this context one could imagine a dilemma if the mentee asks the mentor to use other mentoring methods than the one that the mentor prefers. Nilssen (2010) also argues that it is beneficial to decide on a common understanding of the mentoring early on.

Traditionally, the mentee has been able to choose the conversation topics, while the mentor has chosen the form of mentoring. Carson and Birkeland (2009) question whether this is the best way to achieve the desired results. Empirical research shows that students who want a particular form of communication in mentoring not necessarily ask for it. A survey conducted by Baltzersen (2008) shows that among students who find metacommunicating in mentoring important, only around half of the students in fact use this kind of communication. The reason is likely that the students see it as the mentor's responsibility to take the initiative in talking about mentoring. A survey by Lauvås and Handal (1998) provides an example of this:

**Example**  
A student gives the following answer to whether she talks about mentoring:

  * Student: We could have done it. There is no reason not to do it. When we don't, I feel that it is the mentor's responsibility to take the initiative.
  * Interviewer: Why is it that you will not do it?
  * Student: I see it as being her work method – if she had a work method in her mentoring structure, I think she should be the one to communicate it.

(Lauvås and Handal 1998: 209)

### To talk about the mentoring relationship[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-4)]

According to Nilssen (2010) feelings will always determine how we relate to each other. This is also the case in mentoring. It can sometimes be appropriate to talk about the mentorship relation. A mentor explains: _“In my group of mentees there was a person taking the lead, who was very keen on speaking during the mentoring sessions. Another student would speak only when asked to. We discussed this. Was this how we wanted our sessions to be? Should everyone contribute? What did we want? The quiet student said that she would like to speak more, but that she didn't feel good at expressing herself orally. We agreed that everyone should speak with the skills we had.”_ (Nilssen 2010:82)

We can also talk about a potential disparity between conversational content and communication behaviour. For instance: “You say that you are happy, but to me you look upset.” It is sometimes necessary to metacommunicate when the mentee is showing discontent with the use of body language.

### To ask questions that will clarify a conversation[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-5)]

As mentors we ask ourselves questions in the midst of the mentorship conversation: “am I challenging her too much?”, “are we going in circles?”, “are we moving forward with the conversation?”, “what do we avoid discussing?” This kind of thinking often takes place solely inside the mentor's head, but it influences the direction the conversation is taking and the questions that are being asked. Sometimes we can discuss such topics (Carson and Birkeland 2009: 81). By throwing light on a conversation, these questions can contribute to clarify ambiguities and clear up misunderstandings in the mentorship conversation. Below are some examples:

  * “I understand that we disagree, but I am certain that I know what you are thinking when...”
  * “I don't understand what you mean by...”
  * “I get a little uncertain when you put it that way.”
  * “I wonder if I said something wrong.”
  * “Do you mean that...?”
  * “Do you think that we should rather...?”
  * “I would like to talk to you about the... I wonder if I have misunderstood.”
  * “If we talk it over a little more, perhaps we could...”

(Carson and Birkeland 2002:98)

### To sum up the mentorship conversation[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-6)]

It is usually recommended to sum up the mentorship conversation by agreeing on the main points that have been discussed. The summary should not be too extensive. It can also be beneficial to start every conversation by summarizing the last conversation. The summary can give both parties some time to reflect on the status of the situation and the way ahead (Carson and Birkeland 2009: 83-84).

The summary can be done in writing. Carson and Birkeland (2009: 127) refer to what they call an “experience memo”, which focuses on the mentee's experience of an incident. Through writing, the mentee may become aware of thoughts and feelings she was not previously aware of. If a mentor asks a mentee to write an experience memo, the memo can be used as a basis for the next mentoring session. The experience memo can also be used as a basis for a dialogue around a specific situation. We sometimes wonder how two people can give such different descriptions of the situation. Here are two experience memos written by students in early childhood education during practicum (Carson and Birkeland 2009: 100):

  * **Ole's experience memo:** Kari and I are mentored by the same mentor. This conversation turns out to be very interesting. We discuss an interaction we had with one of the children the previous day. Both Kari and I were present. The mentor asks me some challenging questions that make me think about the interaction in a way that I have not thought about it before (ibid: 100).
  * **Kari's experience memo:** I am being mentored along with Ole. We are supposed to talk about an episode that we have previously experienced. Ole and I choose a situation involving a conflict with a child who refuses to put on rain gear. We had observed this conflict between the child and an assistant. The mentor asks a lot of questions, but does not offer one single explanation as to why the child reacted the way it did (ibid: 101).

### To talk about what not to talk about[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-7)]

As part of the talk about the conversation, we should talk about what we should not talk about. Here is an example: _"(...) In the subsequent metaconversation we discuss that the student could perhaps seek help in clearing up the relationship to her mother. I tell her that the processing of the relationship to her mother should not be a topic in this mentoring. But the way this relationship affects her today is a topic that we can discuss during mentoring"_ (Carson and Birkeland 2009: 99).

## Empirical research on the value of metacommunication[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-8)]

There is little empirical research on the existence of verbal metacommuncation in mentorship conversations. One exception is Baltzersen (2008) who has analyzed data from a 1999 survey of master students writing a master thesis (the mentor-mentee relationship usually lasts a minimum of one year). The results showed that few students spoke regularly with their mentor about mentoring. Approximately one third did it only in the beginning of mentoring, while more than half never did it at all. Furthermore, the survey shows a strong positive statistical correlation between the degree of metacommunication and the perception that the communication is good. Regular conversations about the conversation conflicts appear to prevent conflicts. In another interview survey Lauvås and Handal (1998) conclude that a greater degree of metacommunication in research mentoring (individual mentoring of students) is central to improving the quality of mentoring. Agreeing on the nature of the mentor-mentee relationship can prevent an unnecessary complicated situation where both parties have to interpret the other person's signals directly.

## Sources[[edit](/w/index.php?title=Mentor_teacher/To_talk_about_the_conversation_in_mentoring&action=edit&section=T-9)]

  * Baltzersen, Rolf K. (2008): _Å samtale om samtalen. Veiledning og metakommunikasjon._ Bergen: Fagbokforlaget.
  * Carson, Nina og Åsta Birkeland (2009). _Veiledning for førskolelærere_. Kristiansand: Høgskoleforlaget.
  * Nilssen, Vivi (2010). _Praksislæreren_. Oslo: Universitetsforlaget.
  * Lauvås, Per og Gunnar Handal (1998): _Hovedfagsveiledning ved Universitetet i Oslo_. Oslo: Pedagogisk forskningsinstitutt, Universitetet i Oslo. (Rapport nr.1)

# Active listening[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=7)]

## What is active listening?[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-1)]

Since the 1960s there has been a lot of focus on the therapist's conversational skills. The ability to demonstrate active listening skills is now considered to be important. The communication technique of active listening includes both non-verbal skills such as body language (e.g. eye contact, movements, distance, etc.) and verbal skills. The ability to demonstrate empathy is central. For example, Bjørndal (2011) refers to Clark (2007) who claims that a substantial body of empirical evidence from professional counselling research proves the importance of empathy to the field. Carson and Birkeland (2009: 126) believe that active listening should be part of any approach to mentoring.

## Conversational techniques related to active listening[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-2)]

A mentor who wants to be an active listener must focus on understanding what the mentee is saying. The mentor must strive to be present with the mentee. We can select from the literature on active listening a few techniques that can be useful teaching aids to the mentor. Some examples are:

### Paraphrasing[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-3)]

Paraphrasing requires that you as a mentor try, in your own words, to repeat back to the mentee what you have heard. This will often contribute to the mentee opening up. The goal is to motivate the mentee to clarify her arguments and hopefully obtain an increased insight into her own challenges. This technique may also prove to the mentee that the mentor is in fact listening carefully to what she is saying.

In active listening there are several types of paraphrasing. A basic strategy is repeating key words from what the mentee is saying. It could be the last word uttered, or another particularly interesting word. It could be done in a questioning or inquisitive way. For instance if the mentee is saying: “it is about points of view”, the mentor could repeat “points of view” in an inquiring tone of voice. In this way the mentor is showing that she is listening carefully to the mentee. In addition, the mentee is encouraged to continue to reflect.

Summarizing is similar to paraphrasing in that both methods involve an attempt to repeat aspects of what the mentee has said. Summarizing, however, encompasses a lengthier time period. In a summary, the mentor will try in her own words to repeat what the mentee has talked about over an extended period of time. Here are some examples of typical formulations:

  * “you tell me that...”
  * “do I understand you right when you say...”
  * “am I right?”

Lauvås and Handal (2000) claim that paraphrasing is the most important conversation skill in the mentorship conversation. However, few mentors are skilled at this. Geldard (1989) in Lauvås and Handal (2000) defines paraphrasing as the mentor extracting the most important details from what the client is saying, and trying to express them in a clearer way in his own words. The mentor attempts to select the essential elements of what the client is expressing, and reflects this in turn back to the client (Geldard 1989:25).

In using this definition as a starting point, Lauvås and Handal (2000) maintain that paraphrasing is not really about repeating what has been said, but rather understanding and interpreting the meaning behind what has been said. At times, for instance when the mentee is losing the thread, it may be appropriate to give the most precise rendering possible. Repetition, however, can irritate and fail to advance the conversation. Conversely, if the interpretation done through paraphrasing is not close enough to what she has said, there is a risk of confusing the mentee. The objective of paraphrasing is to encourage the mentee to keep reflecting. Success in paraphrasing occurs when the mentee accepts the paraphrase as being the essence of what has been said, thus furthering the mentee's own thinking. Wheeler and Birtle (1993:33-34) maintain that paraphrasing can serve three main purposes:

  * Documenting that the mentor has payed attention and understood the essence of what has been communicated.
  * Assisting in allowing the mentee to correct the mentor's understanding of what was being expressed in the conversation.
  * Allowing to think the conversation through, either by proceeding with the next point or by spending more time on the point at hand.

The initial challenge is to get the mentee to talk. The mentee could be insecure, and reluctant to be open about the topic under discussion. She could be embarrassed because she finds that something is unclear. She could be concerned about what the mentor thinks of her (i.e. that she is not professional enough). The mentor may be tempted to give advice about topics and questions that have come up. Many mentees, however, are more in need of help organizing their own thoughts than they are of words of advice.

It is important to listen carefully and try to understand the underlying intention of the mentee on occasions when the mentee is not capable of formulating his or her thoughts. The purpose of paraphrasing is to help the mentee to clarify her own concept, and not to simply import the mentor's ideas. In paraphrasing, one could try to clarify a concept that the mentee is looking for. This may for instance be appropriate when the mentee is saying “I am not capable of explaining this further” or “Now I feel that I might be on to something” (Lauvås and Handal 2000).

### Open questions[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-4)]

The question as a linguistic act, can be a powerful tool. We have great difficulty not answering a question that has been asked. To ask a question is therefore also a powerful way to control a conversation. In active listening, the open question rather than the closed question is recommended. An example of an open question is “How did you get here?”, while a similar closed question would be “Did you get here by bus?”

When immersing oneself in a new subject matter, it is easy to make assumptions about what the subject matter entails. One starts asking questions to confirm or refute these assumptions. Closed questions are not recommended for several reasons. The answers to closed questions are usually short. To get the desired information, one will have to keep asking questions, and the process will be much longer. In addition, the mentor will define the subject of conversation and the direction the conversation takes. The mentor therefore decides what is central and relevant based on her own perspective (Lauvås and Handal 2000). By asking open questions, on the other hand, the mentee is invited to elaborate on what she has said:

  * “Could you elaborate/explain”,
  * “You said... could you please tell me more about that?”,
  * “You mentioned the word..., what do you mean by that?”, “I did not understand what you meant when you described...”,
  * “Could you repeat that?”,
  * “Which pros and cons...?” (See more about this in the article “To ask questions”)

Open questions will encourage the mentee to provide more information. Such open questions can, for instance, be used after an explanatory introduction: “I wonder if you could say a little more about what you wrote in the memo”. Still, it would not be correct to say that all open questions are good while all closed questions are bad. The questions must be adapted to the situation. In some situations closed questions work better than open questions.

Lauvås and Handal (2000) cite three different types of open questions that are of importance in the mentoring context:

  * Follow-up questions – These questions are used to clarify concepts in a more thorough manner.
  * Topic changing questions – These questions can be used when it is necessary to elaborate on a topic that the mentee has not yet touched upon. Questions of this type introduce new topics of discussion.
  * Acknowledging questions. After providing advice or suggestions, the mentor should return the initiative to the mentee. An example is: “What do you think of this?” Questions of this kind should be open and neutral (non-leading) questions.

According to Lauvås and Handal, the following are examples of poor questions:

  * We ask two questions in one sentence or phrase.
  * We ask convoluted questions.
  * We comment rather than ask.
  * We display bias.
  * We ask questions that are overly complicated (Lauvås and Handal 2000).

They stress the importance of the mentor not asking too many questions. Too many questions may lead to the conversation resembling question period, or even worse, an interrogation. The mentee might in this scenario find it more difficult to open up and would consequently talk less. She might soon await new questions, instead of taking the initiative in the conversation. Thus, the mentor is in danger of leading the conversation to such a degree that it limits the mentee's ability to raise the issues that she is truly preoccupied with. Geldard maintains that anything that contributes to the mentee leading the conversation is positive, given that the mentee is expecting the supervisor to lead the conversation.

In the literature on mentoring, why-questions are usually discouraged. Instead, one should begin questions with when, where, what, who and which. Why-questions can quickly be interpreted as an accusation, i.e. that the person is doing something wrong, resulting in the mentee becoming defensive. For instance, many students have experience with teachers asking why-questions following an incorrect answer. The teacher's purpose with asking the why-question is to get the student to try again. The why-question is a consequence of a basic pattern of communication in the classroom (according to IRE communication patterns in the classroom (Lauvås and Handal 2000).

### Support through non-verbal communication[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/db/The_Gaze.jpg/220px-The_Gaze.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Eye contact has always been important in communication between people

Geldard (1989) emphasizes the importance of being attentive as a basic conversation skill. The mentee should feel that the mentor is interested in the conversation. This is not a technical skill, but rather a prerequisite to be able to act as a mentor.

Below we discuss certain common external characteristics associated with attentiveness towards the mentee. These are sometimes called minimum responses. Minimum responses are usually related to a person's body language.

Examples are using words like “yes” “okay” “hmm”, or nodding one's head. The mentor is showing interest by using these minimum responses. However, these responses should only be used to a degree – over use could make the mentee doubt that the mentor is paying attention and interested in what she has to say.

Eye contact is another minimum response. Without it, the communication between two people might suffer. At the same time, staring at people during a conversation can have negative effects. One can be perceived as being intrusive and invasive, and showing the other too much attention. On an additional note, Lauvås and Handal (2000) explain that an overemphasis on minimum responses could make the conversation seem rehearsed. It could easily move the focus on to the more technical sides of the conversation. An overemphasis could move the focus away from the substance of the conversation.

### [Mirroring](//en.wikipedia.org/wiki/Mirroring)[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-6)]

Mirroring happens when the mentor interprets the mentee's feelings by attempting to describe them:

  * “You sound very upset, did something happen?
  * “Listening to what you say, I hear that you are proud of succeeding!”

Mirroring is an important conversational technique in therapy. The well-known psychologist Carl Rogers believed that the therapist should mirror good behaviour. In a video presentation he says the following regarding his relation to his female client: “If she is understood by me, she will be better to understand herself?”, “If she feels that I am authentic, she will feel authenticity in herself”. (Quote – finne originalen). Rogers is of the opinion that the therapist must mirror good behaviour, because she is a role model for client.

## Historical background of active listening[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-7)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Carl_Ransom_Rogers.jpg/220px-Carl_Ransom_Rogers.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Carl Rogers

Historically, active listening has been associated with Carl Rogers. Rogers established the client-centred therapy (also known as person-centred therapy). This form of therapy has been very influential for psychology as a field and also for mentoring. The client-centred therapy came into existence as a reaction towards the deterministic view of human beings in behaviourism [wikipedia link] and psychoanalysis. With his humanistic approach, Rogers is speaking of the treatment of the human being as an object with a free will. In sharp contrast, the behaviourist school of thought maintained that the therapist should direct human behaviour by using various rewarding techniques. This approach is perhaps best illustrated by the well-known quote by the founder of behaviourism, John B. Watson [wikipedia link]: “Give me a dozen healthy infants, well-formed, and my own specified world to bring them up in and I'll guarantee to take any one at random and train him to become any type of specialist I might select – doctor, lawyer, artist, merchant-chief and, yes, even beggar-man and thief, regardless of his talents, penchants, tendencies, abilities, vocations, and race of his ancestors.”

Within [psychoanalysis](//en.wikipedia.org/wiki/psychoanalysis), the reflections of the patient are emphasized, but it is assumed that human beings are driven by instincts. The therapist or the psychoanalyst is the only person who knows the interpretative framework, and is the only one who can determine the real reasons behind the patient's problems. The problems usually have their origin in childhood experiences.

[Client-centred therapy](//en.wikipedia.org/wiki/Client-centred_therapy), on the other hand, is based on the idea that the human being has a natural disposition toward developing in a positive direction. Thus, there is an attempt through therapy to create the necessary conditions that will liberate the client's innate ability to develop. The role of the therapist is more like that of a gardener, who creates good conditions for growth, without intervening directly.

We find the best conditions for personal growth when the client is being regarded as an expert on his own life. The client should play the starring role in his own treatment by getting help to help himself. For Rogers, this means that the therapist must not be too controlling in the session. In the same manner that the gardener grows plants by creating a good growth environment, the therapist can make his or her clients stronger by creating a good conversational environment. In this context, Rogers maintains that a therapist should possess three qualities:

### Genuineness[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-8)]

Firstly, the therapist should be genuine or congruent. The therapist should not hide behind a professional facade [quote wikipedia, on the chapter on person-centred therapy], but be herself when talking to the client. What the therapist is saying to the client should be in accordance with what she is thinking or experiencing. In a video interview Rogers asks if it is at all possible to be genuine in this kind of setting. But what is important is that what you are experiencing is coming out in the moment of communication. Rogers emphasizes that one should be transparent when dealing with the client. If negative feelings appear towards the client, it is better to explain these than make an attempt to hide them.

### Unconditional positive regard[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-9)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Samaritan.jpg/220px-Samaritan.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Carl Rogers was inspired by core values in Christianity

Secondly, it is necessary that the therapist shows the client unconditional positive regard. The therapist must listen to a client's feelings and experiences in an accepting, empathic and honest manner. The therapist should not judge wether the client deserves this esteem. In a video recording, Rogers even suggests that it is important to show the client non judgemental love. It is, however, challenging to show regard if one does not like the client and her opinions that have emerged. Regard appears to be a concept that is closely associated with the concept of approval. One could also assert that this thinking exists within the theory of dialogue with its focus on equality in relations (see for instance article on Martin Buber).

### Empathy[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-10)]

The therapist must, in an empathetic manner, be able to recognize the client's feelings and points of view, and subsequently communicate this understanding back to the client. In a video recording Rogers maintains that one of the goals of a session is for the therapist to try and see the world through the client's eyes. This approach provides a better understanding of the other person. The objective is to make the client's feelings surface. This may help the therapist to a better understanding, and may also help the client understand her own thoughts (Bjørndal 2008: 166-171).

Rogers maintains that it is more likely a client will explore her feelings and discover unknown qualities about herself, if there is a bond between the therapist and the client. Feeling understood by the therapist, will help the client better understand herself. In addition, if the therapist is listening carefully to the client, the client will improve her ability to listen to herself. From being out of touch with what is happening on the inside, the client will increasingly feel her own presence. The goal is for the client to go from feelings of low self-esteem to a better acceptance of herself.

## Is active listening about technique or attitude?[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-11)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/19/Ara_ararauna_-eating_-Wilhelma_Zoo-8-2rc.jpg/220px-Ara_ararauna_-eating_-Wilhelma_Zoo-8-2rc.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Aktive listening has been criticized for being "parrot-communication"

According to Bjørndal (2011), in the early stages of Roger's career, he took a skills approach to empathy, but eventually he distanced himself from this approach. He reacted to the fact that mirroring and paraphrasing were used to further empirical understanding. The risk was, according to Rogers, that one would have a superficial approach to the client. Instead, he focused on empathy as primarily a question of basic human behaviour. Without the right attitude, paraphrasing and other conversation techniques would simply seem like parroting, and a mechanical way of repeating what the client is saying. The therapist needs to try seeing the world from the client's perspective. This approach to empathy emphasizes the importance of being conscious about one's own attitudes and the consequences these attitudes might have for the meeting with the mentee (Bjørndal 2011). The importance of Roger's main concepts (empathy, unconditional positive regard and genuineness) is today thoroughly documented (Clark 2007). Similarly, in practicum mentoring it is important to show the mentee positive regard. Only with the right attitude can conversation techniques contribute to the mentee's growth.

## Sources[[edit](/w/index.php?title=Mentor_teacher/Active_listening&action=edit&section=T-12)]

Text:

  * [Aktiv lytting](http://www.nlsh.no/getfile.php/NLSH_bilde%20og%20filarkiv/Pulsen/Kompetanseutvikling/Tekstfiler/Aktiv_lytting_modul_2.pdf). Notat utviklet ved Nordlandssykehuset
  * Bjørndal, Cato (2008). _Bak veiledningens dør. Symmetri og asymmetri i veiledningssamtaler._ Doktoravhandling. Tromsø: Universitetet i Tromsø.
  * Baltzersen, Rolf K (2011). [Lysbildepresentasjon](http://www.slideshare.net/rolfkb/foredrag-veiledningfrskole120911slideshareversjon) om aktiv lytting.
  * Bjørndal (2011). Hva slags kompetanse trenger veilederen? Karlsen, Thorbjørn (red.) _Veiledning under nye vilkår_. Oslo: Gyldendal akademisk.
  * Carson, Nina og Åsta Birkeland (2009). _Veiledning for førskolelærere_. Kristiansand: Høgskoleforlaget
  * Clark, A.J. (2007) _Empathy in counseling and psychotherapy: perspectives and practices_. Mahwah, N.J.: Lawrence Erlbaum Associates.
  * Geldard, David (1989). _Basic personal counselling: a training manual for counselors._ New York: Prentice Hall.
  * Lauvås, Per og Gunnar Handal (2000). _Veiledning og praktisk yrkesteori_. Oslo: Cappelen akademisk.
  * Wheeler, Sue og Jan Birtle (1993). _A handbook for personal tutors._ Buckingham: Society for Research into Higher Education.

Videos:

  * Shostrom, E. L. (1965). _Three Approaches to Psychotherapy_. Carl Rogers redegjør for kjennetegn ved den klientsentrerte terapitilnærmingen (Fra 3:05-9:07). [Video - Carl Rogers & Gloria Counselling - Part 1](http://www.youtube.com/watch?v=ZBkUqcqRChg). (Opplæringsfilm)
  * Shostrom, E. L. (1965). _Three Approaches to Psychotherapy_. Første del av den klientsentrerte samtalen med Glora (Fra 0:00-9:57). [Video - Carl Rogers and Gloria Counselling Part 2](http://www.youtube.com/watch?v=m30jsZx_Ngs&feature=related). (Opplæringsfilm)

# PART 2 - THEORIES ABOUT MENTORING[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=8)]

# Action-reflection model[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=9)]

## Origins[[edit](/w/index.php?title=Mentor_teacher/Action-reflection_model&action=edit&section=T-1)]

There is a consensus that the action-reflection model has been the most influential mentoring model in Norway. The model has been developing since the 1980s with Handal and Lauvås (1983, 1990) as originators. The model became the guide for a whole generation of Norwegian mentors (Skagen 2004:31) through the national plan for counselling studies in Norwegian university colleges. Of particular note is the model's influence on early childhood educators starting in the early 1990s (Carson and Birkeland 2009).

The model was developed during a time when mentors were facing criticism for taking too much control over the student teachers' practicum. It was assumed that the student teachers had to follow the mentor's wishes, since the final certification of teacher candidates was ultimately the mentor's decision. As a result, some were of the opinion that the teacher education primarily produced dependent teachers (Skagen 2004:31). The action-reflection model was hence developed as a counterbalance to a hierarchical tradition of apprenticeship, which was central in the Norwegian teacher education through to until the late 1980s. This apprenticeship model emphasized the master's work as an example to be imitated (Carson and Birkleland (2009: 68). Characteristics

"Practice theory" is an important term in the action-reflection model. It can be defined as the values, experiences and knowledge that determine the person's actions or plan of action. “Practice theory” refers to every person's subjective notion of practice and preparedness for practice. With the term, Lauvås and Handal (2000) assume that every person has a personal, cognitive action strategy which builds on knowledge and experience with other people. These strategies and ideas are arranged according to values that we consider relevant. For most people the practice theory is rather cluttered, random and filled with discrepancies.

The focus of the mentoring is on helping the mentee become better at understanding her own practice theory. The mentoring focuses on the theory behind the practice. The goal is to create awareness about core values that direct our actions. The mentee can achieve an increased understanding of these core values when asked to justify and explain her own actions. A greater awareness of what the theory consists of makes it possible to expand the mentee's repertory of actions. Since the core values in practice theory are often contradictory, it is essential to create self-awareness in the mentee.

Questions such as what we stand for as professionals or what the values are behind our actions, can contribute to strengthening our professional identity. Carson and Birkeland (2009:72-73) describe practice theory as follows:

  * "Practice theory" is individual because every person possesses different knowledge, experiences and values.
  * "Practice theory" is ever-changing because we continue to make new experiences. This may lead to a change in values, even though values have a tendency to be more resistant to change than knowledge.
  * Everyone has a "practice theory", even those who are new to professional life.
  * "Practice theory" is largely unconscious and difficult to formulate. People are often unaware of the values that guide their actions.
  * "Practice theory" is often incoherent, and the values can be in opposition to each other.

In the action-reflection model, the focus is on planned, formalized mentor-mentee conferences, as opposed to the apprenticeship model, where the focus is rather on informal mentoring in the ongoing daily interaction. The mentoring is based on the mentee's expressed needs, and the mentee is usually asked to develop a mentorship plan for practicum. This is a document that will help both mentor and mentee prepare the mentoring.

Originally the model was geared towards the mentoring of student teachers regarding topics related to teaching. Today, the model is also used in the mentoring of experienced teachers, and the mentoring varies depending on how long the teacher has been teaching. Newly certified teachers, for instance, might need mentoring to acquire a clearer professional identity. More experienced professionals might use mentoring to avoid stagnation and burn out (Carson and Birkeland 2009:72-75).

## Theoretical sources of inspiration[[edit](/w/index.php?title=Mentor_teacher/Action-reflection_model&action=edit&section=T-2)]

Handal and Lauvås describe the action-reflection model as humanistic and dialectic. Amongst the authors that inspired them was Ole B. Thomsen. Thomsen argued that student teachers should be joint participants in developing the criteria for good teaching. They were also influenced by Carl Rogers' ideas of self-realization and personal growth (Skagen 2004: 32). Donald Schön's emphasis on the teacher's capability to reflect over her own actions is yet another inspiration for the model.

## Criticism[[edit](/w/index.php?title=Mentor_teacher/Action-reflection_model&action=edit&section=T-3)]

The action-reflection model has been criticized for several reasons. Firstly, some believe that the model serves to weaken the mentor's professional authority because of the focus on dialogue.Secondly, some question whether there is too much emphasis on individual differences and preferences, and not enough emphasis on the ability to adapt to the specific mentoring tasks. Thirdly, some suggest that the theoretical basis for the model is unclear. By emphasizing reflection, we might lose the focus on proper actions. The model will also favour students with good verbal skills (Skagen 2004: 124). Søndenå (2004:16) finds it problematic that all practical theories are considered equal. In our eagerness to develop the mentee's ability to reflect, we might forget what should be the purpose of our reflection.

## References[[edit](/w/index.php?title=Mentor_teacher/Action-reflection_model&action=edit&section=T-4)]

  * Carson, Nina og Åsta Birkeland (2009). _Veiledning for førskolelærere_. Kristiansand: Høgskoleforlaget
  * Handal, Gunnar og Per Lauvås (1983). _På egne vilkår: en strategi for veiledning med lærere._ Oslo: Cappelen. [Revidert utgave fra 1999 er tilgjengelig i full versjon](http://www.nb.no/utlevering/contentview.jsf?urn=URN:NBN:no-nb_digibok_2008092604074).
  * Handal, Gunnar og Per Lauvås (1990). _Veiledning og praktisk yrkesteori._ Oslo: Cappelen. [Hele boken elektronisk](http://www.nb.no/utlevering/contentview.jsf?&urn=URN:NBN:no-nb_digibok_2007110500028)
  * Skagen, Kaare (2004) _I veiledningens landskap._ Kristiansand: Høgskoleforlaget.
  * Søndenå, Kari (2004). _Kraftfull refleksjon i lærerutdanningen_. Oslo: Abstrakt forlag.

# Apprenticeship model[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=10)]

## What is the apprenticeship model?[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/07/Zimmermann_1880.jpg/220px-Zimmermann_1880.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The Carpenter.

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/00/Medieval_baker.jpg/220px-Medieval_baker.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A medieval baker with his apprentice. The Bodleian Library, Oxford.

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/35/Apprentices_at_Eveleigh_Workshops_%282594507080%29.jpg/220px-Apprentices_at_Eveleigh_Workshops_%282594507080%29.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Apprentices being trained at the Carriage Works at the Eveleigh Workshops, New South Wales.

Historically, there was hardly any formal training of craftsmen. The training took place under the watch of experienced craftsmen in working communities where the apprentice received continuous mentoring. The master demonstrated the correct way of completing a task, and afterwards the apprentice attempted to imitate the master's skills, while being corrected for any mistakes.

This traditional model of apprenticeship originated in the European guilds of the Middle Ages. The guilds appeared in the 12th century. Before training began, the apprentice and the [master craftsman](//en.wikipedia.org/wiki/master_craftsman) would sign a legal contract, with specific terms for the training. The apprentice was required to sign an apprenticeship contract of several years before she could become a [journeyman](//en.wikipedia.org/wiki/journeyman), a person fully trained in a trade or craft, but not yet a master craftsman (Skagen 2004:118). The Encyclopedia Britannica (2013 online edition) defines apprenticeship as: “training in an art, trade, or craft under a legal agreement that defines the duration and conditions of the relationship between master and apprentice”.[1]

The term “apprenticeship” can be used in two ways. The first to describe the statutory institutional structures that have dominated vocational education. The second is as a general metaphor for a relationship where a novice learns from an experienced person. The master knows how the work should be done. She models the work for the novice, who in turn tries to follow the master's example. The last decade has seen a rebirth of the apprenticeship model, and many now consider the master-apprentice relation to be a good vocational learning model. The apprenticeship model has also been introduced outside of the traditional vocational education, as a general pedagogical model (Nielsen and Kvale 1999).

## Usage[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-2)]

The apprenticeship model has a particularly strong foothold within vocational pedagogy (Skagen 2004: 118). As a metaphor, it refers to an asymmetrical relationship between two individuals, one who has mastered the skills of the trade (the master), and another who has not (the apprentice). Similar to a traditional teacher-student relationship, this model is based on one-way communication. During the process, the apprentice acquires tacit knowledge through observing the master as she uses her skills (Polanyi 1958). This perspective can also be used to analyze the interplay between parent and child. Through the participation in daily activities, children learn skills by observing their parents (Rogoff 1990). This kind of learning is sometimes described as [observational learning](//en.wikipedia.org/wiki/observational_learning) (see [Albert Bandura](//en.wikipedia.org/wiki/Albert_Bandura)).

## Characteristics[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-3)]

Nielsen and Kvale (1999:19) mention four characteristics of the apprenticeship model as a pedagogical idea:

  * **Participation in a [community of practice](//en.wikipedia.org/wiki/community_of_practice):** The apprenticeship takes place in a social organization, for instance a community of craftsmen. The apprentice learns by participating in a group of competent practitioners of a craft. The novice advances from “peripheral legitimate participation” to “full participation”, and gradually becomes a more competent member of the professional culture. Mentoring is continuous in these communities, but is not considered an activity on its own. Reflection and action take place side by side. Mentoring does not follow a universal formula, but is adapted to the specific situation.
  * **Professional identity:** The apprentice learns by completing practical assignments that gradually become more difficult. As her set of skills grows, she develops a professional identity through the process of mastering. The reflective conversation should take place soon after the assignment, or it may not have the desired effect.
  * **Learning through imitation of the master:** The novice observes and imitates the work of the master or the other skilled workers. The mentoring follows a pattern, starting with the master demonstrating the correct execution of an assignment. The apprentice then starts practicing, and is corrected by the master until she is proficient at the skill. The master will often interfere more in the beginning of the mentoring, and gradually less.
  * **The quality of the work is evaluated through practice:** The quality of a product is judged on its functionality and the customers' feedback. The master chooses the assignments the apprentice can complete on her own. The master governs the accumulated knowledge of the particular craft, and has developed subtle and complex criteria for the evaluation of craftsmanship. These criteria, however, are often characterized by tacit knowledge and are therefore not articulated.

The apprenticeship model is based on the assumption that competence can not be taught by verbal communication alone. (Expert) competence is partly inherent and instinctive. It can therefore be challenging for the master to find the balance between explaining with words and demonstrating how to complete an assignment. Visualization, demonstration, observation and imitation are principal techniques.

## Central theorists[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Tailors_in_Tanzania.jpg/220px-Tailors_in_Tanzania.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Tailors participating in a community of practice.

The theory of [situated learning](//en.wikipedia.org/wiki/situated_learning) is central within the apprenticeship model (Lave and Wenger 1991). The focus is not on cognitive processes (see for instance cognitive learning theory), but on learning through interactions between individuals, cultural tools and social communities. Jean Lave and Etienne Wenger (1991) developed this theory by studying how craftsmen in african societies learn. Learning takes place by participating in a [community of practice](//en.wikipedia.org/wiki/community_of_practice), which is “formed by people who engage in a process of collective learning in a shared domain of human endeavour”.[2] In the community of practice, the apprentice is initially seen as a “legitimate peripheral participant”. The learning trajectory depends on the possibilities that are given to the individual in the community of learning (Nielsen and Kvale 1999).

With their focus on the community of practice, Lave and Wenger (1991) downplay the pedagogical importance of the master as an individual. Just as the master mentors the apprentice, so does the apprentice learn a great deal from other apprentices and from her own trial and error. This approach is contradictory to Hubert and Stuart Dreyfus, whose focus is on the way a novice learns from the master in a one-on-one relationship. The learning takes place by observing and imitating the master. The novice does not necessarily need to be part of a larger social environment. This form of learning happens within both sports and research.

In the literature on communities of practice, the term [scaffolding](//en.wikipedia.org/wiki/instructional_scaffolding) is used to describe how the instruction is tailored to the needs of the apprentice. Scaffolding means that the master offers support, and creates interest in the work for instance by simplifying practical assignments, explaining targets, evaluating the quality of the work product produced by the apprentice compared to the model. She must also aim at balancing the apprentice's frustration on one side and willingness to take risks on the other (inspiration: Rogoff). The term scaffolding is similar to the term [zone of proximal development](//en.wikipedia.org/wiki/zone_of_proximal_development), originally developed by [Lev Vygotsky](//en.wikipedia.org/wiki/Lev_Vygotsky). The idea behind zone of proximal development is that the novice can only learn new skills in a tailored situation, and with support from a more capable person. The teacher might be thinking out loud while solving mathematical problems, and giving the student an opportunity to develop strategies and problem solving. Observational learning is another important learning method, where the subject replicates a model's novel behaviour through observation and imitation[3]. The theory was proposed by [Albert Bandura](//en.wikipedia.org/wiki/Albert_Bandura).

## The importance of the apprenticeship model in many professions[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Bundesarchiv_Bild_183-16229-0001%2C_Architekt_mit_Student_an_Pl%C3%A4nen_arbeitend.jpg/220px-Bundesarchiv_Bild_183-16229-0001%2C_Architekt_mit_Student_an_Pl%C3%A4nen_arbeitend.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

An architect mentors a student.

Language often plays a subordinate role in the training of craftsmen, particularly during observation and demonstration. Most importantly, mentoring and practical work take place side by side. For instance, in the architecture profession, experienced architects mentor their students at the drawing board. As a result, the students are mentored in drawing, while simultaneously discussing reasons for their choices. According to Skagen (2004:19), Donald Schön rejects the notion that this form of apprenticeship simply means copying someone else's actions. He argues that the novice instead uses these experiences to develop her own work style. Schön uses the terms reflective imitation, imitative reconstruction and selective reconstruction to describe these processes. The idea is that the students must enter into a relation of dependence, before being able to become independent. To illustrate, Skagen recounts two personal narratives from one of Schön's books, describing how architects mentor their students:

**Personal narrative no. 1:** Johanna's mentor has a strong opinion about how an architect should draw. While some of the students are intimidated by the mentor because of this, Johanna is not. She believes that she will learn a great deal by following the mentor's ideas, and decides to participate on these premises. She does not worry that she will become dependent on the mentor, but rather thinks that she can develop her own style later. Before being able to do that, however, she must understand how the mentor works. To her this is a paradox. She lets the mentor take control over the course of learning, but to her the goal is to later gain greater control over her own project. It is Johanna's reflective ability and courage that makes it possible for her to let go of some of her own opinions for the time being (Skagen 2004: 121-122, citing Schön, 1988:121-126).

**Personal narrative no. 2:** Another architecture student, Judith, has greater issues with this same mentor. She has a strong opinion about what architecture is, and how an architect should work. She spends a lot of energy defending her own ideas when the mentor makes suggestions. She sees the mentor's suggestions as an attack on her as a professional. Because she is not capable of critical thinking regarding her own professional understanding, she is also not capable of listening to the mentor's suggestions. Neither is she interested in the mentor's comments, but wants praise for the work she does when she does it the way she wants. The result is she is not capable of integrating the mentor's thinking with her own to develop a holistic understanding. Judith does not manage to take the cognitive risk needed for her to start her own learning journey (Skagen 2004:122, citing Schön, 1988: 126-137).

## Criticism of the apprenticeship model[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-6)]

Some critics claim that the apprenticeship model has nothing to do with mentoring. Within the teacher education in Norway, for instance, mentoring courses have traditionally focused on the action-reflection model. The action-reflection model came as a reaction to the tradition of apprenticeship. According to critics the traditional apprenticeship model, dominant at the time, did little but cultivate “parrot teachers”. It has now become legitimate to include the apprenticeship model as one of several mentoring models in introductory books about mentoring pedagogy (Skagen 2004 and Løv 2009). There are, however, grounds to suggest the apprenticeship model differs from other mentoring models in its emphasis on the mentor giving the mentee advice.

It is worth noting that some streams within the apprenticeship model focus on group mentoring (i.e. the community of practice approach) rather than traditional mentoring models with their emphasis on individual mentoring (i.e. the action-reflection model). Informal mentoring is more important within the apprenticeship model than within the action-reflection model, which emphasizes formalized mentor-mentee conferences. Learning through observation is seen as an important form of learning, while the action-reflection model maintains that the mentee should put thoughts into words. Below is a criticism of the apprenticeship model:

  * The apprenticeship model has been criticized because it requires an exact solution to the assignment. The model could be unduly conservative and shut out creativity and innovation. Supporters, on the other hand, claim that practicing skills is an important complimentary prerequisite for later being able to develop creativity.
  * The apprenticeship model requires a close connection between reflection and the exercise of a profession. Verbalization is not essential. The result, according to some, is less room for in-depth reflection on the activity. The mentorship conversation focuses on action, and emphasizes demonstration and illustration.
  * The apprenticeship model downplays the mentee's right to formulate requests and criteria for her own growth. It instead lets the traditions of the trade decide the framework for mentoring. It criticizes the reform pedagogy's one-sided emphasis on creativity, self-development and autonomy of the learner.
  * The fact that the master must be competent within a trade or a profession, sets limitations for who can act as a mentor. Within the action-reflection model, it is more important that the mentor has communicative competence, i.e. the ability to develop good relations and ask good questions. Good technical or professional knowledge is not as necessary.
  * The apprenticeship model has been criticized for rating practice higher than theory. Excessive concern with mastering professional skills can undermine important technical principles (Skagen 2004: 122-123).

## Integration of the apprenticeship model in teacher education[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-7)]

In recent decades, teacher education in many jurisdictions have focused on fostering reflective teachers (Skagen 2004: 121). The didactic model of Hiim and Hippe[4], for instance, builds on this thinking. Taking place within this type of pedagogical regime, Skagen (2004: 125-126) is of the opinion that mentoring has become one-sided. The reflective conversation is dominant. Nowadays, the new teacher following initiation into the teaching profession is quickly provided full responsibilities for teaching with little opportunity to observe other teachers. Within the apprenticeship model, one could alternatively picture a situation where the student teacher is responsible for part of the teaching, until the final certification. When that is said, there is little empirical research to show which mentoring models are in fact used in the practicum of the teacher education.

## References[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-8)]

  1. ↑ <http://www.britannica.com/EBchecked/topic/30748/apprenticeship>
  2. ↑ <http://www.ewenger.com/theory/>
  3. ↑ <http://psychcentral.com/encyclopedia/2009/observational-learning>
  4. ↑ <http://www.learning-at-distance.eu/docs/pedagogical/PT6_didactic.pdf>

## Sources[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-9)]

  * Hiim, Hilde og Else Hippe (2006) Undervisningsplanlegging for yrkesfaglærere. Oslo: Gyldendal akademisk forlag.
  * Lave, Jean og Etienne Wenger (1991). Situated learning : legitimate peripheral participation. Cambridge: Cambridge University Press .
  * Nielsen Klaus og Steinar Kvale (1999). Mesterlære: læring som sosial praksis. Oslo: Ad Notam Gyldendal.
  * Polanyi, Michael (1958). Personal knowledge. London: Routledge and Kegan Paul.
  * Rogoff, Barbara (1990). Apprenticeship in thinking: cognitive development in social context. New York: Oxford University Press.
  * Skagen, Kaare (2004). I veiledningens landskap. Kristiansand: Høgskoleforlaget.

## Video resources[[edit](/w/index.php?title=Mentor_teacher/Apprenticeship_model&action=edit&section=T-10)]

  * [Lecture](http://www.youtube.com/watch?v=FAYs46icCFs) by Jean Lave (2012) about apprenticeship and learning.

# Systemic mentoring[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=11)]

## Characteristics[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-1)]

Systemic mentoring is a mentoring approach designed to create awareness in the mentee of how people affect and are affected by their environment. It is based on ideas proposed by [Gregory Bateson](//en.wikipedia.org/wiki/Gregory_Bateson) and [Urie Bronfenbrenner](//en.wikipedia.org/wiki/Urie_Bronfenbrenner), among others. Systemic mentoring focuses on the person as part of a social system and the emphasis is on interpersonal relationships (Skagen 2004;89-90). Central concepts in the [systems theory](//en.wikipedia.org/wiki/systems_theory) are wholeness, human relations and circularity.

The term “wholeness” refers to the way that phenomenons are connected to each other. In interpersonal communication the parties will always be mutually influenced. For instance, in an educational institution there are relations between mentors, between management and mentor, and between mentor and mentee. Not all these parties participate directly in the mentoring, but they all can influence how the mentoring is organized (cf. Bronfenbrenner). Additionally, on the organizational level there are relations between institutions involved in mentoring. Thus, when an issue arises and a problem needs to be solved, involving those who are directly affected is not always enough (Skagen 2004:90).

In daily interaction we have a tendency to evaluate our actions in terms of cause and effect. The result of such thinking is that we might not look at all sides of an issue (Skagen 2004:90). In systemic mentoring exclusive why-questions are viewed as unproductive as they imply a too exact cause and effect (i.e. “Why do you do that?”). In contrast systemic mentoring uses a more circular explanation of cause and effect where we include our own contribution to the interaction. [Gregory Bateson](//en.wikipedia.org/wiki/Gregory_Bateson) is preoccupied with the concept that when we explain an interaction we first punctuate the interaction. When we punctuate, we end the process of interaction, and start interpreting the interaction. We explain the reasons behind what is happening between the parties. “The teacher is yelling because the students are loud” could also be interpreted as “The students are loud because the teacher is yelling”. The term “punctuation” refers to the concept that there are always alternative ways to understand an incident. If we punctuate the interaction differently, we will have a different understanding of the interaction (Carson and Birkeland 2009: 92-94).

## Question techniques in systemic mentoring[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-2)]

Within systemic mentoring, the preconception is that the mentee is incapable of finding a way out of a deadlocked situation on her own. To encourage change we can use so-called circular questions that were developed by the Milan group (Carson and Birkeland 2009:102-103). The questions are divided into four categories. To illustrate we start out by an example:

A pedagogical leader of a daycare works in a room where the children are between the ages of 18 months and 3 years. She writes the following: _I have an immature assistant named Bente. The other day, Bente is sitting on the floor playing ball with three of the children. Per, 2 years old, goes over to Bente and pulls on her arm. Bente does not react. Per continues pulling on her arm. Finally, she pushes him away. Per starts crying and runs over to the dressing area. I sharply told Bente to go over to Per and talk to him. Should I have handled the situation differently? Was what I did ethically responsible?_ (Carson and Birkeland 2009:105)

### Questions that explore differences[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-3)]

These questions are divided into four subcategories:

#### Questions that explore differences on a personal level[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-4)]

These questions are based on the presumption that we all react differently to a situation. The focus is on establishing how different people react, or who has the strongest reaction. Going back to the daycare story, we can ask the following questions:

  * Who was present?
  * How did the other children react to Bente's conduct?
  * How did you and the other assistant react to Bente's conduct?
  * Was it you or the other assistant that reacted to Bente's conduct?

The focus is on visible reactions. The questions will elicit different reactions from the people present, and may lead to a better understanding of the incident.

#### Questions that explore differences in relations[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-5)]

These questions explore differences in interpersonal relations. The mentee is asked to describe different relationships, and differences in relationships. Questions can be:

  * How is the relationship between Bente and Per?
  * between Bente and the other children?
  * between you and Bente?
  * between Bente and the other assistant?
  * Who is closest to Bente?
  * How is your relation to Bente different from your relation to the other assistant?

These questions reveal differences in relationships. They raise awareness around relations that Bente is part of. Is it possible that Bente perceives an alliance between the pedagogical leader and the other assistant?

#### Questions that explore differences in opinions, ideas, values and motives[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-6)]

These questions focus on how we imagine other people perceive the situation. The aim is to elicit differences in how we think compared to how the other parties involved in the situation think. We can ask questions such as:

  * What do you think Bente was thinking when she reacted the way she did?
  * What do think the other assistant was thinking when she saw Bente's reaction?
  * How is your way of handling a similar situation different from Bente's approach?
  * How did Bente explain her reaction?

These questions elicit thoughts regarding how the situation is understood, as well as differences between the participants' thoughts. They also elicit differences in values and in the perception of children.

#### Questions that explore differences between the present and the future[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-7)]

With these questions we consider the ways that different people react to new situations. The focus is on the involved parties' reaction in previous situations, and how they might have reacted differently. Compared to the previous example, a question might be:

  * Has Bente previously reacted to Per in a similar manner?

All these questions contribute to eliciting information that could give the mentee a wider and more complex picture of her activity.

  


### Questions that explore behavioural effect[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-8)]

These questions aim at making the mentee acknowledge the mutual influence people have on each other. We want to create greater awareness of other people's reactions and our own reactions to other people's conduct. When discussing the same story, we could ask the following question:

  * How do you think Bente reacted to your intervention?

The ability to understand the other person's perspective is essential to empathy.

### Triadic questions[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-9)]

Triadic questions build on the questions that explore effect. Their purpose is to create awareness of the third party's reaction to the interaction. We can ask questions such as:

  * How do you think the children perceive the relationship between you and the assistants?
  * How do you think Per, the other children and the other assistant reacted to your intervention?

Here we consider a third party's reaction to the episode. Both in questions that explore behavioural effect and triadic questions we attempt to create awareness of the reciprocal relationship between colleagues. The mentor should help the mentee to obtain an external perspective and in a sense develop an ability to observe herself from the outside (Carson and Birkeland 2009: 105).

### Hypothetical questions[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-10)]

In these questions about the future we encourage the mentee to consider alternative options. Possible questions are:

  * How would you feel if Bente was to leave?
  * If you were to make changes in your relationship with Bente, what would they be?
  * What is needed for you and the assistant to come to an agreement?
  * If you were successful in making changes, what would the situation be like?
  * What is hampering such a change? (Carson and Birkeland 2009: 105)

With hypothetical questions we encourage the mentee to look for an alternative course of action. They will make her think about how the situation might look if the problem is solved.

## Example – To se oneself from the outside[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-11)]

Berit is supervisor in a daycare and manager of a group of employees that consists of two assistants, a learning support teacher and a special needs educator. Below are two personal narratives she has written and for which she received systemic mentoring (from Carson and Birkeland 2009: 107-110).

**Before the mentorship conversation**  
“I need help with my relationship to the learning support teacher. She is taking authority over the day care room. She is even taking charge of the parents. I am the pedagogical leader! Her only responsibility is a child with special needs. To give a concrete example: in our staff meetings where both assistants and the special needs educator are present, we are almost fighting over who should make decisions. The more I take charge, the more dominant she becomes. She should realize that I am pedagogical leader. I feel very frustrated”.

**After the mentorship conversation**  
"Now I am glad! I understand my own role and how I was trapped. When asked how I thought the other parties reacted to the episode, I realized that I believed there was an alliance between the special needs teacher and the learning support teacher. I saw this alliance as a threat to me as leader. When the mentor asked how I think they see me, I also realized that I imagine them perceiving me as a an incompetent leader. Thus, I have to admit that this is how I see myself. This has been difficult to absorb. When asked by the supervisor how I want the relationship between myself and the learning support teacher to be, I have to admit that I had not thought it through. I had been more concerned about what I did not want it to be. This is something I need to work on. I now understand that I need to take responsibility for my role as pedagogical leader – and I will!”

The first personal narrative shows that Berit is seemingly stuck in a destructive interaction pattern. Quite typically this involves thinking that it is the other person who needs to change. It can be difficult to see how we can make a difference ourselves. In the second narrative Berit has a clearer understanding of her own responsibilities as pedagogical leader.

In the mentorship conversation the mentor chooses to use circular questions based on systemic mentoring, such as: “How do you think the others see you as pedagogical leader?” Berit will then become more aware of her own role in the interaction. She is forced to become her own observer. A question regarding the future such as: “how do you wish the relationship to be?” makes her aware of things she has not yet considered. When stuck in a destructive communication pattern, it is easy to forget to think constructively and creatively.

## Sources[[edit](/w/index.php?title=Mentor_teacher/Systemic_mentoring&action=edit&section=T-12)]

  * Baltzersen, Rolf K. (2008). Å samtale om samtalen. Bergen: Fagbokforlaget.
  * Bomar, Perri J. (2003), Promoting Health in Families: Applying Family Research and Theory in Nursing
  * Carson, Nina og Åsta Birkeland (2009). Veiledning for førskolelærere. Kristiansand: Høgskoleforlaget
  * Gjems, Liv (1995) Veiledning i profesjonsgrupper. Oslo: Universitetsforlaget. Hele boken
  * Skagen, Kaare (2004) I veiledningens landskap. Kristiansand: Høgskoleforlaget.
  * Ulleberg, Inger (2004). Kommunikasjon og veiledning : en innføring i Gregory Batesons kommunikasjonsteori - med historier fra veiledningspraksis. Oslo: Universitetsforlaget.

# Appreciative Inquiry[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=12)]

## What is Appreciative Inquiry?[[edit](/w/index.php?title=Mentor_teacher/Appreciative_Inquiry&action=edit&section=T-1)]

[Appreciative Inquiry](//en.wikipedia.org/wiki/Appreciative_Inquiry) (AI) is a mentoring approach that seeks to identify and foster the best in people and organizations. “Appreciative” refers to the attempt at focusing on things we appreciate and that create value. “Inquiry” refers to the search for what is already working and has value. AI has received increased attention in recent years (Cooperrider & Srivastva 1087; Cooperrider & Srivastva 1999; Cooperrider & Whitney 2000).

When undertaking an appreciative inquiry, we start by examining aspects of the person's life and work she finds meaningful and productive. This approach is done on the assumption that people will achieve transformative goals quicker by strengthening their pre-existing resources. A situation may also be strengthened by the alternative method of problem analysis, but problem analysis may also worsen a situation (Cooperrider & Srivastva 1987). According to Cooperrider & Srivastva (1987), appreciative inquiry builds on the following assumptions:

  * All organizations and all individuals have success stories to show that can contribute to positive development.
  * All development is based on experience. And when we start the process with positive experiences, the road to development becomes more meaningful. We should make positive experiences visible and active in the organization.
  * Inquiry and change stand in a dialectic relationship to each other. By starting an inquiry, we simultaneously start a change process.

When making these changes, employees will understand what is important in the organization, what creates a good life, happiness, development and freedom (Ludema, Cooperrider & Barrett 2006). People who are recognized for their strengths and qualities are willing to give more. In order to understand what is working, it is necessary to reflect on the characteristics of good experiences and achievements. The theoretical base for the approach is based on the following assumptions:

  * Importance, meaning and recognition are created through interaction with others.
  * Language as a tool can be used to construct a positive reality.
  * What we see as reality is not created inside us, but between individuals through language.

## The four phases of Appreciative Inquiry[[edit](/w/index.php?title=Mentor_teacher/Appreciative_Inquiry&action=edit&section=T-2)]

An appreciative inquiry is done in four phases (Cooperrider & Srivastva 1999; Cooperrider & Whitney 2000; Ludema, Cooperrider & Barrett 2006; Whitney & Trosten-Blom 2003). This is also referred to as the 4-D cycle: Discovery, Dream, Design and Destiny.

**1\. Discovery** The purpose of the discovery phase is to identify situations where an organization or an individual's performance is at its best. The discovery is done through systematic charting, for instance by qualitative data collection methods such as interviews. Common for this data collection is the search for positive stories. The idea is that by telling stories, we reveal how we perceive and experience our lives. And by bringing these stories forward, and with them our experiences, we will be able to create a common experience base around what we value and what energizes us in our daily lives. During interviews, the following positively formed questions could be posed:

  * What makes us happy?
  * What contributes to making us happy?
  * What helps us bring forward the positive?

When listening to employees during this process, we try to identify and explore energizing aspects of their stories. The key is to uncover energizing stories and understand the areas that give vitality to individuals and organizations.

**2\. Dream** After charting valuable experiences, we formulate dreams and visions for the future. We exchange notions of a preferred future. For an appreciative inquiry to work, it must be based on participation. Ideally, it should involve all employees in an organization or a team, and as far as possible also collaborators and users.

**3\. Design** In the design phase employees make precise descriptions of how the organization's day to day practice would look once the dream or vision has been fulfilled. They formulate precise goals and create an action plan for the way ahead. In this phase the organization's employees make an attempt at creating relations and systems that can support the desired development. The purpose of this phase is to define a vision and what is needed to realize this vision.

**4\. Destiny** In the destiny phase the employees adopt initiatives in order to realize the goals that were developed in the design phase. This requires a specific action plan describing what needs to be done when and by whom. The employees reinforce positive experiences from the past and attempt new measures. The learning process continues with adjustments and experimentation. More benefits in this phase are realized based on the amount of effective and creative tools for evaluation and development that have been identified.

## Use and examples[[edit](/w/index.php?title=Mentor_teacher/Appreciative_Inquiry&action=edit&section=T-3)]

Appreciative inquiry can be used:

  * to reflect on competences and resources in a group of employees.
  * to create knowledge of and reflect on professional work.
  * to determine the priorities management and employees will use for day-to-day work.
  * to plan and implement organizational development.

(Cooperrider & Srivastva 1999; Cooperrider & Whitney 2000; Ludema, Cooperrider & Barrett 2006; Whitney & Trosten-Blom 2003).

## Sources[[edit](/w/index.php?title=Mentor_teacher/Appreciative_Inquiry&action=edit&section=T-4)]

  * Cooperrider, D.L. and Srivastva, S. (1987). Appreciative Inquiry in Organizational Life, Research in Organizational Change and Development, 1, pp. 129-169. [Original article](http://www.margiehartley.com/home/wp-content/uploads/file/APPRECIATIVE_INQUIRY_IN_Orgnizational_life.pdf) (read 15.06.12)
  * Cooperrider, D. L., & Srivastva, S. (1999). Appreciative inquiry in organizational life. In: S. Srivastva & D. L. Cooperrider (Eds), Appreciative Management and Leadership: The Power of Positive Thought and Action in Organization (Rev. ed., pp. 401–441). Cleveland, OH: Lakeshore Communications.
  * Cooperrider, D.L. & Whitney, D. (2000). A Positive Revolution in Change: Appreciative Inquiry. Appreciative Inquiry Commons. [Original article](http://appreciativeinquiry.case.edu/uploads/whatisai.pdf)
  * Ludema, J.D., Cooperrider, D.L., & Barrett, F.J. (2006). Appreciative Inquiry: the Power of the Unconditional Positive Question. I Reason, Peter & Bradbury, Hilary (Eds.) (2006). Handbook of Action Research. Sage. London
  * Whitney, D. & Trosten-Blom, A. (2003). The Power of Appreciative Inquiry. A Practical Guide to Positive Change. San Fransisco: Berrett-Koehler Publishers
  * <http://appreciativeinquiry.case.edu/uploads/Introduction%20to%20Appreciative%20Inquiry.pdf>

## Relevant books[[edit](/w/index.php?title=Mentor_teacher/Appreciative_Inquiry&action=edit&section=T-5)]

  * Appreciative Inquiry: Change at the Speed of Imagination av Jane Magruder Watkins & Bernard Mohr, San Francisco: Jossey-Bass, 2001.
  * Appreciative Inquiry Handbook av David Cooperrider, Diana Whitney & Jacqueline Stavros, San Francisco: Berrett-Koehler, 2007 (2nd edition).
  * The Appreciative Inquiry Summit: A Practitioner's Guide for Leading Large-Group Change av James Ludema, Diana Whitney, Bernard Mohr & Thomas Griffin, San Francisco`: Berrett-Koehler, 2003.
  * Experience AI: A Practitioner's Guide to Integrating Appreciative Inquiry with Experiential Learning av Miriam Ricketts & James Willis, Chagrin Falls, Ohio: Taos Institute , 2004.
  * Appreciative Leaders: In the Eye of the Beholder by Marjorie Schiller, Bea Mah Holland & Deanna Riley, Chagrin Falls, Ohio: Taos Institute , 2001.
  * Appreciative Coaching: A Positive Process for Change av Sara Orem, Jacqueline Binkert & Ann Clancy, San Francisco: Jossey-Bass, 2007.
  * Social Construction: Entering the Dialogue av Kenneth Gergen & Mary Gergen, Chagrin Falls, Ohio: Taos Institute , 2004.

## Relevant internet resources[[edit](/w/index.php?title=Mentor_teacher/Appreciative_Inquiry&action=edit&section=T-6)]

  * Appreciative Inquiry Commons (<http://appreciativeinquiry.case.edu>) has articles and commentaries on Appreciative Inquiry in theory and practice, as well as information on workshops and conferences.
  * The Taos Institute (<http://www.taosinstitute.net/>)
  * Anne Radford (<http://www.aradford.co.uk/>) is editor of AI Practitioner and has other AI resources.

# Coaching[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=13)]

## What is coaching?[[edit](/w/index.php?title=Mentor_teacher/Coaching&action=edit&section=T-1)]

The term [coaching](//en.wikipedia.org/wiki/coaching) originates from the word “coach”, a medium of transport. In 19th century England the word “coach” came to be used to describe a private teacher who assisted students preparing for exams. The transposition of a word for transport to a name for a teacher came about for these 19th century exam preparation teachers due to the students' conception that they were being driven through the examinations or were able to ride through the examinations on a coach with the help of their prep teachers. In some recent conceptions of mentoring, the word “coach” is used metaphorically as the guide who assists the mentee on her inner journey. The coach assists the mentee to improve her own abilities, by developing mental or practical skills (Skagen 2004).

## Origins[[edit](/w/index.php?title=Mentor_teacher/Coaching&action=edit&section=T-2)]

![Tommy Haas serves.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Tommy_Haas_serves.jpg/220px-Tommy_Haas_serves.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Coaching as a form of mentoring was originally developed in American sports. The Norwegian football coach [Knut Rockne](//en.wikipedia.org/wiki/Knut_Rockne) was a pioneer in developing the sports coach as mentor concept. It was, however, tennis coach [Timothy Gallwey](//en.wikipedia.org/wiki/Timothy_Gallwey) who popularized the coach as mentor guiding the mentee on an inner journey model. Gallwey claimed that the key to becoming a good tennis player, is to master what he calls the “inner game”. His book “The Inner Game of Tennis” became an inspiration for several names in coaching, i.e. Myles Downey and John Whitmore.

Gallwey alleged that relaxed concentration is essential to mastering the game of tennis. The player must not criticize or judge his own achievements. Paradoxically, the secret to winning a game is not trying too hard. The player must concentrate on the game and not on winning. To enable the release of energy and resources and maximization of the performance it is imperative to enter into a state of serenity. This state does not need to be learned, as it is part of us, but we may have acquired bad habits that prevent us from entering it. To reach this productive state we should not analyze our actions, but rather create images of ourselves performing good actions. We must stop judging our own shortcomings in a negative way. This requires us to separate between an observation of our actions on one side, and an evaluation of this observation on the other. This optimal state, as described by Gallwey, has similarities with [Csikszentmihalyi](//en.wikipedia.org/wiki/Mihaly_Csikszentmihalyi)'s [notion of flow](//en.wikipedia.org/wiki/flow_\(psychology\)) (Skagen 2004). Coaching as mentoring has later been introduced in executive coaching, business coaching and life coaching. Additionally, several other types of coaching have emerged. The term is today more often than not used as a reflective and conversational method whereby one person assists another to realize the maximum potential of their abilities in a particular area (Skagen 2004).

## Source[[edit](/w/index.php?title=Mentor_teacher/Coaching&action=edit&section=T-3)]

  * Skagen, Kaare (2004) I veiledningens landskap. Kristiansand: Høgskoleforlaget.

# Dreyfus model of skill acquisition[[edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit&section=14)]

![Kasparov-11.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Kasparov-11.jpg/220px-Kasparov-11.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

## Different stages of skill acquisition[[edit](/w/index.php?title=Mentor_teacher/Dreyfus_model_of_skill_acquisition&action=edit&section=T-1)]

Hubert L. and Stuart E. Dreyfus refer to various studies of learning processes and claim that a person acquires skills by passing through different stages. They base their theory on empirical studies and observations of sensory-motor skills such as biking, swimming, aircraft piloting, and cognitive skills such as chess-playing. In the book “Mind Over Machine” (1986), they describe a stage model of skill acquisition:

Stage Characteristics Teacher

Expert
The difference between the expert and the proficient performer is that the expert is immediately and intuitively capable of making the right decision, or seeing the right strategy or action to take. The action is based on a holistic evaluation of the situation.
An expert teacher often has a broad experience from various schools and is quickly capable of understanding all aspects of a situation.

Proficient
The proficient performer instantly sees the connection between earlier experiences and new situations. The reaction is immediate and intuitive. There is a correlation between intuition and analysis. Discretionary judgment and interpretation is more important than in the competent performer.

Competent
The competent performer is capable of making choices and priorities in a situation, based on work experience. Some use of interpretation and discretion. The basis of experience is broader than that of the advanced beginner.

Advanced beginner
The advanced beginner has more practical experience than the novice. Recognizes important dimensions and circumstances in a situation.
A student teacher who is an advanced beginner (following a completed education), has experience from numerous lessons and different classes.

Novice
A novice learns through demonstration and instruction. She learns that it is important to focus on particular rules, facts and traits in a situation. The novice's learning situation is protected from “real life”.
During the first practicum lesson, advice given by the mentor will determine the student teacher's approach to teaching.

Hubert L. and Stuart E. Dreyfus argue that once an individual has acquired a skill, she can act without following rules, consciously or unconsciously. Neither is it necessary that she understands the purpose of the action. It is her body that reacts to the demands of the situation. In this, Dreyfus and Dreyfus (1999) are influenced by the philosopher Merleau-Ponty. According to Merleau-Ponty, “when one's situation deviates from some optimal body-environment relationship, one's activity takes one closer to that optimum and thereby relieves the "tension" of the deviation. One does not need to know, nor can one normally express, what that optimum is. One's body is simply solicited by the situation to get into equilibrium with it” (Dreyfus 1998).

## Examples[[edit](/w/index.php?title=Mentor_teacher/Dreyfus_model_of_skill_acquisition&action=edit&section=T-2)]

One example is how a skilled soccer playerimmediately understands when and how to dribble around the opponent (Tiller 2006). There is no indication that such a skilled soccer player has time to consider rules before dribbling. When Maradona [dribbled around the entire English defence](http://www.youtube.com/watch?v=jk-kXwjASEE) during the 1986 World Cup, he had not planned this in advance. Based on the situation, Maradona made a quick assessment whether to pass the ball or to continue dribbling. Maradona's expertise can be linked to what is known as [tacit knowledge](//en.wikipedia.org/wiki/tacit_knowledge). This implies that the knowledge is non-explicit; it can not always be communicated to others as rules or distinct recommendations. A masterful driver is “one” with her car, and a masterful teacher is “one” with her classroom. Compared to research done on rational decision making processes, little research has been done on intuitive decision making processes.

## How to become an expert?[[edit](/w/index.php?title=Mentor_teacher/Dreyfus_model_of_skill_acquisition&action=edit&section=T-3)]

Towards the end of an [online video presentation](http://www.youtube.com/watch?v=8VCMc7f1XMw&feature=related), Dreyfus stresses that in order to reach the expert stage, we need to take chances (as opposed to following routines). We do not become experts without making, and learning from, serious mistakes.

## Sources[[edit](/w/index.php?title=Mentor_teacher/Dreyfus_model_of_skill_acquisition&action=edit&section=T-4)]

  * Dreyfus, Hubert L., Dreyfus, Stuart E. og Tom Athanasiou (1986). Mind over machine : the power of human intuition and expertise in the era of the computer. New York: Free Press
  * Tiller, Tom (2006). Aksjonslæring - forskende partnerskap i skolen : motoren i det nye læringsløftet. Kristiansand: Høgskoleforlaget
  * Bakke, Kari Renate & Emil Severin Tønnesen (2007) Lave & Wenger og Dreyfus & Dreyfus. Master thesis. Oslo: University of Oslo <http://www.duo.uio.no/sok/work.html?WORKID=62030>
  * <http://www.class.uh.edu/cogsci/dreyfus.html>
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Mentor_teacher/Print_version&oldid=2527521](http://en.wikibooks.org/w/index.php?title=Mentor_teacher/Print_version&oldid=2527521)" 

[Category](/wiki/Special:Categories): 

  * [Mentor teacher](/w/index.php?title=Category:Mentor_teacher&action=edit&redlink=1)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Mentor+teacher%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Mentor+teacher%2FPrint+version)

### Namespaces

  * [Book](/wiki/Mentor_teacher/Print_version)
  * [Discussion](/w/index.php?title=Talk:Mentor_teacher/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Mentor_teacher/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Mentor_teacher/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Mentor_teacher/Print_version&action=edit)
  * [View history](/w/index.php?title=Mentor_teacher/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Mentor_teacher/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Mentor_teacher/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Mentor_teacher/Print_version&oldid=2527521)
  * [Page information](/w/index.php?title=Mentor_teacher/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Mentor_teacher%2FPrint_version&id=2527521)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Mentor+teacher%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Mentor+teacher%2FPrint+version&oldid=2527521&writer=rl)
  * [Printable version](/w/index.php?title=Mentor_teacher/Print_version&printable=yes)

  * This page was last modified on 20 May 2013, at 14:35.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Mentor_teacher/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
