# Introduction to Library and Information Science/Print version

From Wikibooks, open books for an open world

< [Introduction to Library and Information Science](/wiki/Introduction_to_Library_and_Information_Science)

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Introduction to Library and Information Science](/wiki/Introduction_to_Library_and_Information_Science)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=purge&printable=yes) this page.

  1. [Introduction to Library and Information Science/Contextualizing Libraries: Their History and Place in the Wider Information Infrastructure](/wiki/Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure)
  2. [Introduction to Library and Information Science/Ethics and Values in the Information Professions](/wiki/Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions)
  3. [Introduction to Library and Information Science/Information Policy](/wiki/Introduction_to_Library_and_Information_Science/Information_Policy)
  4. [Introduction to Library and Information Science/Information Organization](/wiki/Introduction_to_Library_and_Information_Science/Information_Organization)
  5. [Introduction to Library and Information Science/Information Seeking](/wiki/Introduction_to_Library_and_Information_Science/Information_Seeking)
  6. [Introduction to Library and Information Science/Re-contextualizing Libraries: Considering Libraries within Their Communities](/wiki/Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities)
  7. [Introduction to Library and Information Science/Technology and Libraries: Impacts and Implications](/wiki/Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications)
  8. [Introduction to Library and Information Science/Transcending Boundaries: Global Issues and Trends](/wiki/Introduction_to_Library_and_Information_Science/Transcending_Boundaries:_Global_Issues_and_Trends)
  9. [Introduction to Library and Information Science/Learning More: Free LIS Resources](/wiki/Introduction_to_Library_and_Information_Science/Learning_More:_Free_LIS_Resources)
  10. [Introduction to Library and Information Science/List of Contributors](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

## Contents

  * 1 Contextualizing Libraries: Their History and Place in the Wider Information Infrastructure
    * 1.1 Libraries of the past
      * 1.1.1 A brief history of libraries
        * 1.1.1.1 Early libraries (2600 BC – 800 BC)
        * 1.1.1.2 Classical period (800 BC – 500 AD)
          * 1.1.1.2.1 The Library of Alexandria
          * 1.1.1.2.2 Other Classical libraries
        * 1.1.1.3 Middle Ages (501 AD – 1400 AD)
        * 1.1.1.4 Renaissance
        * 1.1.1.5 17th and 18th centuries
        * 1.1.1.6 19th century
        * 1.1.1.7 20th century
      * 1.1.2 Issues in library history
        * 1.1.2.1 Ahistoricism
        * 1.1.2.2 Gender
        * 1.1.2.3 Inclusions and exclusions
        * 1.1.2.4 Tunnel vision
    * 1.2 Libraries in the information age
      * 1.2.1 Defining information
        * 1.2.1.1 Technical aspects
          * 1.2.1.1.1 Information as a sequence of symbols
        * 1.2.1.2 Societal aspects
          * 1.2.1.2.1 Information as a right
          * 1.2.1.2.2 Information as a commodity
      * 1.2.2 Quantifying information
      * 1.2.3 Defining knowledge
        * 1.2.3.1 Information needs
        * 1.2.3.2 Education
      * 1.2.4 Defining libraries
    * 1.3 References
  * 2 Ethics and Values in the Information Professions
    * 2.1 The Values of librarianship
      * 2.1.1 Defining professional values
      * 2.1.2 Ranganathan's five laws
    * 2.2 Professional Ethics
      * 2.2.1 The ALA's Code of Ethics
        * 2.2.1.1 Highest level of service to all users
        * 2.2.1.2 Intellectual freedom
        * 2.2.1.3 Privacy and confidentiality
        * 2.2.1.4 Intellectual property rights
        * 2.2.1.5 Respecting fellow library workers
        * 2.2.1.6 Non-advancement of private interests
        * 2.2.1.7 Distinguishing between personal convictions and professional duties
        * 2.2.1.8 Excellence in the profession
      * 2.2.2 Other Codes of Ethics
        * 2.2.2.1 Society of American Archivists Core Values Statement and Code of Ethics
        * 2.2.2.2 The Hacker Ethic
          * 2.2.2.2.1 Access to computers
          * 2.2.2.2.2 Information should be free
          * 2.2.2.2.3 Mistrust authority
          * 2.2.2.2.4 Meritocracy
          * 2.2.2.2.5 Art and beauty
          * 2.2.2.2.6 Computers can change your life
          * 2.2.2.2.7 Sharing
          * 2.2.2.2.8 Hands-On Imperative
          * 2.2.2.2.9 Community and collaboration
        * 2.2.2.3 Protocols for Native American Archival Materials
    * 2.3 References
  * 3 Information Policy
    * 3.1 Collection development
    * 3.2 Confidentiality
    * 3.3 Control of information
    * 3.4 Copyright
    * 3.5 Digital Rights Management
    * 3.6 Fines and fine waiving
    * 3.7 Government information
    * 3.8 International information policy
    * 3.9 Outsourcing
    * 3.10 Web content filters
    * 3.11 References
  * 4 Information Organization
    * 4.1 Why organize information?
    * 4.2 Bibliography
      * 4.2.1 Subject guides
    * 4.3 Bibliographic metadata
      * 4.3.1 Cataloging
        * 4.3.1.1 Authority control
        * 4.3.1.2 MARC formats
        * 4.3.1.3 Bibliographic framework (BIBFRAME)
        * 4.3.1.4 Functional Requirements for Bibliographic Records
      * 4.3.2 Classification
        * 4.3.2.1 Dewey Decimal Classification
        * 4.3.2.2 Taxonomies vs. folksonomies
    * 4.4 Information architecture
    * 4.5 Information retrieval
    * 4.6 The Semantic Web, RDF, and linked data
    * 4.7 Knowledge management
    * 4.8 General issues in information organization
      * 4.8.1 The politics of information organization
    * 4.9 Notes
    * 4.10 References
  * 5 Information Seeking
    * 5.1 Scientific and academic research
    * 5.2 References
  * 6 Re-contextualizing Libraries: Considering Libraries within Their Communities
    * 6.1 The library as community space
      * 6.1.1 The library as third place
    * 6.2 Library service to specific communities
      * 6.2.1 Economically poor
      * 6.2.2 Information poor
      * 6.2.3 People with disabilities
      * 6.2.4 Rural communities
      * 6.2.5 Youth services
        * 6.2.5.1 Who has the authority to determine what children read?
    * 6.3 Library-community relations
      * 6.3.1 Outreach services
      * 6.3.2 Library advocacy work
    * 6.4 References
  * 7 Technology and Libraries: Impacts and Implications
    * 7.1 Technology and LIS: a historical perspective
    * 7.2 Implementing information technologies in libraries
    * 7.3 Digital libraries and services
      * 7.3.1 Digital libraries
      * 7.3.2 Virtual reference
    * 7.4 Access to technology
    * 7.5 Physical libraries in a cyber world
    * 7.6 Cost of adoption
    * 7.7 Conclusion: Rutenbeck's "Five great challenges"
      * 7.7.1 Malleability
      * 7.7.2 Selectivity
      * 7.7.3 Exclusivity
      * 7.7.4 Vulnerability
      * 7.7.5 Superficiality
      * 7.7.6 Conclusion
    * 7.8 References
  * 8 Transcending Boundaries: Global Issues and Trends
  * 9 Learning More: Free LIS Resources
    * 9.1 Reference sources
    * 9.2 Peer-reviewed Journals
      * 9.2.1 Non-English
  * 10 List of Contributors

# Contextualizing Libraries: Their History and Place in the Wider Information Infrastructure[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=1)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Next Chapter**

[Ethics and Values in the Information Professions](/wiki/Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions) →

  
This chapter will draw on two important fields to define roles and contexts for librarianship and other information work. First, we will explore the many diverse roles libraries have played throughout history, exploring the different motivations for libraries and services library workers have provided towards these motivations. We will then look at how different individuals and fields conceive of information in today's world, and how these conceptions inform their practice. We will conclude by drawing on historical LIS practice and lessons learned from related disciplines to establish roles and a scope for contemporary LIS practice and scholarship.

After reading this chapter, a student should have an understanding of:

  * a general history of libraries
  * the many diverse roles played by libraries throughout history
  * the value of critically examining library history to inform current library practice
  * different ways of looking at information
  * fields related to LIS, and their common and divergent goals

## Libraries of the past[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-1)]

This section will introduce characteristics and purposes of libraries throughout time, and then introduce some critical issues and methods of library history.

### A brief history of libraries[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-2)]

#### Early libraries (2600 BC – 800 BC)[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Library_of_Ashurbanipal_The_Flood_Tablet.jpg/220px-Library_of_Ashurbanipal_The_Flood_Tablet.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Tablet from the Library of Ashurbanipal containing part of the Epic of Gilgamesh

The first libraries consisted of archives of the earliest form of writing - the clay tablets in cuneiform script discovered in temple rooms in Sumer[1].

The earliest discovered private archives were kept at Ugarit (in present-day Syria); besides correspondence and inventories, texts of myths may have been standardized practice-texts for teaching new scribes. There is also evidence of libraries at Nippur about 1900 BC and those at Nineveh about 700 BC showing a library classification system.[2]

Over 30,000 clay tablets from the Library of Ashurbanipal have been discovered at Nineveh,[3] providing modern scholars with an amazing wealth of Mesopotamian literary, religious and administrative work. Among the findings were the Enuma Elish, also known as _the Epic of Creation,_[4] which depicts a traditional Babylonian view of creation, the Epic of Gilgamesh,[5] a large selection of "omen texts" including _Enuma Anu Enlil_ which "contained omens dealing with the moon, its visibility, eclipses, and conjunction with planets and fixed stars, the sun, its corona, spots, and eclipses, the weather, namely lightning, thunder, and clouds, and the planets and their visibility, appearance, and stations",[6] and astronomic/astrological texts, as well as standard lists used by scribes and scholars such as word lists, bilingual vocabularies, lists of signs and synonyms, and lists of medical diagnoses.

Philosopher Laozi was keeper of books in the earliest library in China, which belonged to the Imperial Zhou dynasty.[7] Also, evidence of catalogues found in some destroyed ancient libraries illustrates the presence of librarians.[7]

#### Classical period (800 BC – 500 AD)[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/64/Ancientlibraryalex.jpg/220px-Ancientlibraryalex.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Artistic rendering of the Library of Alexandria, based on some archaeological evidence

##### The Library of Alexandria[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-5)]

The Library of Alexandria, in Egypt, was the largest and most significant great library of the ancient world. It flourished under the patronage of the Ptolemaic dynasty and functioned as a major center of scholarship from its construction in the 3rd century BC until the Roman conquest of Egypt in 30 BC. The library was conceived and opened either during the reign of Ptolemy I Soter (323–283 BC) or during the reign of his son Ptolemy II (283–246 BC).[8] An early organization system was in effect at Alexandria.[8]

Much of what we know about the Alexandrian library is not based on verifiable fact, but rather a collection of stories, many of which we should forego according to Jochum’s research. There are no physical remnants of the library left, only written allusions from classical writers, but he believes that the great library did not exist merely as single building. The Alexandrian library claimed to have contained every book on every subject in every language. The methods for acquiring these books varied. One reported method was to employ traders to buy books wherever they could be found. Another claimed that books were confiscated from ships in the Alexandrian harbor, then copied for the library and returned to their owners. Catalogs were made of the collection’s books, including the metadata on the original owners and where the copy was copied or written.

Today, the thought of a library containing every book on every subject in every known is impossible, especially as technology advances. As long ago as 1976, having the information available digitally was proposed as the way to emulate the ideal of the Alexandrian library. The economies offered by digitalization can get us access to the type of knowledge sought by the Greeks. Jochum offers that the Alexandrian may not have existed as the ultimate facility. Once we can weed out the lore from fact, we can then begin to move forward with the library as a learning center instead of a just physical repository for books.[9]

##### Other Classical libraries[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-6)]

Private or personal libraries made up of written books (as opposed to the state or institutional records kept in archives) appeared in classical Greece in the 5th century BC. The celebrated book collectors of Hellenistic Antiquity were listed in the late 2nd century in _Deipnosophistae_. All these libraries were Greek; the cultivated Hellenized diners in _Deipnosophistae_ pass over the libraries of Rome in silence. By the time of Augustus there were public libraries near the forums of Rome: there were libraries in the Porticus Octaviae near the Theatre of Marcellus, in the temple of Apollo Palatinus, and in the Bibliotheca Ulpiana in the Forum of Trajan. The state archives were kept in a structure on the slope between the Roman Forum and the Capitoline Hill.

Private libraries appeared during the late republic: Seneca the Younger inveighed against libraries fitted out for show by illiterate owners who scarcely read their titles in the course of a lifetime, but displayed the scrolls in bookcases (_armaria_) of citrus wood inlaid with ivory that ran right to the ceiling: "by now, like bathrooms and hot water, a library is got up as standard equipment for a fine house (_domus_).[10] Libraries were amenities suited to a villa, such as Cicero's at Tusculum, Maecenas's several villas, or Pliny the Younger's, all described in surviving letters. At the Villa of the Papyri at Herculaneum, apparently the villa of Caesar's father-in-law, the Greek library has been partly preserved in volcanic ash; archaeologists speculate that a Latin library, kept separate from the Greek one, may await discovery at the site.

In the West, the first public libraries were established under the Roman Empire as each succeeding emperor strove to open one or many which outshone that of his predecessor. Unlike the Greek libraries, readers had direct access to the scrolls, which were kept on shelves built into the walls of a large room. Reading or copying was normally done in the room itself. The surviving records give only a few instances of lending features. As a rule, Roman public libraries were bilingual: they had a Latin room and a Greek room. Most of the large Roman baths were also cultural centres, built from the start with a library, a two room arrangement with one room for Greek and one for Latin texts.

Libraries were filled with parchment scrolls as at Library of Pergamum and on papyrus scrolls as at Alexandria: the export of prepared writing materials was a staple of commerce. There were a few institutional or royal libraries which were open to an educated public (such as the Serapeum collection of the Library of Alexandria, once the largest Great library in the ancient world),[8] but on the whole collections were private. In those rare cases where it was possible for a scholar to consult library books there seems to have been no direct access to the stacks. In all recorded cases the books were kept in a relatively small room where the staff went to get them for the readers, who had to consult them in an adjoining hall or covered walkway.

Han Chinese scholar Liu Xiang established the first library classification system during the Han Dynasty,[11] and the first book notation system. At this time the library catalogue was written on scrolls of fine silk and stored in silk bags.

#### Middle Ages (501 AD – 1400 AD)[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-7)]

In the 6th century, at the very close of the Classical period, the great libraries of the Mediterranean world remained those of Constantinople and Alexandria.  
Cassiodorus, minister to Theodoric, established a monastery at Vivarium in the heel of Italy with a library where he attempted to bring Greek learning to Latin readers and preserve texts both sacred and secular for future generations. As its unofficial librarian, Cassiodorus not only collected as many manuscripts as he could, he also wrote treatises aimed at instructing his monks in the proper uses of reading and methods for copying texts accurately. In the end, however, the library at Vivarium was dispersed and lost within a century.

Through Origen and especially the scholarly presbyter Pamphilus of Caesarea, an avid collector of books of Scripture, the theological school of Caesarea won a reputation for having the most extensive ecclesiastical library of the time, containing more than 30,000 manuscripts: Gregory Nazianzus, Basil the Great, Jerome and others came and studied there.

By the 8th century first Iranians and then Arabs had imported the craft of papermaking from China, with a paper mill already at work in Baghdad in 794. By the 9th century public libraries started to appear in many Islamic cities. They were called "halls of Science" or _dar al-'ilm_. They were each endowed by Islamic sects with the purpose of representing their tenets as well as promoting the dissemination of secular knowledge. The 9th century Abbasid Caliph al-Mutawakkil of Iraq, ordered the construction of a "zawiyat qurra" – an enclosure for readers which was "lavishly furnished and equipped".  
In Shiraz, Adhud al-Daula (d. 983) set up a library, described by the medieval historian al-Muqaddasi as "a complex of buildings surrounded by gardens with lakes and waterways. The buildings were topped with domes, and comprised an upper and a lower story with a total, according to the chief official, of 360 rooms.... In each department, catalogs were placed on a shelf... the rooms were furnished with carpets".[12]  
The libraries often employed translators and copyists in large numbers, in order to render into Arabic the bulk of the available Persian, Greek, Roman and Sanskrit non-fiction and the classics of literature.  
This flowering of Islamic learning ceased centuries later, after many of these libraries were destroyed by Mongol invasions. Others were victim of wars and religious strife in the Islamic world. However, a few examples of these medieval libraries, such as the libraries of Chinguetti in West Africa, remain intact and relatively unchanged. Another ancient library from this period which is still operational and expanding is the Central Library of Astan Quds Razavi in the Iranian city of Mashhad, which has been operating for more than six centuries.

The contents of these Islamic libraries were copied by Christian monks in Muslim/Christian border areas, particularly Spain and Sicily. From there they eventually made their way into other parts of Christian Europe. These copies joined works that had been preserved directly by Christian monks from Greek and Roman originals, as well as copies Western Christian monks made of Byzantine works.

Buddhist scriptures, educational materials, and histories were stored in libraries in pre-modern Southeast Asia. In Burma, a royal library called the Pitaka Taik was legendarily founded by King Anawrahta;[13] in the 18th century, British envoy Michael Symes, upon visiting this library, wrote that "it is not improbable that his Birman majesty may possess a more numerous library than any potentate, from the banks of the Danube to the borders of China". In Thailand libraries called ho trai were built throughout the country, usually on stilts above a pond to prevent bugs from eating at the books.

In the Early Middle Ages, monastery libraries developed, such as the important one at the Abbey of Montecassino. Books were usually chained to the shelves, and these chained libraries reflected the fact that manuscripts, created via the labour-intensive process of hand copying, were valuable possessions.[14] Despite this protectiveness, many libraries loaned books if provided with security deposits (usually money or a book of equal value). Lending was a means by which books could be copied and spread. In 1212 the council of Paris condemned those monasteries that still forbade loaning books, reminding them that lending is "one of the chief works of mercy."[15] The early libraries located in monastic cloisters and associated with scriptoria were collections of lecterns with books chained to them. Shelves built above and between back-to-back lecterns were the beginning of bookpresses. The chain was attached at the fore-edge of a book rather than to its spine. Book presses came to be arranged in carrels (perpendicular to the walls and therefore to the windows) in order to maximize lighting, with low bookcases in front of the windows. This "stall system" (fixed bookcases perpendicular to exterior walls pierced by closely spaced windows) was characteristic of English institutional libraries. In European libraries, bookcases were arranged parallel to and against the walls. This "wall system" was first introduced on a large scale in Spain's El Escorial.

#### Renaissance[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-8)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Biblioteca_medicea_laurenziana_interno_01.JPG/220px-Biblioteca_medicea_laurenziana_interno_01.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Reading room of the Laurentian Library

In Rome, the papal collections were brought together by Pope Nicholas V, in separate Greek and Latin libraries, and housed by Pope Sixtus IV, who consigned the Bibliotheca Apostolica Vaticana to the care of his librarian, the humanist Bartolomeo Platina in February 1475.[16]

The 16th and 17th centuries saw other privately endowed libraries assembled in Rome: the Vallicelliana, formed from the books of Saint Filippo Neri, with other distinguished libraries such as that of Cesare Baronio, the Biblioteca Angelica founded by the Augustinian Angelo Rocca, which was the only truly public library in Counter-Reformation Rome; the Biblioteca Alessandrina with which Pope Alexander VII endowed the University of Rome; the Biblioteca Casanatense of the Cardinal Girolamo Casanate; and finally the Biblioteca Corsiniana founded by the bibliophile Clement XII Corsini and his nephew Cardinal Neri Corsini, still housed in Palazzo Corsini in via della Lungara.

The Republic of Venice patronized the foundation of the Biblioteca Marciana, based on the library of Cardinal Basilios Bessarion. In Milan, Cardinal Federico Borromeo founded the Biblioteca Ambrosiana. This trend soon spread outside of Italy, for example Louis III, Elector Palatine founded the Bibliotheca Palatina of Heidelberg. These libraries don't have so many volumes as the modern libraries. However, they keep many valuable manuscripts of Greek, Latin and Biblical works.

Tianyi Chamber, founded in 1561 by Fan Qin during the Ming Dynasty, is the oldest surviving library in China. In its heyday it boasted a collection of 70,000 volumes of antique books.

#### 17th and 18th centuries[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-9)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Vogel_Za%C5%82uski_Library.jpg/220px-Vogel_Za%C5%82uski_Library.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Załuski Library, Warsaw

During the 17th and 18th centuries, some of the more important European libraries were founded, such as the Bodleian Library at Oxford, the British Museum Library in London, the Mazarine Library and the Bibliothèque Sainte-Geneviève in Paris, the Austrian National Library in Vienna, the National Central Library in Florence, the Prussian State Library in Berlin, the Załuski Library in Warsaw and the M.E. Saltykov-Shchedrin State Public Library of St Petersburg.[17]

The 18th century is when we see the beginning of the modern public library. In France, the French Revolution saw the confiscation in 1789 of church libraries and rich nobles' private libraries, and their collections became state property. The confiscated stock became part of a new national library – the Bibliothèque Nationale. Two famous librarians, Hubert-Pascal Ameilhon and Joseph Van Praet, selected and identified over 300,000 books and manuscripts that became the property of the people in the _Bibliothèque Nationale_.[18] During the French Revolution, librarians were solely responsible for the bibliographic planning of the nation. Out of this came the implementation of the concept of library service – the democratic extension of library services to the general public regardless of wealth or education.[18]

#### 19th century[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-10)]

#### 20th century[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-11)]

Stephen Cresswell reviews literature concerning libraries, the civil rights movement and the end of segregation in Southern libraries. The ALA did not actively support library integration. As Rubin notes, until the 1960s, the ALA considered itself an association representing only its constituency of librarians (Rubin, 294). Efforts by the ALA included:

  1. The 1936 decision to boycott convention cities where hotels and restaurants were segregated.
  2. In the late 1950s and 1960s ALA denied membership to segregated state library associations and ruled a state could have only one state association.
  3. The 1961 amendment to the Library Bill of Rights stated that the right of an individual to the use of a library should not be abridged because of his race, religion, national origins or political views.
  4. In 1962 the organization undertook an “Access Study” to evaluate freedom of access throughout the country.

The study revealed more segregation and inequities in libraries in northern cities than in the South. Northern libraries were sometimes the focus of destructive demonstrations. In the South they were often the first focus of civil rights demonstrations rather than schools, because they evoked sympathy for the individual’s right to learn, rather than the more emotional reactions to integrating public schools.

[19]

### Issues in library history[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-12)]

#### Ahistoricism[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-13)]

Lancaster, F.W. (1978). Toward paperless information systems.

Harris and Hannah (1992). Why do we study the history of libraries?

Black, Alastair. "Information and Modernity: The History of Information and the Eclipse of Library History." Library History 14 (May 1998): 39-45.

#### Gender[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-14)]

Garrison, writing in 1972, highlights a problem of the public image of librarianship: it has not attained the status of the more scientific professions such as doctor, sociologist, etc. One possible reason, the one central to this article, is the entrée of women into the field during the Victorian era. Garrison examines three tenets that make a profession: service, knowledge, and autonomy. Librarians, as professionals, serve their clients (community or society); female librarians, on the other hand, were to be almost subservient. The knowledge required of a librarian, considered highly educated for a woman at the time, lacked the standardized training for a doctor. Libraries were governed by boards populated by men, not female librarians, who made key decisions. Garrison concludes that until library science comes to terms with women’s early employment in libraries and the way it has shaped the current assumptions, it will never attain the rank of other professions. Garrison provides a lively essay on the history of female librarians and its manifestations today. Her perspective, however, is colored by feminism’s second wave in the 1970s.

Perhaps the public image of librarianship today should not focus so much on doctors and sociologists, but the more technology-based professions under the information science umbrella. For instance, librarians are not seen as the driving force behind innovation like software engineers and others in the IT field. Would an analysis of women in the early stages of librarianship give insight into why some have trouble with the information science moniker?[20]

Even though the profession of a librarian is considered "women's work" there are men who have chosen this profession. However, they usually hold positions of upper management and other higher paying areas. What exactly is "women's work" within the library environment? Suzanne Hildenbrand argues that cataloging and services for children and youth are most often seen in this way. There are statistics that show these two positions are the lowest paid and are not held in high esteem within the library workplace. The author raises a great point that what needs to be focused on is not the movement of women into management positions and other high paying positions but one that focuses on the equality of salaries and conditions within the most female concentrated specialties up to the standard of the profession [21]

#### Inclusions and exclusions[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-15)]

Before 1960, there were no public library services for ethnic minorities. During the 1960’s and 1970’s, many attempts to design and develop library services for ethnic groups were put into motion. The cultural programs that flourished were programs that had adequate federal funding for services and experimentation. Other factors that contributed to successful programs:

  * Recruitment of appropriate staff to identify information needs and promote library programs
  * Involvement by the community in planning and developing services
  * Developed mechanisms that enable the community to identify its own needs
  * Link the needs to the expertise of librarians

Ethnic library services have been dropping gradually since 1981; and libraries are still failing to include: books, periodicals, films, recording, and archives that relate to various minority groups. Rethinking ideas to meet different needs is required when there are demographic changes, and libraries should take proper steps to appeal to everyone [22].

It is important to have a diverse staff, particularly when a diverse clientele is involved. There has been a decrease in college enrollment amongst minorities; and in 1991-1992, only 8.5% of the Library and Information Science graduates were minorities. There are five tasks administrators and librarians should implement, so the number of graduates increase in the library program:

  * Cooperative efforts to hire minority graduates
  * Additional monetary incentives ? scholarships, tuition waivers, and housing
  * Recruitment activities aimed at students as early as the junior high school
  * Recruitment of nontraditional students from military or community colleges
  * Development of an academic and social environment on campus conducive to success

In 1993, a few efforts have been made to recruit minorities, but none had been particularly successful. In order to make recruitment more successful, it must be considered a priority [23]

Salvador Guerena and Edward Erazo have three recommendations for the future of Latinos and libraries:

  1. Increase recruitment, retention, and mentoring of bilingual/ bicultural Latino professional personnel.
  2. Include members of the Latino community in the process of planning library services for the community.
  3. Foster networking among libraries providing service to the Latino community.

Hispanics represent the fastest growing demographic group in the United States, but Latino librarianship has remained constant at 1.8% of librarians. Shortages of bilingual librarians will continue to increase. Foreign language proficiency is not required of library schools so graduates are not prepared to serve the needs of the Latino community. REFORMA, LSTA, and ALA have been advocates for training, improving technology and curriculum in response to changing multicultural, multiethnic and multilingual society. The article is informative yet pessimistic. It recognizes the technological divide in the Hispanic community and the need for education and availability of computers in libraries. The affordability of computers has not increased ownership of computers in their homes. In West Chicago Middle School, many Latino students use the computers in the classroom to complete their assignments. For many of these students, high school will be the end of their formal education. At the Olcott library, the greatest demand for Spanish titles comes from Miami and Los Angeles not locally. A telling observation of the article is that Hispanics do not feel welcome in libraries because Hispanics feel libraries are Anglo American institutions run by and for Anglo Americans.[24]

#### Tunnel vision[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-16)]

Wayne Weigand says that "a constant re-examination of our past [...] can show the parameters of tunnel vision and reveal many of the blind spots". Librarians often act as "stewards" of the past, which may mean perpetuating many of the past's close-minded views.[25]

  
Library collections, like the steward-librarians Weigand mentions are "products of our pasts". Unless we have the luxury of throwing out our entire collection and starting anew, we are stuck with including the tunnel vision of the past in our libraries.

## Libraries in the information age[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-17)]

### Defining information[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-18)]

There are many ways of defining and conceptualizing _information_. Definitions can focus on the technical aspects of information, or the societal aspects.

#### Technical aspects[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-19)]

##### Information as a sequence of symbols[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-20)]

In its most restricted technical sense, is a sequence of symbols that can be interpreted as a message. Information can be recorded as signs, or transmitted as signals.

#### Societal aspects[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-21)]

##### Information as a right[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-22)]

In an article written for the Bowker Annual in 1987, Kenneth Dowlin discusses the need for the library profession to ensure that access to information remains available, as a basic human right, to everyone in an age where we are moving from an industrial to an information society. He argues that the mission of libraries should be to develop minimum standards of access and “promote the compatibility of information systems”. Dowlin gives a brief discussion of why information must be considered a human right, and identifies several barriers to this, namely

  1. Legislative barriers
  2. Competitive barriers
  3. Technological barriers
  4. Perceptual barriers
  5. Economic barriers

He then proposes some strategies to reduce these barriers and defines the role the library profession should play in implementing them.

I believe that he is correct in his assessment of the barriers that exist, and that libraries should play a role in ensuring access for all to information, but disagree with most of his proposed solutions, which in my mind are based on false assumptions, which time has borne out. He asks the library profession to implement solutions they are not equipped to deal with and have no control over. The library profession has no way to set standards of technology to ensure access for all. Letting the private sector derive solutions to these barriers, has proven the best way to overcome the barriers he has identified. Although Dowlin’s fundamental statement is correct, it is questionable whether his solutions are practical or achievable in the real world.[26]

##### Information as a commodity[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-23)]

### Quantifying information[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-24)]

There is a plethora of ways to think about information, and those involved in information and knowledge work have a number widely divergent agendas. This can make evaluation of information services very difficult. Some groups attempt to make such evaluation mathematical and scientific, while others rely on tools from the social sciences, such as surveys and studies. The mathematical and scientific groups often try to measure a service's value using calculations and monetary values.

While the United Kingdom conducted a survey that had people evaluate how much service they received and how it contributed to their productivity. The article wasn't necessarily aimed at just the business world. The author did a great job at relating this to the library field by talking about the amount of knowledge you poses and how useful that makes you. It talked about the more knowledgeable you are, the more productive you will be, and the more assistance you will be able to provide. From our discussion last week in class about what makes a good librarian this was one of the major things that we all thought made a good librarian. I feel the more informed and versatile you are in all different aspects, the more you will have to draw upon and offer. All of that contributes to your ability to be more productive for the patrons that you assist.[27]

### Defining knowledge[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-25)]

Knowledge is a general understanding or familiarity with a subject, place, situation, etc. Knowledge can be acquired through experience or education.

#### Information needs[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-26)]

An information need is a gap in a person's knowledge. When a person identifies such a gap, it may be expressed as a question or a search query.

  


#### Education[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-27)]

### Defining libraries[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-28)]

## References[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure&action=edit&section=T-29)]

  1. ↑ Casson, Lionel (11 Aug 2002). _Libraries in the Ancient World_. Yale University Press. p. 3. 
  2. ↑ _The American International Encyclopedia_, New York: J. J. Little & Ives, 1954; Volume IX
  3. ↑ [Britishmuseum.org](http://www.britishmuseum.org/research/research_projects/ashurbanipal_library_phase_1.aspx) "Assurbanipal Library Phase 1", British Museum One
  4. ↑ "Epic of Creation", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 233-81
  5. ↑ "Epic of Gilgamesh", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 50–135
  6. ↑ Van De Mieroop, Marc. _A History of the Ancient Near East ca. 3000–323 BC_. Oxford, UK: Blackwell Publishing, 2007: pg. 263
  7. ↑ _**a**_ _**b**_ Mukherjee, A. K. Librarianship: Its Philosophy and History. Asia Publishing House (1966) p. 86
  8. ↑ _**a**_ _**b**_ _**c**_ Phillips, Heather A., ["The Great Library of Alexandria?". Library Philosophy and Practice, August 2010](http://unllib.unl.edu/LPP/phillips.htm)
  9. ↑ Jochum, Uwe. “The Alexandrian Library and Its Aftermath.” Library History 15 (May 1999): 5-12.
  10. ↑ Seneca, _De tranquillitate animi_ ix.4–7.
  11. ↑ Zurndorfer, Harriet Thelma (1995). _China bibliography: a research guide ... – Google Books_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-90-04-10278-1](/wiki/Special:BookSources/978-90-04-10278-1). 
  12. ↑ Goeje, M. J. de, ed (1906). "Al-Muqaddasi: Ahsan al-Taqasim" (in Arabic). _Bibliotheca geographorum Arabicorum_. **III**. Leiden: E. J. Brill. pp. 449. 
  13. ↑ _[International dictionary of library histories](http://books.google.com/books?id=Zoq_TtEN54IC&pg=PA29)_, 29
  14. ↑ Streeter, Burnett Hillman (10 Mar 2011). _[The Chained Library_](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Cambridge University Press. [http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Retrieved 6 March 2012. 
  15. ↑ Geo. Haven Putnam (1962). _Books and Their Makers in the Middle Ages_. Hillary. 
  16. ↑ This section on Roman Renaissance libraries follows Kenneth M. Setton, "From Medieval to Modern Library" _Proceedings of the American Philosophical Society_ **104**.4, Dedication of the APS Library Hall, Autumn General Meeting, November, 1959 (August 1960:371–390) p. 372 ff.
  17. ↑ Stockwell, Foster (2000). _A History of Information and Storage Retrieval_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-7864-0840-5](/wiki/Special:BookSources/0-7864-0840-5). 
  18. ↑ _**a**_ _**b**_ Mukherjee, A. K. (1966) _Librarianship: its Philosophy and History_. Asia Publishing House; p. 112
  19. ↑ Cresswell, Stephen. “The Last Days of Jim Crow in Southern Libraries.” Libraries and Culture 31 (summer/fall 1996): 557-573.
  20. ↑ Garrison, Dee. “The Tender Technicians: The Feminization of Public Librarianship, 1876-1905.” Journal of Social History 6 (winter 1972-1973): 131-156.
  21. ↑ Hildenbrand, Suzanne. "'Women's Work' within Librarianship." Library Journal 114 (September 1, 1989): 153-155.
  22. ↑ Trujillo, Roberto G., and Yolanda J. Cuesta, 1989. Service to Diverse Populations. ALA Yearbook of Library and Information Science. Vol. 14: 7-11.
  23. ↑ McCook, Kathleen, and Geist, Paula, 1993. Diversity Deferred: Where are the Minority Librarians? Library Journal. 118: 23-26.
  24. ↑ Guerena, Salvador and Edward Erazo. "Latinos and Librarianship." Library Trends 49 (2000) : 138-181.
  25. ↑ Wayne Wiegand, Tunnel Vision and Blind Spots: What the Past Tells Us about the present; reflections on the twentieth-century history of American librarianship (Library Quarterly, 69:1, Jan. 1999)
  26. ↑ Dowlin, Kenneth E. “Access to Information: A Human Right?” Bowker Annual 32 (1987): 64-68.
  27. ↑ Koenig, Michael E. D. “Information Services and Downstream Productivity.” Annual Review of Information Science and Technology 25 (1990): 55 – 86.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Next Chapter**

[Ethics and Values in the Information Professions](/wiki/Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions) →

# Ethics and Values in the Information Professions[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=2)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Contextualizing Libraries: Their History and Place in the Wider Information Infrastructure](/wiki/Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure)
[Information Policy](/wiki/Introduction_to_Library_and_Information_Science/Information_Policy) →

  


## The Values of librarianship[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-1)]

Values are essential to the success and future of librarianship: they highlight what is "important and worthy in the long run," and help to define our profession. In a literature review on professional values in LIS, Lee Finks argues that these values fall into four categories:

  1. _Professional values_ are inherent in librarianship and include recognizing the importance of service and stewardship; maintaining philosophical values that reflect wisdom, truth, and neutrality; preserving democratic values; and being passionate about reading and books.
  2. _General values_ are "commonly shared by normal, healthy people, whatever their field." Librarians' work, social, and satisfaction values express a commitment to lifelong learning, the importance of tolerance and cooperation, and the need to feel accepted.
  3. _Personal values_ specifically belong to librarians and include humanistic, idealistic, conservative, and aesthetic values.
  4. _Rival values_ threaten the mission of libraries with bureaucratic, anti-intellectual, and nihilistic ideas. Librarians must have faith in the profession's ability to do good. [1]

This section will mainly discuss professional values, but general, personal, and even some rival values will be discussed in this book.

### Defining professional values[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-2)]

In 1999, the ALA formed a task force to "to clarify the core values (credo) of the profession". This task force believed "that without common values, we are not a profession," and proposed the following definition of common goals for our field:

  1. Connection of people to ideas
  2. Assurance of free and open access to recorded knowledge, information and creative works.
  3. Commitment to literacy and learning
  4. Respect for the individuality and the diversity of all peoples
  5. Freedom for all people to form, to hold, and to express their own beliefs
  6. Preservation of the human record
  7. Excellence in professional service to our communities
  8. Formation of partnerships to advance these values [2]

In June 2004, the ALA actually adopted a Core Value Statement, but this statement represented a compromise with critics of the Task Force. The actual statement lists 11 core values pulled from existing ALA policies. [3]

### Ranganathan's five laws[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-3)]

Another way to define and provide direction for our profession was proposed by mathematician and librarian S.R. Ranganathan in 1931. Ranganathan was interested in providing librarianship with a set of fundamental laws, analogous to the scientific laws that serve as fundamental principles for natural and some social sciences. Ranganathan's original laws were:

  * Books are for use.
  * Every reader [their] book.
  * Every book its reader.
  * Save the time of the reader.
  * A library is a growing organism. [4]

Michael Gorman respectfully adjusted Ranganathan's laws to better fit the future needs and practices of libraries. Gorman's revised laws are:

  * Libraries serve humanity- They should serve the individual, community and society to a higher quality. When making decisions, librarians should consider how the change will better serve humanity.
  * Respect all forms by which knowledge is communicated- If there is a new means of communication of knowledge, and it is a better carrier, utilize it.
  * Use technology intelligently to enhance service- Technology needs to be integrated so that it is used intelligently in a cost-effective and beneficial way.
  * Protect free access to knowledge- The library is central to freedom. It needs to preserve all records so none are lost, and should be transmitted to all.
  * Honor the past and create the future- Libraries need to combine the past and future in a rational manner. Not clinging to the past but looking forward for the better. [5]

## Professional Ethics[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-4)]

Once we have defined goals for our profession, we need to make sure that we meet these goals in ethical ways. Library and Information workers are expected to follow certain ethical standards, typically codified in documents called Codes of Ethics. These codes offer a basis for making ethical decisions and applying ethical solutions to situations involving information provision and use.

A major document that codifies professional librarian ethics within the United States is the American Library Association's Code of Ethics. This chapter will examine each article of the ALA's code, and then contrast it with codes that have originated from different communities within LIS. The [following chapter](/wiki/Introduction_to_Library_and_Information_Science/Information_Policy) will examine more closely the real-world implications of these ethical standards, especially when they conflict with the interests of practicality and/or other interest groups.

### The ALA's Code of Ethics[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-5)]

#### Highest level of service to all users[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-6)]

“
We provide the highest level of service to all library users through appropriate and usefully organized resources; equitable service policies; equitable access; and accurate, unbiased, and courteous responses to all requests.
”

#### Intellectual freedom[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-7)]

“
We uphold the principles of intellectual freedom and resist all efforts to censor library resources.
”

Intellectual freedom is a major area of conflict within libraries. While upholding the principles of intellectual freedom is a goal that most library workers, could agree on, and while censorship is never a popular option, the situation in day-to-day library work can present complications to this seemingly simple rule.

Challenged materials.

Another issue, brought up by John Swan, is how libraries should represent points of view that are completely wrong. Swan asks if "Truth" should play the pivotal role as the raison d’etre of libraries, or if libraries serve another cause entirely? His topics for discussion include:

  1. Are libraries committed to "Truth" for legal purposes?
  2. The role of "Truth", "Untruth" and Libraries.
  3. "Truth" is necessary for the law, but "Untruths" are a necessary function of libraries.
  4. Intellectual freedom, not "Truth" should be the driving force for libraries.
  5. Libraries have a duty to present Untruths".

His conclusions are that libraries exist, by their very nature, as forums for ideas. According to Swan, both "Truth" and "Untruth" are necessary in providing information to the public in these forums. The role of libraries is access to both, and in fact one cannot exist without the other. Swan makes distinctions about the differing roles of the legal system, third party groups, libraries and the role that censorship plays from pressure groups. These distinctions are as real and pertinent today as they were 20 years ago, in fact more so, as there is more "conflicting" information available to the public today due to advances in technology (internet, blogs, etc.).[6]

#### Privacy and confidentiality[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-8)]

“
We protect each library user's right to privacy and confidentiality with respect to information sought or received and resources consulted, borrowed, acquired or transmitted.
”

#### Intellectual property rights[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-9)]

“
We recognize and respect intellectual property rights
”

Intellectual property rights are a difficult issue. While most of the rest of the ALA's Code of Ethics talks about how libraries should provide unrestricted access to information, copyright and other intellectual property rights can sometimes provide restrictions on this flow of information. Libraries have taken an active interest in open licensing, free software, and new publication and distribution models that respect the rights of information creators while allowing more widespread access to ideas.

David Dorman asserts that the Open Source Software movement is akin to librarians' views of information. That is, information is public property and as such anyone should have access to it. OSS furthers this by emphasizing the software that holds the information: if control of the software is eliminated, the information itself is more free and accessible. Thus, the Information Control Wars is the battle between those who believe technology should promote free access to information, and those who believe technology should control it for their economic and political gain. Dorman presents a thoughtful treatise on the philosophical, democratic, and tangible merits of OSS. His analysis sheds light on the legal implications of patent and copyright legislation of which the casual supporter of OSS may not be aware.

The discussion of OSS in context with information belonging to all brings to mind SCO Group’s many lawsuits against companies who allegedly copied source code that, OSS advocates argue, was free to begin with. Little SCO taking on the big, bad corporation of IBM, for example, seems on the surface to underscore democracy. But SCO’s claims run against the intent of OSS, and their attempts to extract monies seem ill-founded at best. The question arises nonetheless: how does one determine when intellectual property has been violated in OSS? If there is a violation in the OSS world, what implications does that have for its future? What are the implications for those who support free information and access?[7]

#### Respecting fellow library workers[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-10)]

“
We treat co-workers and other colleagues with respect, fairness and good faith, and advocate conditions of employment that safeguard the rights and welfare of all employees of our institutions.
”

#### Non-advancement of private interests[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-11)]

“
We do not advance private interests at the expense of library users, colleagues, or our employing institutions.
”

#### Distinguishing between personal convictions and professional duties[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-12)]

“
We distinguish between our personal convictions and professional duties and do not allow our personal beliefs to interfere with fair representation of the aims of our institutions or the provision of access to their information resources.
”

  
Librarians have often taken a politically neutral stance as a way to gain professional status. In this literature review, the author argues that by not defining their political values, librarians will be influenced by those with economic and political power. This will threaten the public’s access to information while corporations profit. The author disagrees with a prediction by Thomas Suprenant and Claudia Perry-Holmes that libraries can enhance their “institutional status” by charging patrons and offering “information stamps” to those who cannot pay. They believe the profession can stay alive if librarians focus on “efficiency, productivity, and quality control” and compete with the private sector. Librarians must lose their neutral viewpoints and publicly fight for equal access to information.[8]

The author’s argument is made stronger with examples of how information traditionally handled by the government was turned over to private vendors during the Reagan administration. Library services based on ability to pay, which the author compares to this country’s health care system, would greatly accelerate the digital divide. Since this article was written, librarians have become more outspoken. Legislation following the September 11, 2001, terrorist attacks prompted the ALA to adopt resolutions opposing attempts to restrict access to government information on the basis of national security issues. Librarians’ concerns about the Patriot Act led to proposed legislation and several ALA policies urging user privacy and open access. Librarians are fighting the government for the public’s sake, but they must act before access is threatened, not after it is denied.

#### Excellence in the profession[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-13)]

“
We strive for excellence in the profession by maintaining and enhancing our own knowledge and skills, by encouraging the professional development of co-workers, and by fostering the aspirations of potential members of the profession.
”

### Other Codes of Ethics[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-14)]

#### Society of American Archivists Core Values Statement and Code of Ethics[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-15)]

<http://www2.archivists.org/statements/saa-core-values-statement-and-code-of-ethics>

#### The Hacker Ethic[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-16)]

Hacker ethic is a term for the moral values and philosophy that are standard in the hacker community. The early hacker culture and resulting philosophy originated at the Massachusetts Institute of Technology (MIT) in the 1950s and 1960s. The term _hacker ethic_ is attributed to journalist Steven Levy as described in his 1984 book titled Hackers: Heroes of the Computer Revolution. The key points within this ethic are access, freedom of information, and improvement to quality of life.

As Levy summarized in the preface of _Hackers_, the general tenets or principles of hacker ethic are:

  * Sharing
  * Openness
  * Decentralization
  * Free access to computers
  * World Improvement

In addition to those principles, Levy also described more specific hacker ethics and beliefs in chapter 2, _The Hacker Ethic_:

##### Access to computers[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-17)]

“
Access to computers - and anything which might teach you something about the way the world works - should be unlimited and total. Always yield to the Hands-On Imperative!
”

##### Information should be free[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-18)]

“
All information should be free: Linking directly with the principle of access, information needs to be free for hackers to fix, improve, and reinvent systems. A free exchange of information allows for greater overall creativity.
”

In the hacker viewpoint, almost any system could benefit from an easy flow of information, a concept known as transparency in the social sciences. This is only limited by a concern for maintaining the privacy of certain information, such as medical information. This concept can be seen as roughly analogous to the concept of Intellectual Freedom in the ALA's documents.

The Free Software Foundation notes that "free" refers to unrestricted access; it does not refer to price.[9]

##### Mistrust authority[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-19)]

“
Mistrust authority - promote decentralization: The best way to promote the free exchange of information is to have an open system that presents no boundaries between a hacker and a piece of information or an item of equipment that he needs in [their] quest for knowledge, improvement, and time on-line. Hackers believe that bureaucracies, whether corporate, government, or university, are flawed systems.
”

##### Meritocracy[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-20)]

“
Hackers should be judged by their hacking, not criteria such as degrees, age, race, sex, or position: Inherent in the hacker ethic is a meritocratic system where superficiality is disregarded in esteem of skill.
”

While this is an admirable part of a code of ethics, there is a huge lack of diversity within the hacker community and free culture. The Ada Initiative notes that "[w]omen are one of many groups currently under-represented in several areas of open technology and culture. Recent surveys have shown that around 2-5% of open source developers are women (compared to 20-30% of the larger tech industry), and that women represent just 10-15% of Wikipedia editors."[10] Even though the Hacker Ethic does not place any formal restrictions on participation, it does foster environments in which women are targeted in very specific ways, and attempts to address these issues are seen as censorship.[11]

##### Art and beauty[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-21)]

“
You can create art and beauty on a computer: Hackers deeply appreciate innovative techniques which allow programs to perform complicated tasks with few instructions.
”

##### Computers can change your life[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-22)]

“
Computers can change your life for the better
”

Hackers felt that computers had enriched their lives, given their lives focus, and made their lives adventurous.

##### Sharing[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-23)]

According to Levy's account, sharing was the norm and expected within the non-corporate hacker culture. The principle of sharing stemmed from the open atmosphere and informal access to resources at MIT. During the early days of computers and programming, the hackers at MIT would develop a program and share it with other computer users.

If the hack was particularly good, then the program might be posted on a board somewhere near one of the computers. Other programs that could be built upon it and improved it were saved to tapes and added to a drawer of programs, readily accessible to all the other hackers. At any time, a fellow hacker might reach into the drawer, pick out the program, and begin adding to it or "bumming" it to make it better. Bumming referred to the process of making the code more concise so that more can be done in fewer instructions, saving precious memory for further enhancements.

In the second generation of hackers, sharing was about sharing with the general public in addition to sharing with other hackers. A particular organization of hackers that was concerned with sharing computers with the general public was a group called Community Memory. This group of hackers and idealists put computers in public places for anyone to use. The first community computer was placed outside of Leopold's Records in Berkeley, California.

This second generation practice of sharing contributed to the battles of free and open software. In fact, when [Bill Gates](//en.wikipedia.org/wiki/Bill_Gates)' version of [BASIC](/wiki/BASIC) for the Altair was shared among the hacker community, Gates claimed to have lost a considerable sum of money because few users paid for the software. As a result, Gates wrote an [Open Letter to Hobbyists](//en.wikipedia.org/wiki/Open_Letter_to_Hobbyists).[12][13] This letter was published by several computer magazines and newsletters, most notably that of the [Homebrew Computer Club](//en.wikipedia.org/wiki/Homebrew_Computer_Club) where much of the sharing occurred.

##### Hands-On Imperative[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-24)]

Many of the principles and tenets of hacker ethic contribute to a common goal: the Hands-On Imperative. As Levy described in Chapter 2, "Hackers believe that essential lessons can be learned about the systems—about the world—from taking things apart, seeing how they work, and using this knowledge to create new and more interesting things."

Employing the Hands-On Imperative requires free access, open information, and the sharing of knowledge. To a true hacker, if the Hands-On Imperative is restricted, then the ends justify the means to make it unrestricted _so that improvements can be made_. When these principles are not present, hackers tend to work around them. For example, when the computers at MIT were protected either by physical locks or login programs, the hackers there systematically worked around them in order to have access to the machines. Hackers assumed a "willful blindness" in the pursuit of perfection.

This behavior was not malicious in nature: the MIT hackers did not seek to harm the systems or their users (although occasional practical jokes were played using the computer systems). This deeply contrasts with the modern, media-encouraged image of hackers who crack secure systems in order to steal information or complete an act of cyber-vandalism. Dorothy Denning notes that even hackers who crack secure systems illegally are often motivated by personal morals and beliefs, rather than by malice. [14]

##### Community and collaboration[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-25)]

Throughout writings about hackers and their work processes, a common value of community and collaboration is present. For example, in Levy's _Hackers_, each generation of hackers had geographically based communities where collaboration and sharing occurred. For the hackers at MIT, it was the labs where the computers were running. For the hardware hackers (second generation) and the game hackers (third generation) the geographic area was centered in Silicon Valley where the [Homebrew Computer Club](//en.wikipedia.org/wiki/Homebrew_Computer_Club) and the [People's Computer Company](//en.wikipedia.org/wiki/People%27s_Computer_Company) helped hackers network, collaborate, and share their work.

The concept of community and collaboration is still relevant today, although hackers are no longer limited to collaboration in geographic regions. Now collaboration takes place via the Internet.[15]

#### Protocols for Native American Archival Materials[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-26)]

The Protocols for Native American Archival Materials is a list of best practices for non-tribal institutions that hold Native American archival materials. The protocols have been pretty controversial, partly because of the cost involved; the archivist at the University of Washington said that he would need to hire at least one full-time staff member whose sole job would be ensuring compliance with the protocols.[16] But the main reason is that it goes against a lot of traditional (European) LIS values, such as Universal Access.

Most of the document is about opportunities to collaborate and consult with tribal leaders about the care of materials in archives. However, the short sections on "Accessibility and Use" and "Culturally Sensitive Materials" state that "For Native American communities the public release of or access to specialized information or knowledge—gathered with and without informed consent—can cause irreparable harm. Instances abound of misrepresentation and exploitation of sacred and secret information." As such, the protocols establish expectations of repatriation of certain materials, and allow Native American communities to restrict access to formerly open collections, stating that "[a]ccess to some knowledge may be restricted as a privilege rather than a right."

Another part that bothered some was in the context section, which suggests cataloging practices for describing materials containing pejorative content. I really liked a lot of the suggestions (e.g. one of their sample notes: "The [tribal name] finds information in this work inaccurate or disrespectful. To learn more contact ...."), which I felt added more information for catalog users. At the same time, I felt challenged by other suggestions that involved removing certain content (i.e. their suggestion that librarians "remove offensive terms from original titles and provide substitute language" in catalog records). I understand where this is coming from -- I wouldn't want to look up a book about a community I belong to, only to find words ridiculing that community and challenging its right to exist -- but it also totally challenges my "accept no censorship! Provide lots of access points!" mindset. [17]

## References[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions&action=edit&section=T-27)]

  1. ↑ Casson, Lionel (11 Aug 2002). _Libraries in the Ancient World_. Yale University Press. p. 3. 
  2. ↑ _The American International Encyclopedia_, New York: J. J. Little & Ives, 1954; Volume IX
  3. ↑ [Britishmuseum.org](http://www.britishmuseum.org/research/research_projects/ashurbanipal_library_phase_1.aspx) "Assurbanipal Library Phase 1", British Museum One
  4. ↑ "Epic of Creation", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 233-81
  5. ↑ "Epic of Gilgamesh", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 50–135
  6. ↑ Van De Mieroop, Marc. _A History of the Ancient Near East ca. 3000–323 BC_. Oxford, UK: Blackwell Publishing, 2007: pg. 263
  7. ↑ _**a**_ _**b**_ Mukherjee, A. K. Librarianship: Its Philosophy and History. Asia Publishing House (1966) p. 86
  8. ↑ _**a**_ _**b**_ _**c**_ Phillips, Heather A., ["The Great Library of Alexandria?". Library Philosophy and Practice, August 2010](http://unllib.unl.edu/LPP/phillips.htm)
  9. ↑ Jochum, Uwe. “The Alexandrian Library and Its Aftermath.” Library History 15 (May 1999): 5-12.
  10. ↑ Seneca, _De tranquillitate animi_ ix.4–7.
  11. ↑ Zurndorfer, Harriet Thelma (1995). _China bibliography: a research guide ... – Google Books_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-90-04-10278-1](/wiki/Special:BookSources/978-90-04-10278-1). 
  12. ↑ Goeje, M. J. de, ed (1906). "Al-Muqaddasi: Ahsan al-Taqasim" (in Arabic). _Bibliotheca geographorum Arabicorum_. **III**. Leiden: E. J. Brill. pp. 449. 
  13. ↑ _[International dictionary of library histories](http://books.google.com/books?id=Zoq_TtEN54IC&pg=PA29)_, 29
  14. ↑ Streeter, Burnett Hillman (10 Mar 2011). _[The Chained Library_](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Cambridge University Press. [http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Retrieved 6 March 2012. 
  15. ↑ Geo. Haven Putnam (1962). _Books and Their Makers in the Middle Ages_. Hillary. 
  16. ↑ This section on Roman Renaissance libraries follows Kenneth M. Setton, "From Medieval to Modern Library" _Proceedings of the American Philosophical Society_ **104**.4, Dedication of the APS Library Hall, Autumn General Meeting, November, 1959 (August 1960:371–390) p. 372 ff.
  17. ↑ Stockwell, Foster (2000). _A History of Information and Storage Retrieval_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-7864-0840-5](/wiki/Special:BookSources/0-7864-0840-5). 
  18. ↑ _**a**_ _**b**_ Mukherjee, A. K. (1966) _Librarianship: its Philosophy and History_. Asia Publishing House; p. 112
  19. ↑ Cresswell, Stephen. “The Last Days of Jim Crow in Southern Libraries.” Libraries and Culture 31 (summer/fall 1996): 557-573.
  20. ↑ Garrison, Dee. “The Tender Technicians: The Feminization of Public Librarianship, 1876-1905.” Journal of Social History 6 (winter 1972-1973): 131-156.
  21. ↑ Hildenbrand, Suzanne. "'Women's Work' within Librarianship." Library Journal 114 (September 1, 1989): 153-155.
  22. ↑ Trujillo, Roberto G., and Yolanda J. Cuesta, 1989. Service to Diverse Populations. ALA Yearbook of Library and Information Science. Vol. 14: 7-11.
  23. ↑ McCook, Kathleen, and Geist, Paula, 1993. Diversity Deferred: Where are the Minority Librarians? Library Journal. 118: 23-26.
  24. ↑ Guerena, Salvador and Edward Erazo. "Latinos and Librarianship." Library Trends 49 (2000) : 138-181.
  25. ↑ Wayne Wiegand, Tunnel Vision and Blind Spots: What the Past Tells Us about the present; reflections on the twentieth-century history of American librarianship (Library Quarterly, 69:1, Jan. 1999)
  26. ↑ Dowlin, Kenneth E. “Access to Information: A Human Right?” Bowker Annual 32 (1987): 64-68.
  27. ↑ Koenig, Michael E. D. “Information Services and Downstream Productivity.” Annual Review of Information Science and Technology 25 (1990): 55 – 86.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Contextualizing Libraries: Their History and Place in the Wider Information Infrastructure](/wiki/Introduction_to_Library_and_Information_Science/Contextualizing_Libraries:_Their_History_and_Place_in_the_Wider_Information_Infrastructure)
[Information Policy](/wiki/Introduction_to_Library_and_Information_Science/Information_Policy) →

# Information Policy[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=3)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Ethics and Values in the Information Professions](/wiki/Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions)
[Information Organization](/wiki/Introduction_to_Library_and_Information_Science/Information_Organization) →

Librarians are far from the only players in today's Information Age. A huge number of people and organizations have a say in how information is created, used, stored, accessed, and disseminated. Each of these parties is influenced by widely divergent goals, world views, and professional ethics.

These divergent viewpoints often come to the fore in debates over **Information Policy**. An information policy is a _public law, regulation or policy that encourages, discourages, or regulates the creation, use, storage, access, and communication and dissemination of information._[18]

Librarians and other information workers are often involved in creating and transforming information policy, and invariably feel the effects of these policies. This chapter will discuss a number of Information Policy debates of particular interest to the LIS community.

  


## Collection development[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-1)]

Collection development is _the process of planning and building a useful and balanced collection of library materials_[19]. Collection development policies provide guidelines for people who select materials for library collections, and can also be used to evaluate selectors' choices, to see if they were indeed appropriate for the library's collection.

Public libraries particularly face a "quality vs. demand" problem. Librarians are experts in book selection, and have tools, such as professional reviews, to guide them in choosing good books for their collections. However, this does not always mean that their selections are popular with their patrons.

The tension between "quality" and "demand" is often discussed in reference to the case of the Baltimore County Public Library's approach to collection development from the 1980s. When the library considered the fees they were paying to convert to online records, they began to wonder if every item was earning its keep. They checked circulation statistics for each item. Material that didn't circulate frequently enough was withdrawn. More attention was paid to areas of the collection that circulated well. More copies of bestsellers were purchased.

This approach was criticized as not being actual collection development, but just mindless reading of statistics. In an article for Library Journal, Nora Rawlinson, then head of materials selection at Baltimore County Public Library, admitted that it is easy to select popular items, but other material is carefully considered before being purchased for the collection. Esoteric material is rejected and fair service to patrons is considered when selecting. The diverse interests of their patrons can be met because they reduced staff and increased the book budget. The approach was successful: surveys showed that patrons were satisfied, and the library received a significant number more interlibrary loan requests than it made. The fears that the library would devolve into a collection stuffed with bestsellers and little material of real value were unfounded.

Although these collection practices were originally controversial for some libraries, Baltimore County's choice to use a combination of popularity (as represented by circulation statistics) and professional judgement has been widely adopted by many public libraries [20].

  


## Confidentiality[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-2)]

The 2001 USA PATRIOT Act has changed how the United States Federal Government can obtain information. The Federal Bureau of Investigation has used the act to ask libraries which books patrons checked out, what databases patrons used, and what reference questions they asked. Ultimately, it requires a court order for libraries to turn over such records and information about patrons. A court decision in Colorado ruled that an adversarial hearing was allowed before a search warrant could be enacted. The PATRIOT ACT permits surveillance, allows for searches without probable cause, and enforces secrecy. All the FBI has to assert in its investigation is that terrorism is involved.

Library staff members should keep in mind that they should not turn over records to anyone without a warrant. In an article for _Library Journal_, Mary Minow suggests that all libraries have a plan involving staff training, supervising, having a lawyer present if a warrant has been issued, and procedures for handling the requests for information. Is library patron record privacy trivial compared to stopping terrorism? Several organizations asked for an account by the Department of Justice of the investigations carried out by the FBI since the passing of the Patriot Act. At the time of Minow's article, the information requested was termed "classified" and not available to the public [21].

## Control of information[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-3)]

This editorial states the situation of three specific libraries in Ohio whose hazardous materials emergency plans were removed without notice and without due cause by agents of the Department of Homeland Security. The pretense given by the agents in viewing the plans was that they were there to update it; instead, they took the plans to be stored at a Homeland Security office, where “proper ID may be required” for viewing. Since the areas affected were at risk for terrorist activities in that there was an oil refinery and a tank manufacturing plant in the area, the affected librarians did not necessarily take offense to the removal of these documents given the political climate, but rather the way the information was unceremoniously taken from them.

To remove information that could be vital to some, yet be used as a dangerous tool by others walks a fine line between looking out for the public good and censorship. The Department of Homeland Security manhandled this situation by treating the librarians, and indirectly their patrons, as bothersome pests because of a need to possess information. In the class discussions, the topic of information as a commodity always comes to the issue of who should control information. All parties involved have their own agenda, and in this case the government may have cloaked their desire to remove potentially damaging environmental data under the guise of preventing another terrorist attack.[22]

  


## Copyright[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-4)]

How does copyright apply to libraries?

  * Libraries are often the only entities that provide access to the vast majority of copyrighted works before the expiration of the copyright, and to works that lose commercial vitality before the copyright expires (i.e. go out of print but are still legally protected).
  * First sale doctrine (1908) enables libraries to lend books and other resource 
    * Except software gets dicier, because of End-user license agreements (EULAs)
  * Fair use allows for the use of (usually tiny snippets of) copyrighted works for purposes of criticism, comment, news reporting, scholarship, or research.
  * Libraries are permitted to make reproductions of copyrighted works for preservation and replacement purposes.
  * Libraries can aid in the transformation and reproduction of copyrighted works for users with disabilities.
  * Libraries often play an archival function with print works. Can they do this in the highly copyrighted, license-agreemented world of electronic information? Electronic resources tend to have a very short shelf life, and may not be archived properly for future use.
  * Digital Rights Management technologies often don't recognize any limitations to copyright, and just go ahead and restrict access.

The Teach Act helps redefine the terms and conditions of copyright laws, focusing on copyright protected materials in distance education. The act puts more pressure on the educational institution, rather than the educator; but there are several benefits because of the Teach Act: expanded range of allowed works, expansion of receiving locations, storage of transmitted content, and digitizing of analog works. It is important for educators to be aware of copyright information, the number of students enrolled in class, and the amount of time allotted to view the material. If they are cognizant of them, they will not have to worry about breaking the law. Since distance education is growing, librarians are expected to deal with interlibrary loans more often, amongst other new opportunities, and need to understand the Teach Act too. Kenneth brings up several points that are essential to remember about the Teach Act. Distance learning is growing rather quickly, and is becoming more popular amongst the student population. Because of this rapid growth, librarians are asked to perform several new tasks that coincide with the act. Librarians need to be familiar with the Teach Act, so no laws are broken, and all materials remain protected.[23]

## Digital Rights Management[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-5)]

In this editorial the authors propose that libraries must be involved in the development of digital rights management policies and the selection and implementation of appropriate technologies, because the interests of libraries are different from the interests of commercial information providers. The core mission of libraries is to offer free access to information rather than on a pay-per-use basis as many commercial entities do. Digital rights management for libraries requires identifying and authenticating rights holders and users, while protecting their privacy and confidentiality. The principles of first sale and fair use must be maintained in the digital environment while preserving authors’ rights, as well. As libraries begin to publish more on the web, their interest in digital rights management will increase.

Libraries already offer many products in a digital form accessible to patrons by remote access after identification and authentication. While the library bears the expense of the product, access is open to anyone who has a valid card. In my opinion, the user identifies this service with the library. I agree that libraries need to be involved in digital rights management so information does not become a commodity that can be accessed only by those who can afford it.[24]

  


## Fines and fine waiving[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-6)]

## Government information[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-7)]

## International information policy[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-8)]

This article provides a historical perspective on the development of international policies and sanctions regarding the fair and safe trade of information between countries. During the internet’s infancy, the issues regarding keeping privileged information confidential and regulation the economic aspects of electronic information were still being worked out. One of the bodies involved in these issues was called the Organization for Economic Cooperation and Development (OECD). When this editorial article was written in 1985 ways to control and regulate the international flow of information were still being worked out. This article only provides a small glimpse of the issue from a modern vantage point. One would assume that today, more than twenty years later that regulations would now be firmly in place. In order to get a better idea of the evolution of international information policy it would be necessary to read several articles that span the past two decades.[25]

## Outsourcing[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-9)]

![The Hawaii State Library, a historic building surrounded by trees](//upload.wikimedia.org/wikipedia/commons/thumb/f/fe/HawaiiStateLibrary.JPG/220px-HawaiiStateLibrary.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The Hawaii State Library, the seat of the Hawai'i State Public Library System

In recent years, many libraries have explored outsourcing "behind-the-scenes" activities, such as cataloging and book selection, to private companies. A classic example of this was a 1996 decision by Bartholomew Kane, the Hawaii State Librarian, to outsource all cataloging and selection for the libraries in the state to the private company Baker and Taylor. Kane's philosophy in this decision was guided by public surveys which showed a public desire for increased library assistance and longer hours of operation. By outsourcing cataloging and selection, Kane was able to meet both of these public demands.

However, this approach also has its drawbacks. For instance, by outsourcing selection and cataloging, the library loses its autonomy in making differentiated selections to suit their individual populations. Although the State Library argued that it would be in Baker and Taylor's best financial interst to select the appropriate materials, the issue is not entirely resolved. For instance, will the selectors at Baker and Taylor have the same interactions with and knowledge of the public that the librarians would have? Additionally, the state of Hawaii is in a unique situation, as the only state with a state-wide library system, and in a state of geographic semi-isolation from the rest of the country. Applying a blanket solution such as outsourcing some of the traditional roles of the public library is not a catch-all solution for all libraries that need to increase their hours and personnel without increasing their bottom line.[26]

## Web content filters[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Screenshot-whitehouse_com.png/220px-Screenshot-whitehouse_com.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A screenshot of filtering software _DansGuardian_ blocking [whitehouse.com](//en.wikipedia.org/wiki/whitehouse.com).

Libraries are one of the primary providers of public Internet access within the United States. American librarians are also ethically bound by the ALA's code of ethics to "resist all efforts to censor library resources." Therefore, when the 2000 Children's Internet Protection Act (CIPA) required libraries and schools to filter web content as a condition for receiving certain federal funding, many in the library community strongly objected. The ALA challenged the act as unconstitutionally blocking access to constitutionally protected information on the Internet. The ALA also noted that E-rate funding, one of the federal funding programs contingent on web filter use, was created to provide Internet access to all communities, including historically underfunded communities. Mandating filters imposes additional financial burdens on the same schools and libraries that the e-rate program was meant to help. Finally, the ALA stated that web filters are notoriously unreliable, with "no filtering software successfully differentiat[ing] constitutionally protected speech from illegal speech on the Internet." The case made it to the Supreme Court, which in 2003, ruled that CIPA was in fact constitutional.

The debate over filtering in the library community is far from over, however. Writing in 2004, Nancy Kranich notes seven reasons filters do not succeed in protecting patrons from offensive Internet material:

  1. Filters underblock sites that are banned by CIPA
  2. Filters overblock sites that are legal
  3. Filter providers cannot review every site
  4. Filters do not distinguish between users of different ages
  5. Overriding or disabling filters is time-consuming and costly
  6. Some users find ways around filters or find access elsewhere
  7. Filters do not block email, chat rooms or videos

Kranich argues that the best ways to protect consumers are through education, Internet access policies, links to approved, quality sites, and reference assistance. Requiring parental consent for minors to use the Internet, public monitoring, and the use of privacy screens also help protect consumers.[27]

  


Many in the library community also worried that federal laws such as CIPA could lead the way to even more restrictive laws on the state level. Some libraries filter because violating certain state laws could lead to criminal charges. Most libraries depend on community support and money, so resisting the public’s requests puts libraries’ futures at risk. Would libraries choose filtering if there were no threats of legal action and eliminated funding? If so, what does this say about the ALA’s mission?

However, Hampton Auld takes a different view of filtering. In Auld's article, the Chesterfield County (Virginia) Public Library began filtering all public Internet-access computers after complaints that adults and children were viewing pornographic images. The library observed a reduction in the number of times pornography had to be cleared from screens, a reduction in the number of reported complaints, and an improved library environment, despite mistakes made by the filtering software. Auld argues that filters work in blocking pornography while only slightly affecting access to protected speech. According to Auld, the ALA should revise its anti-filtering policy because filters are more effective than any other ALA-recommended method and the policy is undermining and dividing the profession.[28]

The following table represents arguments for and against filtering requirements from an earlier supreme court case, Reno v. ACLU. In this case, the supreme court sided with the ACLU, unanimously striking down a portion of the 1996 Communications Decency Act (CDA).

Argument
Defense

Filters use keywords.
True, but good filters can turn off keyword blocking and rely on site-selected blocking.

Filters block sex education, AIDS info, etc.
Can be set up so only pornographic sites are blocked.

Outsiders select material.
Librarians have vendors preselect books.

The lists of sites that are banned cannot be viewed or changed.
They are all different. Some have viewable lists, main thing is that it is editable and accurate.

Libraries look like "publishers" and can be responsible for its content.
"Good Samaritan" blocking amendment protects libraries if blocking offensive material.

Internet is too big and changes too fast to be 100% accurate.
Libraries have to try to be consistent, not ensure appropriateness.

Let the users decide appropriateness, not the librarian.
Libraries have always had global judgment (ex.- not to carry Huster).

Libraries have limited budgets which is why they don't carry everything.
Wrong- remember appropriateness! (and offensiveness)

Violates the Constitution.
Uses discretion, not removing from one thing, selecting from several.

Selection is addition, censorship is removal.
Restricts the potential access.

[29]

Edwards' commentary focuses on the questionable success of filters meant to block access by young people to websites with pornographic content in libraries and schools. While allowing schools and libraries to maintain access to federal funding under the Children’s Internet Protection Act of 2000 (CIPA), the use of these filters may also be blocking access to sensitive health information. The most frequently blocked sites included the following words:

  * Gay or lesbian
  * Condoms
  * Safe Sex
  * Abortion

The more the restrictive filters prevented the twelve testers from finding health information on topics such as pregnancy, abortion and drug use, while only marginally improving protection against pornographic sites. Both sides of the filtering debate claim victory. Those for filters advocate their use by applauding the success of the study in blocking between 87-91% of pornography in the study. Those against the use of filters cite the potential 24% of health information sites blocked as the failure inherent in the system. The perplexing portion of CIPA is that the government mandates the use of filtering to remain eligible for federal funding; yet they make no policy as to what should be filtered. The recurring theme with library policy is the information as a commodity, again leaving the question of what information should be available to whom to be an arbitrary decision. One can infer that the debate regarding this topic will remain controversial since there is no way to standardize to a general agreement what issues should be blocked.[30]

## References[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Policy&action=edit&section=T-11)]

  1. ↑ Casson, Lionel (11 Aug 2002). _Libraries in the Ancient World_. Yale University Press. p. 3. 
  2. ↑ _The American International Encyclopedia_, New York: J. J. Little & Ives, 1954; Volume IX
  3. ↑ [Britishmuseum.org](http://www.britishmuseum.org/research/research_projects/ashurbanipal_library_phase_1.aspx) "Assurbanipal Library Phase 1", British Museum One
  4. ↑ "Epic of Creation", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 233-81
  5. ↑ "Epic of Gilgamesh", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 50–135
  6. ↑ Van De Mieroop, Marc. _A History of the Ancient Near East ca. 3000–323 BC_. Oxford, UK: Blackwell Publishing, 2007: pg. 263
  7. ↑ _**a**_ _**b**_ Mukherjee, A. K. Librarianship: Its Philosophy and History. Asia Publishing House (1966) p. 86
  8. ↑ _**a**_ _**b**_ _**c**_ Phillips, Heather A., ["The Great Library of Alexandria?". Library Philosophy and Practice, August 2010](http://unllib.unl.edu/LPP/phillips.htm)
  9. ↑ Jochum, Uwe. “The Alexandrian Library and Its Aftermath.” Library History 15 (May 1999): 5-12.
  10. ↑ Seneca, _De tranquillitate animi_ ix.4–7.
  11. ↑ Zurndorfer, Harriet Thelma (1995). _China bibliography: a research guide ... – Google Books_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-90-04-10278-1](/wiki/Special:BookSources/978-90-04-10278-1). 
  12. ↑ Goeje, M. J. de, ed (1906). "Al-Muqaddasi: Ahsan al-Taqasim" (in Arabic). _Bibliotheca geographorum Arabicorum_. **III**. Leiden: E. J. Brill. pp. 449. 
  13. ↑ _[International dictionary of library histories](http://books.google.com/books?id=Zoq_TtEN54IC&pg=PA29)_, 29
  14. ↑ Streeter, Burnett Hillman (10 Mar 2011). _[The Chained Library_](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Cambridge University Press. [http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Retrieved 6 March 2012. 
  15. ↑ Geo. Haven Putnam (1962). _Books and Their Makers in the Middle Ages_. Hillary. 
  16. ↑ This section on Roman Renaissance libraries follows Kenneth M. Setton, "From Medieval to Modern Library" _Proceedings of the American Philosophical Society_ **104**.4, Dedication of the APS Library Hall, Autumn General Meeting, November, 1959 (August 1960:371–390) p. 372 ff.
  17. ↑ Stockwell, Foster (2000). _A History of Information and Storage Retrieval_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-7864-0840-5](/wiki/Special:BookSources/0-7864-0840-5). 
  18. ↑ _**a**_ _**b**_ Mukherjee, A. K. (1966) _Librarianship: its Philosophy and History_. Asia Publishing House; p. 112
  19. ↑ Cresswell, Stephen. “The Last Days of Jim Crow in Southern Libraries.” Libraries and Culture 31 (summer/fall 1996): 557-573.
  20. ↑ Garrison, Dee. “The Tender Technicians: The Feminization of Public Librarianship, 1876-1905.” Journal of Social History 6 (winter 1972-1973): 131-156.
  21. ↑ Hildenbrand, Suzanne. "'Women's Work' within Librarianship." Library Journal 114 (September 1, 1989): 153-155.
  22. ↑ Trujillo, Roberto G., and Yolanda J. Cuesta, 1989. Service to Diverse Populations. ALA Yearbook of Library and Information Science. Vol. 14: 7-11.
  23. ↑ McCook, Kathleen, and Geist, Paula, 1993. Diversity Deferred: Where are the Minority Librarians? Library Journal. 118: 23-26.
  24. ↑ Guerena, Salvador and Edward Erazo. "Latinos and Librarianship." Library Trends 49 (2000) : 138-181.
  25. ↑ Wayne Wiegand, Tunnel Vision and Blind Spots: What the Past Tells Us about the present; reflections on the twentieth-century history of American librarianship (Library Quarterly, 69:1, Jan. 1999)
  26. ↑ Dowlin, Kenneth E. “Access to Information: A Human Right?” Bowker Annual 32 (1987): 64-68.
  27. ↑ Koenig, Michael E. D. “Information Services and Downstream Productivity.” Annual Review of Information Science and Technology 25 (1990): 55 – 86.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Ethics and Values in the Information Professions](/wiki/Introduction_to_Library_and_Information_Science/Ethics_and_Values_in_the_Information_Professions)
[Information Organization](/wiki/Introduction_to_Library_and_Information_Science/Information_Organization) →

  


# Information Organization[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=4)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Information Policy](/wiki/Introduction_to_Library_and_Information_Science/Information_Policy)
[Information Seeking](/wiki/Introduction_to_Library_and_Information_Science/Information_Seeking) →

## Why organize information?[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-1)]

The sheer abundance of information available on the Internet leads to limited user attention and a high reliance on gatekeeping services, such as search engines. These gatekeeping services capitalize on user attention scarcity by channeling users' attention toward certain documents and away from others.[31]

## Bibliography[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-2)]

Marcia Bates attempts to define and standardize the systematic bibliography in a way that makes it clear to the end user what is covered in such a bibliography, how to make research easier and bibliographies more valuable as a tool in search strategies. The author never loses sight of the end user and the real world applications of bibliographic use. The concept of the "defining purpose" of a bibliography is a theme that runs throughout the entire article, and the major specifications of a bibliography discussed at length and in detail, are:

  1. Scope
  2. Selection Principles
  3. Organization
  4. Domain
  5. Information fields
  6. Bibliographic units

Special consideration is given to the Principles of Selection, or the manner in which articles are chosen for a particular bibliography. These are:

  1. Expert Judgment
  2. Random Samples
  3. Representative Sample
  4. Functional Equivalence Sets

I agree with the concepts stated in the paper, and the necessity for some type of systematic structure when building bibliographies, so that users get the information they need and have confidence that the material presented in the bibliography is comprehensive, pertinent and complete, as defined by the purpose statement of the bibliography. I thought this was an excellent article, as it laid out step by step, in detail, how to build a systematic bibliography that keeps the end user’s search strategies in mind at all times.

Reading this article makes me question whether the use of digital resources has altered the way bibliographies are compiled.[32]

### Subject guides[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-3)]

## Bibliographic metadata[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Handwritten_subject_card..JPG/220px-Handwritten_subject_card..JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A handwritten subject card from the Library’s old card catalog recalls the precomputer days when information had to be created, classified, and sorted by hand.

Cataloging is the process of adding an item to a catalog, a process typically including bibliographic description, subject analysis, and classification.

### Cataloging[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-5)]

#### Authority control[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-6)]

#### MARC formats[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-7)]

The MARC formats are digital formats for the description of bibliographic items developed by the US Library of Congress during the 1960s to facilitate the creation and dissemination of cataloging between libraries. While the formats were originally created to facilitate printing of paper catalog cards, they are still in use today as the basis for most computerized library catalogs.

Jackie Radebaugh argues that the MARC format will survive in an era of global digital communication. She describes the modifications made to MARC to accommodate different types of materials, to make web addresses accessible from MARC, and to access an online table of contents from the MARC record. MARC 21 is used in many countries of the world today. MARC documentation has been translated into several languages. Current modifications include mapping MARC to a variety of languages including Dublin Core, SGML, and XML to adapt MARC to web-based environments. After it has been modified for web use will it still be MARC? Radebaugh quotes one presenter at the 2000 ALA conference who stated that MARC is very much alive. At the same conference Fred Kilgour, the man who championed MARC and is responsible for much of its success, speculated that in the next 30 years Marc will be replaced. In my opinion MARC has been a resilient format, but may be superseded by formats more adaptive to digital environments.[33]

#### Bibliographic framework (BIBFRAME)[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-8)]

Several expert groups, including the Working Group on the Future of Bibliographic Control and the U.S. RDA Test Coordinating Committee have recommended that the library community implement a new carrier for bibliographic data that replaces the MARC standards. The RDA Test Committee's Final Report suggested that new ways of cataloging are unlikely to yield significant benefits unless they are implemented on top of a new means for capturing and sharing bibliographic data. In other words, many experts believe that the MARC format is holding back the development of better cataloging practices.

The general plan for the new Bibliographic Framework enumerates a list of requirements for the new carrier, which is described as an “environment” rather than a simple “format”. Some of the most noteworthy requirements are that the new environment will support bibliographic description expressed as both textual data and linked data URIs; accommodate RDA, AACR2, DACS, VRA Core, and CCO descriptive rules; and provision for data that support or accompany bibliographic data, such as authority data, holdings data, preservation data, and technical data. The plan also notes that catalogers are likely to interact with the new data carrier on a more abstract level than they currently interact with MARC. BIBFRAME's approach is based on the RDF data model from the Linked Data community, for which a number of query and storage tools have already been developed.[34]

  


#### Functional Requirements for Bibliographic Records[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-9)]

![Four different entities \(Works, Expressions, Manifestations, and Items\) are shown, along with their relationships.  Expressions are described as the realizations of Works, Manifestations as the embodiments of Expressions, and Items as the exemplars of Manifestations.](//upload.wikimedia.org/wikipedia/commons/thumb/8/80/FRBR-Group-1-entities-and-basic-relations.svg/220px-FRBR-Group-1-entities-and-basic-relations.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The FRBR Group One Entities and their relationships with each other.

Historically, cataloging practice has been devoted to describing "books". Early attempts to standardize cataloging practice internationally, such as the 1961 Paris Principles, only addressed the cataloging of printed books. The Paris Principles describe themselves as only being applicable to "catalogues of printed books in which entries under authors' names and, where these are inappropriate or insufficient, under the titles of works are combined in one alphabetical sequence."1[35] Even in 1961, libraries offered their patrons materials other than print books, such as periodicals and musical recordings, and the number of formats that library catalogers have been called on to describe has only grown since that time. Contemporary library catalogs may include reference databases, e-books, DVDs, computer software, websites, blogs, audiobooks, digitized archival materials, and countless other resources.

As the number of formats described in library catalogs has grown, the meaning of the term _book_ has become less clear. As Barbara Tillett notes:

![The Group One Entities and their connections to Group Two entities, specifically people and corporate bodies.  Group Two entities are described as creators of Works, realizers of Expressions, producers of Manifestations, and owners of Items.](//upload.wikimedia.org/wikipedia/commons/thumb/6/6d/FRBR-Group-2-entities-and-relations.svg/220px-FRBR-Group-2-entities-and-relations.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The Group One Entities and their connections to Group Two entities

“
When we say the word _book_ in everyday language, we may actually mean several things. For example, when we say _book_ to describe a physical object that has paper pages and a binding and can sometimes be used to prop open a door or hold up a table leg, FRBR calls this an "item." When we say _book_ we also may mean a "publication" as when we go to a bookstore to purchase a book. We may know its ISBN but the particular copy does not matter as long as it's in good condition and not missing pages. FRBR calls this a "manifestation." When we say _book_ as in "who translated that book," we may have a particular text in mind and a specific language. FRBR calls this an "expression." When we say _book_ as in "who wrote that book," we could mean a higher level of abstraction, the conceptual content that underlies all of the linguistic versions, the story being told in the book, the ideas in a person's head for the book. FRBR calls this a "work."[36]
”

Because of these issues, the cataloging community felt that it was necessary to have a new conceptual model for cataloging that didn't center around the ambiguous _book_. The Functional Requirements for Bibliographic Records, or FRBR, was an attempt to clarify this hazy terminology, and to provide a model that was independent of particular cataloging codes and material formats.

FRBR starts with four "Group One Entities": the **Work**, the **Expression**, the **Manifestation**, and the **Item**. A traditional catalog record combines description at each of these levels, but generally centers around a description at the manifestation level. After defining these Group One Entities, FRBR then continues to define relationships between these entities and each other, as well as with other entities, such as authors, publishers, and other people and corporate bodies (Group Two entities), and topics (Group Three entities).

Like the earlier Paris Principles, FRBR is seperate from specific cataloging standards such as AACR2 or International Standard Bibliographic Description (ISBD). However, the FRBR model has been used to inform new cataloging standards, such as Resource Description and Access (RDA), as well as changes in automated systems and user interfaces.

### Classification[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/LibraryOfCongressClassification.jpg/220px-LibraryOfCongressClassification.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Books about the Java programming language, sorted by Library of Congress Classification.

To make a Classification system, you need four things:

  * classes, or ways to group objects based on similar characteristics
  * labels for the classes, or ways of expressing these conceptual classes in human language
  * notation, another way to express these classes. Notation helps with automated processes, as well as making things easier for humans. For example, Dewey Decimal Classification system notates the subject of "Jewish people in Ukraine" as 305.89240477. This is much easier to shelve and retrieve than the non-notated version, shown below.

Class notation: 305.89240477  
''vs.''  
Class labels: Social sciences > Groups of people > Jews > Subdivided geographically > Europe > Russia and Eastern Europe > Ukraine

  * relationships between classes (these are usually taxonomic, i.e. heirarchical). For example in the example above, _Europe_ stands in a heirarchical relationship with _Russia and Eastern Europe_

#### Dewey Decimal Classification[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-11)]

The DDC is in its 23rd edition and is the "world's most widely used classification system." It can be ordered in a four-volume print version, as full WebDewey or an abridged print or web version which is better for smaller collections. Membership includes updates on its web versions quarterly, and a semiannual DDC newsletter, offers to conferences and workshops, OCLC articles and case studies. This website is very simple to use. It is not too complicated and gets to the point if your library has a need for it. It doesn’t have a lot of “bells and whistles” but has what is necessary and is simple to follow. As it pertains to the chapter the information this site provides is a basic source to use when learning about DDC. The Dewey Decimal system is such a huge part of so many libraries it is hard to think of not having such a well structure organizational tool to use.[37]

#### Taxonomies vs. folksonomies[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-12)]

## Information architecture[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-13)]

Information Architecture is a field that started in the 1990’s with the high-tech boom in full force. They are similar to a building architect except they do their designing for a website. An IA (Information Architect) makes up the logical structure of a website. They look at the needs of the users and design the visual and interaction design according to the user experience, making it easier to find information and to work around a site. This also will make it easier to manage the site.

The key concepts that an IA looks at are:

  * organization
  * navigation
  * search
  * labeling
  * controlling

The IA then draws up blueprints and works closely with the technical, graphic, and editorial team members to finish the site. IA Chris Farnum is very knowledgeable and informative in their profession and goes on to explain that there are several ways to find out more about his field through books, seminars and college courses. I like the way that the information has been presented very clearly and explained in detail, and I see a strong need for this type of profession in today’s world of technology. With all of the options and choices of sites out in the World Wide Web, in this day and age, I can see a large need to make your site the most marketable and user-friendly as possible.[38]

  


## Information retrieval[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-14)]

Artificial intelligence has two main applications in information retrieval: organization of application methods, and the design of classification methods. There is no shared terminology between the fields, making it difficult for the two areas to collaborate initially. Linda C. Smith, in her 1976 article "Artificial Intelligence and Information Retrieval," predicts that as artificial intelligence and information retrieval continue to expand there will still need to be an increase in the cognitive ability of the users to discern what has been retrieved from the original search. The other concern for users was the anticipation that in order to use the system, a user would need to be experts to get the desired results. At the time of the article, there was a growing interest in the ability of these retrieval systems to answer questions and retrieve facts, both items we see have come to fruition today in modern search engines used every day. Artificial intelligence was seen to have both short term and long term effects on information retrieval. In the short term, it would modify the results of a current search during a query to meet the user’s current needs. In the long term, it would modify the document representations to improve responses. This article was a follow up to the author’s initial research in 1980. Little had changed in that time as far as attitudes and outlook for the feasibility of using artificial intelligence techniques as practical applications in library science and information retrieval. With hindsight on my side, it is interesting to see that common search engines use the kind of aided searches to find related topics that the author thought only the experts would be able to complete.[39]

  
The World Wide Web (WWW) is common in school libraries because of its value as an educational tool. Previous research indicates that domain expertise improves online search performance. Other research shows that WWW browsing experience does not play a significant role in achieving a higher efficiency or accuracy level in a search. The authors' study tests fourth-graders' online search performance in relation to how proficient they were in WWW use; the level of domain expertise (Dutch literature) was consistent. The results showed that WWW experts were better than novices at locating Web sites but that WWW experience does not substantially affect how well information is located on a specific Web site. The authors argue that locating Web sites involves more use of search engines, a skill in which the experts are more proficient, but finding information on a Web site generally involves browsing, in which WWW experience is not as important. Although the novices were not true beginners and the experts not professionals, the novices would greatly benefit from courses teaching search skills, such as how to use search engines and Boolean operators. I think that instruction in determining the relevance and validity of search results is just as important as search skills, but the article does not address this. However, judging relevance depends on the user’s knowledge of a subject that school librarians are not often responsible for teaching. A good relationship among teachers, school librarians, and the WWW must emerge for students to receive the best possible education.[40]

  
Information science has at its core the concept of “Relevance”, which is a subjective notion. Relevance is defined broadly as a measurement of the effectiveness of an exchange or contact of information between a source and a user, all based on the differing views of what constitutes effective communication. This concept is the basis for how entire information retrieval systems are designed and utilized. There are many differing views on what this means, but all of them are somewhat related and interconnected regardless of how they are defined or utilized. The author describes in great detail, the framework for these differing views and the underlying philosophies behind each concept of what constitutes effective communication. He argues that all of these differing constructs are incomplete, (yet correct); depending on where one starts their examination of the communication process. He ends his paper with an appropriate call for more study on the subject. His paper is a recap of the opposing arguments of three decades ago, but in fact is more important now than ever before, as new information systems come on line and into being (the internet, the electronic database, funding for collections, etc.), and are all based on an incomplete definition of “effective communication”.[41]

## The Semantic Web, RDF, and linked data[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-15)]

![An RDF graph describes Semantic Web innovator Eric Miller through a combination of literal strings and URIs.  His title, a relationship described by the URI http://www.w3.org/2000/10/swap/pim/contact#personalTitle, is described by the literal string "Dr."  His email address, a relationship described by the URI http://www.w3.org/2000/10/swap/pim/contact#mailbox, is described by the literal string "mailto:em@w3.org".  His type, a relationship described by the URI http://www.w3.org/1999/02/22-rdf-syntax-ns#type, is described by the URI http://www.w3.org/2000/10/swap/pim/contact#Person, indicating that he is a person](//upload.wikimedia.org/wikipedia/commons/thumb/5/58/Rdf_graph_for_Eric_Miller.png/220px-Rdf_graph_for_Eric_Miller.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

An RDF graph describes Semantic Web innovator Eric Miller through a combination of literal strings and URIs.

Eric Miller and Ralph Swick describe the Semantic Web as "an extension of the current Web in which the meaning of information is clearly and explicitly linked from the information itself, better enabling computers and people to work in cooperation."

The Semantic Web is a stack of technologies that seeks to convert the current Web, which is full of unstructured and semi-structured documents, into a "web of data" where documents are all available in machine-readable formats as well as human-readable ones. Semantic Web enthusiasts argue that this abundance of machine-readable formats will allow both human users and automated technologies to find, share, and combine information more easily.

“
The Semantic Web fosters and encourages greater data reuse by making it available for purposes not planned or conceived by the data provider. Suppose you want, for example, to locate news articles published in the previous month about companies headquartered in cities with populations under 500,000 or to compare the stock price of a company with the weather at its home base or to search online product catalogs for an equivalent replacement part for something. The information may be there in the Web, but currently only in a form that requires intensive human processing.
”

[42]

A key resource for current work with RDF is [DBpedia](//en.wikipedia.org/wiki/DBpedia), an effort to extract RDF data from the Wikipedia project. An example of a typical DBpedia record can be seen at <http://dbpedia.org/page/Audre_Lorde>, a human-language description of Audre Lord, a "black lesbian feminist mother poet warrior," who also worked as a librarian. This exact same information is available in a machine readable format at the URI <http://dbpedia.org/data/Audre_Lorde>. For every URI for humans in the format <http://dbpedia.org/page/Topic>, there is a URI for machines in the format <http://dbpedia.org/data/Topic>, which expresses the exact same data. Notice also that all of the properties and many of their values are links that you can click on. Most of these links are also available in machine-readable formats, which means that a machine could follow these links repeatedly to integrate information about Audre Lorde from numerous sources.

Miller and Hillmann, in order to make sense of the semantic (contextual) web, describe the makeup of the web: semantics, structure, and syntax. Semantics refers to the context of information and its meaning. The structure encompasses how the information is organized, and the syntax is how the semantics and structure are communicated. EXtensible Markup Language (XML) deals with the syntax, and Resource Description Format (RDF) is what enables the structure. Libraries are best equipped to embrace XML and RDF to address cataloging and web-based interfaces to share information. It is their responsibility to utilize traditional models (MARC) and current developments (XML and RDF) to control their information and provide usable interfaces for patrons. The article is succinct and straightforward, and the authors’ attempts to decode these swirling acronyms should be commended. However, from a layperson’s perspective, these are still difficult concepts to wrap one’s head around. Miller and Hillmann are concerned that libraries’ focus is too narrow to meet the needs of patrons. Now that the semantic web has greater possibilities, libraries should include items usually forgotten such as older journals or sound files. This is very postmodern indeed. As exciting as this is (to see the inclusion of items generally left out of a library’s domain), I wonder at this feasibility in a public library. How prepared are public librarians to learn these new languages? Patrons are ready to see their public library as a resource not just for books and internet access, but are libraries ready to deliver?[43]

## Knowledge management[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-16)]

Knowledge Management is an outgrowth of data and information management. Increased competition and a mobile workforce with analytical skills and reduced loyalty to the organization make the concept of knowledge management and retention, appealing to managers.

Knowledge Management (KM), once the sole domain of the corporate world, is now necessary to many information disciplines. Information professionals need an understanding of what makes KM effective. This understanding begins with knowledge as an ever-changing entity, made up of human experiences, emotions, and senses. Scholars have identified knowledge to include the tacit (internal) and the explicit (manifestations of the internal). Organizations have developed KM systems to facilitate both tacit and explicit knowledge, and the sharing of the two, through discussion, training, team-building, etc. The author contends that (despite critics’ assessment that KM is incapable of a process so subjective and human) examples abound from the corporate world where KM has maximized profitability, innovation, etc. Based on these examples, the author stresses principles to guide effective KM. These include an environment dedicated to valuing individual experience and open communication as a means to share and learn; using technology to accommodate knowledge (emphasizing currency, accessibility, etc.); and an understanding that KM requires a rooting in both the tacit and explicit forms of knowledge. The fluidity of knowledge is well-developed. However, how this evolving knowledge affects KM is illustrated by examples solely from the realm of corporate organizations. If KM is increasing in scope beyond the traditional organizations, there is a surprising lack of even anecdotal evidence in new, information-based environments. The implications given for information professionals are a rehashing of the models that have served corporations. It is unclear how KM, armed with a sense of the dynamic and human nature of knowledge, will look different in an information-based environment. This article would be better served if it distinguished how effective KM would look, feel, and operate under the expanding information professions versus the traditional corporate model.[44]

  
David Blair contends that early attempts to manage knowledge failed because they attempted to improve or replace human decision making. Knowledge management does not replace human decision making but facilitates it. Experts are part of the system. The author persuasively argues that data and information management offer limited returns to an organization and that artificial intelligence projects and systems without human experts have not proven successful. The author contends that knowledge management requires “communities of practice,” a culture in which experts share knowledge with novices. Additionally, a wide variety of informative media must be available through technology to support Knowledge Management. Knowledge workers require strong critical thinking skills and the ability to find and evaluate information from a variety of sources.

The greatest challenges to implementing knowledge management are creating an organizational culture that facilitates the sharing of knowledge, the treatment of tacit knowledge and the legal issues concerning the nature of intellectual property. The author contends that though tacit knowledge may be inexpressible, rules-of-thumb and “best practices,” case studies of problems and methods of resolution can provide experts with the knowledge to make informed decisions.

Some aspects of Knowledge Management have already been implemented. The Knowledge management is one of many emerging information technologies that organizations employ to remain competitive.[45]

## General issues in information organization[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-17)]

### The politics of information organization[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-18)]

Sanford Berman's Prejudices and Antipathies

Hope Olson's The Power to Name

## Notes[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-19)]

    1.**^** The principles half-heartedly say in a footnote that "the word _book_ should be taken to include other library materials having similar characteristics," and "serials and periodicals" are mentioned once in the document.

## References[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Organization&action=edit&section=T-20)]

  1. ↑ Casson, Lionel (11 Aug 2002). _Libraries in the Ancient World_. Yale University Press. p. 3. 
  2. ↑ _The American International Encyclopedia_, New York: J. J. Little & Ives, 1954; Volume IX
  3. ↑ [Britishmuseum.org](http://www.britishmuseum.org/research/research_projects/ashurbanipal_library_phase_1.aspx) "Assurbanipal Library Phase 1", British Museum One
  4. ↑ "Epic of Creation", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 233-81
  5. ↑ "Epic of Gilgamesh", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 50–135
  6. ↑ Van De Mieroop, Marc. _A History of the Ancient Near East ca. 3000–323 BC_. Oxford, UK: Blackwell Publishing, 2007: pg. 263
  7. ↑ _**a**_ _**b**_ Mukherjee, A. K. Librarianship: Its Philosophy and History. Asia Publishing House (1966) p. 86
  8. ↑ _**a**_ _**b**_ _**c**_ Phillips, Heather A., ["The Great Library of Alexandria?". Library Philosophy and Practice, August 2010](http://unllib.unl.edu/LPP/phillips.htm)
  9. ↑ Jochum, Uwe. “The Alexandrian Library and Its Aftermath.” Library History 15 (May 1999): 5-12.
  10. ↑ Seneca, _De tranquillitate animi_ ix.4–7.
  11. ↑ Zurndorfer, Harriet Thelma (1995). _China bibliography: a research guide ... – Google Books_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-90-04-10278-1](/wiki/Special:BookSources/978-90-04-10278-1). 
  12. ↑ Goeje, M. J. de, ed (1906). "Al-Muqaddasi: Ahsan al-Taqasim" (in Arabic). _Bibliotheca geographorum Arabicorum_. **III**. Leiden: E. J. Brill. pp. 449. 
  13. ↑ _[International dictionary of library histories](http://books.google.com/books?id=Zoq_TtEN54IC&pg=PA29)_, 29
  14. ↑ Streeter, Burnett Hillman (10 Mar 2011). _[The Chained Library_](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Cambridge University Press. [http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Retrieved 6 March 2012. 
  15. ↑ Geo. Haven Putnam (1962). _Books and Their Makers in the Middle Ages_. Hillary. 
  16. ↑ This section on Roman Renaissance libraries follows Kenneth M. Setton, "From Medieval to Modern Library" _Proceedings of the American Philosophical Society_ **104**.4, Dedication of the APS Library Hall, Autumn General Meeting, November, 1959 (August 1960:371–390) p. 372 ff.
  17. ↑ Stockwell, Foster (2000). _A History of Information and Storage Retrieval_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-7864-0840-5](/wiki/Special:BookSources/0-7864-0840-5). 
  18. ↑ _**a**_ _**b**_ Mukherjee, A. K. (1966) _Librarianship: its Philosophy and History_. Asia Publishing House; p. 112
  19. ↑ Cresswell, Stephen. “The Last Days of Jim Crow in Southern Libraries.” Libraries and Culture 31 (summer/fall 1996): 557-573.
  20. ↑ Garrison, Dee. “The Tender Technicians: The Feminization of Public Librarianship, 1876-1905.” Journal of Social History 6 (winter 1972-1973): 131-156.
  21. ↑ Hildenbrand, Suzanne. "'Women's Work' within Librarianship." Library Journal 114 (September 1, 1989): 153-155.
  22. ↑ Trujillo, Roberto G., and Yolanda J. Cuesta, 1989. Service to Diverse Populations. ALA Yearbook of Library and Information Science. Vol. 14: 7-11.
  23. ↑ McCook, Kathleen, and Geist, Paula, 1993. Diversity Deferred: Where are the Minority Librarians? Library Journal. 118: 23-26.
  24. ↑ Guerena, Salvador and Edward Erazo. "Latinos and Librarianship." Library Trends 49 (2000) : 138-181.
  25. ↑ Wayne Wiegand, Tunnel Vision and Blind Spots: What the Past Tells Us about the present; reflections on the twentieth-century history of American librarianship (Library Quarterly, 69:1, Jan. 1999)
  26. ↑ Dowlin, Kenneth E. “Access to Information: A Human Right?” Bowker Annual 32 (1987): 64-68.
  27. ↑ Koenig, Michael E. D. “Information Services and Downstream Productivity.” Annual Review of Information Science and Technology 25 (1990): 55 – 86.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Information Policy](/wiki/Introduction_to_Library_and_Information_Science/Information_Policy)
[Information Seeking](/wiki/Introduction_to_Library_and_Information_Science/Information_Seeking) →

# Information Seeking[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=5)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Information Organization](/wiki/Introduction_to_Library_and_Information_Science/Information_Organization)
[Re-contextualizing Libraries: Considering Libraries within Their Communities‎](/wiki/Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities) →

  


## Scientific and academic research[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Seeking&action=edit&section=T-1)]

Antwerp State University Centre conducted a survey of 3545 scientists which confirmed that the scientists first consult references at the end of articles in journals and books when staying informed about their field. Ranked second, Current Contents and the library operated SDI service were reviewed for paper titles. Abstracting and indexing journals, followed by personal recommendations, computerized information services, library browsing, theses and catalogues ranked next. The Antwerp survey was compared to Hakulinen's findings which also conclude that for scientific research abstracting and indexing journals are less important. The so-called information explosion poses the challenge of keeping aware of new publications and what has been published on a given subject. With the increase in information, scientists do not read more, but are finding relevancy to their subject area in a set number of core journals.

The use of computer data bases to scan titles and subjects in a scientist’s field is more pertinent today than when the article was published. A search across multiple listings of journals through computer data bases saves time previously spent reading the table of contents of journals and having to physically retrieve those journals. Academic libraries are maintaining fewer periodicals in print each year. The findings of the article remain important in its contribution to bibliometrics specifically regarding where scientists can find current information in their field.[46]

  


## References[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Information_Seeking&action=edit&section=T-2)]

  1. ↑ Casson, Lionel (11 Aug 2002). _Libraries in the Ancient World_. Yale University Press. p. 3. 
  2. ↑ _The American International Encyclopedia_, New York: J. J. Little & Ives, 1954; Volume IX
  3. ↑ [Britishmuseum.org](http://www.britishmuseum.org/research/research_projects/ashurbanipal_library_phase_1.aspx) "Assurbanipal Library Phase 1", British Museum One
  4. ↑ "Epic of Creation", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 233-81
  5. ↑ "Epic of Gilgamesh", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 50–135
  6. ↑ Van De Mieroop, Marc. _A History of the Ancient Near East ca. 3000–323 BC_. Oxford, UK: Blackwell Publishing, 2007: pg. 263
  7. ↑ _**a**_ _**b**_ Mukherjee, A. K. Librarianship: Its Philosophy and History. Asia Publishing House (1966) p. 86
  8. ↑ _**a**_ _**b**_ _**c**_ Phillips, Heather A., ["The Great Library of Alexandria?". Library Philosophy and Practice, August 2010](http://unllib.unl.edu/LPP/phillips.htm)
  9. ↑ Jochum, Uwe. “The Alexandrian Library and Its Aftermath.” Library History 15 (May 1999): 5-12.
  10. ↑ Seneca, _De tranquillitate animi_ ix.4–7.
  11. ↑ Zurndorfer, Harriet Thelma (1995). _China bibliography: a research guide ... – Google Books_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-90-04-10278-1](/wiki/Special:BookSources/978-90-04-10278-1). 
  12. ↑ Goeje, M. J. de, ed (1906). "Al-Muqaddasi: Ahsan al-Taqasim" (in Arabic). _Bibliotheca geographorum Arabicorum_. **III**. Leiden: E. J. Brill. pp. 449. 
  13. ↑ _[International dictionary of library histories](http://books.google.com/books?id=Zoq_TtEN54IC&pg=PA29)_, 29
  14. ↑ Streeter, Burnett Hillman (10 Mar 2011). _[The Chained Library_](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Cambridge University Press. [http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Retrieved 6 March 2012. 
  15. ↑ Geo. Haven Putnam (1962). _Books and Their Makers in the Middle Ages_. Hillary. 
  16. ↑ This section on Roman Renaissance libraries follows Kenneth M. Setton, "From Medieval to Modern Library" _Proceedings of the American Philosophical Society_ **104**.4, Dedication of the APS Library Hall, Autumn General Meeting, November, 1959 (August 1960:371–390) p. 372 ff.
  17. ↑ Stockwell, Foster (2000). _A History of Information and Storage Retrieval_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-7864-0840-5](/wiki/Special:BookSources/0-7864-0840-5). 
  18. ↑ _**a**_ _**b**_ Mukherjee, A. K. (1966) _Librarianship: its Philosophy and History_. Asia Publishing House; p. 112
  19. ↑ Cresswell, Stephen. “The Last Days of Jim Crow in Southern Libraries.” Libraries and Culture 31 (summer/fall 1996): 557-573.
  20. ↑ Garrison, Dee. “The Tender Technicians: The Feminization of Public Librarianship, 1876-1905.” Journal of Social History 6 (winter 1972-1973): 131-156.
  21. ↑ Hildenbrand, Suzanne. "'Women's Work' within Librarianship." Library Journal 114 (September 1, 1989): 153-155.
  22. ↑ Trujillo, Roberto G., and Yolanda J. Cuesta, 1989. Service to Diverse Populations. ALA Yearbook of Library and Information Science. Vol. 14: 7-11.
  23. ↑ McCook, Kathleen, and Geist, Paula, 1993. Diversity Deferred: Where are the Minority Librarians? Library Journal. 118: 23-26.
  24. ↑ Guerena, Salvador and Edward Erazo. "Latinos and Librarianship." Library Trends 49 (2000) : 138-181.
  25. ↑ Wayne Wiegand, Tunnel Vision and Blind Spots: What the Past Tells Us about the present; reflections on the twentieth-century history of American librarianship (Library Quarterly, 69:1, Jan. 1999)
  26. ↑ Dowlin, Kenneth E. “Access to Information: A Human Right?” Bowker Annual 32 (1987): 64-68.
  27. ↑ Koenig, Michael E. D. “Information Services and Downstream Productivity.” Annual Review of Information Science and Technology 25 (1990): 55 – 86.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Information Organization](/wiki/Introduction_to_Library_and_Information_Science/Information_Organization)
[Re-contextualizing Libraries: Considering Libraries within Their Communities‎](/wiki/Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities) →

# Re-contextualizing Libraries: Considering Libraries within Their Communities[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=6)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Information Seeking](/wiki/Introduction_to_Library_and_Information_Science/Information_Seeking)
[Technology and Libraries: Impacts and Implications](/wiki/Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications) →

## The library as community space[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-1)]

### The library as third place[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-2)]

## Library service to specific communities[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-3)]

### Economically poor[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-4)]

Berman, S. (2005). Classism in the stacks: libraries and poor people. Counterpoise, 9(3), 51-55.

### Information poor[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-5)]

There are two groups when it comes to learning and sharing information: insiders and outsiders. Insiders are people who are comfortable with society. Outsiders are people who are more withdrawn from society, and often feel removed from everyone else. Outsiders may be secretive, deceitful, and/or afraid to take risks. Insiders and outsiders rarely exchange ideas with each other, because they may be suspicious of each other, and have a difficult time with trust.

Chatman implemented three studies focusing on three theories (gratification, alienation, and diffusion). She wanted to figure out why the insiders and outsiders were so different. She concluded that race and socioeconomic standings played a role. If an individual is forced to not trust others, they will also have a difficult time with trusting information (giving or receiving).

If people are forced to survive on their own, how can they be expected to embrace "outside ideas"? Embarrassment may be a factor for the outsiders too. The last thing they want to admit is that they may not be as knowledgeable as others. There may be obstacles they need to focus on that are much more crucial than learning new information.

Many barriers, including physical, economic, and social barriers, prevent or hinder people from finding the information they need. Many outsiders face a combination of these barriers, and do not want to try to overcome them just to obtain more information.[47]

### People with disabilities[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-6)]

Imagine having a disability and having no idea what to do. A library can be a wealth of information. They can connect the disabled person with organizations that can assist them. The library can also provide books, magazines, videos, products, and other resources to help the individual live independently. However, not many libraries are equipped with the information or the knowledge to be effective. A few suggestions to become better informed are to get on as many mailing lists of as many organizations for people with disabilities as possible and to use the Internet. Having the information is great, but it needs to be accessible. Libraries need to have assistive technology, like electronic magnifiers, machines that read aloud, modified keyboards, page turning devices, and assistive listening devices in order to serve this population. On top of having the accessible information, outreach services need to be used to bring people with disabilities into their community’s library. How could you disagree with this article? After many years working with children with physical and mental disabilities it is very evident that many libraries don’t offer programs and services to this population. It is very discouraging. Libraries are willing to bring in book collections for their culturally diverse populations but not for people with disabilities. Why doesn’t Dominican offer a course for providing services to people with disabilities? We offer courses for children and adults. Maybe this topic should be integrated into the curriculum of existing courses?[48]

  


### Rural communities[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-7)]

Fulfilling the informational and recreational needs of rural Americans is an important but challenging task for libraries. Staff creativity has helped counter the effects of budget constraints and lack of resources. Librarians can reach many people by meeting with local clubs and adult education classes. Librarians have an obligation to speak out in the community and communicate with city government to ask for and offer support. Linda Johnson wrote a literature review that provides examples of rural library programs that benefit this underserved population. Outreach services include Books by Mail, bookmobiles, deposit collections, and services to nursing homes, shelters, schools, and to the homebound. Programs for children offer social interaction and learning and frequently involve parents. There is also a need to serve youths who receive homeschooling.[49]

Anne Nelson shared her experiences of growing up in a small town and using its even smaller library. The library went above and beyond in purposely trying to keep things “safe” and not controversial to “protect” its community. Anne was looking for her library to challenge her not shield her from the world and its history. She also believed her library didn’t reach out to the minority citizens of the community. She was convinced her library needed to establish itself as a “democratic institution” in order to be able to serve everyone in the community. As the title of this article states, Anne’s library failed her. [50]

### Youth services[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-8)]

School and public libraries need to work together in order to provide the most effective services to the children/young adults of our nation. They are the future of this country and librarians can and should support their needs for growth and achievement. Libraries and librarians can help meet those needs in many ways. A few examples are:

  1. Provide a positive sense of self worth.
  2. Prepare them to use present day technology and to adapt to a changing technological world.
  3. Teach them to think critically in order to solve problems.
  4. Guide them in the process in becoming lifelong learners.
  5. Prepare them to communicate effectively – to listen, to speak, to read, and to write.

Even though this editorial article was written 16 years ago, it is still something that is relevant to the current times. It was an eye opener, and extremely helpful to read about all that is expected and what little assistance you sometimes receive. You would think librarians would have the resources, staffing, and facilities to effectively carry out this responsibility. It all comes back to library policies. As a future librarian, it is scary to see all that comes with the job but not see the support that is needed to perform it. Unfortunately politics are not something that all librarians want to get involved in. However, it is sometimes necessary to become an advocate in order to see the children/young adults, the future of this country, succeed.[51]

  
Whether you agree or not with the No Child Left Behind Act, it is here for the duration. This doesn’t just impact schoolteachers. School librarians play an important role in a child’s achievements, but it isn’t written out in concrete terms like it is for teachers. It is the librarian’s job to figure out their role in all of this. They have to become active, supportive, and a leader. They need to initiate special projects and collaborate with the schoolteachers and school specialists. They need to become an advocate for the school library and show everyone that it will assist in improving student achievement and NCLB scores.

This editorial article brings up a great point that hasn’t been brought up before in the GSLIS program. The No Child Left Behind Act has an affect on both school libraries and public libraries. Everyone needs to support all children and their efforts to achieve greatness. As an early childhood educator and future school librarian, the importance and necessity of school libraries and children’s/youth departments in public libraries is clearly evident. It will be part of the job, as a school librarian, to convince everyone else of this while maintaining effectiveness.[52]

  
The relationship between exposure to media violence and aggressive behavior by the viewer has been a major debate for almost 20 years. It is more likely for a child to be aggressive if he or she is reinforced for his or her aggression or if he or she is the object of aggression. In many cases, exposure to media violence increases the chance that a child will respond to frustration with aggression. The following variables may also play a part in the child’s aggression:

  * Intellectual achievement
  * Social popularity
  * Identification with television characters
  * Belief in the realism of television
  * Fantasizing about aggression

Parents should intervene when children are watching something too violent on the television because they provide critical input. Also, it is essential for parents to monitor children during the pre-adolescent years because that is when the media violence begins to stimulate the aggressive behavior.

Many individuals may agree with Huesmann’s statements, but it is important to remember that there are several other factors that can lead to aggression also. Parents should be aware of their child’s actions, and monitor the aggression. They should model proper behavior too. There is no concrete evidence that media violence is the main variable for an individual’s negative behavior, so why aren’t other variables analyzed and discussed regularly too?[53]

#### Who has the authority to determine what children read?[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-9)]

_**Libraries?**_ The ALA and Supreme Court agree that libraries do not act _in loco parentis_.

_**Parents?**_

ALA Supreme Court

This is one of the ALA's stances.  


“
Librarians and library governing bodies cannot assume the role of parents or the functions of parental authority in the private relationship between parent and child. Librarians and governing bodies should maintain that only parents and guardians have the right and the responsibility to determine their children's—and only their children’s—access to library resources.
”
  
The ALA also says that kids have the same privacy rights as adults; what materials they use cannot be shown to parents. So if the kid doesn't want to say what books they've been reading, then the parent does not have a right to that information. This makes it tricky for parents to exercise their responsibility to determine their children's access to library resources.
This is not the supreme court's idea: 

  * Primary caretakers are entitled to help of government bodies in fulfilling their duties as caretakers
  * Supervision of children's materials is best left to parents, but it's also in the interest of society (and hence the responsibility of librarians and others) not to have kids reading certain things.

_**Children?**_

ALA Supreme Court

This seems to be the ALA's real stance: 

  * Kids are responsible for selecting which materials they can or cannot read.
  * Parents can advise (and even advise with incentives/punishments), but so can anyone else.
The supreme court likes this too, but... 

  * Children's right to select such materials should be limited, both for the sake of the kid, and for the sake of society.
  * You can't remove books from libraries just because you don't agree with the views expressed in them. However, you can remove items if they're obscene, or otherwise not suitable for kids. School libraries can remove items if they are "educationally unsound."

_**Avoidance of harm argument**_ Restrictions on what kids can read may be harmful, as might the parent's knowledge of what the kid is reading (e.g. access to information for queer teens in rural areas, information about pregnancy for teens).

## Library-community relations[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-10)]

### Outreach services[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-11)]

### Library advocacy work[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-12)]

## References[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities&action=edit&section=T-13)]

  1. ↑ Casson, Lionel (11 Aug 2002). _Libraries in the Ancient World_. Yale University Press. p. 3. 
  2. ↑ _The American International Encyclopedia_, New York: J. J. Little & Ives, 1954; Volume IX
  3. ↑ [Britishmuseum.org](http://www.britishmuseum.org/research/research_projects/ashurbanipal_library_phase_1.aspx) "Assurbanipal Library Phase 1", British Museum One
  4. ↑ "Epic of Creation", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 233-81
  5. ↑ "Epic of Gilgamesh", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 50–135
  6. ↑ Van De Mieroop, Marc. _A History of the Ancient Near East ca. 3000–323 BC_. Oxford, UK: Blackwell Publishing, 2007: pg. 263
  7. ↑ _**a**_ _**b**_ Mukherjee, A. K. Librarianship: Its Philosophy and History. Asia Publishing House (1966) p. 86
  8. ↑ _**a**_ _**b**_ _**c**_ Phillips, Heather A., ["The Great Library of Alexandria?". Library Philosophy and Practice, August 2010](http://unllib.unl.edu/LPP/phillips.htm)
  9. ↑ Jochum, Uwe. “The Alexandrian Library and Its Aftermath.” Library History 15 (May 1999): 5-12.
  10. ↑ Seneca, _De tranquillitate animi_ ix.4–7.
  11. ↑ Zurndorfer, Harriet Thelma (1995). _China bibliography: a research guide ... – Google Books_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-90-04-10278-1](/wiki/Special:BookSources/978-90-04-10278-1). 
  12. ↑ Goeje, M. J. de, ed (1906). "Al-Muqaddasi: Ahsan al-Taqasim" (in Arabic). _Bibliotheca geographorum Arabicorum_. **III**. Leiden: E. J. Brill. pp. 449. 
  13. ↑ _[International dictionary of library histories](http://books.google.com/books?id=Zoq_TtEN54IC&pg=PA29)_, 29
  14. ↑ Streeter, Burnett Hillman (10 Mar 2011). _[The Chained Library_](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Cambridge University Press. [http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Retrieved 6 March 2012. 
  15. ↑ Geo. Haven Putnam (1962). _Books and Their Makers in the Middle Ages_. Hillary. 
  16. ↑ This section on Roman Renaissance libraries follows Kenneth M. Setton, "From Medieval to Modern Library" _Proceedings of the American Philosophical Society_ **104**.4, Dedication of the APS Library Hall, Autumn General Meeting, November, 1959 (August 1960:371–390) p. 372 ff.
  17. ↑ Stockwell, Foster (2000). _A History of Information and Storage Retrieval_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-7864-0840-5](/wiki/Special:BookSources/0-7864-0840-5). 
  18. ↑ _**a**_ _**b**_ Mukherjee, A. K. (1966) _Librarianship: its Philosophy and History_. Asia Publishing House; p. 112
  19. ↑ Cresswell, Stephen. “The Last Days of Jim Crow in Southern Libraries.” Libraries and Culture 31 (summer/fall 1996): 557-573.
  20. ↑ Garrison, Dee. “The Tender Technicians: The Feminization of Public Librarianship, 1876-1905.” Journal of Social History 6 (winter 1972-1973): 131-156.
  21. ↑ Hildenbrand, Suzanne. "'Women's Work' within Librarianship." Library Journal 114 (September 1, 1989): 153-155.
  22. ↑ Trujillo, Roberto G., and Yolanda J. Cuesta, 1989. Service to Diverse Populations. ALA Yearbook of Library and Information Science. Vol. 14: 7-11.
  23. ↑ McCook, Kathleen, and Geist, Paula, 1993. Diversity Deferred: Where are the Minority Librarians? Library Journal. 118: 23-26.
  24. ↑ Guerena, Salvador and Edward Erazo. "Latinos and Librarianship." Library Trends 49 (2000) : 138-181.
  25. ↑ Wayne Wiegand, Tunnel Vision and Blind Spots: What the Past Tells Us about the present; reflections on the twentieth-century history of American librarianship (Library Quarterly, 69:1, Jan. 1999)
  26. ↑ Dowlin, Kenneth E. “Access to Information: A Human Right?” Bowker Annual 32 (1987): 64-68.
  27. ↑ Koenig, Michael E. D. “Information Services and Downstream Productivity.” Annual Review of Information Science and Technology 25 (1990): 55 – 86.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Information Seeking](/wiki/Introduction_to_Library_and_Information_Science/Information_Seeking)
[Technology and Libraries: Impacts and Implications](/wiki/Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications) →

# Technology and Libraries: Impacts and Implications[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=7)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Re-contextualizing Libraries: Considering Libraries within Their Communities](/wiki/Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities)
[Transcending Boundaries: Global Issues and Trends](/wiki/Introduction_to_Library_and_Information_Science/Transcending_Boundaries:_Global_Issues_and_Trends) →

  


## Technology and LIS: a historical perspective[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Vannevar_Bush_portrait.jpg/220px-Vannevar_Bush_portrait.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A portrait of Vannevar Bush

In his prophetic 1945 article _As We May Think_, Vannevar Bush envisioned a machine called a _memex_, a collective memory machine that would make knowledge more accessible. The author begins his argument by discussing the growing amount of information in the world. The increasing amount and complexity of information along with the time gap between creation and dissemination requires a new technology. Bush's technology would focus on greater usability in information retrieval, allowing users to create their own "sort of mechanized private file and library". Through the miniaturization of data using photocells or microfilm, great amounts of information could be stored in very little space. Traditionally information is stored in index or hierarchical form, but this is not how the brain stores information. The memex would arrange things associatively, mimicking the way the human brain stores and contextualizes information.

This memex is remarkably similar to a modern day computer, in that it would be a new technology designed for personal use that would allow for the creation, storage, and organization of different materials and data. This is a fascinating article as it explains how the need of a new way to store, organize and retrieve increasing amounts of data led to the idea of modern day computers. It is a particularly interesting article in the modern context, where information and data continue to expand at an exponential rate. What new technologies and changes in data organization will the future hold? How will libraries adapt to these changes?[54]

  
Technology began to transform libraries in the 1950s with microfilm and in the mid-1960s with the Xerox machine. Computerized databases were developed in the 1970s and offered more information and better ways to search and obtain it. Networks such as OCLC and RLIN made it easier to share resources. Although this article predates widespread use of the Internet, it is correct in predicting that technology will continue to change the future of libraries. Technology has allowed greater access to information for more people, but it was too early for the author to accurately predict the digital divide. He argues that libraries must innovate to stay alive and that change is happening so quickly that it often appears "chaotic." The World Wide Web, however, is often described as chaotic, unorganized, and confusing, but its benefits greatly outweigh its risks. Because new technology often helps libraries keep people connected to information, libraries must strive to make sense out of the technological chaos. The author makes a strong case for businesses’ need to compete but states that libraries’ structure and rules "inhibit us from making the kind of innovation that is needed to compete and survive." The challenge, he concludes, is not in introducing new technology but in creating new management structures for libraries. This plan seems to push libraries toward behaving like businesses, but I think this would restrict access and introduce new economic, cultural, and political problems.[55]

## Implementing information technologies in libraries[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-2)]

According to John Bushman, the implementation of information technology requires librarians to ask two basic questions:

  * Why is the technology good for libraries, librarians, or the public?
  * Where will the technology lead us?

It is the librarian's duty to ask these questions and become involved in finding the answers. All technological advances need to be approached critically, with the knowledge that they may have both social and political consequences. Librarians need to be able to evaluate technologies to determine whether a given technology will harm or help the library and its community. Funding, getting the public involved with the change in technology, getting them to deal with the positive and negative effects of change, and making sure the librarians are able to handle the pressures are all ways of becoming involved with finding the answers about information technology and the future of libraries.[56]

## Digital libraries and services[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-3)]

### Digital libraries[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-4)]

The Digital Library Federation looked at what it sees as the major issues regarding digital libraries in the future. These are the five challenges the organization have outlined: architectural and systems in libraries, standards and practices, collection development, how communities will use a digital library, and long-term access to digital libraries. In terms of designing and implementing new technology, information sharing about new technology is vital because few employees in libraries actually manage technological change. Libraries need to have a plan so adopting technology and training employees and users is a smooth transition. The library is simultaneously a consumer and supplier of information and needs to have standards to critique itself. Issues involved in collection development include costs, copyright and licensing, all facets of computerizing, support services, and the impact on the rest of the library. How information is presented online can determine whether and to what extent it is used by the public. The sources of digital information are coming from all kinds of places and shared resources can help defray costs. Making the decision about what information to digitize and anticipating the costs of preserving the information is the last of these challenges.

The digital library service environment is defined as a network online information space in which users can discover, locate, acquire access to, and increasingly use information. There is no distinction about the information format. The identity of a digital library is the way the library discloses, provides access to, and supports the use of its increasingly virtual collection. Managing, administering, monitoring and ensuring fair use of its collection are a part of the mix, as well as keeping up with new technologies to support education and cultural engagement so that the library can evolve and sustain itself. The prospect of a completely virtual library still seems in the future, but we seem headed in that direction.[57]

The National Digital Library Program was created by the Library of Congress so libraries, schools and homes will have access to original documents of American history and culture. The goal by the year 2000 was to digitize over 5 million items. The challenge is selecting from over 110 million items and converting to a technological format that will last. Some funding is coming from private donations. The article is descriptive, informative, but at the same time unclear about how the selection of information to be digitized was made. The Library of Congress is a leading repository of information. Is their selection of information for this digitizing project representative of the body of knowledge that Americans and world scholars can look to understand what has shaped American history? Should we be questioning whether American history is more important than other cultures that have been influential in world history? For instance, the book, In Search of the Cradle of Civilization, (Frawley, et al) places east Indian settlements earlier than Sumerian, Mesopotamian, and Babylonian societies. India, the largest democracy in the world today, has been ignored by the rest of the world. Books like In Search of the Cradle can be found at The Theosophical Society which has been a part of Wheaton’s local history for over 100 years. A part of my role in the Olcott Library is to apply for a state grant that will digitize important elements of the collection that contribute to Illinois history.[58]

### Virtual reference[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-5)]

In an effort to reach patrons accessing the library via computers, many libraries and library consortia offer virtual reference services. These services can be either real-time or offset, and are offered via email, instant messaging, web form interfaces, SMS, and even virtual reality games. According to the Reference and User Services Association, "Virtual reference is responsive to patrons' need for convenient access to reference service." [59]

Though virtual reference is a great convenience for library patrons, its implementation introduces several challenges for traditional libraries. Most individual institutions don't have the staffing levels necessary to monitor an IM service regularly enough for the service be attractive to users. For real-time virtual reference, many libraries are part of chat co-operatives or consortia, some of which are able to offer reference services 24 hours a day. However, this does mean that reference workers from other institutions, who may not be as familiar with the patrons' home institution's resources, may not be able to provide services of as high a quality as the home institution might.

In his introduction to _Digital Reference Service in the New Millennium: Planning, Management, and Evaluation_, R. David Lankes examines the emerging field of digital reference, how it affects the traditional reference staff and service, and addresses two key issues, "scalability" and "ambiguity".

Lankes makes the argument that the availability and use of digital resources are fundamentally re-defining the role of reference services. According to Lankes, library reference staff are now becoming "information brokers", because of the nature of the digital environment and changing user expectations. He discusses two issues, scalability (the ability to service growth), and ambiguity (identifying resources needed to meet user's needs). He describes several differing initiatives that have been or could be brought into play to address these issues, both alterations of existing reference practices, and new methods of providing relevant reference services in a digital age.

His arguments are sound, and pose fundamental questions as to what defines a “Library” and “Reference Services”, as one would expect in the introductory chapter of a book on the changing role the digital world plays in the reference field. Some of the questions and possible solutions, however, seem very radical and unrealistic given the fragmented standard reference environment based on local libraries, both from a funding and staffing perspective, and assumes that some “entity” (modeled on the private sector) will provide a more centralized construct more appropriate for the digital age.[60]

## Access to technology[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-6)]

Gordon Flagg explains how the FCC unanimously passed a new rule on May 7, 1997 that decreased the charges of telecommunication services to schools and libraries throughout the nation. The discounts range from 20-90% (the highest percent going to libraries and schools in low-income, rural, and high-cost communities). In order to raise the $2.25 billion needed for this plan they increased fees ($1.50 for residential and $3.00 for business) and taxes on second phone lines.

This decision was praised by the ALA because it allows more schools and libraries to access the internet where in the based it was too costly to do so. That way everyone has the opportunity to use this service even if they cannot afford it in their homes. Some experts feared that this reduction would be difficult to sustain in the long run, because it is such a big undertaking and that there may be legal challenges they might have to deal with.[61]

## Physical libraries in a cyber world[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-7)]

Rapidly-deteriorating materials create an urgent need to focus on preservation, particularly in research libraries. Preservation decisions often fall into two major categories: _selection_ and _medium_.

  * Problems of _selection_ are best answered by a team of both librarians and scholars, who employ criteria that is three-fold: collection-, subject-, and usage-based.
  * Problems of _medium_, on the other hand, are more subjective. Microfilm is quite stable and durable, but access is somewhat limited. Digitization, while alleviating access problems, poses concerns about cost, instability, and hardware and software change.

Abby Smith advocates a preservation strategy that includes a combination of microfilm and digital storage. To be sure, funding for this multi-pronged approach is unanswered, but Smith’s ideas in action will help ensure the selection of a broad scope of scholarly works for preservation in forms that meet researchers' needs of integrity and accessibility. Since the publication of Smith's article, however, digital storage has gained more potential. For instance, some problems of cost and changing technology can be mitigated by storing documents on, say, a one-terabyte hard drive. Drive size has certainly come down in cost since 1999, and a hard drive will not become obsolete as quickly as many removable formats. Moreover, accessibility may be benefited by the sheer amount of works that can fit on a terabyte hard drive. Nonetheless, it is clear that the mediums used for preservation should be reevaluated as digitization expands.[62]

  


## Cost of adoption[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-8)]

Libraries have been transformed and modernized by the application of information technology. Users do not have to go to libraries, and have the opportunity to retrieve information via Internet. Because of all the new technology being introduced to libraries, library administrators are forced to break down the budget, in order to make wise decisions when it comes to long-term benefits for the library. If a library administrator follows a cost structure model, he/she will have more success determining the direct and indirect costs. Also, the library administrator will be able to understand the initial and recurring costs within the life cycle of implied information technologies. It is common for administrators to forget to include training and other necessary costs, which may hurt their long-term budget. It is essential for library administrators to analyze each part of the budget, so he/she does not end up wasting any money.

I agree with the author’s statement about the “bigger picture” when it comes to a budget, and remembering the significance of keeping up with new technology offered. Chapter five brings up several great points about the importance of the growth of technology, and the awareness of people’s right to privacy. Much of society is getting comfortable with technology, and requires the programs offered. It is the library’s job to provide the programs to the public, and not go over the budget, while remembering the importance of an individual's privacy.[63]

  
Monetary costs are not the only costs to adopting new technology. Author Nicholson Baker is a firm believer that adopting new technologies can come at the expense of preserving history. Libraries around the country, including those at academic institutions, have replaced many of their card catalogs with online access catalogs. They are throwing out their card catalogs, sometimes with fanfare. Despite some attempts to preserve data by microfilming the cards and proofing the new records, information is being lost because of errors and omissions.

Librarians rapidly adapted to technology to cope with a cataloging crisis caused by growing numbers of items to process. The author argues that they are overlooking their mission to preserve books. Instead of being archetype librarians, they want to be seen as technology specialists.

Author Nicholson Baker contended that disposing of the card catalog was akin to tossing out history. The notations made on each card over decades, make the card catalog itself an artifact worthy of preservation. It is ironic that while the goal of libraries is to preserve information, they are keen to dispose of the catalog, which he sees as more than a finding aid. With humor, wit and irony Baker described the evolution of the library catalog. Accession dates, provenance and notes in some catalogs might be of value to scholars, but the nostalgia for well-thumbed faded cards with carefully written notes seems to be Baker's primary object.[64]

  
Nicholson again critiqued libraries' adoption of technologies in his 2001 book _Double fold: libraries and the assault on paper_, Nicholson Baker presents a strongly-worded critique of libraries' digital reproduction of paper materials. In one of his most compelling case studies, he examines the case of the _Syracuse Daily Standard_ newspaper, which in 1858, claimed to have been printed on paper "said to be taken from Egyptian [sic] mummies." When he attempted to find the actual newspapers, he discovered that the local public library had since discarded its paper copies of the newspaper, instead offering a microfilm copy to its patrons.[65]

The book, which the New York Times described as a "blistering and thoroughly idiosyncratic attack"[66], was strongly criticized by the library community. A major argument against Baker's book was that libraries build their collections based on both current and anticipated use, rather than strictly preserving anything they can. Not every item ever published can be collected and preserved in its original format, nor will every item ever published be useful to library patrons, especially if it has disintegrated extensively. A second major argument against the book was the impracticality of maintaining print items, particularly acidic ones, on a large scale. A third argument notes that digitization and microfilm tend to enable more people access to a particular item, as microforms can be shared via Interlibrary Loan much more feasibly than can decaying print resources, and since digitized materials can often be shared with anyone who can access the Internet. For a bibliography of reactions to Baker's book, see the [of Research Library's exhaustive list](http://www.arl.org/preserv/presresources/Nicolas_Baker.shtml%7CAssociation).

## Conclusion: Rutenbeck's "Five great challenges"[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-9)]

According to Jeff Rutenbeck, the continued growth of the digital world presents five major challenges to its users: malleability, selectivity, exclusivity, vulnerability, and superficiality.

### Malleability[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-10)]

Malleability refers to the total impermanence of digital information, from data to pictures to even people's identities. Unlike print, digital information can be reconfigured in ways that print information cannot.

### Selectivity[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-11)]

Selectivity addresses the preference by users to only consider information available online, dismissing information available only in print.

### Exclusivity[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-12)]

The digital divide comes to the forefront with exclusivity, since new technology is being introduced constantly, but there is no universal way to bring everyone to the same levels of competence.

### Vulnerability[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-13)]

Vulnerability highlights the inherent problems with our interconnectedness; while we enjoy the easy and constant flow of information and ideas, at the same time, we leave ourselves open to security breaches and systems failures.

### Superficiality[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-14)]

What I feel is the greatest challenge in the digital age is superficiality. We have access to so much information, but there is no guarantee that what we see is accurate.

### Conclusion[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-15)]

The author identifies the issues clearly, and offers suggestions as to how we can battle these challenges, but acknowledges that there is no clear cut answer to overcoming any of them. Most users, including myself, butt against these issues in our personal and business life, and struggle with how to reconcile them, since, as the author acknowledges, any answer leads to compromises.[67]

## References[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications&action=edit&section=T-16)]

  1. ↑ Casson, Lionel (11 Aug 2002). _Libraries in the Ancient World_. Yale University Press. p. 3. 
  2. ↑ _The American International Encyclopedia_, New York: J. J. Little & Ives, 1954; Volume IX
  3. ↑ [Britishmuseum.org](http://www.britishmuseum.org/research/research_projects/ashurbanipal_library_phase_1.aspx) "Assurbanipal Library Phase 1", British Museum One
  4. ↑ "Epic of Creation", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 233-81
  5. ↑ "Epic of Gilgamesh", in Dalley, Stephanie. _Myths from Mesopotamia._ Oxford, 1989; pp. 50–135
  6. ↑ Van De Mieroop, Marc. _A History of the Ancient Near East ca. 3000–323 BC_. Oxford, UK: Blackwell Publishing, 2007: pg. 263
  7. ↑ _**a**_ _**b**_ Mukherjee, A. K. Librarianship: Its Philosophy and History. Asia Publishing House (1966) p. 86
  8. ↑ _**a**_ _**b**_ _**c**_ Phillips, Heather A., ["The Great Library of Alexandria?". Library Philosophy and Practice, August 2010](http://unllib.unl.edu/LPP/phillips.htm)
  9. ↑ Jochum, Uwe. “The Alexandrian Library and Its Aftermath.” Library History 15 (May 1999): 5-12.
  10. ↑ Seneca, _De tranquillitate animi_ ix.4–7.
  11. ↑ Zurndorfer, Harriet Thelma (1995). _China bibliography: a research guide ... – Google Books_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [978-90-04-10278-1](/wiki/Special:BookSources/978-90-04-10278-1). 
  12. ↑ Goeje, M. J. de, ed (1906). "Al-Muqaddasi: Ahsan al-Taqasim" (in Arabic). _Bibliotheca geographorum Arabicorum_. **III**. Leiden: E. J. Brill. pp. 449. 
  13. ↑ _[International dictionary of library histories](http://books.google.com/books?id=Zoq_TtEN54IC&pg=PA29)_, 29
  14. ↑ Streeter, Burnett Hillman (10 Mar 2011). _[The Chained Library_](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Cambridge University Press. [http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false](http://books.google.co.uk/books?id=jM-OY0LCHCEC&printsec=frontcover&dq=Chained+libraries&hl=en&sa=X&ei=guNVT9v8CMTV8QPmmaTbCA&redir_esc=y#v=onepage&q=Chained%20libraries&f=false). Retrieved 6 March 2012. 
  15. ↑ Geo. Haven Putnam (1962). _Books and Their Makers in the Middle Ages_. Hillary. 
  16. ↑ This section on Roman Renaissance libraries follows Kenneth M. Setton, "From Medieval to Modern Library" _Proceedings of the American Philosophical Society_ **104**.4, Dedication of the APS Library Hall, Autumn General Meeting, November, 1959 (August 1960:371–390) p. 372 ff.
  17. ↑ Stockwell, Foster (2000). _A History of Information and Storage Retrieval_. [ISBN](//en.wikipedia.org/wiki/International_Standard_Book_Number) [0-7864-0840-5](/wiki/Special:BookSources/0-7864-0840-5). 
  18. ↑ _**a**_ _**b**_ Mukherjee, A. K. (1966) _Librarianship: its Philosophy and History_. Asia Publishing House; p. 112
  19. ↑ Cresswell, Stephen. “The Last Days of Jim Crow in Southern Libraries.” Libraries and Culture 31 (summer/fall 1996): 557-573.
  20. ↑ Garrison, Dee. “The Tender Technicians: The Feminization of Public Librarianship, 1876-1905.” Journal of Social History 6 (winter 1972-1973): 131-156.
  21. ↑ Hildenbrand, Suzanne. "'Women's Work' within Librarianship." Library Journal 114 (September 1, 1989): 153-155.
  22. ↑ Trujillo, Roberto G., and Yolanda J. Cuesta, 1989. Service to Diverse Populations. ALA Yearbook of Library and Information Science. Vol. 14: 7-11.
  23. ↑ McCook, Kathleen, and Geist, Paula, 1993. Diversity Deferred: Where are the Minority Librarians? Library Journal. 118: 23-26.
  24. ↑ Guerena, Salvador and Edward Erazo. "Latinos and Librarianship." Library Trends 49 (2000) : 138-181.
  25. ↑ Wayne Wiegand, Tunnel Vision and Blind Spots: What the Past Tells Us about the present; reflections on the twentieth-century history of American librarianship (Library Quarterly, 69:1, Jan. 1999)
  26. ↑ Dowlin, Kenneth E. “Access to Information: A Human Right?” Bowker Annual 32 (1987): 64-68.
  27. ↑ Koenig, Michael E. D. “Information Services and Downstream Productivity.” Annual Review of Information Science and Technology 25 (1990): 55 – 86.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Re-contextualizing Libraries: Considering Libraries within Their Communities](/wiki/Introduction_to_Library_and_Information_Science/Re-contextualizing_Libraries:_Considering_Libraries_within_Their_Communities)
[Transcending Boundaries: Global Issues and Trends](/wiki/Introduction_to_Library_and_Information_Science/Transcending_Boundaries:_Global_Issues_and_Trends) →

# Transcending Boundaries: Global Issues and Trends[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=8)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Technology and Libraries: Impacts and Implications](/wiki/Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications)
[Learning More: Free LIS Resources](/wiki/Introduction_to_Library_and_Information_Science/Learning_More:_Free_LIS_Resources) →

  
This book will close with a look at librarianship outside the context of the United States and Canada, and will examine some emerging themes in the field of Librarian and Information Science.

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**
**Next Chapter**

← [Technology and Libraries: Impacts and Implications](/wiki/Introduction_to_Library_and_Information_Science/Technology_and_Libraries:_Impacts_and_Implications)
[Learning More: Free LIS Resources](/wiki/Introduction_to_Library_and_Information_Science/Learning_More:_Free_LIS_Resources) →

# Learning More: Free LIS Resources[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=9)]

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**

← [Transcending Boundaries: Global Issues and Trends](/wiki/Introduction_to_Library_and_Information_Science/Transcending_Boundaries:_Global_Issues_and_Trends)

  
Many LIS resources have restrictive licenses and are only available to people affiliated with libraries that subscribe to them. This includes many of our discipline's most well-known journals. However, there is an increasing number of LIS material available freely online. Some are free of charge, others are freely licensed, and some, like the LIS Wiki, can be edited by anyone.

## Reference sources[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Learning_More:_Free_LIS_Resources&action=edit&section=T-1)]

  * [Online Dictionary for Library and Information Science](http://www.abc-clio.com/ODLIS/odlis_A.aspx), by Joan K. Reitz. This is a great resource, but not freely licensed, so don't copy it here.
  * [LIS Wiki](http://liswiki.org/wiki/Main_Page), a Free compendium that anyone can edit -- licensed under the GNU FDL.
  * Talking with other library workers, many of whom love answering questions and mentoring.

## Peer-reviewed Journals[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Learning_More:_Free_LIS_Resources&action=edit&section=T-2)]

While the major peer-reviewed journals in LIS tend to have some major barriers to access, an increasing number of journals in our field are freely accessible online. Currently, open access journals tend to have a more international focus, and also tend to emphasize technology topics more than traditional U.S. indexes of library publications. You can search a number of open-access peer-revied journals simultaneously using the [[Directory of Open Access Journals](http://www.doaj.org)], which indexes dozens of LIS journals.

  * [code4lib](http://journal.code4lib.org/) is an excellent journal about library tech.
  * [DESIDOC Journal of Library & Information Technology](http://publications.drdo.gov.in)
  * [D-Lib](http://www.dlib.org/) \-- one of the most well-respected journals in the area of digital libraries.
  * [First Monday](http://firstmonday.org/index) "is one of the first openly accessible, peer–reviewed journals on the Internet, solely devoted to the Internet. Since its start in May 1996, First Monday has published 1,278 papers in 205 issues; these papers were written by 1,714 different authors." Licensed under the Creative Commons BY-NC-SA license.
  * [Information Technology and Libraries](http://ejournals.bc.edu/ojs/index.php/ital/issue/current)
  * [In the Library with the Lead Pipe](http://www.inthelibrarywiththeleadpipe.org) \-- despite this blog's humorous title, it provides a number of peer-reviewed articles with footnoted citations, and is an awesome place to learn about new ideas in librarianship.
  * [International Journal of Digital Library Services](http://www.ijodls.in)
  * [International Research: Journal of Library and Information Science](http://irjlis.com)
  * [Journal of Library Innovation](http://www.libraryinnovation.org/) covers innovative library practices in many forms, ranging from "the discovery of unmet user needs" to "creative collaboration between libraries, or between libraries and other types of institutions" to "Implementing new technologies" to "Explorations of the future of libraries."
  * [Journal of the Medical Library Association](https://www.ncbi.nlm.nih.gov)
  * [Library and Information Research](http://www.lirgjournal.org.uk/)
  * [Library Philosophy and Practice](http://digitalcommons.unl.edu/libphilprac/)
  * [Library Resources and Technical Services (LRTS)](http://www.ala.org/alcts/resources/lrts/archive) is one of the most prestigious journals in the areas of cataloging and technical services. The American Library Association makes the entire run of this journal, except for the most recent year, available online.
  * [Library Student Journal](http://www.librarystudentjournal.org) \-- articles written by LIS students. Note that only the "Articles" section, rather than the "Essays" and "Opinions" sections, is peer-reviewed. Although this journal isn't cited very often, the articles are of a high quality.
  * [Library Trends](https://ideals.illinois.edu/handle/2142/999) has been edited by professors at the Graduate School of LIS at the University of Illinois since 1952. Each issue has its own theme, and the topics it covers are quite wide-ranging. Illinois' Institutional Repository makes all issues available online, except for the two most recent years.
  * [Partnership: the Canadian Journal of Library and Information Practice and Research](https://journal.lib.uoguelph.ca/index.php/perj/)
  * [Theological Librarianship](https://journal.atla.com/ojs/index.php/theolib)

### Non-English[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Learning_More:_Free_LIS_Resources&action=edit&section=T-3)]

  * [Journal of Educational Media and Library Sciences](http://joemls.dils.tku.edu.tw/) (Chinese - Taiwan)
  * [Knjižnica](http://revija-knjiznica.zbds-zveza.si/) (Slovenian)
  * [Libreas](http://www.libreas.eu/) (German)

!["A brightly-lit public library building in Taipei"](//upload.wikimedia.org/wikipedia/commons/thumb/b/b7/TpmlBeitou.JPG/100px-TpmlBeitou.JPG)
_**Introduction to**_  
_**Library and Information Science**_

[Textbook home](/wiki/Introduction_to_Library_and_Information_Science)

[List of chapters](/wiki/Introduction_to_Library_and_Information_Science#Chapters)

[LIS books on Wikibooks](/wiki/Subject:Library_and_information_science)
![Ottawa Library's bookmobile with writing in both English and French](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Bookmobile.jpg/100px-Bookmobile.jpg)
_**Get Involved**_

[To do list](/wiki/Introduction_to_Library_and_Information_Science/To_Do_List)

[Contributors list](/wiki/Introduction_to_Library_and_Information_Science/List_of_Contributors)

[How to contribute to Wikibooks](/wiki/Help:Contributing)

**Previous Chapter**

← [Transcending Boundaries: Global Issues and Trends](/wiki/Introduction_to_Library_and_Information_Science/Transcending_Boundaries:_Global_Issues_and_Trends)

  


# List of Contributors[[edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit&section=10)]

This textbook began as an experiment by Kate Williams and students at [Dominican University library school](http://www.dom.edu/gslis). Here are the members of that class who contributed annotations to the project:

  * Amanda Genge
  * Angela Busboom Yackley
  * Ann Gass
  * Anna Parks
  * Corey Bard
  * Dana Folkerts
  * Gwen Jackson
  * Judy Smith
  * Kara Bourke
  * Katie Sollors
  * Perry Bassett

Since then, others have worked on this textbook:

  * [Jane Sandberg](/wiki/User:Sandbergja)

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&oldid=2561196](http://en.wikibooks.org/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&oldid=2561196)" 

[Category](/wiki/Special:Categories): 

  * [Introduction to Library and Information Science](/wiki/Category:Introduction_to_Library_and_Information_Science)

Hidden category: 

  * [No references for citations](/wiki/Category:No_references_for_citations)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Introduction+to+Library+and+Information+Science%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Introduction+to+Library+and+Information+Science%2FPrint+version)

### Namespaces

  * [Book](/wiki/Introduction_to_Library_and_Information_Science/Print_version)
  * [Discussion](/w/index.php?title=Talk:Introduction_to_Library_and_Information_Science/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Introduction_to_Library_and_Information_Science/Print_version)
  * [Edit](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=edit)
  * [View history](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Introduction_to_Library_and_Information_Science/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Introduction_to_Library_and_Information_Science/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&oldid=2561196)
  * [Page information](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Introduction_to_Library_and_Information_Science%2FPrint_version&id=2561196)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Introduction+to+Library+and+Information+Science%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Introduction+to+Library+and+Information+Science%2FPrint+version&oldid=2561196&writer=rl)
  * [Printable version](/w/index.php?title=Introduction_to_Library_and_Information_Science/Print_version&printable=yes)

  * This page was last modified on 27 September 2013, at 04:16.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Introduction_to_Library_and_Information_Science/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
