# Spanish/Print version

From Wikibooks, open books for an open world

< [Spanish](/wiki/Spanish)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

  


## Contents

  * 1 Spanish
  * 2 Main Contents
  * 3 **Introduction**
    * 3.1 Book definition
    * 3.2 Introduction
  * 4 **Lesson one**
    * 4.1 Dialogue
    * 4.2 Hello!
    * 4.3 What's your name?
    * 4.4 Simple Vocabulary
    * 4.5 The Spanish Alphabet
      * 4.5.1 Consonants
      * 4.5.2 Vowels
    * 4.6 Acute accents
    * 4.7 How do you spell that?
    * 4.8 Summary
  * 5 **Lesson two**
    * 5.1 Dialogue
    * 5.2 The numbers
      * 5.2.1 Notes
      * 5.2.2 Examples
    * 5.3 How old are you?
    * 5.4 What's the date today?
    * 5.5 When's your birthday?
    * 5.6 Summary
  * 6 **Lesson three**
    * 6.1 Articles
      * 6.1.1 Definite articles
      * 6.1.2 Indefinite articles
    * 6.2 Regular Verbs
    * 6.3 Questions and Exclamations
    * 6.4 Summary
  * 7 **Lesson four**
    * 7.1 Dialogue
    * 7.2 Countries of the World
      * 7.2.1 Where do you live?
      * 7.2.2 The compass
    * 7.3 Habitations
    * 7.4 Adjectives
    * 7.5 City and Countryside
    * 7.6 Summary
  * 8 **Lesson five**
    * 8.1 Dialogue
    * 8.2 Sports and Activities
    * 8.3 Stem-changing Verbs
    * 8.4 Compound Sentences
    * 8.5 ¿Qué opinas sobre los deportes?
      * 8.5.1 Gustar
      * 8.5.2 Love and Hate
    * 8.6 Summary
  * 9 **Lesson six**
    * 9.1 Dialogue
    * 9.2 Food and Drink
      * 9.2.1 What do you eat?
      * 9.2.2 A bottle of wine
    * 9.3 In the Shop
    * 9.4 Adjectives
      * 9.4.1 "E" and Consonant Adjectives
      * 9.4.2 Colours
    * 9.5 Summary
  * 10 **Pronunciation**
    * 10.1 Letter-sound correspondences in Spanish
    * 10.2 One letter, one sound
    * 10.3 Local pronunciation differences
    * 10.4 Word stress
      * 10.4.1 Rules for pronouncing the implicit accent
    * 10.5 The diaeresis ( ¨ )
  * 11 **Contributors**

# 

# Spanish[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=1)]

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Spanish](/wiki/Spanish)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Spanish/Print_version&action=purge&printable=yes) this page.

# Main Contents[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=2)]

  * [Introduction](/wiki/Spanish/Print_version#Introduction)
  * [Lesson one](/wiki/Spanish/Print_version#Lesson_one)
  * [Lesson two](/wiki/Spanish/Print_version#Lesson_two)
  * [Lesson three](/wiki/Spanish/Print_version#Lesson_three)
  * [Lesson four](/wiki/Spanish/Print_version#Lesson_four)
  * [Lesson five](/wiki/Spanish/Print_version#Lesson_five)
  * [Lesson six](/wiki/Spanish/Print_version#Lesson_six)
  * [Pronunciation](/wiki/Spanish/Print_version#Pronunciation)
  * [Contributors](/wiki/Spanish/Print_version#Contributors)

* * *

# **Introduction**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=3)]

## Book definition[[edit](/w/index.php?title=Spanish/Introduction&action=edit&section=T-1)]

  * **Scope**: This Wikibook aims to teach the Spanish language from scratch. It will cover all of the major grammar rules, moving slowly and offering exercises and plenty of examples. It's not all grammar though, as it offers vocabulary and phrases too, appealing to all learners. By the end, you should be able to read and write Spanish skilfully, though you'll need a human to help with listening and speaking.
  * **Purpose**: The purpose of this Wikibook is to teach you the Spanish language in an easy and accessible way. By the end, as mentioned, you should be a proficient reader and writer, though listening and speaking require a human tutor.
  * **Audience**: Anyone who wishes to learn Spanish, though adult and teenage learners are likely to enjoy it more.
  * **Organization**: This Wikibook requires no prior knowledge of the subject, and all relevant terms are explained as they are encountered. The book runs chronologically from lesson 1 to lesson 2 to lesson 3 and so on until the end.
  * **Narrative**: Generally engaging and thorough, with plenty of examples and exercises to aid learning. Once concepts are introduced, they are repeated, building a base of vocabulary and grammar that will stay in your mind.
  * **Style**: This book is written in British English, and the Spanish taught is generally Iberian Spanish (called _Castellano_ in Spain), though key Latin American differences are explained as we go along. The formatting is consistent throughout, with Spanish in italics and all tables using the same formatting. Each lesson begins with a conversation, including the key grammar and vocabulary in the lesson. At the end, there is a summary, explaining what has been achieved. Exercises are linked throughout, and each new concept or set of vocabulary is accompanied by examples, each with a translation underneath.

## Introduction[[edit](/w/index.php?title=Spanish/Introduction&action=edit&section=T-2)]

You are about to embark on a course learning another language, the Spanish Language!

The first lesson begins with simple greetings, and covers important ideas of the Spanish Language. Throughout education, methods of teaching Spanish have changed greatly. Years ago, the Spanish Language was taught simply by memory. Today, however, the Spanish Language is taught by moving slowly and covering grammar and spelling rules.

Again, this is an introduction. If this is the first time you are attempting to learn Spanish, do not become discouraged if you cannot understand, pronounce, or memorize some of the things discussed here.

In addition, learning a second language requires a basic understanding of your own language. You may find, as you study Spanish, that you learn a lot about English as well. At their core, all languages share some simple components like verbs, nouns, adjectives, and plurals. Your first language comes naturally to you and you don't think about things like subject-verb agreement, verb conjugation, or usage of the various tenses; yet, you use these concepts on a daily basis.

While English is described as a very complicated language to learn, many of the distinguishing grammar structures have been simplified over the years. This is not true for many other languages. Following the grammatical conventions of Spanish will be very important, and can actually change the meaning of phrases. You'll see what is meant by this as you learn your first verbs _ser_ and _estar_.

Do not become discouraged! You can do it.

[Continue to lesson 1](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) >>

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

  


* * *

# **Lesson one**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=4)]

![Geometría](//upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Alfonso_X_el_Sabio_y_su_corte.jpg/80px-Alfonso_X_el_Sabio_y_su_corte.jpg)

![Quijote-2.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Quijote-2.jpg/70px-Quijote-2.jpg)

Lesson 1 — ¿Cómo te llamas?

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Segovia_Aqueduct.JPG/200px-Segovia_Aqueduct.JPG)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The aqueduct of Segovia.

  


## Dialogue[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-1)]

    _**Raúl**: ¡Hola! Me llamo Raúl. ¿Cómo te llamas?_
    _**Sofía**: Hola, Raúl. Me llamo Sofía. ¿Cómo se escribe Raúl?_
    _**Raúl**: Se escribe R-A-Ú-L. ¿Qué tal?_
    _**Sofía**: Bien. ¿Y tú?_
    _**Raúl**: Fenomenal, gracias._
    _**Sofía**: ¡Qué fantástico! Adiós, Raúl._
    _**Raúl**: ¡Hasta luego!_

[Translation](/wiki/Spanish/Exercises/%C2%BFC%C3%B3mo_te_llamas%3F#Dialogue) (wait until the end of the lesson).

## Hello![[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-2)]

Spanish Vocabulary • Print version  
¡Hola! ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Hello!

Inglés Español ([help](//en.wikipedia.org/wiki/Wikipedia:Media_help_\(Ogg\)))

Hello
[Hola](//en.wiktionary.org/wiki/hola) ([listen](//upload.wikimedia.org/wikipedia/commons/4/4e/Hola.ogg))

Good morning!
[¡Buenos días!](//en.wiktionary.org/wiki/buenos_d%C3%ADas) ([listen](//upload.wikimedia.org/wikipedia/commons/1/1f/Buenos_d%C3%ADas.ogg))

Good day!

Good evening!
[¡Buenas tardes!](//en.wiktionary.org/wiki/buenas_tardes) ([listen](//upload.wikimedia.org/wikipedia/commons/f/ff/Buenas_tardes.ogg))

Good night!
[¡Buenas noches!](//en.wiktionary.org/wiki/buenas_noches) ([listen](//upload.wikimedia.org/wikipedia/commons/8/83/Buenas_noches.ogg))

See you later!
[¡Hasta luego!](//en.wiktionary.org/wiki/hasta_luego) ([listen](//upload.wikimedia.org/wikipedia/commons/e/ef/Hasta_luego.ogg))

See you tomorrow!
[¡Hasta mañana!](//en.wiktionary.org/wiki/hasta_ma%C3%B1ana) ([listen](//upload.wikimedia.org/wikipedia/commons/d/d0/Hasta_ma%C3%B1ana.ogg))

Goodbye
[Adiós](//en.wiktionary.org/wiki/adi%C3%B3s) ([listen](//upload.wikimedia.org/wikipedia/commons/c/c1/Adi%C3%B3s.ogg))

Notes

  * _[Hasta](//en.wiktionary.org/wiki/hasta#Spanish)_ means "until"; _[luego](//en.wiktionary.org/wiki/luego#Spanish)_ means "then"; you can translate it as "see you later" or "see you soon". In the same vein, _[hasta mañana](//en.wiktionary.org/wiki/hasta_ma%C3%B1ana)_ means "see you tomorrow".
  * Note the upside-down exclamation (¡) and question marks (¿); you will learn more about them in [lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica#Questions_and_Exclamations).

Examples

  * _¡Buenos días, clase!_

    Good morning, class!
  * _Hola, ¿Cómo estás hoy?_

    Hello, how are you today?
  * _Adiós, ¡hasta luego!_

    Bye, see you soon!

[Go to the exercise](/wiki/Spanish/Exercises/%C2%BFC%C3%B3mo_te_llamas%3F#Hello.21).

## What's your name?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-3)]

To ask someone else's name in Spanish, use _[cómo](//en.wiktionary.org/wiki/c%C3%B3mo)_, then one of the phrases in the table below (_¿Cómo te llamas?_ is "What's your name?" (literally How do you call yourself?).

In Spanish, to say your name, you use the reflexive verb _[llamarse](//en.wiktionary.org/wiki/llamarse)_, which means literally _to call oneself_ (_Me llamo Robert_ is "I call myself Robert) meaning "My name is Robert".

Spanish Verb • Print version  
Llamarse ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) To call oneself

Inglés Español

I am called (I call myself)
Me llamo

You (familiar, singular) are called (You call yourself)
Te llamas

He/She/You (formal, singular) is/are called (He/She/You call yourself)
Se llama

We are called (We call ourselves)
Nos llamamos

You (familiar, plural) are called (You all call yourselves)
Os llamáis

They/You (formal, plural) are called (They/You all call yourselves)
Se llaman

Notes

  * "Os llamáis" is only used in Spain. In Latin America, "Se llaman" is used for both the second and third plural persons.

Examples

  * _Me llamo Chris_

    My name is Chris (I call myself Chris.)
  * _Se llaman Peter y Robert_

    They're called Peter and Robert. (They call themselves Peter and Robert.)
  * _¿Cómo te llamas?_

    What's your name? (What do you call yourself?)
  * _¿Cómo se llama?_

    What's his/her name? (What does he/she call him/herself?)

[Go to the exercise](/wiki/Spanish/Exercises/%C2%BFC%C3%B3mo_te_llamas%3F#What.27s_your_name.3F).

## Simple Vocabulary[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-4)]

Spanish Vocabulary • Print version  
¿Qué tal? ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) How are you?

Inglés Español

It's a pleasure.
Es un placer.

A real pleasure.
Mucho gusto.

The pleasure is mine.
El gusto es mío.

How are you?
¿Qué tal? (_[listen](//upload.wikimedia.org/wikipedia/commons/0/0c/Qu%C3%A9_tal.ogg)_)

¿Cómo estás?

Great!
Fantástico

Fantástica

Great
Genial

Very well
Muy bien

Well
Bien

So-so
Más o menos

Bad
Mal

Really bad
Fatal

And you?
¿Y tú?

Thank you
Gracias (_[listen](//upload.wikimedia.org/wikipedia/commons/1/14/Gracias.ogg)_)

Thank you very much
Muchas gracias

You're Welcome
De nada

Yes
Sí

No
No

Notes

For some of the words above, there are two options. The one ending in "o" is for males, and the one ending in "a" is for females. It's all to do with agreement, which is covered in future chapters.

Also, there are cultural differences in how people respond to "How are you?". In the U.S., we might answer "Mal" if we have a headache, or we're having a bad hair day. In Spanish-speaking cultures, "mal" would be used if a family member were very ill, or somebody lost their job. Similarly, "Fatal" in the U.S. might mean a ruined manicure or a fight with one´s girlfriend, but would be reserved more for things like losing one's home in a Spanish-speaking country.

Examples

  * _**Roberto**: Hola, Rosa. ¿Qué tal?_

    Hello, Rose. How are you?
  * _**Rosa**: Muy bien, gracias. ¿Y tú, Roberto?_

    Very well, thanks. And you, Robert?
  * _**Roberto**: Bien también. ¡Hasta luego!_

    I'm good too. See you later!

[Go to the exercise](/wiki/Spanish/Exercises/%C2%BFC%C3%B3mo_te_llamas%3F#How_are_you.3F).

## The Spanish Alphabet[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-5)]

Here is the traditional Spanish alphabet. The current Spanish alphabet is made up of the letters with numbers above them, and is also sorted in that order. Please read the notes and sections below. (Blue and red letters are a part of the normal English alphabet).

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27

a
b
c
ch
d
e
f
g
h
i
j
k
l
ll
m
n
ñ
o
p
q
r
s
t
u
v
w
x
y
z

Notes about _Ñ_

_N_ and _Ñ_ are considered two different letters. They are alphabetized as separate letters, so _Ñ_ always comes after _N_, regardless of where it appears in the word. Ex: _muñeca_ comes after _municipal_.

Notes about _CH_ and _LL_

_CH_ and _LL_ are no longer distinct letters of the alphabet. In 1994, the Real Academia Española (Spanish Royal Academy) declared that they should be treated as [digraphs](//en.wikipedia.org/wiki/Digraph_\(orthography\)) for collation purposes. Accordingly, words beginning with _CH_ and _LL_ are now alphabetized under _C_ and _L_, respectively. In 2010, the Real Academia Española declared that CH and LL would no longer be treated as letters, bringing the total number of letters of the alphabet down to 27.

Notes about _K_ and _W_

_K_ and _W_ are part of the alphabet but are mostly seen in foreign derived words and names, such as karate and whiskey. For instance, kilo is commonly used to refer to a kilogram.

### Consonants[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-6)]

Although the above will help you understand, proper pronunciation of Spanish consonants is a bit more complicated:

Most of the consonants are pronounced as they are in American English with these exceptions:

  * **b** like the English _b_ at the start of a word and after _m_ or _n_, (IPA: /b/). Elsewhere, especially between vowels, it is softer, often like a blend between English _v_ and _b_. (IPA: /β/)
  * **c** before **i** and **e** like English _th_ in "think" (in Latin America it is like English _s_) (European IPA: /θ/; Latin American IPA: /s/)
  * **c** before **a**, **o**, **u** and other consonants, like English _k_ (IPA: /k/)

    

  * The same sound for **e** and **i** is written like **que** and **qui**, where the **u** is silent (IPA: /ke/ and /ki/).

  * **ch** like _ch_ in “cheese” (IPA: /tʃ/)
  * **d** at the start of a word and after _n_, like English _d_ in "under" (IPA: /d/)
  * **d** between vowels (even if these vowels belong to different words) similar to English _th_ in "mother" (IPA: /ð/); at the end of words like "universidad" you may hear a similar sound, too.
  * **g** before **e** or **i** like the Dutch _g_ (IPA: /x/)
  * **g** before **a**, **o**, **u**, like _g_ in “get” (IPA: /g/)

    

  * The same sound for **e** and **i** is written like **gue** and **gui**, where the **u** is silent (IPA: /ge/ and /gi/). If the word needs the **u** to be pronounced, you write it with a diaeresis e.g. **pingüino**, **lengüeta**.

  * **h** is always silent (except in the digraph _ch_)
  * **j** like the _h_ in hotel, or like the Scottish pronunciation of _ch_ in "loch" (IPA: /h/ or /x/)
  * **ll** is pronounced like _gli_ in Italian "famiglia," or as English y in “yes” (IPA: /ʎ/)
  * **ñ** like nio in “onion” (or gn in French cognac) (IPA: /ɲ/)
  * **q** like the English _k;_ occurs only before _ue_ or _ui_ (IPA: /k/)
  * **r** at the beginning of a word; after _l_, _n_, or _s_; or when doubled (_**rr**_), it is pronounced as a full trill (IPA: /r/), elsewhere it is a single-tap trill (IPA: /ɾ/)
  * **v** is pronounced like _b_, there is no distinction whatsoever between B and V. (IPA: /b/)
  * **x** is pronounced much like an English _x_, except a little more softly, and often more like _gs_. (IPA: /ks/)
  * **z** like the English _th_ (in Latin America, like the English _s_) (European IPA: /θ/; Latin American IPA: /s/)

### Vowels[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-7)]

The pronunciation of vowels is as follows:

  * **a** [a] "_La Mano_" as in "Kahn" (ah)
  * **e** [e] "_Mente_" as in "hen" (eh)
  * **i** [i] "_Sin_" as the _ea_ in "lean" (e)
  * **o** [o] "_Como_" as in "more" (without the following 'r')
  * **u** [u] "_Lunes_" as in "toon" or "loom" (oo)

The "u" is always silent after a g or a q (as in "qué" pronounced keh).

Spanish also uses the ¨ (diaeresis) diacritic mark over the vowel u to indicate that it is pronounced separately in places where it would normally be silent. For example, in words such as _vergüenza_ ("shame") or _pingüino_ ("penguin"), the u is pronounced as in the English "w" and so forms a diphthong with the following vowel: [we] and [wi] respectively. It is also used to preserve sound in stem changes and in commands: _averiguar_ (to research) - _averigüemos_ (let's research).

The **y** [ʝ] "_Reyes_" is similar to the y of "yet", but more voiced (in some parts of Latin America it is pronounced as s in "vision" [ʒ] or sh in "flash" [ʃ]) At the end of a word or when it means "and" ("_y_") it is pronounced like **i**. [Link to audio files](http://www.spanishspanish.com/alfabeto_ipower.html/).

## Acute accents[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-8)]

Spanish uses the ´ (Acute) diacritic mark over vowels to indicate a vocal stress on a word that would normally be stressed on another syllable; Stress is contrastive. For example, the word _ánimo_ is normally stressed on _a_, meaning "mood, spirit." While _animo_ is stressed on _ni_ meaning "I cheer." And _animó_ is stressed on _mó_ meaning "he cheered."

Additionally the acute mark is used to disambiguate certain words which would otherwise be homographs. It's used in various question word or relative pronoun pairs such as _cómo_ (how?)& _como_ (as), _dónde_(where?) & _donde_ (where), and some other words such as _tú_ (you) & _tu_ (your), _él_ (he/him) & _el_ (the).

A E I O U

á
é
í
ó
ú

## How do you spell that?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-9)]

Spanish Vocabulary • Print version  
¿Qué tal? ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) How are you?

Inglés Español

How is it spelled?
¿Cómo se deletrea?

¿Cómo se escribe?

It is spelled
Se escribe

B as in Barcelona
Con B de Barcelona

Examples

  * _**Roberto**: Buenos días. Me llamo Roberto. ¿Cómo te llamas?_

    Good day. My name is Robert. What's your name?
  * _**Benjamín**: Hola. Me llamo Benjamín. ¿Cómo se escribe Roberto?_

    Hello. I'm Benjamin. How do you spell Robert?
  * _**Roberto**: Se escribe R (de Rioja); O (de Orangután); B (de Barcelona); E (de España); R (de Rioja); T (de Tigre); O (de Orangután)._

    It's spelled R (as in Rioja); O (as in Orangutan); B (as in Barcelona); E (as in Spain); R (as in Rioja); T (as in Tiger); O (as in Orangutan).
  * _**Benjamín**: Muchas gracias. ¡Adiós, Roberto!_

    Many thanks. Goodbye, Robert.

[Go to the exercise](/wiki/Spanish/Exercises/%C2%BFC%C3%B3mo_te_llamas%3F#How_do_you_spell_that.3F).

## Summary[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F&action=edit&section=T-10)]

In this lesson, you have learned

  * How to greet people (_Hola; buenos días; adiós_).
  * How to introduce yourself (_Me llamo Rosa_).
  * How to introduce others (_Se llama Roberto_).
  * How to say how you are (_Fenomenal; fatal; bien_).
  * How to spell your name (_Se escribe P-E-T-E-R_).
  * How to ask others about any of the above (_¿Cómo te llamas?; ¿Cómo estás?; ¿Cómo se escribe?_).
  * The Spanish Alphabet and how letters are pronounced.

You should now do the exercise related to each section ([found here](/wiki/Spanish/Exercises/%C2%BFC%C3%B3mo_te_llamas%3F)), and translate the dialogue at the top before moving on to [lesson 2](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F)...

Drill the words covered in this lesson with this [Anki Flash Card Deck](http://ichi2.net/anki/wiki/PreMadeDecks?action=AttachFile&do=view&target=WikiBooks-Spanish_Lessons-C%C3%B3mo_te_llamas.zip) or this [Flashcard Exchange deck](http://www.flashcardexchange.com/flashcards/view/1768374).

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

* * *

# **Lesson two**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=5)]

![Geometría](//upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Alfonso_X_el_Sabio_y_su_corte.jpg/80px-Alfonso_X_el_Sabio_y_su_corte.jpg)

![Quijote-2.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Quijote-2.jpg/70px-Quijote-2.jpg)

Lesson 2 — ¿Cuándo es tu cumpleaños?

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/93/Aneto_01.jpg/200px-Aneto_01.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Pico Aneto, in the Pyrenees.

  


## Dialogue[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-1)]

    _**Raúl**_: ¡Hola, Sofía! Me llamo Raúl. ¿Cuál es la fecha de hoy?
    _**Sofía**_: Hola, Raúl. Hoy es el diecisiete de octubre.
    _**Raúl**_: Muchas gracias. Mi cumpleaños es el viernes.
    _**Sofía**_: ¡Feliz cumpleaños!
    _**Raúl**_: Gracias. ¿Cuántos años tienes?
    _**Sofía**_: Tengo veinte años.
    _**Raúl**_: Vale. Adiós, Sofía.
    _**Sofía**_: ¡Hasta luego!

[Translation](/wiki/Spanish/Exercises/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F#Dialogue) (wait until the end of the lesson).

## The numbers[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-2)]

0.
[Cero](//en.wiktionary.org/wiki/cero#spanish)

1.
[Uno](//en.wiktionary.org/wiki/uno#Spanish)
11.
[Once](//en.wiktionary.org/wiki/once#Spanish)
21.
[Veintiuno](//en.wiktionary.org/wiki/veintiuno#Spanish)
31.
Treinta y uno
50.
[Cincuenta](//en.wiktionary.org/wiki/cincuenta#Spanish)
600.
[Seiscientos](//en.wiktionary.org/wiki/cincuenta#Spanish)

2.
[Dos](//en.wiktionary.org/wiki/dos#Spanish)
12.
[Doce](//en.wiktionary.org/wiki/doce#Spanish)
22.
[Veintidós](//en.wiktionary.org/wiki/veintid%C3%B3s#Spanish)
32.
Treinta y dos
60.
[Sesenta](//en.wiktionary.org/wiki/Sesenta#Spanish)
700.
[Setecientos](//en.wiktionary.org/wiki/cincuenta#Spanish)

3.
[Tres](//en.wiktionary.org/wiki/tres#Spanish)
13.
[Trece](//en.wiktionary.org/wiki/trece#Spanish)
23.
[Veintitrés](//en.wiktionary.org/wiki/veintitr%C3%A9s#Spanish)
33.
Treinta y tres
70.
[Setenta](//en.wiktionary.org/wiki/Setenta#Spanish)
800.
[Ochocientos](//en.wiktionary.org/wiki/cincuenta#Spanish)

4.
[Cuatro](//en.wiktionary.org/wiki/cuatro#Spanish)
14.
[Catorce](//en.wiktionary.org/wiki/catorce#Spanish)
24.
[Veinticuatro](//en.wiktionary.org/wiki/veinticuatro#Spanish)
34.
Treinta y cuatro
80.
[Ochenta](//en.wiktionary.org/wiki/Ochenta#Spanish)
900.
[Novecientos](//en.wiktionary.org/wiki/cincuenta#Spanish)

5.
[Cinco](//en.wiktionary.org/wiki/cinco#Spanish)
15.
[Quince](//en.wiktionary.org/wiki/quince#Spanish)
25.
[Veinticinco](//en.wiktionary.org/wiki/veinticinco#Spanish)
35.
Treinta y cinco
90.
[Noventa](//en.wiktionary.org/wiki/Noventa#Spanish)
1,000.
[Mil](//en.wiktionary.org/wiki/cincuenta#Spanish)

6.
[Seis](//en.wiktionary.org/wiki/seis#Spanish)
16.
[Dieciséis](//en.wiktionary.org/wiki/diecis%C3%A9is#Spanish)
26.
[Veintiséis](//en.wiktionary.org/wiki/veintis%C3%A9is#Spanish)
36.
Treinta y seis
100.
[Cien](//en.wiktionary.org/wiki/Cien#Spanish)
2,000.
[Dos mil](//en.wiktionary.org/wiki/cincuenta#Spanish)

7.
[Siete](//en.wiktionary.org/wiki/siete#Spanish)
17.
[Diecisiete](//en.wiktionary.org/wiki/diecisiete#Spanish)
27.
[Veintisiete](//en.wiktionary.org/wiki/veintisiete#Spanish)
37.
Treinta y siete
200.
[Doscientos](//en.wiktionary.org/wiki/diez#Spanish)
10,000.
[Diez mil](//en.wiktionary.org/wiki/cincuenta#Spanish)

8.
[Ocho](//en.wiktionary.org/wiki/ocho#Spanish)
18.
[Dieciocho](//en.wiktionary.org/wiki/dieciocho#Spanish)
28.
[Veintiocho](//en.wiktionary.org/wiki/veintiocho#Spanish)
38.
Treinta y ocho
300.
[Trescientos](//en.wiktionary.org/wiki/veinte#Spanish)
100,000.
[Cien mil](//en.wiktionary.org/wiki/cincuenta#Spanish)

9.
[Nueve](//en.wiktionary.org/wiki/nueve#Spanish)
19.
[Diecinueve](//en.wiktionary.org/wiki/diecinueve#Spanish)
29.
[Veintinueve](//en.wiktionary.org/wiki/veintinueve#Spanish)
39.
Treinta y nueve
400.
[Cuatrocientos](//en.wiktionary.org/wiki/treinta#Spanish)
101,000.
[Ciento un mil](//en.wiktionary.org/wiki/cincuenta#Spanish)

10.
[Diez](//en.wiktionary.org/wiki/diez#Spanish)
20.
[Veinte](//en.wiktionary.org/wiki/veinte#Spanish)
30.
[Treinta](//en.wiktionary.org/wiki/treinta#Spanish)
40.
[Cuarenta](//en.wiktionary.org/wiki/cuarenta#Spanish)
500.
[Quinientos](//en.wiktionary.org/wiki/cuarenta#Spanish)
1,000,000.
[Un millón](//en.wiktionary.org/wiki/mill%C3%B3n#Spanish)

### Notes[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-3)]

  * To form the numbers from thirty to one hundred, you take the multiple of ten below it, then _[y](//en.wiktionary.org/wiki/y#Spanish)_, then its units value:

"54" _Cincuenta y cuatro_ Like, _fifty and four_

"72" _Setenta y dos_ Like, _seventy and two_

"87" _Ochenta y siete_ Like, _eighty and seven_

  


  * To say _one hundred_ you say just _cien_, never _un cien_. To form the numbers from one hundred to two hundred, you turn _cien_ into _ciento_ before adding the rest of the number:

"101" _Ciento uno_

"128" _Ciento veintiocho_

"150" _Ciento cincuenta_

"199" _Ciento noventa y nueve_

  


  * When used before a masculine noun, _uno_ becomes _un_; before a feminine noun, _una_. To preserve the stress on the last syllable, _veintiuno_ acquires an acute accent when it becomes _veintiún_ before a masculine noun. Note the same mechanism in operation when writing 16 (diez + seis) = _dieciséis_ or 22 (veinte + dos) = _veintidós_.

  


  * Spanish uses the long count style:

1,000,000,000 _mil millones_ / _un millardo_ (less common)

1,000,000,000,000 _un billón_

1,000,000,000,000,000 _mil billones_ / _un billardo_ (rare)

1,000,000,000,000,000,000 _un trillón_

1,000,000,000,000,000,000,000 _mil trillones_ / _un trillardo_ (rare)

1,000,000,000,000,000,000,000,000 _un cuatrillón_

  
The rule of thumb is to count how many "millions" are in the digits:

1 (000 000) (000 000) (000 000) is _un trillón_, because there are three ("tri") multiples of millions.

  


  * Longer numbers:

12,521,008,867,121,403,051 _Doce trillones quinientos veintiún mil ocho billones ochocientos sesenta y siete mil ciento veintiún millones cuatrocientos tres mil cincuenta y uno_

68,076,564,322,676,958,606 _Sesenta y ocho trillones setenta y seis mil quinientos sesenta y cuatro billones trescientos veintidós mil seiscientos setenta y seis millones novecientos cincuenta y ocho mil seiscientos seis_

  
Note that the words _millones_, _billones_, _trillones_ are written in plural, but _mil_ (thousand) is always kept in singular, even when counting several thousands. However, if you need to refer to an amount in several thousands without specifying how many, you can use the plural _miles_ (_He escrito miles de cartas_ = I've written thousands of letters). For this same purpose, you can use the synonym _millares_.

Similarly, there is the plural _cientos_ (_He escrito cientos de cartas_ = I've written hundreds of letters). _Centenas_ and _centenares_ are less common synonyms for _cientos_.

All those synonyms have forms in singular (_Un millar de cartas_ = One thousand letters; _Una centena_ / _Un centenar de cartas_ = One hundred letters). These synonyms are not used for actually counting, though.

There is also _decena_, which means a group of ten.

### Examples[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-4)]

  * _Tengo diecisiete gatos_

    I have 17 cats.
  * _Hay treinta y cinco aulas_

    There are 35 classrooms.
  * _Tengo noventa y seis primos._

    I have 96 cousins.
  * _Hay veintidós estudiantes en esta clase._

    There are 22 students in this class.
  * _¡Quiero un caramelo!_

    I want a candy!
  * _¡Quiero uno!_

    I want one!

To declare the presence or existence of something (e.g. "there is," "there are"), Spanish uses _hay_, which is a special conjugation of the verb _haber_ (to have). Its past form ("there was," "there were") is _hubo._ Another form in the past (meaning roughly "there used to be") is _había_. Its future form ("there will be") is _habrá_. All these forms are invariable in singular and plural: _Había un gato aquí_, _Había dos gatos aquí_. Attempting to construct plural forms of them ("_habían_", "_habrán_") is a very common error and is severely frowned upon.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F#The_numbers).

## How old are you?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-5)]

To ask someone else's age in Spanish, use _Cuántos años_, then one of the entries in the table below (_¿Cuántos años tienes?_ means "How old are you?", or more literally, "How many years do you have?")

To say your age in Spanish, you use the irregular verb _[tener](//en.wiktionary.org/wiki/tener)_ (which means "to have"), then your age, then _[años](//en.wiktionary.org/wiki/a%C3%B1o)_ (which means "years"). For example, _Tengo trece años_ means "I have 13 years" or "I am 13 years old".

Spanish Verb • Print version  
Tener ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) To have

Inglés Español

I have
(Yo) Tengo

You (familiar, singular) have
(Tú) Tienes

He/She/You (formal, singular)/It has
(Él/Ella/Usted) Tiene

We have
(Nosotros) Tenemos

You (familar, plural) have
(Vosotros) Tenéis

They/You (formal, plural) have
(Ellos/Ellas/Ustedes) Tienen

Note

  * "Tenéis" would only be used in Spain. In Latin America, one would use "Tienen" for both the second and third plural persons.

Examples

  * _Tengo veinte años_

    I am 20 years old.
  * _¿Cuántos años tienes?_

    How old are you?
  * _Tiene ochenta y siete años._

    He is 87 years old.
  * _¿Cuántos años tienen?_

    How old are they?

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F#How_old_are_you.3F).

## What's the date today?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-6)]

To ask for the date in Spanish, you use _¿Cuál es la fecha?_ or _¿Qué día es hoy?_ (meaning "What is the date?", or "What day is today?"). In reply, you would say _Hoy es [day of the week], [date of the month] de [month of the year]_ (For example, _Hoy es martes veinticinco de mayo_ is "Today is Tuesday, the 25th of May").

Spanish Vocabulary • Print version  
Los meses del año ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) The months of the year

Inglés Español

January
enero

February
febrero

March
marzo

April
abril

May
mayo

June
junio

July
julio

August
agosto

September
septiembre

October
octubre

November
noviembre

December
diciembre

Spanish Vocabulary • Print version  
Los días de la semana ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) The days of the week

Inglés Español

Monday
lunes

Tuesday
martes

Wednesday
miércoles

Thursday
jueves

Friday
viernes

Saturday
sábado

Sunday
domingo

Notes

  * Neither days of the week nor months of the year are capitalised, unless at the beginning of sentences.
  * On the first of the month, some Spanish speakers say _primero_ [_First_] (_Hoy es domingo primero de enero_).
  * You may still find the spelling _setiembre_ in books from the early 20th century. It emerged from the way some countries pronounce the consonants in it. This spelling is not standard usage and you should avoid using it.

Examples

  * _¿Qué fecha es hoy?_ (_¿A qué estamos?_ is used too.) 

    What is the date?
  * _Hoy es miércoles veintinueve de septiembre._

    Today is Wednesday, the 29th of September
  * _Hoy es jueves quince de agosto._

    Today is Thursday, the 15th of August.
  * _Hoy es sábado dos de enero._

    Today is Saturday, the 2nd of January.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F#What.27s_the_date_today.3F).

## When's your birthday?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-7)]

Although _birthday_ translates as _cumpleaños_, they do not imply the same exact meaning. In English, _birthday_ literally refers to the day of your birth, so it is possible to wish happy birthday to a newborn. In Spanish, _cumpleaños_ literally means "completing a year" and is only used for the day in subsequent years that matches the date on which you were born. Thus, you would never say "feliz cumpleaños" to a newborn, since he still hasn't "completed a year."

Spanish Vocabulary • Print version  
Cumpleaños ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Birthday

Inglés Español

When is your birthday?
¿Cuándo es tu cumpleaños?

My birthday is
Mi cumpleaños es

On the first of May
El primero de mayo

On Wednesday
El miércoles

Happy birthday!
¡Feliz cumpleaños!

Examples

  * _Mi cumpleaños es el once de julio._

    My birthday is on the 11th of July.
  * _Mi cumpleaños es el ocho de diciembre._

    My birthday is on the 8th of December.
  * _¿Cuándo es tu cumpleaños?_

    When is your birthday?
  * _Mi cumpleaños es el sábado._

    My birthday is on Saturday.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F#When.27s_your_birthday.3F).

## Summary[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F&action=edit&section=T-8)]

In this lesson, you have learned:

  * How to count from cero to one septillion (_cero; veintiocho; noventa; cien; un cuatrillón_)
  * The days of the week (_lunes; miércoles; viernes_)
  * The months of the year (_enero; abril; octubre; diciembre_)
  * How to say your age (_Tengo cuarenta años_)
  * How to ask the age of others (_¿Cuántos años tienes?_)
  * How to say today's date (_Hoy es jueves veintinueve de noviembre_)
  * How to say your birthday (_Mi cumpleaños es el primero de agosto_; _mi cumpleaños es el martes_)
  * How to ask the birthday of others (_¿Cuándo es tu cumpleaños?_)

You should now do the exercise related to each section ([found here](/wiki/Spanish/Exercises/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F)), and translate the dialogue at the top before moving on to [lesson 3](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)...

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

  


* * *

# **Lesson three**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=6)]

![Geometría](//upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Alfonso_X_el_Sabio_y_su_corte.jpg/80px-Alfonso_X_el_Sabio_y_su_corte.jpg)

![Quijote-2.jpg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Quijote-2.jpg/70px-Quijote-2.jpg)

Lesson 3 — Introducción a la gramática

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Aconcagua.jpg/200px-Aconcagua.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Aconcagua mountain in the Argentinian Andes.

  


## Articles[[edit](/w/index.php?title=Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica&action=edit&section=T-1)]

As in many languages, Spanish gives each noun a gender: **masculine** or **feminine**, both for singular things and plural ones.

Spanish, like English, has two articles: the definite article ("the") and the indefinite article ("a" or "an"). However, there are 4 forms, depending on the number and gender of the noun. The plural indefinite article is "some" in English.

  * If the noun ends in a vowel, to make it plural, **add s** (_gato_ \- "cat"; _gatos_ \- "cats").
  * If the noun ends in a consonant, to make it plural, **add es** (_papel_ \- "paper"; _papeles_ \- "papers").

Happily, the gender of Spanish nouns is usually pretty easy to work out. Some very simple rules-of-thumb:

  * If it ends in _a_, _d_, _z_ or _ión_: it's likely to be feminine.
  * If it ends in _o_, or a _consonant_: it's likely to be masculine.

### Definite articles[[edit](/w/index.php?title=Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica&action=edit&section=T-2)]

Spanish Grammar • Print version  
The definite article ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) El artículo definido

**masculine**
_singular_
[el](//en.wiktionary.org/wiki/el#Spanish)
el [hombre](//en.wiktionary.org/wiki/hombre#Spanish)
the man

_plural_
[los](//en.wiktionary.org/wiki/los#Spanish)
los [niños](//en.wiktionary.org/wiki/ni%C3%B1os#Spanish)
the boys

**feminine**
_singular_
[la](//en.wiktionary.org/wiki/la#Spanish)
la [mujer](//en.wiktionary.org/wiki/mujer#Spanish)
the woman

_plural_
[las](//en.wiktionary.org/wiki/las#Spanish)
las [niñas](//en.wiktionary.org/wiki/ni%C3%B1as#Spanish)
the girls

### Indefinite articles[[edit](/w/index.php?title=Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica&action=edit&section=T-3)]

Spanish Grammar • Print version  
The indefinite article ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) El artículo indefinido

**masculine**
_singular_
[un](//en.wiktionary.org/wiki/un#Spanish)
un hombre
a man

_plural_
[unos](//en.wiktionary.org/wiki/unos#Spanish)
unos niños
some boys

**feminine**
_singular_
[una](//en.wiktionary.org/wiki/una#Spanish)
una mujer
a woman

_plural_
[unas](//en.wiktionary.org/wiki/unas#Spanish)
unas niñas
some girls

[Go to the exercises](/wiki/Spanish/Exercises/Introducci%C3%B3n_a_la_gram%C3%A1tica#Articles).

## Regular Verbs[[edit](/w/index.php?title=Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica&action=edit&section=T-4)]

We have already seen the present tense conjugations of two Spanish verbs, _[llamarse](//en.wiktionary.org/wiki/llamarse)_ and _[tener](//en.wiktionary.org/wiki/tener#Spanish)_. However, _tener_ (to have) is an irregular verb. Luckily, many verbs follow an easy to understand conjugation scheme.

In Spanish, the conjugation of a regular verb depends on the ending of its infinitive. (The infinitive is the basic form of the verb that you find in the dictionary; for example, English infinitives are always written with _to_, like the verbs _to run_ or _to speak_.) All Spanish infinitives end in the letter _r_, and the three regular conjugation patterns are classified into _-ar_, _-er_, and _-ir_ verbs.

Unlike English, Spanish verbs conjugate depending on the person; that is, they change depending on who is being talked about. This occurs in the English verb **to be** (e.g. I _am_, you _are_, he _is_, etc.) but in Spanish this occurs for all persons in all verbs. As a result, pronouns are usually omitted because they can be inferred from the conjugation.

The pronouns

Person in English Person in Spanish

**Singular**
**Plural**
**Singular**
**Plural**

**First**
I
We
[Yo](//en.wiktionary.org/wiki/yo#Spanish)
[Nosotros](//en.wiktionary.org/wiki/nosotros#Spanish)

**Second**
You
You all
[Tú](//en.wiktionary.org/wiki/t%C3%BA#Spanish)
[Vosotros](//en.wiktionary.org/wiki/vosotros#Spanish)

**Third**
He / She / It
They
[Él](//en.wiktionary.org/wiki/%C3%A9l#Spanish) / [Ella](//en.wiktionary.org/wiki/ella#Spanish)  
[Usted](//en.wiktionary.org/wiki/usted)
[Ellos](//en.wiktionary.org/wiki/ellos#Spanish) / [Ellas](//en.wiktionary.org/wiki/ellas#Spanish)  
[Ustedes](//en.wiktionary.org/wiki/ustedes#Spanish)

  
Spanish distinguishes between the singular **you** (informal _tú_, formal _usted_) and the plural **you** (informal _vosotros_, formal _ustedes_). Both _tú_ and _vosotros_ have their own conjugation patterns; _usted_ follows the same pattern as _él/ella_ and _ustedes_ follows the same pattern as _ellos_.

In Latin America, _vosotros_ is almost unheard of, and _ustedes_ is exclusively used instead.

_Nosotros_ (we) has a feminine _nosotras_ that is used when the entire group is composed of females. Likewise, _vosotros_ and _ellos_ have feminine forms _vosotras_ and _ellas_.

The Present Tense in English

Present Tense (en)

**Singular**
**Plural**

**First**
I play
We play

**Second**
You play
You all play

**Third**
He / She / It plays
They play

The Present Tense in Spanish

Regular -ar Verbs

**Singular**
**Plural**

**First**
-o
-amos

**Second**
-as
-áis

**Third**
-a
-an

Example: Cant-ar (To sing)

**Singular**
**Plural**

**First**
Cant-o
Cant-amos

**Second**
Cant-as
Cant-áis

**Third**
Cant-a
Cant-an

Regular -er Verbs

**Singular**
**Plural**

**First**
-o
-emos

**Second**
-es
-éis

**Third**
-e
-en

Example: Beb-er (To drink)

**Singular**
**Plural**

**First**
Beb-o
Beb-emos

**Second**
Beb-es
Beb-éis

**Third**
Beb-e
Beb-en

Regular -ir Verbs

**Singular**
**Plural**

**First**
-o
-imos

**Second**
-es
-ís

**Third**
-e
-en

Example: Part-ir (To split)

**Singular**
**Plural**

**First**
Part-o
Part-imos

**Second**
Part-es
Part-ís

**Third**
Part-e
Part-en

More examples

  * _[Llorar](//en.wiktionary.org/wiki/llorar#Spanish)_ ("to cry"): lloro, lloras, llora, lloramos, lloráis, lloran
  * _[Cocinar](//en.wiktionary.org/wiki/cocinar#Spanish)_ ("to cook"): cocino, cocinas, cocina, cocinamos, cocináis, cocinan
  * _[Comer](//en.wiktionary.org/wiki/comer#Spanish)_ ("to eat"): como, comes, come, comemos, coméis, comen
  * _[Leer](//en.wiktionary.org/wiki/leer#Spanish)_ ("to read"): leo, lees, lee, leemos, leéis, leen
  * _[Vivir](//en.wiktionary.org/wiki/vivir#Spanish)_ ("to live"): vivo, vives, vive, vivimos, vivís, viven
  * _[Cubrir](//en.wiktionary.org/wiki/cubrir#Spanish)_ ("to cover"): cubro, cubres, cubre, cubrimos, cubrís, cubren

  


Notes

  * There are many more "-ar" verbs than "-er" or "-ir". Make sure you are most familiar with these endings.
  * The second person plural is highlighted because that tense is only used in the variety of Spanish used in Spain. In other Spanish dialects the third person plural form is used instead.
  * When reading texts, you will need to know the person of the verb at a glance. Notice the pattern: 
    1. "O" denotes _I_
    2. "S" denotes _You_
    3. A vowel that is not "O" denotes _He/She/It_
    4. "MOS" denotes _We_
    5. "IS" denotes _You All_
    6. "N" denotes _They_

  
[Go to the exercises](/wiki/Spanish/Exercises/Introducci%C3%B3n_a_la_gram%C3%A1tica#Regular_verbs).

## Questions and Exclamations[[edit](/w/index.php?title=Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica&action=edit&section=T-5)]

In previous lessons, you will have noticed that we use the funny upside-down question mark "[¿](//en.wiktionary.org/wiki/%C2%BF)". In Spanish, questions always start with that, and finish with the regular question mark. It is the same for exclamations; the funny upside-down exclamation mark "[¡](//en.wiktionary.org/wiki/%C2%A1)" precedes exclamations.

This happens because Spanish does not reverse the word order to ask a question. While English says _You are here_ / _Are you here?_, Spanish keeps the same order: _Tú estás aquí_ / _¿Tú estás aquí?_ Whereas the English word order alerts you since the beginning that what you are going to read is a question, Spanish offers no such initial warning. To compensate for this, Spanish adds the initial question mark, so that you'll always be able to tell a declarative statement from a question from the moment you begin reading it.

Questions in Spanish are mainly done by intonation (raising the voice at the end of the question), since questions are often identical to statements. _Te llamas Richard_ means "Your name is Richard", and _¿Te llamas Richard?_ means "Is your name Richard?".

You can also use questions words, as indicated below.

Spanish Vocabulary • Print version  
Questions ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Preguntas

[Español](//en.wiktionary.org/wiki/espa%C3%B1ol) [Inglés](//en.wiktionary.org/wiki/ingl%C3%A9s)

¿[Dónde](//en.wiktionary.org/wiki/d%C3%B3nde#Spanish)?
Where?

¿[Quién](//en.wiktionary.org/wiki/qui%C3%A9n#Spanish)?
Who?

¿[Qué](//en.wiktionary.org/wiki/qu%C3%A9#Spanish)?
What?

¿[Cuál](//en.wiktionary.org/wiki/cu%C3%A1l#Spanish)?
Which?

¿[Cómo](//en.wiktionary.org/wiki/c%C3%B3mo#Spanish)?
How? (as in _How does it work?_)

¿[Cuán](//en.wiktionary.org/wiki/cu%C3%A1n#Spanish)?
How? (as in _How long is it?_)

¿[Por qué](//en.wiktionary.org/wiki/por_qu%C3%A9#Spanish)?
Why?

¿[Cuándo](//en.wiktionary.org/wiki/cu%C3%A1ndo#Spanish)?
When?

¿[Cuánto](//en.wiktionary.org/wiki/cu%C3%A1nto#Spanish)?
How much?

¿[Cuántos](//en.wiktionary.org/wiki/cu%C3%A1nto#Spanish)?
How many?

¿[De quién](//en.wiktionary.org/wiki/qui%C3%A9n#Spanish)?
Whose?

¿A quién?
Whom?

¿De dónde?
Whence?

¿[Adónde](//en.wiktionary.org/wiki/ad%C3%B3nde#Spanish)?
Whither?

¿Para qué?
Wherefore?

Examples

  * _¿Con quién?_

    With whom?
  * _¿Dónde está el banco?_

    Where is the bank?
  * _¿Cuándo es tu cumpleaños?_

    When's your birthday?
  * _¿Qué fecha es hoy?_

    What is the date today?

Notes

  * If you refer to a group of people, you can use the plural _quiénes_.
  * _Cuánto_ and _cuántos_ have feminine forms _cuánta_ and _cuántas_.
  * The archaic _cúyo_ was used in place of _de quién_. You may still find it in books from the early 20th century. Outside of questions, the corresponding pronoun _cuyo_ is still used to mean **whose** in declarative statements. (Feminine _cuya_; plural _cuyos_; feminine plural _cuyas_; this pronoun's number and gender agree with that which is possessed, not the possessor.)
  * _Cuán_ is gradually becoming archaic and being replaced by _qué tan_.

[Go to the exercises](/wiki/Spanish/Exercises/Introducci%C3%B3n_a_la_gram%C3%A1tica#Questions_and_Exclamations).

## Summary[[edit](/w/index.php?title=Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica&action=edit&section=T-6)]

In this lesson, you have learned:

  * The Spanish articles (_[el](//en.wiktionary.org/wiki/el#Spanish); [la](//en.wiktionary.org/wiki/la#Spanish); [los](//en.wiktionary.org/wiki/los#Spanish); [las](//en.wiktionary.org/wiki/las#Spanish); [un](//en.wiktionary.org/wiki/un#Spanish); [una](//en.wiktionary.org/wiki/una#Spanish); [unos](//en.wiktionary.org/wiki/unos#Spanish); [unas](//en.wiktionary.org/wiki/unas#Spanish)_).
  * How to conjugate regular verbs in the present tense (_[lloro](//en.wiktionary.org/wiki/lloro#Spanish); [comes](//en.wiktionary.org/wiki/comes#Spanish); [vive](//en.wiktionary.org/wiki/vive#Spanish); [cocinamos](//en.wiktionary.org/wiki/cocinamos#Spanish); [bebéis](//en.wiktionary.org/wiki/beb%C3%A9is#Spanish); [cubren](//en.wiktionary.org/wiki/cubren#Spanish)_).
  * How to question people and exclaim in Spanish (_¿Cuántos años tienes?_; ¡Qué fantástico!_)_

You should now do the exercise related to each section ([found here](/wiki/Spanish/Exercises/Introducci%C3%B3n_a_la_gram%C3%A1tica)) before moving on. This is a very important topic for future lessons; it's important that you know it well.

You have now completed this chapter! [Return to the Contents](/wiki/Spanish/Contents)...

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

  


* * *

# **Lesson four**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=7)]

**Lesson 4 — ¿Dónde vives?**

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Lago_Gral._Carrera_01.JPG/200px-Lago_Gral._Carrera_01.JPG)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Lago General Carrera in Chile.

## Dialogue[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-1)]

Vocabulary

Londres
London

Pero
But

Pues
Well

    _**Raúl**_: ¡Hola! ¿Dónde vives?
    _**Sofía**_: Hola, Raúl. Vivo en un piso en Londres, Inglaterra. ¿Y tú?
    _**Raúl**_: Vale. Vivo en el sur de España.
    _**Sofía**_: ¿En el campo o en la ciudad?
    _**Raúl**_: En el campo. Las ciudades son ruidosas.
    _**Sofía**_: Sí, pero no hay nada que hacer en el campo.
    _**Raúl**_: Pues, ¡adiós, Sofía!
    _**Sofía**_: ¡Hasta luego!

[Translation](/wiki/Spanish/Answers/%C2%BFD%C3%B3nde_vives%3F#Dialogue) (wait until the end of the lesson).

## Countries of the World[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-2)]

![Flag of the United Kingdom.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/ae/Flag_of_the_United_Kingdom.svg/80px-Flag_of_the_United_Kingdom.svg.png)
![Flag of England.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/be/Flag_of_England.svg/80px-Flag_of_England.svg.png)
![Flag of Scotland.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/10/Flag_of_Scotland.svg/80px-Flag_of_Scotland.svg.png)
![Flag of Wales.svg](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Flag_of_Wales.svg/80px-Flag_of_Wales.svg.png)
![Flag of Ireland.svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/45/Flag_of_Ireland.svg/80px-Flag_of_Ireland.svg.png)

El Reino Unido
Inglaterra
Escocia
Gales
Irlanda

![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/80px-Flag_of_Spain.svg.png)
![Flag of France.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Flag_of_France.svg/80px-Flag_of_France.svg.png)
![Flag of Germany.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Flag_of_Germany.svg/80px-Flag_of_Germany.svg.png)
![Flag of Italy.svg](//upload.wikimedia.org/wikipedia/commons/thumb/0/03/Flag_of_Italy.svg/80px-Flag_of_Italy.svg.png)
![Flag of Russia.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Flag_of_Russia.svg/80px-Flag_of_Russia.svg.png)

España
Francia
Alemania
Italia
Rusia

![Flag of the United States.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Flag_of_the_United_States.svg/80px-Flag_of_the_United_States.svg.png)
![Flag of Canada.svg](//upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Flag_of_Canada.svg/80px-Flag_of_Canada.svg.png)
![Flag of New Zealand.svg](//upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Flag_of_New_Zealand.svg/80px-Flag_of_New_Zealand.svg.png)
![Flag of Australia.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Flag_of_Australia.svg/80px-Flag_of_Australia.svg.png)
![Flag of Mexico.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Flag_of_Mexico.svg/80px-Flag_of_Mexico.svg.png)

Los Estados Unidos
Canadá
Nueva Zelanda
Australia
México

![Flag of Japan.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Flag_of_Japan.svg/80px-Flag_of_Japan.svg.png)
![Flag of the People's Republic of China.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/80px-Flag_of_the_People%27s_Republic_of_China.svg.png)
![Flag of India.svg](//upload.wikimedia.org/wikipedia/commons/thumb/4/41/Flag_of_India.svg/80px-Flag_of_India.svg.png)
![Flag of Brazil.svg](//upload.wikimedia.org/wikipedia/commons/thumb/0/05/Flag_of_Brazil.svg/80px-Flag_of_Brazil.svg.png)
![Flag of Turkey.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Flag_of_Turkey.svg/80px-Flag_of_Turkey.svg.png)

Japón
República Popular China
India
Brasil
Turquía

![Flag of Portugal.svg](//upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Flag_of_Portugal.svg/80px-Flag_of_Portugal.svg.png)
![Flag of Morocco.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Flag_of_Morocco.svg/80px-Flag_of_Morocco.svg.png)
![Flag of Egypt.svg](//upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Flag_of_Egypt.svg/80px-Flag_of_Egypt.svg.png)
![Flag of South Africa.svg](//upload.wikimedia.org/wikipedia/commons/thumb/a/af/Flag_of_South_Africa.svg/80px-Flag_of_South_Africa.svg.png)
![Flag of Argentina.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Flag_of_Argentina.svg/80px-Flag_of_Argentina.svg.png)

Portugal
Marruecos
Egipto
República de Sudáfrica
Argentina

### Where do you live?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-3)]

To say you are from a country, you use _ser_ (meaning "to be [a permanent characteristic]"), then _de_ (meaning "of" or "from"), then the country or place. To say you are currently living in a place or country, you use _vivir_ (meaning "to live"), then _en_ (meaning "in"), then the country or place.

To ask where someone else lives, you use _Dónde_ then _vivir_ (_¿Dónde vives?_ means "Where do you live?"). To ask where someone is from, you use _De dónde_, then _ser_ (_¿De dónde eres?_ means "Where are you from?").

While _vivir_ is totally regular (vivo, vives, vive, vivimos, vivís, viven), _ser_ is about as irregular as they come. It is conjugated below.

Spanish Verb • Print version  
Ser ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) To be

Inglés Español

I am
Soy

You are
Eres

He/She/It is
Es

We are
Somos

You all are
Sois

They are
Son

Examples

  * _Vivo en Inglaterra_

    I live in England.
  * _Son de España, pero viven en Alemania._

    They are from Spain, but they live in Germany.

### The compass[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-4)]

![thump](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/RoseSimple_es.pdf/page1-220px-RoseSimple_es.pdf.jpg)

Examples

  * _Vivo en el suroeste de México._

    I live in the Southwest of Mexico.
  * _Soy del norte de Australia._

    I'm from the north of Australia.

Notes

  * _Noreste_ has a variant _nordeste_. _Sureste_ and _suroeste_ have, respectively, variants _sudeste_ and _sudoeste_.
  * _Oeste_ has a synonym _occidente_ which is used with the same frequency. The corresponding synonym of _este_ is _oriente_. You can also use them in compounds like _nororiente_, _noroccidente_, _suroriente_/_sudoriente_ and _suroccidente_/_sudoccidente_.
  * Their corresponding adjectives are _septentrional_ (**northern**), _meridional_ (**southern**), _oriental_ (**eastern**), _occidental_ (**western**). Compound adjectives like _noroccidental_ and _sudoriental_ are also possible.
  * The adjectives _norteño_ (**northern**) and _sureño_ (**southern**) do not refer to geographical positions but to someone's regional origin.
  * Archaic usage had _septentrión_ to mean **north** and _mediodía_ to mean **south**. Some older books may still use them. Today, _septentrión_ is no longer used, and _mediodía_ means _noon_.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFD%C3%B3nde_vives%3F#Countries_of_the_World).

## Habitations[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-5)]

Spanish Vocabulary • Print version  
Casas ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Houses

Inglés Español

A house
Una casa

A detached house
Una casa individual

A semi-detached house
Una casa pareado

A terraced house
Una casa adosada

A flat
Un piso

A bungalow
Un bungalow

A room
Una habitación

Note

It's _una habitación_, but the plural is _unas habitaciones_ (without the accent)

  * This is a general rule, because in the singular, the the 'ó' shows the sound is to be emphasized, but for plural the 's' has also to be heard, so it is written as it is spoken, as 'o' without the accent).

Examples

  * _Vivo en un piso._

    I live in a flat.
  * _Vivo en una casa adosada en Canadá._

    I live in a semi-detatched house in Canada.
  * _Vive en un bungalow que tiene diez habitaciones._

    He lives in a bungalow that has ten rooms.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFD%C3%B3nde_vives%3F#Habitations).

## Adjectives[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-6)]

As we already learnt, Spanish nouns each have a gender. This doesn't just affect the article, but the adjective; it has to _agree_. Also, adjectives go after the noun, not before it.

If the adjective (in its natural form - the form found in the dictionary), ends in an "O" or an "A", then you remove that vowel and add...

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Male.png/155px-Male.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

**O** or **OS**

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/99/Female.png/125px-Female.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

**A** or **AS**

  * _O_ for masculine singular nouns
  * _OS_ for masculine plural nouns
  * _A_ for feminine singular nouns
  * _AS_ for feminine plural nouns.

Examples

  * _Un hombre bueno_

    A good man
  * _Unos hombres buenos_

    Some good men
  * _Una mujer buena_

    A good woman
  * _Unas mujeres buenas_

    Some good women

The masculine O / feminine A rule is applicable to the vast majority of Spanish nouns. There are a handful of exceptions, though, but you'll get to memorize them.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFD%C3%B3nde_vives%3F#Adjectives).

## City and Countryside[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-7)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Chicago_Downtown_Aerial_View.jpg/200px-Chicago_Downtown_Aerial_View.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

¿La ciudad?

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/A_deciduous_beech_forest_in_Slovenia.jpg/200px-A_deciduous_beech_forest_in_Slovenia.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

¿O el campo?

Spanish Vocabulary • Print version  
¿La ciudad o el campo? ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) The city or the countryside?

Inglés Español

The city
La ciudad

The countryside
El campo

The good thing about ... is that
Lo bueno de ... es que

The bad thing about ... is that
Lo malo de ... es que

There are lots of things to do
Hay mucho que hacer

There isn't anything to do
No hay nada que hacer

You can walk in woodlands
Se puede caminar en los bosques

There isn't any foliage
No queda ningún follaje

Pretty
Bonito/a

Lively
Animado/a

Quiet
Tranquilo/a

Boring
Aburrido/a

Noisy
Ruidoso/a

Examples

  * _La ciudad es ruidosa._

    The city is noisy.
  * _El campo es aburrido._

    The countryside is boring.
  * _Lo bueno de la ciudad es que hay mucho que hacer._

    The good thing about the city is that there are lots of the things to do.
  * _Lo malo de la ciudad es que no quedan plantas._

    The bad thing about the city is that there isn't any foliage.

  
_Lo_ is the only Spanish word classified as neuter gender (although it is always accompanied by masculine adjectives). It is an unusual article that does not carry a noun, and is used to build sentences like _esto es lo que yo quiero_ (this is what I want) and _haz lo correcto_ (do the right thing).

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFD%C3%B3nde_vives%3F#City_and_countryside).

## Summary[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F&action=edit&section=T-8)]

In this lesson, you have learnt

  * Various countries of the world (_Australia; Italia; Francia; los Estados Unidos_).
  * How to say where you and others live and come from (_Vivo en Inglaterra; Somos de Gales_).
  * How to ask where someone lives (_¿Dónde vives?_).
  * The points of the compass (_el sur; el noroeste; el oeste_).
  * How to describe your house (_una casa; un piso_).
  * The basics of adjectives ending in "O" or "A" (_la mujer mala; el niño bonito_).
  * How to talk about the city of the countryside (_la ciudad; el campo; no hay mucho para hacer_).

You should now do the exercise related to each section ([found here](/wiki/Spanish/Exercises/%C2%BFD%C3%B3nde_vives%3F)), and translate the dialogue at the top before moving on to [lesson 5](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F)...

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

  


* * *

# **Lesson five**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=8)]

**Lesson 5 — ¿Qué te gusta hacer?**

  


## Dialogue[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-1)]

Vocabulary

Todo el tiempo
All the time

¡Hasta mañana!
See you tomorrow!

Divertido
Fun

    _**Raúl**_: ¡Hola, Sofía! ¿Te gustan los deportes?
    _**Sofía**_: Buenos días. Me encanta jugar al fútbol. ¿Y tú?
    _**Raúl**_: No, no me gusta. Sin embargo, practico natación todo el tiempo/siempre.
    _**Sofía**_: Ah, no sé nadar. ¿Juegas al ajedrez?
    _**Raúl**_: Sí, me encanta; es un juego muy divertido.
    **_Sofía' ¡Adiós, Raúl!_**
    _**Raúl**_: ¡Hasta mañana!

[Translation](/wiki/Spanish/Answers/%C2%BFQu%C3%A9_te_gusta_hacer%3F#Dialogue) (wait until the end of the lesson).

## Sports and Activities[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-2)]

Spanish Vocabulary • Print version  
Deportes y Actividades ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Sports and Activities

Inglés Español

A sport
Un deporte

A game
Un juego

An activity
Una actividad

To play (a game)
Jugar

To play (an instrument)
Tocar

To practice
Practicar

Soccer
El fútbol

American Football
El fútbol americano

Rugby
El rugby

Tennis
El tenis

Cricket
El críquet

Swimming
La natación

Judo
El judo

Chess
El ajedrez

To sing
Cantar

To read
Leer

To swim
Nadar

To watch TV
Ver la tele

A lot
Mucho

Many
Muchos

Notes

  * In Spanish, if an activity is a game, then you "play" it (_jugar_), otherwise you "practice" it (_practicar_). For example, it's _jugar al tenis_ ("to play tennis") but _practicar la natación_ ("to go swimming").
  * If someone plays an instrument you use the verb _tocar_. For example, _tocar la guitarra_ ("to play the guitar")
  * The verbs are all regular, except: 
    * _Jugar_ (this is discussed in detail below)
    * _Ver_ (v**eo**, ves, ve, vemos, v**eis**, ven)

Examples

  * _Veo mucho la tele._

    I watch TV a lot
  * _Practico natación._

    I go swimming.
  * _¿Practicas judo?_

    Do you do judo?
  * _Practicamos muchas actividades._

    We do many activites
  * _¿Por qué cantáis?_

    Why do you sing?
  * _¿Cuándo lee?_

    When does he or she read?

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_te_gusta_hacer%3F#Sports_and_Activities).

## Stem-changing Verbs[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-3)]

_Jugar_ the first type of irregular verb; known as a **stem-changing verb**. Basically, in the "I", "you", "he/she/it" and "they" forms, the _u_ or _o_ changes to a _ue_. The _jugar_ example is written out below.

Spanish Verb • Print version  
Jugar ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) To play

Inglés Español

I
J**ue**go

You
J**ue**gas

He/She/It
J**ue**ga

We
Jugamos

You all
Jugáis

They
J**ue**gan

Other verbs that follow this pattern

  * _poder_ ("to be able to"): puedo, puedes, puede, podemos, podéis, pueden
  * _dormir_ ("to sleep"): duermo, duermes, duerme, dormimos, dormís, duermen
  * _encontrar_ ("to find"): encuentro, encuentras, encuentra, encontramos, encontráis, encuentran

Notes

  * The verb _jugar_ always has _a_ after it: _jugar a_. In Spanish, _a el_ gets contracted to _al_ and _de el_ gets contracted to _del_. So, it would be _juego al rugby_.
  * _Poder_ (meaning "to be able to") is usually followed by another verb, making "I can do something". The following verb must be in the infinitive. For example, _puede leer_ ("he can read").

Examples

  * _Juego al tenis._

    I play tennis.
  * _¿Jugáis al ajedrez?_

    Do you play chess?
  * _¿Qué deportes juegas?_

    What sports do you play?
  * _¿Cuándo juegan al fútbol?_

    When do they play football?
  * _¿Puedes cantar?_

    Can you sing?
  * _¿Dónde duermes?_

    Where do you sleep?

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_te_gusta_hacer%3F#Stem-changing_Verbs).

## Compound Sentences[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-4)]

So far, everything we've written has been simple sentences — "My name is Santiago" (_Me llamo Santiago_); "The city is noisy" (_La ciudad es ruidosa_); "I play american football" (_Juego al fútbol americano_). Wouldn't it be fantastic if we could join them up? Below are some little words that will make our sentences longer, and more meaningful. You use them just like you do in English.

Also, everything we've written has been positive ("I do this, I do that"). To make it negative, we just add a word in front of the verb: _no_ (meaning "not") or _nunca_ (meaning "never"). For example, _No juego al rugby_ (I don't play rugby"); _Nunca como manzanas_ ("I never eat apples"). It's as simple as that.

Spanish Vocabulary • Print version  
Conjunctions ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Conjunciones

Inglés Español

And
Y

Or
O

Because
Porque

But
Pero

Also
También

So
Así

Note

  * _Porque_ ("because") and _Por qué_ ("why") are similar and easy to mix up; make sure you don't!

Examples

  * _Me llamo Chris y mi cumpleaños es el veinte de agosto._

    My name is Chris and my birthday is on the 20th of August.
  * _Me llamo Raúl, pero él se llama Roberto._

    My name is Raúl, but his name is Robert.
  * _No practica judo._

    He doesn't do judo.
  * _Juego al fútbol americano y practico natación también._

    I play american football and I go swimming too.
  * _No vivo en una ciudad porque las ciudades son ruidosas._

    I don't live in the city because cities are noisy.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_te_gusta_hacer%3F#Compound_sentences).

  


## ¿Qué opinas sobre los deportes?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-5)]

To ask someone about their opinions in Spanish, use _Qué opinas sobre_ ("What is your opinion about") then the thing you want their opinion on (_¿Que opinas sobre los deportes?_ means "What do you think about sports?").

### Gustar[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-6)]

There is no verb for "to like" in Spanish. Instead, you use _gusta_ (meaning "it pleases") and a personal pronoun; you say that "it pleases me" or "I am pleased by it". The personal pronouns are shown below.

Spanish Verb • Print version  
Gustar ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) To please

Inglés Español

Me
Me

You
Te

Him/Her/It
Le

Us
Nos

All of you
Os

Them
Les

Notes

  * Like any other verb, you can put _no_ in front of it, to say "I don't like" (_No me gusta_).
  * If you like an activity rather than a thing, just use the infinitive afterwards: "I like swimming" (_Me gusta nadar_).
  * _Gusta_ means "it pleases", so only works for singular things. If the thing that you like is plural (the women for example), you add "n" (_Me gustan las mujeres_ \- "I like women").

### Love and Hate[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-7)]

Just saying you like or dislike something is a bit dull. Saying you love something is really easy. Instead of _gusta_, use _encanta_ (_Me encanta leer_ means "I love reading"). To say you hate something, use the regular verb _Odiar_ (odio, odias, odia, odiamos, odiáis, odian).

You can also use _nada_ or _mucho_ to add emphasis to _gusta_. For example, _No me gusta nada ver la tele_ ("I don't like watching TV at all"); _Me gusta mucho el ajedrez_ ("I like chess a lot").

Examples

  * _¿Qué opinas sobre el ajedrez?_

    What do you think of chess?
  * _Me gusta el críquet._

    I like cricket.
  * _No le gustan los deportes._

    He doesn't like sports.
  * _Nos gusta jugar al rugby y fútbol._

    We like playing rugby and football.
  * _Les gusta mucho nadar, pero no pueden cantar._

    They like swimming a lot but they can't sing.
  * _¿Te gusta practicar la natación?_

    Do you like going swimming?
  * _¿Por qué os gusta el tenis?_

    Why do (all of) you like tennis?
  * _Odian el ajedrez._

    They hate chess.
  * _Me encantan los deportes, así vivo en la ciudad._

    I love sports, so I live in the city.

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_te_gusta_hacer%3F#.C2.BFQu.C3.A9_opinas_sobre_los_deportes.3F).

## Summary[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F&action=edit&section=T-8)]

In this lesson, you have learned:

  * How to say some sports and activities (_el rugby; la natación; cantar_).
  * How to say you play and do these things (_juego al rugby; practicamos natación_).
  * About a few stem-changing verbs (_encuentro, encuentras, encuentra, encontramos, encontráis, encuentran_)
  * How to make longer and negative sentences (_no; nunca; así; pero_).
  * How to ask for opinions (_¿Qué opinas sobre el fútbol?; ¿Te encanta leer?_)
  * How to express opinions (_Me gusta; Le gustan; Me encanta; Odiamos_)

You should now do the exercise related to each section ([found here](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_te_gusta_hacer%3F)), and translate the dialogue at the top before moving on to [lesson 6](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)...

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

  


* * *

# **Lesson six**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=9)]

**Lesson 6 — ¿Qué comes?**

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Jaen_Cathedral.jpg/200px-Jaen_Cathedral.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Catedral de Jaén in Spain.

## Dialogue[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-1)]

Vocabulary

Necesitar
To need

Zumo de
Juice [of]

    _**Raúl**_: Hola. ¿Qué compras?
    _**Sofía**_: Hola, Raúl. Compro una barra de pan y una botella de leche.
    _**Raúl**_: Vale. Así, ¿tomas leche y pan tostada para tu desayuno?
    _**Sofía**_: Sí. Y tú, ¿qué desayunas?
    _**Raúl**_: Normalmente, tomo zumo de naranja y una manzana.
    _**Sofía**_: Y ¿tienes la comida que necesitas?
    _**Raúl**_: Sí. Adiós.
    _**Sofía**_: ¡Hasta luego!

[Translation](/wiki/Spanish/Answers/%C2%BFQu%C3%A9_comes%3F#Dialogue) (wait until the end of the lesson).

## Food and Drink[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-2)]

![Bread](//upload.wikimedia.org/wikipedia/commons/thumb/3/33/French_bread_DSC00865.JPG/100px-French_bread_DSC00865.JPG)
![Cheese](//upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Cheese.svg/100px-Cheese.svg.png)
![Egg](//upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Freerange_eggs.jpg/100px-Freerange_eggs.jpg)
![Rice](//upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Brown_rice.jpg/100px-Brown_rice.jpg)
![Pasta](//upload.wikimedia.org/wikipedia/commons/thumb/8/89/Pasta_with_pesto.jpg/100px-Pasta_with_pesto.jpg)

Pan (_m_)
Queso (_m_)
Huevo (_m_)
Arroz (_m_)
Pasta (_f_)

![Tomato](//upload.wikimedia.org/wikipedia/commons/thumb/8/89/Tomato_je.jpg/100px-Tomato_je.jpg)
![Lettuce](//upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Kropsla_herfst_.jpg/90px-Kropsla_herfst_.jpg)
![Cucumber](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/CDC_cuke2.jpg/90px-CDC_cuke2.jpg)
![Carrot](//upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Carrots_with_stems.jpg/100px-Carrots_with_stems.jpg)
![Potato](//upload.wikimedia.org/wikipedia/commons/thumb/5/57/Kartoffeln_der_Sorte_Marabel.JPG/100px-Kartoffeln_der_Sorte_Marabel.JPG)

Tomate (_m_)
Lechuga (_f_)
Pepino (_m_)
Zanahoria (_f_)
Patata (_f_)

![Apple](//upload.wikimedia.org/wikipedia/commons/thumb/5/55/GreenApple.png/100px-GreenApple.png)
![Banana](//upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Bananas.svg/100px-Bananas.svg.png)
![Orange](//upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Orange-fruit-2.jpg/90px-Orange-fruit-2.jpg)
![Pear](//upload.wikimedia.org/wikipedia/commons/thumb/2/2d/PearPhoto.jpg/65px-PearPhoto.jpg)
![Grape](//upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Grapes05.jpg/65px-Grapes05.jpg)

Manzana (_f_)
Plátano (_m_)
Naranja (_f_)
Pera (_f_)
Uva (_f_)

![Water](//upload.wikimedia.org/wikipedia/commons/thumb/0/02/Stilles_Mineralwasser.jpg/70px-Stilles_Mineralwasser.jpg)
![Milk](//upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Milk_glass.jpg/65px-Milk_glass.jpg)
![Wine](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Red_Wine_Glas.jpg/60px-Red_Wine_Glas.jpg)
![Coffee](//upload.wikimedia.org/wikipedia/commons/thumb/4/45/A_small_cup_of_coffee.JPG/100px-A_small_cup_of_coffee.JPG)
![Tea](//upload.wikimedia.org/wikipedia/commons/thumb/8/80/Tea_bags.jpg/100px-Tea_bags.jpg)

Agua (_m_)
Leche (_f_)
Vino (_m_)
Café (_m_)
Té (_m_)

Notes

  * _m_ indicates that the noun is masculine (_el queso_ — "the cheese"; _los plátanos_ — "the bananas"), whereas _f_ indicates that it is feminine (_la lechuga_ — "the lettuce"; _las uvas_ — "the grapes")
  * In South America, _papa_ is used instead of _patata_ and _Plátano_ refers to a plantain or cooking banana whereas a normal sweet banana is known as a _banana_ or _banano_.
  * While _agua_ is feminine, it takes the masculine articles _un_ and _el_. For example, _el agua curiosa_ ("the strange water") and _las aguas curiosas_ ("the strange waters"). This is because _agua_ starts with an accented _a_.
  * _Con_ means "with", _sin_ means without (_café con leche_ means "coffee with milk", _café sin leche_ means "coffee without milk").
  * Wine comes in two varieties, "red" and "white". In Spanish, they are called _vino tinto_ and _vino blanco_.

Examples

  * _Me gustan los huevos._

    I like eggs.
  * _No me gusta nada la lechuga._

    I don't like lettuce at all.
  * _Me encanta el té con leche._

    I love tea with milk
  * _Me gustan mucho las zanahorias, pero los pepinos son aburridos._

    I like carrots a lot, but cucumbers are boring.

### What do you eat?[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-3)]

To ask what someone else eats, use _Qué_ followed by a form of one of the verbs below (_¿Qué comes?_ means "What do you eat?"). To ask what someone likes to eat, use _Qué te gusta_ then any of the verbs below (_¿Qué te gusta comer?_ means "What do you like to eat?").

Spanish Verbs • Print version  
Eating and Drinking ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Comer y Beber

Español Inglés

Comer
To eat

Beber
To drink

Tomar
To have (food/drink)

Desayunar
To (eat) breakfast

Almorzar [in Spain, comer]
To (eat) lunch

Cenar
To dine (eat dinner)

Note

All of these verbs are regular except _almorzar_, which is one of the UE Verbs we learnt about in the last chapter; _almuerzo, almuerzas, almuerza, almorzamos, almorzáis, almuerzan_.

Examples

  * _¿Qué te gusta almorzar?_

    What do you like to eat for lunch?
  * _Como naranjas y plátanos, pero no me gustan las peras._

    I eat oranges and bananas, but I don't like pears.
  * _Me gusta comer uvas._

    I like to eat grapes.
  * _¿Bebes leche?_

    Do you drink milk?

### A bottle of wine[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-4)]

Spanish Verbs • Print version  
Eating and Drinking ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Comer y Beber

Español Inglés

Algo de
Some

Un vaso de
A glass of

Una copa de

Una botella de
A bottle of

Una barra de
A loaf of

Un kilo de
A kilo of

Un kilo y mediο de
One and a half kilos of

Un kilo y cuarto de
One and a quarter kilos of

Μedio kilo de
Half a kilo of

Un cuarto de kilo de
A quarter of a kilo of

Notes

  * You will have noticed "some" on the list, but "unos/unas" is some! Yes, it would be _unas manzanas_ ("some apples") but that only works for plurals. "Some bread" has to be translated as _algo de pan_ or just _pan_.
  * Also, there are two ways of saying "a glass of". _Copa_ is for glasses with a stem (mostly wine: _una copa de vino_), and _vaso_ is used for without a stem.
  * Obviously, in all these phrases, the _un_ can be replaced with any number (_Dos vasos de leche_ means "two glasses of milk").

Examples

  * _Tres botellas de vino tinto_

    Three bottles of red wine
  * _Un medio kilo de arroz_

    Half a kilo of rice
  * _Una barra de pan_

    A loaf of bread
  * _Cinco kilos y medio de patatas_

    Five and a half kilos of potatoes

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_comes%3F#Food_and_Drink).

## In the Shop[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-5)]

In Spanish, as in English, there are many ways of expressing what you would like to buy, some of which are listed below. You will also see some other useful words and phrases for when shopping for food.

Spanish Verbs • Print version  
I would like... ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) Me gustaría...

Español Inglés

Quisiera
I would like

Querría

Me gustaría

Ahí está(n)
There you go; voila.

Comprar
To buy

La cuenta
The bill / account

Cobrar
To settle in cash

Costar
To cost

Una tienda
A shop

Notes

  * _Comprar_ is a regular verb (_compro, compras, compra, compramos, compráis, compran_).
  * With _ahí está(n)_, the _n_ is for plural. Without is for singular.
  * _Costar_ is a O => UE verb (_cuesto, cuestas, cuesta, costamos, costáis, cuestan_), but obviously, you only use the third person. 

    Also, if you want to say "How much does it cost," you use _¿Cuánto cuesta(n)?_ (_cuesta_ is for singular things, _cuestan_ for plurals, as seen below).
  * In a bar or café in Spain, one usually pays for everything on leaving _¿La cuenta, por favor?_ is to ask for the bill and it relates to the verb _contar_ \- to count or to tell. Alternatively _cobrar_ (collect) relates to payment (or cash) _¿me cobra?_ = may I pay?

  


Examples

  * _Quisiera una manzana, por favor._

    I would like an apple, please.
  * _Querría comprar una barra de pan._

    I'd like to buy a loaf of bread.
  * _Me gustaría comprar una botella de vino tinto, por favor._

    I'd like to buy a bottle of red wine, please.
  * _¿Cuánto cuestan las uvas?_

    How much do the grapes cost?
  * _¿Cuánto cuesta un kilo de patatas?_

    What does a kilo of potatoes cost?

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_comes%3F#In_the_shop).

## Adjectives[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-6)]

### "E" and Consonant Adjectives[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-7)]

In Spanish, clearly not all adjectives end in "o" or "a". The good thing about these is that they stay the same, irrespective of gender.

  * Adjectives ending in "e" add an "s" when in the plural.
  * Adjectives ending in a consonant add an "es" when in the plural.

Notes

  * When an adjective (or indeed a noun) ends in _z_, it changes to a _c_ in plural, then adds the "es" (_feliz_/_felices_ — "happy").

Examples

  * _El hombre amable_

    The friendly man
  * _La mujer amable_

    The friendly woman
  * _Los niños amables_

    The friendly boys
  * _Las niñas amables_

    The friendly girls

  * _El hombre difícil_

    The difficult man
  * _La mujer difícil_

    The difficult woman
  * _Los niños difíciles_

    The difficult boys
  * _Las niñas difíciles_

    The difficult girls

### Colours[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-8)]

Colours in Spanish are just adjectives, so they still have to agree and go after the noun. They are shown below.

Spanish Vocabulary • Print version  
Los colores ![Flag of Spain.svg](//upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/15px-Flag_of_Spain.svg.png) The colours

Inglés Español

Red
     
Rojo

Orange
     
Naranja / Anaranjado

Yellow
     
Amarillo

Green
     
Verde

Blue
     
Azul

Purple
     
Morado / Violeta

Brown
     
Marrón / Pardo / Café

Pink
     
Rosa / Rosado

White
     
Blanco

Grey
     
Gris

Black
     
Negro

Notes

  * Adjectives can function as nouns if you add an article in front of them. For example, _el morado_ means "the purple one".
  * _Take care with Brown!_
    * The plural form of _marrón_ is _marrones_ (without the accent); _las zanahorias marrones_ means "the brown carrots".
    * Marrones glacés are (in Spanish as in Italian) candied chestnuts.
    * Hair and eyes color brown is usually _Castaño_ (chesnut). Brown skin color is _Moreno_ (tanned).
  * The adjective _negrita_ (Literally:little black/bold face) is a term of familiarity or endearment is in Spanish and not to be confused with an offensive English expression.
  * _Naranja_ is only the noun form of the word; when used as an adjective, _anaranjado_ is used.
  * The color _rosa_ ends in "a" even if applied to a masculine noun; _el balón rosa_, "the pink ball"

Examples

  * _La manzana verde_

    The green apple
  * _Los huevos blancos_

    The white eggs
  * _El queso amarillo_

    The yellow cheese
  * _Las naranjas anaranjadas_

    The orange oranges

[Go to the exercises](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_comes%3F#Adjectives).

## Summary[[edit](/w/index.php?title=Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F&action=edit&section=T-9)]

In this lesson, you have learnt

  * How to say some foods and drinks (_la lechuga; una manzana; la leche_).
  * How to say you eat and drink things (_como, comes, come, comemos, coméis, comen_).
  * How to say some simple quantities (_un kilo de patatas; una copa de vino tinto_)
  * What to say in a shop (_quisiera; querría; la cuenta_).
  * How to form adjectives that don't end in "O" or "A" (_la tienda verde; los quesos azules_)

You should now do the exercise related to each section ([found here](/wiki/Spanish/Exercises/%C2%BFQu%C3%A9_comes%3F)), and translate the dialogue at the top before moving on.

You have now completed this chapter! [Return to the Contents](/wiki/Spanish/Contents)...

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

  


* * *

# **Pronunciation**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=10)]

Pronouncing Spanish based on the written word is much simpler than pronouncing English based on written English. This is because, with few exceptions, each letter in the Spanish alphabet represents a single sound, and even when there are several possible sounds, simple rules tell us which is the correct one. In contrast, many letters and letter combinations in English represent multiple sounds (such as the _ou_ and _gh_ in words like _cough_, _rough_, _through_, _though_, _plough_, etc.).

  


## Letter-sound correspondences in Spanish[[edit](/w/index.php?title=Spanish/Pronunciation&action=edit&section=T-1)]

The table below presents letter-sound correspondences in the order of the traditional Spanish alphabet. (Refer to the article [Writing system of Spanish](//en.wikipedia.org/wiki/Writing_system_of_Spanish) in Wikipedia for details on the Spanish alphabet and alphabetization.)

Letter Name of  
the letter IPA Pronunciation of the letter (English approximation)

A a
a
a
Like _a_ in _father_

B b
be, be larga, be alta
b
Like _b_ in _bad_.

β
**Between vowels**, the lips should not be fully closed when pronouncing the sound (somewhat similar to the _v_ in _value_, but much softer).

C c
ce
θ/s
**Before the vowels _e_ and _i_**, like _th_ in _thin_ (most of Spain) or like _c_ in _center_ (Parts of Andalucía, Canary Islands and Americas).

k
**Everywhere else**; like _c_ in _coffee_

Ch ch
che
tʃ
Like _ch_ in _church_.

D d
de
d
Does not have an exact English equivalent. Sounds similar to the _d_ in _day_, but instead of the tongue touching the roof of the mouth behind the teeth, it should touch the teeth themselves.

ð
Between vowels, the tongue should be lowered so as to not touch the teeth (somewhat similar to the _th_ in _the_).

E e
e
e
Like _e_ in _ten_, and the _ay_ in _say_.

F f
efe
f
Like _f_ in _four_.

G g
ge
g
Like _g_ in _get_.

ɰ
Between vowels (where the second vowel is _a_, _o_ or _u_), the tongue should not touch the soft palate (no similar sound in English, but it's somewhat like Arabic _ghain_).

x
**Before the vowels _e_ and _i_**, like a Spanish _j_ (see below).

H h
hache
**Silent**, unless combined with _c_ (see above). Hu- or hi- followed by another vowel at the start of the word stand for /w/ (English _w_) and /j/ (English _y_). Also used in foreign words like **hámster**, where it is pronounced like a Spanish _j_ (see below).

I i
i
i
Like _e_ in _he_. Before other vowels, it approaches _y_ in _you_.

J j
jota
x
Like the _ch_ in _loch_, although in many dialects it may sound like English _h_.

K k
ka
k
Like the _k_ in _ask_. Only used in words of foreign origin - Spanish prefers _c_ and _qu_ (see above and below, respectively).

L l
ele
l
Does not have an exact English equivalent. It is similar to the English "l" in _line_, but shorter, or "clipped." Instead of the tongue touching the roof of the mouth behind the teeth, it should touch the tip of the teeth themselves.

Ll ll
doble ele, elle
ʎ/ʝ
Pronounced, mostly in Northern Spain, like _gl_ in the Italian word _gli_. Does not have an English equivalent, but it's somewhat similar to _li_ in _million_. In other parts of Spain and in Latin America, _ll_ is commonly pronounced as /ʝ/ (somewhat similar to English _y_, but more vibrating). In Argentina and Uruguay it can be like _sh_ in "flash" or like the _s_ in the English "vision".

M m
eme
m
Like _m_ in _more_.

N n
ene
n
Like _n_ in _no_. Before **p**, **b**, **f** and **v** (and in some regions **m**) sounds as _m_ in _important_. For example **un paso** sounds **umpaso**. Before **g**, **j**, **k** sound (c, k , q), **w** and **hu** sounds like _n_ in _anchor_: un gato, un juego, un cubo, un kilo, un queso, un whisky, un hueso. Before **y** sound (_y_ or _ll_), it sounds like _ñ_, see below.

Ñ ñ
eñe
ɲ
Like _gn_ in the Italian word _lasagna_. As it's always followed by a vowel, the most similar sound in English is /nj/ (_ny_) + _vowel_, as in _canyon_, where the _y_ is very short. For example, when pronouncing "años", think of it as "anyos", or an-yos. To practice, repeat the onomatopoeia of chewing: "ñam, ñam, ñam".

O o
o
o
Like _o_ in _more_, without the following _r_ sound.

P p
pe
p
Like _p_ in _port_.

Q q
cu
k
Like _q_ in _quit_. As in English, it is always followed by a _u_, but before _e_ or _i_, the _u_ is silent (_líquido_ is pronounced /'li.ki.ðo/). The English /kw/ sound is normally written _cu_ in Spanish (_cuanto_), although _qu_ can be used for this sound in front of _a_ or _o_ (_quásar_, _quórum_).

R r
ere, erre
ɾ
This has two pronunciations, neither of which exist in English. The 'soft' pronunciation [ɾ] sounds like American relaxed pronunciation of _tt_ in "butter", and is written _r_ (always written _r_).

r
The 'hard' pronunciation [r] is a multiply vibrating sound, similar to Scottish rolled r (generally written _rr_). 'Hard' _r_ is also the sound of [r] at the start of a word or after _l_, _n_ or _s_.

S s
ese
s
Like _s_ in _six_. In many places it's aspirated in final position, although in Andalusia it is not itself pronounced, but changes the sound of the preceding vowel. (See regional variations). In most parts of Spain, it's pronounced as a sound between [s] and [ʃ].

T t
te
t
Does not have an exact English equivalent. Like to the _t_ in _ten_, but instead of the tongue touching the roof of the mouth behind the teeth, it should touch the teeth themselves.

U u
u
w
**before another vowel** (especially after _c_), like _w_ in _twig_.

**In the combinations _gue_,_gui_ and _qu_, it is silent unless it has a diaresis (_güe_, _güi_), in which case it is as above: _w_ (only in the combinations _güe_ and _güi_ and not in the combination _qü_).**

u
**Everywhere else**, like _oo_ in _pool_, but shorter.

V v
uve, ve, ve corta, ve baja
b, β
Identical to Spanish _b_ (see above). The pronunciation "v" is regarded as an over-cultism[_[citation needed](/wiki/Wikibooks:OR)_].

W w
uve doble, doble ve, doble u
b, β, w
Used only in words of foreign origin (Spanish prefers _u_). Pronunciation varies from word to word: _watt_ is pronounced like _bat_ or _huat_, but _kiwi_ is always pronounced like _quihui_.

X x
equis
ks
Like _ks_ (English _x_) in _extra_. In some cases it may be pronounced like _gs_ or _s_.

ʃ
In words of Amerindian origin, like _sh_ in _she_.

x
Note that _x_ used to represent the sound of _sh_, which then evolved into the sound now written with _j_. A few words have retained the old spelling, but have modern pronunciation /x/. Most notably, _México_ and its derivatives are pronounced like _Méjico_.

Y y
i griega, ye
i
It sounds as a vowel [i]: a. when it is a word itself (_y_ /i/, meaning "and" in English), b. at the end of a word like in _rey_ /rei/ ("king"), c. in the middle of a compound word like in _Solymar_ (_sol y mar_ /so.li'mar/, meaning "sun and sea"), d. at the beginning of a word followed by a consonant in words or names that have retained an old spelling (_Yfrán_ /i'fɾan/).

ʝ
It sounds as a consonant [ʝ] in any other position: _reyes_ /'re.ʝes/, _yeso_ /'ʝe.so/. This standard pronunciation for _y_ as a consonant does not have a perfect English equivalent, but it is somewhat similar to English _y_ (just more vibrating). In Argentina and Uruguay _y_ is pronounced similar to the English _sh_ (/ʃ/) in _she_, or /ʒ/ (like English _s_ in _vision_).

Z z
zeta, ceda
θ, s
Always the same sound as a soft _c_ i.e. either /θ/ (most of Spain) or /s/ (elsewhere). See _c_ for details.

## One letter, one sound[[edit](/w/index.php?title=Spanish/Pronunciation&action=edit&section=T-2)]

Pronouncing Spanish based on the written word is much simpler than pronouncing English based on written English. Each vowel represents only one sound. With some exceptions (such as _w_ and _x_), each consonant also represents one sound. Many consonants sound very similar to their English counterparts.

As the table indicates, the pronunciation of some consonants (such as _b_) does vary with the position of the consonant in the word, whether it is between vowels or not, etc. This is entirely predictable, so it doesn't really represent a breaking of the "one letter, one sound" rule.

The University of Iowa has a very visual and [detailed explanation](http://www.uiowa.edu/%7Eacadtech/phonetics/) of the Spanish pronunciation.

Here is another pages with links to the [audio files of the letters](http://www.spanishspanish.com/alfabeto_ipower.html/).

## Local pronunciation differences[[edit](/w/index.php?title=Spanish/Pronunciation&action=edit&section=T-3)]

## Word stress[[edit](/w/index.php?title=Spanish/Pronunciation&action=edit&section=T-4)]

In Spanish there are two levels of stress when pronouncing a syllable: stressed and unstressed. To illustrate: in the English word "_thinking_", "_think_" is pronounced with stronger stress than "_ing_". If both syllables are pronounced with the same stress, it sounds like "_thin king_".

With one category of exceptions (_-mente_ adverbs), all Spanish words have one stressed syllable. If a word has an accent mark (´; explicit accent), the syllable with the accent mark is stressed and the other syllables are unstressed. If a word has no accent mark (implicit accent), the stressed syllable is predictable by rule (see below). If you don't put the stress on the correct syllable, the other person may have trouble understanding you. For example: _esta_, which has an implicit accent in the letter _e_, means "this (feminine)"; and _está_, which has an explicit accent in the letter _a_, means "is." _Inglés_ means "English," but _ingles_ means "groins."

Adverbs ending in _-mente_ are stressed in two places: on the syllable where the accent falls in the adjectival root and on the _men_ of _-mente_. For example: _estúpido_ → _estúpida**men**te_.

The vowel of an unstressed syllable should be pronounced with its true value, as shown in the table above. Don't reduce unstressed vowels to neutral schwa sounds, as occurs in English.

### Rules for pronouncing the implicit accent[[edit](/w/index.php?title=Spanish/Pronunciation&action=edit&section=T-5)]

There are only the following rules for pronouncing the implicit accent. The stressed syllable is in bold letters:

  * If a word ends with a vowel or with _n_ or _s_ , the next-to-last syllable is stressed.  
**Examples**: 
    * _cara_ (**ca**-ra) (face)
    * _mano_ (**ma**-no) (hand)
    * _amarillo_ (a-ma-**ri**-llo) (yellow)
    * _hablan_ (**ha**-blan) (they speak)
    * _martes_ (**mar**-tes) (Tuesday)
  * If a word ends with a consonant other than _n_ or _s_, the last syllable is stressed.  
**Examples**: 
    * _farol_ (fa-**rol**) (street lamp)
    * _azul_ (a-**sul**) (blue)
    * _español_ (es-pa-**ñol**) (Spanish)
    * _salvador_ (sal-va-**dor**) (savior).
  * A syllable usually contains exactly one vowel. If there are two adjacent vowels, they count as two distinct syllables if both are one of _a_,_e_ and _o_. If, however, at least one of them is _i_ or _u_, they count as only one syllable. If, according to the two rules above, that syllable is stressed, the first of the two vowels is stressed if it is one of _a_,_e_ and _o_, while the second vowel is stressed if the first one is one of _i_ and _u_.  
**Examples**: 
    * _correo_ (co-**rre**-o) (mail)
    * _hacia_ (**ha**-cia) (in the direction of)
    * _fui_ (fu-**i**) (I was) (Note that this word has only one syllable.)

Any exception to these rules is marked by writing an acute accent (_máximo_, _paréntesis_, _útil_, _acción_). In those exceptions, the stressed sylable is the one where the acute accent (called _tilde_ in Spanish) appears.

## The diaeresis ( ¨ )[[edit](/w/index.php?title=Spanish/Pronunciation&action=edit&section=T-6)]

In the clusters _gue_ and _gui_, the _u_ is not pronounced; it serves simply to give the _g_ a hard-_g_ sound, like in the English word _gut_ (_gue_ → [ge]; _gui_ → [gi]).

However, if the _u_ has a the diaeresis mark (¨), it is pronounced like an English _w_ (_güe_ → [gwe]; _güi_ → [gwi]). This mark is rather rare.

Examples:

  * _pedigüeño_ = beggar
  * _agüéis_ (2nd person plural, present subjunctive of the verb _aguar_). Here, the diaeresis preserves the _u_ (or [w]) sound in all the verb tenses of _aguar_.
  * _argüir_ (to deduce)
  * _pingüino_ = penguin

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)

* * *

# **Contributors**[[edit](/w/index.php?title=Spanish/Print_version&action=edit&section=11)]

[The Spanish Wikibook](/wiki/Spanish) was created on August 2, 2003 by [ThomasStrohmann](/wiki/User:ThomasStrohmann); it was the first language book on Wikibooks. During December 2006, it underwent a complete archive and rewrite, by [Celestianpower](/wiki/User:Celestianpower). A list of major contributors — past and present — can be found below.

  * [ThomasStrohmann](/wiki/User:ThomasStrohmann) ([discuss](/wiki/User_talk:ThomasStrohmann) **·** [email](/wiki/Special:EmailUser/ThomasStrohmann) **·** [contribs](/wiki/Special:Contributions/ThomasStrohmann) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=ThomasStrohmann) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=ThomasStrohmann&lang=en&wiki=wikibooks))
  * [Karl Wick](/wiki/User:Karl_Wick) ([discuss](/wiki/User_talk:Karl_Wick) **·** [email](/wiki/Special:EmailUser/Karl_Wick) **·** [contribs](/wiki/Special:Contributions/Karl_Wick) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Karl+Wick) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Karl+Wick&lang=en&wiki=wikibooks))
  * [Wintermute](/wiki/User:Wintermute) ([discuss](/wiki/User_talk:Wintermute) **·** [email](/wiki/Special:EmailUser/Wintermute) **·** [contribs](/wiki/Special:Contributions/Wintermute) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Wintermute) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Wintermute&lang=en&wiki=wikibooks))
  * [Mariela Riva](/wiki/User:Mariela_Riva) ([discuss](/w/index.php?title=User_talk:Mariela_Riva&action=edit&redlink=1) **·** [email](/wiki/Special:EmailUser/Mariela_Riva) **·** [contribs](/wiki/Special:Contributions/Mariela_Riva) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Mariela+Riva) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Mariela+Riva&lang=en&wiki=wikibooks))
  * [Mxn](/wiki/User:Mxn) ([discuss](/wiki/User_talk:Mxn) **·** [email](/wiki/Special:EmailUser/Mxn) **·** [contribs](/wiki/Special:Contributions/Mxn) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Mxn) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Mxn&lang=en&wiki=wikibooks))
  * [Sabbut](/wiki/User:Sabbut) ([discuss](/wiki/User_talk:Sabbut) **·** [email](/wiki/Special:EmailUser/Sabbut) **·** [contribs](/wiki/Special:Contributions/Sabbut) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Sabbut) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Sabbut&lang=en&wiki=wikibooks))
  * [Javier Carro](/wiki/User:Javier_Carro) ([discuss](/wiki/User_talk:Javier_Carro) **·** [email](/wiki/Special:EmailUser/Javier_Carro) **·** [contribs](/wiki/Special:Contributions/Javier_Carro) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Javier+Carro) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Javier+Carro&lang=en&wiki=wikibooks))
  * [Fenoxielo](/wiki/User:Fenoxielo) ([discuss](/w/index.php?title=User_talk:Fenoxielo&action=edit&redlink=1) **·** [email](/wiki/Special:EmailUser/Fenoxielo) **·** [contribs](/wiki/Special:Contributions/Fenoxielo) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Fenoxielo) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Fenoxielo&lang=en&wiki=wikibooks))
  * [Think Fast](/wiki/User:Think_Fast) ([discuss](/wiki/User_talk:Think_Fast) **·** [email](/wiki/Special:EmailUser/Think_Fast) **·** [contribs](/wiki/Special:Contributions/Think_Fast) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Think+Fast) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Think+Fast&lang=en&wiki=wikibooks))
  * [Celestianpower](/wiki/User:Celestianpower) ([discuss](/wiki/User_talk:Celestianpower) **·** [email](/wiki/Special:EmailUser/Celestianpower) **·** [contribs](/wiki/Special:Contributions/Celestianpower) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Celestianpower) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Celestianpower&lang=en&wiki=wikibooks))
  * [John D'Adamo](/wiki/User:John_D%27Adamo) ([discuss](/wiki/User_talk:John_D%27Adamo) **·** [email](/wiki/Special:EmailUser/John_D%27Adamo) **·** [contribs](/wiki/Special:Contributions/John_D%27Adamo) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=John+D%27Adamo) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=John+D%27Adamo&lang=en&wiki=wikibooks))
  * [AnthonyBaldwin](/wiki/User:AnthonyBaldwin) ([discuss](/wiki/User_talk:AnthonyBaldwin) **·** [email](/wiki/Special:EmailUser/AnthonyBaldwin) **·** [contribs](/wiki/Special:Contributions/AnthonyBaldwin) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=AnthonyBaldwin) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=AnthonyBaldwin&lang=en&wiki=wikibooks))
  * [Flickts](/wiki/User:Flickts) ([discuss](/wiki/User_talk:Flickts) **·** [email](/wiki/Special:EmailUser/Flickts) **·** [contribs](/wiki/Special:Contributions/Flickts) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Flickts) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Flickts&lang=en&wiki=wikibooks))
  * [Neoptolemus](/wiki/User:Neoptolemus) ([discuss](/wiki/User_talk:Neoptolemus) **·** [email](/wiki/Special:EmailUser/Neoptolemus) **·** [contribs](/wiki/Special:Contributions/Neoptolemus) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Neoptolemus) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Neoptolemus&lang=en&wiki=wikibooks))
  * [Akhram](/wiki/User:Akhram) ([discuss](/wiki/User_talk:Akhram) **·** [email](/wiki/Special:EmailUser/Akhram) **·** [contribs](/wiki/Special:Contributions/Akhram) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Akhram) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Akhram&lang=en&wiki=wikibooks))

![Spain](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Escudo_de_Espa%C3%B1a_%28mazonado%29.svg/100px-Escudo_de_Espa%C3%B1a_%28mazonado%29.svg.png)

[¡Aprovéchalo!](/wiki/Spanish)  
_Learn the Spanish language_  
[Contents](/wiki/Spanish/Contents) • [Introduction](/wiki/Spanish/Introduction)  
[Lesson one](/wiki/Spanish/Lessons/%C2%BFC%C3%B3mo_te_llamas%3F) • [Lesson two](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1ndo_es_tu_cumplea%C3%B1os%3F) • [Lesson three](/wiki/Spanish/Lessons/Introducci%C3%B3n_a_la_gram%C3%A1tica)  
[Lesson four](/wiki/Spanish/Lessons/%C2%BFD%C3%B3nde_vives%3F) • [Lesson five](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_te_gusta_hacer%3F) • [Lesson six](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_comes%3F)  
[Lesson seven](/wiki/Spanish/Lessons/%C2%BFQu%C3%A9_hora_es%3F) • [Lesson eight](/wiki/Spanish/Lessons/%C2%BFAd%C3%B3nde_vas_a_ir%3F) • [Lesson nine](/wiki/Spanish/Lessons/%C2%BFCu%C3%A1l_es_tu_trabajo%3F)  
[Pronunciation](/wiki/Spanish/Pronunciation) • [Contributors](/wiki/Spanish/Contributors)

![Mexico](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Coat_of_arms_of_Mexico.svg/75px-Coat_of_arms_of_Mexico.svg.png)
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Spanish/Print_version&oldid=922565](http://en.wikibooks.org/w/index.php?title=Spanish/Print_version&oldid=922565)" 

[Categories](/wiki/Special:Categories): 

  * [Spanish Printable Versions](/w/index.php?title=Category:Spanish_Printable_Versions&action=edit&redlink=1)
  * [Spanish](/wiki/Category:Spanish)

Hidden category: 

  * [Pages needing sources](/wiki/Category:Pages_needing_sources)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Spanish%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Spanish%2FPrint+version)

### Namespaces

  * [Book](/wiki/Spanish/Print_version)
  * [Discussion](/wiki/Talk:Spanish/Print_version)

### 

### Variants

### Views

  * [Read](/wiki/Spanish/Print_version)
  * [Edit](/w/index.php?title=Spanish/Print_version&action=edit)
  * [View history](/w/index.php?title=Spanish/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Spanish/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Spanish/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Spanish/Print_version&oldid=922565)
  * [Page information](/w/index.php?title=Spanish/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Spanish%2FPrint_version&id=922565)

### In other languages

  * [Français](//fr.wikibooks.org/wiki/Enseignement_de_l%27espagnol/Le%C3%A7on_1)
  * [Türkçe](//tr.wikibooks.org/wiki/%C4%B0spanyolca/S%C3%B6yleyi%C5%9F)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Spanish%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Spanish%2FPrint+version&oldid=922565&writer=rl)
  * [Printable version](/w/index.php?title=Spanish/Print_version&printable=yes)

  * This page was last modified on 13 July 2007, at 16:35.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Spanish/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
