# Using Firefox/Print

From Wikibooks, open books for an open world

< [Using Firefox](/wiki/Using_Firefox)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Using_Firefox/Print&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Using_Firefox/Print) on _17 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Using_Firefox/Print&oldid=2502696&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Using Firefox](/wiki/Using_Firefox)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Using_Firefox/Print&action=purge&printable=yes) this page.

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Firefox_LiNsta.png/220px-Firefox_LiNsta.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Mozilla Firefox

**Using Firefox** is a book designed to help you get the most out of the open source web browser [Mozilla Firefox](//en.wikipedia.org/wiki/en:Mozilla_Firefox). If you don't have Mozilla Firefox yet, you can download it from <http://www.getfirefox.com>.

## Table of Contents[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=1)]

  1. [Introduction](/wiki/Using_Firefox/Introduction)
  2. [Installation](/wiki/Using_Firefox/Installation)
  3. [Browsing with Tabs](/wiki/Using_Firefox/Browsing_with_Tabs)
  4. [Searching and finding within documents](/wiki/Using_Firefox/Search)
  5. [User preferences](/wiki/Using_Firefox/Preferences)
  6. [Extensions](/wiki/Using_Firefox/Extensions)
  7. [Plug-ins](/wiki/Using_Firefox/Plug-ins)
  8. [Mouse shortcuts](/wiki/Using_Firefox/Mouse_shortcuts)
  9. [Keyboard shortcuts](/wiki/Using_Firefox/Keyboard_shortcuts)
  10. [Privacy](/wiki/Using_Firefox/Privacy)
  11. [Advanced configuration](/wiki/Using_Firefox/Advanced)
  12. [Developers tools](/wiki/Using_Firefox/Developers)
  13. [Creating an extension](/wiki/Using_Firefox/Creating_an_extension)
  14. [External Links](/wiki/Using_Firefox/Links)

# Introduction[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=2)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## About Firefox[[edit](/w/index.php?title=Using_Firefox/Introduction&action=edit&section=T-1)]

**Mozilla Firefox** (originally known as "Phoenix" and briefly as "Mozilla Firebird") is a free, cross-platform, graphical web browser developed by the Mozilla Foundation and hundreds of volunteers. Its current release is Firefox 15.0, released in August 28, 2012.

Firefox strives to be a lightweight, fast, intuitive, and highly extensible standalone browser. Firefox has now become the foundation's main development focus. Firefox includes an integrated pop-up blocker, tabbed browsing, live bookmarks, built in Phishing protection, support for open standards, an extension mechanism for adding functionality and localization for Firefox in different languages. Firefox also attempts to produce secure software and fix security holes promptly. Although other browsers have introduced these features, Firefox is the first such browser to achieve wide adoption.

Firefox has attracted attention as an alternative to other browsers such as Microsoft Internet Explorer. As of January 2011, estimates suggest that Firefox's usage share is around 30% of overall browser usage worldwide and is the dominant browser in Europe by some metrics. Since its release, Firefox has significantly reduced Internet Explorer's dominant usage share.

## History of Firefox[[edit](/w/index.php?title=Using_Firefox/Introduction&action=edit&section=T-2)]

Before its 1.0 release on November 9, 2004, Firefox had already gained acclaim from numerous media outlets, including Forbes and the Wall Street Journal. With over 25 million downloads in the 99 days after its release, Firefox became one of the most downloaded free and open source applications, especially among home users. On October 19, 2005, Firefox had its 100 millionth download, just 344 days after the release of version 1.0. By January 31, 2009 Firefox had been downloaded 1 billion times.

Firefox has become the foundation's main development focus (along with its Thunderbird email client), and has replaced the Mozilla Suite as their official main software release.

Blake Ross began working on the Firefox project as an experimental branch of the Mozilla project. They believed that the commercial requirements of Netscape's sponsorship and developer-driven feature creep compromised the utility of the Mozilla browser. To combat what they saw as the Mozilla Suite's software bloat, they created a pared-down browser (then known as Phoenix, today known as Firefox), with which they intended to replace the Mozilla Suite. Ben Goodger currently works as the lead developer of Firefox.

Mozilla Firefox retains the cross-platform nature of the original Mozilla browser by using the XUL user interface markup language. Through Firefox's support of XUL, users may extend their browser's capabilities by applying themes and extensions. Initially, these add-ons raised security concerns, so with the release of Firefox 0.9, the Mozilla Foundation opened Mozilla Update, a website containing themes and extensions "approved" as not harmful.

### Standards[[edit](/w/index.php?title=Using_Firefox/Introduction&action=edit&section=T-3)]

Support for software standards

The Mozilla Foundation takes pride in Firefox's compliance with existing standards, especially W3C web standards. Firefox has extensive support for most basic standards including HTML, XML, XHTML, CSS, ECMAScript (JavaScript), DOM, MathML, SVG, DTD, XSL and XPath.

Firefox also supports [PNG](//en.wikipedia.org/wiki/PNG) images and variable transparency.

Mozilla contributors constantly improve Firefox's support for existing standards. Firefox has already implemented most of CSS Level 2 and some of the not-yet-completed CSS Level 3 standard. Also, work continues on implementing standards currently missing, including APNG and XForms. Some of the Mozilla standards like XBL is also making its way to open standards (via WHATWG).

# Installation[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=3)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Getting Firefox[[edit](/w/index.php?title=Using_Firefox/Installation&action=edit&section=T-1)]

Firefox can be downloaded from [this page](http://www.mozilla.com/firefox/). Pressing the large green button will download Firefox. To get a version of Firefox in another language, see [this page](http://www.mozilla.org/products/firefox/all).

## Installing[[edit](/w/index.php?title=Using_Firefox/Installation&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikibooks/en/thumb/b/b1/Windows_Firefox_Installer.png/200px-Windows_Firefox_Installer.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Firefox Windows Installer

### Microsoft Windows[[edit](/w/index.php?title=Using_Firefox/Installation&action=edit&section=T-3)]

Firefox supports various versions of Windows including 98, 98SE, Me, NT 4.0, 2000, XP,Server 2003, Vista and Windows 7 although it is possible to run Firefox in Windows 95 [[1]](http://johnhaller.com/jh/mozilla/windows_95/). Builds for Windows XP Professional x64 Edition also exist [[2]](http://www.mozilla-x86-64.com/). The Microsoft Windows version of Firefox is distributed as an executable installer. However, starting in Firefox 3.0, there's only support for Windows 2000, Windows XP, Windows Vista and Windows 7.

To install, double click on Firefox Setup <version>.exe (where <version> is a number) and follow the installation instructions. Choosing the standard installation is recommended for most new users. This will install Firefox under Program Files.

  
You can run Firefox from the Program Files entry or by double-clicking the Firefox icon on your desktop. The first run of Firefox will give you the option of importing your settings from Internet Explorer (or any other browser installed on you computer). Choosing 'Yes' will import all your bookmarks (also known as favorites), saved passwords, history and browsing options. After it finishes importing all these settings, the Firefox browser will start up and a dialog box will pop-up alerting you that Firefox is not set as the default browser. Selecting 'Yes' will associate Firefox with web related files on your PC and Firefox will also open when links are selected from (most) external applications, such as from an instant messenger.

After setting Firefox as the default browser, it should automatically appear on the Windows XP new-style Start menu under the "Internet" option. However, if it doesn't, it can be manually set. Right click on the Start button and select "Properties". From there, select "Customize...", and select "Mozilla Firefox" next to the "Internet" checkbox.

![](//upload.wikimedia.org/wikibooks/en/thumb/9/9e/MacOSX_Firefox_Install_Window.png/200px-MacOSX_Firefox_Install_Window.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Firefox MacOSX Disc Image

### Mac OS X[[edit](/w/index.php?title=Using_Firefox/Installation&action=edit&section=T-4)]

Double click on the compressed Disk Image to mount it. Drag the Firefox application icon to the "Applications" folder on your hard drive. Do not double-click the Firefox icon inside the Disk Image; doing so can cause a program hang. To make Firefox always appear in the dock, drag the icon from the "Applications" folder to the dock.

### Linux[[edit](/w/index.php?title=Using_Firefox/Installation&action=edit&section=T-5)]

Many distributions now come with Firefox included. Check your distribution's documentation for details. There should be a Firefox icon in your desktop environment's program menu.

If your distribution does not come with Firefox pre-installed, you may download it from the official Firefox website. Once the download is complete, decompress the file, which can be done usually by opening the file in a file archiver (such as ark or file roller) and extract it to another folder. Alternatively, typing `tar -xvzf firefox-<version>.tar.gz` or `tar -xvzf firefox*` at a command line will generate directory named "firefox." This directory can be moved anywhere. Typing `./firefox` in the shell from the install directory should run Firefox.

### Other Operating Systems[[edit](/w/index.php?title=Using_Firefox/Installation&action=edit&section=T-6)]

Since the Mozilla Foundation makes the Firefox source code available, users can also compile and run Firefox on a variety of other architectures and operating systems. Operating systems not supported by Firefox, but known to run the browser include:

  * Solaris (x86 and SPARC)
  * OS/2
  * AIX
  * FreeBSD
  * PC-BSD
  * NetBSD
  * BeOS
  * SkyOS
  * RISC OS (ARM)
  * OpenBSD

# Browsing with Tabs[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=4)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## What are tabs?[[edit](/w/index.php?title=Using_Firefox/Browsing_with_Tabs&action=edit&section=T-1)]

Firefox has been designed to be useable by any user immediately--with no learning curve. However, to truly "rediscover the web", you should become comfortable with Firefox's advanced features. One of these is the use of tabs. Firefox uses "tabs" to show multiple web pages in the same window. Several other web browsers, such as Internet Explorer 7 and Opera, also use tabs.

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/FirefoxTabs.png/400px-FirefoxTabs.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The default look of Firefox, with tabs visible

Tabs are featured underneath the Location and Bookmarks Toolbars, in a file folder-like layout. Tabs allow users to have one Firefox window in the taskbar, with multiple web pages open within that window. In the image, the default Firefox homepage is shown in the first tab, and [Firefox Central](http://www.mozilla.org/products/firefox/central.html) (accessed from the "Getting Started" bookmark) is shown in the second. The number of tabs that can be opened at any one time is unlimited, though the tab bar can only hold around 20 tabs comfortably. Also, Firefox does not display the tab bar unless more than one tab is open (there is an option to change this).

## Create, close, and select tabs[[edit](/w/index.php?title=Using_Firefox/Browsing_with_Tabs&action=edit&section=T-2)]

There are many different ways to both create, close, and access tabs. First, a new blank tab can be created by clicking on _File_ → _New Tab_, or by using the keyboard shortcut [Ctrl]+[T]. If the tab bar is visible, an empty space (i.e., one not occupied by a tab) can be right clicked, and "New Tab" will create a new tab. Similarly, double clicking an empty space on the tab bar will create a new blank tab. Another way to create a tab, arguably the most common, is by clicking the middle mouse button (sometimes referred to as the third mouse button, or scroll wheel) on any link or bookmark (for instance, "Getting Started" in the above image). Finally, holding down the [Ctrl] key and left clicking a link will open that website in a new tab.

There are also a variety of different ways to close tabs. First, _File_ → _Close_ or [Ctrl]+[W] will close the currently selected tab. Also, the red "x" on the right edge of the tab bar will close the current tab. Finally, middle clicking on any tab (it doesn't have to be selected), or right clicking and selecting "Close Tab" will close whichever tab was selected.

Finally, there are a few different ways to select tabs. The most obvious is to simply left click on a tab. However, a keyboard shortcut also exists: [Ctrl]+[Number] where "Number" is any number 1-9. The corresponding tab will then be selected. Of course, this only works for the first 9 tabs opened. Another common keyboard shortcut is [Ctrl]+[Tab]. This will make the next tab active. Using [Ctrl][Shift]+[Tab] will select the previous tab. These shortcuts are an easy way to cycle through the currently open web pages.

A new feature in Firefox 1.5 is the ability to "Drag and Drop" tabs. By clicking and holding down the left mouse button on a tab, it is possible to change the order of tabs or put them on a different Firefox window. Once the desired location is found (as signaled by an arrow), the left button can be released, and the tab will be moved.

In addition to basic functionality, there are many other ways to use tabs.

## Customization[[edit](/w/index.php?title=Using_Firefox/Browsing_with_Tabs&action=edit&section=T-3)]

For Tab preferences, see the chapter on [Preferences](/wiki/Using_Firefox/Preferences#Tabs).

## Multiple home pages[[edit](/w/index.php?title=Using_Firefox/Browsing_with_Tabs&action=edit&section=T-4)]

Tabbed browsing also enables another feature: multiple home pages. With multiple home pages, it is possible to have several pages open each time the browser is opened or the "Home" button is selected.

To set multiple home pages, go to the "Preferences" window, accessible from _Tools_ → _Options_ on Windows, _Edit_ → _Preferences_ on Linux, or _Firefox_ → _Preferences_ on OS X. Once in the Preferences window, select the _General_ panel, and type each URL, separated by a pipe character (which is _|_), in the _Home Page_ box. For example:

http://addons.mozilla.org/|http://www.google.com|http://wikibooks.org/wiki/Special:Randompage

An easier way to set multiple homepages is to open all of the desired sites in tabs (making sure **only** the desired sites are opened) and then click the _Use Current Pages_ button from the _General_ tab of the _Preferences_ window.

## Bookmark Groups[[edit](/w/index.php?title=Using_Firefox/Browsing_with_Tabs&action=edit&section=T-5)]

Bookmarks Groups are very similar to Multiple Home pages. Bookmark Groups create a folder with multiple related (or unrelated, even) bookmarks. It is then possible to open all of them at once by clicking on the created folder and clicking _Open in Tabs_. Alternately, you can simply open just one of the bookmarked web sites. To create a Bookmark Group, simply open each desired site in its own tab (again, be sure to **only** open the sites you'd like in the group). From there, a few ways exist to create a group:

  * Right click on a tab and select _Bookmark All Tabs..._
  * Click on _Bookmarks_ → _Bookmark All Tabs..._
  * Hit [Ctrl]+[Shift]+[D]

No matter which way you create the group, the same window will appear, asking you for a name and where to create the group.

## Middle click to close tabs on Linux[[edit](/w/index.php?title=Using_Firefox/Browsing_with_Tabs&action=edit&section=T-6)]

When using Firefox on Linux, the default behavior when middle clicking is to try to load whatever is currently in the clipboard as if it were a URL. If you prefer to use the middle click to close tabs, type _about:config_ in the location bar and hit enter.

In the new window that appears, type _middlemouse.contentLoadURL_ in the box labeled _Filter:_. Then, right click on the preference, and select _Toggle_, which should set the preference to **false**.

(_Another contributor writes:_ Unfortunately, in some versions--- such as the one I'm using now---this simply causes Firefox to do _nothing_ when you middle-click a tab. 'Twould be nice to figure out how to really fix this!)

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# Searching and finding within documents[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=5)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Quick searches and keywords[[edit](/w/index.php?title=Using_Firefox/Search&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Adding_a_Keyword_Search_in_Firefox.png/300px-Adding_a_Keyword_Search_in_Firefox.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Select "Add a Keyword for this Search".

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/49/Defining_a_Quicksearch_Keyword_in_Firefox.png/300px-Defining_a_Quicksearch_Keyword_in_Firefox.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

A Name and the Keyword _w_ were just entered for this Quick Search.

Quick Searches allow you to define custom search keywords for entering in the Location Bar. After setup, just type your search keyword before your search terms. A wiki of popular quick searches is maintained [here](http://www.wormus.com/leakytap/Internet/CustomKeywords). The steps needed to make a new Quick Search are outlined below:

  1. Go to a web page that contains a search box.
  2. Right click in the search entry box.
  3. Select "Add a Keyword for this Search".
  4. Give your quick search a keyword. For example, a Wikipedia search could be _w_. Obviously, shorter keywords are more efficient than longer ones, such as _wikipedia_.

An alternative method for older versions of Firefox or locations without search boxes is to:

  1. Go to a webpage that contains a search box.
  2. Search for something. In this case, _oddball_ will be the search word.
  3. Note the term in the URL, and replace it with _%s_. For example, searching on the Google search engine gives us the URL:

    

    `http://www.google.com/search?hl=en&q=**oddball**&btnG=Google+Search`
    Using our example, the new address would be: 

    `http://www.google.com/search?hl=en&q=**%s**&btnG=Google+Search`

  1. Copy the modified URL from the location bar.
  2. Go to _Bookmarks_ → _Manage Bookmarks_ → _New Bookmark_.
  3. Paste your modified URL in the _Location_ box.
  4. Give your quick search a name, e.g. Google Quick Search.
  5. Give your quick search a keyword. **Note:** This can be one character or more. For example, a Google search could be _g_.

To use your new quick search all you need to do is type `_keyword_ _your search term_` in the address bar; for example, to search for the information regarding the history of Wikipedia in Google, you would type, `g history of wikipedia`. You can also bookmark advanced searches using the same technique. Just try a search and replace your search term with _%s_. Simple!

This functionality doesn't have to be limited to web searches; it can be used to quickly go to pages that have a certain structure. For example, one way to get more out of [Wikipedia](//en.wikipedia.org/wiki/Main_Page) would be to create a bookmark to `http://en.wikipedia.org/wiki/%s` with keyword _w_. Getting to Wikipedia articles now only requires typing in `w _article title_`.

Another example is currency conversions. To easily convert from US dollars to Euro, one could create a bookmark to `http://www.xe.com/ucc/convert.cgi?From=USD&To=EUR&Amount=%s` and give it the keyword _$_. To convert a given amount (say $50), all one has to do now is enter `$ 50` into the address bar (note the space, it's very important).

Once you start thinking about them, keywords can become quite useful.

You can also use the [SmartSearch](http://update.mozilla.org/extensions/moreinfo.php?id=188) extension to do all your quick searches from the context menu, by highlighting a word on a page, right-clicking it and search using any of your quick searches.

## Find Toolbar[[edit](/w/index.php?title=Using_Firefox/Search&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Firefox_FAYT.png/300px-Firefox_FAYT.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Screenshot of performing "Find as you type". "ency" was being typed and the first matched text was highlighted in green.

A new and innovative feature is the Find Toolbar. The Find Toolbar is used for searching for text within a page without being too obtrusive. When activated by pressing Ctrl+F, the Find Toolbar appears on the bottom of the Firefox browser ready to search the current web page. The Find Toolbar using incremental searching which means that it will look up your search term simultaneously as you type it. This is more robust than traditional find as finding is done immediately when typing starts. The Find Toolbar has the ability to find the next or previous result and select it, highlight all the matched results and match case. Firefox will search down until reaching the end of the document and "wraparound" to the beginning of the page. If there are no results matching your terms, Firefox will 'beep' to inform you of this. (If you want to disable this 'beep' go to `about:config` and change the value `accessibility.typeaheadfind.enablesound` to `false`.) When you are done searching, simply press the Esc key and the Find Toolbar will hide.

### Find As You Type[[edit](/w/index.php?title=Using_Firefox/Search&action=edit&section=T-3)]

A very useful feature is Find As You Type, which lets you use the functionality of the Find Toolbar without having to open or close it with Ctrl+F or Cmd+F.

By default, Find As You Type will only begin after pressing the _/_ key. Alternatively, to only search links, press the _'_ key (apostrophe). However, it is possible to have Find As You Type work without needing an additional key press. To do so, go to _Tools_ → _Options_ → _Advanced_ → _General_ and check "Begin finding when you begin typing".

From now on, when searching about some topic on a website, just start typing into the body of the page. You will instantly go to the first instance of the sequence of letters as you type. The Find Toolbar will temporarily appear at the bottom of the page, allowing you to highlight all the places the term occurs, or jump to the next one. More Find Toolbar shortcuts can be found in the [Keyboard shortcuts](/wiki/Using_Firefox/Keyboard_shortcuts) section, and a complete description [here](http://www.mozilla.org/access/type-ahead/).

A useful tip to navigate around a web page is to use find as you type. You simply push the _'_ key (apostrophe) and begin typing the text of the link you wish to follow. Once Firefox highlights that link (whether you've only typed a few letters or the entire word), you hit the Enter key and Firefox will begin loading that page. For example, if on this same page, you quickly want to go to the Table of Contents. Notice that the link for the table of contents is _<< To Contents_. Press the apostrophe key to activate the Find Toolbar for searching for links and then type "to". Firefox will then highlight part of the link. Pressing enter will take you to the _Using Firefox_ Table of Contents. One thing to note is that the apostrophe key does not necessarily have to be used for this tip to work; just using Find As You Type can accomplish the same thing, but since it searches all text, whether it's a link or not, it may not be as quick as beginning your search with the apostrophe key.

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# User preferences[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=6)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Preferences[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-1)]

To access the Preferences window, navigate to _Tools_ → _Options_ on Windows, _Edit_ → _Preferences_ on Linux, or _Firefox_ → _Preferences_ on OS X.

### General[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Firefox_Pref_Window_General.png/200px-Firefox_Pref_Window_General.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The General tab

The General Tab of the Preferences window allows you to change a few things:

  * Home Page
  * Default Browser
  * How Firefox connects to the Internet

The Home Page setting will most likely be the most used from this window, as the other two only need to be set once (if at all). There are four ways to set a home page from this window:

  * Type an address into the _Location(s):_ box (e.g., <http://www.google.com>)
  * Select the _Use Current Page(s)_ button, which will set the current page as the home page if only one is showing, or set all tabs as [multiple home pages](/wiki/Using_Firefox/Browsing_with_Tabs#Multiple_home_pages)
  * Select the _Use Bookmark..._ button to open a dialog that will allow you to select a site currently bookmarked as the home page
  * Select _Use Blank Page_ to have _about:blank_ set as the home page.

The first time Firefox is launched, it will check if it is set as the default browser. The option _Firefox should check to see if it is the default browser when starting_, when checked, will make sure that Firefox remains the default browser (or, if Firefox is _not_ the default browser, it will ask you each time if you'd like it to be). Also, pressing _Check now_ will do the check after the browser has already been started.

The Connection Settings button only needs to be used if you use a proxy to connect to the Internet. If so, you can have Firefox auto-detect the settings, manually enter them, or use an automatic proxy configuration URL.

  


### Privacy[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-3)]

The Privacy tab is described as follows: _As you browse the web, Firefox keeps information about where you have been, what you have done etc. in the following areas:_ Each area has its own settings. As you select tabs inside the Privacy Tab, the main content area will change. However, there is one setting at the bottom of the window that is accessible from each tab. It says _The Clear Private Data tool can be used to erase your private data using a keyboard shortcut or when Firefox closes._ along with a _Settings..._ button. Selecting that button will bring up a list of information that Firefox stores. Each can be set or unset individually. In addition to selecting which data you'd like cleared, there is an option to _Clear private data when closing Firefox_ and another to _Ask me before clearing private data_. All private data that you have selected can be cleared at any time during a browsing session by hitting [Ctrl]+[Shift]+[Del].

Clearing private data is a public act that may, if your purpose was to keep some activity secret, expose that very secret. For a significant historical example see <http://en.wikipedia.org/wiki/Soviet_atomic_bomb_project#Beginnings_of_the_program>. Further, if "Clear Private Data" does not overwrite that data (and the prior paragraph does not so state) then that data may remain on your computer for some time and can possibly be accessed.

  


#### History[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Firefox_Pref_Window_privacy-history.png/200px-Firefox_Pref_Window_privacy-history.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Privacy Tab with History selected

The History tab has only two items:

  * Remember visited pages for the last __ day(s).
  * A button to _Clear Browsing History Now_

These options are pretty self explanatory. Set the number of days you'd like Firefox to remember pages you have visited. Setting the value to **0** will cause Firefox to not use History. Pressing the _Clear Browsing History Now_ button will erase all of the History.

The History is available from the _Go_ → _History_ menu item, by pressing [Ctrl]+[H], or by going to _View_ → _Sidebar_ → _History_. The _Go_ menu itself also shows History.

History is an option for "Clear Private Data", and is selected by default.

  


  


#### Saved Forms[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/93/Firefox_Pref_Window_privacy-saved_forms.png/200px-Firefox_Pref_Window_privacy-saved_forms.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Privacy Tab with Saved Forms selected

This tab, like the History tab, has only two items of interest:

  * Save information I enter in forms and the Search Bar.
  * Clear Saved Form Data Now

Checking the box (which is the default setting) will have Firefox save any data that is entered in a form. This includes things like the Google search box, any contact information (Name, Address, Email, etc) and other search boxes. Also, the Search Box included on the default Firefox toolbar (accessible by pressing [Ctrl]+[K]) Unchecking this box will stop Firefox from saving this information. Pressing the _Clear Saved Form Data Now_ button will remove all the data currently stored by Firefox.

Saved Form Data is an option for "Clear Private Data", and is selected by default.

Note that you can clear out individual items _(such as an erroneous or mis-typed entry)_ without having to clear all saved data. When the list of saved items shows up, navigate to the item you want to remove _(don't click on it)_, then use the Shift-Delete key combination.

#### Passwords[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Firefox_Pref_Window_privacy-passwords.png/200px-Firefox_Pref_Window_privacy-passwords.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Privacy Tab with Passwords selected

When _Remember Passwords_ is checked (default), Firefox will present you with an option to save a password on any site where one is entered. After entering a password and hitting the submit button, Firefox will present a dialog with three options, _Remember_, _Never for This Site_, and _Not Now_. Selecting _Remember_ will have Firefox store the password for that page, and will automatically enter it on each successive visit. Selecting _Never for This Site_ will prevent Firefox from remembering the password for that page, **and** it will not ask to save a password on that page again. Selecting _Not Now_ will prevent Firefox from saving the password on that visit, but the dialog will be presented again the next time you visit that site.

Firefox also has the option to set a Master Password. Without one, Firefox will automatically enter any password that is stored--regardless of who is using the browser at that time. A Master Password will cause Firefox to prompt the user for a password before it will enter any saved passwords. However, it will only prompt once _per session_, meaning as long as the browser remains open. To prevent unauthorized use of passwords, be sure to close the browser when you are finished using it (if you entered a Master Password). The Master Password can also be unset from this window.

Pressing the _View Saved Passwords_ button will open a new dialog. This window shows every site that Firefox has a username/password saved for. At first, the address of the site and the username are displayed. Press the _Show Passwords_ button to display the saved passwords. Individual entries can be removed by selecting them, and pressing _Remove_. All entries can be removed with the _Remove All_ button.

Also on the _View Saved Passwords_ dialog is a tab that displays _Passwords Never Saved_. This window is very similar to the _Passwords Saved_ window. Removing an entry from this list, however, will cause Firefox to ask to save a password the next time you visit that site.

Saved Passwords are an option for "Clear Private Data", but are not selected by default.

#### Download History[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-7)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/80/Firefox_Pref_Window_privacy-download_history.png/200px-Firefox_Pref_Window_privacy-download_history.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Privacy Tab with Download History selected

Any time you download an item from the Internet, Firefox opens the Download Manager to track it. After the download is finished, Firefox will keep that item visible. Each item can be removed individually, or the entire history can be cleared at once. Also, Firefox can be set to never save a history (or clear the download history on its own, after each download). The Download Manager can be accessed by going to _Tools_ → _Downloads_, or by pressing [Ctrl]+[J]. It can also be accessed by pressing the _View Download History_ button on this pane of the Preferences window.

The only setting here affects how Firefox clears the Download Manager. _Remove files from the Download Manager:_

  * Upon successful download
  * When Firefox exits
  * Manually (default)

_Upon successful download_ will erase entries from the Download Manager as they finish downloading, _When Firefox exits_ will clear the Download Manager history each time Firefox is closed, and _Manually_ will leave all entries in the Download Manager until they are removed by the user.

**Note**: Removing files from the Download Manager **does not** delete the files from your computer. It only removes the history of you downloading it from Firefox.

Download History is an option for "Clear Private Data", and is selected by default.

  


#### Cookies[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-8)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/80/Firefox_Pref_Window_privacy-cookies.png/200px-Firefox_Pref_Window_privacy-cookies.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Privacy Tab with Cookies selected

[Cookies](//en.wikipedia.org/wiki/HTTP_cookie) are "_pieces of information stored by sites on your computer. They are used to remember login information and other data._" This window can be a little more confusing than the others.

The first option, which is enabled by default, is _Allow sites to set Cookies_. Next to that option is a button named _Exceptions_. Setting exceptions will allow cookies from every site _except_ for sites on the list.

Under that are two more options:

  * _for the originating site only_
  * _unless I have removed cookies set by the site_

Checking the first box will only allow cookies that are from the site you are currently on. For other sites to give you cookies, you will have to navigate to that site (with the option enabled; it is disabled by default). The second option will except all cookies, as long as you have not removed a cookie from that site. For instance, if you remove a cookie set by google.com, then google.com will no longer be able to send you cookies.

Beneath those options is a dropdown box. _Keep Cookies:_

  * _until they expire_ (default)
  * _until I close Firefox_
  * _ask me every time_

Each cookie has an expiration date. By selecting the first option, Firefox will keep each cookie until it expires, and then discard it. Selecting the second option will keep all cookies only until Firefox is closed. The third option will make Firefox ask you each time a site tries to set a cookie, or modify an existing one.

Pressing the _View Cookies_ button will bring up a new window, listing all cookies by site. From this window, it is possible to remove one, a few, or all cookies. Also, it is possible to view the contents of each cookie (though they are usually nonsensical).

Finally, the _Clear Cookies Now_ button will clear all cookies.

Cookies are an option for "Clear Private Data", but are not selected by default.

  


#### Cache[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-9)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Firefox_Pref_Window_privacy-cache.png/200px-Firefox_Pref_Window_privacy-cache.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Privacy Tab with Cache selected

_Pages you view are stored in the cache for faster viewing later on_. As you visit pages, Firefox will automatically save copies of them. If you navigate to the same page later, Firefox will use the page saved rather than downloading it again. With this setting, you can set the size of the cache.

_Use up to __ MB of disk space for the cache._ The default value is 50.

Press the _Clear Cache Now" button to remove all pages from the cache._

Cache is an option for "Clear Private Data", and is selected by default.

### Content[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/81/Firefox_Pref_Window_Content.png/200px-Firefox_Pref_Window_Content.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Content Tab

The first setting on this pane is for blocking popups. Firefox is set to automatically enable all unwanted popups. The setting is _Block Popup Windows_, and is enabled by default. To the right is an _Allowed Sites_ button, that lets you set sites to accept popup windows from. When a popup is blocked, the yellow "information bar" appears at the top of the window. From there, you can allow the popup that was blocked, or allow access for the site to open popups. Sites can be removed from the _Allowed Sites_ list, which will cause Firefox to block popups from that site again.

Next is the _Warn me when web sites try to install extensions or themes_. This is also enabled by default. To the right of that is an _Exceptions_ button. Any site that is not on the Exceptions list (which contains only _addons.mozilla.org_ and _update.mozilla.org_ by default) will be blocked from installing extensions or themes. A yellow information bar will appear at the top of the window, very similar to the one that appears when a popup is blocked. If you want to install an extension or theme from the current site, you can add it to the exceptions list, and then retry the install. If the install was unwanted (e.g., a web site tried to install a malicious extension), you don't need to take any further action, as the install was already blocked. Do not add the site to your exceptions list unless you want to install an extension/theme.

_Load images_ is the next preference. It is enabled by default. This preference also has an _Exceptions_ list, though it works slightly different from the extensions/themes exceptions list. From this list, you can both allow **and** deny permission for sites to load images. For instance, if the _Load images_ preference is enabled, you can use the Exceptions list to deny specific sites the ability to load images. If, for example, you did not want wikibooks.org to load images, you would type "wikibooks.org" in the _Address of the web site_ box, and hit _Deny_. All other sites would be allowed to load images as normal.

If the _Load images_ preference was disabled, then no images would be downloaded. However, if (again for example) you wanted wikibooks.org to be **allowed** to load images, then you would type "wikibooks.org" in the _Address of the web site_ box, this time hitting _Allow_. All images would be blocked **except** images from wikibooks.org. Both types (allowed sites and denied sites) can be set at the same time, but would depend on the state of the _Load images_ preference.

Below _Load images_ is a preference (disabled by default) _for the originating web site only_. When enabled, images will only load if they come from the same site as the current page. However, this will not display images for such large sites as Yahoo! and Wikipedia, as images on those sites are stored on separate servers.

The preference _Enable Java_ (enabled by default), controls whether or not Java applets are loaded in Firefox.

_Enable JavaScript_ (enabled by default) controls whether or not [JavaScript](//en.wikipedia.org/wiki/JavaScript) is executed by the browser. Pressing the _Advanced..._ button will bring up a new window with the following options: _Allow scripts to:_

  * Move or resize existing windows
  * Raise or lower windows
  * Disable or replace context menus
  * Hide the status bar
  * Change status bar text

The first three are enabled (meaning JavaScripts on a page will be able to do those actions) while the last two are disabled by default.

Finally, the Content tab contains Fonts & Colors settings. From this dialog, you can set the default font, and the default font size. The _Advanced..._ dialog will allow you to select which specific fonts display which font type, and their sizes. The _Colors..._ button allows you to set Link, Background, and Text colors.

  


### Tabs[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-11)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Firefox_Pref_Window_Tabs.png/200px-Firefox_Pref_Window_Tabs.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Tabs tab

The first Tab-related preference is "Open links from other applications in:"

  * A new window
  * A new tab in the most recent window
  * The most recent tab/window

These options are mostly self explanatory. When another application (AOL Instant Messenger, for instance) tries to open a link, this preference will tell Firefox where to do it. The first two are easy enough to figure out, while the third will simply reuse the window that was most recently focused (replacing its contents).

The next preference is "Force links that open new windows to open in:"

  * The same tab/window as the link
  * A new tab

This preference is sometimes referred to as "Single Window Mode", as it prevents the "target:_blank" and "target:_new" attributes on links from opening new windows, always forcing Firefox to use one window. However, it has been disabled by default, as a few crashes have been reported with it enabled. There is little danger in enabling it, as it can be easily disabled again if a problem arises.

Three other preferences are on this window:

  * Hide the tab bar when only one web site is open
  * Select new tabs opened from links
  * Warn when closing multiple tabs

The tab bar is hidden by default when only one website is opened. To have it always visible, uncheck the box next to the preference. "Select new tabs opened from links" can be described as "open a tab in the foreground". In other words, with this preference enabled (it's disabled by default), a new tab opened by middle clicking a link will automatically be selected and visible. The default behavior is to have the new tab open in the background, where you have to manually select it to view it. The final preference is visible by opening more than one tab and trying to close the window. A warning will be displayed to make sure all of the tabs can be closed.

It is also possible to extend tabbed browsing functionality through Firefox's extension system. See [Chapter 6](/wiki/Using_Firefox/Extensions) for more details on extensions.

### Downloads[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-12)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/22/Firefox_Pref_Window_Downloads.png/200px-Firefox_Pref_Window_Downloads.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Downloads tab

The Downloads tab has several preferences. First, there is the option of setting a "Download Folder". If _Ask me where to save every file_ is selected, then Firefox will prompt you for a location to save every file you download. Selecting _Save all files to this folder:_ will make it so every download goes to the same location. The Desktop is the default location for downloads on Windows.

Next, _Show Download Manager when a download begins_, which is enabled by default. This brings up the download manager for each file that is downloaded. You will manually have to close the Download Manager unless the preference _Close the Download Manager when all downloads are complete_ is selected.

The final preference states _Firefox can automatically download or open files of certain types._ Pressing the _View & Edit Actions..._ button will bring up a new window. It contains a list of file extensions, and default actions for files of that type. Each file type can be set to automatically open with its default application, automatically open with a non-default application, saved to the computer, or opened with a plugin (assuming the correct plugin is installed). At this time, there appears to be no "Add" button, so you're out of luck if the type you want to handle is missing from the list. Additionally, some users may have a blank dialog box (as of 8-8-2006), in which case none of the extensions are listed. The issue is mentioned at [http://forums.mozillazine.org/viewtopic.php?p=2400536&sid=d02c030728278592cbeb3aee9805b14b](http://forums.mozillazine.org/viewtopic.php?p=2400536&sid=d02c030728278592cbeb3aee9805b14b) but the fixes described may not work for all users. Those users should locate their profiles folder (%AppData%\Mozilla\Firefox\Profiles\xxxxxxxx.default on WinXP where x is a random character), and delete the appropriate files there.

### Advanced[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-13)]

This pane offers some advanced settings. There is a third tab offered under "Advanced", "Security". However, most users should not need to change any preferences on this tab.

#### General[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-14)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/50/Firefox_Pref_Window_advanced-general.png/200px-Firefox_Pref_Window_advanced-general.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Advanced Tab with General selected

The setting _Allow text to be selected with the keyboard_ controls **caret browsing**. When using caret browsing, a cursor is placed in the browser, and it can be moved with the arrow keys and used to select text. Pressing [F7] will also enable and disable this feature.

_Begin finding when you begin typing_ is a setting for Find As You Type (FAYT). Normally, FAYT is activated only after pressing the _/_ or _'_ keys, or by pressing [F3]. With this setting enabled, FAYT will begin when any key is pressed (as long as the cursor is not in a form, or other text entry area).

_Resize large images to fit in the browser window_ will automatically resize any image that is larger than the current browser window so that it fits in the window without causing scrollbars. Clicking on the image will display it at its full size, and clicking on it again will resize it to fit the window.

_Use autoscrolling_ toggles the ability to autoscroll. With autoscroll enabled, click the middle mouse button to enter autoscroll mode. While in autoscroll mode, simply move the mouse up to scroll up, and move the mouse down to scroll down. Clicking the middle mouse button again will exit autoscroll.

_Use smooth scrolling_ toggles the ability to make scrolling with the mouse wheel "smoother" than normal.

Finally, click the _Edit Languages..._ button to change the order of preference of languages for pages that offer more than one language.

  


#### Update[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-15)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/99/Firefox_Pref_Window_advanced-update.png/200px-Firefox_Pref_Window_advanced-update.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

The Advanced Tab with Update selected

The Update tab changes the way Firefox checks for updates for itself, extensions and themes, and search engines. All three should remain checked, as critical security updates will use the Update system.

The final preference determines how to install updates. If _Ask me what I want to do_ is selected, then Firefox will alert you when new updates are found and wait for instructions. If _Automatically download and install the update_ is selected, Firefox will apply updates without asking. However, if _Warn me if this will disable extensions or themes_ is checked, and a new update may break a currently installed extension or theme, Firefox will display a warning.

Finally, select the _Show Update History_ button to see a list of previously installed updates, and what they contained.

### Multiple Users[[edit](/w/index.php?title=Using_Firefox/Preferences&action=edit&section=T-16)]

With Firefox, it is possible to create many different _profiles_ each with its own settings. This has several advantages, because it allows you to install the extensions you need for web development, while not slowing down your browser for normal surfing. The disadvantage is that only one profile can be running a the same time. To switch profiles, or add new profiles, you need to run `firefox -profilemanager`. On Windows, this can be achieved by typing the command into the "Run" dialog on the start menu, on most other systems this can be run wherever a command may be run, usually a Terminal or Command Line.

This command must be run when firefox is not running on your computer, if it is running,you will just get a new window with the preferences for the currently active profile. The dialog box that opens when the command is run successfully allows you to select from a list of profiles. With each profile you have the option to either "Rename" or "Delete" it, or just to "Start Firefox" by using it.

When you delete a profile from the profile manager, it asks you whether you want to delete or keep the files that contain the information associated with it. If you select the delete files option, then all private data associated with that profile, including history, saved passwords, and cookies, are deleted from the hard drive. There is no reason to keep these files as creating a new profile under the same name as the deleted one will not restore the profile.

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# Extensions[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=7)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

Extensions are small add-ons that add new functionality to Firefox. They can add anything from a toolbar button to a completely new feature. They allow the browser to be customized to fit the personal needs of each user if they need additional features, while keeping Firefox small to download.

There are over 1000 extensions available for Firefox. This may make it difficult for people to find what they want. The links on this page are intended to help while also remaining current. As such they will not generally point to specific extension but rather where to look for them. To look at links by category [this page](https://addons.mozilla.org/firefox/extensions/) is a good start. Additionally the headings below provide a link to mozilla.org pointing to the specific category - this means that the information will always be up to date.

A good place to start looking for extensions is [here](https://addons.mozilla.org/firefox/recommended/) for recommended extensions.

The most popular extensions are to be found [here](https://addons.mozilla.org/search.php?app=firefox&appfilter=firefox&type=E&sort=downloads).

There are many themes available at Mozilla Update which make Firefox more attractive. The most popular ones are [here](https://addons.mozilla.org/search.php?app=firefox&appfilter=firefox&type=T&sort=downloads).

In addition, Mozilla has recently launched [Fashion Your Firefox](https://addons.mozilla.org/en-US/firefox/fashionyourfirefox), a service for users who don't want to go through the entire library of addons to choose just a few good ones based on what they use Firefox for.

  


## [Blogging](https://addons.mozilla.org/search.php?cat=1&app=firefox&appfilter=firefox&type=E)[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-1)]

## [Bookmarks](https://addons.mozilla.org/search.php?cat=22&app=firefox&appfilter=firefox&type=E)[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-2)]

## Developer Tools[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-3)]

  * [EditCSS](http://update.mozilla.org/extensions/moreinfo.php?id=179&page=releases)\- Stylesheet modifier in the Sidebar. Allows you to edit any site's CSS file on the fly.
  * [Web Developer Extension](http://update.mozilla.org/extensions/moreinfo.php?id=60&page=releases)\- Must have extension for anyone dabbling in web design.

## Download Tools[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-4)]

  * [Download Statusbar](http://update.mozilla.org/extensions/moreinfo.php?id=26&page=releases) — View downloads in an auto-hide statusbar.
  * [DownThemAll!](https://addons.mozilla.org/en-US/firefox/addon/201) — Easily manage downloads while accelerating them as well.
  * [Video DownloadHelper](https://addons.mozilla.org/en-US/firefox/addon/3006) — Download videos(FLV files; **F**lash **V**ideo; extension:*.flv) from sites like [Youtube](http://www.youtube.com) and other types of media including MP3(Extension:*.mp3) etc.

## Themes[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-5)]

  * [Vista-aero](https://addons.mozilla.org/en-US/firefox/addon/4988) — A theme for Firefox meant to look like Internet Explorer 7; with Aero-like visual effects

## Miscellaneous[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-6)]

  * [BBCode](http://update.mozilla.org/extensions/moreinfo.php?id=128&page=releases) — Enables you to quickly and easily insert various BBCode tags in editable textboxes from the context menu. Very handy for customizing posts on forums.
  * [Calculator](http://quicktools.mozdev.org/mozcalc/) — A simple calculator extension.
  * [Calculator](https://addons.mozilla.org/firefox/1194/) — An advanced calculator extension.
  * [Calendar](http://www.mozilla.org/projects/calendar/) — An [iCal](http://www.apple.com/ical/) compatible Calendar for Firefox. You can download calendars for your favourite sports teams, etc., from [iCal Share](http://icalshare.com/)
  * [ChatZilla](http://update.mozilla.org/extensions/moreinfo.php?id=16&page=releases) — A simple, straightforward Internet Relay Chat (IRC) client.
  * [Cookiepie](http://www.nektra.com/oss/firefox/extensions/cookiepie/) — An extension to handle multiple web accounts simultaneously, opening many Gmail, Yahoo, Hotmail accounts in different tabs on the same browser.
  * [FoxyTunes](http://update.mozilla.org/extensions/moreinfo.php?application=firefox&id=219) — Adds media player controls within Firefox. Currently supports many different music players across multiple platforms.
  * [Gmail Notifier](http://update.mozilla.org/extensions/moreinfo.php?id=173&page=releases) — A Gmail notifier that integrates into the browser's user interface.
  * [FasterFox](http://addons.mozilla.org/extensions/moreinfo.php?id=1269) — A simple-to-use performance and network tweaker. Fasterfox allows you to change certain setting to make Firefox load pages more quickly, depending on your computer speed and Internet connection.
  * [Quick Note](http://update.mozilla.org/extensions/moreinfo.php?id=46&page=releases) — A note taking extension with advanced features.
  * [StumbleUpon](http://update.mozilla.org/extensions/moreinfo.php?id=138&page=releases) — Lets you 'stumble upon' websites that have been recommended ("thumbed up") by friends and community members with interests similar to your own. See also [StumbleUpon website](http://www.stumbleupon.com/).
  * [WebmailCompose](http://update.mozilla.org/extensions/moreinfo.php?id=206&page=releases) — Makes mailto: (email) links load a webmail mail compose window and adds a WebMailCompose link to the context menu. Now supports selected addresses.
  * **[Wikipedia](http://wikipedia.mozdev.org/)** — Provides text formatting options in the context menu for use on wiki sites based on [Mediawiki](http://wikipedia.sourceforge.net/), such as Wikipedia and Wikibooks.

## Mouse gestures[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-7)]

  * [All-in-one mouse gestures](http://update.mozilla.org/extensions/moreinfo.php?id=12&page=releases) — Enables you to use the mouse for a wide variety of customizable shortcuts.

## Navigation[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-8)]

  * [Linkification](http://www.beggarchooser.com/firefox/) — Injects CSS on the fly making text URLs clickable with the default option to suppress referrer information.
  * [Paste & Go](http://update.mozilla.org/extensions/moreinfo.php?id=65&page=releases) — Lets you paste a URL from the clipboard and directly load it.

## News[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-9)]

  * [Sage](http://update.mozilla.org/extensions/moreinfo.php?id=77&page=releases) — A lightweight [RSS](/wiki/RSS) and [Atom feed](//en.wikipedia.org/wiki/ATOM_feed) aggregator. Very useful for viewing news from many sites.

## Page Display[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-10)]

  * [Adblock Plus](http://www.extensionsmirror.nl/index.php?showtopic=774) — Blocks or hides advertisements and other annoyances from web pages, while still retaining the correct page format. It is designed to allow you to block flash and image banners built into the web page, as well as scripts. You add your own filters using wildcards (*) for simple filters, or [RegEx](http://www.regular-expressions.info/) (regular expressions) for advanced ones. An excellent maintained set of filters is [here](http://pierceive.com/).
  * [Flashblock](http://flashblock.mozdev.org/) — Allows you to easily block flash animations. Flash animations are replaced with an icon you click to play. May conflict with Adblock Plus and crash on some flash-intensive sites.
  * [Image Zoom](http://update.mozilla.org/extensions/moreinfo.php?id=139&page=releases) — Adds zoom functionality for images. Functionality is also included in the Mouse Gestures extension.

## Search tools[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-11)]

  * [termBlaster](http://addons.mozilla.org/extensions/moreinfo.php?id=1720) — Lets you search selected text using search engines selected by context menu. It comes with 110+ search engines from encyclopedias to translators to web-search engines organized in folders.
  * [Dictionary Search](http://update.mozilla.org/extensions/moreinfo.php?id=68&page=releases) — Looks up selected word in a (customizable) online dictionary. Functionality is also included in the SmartSearch extension, which lacks the 4 search limitation.
  * [Googlebar](http://update.mozilla.org/extensions/moreinfo.php?application=firefox&id=33&page=releases) — The Google Toolbar for Firefox. Additionally, Googlebar Lite provides a simpler interface (which is recommended for new users). [[3]](https://addons.mozilla.org/extensions/moreinfo.php?id=492)
  * [Groowe Search Toolbar](http://www.groowe.com/) — Groowe Search Toolbar bundles Google toolbar, Yahoo, Ask Jeeves, Teoma, Amazon, Download.com and others. The application is available for Internet Explorer as well.

## Tabs and windows[[edit](/w/index.php?title=Using_Firefox/Extensions&action=edit&section=T-12)]

  * [Focus Last Selected Tab](http://update.mozilla.org/extensions/moreinfo.php?id=32&page=releases) — Brings focus to the last selected tab when closing the active tab. Functionality is also included in the TabMix extension.
  * [Session Saver](http://extensionroom.mozdev.org/more-info/sessionsaver) — Saves the open tabs when closing the browser, and restores them upon restarting it. Functionality is also included in the TabMix extension.
  * [Single Window](http://update.mozilla.org/extensions/moreinfo.php?id=50&page=releases) — A simple extension that allows Mozilla to fully utilize the built-in tabbed browsing behavior. Traps links that would normally open in a new window. Functionality is also included in the TabMix extension.
  * [Tabbrowser Preferences](http://update.mozilla.org/extensions/moreinfo.php?id=158&page=releases) — Enables enhanced control for tabbed browsing. Most functionality is also included in the TabMix extension. Recommended for users who would like to change the way tabs behave in Firefox.
  * [TabMixPlus](https://addons.mozilla.org/firefox/1122/) An extension that allows considerable customisation in the use of tabs and windows as well as a "restore" function that is as useful (or better) then the built in FireFox one.
  * [Undoclosetab](http://update.mozilla.org/extensions/moreinfo.php?id=58&page=releases) — Reopen a closed tab. Functionality is also included in the TabMix, SessionSaver, and Mouse Gestures extensions.

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# Plug-ins[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=8)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## What is a Plugin?[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-1)]

Firefox requires _plugins_ in order to read or display special content from the websites. Plugins are programs that are integrated into Firefox that allows websites to provide content to you. Such content includes flash videos, java games and streaming video from the Internet. Examples of plugins are Flash, RealPlayer, and Java. Plugins are a necessary component to truly access the Internet's interactive stuff.

A much more comprehensive list of plugins, with detailed installation instructions, is available at [Mozilla Update](http://pfs.mozilla.org/plugins/). Another valuable resource is [Mozdev Plugins](http://plugindoc.mozdev.org).

## Before You Install[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-2)]

### Close Firefox before installing plugins[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-3)]

Firefox should be closed before running any plugin installation programs, as existing files may be overwritten during the installation process.

### Using XPInstall to install plugins[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-4)]

Some plugins are available as XPInstall packages (XPIs), the same format as that for extensions. Where XPIs are available, it is recommended you use them as they often install the plugin automatically without you having to restart Firefox. After the XPI has finished installing, you should restart your browser.

### Checking which plugins you have installed[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-5)]

To check what plugins you have installed, simply type _about:plugins_ in the Location bar. This page will show which plugins are installed, what file types they are associated with and if the plugin is enabled or disabled.

## Available Plugins[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-6)]

### Adobe PDF Reader[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-7)]

In order to read .pdf files, you need to install a pdf reader. Adobe Reader, one of the more popular software, can do this. Simply go to Adobe's official [site](http://www.adobe.com/products/acrobat/readstep2.html) and download Adobe Reader. With Firefox closed, install Adobe Reader and it will also install the plugin necessary for Firefox to view PDF files. No other steps are necessary. Firefox will now open all PDFs from within a Firefox tab.

If you install Adobe Reader after Firefox, Adobe Reader will automatically select the right plugin. If you already have the latest version of Adobe Reader installed then Firefox will automatically use the plugin. Some people have problems with the Adobe Reader plugin in Firefox. The explanation and solution is [here](http://kb.mozillazine.org/index.phtml?title=Adobe_Reader).

### Java[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-8)]

The Java Plugin is part of the Java Runtime Environment (JRE, for short). The JRE installer will install the Java Plugin for Netscape 7.2 and Mozilla automatically.

To get the it simply go to [java.com](http://java.com/) and click the "Download Now!" button to download and install the latest JRE.

### Macromedia Flash Player[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-9)]

When you encounter a site that makes use of Flash graphics, a yellow bar will appear at the top of the page telling you that there is a missing plugin preventing you from viewing all the content on the current page. Click on _Install Missing Plugins_ button and the Mozilla Plugin Finder Service will appear automatically. After accepting the User Agreement from Macromedia, the necessary components to view Flash will be installed.

Alternately, you may install Macromedia Flash Player (without having to go to a site) by installing the plugin manually. Simply go [here](http://plugindoc.mozdev.org/windows.html#Flash) and click on the Macromedia Flash Player 8.0 link.

### Macromedia Shockwave Player[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-10)]

Simply go to the Macromedia Shockwave [site](http://sdc.shockwave.com/shockwave/download/download.cgi?) and download the plugin. When you are installing it, Firefox will appear in the list of browsers that you can install the plugin for. (Remember, Firefox should be closed when installing).

### Quicktime Player (Windows & Mac)[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-11)]

Simply go to Apple's (the developer of Quicktime) website and download [Quicktime](http://www.apple.com/quicktime/download/). Installing Quicktime will install the appropriate plugin in order for Firefox to view .mov files.

### RealPlayer[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-12)]

Simply go to Real's (the developer of RealPlayer) website and download the [program](http://www.real.com/freeplayer/?rppr=rnwk). The RealPlayer installer will automatically detect your browser's plugins folder and install the plugin.

## Uninstalling Plugins[[edit](/w/index.php?title=Using_Firefox/Plug-ins&action=edit&section=T-13)]

A list of your installed plugins can be obtained from about:plugins. As a general rule, to remove a plugin, you remove the file listed in about:plugins for it. Typically a .dll file.

On a XP machine this can typically be found at c:\Program Files\Mozilla Firefox\plugins

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# Mouse shortcuts[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=9)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

    _Note: for Mac OS X, use the Command key in place of Control for all shortcuts listed._

## Standard Firefox Shortcuts[[edit](/w/index.php?title=Using_Firefox/Mouse_shortcuts&action=edit&section=T-1)]

**Back**
Shift+Scroll down

**Close Tab**
Middle-click on tab

**Decrease Text Size**
Ctrl+Scroll down

**Forward**
Shift+Scroll up

**Increase Text Size**
Ctrl+Scroll up

**New Tab**
Double-Click on Tab Bar or Middle-click on Tab Bar

**Open Link in Background Tab**
Ctrl+Left-click or Middle-click on a link

**Open Link in Foreground Tab**
Ctrl+Shift+Left-click or Shift+Middle-click on a link

**Open Link in New Window**
Shift+Left-click on a link

**Save Link As**
Alt+Left-click on a link

**Scroll line by line**
Alt+Scroll

# Keyboard shortcuts[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=10)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Standard Firefox Keyboard Shortcuts[[edit](/w/index.php?title=Using_Firefox/Keyboard_shortcuts&action=edit&section=T-1)]

    _Note: for Mac OS X, use the Command key in place of Control for all shortcuts listed._

**Back**
Alt+Left Arrow (or Backspace on Windows)

**Bookmarks**
Ctrl+B or Ctrl+I

**Bookmark This Page**
Ctrl+D

**Bookmark All Tabs**
Ctrl+Shift+D

**Caret Browsing**
F7

**Clear Personal Data**
Ctrl+Shift+Del

**Close Tab**
Ctrl+W or Ctrl+F4

**Close Window**
Ctrl+Shift+W or Alt+F4

**Complete .com Address**
Ctrl+Enter

**Complete .net Address**
Shift+Enter

**Complete .org Address**
Ctrl+Shift+Enter

**Copy**
Ctrl+C or Ctrl+Insert

**Cut**
Ctrl+X or Shift+Del

**Delete**
Del

**Downloads**
Ctrl+J (Windows & Mac OS X only), Ctrl+Y (Linux only)

**Find Again**
F3 or Ctrl+G

**Find in This Page (Find As You Type)**
Ctrl+F or /

**Find in This Page (Find As You Type): links only**
' (apostrophe key)

**Find Previous**
Shift+F3 or Shift+Ctrl+G

**Force Reload (override cache)**
Ctrl+F5 or Ctrl+Shift+R

**Forward**
Alt+Right Arrow (or Shift+Backspace on Windows)

**Full Screen**
F11 (not implemented on Mac OS X)

**Group Your Tabs (Panorama)**
Ctrl+Shift+E

**History**
Ctrl+H

**Home**
Alt+Home

**Location Bar**
F6 or Ctrl+L or Alt+D

**New Tab**
Ctrl+T

**Next Frame**
F6

**Next Tab**
Ctrl+Tab or Ctrl+PageDown or Ctrl+Alt+Right Arrow

**New Window**
Ctrl+N

**Open File**
Ctrl+O

**Open Last Closed Tab**
Ctrl+Shift+T

**Open Location in New Tab**
Alt+Enter

**Page Source**
Ctrl+U

**Paste**
Ctrl+V or Shift+Insert

**Previous Frame**
Shift+F6

**Previous Tab**
Ctrl+Shift+Tab or Ctrl+PageUp or Ctrl+Alt+Left Arrow

**Print**
Ctrl+P

**Redo**
Ctrl+Y (NOT Linux) or Ctrl+Shift+Z

**Reload**
F5 or Ctrl+R

**Save Page As**
Ctrl+S

**Search**
_see **Find** and **Web Search**_

**Select All**
Ctrl+A

**Select Next Search Engine in Search Bar**
Ctrl+Down

**Select Previous Search Engine in Search Bar**
Ctrl+Up

**Select Tab [1 to 8; last tab]**
Ctrl+[1 to 8; 9]

**Stop**
Esc

**Text Size: Decrease**
Ctrl+-

**Text Size: Increase**
Ctrl++

**Text Size: Normal**
Ctrl+0

**Web Search**
Ctrl+K (or Ctrl+E on Windows & Mac OS X, or Ctrl+J on Unix)

**Undo**
Ctrl+Z

**Start typing in address bar**
Ctrl+L (Cmd + L on OS X)

# Privacy[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=11)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Clearing Private Data[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-1)]

### History[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-2)]

![Firefox Pref Window privacy-history.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Firefox_Pref_Window_privacy-history.png/220px-Firefox_Pref_Window_privacy-history.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

It is possible to select individual history items to delete, by using the history side bar. You can open the history side bar by selecting from the menu the _View -> Sidebar -> History_ option. Deleting singular items can be achieved by finding the item, right-clicking on it to get the context menu, and selecting _Delete_. Deleting multiple entries can be achieved by right-clicking the list to focus it (for left-clicking will open the web page under the mouse, and losing focus on the list) and using the up/down arrows, and shift+up/down to select blocks of entries. Pressing _Delete_ on the keyboard will delete the selected history items.

It is possible to delete all history items by opening the preferences dialog on the menu at _Edit -> Preferences_, and clicking on the _Privacy_ tab and then the _History_ tab. A button will be there to _Clear Browsing History Now_. This will clear **all** history items.

Under this tab also, by changing the option _Remember my browsing history for X days_, to 0, history items will not be kept between sessions.

Auto-completed URLs will disappear as corresponding history items are deleted.

### Cookies[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-3)]

![Firefox Pref Window privacy-cookies.png](//upload.wikimedia.org/wikipedia/commons/thumb/8/80/Firefox_Pref_Window_privacy-cookies.png/220px-Firefox_Pref_Window_privacy-cookies.png)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Cookies can be cleared by selecting the _Privacy_ tab and then the _Cookies_ tab under the user preferences from the menu at _Edit -> Preferences_. All cookies can be deleted by clicking the _Clear Cookies Now_ button. Individual cookies can be cleared by clicking the _View Cookies_ button to open the cookie viewing dialog. Selecting cookies and pressing _Delete_ on the keyboard will delete those cookies.

By changing the option to _Keep Cookies_ to _Until I close Firefox_, cookies will not be kept between sessions. Also it is possible to choose to block all websites from putting cookies on your computer unless you have explicitly allowed them to do so, by adding them to a list accessible from this tab.

### Other Data[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-4)]

It is possible to delete other private data by using options under the _Privacy_ tab of the user preferences. See [Preferences](/wiki/Using_Firefox/Preferences#Privacy) for more details.

If you just want to delete one or a few values from the saved (remembered) list of field (or form) values, navigate to the item you want to clear _(don't click on it, just "point" to it)_, then use the Shift-Delete key combination to clear it.

### Deleting All Private Data[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-5)]

You can delete all private data, including browsing history, cookies, cache, saved form data, passwords, and download history, by opening the _Clear Private Data_ dialog under the menu in _Tools -> Clear Private Data_ (or by pressing _Ctrl-Shift-Delete_ on your keyboard). This will ask you to list your preferences as to what should be cleared from Firefox. If you want to do the same thing often in the future, you can deselect _Ask me before clearing private data_, and the dialog will not be cleared.

Your preferences for this option can be set in the user preferences dialog under the _Privacy_ tab; there is a button down the bottom right that says _Settings_, which will effect this function.

### Security Extensions[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-6)]

#### Stealther[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-7)]

This Firefox extension allows you to surf the web without leaving a trace on your local machine. It temporarily disables the following while it is active:

\- Browsing History (Websites you've visited, no auto-complete of URL's - Cookies (Doesn't allow websites to store cookies *Warning* this could cause difficulties when trying to access user account or E-Mail) - Downloaded Files History (All the files you've downloaded) - Disk Cache (Any files normally stored on your local machine "i.e images" will not be stored for fast viewing) - Saved Form Information (Information that would be used during the save form feature in Firefox "i.e save user name and password on this computer?" will not work) - Sending of ReferrerHeader. (When you click on a link from one web page or website to another, the browser usually sends a Referer/header to the server to tell sites where you came from.)

#### NoScript[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-8)]

"Winner of the "2006 PC World World Class Award", this tool provides extra protection to your Firefox. It allows JavaScript, Java and other executable content to run only from trusted domains of your choice, e.g. your home-banking web site, and guards the "trust boundaries" against cross-site scripting attacks (XSS). Such a preemptive approach prevents exploitation of security vulnerabilities (known and even unknown!) with no loss of functionality... Experts do agree: Firefox is really safer with NoScript ;-)" -Giorgio Maone

#### WOT[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-9)]

"Can you recognize good and reliable Internet content? Did you have a bad experience that you would like to share with others? WOT can help you. Seeing website reputations on your browser allows you to learn from other people. This shared knowledge makes it easier to avoid online fraud, including phishing and spyware. WOT can add reputations also to web search results, Digg, Gmail, Wikipedia, and other selected sites." -Against Intuition, Inc.

"This of course preserves your privacy to great extent" - Anonymous

#### CookieSafe[[edit](/w/index.php?title=Using_Firefox/Privacy&action=edit&section=T-10)]

"This extension will allow you to easily control cookie permissions. It will appear on your statusbar. Just click on the icon to allow, block, or temporarily allow the site to set cookies. You can also view or clear the cookies and exceptions by right clicking on the statusbar icon. For safer browsing you may choose to deny cookies globally and then enable them on a per site basis." -Ron Beckman

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# Advanced configuration[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=12)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## about:config[[edit](/w/index.php?title=Using_Firefox/Advanced&action=edit&section=T-1)]

Type about:config into your address bar and you will be brought to the about:config settings. This is a powerful way to tweak your settings in ways that are not normally accessible through the Options menu. By simply double clicking one of the available options (after copying and pasting them into the filter bar to find them easily), changes can be made, including the following:

  * browser.block.target_new_window — if set to true, links that normally force a new window to open will open in the current window instead.
  * browser.xul.error_pages.enabled — if set to true, Firefox displays an error page similar to IE instead of a message box if loading a page fails.
  * layout.frames.force_resizability — if set to true, allows the user to resize frames on any web site that uses them.

The following changes can be made to speed up browsing. Normally the browser will make one request to a web page at a time. When you enable pipelining it will make several at once, which usually speeds up page loading. Make these changes to enable pipelining:

Set "network.http.pipelining" to "true"

Set "network.http.proxy.pipelining" to "true"

[Tip: If have your browser set to connect to an optional http proxy, you can leave "network.http.pipelining" setp to "false", then add the domains of websites that don't work with pipelining (like images.google.com) to the proxy exclude list.]

Set "network.http.pipelining.maxrequests" to 8. This means it will make up to 8 requests at once rather than the default of 4. This is only an advantage if you have a reliable internet connection that isn't particularly slow.

Finally, right-click anywhere and select New-> Integer. Name it "nglayout.initialpaint.delay" and set its value to "0". This value is the amount of time the browser waits before it acts on information it receives, but it will increase the total time taken to render the page. This option is more suitable for a faster computer ("250" is the default). Try a value of "100" if "0" causes problems.

For broadband users:

Set "network.http.max-connections-per-server" to 14. Many guides recommend setting this figure to 100, but this can have undesirable effects upon webservers.

Set "network.http.max-connections" to 48

  
A much more complete list can be found [here](http://preferential.mozdev.org/preferences.html), with descriptions and which values the preference will take (where applicable)

## Editing the userChrome.css File[[edit](/w/index.php?title=Using_Firefox/Advanced&action=edit&section=T-2)]

userChrome.css is a file that allows you to change the appearance of Firefox with CSS rules. The actual browser window (i.e., not the webpage, but everything else) is called the "chrome". The file userChrome.css overrides default settings to allow for more customization.

userChrome.css is not created by default. It should be created in your profile folder, which can be found in the following places:
    
    
    **Windows**:
     %appdata%\Roaming\Mozilla\Firefox\Profiles\<Profile name>\
    **Linux**:
     ~/.mozilla/firefox/<Profile name>/
    **Mac OS X**:
     ~/Library/Mozilla/Firefox/Profiles/<Profile name>/
    or
     ~/Library/Application Support/Firefox/Profiles/<Profile name>/
    

In all cases, the profile is randomly named, with 8 characters followed by _.default_. Inside that folder is another named "chrome". Inside the chrome folder is where userChrome.css needs to be created.

## Editing the userContent.css File[[edit](/w/index.php?title=Using_Firefox/Advanced&action=edit&section=T-3)]

## Tips[[edit](/w/index.php?title=Using_Firefox/Advanced&action=edit&section=T-4)]

  * Allowing extension downloads from mozilla.org instead of www.mozilla.org will match all subdomains of mozilla.org, just as blocking cookies from doubleclick.net instead of www.doubleclick.net will allow blocking of all doubleclick.net subdomains. Allowing "www.mozilla.org" would not allow "addons.mozilla.org". However, as a security measure, when whitelisting sites for extensions, the most specific domain available should be used (i.e., addons.mozilla.org instead of mozilla.org) to prevent potentially malicious installs from other subdomains on a site.
  * To get Firefox on a computer without an internet connection or where internet downloads are blocked you can download the file as normal form another computer (usually you can do this at a public library) then put the *.exe file on some removable media and transfer it to the first computer.

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# Developers tools[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=13)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Extension Development[[edit](/w/index.php?title=Using_Firefox/Developers&action=edit&section=T-1)]

The most comprehensive site for Extension development is at the Mozillazine Knowledge Base found [here](http://kb.mozillazine.org/Extension_development). Other helpful tools include the [DOM Inspector](http://www.mozilla.org/projects/inspector/) included in Firefox and the JavaScript console.

Firefox is especially developer-friendly. It allows even the most casual web developer to crib useful HTML techniques from most any website they visit, and offers a host of other features for more serious users.

## Source viewing[[edit](/w/index.php?title=Using_Firefox/Developers&action=edit&section=T-2)]

Perhaps the most-used development feature is the ability to highlight images and text in any website, and choose to view source from a drop-down menu. When this feature is used, Firefox displays the HTML source that was used to generate the highlighted content.

For instance, highlighting the above paragraph and section heading, right clicking, and choosing "_Vi_e_w Selection Source_", will display the following in a new window:
    
    
    <p><a name="Source_viewing" id="Source_viewing"></a></p>
    <h2>Source viewing</h2>
    <p>Perhaps the most-used development feature is the ability to highlight images and text in any website, and choose "<i>View selection source</i>" from the drop-down menu. Doing this will bring up a pop-up window, with the HTML source that was used to generate the highlighted content.</p>
    

Combining this technique with a good markup language reference source, such as the [Wikibook](/wiki/Main_Page) [HTML Programming](/wiki/HTML_Programming), will allow you to learn from every new website you visit.

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

# Creating an extension[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=14)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Introduction[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-1)]

This tutorial will explain step by step how to deploy an extension for Firefox 3. In this way the reader could implement in a easy way extensions that let personalize their version of Firefox, taking care about the compatibilities with Firefox 3.0*.

The first chapter gives a brief introduction to the extensions for Firefox. Then it will discuss some items that the developer must have considered about the compatibilities.

The second chapter starts to describe step by step how to deploy the extension and then, the last chapter will explain hoy to make the install file and how to install it.

  


## Extensions for Firefox 3.0.*[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-2)]

This chapter will introduce the topic of what are the extensions and what functionalities they give. And for last the topic of compatibility.

  


### What are the extensions?[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-3)]

An extension is a new functionality that is integrated to Firefox. These one can be deployed independent from the browser and from the platform. So we can say that extensions let users to bring new features, functionalities and behaviors to the browser.

  
The extensions are not the same as plug-ins. A plug-in allows for the viewing of web content that the browser cannot show by itself, for example: pdf, flash, sounds and videos.

  


### Compatibility with Firefox 3.0.*[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-4)]

Some functions of JavaScript are not longer supported in the new releases of Firefox, especially over versions 3.p.*. Also the structures of the manifest files and the reference to the browes.xul have been changed. It is important to know about that changes, if not the extension could be incompatible with the last versions of Firefox. Other items to consider are the Managers that Firefox implements (ex, loginManager). These have been suffered changes too. For more information: Updating....

  


## Start creating an extension.[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-5)]

The next chapter describes step by step how to develop simple extensions. It’ll specify the folders that must be created, the structure that must follow the type of files and the root folder.

  


### Structure of folders[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-6)]

There is an obligatory structure that the folders must carry out. This structure defines the names of the folders, the hierarchical structure, the type of files of each folder and the place where these folders and files should be stored for bean recognized for Firefox.

  


### Root folder[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-7)]

Al the beginning we must create a folder with the name of the extension. This name must be unique and match the name defined in the installation file. There are two ways of naming the root folder of an extension.

As mentioned, this name must be unique, so the first alternative is to generate a GUID identifier for it. In windows you can use the guidgen command and in Linux the uuidgen command. For example, you can generate this {1ca6f699-f8f3-479b-983b-20775f09f755}. The second alternative is to create a name with e-mail format. Is not recommendable to use a personal e-mail, only should have the same format. For example, we can call our extension like myextension@somedomain.

Inside the root folder we'll create the structure corresponding to the extension.

  


### Chrome Folder[[edit](/w/index.php?title=Using_Firefox/Creating_an_extension&action=edit&section=T-8)]

# External Links[[edit](/w/index.php?title=Using_Firefox/Print&action=edit&section=15)]

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

## Helpful Links[[edit](/w/index.php?title=Using_Firefox/Links&action=edit&section=T-1)]

  * [Why switch to Firefox?](http://www.switch2firefox.com/whyswitch/) — Reasons to switch.
  * [Portable Firefox](http://johnhaller.com/jh/mozilla/portable_firefox/) — John Haller has repackaged firefox to be run from a removable storage device (such as a USB key or a zip disk).
  * [Spread Firefox](http://www.spreadfirefox.com/) — Firefox marketing.

## Getting Started[[edit](/w/index.php?title=Using_Firefox/Links&action=edit&section=T-2)]

  * [Firefox Help](http://www.mozilla.org/support/firefox/) — Online Help for the Mozilla Firefox Web Browser
  * [Getting started with Mozilla Firefox](http://www.edafe.org/tag/firefox/)
  * [MozillaZine Knowledge Base wiki](http://kb.mozillazine.org/)
  * [Mozilla Community wiki](http://mozilla.wikicities.com/)
  * [MozillaZine Forums](http://forums.mozillazine.org/)\- If you have any problems with Firefox this should be your first port of call.
  * [Firefox Resources](http://loadaveragezero.com/app/drx/Internet/WWW/Clients/Browsers/Firefox)
  * [Firefox Guide](http://www.browserfirefox.com/) Simplified guide for the Firefox browser and all its resources

## Plugins, Extensions, and Tweaks[[edit](/w/index.php?title=Using_Firefox/Links&action=edit&section=T-3)]

  * [PluginDoc](http://plugindoc.mozdev.org/) — Lists common plugins and how to install them in Firefox.
  * [Mozilla Addons](https://addons.mozilla.org/) — Official Mozilla site for plugins, extensions and themes.
  * [Addonsmirror.net](http://www.addonsmirror.net/) — unofficial extension database (Formerly extensionsmirror.nl)
  * [Firefox Tweak Guide](http://www.tweakfactor.com/articles/tweaks/firefoxtweak/) — Has some great tweaks for speed and various other customizations.
  * [How to write Firefox extensions](http://roachfiend.com/archives/2004/12/08/how-to-create-firefox-extensions) — Tutorial for creating Firefox extensions, which includes a "Hello, world!" extension to explain the basics.

_Chapters:_ [1](/wiki/Using_Firefox/Introduction) \- [2](/wiki/Using_Firefox/Installation) \- [3](/wiki/Using_Firefox/Browsing_with_Tabs) \- [4](/wiki/Using_Firefox/Search) \- [5](/wiki/Using_Firefox/Preferences) \- [6](/wiki/Using_Firefox/Extensions) \- [7](/wiki/Using_Firefox/Plug-ins) \- [8](/wiki/Using_Firefox/Mouse_shortcuts) \- [9](/wiki/Using_Firefox/Keyboard_shortcuts) \- [10](/wiki/Using_Firefox/Privacy) \- [11](/wiki/Using_Firefox/Advanced) \- [12](/wiki/Using_Firefox/Developers) \- [13](/wiki/Using_Firefox/Creating_an_extension) \- [14](/wiki/Using_Firefox/Links)

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Using_Firefox/Print&oldid=2502696](http://en.wikibooks.org/w/index.php?title=Using_Firefox/Print&oldid=2502696)" 

[Category](/wiki/Special:Categories): 

  * [Using Firefox](/wiki/Category:Using_Firefox)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Using+Firefox%2FPrint&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Using+Firefox%2FPrint)

### Namespaces

  * [Book](/wiki/Using_Firefox/Print)
  * [Discussion](/w/index.php?title=Talk:Using_Firefox/Print&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Using_Firefox/Print&stable=1)
  * [Latest draft](/w/index.php?title=Using_Firefox/Print&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Using_Firefox/Print&action=edit)
  * [View history](/w/index.php?title=Using_Firefox/Print&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Using_Firefox/Print)
  * [Related changes](/wiki/Special:RecentChangesLinked/Using_Firefox/Print)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Using_Firefox/Print&oldid=2502696)
  * [Page information](/w/index.php?title=Using_Firefox/Print&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Using_Firefox%2FPrint&id=2502696)

### In other languages

  * [Français](//fr.wikibooks.org/wiki/Firefox/Introduction)
  * [Italiano](//it.wikibooks.org/wiki/Mozilla_Firefox/Introduzione)
  * [Nederlands](//nl.wikibooks.org/wiki/Firefox/Sneltoetsen)
  * [Español](//es.wikibooks.org/wiki/Mozilla_Firefox/Texto_completo)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Using+Firefox%2FPrint)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Using+Firefox%2FPrint&oldid=2502696&writer=rl)
  * [Printable version](/w/index.php?title=Using_Firefox/Print&printable=yes)

  * This page was last modified on 17 March 2013, at 07:26.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Using_Firefox/Print)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
