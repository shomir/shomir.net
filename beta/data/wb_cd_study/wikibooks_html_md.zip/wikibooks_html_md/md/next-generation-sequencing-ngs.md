# Next Generation Sequencing (NGS)/Print version

From Wikibooks, open books for an open world

< [Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Next_Generation_Sequencing_\(NGS\)/Print_version) on _27 October 2012_. There is [1 pending change](//en.wikibooks.org/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&oldid=2428819&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

→

## Contents

  * 1 Introduction
    * 1.1 Introduction
      * 1.1.1 Platforms and Technologies
      * 1.1.2 File format and terminology
        * 1.1.2.1 FASTA
        * 1.1.2.2 FASTQ
        * 1.1.2.3 SFF
        * 1.1.2.4 SAM/BAM
        * 1.1.2.5 FASTG
        * 1.1.2.6 VCF
        * 1.1.2.7 Read lengths
        * 1.1.2.8 Paired-/Single-ends
        * 1.1.2.9 Mate-pairs
        * 1.1.2.10 Colorspace?
        * 1.1.2.11 Quality scores
        * 1.1.2.12 Error profiles & Sequencing biases
      * 1.1.3 Uses of NGS
        * 1.1.3.1 DNA
        * 1.1.3.2 RNA
        * 1.1.3.3 ChIP
        * 1.1.3.4 Chromatin structure
      * 1.1.4 General NGS Workflow Overview
    * 1.2 References
  * 2 Big Data
    * 2.1 Big Data
      * 2.1.1 Data Deluge
      * 2.1.2 Storing data
      * 2.1.3 Moving data
      * 2.1.4 Externalizing compute requirements from the research group
    * 2.2 References
  * 3 Bioinformatics from the outside
    * 3.1 Bioinformatics from the outside
      * 3.1.1 Unix command line: History
        * 3.1.1.1 Getting and installing Ubuntu
        * 3.1.1.2 Acclimatisation
        * 3.1.1.3 Fetching the examples
        * 3.1.1.4 Basics
          * 3.1.1.4.1 The command line
          * 3.1.1.4.2 Files and directories
          * 3.1.1.4.3 Commands
        * 3.1.1.5 Reading and writing permission
        * 3.1.1.6 Dealing with multiple files
        * 3.1.1.7 Running multiple programs
        * 3.1.1.8 In, out and pipes
        * 3.1.1.9 Compression
        * 3.1.1.10 Working on remote computers
        * 3.1.1.11 Transferring files
        * 3.1.1.12 Getting help
        * 3.1.1.13 Variables and programming
        * 3.1.1.14 Line endings – compatibility problems
      * 3.1.2 GUIs
        * 3.1.2.1 Galaxy
        * 3.1.2.2 GeneTalk
        * 3.1.2.3 BaseSpace
    * 3.2 References
  * 4 Pre-processing
    * 4.1 Pre-processing
      * 4.1.1 FASTQ files – discussion of the various quality encodings
      * 4.1.2 Presentation of the metrics used in QC
        * 4.1.2.1 Sequence Quality
        * 4.1.2.2 Per Base Sequence Content
        * 4.1.2.3 Adapter sequence present or not?
      * 4.1.3 Intro to errors and quality scores/encoding
      * 4.1.4 Preprocessing Steps
        * 4.1.4.1 Sequence Quality Trimming
        * 4.1.4.2 Alternative clipping strategies (Adaptor clipping)
        * 4.1.4.3 K-mer filtering/correction strategies
        * 4.1.4.4 Digital Normalization and Partitioning
        * 4.1.4.5 Paired end merging
        * 4.1.4.6 Removal of other undesirable sequences
      * 4.1.5 Exercise
        * 4.1.5.1 QC workflow (Data from machine -> pre-trimming quality plots -> trimming -> post-trimming quality plots)
        * 4.1.5.2 The dataset
        * 4.1.5.3 Fastq output analysis
        * 4.1.5.4 Adapter removal only
        * 4.1.5.5 Adapter Removal and quality clipping
        * 4.1.5.6 Read correction
      * 4.1.6 Links to useful tools for preprocessing
        * 4.1.6.1 Links to resources used in this chapter
        * 4.1.6.2 Links to other QC tools e.g. FASTX toolkit and spectral alignment for error correction
  * 5 Alignment
    * 5.1 Introduction
    * 5.2 Short reads
    * 5.3 Alignment
      * 5.3.1 Mapping algorithms
      * 5.3.2 Sources of errors
      * 5.3.3 Alignment types
      * 5.3.4 The SAM/BAM format
        * 5.3.4.1 SAM/BAM tools examples
    * 5.4 Software packages
  * 6 Further Reading Material and References
  * 7 DNA Variants
    * 7.1 DNA Variants
      * 7.1.1 Linking to Wikipedia
      * 7.1.2 Protocols
        * 7.1.2.1 Whole genome, exome, etc. Consequences for downstream analysis
      * 7.1.3 Typical workflow
      * 7.1.4 File formats
        * 7.1.4.1 VCF
      * 7.1.5 Creating a dataset
        * 7.1.5.1 SAMTOOLS
        * 7.1.5.2 others...
      * 7.1.6 Reference datasets
        * 7.1.6.1 Human=> Variants=>1000 genomes, HapMap,etc
        * 7.1.6.2 Other species
      * 7.1.7 Viewing datasets
        * 7.1.7.1 Ensembl
        * 7.1.7.2 UCSC
        * 7.1.7.3 IGV
        * 7.1.7.4 Tablet?
      * 7.1.8 Comparing datasets
        * 7.1.8.1 VCF tools
  * 8 SEQwiki content dump
  * 9 SNP detection
  * 10 Decision Helper
  * 11 Software Packages
    * 11.1 Free Software
      * 11.1.1 Freebayes
      * 11.1.2 GATK
      * 11.1.3 MAQ
      * 11.1.4 samtools
      * 11.1.5 Sibelia
      * 11.1.6 SOAPsnp
      * 11.1.7 SNVMix
    * 11.2 Commercial Software
  * 12 Further Reading Material and References
  * 13 RNA
    * 13.1 RNA
      * 13.1.1 Base space vs Colour space
      * 13.1.2 Paired end/Mate pair reads
      * 13.1.3 Stranded reads
      * 13.1.4 Protocols
      * 13.1.5 Typical workflow
        * 13.1.5.1 Spliced Mapping
        * 13.1.5.2 TopHat
        * 13.1.5.3 GSNAP
        * 13.1.5.4 MapSplice
      * 13.1.6 File formats
        * 13.1.6.1 GFF/GTF
      * 13.1.7 Creating a dataset
        * 13.1.7.1 Cufflinks
        * 13.1.7.2 MISO
        * 13.1.7.3 GSTRUCT
      * 13.1.8 Reference datasets
        * 13.1.8.1 Human
          * 13.1.8.1.1 CCDS
          * 13.1.8.1.2 GENCODE
          * 13.1.8.1.3 HAVANA[1]
          * 13.1.8.1.4 RefSeq[2]
          * 13.1.8.1.5 UCSC genes [3]
      * 13.1.9 Viewing datasets
        * 13.1.9.1 Browsers
      * 13.1.10 Comparing datasets
  * 14 SEQwiki content dump
    * 14.1 What does the data look like?
    * 14.2 What can be done with RNASeq data
      * 14.2.1 Calling DE genes
        * 14.2.1.1 Counting/summarizing reads
        * 14.2.1.2 Statistical Analysis
      * 14.2.2 Differential exon usage
      * 14.2.3 Category enrichment (e.g. GO enrichment)
      * 14.2.4 Estimating expression height
      * 14.2.5 Finding novel genes or splice variants
    * 14.3 Quality Control (QC)
    * 14.4 Mapping the reads
      * 14.4.1 Obtaining the reference
      * 14.4.2 Aligning reads to the reference
      * 14.4.3 More complex alignment
        * 14.4.3.1 Exon Junction libraries
        * 14.4.3.2 Further options
    * 14.5 Differential Expression
      * 14.5.1 Summarization of reads
        * 14.5.1.1 Compressing aligned reads using SAMtools
        * 14.5.1.2 Working with BAM files in R
          * 14.5.1.2.1 Fetching gene information
          * 14.5.1.2.2 Summarizing reads in R
          * 14.5.1.2.3 Checking compatibility of annotations and reads
          * 14.5.1.2.4 Counting the number of reads
      * 14.5.2 Differential Expression Testing
        * 14.5.2.1 Normalization
        * 14.5.2.2 Statistical testing
    * 14.6 Gene Set testing (GO)
    * 14.7 Example 1: Differential Expression and GO Term Analysis: Li Prostate cancer data set
      * 14.7.1 Description
      * 14.7.2 Quality Control
      * 14.7.3 Sequence alignment
        * 14.7.3.1 Building the reference
        * 14.7.3.2 Aligning the reads
      * 14.7.4 Summarization of reads
        * 14.7.4.1 Converting to BAM
        * 14.7.4.2 Processing in R
      * 14.7.5 Differential Expression testing
        * 14.7.5.1 Normalization
        * 14.7.5.2 Statistical Test
      * 14.7.6 Gene Ontology testing
  * 15 Example 2 Differential Expression: Di Arabidopsis pathogen data
    * 15.1 Quality Control
    * 15.2 Mapping Reads
    * 15.3 Summarizing Reads
    * 15.4 Analysis of differentially expressed genes
    * 15.5 References
  * 16 Epigenetics
    * 16.1 Epigenetics
      * 16.1.1 Protocols
      * 16.1.2 Typical workflow
      * 16.1.3 File formats
      * 16.1.4 Creating a dataset
      * 16.1.5 Reference datasets
      * 16.1.6 Viewing datasets
      * 16.1.7 Comparing datasets
  * 17 Chromatin structure
    * 17.1 Chromatin structure
      * 17.1.1 Protocols
      * 17.1.2 Typical workflow
      * 17.1.3 File formats
      * 17.1.4 Creating a dataset
      * 17.1.5 Reference datasets
      * 17.1.6 Viewing datasets
      * 17.1.7 Comparing datasets
  * 18 De novo assembly
    * 18.1 De novo assembly
      * 18.1.1 Typical workflow
        * 18.1.1.1 Experiment design
        * 18.1.1.2 Data pre-processing
        * 18.1.1.3 Genome assembly
        * 18.1.1.4 Post-assembly analysis
      * 18.1.2 Creating a dataset
        * 18.1.2.1 Free Software
          * 18.1.2.1.1 ABySS
          * 18.1.2.1.2 Allpaths-LG
          * 18.1.2.1.3 Euler SR USR
          * 18.1.2.1.4 MIRA
          * 18.1.2.1.5 Ray
          * 18.1.2.1.6 SOAP de novo
          * 18.1.2.1.7 SPAdes
          * 18.1.2.1.8 Velvet
          * 18.1.2.1.9 Minia
        * 18.1.2.2 Commercial
          * 18.1.2.2.1 CLC cell
          * 18.1.2.2.2 Newbler
      * 18.1.3 Decision Helper
    * 18.2 Case study
  * 19 Further Reading Material and References
    * 19.1 Reference datasets
      * 19.1.1 ENA
      * 19.1.2 SRA
      * 19.1.3 SRA Metadata Model
      * 19.1.4 NCBI
    * 19.2 Viewing datasets
      * 19.2.1 ENSEMBL
      * 19.2.2 UCSC
      * 19.2.3 Tablet
      * 19.2.4 IGV
    * 19.3 Comparing datasets
      * 19.3.1 Whole genome alignments
  * 20 Velvet
    * 20.1 Velvet practical: Part 1
      * 20.1.1 Prepare the environment
      * 20.1.2 Downloading and Compile Velvet
    * 20.2 Single ended read assembly

# Introduction

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**Introduction**
**[Big Data](/wiki/Next_Generation_Sequencing_\(NGS\)/Big_Data)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Next-generation_sequencing#High-throughput_sequencing**_](//en.wikipedia.org/wiki/Next-generation_sequencing)

## Introduction

### Platforms and Technologies

Employing different technologies, the purpose of NGS platform is to decode the identity or modification on the nucleotides.

NGS platforms evolve quickly. Usually, new technologies & platforms are announced at the Advances in Genome Biology & Technology (AGBT) conference [1]  


For educational purposes, some reviews of NGS platforms published in 2011 [2]. Read more about the sequencing technologies [here](http://en.wikipedia.org/wiki/DNA_sequencing#Illumina_.28Solexa.29_sequencing)

### File format and terminology

#### FASTA

The FASTA format, generally indicated with the suffix .fa or .fasta, is a straightforward, human readable format. Normally, each file consists of a set of sequences, where each sequence is represented by a one line header, starting with the '>' character, followed by the corresponding nucleotide sequence, in **multiple lines** of regular width (generally 60 or 80 characters wide). In practice, some tools may produce a sequence with a header and a **single long line** of sequence. For more detailed information see the [FASTA](http://en.wikipedia.org/wiki/FASTA) Wikipedia page.

#### FASTQ

FASTQ files are text file formats (human readable) providing a 4-lines entries per sequence.

  1. Sequence identifier
  2. The sequence
  3. Comments
  4. Quality scores

FASTQ format is commonly used to store sequencing reads, in particular from Illumina and Ion Torrent platforms.

Paired-end reads may be stored either in one FASTQ file (alternating) or in two different FASTQ files. Paired-end reads may have sequence identifiers ended by "/1" and "/2" respectively.

Example FASTQ entry for one Illumina read:
    
    
    @EAS20_8_6_1_3_1914/1
    CGCGTAACAAAAGTGTCTATAATCACGGCAGAAAAGTCCACATTGATTATTTGCACGGCGTCACACTTTGCTATGCCATAGCATTTTTATCCATAAGATT
    +
    HHHHHHHHHFHGGHHHHHHHHHHHHHHHHHHHHEHHHHHHHHHHHHHHGHHHGHHHGHIHHHHHHHHHHHHHHHGCHHHHFHHHHHHHGGGCFHBFBCCF
    

Generally a FASTQ file is stored in files with the suffix .fq or .fastq using [Gzip](http://en.wikipedia.org/wiki/Gzip) file compression indicated by the suffix .gz or .gzip.

For more detailed information see the [FASTQ](http://en.wikipedia.org/wiki/FASTQ_format) Wikipedia page.

#### SFF

SFF is a binary file format used to encode sequencing reads from the 454 platform.

<http://en.wikipedia.org/wiki/Standard_Flowgram_Format>

#### SAM/BAM

File formats used to encode short reads alignment. See [Next_Generation_Sequencing_(NGS)/Alignment](/wiki/Next_Generation_Sequencing_\(NGS\)/Alignment) for more information.

#### FASTG

[FASTG](http://fastg.sourceforge.net/) is an emerging file format for genome assemblies that take ambiguities into account. FASTG is like FASTA, but the G stands for ‘graph’.

#### VCF

The Variant Call Format (VCF) is a specification used in bioinformatics for storing gene sequence variations. See [[1]](http://en.wikipedia.org/wiki/Variant_Call_Format) for more information.

#### Read lengths

As of Feb 2013, the read-length of second generation sequencing platforms are shorter than conventional Sanger sequencing, creating challenges in reads mapping and assembly.

  * The most well used Illumina platforms can produce read-length up to **250bp**. In practice, ~**100bp** is mostly accessible to researchers worldwide.
  * [Ion Torrent](http://en.wikipedia.org/wiki/Ion_semiconductor_sequencing): Varies, typically peak at **400bp**
  * SOLiD: **50-75bp**

#### Paired-/Single-ends

  * _Single-end_ reads means the sequence fragment are sequenced from 1 direction only.
  * In _paired-end_ sequencing, a single fragment are sequenced from both 5' and 3' end, giving rise to forward and reverse read. The sequenced fragments could be separated by a certain bases (inner insert size) or can be overlapping, giving rise to a contiguous longer single-end fragment after merging. The uses of paired-end reads can improve the accuracy of reads mapping onto a reference genome. The typical fragment size (external inserts size) is **200bp** to **500bp**

#### Mate-pairs

_Mate-pair_ is different from _paired-end"_ in the sense of how the sequence library is made. In "Mate-pair" sequencing, **2-5kb** fragments are selected and sequenced from both end, thus giving information how nucleotides far apart are linked together. Mate-pairs are more indeal for studying genomic structural rearrangement and help de novo genome assembly.

#### Colorspace?

Colorspace is a [2-base encoding system](http://marketing.appliedbiosystems.com/images/Product_Microsites/Solid_Knowledge_MS/pdf/CSHL_Fu.pdf) commercialized by Life Tech and used in SOLiD platforms. Technology overview is described [here](http://seqanswers.com/forums/showthread.php?t=10)

#### Quality scores

Quality score is a indication of probability of the base call being incorrect. Quality score is used in the FASTQ format.

Various encoding schemes are available, including most common [[Phred quality scores](http://en.wikipedia.org/wiki/Phred_quality_score)].

#### Error profiles & Sequencing biases

### Uses of NGS

#### DNA

#### RNA

#### ChIP

#### Chromatin structure

### General NGS Workflow Overview

## References

  1. ↑ <http://agbt.org/>
  2. ↑ <http://www.ncbi.nlm.nih.gov/pubmed/21612267>

  


# Big Data

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[Introduction](/wiki/Next_Generation_Sequencing_\(NGS\)/Introduction)**
**Big Data**
**[Bioinformatics from the outside](/wiki/Next_Generation_Sequencing_\(NGS\)/Bioinformatics_from_the_outside)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Big_data**_](//en.wikipedia.org/wiki/Big_data)

## Big Data

### Data Deluge

The first problem you face is probably the large size of the NGS FASTQ files - the "data deluge" problem. You no longer only have to deal with microplate readings, or digitalized gel photos; the size of NGS data can be huge. For example, compressed FASTQ files from a 60x human whole genome sequencing can still require 200Gb. A small project with 10 - 20 whole genome sequencing (WGS) samples can generate ~4TB of raw data. Even these estimates do not include the disk space required for downstream analysis.

### Storing data

Referenced from a post from BioStar[1]:

  * Very high end: enterprise cluster and SAN.
  * High end: Two mirrored servers in separate buildings or Cloud.
  * Typical: External hard drives and/or NAS with raid-5/6

### Moving data

Moving data between collaborators is also non-trivial. For RNA-Seq samples, FTP may suffice, but for WGS data, shipping hard drives may be the only solution.

### Externalizing compute requirements from the research group

It is difficult for a single lab to maintain sufficient computing facilities. A single lab will probably own some basic computing hardware; however, many tasks will have huge computational demands (e.g. memory for de novo genome assembly) that require the them to be performed elsewhere. Your institution / core facility may host a centralized cluster. Alternatively, you might consider doing the task on the cloud.

  * NIH maintains a centralized computing cluster **[Biowulf](http://biowulf.nih.gov/)**
  * Bioinformatics cloud computing is suggested [2] [3]. EBI has adopted a cloud based platform **Helix Nebula** [4]

## References

  1. ↑ <http://agbt.org/>
  2. ↑ <http://www.ncbi.nlm.nih.gov/pubmed/21612267>

  


# Bioinformatics from the outside

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[Big Data](/wiki/Next_Generation_Sequencing_\(NGS\)/Big_Data)**
**Bioinformatics from the outside**
**[Pre-processing](/wiki/Next_Generation_Sequencing_\(NGS\)/Pre-processing)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Bioinformatics**_](//en.wikipedia.org/wiki/Bioinformatics)

## Bioinformatics from the outside

    _For an in-depth introduction to UNIX, see the [Guide to Unix](/wiki/Guide_to_Unix) or [A Quick Introduction to Unix](/wiki/A_Quick_Introduction_to_Unix)._

### Unix command line: History

The first version of Unix was developed by Bell Labs (part of AT&T) in 1969, making it more than forty years old. Its roots go back to when computers were large and rare, time on them very expensive and shared between many users. Unix was developed so as to allow multiple users to work simultaneously. Unix actually grew out of a desire to play a game called [Space Travel](//en.wikipedia.org/wiki/Space_Travel_\(video_game\)) and the features that made it an operating system were incidental. Initially it only supported one user and the name Unix, originally UNICS, is a pun on MULTICS, a multi-user system available at the time.

While this might seem strange and unnecessary in a world where everyone has their own laptop, computing is again moving back to remote central services with many users. The compute power required for mapping **next-generation** sequencing **data or** de novo assembly **is beyond what is available or** desirable to have sitting on your lap. In many ways, the “cloud” (or whatever has replaced it by the time you read this) requires ways of working that have more in common with traditional Unix machines than the personal computing emphasised by Windows and Apple Macintosh.

USA federal monopoly law prevented AT&T from commercialising Unix but interest in using it increased outside of Bell Labs and eventually they decided to give it away freely, including the source code, which allowed other institutions to modify it. Perhaps the most important of these institutions was the University of Berkeley. (A significant proportion of Mac OS X has its roots in the Berkeley Standard Distribution (BSD) that distributed a set of tools to make Unix more useful and made changes that significantly increased performance.) The involvement of several universities in its development meant Unix was ideally placed when the internet was created and many of the fundamental technologies were developed and tested using Unix machines. Again, these improvements were given away freely. Some of the code was repurposed to provide networking for early versions of Windows and even today several utilities in Windows Vista incorporate Berkeley code.

As well as being a key part in the development of the early internet, a Unix machine was also the first web server, a [NeXT cube](//en.wikipedia.org/wiki/NeXT). NeXT was an early attempt to make a Unix machine for desktop use. Extremely advanced for its time but also very expensive, it never really caught on outside of the finance industry. Apple eventually bought NeXT, its operating system becoming OS X, and this heritage can still be seen in its programming interfaces. Apple is now the largest manufacturer of Unix machines; every Apple computer, the iPhone, and most recent iPods have a Unix base underneath their facade.

By the early 90s Unix became increasingly commercially important. This inevitably lead to legal trouble: with so many people giving away improvements freely and having them integrated into the system, who actually owned it? The legal trouble cast uncertainty over the freely available Unix versions, creating an opening for another free operating system.

The vacuum was filled by Linux, a freely available computer operating system similar to Unix started by Linus Torvalds in 1991 as a hobby. More correctly, Linux is just the kernel, the central program from which all others are run. Many more tools in addition to this are required to make an operating system. These tools are provided by the GNU project.[5]

Importantly, Linux was written from scratch and did not contain any of the original Unix code and so was free of legal doubt. Coinciding with the penetration of the internet onto university campuses, and the availability of cheap but sufficiently powerful personal computers, Linux rapidly matured with over one hundred developers collaborating over the internet within two years. The real advances driving Linux were social rather than technological, disparate volunteers donating time on the understanding that, in return for giving their work away freely, anything based on their work is also given away freely and so they in turn benefit from improvements.

The idea that underpins this sharing and ensures that nobody can profit from anyone else's work without sharing is “copyleft”, described in a simple legal document called the GNU General Public Licence,[6] which turns the notion of copyright on its head. (It should be noted that the GNU project, and the philosophy behind it, predate Linux by almost a decade.) Today, Linux has become the dominant free Unix-like operating system with millions of users and support from many large companies.

#### Getting and installing Ubuntu

Here we describe the Ubuntu distribution (packaging) of Linux, which is one of the most widely used, but all the examples are fairly generic and should work with most Linux, Unix, and Mac OS X computers. There are many different guides on the web about how to install Ubuntu but we recommend installing it as a virtual machine on your current computer.

The Ubuntu Linux distribution is generally easy to use and it is updated (for free) every six months. The examples and versions used here are for version of Ubuntu is 11.10, named after its release date in October 2011, and also known as “Oneiric Ocelot”; the next (most current) version, 12.04 or “Precise Pangolin” was released in April 2012 and is designated a Long Term Support (LTS) edition, meaning that it will be receive fixes and maintenance upgrades for five years before being retired, and is the best option if you don't want to be regularly upgrading your system.

#### Acclimatisation

A significant effort has been undertaken to make Ubuntu easy to use, so even novice computer users should have little trouble using it. There are quite a few tutorials available for users new to [Ubuntu](//en.wikipedia.org/wiki/Ubuntu). The official material is available[7] but a quick search on the web will locate much more. In addition, there is a lot of documentation installed on the machine itself. You can access this by moving the mouse towards Ubuntu Desktop at the top left of the screen and clicking on the help menu that appears. In general, the name of the program you are currently using is displayed at the top-left of the screen and moving the mouse to top of the screen will reveal the programs menus in a similar fashion to how they are displayed on the Mac (although, confusingly, some programs display their menus within their own window rather like a Windows computer).

An alternative way to get help is to click on the circular symbol (a stylised picture of three people holding hands) at the top left of the screen and type help in the search box that appears. For want of a better name, we will refer to the people-holding-hands button as the Ubuntu button although the help text that appears describes it as “Dash home”.

Ubuntu comes free with many tools, including web browsers, file managers, word processors, etc. There are free equivalents available for most of the everyday software people use, and you can browse what is available by clicking on the Ubuntu Software Centre, whose icon at the left of the screen looks like a paper shopping bag full of goodies. The Ubuntu Software Centre is just a starting point and there are many other sources available, both of prepackaged software specifically for Ubuntu, and source code that will require compiling. Search the web for “Ubuntu software repositories” for more information on obtaining additional software.

While there are explicit key combinations for copy and pasting text, just like on Windows or Mac, control-c and control-v in Ubuntu, this convention is not respected by all programs. Unix has traditionally been more mouse centred with the left mouse button used to highlight text and the middle button used to copy it. You may find yourself accidentally doing this occasionally if you are not used to using the middle mouse button. Starting applications from icons, opening folders, etc... only requires a single click, rather than the double click required on Windows, making the action of pressing buttons and selecting things from menus more consistent with each other. Accidentally double clicking will generally result in an action being done twice, not normally a bad thing but it does mean that impatient users can quickly find their desktop covered in windows.

Perhaps the most important difference you are likely to encounter on a daily basis is that the names of files and directories are case sensitive: README.txt, readme.txt and readme.TXT all refer to different files. This is different from both Windows and Mac OS X, where upper and lower-case characters are preserved in the name but the file can be referred to using any case. (Despite the Unix heritage of OS X, Apple chose this behaviour to maintain compatibility with earlier versions of the Mac operating system)

#### Fetching the examples

There are many examples in this tutorial to be tried, enclosed in boxes like the one below, which explains the format of the examples. The example below shows how to automatically download and unpack the file ready for use.

![](//upload.wikimedia.org/wikipedia/commons/9/9d/Wiki_NGS_Unix_one.JPG)

Figure 1: Example of how to automatically download and unpack a file

#### Basics

##### The command line

While Ubuntu has all the graphical tools you might expect in a modern operating system, so new users rarely need to deal with its Unix foundations, we will be working with the command-line. An obvious question is, why is the command-line still the main way of interacting with Unix or, more relevantly, why we are making you use it? Part of the answer to the first question is that the origins of Unix predate the development of graphical interfaces and this is what all the tools and programs have evolved from. The reason the command-line remains popular is that it is an extremely efficient way to interact with the computer: once you want to do something complex enough that there isn't a handy button for it, graphical interfaces force you to go through many menus and manually perform a task that could have been automated. Alternatively, you must resort to some form of programming (Mac OS X Automator, Microsoft Office macros, etc) which is the functional equivalent of using the command line.

Unix is built around many little tools designed to work together. Each program does one task and returns its output in a form easily understood by other programs. These properties allow simple programs to be combined together to produce complex results, rather like building something out of Lego bricks. The forward to the 1978 report in the Bell System Technical Journal[8] describes the Unix philosophy as:

"(i) Make each program do one thing well. To do a new job, build afresh rather than complicate old programs by adding new features.

(ii) Expect the output of every program to become the input to another, as yet unknown, program. Don't clutter output with extraneous information. Avoid stringently columnar or binary input formats. Don't insist on interactive input.

(iii) Design and build software, even operating systems, to be tried early, ideally within weeks. Don't hesitate to throw away the clumsy parts and rebuild them.

(iv) Use tools in preference to unskilled help to lighten a programming task, even if you have to detour to build the tools and expect to throw some of them out after you've finished using them."

The rest of this tutorial will be based using the command-line through a “terminal”. This terminology dates back to the early days of Unix when there would be many “terminals”, basically a simple screen and keyboard, connected to a central computer. The terminal program can be found by clicking on the Ubuntu button and typing terminal in the search box, as shown in Illustration 1. You can also easily access the terminal using just the keyboard, by pressing control-alt-T. Once open, the text size can be changed using the View/Zoom menu options or the font changed entirely using the Edit/Profile Preferences menu option.

While we are using Linux during the workshop, you may not have access to a machine later or may not wish to use Linux exclusively on your computer. While you could install Linux as 'dual-boot' on your computer, or run it in a virtual machine (A Virtual Machine (VM) is a program on your computer that acts like another computer and can run other operating systems. Several VM's are available, VirtualBox <http://www.virtualbox.org/> is free and regularly updated), the knowledge of the command-line is fairly transferable between platforms. Mac OS X also has a command-line hidden away (/Applications/Utilities/Terminal) and, with a small number of eccentricities, everything that works on the Linux command-line should work for OS X. Windows has its own incompatible version of a command-line but Cygwin <http://www.cygwin.com/> can be installed and provides an entire Unix-like environment within Windows.

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/13/Wiki_NGS_Unix_two.JPG/220px-Wiki_NGS_Unix_two.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Figure 2: Opening a terminal in Ubuntu. A partially obscured terminal is shown at the bottom right of the desktop

At the beginning of the command-line is the command prompt, showing that the computer is ready to accept commands. The prompt is text of the form **user@computer:directory$**. Figure 2 has a user called tim in the directory ~ on a computer called coffee-grinder. Having all this information is handy when you are working with multiple remote computers at the same time. The prompt is configurable and may vary between computers; you may notice later that other prompts are slightly different. Some basic commands are shown in Table 1; try typing them at the command-line and press return after the command to tell the computer to run the command.

![](//upload.wikimedia.org/wikipedia/commons/8/8e/Wiki_NGS_Unix_three.JPG)

Figure 3: Some basic commands to answer the important questions of life: "whom am I?", "where am I?" and "what operting system am I running?"

##### Files and directories

All files in Unix are arranged in a tree-like structure: directories are represented as branches leading from a single trunk (the “root”) and may, in turn, have other branches leading from them (directories inside directories) and individual files are the leaves of the tree. The tree structure is similar to that of every other common operating system and most file browsers can display the filesystem in a tree-like fashion, for example: part of the filesystem for an Ubuntu Linux computer is displayed in Figure 4.

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Wiki_NGS_Unix_four.JPG/220px-Wiki_NGS_Unix_four.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Figure 4: Tree-like structure of the Ubuntu filesystem. Home/Tim directories have been open to show its contents (illustrative purpose)

Where Unix differs from other operating systems is that the _filesystem is used much more for organising different types of files_. The essential system programs are all in **/bin** and their shared code (libraries) are in **/lib**; similarly user programs are in**/usr/bin**, with libraries in **/usr/lib** and manual pages in **/usr/share/man**.

There are two different ways of specifying the location of a file or directory in the tree: the absolute path and the relative path from where we currently are in the filesystem (the current working directory). An absolute path is one that starts at the root and does not depend on the location of the current working directory. Starting with a / to signify the root, the absolute path describes all the directories (branches) we must follow to get to the file in question. each directory name is separated by a /.

For example, home/user/Music/TheKinks/SunnyAfternoon.mp3 refers to the file SunnyAfternoon.mp3 inside the directory TheKinks, which is inside the directory Music, which is inside the user's directory, which is inside on the directory home, which is connected to the root. If you are familiar with Microsoft Windows, you might notice that the path separator is different. Unix-based systems use a forward-slash (/) rather than the backward-slash (\\) used on Windows. You may have noticed that the paths of web pages are also separated by forward-slashes, revealing their Unix origins as a path to a file on a remote machine.

For convenience, a few directories have special symbols that are synonyms for them and the most common of these are listed in Figure 5. Most of these have a special meaning when at the beginning of a path otherwise they are just a symbol. For example **dir/~/** is the directory **~** inside the directory **dir** in the current directory, whereas **~/dir/** is the directory **dir** inside the home directory (usually /home/user on Linux, /Users/user on Mac OS X). In both cases the '**/'** symbols are separators rather than the root directory.

![](//upload.wikimedia.org/wikipedia/commons/7/79/Wiki_NGS_Unix_five.JPG)

Figure 5: Special directory names

The current location, the working directory, can be displayed at the command-line using the pwd command. Rather than referring to a file by its absolute path, we can refer it by using a path relative to where we are: a file in the current directory can be referred to by its name, a file in a directory inside our working directory can be referred to by directory/filename (and so on for files inside of directories inside of directories inside of our working directory, etc...). Note that these paths are very similar to how we describe absolute paths except that they do not start with /; absolute paths are relative paths relative to the root (alternatively we could read the initial / as “goto root” and consider them to be relative paths). As shown in Figure 5, the directory above the current directory can be referred to as .. so, if the working directory is /home/user, then the root directory can be referred to as ../.. (go up one directory, then go up another directory). The symbol .. can be freely mixed into paths: the directory examples below the current directory could have path examples/../examples/../examples (needless to say, simply using just examples is recommended).

##### Commands

Commands are just programs elsewhere on the computer and entering their name on the command-line runs them. Commands have a predicable format:

**command -flags target**

The command is the name of the program to run, the (optional) flags modify its behaviour and the target is what the command is to operate on, often the name of a file. Many commands require neither flags nor target but Unix tools are generally extremely configurable and even simple commands like date (some utilities also have parodies, see **ddate** or **sl** for example) have many optional flags to change the format of their output.

As mentioned in Files and directories, there are special directories to contain executable programs and programs within them can be run by typing their name at the command-line. The reason you can run the programs in these directories simply by typing their names is that the operating system knows to look in those directories for programs. In general you will not have permission to place files in these directories and experienced Unix users create their own, normally **~/bin/** ,to place programs they use frequently. Creating this directory does not make it special; you still have to tell the operating system to go look for programs there as well. The operating system has a variable, **$PATH**, which is a list of directories in which the computer looks for programs. To add a directory to that list, use the command "export **PATH=~/bin:$PATH**" where "~/bin" is the directory you want to add. This command is often added to the file **~/.bashrc**, which is a list of commands to be run automatically every time a new terminal is opened. If a program is not in a special directory, you cannot run it just by typing its name because the computer doesn't know where to find it. This is true even if the program is in the current directory. Programs which are not in special directories can still be run, but you have to include the path to where it can be found. If the program is in your current working directory, this can be as simple as typing ./program (program is in current directory). If the program is elsewhere just type the absolute or relative path to were it is. You can always use the command-line's autocompletion features (see “tab-completion” below) to reduce the amount of typing needed. In order to allevite the need to type paths to commonly-used programs, it is a good idea to add their paths to the **PATH** variable in ~/.bashrc.

One thing you'll quickly discover is that the mouse does not move the cursor in the terminal. The terminal interface predates the popularity of mice by decades and alternative methods of efficiently moving around and editing have been developed. There are keyboard short-cuts defined for most common operations, and a few of these are listed in Figure 6. Probably the most useful shortcut is the tab key. It can be used to complete command names and paths in the filesystem (called 'tab-completion'). Pressing tab once will complete a path up to the first ambiguity encountered and pressing again gives a list of possible completions (you can type the next letter or so of the one you want and press tab again to attempt further auto-completion).

![](//upload.wikimedia.org/wikipedia/commons/d/d5/Wiki_NGS_Unix_six.JPG)

Figure 6: Common key bindings for moving around command-line

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Wiki_NGS_Unix_seven.JPG/220px-Wiki_NGS_Unix_seven.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Figure 7: commands for manipulationg files

A record is kept of the commands you have entered, and the **history** command can be used to list them so you can refer back to what you did earlier. The history can also be searched: Control-r starts a search and the computer will match against your history as you type; typing enter accepts the current line, typing Control-r again goes to the next match and Control-g cancels the search. History can also be referred to by entry number, listed using the **history** command: entering !n on the command-line will repeat history entry n, entering !! will repeat the last command.

There are many commands, often quite terse, for manipulating files and a few of the more useful of these are shown in Table 4. Many of the commands for Unix have short names, often only two or three letters, so errors typing can easily have unintended and severe consequences! Be careful what you enter, because Unix rarely gives you a second chance to correct mistakes. Some Unix machines have the **sl** command to encourage accurate typing.

Figure 7 shows few commands for manipulating files and brief explanations.

On the Unix command line, some symbols can have special meanings. A slash, '/', indicates the end of a directory name, an asterisk, '*' is a wildcard, etc. However, there are many circumstances when it is preferable for symbols not to have a special meaning, the most common example being when the file name contains a space (a space is a special character in the sense that it is interpreted as a break between command-line options). The character in question can be “escaped” by prefixing it with a '\' to remove its special meaning so, for example: / is the root directory but \/ is a file called '/'.

Files beginning with a . character are hidden by default and will not appear in the output of ls or equivalent (or in the file browser when you're using a graphical user interface). Generally, hidden files are those used directly by the computer or programs, containing configuration information not intended for the average user to understand or use.

#### Reading and writing permission

All files and directories have a set of permissions associated with them, describing who is allowed to read or write that file. There are three basic permissions: read **r**, write **w**, and execute **x**. The meanings of read and write are fairly obvious, but execute has two meanings depending on context. For normal files, execute permission is used on files with executable code (i.e. programs) to give users permission to run that program. For a directory, **x** permission allows a user to open that directory and see the files it contains. There are three categories of user: owner **u** (generally the user who created the file), group **g** (the group of users that the owner belongs to), and other **o** (everyone else). The permissions for each file are described as a string of nine characters, three for each user category. The three positions assigned to each user category correspond to the three types of permissions ('_r**,**w_, and **x**, in that order). If that user category has a given permission, the appropriate letter will appear. If not, the letter will be replaced with a dash '-'. For example, if a user category has permission to read and execute a file, but not write it, their triplet will look like **r-x**. The permission string **rwxr-x---** means that the owner has permission to read, write or execute, users in the same group have read and execute permission and other users have no permissions.

The owner of a file can change its permissions. Some programs will do this automatically if they are being run by the file's owner, giving the impression that the permissions have been ignored. Running **rm -f** is the most common time a user will run into this behaviour: by default **rm** will prompt to remove write-protected files (i.e. files you don't have permission to write) but the **-f** (force) flag turns tells it not to bother asking and just remove the file.

#### Dealing with multiple files

Often, especially when running scripts or organising files, you will need to be dealing with multiple files at once. Rather than typing each file name out explicitly, we can give the computer a pattern instead of a filename. All filenames are checked against the pattern and the computer automatically generates a list of all the matching files to use when running the command. Patterns are created using symbols that have a special meaning. For example: ***** means match anything (or nothing), so **a*b** is a pattern that matches any filename beginning with a and ending with **b** including the file **ab**. Figure 8 contains a list of special symbols useful for constructing patterns.

![](//upload.wikimedia.org/wikipedia/commons/f/f8/Wiki_NGS_Unix_eight.JPG)

Figure 8: Special symbols for filenames. As with the \\* example in the table, any of these symbols can be prevented from having a special meaning by “escaping” them with a '\'.

As mentioned above, pattern matching occurs before a command is run and the pattern is replaced by the list of matches. The command never sees the pattern, just the results of the match.

#### Running multiple programs

From early on in its development, Unix was designed to run multiple programs simultaneously on remote machines and support for this is integrated into the command-line. Jobs (scripts, programs, or other fairly self-contained things running from the command line) can be divided into two types, foreground jobs and background jobs, based on how they affect the terminal. A foreground job temporarily replaces the command-line and you cannot enter new commands until it has finished, whereas a background job runs independently and allows you to continue with other tasks. Only foreground jobs receive input from the keyboard, so interactive programs like PAUP* should be run as foreground (although you could set up a compute intensive analysis, background it and continue with other tasks while it is running. Later, when the calculations have finished, the program can be made foreground again so interaction can continue). Although background jobs leave your command-line mostly free to do other things, they do send their output to the terminal you launched them from, so you might see it popping up in the middle of another task, which can be confusing. If you are running multiple background jobs, their output will be interleaved based on when it was produced, with no indication of which program produced the output.

  


![](//upload.wikimedia.org/wikipedia/commons/6/6d/Wiki_NGS_Unix_nine.JPG)

Figure 9: A few commands and key combinations for job control

As hinted in Figure 9, there is a difference between a job and a process. A process is a single program running on the machine, and each process is uniquely numbered with a pid (process ID). You can list all the processes you are running, including the command-line itself (generally called bash, but in some unix distributions it may be zsh or tcsh) using ps (or ps -a if you want to see what all the other users of the machine are doing). The command-line itself is just a process (program) running on the computer, albeit one specially designed for starting, stopping and manipulating other processes. Processes are the fundamental method of keeping track of what is running on the computer. Jobs, on the other hand, are things entered on the command-line and many include several programs logically connected together by pipes (see In, out and pipes

for details) to achieve a task.

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/de/Wiki_NGS_Unix_ten.JPG/220px-Wiki_NGS_Unix_ten.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Figure 10: The command-line splits the jobs into several processes

The command-line

splits the jobs into several processes and runs them, possibly simultaneously. See illustrative example in Figure 10.

#### In, out and pipes

Where possible, Unix commands behave sort of like filters, or the mathematical concept of a function: they read from input, manipulate that input, and write the output. This might sound trivial, tautologous even, but it enables simple commands to be combined to produce complex results. Every command reads from stdin (short for standard in) and writes to stdout (short for standard out). By default stdin is whatever gets typed in the terminal from and keyboard, and stdout is connected to the current command-line, so results are displayed on the screen. stdout can easily be redirected to a file instead by using the greater-than operator, >. **> filename** redirects stdout to the file specified for later perusal. By chaining many simple commands together, complex transformations of the input can be achieved. The following is an advanced example, showing how a complex output can be achieved using a series of smaller steps. You may not yet have sufficient understanding of the shell to follow everything in this example but try to work through it and see what each step is doing. The man pages for each command (see Getting help) might be useful.

#### Compression

The aim of compression is to make files smaller, which is useful for both saving disk space and making it quicker to send files over the internet. Some types of programs that send data over the internet have the ability to transparently compress files before sending and uncompress at the other end. Some web servers implement this but the most important example for us are scp and sftp (two command-line programs used to transfer files over networks) which can each be given the -C option to request compression.

Simply put, compression programs look for frequently repeated patterns in the file and remove this redundancy in a manner that can be undone later. Text files tend to compress very well, with 100MB worth of Wikipedia being compressable into less than 16MB (See The Hutter prize <http://prize.hutter1.net/>), and, in particular, biological sequences tend to be very compressible since the size of the alphabet of nucleotides or amino acids is small.

The two most common tools for compressing files are **gzip** and **bzip2**, with their respective tools for uncompressing being **gunzip** and **bunzip2**. **gzip** is the de-facto standard; **bzip2** tends to produce smaller files but takes longer to compress them. On the Windows platform, the Zip (often known as WinZip (<http://www.winzip.com/>)) compression method is favoured and many Unix platforms provide **zip** and **unzip** tools to deal with these files. Non-Linux Unix platforms, like Mac OS X for example, have older tools called **compress** and **uncompress** that are rarely used any more. Support for **compress** 'd files on Linux can be patchy and unreliable. For example, a machine one author has access to has a compress manual page but no actual tool installed.

A final method to be aware of, that is becoming more popular, is 7-zip (**7za**). 7-zip can produce smaller files than all the above methods, again at the expense of taking longer to compress. A list of file suffixes that can be used to identify what files are compressed using what method is provided in Figure 11.

![](//upload.wikimedia.org/wikipedia/commons/9/99/Wiki_NGS_Unix_eleven.JPG)

Figure 11: List of suffice useful to ientify what files are compressed

Compression works better if files are combined and then compressed together, rather than compressing them individually, since this allows the compression program to spot repeated patterns between the files. On Unix, the process of packing/unpacking several files into / from a single file has been historically separate from the process of the compression, in keeping with the philosophy of having little tools that do one thing well. The Unix tool for packing and unpacking files is tar “Tape Archiver”, the odd name because its heritage goes back to 1979 when writing files to magnetic tape was a common method of storage.

Below is an example of using tar to compress and then extract files in an archive:
    
    
    **ls**
    chimp.fasta human.fasta macaque.fasta orangutan.fasta
    # Pack into single file. The suffix is your responsibility. ** 'c' ** means create, and
    #'f' means that the next argument is the filename to write to.
    **tar -cf sequences.tar *.fasta**
    Note that the original files are untouched
    
    **ls**
    chimp.fasta human.fasta macaque.fasta orangutan.fasta sequences.tar
    # Delete all sequences
    **rm *.fasta**
    # 'x' means extract
    **tar -xf sequences.tar**
    **ls**
    chimp.fasta human.fasta macaque.fasta orangutan.fasta sequences.tar
    
    

Over time, the features of tar have increased to make it more convenient and modern versions are now capable of packing and compressing files, as in the example above.
    
    
    **ls**
    
    chimp.fasta human.fasta macaque.fasta orangutan.fasta sequences.tar
    # Pack and gzip sequences simultaneously (** 'z' ** tells tar to use gzip)
    **tar -zcf sequences.tgz *.fasta**
    #List the contents without extracting
    **tar -ztf sequences.tgz**
    chimp.fasta
    human.fasta
    macaque.fasta
    orangutan.fasta
    # More recent versions of tar can also bzip2 files
    **tar -jcf sequences.tbz2 *.fasta**
    **tar -jtf sequences.tbz2**
    chimp.fasta
    human.fasta
    macaque.fasta
    orangutan.fasta
    

  


![](//upload.wikimedia.org/wikipedia/commons/c/c5/Wiki_NGS_Unix_twelve.JPG)

Figure 12: File suffixes for common compression programs. When combined with tar to compress multiple files, often the full suffix .tar.suffix is shortened to that given above. zip and 7za “7-zip” have a Windows heritage and have built methods to combine multiple files together, so are rarely used in conjunction with tar. The file tool can also be used to determine file type, e.g: file file.unknown.suffix . See man file for details.

Compression and decompression are actually done by the same program. Decompression program names like 'gunzip' are actually just convenient aliases that tell the computer to call the gzip program with the unzipping flags.

#### Working on remote computers

Why use a remote computer? There are many reasons: First, central computing resources tend to be much larger, more reliable and more powerful than your laptop or PC – if you need to do a lot of work or use a lot of data then you may have no option but to use a bigger computer.

There is also a world of difference between server-quality hardware and stuff on your desk. Uninterruptible power supplies, (i.e. backup batteries for when the power goes out) are one example. Servers also tend to have redundant components and memory that can detect and correct errors. At the top end, servers can detect and isolate faulty parts, report the problem, and continue running. Often the first time users of a central server know that a fault occurred is when an engineer turns up with a replacement part.

If you have a job that will take a long time to run, for instance Bayesian phylogenetic methods, you may not want to commit to leaving your personal computer untouched for long enough to complete the analysis (and you really trust your colleagues not to turn it off?) whereas central facilities are permanently on and have batteries to prevent small glitches in the power supply from affecting the computers. Lastly, and most importantly, central computers tend to have much more rigorous and tested policies for backing up data – Do you do regular backups? Are they kept in a separate physical location from the original? When was the last time you checked that the backup actually worked?

SSH (short for Secure SHell) is a method of connecting to other computers and giving access to a command-line on them; once we have a command-line we can interact with the remote computer just like we interact with the local one using the command-line. SSH replaces an older method of connecting to remote computers called telnet, which sends everything – including your password – as normal undisguised text so anyone can read it. It is not a good idea to use telnet unless you know what you are doing and you have no other option. Similarly, avoid FTP `File Transfer Protocol' for transferring files if you have sftp or scp available.

As well as keeping communications between your computer and a remote computer secure, SSH also allows you to verify that the remote computer is the computer it claims to be – no point keeping traffic secure if you send it to the wrong place – and prevents someone sitting in the middle of the connection listening to each message then passing it on, pretending to each side to be the other. (This is known as a Man-in-the-Middle attack <http://en.wikipedia.org/wiki/Man-in-the-middle_attack>. Both sides think they are communicating with the other but are actually communicating with an intermediary who copies all messages then forwards them on.) The method use to verify identity, without possibility of forgery, and even if someone else can copy and manipulate all messages is very interesting and has many other uses. See <http://en.wikipedia.org/wiki/Public-key_cryptography> and <http://en.wikipedia.org/wiki/Digital_signature> for details. If verification fails, you will be warned with a message like in Figure 13 and the computer will refuse to connect.

![](//upload.wikimedia.org/wikipedia/commons/3/3b/Wiki_NGS_Unix_thirdteen.JPG)

Figure 13: warning message

By far, the majority of these warnings are caused by inept computer administration rather than malice (for instance, if someone has upgraded the other machine incorrectly so it appears to be a different computer, you will get this kind of error). If you are sure it is safe, the warning can be dealt with by deleting the appropriate line for the computer from the **~/.ssh/known_hosts** file. Graphical programs can also be run on remote machines, but expect pauses unless you have a very, very fast internet connection. The system that enables this is called the X Windows system (or just X, or X11) (X is the successor to the W Windows System, if you are wondering where the X came from). You can use the -X flag when you run ssh to allow the remote computer to programs in new windows on your local display, provided you have software on your local computer that understand the instructions being sent. Linux computers use such software by default for display and Mac OS X comes with software that can be used (and is started automatically by ssh in the following example). On Windows, the Cygwin software provides the required functionality. Below is an example of using ssh with the -X flag.

#### Transferring files

It is possible to transfer files between computers using SSH alone but this is not recommended since more friendly interfaces exist. Of course, there are many graphical file transfer programs available. Without recommending particular programs, Cyber-duck <http://cyberduck.ch/> for the Mac OS X and WinSCP <http://winscp.net/> for Windows appear to be usefule options, but there are many more. Alternatively, under Mac and Unix, it is possible to mount directories on remote computers so there appear to be local; search for **sshfs** for details. When transferring files, silent errors are extremely rare but can happen and so we'd like to be able to verify that the file received is identical to the one sent. Short files could be checked by eye, but this can't be automated without transferring the file again (which might also get an error). A common technique to verify correct transfer is to calculate the md5 (Message Digest algorithm 5) of both files and compare these values. The md5 is short string of characters that identifies a file and two different files are extremely unlikely to share the same string – if a file changes, its md5 will (very probably) change and so we know that that a change occurred. It is extremely difficult to deliberately create two files that have the same sum. The chances of two non-identical random files having the same md5 is about 3.4e38. When checking large numbers of files, the chance that there are two files in the set with the same md5 increases rapidly but will still be small enough for realistic uses. More rarely, you may come across SHA sums, **shasum** on both Unix and Mac computers, which are very similar to md5's but have an even smaller chance that two files share the same string.

#### Getting help

General help with Ubuntu has already been covered in “Acclimatisation“, alternatively, just find someone to ask. As with everything else, the web is a rich source of good, bad, and down-right weird tutorials.

If you are have little or no programming experience, Python (<http://python.org/>) is a good choice for learning how to do useful bioinformatics scripting, especially in conjunction with the Biopython module (<http://biopython.org/>). Unix is generally very well documented, although the documentation is often aimed at more experienced users. The manual pages all tend to follow the same format, and it's a good idea to become familiar with it. The page will start with a description of what the command does and a summary of all its flags. Optional flags will be enclosed in square brackets. Next comes a full description of the command and detailed descriptions of what each flag does. Sometimes there is also a section containing examples of usage. Mac OS X is generally very consistent about man pages but Linux derivatives can be a mixed bag.

![](//upload.wikimedia.org/wikipedia/commons/b/bc/Wiki_NGS_Unix_fourteen.JPG)

Figure 14: Look at manual page for man example

#### Variables and programming

So far, we have only used the command-line to run other programs and to chain them together to achieve more complex results. The command-line tools can be used like a programming language in its own right, and we can write little programs to automate common tasks; often this referred to as scripting rather than programming although the distinction is not really relevant.

Obviously learning to program is not something that can be taught in an hour or two, and even experienced programmers take several days to become productive in a new language, so this section can give little more than a taste of what is possible; however, it should be possible to show how you could save a lot of time with a little investment up front. If you are doing similar things to large number of files, many sequences for example, typing the same command over and over on the command line is time-consuming, tedious, and prone to error, especially as you get bored. Scripting can save you a lot of time and allow you to get on with something else while the computer takes on that task for you. Think about the last time you needed to rename 100 files, or change the format of thousands of gene alignments so they are compatible with your phylogeny program. Learning a little bit of scripting can speed up these tasks tremendously. As with everything, there are many tutorials available on the web and a search for bash scripting tutorial or bash scripting introduction will yield many examples of varying completeness and comprehensibility.

In order to provide you with a little bit of programming background, we've prepared a small general tutorial below:

The first thing to introduce are variables. A variable is just a name for another piece of data, a useful analogy is that of a labelled box: every time we see the label, we replace it conceptually with the contents of the box. The ability to manipulate variables, changing the state of the computer, is fundamental to programming. Here we'll introduce two useful cases: shortening common directory paths and performing the same operations on many files. In bash scripting, variables called with a dollar sign, followed by the name of the variable: **$NAME**. There are some restrictions on the characters that can be part of a variable name, and variable names cannot start with a number. As a rule of thumb it's a good idea to only use upper- or lower-case letters in your variable names

A variable can refer to the name of a file and we can write things at the command-line using the variable instead of the name explicitly – change the variable and we run exactly the same commands on a different file. One way to take advantage of this this would be to set the variable to one of several files and use the history to repeat a set of commands. Of course, if the commands write their output to a file then that would have to be renamed each time otherwise the output for each file would be written over that for the previous. Shell scripting provides an alternative: the computer can be told to set the variable to each of many file names in turn and the value of the variable can be edited automatically to provide the name of a unique output file.

A common Unix practice is to place frequently used sets of functions into a file, called a script, for reuse thereby preventing errors retyping them. Writing a script also means that complex operations with many steps can be tested before you commit to running them over many files, something that could potentially take days if we are dealing with large numbers of genes. Scripts can be written and modified in any common text editor but must be saved in text format; nano is a good basic editor that is fairly intuitive to use but there are many others more specifically designed with programmers in mind. Alternatively you could use gedit, a program more like Notepad on Windows (to access gedit, click the Ubuntu button and search for **gedit**; entering **gedit &** at the command-line will also work).

#### Line endings – compatibility problems

Even after the standard alphabet for computers was established (ASCII – American Standard Code for Information Interchange) there was no agreement about how to how to indicated the end of a line. ASCII provides two possibilities: line-feed **'\n'** and carriage-return **'\r'** , based on how old type-writers and tele-type terminals used to work: a carriage-return moves the carriage, the position to print the next character at, back to be beginning of the line and line-feed moves the paper one line down but doesn't change where the carriage is. On Unix a **'\n'** character is taken to mean “line-feed and carriage return” and this is used to separate lines of text. On Windows, lines are separated by the pair of characters **'\r\n'** (in that order) and old versions of Apple operating systems (prior to OS X) use **'\r'** to separate lines. The situation on Mac OS X is more complex since it must deal with both its Mac and Unix heritage; officially **'\n' '** now separates lines in files but programs have to be able to deal with both conventions.

To further complicate things, some methods of transferring files between machines try to automatically convert the line endings for you. This is generally a mistake. Specifically an old file transfer method called FTP “File Transfer Protocol” has two modes: text and binary, text mode will attempt to translate line endings. Unix platforms default to binary and are generally safe. The only case where you need to be careful is transferring files from Windows using the command-line FTP application. **If you transfer a binary file over** FTP in text mode, the received file will be corrupted irretrievably. **If in** doubt, see Transferring files for how to verify that your file has transferred correctly.

If you've managed to read through to here, you're probably thinking: a) that's complicated, and b)why haven't I noticed this? The answer is that it used to cause problems in the past but programmers are aware of the issues nowadays and programs tend to do the right thing. Some programming languages like Perl even deal with these problems transparently so even programmers don't need to be aware of them any more.

### GUIs

#### Galaxy

#### GeneTalk

5 steps to analyze VCF files in [GeneTalk](/wiki/GeneTalk) at [www.gene-talk.de](http://www.gene-talk.de)

  1. Upload VCF file
  2. Edit pedigree and phenotype information for segregation filtering
  3. Filter your VCF file by editing the following filtering options
  *     * Functional filter (filter out variants that have effects on protein level)
    * Linkage filter (filter out variants that are on specified chromosomes)
    * Gene panel filter (filter variants by genes or gene panles, subscribe to publically available gene panels or create own ones)
    * Frequency filter (show only variants with a genotype frequency lower than specified)
    * Inheritance filter (filter out variants by presumed mode of inheritance)
    * Annotation filter (show only variants that are listed in databases)
  1. View results and annotations
  2. Write your own annotations

#### BaseSpace

## References

  1. ↑ <http://agbt.org/>
  2. ↑ <http://www.ncbi.nlm.nih.gov/pubmed/21612267>

  


# Pre-processing

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[Bioinformatics from the outside](/wiki/Next_Generation_Sequencing_\(NGS\)/Bioinformatics_from_the_outside)**
**Pre-processing**
**[Alignment](/wiki/Next_Generation_Sequencing_\(NGS\)/Alignment)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Fastq**_](//en.wikipedia.org/wiki/Fastq)

## Pre-processing

### FASTQ files – discussion of the various quality encodings

FASTQ files extend FASTA files in that they provide both sequence and quality. A FASTQ file thus typically consists of four lines.

  1. A line starting with @ containing the sequence identifier
  2. the actual sequence
  3. a line starting with + after which the sequence identifier is optional
  4. a line with quality values which are encoded in ASCII space

As such the 2nd and 4th line must have the same length One such entry is given below showing one sequence "ATGTCT"...
    
    
    @HWI-ST999:102:D1N6AACXX:1:1101:1235:1936 1:N:0:
    ATGTCTCCTGGACCCCTCTGTGCCCAAGCTCCTCATGCATCCTCCTCAGCAACTTGTCCTGTAGCTGAGGCTCACTGACTACCAGCTGCAG
    +
    1:DAADDDF<B<AGF=FGIEHCCD9DG=1E9?D>CF@HHG??B<GEBGHCG;;CDB8==C@@>>GII@@5?A?@B>CEDCFCC:;?CCCAC
    

Here the quality value which ranges from -5 to 41 is added to an offset and the resulting character is taken from an ASCII table. As such the whole data can be represented as text. Whilst Illumina made multiple changes to the quality format and eventually returned to almost Sanger encoding, the most important different is whether the offset is 33 as in Sanger and Illumina v1.8 and later or 64 as in previous Illumina (and Solexa) formats. As you can see from the chart if you find any of the following characters: !"#$%&'()*+,-./0123456789: your offset must be 33 whereas any of the following characters KLMNOPQRSTUVWXYZ[\\]^_`abcdefgh point towards an offset of 64. The above example is thus base offset by 33 as we find a 1 as first character. Also bear in mind that the @ and + signs are valid characters for quality so even if a line started by @ or + this could just be the beginning of the quality string.

See the quality chart below which is modified from the [wikipedia](http://en.wikipedia.org/wiki/FASTQ_format) article.
    
    
      SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS.....................................................
      ..........................XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX......................
      ...............................IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII......................
      .................................**J**JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ......................
      LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL....................................................
      !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~
      |                         |    |        |                              |                     |
     33                        59   64       73                            104                   126
      0........................26...31.......40                                
                               -5....0........9.............................40 
                                     0........9.............................40 
                                        3.....9.............................40 
      0........................26...31........41 
    
    
    
                                 
    
     S - Sanger and Illumina 1.8+,  Offset 33, Quality range (0, 40)  (!,I)
     X - Solexa,                    Offset 64, Quality range (-5, 40) (;,h)
     I - Illumina 1.3+              Offset 64, Quality range (0, 40)  (@,h)
     J - Illumina 1.5+              Offset 64, Quality range (3, 40)  (B,h)  
     L - Illumina 1.8+              Offset 33, Quality range (0, 41)  (!,J)
    

### Presentation of the metrics used in QC

When you turn to quality control there are various metrics to consider.

  


##### Sequence Quality

The simplest is obiviously the quality score introduced in the FASTQ files above. As such it gives already a valid idea about base call quality. As often quality of reads degrades over the course of a sequence it is common practice to determine the average quality of the first, second, third,...nth base by just averaging over all reads in a file. Also to give some idea about the spread usually bar plots showing quantiles are given.  
![Per base quality](//upload.wikimedia.org/wikipedia/commons/0/0f/Per_base_quality.png)  


  
As an example here sequence data was investigated for quality using FastQC. As you can see the sequence reads are 36baseses long and the average sequence quality (depicted by the blue line) is steadily declining. In many new Illumina kits the sequence quality goes up a bit first before it steadily declines.

However instead of going over each base one can average the quality of each read instead and show a cumulative plot of the sequence quality of these.  
![FASTQC Per sequence quality](//upload.wikimedia.org/wikipedia/commons/0/07/Per_sequence_quality.png)  
In the above screenshot one can observe that most reads have an average quality of 32. This is to be considered very good in general, however given that these reads are somewhat on the short side, it is probably at best an OK result.

##### Per Base Sequence Content

Another important metric is to look for base content at each position. Assuming the data is a random sample from the sequence space, at each position the contribution should be identical. Thus one needed to see straight lines. In reality it often happens that the first few bases might indeed show some erratic behavior, which could be due to non completely random primers. In the shown example however the reads are completely off. As you can see there is considerable bias in each base over the whole reads. In fact this bias is so strong, that you can read the overrepresented bases of the read.  
![Per base sequence content](//upload.wikimedia.org/wikipedia/commons/f/f5/Per_base_sequence_content.png)  
As an example if you look at the last few bases you can read them as CTTGAAA-end of sequence.

##### Adapter sequence present or not?

If we now turn our attention to the overrepresented sequences in FastQC we can immediately figure out where this came from:

Sequence Count Percentage Possible Source

GATCGGAAGAGCTCGTATGCCGTCTTCTGCTTGAAA
1870684
19.446980406066654
Illumina Single End Adapter 1 (100% over 33bp)

GAAGAGCTCGTATGCCGTCTTCTGCTTGAAAAAAAA
95290
0.9906017065918623
Illumina Single End Adapter 1 (100% over 28bp)

  


### Intro to errors and quality scores/encoding

As mentioned above the base caller assigns a quality score which is then available for each base. This give the estimated reliability for this base. Please note that depending on your sequencing platform the typical mistakes are different. Illumina's most prevalent form of mistake is a nucleotide exchange whereas 454, Ion Torrent/Proton and other similar platforms have major issues with homopolymers such as AAAAAA where the correct number of As can often not be determined exactly.

### Preprocessing Steps

#### Sequence Quality Trimming

In order to cope with lower quality data it is common to remove low quality bases. Typically one would remove lower quality bases from the e.g. the 3' end using a sliding windows approach as the per base qulity graudally drops.

#### Alternative clipping strategies (Adaptor clipping)

In addition to removing lower base quality data, one would also remove adapters, PCR primers and other artifacts. In practice one would combine the adapter clipping with quality trimming approaches.

#### K-mer filtering/correction strategies

There are different ways to correct for base errors using kmer approaches because some errors can not be simply clipped off and even a very good quality value does not mean that a read is really error free. This is an important step prior to an assembly but potentially less crucial for alignments.

One basic idea is based on kmers in the read string. The original idea going back at least until 2001 (Pevzner 2001) generates a spectrum of kmers first, then kmers which are above a certain threshold (called solid) and kmers below this threshold are potentially arising from mistakes.

If a read is split into multiple kmers a single sequencing error will result in converting several overlapping kmers from strong to weak ones. An error correction step could now try to find the smallest number of changes required to make all kmers in the read strong.

Variants such as Quake also take the base quality into account to be better able to discriminate between low copy true kmers and high copy error kmers.

#### Digital Normalization and Partitioning

When considering especially RNA sequencing, it is well known that a normalization of RNA using molecular biology techniques (lab normalization) can help in providing better contigs and that a better general representation is achieved. This is because using lab normalization depletes common -or highly represented- sequences. Thus, when sampling from sequence space, after lab normalization it is less likely to find the previously very common sequences and thus more likely to find the previously underrepresented sequences. Apart from the advantage of having a higher likelihood to find underrepresented sequences there is the additional advantage that it is now less likely to find the same sequencing error multiple times in two or or more independent reads due to sheer oversampling. The latter makes it less likely that assembly software would erroneously create multiple contigs out of one true mRNA, due to these correlated SNPs. That said, lab normalization is neither easy and if it is outsourced it can be costly. Thus, one can instead use digital normalization. The basic idea is to downsample reads that have a lot of abundant kmwers. In addition this has the added benefit (to the ones above) that the number of reads to process becomes smaller, and thus it might be much more feasible (and faster) to assemble a transcriptome. One way to go about this is to use Titus Brown's tool set: <http://ged.msu.edu/papers/2012-diginorm/>

#### Paired end merging

A number of tools will take Illumina paired-end data and merge the reads if an overlap can be detected between them, potentially correcting errors by a taking the higher quality basecall at discrepant positions. This may improve assembler performance by reducing the data complexity, and may also improve the resulting contigs by removing erroneous data and improving the assembly of repeats. Tools to accomplish this include [COPE](ftp://ftp.genomics.org.cn/pub/cope) and [FLASH](http://seqanswers.com/wiki/FLASH).

#### Removal of other undesirable sequences

Depending on the design of an experiment, there may be other sequences which are desirable to remove or mask from the reads prior to assembly. For example, if sequencing pools of BAC or cosmid DNA, it may be desired to remove most if not all of the vector backbone. Similarly, E.coli sequences will contaminate BAC or cosmid DNA preparations and could be removed in advance. Removing these post-assembly is an option as well. The PhiX control viral DNA is a common contaminant in Illumina sequencing data. Fast search tools such as SMALT can be used to map reads against a reference genome in order to identify those which should be removed.

### Exercise

#### QC workflow (Data from machine -> pre-trimming quality plots -> trimming -> post-trimming quality plots)

A typical workflow might thus be to first get the data from the machine, and evaluate the typical quality plots as shown in the previous section. This gives a valid and important insight into the read quality and might potentially raise awareness about library preparation problems that might have occurred. After this problems have been identified and noted down, one would try to remove several errors by using trimming tools such as Trimmomatic to remove low quality bases from the sequence end and (potentially more importantly) to also remove remaining adapters etc from the reads. After having thus processed the reads one would once again judge the quality to inform about remaining quality issues. As an example even after removing known adapters from the sequences as in the above case, one might still see a per base sequence bias and would want to remove this bias or at least keep it in mind. We will discuss one exemplary workflow here.

#### The dataset

Download SRR074262 from the [SRA](http://www.ncbi.nlm.nih.gov/sra) (this is the example from above).

#### Fastq output analysis

Download [FastQC](http://www.bioinformatics.babraham.ac.uk/projects/fastqc/) (or analyze your data in RobiNA for similar plots). FastQC is relatively self explanatory. Open the the FastQ file you just downloaded. FastQC will run through your dataset and you generate the plots shown in the introduction by clikcing on the individual categories on the left hand side.

#### Adapter removal only

We will use Trimmomatic to simply remove adapters. java -jar trimmomatic-0.30.jar SE -phred33 SRR074262.fastq aclipped.fq.gz ILLUMINACLIP:TruSeq2-SE.fa:2:30:10 MINLEN:25 This tells trimmomatic that the quality encoding is phred 33 (modern Illumina) and it will store the results in the compressed file adapter_clipped.fq.gz. Finally it will use TruSeq3 adapters provided by trimmomatic.

Trimmomatic report

* * *

Input Reads: 9619406 Surviving: 7443332 (77.38%) Dropped: 2176074 (22.62%) TrimmomaticSE: Completed successfully

* * *

FastQC automatically recognizes gz files, so having the file compressed is ok. Indeed when we open the file aclipped.fq.gz in FASTQC the adapters have been removed.

Sequence Count Percentage Possible Source

GGGGAGGAGAGAGCCATTGTTGAGGCGGCCATTGAG
46910
0.630228505190954
No Hit

AGGGGAGGAGAGAGCCATTGTTGAGGCGGCCATTGA
21029
0.28252132244000405
No Hit

#### Adapter Removal and quality clipping

We will use Trimmomatic to remove adapters and use a sliding window approach to remove lower quality bases at the end

java -jar trimmomatic-0.30.jar SE -phred33 SRR074262.fastq aclippedtrim.fq.gz ILLUMINACLIP:TruSeq2-SE.fa:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:25

* * *

Input Reads: 9619406 Surviving: 6513310 (67.71%) Dropped: 3106096 (32.29%) TrimmomaticSE: Completed successfully

* * *

#### Read correction

### Links to useful tools for preprocessing

#### Links to resources used in this chapter

  * [FastQC](http://www.bioinformatics.babraham.ac.uk/projects/fastqc/)
  * [Trimmomatic](http://www.usadellab.org/cms/index.php?page=trimmomatic)

#### Links to other QC tools e.g. FASTX toolkit and spectral alignment for error correction

  * [FASTX-Toolkit](http://hannonlab.cshl.edu/fastx_toolkit/)

  


# Alignment

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[Pre-processing](/wiki/Next_Generation_Sequencing_\(NGS\)/Pre-processing)**
**Alignment**
**[DNA Variants](/wiki/Next_Generation_Sequencing_\(NGS\)/DNA_Variants)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[List of sequence alignment software**_](//en.wikipedia.org/wiki/List_of_sequence_alignment_software)

## Introduction

**Alignment**, also called **mapping**,[9] of reads is an essential step in _re-sequencing_. Having sequenced an organism of a species before, and having constructed a reference sequence, re-sequencing more organisms of the same species allows us to see the genetic differences to the reference sequence, and, by extension, to each other. Alignments of data from these re-sequenced organisms is a relatively simple method of detecting variation in samples. There are certain instances (such as new genes in the sequenced sample that are not found in the existing reference sequence) that can not be detected by alignment alone; however, while other approaches, such as [de novo assembly](/wiki/Next_Generation_Sequencing_\(NGS\)/De_novo_assembly), are potentially more powerful, they are also much harder or, for some organisms, impossible to achieve with current sequencing methods.

Next-generation sequencing generally produces _short reads_ or _short read pairs_, meaning short sequences of <~200 bases (as compared to _long reads_ by Sanger sequencing, which cover ~1000 bases). To compare the DNA of the sequenced sample to its reference sequence, we need to find the corresponding part of that sequence for each read in our sequencing data. This is called **aligning** or **mapping** the reads against the reference sequence. Once this is done, we can look for variation (e.g. SNPs) within the sample. This poses a number of problems:

  * The short reads do not come with position information, that is, we do not know what part of the genome they came from; we need to use the sequence of the read itself to find the corresponding region in the reference sequence.
  * The reference sequence can be quite long (~3 billion bases for human), making it a daunting task to find a matching region.
  * Since our reads are short, there may be several, equally likely places in the reference sequence from which they could have been read. This is especially true for repetitive regions.
  * If we were only looking for perfect matches to the reference, we would never see any variation. Therefore, we need to allow some mismatches and small structural variation (InDels) in our reads.
  * Any sequencing technology produces errors. Similar to the "real" variation, we need to tolerate a low level of sequencing errors in our reads, and separate them from the "real" variation later.
  * We need to do that for each of the millions of reads in our sequencing data.

## Short reads

Raw short reads often come in (or can be converted into) a file format called [FASTQ](//en.wikipedia.org/wiki/FASTQ_format)[10]. It is a _plain text_ format, where each single read occupies four consecutive lines:
    
    
    @Read_id_1
    CTGATGTGCCGCCTCACTTCGGTGGT
    +
    @@@DDDDDH8<BAHG@BHGIHIII>(
    **@Read_id_2
    TGATGTGCCGCCTCACTACGGTGGTG
    +
    FHHHHHJIJIJIJIIIJJIIJGIGII**
    @Read_id_3
    ...
    

The four lines are:

  1. The name/ID of the read, preceded by a "@". For read pairs, there will be two entries with that name, either in the same or a second FASTQ file.
  2. The sequence of the read.
  3. A "+" sign. In very old FASTQ files, this is followed by the read name from the first line. Today, this line is present for <s>historical reasons</s> backwards compatibility only.
  4. The quality scores of the bases from line 2. The scores are generated by the sequencing machine, and encoded as ASCII (33+score) characters. The line should have the same length as line 2, as there is one quality score per base.

## Alignment

For each of the short reads in the FASTQ file, a corresponding location in the reference sequence (or that no such region exists) needs to be determined. This is achieved by comparing the sequence of the read to that of the reference sequence. A mapping algorithm will try to locate a (hopefully unique) location in the reference sequence that matches the read, while tolerating a certain amount of mismatch to allow subsequence variation detection. Reads aligned (mapped) to a reference sequence will look like this:
    
    
    **GCTGATGTGCCGCCTCACTTCGGTGGTGAGGTG**  Reference sequence
     CTGATGTGCCGCCTCACTTCGGTGGT        Short read 1
      TGATGTGCCGCCTCACTACGGTGGTG       Short read 2
       GATGTGCCGCCTCACTTCGGTGGTGA      Short read 3
    GCTGATGTGCCGCCTCACTACGGTG          Short read 4
    GCTGATGTGCCGCCTCACTACGGTG          Short read 5
    

You can see the reference sequence on the top row, and five short reads stacked below; this is called a _pileup_. While two of the reads are a perfect match to the reference, the three other reads show a mismatch each, highlighted in red ("A" in the read, instead of "T" in the reference). Since there are multiple reads showing the mismatch, at the same position, with the same difference, one could conclude that it is an actual genetic difference (_point mutation_ or _SNP_), rather than a sequencing error or mismapping.

### Mapping algorithms

There are several alignment algorithms in existence; you can find an (incomplete) list further down in software packages. Some notes on mapping algorithms:

  * The reference sequence, the short reads, or both, are often pre-processed into an indexed form for rapid searching.

### Sources of errors

There are several potential sources for errors in an alignment, including (but not limited to):

  * PCR artifacts. Many NGS methods involve one ore multiple PCR steps. PCR errors will show as mismatches in the alignment, and especially errors in early PCR rounds will show up in multiple reads, falsely suggesting genetic variation in the sample. A related error would be _PCR duplicates_, where the same read pair occurs multiple times, skewing coverage calculations in the alignment.
  * Sequencing errors. The sequencing machine can make an erroneous call, either for physical reasons (e.g. oil on an Illumina slide), or due to properties of the sequenced DNA (e.g., homopolymers). As sequencing errors are often random, they can be filtered out as singleton reads during variant calling.
  * Mapping errors. The mapping algorithm can map a read to the wrong location in the reference. This often happens around repeats or other low-complexity regions.

### Alignment types

Alignments can be used for different purposes:

  * _Whole-genome sequencing_. This would be the "default" use; sequence all DNA from an organism and map it to the appropriate reference sequence, to find genetic variation.
  * _Exome sequencing_. For large genomes (e.g., human), capture just the exomic DNA before sequencing. This will return sequencing data for most of the genes, at a fraction of the cost.
  * _Transcriptome sequencing (RNA-Seq)_. Sequencing of the transcriptome, that is, of the RNA present in the sample. This can show which genes are transcribed in the sample, and help fine-tune gene annotation (exon boundaries etc.). Mapping can be done either to the full reference sequence, or to a special "transcriptome reference".
  * _ChIP-Seq (Protein-DNA interaction)_.

### The SAM/BAM format

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[SAMtools**_](//en.wikipedia.org/wiki/SAMtools)

The SAM/BAM format has emerged as the _de facto_ standard format for short read alignments. SAM[11] is the plain-text version of the binary, compressed BAM format. They can be converted into one another by the name-giving _samtools_[12] command-line tool. BAM (without alignment position data) is increasingly used as a space-saving alternative to FASTQ files for containing the short raw read data, and all current alignment software can generate SAM/BAM as an output format. Once in BAM format, the file can be indexed, giving quick access to any region of the reference sequence. Subsequently, using samtools or other software, BAM files can be analysed (e.g. for quality control), modified (removal of PCR duplicates, local realignment, base quality recomputation), or used to call variation, either small (SNPs, short InDels) or large (inversions, tandem duplications, deletions, translocations). BAM files can be visualised using tools like Artemis, ACT, or LookSeq[13]. Last not least, alignments in BAM format can be used to "morph" the reference sequence to correspond to the short read data with ICORN[14]; this can be useful to get an actual DNA sequence for a sample, or to construct a new reference sequence based on a closely related species.

Other useful SAM/BAM-related software includes:

  * Picard[15]
  * Bio-SamTools[16]

#### SAM/BAM tools examples

  * Convert SAM to BAM format: 
    * samtools view -bS aln.sam > aln.bam
  * Sort BAM file according to position on reference sequence 
    * samtools sort aln.bam aln_sorted.bam
  * Index BAM file (needed for visualising the alignment) 
    * samtools index aln_sorted.bam aln_sorted.bai
  * Extract the header information from a BAM file 
    * samtools view –h aln_sorted.bam > aln.sam
  * Generate a FASTQ file from a BAM file 
    * bam2fastq -o aligned.fastq --no-unaligned aln.bam

## Software packages

Software Type Supported  
technologies Interface Notes

Partek
Commercial
All
GUI

  * Free trial
  * Easy to use, no command line
  * Vast choice of publicly available aligners recommended by Illumina & Life Technologies, Ion Torrent
  * Guidance on alignment choice

BWA[17]
Free software
Illumina  
SOLiD  
454
Command line

  * The SAM/BAM output adhere to SAM format, contains mapped and unmapped data, easy to parse
  * Not fully threaded. sampe and samse can only utilize 1 CPU. bwasw (454 longer reads) can be fully threaded, though
  * Not as sensitive as Stampy and Novoalign
  * May be outperformed by BWA-MEM for 70-100bp Illumina reads.

Bowtie[18]
Free software
Illumina  
SOLiD
Command line

  * Discussed in the [SeqAnswers forum](http://seqanswers.com/forums/showthread.php?t=706)
  * Fast
  * No mapping quality reported
  * Not as sensitive as Stampy and Novoalign

Stampy[19]
Free software
Illumina
Command line

  * Balance of speed and sensitivity
  * Can be slow even using BWA as premapper

SHRiMP2
Free software
Illumina
Command line

  * Higher sensitivity than BWA
  * One step mapping, Indexing of genome is not needed
  * Alignment can take less time than BWA is the reference sequence is short, e.g. mapping of reads against a targeted region
  * Alignment speed is slow IF mapping is done onto a large genome

TMAP
Free software
IonTorrent
Command line

  * Uses a selection of algorithms to balance speed and sensitivity

SNP-o-matic[20]
Free software
Illumina
Command line

  * Very fast, especially on genomes <100mbp
  * No/limited _de novo_ variation discovery
  * Also works as a genotyper

CLC workstation
Commercial
All
GUI

  * Easy to use
  * Expensive
  * Alignment is spurious based on our dataset
  * Alignment speed is NOT impressive at all compared to BWA or Bowtie (i7 860 + 16GB memory, windows 2008 R2-64bit)

Novoalign
Commerical for multi-threaded version. Single threaded version is free
Illumina
Command Line
Fast and accurate. Probably the best aligner as of 2013.

GSMapper
Commerical
454
GUI
/

SSAHA2
Free software
454
Command line
Fast and accurate for all reads it can map

BLAT
Free software
454
Command line
Not designed for NGS data.

Mosaik
Free software
454
Command line
Tedious steps. Alignment speed can be slow. Huge memory requirement.

BWA-SW[21]
Free software
454, IonTorrent
Command line

  * For long sequences ranged from 70bp to 1Mbp.
  * Authors recommend to use BWA-MEM (which is the latest) instead of BWA-SW.

BWA-MEM[22]
Free software
454, IonTorrent
Command line

  * For long sequences ranged from 70bp to 1Mbp.
  * Newer version of BWA-SW, so recommended to use instead of BWA-SW.
  * May outperform by BWA for 70-100bp Illumina reads.
  * May outperform Novoalign for variants call [23]

Bfast[24]
Free software
SOLiD
Command Line
Speed of alignment may be too slow for large NGS data [25]

Tophat[26]
Free software
Illumina
Command Line
Transcriptome data only

Splicemap
Free software
Illumina
Command Line
Transcriptome data only

MapSplice
Free software
Illumina
Command Line
Transcriptome data only

AbMapper
Free software
Illumina
Command Line
Transcriptome data only

ERNE-map (rNA)[27]
Free software
Illumina
Command line

  * Sensitive and efficient
  * Can be paired with an independent trimming module (ERNE-filter[28]) and a bisulfite-treated-specific read aligner program (ERNE-bs5[29])
  * Slow when dealing with gapped alignments

An exhaustive list of NGS aligner is maintained at [HTS mapper](http://wwwdev.ebi.ac.uk/fg/hts_mappers/)

Based on personal experience and prevalence and based on literature data on the performance[30][31][32], a quick primer on when to use which software:

  * If only speed matters use bowtie.
  * BWA is a bit slower but more sensitive.
  * If sensitivity and specificity is needed, try Stampy, Novoalign, or SHRiMP 2.

# Further Reading Material and References

  1. ↑ <http://www.biostars.org/p/6749/>
  2. ↑ <http://www.youtube.com/watch?v=ZzBCvmV-6p4>
  3. ↑ <http://www.nature.com/nrg/journal/v11/n9/pdf/nrg2857.pdf>
  4. ↑ <http://www.helix-nebula.eu/uploads/4.%20EMBL%20Flagship.pdf>
  5. ↑ [<http://www.gnu.org/> the GNU project]
  6. ↑ [GNU General Public Licence](http://www.gnu.org/copyleft/)
  7. ↑ [Unbuntu help](https://help.ubuntu.com/11.10/)
  8. ↑ M.D. McIlroy, E.N.Pinson, and B.A. Tague "Unix Time-Sharing System Forward", The Bell System Technical Jounal, July -Aug 1978 vol 57, number 6 part 2, pg. 1902
  9. ↑ [Brief review of alignment aglorithm - Alignment section](http://www.nature.com/nmeth/journal/v7/n6/full/nmeth0610-479b.html)
  10. ↑ Cock et al (2009) The Sanger FASTQ file format for sequences with quality scores, and the Solexa/Illumina FASTQ variants. Nucleic Acids Research, [doi](//en.wikipedia.org/wiki/Digital_object_identifier):[10.1093/nar/gkp1137](http://dx.doi.org/10.1093%2Fnar%2Fgkp1137)
  11. ↑ [SAM format specifications](http://samtools.sourceforge.net/SAM1.pdf)
  12. ↑ [samtools](http://samtools.sourceforge.net), from the WTSI
  13. ↑ <http://genome.cshlp.org/content/19/11/2125.long>
  14. ↑ [ICORN](http://icorn.sourceforge.net/)
  15. ↑ [Picard](http://picard.sourceforge.net) by Broad Institute
  16. ↑ [Bio-SamTools](http://search.cpan.org/~lds/Bio-SamTools/)
  17. ↑ [Li and Durbin, 2009](http://bioinformatics.oxfordjournals.org/content/25/14/1754.long)
  18. ↑ [Langmead et al., 2009](http://genomebiology.com/content/10/3/R25)
  19. ↑ [Lunter and Goodson, 2010](http://genome.cshlp.org/content/21/6/936.long)
  20. ↑ <http://bioinformatics.oxfordjournals.org/content/25/18/2434>
  21. ↑ [Li and Durbin, 2010](http://bioinformatics.oxfordjournals.org/content/26/5/589)
  22. ↑ [Li, submitted in 2013](http://arxiv.org/abs/1303.3997)
  23. ↑ <http://bcbio.wordpress.com/2013/05/06/framework-for-evaluating-variant-detection-methods-comparison-of-aligners-and-callers/>
  24. ↑ <http://en.wikipedia.org/wiki/BFAST>
  25. ↑ <http://massgenomics.org/short-read-aligners>
  26. ↑ <http://tophat.cbcb.umd.edu/>
  27. ↑ [Vezzi, Del Fabbro, Tomescu and Policriti, 2012](http://bioinformatics.oxfordjournals.org/content/28/1/123.long)
  28. ↑ [ERNE website - filter](http://erne.sourceforge.net/)
  29. ↑ [ERNE website - bs5](http://erne.sourceforge.net/)
  30. ↑ [Evaluation of next-generation sequencing software in mapping and assembly](http://www.nature.com/jhg/journal/v56/n6/pdf/jhg201143a.pdf)
  31. ↑ [A list of old short reads aligners](http://lh3lh3.users.sourceforge.net/NGSalign.shtml)
  32. ↑ [ROC curves, including bowtie2](http://lh3lh3.users.sourceforge.net/alnROC.shtml)

  


# DNA Variants

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[Alignment](/wiki/Next_Generation_Sequencing_\(NGS\)/Alignment)**
**DNA Variants**
**[RNA](/wiki/Next_Generation_Sequencing_\(NGS\)/RNA)**

## DNA Variants

### Linking to Wikipedia

[What is SNPs?](http://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) [What is Mutation?](http://en.wikipedia.org/wiki/Mutation) [What is Genetic Variation?](http://en.wikipedia.org/wiki/Genetic_variation)

### Protocols

#### Whole genome, exome, etc. Consequences for downstream analysis

### Typical workflow

### File formats

#### VCF

**VCF** stands for [Variant Call Format](//en.wikipedia.org/wiki/Variant_Call_Format). It was created by the [1000 Genomes Project](//en.wikipedia.org/wiki/1000_Genomes_Project) as a way to store small-scale variation data (SNPs, InDels, short structural rearrangements), and has since become the _de facto_ standard format for storing such data. The official, detailed description can be found [here](http://www.1000genomes.org/wiki/Analysis/Variant%20Call%20Format/vcf-variant-call-format-version-41) (VCF version 4.1, as of writing).

VCF can store information about a variant, such as its position on a reference sequence, the reference and alternate alleles, stable variant identifier (e.g. [rs number](//en.wikipedia.org/wiki/dbSNP)), as well as the observed allele(s) in multiple samples. VCF can also hold aggregate information about the variant across all samples (e.g. total coverage depth, allele frequencies etc.), as well as a list of filters that the variant failed during the current analysis.

The basic VCF file format is ASCII text. A header section identifies the VCF format version, defines FILTER and INFO fields, and other meta-data. This is followed by the actual data table, consisting of a single row containing the standard headers and the sample names, and one row per variant. All columns in the table header and the data rows are separated by tab (\t) characters:
    
    
    #CHROM POS    ID     REF    ALT     QUAL FILTER INFO                    FORMAT      Sample1        Sample2        Sample3
    2      4370   rs6057 G      A       29   .      NS=2;DP=13;AF=0.5;DB;H2 GT:GQ:DP:HQ 0|0:48:1:52,51 1|0:48:8:51,51 1/1:43:5:.,.
    

(for more exhaustive examples, see the official description)

### Creating a dataset

#### SAMTOOLS

#### others...

### Reference datasets

#### Human=> Variants=>1000 genomes, HapMap,etc

#### Other species

### Viewing datasets

#### Ensembl

#### UCSC

#### IGV

#### Tablet?

### Comparing datasets

#### VCF tools

# SEQwiki content dump

# SNP detection

SNPs, or single nucleotide polymorphisms, are heritable single base changes in a genome versus a reference sequence. They are part of the more generic set of Single Nucleotide Variations (SNVs), which also encompasses somatic single base changes which are not passed to offspring and are due to environmental damage. Tools for SNP identification can also be used for SNV identification, though tools specific for SNV identification exist as well. In some contexts, such as cancer genomes, SNV identification is complicated by heterogeneous DNA samples.

SNP identification programs must distinguish system noise (instrument errors, PCR errors, etc) from actual variation. They generally do so by modeling various error types and the expected distribution of calls under homozygous reference (AA), homozygous variant (BB) and heterozygous variant (AB) states. Confidence in calls is generally affected by the reported sequence quality values and read depth. Some SNP/SNV callers work by comparing individual samples to a reference, whereas others can simultaneously call in multiple samples using information from each sample to assist calling in the other samples. SNP callers for mixed population samples also exist.

A common source of error in SNP/SNV calling is misalignment due to pseudogenes, repeated genomic segments or close orthologs; in these cases the co-alignment of reads arising from different genomic regions can result in a false positive call. Another source of error can be local misalignment (or ambiguous alignment) due to indels in reads (either true indel variations or sequencing errors); realignment tools such as [Dindel](/w/index.php?title=Dindel&action=edit&redlink=1) and those found in [GATK](/wiki/GATK) can generate more consistent treatment of indels to reduce this source of error. Many SNP/SNV callers are designed for diploid DNA, and may not work well in samples with higher ploidy. As noted above, heterogeneity in samples such as tumor samples can frustrate SNV calling, and some callers are specifically designed to cope with this. Tumor samples may also have altered copy number due to gene or chromosomal amplification, meaning they are effectively of triploid or higher ploidy in some regions.

SNP/SNV callers often call only these polymorphisms, and not (for example) small indels. Users of these tools should also take care when calling adjacent pairs of SNPs/SNVs, as the phasing of these (or more distant SNPs) is not reported in many callers' reports.

# Decision Helper

I want to quickly call SNP versus a reference =>Freebayes, samtools

  


# Software Packages

## Free Software

### Freebayes

[Freebayes](https://github.com/ekg/freebayes) is the successor of Poly- Giga- and BAMBayes and should be much faster than these. Like these it relies on BAM files. It has also been described in some more detail by its developer on [Biostar](http://biostar.stackexchange.com/questions/613/what-methods-do-you-use-for-in-del-snp-calling)

  * Pros 
    * very easy to run for simple SNP calling
    * Does not assume any ploidy
    * can read BAM files via STDIN

### GATK

The Genome Analysis toolkit [GATK](/wiki/GATK) allows multiple steps. The authors used their pipeline for variant calling using the NA12878 exome data set and compared their results to those of [Crossbow](/w/index.php?title=Crossbow&action=edit&redlink=1) (which uses [SOAPsnp](/w/index.php?title=SOAPsnp&action=edit&redlink=1)). Based on these results they concluded that crossbow had a lower spcecificity.

One easy way to to run GATK and other tools might be to use this [variant pipeline](https://github.com/vlandham/variant_pipeline) mentioned on [Biostar](http://biostar.stackexchange.com/questions/8260/workflow-or-tutorial-for-snp-calling)

  * Important reminder 
    * If you run GATK framework in your own pipeline, you have to bear in mind GATK has Stringent file formatting requirement.
    * e.g. chromosomes ordering in genome reference file has to be in [canonical](http://www.broadinstitute.org/gsa/wiki/index.php/Input_files_for_the_GATK) order.
    * BAM header has to be present in every BAM file.
    * The BAM file has to be sorted, preferably by Picards because it write the proper header after sorting
    * Read-group tag has to be present in each BAM. Either input the correct tag during mapping or you may waste your time in fixing the BAM file afterwards
  * Pro 
    * Likely relatively specific (The authors show higher specificity than crossbow)
  * Con 
    * relatively complex pipelines

### MAQ

[MAQ](/w/index.php?title=MAQ&action=edit&redlink=1)

  * Pros 
    * performed slightly better than sopasnp and beter than snvnmix according to an independent comparison

### samtools

[samtools](/w/index.php?title=Samtools&action=edit&redlink=1) using the mpileup command <http://samtools.sourceforge.net/mpileup.shtml>

**samtools pileup** (without the **m**) is deprecated and has been removed in recent SAMtools versions.

### Sibelia

[Sibelia](/w/index.php?title=Sibelia&action=edit&redlink=1) is a comparative genomic tool to assist biologists in analysing genomic variations that correlate with pathogens, or the genomic changes that help microorganisms adapt in different environments. Sibelia is also useful in evolutionary and genome rearrangement studies for multiple strains of microorganisms.

  * Pros 
    * Works well for multiple bacterial genomes.
    * Easy to run and cross-platform, licensed under GPL.
  * Cons 
    * Works slow for large genomes.

<http://bioinf.spbau.ru/sibelia>

### SOAPsnp

[SOAPsnp](/w/index.php?title=SOAPsnp&action=edit&redlink=1) is e.g. used in the [Crossbow](/w/index.php?title=Crossbow&action=edit&redlink=1) pipeline.

### SNVMix

[SNVMix](/w/index.php?title=SNVMix&action=edit&redlink=1) The authors of SNVMix compared their tool to MAQ v0.6.8 and found better performance as judged by area under the curve when using Affymetrix SNP 6.0 data. However in an independent comparison using MAQ 0.71 MAQ performed better.

  * Cons 
    * Might be unstable in high coverage region according to an independent comparison.
    * Might be less precise than MAQ and SOAPsnp

## Commercial Software

[Partek](http://www.partek.com)  
[CLCBio](/w/index.php?title=CLCBio&action=edit&redlink=1)

# Further Reading Material and References

  * Further Reading 
    * [Alkan et al., 2011](http://www.nature.com/nrg/journal/v12/n5/full/nrg2958.html) Finding variation using different approaches
  * Original Publications 
    * [Li et al., 2008](http://genome.cshlp.org/content/18/11/1851.long) MAQ
    * [Li et al., 2009](http://bioinformatics.oxfordjournals.org/content/25/15/1966.long) SOAP2 (snp)
    * [Li et al., 2011](http://bioinformatics.oxfordjournals.org/content/early/2011/09/08/bioinformatics.btr509.long) samtools (snp)
    * [Goya et al.,2010](http://bioinformatics.oxfordjournals.org/content/26/6/730.long) SNVMIX
    * [DePristo et al., 2011](http://www.nature.com/ng/journal/v43/n5/full/ng.806.html) GATK (snp)
  * Comparisons 
    * Nielsen R, Paul JS, Albrechtsen A, Song YS Genotype and SNP calling from next-generation sequencing data. Nat Rev Genet. (2011) 12:443-51. _The article gives general reccommendations for a workflow and suggests to use a calibration step as implemented by GATK or SOAPsnp_
    * [Wang et al., 2011](http://www.nature.com/srep/2011/110805/srep00055/full/srep00055.html) A comparison of short read aligners and performance assesment of MAQ (0.71), SOAPsnp (1.03) and SNVmix(2-0.11.8-r4) where **MAQ performed best**

  


# RNA

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[DNA Variants](/wiki/Next_Generation_Sequencing_\(NGS\)/DNA_Variants)**
**RNA**
**[Epigenetics](/wiki/Next_Generation_Sequencing_\(NGS\)/Epigenetics)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[List_of_RNA-Seq_bioinformatics_tools**_](//en.wikipedia.org/wiki/List_of_RNA-Seq_bioinformatics_tools)

This guide is meant to offer an easy to follow guide to the analysis of RNA-seq data, aimed at those without any prior experience analysing next-gen data. However, a basic level of familiarity with R, the next-gen sequencing procedures and using the UNIX shell are assumed. Most of the steps described here are outlined in the review article [5].

  * It was primarily written by Matthew Young (myoung@wehi.edu.au) and is a work in progress.
  * The pathogen example was provided by B. Usadel and makes use of a different set of tools.

  


## RNA

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Transcriptome**_](//en.wikipedia.org/wiki/Transcriptome)

Introduction to transcriptomics..

For every sample on which RNA-seq is run, the output you will typically receive is a file containing millions of short (25-300bp) DNA sequences, called reads, and quality scores indicating the confidence of each base call. However, there are some important common variations on this which depend on the platform and protocol used. These include, but are not limited to:

  * Base space or colour Space
  * Paired end/mate pair or single end/unpaired
  * Stranded or un-stranded

Each of these is described in more detail in the following sections.

### Base space vs Colour space

The two main platforms for second-generation sequencing of RNA are produced by Illumina and ABI Solid. While both produce millions of short reads, they are sequenced and reported in slightly different ways. The Solid platform uses a sequencing technique which generates the read information by attaching two base pairs at a time. Each base pair of a read is sequenced twice, by two (potentially different) di-nucleotides. To take advantage of this sequencing chemistry, Solid reports its reads not as a sequence of nucleotides, but as a sequence of 4 colours, where each colour represents a transition between bases, known as "colour space encoding" (<http://marketing.appliedbiosystems.com/images/Product_Microsites/Solid_Knowledge_MS/pdf/SOLiD_Dibase_Sequencing_and_Color_Space_Analysis.pdf>). On the other hand, the Illumina platform reads one base at a time along a fragment until the desired read length is reached. The observed bases are then reported as the output.

The consequence of this is that the tools for analyzing RNA-seq data depend on the platform used to produce the short read data. While it is possible to convert colour space reads to base space (and vice versa), doing so introduces severe biases into the data which should be avoided at all costs. Therefore, reads should be kept in their native format and the appropriate tools should be used to analyze them.

### Paired end/Mate pair reads

The standard RNA-seq protocol involves random shearing of reverse transcribed mRNA (cDNA), followed by sequencing a short "read" from one end of the fragment. This means that only the first 25-300bp of a fragment are known (depending on the length of the reads) with the rest of the fragment remaining unsequenced. In fact, because fragmentation is random, the length of each fragment is also unknown, although a size selection step is usually applied.

Although the chemistry is not sufficiently precise to allow the entire fragment to be sequenced, a clever trick can be applied whereby a short read is taken from both ends of the fragment resulting in a pair of short reads one from each end of the fragment. Reads where this has been performed are known as paired end or mate pair reads. Paired end reads allow additional information to be inferred about the intervening sequence and are particularly useful for de novo transcriptome construction and detecting structural variants, such as indels.

### Stranded reads

RNA-seq data can come in either stranded or unstranded varieties. If the data is unstranded, the strand from which the fragment was transcribed cannot be identified directly from the sequence. Furthermore, because the RNA-seq protocol usually involves forming double stranded cDNA for ease of sequencing, the returned sequence is just as likely to be that of the reverse complement of the source DNA sequence as the original DNA sequence. In practical terms, this means that while half the reads map to the forward strand and half the reverse, this mapping does not contain any information about which strand the RNA was transcribed from.

Stranded RNA-seq data on the other hand preserves strand information, making it possible to identify which strand the RNA was transcribed from.

  


### Protocols

### Typical workflow

#### Spliced Mapping

#### TopHat

#### GSNAP

#### MapSplice

### File formats

#### GFF/GTF

### Creating a dataset

#### Cufflinks

#### MISO

#### GSTRUCT

### Reference datasets

#### Human

The Genome Reference Consortium provides a human reference genome that is constructed from several individuals from a diverse population. And the quality of the reference is continually improved with the correction of extant assembly errors, including but not limited to incorrect mixing the haplotype structure among the individuals used

##### CCDS

The Consensus CDS (CCDS) project is a collaborative effort to identify a core set of human and mouse protein coding regions that are consistently annotated and of high quality. The annotation are consensus among NCBI's RefSeq, EBI's Ensembl and Sanger's Havana

##### GENCODE

GENCODE is a sub-project of the ENCODE scale-up project to annotate all evidence-based gene features in the entire human genome

##### HAVANA[1]

The HAVANA group in Sanger Institute manually annotate the human genome, providing comprehensive annotation for full complexity of gene loci and features that may not be well catered by automated annotation system.

##### RefSeq[2]

RefSeq is a reference sequence annotation provided by the NCBI

##### UCSC genes [3]

UCSC Known genes are constructed by a fully automated process, based on protein data from Swiss-Prot/TrEMBL (UniProt) and the associated mRNA data from Genbank.

### Viewing datasets

#### Browsers

### Comparing datasets

# SEQwiki content dump

## What does the data look like?

## What can be done with RNASeq data

In order to analyze your RNASeq data, there are different aims which require different preprocessing steps.

  


### Calling DE genes

If you want to call differentially expressed genes it is mandatory for many BioConductor packages that you do **not** convert your read count to e.g. rpkm but use the raw read count. The reason is that the statistical model uses the original read count data. (Less reads mean more short noise, whereas a lower rpkm value could still be associated to many reads e.g. in the case of a very long gene). Please also bear in mind that even if you use RNASeq data you still **need biological replicates**.

Also you will want to use software packages that are made for RNAseq (i.e count data) such as [DESeq](/w/index.php?title=DESeq&action=edit&redlink=1), [bayseq](/w/index.php?title=Bayseq&action=edit&redlink=1), [NBPSeq](/w/index.php?title=NBPSeq&action=edit&redlink=1) or [edgeR](/w/index.php?title=EdgeR&action=edit&redlink=1), which all use a negative binomial model.

A typical workflow might look like this

  1. quality control your data
  2. Mapping Reads (see the [howto](http://seqanswers.com/wiki/How-to/short_read_aligners))
  3. Counting Reads per feature
  4. statistical analysis

  


  


#### Counting/summarizing reads

After having aligned reads to your genome you need to summarize the reads. This might be a crucial step, as there are many different ways to do summarization. One way could be to be very stringent and only count completely unambigous reads, however in downstream analyses this needs to be taken into account. One could summarize the data by using e.g. [HTSeq count <http://www-huber.embl.de/users/anders/HTSeq/doc/count.html>] or the Bioconductor Iranges module

#### Statistical Analysis

When testing for differential expression, one should likely take a package modelling count data. In Bioconductor, options include [DESeq <http://www.bioconductor.org/packages/release/bioc/html/DESeq.html>], edgeR and bayseq.

### Differential exon usage

Besides overall changes in expression of a gene, there can be differentially abundant of isoforms or specific exons. Testing for differentially abundant exons can be done using [DEXSeq <http://bioconductor.org/packages/release/bioc/html/DEXSeq.html>], see also the Genome Research paper [[2]](http://genome.cshlp.org/content/early/2012/06/21/gr.133744.111.long).

### Category enrichment (e.g. GO enrichment)

As with all enrichment analyses, the categories that you find might be confounded by detection power. With RNASeq, the power for detecting differential expression (at the same type-I error, e.g. the same adjusted p-value) is higher for genes with more counts. For example, if all photosynthesis genes were highly expressed, you would have a higher chance to find any of these to be differentially expressed than other genes. Now, if you found photosynthesis genes enriched in your list of differentially expressed genes, that might be just because they were easier to find.

The authors of the [Goseq](/w/index.php?title=Goseq&action=edit&redlink=1) package in Bioconductor noted that longer genes tend to generate more counts, and they provide software for doing GO category enrichment analysis that is able to adjust either for gene length, or directly for expression strength.

### Estimating expression height

A typical workflow might look like this

  1. Mapping Reads
  2. Counting Reads per feature
  3. normalizing for gene length

### Finding novel genes or splice variants

## Quality Control (QC)

There are many possible avenues for performing checks for quality on sequencing data. Some popular options are: [FastQC](/w/index.php?title=FastQC&action=edit&redlink=1) (<http://www.bioinformatics.bbsrc.ac.uk/projects/fastqc/>), DNAA (<http://seqanswers.com/wiki/DNAA>) or you can do it in R or use [HTSeq](/w/index.php?title=HTSeq&action=edit&redlink=1)

Although more complex quality metrics can be used, a basic check that the sequence composition doesn't vary too greatly along the length of the reads and the quality scores do not dip too low are a good place to start. These checks (as well as several others) can be performed by loading the fastq files into the fastQC program.

## Mapping the reads

Unless your aim is to do de novo transcriptome assembly, the first step of any analysis will be to align your millions of short reads to a reference of some kind. This is usually the reference genome for the species from which the RNA was extracted. There are many different aligners for performing short-read alignment to a reference (lists are available here (<http://en.wikipedia.org/wiki/List_of_sequence_alignment_software>) and here (<http://seqanswers.com/wiki/Special:BrowseData/Bioinformatics%20application?Bioinformatics_method=Mapping>) ). Each has specific advantages and disadvantages, usually involving a trade-off between speed and sensitivity. For the purposes of this guide we will use the aligner BOWTIE because it is actively developed, fast, widely used and supports both base space and colour space reads.

As a starting point, I will assume you have the following files:

For single end reads:

sample.fa or sample.cfa (cfa for colour space, fa for base space)

For paired end reads:

sample_pair1.fa and sample_pair2.fa or sample_pair1.cfa and sample_pair2.cfa (cfa for colour space, fa for base space)

### Obtaining the reference

In order to map the short reads to a reference genome, that genome has to be turned into an index which can be used by BOWTIE. A number of prebuilt indexes for common genomes can be downloaded from the BOWTIE website (<http://bowtie-bio.sourceforge.net/index.shtml>) . If your genome is not available you will have to construct the index yourself from a fasta file containing your reference genome, these can be obtained from UCSC (<ftp://hgdownload.cse.ucsc.edu/goldenPath/>) . This is accomplished using the command:
    
    
       bowtie-build reference.fa reference_name
    

The argument "reference_name" is a unique identifier that will be used to refer to this reference genome from now on. If your reads are colour space, construct a colour space index by adding the -C command:
    
    
       bowtie-build -C reference.fa reference_name
    

This command will output 6 files named reference_name.1.ebwt, reference_name.2.ebwt, reference_name.3.ebwt, reference_name.4.ebwt, reference_name.rev.1.ebwt, and reference_name.rev.2.ebwt.

Irrespective of how you obtain the index, in order for BOWTIE to use it, the six files mentioned above need to be placed in the BOWTIE indexes directory. If you're not sure what your indexes directory is, it is pointed to by the environmental variable BOWTIE_INDEXES, so:
    
    
       echo $BOWTIE_INDEXES
    

will display the path where you should put the index files.

If you wish to use an aligner other than BOWTIE, you will also have to build an index from the reference genome. Refer to the documentation for your preferred aligner for more information.

### Aligning reads to the reference

Having constructed the reference into an index that BOWTIE can use, we now want to align our data to this index. BOWTIE offers a wealth of command line options that can be used to adjust the alignment algorithm and how it handles input/output. These command line options are described in detail in the BOWTIE manual (<http://bowtie-bio.sourceforge.net/manual.shtml>) , but there are a few flags that are commonly used in the analysis of RNA-seq and bear mentioning here.

The --sam or -S tells BOWTIE to output the results of the alignment in SAM format instead of the BOWTIE format. SAM (<http://samtools.sourceforge.net/>) is rapidly becoming the standard for reporting short read alignment and is supported by a wide range of downstream analysis tools. Unless you have a very good reason not to, this flag should always be specified.

The --best flag tells BOWTIE to guarantee that the alignment that it reports has the fewest number of mismatches to the reference out of all matches found. It also performs a few other desirable functions such as removing strand bias (see BOWTIE manual (<http://bowtie-bio.sourceforge.net/manual.shtml#thebowtie-aligner>) ). The trade-off for these benefits is that --best is slightly slower, but this difference is negligible in almost all instances. Note that --best does not apply to paired-end reads. This flag should be enabled unless speed is a major consideration.

Each base has a quality score associated with it which is reported on the PHRED scale (<http://en.wikipedia.org/wiki/Phred_quality_score>) where lower scores mean less confidence in the accuracy of the base call. For each candidate alignment, BOWTIE adds up the quality scores at bases which don't match the reference. Any match location that has a sum of mismatch quality scores greater than -e is deemed invalid and not reported. The default value of -e of 70 was optimized when read lengths tended to be shorter (~30bp), but is not appropriate for longer read lengths commonly used today. Furthermore, any true biological variation from the reference (such as SNPs) will in theory have a high quality score. Therefore, reads with SNPs will score very poorly on the sum of mismatching quality scores metric. For all these reasons, it is advised that the user increase -e beyond the default unless the reference is known to be an excellent representation of the biological source of RNA and the number of errors in the read is small.

The -p flag sets the number of simultaneous threads to use. As short read alignment is effectively infinitely parallelizable, set this to the number of CPU cores available.

With these considerations in mind, we map our short read data to our reference using the command
    
    
       bowtie -p 8 --sam --best reference_name sample.fa aligned_reads.sam
    

If using colour space, the -C flag needs to be added.
    
    
       bowtie -p 8 --sam -C --best reference_name sample.cfa aligned_reads.sam
    

If your data is paired end the two paired files need to be specified using the -1 and -2 flags
    
    
       bowtie -p 8 --sam reference_name -1 sample_pair1.fa -2 sample_pair2.fa aligned_reads.sam
    

### More complex alignment

The fragments of cDNA that are being sequenced originate not from the genome, but from the transcriptome. The transcriptome is formed by combining exons from the genome, which is why mapping to the genome is a good approximation. However, in doing so the ability to map any read that crosses exon-exon boundaries is lost. The longer the reads, the more this becomes an issue as a read is more likely to cross a boundary and be rendered unmappable. Depending on the desired downstream analysis, this lost coverage at exon boundaries may or may not be a problem.

#### Exon Junction libraries

It is possible to build exon junction libraries from known annotated exons and then try and map those reads that fail to map against this sequence. Such an approach is only capable of capturing reads that span known annotations, limiting its utility and biasing the results towards well annotated genes/genomes. In order to do this, a new reference needs to be constructed that contains both the reference genome, as well as the new exon-junction sequence. It is important that the original genomic reference still be included in the reference, even if you are only mapping those reads that failed to align to the genome, so as the reads can compete amongst all possible mapping locations when determining alignment. You also need to decide how much sequence to take from either side of the exon-exon boundary. The amount of sequence from each exon must be less than the read length, otherwise any read which falls near an exon boundary, but not over it, will map to two locations, the exon junction library and the genome itself. This means that if you intend to trim your reads, the amount of sequence you take from each side of the exon junction must me less than the length of the trimmed read. Finally, you need to decide what combinations of exon-exon joinings you are going to consider. Do you only consider splicing within genes, within chromosomes, without exon reorientation? All of these things occur with different frequencies in different samples and the more possibilities you consider the greater the computational complexity.

To construct the junction library you first need a genome annotation. These can be downloaded from the UCSC table browser [1](<http://genome.ucsc.edu/cgi-bin/hgTables>) . You can then either write your own tools to create a fasta file with all the exon junctions, or use an existing tool, such as the "Make Splice Junction Fasta" application included in the USeq software package [2] (<http://useq.sourceforge.net/applications.html>) . Once you have a fasta file containing your exon-junction libarary you need to combine it with the fasta file for your reference genome.
    
    
       cat reference.fa junctions.fa >reference_and_junctions.fa
    

Then build a new bowtie index as descibed above
    
    
       bowtie-build reference_and_junctions.fa junction_lib
    

Finally, you map the reads in the same way as to the reference genome. For example,
    
    
       bowtie -p 8 --sam --best junction_lib sample.fa aligned_reads.sam
    

#### Further options

If this approach still does not map a reasonable number of reads, there are other alternative approaches that can be explored, at even greater computation cost. For example, you may try to estimate splice junctions from the data itself, using "De-novo" splice junction finders. There are many tools that attempt to do this, some examples include TopHat (<http://tophat.cbcb.umd.edu/>) , SplitSeek (<http://genomebiology.com/2010/11/3/R34>) , PerM (<http://code.google.com/p/perm/>) , soapAls (<http://soap.genomics.org.cn/soapals.html>) . Full de novo assembly of the transcriptome is also a possibility, although very high coverage is required for this to work well. Paired end data is of huge benefit to this task as either end of a fragment mapping to a different exon is very strong evidence for a splice junction. A list of such tools can be found in table 1 of the review article here [5].

## Differential Expression

A common use of expression assays is to look for differences in expression levels of genes or other objects of interest between two experimental conditions, such as a wildtype vs knockout. In order to do this we need to transform the data from a list of reads mapping to genomic coordinates into a table of counts. The strategy we employ here is to load the short reads into R using the Rsamtools package and then count the number of reads overlapping some annotation object, which is usually something like a collection of genes downloaded from the UCSC. Once transformed, a test can be performed to look for statistically significant differences in expression level.

### Summarization of reads

#### Compressing aligned reads using SAMtools

In order to be able to load millions of aligned reads into memory in R, we need to create a binary compressed version of our human readable SAM output. This file will contain all the same information, but have a much smaller memory footprint as well as being quickly searchable. To create such files, we first need to install [SAMtools](/w/index.php?title=SAMtools&action=edit&redlink=1)(<http://samtools.sourceforge.net/>) . Next we need to construct an index of the reference, using the fasta file. This is done by executing:
    
    
       samtools faidx reference.fa
    

Which creates a file reference.fa.fai. Next we convert SAM to BAM. BAM files contain all the same information as SAM files, but are compressed to be more space efficient and searchable.
    
    
       samtools import reference.fa.fai aligned_reads.sam aligned_reads.bam
    

Finally we need to create an index of the reads so they can be quickly searched. In order to do this we first need to sort the BAM file.
    
    
       samtools sort aligned_reads.bam aligned_reads_sorted
    

This will create aligned_reads_sorted.bam, which we now index.
    
    
       samtools index aligned_reads_sorted.bam
    

Which creates the index file aligned_reads_sorted.bam.bai.

If you don't have the original fasta file for the reference because you downloaded a prebuilt index from the BOWTIE website (or because you lost the fasta file after making your own), you can rebuild the source fasta file by running the following.
    
    
       bowtie-inspect reference_name>reference.fa
    

#### Working with BAM files in R

Our goal is to use R to summarize the reads by genes for each sample. To this end, we will use our newly created compressed representation of the short reads (the sorted, indexed, BAM file).

##### Fetching gene information

The first thing we need to do is to define the location of genes in chromosome coordinates. To do this, we use the GenomicFeatures (<http://www.bioconductor.org/packages/2.6/bioc/html/GenomicFeatures.html>) package. This package allows us to download gene information from the UCSC genome browser using the following commands:
    
    
       library(GenomicFeatures)
       txdb=makeTranscriptDbFromUCSC(genome='hg19',tablename='ensGene')
    

Various genomes and gene IDs are available, but as an example we will use the latest human genome and ENSEMBL gene IDs. The variable "txdb" now contains all the information we need, but in order to do anything with it we need to do some processing.
    
    
       tx_by_gene=transcriptsBy(txdb,'gene')
    

This produces a GRangesList object which is a list of GRanges objects, where each GRanges object is a gene and the entries are the genomic coordinates of its transcripts. We are going to work out which reads overlap which genes using the countOverlaps function to overlap this object with the object containing the short reads.

Although we are choosing to summarize by including all reads that fall within a gene here, the procedure will work the same for any GRanges or GRangesList object. For example, if you wished to only include reads that overlap exons, you could create a different GRangesList object.
    
    
       ex_by_gene=exonsBy(txdb,'gene')
    

##### Summarizing reads in R

First we load the aligned_reads_sorted.bam file into R.
    
    
       library(Rsamtools)
       reads=readBamGappedAlignments("aligned_reads_sorted.bam")
    

##### Checking compatibility of annotations and reads

Before we try and compare the reads to the annotation, we first need to do a few checks to make sure that everything will work OK. If your RNA-seq data did not come with strand information, than we cannot know which strand the read was transcribed from. However, the mapping process will map it to one strand or the other (in theory, both are equally likely), thus the reads will have a strand artificially allocated to them. When we count the number of reads overlapping a gene (or other feature), only those reads that map to the strand the gene is on will count and roughly half our reads will be lost. To avoid this we need to set the reads strand value to "*" (unknown).

Furthermore, it will often be the case that the chromosome names used by the alignment software (which are ultimately determined by the chromosome names in the fasta file for the reference genome) will differ from those given in the annotation. In order for the comparison function to work, these names need to be converted to the same naming convention. It is easy to check if the names match by listing all the chromosomes for both reads and annotations. Remember, our annotation data is stored in "tx_by_gene" and our short reads are stored in "reads".
    
    
       #The annotations have chromosomes called
       names(seqlengths(tx_by_gene))
       #The reads have chromosomes called
       as.character(unique(rname(reads)))
    

If the chromosome names are the same (or are the same for the ones you care about), then no name conversion is needed. If on the other hand they differ, we need to change either the reads or the annotations naming convention. It turns out that it is usually easier to change the names of the reads, but the procedure is the same regardless. This is best illustrated by an example. Suppose you have this situation:
    
    
       #The annotations have chromosomes called
       > names(seqlengths(tx_by_gene))
       [1] "chr1" "chr10" "chr11" "chr12" "chr13"
       [6] "chr13_random" "chr14" "chr15" "chr16" "chr17"
       [11] "chr17_random" "chr18" "chr19" "chr1_random" "chr2"
       [16] "chr3" "chr3_random" "chr4" "chr4_random" "chr5"
       [21] "chr5_random" "chr6" "chr7" "chr7_random" "chr8"
       [26] "chr8_random" "chr9" "chr9_random" "chrM" "chrUn_random"
       [31] "chrX" "chrX_random" "chrY" "chrY_random"
    
    
    
       #The reads have chromosomes called
       >as.character(unique(rname(reads)))
       [1] "10.1-129993255" "11.1-121843856" "1.1-197195432" "12.1-121257530"
       [5] "13.1-120284312" "14.1-125194864" "15.1-103494974" "16.1-98319150"
       [9] "17.1-95272651" "18.1-90772031" "19.1-61342430" "2.1-181748087"
       [13] "3.1-159599783" "4.1-155630120" "5.1-152537259" "6.1-149517037"
       [17] "7.1-152524553" "8.1-131738871" "9.1-124076172" "MT.1-16299"
       [21] "X.1-166650296" "Y.1-15902555"
    

So we need to convert the read chromosome names "NO.1-Length" to the annotation name "chrNO".
    
    
       new_read_chr_names=gsub("(.*)[T]*\\..*","chr\\1",rname(reads))
    

If you are not familiar with regular expressions, refer to the help file for gsub in R. new_read_chr_names will now contain the read chromosome names, converted to the same format as the annotation object tx_by_genes.

Now we can fix both the chromosome name and strand problem simultaneously, by building a GenomicRanges object from each of the read objects. If you have unstranded RNA-seq data and need to convert chromosomes, we run:
    
    
       reads=GRanges(seqnames=new_read_chr_names,ranges=IRanges(start=start(reads),end=end(reads)), 
         strand=rep("*",length(reads)))
    

If we just want to convert chromosome names.
    
    
           reads=GRanges(seqnames=new_read_chr_names,ranges=IRanges(start=start(reads),end=end(reads)), 
         strand=strand(reads))
    

If we just want to make each read be ambiguous with respect to strand.
    
    
       reads=GRanges(seqnames=rname(reads),ranges=IRanges(start=start(reads),end=end(reads)),
       strand=rep("*",length(reads)))
    

Note that if you mapped reads to an exon-junction library, every exon junction will have its own "chromosome". If you wish these junctions reads to be included in the summarization, you will have to convert each of them to genomic coordinates. As each read comes from two distinct genomic locations (either side of the exon junction), you will have to make a decision about how you are going to assign each read a genomic coordinate.

##### Counting the number of reads

Finally, we get the number of reads that overlap with each gene (or whatever else you're interested in).
    
    
       counts=countOverlaps(tx_by_gene,reads)
    

"counts" will now contain a numeric vector, where the ith entry is the number of reads that overlap the ith gene in "tx_by_gene".

### Differential Expression Testing

As our aim is to compare conditions, we will have more than one lane of reads, possibly several for each condition. Using the procedure outlined in the previous section, we can count the number of reads that overlap a feature of interest, such as genes, in each experimental condition, for each replicate. Next we combine them into a table of counts.
    
    
       toc=data.frame(condition1_rep1=counts1.1,condition1_rep2=counts1.2,
         condition2_rep1=counts2.1,condition2_rep2=counts2.2,stringsAsFactors=FALSE)
       rownames(toc)=names(tx_by_gene)
    

etc. for as many conditions and replicates as are available. Here the convention is countsn.m is the vector containing the number of reads from replicate m of condition n that overlap the genes given by tx_by_gene.

#### Normalization

It has been shown that a small number of highly expressed genes can consume a significant amount of the total sequence. As this can change between lanes and experimental condition, along with library size, it is necessary to perform some kind of between sample normalization when testing for differential expression. The choice of normalization is not independent of the test used to determine if any genes are significantly differentially expressed (DE) between conditions. For example, quantile normalization produces non-integer counts, making tests based on the assumption of count data such as the widely used Poisson or Negative Binomial models inapplicable. We choose to use the scaling factor normalization method as it preserves the count nature of the data and has been shown to be an effective means of improving DE detection [1].

To perform the normalization and the test for differential expression, we will use the R package edgeR (<http://www.bioconductor.org/packages/2.6/bioc/html/edgeR.html>) [2], although there are other options available. We can now calculate the normalization factors using the TMM method [1].
    
    
       library(edgeR)
       norm_factors=calcNormFactors(as.matrix(toc))
    

#### Statistical testing

Next, we have to create a DGE object used by edgeR. The scaling factor calculated using the TMM method is incorporated into the statistical test by weighting the library sizes by the normalization factors (which are then used as an offset in the statistical model).
    
    
       DGE=DGEList(toc,lib.size=norm_factors*colSums(toc),group=rep(c("Condition1","Condition2"),c(2,2)))
    

The group variable identifies which columns in the table of contents come from which experimental condition or "group". To perform the statistical test for significance, we first estimate the common dispersion parameter
    
    
       disp=estimateCommonDisp(DGE)
    

Finally, we calculate the p-values for genes being DE
    
    
       tested=exactTest(disp)
    

## Gene Set testing (GO)

To accurately test sets of genes for over representation amongst DE genes using RNA-seq data, we need to use a method which takes into account the biases particular to this technology. The goseq package (<http://www.bioconductor.org/packages/2.6/bioc/html/goseq.html>) is one such method for accounting for certain RNA-seq specific biases when performing GO (and other gene set based tests) analysis [3]. First we must format the output of edgeR to be read by goseq. We call any gene with a Benjamini-Hochberg FDR of less than .05 DE.
    
    
       library(goseq)
       genes = as.integer(p.adjust(tested$table$p.value, method = "BH") < 0.05)
       names(genes) = row.names(tested$table)
    

Next, we calculate a probability weighting function, correcting for length bias, a technical bias present in all forms of RNA-seq data (see [3] for a details).
    
    
       pwf=nullp(genes,'hg19','ensGene')
    

If we'd instead wanted to correct for total read count bias, we would calculate the pwf using the number of counts from each gene as follows:
    
    
       pwf=nullp(genes,bias.data=rowsum(counts[match(names(genes),rownames(counts))]))
    

Finally, we calculate the p-value for each GO category being over represented amongst DE genes.
    
    
       GO.pvals=goseq(pwf,'hg19','ensGene')
    

## Example 1: Differential Expression and GO Term Analysis: Li Prostate cancer data set

This section provides an easy to follow example to illustrate the analysis pipeline outlined above.

### Description

This data set compares prostate cancer LNcap cell lines with and without treatment by the testosterone like hormone androgen [4]. The sequencing was done using the Illumina GA I and produced 36 bp, single end, unstranded reads. The output from the machine are 7 files (each from a different sequencing lane):

untreated1.fa

untreated2.fa

untreated3.fa

untreated4.fa

treated1.fa

treated2.fa

treated3.fa

Note that this data set is slightly unusual in that the quality scores are missing from the reads. Therefore, we will have to keep this in mind when doing the analysis.

### Quality Control

It's published data, so that's a pretty good quality control one would hope...

### Sequence alignment

#### Building the reference

The first step in the pipeline is to align all the reads to a reference. As this data is taken from human LNcap cells, the latest build of the human genome is an obvious choice. We have installed BOWTIE (version 0.10.0) using all the standard options. There is a prebuilt copy of the human index available from the BOWTIE website, however, to illustrate building a genome from scratch we instead download the .fa files for the genome from the UCSC. We create a working directory containing the 7 RNA-seq data files and the file chromFA.tar.gz downloaded from <http://hgdownload.cse.ucsc.edu/goldenPath/hg19/bigZips/>. The file chromFA.tar.gz contains the sequence of all human chromosomes, including the unallocated contigs. To make a BOWTIE index we need to concatenate them into a single file. We will exclude all the contigs from our fasta file.
    
    
       tar -zxvf chromFA.tar.gz
    

We only want chr1-22.fa, chrX.fa, chrY.fa and chrM.fa, so delete everything else:
    
    
       rm chr*_*.fa
    

Now we concatenate the desired files (it is useful to have the reference both in one chromosome per file and one file per genome formats, although the BOWTIE index can be made from either).
    
    
       cat chr*.fa>hg19.fa
    

We build the BOWTIE index and name it hg19.
    
    
       bowtie-build hg19.fa hg19
    

And move the BOWTIE index files to the appropriate location for BOWTIE to find them.
    
    
       mv *.ebwt $BOWTIE_INDEXES
    

#### Aligning the reads

Having constructed the BOWTIE index for the human genome, we now proceed to map the reads from each lane. We want to use the --best and --sam flags. At this point we recall that our data lacks quality information for the reads. Therefore, we use the -v 3 option which ignores quality scores when aligning reads to the genome.
    
    
       for src_fastafile in *treated*.fa
       do
         bowtie -v 3 -p 8 --best --sam hg19 ${src_fastafile} ${src_fastafile%%.fa}.sam
       done
    

The for loop is just for convenience and is equivalent to writing:
    
    
       bowtie -v 3 -p 8 --best --sam hg19 untreated1.fa untreated1.sam
       bowtie -v 3 -p 8 --best --sam hg19 untreated2.fa untreated2.sam
       bowtie -v 3 -p 8 --best --sam hg19 untreated3.fa untreated3.sam
       bowtie -v 3 -p 8 --best --sam hg19 untreated4.fa untreated4.sam
       bowtie -v 3 -p 8 --best --sam hg19 treated1.fa treated1.sam
       bowtie -v 3 -p 8 --best --sam hg19 treated2.fa treated2.sam
       bowtie -v 3 -p 8 --best --sam hg19 treated3.fa treated3.sam
    

BOWTIE will output 7 SAM files containing the aligned reads. To count the fraction of aligned reads we run the following command at the shell (this information is also reported directly by BOWTIE, but it is useful to be able to calculate it yourself if need be).
    
    
       awk '$3!="*"' untreated1.fa|wc -l
       wc -l untreated1.fa
    

The first command prints the number of reads that have mapped in the BOWTIE output file, the second outputs 4 times the number of reads in the input file (because the fasta format is for 4 lines per read).

We will ignore those reads that cross exon-exon boundaries and continue with the analysis.

### Summarization of reads

#### Converting to BAM

In order to summarize our aligned reads into genes, we first have to convert the SAM output of BOWTIE into the compressed, index BAM format. First we need to create an index for the human genome in the samtools format. For this we need the fasta file for the reference (which should be the same that was used to create the index for aligning the reads), which we already have, but we will reconstruct it from the BOWTIE index anyway.
    
    
       bowtie-inspect hg19>hg19.fa
    

Now we construct the samtools index. The following command produces a .fai file which we can use to convert the SAM files to BAM files.
    
    
       samtools faidx hg19.fa
    

Next, we convert all 7 SAM files to BAM files.
    
    
       for SAM in *.sam
       do
         #Convert to BAM format
         samtools import hg19.fa.fai ${SAM} ${SAM%%.sam}.bam
         #Sort everything
         samtools sort ${SAM%%.sam}.bam ${SAM%%.sam}_sorted
         #Create an index for fast searching
         samtools index ${SAM%%.sam}_sorted.bam
         #Delete temporary files
         rm ${SAM%%.sam}.bam
       done
    

Again, the bash for loop is just for convenience, the above is equivalent to running the following for all 7 files:
    
    
       samtools import hg19.fa.fai untreated1.sam untreated1.bam
       samtools sort untreated1.bam untreated1_sorted
       samtools index untreated1_sorted.bam
       rm untreated1.bam
    

#### Processing in R

Next we need to load the sorted, indexed, BAM files into R. As we have unstranded RNA-seq, we need to make the strand designator for each read ambiguous (which is done by setting it to "*"). After starting R we run,
    
    
       library(Rsamtools)
       #Create a list of bam file object containing the short reads
       bamlist=list()
       src_files=list.files(pattern="*_sorted.bam$")
       for(filename in src_files){
         #Since we do not know which strand the reads were originally transcribed,
         #so set the strand to be ambiguous
         tmp=readBamGappedAlignments(filename)
         bamlist[[length(bamlist)+1]]=GRanges(seqnames=rname(tmp),
           ranges=IRanges(start=start(tmp),end=end(tmp)),
           strand=rep("*",length(tmp)))
       }
       names(bamlist)=src_files
    

Having loaded the files into R, we next need to create an annotation object. Since we are using hg19, we can readily download one from the UCSC using the GenomicFeatures package. We choose to use the ENSEMBL gene annotation.
    
    
       library(GenomicFeatures)
       txdb=makeTranscriptDbFromUCSC(genome="hg19",tablename="ensGene")
    

We want to compare genes for differential expression, so we will summarize by gene and we choose to count all reads that fall within the body of the gene (including introns) as counting towards a genes count.
    
    
       tx_by_gene=transcriptsBy(txdb,"gene")
    

Finally, we count the number of reads that fall in each gene for each lane and record the results in a table of counts.
    
    
       #Initialize table of counts
       toc=data.frame(rep(NA,length(tx_by_gene)))
       for(i in 1:length(bamlist)){
         toc[,i]=countOverlaps(tx_by_gene,bamlist[[i]])
       }
       #Fix up labels
       rownames(toc)=names(tx_by_gene)
       colnames(toc)=names(bamlist)
    

### Differential Expression testing

Having finally obtained a table of counts, we now want to compare the treated and untreated groups and look for any statistically significant differences in the number of counts for each gene. We will do this using the negative binomial model used by edgeR.

#### Normalization

We calculate appropriate scaling factors for normalization using the TMM method with the first lane as the reference.
    
    
       library(edgeR)
       norm_factors=calcNormFactors(as.matrix(toc))
    

The counts themselves are not changed, instead these scale factors are used as an offset in the negative binomial model. This is incorporated in the DGE list object required by edgeR.
    
    
       DGE=DGEList(toc,lib.size=norm_factors*colSums(toc),group=gsub("[0-9].*","",colnames(toc)))
    

#### Statistical Test

Next we calculate a common dispersion parameter which represents the additional extra Poisson variability in the data.
    
    
       disp=estimateCommonDisp(DGE)
    

Which allows us to calculate p-values for genes being differentially expressed.
    
    
       tested=exactTest(disp)
    

### Gene Ontology testing

In order to test for over represented GO categories amongst DE genes, we first have to pick a cutoff for calling genes as differentially expressed after applying multiple hypothesis correction. We choose the ever popular cutoff for significance of .05
    
    
       library(goseq)
       #Apply benjamini hochberg correction for multiple testing
       #choose genes with a p-value less than .05
       genes=as.integer(p.adjust(tested$table$p.value,method="BH") <.05)
       names(genes)=row.names(tested$table)
    

Now we calculate the probability weighting function, which quantifies the length bias effect.
    
    
       pwf=nullp(genes,"hg19","ensGene")
    

Finally, we calculate the p-values for each GO category being over represented amongst DE genes.
    
    
       GO.pvals=goseq(pwf,"hg19","ensGene")
    

# Example 2 Differential Expression: Di Arabidopsis pathogen data
    
    
     Donwnload the six fastq.gz files from here: [http://www.ebi.ac.uk/ena/data/view/SRP004047&display=html](http://www.ebi.ac.uk/ena/data/view/SRP004047&display=html)
    

These files are from an Arabidopsis study using three replicates each from infected and mock infected plants. This is the data set underlying the NBPSeq R package.

### Quality Control
    
    
     Download FastQC and open the files in FastQC one by one.
     You can open the files by using File->Open. 
    

_As of Version 0.94. if you are on Windows use the Linux version and double-click run_fastqc.bat_
    
    
     You will see a very wiggly line for the first library. If you just look at the peaks and note the sequence you will see the pattern
     AAGAGCTCGTATGC starting at the green plateu towards the right. This is an illumina adapter sequence, which you will also see in the
     overrepresented counts tab.
    

[File:FastQC.png](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=FastQC.png)

### Mapping Reads

Download the Arabidopsis genome release from here
    
    
     <ftp://ftp.arabidopsis.org/home/tair/Sequences/blast_datasets/other_datasets/CURRENT/arabidopsis.seq.gz>
     It doesn't include mitochondrial or chlorplast sequences but is good enough for the tutorial purpose
    
    
    
     unzip all read files 
    

Using bowtie an index needs to be built
    
    
     Unix systems
     bowtie-build arabidopsis.seq arabidopsis
    
    
    
     Windows
     C:\Prog\bowtie-0.12.7\bowtie-build.exe arabidopsis.seq arabidopsis
    

Alternatively, you can download the provided index file from the bowtie website if you work with one of the supported organisms.

  
Now you can map reads using bowtie. [Bowtie](/w/index.php?title=Bowtie&action=edit&redlink=1) has many options and you better check them. Here we tell it to use two processors (-p 2) to report SAM based alignements -S for all (-a) aligment having maximally one mismatch (-v 1). We further restrict this based on the fact that only each read providing more than one valid alignment should be discarded (-m 1)
    
    
     bowtie -p 2 -S -a -m 1 -v 1 arabidopsis SRR074262.fastq aligned_074262
     bowtie -p 2 -S -a -m 1 -v 1 arabidopsis SRR074263.fastq aligned_074263
     bowtie -p 2 -S -a -m 1 -v 1 arabidopsis SRR074264.fastq aligned_074264
     bowtie -p 2 -S -a -m 1 -v 1 arabidopsis SRR074284.fastq aligned_074284
     bowtie -p 2 -S -a -m 1 -v 1 arabidopsis SRR074285.fastq aligned_074285
     bowtie -p 2 -S -a -m 1 -v 1 arabidopsis SRR074286.fastq aligned_074286
    
    
    
     C:\Prog\bowtie-0.12.7\bowtie.exe -p 2 -S -a -m 1 -v 1 arabidopsis SRR074262.fastq aligned_074262
     
    

This needs to be repeated for all 6 libraries.

Output SRR074262.fastq

  1. reads processed: 9619406
  2. reads with at least one reported alignment: 5034111 (52.33%)
  3. reads that failed to align: 4132070 (42.96%)
  4. reads with alignments suppressed due to -m: 453225 (4.71%)

Reported 5034111 alignments to 1 output stream(s)

Output SRR074263.fastq

  1. reads processed: 4199495
  2. reads with at least one reported alignment: 2298490 (54.73%)
  3. reads that failed to align: 1701822 (40.52%)
  4. reads with alignments suppressed due to -m: 199183 (4.74%)

Reported 2298490 alignments to 1 output stream(s)

Output SRR074264.fastq

  1. reads processed: 4810892
  2. reads with at least one reported alignment: 2730242 (56.75%)
  3. reads that failed to align: 1852040 (38.50%)
  4. reads with alignments suppressed due to -m: 228610 (4.75%)

Reported 2730242 alignments to 1 output stream(s)

  
Output SRR074284.fastq

  1. reads processed: 4763394
  2. reads with at least one reported alignment: 2622118 (55.05%)
  3. reads that failed to align: 1908441 (40.06%)
  4. reads with alignments suppressed due to -m: 232835 (4.89%)

Reported 2622118 alignments to 1 output stream(s)

Output SRR074285.fastq

  1. reads processed: 8217239
  2. reads with at least one reported alignment: 4515790 (54.96%)
  3. reads that failed to align: 3206578 (39.02%)
  4. reads with alignments suppressed due to -m: 494871 (6.02%)

Reported 4515790 alignments to 1 output stream(s)

  
Output SRR074286.fastq

  1. reads processed: 3776979
  2. reads with at least one reported alignment: 2014498 (53.34%)
  3. reads that failed to align: 1506142 (39.88%)
  4. reads with alignments suppressed due to -m: 256339 (6.79%)

Reported 2014498 alignments to 1 output stream(s)

### Summarizing Reads

If you want to use [HTSeq-count](http://www-huber.embl.de/users/anders/HTSeq/doc/count.html) and are on Fedora or CentOS you will have to go through some extra effort, as HTSeq uses python 2.6 and Fedora and CentOS only come with python 2.4 installed. (_Before you do any of the following ask your sysadmin if this is ok_)

here are some suggestions <http://stackoverflow.com/questions/1465036/install-python-2-6-in-centos> My favorite one is to use EPEL (see below), buy YMMV.
    
    
     rpm -Uvh <http://download.fedora.redhat.com/pub/epel/5/i386/epel-release-5-4.noarch.rpm>
     yum install python26
     yum install python26-numpy
     yum install python26-numpy-devel
    

Then continue as detailed on the website but type
    
    
     python26 setup.py build
     python26 setup.py install
    

instead of
    
    
     python setup.py build
     python setup.py install
    

\---

Now we are ready to download the gff file <ftp://ftp.arabidopsis.org/home/tair/Genes/TAIR10_genome_release/TAIR10_gff3/TAIR10_GFF3_genes.gff>

This file does not contain RNA genes and transposable elements.

Now the parent ID probably works for some use cases of HTSeq. If you needed a true GTF file you could use the perl script mentioned [here](http://seqanswers.com/forums/showthread.php?t=2605) at the bottom If we named it celeste_script.pl here would be what to execute. (The reason we can't use -i Parent is that otherwise an exon might belong to two splice variants e.g. AT1G01040.1 and AT1G01040.2 and not be counted as we want to use intersection-strict)
    
    
     cat TAIR10_GFF3_genes.gff |perl celeste_script.pl > TAIR10_GTF.gtf 
    

and now finally
    
    
     htseq-count -m intersection-strict -s no aligned_074262 TAIR10_GTF.gff > counts_074262
     htseq-count -m intersection-strict -s no aligned_074263 TAIR10_GTF.gtf > counts_074263
     htseq-count -m intersection-strict -s no aligned_074264 TAIR10_GTF.gtf > counts_074264
     htseq-count -m intersection-strict -s no aligned_074284 TAIR10_GTF.gtf > counts_074284
     htseq-count -m intersection-strict -s no aligned_074285 TAIR10_GTF.gtf > counts_074285
     htseq-count -m intersection-strict -s no aligned_074286 TAIR10_GTF.gtf > counts_074286
    

Now we start getting something we can use
    
    
     head counts_074262
    
    
    
     AT1G01010       75
     AT1G01020       73
     AT1G01030       33
     AT1G01040       109
     AT1G01046       0
     AT1G01050       41
     AT1G01060       10
     AT1G01070       2
     AT1G01073       0
     AT1G01080       281
    
    
    
     head counts_074263
    
    
    
     AT1G01010       35
     AT1G01020       34
     AT1G01030       18
     AT1G01040       52
     AT1G01046       0
     AT1G01050       51
     AT1G01060       5
     AT1G01070       19
     AT1G01073       0
     AT1G01080       212
    
    
    
     head counts_074264
    
    
    
     AT1G01010       80
     AT1G01020       46
     AT1G01030       45
     AT1G01040       50
     AT1G01046       0
     AT1G01050       69
     AT1G01060       13
     AT1G01070       35
     AT1G01073       0
     AT1G01080       226
    
    
    
     head counts_074284
    
    
    
     AT1G01010       45
     AT1G01020       50
     AT1G01030       33
     AT1G01040       65
     AT1G01046       0
     AT1G01050       50
     AT1G01060       0
     AT1G01070       7
     AT1G01073       0
     AT1G01080       178
    
    
    
     head counts_074285
    
    
    
     AT1G01010       35
     AT1G01020       43
     AT1G01030       26
     AT1G01040       72
     AT1G01046       0
     AT1G01050       51
     AT1G01060       3
     AT1G01070       6
     AT1G01073       0
     AT1G01080       531
    

  

    
    
     head counts_074286
    
    
    
     AT1G01010       61
     AT1G01020       27
     AT1G01030       36
     AT1G01040       25
     AT1G01046       0
     AT1G01050       25
     AT1G01060       16
     AT1G01070       20
     AT1G01073       0
     AT1G01080       128
    

### Analysis of differentially expressed genes

start R

  
using DESeq (now refer to the [vignette](http://www.bioconductor.org/packages/2.8/bioc/vignettes/DESeq/inst/doc/DESeq.pdf))
    
    
     R
     
    

In R:
    
    
     library(DESeq)
     setwd("where the data is")
     c1<-read.table("counts_074284",row.names=1) 
     c2<-read.table("counts_074286",row.names=1)
     c3<-read.table("counts_074262",row.names=1)
     c4<-read.table("counts_074263",row.names=1)
     c5<-read.table("counts_074264",row.names=1)
     c6<-read.table("counts_074285",row.names=1)
     counts<-cbind(c1,c2,c3,c4,c5,c6)
     counts<-counts[-c(32679:32683),]  #remove the more general lines
     colnames(counts)<-c("P1","P2","P3","M1","M2","M3")
     design <- rep (c("P","Mo"),each=3)
     de  <-  newCountDataSet(counts, design)
     de  <-  estimateSizeFactors( de)
     # de  <-  estimateVarianceFunctions(  de  ) # This function has been removed. Use 'estimateDispersions' instead.  
     de <- estimateDispersions( de )
     res  <-  nbinomTest(  de,  "P",  "Mo")
    

How many genes are significant?
    
    
     sum(na.omit(res$padj<0.05))
    

## References

[1] Robinson MD and Oshlack A. A scaling normalization method for differential expression analysis of RNA-seq data. Genome Biology (2010), 11(3), R25

[2] Robinson MD*, McCarthy DJ* and Smyth GK (2010) edgeR: a Bioconductor package for differential expression analysis of digital gene expression data. Bioinformatics, 26(1):139-40

[3] Young MD, Wakefield MJ, Smyth GK and Oshlack A. Gene ontology analysis for RNA-seq: accounting for selection bias. Genome Biology (2010),11(2), R14

[4] Li H, Lovci MT, Kwon YS, Rosenfeld MG, Fu XD, Yeo GW Determination of tag density required for digital transcriptome analysis: application to an androgen-sensitive prostate cancer model. Proc Natl Acad Sci USA 2008 , 105:20179-20184.

[5] Oshlack A, Robinson MD, Young MD. From RNA-seq reads to differential expression results. Genome Biology (2010), 11:220

  


  1. ↑ <http://www.sanger.ac.uk/research/projects/vertebrategenome/havana/>
  2. ↑ <http://www.ncbi.nlm.nih.gov/refseq/>
  3. ↑ <http://bioinformatics.oxfordjournals.org/content/22/9/1036.long>

  


# Epigenetics

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[RNA](/wiki/Next_Generation_Sequencing_\(NGS\)/RNA)**
**Epigenetics**
**[Chromatin structure](/wiki/Next_Generation_Sequencing_\(NGS\)/Chromatin_structure)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Epigenetic**_](//en.wikipedia.org/wiki/Epigenetic)

## Epigenetics

Epigenetics is the science that studies inheritable traits not transmitted by plain sequence information. NGS can assess a particular non-standard epigenetics effect, which is the amount of _methylation_ occurring on cytosines. This methylation is important biologically because it may influence the level of packing of chromatine and therefore affect efficiency of transcription in entire genomic areas. Cytosine methylation is reversible but inheritable somatically and germinally.

Genomic DNA can be treated with bisulfite[1], protocol that will transform only non-methylated cytosines into thymidines. Methylated cytosines are not affected, and will still be sequenced as such. A common NGS application in epigenetics is to align bisulfite-treated reads from a known organism on a reference genome, to assess the degree of methylation in particular areas. However, the complexity of the alignment will be higher, alongside with the reduced complexity of the reads (with several Cs being turned into Ts). Therefore, genomic DNA samples are sequenced both with and without bisulfite treatment, operation which allow to assess and normalize for the initial of reads aligning on specific regions.

Specific short read aligners exist for this task, just to name a few:

  * [erne-bs5](http://erne.sourceforge.net/)
  * [Bismark](http://www.bioinformatics.babraham.ac.uk/projects/bismark/)
  * [brat-bw](http://compbio.cs.ucr.edu/brat/)

### Protocols

### Typical workflow

### File formats

### Creating a dataset

### Reference datasets

### Viewing datasets

### Comparing datasets

  


# Chromatin structure

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[Epigenetics](/wiki/Next_Generation_Sequencing_\(NGS\)/Epigenetics)**
**Chromatin structure**
**[De novo assembly](/wiki/Next_Generation_Sequencing_\(NGS\)/De_novo_assembly)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Chromatin_structure**_](//en.wikipedia.org/wiki/Chromatin_structure)

## Chromatin structure

### Protocols

### Typical workflow

### File formats

### Creating a dataset

### Reference datasets

### Viewing datasets

### Comparing datasets

  


# De novo assembly

**[Next Generation Sequencing (NGS)](/wiki/Next_Generation_Sequencing_\(NGS\))**

**[Chromatin structure](/wiki/Next_Generation_Sequencing_\(NGS\)/Chromatin_structure)**
**De novo genome assembly**
**[De novo RNA assembly](/wiki/Next_Generation_Sequencing_\(NGS\)/De_novo_RNA_assembly)**

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Sequence_assembly**_](//en.wikipedia.org/wiki/Sequence_assembly)

## De novo assembly

The generation of short reads by next generation sequencers has lead to an increased need to be able to assemble the vast amount of short reads that are generated. This is no trivial problem, as the sheer number of reads makes it near impossible to use, for example, the overlap layout consensus (OLC) approach that had been used with longer reads. Therefore, most of the available assemblers that can cope with typical data generated by Illumina use a de Bruijn graph based k-mer based approach.

A clear distinction has to be made by the size of the genome to be assembled.

  * small (e.g. bacterial genomes: few Megabases)
  * medium (e.g. lower plant genomes: several hundred Megabases)
  * large (e.g. mammalian and plant genomes: Gigabases)

All de-novo assemblers will be able to cope with small genomes, and _given decent sequencing libraries_ will produce relatively good results. Even for medium sized genomes, most de-novo assemblers mentioned here and many others will likely fare well and produce a decent assembly. That said, OLC based assemblers might take weeks to assemble a typical genome. Large genomes are still difficult to assemble when having only short reads (such as those provided by Illumina reads). Assembling such a genome with Illumina reads will probably will require using a machine that has about 256 GB and potentially even 512GB RAM, unless one is willing to use a small cluster ([ABySS](http://seqanswers.com/wiki/ABySS), [Ray](http://seqanswers.com/wiki/Ray), [Contrail](http://seqanswers.com/wiki/Contrail)), or invest into commercial software ([CLCbio_Genomics_Workbench](http://seqanswers.com/wiki/CLCbio_Genomics_Workbench)).

### Typical workflow

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/11/WGS_denovo_assembly_overview.png/600px-WGS_denovo_assembly_overview.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Overview of the denovo assembly process for WGS

A genome assembly project, whatever its size, can generally be divided into stages:

  1. Experiment design
  2. Sample collection
  3. Sample preparation
  4. Sequencing
  5. [Pre-processing](/wiki/Next_Generation_Sequencing_\(NGS\)/Pre-processing)
  6. Assembly
  7. Post-assembly analysis

  


#### Experiment design

Like any project, a good _de novo_ assembly starts with proper experimental design. Biological, experimental, technical and computational issues have to be considered:

  * Biological issues: What is known about the genome? 
    * How big is it? Obviously, bigger genomes will require more material.
    * How frequent, how long and how conserved are repeat copies? More repetitive genomes will possibly require longer reads or long distance mate-pairs to resolve structure.
    * How AT rich/poor is it? Genomes which have a strong AT/GC imbalance (either way) are said to have low information content. In other words, spurious sequence similarities will be more frequent.
    * Is is haploid, diploid, or polyploid? Currently genome assemblers deal best with haploid samples, and some provide a haploid assembly with annotated heterozygous sites. Polyploid genomes (e.g. plants) are still largely problematic.
  * Experimental issues: What sample material is available? 
    * Is it possible to extract a lot of DNA? If you have only little material, you might have to amplify the sample (e.g. using MDA), thus introducing biases.
    * Does that DNA come from a single cell, a clonal population, or a heterogeneous collection of cells? Diversity in the sample can create more or less noise, which different assemblers handle differently.
  * Technical issues: What sequencing technologies to use? 
    * How much does each cost?
    * What is the sequence quality? The greater the noise, the more coverage depth you will need to correct for errors.
    * How long are the reads? The longer the reads, the more useful they will be to disambiguate repetitive sequence.
    * Can paired reads be produced cost-effectively and reliably? If so, what is the fragment length? As with long reads, reliable long distance paired can help disambiguate repeats and scaffold the assembly.
    * Can you use a hybrid approach? E.g. short and cheap reads mixed with long expensive ones.
  * Computational issues: What software to run? 
    * How much memory do they require? This criteria can be final, because if a computer does not have enough memory, it will either crash, or slow down tremendously as it swaps data on and off the hard drive.
    * How fast are they? This criteria is generally less stringent, since the assembly time is generally minor within a complete genome assembly and annotation project. However, some scale better than other.
    * Do they require specific hardware? (e.g. large memory machine, or cluster of machines)
    * How robust are they? Are they prone to crash? Are they well supported?
    * How easy are they to install and run?
    * Do they require a special protocol? Can they handle the chosen sequencing technology?

Some steps which are likely common to most assemblies:

  1. If it is within reason and would not tamper with the biology: Try to get DNA from haploid or at least mostly homozygous individuals.
  2. Make sure that all libraries are really ok quality-wise and that there is no major concern (e.g. use FastQC)
  3. For paired end data you might also want to estimate the insert size based on draft assemblies or assemblies which you have made already.
  4. Before submitting data to a de-novo assembler it might often be a good idea to clean the data, e.g. to trim away bad bases towards the end and/or to drop reads altogether. As low quality bases are more likely to contain errors, these might complicate the assembly process and might lead to a higher memory consumption. (More is not always better) That said, several general purpose short read assemblers such as SOAP de-novo and ALLPATHS-LG can perform read correction prior to assembly.
  5. Before running any large assembly, double and triple check the parameters you feed the assembler.
  6. Post assembly it is often advisable to check how well your read data really agrees with the assembly and if there are any problematic regions
  7. If you run de Bruijn graph based assemblies you will want to try different k-mer sizes. Whilst there is no rule of thumb for any individual assembly, smaller k-mers would lead to a more tangled graph if the reads were error free. Larger k-mer sizes would yield a less tangled graph, given error free reads. However, a lower k-mer size would likely be more resistant to sequencing errors. And a too large k might not yield enough edges in the graph and would therefore result in small contigs.

#### Data pre-processing

For a more detailed discussion, see the chapter dedicated to [pre-processing](/wiki/Next_Generation_Sequencing_\(NGS\)/Pre-processing).

Data pre-processing consists in filtering the data to remove errors, thus facilitating the work of the assembler. Although most assemblers have integrated error correction routines, filtering the reads will generally greatly reduce the time and memory overhead required for assembly, and probably improve results too.

#### Genome assembly

Genome assembly consists in taking a collection of sequencing reads, which are much shorter than the actual genome, and creating a genome sequence which is a likely source of all these fragments. What defines a likely genome depends generally on heuristics and the data available. Firstly, by parsimony, the genome must be as short as possible. One could take all the reads and simply produce the concatenation of all their sequences, but this wold not be parsimonious. Secondly, the genome must include as much of the input data as possible. Finally, the genome must satisfy as many of the experimental data as possibly. Typically, paired-end reads are expected to map onto the genome with a given respective orientation and a given distance from each other.

The output of an assembler is generally decomposed into [contigs](http://en.wikipedia.org/wiki/Contig), or contiguous regions of the genome which are nearly completely resolved, and scaffolds, or sets of contigs which are approximately placed and oriented with respect to each other.

There are many assemblers available (See the Wikipedia page on [sequence assembly](http://en.wikipedia.org/wiki/Assembler_%28bioinformatics%29) for more details). Tutorials on how to use some of them are below.

#### Post-assembly analysis

Once a genome has been obtained, a number of analyses are possible, if not necessary:

  * Quality control
  * Comparison to other assemblies
  * Variant detection
  * Annotation

### Creating a dataset

#### Free Software

##### ABySS

[ABySS](http://seqanswers.com/wiki/ABySS) is a de-novo assembler which can run on multiple nodes where it uses the message parsing interface (MPI) interface for communication. As ABySS distributes tasks, the amount of RAM needed per machine is smaller and thus Abyss is able to cope with large genomes. See [here](/wiki/Next_Generation_Sequencing_\(NGS\)/ABySS) for a tutorial.

  * Pros 
    * distributed interface a cluster can be used
    * a large genome can be assembled with relatively little RAM per compute node. A human genome was assembled on 21 nodes having **16GB RAM each**
  * Cons 
    * relatively slow

##### Allpaths-LG

Allpath-LG is a novel assembler requiring specialized libraries. The authors of the software benchmarked ALLPATH-LG against SOAP-denovo and ALLPATH-LG reported superior performance. However it must be noted that they might not have used the SOAP-denovo gap filling module for one of the data set due to time constraints. This would probably have improved the SOAP assembly contiguous sequence length. In our own hand (usadellab) we have seen similar good N50 results and also ([Schneeberger et al. 2011](http://www.pnas.org/content/108/25/10249.long)), reported good N50 values for ALLPATHS-LG Arabidopsis assemblies. Similarly ALLPATHS-LG was named as well performing in the assemblathon.

  * Pros 
    * relatively fast runtime (slower than SOAP)
    * good scaffold length (likely better than SOAP)
    * can use long reads (e.g. PAC Bio) but only for small genomes
  * Cons 
    * specially tailored libraries are necessary
    * large genomes (mammalian size) need a lot of RAM. The publications estimates about **512GB** would be sufficient though
    * slower than SOAP

##### Euler SR USR

[EULER](http://seqanswers.com/wiki/EULER) is an assembler that includes an error correction module.

  * Pros 
    * Has an error correction module
  * Cons

##### MIRA

[MIRA](http://seqanswers.com/wiki/MIRA) is a general purpose assembler that can integrate various platform data and perform true hybrid assemblies.

  * Pros 
    * very well documented and many switches
    * can combine different sequencing technologies
    * likely relatively good quality data
  * Cons 
    * Only partly multithreaded thus and due to the technology slow
    * Probably not recommended to assemble larger genomes

##### Ray

[Ray](http://seqanswers.com/wiki/Ray) is a distributed scalable assembler tailored for bacterial genomes, metagenomes and virus genomes.

Tutorial available [here](/wiki/Next_Generation_Sequencing_\(NGS\)/Ray)

  * Pros 
    * scalability (uses MPI)
    * correctness
    * usability
    * well documented
    * responsive mailing list
    * can combine different sequencing technologies
    * de Bruijn-based
  * Cons

##### SOAP de novo

[SOAPdenovo](http://seqanswers.com/wiki/SOAPdenovo) is an all purpose genome assembler. It was used to assemble the giant panda genome. See [here](/wiki/Next_Generation_Sequencing_\(NGS\)/SOAPdenovo) for a tutorial.

  * Pros 
    * SOAP de novo uses a medium amount of RAM
    * SOAP de novo is relatively fast (probably the fastest free assembler)
    * SOAP de novo contains a scaffolder and a read-corrector
    * SOAP de novo is relatively modular (read-corrector, assembly, scaffold, gap-filler)
  * Cons 
    * potentially somewhat confusing way in which contigs are built.
    * Relatively large amount of RAM needed, [BGI](http://soap.genomics.org.cn/soapdenovo.html) states ca. **150GB** (less than ALLPATHS though)

##### SPAdes

[SPAdes](http://seqanswers.com/wiki/SPAdes) is an single-cell genome assembler.

  * Pros 
    * SPAdes works good with highly non-uniform coverage (e.g. after using Multiple Displacement Amplification)
    * SPAdes uses medium ammount of RAM
    * SPAdes is relatively fast
    * SPAdes includes error correction software BayesHammer
    * SPAdes have scaffolder (version 2.3+)
  * Cons 
    * SPAdes is well tested only on bacterial genomes
    * SPAdes works with Illumina reads only

##### Velvet

See [here](/wiki/Next_Generation_Sequencing_\(NGS\)/Velvet) for a tutorial on creating an assembly with Velvet.

  * Pros 
    * Easy to install, stable
    * Easy to run
    * Fast (multithreading)
    * Can take in long and short reads, works with SOLiD colorspace reads
    * Can use a reference genome to anchor reads which normally map to repetitive regions (Columbus module)
  * Cons 
    * Velvet might need large amounts of RAM for large genomes, potentially **> 512 GB** for a human genome based if at all possible. This is based on an approximation formula derived by [Simon Gladman](http://listserver.ebi.ac.uk/pipermail/velvet-users/2009-July/000474.html) for smaller genomes -109635 + 18977*ReadSize + 86326*GenomeSize in MB + 233353*NumReads in million - 51092*Kmersize

##### Minia

[Minia](http://seqanswers.com/wiki/Minia) is a de Bruijn graph assembler optimized for very low memory usage.

  * Pros 
    * Assembles very large genomes quickly on modest resources
    * Easy to install, run
  * Cons 
    * Illumina data only
    * Does not perform any scaffolding
    * Some steps are I/O-intensive, i.e. a local hard disk should be used rather than a network drive

#### Commercial

##### CLC cell

The CLC assembly cell is a commercial assembler released by CLC. It is based on a de Bruijn graph approach.

  * Pros 
    * CLC uses very little RAM
    * CLC is very fast
    * CLC contains a scaffolder (version 4.0+)
    * CLC can assemble data from most common sequencing platforms.
    * Works on Linux, Mac and Windows.
  * Cons 
    * CLC is not free
    * CLC might be a bit more liberal in folding repeats based on our own plant data.

##### Newbler

[Newbler](http://seqanswers.com/wiki/Newbler) is an assembler released by the Roche company.

  * Pros 
    * Newbler has been used in many assembly projects
    * Newbler seems to be able to produce good N50 values
    * Newbler is often relatively precise
    * Newbler can usually be obtained free of charge
  * Cons 
    * Newbler is tailored to (mostly) 454 data. Since Ion Torrent PGM data has a similar error profile (predominance of miscalled homopolymer repeats), it may be a good choice there also. Whilst it can accomodate some limited amount of Illumina data as has been described [here](http://contig.wordpress.com/2011/01/21/newbler-input-ii-sequencing-reads-from-other-platforms/), this is not possible for larger data sets. The [fire ant genome](http://www.pnas.org/content/early/2011/01/24/1009690108.abstract) added ~40x Illumina data to ~15x 454 coverage in the form of "fake" 454 reads: first assembling the Illumina data using SOAPdenovo and then chopping the obtained contigs into overlapping 300bp reads, and finally inputting these fake 454 reads to Newbler alongside real 454 data.
    * As Newbler at least partly uses the OLC approach large assemblies can take time

### Decision Helper

This is based both on personal experience as well as on published studies. Please note however that genomes are different and software packages are constantly evolving.

An Assemblathon challenge which uses a synthetic diploid genome assembly was reported on by [Nature](http://www.nature.com/news/2011/110323/full/471425a.html) to call **SOAP _de novo_, Abyss and ALLPATHS-LG the winners**.

However a talk on the result website <http://assemblathon.org/assemblathon-1-results> names **SOAP _de novo_, sanger-sga and ALLPATHS-LG** to be consistently amongst the **best performers** for this synthetic genome.

I want to assemble:

  * Mostly 454 or Ion Torrent data 
    * small Genome =>MIRA, Newbler
    * all others use Newbler
  * Mixed data (454 and Illumina) 
    * small genome => MIRA, but try other ones as well
    * medium genome => no clear recommendation
    * large genome, assemble Illumina data with ALLPATHS-LG and SOAP, add in other reads or use them for scaffolding
  * Mostly Illumina (or Colorspace) 
    * small genome => MIRA, velvet
    * medium genome => no clear recommendation
    * large genome, assemble Illumina data with ALLPATHS-LG and SOAP, add in other reads or use them for scaffolding

(For large genomes this is based on the fact that not many assemblers can deal with large genomes, and based on the assemblathon outcome. For 454 data this is based on Newbler's good general performance, and MIRA's different outputs, its versatility and the theoretical consideration that de Bruijn based approaches might fare worse)

Post assembly you might want to try the SEQuel software to improve the assembly quality.

I want to start a large genome project for the least cost

  * Use Illumina reads with ALLPATHS-LG specification (i.e. overlapping), the reads will work in e.g. SOAP de novo as well

(This recommendation is based on the assemblathon outcome, the original ALLPATHS publication ([Gnerre et al., 2011](http://www.ncbi.nlm.nih.gov/pubmed/21187386)) as well as a publication that used ALLPATHS for the assembly of Arabidopsis genomes ([Schneeberger et al., 2011](http://www.pnas.org/content/108/25/10249.long)).

Each software has its particular strength, if you have specific requirement, the result from [Assemblathon](http://assemblathon.org/) will guide you. Another comparison site [GAGE](http://gage.cbcb.umd.edu/) has also released its comparison ([Salzberg et al. 2011](http://genome.cshlp.org/content/early/2012/01/12/gr.131383.111)). Also there exists [QUAST](http://sourceforge.net/p/quast) tool for assessing genome assembly quality.

## Case study

# Further Reading Material and References

  * Background 
    * [Genome Sequence Assembly Primer](http://www.cbcb.umd.edu/research/assembly_primer.shtml)
    * [Paszkiewicz and Studholme, 2010](http://bib.oxfordjournals.org/content/11/5/457.long) Some general background
    * [Nagarajan and Pop, 2010](http://dx.doi.org/10.1007/978-1-60761-842-3_1)
    * [Imeldfort and Edwards, 2009](http://bib.oxfordjournals.org/content/10/6/609.long) Sequencing of plant genomes
    * [Pop 2009](http://www.ncbi.nlm.nih.gov/pmc/articles/PMC2691937/?tool=pubmed)
  * Original publications 
    * [Simpson et al., 2009](http://genome.cshlp.org/content/19/6/1117.full) ABySS
    * [Zerbino and Birney, 2008](http://genome.cshlp.org/content/18/5/821.long) Velvet
    * [Gnerre et al., 2011](http://www.pnas.org/content/108/4/1513.long) ALLPATHS-LG
    * [Li et al., 2010](http://genome.cshlp.org/content/20/2/265.long) SOAP denovo
    * [Chevreaux et al., 2004](http://genome.cshlp.org/content/14/6/1147.long) MIRAest
    * [Chaisson et al., 2009](http://genome.cshlp.org/content/19/2/336.long) EULER-USR
    * [The CLC Assembly Cell Whitepaper](http://www.clcbio.com/files/whitepapers/white_paper_on_de_novo_assembly_on_the_CLC_Assembly_Cell.pdf) includes a comparison with ABySS for a human genome and with velvet for a bacterial genome

  


  * Comparisons 
    * [Ye et al., 2011](http://genomebiology.com/2011/12/3/R31) Comparison of Sanger/PCAP; 454/Roche and Illumina/SOAP assemblies. **Illumina/SOAP** had **lower substitution, deletion and insertion rates** but **lower contig and scaffold N50 sizes than 454/Newbler**.
    * [Paszkiewicz et al., 2010](http://bib.oxfordjournals.org/content/11/5/457.abstract) General review about short read assemblers
    * [Zhang et al., 2011](http://www.plosone.org/article/info%3Adoi%2F10.1371%2Fjournal.pone.0017915) In depth comparison of different genome assemblers on simulated Illumina read dat. Unfortunately only up to medium genomes were tested. For **eukaryotic genomes** and **short reads Soap denovo** is suggested for **longer reads ALLPATHS-LG**.
    * [Chapman JA et al. 2011](http://www.plosone.org/article/info%3Adoi%2F10.1371%2Fjournal.pone.0023501) introduce the new assembler [Meraculous](http://seqanswers.com/wiki/Meraculous) gathered literature data on the assembly of E. coli K12 MG1655 for Allpaths 2, Soapdenovo, Velvet, Euler-SR, Euler, Edena, AbySS and SSAKE. **Allpaths2** had by far the **largest Contig and Scaffold N50** and was apart from Meraculous the only **misassembly free**. **Meraculous** was shown to even contain **no errors**.
    * [Liu et al., 2011](http://www.biomedcentral.com/1471-2105/12/354) benchmark their new assembler PASHA against SOAP de novo (v 1.04), velvet (1.0.17) and ABySS (1.2.1) using three bacterial data sets. Whilst PASHA usually the largest NG50 and NG80 (N50 and N80 calculated with the true genome sizes) **SOAP de novo produced the highest number of contigs** and soemtimes worse NG50 and NG80. However for one dataset **SOAP denovo showed the best genome coverage**.
    * The [Assemblathon](http://assemblathon.org) comparing _de novo_ genome assemblies of many different teams based on a synthetic genome. The Assemblathon 1 competition is now published in Genome Research by [Earl et al., 2011](http://genome.cshlp.org/content/early/2011/09/16/gr.126599.111.abstract).

### Reference datasets

#### ENA

See [here](http://en.wikipedia.org/wiki/European_Nucleotide_Archive) for more information.

The European Nucleotide Archive (ENA), has a three-tiered data architecture.It consolidates information from:

  * EMBL-Bank.
  * the European Trace Archive:containing raw data from electrophoresis-based sequencing machines.
  * the Sequence Read Archive: containing raw data from next-generation sequencing platforms.

#### SRA

See [SRA](http://en.wikipedia.org/wiki/Short_Read_Archive) for more information.

The Sequence Read Archive (SRA) is:

  * the Primary archival repository for next generation sequencing reads and alignments (BAM)
  * Expanding to manage other high-throughput data including sequence variations (VCF)
  * Will shorty also accept capillary sequencing reads
  * Globally comprehensive through INSDC data exchange with NCBI and DDBJ
  * Part of European Nucleotide Archive (ENA)
  * Data owned by submitter and complement to publication
  * Data expected to be made public and freely available; no access/use restrictions permitted
  * Pre-publication confidentiality supported
  * Controlled access data submitted to EGA
  * Active in the development of sequence data storage and compression algorithms/technologies

#### SRA Metadata Model

  * Study: sequencing study description
  * Sample: sequenced sample description
  * Experiment/Run: primary read and alignment data
  * Analysis: secondary alignment and variation data
  * Project: groups studies together
  * EGA DAC: Data Access Committee
  * EGA Policy: Data Access Policy
  * EGA Dataset: Dataset controlled by Policy and DAC

#### NCBI

### Viewing datasets

#### ENSEMBL

#### UCSC

#### Tablet

#### IGV

### Comparing datasets

#### Whole genome alignments

  


# Velvet

## Velvet practical: Part 1

This practical will cover the following items:

  * Compile Velvet
  * Single end
  * K-mer length
  * Coverage cut-offs
  * Whole genome sequence as input???

### Prepare the environment

First make sure that you are in your home directory by typing:

**cd**

and making absolutely sure you're there by typing:

**pwd**

Now create sub-directories for this and the two other velvet practicals. All these directories will be made as sub-directories of a directory for the whole course called NGS. For this you can use the following commands:

**mkdir -p NGS/velvet/{part1,part2,part3}**
    
    
    # The -p tells mkdir (make directory) not to worry if a parent directory is missing.
    # That is, if a sub-diectory cannot be made because its parent directory does not exist,
    # just make the parent directory  first rather than reporting an error.
    # The “one at a time” approach would be:
    mkdir NGS
    mkdir NGS/velvet
    mkdir NGS/velvet/part1
    mkdir NGS/velvet/part2
    mkdir NGS/velvet/part3
    

After creating the directories, examine the structure and move into the directory ready for the first velvet exercise by typing:

**ls -R NGS;**

**cd NGS/velvet/part1; pwd;**

### Downloading and Compile Velvet

You can find the latest version of velvet at:

<http://www.ebi.ac.uk/~zerbino/velvet/>

You could go to this URL and download the latest velvet version, or equivalently, you could type the following, which will download, unpack, inspect, compile and execute your locally compiled version of velvet:

`'cd ~/NGS/velvet/part1; pwd;`

`cp ~/NGS/Data/velvet_1.2.07.tgz . ;`

`tar xzf ~/NGS/Data/velvet_1.2.07.tgz;`

`ls -R; cd velvet_1.2.07;`

`make velveth velvetg;`

`./velveth `

Take a look at the executables you have created. They will be displayed as green by the command:

`ls --color=always;`
    
    
    The switch **--color**, instructs that files be coloured according to their type.
    This is often the default. Here we are just being cautious. 
    The **=always** is included as colouring is usually suppressed in scripts.
    If you run this exercise using the script provided, just **--color** would not be enough.
    **--color=always** insists on file colouring even from a script.
    

Have a look of the output the command produces and you will see the following parameters passed into the compiler:

**“MAXKMERLENGTH=31”** and **“CATEGORIES=2”**

This indicates that the default compilation was set for De Bruijn graph KMERs of maximum size 31 and to allow a maximum of just 2 read categories. You can override these, and other, default configuration choices using command line parameters. Assume, you want to run velvet with a KMER length of 41 using 3 categories, velvet needs to be recompiled to enable this functionality by typing:

`make clean; make velveth velvetg MAXKMERLENGTH=41 CATEGORIES=3; ./velveth`

velvet can also be used to process SOLID colour space data. To do this you need a further make parameter. With the following command clean away your last compilation and try the following parameters:

`make clean; make MAXKMERLENGTH=41 CATEGORIES=3 color ./velveth_de`

For a further description of velvet compile and runtime parameters please see the velvet Manual: <https://github.com/dzerbino/velvet/wiki/Manual>

## Single ended read assembly
    
    
    The data you will examine is from _**Staphylococcus aureus**_ USA300 which has a genome of around 3MB.
    The reads are  Illumina and are unpaired, also known as single-end library. 
    Even though you have carefully installed velvet in your own  workspace, we will use a pre-installed version. 
    The data needed for this section can be obtained from the Sequence Read Archive (SRA). 
    For the following example use the run data SRR022825 and SRR022823 from the SRA Sample SRS004748.
    The SRA experiment could be viewed by setting your browser to the URL:
            
    **<http://www.ebi.ac.uk/ena/data/view/SRS004748>**
    

The following exercise focuses on velvet using single-end reads, how the available parameters effect an assembly and how to measure and compare the changes. To begin with, first move back to the directory you prepared for this exercise, create a new folder with a suitable name for this part and move into it. The command to download the file from the internet would be:

`wget <ftp://ftp.sra.ebi.ac.uk/vol1/fastq/SRR022/SRR022825/SRR022825.fastq.gz>`

`wget <ftp://ftp.sra.ebi.ac.uk/vol1/fastq/SRR022/SRR022823/SRR022823.fastq.gz>`

or if you had the files installed locally, just create soft links to the files. Continue by copying (or typing):

`cd ~/NGS/velvet/part1`

`mkdir SRS004748`

`cd SRS004748`

`pwd`

`ln -s ~/NGS/Data/SRR022825.fastq.gz .`

`ln -s ~/NGS/Data/SRR022823.fastq.gz .`

`ls -l`
    
    
    You are ready to process your data with velvet, which is a compressed fastq file. Velvet has two main components:
    velveth -used to construct, from raw read data, a dataset organised in the fashion expected by the second component, velvetg.
    velvetg -the core of velvet where the de Bruijn graph assembly is built and manipulated.
    You can always get further information about the usage of both velvet programs by typing velvetg or velveth in your terminal.
    

Now run velveth for the reads in **SRR022825.fastq.gz** and **SRR022823.fastq.gz** using the following options:

\- A de Bruijn graph k-mer of 25

\- An output directory called run_25

`velveth run_25 25 -fastq.gz -short SRR022825.fastq.gz SRR022823.fastq.gz`

**velveth** talks to itself for a while and ends with some files in the output directory. Move into the output directory **run_25** and take a look around at what **velveth** had done so far. The UNIX command less allows you to look at output files (press q for quit). Just in case you still need a hint:

`cd run_25;`

`ls -l;`

`head Sequences;`

Now move one directory level up and run velvetg on your output directory, with the commands:

`cd ..`

`time velvetg run_25`

Move back into your results directory to examine the effects of velvetg:

`cd run_25; ls -l;`

FOR YOU: once you run the command above:

  * Q1: What extra files do you see in the folder run_25?
  * Q2:What do you suppose they might represent?
  * Q3: In the Log file in run_25, what is the N50?
    
    
    N50 statistic: Broadly, it is the median (not average) of a sorted data set using the length of a set of sequences.
    Usually it is the length of the contig whose length.
    When added to the length of all longer contigs, makes a total greater that half the sum of the lengths of all contigs. 
    Easy, but messy – a more formal definition can be found here:
            
    <http://www.broadinstitute.org/crd/wiki/index.php/N50>
    

Backup the contigs.fa file and calculate the N50 (and the N25,N75) value with the command:

<cpde cp contigs.fa contigs.fa.0

YOU now try:

<code gnx -min 100 -nx 25,50,75 contigs.fa

  * Q4. Does the value of N50 agree with the value stored in the Log file?
  * Q5. If not, why do you think this might be?
    
    
    In order to improve our results, take a closer look at the standard options of velvetg by typing 'velvetg' without parameters.
    For the moment focus on the two options -cov_cutoff and -exp_cov. 
    Clearly -cov_cutoff will allow you to exclude contigs for which the kmer coverage is low, implying unacceptably poor quality. 
    The -exp_cov switch is used to give velvetg an idea of the coverage to expect. 
    If the expected coverage of any contig is substantially in excess of the suggested expected value,
    maybe this would indicate a repeat. 
    For further details of how to choose the parameters, go to 'Choice of a coverage cutoff':       
      <http://wiki.github.com/dzerbino/velvet/>
    

Briefly, the **Kmer** coverage (and much more information) for each contig is stored in the file **stats.txt** and can be used with R to visualize the coverage distribution. Take a look at the **stats.txt** file, start R, load and visualize the data using the following commands:

`R`

`library(plotrix)`

`data <\- read.table("stats.txt", header=TRUE)`

`x11()`

`weighted.hist(data$short1_cov, data$lgth, breaks=0:50)`

A weighted histogram is a better way of visualizing the coverage information, because of noise (lot of very short contigs). You can see an example output below:

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/9c/DeNovoVelvet_Fig1.JPG/220px-DeNovoVelvet_Fig1.JPG)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Figure1: weight histogram showing the coverage information

After choosing the expected coverage and the coverage cut-off, you can exit R by typing:

`q()`

`n`
    
    
    The weighted histogram suggests to me that the expected coverage is around 14 and that everything below 6 is likely to be noise. 
    Some coverage is also represented at around 20, 30 and greater 50, which might be contamination or repeats (depending on the dataset), but at the moment this should not worry you. 
    To see the improvements, rerun velvetg first with -cov_cutoff 6 and after checking the N50 use only / add -exp_cov 14 to the command line option. 
    Also keep a copy of the contigs file for comparison:
    

`cd ~/NGS/velvet/part1/SRS004748 time velvetg run_25 -cov_cutoff 6`

  1. `Make a copy of the run`

`cp run_25/contigs.fa run_25/contigs.fa.1`

`time velvetg run_25 -exp_cov 14 cp run_25/contigs.fa run_25/contigs.fa.2`

`time velvetg run_25 -cov_cutoff 6 -exp_cov 14 cp run_25/contigs.fa run_25/contigs.fa.3`

  * Q6.What is the N50 with no parameter:
  * Q7.What is the N50 with -cov_cutoff 6:
  * Q8.What is the N50 with -exp_cov 14:
  * Q9.What is the N50 with -cov_cutoff 6 -exp_cov 14:
  * Q10Did you notice a variation in the time velvetg took to run? If so, can you explain why that might be?

You were running velvetg with the given **-exp_cov** and **-cov_cutoff** parameters. Now try to experiment using different cut-offs, expected parameters and also explore other settings (e.g. -max_coverage, -max_branch_length, -unused_reads, -amos_file, -read_trkg or see velvetg help menu).
    
    
    In particular, look at the -amos_file parameter which instructs velvetg to create a version of the assembly that can be
    processed and viewed with a program called AMOS Hawkeye. 
    Another  program, called tablet, can also understand and display the AMOS file. 
    For now, we will take a look at tablet.
    

Run velvetg with just -cov_cutoff 6 but requesting an amos file:

`velvetg run_25 -cov_cutoff 6 -amos_file yes`

Now take a swift look at the assembly with tablet:

`tablet run_25/velvet_asm.afg &`

velvet_asm.afg being the file velvetg made is response to the inclusion of the -amos_file yes switch. tablet will take quite a bit of memory and you can safely ignore the complaints from tablet. Once the file has loaded, select one of the longer contigs. Note the lack of Read information and the one dimensional nature of the contig display. Close down tablet when you have seen enough. Now rerun velvetg adding the additional parameter -exp_cov 7 with no need to save any files as the amos file needs to be changed. Now rerun velvetg adding the additional parameter -exp_cov 14 with no need to save any files as the AMOS file needs to be changed.

`velvetg run_25 -cov_cutoff 6 -exp_cov 14 -amos_file yes`

Again, view the amos file with tablet:

`tablet run_25/velvet_asm.afg &`

Select a longish contig as before and explore the display options before close down table. FOR YOU:

  * Q11. Why do you think there was read information only for the second use of tablet?
  * Q12. You may have noticed velvetg took a little longer with -exp_cov 14 on. Does this make sense ?

If you want to explore the behaviour of velvet even further, you could experiment with the following.

Reduce the sequence coverage by only choosing one input file for the assembly e.g. SRR022825.fastq.gz

Increase the sequence coverage by downloading further files from the same ENA sample SRS004748 (<http://www.ebi.ac.uk/ena/data/view/SRS004748>).

FOR YOU: How did the N50 change by

  * Q13. reducing the coverage?
  * Q14. increasing the coverage?

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Next_Generation_Sequencing_(NGS)/Print_version&oldid=2551296](http://en.wikibooks.org/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&oldid=2551296)" 

[Category](/wiki/Special:Categories): 

  * [Next Generation Sequencing (NGS)](/wiki/Category:Next_Generation_Sequencing_\(NGS\))

Hidden categories: 

  * [Pages with broken file links](/wiki/Category:Pages_with_broken_file_links)
  * [No references for citations](/wiki/Category:No_references_for_citations)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Next+Generation+Sequencing+%28NGS%29%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Next+Generation+Sequencing+%28NGS%29%2FPrint+version)

### Namespaces

  * [Book](/wiki/Next_Generation_Sequencing_\(NGS\)/Print_version)
  * [Discussion](/w/index.php?title=Talk:Next_Generation_Sequencing_\(NGS\)/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&action=edit)
  * [View history](/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Next_Generation_Sequencing_\(NGS\)/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Next_Generation_Sequencing_\(NGS\)/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&oldid=2551296)
  * [Page information](/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Next_Generation_Sequencing_%28NGS%29%2FPrint_version&id=2551296)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Next+Generation+Sequencing+%28NGS%29%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Next+Generation+Sequencing+%28NGS%29%2FPrint+version&oldid=2551296&writer=rl)
  * [Printable version](/w/index.php?title=Next_Generation_Sequencing_\(NGS\)/Print_version&printable=yes)

  * This page was last modified on 23 August 2013, at 02:03.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Next_Generation_Sequencing_\(NGS\)/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
