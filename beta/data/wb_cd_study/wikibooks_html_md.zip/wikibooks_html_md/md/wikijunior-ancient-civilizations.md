# Wikijunior:Ancient Civilizations/Print version

From Wikibooks, open books for an open world

< [Wikijunior:Ancient Civilizations](/wiki/Wikijunior:Ancient_Civilizations)

![Edits to this page require review.](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/doc-magnify.png)![This is a reviewed version of this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/2.png)This is the [latest reviewed version](/wiki/Wikibooks:REVIEW), [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Wikijunior:Ancient_Civilizations/Print_version) on _3 May 2012_.(+)

 **Quality**: poor/unrated  

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Wikijunior:Ancient Civilizations](/wiki/Wikijunior:Ancient_Civilizations)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=purge&printable=yes) this page.

  


# Table of Contents[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=1)]

## Ancient Civilizations[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=2)]

    [Ancient Pueblo Peoples](/wiki/Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples)
    [Assyrians](/wiki/Wikijunior:Ancient_Civilizations/Assyrians)
    [Aztecs](/wiki/Wikijunior:Ancient_Civilizations/Aztecs)
    [Celts](/wiki/Wikijunior:Ancient_Civilizations/Celts)
    [Chinese](/wiki/Wikijunior:Ancient_Civilizations/Chinese)
    [Egyptians](/wiki/Wikijunior:Ancient_Civilizations/Egyptians)
    [Greeks](/wiki/Wikijunior:Ancient_Civilizations/Greeks)
    [Hebrews](/wiki/Wikijunior:Ancient_Civilizations/Hebrews)
    [Incas](/wiki/Wikijunior:Ancient_Civilizations/Incas)
    [Mound Builders (North America)](/wiki/Wikijunior:Ancient_Civilizations/Mound_Builders)
    [Mayans](/wiki/Wikijunior:Ancient_Civilizations/Mayans)
    [Vikings/Norse (Scandinavians)](/wiki/Wikijunior:Ancient_Civilizations/Norse)
    [Persians](/wiki/Wikijunior:Ancient_Civilizations/Persians)
    [Romans](/wiki/Wikijunior:Ancient_Civilizations/Romans)
    [Scythians](/wiki/Wikijunior:Ancient_Civilizations/Scythians)

## References[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=3)]

## Authors[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=4)]

    [Authors](/wiki/Wikijunior:Ancient_Civilizations/Authors)

  


* * *

# Ancient Pueblo Peoples[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=5)]

![](//upload.wikimedia.org/wikipedia/commons/1/1c/Square_Tower.jpeg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Square Tower House at Mesa Verde

The Ancient Pueblo people were a Native American culture also known as Anasazi, but descendents of the people prefer not to be called that. They are the ancestors of modern Pueblos. Their culture dates back to 1200 B.C.

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-1)]

The Ancient Pueblo people lived in what is now the southwestern United States of America. They lived in a high desert area filled with flat-topped hills called mesas. Utah, Colorado, New Mexico and Arizona meet at a point called “Four Corners”. The area surrounding Four Corners was the home of the Ancient Pueblos, which is probably why the "Four corners." nickname is "the pueblo corners".

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ed/Mesa_verde_cliff_palace_close.jpg/300px-Mesa_verde_cliff_palace_close.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Cliff Palace at Mesa Verde

The Ancient Pueblo people built large buildings made up of many individual rooms. Families built the buildings over generations. Different families lived together in a single building, like an apartment complex today. The Spanish called the buildings pueblos. Pueblo is a Spanish word that means "village". It is from these pueblos that the Ancient Pueblo people get their name.

These buildings were made of wood logs, adobe and stone. Adobe is a natural building material made from water, dirt and straw. The Ancient Pueblo builders used stones to make the walls of each room. Then they covered them with a layer of smooth adobe. The color of the walls is often the same as the color of the ground nearby.

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/85/Taos_Pueblo1.jpg/200px-Taos_Pueblo1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Rooms at Taos Pueblo

One very famous pueblo is Taos Pueblo. It has a multi-storied residential complex of reddish-brown adobe. The Rio Pueblo River runs through the middle of the pueblo. Pueblo people built this pueblo between 1000 and 1450 A.D. About one hundred and fifty people still live there today.

They also built enclosed pits called kivas. Religious rituals and ceremonies were held inside the kivas. Most kivas built by the Ancient Pueblo people were round underground rooms. A hole in the roof was both a door and chimney. There were benches and alcoves in the walls. A fire pit was in the center.

The Ancient Pueblo people are famous for their cliff dwellings. Mesa Verde in south western Colorado has several built into its sides. Cliff Palace is a particularly well known dwelling there. It has 220 rooms, in several stories and 23 kivas. The design of Cliff Palace seems random. Different people added new rooms slowly. Over many years, it took shape. People who lived there grew their food on the top of the mesa above them. They had to climb the face of a steep cliff to get home. They used small hand and foot holds carved in the rock.

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/08/Pueblo_corn.jpg/200px-Pueblo_corn.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Pueblo Corn

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-3)]

The Ancient Pueblo people were superb farmers despite the harsh and arid climate. They ate mainly corn, beans, and squash. They knew how to dry their food and could store it for years. Women ground the dried corn into flour, which they made into paper-thin cakes. They cooked these on a hot rock. Today their ancestors call these cakes "piki." They also cooked stews in clay pots over a fire.

Since they lived in the high desert, food was hard to come by. They had bows and stone-tipped arrows. They hunted and ate animals like mice and rabbits. They also gathered wild foods like piñon nuts, yucca bulbs and sunflower seeds. They kept turkeys and ate their eggs, but they may not have eaten the birds themselves. Instead, they used these birds to control insects. The birds would eat the bugs before the bugs ate the plants.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-4)]

\--[99.1.241.17](/wiki/Special:Contributions/99.1.241.17) ([discuss](/w/index.php?title=User_talk:99.1.241.17&action=edit&redlink=1)) 05:00, 17 December 2011 (UTC) Ancient Pueblo people wore many different types of clothing. They wore shirts and loincloths made of animal hides and furs. As animals were scarce, so was leather. They made sandals with thick soles from the matted fibers of the yucca plant. Yucca fibers were also used as thread.

About 1,000 years ago, they began trading and growing cotton. They used cotton to weave shirts, dresses, loincloths and blankets. They decorated their clothing using natural dyes made from plants and minerals. Some common colors were ochre yellow, rust red, and pale blue-gray. The Ancient Pueblo people were expert weavers and they would decorate the fabric they wove. They painted or embroidered abstract geometric designs on the fabric.

The weather was hot during the summer, so they wore little clothing then; however, they experienced cold winters. To make robes and coats, they wrapped feathers around Yucca fibers which they then sewed together.

They also wore jewelry. They crafted pendants, earrings and necklaces from turquoise. They traded for shells and beads and wore these as well.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/6/64/Image-Kachina_small_01.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Katchina Doll

No one knows for sure what the Ancient Pueblo people believed. We can make some good guesses, though. This is because we know what modern Pueblos believe.

They did not believe in a single god. They believed in many mystic beings and gods. Today their ancestors call some of these kachinas. The kachinas could speak directly with gods. People would ask the kachinas to help them. Dancing was a main way that people connected with kachinas.

According to Pueblo history, their ancestors entered this world from another world. The people who entered this world are the First People. A flute-playing locust led them on the journey.

An important concept in Pueblo history and religion is the sipapu. A sipapu was a place where people could communicate with spirits. It could be an alcove in a kiva, a mountain, a body of water, or some other place. Ancient Pueblo Peoples believed that the dead pass into the spirit world through the sipapu. When someone died, their spirit went to a different world for a time. Then they were reborn in this world as a new baby.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Martinez_Pot.jpg/300px-Martinez_Pot.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Pot Made by Maria Martinez

Ancient Puebloans did not have a written language. They did create pottery, cloth, and rock carvings with abstract designs, though. These designs identified groups or spirits. They also made rock carvings that had pictures of people and animals.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-7)]

A Pueblo medicine man named Popé led a revolt against the Spanish in 1680. The revolt was in response to the cruel treatment the native Americans received from the conquering Spanish. The Pueblos managed to force the Spanish out of New Mexico but two years after Popé's death, the Spanish regained control.

Maria Martinez is a famous pottery maker known for her recreation of traditional Puebloan designs. Her most famous pots have matte black designs on a shiny black surface.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Ancient_Pueblo_Peoples&action=edit&section=T-8)]

There are still Pueblo people living in New Mexico and Arizona. Some live other places in the American south west. There are around 25 pueblos today. Taos, Acoma, Zuni, and Hopi are the most well known pueblos. Modern Pueblo people are descended from the Mogollon and Hohokam people as well as the Ancient Pueblo people.

# Aztecs[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=6)]

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/18/Mx-map.png/220px-Mx-map.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Map of [Mexico](//en.wikipedia.org/wiki/Mexico)

The Aztecs lived in what is now Mexico. The name Mexico comes from the Aztec word _Mexica_, a name they used to describe themselves. Their capital city, Tenochtitlan, was located where Mexico City is today.

  


## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-2)]

The Aztec's city, Tenochtitlan, was built on a self-made island. When they first arrived in the area, there was nothing but a swampy island in the middle of Lake Texcoco. They developed a system, called the _chinampa_ system to dry the land by setting up small plots in which they produced all the food they needed. When enough land was dry they would begin to build there. Over time, they added to the size of the island using this system.

### Tenochtitlan[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-3)]

Tenochtitlan was divided into four zones or _campan_. Each _campan_ was divided into 20 districts (_calpullis_), and each _calpulli_ was crossed by streets, or _tlaxilcalli_. There were three main streets that crossed the city and extended to firm land; the _calpullis_ were divided by channels used for transportation, with wood bridges that were removed at night. Each _calpulli_ had its own _tianquiztli_ (marketplace), but there was also a main marketplace in Tlatelolco.

Tenochtitlan was created symmetrical, that is, a mirror image on both sides. At the heart of the city lay public buildings, temples and schools. Inside a walled square, 300 meters to the side, was the ceremonial center. There were public buildings, the main temple, the temple of Quetzalcoatl, the ball game, the _tzompantli_, or rack of skulls, the temple of the sun, the platforms for the sacrifice of gladiators, and some minor temples. Outside was the palace of Moctezuma. Nearby was the _cuicalli_ or house of the songs, and the _calmecac_, or school. All construction had to be approved by the _calmimilocatl_, a person in charge of city planning.

Moctezuma's palace had 100 rooms and bathrooms for the lords and ambassadors of allies and conquered people. It also had two zoos, one for birds of prey and another for other birds, reptiles, and mammals. There was also a botanical garden and an aquarium. The aquarium had ten salt water ponds and ten fresh water ponds, containing fish and aquatic birds.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-4)]

Aztec men wore cloth around their waists and cloaks around their shoulders. Aztec women wore sleeveless blouses and wraparound skirts. Nobles dressed in brightly coloured cotton clothes decorated in gold and feathers. This was done to attract attention to themselves. The poor wore clothes made of maguey fibres, and slaves did not wear much at all!

The Aztec army dressed differently from everyday people. Warriors wore vests made of quilted cotton, feathered plumes dusted with stones and precious metals. They also wore collars, bracelets and earrings made of the same materials. Depending on how many enemies they captured, warriors could earn the right to wear animal costumes. Chiefs wore layers of gold or silver with feathers underneath. Both chiefs and warriors wore wooden helmets shaped like animals, and carried shields made of woven reeds and feathers. Common soldiers did not have these items. They painted themselves in the colours of their chief's banner, and wore a simple girdle.

When sacrificing humans to the gods, priests wore black blood-stained robes, while the victim was painted with chalk. Often, masks were worn during the ceremony.

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f0/AhuitzotlGlyphHarvard.jpg/200px-AhuitzotlGlyphHarvard.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The name glyph for Ahuitzotl, an Aztec emperor.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-5)]

Like the Mayans, the Aztecs wrote using a series of glyphs, or pictures. For example, a snake (coatl) was represented by a drawing of a snake's head. Numbers below 20 were represented by a series of dots. Numbers larger than 20 were represented by glyphs. For example, the number 500 would be represented by a feather and four flags (400 + 5*20 = 500). To show that glyphs belonged to a single group, a line was drawn to connect them. Next, a line was drawn to the object being counted.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/d/d9/YaxchilanDivineSerpent.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

[Quetzalcoatl](//en.wikipedia.org/wiki/Quetzalcoatl)

According to Aztec legend, the ancestors of the Aztecs came from a place in the north called Aztlán. They were guided by a god named Huitzilopochtli, meaning "Left-handed Hummingbird." There was a prophecy that said that they should build their home where they saw an eagle eating a snake while perched on a nopal cactus. When they arrived on the island in Lake Texcoco, they saw this, and settled there.

The Aztecs also believed that their ancestors were considered by other groups to be uncivilized. However, they decided to learn, and took knowledge from other peoples, especially the Toltec. They believed all culture came from them.

The Aztecs had several creation myths. One said that there were four ages before our time, each of which ended in a catastrophe. Our age – _Nahui-Ollin_, the fifth age, or fifth creation – escaped destruction because of the sacrifice of Nanahuatl ("full of sores", the smallest and humblest of the gods), who was transformed into the Sun. Another says that Earth was created by the twin gods Tezcatlipoca and Quetzalcoatl. Tezcatlipoca lost his foot in the process of creating the world and all representations of these gods show him without a foot and with a bone exposed.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-7)]

At the time of the arrival of the Spanish, Emperor Moctezuma ruled over Tenochtitlan. His name in Nahuatl, pronounced Mo–tekw–so–ma, meant "he who makes himself ruler by his rage."

Legend has it that ten years before the Spanish arrived, eight things happened that signaled the fall of the Aztec empire. They were:

  1. A comet appeared in the sky during the day.
  2. A pillar of fire (possibly the comet) appeared in the night sky.
  3. The temple of Huitzilopochtli was destroyed by fire.
  4. A bolt of lightning struck the Tzonmolco temple.
  5. Tenochtitlan was flooded.
  6. Strange people with many heads but one body were seen walking through that city.
  7. A woman was heard weeping a dirge for the Aztecs.
  8. A strange bird (quetzal) was caught. When Moctezuma looked into its mirror-like eyes, he saw unfamiliar men landing on the coast.

In the spring of 1519, Moctezuma received reports of strange men off the coast of his empire. At first, the emperor sent an ambassador with a costume of Tlaloc, and another of Quetzalcoatl. When the ambassador met conquistador Hernán Cortés, he thought he looked like Quetzalcoatl. He told Moctezuma, who tried to stop him from coming to Tenochtitlan. He sent gold, wizards, priests, and even one of his ambassadors, Tzihuacpopoca, who pretended to be the emperor.

Eventually, Moctezuma met Hernán Cortés. He believed he was the god Quetzalcoatl. He took him to his garden and gave him flowers, the greatest honour he could give. When Cortés ordered a halt to the human sacrifices, he agreed. He even offered to be baptized a Christian and become a subject of King Charles I of Spain.

When Cortés went to meet other Spaniards on the coast, deputy governor Pedro de Alvarado took over. He stopped the Aztecs from celebrating Toxcatl, and killed most of the important upper class Aztecs in what is known as "The Massacre in the Main Temple." Between 350 to 1000 people died. This enraged the Aztecs, who revolted. Moctezuma was then taken by the Spanish. On July 1, 1520, Moctezuma appeared on the balcony of his palace, pleading with his people to retreat. Instead, they threw rocks at him, and he died shortly after the attack.

After the death of Moctezuma, there were only two other emperors. One died of smallpox, the last Aztec emperor was named Cuahutemoc, and to make him confess where the Aztec wealth was kept, they burned his feet until finally his death came very possibly from shock, or so Mexican scholars say. One year later, the Aztec empire had crumbled. Techichpotzin, Moctezuma's daughter, inherited his wealth. She was baptized a Christian and given the name Isabel Moctezuma. She married a total of five times before she died.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Aztecs&action=edit&section=T-8)]

Although the Aztecs no longer exist, their influence is still felt in Mexico. More than 60% of the population are _mestizo_ or mixed. This means that some of their ancestors were Aztec. There are also over 1.5 million people in Mexico who speak Nahuatl, which comes from the Classical Nahuatl spoken by the Aztecs.

The Nahuatl language has given many words to English, usually through Spanish. Here is a list of some English words of Nahuatl origin:

  * avocado: from ahuacatl (fruit)
  * chilli: from chilli (vegetable)
  * chocolate: from xocolatl (drink)
  * cocoa: from cacahuatl (fruit/nut)
  * coyote: from coyotl (mammal)
  * ocelot: from ocelotl (mammal)
  * shack: from xacalli (structure)
  * tomato: from (xi)tomatl (fruit/berry)

# Assyrians[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=7)]

{{:[Assyrians](/wiki/Wikijunior:Ancient_Civilizations/Assyrians)}}

# Celts[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=8)]

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Celts_in_Europe.png/200px-Celts_in_Europe.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

This map shows areas once inhabited by ancient Celts (light green), the areas that remain Celtic-speaking today (dark green), and the boundaries of the six commonly-recognized 'Celtic nations' (intermediate green).

In around 400 BC, the Celts ranged from [Britain](/wiki/Wikijunior:Europe/United_Kingdom) and [Ireland](/wiki/Wikijunior:Europe/Ireland) all the way across Europe to northern Turkey. Today, Celtic people live in Scotland, Wales, Cornwall and Northern Ireland in the [United Kingdom](/wiki/Wikijunior:Europe/United_Kingdom), Brittany in [France](/wiki/Wikijunior:Europe/France), the Isle of Man and the [Republic of Ireland](/wiki/Wikijunior:Europe/Ireland). Other Celtic people live in countries where their ancestors moved to.

## What did they look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-2)]

Men wore a loose fitting tunic down to the knees and trousers called Bracae. Women wore long, loose fitting dresses. They made their clothes from linen woven from the flax that Celtic farmers grew. They were very concerned about their appearance and used dye from berries to colour their clothes. Both men and women also wore great cloaks when travelling, women used a decorative brooch to fasten their cloak at the neck. These cloaks were very heavy and often used as sleeping bags for the men when they were away hunting. The Celts used lime to bleach their hair, preferring light hair and both men and women wore their hair long.

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-3)]

Most Iron Age Celts in Britain lived in **roundhouses**; circular houses of wood or stone with thatched straw roofs shaped like a cone. Most roundhouses were made up of wooden posts, with the walls made out of "_**wattle and daub.**_" Wattle and daub consists of wooden sticks (wattles), covered with a mixed mud and clay plaster (daub).

In Scotland most roundhouses were built of stone rather than wood, yet retained the cone-shaped thatched roof. This type of roundhouse is called the **Atlantic roundhouse.**

Celtic houses in mainland Europe were rectangular.

The Celts in Ireland built many forts and settlements, the most popular design was the ringfort. Inside a ringfort wooden, circular houses were built using wattle and daub.

Celts also built fortified defensive structures, which can still be seen today, especially in the highlands and isles of Scotland, as well as Ireland.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-4)]

Celts ate like most other Europeans, subsisting mostly on grains supplemented by meats, fruits, and vegetables. Exactly what they ate varied by area, and Celts grew local crops. Scottish highlanders were famous for supposedly subsisting almost entirely on **oats**, though this was not entirely true. However, oats remain the favorite grain of Scotland, and Scottish cuisine is full of them. **Potatoes** serve this role in Ireland, although they were not introduced until after Columbus reached the New World.

The Celts in Ireland farmed the land and reared cattle and sheep. In the spring, they would get milk, butter and cheese from the cattle, killing them later in the year for meat. Cattle were not only a means of food for Celts, the Celts wealth was measured in the amount of cattle they owned. One ancient Irish tale tells of Queen Maedhb (May-ev) and another rival king, and their battle over the Táin Bó Chuaille (a bull). This doesn't just show the importance of cattle in Celtic society, but also the fact that they thoroughly accepted the idea of women as leaders, unlike other societies of that time.

The most famous example of food of any Celtic people is probably the Scottish **haggis**. Many people aren't quite clear on what a haggis is, and one survey conducted in the United States found that over half of the people they surveyed thought that the haggis was a small rodent native to Scotland. In reality, a haggis usually consists of a sheep's 'pluck' (heart, liver, windpipe and lungs), minced with onion, oatmeal, suet, spices, and salt, mixed with stock, which is traditionally boiled in the animal's stomach for about an hour.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Torque_gaulois_en_bronze.jpg/200px-Torque_gaulois_en_bronze.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A bronze torque, a neckband worn by Gauls.

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Gaul_warrior_Mondragon_2.jpg/200px-Gaul_warrior_Mondragon_2.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Relief statue of a Gaulish woman. She wears loose robes, an armband (probably bronze), and carries a sword.

Celts took a great interest in their clothes when they could afford to do so. Many more modern Celts had colourful designs woven into their clothes called **tartan**, still shown in Scottish Kilts and Trews today.

Celts also had a great fondness for jewellery, and both men and women wore quite a bit, when they could afford it.

Finally, many warrior Celts wore their weapons (swords, more often than not) as normal attire. This became very complex during the late Middle Ages with Scottish highlanders, who were sometimes seen with a broadsword at their waist, dirk (long knife) on their belt, one or more pistols also attached to their belt, a long hunting rifle, and a small dagger in their sock, called a Sgian Dubh (Gaelic for _"Black Dagger"_).

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-6)]

Celts didn't have a very high opinion of the written word. Instead, they recorded their history and culture in an **oral tradition;** that is, they recorded their past by telling stories. Early examples of Gaelic Celtic writing have been recovered in Europe, based on the Phoenician alphabet.

In Ireland, a different alphabet was used, primarily in Gaelic Celtic languages like [Irish](/wiki/Wikijunior:Languages/Irish), [Manx](/wiki/Wikijunior:Languages/Manx_Gaelic), and Scottish Gaelic. This alphabet was called **Ogham**, sometimes referred to as the _"Celtic Tree Alphabet."_ It developed as a way for Irish monks to write in stone.

![](//upload.wikimedia.org/wikipedia/commons/4/46/Ogham_airenach.png)

An example of Ogham from the Book of Ballymote.

After Christianity was spread throughout the Gaelic world, Ogham fell into disuse, in favor of the Latin alphabet (largely because Christian writings were all in the Latin alphabet).

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-7)]

Celts were **polytheists;** they believed in many gods and goddesses (deities). Unlike many other civilisations, different groups of Celts worshipped various deities, although there were some patterns. **Beira** was the name that Celts gave to Mother Earth, and some of them believed her to be the mother of all their deities.

Most Celts believed in an afterlife, we know this because archaeologists have found many grave goods within their burial tombs (Dolmens, Cairns). Many, though not all, Celts worshipped in sacred groves.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-8)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Boudiccastatue.jpg/200px-Boudiccastatue.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A statue of Boudicca near Westminster Pier, London

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/46/Robert_Burns.jpg/150px-Robert_Burns.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Robert Burns

Yes! Today, the British Isles (along with Ireland) are probably regarded to be Celtic more than any other area in the world. No one is quite sure who lived there before them, and they were certainly well-established by the time the Romans came there in AD 43. After 20 years of Roman rule, the chieftain of the Icenii tribe, Prasutagus, died. Though by tradition, his wife **Boudicca** would have assumed leadership of the tribe, the Romans took Icenii land, brutally humiliating Boudicca and her two daughters. This enraged the Icenii people, and Boudicca raised an army to fight the Romans and liberate Britain. She gained support of many other Celtic tribes, and almost succeeded in toppling the Roman Empire in Britain. She is revered as a national hero in Britain.

The world-renowned Scottish poet, Robert Burns, was a Celt.

Many famous Celts are alive today. The famous Scottish actor, Sean Connery, is proud of his Celtic heritage.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Celts&action=edit&section=T-9)]

Celts are alive and thriving today! Much of the population of Europe are seen as descendants of the Celts, and the nations of Scotland, Ireland, Wales, Cornwall, Brittany and Isle of Man are considered to be made up of primarily Celtic peoples. As well, the Celtic **diaspora**, the descendants of Celts around the world, is vast, being spread greatly through the British Empire. In particular, Novia Scotia, Canada, is a hotbed of modern Gaelic Celtic culture.

# Chinese[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=9)]

Despite its being one of the four greatest ancient civilizations, the Chinese civilization had a slower progress than any other. The Chinese civilization has made countless contributions to the world, including the invention of compass, paper, gunpowder, silk, noodle, porcelain, and paper money and other things that are a part of our lives today. There were also many great works of architecture, such as, the Great Wall.

The Chinese is the only of the four greatest ancient civilizations that managed to survive throughout the five thousand years of its history and one of a few ancient civilizations that have lasted into modern times. The Chinese civilizations is normally divided in four characteristic periods (Pre-history and Shang, Han Empire, Qing [Manchu] Empire 1644- 1912 and Modern age). Due to their extensive record keeping little mystery is left to us, much unlike the Egyptians and Babylonians. The present-day China is the continuation of that evolution. The influence of Chinese civilization also spread to Japan, Korea, and Vietnam.

## Where do they live?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-1)]

![ChinaGeography.png](//upload.wikimedia.org/wikipedia/commons/thumb/2/2c/ChinaGeography.png/300px-ChinaGeography.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The geography of ancient China is often described by geologists in a system of three steps: The first step is to the far west near present day [Tibet Autonomous Region (TAR)](//en.wikipedia.org/wiki/Tibet_Autonomous_Region) (Tibet or Xizang for short). With the highest mountains on earth the climate is quite cold and in the summer quite warm. This area is widely considered inhospitable, from -40℃ (-40°F) in the winter to 37℃ (100°F) in the summer. Because of these extremes, there aren’t many villages and the villages that are there are quite small.

The next step is the middle of China. It’s covered with desert and a small amount of grassland. People there raise yaks, a type of grazing cattle. There are some low hills but no snow. With cold winters and hot summers this area was never densely populated.

Eastern China supported most of China's ancient population. Three rivers flow through this area: the Huang He in the north, the Chang Jiang (Yangzi Jiang) in the center, and the Sikiang in the south. The Huang He is the main river and is more commonly known in the Western World as the Yellow River. This is because the water and the soil around this river is yellow. There was plenty of water for crops and agriculture flourished. Wheat was the main crop in the north, and rice was more common in the southwest.

## What do their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/49/XiAn_CityWall_DiLou.jpg/300px-XiAn_CityWall_DiLou.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

City wall of Xi'an is the best preserved city wall in China.

Most ancient Chinese buildings have not survived because they were made of wood. A small number of buildings were made of stone. However, the forbidden palace, which is still located in China, Beijing, has survived, and many tourists visit it every day. The Temple of Heavens, or Tian Tan, is also a famous tourist attraction. Chinese architecture has curved roofs to resemble the wings of a bird. Roof colors also hold significance; blue was usually reserved for religious buildings, orange/yellow was reserved for imperial buildings, etc.

## What do they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-3)]

Northern Chinese people eat wheat; southern Chinese people eat rice; and they both eat with chopsticks. Many of them eat noodles, which are long, thin pieces of dough that they boil in hot water. A main meat was pork, each family would keep a live pig if they could afford it. They would feed it table scraps, and pigs were also popular as a pet as well as dogs. They also grew fruits like lemons, oranges, peaches, apricots and ginger

## What do they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-4)]

In ancient China, the wealthy wore silk, while commoners wore cotton. The color yellow/gold could only be worn by the emperor and other royalty. A dragon was sometimes sewn on the Emperor's clothes, and gold was often woven into clothing. The color red indicates celebrity or happiness and is usually worn on holidays. They also sometimes wore jade depending on what they were doing, since jade was highly valued

They wore a style of clothing known as the Hanfu, which was robes tied together with a sash or belt. Hanfus vary from simple versions worn by commoners to scholarly versions worn by court officials to elaborate versions worn by the rich.

The Hanfu very much resembles and is the predecessor of the Japanese yukata/kimono, the Korean hanbok, and the Vietnamese Áo tứ thân.

In the 17th century, Manchurian nomads invaded the Ming Dynasty, and created the Qing Dynasty. They ordered everyone to wear Manchurian clothing, which is now known as the Cheongsam; Changshan (male) and the Qipao (female). This type of clothing is what most westerners picture when they think of Chinese clothing.

## What does their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Replica_of_oracle_turtle_shell_with_ancient_Chinese_oracle_scripts.jpg/220px-Replica_of_oracle_turtle_shell_with_ancient_Chinese_oracle_scripts.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Replica of ancient Chinese script on an oracle turtle shell

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Hanzi.png/220px-Hanzi.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Simplified Chinese (left) alongside traditional Chinese (right)

The ancient form of writing evolved into the character system that is still in use today. Traditional Chinese script includes cursive, semi-cursive, wild cursive, clerical, seal, etc. Today, mainland PR-China uses simplified Chinese script, introduced to improve literacy rate, but criticized by historians.

[Taiwan](//en.wikipedia.org/wiki/Taiwan), [Hong Kong](//en.wikipedia.org/wiki/Hong_Kong), and [Macao](//en.wikipedia.org/wiki/Macao) continue to use traditional script.

## What do they believe in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-6)]

During the Bronze Age most of China worshiped many gods and spirits. The most important of these being Ti or “Deity Above". He was believed to help those that pleased him and punish those that didn’t. Ti was in charge of all the gods and goddesses in the pantheon. The gods and goddesses all represented something in nature, e.g. the “God of Soil". Some of the emperors brought their servants with them to the after life. Priests and Priestess’s main job was to act as mediums between the gods and goddesses and the worshipers they specialized in sacrificing and ceremonies of specific gods and goddesses. A special type of medium was an Augur. An Augur asked questions of the gods and goddesses or read oracle bones.

After the Bronze Age, Three Doctrines or Ideologies became important Chinese Religions. The Three ideologies can also be viewed as philosophies but they also have a spiritual element, which is why they are classified as religions. Daoism and Confucianism were native to China and developed in isolation. The Third Doctrine, Buddhism was brought from China by traveling monks from India.

Confucius was alive during when the Chou dynasty (a part of the Zhou Dynasty) was decaying it was riddled with corruption. Confucius experienced the corruption firsthand as he held a position in government. He believed that decline was because the Chinese had abandoned old traditions and old concepts of honor, politeness morality and social roles had been forgotten; this is the base of Confucianism.

Confucianism filtered into different aspect of Chinese culture. Confucius’ teachings became the basis for education in China and his writings became the classics that every child in China reads.

The basis of Daoism is the concept of Dao. Dao is translated as “the path” or “the way.” The term has no conclusive definition it refers to a wide force in nature and is the source of all things.

Daoism in its purest form calls followers to pursue Dao. This means he or she should not try to alter nature or force it to do what it was not meant to do. A follower must remain inactive and not make plans. A follower must not do anything contrary to Dao for example building a house or damming a river. Daoists were members of the educated wealthy elite. Some of the less privileged did learn about it but altered it to be more about magic and alchemy than the purest form of Daoism.

Siddharta Gautama founded Buddhism around 500 BC; He was later called The Enlightened One or the Buddha. Buddhism spread to China via the Silk Road. When it first arrived it was considered part of Daoism because of how similar Daoism and Buddhism are. How ever a number of Buddhist monks came from India to China and kept the religion from being incorporated into Daoism. Buddhism encourages followers to throw off self-interest. Through meditation and right living, a Buddhist can reach Nirvana or absence of suffering which was a similar concept to Dao.

All three religions were not intolerant of each other although they did not always agree. Many people were subscribers of more than one religion and all three subtly influenced each other.

## What is their history?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-7)]

The first step of the Chinese civilization was started by the rule of the Shang dynasty (kings), who ruled a group of towns and cities. They ruled from 1766 - 1027 BC. They were mostly located in the North West of the present-day China, and the rest of the land was run by other tribes who the Shang could not reach. In 1027 BC, the Shang king was replaced by the Zhou Dynasty, and these people ruled for 400 years. They extended the kingdom southwards and towards central China. In 772 BC, barbarians destroyed the capital Hao and a new capital was built at Luoyang. But the Chou were never as powerful again and from 772 - 481 BC the land was split into many small kingdoms run by chiefs. Around 500 BC the hundreds of tiny kingdoms had turned into around 20 states. Peace was proposed to end the wars in the area, but war returned in 481 BC. This lasted until 221 BC in a period known as "The Warring States". After this time, there were seven big kingdoms. Starting in 230 BC, one of them, the Qin kingdom defeated everyone and Prince Cheng named himself Shi Huangdi, the First Emperor of China. The name Qin was also given to the land, and it still remains today as China.

## Are some of them famous?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Chinese&action=edit&section=T-8)]

Confucius (known in Chinese as Kongzi) is widely known as the prototypical Chinese sage. He spawned a whole school of philosophy. His follower, Mencius, is also known today. There are other ancient Chinese people known today, although their origin is thought of as legendary: Laozi, writer of the Daode jing, one of the five major classics of ancient Chinese wisdom; Sunzi, the military theorist who wrote the "Bing Fa", know in the West as "The Art of War". Historiographically, there is a rather important name: Sima Qian, the first major Chinese historian, dating from Western Han.

Politically, there are maybe two major figures: Qin Shi Huang, the First Emperor and the first builder of the Great Wall of China. Originally named Zhao Zheng, he conquered the remaining Chinese kingdoms and became the first "Son of Heaven" to aggregate "All-Under-Heaven", the whole territory. Nearly 60 years later, Emperor Wu of Han (Han Wudi) rose to power, marking the true beginning of Confucianism as "the" building block of the Imperial State.

Zheng He is another famous person. He explored the world on big ships in 1405, almost a century before Ferdinand Magellan set sail. Zheng He visited India, the Persian Gulf, Egypt, and possibly even the most southern tip of Africa!

# Egyptians[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=10)]

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Egypt_Nil.jpg/150px-Egypt_Nil.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

View of the Nile from the river

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/de/Nile_River_and_delta_from_orbit.jpg/200px-Nile_River_and_delta_from_orbit.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

What the Nile looks like from space

The Egyptians lived along the River Nile, the "fertile river" in north eastern Africa. This river flows from the central part of Africa. The Nile's water flows north, until it empties into the Mediterranean Sea. At the northern most part of the Nile, the Nile forms a **delta**. The delta of a river is formed at the river's mouth, where it leaves behind dirt and other sediment. At the delta a river often branches out into a wider, triangular shape.

The Nile was very important to life in Egypt. Seasonal floods every year covered the land near the river with fresh silt, making the land very good for growing food. In order to grow more food, people built **irrigation** canals to move water from the river to nearby areas. The Sahara Desert makes up much of the surrounding area, so most people didn't travel very far from the Nile. The surrounding desert land made the rich soil of the Nile very important for growing crops.

Egyptian transportation systems included boats that traveled north and south along the river. Boats could easily travel north, with the current of the river, but they could go south easily as well. The winds along the river usually blew to the south, so the Egyptians would raise sails on their boats and head against the current with the help of the wind!

The Nile was extremely important to the Egyptian civilization. A Greek historian, Herodotus traveled the river thousands of years after the Egyptians started their civilization. He is often quoted as saying that "Egypt is the gift of the Nile." This means that, there could not have been a civilization in Egypt without the Nile and what it made possible for the people there.

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-2)]

There were two types of buildings that the ancient Egyptians lived in. One was called the **worker's home**. The other was the **town house**, which was for wealthier people. Both types of houses were built from bricks. Stone was only used for building permanent structures, such as the Pyramids. The bricks were made from a mixture of mud, pebbles, and straw. The builders would pour the mixture into wooden frames and leave it in the sun to dry and harden. Buildings made from such bricks eventually crumbled, and new buildings were constructed right on top of the ruins. This led to the formation of tells or hills. Houses were often built along the Nile River, but they had to be high to avoid flooding.

A worker's home was usually one-story high and had up to four rooms. There was a yard and a kitchen in the back of the house, as well as two underground storage cellars. The roofs of the Egyptians houses were flat, and people spent much of their time there. Egyptian families slept, cooked, and ate their meals on the roof. It was a bit like having a living room, kitchen, dining room, and bedroom all up on the roof. The Egyptians did not have running water in their homes, but water could be taken from nearby wells. Workers' homes had very little furniture, including beds and storage chests for clothes.

The houses of the wealthy were much larger and up to three stories tall. Because the walls were much higher, they had to be supported by wooden beams. The walls of the first floor were sometimes made of stone for added strength. Different levels of the house served different purposes. The first floor was where business and work was conducted. The second and third floors were the living space for the family and had nicer furnishings. The roof was used for preparing and cooking meals that were then brought in by the servants. Wealthy homes had gardens, pools, and small shrines for worship. Some houses were decorated with tiled floors, barred windows, fancy staircases, and painted walls. The ceilings were high and held up with columns.

The pyramids were large stone structures built to house the bodies of the Egyptian rulers, or **Pharaohs**, after they died. The pyramids were built high, because it was believed to be the ruler's staircase to heaven. Although the most famous shape is the familiar three-dimensional triangle, pyramids were built in a variety of shapes. They were all built with the help of simple machines, including **pulleys**, **inclined planes**, and **levers**. The inside walls of the pyramids were decorated with **hieroglyphics**, the picture-based writing of the Egyptians. The tomb of the Pharaoh was located in a room deep in the heart of the pyramid, and was filled with gold, jewels, and other riches. It was also filled with other everyday objects that might be needed by the dead Pharaoh during his journey to the afterlife. This could include food, clothing, utensils, pottery, and furniture. Sometimes, even servants were sealed up in the tomb! Because of all the treasure inside the tomb, robbers sometimes broke into the pyramids, but their maze-like interior could cause them to get lost and die of starvation. Another defense against robbers were the curses written at the entrance of the pyramids. Most ancient Egyptians were very superstitious, and the curses were frightening enough to keep them away. Unfortunately, as centuries passed, thieves grew less afraid of the curses and managed to steal many of the ancient treasures that had been in the tombs for ages.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-3)]

The ancient Egyptians ate food that is not much different from what we eat today. Because the Nile River supplied them with a constant water source, the Egyptians were able to grow many different kinds of crops in their desert environment. Common crops included grains, vegetables, and fruit. The Egyptians relied on these crops as their main food source, because it was expensive to raise animals. Therefore, most domestic animals were used as work animals rather than as food. Often, Egyptian families hunted wild animals in order to add meat to their diets.

The Egyptians ate many different kinds of bread. The dough was made from grain, yeast, eggs, butter, salt, milk, and spices. In early times, it was cooked over an open fire. Later, pre-heated stone slabs were used. The bread was usually flat and round, but it might be shaped in rolls for special occasions. It could be plain or filled with beans, vegetables, or other ingredients. If sweet bread was desired, it would be flavoured with honey, fruit, or dates. Honey was the main sweetener for the Egyptians, because they had not discovered sugar. They also believed that honey had healing properties.

Fruits and vegetables made up a large part of the Egyptian diet. The abundant water of the Nile River allowed vegetables to be grown almost all year round except summer. Common vegetables included: cucumbers, onions, cabbage, garlic, radishes, leeks, and more. Green vegetables were often served with a dressing, usually made of vinegar and oil, not unlike the salad dressings we use today. The hot climate limited the variety of fruits that grew in Egypt, but figs, pomegranates, dates, melons, and grapes were readily available. Other fruits like coconuts, apples, and peaches were imported by wealthy people.

Fish was also a large part of their diet, although many rich people would not eat it. Fish was usually eaten fried, boiled, or roasted. It was also often sun-dried.

The Egyptians mainly ate beef. They also ate lamb, pork, goat, fish, duck, and geese. The rich soil made it easy to grow food. The rich soil came from yearly flooding that the Egyptians could predict. They grew barley, wheat, lentils, cucumbers, beans, leeks, onions, dates, figs and grapes. Everybody ate different foods. Poor people ate bread, onions, and other vegetables. Rich people ate cakes sweetened with honey. Their food was cooked in clay ovens.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-4)]

Most Egyptians wore white tunics made of linen. This clothing style was comfortable in the hot climate of Egypt. For men, this tunic came up to the knee, while for women, it reached the ankle. Women sometimes wore shawls with their dresses. While working, men wore loincloths, but many workers wore nothing at all. Women wore shorter skirts while working. Children often didn't wear clothes during the summer, but when winter came, they dressed in cloaks and wraps. Wealthier people had pleats in their clothing, and some noblewomen wore beaded dresses.

Egyptians wore sandals made of palm fiber or braided papyrus for shoes. Most people went barefoot and carried their shoes, wearing them only when necessary. Women seldom wore shoes, because most of their work was indoors.

Royalty wore ceremonial clothes which were elaborately decorated with feathers and sequins. The Pharaoh's sandals and gloves were both highly ornamented.

Both men and women wore makeup, which was made by mixing powdered minerals with oil. They also used a reddish dye called 'henna.' Unlike other ancient civilizations, the Egyptians were quite clean and washed and oiled themselves with scented oil before dressing. They used combs, razors, and tweezers as part of their hygiene routine. Men and women both wore wigs, which were changed every day and made from human hair or wool. Curled wigs were worn on special occasions.

Jewellery was a normal part of any Egyptian's outfit. All classes wore some type of jewellery. made of either gold or colorful beads or stones. Lapis lazuli and turquoise were used to make necklaces. Earrings and rings made of clay were also worn as a fashion accessory.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-5)]

During most of Egypt's history, **polytheism** (the belief in many gods) was practiced. One of the most important gods was Ra the sun god. Several of the gods were based on animals, or had animals as their symbols. One god was often shown as a jackal and another as a cow.

Often, there were myths told about these gods and goddesses that explained some of the major ideas in ancient Egypt. One famous myth involves Isis and Osiris. This story helped explain several of the most important beliefs, such as the belief in the **afterlife** .

Egyptians believed that after people died, they went to an afterlife, where they would continue their lives as they lived them on Earth. To do this successfully, however, they had to preserve everything that they had in life on Earth. This is the reason that Pharaohs were buried with everything that they owned. Pharaohs, and others who were rich enough, would have scenes of their life on Earth painted on the walls of their tombs, so that those same sorts of scenes could be "relived" in the afterlife. This is also why Egyptians believed in **mummification**: the body had to be preserved, so that the spirit, called the '**ka'**, could return to the body after death.

Under the rule of one Pharaoh named Akhenaten, Egypt became **monotheist**, meaning that they believed in one god. During this time, they worshipped the god Aten, another sun god. Monotheism was never fully embraced by the people of Egypt, however, and after the Pharaoh's death, the Egyptian people went back to polytheism.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Egypt_Hieroglyphe2.jpg/220px-Egypt_Hieroglyphe2.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Hieroglyphs.

The Egyptians had three types of writing. The first is called **hieroglyphics**. This was a kind of picture writing in which pictures and characters make up words. This can be very hard to read, because the words often run together, and the Egyptians didn’t use punctuation. Another form of writing is called ““Priests’ Writing.”” This form is the same as hieroglyphics, but written very fast in a cursive style. Last came “Demotic,” which became popular during the time when Egypt was ruled by Pharaohs.

Egyptians could carve hieroglyphs into stone, mud brick, or **papyrus** (paper made by pounding the stems of a reed until they stick together). Egyptian writing was so difficult that only a very few people learned to read it. If these “scribes” worked very hard, they could become court officials or priests. After Christianity became the religion of the Roman Empire, knowledge of how to speak and write Ancient Egyptian disappeared. In the early 1800s, a large slab of stone with three different forms of writing on it was found. Because it was found near the town of Rosetta in the Egyptian delta, it was called the **Rosetta Stone**.

Several years later, a man named Jean-François Champollion discovered that one of the languages on the stone was a form of Greek that he knew how to read. The three languages were hieroglyphs, Demotic, and Greek. By gradually comparing common words between the Greek and Egyptian languages, he was able to get a basic understanding of how the ancient Egyptian language worked. However, it has taken the work of many other people to understand Egyptian writing. Even today, there are many signs and words we do not understand. People are still working to put together the puzzle of what all the symbols mean.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-7)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/38/Tutanchamun_Maske.jpg/220px-Tutanchamun_Maske.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Tutankhamun's burial mask.

Yes! King Tutankhamun, sometimes referred to as "King Tut" or "The Boy King", is one of the most well known ancient Egyptian kings in modern times. Interestingly, he was not considered to be very important in ancient times and was not recorded on most ancient king lists. However, the discovery of his tomb in 1922 made him a celebrity. While many tombs of the past were robbed, this tomb was left virtually undisturbed. Most of the items buried with Tutankhamun have been well preserved, including thousands of artefacts made from precious metals and rare stones. This is why he has become so popular in modern times. The discovery of this tomb has allowed historians and archaeologists to have a glimpse of what some of the more important kings may have had in their burial chambers before they were robbed.

Another king, called "Akheonaten" is also famous today. Akhenaten was Tutankhamun's father, and he tried to change the Egyptian religion from many gods to just one god called "Aten", who only the King could worship. This was a very big change for the people of Egypt and may have been unpopular. Akhenaten built a new city called **Amarna**, but when he died it was abandoned until it was discovered by archaeologists. They were able to see how Egyptians built their cities because it was so well preserved. Egyptologists and historians have argued for many years about why Akhenaten would change the religion that had flourished for thousands of years. Some believe he may have worshipped the "Aten" as his father, Amenhotep III, others think he wanted to make himself more powerful by only allowing the king to worship the god.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Egyptians&action=edit&section=T-8)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Gizeh_Cheops_BW_1.jpg/220px-Gizeh_Cheops_BW_1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The Great Pyramid.

Even today Egypt is still a major country with a large population. Many modern Egyptians still live near the same land that their ancestors lived on thousands of years ago.

The ancient Egyptians wrote messages that they carved into the wall of many of their buildings, and most of the early work by Egyptologists was based on these writings. Moreover, thousands of papyrus scrolls -- on every aspect of life and many areas of knowledge -- have remained, many still untranslated, to this day. We have much of their art and jewellery as well. Many major pieces were recovered from King Tutankhamen's tomb, and from the tombs of many other Pharaohs. One of the more famous works is the bust of Neffertiti.

Many of the Ancient Egyptians' buildings, tombs and monuments survive, although most are in ruins. Still, there is much to be learned about Egyptian politics, history, religion, and scientific ideas.

# Greeks[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=11)]

## What area did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Greeks&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/58/Beginnings_hist_greece.jpg/300px-Beginnings_hist_greece.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The Beginnings of Historic Greece. 700 - 600 BC.

Ancient Greeks lived on the Balkan Peninsula (approximately at the territory of modern [Greece](/wiki/Wikijunior:Europe/Greece)) and on the western part of Turkey. They governed themselves from their cities, each of which had a separate government which governed over the countryside surrounding them. There were quite a few of these city states, but their two greatest cities were Athens, in the north, and Sparta in the south. The Greeks lived under their own rule until first being absorbed by the Macedonians, who lived to their north, and then finally the Roman Empire. Greece has many mountains and poor soil, which prevents many crops from being grown there. The country has a mild climate, which makes it convenient to farm goats and sheep. Also, Greece is a sea country: there are many beaches and islands, and no part of the country is far away from the sea. That made many of the Greeks sailors, and that meant that they sailed near and far, trading with different people, learning about other cultures, and bringing their own culture to faraway lands. These types of exchanges inspired development of Greek science and art.

## What did their structures look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Greeks&action=edit&section=T-2)]

Greek buildings were usually rectangular-shaped, surrounded by **colonnades** – rows of columns. Greece is rich in limestone, which was the most popular material of the time. Marble was more expensive, and was mostly used for statues and decoration.

Greek theaters looked very much like modern ones, except that most were open to the weather. There were semi-circled rows of seats, each row was higher than the row in front of it, so that people in the back could see better. Centered in front of the audience was a circular **orchestra**, where performances took place. A low building called a **skene** sat behind the orchestra. It was used to conceal actors, and gave room for costume changes, props and other "backstage" activity.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Greeks&action=edit&section=T-3)]

Greek men wore **chitons** – pieces of cloth pinned on one shoulder. Women wore **peplos** – long tube-shaped cloth, which was pinned on both shoulders and gathered around the waist. When it was cold, both men and women wore a cloak, called **clamys**. Greeks wore sandals, which looked a lot like the sandals that we wear today.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Greeks&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/75/St%C3%A8le_grecque1.jpg/200px-St%C3%A8le_grecque1.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Athenian decree from the 5th century BC

Greek writing looked a lot like Modern Greek text, written with capital letters. The Greek alphabet appeared in 8th century BC and was influenced by the Phoenician alphabet, the first alphabet that used signs for letters, not for words or syllables. Unlike the Phoenician alphabet, which did not have characters for vowels, the Greek alphabet had characters for all the sounds used in the language. In that sense it was the first modern alphabet, and the oldest to be used to this day. The Greek alphabet became a base for two other alphabets: Latin (that is used in English) and Cyrillic currently used in Slavic-speaking countries.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Greeks&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Aphaia_pediment_5_central_Glyptothek_Munich.jpg/300px-Aphaia_pediment_5_central_Glyptothek_Munich.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Athena

Greeks were **polytheistic**, which means that they believed in many gods and goddesses. Each god or goddess was “responsible” for some side of life or natural phenomenon.

Twelve of the most important gods resided on mount Olympus. Their leader was Zeus, the god of the sky. Other Olympic gods were: his wife Hera - the goddess of marriage and motherhood, Poseidon – god of the sea, Aphrodite - the goddess of love, Apollo – the god of art and leader of muses - and Athena, the goddess of wisdom and war, and the favorite daughter of Zeus.

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/14/Kentaur_Kreta_asb_2004_PICT3436.jpg/240px-Kentaur_Kreta_asb_2004_PICT3436.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Centaur

Greeks believed in many mystical creatures other than gods: titans – children of Gaia, goddess of Earth, challenging Olympic gods; nymphs – nature spirits; muses – goddesses and patrons of art; centaurs – half humans, half horses; Cyclops – one eyed monsters; giants.

In Greek myths, the Gods often had affairs with real people, and that’s how heroes, like Hercules – man of superhuman strength, who committed twelve labours, and Achilles – the hero of Trojan war, were born.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Greeks&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/34/Homer.jpg/150px-Homer.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Homer

We know many Greek politicians, scientists, and artists. Possibly the most known person of this culture is **Homer**, the legendary blind poet, who composed two masterpieces of Greek literature: the poems **Iliad** and **Odyssey**. **Sophocles** and **Aristophanes** are still popular playwrights and their plays are considered to be among the greatest works of world literature. Another famous Greek is a mathematician **Pythagoras**, mostly known for his famous theorem about relations of the sides of right triangles. **Archimedes** made many amazing inventions and discoveries. The legend says that he discovered Archimedes Principle while taking a bath, and got so excited, that he ran out naked into the street crying “Eureka!” – “I have found it!” The philosopher **Socrates** taught to question everything, separating beliefs from proven facts. He even questioned the existence of gods, which got him in trouble: he was accused of corrupting the youth and was sentenced to death by taking poison. Other great philosophers include **Aristotle** (the teacher of **Alexander the Great**) and **Plato**. **Alexander the Great** is known for his conquest of the Middle East and Central Asia.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Greeks&action=edit&section=T-7)]

The whole modern country of Greece! They still speak the same language, though it has changed some, use the same alphabet and preserve their heritage.

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Lincoln_Memorial_Close-Up.jpg/240px-Lincoln_Memorial_Close-Up.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The Lincoln Memorial in Washington D.C.

But Greek heritage is not limited to Greece only. It influenced Western culture greatly. That's why we call it the Cradle of Western Civilization. We use many Greek words in our everyday life, like democracy, philosophy, photography. In fact, the word _alphabet_ comes from _alpha_ and _beta_, the first two letters of the Greek alphabet. In mathematics, one of the greatest discoveries they made was about right-angled triangles which is still important in map making. Greek philosophers strongly influenced ideas in the West for many years and their ideas are still important in politics, religion, government, discussion and argument, and in how people should behave toward one another and in society as a whole. Greek architecture and art strongly influenced Western architecture and art. (What does Lincoln Memorial remind you of?) The foundation of our science came from Ancient Greece. The Greek style of sculpture is still used all over the world today for statues of famous people. The Greeks also invented the theater and many of their plays are still acted all over the world today. Many of their stories and poems are also read widely today. The Greeks were the ones who started the Olympic Games, back in 776 BC, in honor of the god Zeus at the town of Olympia. Soon their fun side became more important and they were not just religious festivals anymore. Games were held every four years until AD 394 and were later restarted in 1896. The first of the new Olympics was held in Greece in honor of their original home and they have grown to become popular worldwide.

# Hebrews[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=12)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Early-Historical-Israel-Dan-Beersheba-Judea-Corrected.png/200px-Early-Historical-Israel-Dan-Beersheba-Judea-Corrected.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Map of Israel before it was divided

## Who are Hebrews?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-1)]

**Hebrews** were ancestors of modern Jews. They claim to be the descendants of the biblical Patriarch Abraham. They are known for their input into world culture, because their beliefs have influenced 3 major religions of the world. They are also known for their cultural and spiritual laws, rules, and morals. The Hebrews have influenced society today to a high degree.

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-2)]

Hebrews were nomadic people. They lived in the ancient Middle East. Around 1400 BC they settled in **Canaan**, the country on the eastern coast of Mediterranean sea, the territory of modern Israel, Jordan, Lebanon and Syria. Later this country was known as the kingdom of Israel and, after the death of King Solomon, was divided into Israel and Judea.

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-3)]

In the warm climate of the Middle East the house was not so important. Most of the life of the Hebrew family happened in the open air. Women did the cooking in the yard; stores were just open counters looking into the street. Stone was used for building houses. There were no large forests in the land of Canaan, so wood was extremely expensive.

When Hebrews were nomadic people, they lived in tents. But even when they settled, tents were very popular. Tents are often mentioned in the [Torah](//en.wikipedia.org/wiki/Torah), and even at the time of David and Solomon, living in a tent was common, especially for poor people.

Another option was living in a cave. The natural cave was enlarged and a wall was built in front, converting the cave into a sheltered home.

Wealthier people lived in the houses built of sun-dried mud bricks. The roofs of the houses were flat, so that people could stay outside in the cool evenings and sleep in summer. Domestic animals were kept on the first floor, together with people. There were no chimneys; smoke from cooking or heating fires escaped through the windows. The furniture was very simple. It included a few mats, spread upon the floor at night for sleeping, and rolled up during the day, or a kind of divan set against the wall; there were a table and chairs; a large jug for grain stood in the corner, and others for water, wine, oil, etc.; a niche in the wall held the lamp.

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/40/Western_wall_jerusalem_night.jpg/300px-Western_wall_jerusalem_night.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Western Wall

But what made Hebrews really proud was the **Jerusalem Temple**. There were two temples built: the First Temple was built by King Solomon. Cedar wood for the construction was brought from Lebanon, and the walls and floor of the temple were covered with gold. The Ark of the Covenant was kept in the Holy of Holies, a room at the end of the temple. The first Temple was destroyed in 586 BC, when the Jews were exiled into the Babylonian Captivity.

After Jews returned from Captivity in 536 BC, they started building the Second Temple. This temple stood till AD 70, when it was destroyed by Romans. Another Temple was built and also destroyed. The only part that was left is from [Herod's Temple](/w/index.php?title=Herod%27s_Temple&action=edit&redlink=1) and is the Outer Western Wall, a sacred site for Jewish people. The Western Temple Mount wall is sometimes called the Wailing Wall and was believed to be from the second Temple and is often prayed near to, by the Jews today. This is also a "Talmedic" tradition.  


## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7a/2nd_century_Hebrew_decalogue.jpg/170px-2nd_century_Hebrew_decalogue.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Second century Hebrew manuscript of Ten Commandments

Hebrew food was similar to the food of other Mediterranean people: they ate homemade bread that the lady of the house would bake in the big clay ovens in the yard, lentils, goat cheese, olives, and fresh fruits. Meat was rare, and usually eaten on special days. Fish was more common. The most popular drink was wine.

But there was one difference about the food Hebrews ate: it had to be **Kosher**. Kosher applied to all different types of food. It applied to meat which had to come from correctly slaughtered animals. These animals had to have split hooves and had to chew their cud. The fish they ate had to have fins and scales. The wine had to be made and supervised by a Hebrew at all times because other cultures would put blood in it to help it ferment and eating or drinking blood is not Kosher. Some of the stricter Hebrews thought that meat should not be mixed with dairy, and that a person had to wait a few hours between having meat and dairy. This is a "Talmudic" tradition.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/ae/PLATE4AX.jpg/150px-PLATE4AX.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Jewish noblemen in ancient Judah

Both men and women wore a tunic with a girdle, a robe on top of it, and a mantle (a sleeveless over garment) and a headdress. Men's and women's clothes were different in style and pattern. Women’s garments were longer, with long sleeves.

Hebrew laws also had instructions about their clothing. They were supposed to wear tassels on the corners of their clothing, a commandment from the Bible. Their clothes were never a mix of wool and flax except for the high priest who was permitted to wear such a mixture. The priests also had special instructions about the clothing that they wore while they worked.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Torah.jpg/150px-Torah.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Torah Scroll

From very ancient times, the Hebrews began to write down their history, laws, and beliefs. The first five books or the **Torah**. The "Torah" was written in Hebrew. The books were written on large pieces of parchment and rolled into scrolls. These books were Genesis, Exodus, Leviticus, Numbers and Deuteronomy.

Hebrew was and is written right-to-left, with consonants and vowel points. The Hebrew script evolved over the course of their history so ancient Hebrew writing does not look the same as it does today. Here is an example of what ancient Hebrew writing looked like:

![Omri.melek.israel.gif](//upload.wikimedia.org/wikipedia/commons/thumb/1/19/Omri.melek.israel.gif/200px-Omri.melek.israel.gif)

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-7)]

Hebrews were among the first people in the world whose religion was **monotheistic**. Monotheism is the belief that there is only one God. All of their neighbors were polytheistic: they believed in many gods and goddesses that looked and behaved like humans. The idea that there is a single God who cannot be seen and is present everywhere and knows everybody’s thoughts was very unusual at that time. YHWH, יהוה or Yahweh, pronounced Yah-way and translates to "I Am", is the original Hebrew name of the Heavenly Father and the Jews believe saying his name is a forbidden. They use Adoni, pronounced Add-doe-nigh instead. He is also called El or Elohim in the Hebrew bible.

According to the _Torah,_ the first person to start spreading the concept of one God was the patriarch Abraham. Monotheistic beliefs are currently found in many religions all over the world.

The Hebrews believed that they were God's chosen people and that the Torah contained God's laws which must be followed.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-8)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/61/Moises.jpg/220px-Moises.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Michelangelo Buonarrotti. Moses

Many biblical heroes are known today. The Bible became the most published book in the world, and, since so much of it was written about Hebrews, many Hebrew historical figures became famous. Many books, paintings and even movies are dedicated to them.

  * **Abraham**, **Isaac**, and **Jacob** are the three patriarchs.
  * **Joseph** \- **Jacob's** youngest son born to him in his old age. According to the **Torah** he was sold in to slavery and ended up in Egypt, where he worked for Pharaoh. His most famous job was interpreting Pharaoh's dreams, which led to him saving Eygpt having a famine while the rest of the world was having one.
  * **Moses** \- Considered by many people to be one of the greatest leaders of Jewish people, and according to the Torah he is called the most humble man that ever lived. The most notable according to the **Torah** he took the Hebrews out of slavery from Eygpt, God through him brought 10 plagues to Egypt, split the Red Sea, received the **Torah** along with the **Ten Commandments** and the oral Jewish law, set up the Jewish courts, took them to the land of Canaan - the land God promised to them through Abraham.
  * **King David** \- One of three kings of ancient Israel and ruler of the largest territorial extent of ancient Israel. He was a significant military leader and lead the ancient Israelite armies in many successful battles. He wrote most of the songs in the **Book of Psalms**.
  * **King Solomon** \- According to the **Torah** he built the first temple. During his reign the kingdom of Israel reached its greatest prosperity, being one of the biggest powers in trade. He was known for his wisdom and justice. He also wrote songs in the **Book of Psalms**.

  


  * **Queen Esther** -Or Hadassah, queen of Persia, according to the **Torah** she saved Jewish people from evil plans of Minister Haman to kill all Jews throughout the Persian Empire. This event is celebrated during the Jewish holiday of Purim.

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Jesus_and_the_doctors_of_the_Faith_dsc01783.jpg/150px-Jesus_and_the_doctors_of_the_Faith_dsc01783.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Jesus speaking with Jewish teachers at age 12

  * **Jesus of Nazareth** \- Jesus is one of the most famous Hebrew of all. He was born in Bethlehem to Hebrew parents. He grew up in Nazareth, which is a part of Israel. He was an early follower of John the Baptist, who baptized him. He also became spiritual leader and many of his early followers were also Hebrew and are still famous today, such as the apostles Paul, Peter and John. Eventually Jesus became Christ and even God in the Christian faith.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Hebrews&action=edit&section=T-9)]

Kingdom of Israel was destroyed by Assyrians in 722 BC. Judea lost its independence to Rome in the first century AD. Jews had to leave their country. For two thousand years they lived all over the world, preserving their religion, language and traditions. They survived through centuries of discrimination and prejudice and through the extermination of one third of the Jewish population of the world in the Second World War. In 1948 the state of Israel was established again.

# Incas[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=13)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/34/Inca-expansion.png/220px-Inca-expansion.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Inca territory.

## What countries did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-1)]

The Inca lived in the Andes Mountains in South America. Their range stretched from southern Chile through Argentina, Bolivia, Peru and Ecuador and into southern Colombia.

The Inca were very warlike and often attacked their neighbors to take their land. In this way, the Inca Empire, which started out small, grew to be very large. In fact, the Inca Empire was the largest empire ever in South America, and one of the largest in the world.

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-2)]

The Inca lived in stone houses varying in sizes. They were all built in the Andes on flat plateaus. Their temples, however, were built on circular mounds made by the Inca, sort of like a slanted cylinder. At the top there was a plateau. On this plateau the main buildings were built.

A strange thing about the Inca was that they didn't use any iron tools to help them cut and shape the stone for their houses. Instead, they used round balls of stone to pound out blocks of stone for their buildings. The blocks of stone were not usually rectangles, but were very strange looking shapes that fit together much like the pieces of a puzzle. Many of the stone walls the Inca built are still so strong and well made that it is impossible to slide the blade of a knife between the stones.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/28/Zea_mays.jpg/220px-Zea_mays.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Corn.

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/ab/Patates.jpg/220px-Patates.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Potatoes.

The Inca ate potatoes and corn. They drank llama milk and water, and ate guinea-pigs for their daily protein, because they didn't have pigs, cows, sheep or turkeys. Occasionally, they ate llamas or alpaca.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-4)]

Typical Inca clothing would consist of a lightweight finely made poncho covered by a heavier, blanket-like poncho. They wore sandals and hats, some with fuzzy chinbands. Many rich Inca men wore large golden earrings as a symbol of how rich they were.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-5)]

The central god of the Inca religion was the sun-god _Inti_, the only god that had temples built for him. The sun-god was the father of the royal family. There were many gods among the Inca, but the sun-god outshone them all. The Inca also believed that there was a heaven, a hell, and a resurrection of the body after death. The Inca worshiped the dead, their ancestors, their king whom they regarded as divine, and nature and it's cycles.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Quipu.png/220px-Quipu.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Quipu.

The Inca did not have a system of writing with letters or symbols. Instead, they used a special system called _quipu_ (pronounced KEE-poo), tying knots in ropes of different colors. The ropes were kept on special belts that the _quipu_ writers would always wear. The different colored ropes could show deaths, weddings, trade, and other things. Being a _quipu_ writer took many years of schooling, and because very few learned, _quipu_ readers were very important.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-7)]

Yma Sumac is a singer who performed Inca and South American folk songs beginning in the 1940s. She is claimed to be an Inca princess directly descended from Atahualpa.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Incas&action=edit&section=T-8)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/64/Stone_windows_macchupichu.jpg/220px-Stone_windows_macchupichu.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Stone windows at Macchupichu.

The Inca are famous for their abandoned cities in the Andes Mountains. Some major cities like Cuzco and Machu Picchu, located in Peru, are major tourist attractions. Although many cities have been found, there are still many hidden in the jungles and under the desert floor. Archaeologists hope to one day know more about these people through their amazing artifacts.

![100% developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/ce/100%25.svg/24px-100%25.svg.png)

# Mound Builders[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=14)]

![Emerald Mound.jpg](//upload.wikimedia.org/wikipedia/commons/a/a8/Emerald_Mound.jpg)

## Where did they Live?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-1)]

The "Mound Builders" lived in what is today the eastern half of the United States and southern Canada, in North America. Their civilization lasted from about 1000 BC to about 1500 AD. A lot of the mounds were built from between 500 BC and 500 AD. Some of the biggest mounds were built after 1000 AD. The biggest mound was 100 feet tall.

Because the people who lived in these societies did not leave any written records, archaeologists look for similarities and differences between the mounds, and figure out which groups of Mound Builders interacted with each other.

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-2)]

![Mound Builder City.jpeg](//upload.wikimedia.org/wikipedia/commons/6/64/Mound_Builder_City.jpeg)

The name for this society comes from the fact that they left large earthen mounds behind in what appears to be community centers of activity. Many of these earthen mounds have been removed by modern peoples in North America, but they were found in many of the same locations where current cities in the United States are now located. They also lived in Spiro which is now present day Oklahoma.

A major feature of most villages was a trading area where items could be exchanged for items that were made in places much more distant. It is known that these trading networks were quite large, and they may have even had contact with other major civilizations in North America like the Aztecs. Items such as obsidian knives have been found over 1000 miles from any known source of volcanic rock.

Often within these mounds, particularly some of the larger mounds, there have been the remains of what is assumed to be a major chief or king, based on the items that are found buried with the person. This was also a reason for why many of these mounds have disappeared, because early treasure hunters would dig through these mounds trying to find gold, silver, or other precious stones and jewelry.

## When did they live there?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-3)]

  * Archaic Period
  * Early Woodland - Adena in Ohio, others in Illinois, Kentucky, West Virginia
  * Middle Woodland - Hopewell in Ohio, others in Illinois, Indiana, Missouri, Kentucky
  * Late Woodland - Effigy Mounds in Iowa, Illinois, Wisconsin, Michigan, and Minnesota
  * Mississippian - Cahokia Mounds in Illinois, Spiro Mounds in Oklahoma

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-4)]

They ate a wide variety of food items, depending on where they were living. Corn (maize) was brought into the area from Mexico and was widely grown together with other vegetables like beans and squash. They also hunted both small animals like rabbits and squirrels, and larger game animals like bison and various types of deer. In some lake regions they ate wild rice, and also ate fish either from the ocean or from freshwater lakes and rivers. They dried many foods to eat in the winter. And they also drank water from freshwater rivers.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-5)]

It is not completely clear how they dressed. If you look at the traditional clothing of their descendants, it was probably simple clothing made for protection from the weather. Their clothing was probably made mostly from animal skins. It may have also included plant fibers, and might have been colored with plant-based dyes.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-6)]

![Petroglyphs2-above Mesquite Springs-800px.JPG](//upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Petroglyphs2-above_Mesquite_Springs-800px.JPG/200px-Petroglyphs2-above_Mesquite_Springs-800px.JPG)

As far as we know, the Mound Builders never invented written language with an alphabet. There are, however, images which have been carved into rocks and in caves, as well as inscribed onto everyday objects like pottery. These can be found throughout North America. These images are called petroglyphs. Not all petroglyphs and pottery images are from the Mound Builders, though. Many come from other times and places in North America.

Often these symbols were arranged to tell a story, or note something of significance to the people who drew these symbols. Usually these symbols would be used to remind a tribal elder about a story that would then be passed on to the next generation, and unless that oral history has been preserved, the story is usually lost.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-7)]

From the jewelry and ceremonial masks buried in the mounds, some archaeologists think that the Mound Builders believed in animal spirits. From the images carved on rocks and bone, other archaeologists think that some Mound Builders may also have believed in some weather spirits, or ancestor spirits.

Because the Mound Builders did not leave any writings, some people look at the beliefs of the Mound Builder's descendants. Some believe in animal spirits, ancestor spirits, weather spirits, local spirits, or a mix of these spirits.

The ceremonial masks, jewelry, and artifacts come from a wide range of places. The Hopewell mounds had copper from Lake Superior, mica from North Carolina, and shells from the Gulf Coast. This might show that the beliefs were held in a wide area, or it might only show that the Mound Builders traded over a wide area.

The first evidence of humans burying the dead comes from the Mound Builders.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-8)]

We don't know the name of a single Mound Builder. Because the Mound Builders did not use writing, no names are known today. But we are still researching them, hopefully we will find names.

## What Happened To Them?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-9)]

  * There is some evidence (war, abandonment of some towns for small, stockaded settlements) that the civilization was in decline before the conquistadors arrived in Central America.
  * The diseases brought by the conquistadors spread quickly through the Americas. Lots of people died from European diseases like smallpox, especially in Mississippian towns where people lived close together.
  * By the time Europeans reached the Mississippi, many of the towns were empty.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-10)]

  * They spread the cultivation of corn, beans, and squashes throughout Eastern (and Central?) North America. These foods were the most important foods of many Native Americans, were important foods to the Europeans who settled the land, and are still important today. North Americans eat a lot of corn and beans. Some squashes (like pumpkins) are important symbols of fall and Thanksgiving in the US.
  * They left many mounds, which archeologists still study today. Some of the mounds are set aside in parks and monuments, so that people can look at the mounds, and learn from them. Some of the mounds are burial mounds, which contain ornaments. Archeologists learn how people lived and dressed from what is left in the mounds.

It is believed that they are the ancestors of several native American Indian groups in North America.

  * The Mississippian cultures left no written records, because they did not have a writing system like we have. They could not write books.
  * culture: stories, architecture, tools, and arts of Native Americans.
  * Native American Art is known around the world today.
  * Native American folk tales
  * Native American religious beliefs

## Who Lives There Now?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mound_Builders&action=edit&section=T-11)]

Settlers from England and Europe often built their own towns on or near abandoned mound builder towns, because they were in good locations for farming or trade. In some cases, they forced the Native Americans out before settling. Some cities that were built on or near mound builder towns are Cahokia, Illinois; Marquette, Iowa; and Chillicothe, Ohio. Now, the people who live in these places are citizens of the USA or Canada. They study the history of Europe, and of the people who built the countries of North America. Their ancestors are mostly from Europe, Africa, and Asia.

Most of the people who live on or near mound builder towns don't even know it. Now, hundreds of years later, people are beginning to study the graves, towns, and temples of the mound builders.

  * <http://www.cahokiamounds.com/cahokia.html>
  * <http://www.nps.gov/efmo/index.htm>
  * <http://www.nps.gov/hocu/>
  * <http://www.ohiohistory.org/places/newarkearthworks/index.cfm>
  * <http://www.nativeamericans.com/MoundBuilders.htm>
  * <http://www.cr.nps.gov/archeology/feature/feature.htm>
  * <http://www.mississippian-artifacts.com/>
  * <http://ngeorgia.com/history/early.html>
  * <http://www.angelfire.com/wi/oneota/>
  * <http://mcclungmuseum.utk.edu/permex/archaeol/archaeol.htm>
  * <http://www.ah.dcr.state.nc.us/sections/hs/town/town.htm>

# Mayans[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=15)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/92/Palenque_11.jpg/300px-Palenque_11.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Temple of the Cross at Palenque in Southern Mexico.

The Maya were a Mesoamerican civilization. They had the most advanced writing system in the Americas prior to European contact. They used sophisticated mathematic systems and had complex and useful cyclical calendars. Spectacular art and monumental architecture were two other notable accomplishments of this civilization.

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-1)]

The ancient Mayans lived in what is now known as southern Mexico and northern Central America including Guatemala, Belize, Honduras, Yucatán Peninsula and El Salvador. Their descendants still live there today, and many of them speak the Mayan languages.

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-2)]

The Mayans were master architects, building pyramids and even entire cities, many of which are still standing today.

Mayan pyramids were made of stone. The stone was carved to create a stair-step design. On the top of each pyramid was a shrine dedicated to a particular deity. Rituals thought to influence the Gods were held in these shrines.

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Lightmatter_chichen15.jpg/220px-Lightmatter_chichen15.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Pyramid of Kulkulkán at Chichén Itzá

Mayan cities grew around the pyramids. They consisted of plazas connected together by _sacbeob_ (whiteway) causeways. There appears to have been little planning in their design; the topography of the region influenced the type of buildings constructed. For example, cities in the hills had tall towers, while cities built on limestone grew into large municipalities.

The largest plazas were at the heart of Mayan cities. They contained governmental and religious buildings, such as the royal acropolis, great pyramid temples, and occasionally ball-courts. Temples and observatories were always constructed so they followed the Mayan interpretation of the orbits of the stars. Outside of this center were less important temples and shrines. At the outskirts lay the homes of the common people.

### Building Materials[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-3)]

The Mayans lacked many tools, such as metal tools, pulleys, and perhaps even the wheel. They did, however, have an abundance of materials. The most common material was limestone, taken from local quarries. Limestone was easy to work, and only hardened once removed from its bed. In addition, it could also be used as mortar or stucco. Common homes used wooden poles, adobe (a mixture of straw and sandy clay), and thatch; however, houses made of limestone have been found as well. In the city of Comalcalco, fired-clay bricks have been found as a substitute for stone. The Mayan's used clay, stone, limestone, thatched hay, wooden poles, and metal to make common day houses.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-4)]

The Mayans grew a wide variety of crops, including corn (maize), Amaranth, manioc, and sunflower seeds. These crops were grown in permanent raised fields, terraces, forest gardens, and managed fallows. There was also harvesting of wild crops. The Mayans ground cacao and mixed it with water to make the first chocolate.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/53/Yaxchil%C3%A1n_lintel.jpg/220px-Yaxchil%C3%A1n_lintel.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The sculpture depicts a sacred ritual. The standing figure wears a headdress of Quetzal plumes. Mayan writing is seen at the top and right side.

When the king appeared in public, he wore white robes and a gold crown on top of his head, decorated with Quetzal (a type of bird) plumes.

During wartime, the Mayans wore masks, while commanders wore robes made of silver and gold. Some Mayan clothes were made of deer skin. Usually women made the clothes.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-6)]

The Mayans wrote using a series of glyphs (symbolic pictures), which were painted on ceramics, walls, or bark-paper codices (books), carved in wood or stone, or molded in stucco. Each glyph represented a word. Mayans wrote numbers vertically.

The Mayan script was used up until the arrival of the Spanish. Although many Mayan centers went into decline (or were completely abandoned) during or after this period, many Mayans still had the skill and knowledge of Mayan writing, and the early Spanish conquistadors knew of people who could still read and write the script. Unfortunately, the Spanish however believed that the Mayan books were evil so by the end of the 16th century, almost all knowledge of the Mayan script was lost.

Attempts to decipher the Mayan script came in the 19th century. Investigators were soon able to decipher the Mayan numbers and portions of texts related to astronomy and the Mayan calender. Most of the Mayan script has since been deciphered, but work still continues today. The Mayan calendar ends at the year of 2012, when they believed the world would end.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-7)]

The Mayans believed that time was cyclical, that is, it goes in circles. The Mayan shaman interpreted these cycles by looking at the number relations of all their calendars. If the interpretations of the shaman showed bad times ahead, human sacrifices would be performed to make the gods happy. They left behind a prophesy that the world would end on December 21, 2012 and bring about the fifth cycle of the world.

According to Mayan mythology, there were thirteen heavens and nine underworlds, with one god for each. Natural elements, stars and planets, numbers, crops, days of the calendar and periods of time all had their own gods.

The creation story of the Mayans is found in the _Popol Vuh_ ("Council Book" or "Book of the Community"). According to the book, the gods Tepee and Tucuman's decided that, in order to preserve their legacy, they had to make a race of beings who could worship them. Earth, along with the animals, was created. Man was first made out of mud but then he fell apart. Other gods were summoned and man was next created of wood but had no soul. Finally, man was made out of maize by even more gods.

The Mayans worshiped Gods and Goddesses and they believed to make the Gods and Goddesses happy they had to make human sacrifices.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-8)]

The ancient Mayans abandoned their large cities suddenly. To this day, no one is still certain why. However, the Mayan people never died out; their descendants still live in Mexico and Central America. The Mayan's legends and royal lineage is written in a book called Popul Vuh. The word 'hurricane' comes from the name of a fearsome Mayan god named Hurakan who is mentioned in this book.

### People[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-9)]

Mayans painted their bodies red, black, white, and blue and thought crossed eyes were cool. They tied objects to their babies' heads to give them crossed eyes. They tied boards to their babies' heads to flatten them too.

At the start of the 21st century, there were about 6 million Mayans living in the Mexican states of Yucatán, Campeche, Quintana Roo, Tabasco, and Chiapas, and in the Central American countries of Belize, Guatemala, and the western portions of Honduras and El Salvador.

The largest group of modern Mayans is found in the Yucatán region of Mexico. They speak both "Yucatec Maya" and Spanish, and are generally integrated into Mexican culture. More traditional Mayans are found in Guatemala. Many of them wear traditional clothes and practice traditional customs. The most traditional Mayans are a group called the Lacandon, who avoided contact with outsiders until the late 20th century by living in small groups in the rain forests.

### Cities[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Tikal_temple_jaguar.jpg/220px-Tikal_temple_jaguar.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The city of Tikal

There are many Mayan buildings that were once part of cities still standing today. The most important ones are: Chichen Itza, Coba, Copán Kalakmul, Tikal, and Uxmal. These cites lay forgotten for centuries, until modern-day explorers rediscovered them. Archaeological surveys and excavations were conducted (and are still being conducted) on some of these sites, revealing more about Mayan culture. Today, some cities can be visited by tourists.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Mayans&action=edit&section=T-11)]

There are indigenous people in Southern Mexico, Guatemala, and Honduras who are descended from the Maya. One of the most famous of them is Rigoberta Menchu, a Quichè Indian. She wrote about the struggles of her people in her book I, Rigoberta Menchu. She received a Nobel Peace Prize.

# Norse[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=16)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Territories_and_voyages_of_the_Vikings_blank.png/250px-Territories_and_voyages_of_the_Vikings_blank.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Routes that the Vikings took between the 8th century and the 10th century. The green shading marks their places of main settlement.

The Norse were a people in northern Europe. They are also often called Vikings. The Vikings were skilled sailors and sailed long distances on their ships. They even visited America hundreds of years before any other European went there.

During the Viking Age, Vikings often raided the British island and other parts of Europe. But they also traded with the rest of Europe.

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/4/47/Sognefjord%2C_Norway.jpg/200px-Sognefjord%2C_Norway.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Sognefjord, Norway

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Kalf%C3%A1rvellir-Sn%C3%A6fellsnes-Iceland-20030528.jpg/200px-Kalf%C3%A1rvellir-Sn%C3%A6fellsnes-Iceland-20030528.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Scene from Iceland

The Scandinavians were many different kinds of people who had different homes. They lived in the areas that are now Denmark, Sweden, Norway, Iceland, Greenland and many small islands in the Baltic Sea, North Sea and Norwegian Sea. These places were their home countries. When the Viking Age began around the 9th century, they traveled far and wide across all of Europe, the Mediterranean and even down into the Middle East. Some settled in the places they traveled to, but their homes remained in the north. Norway, Sweden and Denmark were the homes to the Scandinavians before Iceland was discovered in the 9th century. Many people sought out Iceland as a place of refuge, and possible fortune (because of the available new lands) during the reign of Harald Fairhair. Many went to Iceland to escape punishment and sometimes they left for Iceland when they had been exiled.

Greenland was settled sparsely. In the Norse sagas they say that Erik the Red was exiled from Iceland for murder, and when travelling further west, found Greenland and named it Greenland. But regardless of his discovery, Eskimo tribes were already living there at the time.

Though each country was 'Scandinavian', there were many differences between the people, kings, customs and history of Denmark, Sweden, Norway and Iceland.

  
The word "Viking" is an Old Norse adjective meaning " to go on an adventure". people who travelled overseas from their native land were called Vikings.

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-2)]

The Norse lived mainly on farms, but some lived in towns and villages. The houses were made of whatever was available. Wood was preferred, but stone or blocks of turf were also used, as was wattle and daub, which was woven sticks with mud caked up to several feet thick on them, placed between posts to hold up the roof. Roofs are believed to have usually been thatched or of sod. Some roofs may have had tiles made of slate, limestone or wood. They usually had only one room, but a wealthy family could have up to four rooms. The farmhouse was usually larger than town houses, and there were other buildings that were part of the farm, for things like storage, livestock and the blacksmith. The houses were called long-houses because they were much longer than they were wide. They had a very steep pitch to their roofs so that most of the snow that fell in winter would slide off, and not cause the roof to collapse under its weight.

The cooking was done on a long open hearth, which usually ran down the centre of the main room. There was no chimney. A hole in the roof let much of the smoke out, but the houses would still be very smoky. Raised platforms along the long sides of the house would be used for seating during the day, and as beds for most of the household at night. Sometimes the head of the household, particularly in wealthier homes, would have a bed in a separate room, or in a small closet in the main hall. The homes of the wealthier Norse also decorated their homes with carving and paint.

In towns, half logs were often laid out between houses as a kind of path or road as the ground could become quite muddy. Some homes also had wattle fences erected around what we would call their front yard so they could keep a few livestock and not have them wander through the town.

Inside the home, there were no cupboards or wardrobes for keeping things in. They had hooks on the wall for hanging up items and chests to store things, which could also be used for seats. The woman in charge of the household would have the keys to these chests hung from her brooches; they were considered a sign of status. In addition, items (especially food) could be hung from the open rafters overhead, out of reach of the dogs, children, and mice.

The loom was used for making cloth for clothing and sails for the ships, and was a common item in most houses.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-3)]

The food they ate for breakfast was porridge from ground grains mixed with goat’s milk and honey. Many different foods have been found at Viking sites including berries, apples, fish, seal, pig, cow, lamb, grains, flat bread, turnips, herbs and more. Stews were a common food as all the ingredients, meat, herbs and vegetables, could be thrown in a pot hung over the fire. Flat bread was made from ground grain and liquid and eggs were added to the flour until it became dough. This was then rolled out and cooked in a similar way that you would cook pancakes on an open fire. A common drink was mead, which was made from honey.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-4)]

Their garments were mainly made of wool and linen. Thread was spun using a spindle whorl and then woven into cloth using a drop weight loom. Tablet weaving and even embroidery was used to decorate garments. Women usually wore an under-dress, a dress and an apron. Men wore a shirt that reached to mid thigh and trousers. Both men and women used cloaks. Boots were made of leather. Since Vikings did not have pockets, the men had leather pouches on their belts and the women hung items from utility chains that were attached to brooches they wore at the top of their aprons. Children were dressed similarly to adults. Vikings also loved bright colours used natural things like bark and vegetation to dye their clothes. They had colours like orange, yellow, brown, green and blue as well as many others.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-5)]

The Vikings believed that their world was divided up into nine worlds, on three levels, all held together by the great tree, ‘Yggsdrasil’. Perched upon the tree was the eagle ‘Vidofnir’.

The top level consisted of:

  * Asgard, home of the Aesir or Warrior Gods.
  * Vanahiem, the home of the Vanir or Fertility Gods
  * Alfeim, the home of the Light Elves.

The middle level or “Middle Earth” was connected to the Higher worlds by the great rainbow bridge ‘Bifrost’. Inside this level, were the homes of:

  * Midgard, home of the Humans.
  * Nidavellir, home of the Dwarves.
  * Jotunhiem, home of the Giants.
  * Svartalfhiem, home of the Dark Elves.

Encircling this level, was the great serpent ‘Jormungand’, one of god Loki’s misshapen offspring.

The bottom level included:

  * Muspell, Realm of Fire.
  * Niflhiem, Land of the Dead.
  * In this land is the ‘Niddhog'

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-6)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Runes_futhark_old.png/150px-Runes_futhark_old.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

An example of the Elder Futhark

In pre-Christian times; the Vikings used an alphabet which was comprised of _Runes_. Their alphabet was called the _Futhark_, from the first five letters of their alphabet.

In later times, after most had converted to Christianity (from their earlier Pagan religion), they adopted most of the Latin Alphabet (one of the reasons they adopted it was due to the fact that most Christian writings were written in Latin). However, they kept two runes and adopted them to their Latin alphabet. They were Thorn (Þ) and Eth (Ð).

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-7)]

Yes. One of the most famous Vikings was Leif Eriksson. He took fleet of ships and around the year 1000 sailed to Canada. He is known as one of the first Europeans to set foot in North America. Leif Eriksson was the second son of Erik Thorvalsson, or Eric the Red as we more commonly know him. Erik the Red discovered Greenland after being banished from both Iceland and Norway.

Another famous Viking King is **Harald Hardraada**, who attacked the North of England in 1066. **Harold I** of England defeated him in battle and repelled the invaders. Later on, when **William the Conqueror** of Normandy invaded, Harold lost the battle of Hastings and was shot in the eye with an arrow. This was the beginning of the line of French kings to rule England.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-8)]

Descendants of the Vikings inhabit most of northern Europe even today. The Scandinavian countries of Sweden, Norway, Iceland, and Denmark openly claim Viking heritage and the royalty from those countries descend from the ancient Viking kings. The Vikings also were absorbed into the cultures of many other Northern European countries, especially those countries surrounding the Baltic Sea and the North Sea.

Many Germanic languages like English also have words that come from Norse traditions. For example, the days of the week were named after Norse gods. Tuesday was named after Tyr; Wednesday was named after Wodin, another name for Odin; Thursday was named after Thor; and Friday was named after Frige.

## How do we know this?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-9)]

We know this from carefully studying what they have left behind, in their garbage heaps (called _middens_), their graves, and in areas where their houses had been built. We also can read about their lives in the _sagas_, stories that they told about themselves. Several of them were written down by early Christian monks. We also have carvings they left behind on large rocks, called _rune-stones_, that were often raised in memory of a person or event. These rune-stones allow us to have an idea of what they looked like, and what they considered important enough to go to the expense and effort of raising a stone to remember.

Today, new technology, such as computer imaging and DNA sequencing, is allowing us to learn even more, even from very old finds, such as the Oseberg ship burial, which was found over a hundred years ago.

## For More Reading[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-10)]

There are many great websites that have information about the Norsemen. Here are a few:

### In Wikipedia[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-11)]

[The Viking Wikipedia Article](http://en.wikipedia.org/wiki/Viking)

### Other Websites[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Norse&action=edit&section=T-12)]

[BBC's History for Kids Site (Vikings)](http://www.bbc.co.uk/schools/vikings/index.shtml)

[The Viking Answer Lady](http://www.vikinganswerlady.com/)

[Hurstwic, Norse Re-enactors](http://www.hurstwic.org/)

# Persians[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=17)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Map_achaemenid_empire_en.png/300px-Map_achaemenid_empire_en.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The Persian, Achaemenid Empire at its greatest from 648 BC to 330 BC

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-1)]

The Persian Empire started in the north west corner of what is now Iran. It grew through military conquest to cover a huge region that roughly encompasses today's Iran, Iraq, Armenia, Afghanistan, Turkey, Bulgaria, many parts of Greece, Egypt, Syria, much of what is now Pakistan, Jordan, Israel, the West Bank, the Gaza Strip, Lebanon, Caucasia, Central Asia, Libya, and northern parts of Arabia. The empire eventually became the largest empire of the ancient world.

Persepolis was the ceremonial capitol of Persia. Susa and Pasargadas also were capital cities at different times in Persian history. They were all in what is now Iran.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Granadas_-_Pomegranates.jpg/150px-Granadas_-_Pomegranates.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Pomegranates

The food prepared for Persian kings is legendary. Persians ate stews made from meat and fruit with herbs. They ate rice and bread made with wheat. Yoghurt was also a staple in Persian food. Tablets from the time of these ancient peoples indicate that the inhabitants of Mesopotamia were using basil, cilantro, cumin and caraway in their food in 4,000 BC. Apricots, artichokes, eggplants, lemons, lime, oranges, pistachios, spinach, saffron or tarragon all came to Europe through Persia. Other condiments and spices such as cinnamon, cardamom, cloves, coriander, dill, nutmeg, paprika, pomegranates, saffron, sumac, turmeric, as well as orange-flower water and rose water were used in Persian food. Lamb and goat were the primary meats eaten by Persians. Persians did not eat beef!

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/36/Takht-jamshid.jpg/250px-Takht-jamshid.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

the ruins of Persepolis

Persians made very interesting buildings. The Ruins at Persepolis are an example of ancient Persian buildings. Persians were among the first to use mathematics, geometry, and astronomy in their building. Their buildings were grand and were created by skillful workers. Some Persian buildings had huge barrel-vaulted chambers. The Persians created huge domes of rock and clay and supported their roofs with tall columns. They also decorated the walls of their palaces with lions, bulls and flowers.

The Kharaghan twin towers and the Shah Mosque are two other old buildings built in a Persian style.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/2/29/Persepolis_Apadana_noerdliche_Treppe_Detail.jpg/200px-Persepolis_Apadana_noerdliche_Treppe_Detail.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Carvings in Persepolis

The Persian king wore a robe of honor that was a large piece of fabric that was draped around him. For the king and other aristocracy, their clothes were often decorated with golden clothing ornaments. Some of these are in the form of roundels, while others are gold plaques with loops or rings on the back so they can be sewn onto the cloth. Rich people also liked to wear gold jewellery such as bracelets with animal head carvings.

Common people wore coats and pants made out of leather. Men's coats reached from their shoulders down to their knees and were fastened with a girdle. Their sleeves were somewhat tight and went down to their wrists.

Originally woman's clothing was quite similar to men's clothing but as time went their style changed. Initially their clothes were short and tight but when the style changed their clothes were made longer, more voluminous and were made out of softer materials.

Persian shoes were usually just pieces of leather that were wrapped around their feet and were tied up on the top. These would have look similar to moccasins. Persians also wore red clothes to show respect to their husbands

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Behistun_detail.jpg/150px-Behistun_detail.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Detail of old Persian writing.

Old Persian was written from left to right in Old Persian cuneiform script. Old Persian cuneiform script was supposedly invented by King Darius I, one of ancient Persia's famous kings. There were 36 letters in their alphabet, although some of them essentially represented different syllables. For example they had one symbol for "ka" and another symbol for "ku". They used these symbols even though they also had symbols that represented "a" and "u".

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-6)]

The Persian civilization spawned three major religions: Zoroastrianism, Mithraism, and Manichaeanism.

The Persian thinker Zoroaster, an Aryan nomad,(who propagated Zoroastrianism) was the main religious movement leader. Living around 18th century BC (although some believe as recent as 6th century BC), he helped to unite the Persian empire. He rejected the old Persian gods and introduced that a single wise god, Ahura Mazda, ruled the world. However, Ahura Mazda was often in battle with the prince of evil and lies, Ahriman who is also known as Angra Mainyu. On Earth, each person had to choose which side to support. Ahura Mazda had a helper that secretly helped Ahura and Angra, his name was Eshmugeler.

Zoroaster's teaching were written in a book, the Zend-Avesta. It said that Ahura Mazda would conquer over the forces of evil, Ahriman, at the end. On that day, all the people would be judges for their actions. Those who did good would enter paradise. Those who did evil would be condemned to eternal suffering. Now most Persians are Muslims.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-7)]

Of course, but perhaps the most famous Persian of all time is [Cyrus the Great](//en.wikipedia.org/wiki/Cyrus_the_Great) who founded the Persian Empire. In fact, in 1992 he was ranked #87 on [Michael H. Hart](//en.wikipedia.org/wiki/Michael_H._Hart)'s list of the most influential figures in history. Other famous Persian kings were Cambises and Darius the Great.

**Darius III** is famous only because he suffered under the hands of Alexander the Great of Macedonia. During Darius' reign, the whole Persian Empire was destroyed by Alexander, who first attacked the Persians in what is now modern Turkey. He then moved on into the heart of the Empire where he captured the capital Susa. Darius ran away from battle against Alexander twice, but was murdered by his governor Bessus who wanted the throne for himself. Alexander was angry this happened and respected his dead opponent. He held a great funeral for the dead king. Later, Bessus was captured and executed.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Persians&action=edit&section=T-8)]

Persians are one of the few ancient civilizations who have made significant contributions to humanity from prehistoric times by their Persian empire all the way through to the modern day in their country Iran. Many Persians are now Muslims, although there are Jews, Christians, and Zoroastrians still living and practising their religion in Iran. There are also some Zorastrians, called Parsis, living in India with majority of the community in Mumbai.The Parsis practise the Zorastrian religion and fled from Iran when the Muslims invaded. Rather than convert to Islam a small group set sail from Iran and landed on the shores of India.

# Romans[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=18)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Roman_Empire_Map.png/250px-Roman_Empire_Map.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

The Roman Empire at its greatest extent in 116 AD

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-1)]

At the start, the Romans lived in a region that now forms part of [Italy](/wiki/Wikijunior:Europe/Italy). Through conquest of nearby peoples, the Roman Empire expanded. At its peak, the empire controlled most of Western Europe, North Africa, [Greece](/wiki/Wikijunior:Europe/Greece), the Balkans, and the Middle East. The capital Rome grew from a simple village to a thriving metropolis. Even today, some 2500 years later, Rome is still a major world city.

  


## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Campitelli_-_Insula_romana_1907.JPG/200px-Campitelli_-_Insula_romana_1907.JPG)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Remains of the top floors of an insula near the Capitolium and the Aracoeli in Rome.

Many public buildings built by the Romans, were huge works of white marble complete with arches and grand architecture. The average house by comparison was smaller and plainer, being built of bricks and timber. Much of our extensive knowledge of Roman Buildings comes from ruins and remains left in the ground.

  
Inside a middle class home (a domus), there were many rooms, with distinct functions. These ranged in size, from small cubicles in which they slept, through medium sized rooms in which they eat, to large halls in which they would receive and entertain guests. The rooms in the house normally opened out onto a courtyard. Despite its often small size, the purpose of this courtyard was to provide light and air to the rooms. As well as a courtyard, most wealthy people would also have kept a garden behind the house, in which flowers, fruit vegetables (and even grape vines) would have been grown.

  
In the city of Rome most people lived in two or three-story apartment buildings called _Insulae_. Here a whole family lived in only one or two rooms, spending much of their time outside in the courtyards and streets. Water came from nearby public fountains and aqueducts.

The Romans as well as house builders, constructed many public buildings, including temples, marketplaces, forum, and amphitheaters. These public works also included things required for city living like aqueducts and sewers.

Military building was also undertaken, the largest construction being Hadrian Wall at the Northern Fringes of the Roman Empire. Even today remains of it are still visible in Northern England.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-3)]

Both the rich and poor ate bread and porridges made from wheat, barley and other grains. This was their main staple food. Some of the other common foods that they would have eaten were chicken and other birds, beans, lentils, walnuts, eggs, apples, cheese, milk, wine, figs, dates and grapes.

While most of their food would be familiar to us, Romans did have their share of strange or unusual feast items, including wild boar, peacock, snails, and a type of rodent called a dormouse. Another difference was that while the poor people and the woman ate their food while sitting in chairs, the rich men liked to have banquets together where they would lounge on their sides while they ate their meals.

Ancient Roman meals couldn't have included foods that came to Europe from America or from Asia in later centuries. For instance, they didn't have corn, nor tomatoes, nor potatoes, nor cocoa, and no ancient Roman ever tasted a turkey.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-4)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Toga_Illustration.png/150px-Toga_Illustration.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A Roman man wearing a toga

People in Rome had three types of clothing. Firstly, they wore a loin cloth. This was worn like underwear. Then, over their loin cloth they would wear a tunic and women would sometimes wear two tunics. A tunic was usually made out of wool but occasionally linen. It was a loose garment that fitted over a person's head and was joined at the shoulders and sides. It would resemble a nightgown in our society. Finally, on top of a man's tunic he would wear a toga whenever he went into public, if he could afford one. Togas were large pieces of wool fabric that were wrapped all around the body. Interestingly, only Roman citizens were permitted to wear togas. It was symbol of peace because Roman soldiers also didn't wear togas. Togas were decorated in different ways to indicate rank, like a uniform. For example, a purple fringed toga indicated that the person wearing it was a leader.

Women in Rome also had an outside garment that corresponded to the male toga. It was called a stola and was also made of a large piece of fabric but it was wrapped and attached differently. Woman also wore a warm shawl called a palla when they went out.

Fashion changed as the empire progressed. Initially in Rome both men and woman wore togas but that changed fairly early in the Roman empire. Also, cloaks that were like large ponchos were first primarily used by poor people and soldiers but eventually became the standard dress for even the wealthy. Togas in that era had become purely ceremonial.

Roman men and woman also wore shoes or sandals unless they were extremely poor. They were completely made of leather, even the soles. When visiting one another they would wear them into their friend's home but remove them before eating.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/fb/MarcianaDen%28114%29.jpg/150px-MarcianaDen%28114%29.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A roman coin; note the common letters

Romans developed what is now called the Latin alphabet for their writing. The Latin alphabet is nearly the same as the current English alphabet but originally it only consisted of capital letters. Also, the Romans didn't use a few of the letters that are a part of the modern English alphabet such as j, x and w. The Latin alphabet, invented by the Romans, became the base of the writing systems for many languages all over the world today.

The Romans also invented a way to write the capital letters in cursive. They also didn't use punctuation the way that we do today.

Roman numbers were written with letters as well. These are called Roman numerals.

  * M = 1,000
  * D = 500
  * C = 100
  * L = 50
  * X = 10
  * V = 5
  * I = 1

2008 is written as MMVIII in Roman numerals.

In the Middle Ages, it was very hard to do maths with these numbers, and Arabic numbers (the ones we use today) began to be used. People found that banking and doing maths was much easier with these new number symbols.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-6)]

The Romans, like many other ancient civilizations, were polytheistic; this means they worshipped many gods. Each god or goddess, a female god, would be connected to a certain part of people’s life. If you were a fisherman you might pray to Neptune, the god of the sea. However if you were a warrior you would pray to Mars the god of war. All these gods and goddesses had different stories. These long stories of the gods have lived on in writings on pots and in scripts, or books, by ancient people. Most of the Roman gods were taken from the Greek culture. For example, the god Neptune was taken from the god Poseidon. Today, the names of the Roman gods are used as names for planets!

Romans were generally tolerant of other polytheistic religions, and often adopted foreign gods into their religion, including Egyptian gods. Emperors sometimes declared themselves to be gods. Monotheists such as Christians, who believe in only one god, were distrusted because they refused to worship the emperors and were often persecuted.

## Are some of them famous even today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-7)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Maccari-Cicero.jpg/500px-Maccari-Cicero.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

This 19th Century fresco imagines Cicero denouncing Catiline in the Senate. Cicero mentions in his first speech against Catiline that the other senators have stood up and moved away from him, leaving him alone.

Roman history and literature have had a strong and continuous influence on Western culture for thousands of years, so many Roman statesmen, poets, and philosophers remain famous today.

Julius Caesar is probably the most famous Roman of all time. He was a Roman military and political leader and one of the most influential men in world history. As a general, he led invasions of France and Britain. Most people in Rome thought Caesar was a hero, but his enemies said that he only cared about winning fame and power for himself. When the Senate ordered Caesar to disband his army, he was afraid of what they would do to him, so he began a civil war. Four years later, Caesar won the war and became dictator for life. A group led by Cassius and Brutus, who called themselves the Liberators, killed Caesar at a meeting of the Senate because they thought it was the only way to save the republic. However, Caesar's friends defeated the Liberators in the ensuing civil war, and the Roman Republic became the Roman Empire. Caesar is also famous for reforming the calendar and for several books he wrote about his military campaigns.

Marcus Tullius Cicero was another famous Roman statesman. Many of Cicero's books, speeches, and letters have survived, and we know more about him than any other Roman. Cicero didn't come from a noble family, but he rose rapidly in politics because of his talent for public speaking. Cicero began his career in public office as a quaestor, a low-level official who managed the finances of the state. Because the people of Sicily found him to be honest and fair, they asked him to prosecute the corrupt governor of their island. Cicero prepared for a full trial, but after his opening speech, the governor saw that there was little chance of winning against Cicero and chose to leave the country. Cicero became known as Rome's greatest public speaker, and his successful prosecution entitled him to take the governor's seat in the Senate, giving him a freedom to speak that would not normally have been available to such a young member. Cicero gave some of his most famous speeches denouncing a plan by Catiline, an impoverished nobleman, to murder Rome's ruling class and seize power by force. Cicero was called "father of his country" for stopping the conspiracy. After the fall of the Roman Republic, the new rulers had him killed for speaking out against them. One of Cicero's most famous books is _On Duties_, which was considered the greatest work of moral philosophy through the Middle Ages and the Renaissance. When printing was invented, it was the second book to be printed after the Bible.

Vergil has been considered Rome's greatest poet ever since his own lifetime. He was born into a wealthy family, and spent his childhood on the family farm in northern Italy before being sent to large cities for school when he was 12. Vergil moved to Rome after the government seized his family's farm and he had to go to the capital to ask for it back. There, Vergil became a favourite of the emperor and other rich and important people. Vergil's most famous work is the _Aeneid_, a long poem about the founding of Rome that he worked on for the last 11 years of his life. When he was dying, he asked his friends to burn the draft, because he didn't want anyone to read his unfinished work. The emperor asked Vergil's friends to ignore his wishes and prepare the poem for publication.

Another famous Roman was Pontius Pilate. He was the governor of the Roman ludaea (Judea) province from 26 AD until 36 AD. In modern times he is best known as the man who, according to the Christian Bible, presided over the trial of Jesus Christ and ordered his crucifixion.

## What is left of them today?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-8)]

At its pinnacle, the Roman Empire covered much of Europe, northern Africa, and some of the Middle East. There are many different ethnicities in these regions. Some of them are the direct descendants of Roman citizens while other people and ethnicities emerged through immigration into these areas from other regions. In Rome, the capital city of the Roman Empire, there are currently Italian people who have a blend of Roman heritage and other people that emigrated to the area after the Roman Empire dissolved.

Many modern European languages have evolved from Latin, the language of the Roman Empire. These are called Romance languages, and they include Italian, Spanish, and French. Romance languages are also spoken in many countries in South America and Africa.

Some other languages in Europe that didn't directly descend from Latin were influenced by it. For example, languages like English, Hungarian, and Turkish are all written with versions of the Latin alphabet, even if they had other writing systems of their own. The English language has been heavily influenced by Latin ever since 1066, when England was conquered by people who spoke French. In fact, over half of English words were borrowed from French or Latin, including _joy_, _charity_, _continue_, _army_, _animal_, _actor_, _reptile_, and _library_.

## Beauty in Ancient Rome[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-9)]

The use of cosmetics in ancient Rome was not exclusively for women. Men also used them to improve their appearance, and perfumes and to wax it was considered acceptable. Excessive effort to improve the appearance, would have caused a man to fall into laugh during the time of the Republic. However, there were many who wore makeup, combed their hair and look after your body with baths and massages.

To wax was considered too effeminate, but to show all the hair with splendor was too rude for the Roman taste. Because of that, they had found a middle ground. To wax it was used resin paste or pumice. The elderly, didn't do all this ways to improve beauty because it would have been considered ridiculous, as was seen firstly as a preparation for sexual matters.

To wear trousers was a disgrace because it was something typical of the barbarians.

Men used to have short hair but women instead choose between a great variety of hairstyles. Because of Julius Caesar who came after a war and was blond and tanned, then blond became fashionable. Sometimes they used wigs which were made of hair which they cutted to the Gallic slaves.

For the Roman women was very important to had the skin white and soft with the cheeks a little bit rosy.

For the teeth they used pumice power to whiten them. They had also fake teeth.

Baths made up of milk by donkeys was a very exclusive and expensive treatment to exfoliate the skin. Some of the important persons who had it were Cleopatra or Popea Sabina.

Plastic surgery was also known and used for example in scars.

## Marriage in Ancient Rome[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-10)]

Romans didn't gave lots of importance to marriage like in present days. Most people just came and lived together without any type of ceremony.

Only one of three couples reached marriage.

The oldest way of marriage was the _usus_ which could come immediately into a divorce if the wife stayed out during three consecutive nights.

In Roman times, marriage was private. It didn't had any type of document or record which proved it. However, this sacrament had certain legal effects, since the children had to inherited the father's name and fortune.

### Women as property[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-11)]

Roman marriage could become legal in two ways:

  * the _manum conventioin_ form, in which the bride's father gave the property of her daughter to his future son-in-law.
  * or the _sine manu_, in which the girl continues to be owned by the father and the husband only receives the benefit. If she committed adultery, for example, the father could kill her even if the husband has forgiven her.

## Slaves in Rome[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-12)]

The Romans got slaves between the ones they took in battle or in conquered cities, among the children of slaves or children which were abandoned. Sometimes they bought slaves from other countries. Finally there was the case of men who were forced to be slaves as a result of debts.

The slave ( which were called _mangones_ or _mercatores venalicii_) always followed the armies or bought their human merchandise in major markets of Rome and Delos. Ordinary slaves were sold on a rotating platform (_catasta_). A table (_titulus_) was around their necks as a sign indicating its origin, age, abilities and physical or mental defects, and the certification that were free of any crime. The best were kept in separate rooms in taverns, and showed only to wealthy clients.

The children of slave parents was given the name of _vernae_, as a distinction from the free-born. All the ones belonging to one owner were called, as a whole family. The employees at residences of the city were urban families, while the ones who lived in the villa were called rustic families. However, it was common for slave to serve in both.

In ancient times their number was small, because the houses were very simple, often made by the owner. But as they grew larger and more splendid, the number of slaves increased. There was one for almost every task, which was characteristic of a large house. When the population of Italy was estimated to be about six million people, there was a slave for every three inhabitants, and population in the city of Rome was much higher.

The list of slaves tied to some Roman houses is long: tailors, barbers, cooks, bakers, also musicians, dancers of both sexes and mimes and jugglers groups to divert the host and his guests, especially when they were at the table. There were buffoons who by their faults, weaknesses or thoughts made laugh. The favorite of the ladies were the dwarfs trained to fight and dance.

Doctors and surgeons also were mostly slaves or free men, at least in Republican times, and the same happened with the private secretary of the lord of the house.

### Slaves of rich people[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-13)]

The rich Roman was always accompanied by one or more slaves (_pedisequus_) which had to carry any object his owner may need like to the baths or to a party. They also carried a torch at night. Another type of slaves were the _lectiarii_ or the carriers of chairs. In the city, it was only permitted to sit to ladies and senators.

There were also the readers, which were the slaves who read to their owners while he was a the bath or at the table. There were also the ones who wrote documents and took care of the library of the house. The _cellarius_ had the keys to the warehouse and the wine cellar.

The _procurator_ was the principal in the family of slaves and was the one who manage the money and the expenses of the family.

The slave was absolute property of the house owner and had no legal protection against him.

## Children in Ancient Rome[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-14)]

When a child was born in ancient Rome, the birth was did at home while invoking the protection of the goddess Juno Lucina ("she is the goddess who brings children into light").

The men did not attend births, not even the father of the child or the doctor who presented later. Everything was did by the midwife, except in the poorest families who couldn't afford to any midwife, since they used to be expensive. In that case, the woman had no choice but to be assisted by her own relatives.

It was the midwife who watched the baby to check its vitality and to find possible deformities. She announced the sex, but not with words but by signs, and cut the umbilical cord with a distance of four fingers from the womb. Because of this they didn't used any metal instruments. There were some alternatives like glass, ceramic or even a crust of hard bread. After that, she tied the cord with a wire of wool and cleaned and bath the newborn.

Then, ceremonies began. Immediately a sacred meal was offered to Picumno and Pilumno, sons of Jupiter presiding over marriage and guardianship of children. To try to prevent the dangers since that time, at night three men met on the threshold, one armed with an ax, the second with a club and the third with a broom. The first two struck the door and the third was sweeping the floor, which was considered that the place was clean of evil spirits.

The child was placed at the foot of the _paterfamilias_ (father or in his absence, the paternal grandfather, great grandfather or person in place). _Tollere FILIUM_, which meant to raise the newborn in his arms, meant he was recognizing as his, although it was not his natural son, and because of that he was entitled to enjoy and spend all the rights and privileges as a member of a Roman family. This ceremony took place in _dies lustricus_, eight days after birth if it was a girl and nine when it was a boy.

The newborn (_pupus_) was then purified at the family altar in a ceremony called _lustratio_. The guests had to gave him his or her first toys (_crepundia_), small glass beads that were placed over the baby's shoulder so the metallic sound amused the child as a modern rattle. Toys were shaped like flowers, swords, axes and crescents, and also offered some special identification if the child got lost.

  


## Shows and entertainment in Ancient Rome[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-15)]

Shows were one of the most important and characteristic features of Roman life, which occupied, on a schedule on the IV century, 176 days a year. Many came from the Republic, and others were initiated and added by the emperors. The extraordinary spectacles and shows were held on occasions such as anniversaries or triumphs. Along with free food distributions, were the most common ways of gain the sympathy of the people and to distract them from government issues and economic problems: _panem et circenses_, bread and circuses.

  
The organization of such events had many difficulties. One of them was to get animals for the shows and to train them. The emperors established a monopoly for hunting and for the possession of elephants and installed in Laurentum an elephant park, near Rome. In this regard there is an anecdote from Plutarch, who noted that in a show in Rome, (which had also dogs acting), an elephant missed a trick in the performance and was seen the next night rehearsing the trick on his own.

  
Emperors also like gladiators fights and maintained gladiators training schools in Rome, and later in other places like some people of the Republic did on the past.

  
The imperial ceremonies were usually accompanied by meals for everyone, that could be served in the theater or in the circus, or maybe in outside in different points of the city. In these cases the emperor attended personally. In other occasions the emperor threw a type of coins called _missilia_, which gave some advantages to the ones who could get one of those.

  
Nero gave birds, groceries, tickets for the distribution of wheat, clothes, jewelry, paintings, slaves, cattle, trained animals, and finally, boats, blocks of flats and parcels of land. Elagabalus gave gold and silver, food, costumes, camels, donkeys, cattle and deer.

  
In Emerita Augusta (now Mérida, Spain) the shows were announced on posters painted in red and black that were distributed throughout the city, and in the intervals between races, they also threw _missilia_ or _sparsiones_.

## References[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Romans&action=edit&section=T-16)]

[Classics Unveiled](http://www.classicsunveiled.com/)

# Scythians[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit&section=19)]

## What country did they live in?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Scythians&action=edit&section=T-1)]

The Scythians lived in the steppes to the north of the Black Sea, in the south of modern Russia and Ukraine. They were first described by the Greek historian Herodotus. They were cattle-breeding nomads, meaning that they did not stay in the same place for long. When cattle ate out all the grass around, they travelled to a different place, where the grass was fresh and untouched. They were also skilled horsemen and brave warriors. They were the first who used light cavalry as a main military force.

The horse was everything for a Scythe. They started riding horses when they were small children. Horses were not just transportation for Scythians; they were their protectors, providers and best friends. When a Scythian warrior died, his horse was buried with him.

Scythian women were brave warriors as well. Living in the steppes was dangerous as you have literally nowhere to hide. Scythian women had to be strong and know how to protect themselves.

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/15/Scythian_comb.jpg/220px-Scythian_comb.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Scythian comb

## What did their buildings look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Scythians&action=edit&section=T-2)]

Scythians did not have buildings. It does not make sense to build a house if you know that you are leaving soon. They lived in tents instead.

The only buildings they left behind them were kurgans – artificial hills, made of stones and earth, elevated on top of the tombs of nobilities. These tombs were filled with everything that a person could need in the afterlife: clothes, dishes, weapons, golden jewellery. They cremated their dead by covering the body in wax.

## What did they eat?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Scythians&action=edit&section=T-3)]

The favourite drink of Scythes was horse milk, often mixed with blood.

## What did they wear?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Scythians&action=edit&section=T-4)]

Both men and women wore clothes that were comfortable for riding horse: leather pants and jackets, short soft boots tied at the ankle, and felt pointed hoods. Both men and women wore their hair long and loose, and men had beards.

Scythians also liked to decorate their clothes, horses and weapons with golden jewellery. Since Scythes were very close to nature, the main motif of their jewellery was animals. They loved to show animals in motion, because these images showed what Scythes valued most: strength, speed and freedom.

## What did their writing look like?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Scythians&action=edit&section=T-5)]

Scythians did not develop any written form of their language. Though later, when they came in contact with other cultures, like the Greek colonies in the sea costs, they carved some texts in stones, but these were mostly for religious reasons and for the tombs. We don't know what their language was like and cannot read their writings. Their writing used the Greek alphabet with some modifications.

## What did they believe?[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Scythians&action=edit&section=T-6)]

The Scythians, who originated form Iran, were nomadic horsemen of the Eurasian plains who lived from around 500 to 200Bc. Over the past two centuries numerous Scythian mummies have been discovered in the Altai Mountains. The Altai Mountains are the meeting place of the four countries; the Russian Federation, China, Kazakhstan and Mongolia.

## References[[edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Scythians&action=edit&section=T-7)]

  


![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

This [Wikijunior](/wiki/Wikijunior) article is a [stub](/wiki/Help:Stub). **You can [help](/wiki/Help:Stub) Wikijunior by [expanding it](//en.wikibooks.org/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit).**
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&oldid=2320693](http://en.wikibooks.org/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&oldid=2320693)" 

[See also](/wiki/Special:Categories): 

  * [Wikijunior:Ancient Civilizations](/wiki/Category:Wikijunior:Ancient_Civilizations)
  * [Wikijunior Stubs](/wiki/Category:Wikijunior_Stubs)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3AAncient+Civilizations%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Wikijunior%3AAncient+Civilizations%2FPrint+version)

### Namespaces

  * [Wikijunior](/wiki/Wikijunior:Ancient_Civilizations/Print_version)
  * [Discussion](/w/index.php?title=Wikijunior_talk:Ancient_Civilizations/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Wikijunior:Ancient_Civilizations/Print_version)
  * [Edit](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=edit)
  * [View history](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Wikijunior:Ancient_Civilizations/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Wikijunior:Ancient_Civilizations/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&oldid=2320693)
  * [Page information](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Wikijunior%3AAncient_Civilizations%2FPrint_version&id=2320693)

### In other languages

  * [Deutsch](//de.wikibooks.org/wiki/Wikijunior_Alte_Zivilisationen/_Azteken)
  * [Français](//fr.wikibooks.org/wiki/Wikijunior:Les_civilisations_anciennes/La_Gr%C3%A8ce_antique)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Wikijunior%3AAncient+Civilizations%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Wikijunior%3AAncient+Civilizations%2FPrint+version&oldid=2320693&writer=rl)
  * [Printable version](/w/index.php?title=Wikijunior:Ancient_Civilizations/Print_version&printable=yes)

  * This page was last modified on 3 May 2012, at 08:14.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Wikijunior:Ancient_Civilizations/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
