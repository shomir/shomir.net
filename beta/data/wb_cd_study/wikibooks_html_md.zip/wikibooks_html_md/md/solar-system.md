# Solar System/Print version

From Wikibooks, open books for an open world

< [Solar System](/wiki/Solar_System)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Solar System](/wiki/Solar_System)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Solar_System/Print_version&action=purge&printable=yes) this page.

Solar System

Current, editable version of this book is available in Wikibooks, collection of open-content textbooks at URL:  


<http://en.wikibooks.org/wiki/Solar_System>

The whole text is available under GNU Free Documentation License.

* * *

# Solar System

One of the most difficult and controversial fields of astronomy is the study of the way in which the Solar System was formed, as well as its past and its future evolution.

The Solar System, or more particularly, its larger bodies - all the planets with their satellites, orbit in the Sun close to one plane known as the ecliptic which is defined as the plane in which the Earth orbits, and all move in the same direction. It is helpful to remember that an observer viewing this from a position above the plane of the ecliptic, or from the direction of the terrestrial north pole, would see the planets move around the Sun in an counter-clockwise direction, also referred to as prograde motion. All the planets and their major satellites rotate in an counter-clockwise direction on their axis, with the exception of Venus and Uranus which, because of the position of their axes shows that they experienced some cataclysmic event in their far-off past.

The distance of the planets and their satellites from the Sun increases regularly as described by the Titius-Bode law. This regularity in the movements of revolution and rotation, and the disk shape of the whole system suggested a hypothesis to Immanuel Kant as long ago as 1755, and to Pierre-Simon de Laplace in 1796: that the Sun and the planets had been formed out of a cloud of rotating gas as a result of the combined action of the force of gravity and centrifugal force. This cloud has historically always been known as the "solar nebula."

Another aspect that must be borne in mind is the distribution of density within the system: the terrestrial planets have higher densities, varying from approximately 5.5 and 3.9 times the density of water, while the giants planets have consistently lower densities, varying from 0.7 to 1.6 times the density of water.

## The place of the Solar System in the universe

The universe contains an estimated 100 billion galaxies, of which our Milky Way is one. The Milky Way itself contains an estimated 100 billion stars, of which our Sun is one. The Milky Way is a spiral galaxy with a radius of around 50,000 light-years (a light-year being the distance that light travels in one year), and the Sun and its solar system are around 30,000 light-years from the center of the galaxy.

## The Age of the Solar System

Based on the age of the oldest meteorites, it has been calculated that the Solar System was formed approximately 4.5 billion years ago. Chondrules, spheres of crystal present in chondrite-type meteorites, contain radioactive elements and the proportions of these enable us to measure the time that has elapsed from the moment in which the crystals solidified: this time lapse provides us with an indication of the age of the Solar System.

A group of research scientists at the Institute of Physical Earth Sciences in Paris has carried out very precise measurements of the relationship that exists in certain phosphates between radioactive uranium-238 and the element which derives from it, lead 206. As these crystals are rich in uranium but have virtually no lead in their natural state, the lead isotope present in the phosphates has to result from the decay of the uranium. Working from these measurements, radiometric dating means that we can calculate the age of the crystals at about 4.56 billion years.

## The Sun and the Solar System

The sun is the only star in our solar system. The sun in the centre of our solar system is a medium sized star.the temperature at its surface is about 6000 degree C.Its size is so big that it could hold within itself 13 lakh earths like ours. all the objects around the sun revolve around it because of its gravitational force.Given the close resemblance in physical structure and chemical composition of the stars and particularly of those of solar type, it is a reasonable assumption that the Sun was formed in the same way as stars of later generations, those whose formation present-day observational techniques make it possible to witness. By the description "stars of the solar type" is meant those stars which have approximately the same mass as the Sun. The main physical features of a star and its evolution depend on its mass, as do the phases of its life: formation through the contraction of a cloud of dust and gas; maturity, when the star emits constant radiation for a length of time: the smaller the star, the longer the duration; and the star's end, with variations in radius and temperature and phenomena which may be more or less violent. It would appear that stars form from clouds of gas and dust, those of recent formation still being surrounded by these. The subsequent stages of stellar evolution are sufficiently well-known to make it possible to calculate their ages to within a very close approximation.

## How a star is formed

Of all the phases of a star's life, we know least about its formation. These clouds have very low temperatures and are very opaque; as a result they radiate only in the far-infrared which the terrestrial atmosphere absorbs completely, preventing us from seeing what is happening inside the cloud. As a result of observations from space using the IRAS (Infrared Astronomical Satellite) and data from microwave radio-astronomy which can even penetrate the opaque dust clouds, it has been possible to witness the first phases of condensation of protostars from the interstellar medium. This has led to the discovery that the protostar contracts and the matter accretes onto its equatorial region, while at the same time it expels matter violently along the two opposing directions of its polar axis. In this way a disk forms on the equatorial plane. The presence of a disk of solid matter in stars that have already formed was established by the same satellite but it is also possible to discern this from Earth if the image of the star is occulted with an opaque disk, so that the weak luminosity of the disk is not overwhelmed by the predominant stellar brilliance. These observations enable us to conclude that the young Sun must also have been surrounded by a disk of gas and dust: the solar nebula hypothesized by Kant and Laplace two centuries ago.

According to stellar evolutionary theories, the Sun took approximately 50 million years to reach the phase of stability in its evolution, that is to say, to reach its present values of radius and surface temperature and to radiate, at any given moment, the same quantity of energy that it emits today. Based on these same theories, it has been estimated that these values will remain virtually unchanged for another 5 billion years.

## Composition of the stellar nebula

Dust represents only 2% of the stellar nebula mass; the remainder is made up in the following proportions: gas, of which 78% is accounted for by hydrogen atoms, 20% by helium atoms and 2% by all the other elements. The dust accounts for the largest percentage of the heavier elements which are present in planetary conformation: carbon, oxygen, iron, silicon, magnesium. The denser clouds contain between 10,000 and one million molecules per cubic centimeter and have temperatures of approximately 10 degrees Kelvin, the equivalent of 263 C (440 F) below zero. They are unstable because at such low temperatures the force of gravity is greater than the thermal pressure exerted by the gas and dust particles.

## Origins

Of the numerous theories put forward to explain how the planets were formed, only two are still considered acceptable, although both of them pose many unsolved problems: the first is the planetesimal or accumulation theory, and the second is the protoplanetary or unstable disk theory. How can the formation of a planet from a disk of dust with particles measured in micrometers be explained? It is worth looking at the two possible answers.

## Formation through accretion

This is the most widely accepted hypothesis to be formulated to date. The particles collided with each other and stuck together, leading to processes known as "coagulation" and, subsequently, "accumulation" or "accretion." In this way larger bodies grew from the granules which collected into yet bigger, solid bodies, until they formed terrestrial planets and the nuclei of the giant planets. The gases and dust remained closely intermingled for as long as the turbulent movements typical of the interstellar medium continued in the solar nebula. As the turbulence in the solar nebula diminished, the particles began a process of sedimentation, accumulating towards the central plane of the nebula, forming a very thin disk. Given the relatively high density, it is estimated that the sedimentation process was very quick, perhaps as fast as a thousand years. As the sedimentation process progressed, the mass of the thin disk became unstable and the disk broke up into a large number of solid bodies, each having a diameter of approximately 1 kilometer (.62 miles), called planetesimals. It is estimated that approximately a thousand billion of these existed, orbiting around the Sun, within the region encompassing the orbit of Mars.

## Instability of the disk

## Critical points hypothesis

## Testing the theories

## Wetherill's research

## The Dying Sun

## The Original Nebula

## Definition of a planet

The official definition of a solar "planet" (due to a 2006 resolution of the International Astronomical Union) is "a celestial body that (a) is in orbit around the Sun, (b) has sufficient mass for its self-gravity to overcome rigid body forces so that it assumes a hydrostatic equilibrium (nearly round) shape, and (c) has cleared the neighborhood around its orbit." By this definition the Sun has eight planets: in increasing order of distance from the Sun, they are Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune.

# The Sun

## Galactic orbit

The Sun orbits the center of its galaxy, the Milky Way, about once every 240 million years.

## Rotation

The Sun rotates relative to the distant stars once every 25.05 Earth-days at its equator and once every 34.3 Earth-days at the poles.

## Physical characteristics

Mass: 2,000,000,000,000,000,000,000,000,000 tons, or about 330,000 times the mass of the Earth.

Diameter: 870,000 miles [1.4 million km]

Age: 4.5 billion years

Average Distance from the Earth: 93 million miles [149.6 million km]

Luminosity: 390 quintillion megawatts

Composition: 91.2 % hydrogen, 8.7 % helium, 0.1 % other chemical elements

Surface Temperature: 10,000 degrees Farienight [5,500 degrees Celsius]

Temperature at Core: 25 million degrees Farienight[15 milllion degrees Celsius]

Core Density: 12 times that of solid lead

## A balance of opposing forces

## The solar surface

## Sunspots and faculae

Sunspots are relatively dark areas on the radiating 'surface' (photosphere) of the Sun where intense magnetic activity inhibits convection and cools the photosphere. Faculae are slightly brighter areas that form around sunspot groups as the flow of energy to the photosphere is re-established and both the normal flow and the sunspot-blocked energy elevate the radiating 'surface' temperature. Scientists have speculated on possible relationships between sunspots and solar luminosity since the historical sunspot area record began in the 17th century.[22][23] Correlations are now known to exist with decreases in luminosity caused by sunspots (generally < \- 0.3 %) and increases (generally < \+ 0.05 %) caused both by faculae that are associated with active regions as well as the magnetically active 'bright network'.[24] Modulation of the solar luminosity by magnetically active regions was confirmed by satellite measurements of total solar irradiance (TSI) by the ACRIM1 experiment on the Solar Maximum Mission (launched in 1980).[24] The modulations were later confirmed in the results of the ERB experiment launched on the Nimbus 7 satellite in 1978.[25] Sunspots in magnetically active regions are cooler and 'darker' than the average photosphere and cause temporary decreases in TSI of as much as 0.3 %. Faculae in magnetically active regions are hotter and 'brighter' than the average photosphere and cause temporary increases in TSI. The net effect during periods of enhanced solar magnetic activity is increased radiant output of the sun because faculae are larger and persist longer than sunspots.

There had been some suggestion that variations in the solar diameter might cause variations in output. But recent work, mostly from the Michelson Doppler Imager instrument on SOHO, shows these changes to be small, about 0.001% (Dziembowski et al., 2001).

Various studies have been made using sunspot number (for which records extend over hundreds of years) as a proxy for solar output (for which good records only extend for a few decades). Also, ground instruments have been calibrated by comparison with high-altitude and orbital instruments. Researchers have combined present readings and factors to adjust historical data. Other proxy data — such as the abundance of cosmogenic isotopes — have been used to infer solar magnetic activity and thus likely brightness.

Sunspot activity has been measured using the Wolf number for about 300 years. This index (also known as the Zürich number) uses both the number of sunspots and the number of groups of sunspots to compensate for variations in measurement. A 2003 study by Ilya Usoskin of the University of Oulu, Finland found that sunspots had been more frequent since the 1940s than in the previous 1150 years.[26]

## Distribution of sunspots

## Granulation

Granules on the photosphere of the Sun are caused by convection currents (thermal columns, Bénard cells) of plasma within the Sun's convective zone. The grainy appearance of the solar photosphere is produced by the tops of these convective cells and is called granulation.

The rising part of the granules is located in the center where the plasma is hotter. The outer edge of the granules is darker due to the cooler descending plasma. In addition to the visible appearance, Doppler shift measurements of the light from individual granules provides evidence for the convective nature of the granules.

A typical granule has a diameter on the order of 1,000 kilometers and lasts 8 to 20 minutes before dissipating. Below the photosphere is a layer of "supergranules" up to 30,000 kilometers in diameter with lifespans of up to 24 hours.

## Analysis of the solar spectrum

## Observation of the Solar atmosphere

## A journey through the sun

## Solar prominences

A prominence is a large, bright feature extending outward from the Sun's surface, often in a loop shape. Prominences are anchored to the Sun's surface in the photosphere, and extend outwards into the Sun's corona. While the corona consists of extremely hot ionized gases, known as plasma, which do not emit much visible light, prominences contain much cooler plasma, similar in composition to that of the chromosphere. A prominence forms over timescales of about a day, and stable prominences may persist in the corona for several months. Some prominences break apart and give rise to coronal mass ejections. Scientists are currently researching how and why prominences are formed.

A typical prominence extends over many thousands of kilometers; the largest on record was observed by the Solar and Heliospheric Observatory (SOHO) in 1997 and was some 350,000 km (216,000 miles) long [1] – roughly half the radius of the Sun or 28 times the diameter of the Earth. The mass contained within a prominence is typically on the order of 100 billion tonnes of material.

When a prominence is viewed from a different perspective so that it is against the sun instead of against space, it appears darker than the surrounding background. This formation is instead called a solar filament.[1] It is possible for a projection to be both a filament and a prominence.[2] Flocculi (plural of flocculus) is another term for these filaments, and dark flocculi typically describes the appearance of solar prominences when viewed against the solar disk in certain wavelengths.

## Solar flares

A solar flare is a large explosion in the Sun's atmosphere that can release as much as 6 × 1025 joules of energy.[1] The term is also used to refer to similar phenomena in other stars, where the term stellar flare applies.

Solar flares affect all layers of the solar atmosphere (photosphere, corona, and chromosphere), heating plasma to tens of millions of kelvins and accelerating electrons, protons, and heavier ions to near the speed of light. They produce radiation across the electromagnetic spectrum at all wavelengths, from radio waves to gamma rays. Most flares occur in active regions around sunspots, where intense magnetic fields penetrate the photosphere to link the corona to the solar interior. Flares are powered by the sudden (timescales of minutes to tens of minutes) release of magnetic energy stored in the corona. If a solar flare is exceptionally powerful, it can cause coronal mass ejections.

X-rays and UV radiation emitted by solar flares can affect Earth's ionosphere and disrupt long-range radio communications. Direct radio emission at decimetric wavelengths may disturb operation of radars and other devices operating at these frequencies.

Solar flares were first observed on the Sun by Richard Christopher Carrington and independently by Richard Hodgson in 1859 as localized visible brightenings of small areas within a sunspot group. Stellar flares have also been observed on a variety of other stars.

The frequency of occurrence of solar flares varies, from several per day when the Sun is particularly "active" to less than one each week when the Sun is "quiet". Large flares are less frequent than smaller ones. Solar activity varies with an 11-year cycle (the solar cycle). At the peak of the cycle there are typically more sunspots on the Sun, and hence more solar flares.

## The solor corona

A corona is a type of plasma "atmosphere" of the Sun or other celestial body, extending millions of kilometers into space, most easily seen during a total solar eclipse, but also observable in a coronagraph. The Latin root of the word corona means crown.

  


During a total solar eclipse, the solar corona can be seen with the naked eye. The high temperature of the corona gives it unusual spectral features, which led some to suggest, in the 19th century, that it contained a previously unknown element, "coronium". These spectral features have since been traced to highly ionized Iron (Fe-XIV) which indicates a plasma temperature in excess of 106 kelvin.[1]

Light from the corona comes from three primary sources, which are called by different names although all of them share the same volume of space. The K-corona (K for kontinuierlich, "continuous" in German) is created by sunlight scattering off free electrons; Doppler broadening of the reflected photospheric absorption lines completely obscures them, giving the spectral appearance of a continuum with no absorption lines. The F-corona (F for Fraunhofer) is created by sunlight bouncing off dust particles, and is observable because its light contains the Fraunhofer absorption lines that are seen in raw sunlight; the F-corona extends to very high elongation angles from the Sun, where it is called the Zodiacal light. The E-corona (E for emission) is due to spectral emission lines produced by ions that are present in the coronal plasma; it may be observed in broad or forbidden or hot spectral emission lines and is the main source of information about the corona's composition.[2]

## Analysis of the coronal spectrum

## Discoveries about the corona in the space age

## The solar wind

The solar wind is a stream of charged particles ejected from the upper atmosphere of the Sun. It mostly consists of electrons and protons with energies usually between 10 and 100 eV. The stream of particles varies in temperature and speed over time. These particles can escape the Sun's gravity because of their high kinetic energy and the high temperature of the corona.

The solar wind creates the heliosphere, a vast bubble in the interstellar medium that surrounds the solar system. Other phenomena include geomagnetic storms that can knock out power grids on Earth, the aurorae (northern and southern lights), and the plasma tails of comets that always point away from the Sun.

## The solar wind and Earth

## Solar observation

## Radio emissions

## Birth, life and death of the Sun

## Sunspots

Sunspots are temporary phenomena on the surface of the Sun (the photosphere) that appear visibly as dark spots compared to surrounding regions. They are caused by intense magnetic activity, which inhibits convection, forming areas of reduced surface temperature. Although they are at temperatures of roughly 3,000–4,500 K (4,940–7,640 °F), the contrast with the surrounding material at about 5,780 K leaves them clearly visible as dark spots, as the intensity of a heated black body (closely approximated by the photosphere) is a function of T (temperature) to the fourth power. If the sunspot were isolated from the surrounding photosphere it would be brighter than an electric arc. Sunspots expand and contract as they move across the surface of the sun and can be as large as 80,000 kilometers (49,710 mi) in diameter, making the larger ones visible from Earth without the aid of a telescope.[1]

Manifesting intense magnetic activity, sunspots host secondary phenomena such as coronal loops and reconnection events. Most solar flares and coronal mass ejections originate in magnetically active regions around visible sunspot groupings. Similar phenomena indirectly observed on stars are commonly called starspots and both light and dark spots have been measured.[2]

## The study of solar physics

Solar physics is the study of our Sun. It is a branch of astrophysics that specializes in exploiting and explaining the detailed measurements that are possible only for our closest star. It intersects with many disciplines of pure physics, astrophysics, and computer science, including fluid dynamics, plasma physics including magnetohydrodynamics, seismology, particle physics, atomic physics, nuclear physics, stellar evolution, space physics, spectroscopy, radiative transfer, applied optics, signal processing, computer vision, and computational physics.

Because the Sun is uniquely situated for close-range observing (other stars cannot be resolved with anything like the spatial or temporal resolution that the Sun can), there is a split between the related discipline of observational astrophysics (of distant stars) and observational solar physics. The Solar Physics Division of the American Astronomical Society boasts about 600 members (in 2008), compared to several thousand in the parent organization.

A major thrust of current (2009) effort in the field of solar physics is integrated understanding of the entire solar system including the Sun and its effects throughout interplanetary space within the heliosphere and on planets and planetary atmospheres. Studies of phenomena that affect multiple systems in the heliosphere, or that are considered to fit within a heliospheric context, are called heliophysics, a new coinage that entered usage in the early years of the current millennium.

# Mercury

Mercury is the smallest planet and the closest planet to the Sun. With a diameter of just 4879.4 kilometers (38% of that of Earth), it is smaller than the two largest planetary moons in the solar system — Ganymede of Jupiter and Titan of Saturn. Mercury has no moons. Mercury and Venus are the only two planets with zero oblateness: its polar diameter is the same as its equatorial diameter. Mercury is one of the four terrestrial planets (planets with a solid surface). If you were standing on Mercury, you would weigh just 38% of what you weigh on Earth.

## Orbit

Mercury orbits the Sun once every 87.97 Earth-days, with an orbital eccentricity of 0.21 — far greater than that of any other planet. As a result of this eccentricity, the planet moves notably faster near perihelion (closest point to the Sun) than at aphelion (farthest point from the Sun). Mercury's distance from the Sun varies during its elliptical orbit from 0.31 AU (Earth-Sun distances) at perihelion to 0.47 AU at aphelion, with an average over the entire orbit of 0.39 AU.

## Rotation

Mercury is unique in having essentially no axial tilt whatsoever — its tilt is 0.00°. It rotates prograde (in the direction of its orbit around the Sun) about its axis relative to the distant stars once every 58.65 Earth-days. Because its orbital period is not substantially greater than its rotational period (almost exactly 1.5 times as great), Mercury is the only planet on which a solar day (noon to noon) lasts for more than one local year — specifically, a solar day lasts for almost precisely two solar orbits. Furthermore, the fact that the highly elliptical orbit causes the planet to speed up and slow down over the course of the orbit, combined with the similarity in the lengths of the rotational period and orbital period, results in the Sun temporarily reversing direction across the sky when the planet is near perihelion. This occurs because near perihelion the planet is actually revolving around the Sun faster than it is rotating. Mercury is the only planet where this happens, and there are certain places on the planet (where perihelion occurs around sunrise) where the Sun rises temporarily (in the east), reverses direction and sets temporarily in the east, and then rises for good, while there are other places (where perihelion occurs around sunset) where the Sun sets temporarily (in the west), reverses direction and temporarily rises in the west, and then sets for good.

## Atmosphere

The mean surface temperature of Mercury is 442.5 K,[3] but it ranges from 100 K to 700 K[44] due to the absence of an atmosphere and a steep temperature gradient between the equator and the poles. The subsolar point reaches about 700 K during perihelion then drops to 550 K at aphelion.[45] On the dark side of the planet, temperatures average 110 K.[46] The intensity of sunlight on Mercury’s surface ranges between 4.59 and 10.61 times the solar constant (1,370 W·m−2).[47]

Despite the generally extremely high temperature of its surface, observations strongly suggest that ice exists on Mercury. The floors of deep craters at the poles are never exposed to direct sunlight, and temperatures there remain below 102 K; far lower than the global average.[48] Water ice strongly reflects radar, and observations by the 70 m Goldstone telescope and the VLA in the early 1990s revealed that there are patches of very high radar reflection near the poles.[49] While ice is not the only possible cause of these reflective regions, astronomers believe it is the most likely.[50]

The icy regions are believed to contain about 1014–1015 kg of ice,[51] and may be covered by a layer of regolith that inhibits sublimation.[52] By comparison, the Antarctic ice sheet on Earth has a mass of about 4 × 1018 kg, and Mars' south polar cap contains about 1016 kg of water.[51] The origin of the ice on Mercury is not yet known, but the two most likely sources are from outgassing of water from the planet’s interior or deposition by impacts of comets.[51]

Mercury is too small for its gravity to retain any significant atmosphere over long periods of time; however, it does have a "tenuous surface-bounded exosphere"[53] containing hydrogen, helium, oxygen, sodium, calcium, potassium and others. This exosphere is not stable—atoms are continuously lost and replenished from a variety of sources. Hydrogen and helium atoms probably come from the solar wind, diffusing into Mercury’s magnetosphere before later escaping back into space. Radioactive decay of elements within Mercury’s crust is another source of helium, as well as sodium and potassium. MESSENGER found high proportions of calcium, helium, hydroxide, magnesium, oxygen, potassium, silicon and sodium. Water vapor is present, released by a combination of processes such as: comets striking its surface, sputtering creating water out of hydrogen from the solar wind and oxygen from rock, and sublimation from reservoirs of water ice in the permanently shadowed polar craters. The detection of high amounts of water-related ions like O+, OH-, and H2O+ was a surprise.[54][55] Because of the quantities of these ions that were detected in Mercury's space environment, scientists surmise that these molecules were blasted from the surface or exosphere by the solar wind.[56][57]

Sodium, potassium and calcium were discovered in the atmosphere during the 1980–1990s, and are believed to result primarily from the vaporization of surface rock struck by micrometeorite impacts.[58] In 2008 magnesium was discovered by MESSENGER probe.[59] Studies indicate that, at times, sodium emissions are localized at points that correspond to the planet's magnetic poles. This would indicate an interaction between the magnetosphere and the planet's surface.[60]

## Internal Structure

Mercury is one of four terrestrial planets in the Solar System, and is a rocky body like the Earth. It is the smallest planet in the Solar System, with an equatorial radius of 2,439.7 km.[3] Mercury is even smaller—albeit more massive—than the largest natural satellites in the Solar System, Ganymede and Titan. Mercury consists of approximately 70% metallic and 30% silicate material.[14] Mercury's density is the second highest in the Solar System at 5.427 g/cm³, only slightly less than Earth’s density of 5.515 g/cm³.[3] If the effect of gravitational compression were to be factored out, the materials of which Mercury is made would be denser, with an uncompressed density of 5.3 g/cm³ versus Earth’s 4.4 g/cm³.[15]

Mercury’s density can be used to infer details of its inner structure. While the Earth’s high density results appreciably from gravitational compression, particularly at the core, Mercury is much smaller and its inner regions are not nearly as strongly compressed. Therefore, for it to have such a high density, its core must be large and rich in iron.[16]

  


1\. Crust—100–300 km thick 2. Mantle—600 km thick 3. Core—1,800 km radius Geologists estimate that Mercury’s core occupies about 42% of its volume; for Earth this proportion is 17%. Recent research strongly suggests Mercury has a molten core.[17][18] Surrounding the core is a 500–700 km mantle consisting of silicates.[19][20] Based on data from the Mariner 10 mission and Earth-based observation, Mercury’s crust is believed to be 100–300 km thick.[21] One distinctive feature of Mercury’s surface is the presence of numerous narrow ridges, and these can extend up to several hundred kilometers. It is believed that these were formed as Mercury’s core and mantle cooled and contracted at a time when the crust had already solidified.[22]

Mercury's core has a higher iron content than that of any other major planet in the Solar System, and several theories have been proposed to explain this. The most widely accepted theory is that Mercury originally had a metal-silicate ratio similar to common chondrite meteors, thought to be typical of the Solar System's rocky matter, and a mass approximately 2.25 times its current mass.[23] However, early in the Solar System’s history, Mercury may have been struck by a planetesimal of approximately 1/6 that mass and several hundred kilometers across.[23] The impact would have stripped away much of the original crust and mantle, leaving the core behind as a relatively major component.[23] A similar process has been proposed to explain the formation of Earth’s Moon (see giant impact theory).[23]

Alternatively, Mercury may have formed from the solar nebula before the Sun's energy output had stabilized. The planet would initially have had twice its present mass, but as the protosun contracted, temperatures near Mercury could have been between 2,500 and 3,500 K (Celsius equivalents about 273 degrees less), and possibly even as high as 10,000 K.[24] Much of Mercury’s surface rock could have been vaporized at such temperatures, forming an atmosphere of "rock vapor" which could have been carried away by the solar wind.[24]

A third hypothesis proposes that the solar nebula caused drag on the particles from which Mercury was accreting, which meant that lighter particles were lost from the accreting material.[25] Each hypothesis predicts a different surface composition, and two upcoming space missions, MESSENGER and BepiColombo, both aim to make observations to test them.[26][27]

## Surface

### The enigma of Mercury's polar regions

### The Bright Patches And Dark Areas Of Mercury

## Temperature

## Mariner 10's "Sail Power"

The first spacecraft to visit Mercury was NASA’s Mariner 10 (1974–75).[12] The spacecraft used the gravity of Venus to adjust its orbital velocity so that it could approach Mercury, making it both the first spacecraft to use this gravitational “slingshot” effect and the first NASA mission to visit multiple planets.[120] Mariner 10 provided the first close-up images of Mercury’s surface, which immediately showed its heavily cratered nature, and revealed many other types of geological features, such as the giant scarps which were later ascribed to the effect of the planet shrinking slightly as its iron core cools.[123] Unfortunately, due to the length of Mariner 10's orbital period, the same face of the planet was lit at each of Mariner 10’s close approaches. This made observation of both sides of the planet impossible,[124] and resulted in the mapping of less than 45% of the planet’s surface.[125]

On March 27, 1974, two days before its first flyby of Mercury, Mariner 10's instruments began registering large amounts of unexpected ultraviolet radiation near Mercury. This led to the tentative identification of Mercury's moon. Shortly afterward, the source of the excess UV was identified as the star 31 Crateris, and Mercury's moon passed into astronomy's history books as a footnote.

The spacecraft made three close approaches to Mercury, the closest of which took it to within 327 km of the surface.[126] At the first close approach, instruments detected a magnetic field, to the great surprise of planetary geologists—Mercury’s rotation was expected to be much too slow to generate a significant dynamo effect. The second close approach was primarily used for imaging, but at the third approach, extensive magnetic data were obtained. The data revealed that the planet’s magnetic field is much like the Earth’s, which deflects the solar wind around the planet. However, the origin of Mercury’s magnetic field is still the subject of several competing theories.[127]

On March 24, 1975, just eight days after its final close approach, Mariner 10 ran out of fuel. Since its orbit could no longer be accurately controlled, mission controllers instructed the probe to shut down.[128] Mariner 10 is thought to be still orbiting the Sun, passing close to Mercury every few months.[129]

# Venus

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/52/Venus-pacific-levelled.jpg/220px-Venus-pacific-levelled.jpg)

![](//bits.wikimedia.org/static-1.22wmf15/skins/common/images/magnify-clip.png)

Venus, apart from the Moon, the brightest object in the night sky

Venus, named after the Roman goddess of love, is often known as the Morning Star or Evening Star. This is because it reaches its brightest just before sunrise or soon after sunset. It is the second closest planet to the Sun, after Mercury. Venus has no moons. Its diameter of 12104 kilometers is 0.95 times that of Earth; Venus is the sixth largest planet and the second largest of the four terrestrial planets. If you were standing on Venus, you would weigh 90% of what you weigh on Earth.

## Orbit

Venus orbits the Sun once every 224.70 Earth-days in the most nearly circular orbit of any planet. Its average distance from the Sun is 0.723 AU (astronomical units, meaning Earth-Sun distances).

## Rotation

The rotational characteristics of Venus are interesting and unique. It rotates retrograde (that is, in the opposite direction from its revolution around the Sun), so the Sun rises in the west and sets in the east. The only other planet with retrograde rotation is Uranus, but whereas Uranus is tipped over by almost 90°, Venus has only a very slight tilt — the smallest axial tilt of any planet except Mercury. Venus rotates once relative to the stars every 243.02 Earth-days, a rotational period that is far longer than that of any other planet; its equatorial rotational velocity of 6.52 kilometers per hour is far slower than that of any other planet. Because of the combination of an orbital period of 224.70 Earth-days and a retrograde rotational period of 243.02 Earth-days, a solar day (noon to noon) on Venus lasts for about 116.8 Earth-days, and it has about 1.9 solar days per orbital period.

  


## Physical Characteristics

Venus is a rocky planet, similar in size to the Earth. We have little data on its interior but we think it is likely to be similar to Earth (that is, have a distinct core, mantle and crust). Unlike Earth there is no observable plate movement.

## Atmosphere

Venus has an atmosphere comprised of 96.5% carbon dioxide and 3.5% nitrogen. This high level of CO2 creates a "greenhouse effect". The surface atmospheric pressure is nearly 100 times greater than Earth's, equivalent to being 1 km underwater on Earth.

The amount of CO2, and the clouds of sulphur dioxide, create a huge greenhouse effect. Venus is hotter than Mercury despite receiving only one quarter of the energy from the Sun that Mercury does. Typical temperatures are 480 °C

## The Surface

Most of Venus's surface is smooth plains, with two areas of highlands. The highest mountain, Maxwell Montes, rises 11 km above the surface.

# Earth

Earth is the third planet from the Sun and has a diameter of 12,756 kilometers, making it the fifth largest planet. It is the only place in the universe where at this time life is known to exist. Earth is one of the four terrestrial planets (planets having a solid surface).

## Physical characteristics

## Shape

The diameter of the Earth at the poles is 44 kilometers less than its diameter at the equator.

# Orbit

The orbit is nearly circular, with an eccentricity of only 0.0167. Earth orbits the Sun once every 365.2422 sidereal days (rotations relative to the distant stars) at an average distance of 149,597,870 kilometers, and this distance is defined as one AU (astronomical unit). This distance is often expressed approximately in terms of miles as 93 million miles. Earth is at its closest to the Sun each year (that is, is at perihelion) at a time in the range January 2 to January 5, and is farthest from the Sun (is at aphelion) at a time in the range July 4 to July 7. Light from the Sun takes an average of 499 seconds (8 minutes 19 seconds) to get to Earth.

# Rotation

The Earth rotates prograde (in the same direction as it travels around the Sun) relative to the distant stars once every 23 hours 56 minutes 4 seconds. Since the Earth is traveling around the Sun during this time, it takes an extra 3 minutes 56 seconds to complete a rotation relative to the Sun; so the solar day is 24 hours long. (Indeed, the "hour" is defined as 1/24 of a solar day.)

Earth's axis is tilted by 23.45° relative to the perpendicular of its orbital plane. This tilt is what causes seasons to occur on Earth. (Since Earth's orbit is virtually circular, the minor variations in the distance from the Sun are not the cause of the seasons.) The longest day of the year in the northern or southern hemisphere occurs at the time in the orbit when points on the Tropic of Cancer or Tropic of Capricorn (23.45° north or south latitude) are pointed directly at the Sun at noon (so the Sun appears directly overhead). This time is known as the Summer Solstice in that hemisphere and the Winter Solstice in the opposite hemisphere. The times when the points on the equator are pointed directly at the Sun at noon are called the equinoxes, because at those times all points on Earth experience 12 hours between sunrise and sunset and 12 hours between sunset and sunrise.

# Gravitational field

# Atmosphere

## Atmospheric layers

### The stratosphere and the ionosphere

## Clouds

## Climatic variations

# The Crowded Sky Above Us

# Surface

## Continental drift

## Impact Craters

## Oceans

# The Earth's interior

## A journey through the Earth

# The magnetic field and the magnetosphere

# Moon

## Size

The Moon's diameter is 3476 kilometers, or 0.2764 times that of Earth. This makes the Moon far larger relative to its planet than any other planetary moon in the solar system. In absolute terms it is the fifth largest planetary satellite in the solar system.

## Physical characteristics

### The surface

### The maria and terrae

### The enigma of the craters

### Water in the craters

## Seismology

### Moonquakes

## Internal structure

## Magnetism

## Atmosphere

## Origin and evolution

### Large impact hypothesis

### Age of the Moon

## The Conquest Of The Moon

# Mars

Mars is the fourth planet from the Sun and the second smallest (after Mercury), with a diameter of 6794 kilometers (53% of that of Earth). Mars is one of the four terrestrial planets (planets having a solid surface). If you were standing on Mars, you would weigh just 38% of what you weigh on Earth.

## Orbit

Mars orbits the Sun once every 1.8809 Earth-years, with an orbital eccentricity of 0.093—the greatest eccentricity of any planet except Mercury. It averages 1.52 times as far from the Sun as does Earth.

## Rotation

Mars rotates about its axis prograde (in the same direction as its solar orbit) once every 24 hours 37 minutes 23 seconds. This is closer to one Earth-day than the rotational period of any other planet. Its axis is tilted by 25.19° relative to the perpendicular of its orbital plane; this is closer to Earth's axial tilt of 23.45° than that of any other planet.

## Physical characteristics

## Atmosphere

### Wind

### Climate

## Surface

### Craters

### Gullies

### Canyons

## Volcanism

## Internal structure

## Is there life on Mars?

## Satellites

### Phobos

Phobos is the larger and closer of Mars's two satellites, with a diameter of just 26 kilometers along one axis and just 18 kilometers along another axis. Of all the moons that are their planet's largest, Phobos is the smallest both in absolute terms and relative to its planet's size.

### Deimos

Deimos has a diameter of 16 kilometers along one axis and 10 kilometers along another.

## Astronomers and Mars

### In search of Martians

# Jupiter

Jupiter is the fifth planet from the Sun. It is by far the largest planet, with a diameter of 142,984 kilometers (11.2 times that of Earth). Its mass is 317 times that of Earth. The volume of all the other planets combined is only 69% of Jupiter's volume; 1266 Earths would fit inside it. Jupiter is one of the four gas giants. If Jupiter had a solid surface and you stood on it, you would weigh 2.5 times what you weigh on Earth.

## Physical characteristics

Jupiter is the giant planet of the Solar System, its diameter being eleven times greater than planet Earth's. Also, Jupiter's mass is over 300 times greater than Earth's. Jupiter rotates in less than ten hours, causing the middle of the planet to bulge out and the planet to flatten at its poles. This planet is a gas planet made up of hydrogen and helium, and what appears to be its surface is, in fact, the top of its atmosphere, which has swirls of other gases such as methane and ammonia.

Jupiter might be a giant planet, but it is not solid. Inside, it is made up mostly of liquid hydrogen. At the center lies a small core of rock and iron, which is believed to reach temperatures of at least 36,032 degrees Fahrenheit. Jupiter does not get much heat from the sun because it is so far away; this planet gives out its own heat. Heat rises from the center of Jupiter to the surface and passes into the atmosphere. The heat moves into belts of cooler gases which surround the planet.

Across Jupiter are dark bands, which change in darkness, size, and position from time to time. They are separated by lighter bands called zones. Like the wind patterns in Earth's atmosphere, the bands and zones on Jupiter are caused by heat. Also, Jupiter has a thin ring around it, like Saturn's but much smaller.

## Rotation

Jupiter rotates prograde (in the same direction as it orbits) once every 9 hours 55.5 minutes, with its axis tilted just 3.13° from the perpendicular of its orbit.

## Orbit

Jupiter orbits the Sun once every 11.86 Earth-years, at an average distance of 5.46 AU (Earth-Sun distances) and with an orbital eccentricity of .048.

## Atmosphere

### Clouds and winds

### The Great Red Spot

The Great Red Spot is a swirling storm hanging in Jupiter's atmosphere lying across two bands in the southern hemisphere. It is about 25,000 miles across- over three times the diameter of the Earth- and rotates counter clockwise with a period of around six days. The color is most likely due to phosphine brought up from lower layers, which is broken down by sunlight to create red sulfur.

Jupiter's Great Red Spot is approximately five miles higher than the clouds. The Pioneer and Voyager space probes found that the Great Red Spot is very cold which means that its top is very high in the atmosphere. At the spot's center, gas spirals up, raising pressure in a dome shape. The Great Red Spot is the largest storm in the solar system. It whips violently around Jupiter and has raged in the planet's atmosphere for more than 300 years.

## Internal structure

## The magnetic field

### Structure of the magnetosphere

## The rings of Jupiter

## Satellites

Jupiter has 63 named moons, of which 47 are less than 10 kilometers in diameter. Jupiter's sixteen largest moons divide into four groups. The four nearest Jupiter are tiny, next are the four large Galilean moons, much farther out are two clusters of four small, dark moons, and the farthest group of moons travels around Jupiter backwards compared to the other moons. The Galilean moons are named after an Italian astronomer, Galileo Galilei, who first spotted them in 1610.

### The four Galilean satellites

#### Io

The inner two of the Galilean moons are Io and Europa, both of which are roughly the size of Earth's Moon. Io is a bright, red-orange world; it is covered with volcanoes. Clouds of sulfur and sulfur dioxide spew out of vents on Io's surface because the rock below the surface is hot and molten. Plumes rise up to 200 miles high. Io is home to the most energetic volcano in the solar system, Loki. Io is heated inside by constant twisting and turning due to the gravity of Jupiter, Europa, and Ganymede. The closeness to its planet is the reason for all its activity. The pull of the planet's gravity raises tides inside the moon, which produce heat and cause eruptions.

#### Europa

Europa is one of of the two Galilean inner, large moons along with Io. Europa is covered by smooth ice. Jupiter's powerful gravity stirs Europa's icy crust and causes it to heat up; researchers believe there is liquid water below the moon's surface. This raises the question, "Could alien microbes have evolved in the waters of Europa?" Hydrothermal vents, like those on Earth's seafloor, may provide an energy source and create mineral-rich environments at the bottom of its ocean. Scientists are planning bold missions to this moon.

#### Ganymede

Ganymede is the largest planetary satellite in the solar system, and in fact its diameter is 8% larger than the planet Mercury's.

#### Callisto

Callisto is Jupiter's second largest moon and the third largest in the solar system. Its diameter is 98% of that of Mercury.

## Journey Towards The Giant Of The Solar System

# Saturn

Saturn is the sixth planet from the Sun and is the second largest planet (after Jupiter), with a diameter of 120536 kilometers (9.4 times that of Earth). Saturn is known for its spectacular rings, which can be clearly seen with a home telescope of modest size. Saturn is one of the four gas giants. Even though Saturn is much more massive than Earth, if it had a solid surface and you stood on it you would weigh only 6% more than you do on Earth. This is because you would be standing much farther from the center of the planet than you do on Earth.

## Orbit

Saturn orbits the Sun in 29.46 Earth-years, with an orbital eccentricity of 0.05 and an average distance from the Sun of 9.54 AU (Earth-Sun distances).

## Rotation

Saturn rotates prograde (in the direction of its path around the Sun) once every 10 hours 14 minutes, with an axial tilt of 25.33°.

## Physical characteristics

Saturn is the only planet that is less dense than water—in fact its density is just 0.69 that of water.

## Regions

## Temperature

## Atmosphere

### Clouds and winds

### Spots

### Vortices

## Internal structure

## Magnetic field

### Magnetosphere

## Rings

### The most beautiful planetary system

### The discovery Of Saturn's rings

### Composition of the rings

### The origin of the rings

### The shepherd satellites

### "Spokes" or radial formations

## Satellites

### Titan

Titan is the second largest moon in the solar system and has a diameter over 5% greater than that of the planet Mercury. It is the only planetary moon that has a thick atmosphere.

### Mimas

### Enceladus

### Tethys

### Dione

### Rhea

### Iapetus

### Hyperion

### Phoebe

# Uranus

Uranus (pronounced __**YOUR-uh-nus or yuh-RAIN-us**__) is the seventh of the eight planets from the Sun and is the third largest — with a diameter of 51118 kilometers, it is just 3% larger than Neptune but 4.0 times as large as Earth. Uranus is one of the four gas giants. If Uranus had a solid surface and you stood on it, you would weigh 89% as much as you do on Earth.' _[Images of uranus](http://www.google.com/images?hl=en&q=Uranus&um=1&ie=UTF-8&source=og&sa=N&tab=wi&biw=1004&bih=535&safe=active)_

## Orbit

Uranus orbits the Sun once every 84.01 Earth-years, at an average distance of 19.19 AU (Earth-Sun distances) and with an orbital eccentricity of .046.

## Rotation

The rotational period of Uranus is 17 hours 14 minutes. The tilt of its axis based on prograde motion (motion in the direction of the orbit) is 97.86° from the perpendicular of its orbital plane. In other words, it is tilted by 82.14° and rotates retrograde. Because it is essentially tipped over on its side, almost all points on Uranus experience both a directly overhead noon Sun at times during the orbit and days when the Sun never rises at other times during the orbit. On Earth the former occurs in locations that are closer to the equator than 23.45° latitude because Earth's rotational axis is tilted 23.45° from the perpendicular of its orbital plane, and the latter occurs in locations that are closer than 23.45° degrees to the north or south pole. On Uranus the overhead Sun occurs at any location within 82.14° of the equator — that is, almost everywhere on the planet; and days without sunrise occur at any location within 82.14° of the north or south pole — again almost everywhere on the planet. Uranus is the only planet in the solar system having any locations that experience both types of event.

### Titania

Titania is Uranus's largest satellite, with a diameter of 1578 kilometers.

## Rings

Distance Width Ring (km) (km)

* * *

\-------- -----

1986U2R 38000 2,500 6 41840 1-3 5 42230 2-3 4 42580 2-3 Alpha 44720 7-12 Beta 45670 7-12 Eta 47190 0-2 Gamma 47630 1-4 Delta 48290 3-9 1986U1R 50020 1-2 Epsilon 51140 20-100

(distance is from Uranus' center to the ring's inner edge)

# Neptune

Neptune is the farthest of the eight planets from the Sun and is the fourth largest, with a diameter of 49572 kilometers (3.9 times that of Earth). It is one of the four gas giants. If Neptune had a solid surface and you stood on it, you would weigh 12% more than you do on Earth.

## Orbit

Neptune orbits the sun once every 164.79 Earth-years, at an average distance of 30.06 AU (Earth-Sun distances) and with an orbital eccentricity of 0.010, making its orbit more nearly circular than that of any other planet except Venus. Neptune is so far away from the Sun that light from the Sun takes an average of 4 hours 10 minutes 25 seconds to get to Neptune.

## Rotation

Neptune rotates about its axis prograde (in the direction of its solar orbit) once every 16 hours 6.5 minutes, at an axial tilt of 28.31°.

## Physical characteristics

## Atmosphere

### Spots and clouds

#### Cloud layers

### Winds and currents

## Temperature

## Magnetic Field

## Rings, arcs and dust

## Satellites

### Triton

#### Surface

#### Surface Relief Features

#### Activity on Triton

### Nereid, Proteus, and Larissa

# Pluto

Pluto was the first trans-Neptunian object to be discovered, and is the second largest one currently known. Its diameter is 2320 km, making it just 0.67 times the size of Earth's moon. Pluto's rotational period is 6.39 Earth-days. If you stood on the surface of Pluto, you would weigh only 6% as much as you do on Earth.

## A Belated Discovery

Pluto was discovered on February 18, 1930 by Clyde Tombaugh.

## Satellites

The known satellites of Pluto are Charon, Nix, and Hydra. Charon (pronounced like either Sharon or Karen) has almost exactly half the diameter of Pluto, making the pair essentially a double dwarf planet. Charon is only 12,200 miles (19,640 km) distant from its planet.

## Orbit

Pluto's orbit is both highly eccentric (that is, far from being circular) and highly tilted relative to the orbital plane of Earth. Its eccentricity is 0.2482 (with 0.00 being circular and 1.00 being infinitely eccentric). Its orbital plane is tilted 17.15° from that of Earth. Pluto orbits the Sun in 248.54 Earth-years, at a distance from the Sun that averages 39.53 AU but ranges from 29.65 AU to 50.30 AU (where one AU—astronomical unit—is one Earth distance from the Sun). Thus Pluto spends part of its orbit closer to the Sun than the outermost planet, Neptune (which is always at least 29.80 AU from the Sun), although the two never come at all close to each other.

# Comets

## Physical characteristics

## Classification

## Life of the comet

## Coma and nucleus

## Temperature

## Structure and composition of the nucleus

## The comet's tail

## "Anti-tails"

## Tails and plasma

## The Kuiper Belt and the Oort Cloud

The Kuiper Belt is a belt of objects starting just beyond the orbit of Neptune (with some objects' orbits overlapping that of Neptune). In addition to being the home of some dwarf planets and many smaller objects, it is the source of the short-period comets. The Oort Cloud is a group of objects located much farther from the Sun than the Kuiper Belt; it is the source of the long-period comets.

## Origin and duration of the comets

## The Return Of The Comets

## Giotto

# Asteroids

## Location in the Solar System

Conventionally asteroids are divided into three groups based on location.

### Asteroids in the asteroid belt

The asteroid belt is located between Mars and Jupiter.

### Jupiter trojans

Jupiter trojans share Jupiter's orbit around the Sun, and are located about 60° ahead of or behind Jupiter in their orbits.

### Near-Earth objects

Near-Earth objects are asteroids that spend at least part of their orbit closer to the Sun than Mars. Their perihelia are less than 1.3 AU (Earth–Sun distances) from the Sun.

### Centaurs

Centaurs are objects orbiting between the orbits of Jupiter and Neptune that cross the orbit of at least one gas giant. They have unstable orbits and have characteristics of both asteroids and comets. They are sometimes classified as asteroids.

## Physical characteristics

## "Families"

## Mass, density, rotation

## Composition

## Chemical variations

## Orbital features

## Size

the sizes of asteroids may vary. some are huge and some may be as tiny as a speck of dust.

## "Life span" of the asteroids

## Ceres

Ceres is the largest asteroid, and in fact is a dwarf planet. See [Ceres](/wiki/Solar_System/Ceres) in the section on dwarf planets.

## Gaspra

## The Missing Planet

## Origin of the asteroids

## The Search For Eros

# Meteorites

## Physical characteristics

Most meteorites are very small in relative size to Earth, most of them are about the size of a giant rock or on other words: far too small to be planets, just like comets and asteroids, this bodies due to self gravitation are not round so most of them look like a potato with many holes on its surface.

## Classification

## Analysis of isotopic composition

## Chronology of the Solar System

## Organic Substances

## Meteors and meteor showers

## Meteor showers

## Sporadic Meteorites

## The Tears Of San Lorenzo

# GNU Free Documentation License

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

  


![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Solar_System/Print_version&oldid=2131077](http://en.wikibooks.org/w/index.php?title=Solar_System/Print_version&oldid=2131077)" 

[Category](/wiki/Special:Categories): 

  * [Solar System](/wiki/Category:Solar_System)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Solar+System%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Solar+System%2FPrint+version)

### Namespaces

  * [Book](/wiki/Solar_System/Print_version)
  * [Discussion](/w/index.php?title=Talk:Solar_System/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Solar_System/Print_version)
  * [Edit](/w/index.php?title=Solar_System/Print_version&action=edit)
  * [View history](/w/index.php?title=Solar_System/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Solar_System/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Solar_System/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Solar_System/Print_version&oldid=2131077)
  * [Page information](/w/index.php?title=Solar_System/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Solar_System%2FPrint_version&id=2131077)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Solar+System%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Solar+System%2FPrint+version&oldid=2131077&writer=rl)
  * [Printable version](/w/index.php?title=Solar_System/Print_version&printable=yes)

  * This page was last modified on 2 July 2011, at 04:27.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Solar_System/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
