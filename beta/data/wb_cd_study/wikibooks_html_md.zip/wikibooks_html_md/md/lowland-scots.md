# Lowland Scots/Print version

From Wikibooks, open books for an open world

< [Lowland Scots](/wiki/Lowland_Scots)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

  


# 

# Lowland Scots

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Lowland Scots](/wiki/Lowland_Scots)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Lowland_Scots/Print_version&action=purge&printable=yes) this page.

# Main Contents

  * Introduction
  * Pronounciation
  * Lessons 
    * Lesson One: The Basics
    * Lesson Two: Numbers and Greetings
    * Lesson Three: Advanced Numbers, Plural, and Interoggatives
  * Appendix 
    * External Links
  * Contributors
  * GFDL

* * *

## Introduction

## Origins

The name "Scots" signifies that the language is from Scotland, which was from the [Latin](/wiki/Latin) word _[scotti](/w/index.php?title=Scoti&action=edit&redlink=1)_. "Lowland" is just used to distinguish the language from [Scottish Gaelic](/wiki/Scottish_Gaelic), which is completely unrelated, and many people refer to the Germanic Scots language as simply "Scots". Scots is a Germanic language closely related to English and spoken by about 1.5 million people in Scotland. Scots is descended from the language of the Angles who settled in northern Britain, in an area now known as Northumbria and southern Scotland, in the 5th century AD. The language was originally known as 'Inglis' and has since been influenced by Gaelic, Norse, Latin, Dutch, Norman French, Standard French and English.

By the 14th century Scots was the main language of Scotland and was used in literature, education, government and in legal documents. This was the period when Scots literature began to take off and notable literary works include Barbour's Brus, Whyntoun's Kronykil and Blin Harry's Wallace.

After the union of the Scottish and English parliaments in 1707, English became the language of government and of polite society in Scotland, though the vast majority of people continued to speak Scots. English also began to replace Scots as the main written language in Scotland.

During the 19th and early 20th century efforts were made to eradicate Scots, mainly by punishing children for speaking it at school. In the 1980s and 1990s attitudes began to change and there is limited use of Scots in education, the media and in literature. In 1983 a Scots translation of the New Testament was published and 1985 the saw the publication of the SNDA's Concise Scots Dictionary.

Here is an example of a sample sentence in the two languages, and Dutch, another close relative;

  * English: _I eat an apple._
  * Scots: _A eat a aiple._
  * Dutch: _Ik eet een appel._

Archaic English words show its Germanic roots, which are reflected in Scots:

  * English: _hound, fowl, house, milk_
  * Scots: _hoond, foul, hoose1, milk_

It might not be as easy to learn for an English speaker as, say, Esperanto, but is probably the easiest natural language to learn for English speakers due to the fact that it is so similar to English. In fact, Scots and English share approximately 80% to 90% of the same lexicon.

1: Also "haudin".

## Can Scots people and English people understand each other?

In the majority of instances Scottish people and English people can understand each other with few problems since most Scots can just change to standard English. Many Scots only speak Lowland Scots at home with family and friends. Standard English is used for business and communicating with tourists.

## "Missing" letters

Many writers now strictly avoid apostrophes where they supposedly represent "missing" English letters. Such letters were never actually missing in Scots. For example, in the 14th century, John Barbour spelt the Scots cognate of 'taken' as _tane_. Since there has been no _k_ in the word for over 700 years, representing its omission with an apostrophe seems pointless. The current spelling is usually _taen_.

## Trivia

  * Like most languages, Scots has its own distinct regional dialects. Most Scots can tell which part of the country someone is from simply by their dialect.
  * There is another language used in Scotland. As well as English and Lowland Scots there is also Scottish Gaelic. This is a Celtic language similar to Irish. It's mainly spoken in the North West Highlands and Islands. Luckily most Gaelic speakers also know standard English so there are few communication problems.
  * You are probably more likely to hear more Scots spoken in the country rather than big cities. Urban Scots generally tend to speak a more diluted version which is more like standard English.
  * Scots is recognised by the UK government as a minority language which is distinct from English.
  * "River City" is a Scots soap opera set in a fictional Glasgow suburb. Many of the actors on the show speak a form of Urban Scots. The TV program is produced by Scottish Television.

  
_<<[Back to the main page](/wiki/Lowland_Scots)_

_On to [Pronunciation!>>](/wiki/Lowland_Scots/Pronunciation)_

  


* * *

## Pronounciation

The following is more a guide for readers. How the spellings are applied in practice is beyond the scope of such a short description. Phonetics are in IPA.

### Consonants

Most consonants are usually pronounced much as in English but:

  * **c**: /k/ or /s/, much as in English.
  * **ch**: /x/, also **gh**. Medial 'cht' may be /ð/ in Northern dialects. _loch_ (fjord or lake), _nicht_ (night), _dochter_ (daughter), _dreich_ (dreary), etc. Similar to the German "Na**ch**t".
  * **ch**: word initial or where it follows 'r' /tʃ/. _airch_ (arch), _mairch_ (march), etc.
  * **gn**: /n/. In Northern dialects /gn/ may occur.
  * **kn**: /n/. In Northern dialects /kn/ or /tn/ may occur. _knap_ (talk), _knee_, _knowe_ (knoll), etc.
  * **ng**: is always /ŋ/.
  * **nch**: usually /nʃ/. _brainch_ (branch), _dunch_ (push), etc.
  * **r**: /r/ or /ɹ/ is pronounced in all positions, i.e. rhotically.
  * **s** or **se**: /s/ or /z/.
  * **t**: may be a glottal stop between vowels or word final. In Ulster dentalised pronunciations may also occur, also for 'd'.
  * **th**: /ð/ or /θ/ much as is English. Initial 'th' in _thing_, _think_ and _thank_, etc. may be /h/.
  * **wh**: usually /ʍ/, older /xʍ/. Northern dialects also have /f/.
  * **wr**: /wr/ more often /r/ but may be /vr/ in Northern dialects. _wrack_ (wreck), _wrang_ (wrong), _write_, _wrocht_ (worked), etc.
  * **z**: /jɪ/ or /ŋ/, may occur in some words as a substitute for the older ȝ (yogh). For example: _brulzie_ (broil), _gaberlunzie_ (a beggar) and the names _Menzies_, _[inzean_, _[Culzean](/w/index.php?title=Culzean&action=edit&redlink=1)_, _MacKenzie_ etc. (As a result of the lack of education in Scots, _MacKenzie_ is now generally pronounced with a /z/ following the perceived realisation of the written form, as more controversially is sometimes _Menzies_.)

### Silent letters

  * The word final 'd' in **nd** and **ld**: but often pronounced in derived forms. Sometimes simply 'n' and 'l' or 'n'' and 'l''. _auld_ (old), _haund_ (hand), etc.
  * 't' in medial **cht**: ('ch' = /x/) and **st** and before final **en**. _fochten_ (fought), _thristle_ (thistle) also 't' in _aften_ (often), etc.
  * 't' in word final **ct** and **pt** but often pronounced in derived forms. _respect_, _accept_, etc.

### Vowels

In Scots, vowel length is usually conditioned by the Scots vowel length rule. Words which differ only slightly in pronunciation from Scottish English are generally spelled as in English. Other words may be spelt the same but differ in pronunciation, for example: _aunt_, _swap_, _want_ and _wash_ with /a/, _bull_, _full_ v. and _pull_ with /ʌ/, _bind_, _find_ and _wind_ v., etc. with /ɪ/.

  * The unstressed vowel /ə/ may be represented by any vowel letter.
  * **a**: usually /a/ but in south west and Ulster dialects often /ɑ/. Note final _a_ in _awa_ (away), _twa_ (two) and _wha_ (who) may also be /ɑ/ or /ɔ/ or /e/ depending on dialect.
  * **au**, **aw** and sometimes **a**, **a'** or **aa**: /ɑː/ or /ɔː/ in Southern, Central and Ulster dialects but /aː/ in Northern dialects. The cluster 'auld' may also be /ʌul/ in Ulster. _aw_ (all), _cauld_ (cold), _braw_ (handsome), _faw_ (fall), _snaw_ (snow), etc.
  * **ae**, **ai**, **a**(consonant)**e**: /e/. Often /ɛ/ before /r/. In Northern dialects the vowel in the cluster -'ane' is often /i/. _brae_ (slope), _saip_ (soap), _hale_ (whole), _ane_ (one), _ance_ (once), _bane_ (bone), etc.
  * **ea**, **ei**, **ie**: /iː/ or /eː/ depending on dialect. /ɛ/ may occur before /r/. Root final this may be /əi/ in Southern dialects. In the far north /əi/ may occur. _deid_ (dead), _heid_ (head), _meat_ (food), _clear_, _speir_ (enquire), _sea_, etc.
  * **ee**, **e**(Consonant)**e**: /iː/. Root final this may be /əi/ in Southern dialects. _ee_ (eye), _een_ (eyes), _steek_ (shut), _here_, etc.
  * **e**: /ɛ/. _bed_, _het_ (heated), _yett_ (gate), etc.
  * **eu**: /(j)u/ or /(j)ʌ/ depending on dialect. Sometimes erroneously 'oo', 'u(consonant)e', 'u' or 'ui'. _beuk_ (book), _ceuk_ (cook), _eneuch_ (enough), _leuk_ (look), _teuk_ (took), etc.
  * **ew**: /ju/. In Northern dialects a root final 'ew' may be /jʌu/. _few_, _new_, etc.
  * **i**: /ɪ/, but often varies between /ɪ/ and /ʌ/ especially after 'w' and 'wh'. /æ/ also occurs in Ulster before voiceless consonants. _big_, _fit_ (foot), _wid_ (wood), etc.
  * **i**(consonant)**e**, **y**(consonant)**e**, **ey**: /əi/ or /aɪ/. 'ay' is usually /e/ but /əi/ in _ay_ (yes) and _aye_ (always). In Dundee it is noticeably /ɛ/.
  * **o**: /ɔ/ but often /o/.
  * **oa**: /o/.
  * **ow**, **owe** (root final), seldom **ou**: /ʌu/. Before 'k' vocalisation to /o/ may occur especially in western and Ulster dialects. _bowk_ (retch), _bowe_ (bow), _howe_ (hollow), _knowe_ (knoll), _cowp_ (overturn), _yowe_ (ewe), etc.
  * **ou**, **oo**, **u**(consonant)**e**: /u/. Root final /ʌu/ may occur in Southern dialects. _cou_ (cow), _broun_ (brown), _hoose_ (house), _moose_ (mouse) etc.
  * **u**: /ʌ/. _but_, _cut_, etc.
  * **ui**, also **u**(consonant)**e**, **oo**: /ø/ in conservative dialects. In parts of Fife, Dundee and north Antrim /e/. In Northern dialects usually /i/ but /wi/ after /g/ and /k/ and also /u/ before /r/ in some areas eg. _fuird_ (ford). Mid Down and Donegal dialects have /i/. In central and north Down dialects /ɪ/ when short and /e/ when long. _buird_ (board), _buit_ (boot), _cuit_ (ankle), _fluir_ (floor), _guid_ (good), _schuil_ (school), etc. In central dialects _uise_ v. and _uiss_ n. (use) are [jeːz] and [jɪs].

### Suffixes

  * Negative **na**: /ɑ/, /ɪ/ or /e/ depending on dialect. Also 'nae' or 'y' eg. _canna_ (can't), _dinna_ (don't) and _maunna_ (mustn't).
  * **fu** (ful): /u/, /ɪ/, /ɑ/ or /e/ depending on dialect. Also 'fu'', 'fie', 'fy', 'fae' and 'fa'.
  * The word ending **ae**: /ɑ/, /ɪ/ or /e/ depending on dialect. Also 'a', 'ow' or 'y', for example: _arrae_ (arrow), _barrae_ (barrow) and _windae_ (window), etc.

_<<[Back to Introduction](/wiki/Lowland_Scots/Introduction)_

_[On to Lesson One!>>](/wiki/Lowland_Scots/Lesson01)_

* * *

## Lessons

### Lesson One

**Lowland Scots Lesson One: The Basics**

![Flag of Scotland.svg](//upload.wikimedia.org/wikipedia/commons/thumb/1/10/Flag_of_Scotland.svg/100px-Flag_of_Scotland.svg.png)

## Articles

English, has the words "**the**", "**a**" and "**an**". These words are called "articles" and are used to refer to concepts which are specific (the, which is _definite_) or general (a and an, which are _indefinite_).

  * _A man. The man. A group of men. The men._

Some languages will have one but not the other. Some languages have niether. Scots has both, and the rules are slightly simpler than in English.

### The

The Scottish word for "**the**" is also **the** (pronounced more like "theh" instead of how we pronounce it "thuh") and it almost exactly like in English. The only difference is that it is also used before the names of seasons, days of the week, many nouns, diseases, trades, occupations, sciences and academic subjects. It is also often used in place of the indefinite article and instead of a possessive pronoun: the hairst (autumn), the Wadensday (Wednesday), awa tae the kirk (off to church), the nou (at the moment), the day (today), the haingles (influenza), the Laitin (Latin), The deuk ett the bit breid (The duck ate a piece of bread), the wife (my wife) etc.

  * Scots: _The hoond. The tree. The waw._
  * English: _The dog. The tree. The wall._

### A

The Lowlands word for "**a**" and "**an**" is simply "**a**".

  * Scots: _The hoose. A aiple. The loanin an a tree._
  * English: _The house. An apple. The field and a tree._

## Am, Is, are, was, were

"Am", "is", and "are" are the same in Scots, but "was" and "were" are simply "wis", though "were" is sometimes "war" in the language.

  * Scots: _A am, she is, we are, he wis, thay wis/war._
  * English: _I am, she is, we are, he was, they were._

## Pronouns

Words like "he" and "she" are pronouns. The Scottish system has a few differences over English, as you will see below:

  * **A**1 _I_
  * **me**2 _me_
  * **ma**3 _my_
  * **ye**4 _singular "you"_
  * **he** _he_
  * **his** _his_
  * **she** _she_
  * **her** _her_
  * **him** _him_
  * **it**5 _it_
  * **we**6 _we_
  * **us**7 _us, me_
  * **thay** _they_
  * **thaim** _them_
  * **thair** _their_
  * **yese**8 _plural "you"_
  * **yer**9 _your_

The most recognizable difference is the distinction between singular and plural "you". English used to have the same distinction; it used "thou" for singular "you" and "ye" for plural "you". However, "thou" fell into disuse, and "ye" took its place and became modern "you". "Yese/Youse" would be used in a sentence such as, "A lue10 yese/youse", which translates to, "I love you all". "Ye" would be used in all other cases, like "Wha are ye?", meaning "Who are you?" Scots:

  * _Hou11 are ye?_
  * _Hou are yese?_

English:

  * _How are you?_ (Friendly)
  * _How are you?_ (More than one person) or _How are you all?_ or _How are all of you?_

  


  * 1: Also "I" when used to emphasize.
  * 2: Also "us" or "hus".
  * 3: Also "ma certes".
  * 4: Also "you".
  * 5: Also "hit".
  * 6: Also "oo".
  * 7: Also "hus", "us".
  * 8: Also "youse".
  * 9: Also "your".
  * 10: Also "amour" or "love".
  * 11: Also "whitwey".

## Prepositions

Prepositions, like the name suggests, describe positions and the relationships between things. Some language courses choose to describe these in more advanced lessons, but it's difficult to form sentences without them. Here we will introduce a few basic prepositions, but we will discuss them in greater depth in a future lesson.

  * **in** _in_
  * **on**1 _on_ (as in _I put my books **on** my desk_)
  * **unner** _under_ (very similar to the English word)
  * **ahint**2 _behind_
  * **wi** _with_
  * **neist tae**3 _next to_

The number of sentences which you can now build with a minimal vocabulary has increased dramatically.

  * Scots: _We are in the hoose._
  * English: _We are in the house._

  


  * 1: Also "ontae".
  * 2: Also "aback" or "hinder".
  * 3: Also "til".

## Vocabulary list

This is a vocabulary list. Some of these words have appeared previously in this lesson and some are new.

  * **aiple** _apple_
  * **tree** _tree_
  * **door** _door_
  * **eat** _eat, to eat_
  * **hair** _hair, a small portion_
  * **dug**1 _dog_
  * **cat**2 _cat_
  * **meat**3 _food_
  * **lassie**4 _girl_
  * **moose** _mouse_
  * **waw** _wall_
  * **reid** _red_
  * **laddie**5 _boy_
  * **son** _son_
  * **sit** _sit, to sit_
  * **sleep** _sleep, to sleep_
  * **the toun** _city_
  * **chyre** _chair_
  * **black** _black_
  * **table**6 _table_
  * **hackit**7 _ugly_
  * **loanin**8 _field, paddock, lane_
  * **bide** _to reside, live at, lodge, stay_

  


  * 1: Also "duggie", "hoond", or "tike".
  * 2: Also "baudrons", "cheetie", "pous", or "pousie".
  * 3: Also "farin", "leevin", "mealtith", or "fuid".
  * 4: Also "lassie" or "quean".
  * 5: Also "callant", "lad", "boy", or "loun".
  * 6: Also "buird".
  * 7: Also "grugous", "ill-farrant", "uggsome", or "ougly".
  * 8: Also "lea".

## Practice

Translate these sentences into English.

  * _Ye are John._
  * _The hoose is reid._
  * _She bides in the toun._
  * _The lassie wi black hair._
  * _The dug sleeps unner a tree._
  * _The cat eats the meat._
  * _A sit on the chyre neist tae the table._
  * _Yese are ahint the door in the waw._

Translate these sentences into Lowland Scots.

  * _I am Jack._
  * _It is under the table._
  * _The door is in the red wall._
  * _The mouse lives under the house._
  * _A dog is sleeping behind the chair._
  * _The tree is in the field._
  * _The boy with food._
  * _You eat an apple._

## Answers

Answers to the above excercises.

  * _You are John._
  * _The house is red._
  * _She lives in the city._
  * _The girl with black hair._
  * _The dog sleeps/is sleeping under a tree._
  * _The cat eats/is eating the food._
  * _I sit/am sitting on the chair next to the table._
  * _You are behind the door in the wall._
  * _A am Jack._
  * _It is unner the table._
  * _The door is in the reid waw._
  * _The moose bides unner the hoose._
  * _A dug sleeps ahint the chyre._
  * _The tree is in the loanin._
  * _The laddie wi the meat._
  * _Ye eat an aiple._

## End of lesson one

That concludes the very first Lowland Scots lesson, and by now you should already be able to form simple sentences. Use the vocabulary you have learned to form your own sentences!

_<<[Back to Pronunciation](/wiki/Lowland_Scots/Pronunciation)_

_[On to Lesson Two!>>](/wiki/Lowland_Scots/Lesson02)_

* * *

### Lesson Two

**Lowland Scots Lesson Two: Numbers and Greetings**

## Number Basics

The number system in Scots is very similar to English, which is obvious because Lowlands is English's closest relative. The numbers are as follows;

  * '_wan"_1 _one_
  * **twa** _two_
  * **three** _three_
  * **fower** _four_
  * **five** _five_
  * **sax** _six_
  * **seiven** _seven_
  * **aicht** _eight_
  * **nine** _nine_
  * **ten** _ten_
  * **eleiven** _eleven_
  * **twal** _twelve_
  * **thirteen**2 _thirteen_
  * **fowerteen** _fourteen_
  * **fifteen** _fifteen_
  * **saxteen** _sixteen_
  * **seiventeen** _seventeen_
  * **aichteen** _eighteen_
  * **nineteen** _nineteen_
  * **twinty** _twenty_
  * 1: Also pronounced "yin" "een" or "wan" and "ae" also pronounced "yae".
  * 2: Also "thritteen" or "deil's dizzen".

## Greetings

Some common phrases include as follows:

  * Scots: _walcome. hous it gaun?1 a'am daein fine.2,3 thank ye. thanks. hou much. cheerio._
  * English: _welcome. how are you? I am well. thank you. Thanks. how much? good-bye._

  


  * 1: It literally says "how is it going?".
  * 2: It literally says "I'm doing fine".
  * 3: "A am" would coloquially be contracted into the word "A'm".

### Dialogue

Scots:

  * John: Whit like?1
  * Mary: A'm daein fine. An yersel?2
  * John: A'm daein fine an aw. Thanks for askin! A'm awa the nou. See ye efter.3
  * Mary: See ye efter.

English:

  * John: How are you?
  * Mary: I'm well. You?
  * John: I'm well, too. Thanks for asking! I got to go now. Bye.
  * Mary: Bye.

Literal Translations:  
1 _"What like?"_ \- similar in meaning to: "How's things?"  
2 _"I'm doing fine. And yourself?"_  
3 _"I'm doing fine and all. Thanks for asking. I'm away the now. See you after"_

## End of lesson two

Now that lesson two is complete, you'd should also be able to have a simple conversation with anybody that speaks Scots. You can even count up to "twinty"! In the next lesson, we will discuss more advanced number material.

_<<[Back to Lesson One](/wiki/Lowland_Scots/Lesson01)_

_[On to Lesson Three!>>](/wiki/Lowland_Scots/Lesson03)_

* * *

### Lesson Three

**Lesson Three: Advanced numbers, Plurals, and Interrogatives**

## Numbers

Here is a list of more advanced numbers; **thirty**1 _thirty_ **fowerty** _forty_ **fifty** _fifty_ **saxty** _sixty_ **seiventy** _seventy_ **aichty** _eighty_ **hunder** _hundred_ **thoosand** _thousand_

### Ordinal, Cardinal

Numbers like "ane", "twa", and "three" are cardinal numbers, and that means that they are a generalized kind of number used to denote the size of a set. That's what you've learned so far. Ordinal numbers, however are another type of number used to accommodate infinite sequences and to classify sets with certain kinds of order structures on them. In English, Cardinal numbers would be "first", "second", and "third", though most numbers have "-th" added to them. In Scots, you generally add a "-t" to the end of the word, like so.

  * Scots: seicont, fowert, fift, saxt, seivent.
  * English: second, fourth, fifth, sixth, seventh.

Notice how "first" and "third" weren't included in that list. That's because they are irregular like in English. In Scots, "first" is "first", or sometimes "foremaist", and "third" is "thrid" or "third".

  


  * 1: Also "thritty".

## Plural form

Plural is when the word becomes more than one. In English, the plural form is usually "-(e)s". In Lowland Scots, nouns usually form their plural by adding "-(e)s" to the end of a word, but some irregular plurals occur. For example; "ee"/"een" ("eye"/"eyes"), "cauf"/"caur" ("calf"/"calves"), "horse"/"horse" ("horse"/"horses"), "cou"/"kye" ("cow"/"cows"), "shae"/"shuin" ("shoe"/"shoes"). Nouns of measure and quantity unchanged in the plural. Words include, "fower fit" ("four feet"), "twa mile" ("two miles"), "five pund" ("five pounds"), "three hunderwecht" ("three hundredweight"). Regular plurals include "laifs" ("loaves"), "leafs" ("leaves"), "shelfs" ("shelves") and "wifes" ("wives"), etc.

## Interrogatives

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png)

**A reader requests expansion of this page to include more material.**  
You can help by [adding new material](//en.wikibooks.org/w/index.php?title=Lowland_Scots/Print_version&action=edit) (_[learn how](/wiki/Using_Wikibooks)_) or ask for assistance in the [reading room](/wiki/Wikibooks:PROJECTS).

_<<[Back to Lesson Two](/wiki/Lowland_Scots/Lesson02)_

_[On to Lesson Four!>>](/w/index.php?title=Lowland_Scots/Lesson04&action=edit&redlink=1)_

* * *

# External Links

## Links

![Wikipedia-logo.png](//upload.wikimedia.org/wikipedia/commons/thumb/6/63/Wikipedia-logo.png/40px-Wikipedia-logo.png)

[Wikipedia](//en.wikipedia.org/wiki/) has related information at _**[Scots language**_](//en.wikipedia.org/wiki/Scots_language)

Check out these other awesome links.

  * <http://www.cor.europa.eu/document/Highlight/Scottish%20phrase%20booklet-FIN.pdf>
  * <http://www.scots-online.org/dictionary/engscots.asp>

* * *

  


# Contributors

The Lowland Scots Language textbook was first started on [July 22](//en.wikipedia.org/wiki/July_22), [2007](//en.wikipedia.org/wiki/2007). Add yourself to the list below if you feel you've made a significant contribution to this textbook.

  * [Icelandic Hurricane](/wiki/User:Icelandic_Hurricane) ([discuss](/wiki/User_talk:Icelandic_Hurricane) **·** [email](/wiki/Special:EmailUser/Icelandic_Hurricane) **·** [contribs](/wiki/Special:Contributions/Icelandic_Hurricane) **·** [logs](//en.wikibooks.org/w/index.php?title=Special:Log&user=Icelandic+Hurricane) **·** [count](http://toolserver.org/~tparis/pcount/index.php?name=Icelandic+Hurricane&lang=en&wiki=wikibooks))

  


* * *

# GNU FREE DOCUMENTATION LICENSE

![Caution](//upload.wikimedia.org/wikipedia/commons/thumb/7/74/Ambox_warning_yellow.svg/40px-Ambox_warning_yellow.svg.png)

As of July 15, 2009 Wikibooks has moved to a dual-licensing system that supersedes the previous GFDL only licensing. In short, this means that text licensed under the GFDL only can no longer be imported to Wikibooks, retroactive to 1 November 2008. Additionally, Wikibooks text might or might not now be exportable under the GFDL depending on whether or not any content was added and not removed since July 15.

Version 1.3, 3 November 2008 Copyright (C) 2000, 2001, 2002, 2007, 2008 Free Software Foundation, Inc. <<http://fsf.org/>>

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

## 0\. PREAMBLE

The purpose of this License is to make a manual, textbook, or other functional and useful document "free" in the sense of freedom: to assure everyone the effective freedom to copy and redistribute it, with or without modifying it, either commercially or noncommercially. Secondarily, this License preserves for the author and publisher a way to get credit for their work, while not being considered responsible for modifications made by others.

This License is a kind of "copyleft", which means that derivative works of the document must themselves be free in the same sense. It complements the GNU General Public License, which is a copyleft license designed for free software.

We have designed this License in order to use it for manuals for free software, because free software needs free documentation: a free program should come with manuals providing the same freedoms that the software does. But this License is not limited to software manuals; it can be used for any textual work, regardless of subject matter or whether it is published as a printed book. We recommend this License principally for works whose purpose is instruction or reference.

## 1\. APPLICABILITY AND DEFINITIONS

This License applies to any manual or other work, in any medium, that contains a notice placed by the copyright holder saying it can be distributed under the terms of this License. Such a notice grants a world-wide, royalty-free license, unlimited in duration, to use that work under the conditions stated herein. The "Document", below, refers to any such manual or work. Any member of the public is a licensee, and is addressed as "you". You accept the license if you copy, modify or distribute the work in a way requiring permission under copyright law.

A "Modified Version" of the Document means any work containing the Document or a portion of it, either copied verbatim, or with modifications and/or translated into another language.

A "Secondary Section" is a named appendix or a front-matter section of the Document that deals exclusively with the relationship of the publishers or authors of the Document to the Document's overall subject (or to related matters) and contains nothing that could fall directly within that overall subject. (Thus, if the Document is in part a textbook of mathematics, a Secondary Section may not explain any mathematics.) The relationship could be a matter of historical connection with the subject or with related matters, or of legal, commercial, philosophical, ethical or political position regarding them.

The "Invariant Sections" are certain Secondary Sections whose titles are designated, as being those of Invariant Sections, in the notice that says that the Document is released under this License. If a section does not fit the above definition of Secondary then it is not allowed to be designated as Invariant. The Document may contain zero Invariant Sections. If the Document does not identify any Invariant Sections then there are none.

The "Cover Texts" are certain short passages of text that are listed, as Front-Cover Texts or Back-Cover Texts, in the notice that says that the Document is released under this License. A Front-Cover Text may be at most 5 words, and a Back-Cover Text may be at most 25 words.

A "Transparent" copy of the Document means a machine-readable copy, represented in a format whose specification is available to the general public, that is suitable for revising the document straightforwardly with generic text editors or (for images composed of pixels) generic paint programs or (for drawings) some widely available drawing editor, and that is suitable for input to text formatters or for automatic translation to a variety of formats suitable for input to text formatters. A copy made in an otherwise Transparent file format whose markup, or absence of markup, has been arranged to thwart or discourage subsequent modification by readers is not Transparent. An image format is not Transparent if used for any substantial amount of text. A copy that is not "Transparent" is called "Opaque".

Examples of suitable formats for Transparent copies include plain ASCII without markup, Texinfo input format, LaTeX input format, SGML or XML using a publicly available DTD, and standard-conforming simple HTML, PostScript or PDF designed for human modification. Examples of transparent image formats include PNG, XCF and JPG. Opaque formats include proprietary formats that can be read and edited only by proprietary word processors, SGML or XML for which the DTD and/or processing tools are not generally available, and the machine-generated HTML, PostScript or PDF produced by some word processors for output purposes only.

The "Title Page" means, for a printed book, the title page itself, plus such following pages as are needed to hold, legibly, the material this License requires to appear in the title page. For works in formats which do not have any title page as such, "Title Page" means the text near the most prominent appearance of the work's title, preceding the beginning of the body of the text.

The "publisher" means any person or entity that distributes copies of the Document to the public.

A section "Entitled XYZ" means a named subunit of the Document whose title either is precisely XYZ or contains XYZ in parentheses following text that translates XYZ in another language. (Here XYZ stands for a specific section name mentioned below, such as "Acknowledgements", "Dedications", "Endorsements", or "History".) To "Preserve the Title" of such a section when you modify the Document means that it remains a section "Entitled XYZ" according to this definition.

The Document may include Warranty Disclaimers next to the notice which states that this License applies to the Document. These Warranty Disclaimers are considered to be included by reference in this License, but only as regards disclaiming warranties: any other implication that these Warranty Disclaimers may have is void and has no effect on the meaning of this License.

## 2\. VERBATIM COPYING

You may copy and distribute the Document in any medium, either commercially or noncommercially, provided that this License, the copyright notices, and the license notice saying this License applies to the Document are reproduced in all copies, and that you add no other conditions whatsoever to those of this License. You may not use technical measures to obstruct or control the reading or further copying of the copies you make or distribute. However, you may accept compensation in exchange for copies. If you distribute a large enough number of copies you must also follow the conditions in section 3.

You may also lend copies, under the same conditions stated above, and you may publicly display copies.

## 3\. COPYING IN QUANTITY

If you publish printed copies (or copies in media that commonly have printed covers) of the Document, numbering more than 100, and the Document's license notice requires Cover Texts, you must enclose the copies in covers that carry, clearly and legibly, all these Cover Texts: Front-Cover Texts on the front cover, and Back-Cover Texts on the back cover. Both covers must also clearly and legibly identify you as the publisher of these copies. The front cover must present the full title with all words of the title equally prominent and visible. You may add other material on the covers in addition. Copying with changes limited to the covers, as long as they preserve the title of the Document and satisfy these conditions, can be treated as verbatim copying in other respects.

If the required texts for either cover are too voluminous to fit legibly, you should put the first ones listed (as many as fit reasonably) on the actual cover, and continue the rest onto adjacent pages.

If you publish or distribute Opaque copies of the Document numbering more than 100, you must either include a machine-readable Transparent copy along with each Opaque copy, or state in or with each Opaque copy a computer-network location from which the general network-using public has access to download using public-standard network protocols a complete Transparent copy of the Document, free of added material. If you use the latter option, you must take reasonably prudent steps, when you begin distribution of Opaque copies in quantity, to ensure that this Transparent copy will remain thus accessible at the stated location until at least one year after the last time you distribute an Opaque copy (directly or through your agents or retailers) of that edition to the public.

It is requested, but not required, that you contact the authors of the Document well before redistributing any large number of copies, to give them a chance to provide you with an updated version of the Document.

## 4\. MODIFICATIONS

You may copy and distribute a Modified Version of the Document under the conditions of sections 2 and 3 above, provided that you release the Modified Version under precisely this License, with the Modified Version filling the role of the Document, thus licensing distribution and modification of the Modified Version to whoever possesses a copy of it. In addition, you must do these things in the Modified Version:

  1. Use in the Title Page (and on the covers, if any) a title distinct from that of the Document, and from those of previous versions (which should, if there were any, be listed in the History section of the Document). You may use the same title as a previous version if the original publisher of that version gives permission.
  2. List on the Title Page, as authors, one or more persons or entities responsible for authorship of the modifications in the Modified Version, together with at least five of the principal authors of the Document (all of its principal authors, if it has fewer than five), unless they release you from this requirement.
  3. State on the Title page the name of the publisher of the Modified Version, as the publisher.
  4. Preserve all the copyright notices of the Document.
  5. Add an appropriate copyright notice for your modifications adjacent to the other copyright notices.
  6. Include, immediately after the copyright notices, a license notice giving the public permission to use the Modified Version under the terms of this License, in the form shown in the Addendum below.
  7. Preserve in that license notice the full lists of Invariant Sections and required Cover Texts given in the Document's license notice.
  8. Include an unaltered copy of this License.
  9. Preserve the section Entitled "History", Preserve its Title, and add to it an item stating at least the title, year, new authors, and publisher of the Modified Version as given on the Title Page. If there is no section Entitled "History" in the Document, create one stating the title, year, authors, and publisher of the Document as given on its Title Page, then add an item describing the Modified Version as stated in the previous sentence.
  10. Preserve the network location, if any, given in the Document for public access to a Transparent copy of the Document, and likewise the network locations given in the Document for previous versions it was based on. These may be placed in the "History" section. You may omit a network location for a work that was published at least four years before the Document itself, or if the original publisher of the version it refers to gives permission.
  11. For any section Entitled "Acknowledgements" or "Dedications", Preserve the Title of the section, and preserve in the section all the substance and tone of each of the contributor acknowledgements and/or dedications given therein.
  12. Preserve all the Invariant Sections of the Document, unaltered in their text and in their titles. Section numbers or the equivalent are not considered part of the section titles.
  13. Delete any section Entitled "Endorsements". Such a section may not be included in the Modified version.
  14. Do not retitle any existing section to be Entitled "Endorsements" or to conflict in title with any Invariant Section.
  15. Preserve any Warranty Disclaimers.

If the Modified Version includes new front-matter sections or appendices that qualify as Secondary Sections and contain no material copied from the Document, you may at your option designate some or all of these sections as invariant. To do this, add their titles to the list of Invariant Sections in the Modified Version's license notice. These titles must be distinct from any other section titles.

You may add a section Entitled "Endorsements", provided it contains nothing but endorsements of your Modified Version by various parties—for example, statements of peer review or that the text has been approved by an organization as the authoritative definition of a standard.

You may add a passage of up to five words as a Front-Cover Text, and a passage of up to 25 words as a Back-Cover Text, to the end of the list of Cover Texts in the Modified Version. Only one passage of Front-Cover Text and one of Back-Cover Text may be added by (or through arrangements made by) any one entity. If the Document already includes a cover text for the same cover, previously added by you or by arrangement made by the same entity you are acting on behalf of, you may not add another; but you may replace the old one, on explicit permission from the previous publisher that added the old one.

The author(s) and publisher(s) of the Document do not by this License give permission to use their names for publicity for or to assert or imply endorsement of any Modified Version.

## 5\. COMBINING DOCUMENTS

You may combine the Document with other documents released under this License, under the terms defined in section 4 above for modified versions, provided that you include in the combination all of the Invariant Sections of all of the original documents, unmodified, and list them all as Invariant Sections of your combined work in its license notice, and that you preserve all their Warranty Disclaimers.

The combined work need only contain one copy of this License, and multiple identical Invariant Sections may be replaced with a single copy. If there are multiple Invariant Sections with the same name but different contents, make the title of each such section unique by adding at the end of it, in parentheses, the name of the original author or publisher of that section if known, or else a unique number. Make the same adjustment to the section titles in the list of Invariant Sections in the license notice of the combined work.

In the combination, you must combine any sections Entitled "History" in the various original documents, forming one section Entitled "History"; likewise combine any sections Entitled "Acknowledgements", and any sections Entitled "Dedications". You must delete all sections Entitled "Endorsements".

## 6\. COLLECTIONS OF DOCUMENTS

You may make a collection consisting of the Document and other documents released under this License, and replace the individual copies of this License in the various documents with a single copy that is included in the collection, provided that you follow the rules of this License for verbatim copying of each of the documents in all other respects.

You may extract a single document from such a collection, and distribute it individually under this License, provided you insert a copy of this License into the extracted document, and follow this License in all other respects regarding verbatim copying of that document.

## 7\. AGGREGATION WITH INDEPENDENT WORKS

A compilation of the Document or its derivatives with other separate and independent documents or works, in or on a volume of a storage or distribution medium, is called an "aggregate" if the copyright resulting from the compilation is not used to limit the legal rights of the compilation's users beyond what the individual works permit. When the Document is included in an aggregate, this License does not apply to the other works in the aggregate which are not themselves derivative works of the Document.

If the Cover Text requirement of section 3 is applicable to these copies of the Document, then if the Document is less than one half of the entire aggregate, the Document's Cover Texts may be placed on covers that bracket the Document within the aggregate, or the electronic equivalent of covers if the Document is in electronic form. Otherwise they must appear on printed covers that bracket the whole aggregate.

## 8\. TRANSLATION

Translation is considered a kind of modification, so you may distribute translations of the Document under the terms of section 4. Replacing Invariant Sections with translations requires special permission from their copyright holders, but you may include translations of some or all Invariant Sections in addition to the original versions of these Invariant Sections. You may include a translation of this License, and all the license notices in the Document, and any Warranty Disclaimers, provided that you also include the original English version of this License and the original versions of those notices and disclaimers. In case of a disagreement between the translation and the original version of this License or a notice or disclaimer, the original version will prevail.

If a section in the Document is Entitled "Acknowledgements", "Dedications", or "History", the requirement (section 4) to Preserve its Title (section 1) will typically require changing the actual title.

## 9\. TERMINATION

You may not copy, modify, sublicense, or distribute the Document except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, or distribute it is void, and will automatically terminate your rights under this License.

However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation.

Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice.

Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, receipt of a copy of some or all of the same material does not give you any rights to use it.

## 10\. FUTURE REVISIONS OF THIS LICENSE

The Free Software Foundation may publish new, revised versions of the GNU Free Documentation License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. See <http://www.gnu.org/copyleft/>.

Each version of the License is given a distinguishing version number. If the Document specifies that a particular numbered version of this License "or any later version" applies to it, you have the option of following the terms and conditions either of that specified version or of any later version that has been published (not as a draft) by the Free Software Foundation. If the Document does not specify a version number of this License, you may choose any version ever published (not as a draft) by the Free Software Foundation. If the Document specifies that a proxy can decide which future versions of this License can be used, that proxy's public statement of acceptance of a version permanently authorizes you to choose that version for the Document.

## 11\. RELICENSING

"Massive Multiauthor Collaboration Site" (or "MMC Site") means any World Wide Web server that publishes copyrightable works and also provides prominent facilities for anybody to edit those works. A public wiki that anybody can edit is an example of such a server. A "Massive Multiauthor Collaboration" (or "MMC") contained in the site means any set of copyrightable works thus published on the MMC site.

"CC-BY-SA" means the Creative Commons Attribution-Share Alike 3.0 license published by Creative Commons Corporation, a not-for-profit corporation with a principal place of business in San Francisco, California, as well as future copyleft versions of that license published by that same organization.

"Incorporate" means to publish or republish a Document, in whole or in part, as part of another Document.

An MMC is "eligible for relicensing" if it is licensed under this License, and if all works that were first published under this License somewhere other than this MMC, and subsequently incorporated in whole or in part into the MMC, (1) had no cover texts or invariant sections, and (2) were thus incorporated prior to November 1, 2008.

The operator of an MMC Site may republish an MMC contained in the site under CC-BY-SA on the same site at any time before August 1, 2009, provided the MMC is eligible for relicensing.

# How to use this License for your documents

To use this License in a document you have written, include a copy of the License in the document and put the following copyright and license notices just after the title page:

    Copyright (c) YEAR YOUR NAME.
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3
    or any later version published by the Free Software Foundation;
    with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.
    A copy of the license is included in the section entitled "GNU
    Free Documentation License".

If you have Invariant Sections, Front-Cover Texts and Back-Cover Texts, replace the "with...Texts." line with this:

    with the Invariant Sections being LIST THEIR TITLES, with the
    Front-Cover Texts being LIST, and with the Back-Cover Texts being LIST.

If you have Invariant Sections without Cover Texts, or some other combination of the three, merge those two alternatives to suit the situation.

If your document contains nontrivial examples of program code, we recommend releasing these examples in parallel under your choice of free software license, such as the GNU General Public License, to permit their use in free software.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Lowland_Scots/Print_version&oldid=930167](http://en.wikibooks.org/w/index.php?title=Lowland_Scots/Print_version&oldid=930167)" 

[Category](/wiki/Special:Categories): 

  * [Lowland Scots](/wiki/Category:Lowland_Scots)

Hidden category: 

  * [Requests for expansion](/wiki/Category:Requests_for_expansion)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Lowland+Scots%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Lowland+Scots%2FPrint+version)

### Namespaces

  * [Book](/wiki/Lowland_Scots/Print_version)
  * [Discussion](/wiki/Talk:Lowland_Scots/Print_version)

### 

### Variants

### Views

  * [Read](/wiki/Lowland_Scots/Print_version)
  * [Edit](/w/index.php?title=Lowland_Scots/Print_version&action=edit)
  * [View history](/w/index.php?title=Lowland_Scots/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Lowland_Scots/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Lowland_Scots/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Lowland_Scots/Print_version&oldid=930167)
  * [Page information](/w/index.php?title=Lowland_Scots/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Lowland_Scots%2FPrint_version&id=930167)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Lowland+Scots%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Lowland+Scots%2FPrint+version&oldid=930167&writer=rl)
  * [Printable version](/w/index.php?title=Lowland_Scots/Print_version&printable=yes)

  * This page was last modified on 25 July 2007, at 14:40.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Lowland_Scots/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
