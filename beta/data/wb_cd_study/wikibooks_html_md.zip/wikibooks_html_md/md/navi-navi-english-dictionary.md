# Na'vi/Na'vi-English dictionary/glottal series/Print version

From Wikibooks, open books for an open world

< [Na'vi](/wiki/Na%27vi) | [Na'vi-English dictionary](/wiki/Na%27vi/Na%27vi-English_dictionary) | [glottal series](/wiki/Na%27vi/Na%27vi-English_dictionary/glottal_series)

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Na'vi/Na'vi-English dictionary](/wiki/Na%27vi/Na%27vi-English_dictionary)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&action=purge&printable=yes) this page.

# Na’vi–English[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&action=edit&section=1)]

Confirmed Na’vi words and affixes are listed here in alphabetical order. _Ä_, _ì_, _rr_, _ll_, _ng_ (= _g_), _ts_ (= _c_), _kx_, _px_, _tx_ are ordered as distinct letters from _a_, _i_, _r_, _l_, _n_, _t_, _k_, _p_, _t_. Frommer's preferred orthography, with _g_ for _ng_ and _c_ for _ts_, is included in parentheses to allow electronic searches. Stress is indicated in [IPA](//en.wikipedia.org/wiki/International_Phonetic_Alphabet) transcription: The stress mark ‹ ˈ › appears _before_ the stressed syllable, and syllable breaks are marked with a dot. Prefixes and adpositions which cause lenition are marked with a plus sign, _ay+, −ro+_. Infix positions of verbs are marked in italics by _•raised dots•_. Many of these are assumed rather than attested. Stem-changing words (short plurals, verbal contractions, genitives) are included; many short plurals are assumed rather than attested.

Underlying /n/ is spelled 'm' before 'p' in compound words, as in _txampay_ (_txan-pay_) "sea". However, before 'k' it is spelled 'n', as in _zenke_ (_zene-ke_) "not need to", despite the fact that it is pronounced /ŋ/ and that this sound is spelled 'ng' before 'k' within a root such as _pängkxo_ "chat".

The vocabulary can be greatly expanded through productive use of Na’vi's word-building affixes, but such forms have not been included here unless they are attested in print or email from Paul Frommer.

Abbreviations

    _attr._ attributive forms
    _du._ dual form
    _infix_ infix positions
    _tri._ trial form
    _pl._ plural forms

    Parts of speech and classes of affix:

    

    ADJ. adjective
    ADP. adposition (functions as preposition and suffix)
    ADV. adverb
    AFF. affix (functions as prefix and suffix)
    CONJ. conjunction
    INF. infix
    INTJ. interjection
    MIM. mimesis
    N. noun 

    N.PL. plural noun
    PART. particle
    PREP. preposition
    PN. pronoun
    PREF. prefix
    SUFF. suffix
    V. verb 

    V.DAT. dative verb (takes intransitive and dative arguments, like _lu_ 'have')
    V.DI. ditransitive verb (takes ergative, accusative, and dative arguments, like _tìng_ 'give')
    V.IN. intransitive verb (takes intransitive argument only, like _lu_ 'be')
    V.TR. transitive verb (takes ergative and accusative arguments, like _tse'a_ 'see')

  


## Glottal series[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&action=edit&section=2)]

Following are Na’vi words starting with the glottal lenition series of consonants: **’** (glottal stop) and the vowels **A, Ä, E, I, Ì, O, U**

  


## ’[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-1)]

'ampi v.tr. /ˈʔam.pi/, infix _'•amp•i_ [.]

    touch
    'ampirikx n. /ˈʔam.pi.ɾikʼ/ [FE] leaf pitcher plant (_rikx_ move)

'ango (**'ago**) adj. /ˈʔa.ŋo/, attr. _'angoa_ N. _a'ango_ [.]

    soft (of a sound)

'angtsìk (**'agcìk**) n. /ˈʔaŋ.tsɪk/, pl. _angtsìk_ [.]

    [Hammerhead Titanothere](//en.wikipedia.org/wiki/Fictional_universe_of_Avatar#List_of_fauna) (a rhino-like animal)

'aw num. /ˈʔau̯/, attr. _'awa_ N. _a'aw_ [.]

    one
    'awlie adv. /ʔau̯.ˈli.ɛ/ [.] once (in the past)
    'awlo adv. /ˈʔau̯.lo/ [FE] once, one time (now or in the future) (_alo_ a turn)
    'awpo pn. /ˈʔau̯.po/, pl. _awpo?_ [.] an individual 

    tì'awpo n. /tɪ.ˈʔau̯.po/ [.] individuality, self-centeredness, selfishness
    'awsiteng (**'awsiteg**) adv. /ʔau̯.si.ˈtɛŋ/ [.] together 

    'awstengyem (**'awstegyem**) v.tr. /ʔau̯.stɛŋ.ˈjɛm/, infix _'awstengy••em_ [.] join (_yem_ put)
    'awve adj. /ˈʔau̯.vɛ/, attr. _'awvea_ N. _a'awve_ [.] first 

    nì'awve adv. /nɪ.ˈʔau̯.vɛ/ [.] first
    trr'awve n, adv. /tr̩.ˈʔau̯.vɛ/ [.] Sunday
    ke'aw adj. /ke.ˈʔau̯/, attr. _ke'awa_ N. _ake'aw_ [FE] divided 

    kaw− pref. /ˈkau̯/ [.] no- (see _kaw-_)
    nì'aw adv. /nɪ.ˈʔau̯/ [.] only 

    nì'awtu adv. /nɪ.ˈʔau̯.tu/ [.] alone ("as one person")
    volaw num. /vo.ˈlau̯/, attr. _volawa_ N. _avolaw_ [.] nine (octal 11)

'awkx n. /ˈʔau̯kʼ/, pl. _awkx_ [.]

    cliff

'awm n. /ˈʔau̯m/, pl. _awm_ [.]

    camp
    tì'awm n. /tɪ.ˈʔau̯m/ [.] camping 

    tì'awm si v. /tɪ.ˈʔau̯m si/, infix _tì'awm s••i_ [.] to camp

'ä'o n. /ˈʔæ.ʔo/, pl. _ä'o_ [FE]

    pitcher plant

'änsyem adj. /ʔæn.ˈsjɛm/, attr. _'änsyema_ N. _a'änsyem_ [.]

    whole, complete

'ärìp v.tr. /ˈʔæ.ɾɪp/, infix _'•är•ìp_ [.]

    move (cf. _rikx_)
    kä'ärìp v.tr. /kæ.ˈæ.ɾɪp/ [.] push
    za'ärìp v.tr. /za.ˈʔæ.ɾɪp/ [.] pull

'e'al adj. /ˈʔɛ.ʔal/, attr. _'e'ala_ N. _a'e'al_ [.]

    worst

'efu v. /ˈʔɛ.fu/, infix _'•ef•u_ [.]

    perceive, sense, feel
    oe 'efu som /ˈo.ɛ.ˈʔɛ.fu.ˈsom/ [FE] _I am hot_
    'efu nitram /ˈʔɛ.fu.nit.ˈɾam/ [FE] be happy"
    'efu ohakx /ˈʔɛ.fu.o.ˈhakʼ/ [.] be hungry
    tì'efu n. /tɪ.ˈʔɛ.fu/, pl. _sì'efu_ [.] feeling 

    tì'efumì oeyä /tɪ.ˈʔɛ.fu.mɪ.ˈwɛ.jæ/ [.] _in my opinion_

'eko v. /ˈʔɛ.ko/, infix _'•ek•o_ [.]

    attack

'ekong (**'ekog**) n. /ˈʔɛ.koŋ/, pl. _ekong_ [.]

    beat
    'ekong te'lanä /ˈʔɛ.koŋ tɛʔ.ˈla.næ/ the beat of the hearts

'el...

    ?
    'ele'wll n. /ˈʔɛ.lɛʔ.wl̩/, pl. _ele'wll_ [FE] thorny paw plant ('_ewll_ plant)

'em v. /ˈʔɛm/, infix _'••em_ [.]

    cook

'engeng (**'egeg**) adj. /ˈʔɛŋ.ɛŋ/, attr. _'engenga_ N. _a'engeng_ [.]

    even, level
    rey'eng n. /ɾɛi̯.ˈʔɛŋ/ [.] balance of life

'eoio adj. /ˈʔɛ.o.i.o/, attr. _'eoioa_ N. _a'eoio_ [F]

    ceremonious
    nì'eoio adv. /nɪ.ˈʔɛ.o.i.o/ [F] ceremoniously

'eveng (**'eveg**) n. /ˈʔɛ.vɛŋ/, du. _meveng_, tri. _pxeveng_, pl. _eveng, ayeveng_ [.]

    a child
    'evi n. /ˈʔɛ.vi/, du. _mevi_, tri. _pxevi_, pl. _evi, ayevi_ [.] kid (affectionate form of '_eveng_) 

    −vi suff. /vi/ [FE] (suffix for the product/spawn of something larger)

'ewan adj. /ˈʔɛ.wan/, attr. _'ewana_ N. _a'ewan_ [.]

    young

'ewll n. /ˈʔɛ.wl̩/, pl. _ewll_ [.]

    plant
    −wll suff. /wl̩/ (suffix in various plant names) 

    prrwll n. /ˈpr̩.wl̩/, pl. _frrwll?_ [.] moss

'eylan n. /ˈʔɛi̯.lan/, du. _meylan_, tri. _pxeylan_, pl. _eylan, ayeylan_ [.]

    friend
    tì'eylan n. /tɪ.ˈʔɛi̯.lan/ [.] friendship

'eyng (**'eyg**) v. /ˈʔɛi̯ŋ/, infix _'••eyng_ [.]

    respond, to answer
    nì'eyng (**nì'eyg**) adv. /nɪ.ˈʔɛi̯ŋ/ [.] in answer, in response
    tì'eyng (**tì'eyg**) n. /tɪ.ˈʔɛi̯ŋ/, pl. _sì'eyng_ [.] an answer, a response

'i'a v. /ˈʔiʔ.a/, infix _'•i'•a_ [.]

    end, conclude
    tì'i'a n. /tɪ.ˈʔiʔ.a/, pl. _sì'i'a_ [FE] (the) end 

    tì'i'avay krrä /tɪ.ˈʔiʔ.a.vai̯ ˈkr̩.æ/ [FE] forever, until the end of time

'ia v. /ˈʔi.a/, infix _'•i•a_ [.]

    become absorbed, lose oneself

'it n. /ˈʔit/, pl. _it_ [.]

    a bit, a small amount
    'itan n. /ˈʔi.tan/, pl. _itan_ [.] son
    'ite n. /ˈʔi.tɛ/, pl. _ite_ [.] daughter
    kaw'it adv. /kau̯.ˈʔit/ [.] not a bit, not at all
    nì'it adv. /nɪ.ˈʔit/ [.] (do) a little, a bit

'ì'awn v. /ʔɪ.ˈʔau̯n/, infix _'•ì'•awn_ [.]

    remain, stay

'ìheyu n. /ʔɪ.ˈhɛ.ju/, pl. _ìheyu_ [.]

    spiral 

    ìheyu sìreyä /ɪ.hɛ.ju sɪ.ɾɛ.jæ/ the spiral of lives

'ìnglìsì (**'ìglìsì**) n. /ˈʔɪŋ.lɪ.sɪ/ [.]

    the English language
    nì'ìnglìsì (**nì'ìglìsì**) adv. /nɪ.ˈʔɪŋ.lɪ.sɪ/ in English

'ok n. /ˈʔok/, pl. _ok_ [.]

    remembrance, memory

'ong (**'og**) v.in. /ˈʔoŋ/, infix _'••ong_ [.]

    unfold, blossom

'opin n. /ˈʔo.pin/, pl. _opin_ [.]

    color

'ora n. /ˈʔo.ɾa/, pl. _ora_ [.]

    lake

'Rrta n. /ˈʔr̩.ta/ [.]

    Earth
    Trr 'Rrtayä n. /tr̩.ˈʔr̩.ta.jæ/ [FE]

'u n. /ˈʔu/, pl. _ayu_ [., FE]

    thing (abstract or concrete)
    'uo pn. /ˈʔu.o/ [.] something
    'upe, peu pn. /ˈʔu.pɛ, pɛ.ˈu/ [.] what (thing)
    fra'u pn. /ˈfɾa.ʔu/ [.] everything
    ke'u pn. /ˈkɛ.ʔu/ [.] nothing, none 

    ke'u adv. /ˈkɛ.ʔu/ [.] none at all, not at all

'ul /ˈʔul/

    ?
    nì'ul adv. /nɪ.ˈʔul/ [.] more 

    nulkrr adv. /nul.ˈkr̩/ [.] longer (time) (_krr_ time)
    nulnew v. /nul.ˈnɛu̯/, infix _nuln••ew_ [.] rather, prefer (_new_ to want)

'upxare n. /ʔu.ˈpʼa.ɾɛ/, pl. _upxare_ [.]

    message

## A[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-2)]

a conj. /a/ [.]

    which, that, who (relativizer and subordinator)
    −a− aff. /a/ [.] (links adjectives to nouns)
    alìm adv. /a.ˈlɪm/ [.] far away, at a distance (irregular from _lìm_ be far)
    asim adv. /a.ˈsim/ [.] nearby, at close range (irregular _sim_ be near)

Akwey n. /ak.ˈwɛi̯/ [FE]

    (male name)

alaksi adj. /a.ˈlak.sɪ/, attr. _alaksia_ N. _alaksi_ [.]

    ready

alìm adv. /a.ˈlɪm/ [.] far away, at a distance (_lìm_ be far)

    'Ì'awn alìm! /ʔɪ.ˈʔau̯.na.ˈlɪm/ [FE] "Stay back!"

‹alm› inf. /al.m/

    compound past.pfv infix (in medial TAM position)

alo n. /a.ˈlo/ [.]

    turn, instance, number of times
    alo oeyä /a.ˈlo ˈwɛ.jæ/ my turn
    fralo adv. /ˈfɾa.lo/ each time, every time
    'awlo adv. /ˈʔau̯.lo/ [.] once
    alo a'aw (nì'aw) /a.ˈlo.a.ˈʔau̯.nɪ.ˈʔau̯/ [FE] (just) one time
    melo adv. /ˈmɛ.lo/ [.] twice
    pxelo adv. /ˈpʼɛ.lo/ [FE] thrice
    alo apxey /a.ˈlo.a.ˈpʼɛi̯/ [FE] three times
    alo atsìng, tsìnga alo /a.ˈlo.a.ˈtsɪŋ, ˈtsɪ.ŋa.ˈlo/ [FE] four times
    alo amrr, mrra alo /a.ˈlo.a.ˈmr, ˈmr̩.a.ˈlo/ [FE] five times

alunta conj. /a.ˈlun.ta/ [FE] because (_lun_ reason; cf. _talun(a)_)

‹aly› inf. /al.j/

    compound fut.pfv infix (in medial TAM position)

‹am› inf. /a.m/

    past infix (in medial TAM position)

Amhul n. /am.ˈhul/ [FE]

    (female name)

ampirikx n.pl. /ˈam.pi.ɾikʼ/

    Short plural of _'ampirikx_. leaf pitcher plant

anìheyu n. /a.nɪ.ˈhɛ.ju/ [FE]

    fibonacci plant ('_ìheyu_ spiral)

angtsìk (**agcìk**) n.pl. /aŋ.tsɪk/

    Short plural of _'angtsìk_. Hammerhead

apxa adj. /a.ˈpʼa/, attr. _apxa_ N. _apxa_ [.]

    large
    apxangrr (**apxagrr**) n. /a.ˈpʼa. ŋr̩/ [FE] delta tree (_ngrr_ root) 

    tsawlapxangrr (**cawlapxagrr**) n. /ˈtsau̯.la.pʼa.ŋr̩/, pl. _sawlapxangrr_ [FE] unidelta tree (_tsawl_ tall)

‹arm› inf. /aɾ.m/

    compound past.ipfv infix (in medial TAM position)

‹ary› inf. /aɾ.j/

    compound fut.ipfv infix (in medial TAM position)

asim adv. /a.ˈsim/ [.] nearby, at close range (_sim_ be near)

‹asy› inf. /a.sj/

    compound fut.intent infix (in medial TAM position)

atan n. /a.ˈtan/ [.]

    light (source of illumination)

Ateyo n. /a.ˈtɛ.jo/ [FE]

    (male name)
    Ateyitan n. /?/ "son of Ateyo" [to confirm]

atoki n.

    ?
    atokirina' n. /a.to.ki.ˈɾi.naʔ/ [.] seeds of the great tree (_rina'_ "seed")

atxkxe n. /atʼ.ˈkʼɛ/ [.]

    land

‹ats› (**ac**) inf. /a.ts/

    evid infix (affect; added to final syllable)

au n. /ˈa.u/ [.]

    drum (made of skin)

au! intj. /a.ˈu/ [.]

    no, it can't be! (expresses consternation)

aungia n. /a.ˈu.ŋi.a/ [.]

    sign, omen

awaiei n. /a.wa.i.ˈɛ.i/ [FE]

    banshee of paradise plant

aweykta conj. /a.ˈwɛi̯k.ta/ [FE] because (_oeyk_ cause; cf. _taweyk(a)_)

awkx n.pl. /ˈau̯kʼ/

    Short plural of _'awkx_. cliff

awm n.pl. /ˈau̯m/

    Short plural of _'awm_. camps

‹awn› inf. /au̯.n/

    pass infix (in initial valency position)

awnga (**awga**) pn. /au̯.ˈŋa/ [FE]

    we (including you); alt. for _ayoeng_
    dat awngaru, awngar pn. /au̯.ˈŋa.ɾu, au̯.ˈŋaɾ/ [FE]
    gen awngeyä pn. /au̯.ˈŋɛ.jæ/ [FE]

‹ay› inf. /a.j/

    fut infix (in medial TAM position)

ay\+ pref. /ai̯/ [FM]

    (plural prefix) (causes lenition)
    ayfo pn. /ai̯.ˈfo, ˈai̯.fo/ [.] they (= _fo_)
    aylaru pn. /ai̯.ˈla.ɾu/ [.] to the others
    aynga (**ayga**) pn. /ai̯.ˈŋa/ [.] you all
    ayoe pn. /ai̯.ˈo.ɛ/ [.] we (exclusive)
    ayoeng (**ayoeg**) pn. /ai̯.ˈwɛŋ/ [.] we (inclusive) 

    nìayoeng (**nìayoeg**) pn. /nai̯.ˈwɛŋ/ [.] like us (inclusive)

## Ä[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-3)]

−ä suff. /æ/

    Form of gen _−yä_. after a consonant and the vowels _i, u, o._

ä'o n.pl. /ˈæ.ʔo/

    Short plural of _'ä'o_. pitcher plant

äie n. /æ.ˈi.ɛ/ [.]

    a vision

Änsìt n. /ˈæn.sɪt/ [FE]

    (male name)

‹äng› (**äg**) inf. /æ.ŋ/

    pej infix (affect; added to final syllable)

−äo− adp. /ˈæ.o/ [.]

    below

‹äp› inf. /æ.p/

    refl infix (in initial valency position)

ätxäle n. /æ.ˈtʼæ.lɛ/ [.]

    a request
    ätxäle si v. /æ.ˈtʼæ.lɛ.si/, infix _ätxäle s••i_ to (make a) request

## E[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-4)]

ean adj. /ˈɛ.an/, attr. _eana_ N. _aean_ [.]

    blue, green
    nìean adv. /nɪ.ˈɛ.an/ in blue
    eanean n. /ˈɛ.an.ˈɛ.an/ [FE] cheadle plant

‹ei› inf. /ɛ.i./

    approb infix (affect; added to final syllable)

ekong n.pl. /ˈɛ.koŋ/

    Short plural of _'ekong_. beat

ekxan n. /ɛ.ˈkʼan/ [.]

    obstruction, barrier, baricade

ele'wll n.pl. /ˈɛ.lɛʔ.wl̩/

    Short plural of _'ele'wll_. thorny paw plant

eltu n. /ˈɛl.tu/ [.]

    a brain
    eltu si v. /ˈɛl.tu si/, infix _eltu s••i_ [.] pay attention, quit goofing off
    eltungawng n. /ˈɛl.tu.ŋau̯ŋ/ [.] brainworm (hallucinogenic)
    eltu lefngap n. /ɛl.tu.lɛ.ˈfŋap/ [.] computer

emza'u v. /ɛm.ˈza.ʔu/, infix _emz•a'•u_ [.]

    to pass (a test for initiation) (= _em_ "over" + _za'u_ "come")

Entu n. /ˈɛn.tu/ [FE]

    (male name)

−eo− adp. /ˈɛ.o/ [.]

    in front of

‹er› inf. /ɛ.ɾ/

    ipfv infix (in medial TAM position)

etrìp adj. /ˈɛt.ɾɪp/, attr. _etrìpa_ N. _aetrìp_ [.]

    auspicious, favourable

eveng (**eveg**) n.pl. /ˈɛ.vɛŋ/

    Short plural of _'eveng_. child
    evi n.pl. /ˈɛ.vi/ Short plural of _'evi_. kid

ewll n.pl. /ˈɛ.wl̩/

    Short plural of _'ewll_. plant

eyawr adj. /ɛi̯.ˈau̯ɾ/, attr. _eyawra_ N. _aeyawr_ [.]

    right, correct [check syll]
    keyawr adj. /kɛ.ˈjau̯ɾ/, attr. _keyawra_ N. _akeyawr_ [.] wrong, incorrect [syll differs]
    tìyawr n. /tɪ.ˈjau̯ɾ/ [.] correctness, being correct 

    ngaru tìyawr [.] _you're right_

eyaye n. /ɛ.ˈja.jɛ/ [FE]

    warbonnet fern

‹eyk› inf. /ɛi̯.k/

    caus infix (in initial valency position)

eyk v. /ˈɛi̯k/, infix _••eyk_ [.]

    lead
    eyktan n. /ˈɛi̯k.tan/ [.] leader

eylan n.pl. /ˈɛi̯.lan/

    Short plural of _'eylan_. friend

Eytukan n. /ˈɛi̯.tu.kan/ [FE]

    (male name)

Eywa n. /ˈɛi̯.wa/ [.]

    Pandoran "World spirit" and Na’vi deity, equivalent to Gaea
    Eywa ngahu /ˈɛi̯.wa ˈŋa.hu/ [.] good-bye (lit. "Eywa (be) with you")
    Eywa'eveng (**Eywa'eveg**) n. /ˌɛi̯.wa.ˈʔɛ.vɛŋ/ [.] Pandora (the Na'vi world)

## I[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-5)]

i'en n. /ˈi.ʔɛn/ [.]

    stringed instrument

Iknimaya n. /ˈik.ni.ˈma.ja/ [.]

    Hallelujah Mountains (Thundering rocks, Stairway to Heaven (floating mountains))

ikran n. /ˈik.ɾan/ [.]

    [Mountain Banshee](//en.wikipedia.org/wiki/Fictional_universe_of_Avatar#List_of_fauna) (a pterosaur-like animal)

‹ilv› inf. /il.v/

    compound pfv.sjv infix (in medial TAM position)

‹imv› inf. /im.v/

    compound past.sjv infix (in medial TAM position)

−io− adp. /ˈi.o/ [.]

    above

ioang (**ioag**) n. /i.ˈo.aŋ/ [.]

    animal, beast
    hì'ang n. /ˈhɪ.ʔaŋ/ [.] bug (_hì'i_ little)
    payoang (**payoag**) n. /pai̯.ˈo.aŋ/, pl. _fayoang_ [.] fish (_pay_ water)
    talioang (**talioag**) n. /ˈtal.i.o.aŋ/, pl. _salioang_ [.] sturmbeest
    yayo n. /ˈja.jo/ [.] bird (_ya_ air)

irayo part. /i.ˈɾa.jo/ [.]

    thank you
    ireiyo part. /i.ˈɾɛ.i.jo/ (Jake's pronunciation in the film) thank you
    irayo si v. /i.ˈɾa.jo si/, infix _irayo s••i_ [FE] thank 

    oe ngaru seiyi irayo /ˈo.ɛ ˈŋa.ɾu sɛ.i.ˈji i.ˈɾa.jo/ I thank you

‹irv› inf. /iɾ.v/

    compound ipfv.sjv infix (in medial TAM position)

−it suff. /it/

    acc case suffix, reduced to −**t** after a vowel. Also invariable −**ti**.

it n.pl. /ˈit/

    Short plural of _'it_. bit
    itan n.pl. /ˈi.tan/ Short plural of _'itan_. son
    ite n.pl. /ˈi.tɛ/ Short plural of _'ite_. daughter

‹iv› inf. /i.v/

    sjv infix (in medial TAM position)

‹iyev› inf. /i.jɛ.v/

    compound fut.sjv infix (in medial TAM position)

## Ì[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-6)]

ìheyu n.pl. /ɪ.hɛ.ju/

    Short plural of _'ìheyu_. spiral

−ìl suff. /ɪl/

    erg case suffix, reduced to −**l** after a vowel

−ìlä\+ adp. /ˈɪ.læ, ɪ.ˈlæ/ [.]

    along, via, following
    −kxamlä− adp. /ˈkʼam.læ/ [.] through (via the _kxam_ middle)

ìley! intj. /ɪ.ˈlɛi̯/ [.]

    alala! (battle cry)

‹ìlm› inf. /ɪl.m/

    compound rec.pfv infix (in medial TAM position)

‹ìly› inf. /ɪl.j/

    compound imm.pfv infix (in medial TAM position)

‹ìm› inf. /ɪ.m/

    rec past infix (in medial TAM position)

‹ìmìy› inf. /ɪ.mɪ.j/

    compound rec.imm infix (in medial TAM position)

−ìri suff. /ɪ.ɾi/

    top case suffix, reduced to −**ri** after a vowel

‹ìrm› inf. /ɪɾ.m/

    compound rec.ipfv infix (in medial TAM position)

‹ìry› inf. /ɪɾ.j/

    compound imm.ipfv infix (in medial TAM position)

Ìstaw n. /ɪ.ˈstau̯/ [FE]

    (male name)

‹ìsy› inf. /ɪ.sj/

    compound imm.intent infix (in medial TAM position)

‹ìy› inf. /ɪ.j/

    imm future infix (in medial TAM position)

‹ìyev› inf. /ɪ.jɛ.v/

    Alternate of _iyev_.

## O[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-7)]

−o suff. /o/

    (indefinite suffix) 

    lu ketuwongo nì’aw [FE] "it's just some alien"
    ayupxareo [FE] "some messages"
    'uo pn. /ˈʔu.o/ [.] something
    tuteo pn. /ˈtu.tɛ.o/ [.] somebody
    tsengo (**cego**) adv. /ˈtsɛ.ŋo/ [.] somewhere
    trro adv. /ˈtr̩.o/ [FE] one day, some day
    ? oeyk n. /o.ˈɛi̯k/ [.] cause

oe pn. /ˈo.ɛ/, du. _moe_, tri. _pxoe_, pl. _ayoe_ [.,FE] /ˈmo.ɛ, ˈpʼo.ɛ, ai̯.ˈo.ɛ/ [stress trial? syll. pl?]

    I, we (but not you) 

    erg oel pn. /ˈwɛl/, du. _moel_, tri. _pxoel_, pl. _ayoel_ /ˈmo.ɛl, ˈpʼo.ɛl, ai̯.ˈwɛl/
    acc oeti pn. /ˈwɛ.ti/, du. _moeti_, tri. _pxoeti_, pl. _ayoeti_ /ˈmo.ɛ.ti, ˈpʼo.ɛ.ti, ai̯.ˈwɛ.ti/
    gen oeyä pn. /ˈwɛ.jæ/, du. _moeyä_, tri. _pxoeyä_, pl. _ayoeyä_ /ˈmo.ɛ.jæ, ˈpʼo.ɛ.jæ, ai̯.ˈwɛ.jæ/
    dat1 oeru pn. /ˈwɛ.ɾu/, du. _moeru_, tri. _pxoeru_, pl. _ayoeru_ /ˈmo.ɛ.ɾu, ˈpʼo.ɛ.ɾu, ai̯.ˈwɛ.ɾu/
    dat2 oer pn. /ˈwɛɾ/, du. _moer_, tri. _pxoer_, pl. _ayoer_ /ˈmo.ɛɾ, ˈpʼo.ɛɾ, ai̯.ˈwɛɾ/
    top oeri pn. /ˈwɛ.ɾi/, du. _moeri_, tri. _pxoeri_, pl. _ayoeri_ /ˈmo.ɛ.ɾi, ˈpʼo.ɛ.ɾi, ai̯.ˈwɛ.ɾi/
    oehu pn. /ˈwɛ.hu/? with me
    oeng (**oeg**) pn. /ˈwɛŋ/, tri. _pxoeng_, pl. _ayoeng_ [.,FE] /ˈpʼo.ɛŋ, ai̯.ˈwɛŋ/ [stress trial?] 

    we two (you and I), all of us 

    erg oengal pn. /wɛ.ŋal/ [stress?]
    acc1 oengat pn. /wɛ.ŋat/ [stress?]
    acc2 oengati pn. /wɛ.ŋa.ti/ [stress?]
    gen oengeyä pn. /wɛ.ŋɛ.jæ/ [confirm form]
    nìayoeng (**nìayoeg**) adv. /nai̯.ˈwɛŋ/ [.] like us
    awnga (**awga**) pn. /au̯.ˈŋa/ [FE] we (you and us: alt. for _ayoeng_)
    ohe pn. /ˈo.hɛ/, du. _mohe_, tri. _pxohe_, pl. _ayohe_ [.,FE] /ˈmo.hɛ, ˈpʼo.hɛ, ai̯.ˈo.hɛ/

    I (deferential or ceremonial form)
    ohe ngengasì (**ohe gegasì**) pn. /ˈo.hɛ ŋɛ.ˈŋa.sɪ/ [FE] we two (inclusive & formal) 

    gen ohengeyä (**ohegeyä**) /o.hɛ.ŋɛ.jæ/ our (inclusive dual & formal) [stress?]

oeyk n. /o.ˈɛi̯k/ [.]

    cause (_eyk_ to lead)
    oeyktìng (**oeyktìg**) v. /o.ˈɛi̯k.tɪŋ/, infix _oeykt••ìng_ [.] explain, say why 

    tìoeyktìng (**tìoeyktìg**) n. /tɪ.o.ˈɛi̯k.tɪŋ, tɪ.ˈwɛi̯k.tɪŋ/, pl. _sìoeyktìg_ [FE] explanation
    taweyka, taweyk conj. /ta.ˈwɛi̯.ka, ta.ˈwɛi̯k/ [.] because (English clause order)
    aweykta conj. /a.ˈwɛi̯k.ta/ [FE] because (opposite clause order)

ohakx adj. /o.ˈhakʼ/, attr. _ohakxa_ N. _aohakx_ [.]

    hungry
    tìohakx n. /tɪ.o.ˈhakʼ/ [.] hunger
    'efu ohakx /ˈʔɛ.fu.o.ˈhakʼ/ [.] be hungry

oìsss! intj. /o.ˈɪsː/ [.]

    (hiss, snarl; expresses anger)

ok n.pl. /ˈok/

    Short plural of _'ok_. memory

‹ol› inf. /o.l/

    pfv infix (in medial TAM position)

olo' n. /o.ˈloʔ/ [.]

    clan
    olo'eyktan n. /o.lo.ˈʔɛi̯k.tan/ [.] clan leader

Omatikaya n. /o.ma.ti.ˈka.ja/ [F]

    the Blue Flute Clan
    gen Omatikayaä /o.ma.ti.ˈka.ja.æ/ [FE] (irregular)

omum v. /ˈo.mum/, infix _•om•um_ [.]

    know
    nìawnomum adv. /nɪ.au̯.ˈno.mum/ [.] as is known

ontu n. /ˈon.tu/ [.]

    nose

opin n.pl. /ˈo.pin/

    Short plural of _'opin_. color

ora n.pl. /ˈo.ɾa/

    Short plural of _'ora_. lake

Otranyu n. /ot.ˈɾan.ju/ [FE]

    (clan name)

## U[[edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series&action=edit&section=T-8)]

ukxo adj. /u.ˈkʼo/, attr. _ukxoa_ N. _aukxo_ [.]

    dry

ulte conj. /ˈul.tɛ/ [.]

    and (joins clauses)

ultxa n. /ul.ˈtʼa/ [.]

    meeting
    ultxa si v. /ul.ˈtʼa.si/, infix _ultxa s••i_ [FE] meet, have a meeting (use _hu_ for 'with')
    ultxarun v. /ul.ˈtʼa.ɾun/, infix _ultxar••un_ [FE] encounter, meet (by chance; _run_ find)

unil n. /ˈu.nil/ [.]

    dream
    uniltaron n. /ˈu.nil.ˈta.ɾon/ [.] Dream Hunt (initiation ceremony)
    uniltìrantokx n. /ˈu.nil.tɪ.ˈɾan.tokʼ/ [.] an avatar (dreamwalker body) (_tìran_ to walk, _tokx_ body)
    uniltìranyu n. /ˈu.nil.tɪ.ˈɾan.ju/ [.] dreamwalker

−uo− adp. /ˈu.o/ [.]

    behind

upxare n.pl. /u.ˈpʼa.ɾɛ/

    Short plural of _'upxare_. message

−ur suff. /uɾ/

    dat case suffix, from _*−uru_; reduced to −**ru** (and frequently shortened to −**r**) after a vowel

‹us› inf. /u.s/

    actv infix (in initial valency position)

utral n. /ˈut.ɾal/ [.]

    tree
    −ut suff. /ut/ [SG] (suffix in various tree names)
    Utral Aymokriyä n. /ˈut.ɾal ai̯.ˈmok.ɾi.jæ/ [.] Tree of Voices (_mokri_ voice)
    Vitrautral n. /vit.ˈɾa.ut.ɾal/ [.] the Tree of Souls

uvan n. /u.ˈvan/ [.]

    a game
    uvan si v. /u.ˈvan.si/, infix _uvan s••i_ [.] play a game

‹uy› inf. /u.j/

    form infix (affect; added to final syllable)
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&oldid=1743673](http://en.wikibooks.org/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&oldid=1743673)" 

[Category](/wiki/Special:Categories): 

  * [Na'vi](/wiki/Category:Na%27vi)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Na%27vi%2FNa%27vi-English+dictionary%2Fglottal+series%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Na%27vi%2FNa%27vi-English+dictionary%2Fglottal+series%2FPrint+version)

### Namespaces

  * [Book](/wiki/Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version)
  * [Discussion](/wiki/Talk:Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version)

### 

### Variants

### Views

  * [Read](/wiki/Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version)
  * [Edit](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&action=edit)
  * [View history](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&oldid=1743673)
  * [Page information](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Na%27vi%2FNa%27vi-English_dictionary%2Fglottal_series%2FPrint_version&id=1743673)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Na%27vi%2FNa%27vi-English+dictionary%2Fglottal+series%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Na%27vi%2FNa%27vi-English+dictionary%2Fglottal+series%2FPrint+version&oldid=1743673&writer=rl)
  * [Printable version](/w/index.php?title=Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version&printable=yes)

  * This page was last modified on 25 March 2010, at 15:53.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Na%27vi/Na%27vi-English_dictionary/glottal_series/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
