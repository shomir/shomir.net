# Cell Biology/Print version

From Wikibooks, open books for an open world

< [Cell Biology](/wiki/Cell_Biology)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)This page may need to be [reviewed](/wiki/Wikibooks:REVIEW) for quality.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Cell Biology](/wiki/Cell_Biology)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Cell_Biology/Print_version&action=purge&printable=yes) this page.

_Note: current version of this book can be found at <http://en.wikibooks.org/wiki/Cell_Biology>_

Remember to click "refresh" to view this version.

# Table of contents[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=1)]

Introduction

  * Size of cells
  * What is a cell?
  * What is the difference between elements?
  * What is living?
  * What is interesting about cell biology?
  * What is a tertiary protein?

Types of cells

  * Prokaryotes 
    * Bacteria
  * Eukaryotes 
    * Unique Properties of Plant Cells

Parts of the cell

  * Membranes
  * Organelles
  * Genetic material
  * Energy supply (chloroplasts and mitochondria)

Cell division

  * Cell cycle
  * Meiosis
  * Mitosis

Genes

  * Expression
  * Translation

# Introduction[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=2)]

# Size of cells[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=3)]

## Size of Cells[[edit](/w/index.php?title=Cell_Biology/Introduction/Cell_size&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/6/64/Cellsize.jpg)

Cells are so small that even a cluster of these cells from a mouse only measures 50 microns

Although it is generally the case that biological cells are too small to be seen at all without a microscope, there are exceptions as well as considerable range in the sizes of various cell types. [Eukaryotic](/wiki/Cell_Biology/Cell_types/Eukaryotes) cells are typically 10 times the size of [prokaryotic](/wiki/Cell_Biology/Cell_types/Prokaryotes) cells (these cell types are discussed in the next Chapter). Plant cells are on average some of the largest cells, probably because in many plant cells the inside is mostly a water filled vacuole.

So, you ask, what are the relative sizes of biological molecules and cells? The following are all approximations:
    
    
    0.1 nm (nanometer) diameter of a hydrogen atom
    0.8 nm Amino Acid
      2 nm Diameter of a DNA Alpha helix
      4 nm Globular Protein
      6 nm microfilaments
     7 nm thickness cell membranes
     20 nm Ribosome
     25 nm Microtubule
     30 nm Small virus (Picornaviruses)
     30 nm Rhinoviruses
     50 nm Nuclear pore
    100 nm HIV
    120 nm Large virus (Orthomyxoviruses, includes influenza virus)
    150-250 nm Very large virus (Rhabdoviruses, Paramyxoviruses)
    150-250 nm small bacteria such as Mycoplasma
    200 nm Centriole
    200 nm (200 to 500 nm) Lysosomes
    200 nm (200 to 500 nm) Peroxisomes
    800 nm giant virus Mimivirus
      1 µm (micrometer)
           (1 - 10 µm) the general sizes for Prokaryotes
      1 µm Diameter of human nerve cell process
      2 µm E.coli - a bacterium
      3 µm Mitochondrion
      5 µm length of chloroplast
      6 µm (3 - 10 micrometers) the Nucleus
      9 µm Human red blood cell
     10 µm
           (10 - 30 µm) Most Eukaryotic animal cells
           (10 - 100 µm) Most Eukaryotic plant cells
     90 µm small Amoeba
    100 µm Human Egg
    up to 160 µm Megakaryocyte
    up to 500 µm  giant bacterium Thiomargarita
    up to 800 µm  large Amoeba
      1 mm (1 millimeter, 1/10th cm)
      1 mm Diameter of the squid giant nerve cell
    up to 40mm Diameter of giant amoeba Gromia Sphaerica
      120 mm Diameter of an ostrich egg (a dinosaur egg was much larger)
      3 meters Length of a nerve cell of giraffe's neck
    

Next to the next Megakaryocyte is a Amoeba

## Related reading[[edit](/w/index.php?title=Cell_Biology/Introduction/Cell_size&action=edit&section=T-2)]

  * [Some early history](/wiki/Cell_Biology/History) related to the development of an understanding of the existence and importance of cells. The importance of microscopy.

What limits cell sizes?

Prokaryotes - Limited by efficient metabolism

Animal Cells (Eukaryotic) - Limited by Surface Area to Volume ratio

Plant Cells (Eukaryotic) - Have large sizes due to large central vacuole which is responsible for their growth

# What is a cell?[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=4)]

Cells are structural units that make up plants and animals; also, there are many single celled organisms. What all living cells have in common is that they are small 'sacks' composed mostly of water. The 'sacks' are made from a [phospholipid bilayer](/wiki/Cell_Biology/Membranes) membrane. This membrane is semi-permeable (allowing some things to pass in or out of the cell while blocking others). There exist other methods of transport across this membrane that we will get into later.

So what is in a cell? Cells are 90% fluid (called cytoplasm) which consists of free amino acids, proteins, carbohydrates, fats, and numerous other molecules. The cell environment (i.e., the contents of the cytoplasm and the nucleus, as well as the way the DNA is packed) affect gene expression/regulation, and thus are VERY important aspects of inheritance. Below are approximations of other components (each component will be discussed in more detail later):

### Elements[[edit](/w/index.php?title=Cell_Biology/Introduction/What_is_a_cell&action=edit&section=T-1)]

  * 59% Hydrogen (H)
  * 24% Oxygen (O)
  * 11% Carbon (C)
  * 4% Nitrogen (N)
  * 2% Others - Phosphorus (P), Sulphur (S), etc.

### Molecules[[edit](/w/index.php?title=Cell_Biology/Introduction/What_is_a_cell&action=edit&section=T-2)]

  * 50% protein
  * 15% nucleic acid
  * 15% carbohydrates
  * 10% lipids
  * 10% Other

### Components of cytoplasm[[edit](/w/index.php?title=Cell_Biology/Introduction/What_is_a_cell&action=edit&section=T-3)]

The following is optional reading, as all cell components will be discussed in subsequent chapters.

  * **Cytosol** \- contains mainly water and numerous molecules floating in it- all except the organelles.
  * **Organelles** (which also have membranes) in 'higher' eukaryote organisms: 
    * **Nucleus** (in eukaryotes) - where genetic material (DNA) is located, RNA is transcribed.
    * **Endoplasmic Reticulum (ER)** \- Important for protein synthesis. It is a transport network for molecules destined for specific modifications and locations. There are two types: 
      * **Rough ER** \- Has ribosomes, and tends to be more in 'sheets'.
      * **Smooth ER** \- Does not have ribosomes and tends to be more of a tubular network.
    * **Ribosomes** \- half are on the Endoplasmic Reticulum, the other half are 'free' in the cytosol, this is where the RNA goes for translation into proteins.
    * **Golgi Apparatus** \- important for glycosylation, secretion. The Golgi Apparatus is the "UPS" of the cell. Here, proteins and other molecules are prepared for shipping outside of the cell.
    * **Lysosomes** \- Digestive sacks found only in animal cells; the main point of digestion.
    * **Peroxisomes** \- Use oxygen to carry out catabolic reactions, in both plant and animals. In this organelle, an enzyme called catalase is used to break down hydrogen peroxide into water and oxygen gas.
    * **Microtubules** \- made from tubulin, and make up centrioles,cilia,etc.
    * **Cytoskeleton** \- Microtubules, actin and intermediate filaments.
    * **Mitochondria** \- convert foods into usable energy. (ATP production) A mitochondrion does this through aerobic respiration. They have 2 membranes, the inner membranes shapes differ between different types of cells, but they form projections called cristae. The mitochondrion is about the size of a bacteria, and it carries its own genetic material and ribosomes.
    * **Vacuoles** \- More commonly associated with plants. Plants commonly have large vacuoles.
  * **Organelles found in plant cells and not in animal cells:**
    * **Plastids** \- membrane bound organelles used in storage and food production. These are similar to entire prokaryotic cells - for example, like mitochondria they contain their own DNA and self-replicate. They include: 
      * **Chloroplasts** \- convert light/food into usable energy. (ATP production)
      * **Leucoplasts** \- store starch, proteins and lipids.
      * **Chromoplasts** \- contain pigments. (E.g. providing colors to flowers)
    * **Cell Wall** \- found in prokaryotic and plant cells; provides structural support and protection.

# What is the difference between elements?[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=5)]

The various elements that make up the cell are:

  * 59% Hydrogen (H)
  * 24% Oxygen (O)
  * 11% Carbon (C)
  * 4% Nitrogen (N)
  * 2% Others - Phosphorus (P), Sulphur (S), etc.

The difference between these elements is their respective atomic weights, electrons, and in general their chemical properties. A given element can only have so many other atoms attached. For instance carbon (C) has 4 electrons in its outer shell and thus can only bind to 4 atoms; Hydrogen only has 1 electron and thus can only bind to one other atom. An example would be Methane which is CH4. Oxygen only has 2 free electrons, and will sometimes form a double bond with a single atom, which is an 'ester' in organic chemistry (and is typically scented).

  


Methane Water Methanol (Methyl Alcohol)
    
    
      H
      |
    H-C-H
      |
      H
    
    
    
    H   H
     \ /
      O
    
    
    
      H
      |
    H-C-O-H
      |
      H
    

As for the organic molecules that make up a typical cell:

  * 50% protein
  * 15% nucleic acid
  * 15% carbohydrates
  * 10% lipids
  * 10% Other

Here is a list of Elements, symbols, weights and biological roles.

Element Symbol Atomic Weight Biological Role

Bromine
Br
79.9
Defense and pigmentation in certain marine organisms, esp. algae.

Calcium
Ca
40.1
Bone; muscle contraction, second messenger

Carbon
C
12.0
Constituent (backbone) of organic molecules

Chlorine
Cl
35.5
Digestion and photosynthesis

Chromium
Cr
52.0
Metabolism of sugars and lipids in humans.

Copper
Cu
63.5
Part of Oxygen—carrying pigment of mollusk blood.

Fluorine
F
19.0
For normal tooth enamel development

Hydrogen
H
1.0
Part of water and all organic molecules

Iodine
I
126.9
Part of thyroxine (a hormone)

Iron
Fe
55.8
Hemoglobin, oxygen caring pigment of many animals

Magnesium
Mg
24.3
Part of chlorophyll, the photosynthetic pigment; essential to some enzymes.

Manganese
Mn
54.9
Essential to some enzyme actions.

Nitrogen
N
14.0
Constituent of all proteins and nucleic acids.

Oxygen
O
16.0
Respiration; part of water; and in nearly all organic molecules.

Phosphorus
P
31.0
Constituent of DNA and RNA backbones; high energy bond in ATP.

Potassium
K
39.1
Generation of nerve impulses.

Selenium
Se
79.0
For the working of many enzymes.

Silicon
Si
28.1
Diatom shells; grass leaves.

Sodium
Na
23.0
Part of Salt; nerve conduction

Sulfur
S
32.1
Constituent of most proteins. Important in protein structure: Sulfide bonds are strong.

Zinc
Zn
65.4
Essential to alcohol oxidizing enzyme.

# What is living?[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=6)]

The question, "What is life?" has been one of many long discussions and the answer may depend upon your initial definitions.

Life is cells. Cell theory consists of three basic points.

  1. All living things are made of cells.
  2. The cell is the smallest living thing that can perform all the functions of life.
  3. All cells must come from preexisting cells.

Some definitions of life are:

  1. The quality that distinguishes a vital and functional being from a non-living or dead body or purely chemical matter.
  2. The state of a material complex or individual characterized by the capacity to perform certain functional activities including metabolism, growth, and reproduction.
  3. The sequence of physical and mental experiences that make up the existence of an individual.

## Seven Criteria[[edit](/w/index.php?title=Cell_Biology/Introduction/What_is_living&action=edit&section=T-1)]

![](//upload.wikimedia.org/wikipedia/commons/3/39/Mitosis.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

A cell undergoing mitosis. Reproduction is one of the seven criteria for life.

In biology, whether life is present is determined based on the following seven criteria:

  1. It should maintain some balanced conditions in its inner structure. This is called **Homeostasis**
  2. Its structure is highly organized.
  3. It should be able to break down or build up nutrients to release or store energy based on need. This is called **Metabolism**
  4. It should _grow_, which means its structure changes as time goes by in an advantageous manner.
  5. It should show adaptation to the environment.
  6. It should be able to respond to environmental stimuli on demand (as opposed to adaptation, which occurs over time).
  7. It should be able to reproduce itself.

Another way of remembering the seven life processes for children is:-
    
    
    Movement
    Respiration
    Sensitivity
    
    Growth
    Reproduction
    Excretion
    Nutrition
    

Note the beginning letter of all the seven life processes, it spells out MRS GREN.

## Virus Controversy[[edit](/w/index.php?title=Cell_Biology/Introduction/What_is_living&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/5/52/Phage.jpg/220px-Phage.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Are these bacteriophages technically alive?

This definition of life has got some problems to it though: As an example, let's take viruses. Just by your intuition, what would you say: Are viruses alive or dead? Most people's intuitive answer is: Viruses are alive. When we suffer from any viral infection, we have the feeling that these viruses that cause or infection are alive. According to the seven principles as shown above, viruses are dead, as dead as a piece of plastic: They can't reproduce themselves. To understand that, we want to make a quick excursion to the replication mechanism of viruses: Viruses are really strange in their reproduction technique. Humans and other animals reproduce by the means of sexual intercourse, bacteria do something called binary fission: They divide. One cell divides itself into two, the two daughter cells divide again an so on. The point here is that both bacteria and animals or humans reproduce actively without any help from outside. Keep this point in mind as we move on two the viruses. Viruses need other cells to reproduce. They "drill" their way into another cell, called the host cell. Here, they release the genetic material they carry and, by a complex mechanism that shouldn't be explained further at this point, force their host cell to produce exact copies of the virus. After some time, the host cell is full of viruses and bursts, releasing the new viruses into the environment. Thus viruses need help to reproduce. They can't reproduce at all without a host cell and therefore do not fulfill the requirement "It should be able to reproduce itself". Looking at the other parts of the definition we find that viruses maintain some degree of homeostasis (1), being able to keep its protenatious and nucleic machinery separated from the outside world. Viruses also show adaptation(5), with their ability to mutate in order to affect new organisms. In addition to the reproduction problem, they also fail to meet the other requirements, showing no cellular organization (2) (or indeed cells at all), metabolism (3), or growth (4).

This example is just to illustrate the problems that arise using this definition. Life is not something one can define as any other technical term in science. Life arose from dead matter around 4 billion years ago. When life can arise from dead matter, there can't be a precise border line between these two.

## The cell is alive, what about parts of it?[[edit](/w/index.php?title=Cell_Biology/Introduction/What_is_living&action=edit&section=T-3)]

Organelles are parts of eukaryotic cells (ones having a nucleus). They help the cell carry out its task. But, are they alive? Do they meet 7 criteria?

When a cell divides into two, organelles also 'reproduce'. They also age from young to old and then die. Some of them carry out the task of taking food, converting it to nutrients and energy. They can also react to stimuli, and surely they can evolve. Of course one can argue that all the above are coordinated by the nucleus. But it seems there are some signs of life there.

Yes, there are! Scientists have proven that some bacteria, in its evolutionary way, had found a home in other cells. They felt comfortable when living there, and gradually, they have become a part of that cell. Chloroplasts, for example, used to be bacteria. At some point in their evolutionary history these cyanobacteria formed a mutual symbiosis with the proto-eukaryote ancestors of algae. Since that time, chloroplasts have been helping plant cells photosynthesize.

Another example is mitochondria, organelles that produce energy for eukaryotes. Very likely a parasitic organism originally, the ancestor of the mitochondria we see today colonized the larger proto-eukarotes. It is unknown if the mitochondrial ancestor originally had a metabolic role in its life cycle or if it adapted to the changing conditions after it was engulfed.

# What is interesting about cell biology?[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=7)]

What makes [Cell Biology](/wiki/Cell_biology) particularly interesting is that there is so much that is not fully understood. A cell is a complex system with thousands of molecular components working together in a coordinated way to produce the phenomenon we call "[life](//en.wikipedia.org/wiki/en:Life)". During the 20th century these molecular components were identified (for example, see [Human Genome Project](//en.wikipedia.org/wiki/en:Human_Genome_Project)), but research continues on the details of cellular processes like the control of [cell division](//en.wikipedia.org/wiki/en:Cell_division) and [cell differentiation](//en.wikipedia.org/wiki/en:Cellular_differentiation). Disruption of the normal control of cell division can cause abnormal cell behavior such as rapid [tumor cell](//en.wikipedia.org/wiki/en:Brain_tumor) growth.

Cells have complex interactions with the surrounding environment. Whether it is the external world of a single celled organism or the other cells of a multicellular organism, a complex web of interactions is present. Study of the mechanisms by which cells respond appropriately to their environments is a major part of cell biology research and often such studies involve what is called [signal transduction](//en.wikipedia.org/wiki/en:Signal_transduction). For example, a hormone such as [insulin](//en.wikipedia.org/wiki/en:Insulin) interacting with the surface of a cell can result in the altered behavior of hundreds of molecular components inside the cells. This sort of complex and finely tuned cell response to an external signal is required for normal metabolism and to prevent metabolic disorders like [Type II diabetes](//en.wikipedia.org/wiki/en:Type_II_diabete).

Most of the cells of a multi-cellular organism have the same [genetic material](//en.wikipedia.org/wiki/en:Genetic_material) in every cell; yet, there may be hundreds of different [types of cells](//en.wikipedia.org/wiki/en:List_of_distinct_cell_in_the_adult_human_body) that make up the organism's body each with its own distinctive shape, size, and function. In any case, all of these cells were developed from one special cell, a [zygote](//en.wikipedia.org/wiki/en:Zygote). The study of how the many cell types develop during embryonic development ([Developmental Biology](//en.wikipedia.org/wiki/en:Developmental_biology)) is a branch of Biology that is heavily dependent on the use of microscopy. Much of the control of cell differentiation is at the level of the control of gene [transcription](//en.wikipedia.org/wiki/en:Transcription_\(genetics\)), the control of which [mRNAs](//en.wikipedia.org/wiki/en:MRNA) are made. Muscle cells make muscle proteins and nerve cells make brain proteins. Geneticists, molecular biologists and cell biologists are working to discover the details of how cells specialize to accomplish hundreds of functions from [muscle](//en.wikipedia.org/wiki/en:Muscle) contraction to [memory](//en.wikipedia.org/wiki/en:Memory) storage.

## Summary[[edit](/w/index.php?title=Cell_Biology/Introduction/Cell_biology%27s_interest&action=edit&section=T-1)]

  * Complexity in: 
    * inter-relations between cells
    * signal transduction pathways inside cells
    * control of cell death and cell reproduction
    * control of cell differentiation
    * control of cell metabolism.

# Types of cells[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=8)]

# Prokaryotes[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=9)]

![](//upload.wikimedia.org/wikibooks/en/thumb/e/e9/Prokaryotes.png/300px-Prokaryotes.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

**The structures of two prokaryotic cells.** The bacterium (shown at the top) is a __heterotrophs_![x+345](//upload.wikimedia.org/math/c/8/0/c8069b2971d086d6daf274c1e37a0c6a.png)_, organisms that eat other organisms. Cyanophytes are _autotrophs_, organisms that make their food without eating other organisms.

Most of these prokaryotic cells are small, ranging from 1 to 20 [microns](//en.wikipedia.org/wiki/micron) with a diameter no greater than 1 micron. The major differences between Prokaryotic and Eukaryotic cells are that prokaryotes do not have a nucleus as a distinct organelle and rarely have any membrane bound organelles [mitochondria, chloroplasts, endoplasmic reticulum, golgi apparatus, a cytoskeleton of microtubules and microfilaments] (the only exception may be a bacterium discovered to have vacuoles). Both types contain DNA as genetic material, have a surrounding cell membrane, have ribosomes[70 s], accomplish similar functions, and are very diverse. For instance, there are over 200 types of cells in the human body, that vary greatly in size, shape, and function.

Prokaryotes are cells without a distinct nucleus.They have genetic material but that material is not enclosed within a membrane. Prokaryotes include bacteria and cyanophytes. The genetic material is a single circular DNA strand and is located within the cytoplasm. Recombination happens through transfers of plasmids (short circles of DNA that pass from one bacterium to another). Prokaryoytes do not engulf solids, nor do they have centrioles or asters. Prokaryotes have a cell wall made up of peptidoglycin.

In majority of prokaryotes, the genome consists of a circular chromosome whose structure includes fewer proteins that found in the linear chromosomes of eukaryotes. Their chromosome is located in the nucleoid, a region of cytoplasm that appears lighter than surrounding cytoplasm in electron micrographs. Also, a single chromosome have much smaller rings of separately replication DNA called plasmids.

## Cell Surface[[edit](/w/index.php?title=Cell_Biology/Cell_types/Prokaryotes&action=edit&section=T-1)]

Prokaryotic cell walls maintain cell shape, provide physical protection, and prevents the cell from bursting in a hypotonic environment. In hypertonic environment, most prokaryotes lose water and shrink away from their wall (plasmolyze). The cell walls of prokaryotes differ in molecular composition and construction from those of eukaryotes. The bacterial cell walls contain peptidoglycan, a network of modified-sugar polymers cross linked by short polypeptides. This molecular fabric encloses the entire bacterium and anchors other molecules that extend from its surface. Archaeal cell walls contain a variety of polysaccharides and proteins but lack peptidoglycan.

**Gram-positive bacteria** have simpler walls with a relatively large amount of peptidoglycan. It has a thick cell wall that traps the crystal violet in the cytoplasm. The alcohol rinse does not remove the crystal violet which masks the added red safanin dye.

**Gram-negative bacteria** have less peptidoglycan and are structurally more complex, with an outer membrane that contains lipopolysaccharides. It has a thinner layer of peptidoglycan, and it is located in a layer between the plasma membrane and an outer membrane. The crystal violet is easily rinsed from the cytoplasm, and the cell appears pink or red.

The cell wall of many prokaryotes is covered by a capsule, a sticky layer of polysaccharide or protein. The capsule enables prokaryotes to adhere to their substrate or to other individuals in a colony. Some capsules protect against dehydration, and some shield pathogenic prokaryotes from attack by their host's immune system. Some prokaryotes stick to their substrate or to one another by means of hair like protein appendages called fimbriae. They are also known as attachment pili. Fimbriae are usually shorter extension of the plasma membrane.

In uniform environment, flagellated prokaryotes move randomly, but in heterogeneous environment, many prokaryotes exhibit taxis, movement toward or away from a stimulus. For example, prokaryotes that exhibit chemotaxis change their movement pattern in response to chemicals. They move toward nutrients or oxygen (positive chemotaxis) or away from a toxic substance (negative chemotaxis).

## Reproduction and Adaptation[[edit](/w/index.php?title=Cell_Biology/Cell_types/Prokaryotes&action=edit&section=T-2)]

Prokaryotes reproduce quickly in a favorable environment. By binary fission, a single prokaryotic cell divid into 2 cells, which then divide into 4, 8, 16, and on. Under optimal conditions, many prokaryotes can divide every 1-3 hours. However the cells eventually exhaust their nutrient supply, poison themselves with metabolic wastes, face competition from other microorganisms, or are consumed by other organisms. The prokaryotes are small, they reproduces by binary fission, and they have short generation times. The ability of some prokaryotes to withstand harsh conditions also contributes to their success. Certain bacteria develop resistant cell called endospores when an essential nutrient is laking. The original cell produces a copy of its chromosome and surrounds it with a tough wall, forming the endospore. Water is removed from the endospore, and its metabolism halt. The rest of the original ell then disintegrates, leaving the endospore behind. Most endospore are so durable that they can survive in boiling water. In less hostile environments, endospore can remain dormant but viable for centuries, able to rehydrate and resume metabolism when their environment improves.

Due to their short generation times, prokaryotic populations can evolve substantially in short periods of time. The ability of prokaryotes to adapt rapidly to new conditions highlights the fact that although the structure of their cells is simpler than that of eukaryotic cells, prokaryotes are not "primitive" or "inferior" in an evolutionary sense. They are highly evolved, and their population have responded successfully to many different types of environmental challenges.

**Rapid reproduction and mutation** In sexually reproducing species, the generation of a novel allele by a new mutation is rare at any particular gene. Instead, most of the genetic variation in sexual populations results from the way existing alleles are arranged in new combinations during meiosis and fertilization. Prokaryotes do not reproduce sexually, so at first glance their extensive genetic variation may seem puzzling.

After repeated rounds of division, most of the offspring cells are genetically identical to the original parent cell; however owing to insertions, deletions, and base-pair substitutions in their DNA, some of the offspring cells may differ genetically. The new mutations, though individually rare, can greatly increase genetic diversity in specie that has short generation times and large population sizes. This diversity, in turn, can lead to rapid evolution: individuals that are genetically better equipped for their local environment tend to survive and reproduce more prolifically than less fit individuals.

## Transformation and Transduction[[edit](/w/index.php?title=Cell_Biology/Cell_types/Prokaryotes&action=edit&section=T-3)]

In transformation, the genotype and possible phenotype of a prokaryotic cell are altered by the uptake of foreign DNA from its surroundings. For example, bacteria from a harmless strain of Streptococcus pneumoniae can be transformed to pneumonia causing cells if they are placed into a medium containing dead, broken-open cells of the pathogenic strain. This transformation occurs when a live nonpathogenic cell takes up a piece of DNA carry the allele for pathogenicity. The foreign allele is then incorporated into the cell's chromosome, replacing the existing nonpathogenic allele- an exchange of homologous DNA segments. The cell is now a recombinant: Its chromosome contains DNA derived from two different cells.

In transduction, bacteriophage carry bacterial genes from one hose cell to another; transduction is a type of horizontal gene transfer. For most phages, transduction results from accidents that occur during the phage reproductive cycle. A virus that carries bacterial DNA may not be able to reproduce because it lacks its own genetic material. However, the virus may be able to attach to another bacterium (a recipient) and inject the piece of bacterial DNA acquired from the first cell (the donor). Some of this DNA may subsequently replace the homologous region of the recipient cell's chromosome by DNA recombination. In such case, the recipient cell's chromosome becomes a combination of NA derived from two cells; genetic recombination has occurred.

**Conjugation and Plasmids** In a process called conjugation, genetic material is transferred between two bacterial cells ( of same or different species) that are temporarily joined. The DNA transfer is one way: One cell donates the DNA,a nd the other receives ti. The donor uses sex pili to attach to the recipient. After contacting a recipient cell, each sex pilus retracts, pulling the two cells together, much like a grappling hook. A temporary "mating bridge" then forms between the two cells, providing an avenue for DNA transfer. In most cases, the ability to form sex pili and donate DNA during conjugation results from the presence of a particular piece of DNA called F factor. The F factor consists about 25 genes, most required for the production of sex pili. The F factor can exist either as a plasmid or as a segment of DNA within the bacterial chromosome

The F factor in its plasmid form is called F plasmid. Cells containing the F plasmid, designated F+ cells, function as DNA donors during conjugation. Cells lacking the F factor, designated F-, function as DNA recipients during conjugation. The F+ condition is transferable in the sense that an F+ cell converts and F- cell to F+ is a copy of the entire F+ plasmid is transferred.

Chromosomal genes can be transferred during conjugation when the donor cell's F factor is integrated into the chromosome. A cell with the F factor built into its chromosome is called an Hfr cell. Like an F+ cell, an Hfr cell functions as a donor during conjugation with an F- cell. When chromosomal DNA from an Hfr cell enters and F- cell, homologous regions of the HFr and F- chromosomes may align, allowing segments of their DNA to be exchanged. This results in the production of a recombinant bacterium that has genes derived from two different cells- a new genetic cariant on which evolution can act. Though theses processes of horizontal gene transfer have so far been studied almost exclusively in bacteria, it is assumed that they are similarly important in archaea.

## Diverse nutritional and metabolic adaptations[[edit](/w/index.php?title=Cell_Biology/Cell_types/Prokaryotes&action=edit&section=T-4)]

The mechanisms discussed in the previous section- rapid reproduction, mutation, and genetic recombination- underlie that extensive genetic variation found in prokaryotic populations. This variation is reflected in the nutritional adaptations found in prokaryotes. Like all organisms, prokaryotes can be categorized by their nutrition; how they obtain every and the carbon used in building the organic molecules that make up cells. Nutritional diversity is greater among prokaryotes than among eukaryotes: Every type of nutrition observed in eukaryotes is represented among the prokaryotes, along with some nutritional modes unique to prokaryotes. Phototrophs are the organisms that obtain energy from light. Chemotrophs are the organisms that obtain energy from chemicals. Organisms that need only an inorganic compound are called autotrophs. Heterotrophs require at least one organic nutrient to make other organic compounds. Combining these possibilities for energy sources and carbon sources results in four major modes of nutrition.

**Phtoautotrophs**: phtosynthetic organisms that capture light energy and use it to drive the synthesis of organic compounds other inorganic carbon compounds. Cyanobacteria and many other groups of prokaryotes are phtoautotrophs, as are plants and algae.

**Chemoautotrophs**: also need only an inorganic compound; however, instead of using light as an energy source, they oxidize inorganic substance, such as hydrogen sulfide, ammonia, or ferrous ions. This mode of nutrition is unique to certain prokaryotes.

**Photoheterotrophs**: Harness energy from light but must obtain carbon in organic form. This mode is unique to certain marine and halophilic (salt-loving) prokaryotes.

**Chemoheterotrphs**: must consume organic molecules to obtain both energy and carbon. This nutritional mode is widespread among prokaryotes. Dungi, animals, most protists, and even some parasitic plants are also chemoheterotrophs.

## The Role of Oxygen In Metabolism[[edit](/w/index.php?title=Cell_Biology/Cell_types/Prokaryotes&action=edit&section=T-5)]

Prokaryotic metabolism also caries with respect to oxygen. Obligate aerobes use oxygen for cellular respiration and cannnot grow without it. Obligate anaerobes, however, are posioned by oxygen. Some obligate anaerobes live exclusively by fermentation; other extract chemical energy by anaerobic respiration, in whcih substance other than oxygen such as nitrate ions or sulfate ions accept electrons at the "downhill" end of electron transport chains. Facultative anaerobes use oxygen if it is present but can also carry out anaerobic respiration or fermentation in an anaerobic environment.

**Nitrogen Metabolism** Nitrogen is essential for the production of amino acids and nucleic acids in all organisms. Whereas eukaryotes can obtain nitrogen from only a limited group of nitrogen compounds, prokaryotes can metabolize nitrogen in a wide variety of forms. For example, some cyanobacteria and some methanogens covert atmospheric nitrogen to ammonia, a process called nitrogen fixation. The cells can then incorporate this "fixed" nitrogen into amino acids and other organic molecules. In terms of their nutrition, nitrogen-fixing cyanobacteria are some of the most self-sufficient organisms, since they need only light, carbon dioxide, nitrogen, water and some minerals to grow. Nitrogen fixation by prokaryotes has a large impact on other organisms. For example, nitrogen -fixing prokaryotes can increase the nitrogen but can use the nitrogen compounds that the prokaryotes produce from ammonia.

**Metabolic Cooperation** Cooperation between prokaryotes allows them to use environmental resource they could not use as individual cells. In some cases, this cooperation takes place between specialized cells of a colony. For instance, the cyanobacterium Anabaena has genes than encode proteins for photosynthesis and for nitrogen fixation, but a single cell cannot carry out both processes at the same time. The reason is that photosynthesis produces oxygen which inactivates the enzymes involved in nitrogen fixation. Instead of living as isolated cells, anabaena forms filamentous colonies synthesis while a few specialized cells called heterocytes carry out only nitrogen fixation. Each heterocyte is surrounded by a thickened cell wall that restricts entry of oxygen produced by neighboring photosynthetic cells. Intercellular connections allow heterocytes to transport fixed nitrogen to neighboring cells and to receive carbohydrates.

Metabolic cooperation between different prokaryotic species often occurs in surface-coating colonies known as biofilms. Cells in a biofilm secrete signaling molecules that recruit nearby cells, causing the colonies to grow. The cells also produce proteins that stick the cells to the substrate and on to another. Channels in the biofilm allow nutrients to reach cells in the interior and wastes to be expelled. Biofilm damage industrial and medical equipment, contaminate products, and contribute to tooth decay and more serious health problems. In another example of cooperation between prokaryotes, sulfate-consuming bacteria coexist with methane-consuming archaea in ball- shaped aggregates on the ocean floor. The bacteria appear to use the archaea's waste products, such as organic compounds and hydrogen. In turn, the bacteria produce compounds that facilitate methane consumption by the archaea. This partnership has global ramifications.

## Reference[[edit](/w/index.php?title=Cell_Biology/Cell_types/Prokaryotes&action=edit&section=T-6)]

Berg, Jeremy M., John L. Tymoczko, and Lubert Stryer. Biochemistry. 7th ed. New York: W.H. Freeman, 2012. Print.

Reece, Campbell, Lisa A. Urry, Michael L. Cain, Steven A. Wasserman, Peter V. Minosky, and Robert B. Jackson. Biology. 8th ed. San Francisco: Cummings, 2010. Print.

  


### See also[[edit](/w/index.php?title=Cell_Biology/Cell_types/Prokaryotes&action=edit&section=T-7)]

[Eukaryotes](/w/index.php?title=Cell_Biology/Eukaryotes&action=edit&redlink=1)

# Bacteria[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=10)]

Bacteria are prokaryotic, unicellular organisms. Bacteria are very small; so much so that 1 billion could fit on 1 square centimeter of space on the human gums, and 1 gram of digested food has 10 billion bacteria. Bacteria are the simplest living organisms. Previously they fell under the Kingdom Moneran, but now they fall into two different Domains: Archaebacteria and Eubacteria. There are several differences between the two. Typically, microbiologists in the 21st century call these groups "Archaea" and "Bacteria." One of the co-discoverers of the three Domains has argued that the term "prokaryote" should be removed from classrooms because it reflects an evolutionary hypothesis that has been disproved, given that the Archaea are more closely related to the Eukarya than they are to the Bacteria (Pace 2006, _Nature_ 441 p. 289).

It is incorrect to think of bacteria as particularly "simplistic" for all that they do not have internal organelles that can be visualized using a light microscope. The bacterial nucleoid, for example, is a highly organized structure even though it typically contains just one or two circular chromosomes with a total of millions of basepairs of DNA (Thanbichier et el., 2005, _J Cell. Biochem._ 96:506-521; see also [http://www.microbelibrary.org/Laboratory%20Diagnostics/details.asp?id=782&Lang=English](http://www.microbelibrary.org/Laboratory%20Diagnostics/details.asp?id=782&Lang=English)). Bacteria have complex cell walls exterior to the cell membrane. Some bacteria contain plasmids, which are typically circular DNA with replication that is uncoupled from binary fission (cellular division). Plasmids in nature often encode traits of significant interest to humans, such as the ability to be resistant to clinically important antibiotics, or the ability to degrade "odd" carbon sources such as TNT or human-made pollutants. Plasmids from _Escherichia coli_ have been "domesticated" and have long been in use for genetic engineering, as it is easier to isolate and modify plasmid DNA, and introduce it into a new cells, than it is to modify a bacterial chromosome (see "Techniques" at dnai.org; see also [http://www.microbelibrary.org/Laboratory%20Diagnostics/details.asp?id=707&Lang=English](http://www.microbelibrary.org/Laboratory%20Diagnostics/details.asp?id=707&Lang=English)). A few phylogenetic groups of bacteria can make endospores, which are metabolically inert but are able to resist high temperatures, radiation, and desiccation (see [http://www.microbelibrary.org/Laboratory%20Diagnostics/details.asp?id=2511&Lang=English](http://www.microbelibrary.org/Laboratory%20Diagnostics/details.asp?id=2511&Lang=English)).

Bacterial reproduction is always asexual and usually occurs through binary fusion, once thought to be a simple process of growing and dividing. Microbiologists now know, however, that binary fission is complex in that it requires dozens of proteins cooperating to build the septum (new cell wall between 'daughter' cells) and to actively separate the two daughter chromosomes. Furthermore, there are other forms of reproduction in bacteria, all of them "asexual" in that they do not use gametes or involve genetic exchange (Angert 2005, _Nature Reviews Microbiology_ 3:214-224). Genetic exchange in bacteria is instead called horizontal (or lateral) gene transfer, because bacteria can obtain genetic information from organisms that are not their parents (Amabile-Cuevas 2003, American Scientist 91:138-149). (Vertical genetic transmission is the inheritance of DNA down through the generations.) Horizontal gene transfer can happen any time and has nothing to do with cell division. There are three main types, conjugation which is the sharing of plasmid DNA; transduction, where a bacterial virus accidentally transfers bacterial DNA from one bacterium to another, and transformation, where bacteria bind to DNA in the environment, internalize it, and can use that DNA as genetic material.

## Archaea[[edit](/w/index.php?title=Cell_Biology/Cell_types/Bacteria&action=edit&section=T-1)]

Archaea are microbes that are more closely related to Eukaryotic cells than they are to the Bacteria (<http://tolweb.org/tree/home.pages/aboutoverview.html>). Under a light microscope, they visually resemble Bacteria, so that it wasn't until the advent of the use of molecular methods in evolutionary biology that they were recognized as belonging to their own Domain (a phylogenetic grouping above the level of Kingdom). Archaea have ultrastructural features that are superficially similar to those in Bacteria but are usually comprised of distinctive molecules. They do, for example, have a cell wall, yet that cell wall never contains peptidoglycan. Instead, peptidoglycan is a unique molecular signature of the Bacteria. Archaea also have odd lipids in their cell membranes. They were originally discovered living in extreme environments thought to resemble conditions on early earth, but now that microbiologists have become more adept at detecting them, it is clear that the Archaea are not confined to extreme habitats and can instead be found everywhere. It is true that some Archaea are "extremophiles," found in extremely salty or hot environments, but there are also extremophile Bacteria and even some very unusual extremophile Eukarya. The best-understood groups of Archaea are:

  1. _Methanogens_ use Carbon dioxide and Hydrogen to make Methane. They are found in sewage, cows, and swamps, and they do not take in oxygen.
  2. _Extreme Halophiles_ live in extremely salty places (i.e.: the dead sea and great salt lake).
  3. _Thermoacidophiles_ prefer extremely hot, acidic areas (i.e.: hot springs and volcanos).

## Bacteria[[edit](/w/index.php?title=Cell_Biology/Cell_types/Bacteria&action=edit&section=T-2)]

(sometimes called "eubacteria")

Bacteria have peptidoglycan in their cell walls, and they have no unusual phospholipids. Bacteria have four shapes:

  * bacilli (rod shaped)
  * vibrios (curved shaped)
  * coccus (round shaped)
  * spirilli (spiral shaped).

Bacteria can also have prefixes before their names: strepto, indicating chains of the shaped bacteria, and staphylo, indicating clusters of the shaped bacteria. A 19th century microbiologist invented the Gram stain, still used today to differentiate bacteria into two types, Gram negative and Gram positive (<http://en.wikipedia.org/wiki/Hans_Christian_Gram>). These types are not useful in determining phylogeny but can be very useful in a clinical setting, because Gram negative and Gram positive bacteria can exhibit differential sensitivity to some classes of antibiotics. There are probably dozens of "Kingdoms" within the Domain Bacteria, but the phylogeny of Bacteria is still disputed as microbiologists continue to study the evolution of bacteria using molecular methods. Some of the major types of Bacteria are:

  1. Cyanobacteria are photoautotrophs that strip electrons from water and use them to fix carbon dioxide; they are a major source of organic carbon in marine ecosystems.
  2. Spirochetes are Gram negative bacteria that have flexible cells and internal flagella in an unusual form of a more typical Gram negative cell wall.
  3. Proteobacteria (E-coli)

Some bacteria produce virulence factors that can cause sickness. Some examples of these are serotoxins, which are given off by the Gram positive bacteria, and endotoxins, which are given off by Gram negative bacteria as they die. There are many other examples, however, and specific pathogens make a unique suite of virulence factors that lead to the particular disease caused by that pathogen.

# Eukaryotes[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=11)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Diagram_of_an_animal_cell_in_three_dimensions.png/220px-Diagram_of_an_animal_cell_in_three_dimensions.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

An animal Cell

**Eukaryotes** house a distinct nucleus, a structure in which the genetic material (DNA) is contained, surrounded by a membrane much like the outer cell membrane. Eucaryotic cells are found in most algae, protozoa, all multicellular organisms (plants and animals) including humans. The genetic material in the nucleus forms multiple chromosomes that are linear and complexed with proteins that help the DNA 'pack' and are involved in regulation of gene expression.

The cells of higher plants differ from animal cells in that they have large vacuoles, a cell wall, chloroplasts, and a lack of lysosomes, centrioles, pseudopods, and flagella or cilia. Animal cells do not have the chloroplasts, and may or may not have cilia, pseudopods or flagella, depending on the type of cell.

## Comparing Prokaryotic and Eukaryotic Cells[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-1)]

All cells have several basic features in common: they are all bounded by a selective barrier, plasma membrane. Cytosol is a jellylike substance that is semifluid. All cells contain chromosomes which carry genes in the form of DNA, and ribosomes that make proteins according to instructions from the gene. The major difference between prokaryotic and eukaryotic cels is the location of their DNA. In eukaryotic cell, DNA is found at the nucleus, which is bounded by a double membrane. (the word eukaryotic is from the Greek eu, true, and karyon, kernel, here referring to the nucleus).

Eukaryotic cells are much larger than prokaryotic cells; size is general aspect of cell structure that relates to function. The logistics of carrying out cellular metabolism sets limits on cell size. At the lower limit, the smallest cells, known are bacteria called mycoplasmas have diameters between 0.1 and 1.0mm. These are the smallest packages with enough DNA to program metabolism and enough enzymes and other cellular equipment to carry out the activities necessary for a cell to sustain itself and reproduce.

Metabolic requirements also impose theoretical upper limits on the size that is practical for a singel cell. Plasma membrane functions as a selective barrier that allows sufficient passage of oxygen, nutrients, and wastes to service the entire cell. For each square micrometer of membrane, only a limited amount of a particular substance can cross per second, so the ratio of surface area to volume is critical. As a cell increases in size, its volume grows proportionately more than its surface area. Area is proportional to a linear dimension squared, whereas volume is proportional to the linear dimension cubed. Therefore a smaller object has a greater ration of surface area to volume.

The need for a surface area sufficiently large to accommodate the volume helps explain the microscopic size of most cells, and the narrow, elongated shapes of others, such as nerve cells. Larger organisms has more cells compare to smaller cells. High ratio of surface area to volume is especially important in cells that exchange a lot of material with their surroundings such as intestinal cells. Such cells may have many long, thin projections from their surface called microvilli, which increase surface area without an appreciable increase in volume.

## Animal Cells[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-2)]

**Flagellum**: locomotion organelle present in some animal cells; composed of a cluster of microtubules within an extension of the plasma membrane.

**Centrosome**: region where the cell's microtubules are initiated contains a pair of centrioles which function is unknown.

**Cytoskeleton**: reinforces cell's shape, functions in cell movement components are made of protein. It includes microfilaments, intermediate filaments, and microtubules.

**Microvilli**: projections that increase the cell's surface area.

**Peroxisome**: organelle with carious specialized metabolic functions; produces hydrogen peroxide as a by-product, then converts it to water.

**Mitochondrion**: organelle where cellular respiration occurs and most ATP is generated.

**Lysosome**: digestive organelle where macromolecules are hydrolyzed.

**Golgi apparatus**: organelle active in synthesis, modification, sorting, and secretion of cell products.

**Ribosomes**: complexes (small brown dots) that make proteins; free in cytosol or bound to rough ER or nuclear envelope.

**Plasma membrane**: membrane enclosing the cell

**Endoplasmic Reticulum (ER)**: network of membraneous sacs and tube; active in membrane synthesis and other synthetic and metabolic processes; has rough (ribosome-studded) and smooth regions. (Rough ER, and Smooth ER)

**Nucleus**: nucleus contains:
    
    
                     _Nuclear envelope: double membrane enclosing the nucleus; perforated by pores; continuous with ER_
                     _Nucleolus_: structure involved in production of ribosomes; a nucleus has one or more nucleoli
                     _Chromatin_: material consisting of DNA and proteins; visible as individual chromosomes in a dividing cell
    

In animal cells, lysosomes, centrosomes with centrioles, and flagella are present but not in plant cells.

## Plant Cell[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-3)]

**Cell Wall**: outer layer that maintains cell's shape and protects cell from mechanical damage; made of cellulose, other polysaccharide, and protein.

**Plasmodesmata**: channels through cell walls that connect the cytoplasms of adjacent cells.

**Chloroplast**: photosynthetic organelle; converts energy of sunlight to chemical energy stored in sugar molecules.

**Central vacuole**: prominent organelle in older plant cells; functions include storage, breakdown of waste products, hydrolysis of macromolecules; enlargement of vacuole is a major mechanism of plat growth.

**Nucleus**: nucleus contains:
    
    
                     _Nuclear envelope: double membrane enclosing the nucleus; perforated by pores; continuous with ER_
                     _Nucleolus_: structure involved in production of ribosomes; a nucleus has one or more nucleoli
                     _Chromatin_: material consisting of DNA and proteins; visible as individual chromosomes in a dividing cell
    

**Golgi apparatus**: organelle active in synthesis, modification, sorting, and secretion of cell products.

**Endoplasmic Reticulum (ER)**: network of membraneous sacs and tube; active in membrane synthesis and other synthetic and metabolic processes; has rough (ribosome-studded) and smooth regions. (Rough ER, and Smooth ER)

**Ribosomes**: complexes (small brown dots) that make proteins; free in cytosol or bound to rough ER or nuclear envelope.

**Cytoskeleton**: reinforces cell's shape, functions in cell movement components are made of protein. It includes microfilaments, intermediate filaments, and microtubules.

In plant cell, chloroplasts, central vacuole, cell wall, and plasmodesmata are present but not in animal cells.

## Nucleus[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-4)]

The nucleus contains most of the genes in the eukaryotic cell; some genes are located in mitochondria and chloroplast. It is generally the most conspicuous organelle in a eukaryotic cell. The nuclear envelope encloses the nucleus, sparating its contents from the cytoplasm. The nuclear envelope is a double membrane, each a lipid bilayer with associated proteins. The envelope is perforated by pore structure that are about 100nm in diameter. At the lip of each pore, the inner and outer membranes of the nuclear envelope are continuous. Pore complex lines each pore and regulates the entry and exit of most proteins and RNAs, as well as large complexes of macromolecules. Except at the pores, the nuclear side of the envelope is lined by the nuclear lamina, a netlike array of protein filaments that maintains the shape of the nucleus by mechanically supporting the nuclear envelope. Also nuclear matrix, a framework of fibers extending throughout the nuclear interior, present.

Chromosomes are organized DNA units that carry the genetic information. Each chromosome is made up of material called chromatin, a complex of proteins and DNA. Stained chromatic usually appears as a diffuse mass, byt as a cell prepares to divide, the thin chromatin fibers coil up and condense thick enough to be distinguished as chromosomes. Each eukaryotic species has a characteristic number of chromosomes. For example human has 46 chromosomes.

Nucleolus is a prominent structure within the nondividing nucleus. Ribosomal RNA (rRNA) is synthesized from instructions in the DNA; in nucleolus, proteins imported from the cytoplasm are assembled with rRNA into large and small ribosomal subunits. Theses subunits then exit the nucleus through the nuclear pores to the cytoplasm, where a large and a small subunit can assemble into a ribosome. the number depends on the species and the stage in the cell's reproductive cycle.

The Nucleus directs protein synthesis by synthesizing messenger RNA (mRNA) according to instructions provided by the DNA. The mRNA is then transported to the cytoplasm via the nuclear pores. Once an mRNA molecule reaches the cytoplasm, ribosomes translate the mRNA's genetic message into the primary structure of a specific poly peptide.

## Ribosomes[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-5)]

Ribosomes are complexes made of ribosomal RNA and protein; ribosomes are the cellular components that carry out proteins synthesis, also known as protein factories. Cells that have high rates of protein synthesis have particularly large number of ribosomes. Cells active in protein synthesis also have prominent nucleoli. Ribosomes build proteins in two cytoplasmic locales. Free ribosomes are suspended int he cytosol, while bound ribosomes are attached to the outside of the endoplasmic reticulum or nuclear envelope. Bound and free ribosomes are structurally identical, and ribosomes can alternate between the two roles. Most of proteins are made on free ribosomes function within the cytosol. Bound ribosomes generally make proteins that are destined for insertion into membranes, for packaging within certain organelles such as lysosomes, or for export from the cell (secretion).

## The Endomembrane System[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-6)]

Endomembrane system carries out a variety of tasks in the cell. These tasks include synthesis of proteins and their transport into membranes and organelles or out of the cell, metabolism and movement of lipids, and detoxification of poisons. The membrane of this system are related either through direct physical continuity or by the transfer of membrane segments as tiny vesicles. The various membranes are not identical in structure and function; the thickness, molecular composition, and types of chemical reactions carried out in a given membrane are not fixed but modified several times during the membrane's life. The endomembrane system includes the nuclear envelope, the endoplasmic reticulum, the Golgi apparatus, lysosomes, various kinds of vacuoles, and the plasma membrane.

## Endoplasmic Reticulum (ER)[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-7)]

**Endoplasmic reticulum (ER)** is an extensive network of membrane that it accounts for more than half the total membrane in many eukaryotic cells. The word endoplasmic means "within the cytoplasm", and reticulum is Latine for "little net". The ER consists of a network of membranous tubules and sacs called cisternae. The ER membrane separates the internal compartment of the ER, ER lumen (cavity) or cisternal space, from the cytosol. Since ER membrane is continuous with the nuclear envelope, the space between the two membranes of the envelope is continuous with the lumen of the ER. Smooth ER lacks ribosomes on its outer surface, and Rough ER has ribosomes on the outer surface of the membrane. Ribosomes are also attached to the cytoplasmic side of the nuclear envelope's outer membrane.

**Smooth ER**\- The smooth ER functions in diverse metabolic processes, which vary with cell type. Theses processes include synthesis of lipids, metabolism of carbohydrates, and detoxification of drugs and poisons. Enzymes of the smooth ER are important in the synthesis of lipids, including oils, phospholipids, and steroids. Sex hormones of vertebrates and the various steroid hormones are produced by the smooth ER in animal cells. Other enzymes of the smooth ER help detoxify drugs and poisons in liver cells. Detoxification involves adding hydroxyl groups to drug molecules, making them more soluble and easier to flush from the body. For example, sedative phenobarbital and other barbiturates are the drugs that metabolized in this manner by smooth ER in liver cells. Barbiturates, alcohol, and many other drugs induce the proliferation of smooth ER and its associated detoxification enzymes, therefore, increasing tolerance to the drugs; in other words, higher doses are required to achieve a particular effect. Also, because some of the detoxification enzymes have relatively broad action, the proliferation of smooth ER in response to one drug can increase tolerance to other drugs as well. The smooth ER also stores calcium ions; in muscle cells, a specialized smooth ER membrane pumps calcium ions from the cytosol into the ER lumen. When a muscle cell is stimulated by a nerve impulse, calcium ions rush back across the ER membrane into the cytosol and trigger contraction of the muscle cell.

**Rough ER**\- Many times of cells secrete proteins produced by ribosomes attached to rough ER. As a polypeptide chain grows from a bound ribosomes, it is threaded into the ER lumen through a pore formed by a protein complex in the ER membrane. As the new protein enters the ER lumen, it folds into its native shape. Most secretory proteins are glycoproteins, which have carbohydrates covalently bonded to them. After secretory proteins are formed, the ER membrane keeps them separate from proteins that are produced by free ribosomes and will remain in the cytosol. Secretory proteins depart from the ER wrapped in the membranes of vesicles that bud like bubbles from a specialized region called transitional ER. Transport vesicles are the vesicles in transit from one part of the cell to another. Rough ER is also a membran factory for the cell; it grows in place by adding membrane proteins and phospholipids to its own membrane. As polypeptide destined to be membrane proteins grow fromt he ribosomes, they are inserted into the ER membrane and are anchored there by their hydrophobic portions. The rough ER makes its own membrane phospholipids; enzymes buil into the ER membrane assemble phospholipids from precursors in the cytosol. The ER membrane expands and is transferred in the form of transport vesicles to other components of the endomembrane system.

## Golgi Apparatus[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-8)]

Golgi is a center of manufacturing, warehousing, sorting, and shipping. The products of the ER are modified and stored and then sent to other destinations. Golgi apparatus is extensive in cells specialized for secretion. The Golgi apparatus consists of flattened membranous sac, cisternae. The membrane of each cisterna in a stack separates ints internal space from the cytosol. Besicles concentrated in the vicinity of the Golgi apparatus are engaged in the transfer of material between parts of the Golgi and other structures. Golgi stack has a distinct structural polarity with the membrane of cisternae on opposite side of the stack different in thickness and molecular composition. The two poles of a Golgi stack are referred to as the cis face and the trans face; cis is the receiving and trans is shipping departments of the Golgi apparatus. The cis face is usually located near ER. Transport vesicles move material from the ER to the Golgi apparatus. A vesicle that buds from the ER can add its membrane and the contents of its lumen to the cis face by fusing with a Golgi membrane. The trans face give rise to vesicles, which pinch off and travel to other sites. The products of ER are usually modified during their transit from the cis region to the trans region of the Golgi. Various Golgi enzymes modify the carbohydrate portions of glycoproteins; carbohydrates are first added to proteins int he rough ER during the process of polypeptide synthesis. The carbohydrate on the resulting glycoprotein is then modified as it passes through the rest of the ER and the Golgi. The Golgi removes some sugar monomers and substitutes other, producing a large variety of carbohydrates. In addition, the Golgi apparatus manufactures certain macromolecules by itself. Many polysaccharides secreted by cells are Golgi products, including pectins and certain other non-cellulose polysaccharides made by plant cells and incorporated along with cellulose into their cell walls. Similar to secretory proteins, non-protein Golgi products will be secreted depart from the trans face of the Golgi inside transport vesicles that eventually fuse with the plasma membrane.

The Golgi manufactures and refines its products in stages, with different cisternae containing unique teams of enzymes. Recent research has give rise to a new model of the Golgi as a more dynamic structure; According to the cisternal maturation model, the cisternae of the Golgi actually progress forward from the cis to the tras face of the Golgi, carrying and modifying their cargo as they move. Before a Golgi stack dispatches its products by budding vesicles fromt he trans face, it sorts these products and targets them for various parts of the cell. Molecular identification tags, such as phosphate groups added to the Golgi products, aid in sorting. Transport vesicles budded fromt he Golgi may have external molecules on their membranes that recognize "docking site" on the surface of specific organelles or on the plasma membrane, therefore, targeting the vesicle appropriately.

## Lysosomes[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-9)]

Lysosome is a membranous sac of hydrolytic enzymes that an animal cell uses to digest macromolecules. Lysosomal enzymes work best in the acidic environment found in lysosomes. If a lysosome breaks open or leaks its contents, the released enzymes are not very active because the cytosol has a neutral pH. However, excessive leakage from a large number of lysosomes can destroy a cell by autodigestion. Hydrolytic enzymes and lysosomal membrane are made by rough ER and then transferred to the Golgi apparatus for further processing. Proteins of the inner surface of the lysosomal membrane and the digestive enzymes are spared from destruction by having three dimensional shapes that protect vulnerable bonds from enzymatic attack.

Phagocytosis is a process that amoebas and many other protists eat by engulfing smaller organisms or other food particles. The food vacuole formed , and then fuses with a lysosome and digests the food. Digestion products pass into cytosol and become nutrients for the cell. In human body, white blood cell helps defend the body by engulfing and destroying bacteria and other invaders.

Lysosome use their hydrolytic enzymes to recycle the cell's own organic material; this is called autophagy. During autophagy, damaged organelle or small amount of cytosol become surrounded by a double membranes, and lysosome fuses with the outer membrane of their vesicle. The lysosomal enzymes dismantle the enclosed material, and the organic monomers are returned to the cyotosol for reuse. The lysosomes become engorged with indigestible substrates, which begin to interfere with other cellular activities.

## Vacuoles[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-10)]

Vacuoles are membrane-bounded vesicles whose functions vary in different kinds of cells. Food vacuoles are formed by phagocytosis. Many freshwater protists have contractile vacuoles that pump excess water out of the cell, thereby maintaining a suitable concentration of ions and molecules inside the cell. In plants and fungi, which lacks lysosomes, vacuoles carry out hydrolysis;

The central vacuole develops by the coalescence of smaller vacuoles, themselves derived from the endoplasmic reticulum and Golgi apparatus. The vacuolar membrane is selective in transportin solutes. As result, the solution inside the central vacuole is called cell sap, is different in composition from the cytosol. It can hold reserves of important organic compounds such as proteins stockpiled in the vacuoles of storage cells in seeds. Also it is the plant cell's main repository of inorganic ions, such as potassium and chloride. Many plant cells use their vacuoles contain pigments that color the cells. Vacuoles may also help protect the plant against predators by containing compounds that are poisonous or unpalatable to animals. The vacuole has a major role in the growth of plant cells, which enlarge as their vacuoles absorb water, enabling the cell to become larger with a minimal investment in new cytoplasm.

## Mitochondria and Chloroplasts[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-11)]

Mitochondria and chloroplasts are the organelles that convert energy to forms that cells can use for work. Mitochondria are the site of cellular respiration, the metabolic process that generates ATP by extracting energy from sugars, fats, and other fuels with the help of oxygen. Chloroplasts, are found in plants and algae, and they are the sites of photosynthesis. They convert solar energy to chemical energy by absorbing sunlight and using it to drive the synthesis of organic compounds such as sugar from carbon dioxide and water. Both of them are not part of endomembrane system. Mitochondria have two membrane separating their innermost space from the cytosol, and chloroplasts have three. The membrane proteins of mitochondria and chloroplasts are made not by ribosomes bound to the ER, but by free ribosomes in the cyotosol and by ribosomes contained within these organelles themselves. They also contain small amount of DNA that programs the synthesis of the proteins made on the organelle's ribosomes. Mitochondria and chloroplasts are semiautonomous organelles that grow and reproduce within the cell.

**Mitochondria** Mitochondria are found in all eukaryotic cells; Some cells have a singel large mitochondrion, but more often a cell has hundreds or thousands of mitochondria. The number correlates with he cell's level of metabolic activity. The mitochondrion is enclosed by two membranes, each a phospholipid bilayer witha unique collection of embedded proteins. The outer membrane is smooth, but the inner membrane is convoluted, with infolding called cristae. The inner membrane divides the mitochondrion into two internal compartments. The first is the inter-membrane space, the narrow region between the inner and outer membranes. The second compartment, the mitochondrial matrix, is enclosed by the inner membrane. the matrix contains many different enzymes as wellas the mitochondrial DNA and ribosomes. Enzymes in the matrix catalyze some steps of cellular respiration. Other proteins that function in respiration, including the enzyme that makes ATP are built into the inner membrane, As highly folded surface, the cristae give the inner mitochondrial membrane a large surface ares, thus enhancing the productivity of cellular respiration.

**Chloroplasts** The chloroplast is a specialized member of related plant organelles called plastids. Chloroplasts contain the green pigment chlorophyll, along with enzymes and other molecules that function in the photosynthetic production of sugar. Its shape is lens-shaped and found in leaves. The contents of a chloroplast are partitioned from the cytosol by an envelope consisting of two membranes separated by a very narrow intermembrane space. Inside the chloroplast is another membranous system in the form of flattened, intern=connected sacs called thylakoids. Thylakoids are stacked like poker ships, and each stack is called granum. The fluid outside the thylakoids is the stroma which contains the chloroplast DNA and ribosomes as well as many enzymes. The membranes of the chloroplast divide the chloroplast space into three compartments: the intermembrane space, the stroma, and the thylakoid space.

## Cytoskeleton[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-12)]

Cytoskeleton is a network of fibers extending throughout the cytoplasm. It plays a major role in organizing the structure and activities of the cell. It is composed of three types of molecular structure: microtubules, microfilaments, and intermediate filaments. The main function of the cytoskeleton is to give mechanical support to the cell and maintain its shape. Cytoskeleton is stabilized by balance between opposing forces exerted by its elements. The cytoskeleton is more dynamic than an animal skeleton; it can be quickly dismantled in one part of the cell and reassembled in a new location, changing the shape of the cell. Also several types of cell motility involve the cytoskeleton. the cell motility encompasses both changes in cell location and more limited movements of parts of the cell. Cell motility require the interaction of the cytoskeleton with motor proteins. Cytoskeletal elements and motor proteins work together with plasma membrane molecules to allow whole cells to move along fibers outside the cell. The cytoskeleton is also involved in regulating biochemical activities in the cell in response to mechanical stimulation forces exerted by extracellular molecules via cell-surface proteins are apparently transmitted into the cell by cytoskeletal elements, and the forces may even reach the nucleus.

**Microtubules**\- thickest

All eukaryotic cells have microtubules; the wall of the hollow tube is constructed from a globular protein called tubulin. Each tubulin protein is a dimer, a molecule made up of two subunits. A tubulin dimer consists of two slightly different polypeptides, alpha-tublin, and beta-tubulin. Microtubules grow in length by adding tubulin dimers. Due to the architecture of a microtubules, its two ends are slightly different; one end can accumulate or release tubulin dimers at a much higher rate than the other, therefore, growing and shrinking significantly during cellular activities. This is called the "plus end", not because it can only add tubulin proteins but because it's the end where both "on" and "off" rates are much higher. Microtubules shape and support the cell and also serve as tracks along which organelles equipped with other proteins can move.

In animal cells, microtubules grow out from a centrosomes, a region that is often located near the nucleus and considered a "microtubule-organizing center". Theses microtubules function as compression-resisting girders of the cytoskeleton. Within the centrosome are a pair of centrioles, each composed of nine sets of triplet microtubules arrange in a ring. Before division, the centrioles replicate; although centrosomes with centrioles may help organize microtubule assembly in animal cell,s they are not essential for this function in all eukaryotes.

Also specialized arrangement of microtubules is responsible for the beating of flagella and cilia. Thees are microtubule containing extensions that project from some cells. When cilia or flagella extend from cells that are held in place as part of a tissue layer, they can move fluid over the surface of the tissue. Flagella and cilia different in their beating patterns. A flagellum has an undulating motion that generates force in the same direction as the flagellum's axis. However cilia work more like oars, with alternating power and recovery strokes generating force in a direction perpendicular to the cilium's axis. A cillium may also act as a signal-receiving "antenna" for the cell. Cilia that have this function are nonmotile, and there is only one per cell. Membrane proteins on this kind of cilium transmit molecular signals from the cell's movement to its interior, triggering signaling pathways that may lead to changes int he cell's activities. Cillia-based signaling appears to be crucial to brain function and to embryonic development. Motile cilia and flagella share a common ultrastructure; each has a core of microtubules sheathed in an extension of the plasma membrane. Nine doublets of microtubules, the members of each parit sharing part of their walls, are arranged in a ring. This arrangement, referred to as the "9+2" pattern, is found in all eukaryotic flagella and motile cilia. Non-motile primary cilia have "9+0" pattern, lacking the central pari of microtubules. The microtubule assembly of a cilium or flagellum is anchored in the cell by a basal body, which is structurally very similar to a centriole.

In flagella and motile cilia, flexible cross-linking proteins, evenly spaced along the length of the cilium or falgellum, connect the outer doublets to each other and to the two central microtubules Each outer doublet also has paris of protruding proteins spaced along its length and reaching toward the neighboring doublet; These are large motor proteins called dyneins, composed of several polypeptides. Dyneins are responsible for the bending movements of the organelle. A dynein molecule performs a complex cycle of movements cause by changes in these shape of the proteins, with ATP providing the energy for these changes. The mechanics of dynein-based bending involve a process that resembles walking. A typical dynein protein has two "feet" that "walk" along the microtubule of the adjacent doublet, one foot maintaining contact while the other releases and reattaches one step further along the microtubules. Without any restraints ont he movement of the microtubules doublets, one doublet would continue to "walk" along and slide past the surface of the other, elongating the cilium or flagellum rather than bending it.

**Microfillaments**\- thinnest

Microfilaments are solid rods about 7nm in diameter. They are also called as actin filaments because they are build from molecules of actin, a globular protein. A microfilament si a twisted double chain of actin subunits. Microfilaments can form structural networks, due to the presence of proteins that bind along the side of an actin filament and allow a new filament to extend as a branch. The structure role of microfilaments in the cytoskeleton is to bear tension. A cortical microfilaments, a three-dimensional network formed by microfilaments just inside the plasma membrane, helps support the cell's shape. This network give the outer cytoplasmic layer of a cell called the cortex.

In animal cells specialized for transporting materials across the plasma membrane, such as intestinal cells, bundles of microfilaments make up the core of microvilli. Microfillaments are well known for their role in cell motility, particularly as part of the contractile apparatus of muscle cells (myosin). Localized contraction brought about by actin and myosin also plays a role in amoeboid movement, which a cell such as an amoeba crawls along a surface by extending and flowing into cellular extension called pseudopodia. pseudopodia extend and contract through the reversible assembly of actin subunits nto microfilaments and of microfillaments into networks that convert cytoplasm fro a sol to a gel. The pseudopodium extends until the actin reassembles into a network.

In plant cells, both actin-myosin interactions and sol-gel transformations brought about by actin may be involved in cytoplasmic streaming, a circular flow of cytoplasm within cells.

**intermediate filaments**\- middle range intermediate filaments are larger than the diameter of microfilaments but smaller than that of microtubules. Specialized for bearing tension (like microfilaments), intermediate filaments are a diverse class of cytoskeletal elements. Each type is constructed from a different molecular subunit such as keratins. Intermediate filaments are more permanent fixture of cells than are microfilaments and microtubules. Even after the death of the cell, intermediate filament networks often persist. Intermediate filaments are important in reinforcing the shape of a cell and fixing the position of certain organelles. For instance, the nucleus commonly sits within a cage made of intermediate filaments, fixed in location by braches of the filaments that extend into the cytoplasm. Other intermediate filaments make p the nuclear lamina that lines the interior of the nuclear envelope. In case where the shape of the entire cell is correlated with function, intermediate filaments support that shape.

## Cell Wall[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-13)]

Cell wall is an extracellular structure of plant cell that distinguishes them from animal cells. The wall protects the plant cell, maintains its shape, and prevents excessive uptake of water. The strong walls of specialized cells hold the plant up against the force of gravity. Plant cell walls are musch thicker than the plasma membrane, and the exact chemical composition of the wall varies from species to species and even from one cell type to another in the same plante, but basic design of the wall is consistent. Microfibrils made of the polysaccharide cellulose are synthesized by an enzyme called cellulose synthase and secreted to the extracellular space, where they become embedded in a matrix of other polysaccharides and proteins. This combination of materials, strong fibers in a "ground substance" (matrix), is the same basic architectural design found in steel-reinforced concrete and in fiberglass.

A young plant cell first secrets a thins and flexible wall called the primary cell wall; as the cell grows, the cellulose fibrils are oriented at right angels to the direction of cell expansion, possibly affecting the growth pattern. Between primary walls of adjacent cell is the middle lamella, which is a thin layer rich in sticky polysaccharides pectins. The middle lamella flues adjacent cells together. When the cell mature and stops growing, it strengthens its wall. Some plant cells do this simply by secreting hardening substances into the primary wall, but other cells add a secondary cell wall between the plasma membrane and the primary wall. Then secondary wall, often deposited in several laminated layer, has a strong and durable matrix that afford the cell protection and support.

## References[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-14)]

Berg, Jeremy M., John L. Tymoczko, and Lubert Stryer. Biochemistry. 7th ed. New York: W.H. Freeman, 2012. Print.

Reece, Campbell, Lisa A. Urry, Michael L. Cain, Steven A. Wasserman, Peter V. Minosky, and Robert B. Jackson. Biology. 8th ed. San Francisco: Cummings, 2010. Print.

### See also[[edit](/w/index.php?title=Cell_Biology/Cell_types/Eukaryotes&action=edit&section=T-15)]

[Prokaryotes](/w/index.php?title=Cell_Biology/Prokaryotes&action=edit&redlink=1)

# Unique Properties of Plant Cells[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=12)]

[Cell_biology](/wiki/Cell_biology) | [Types of cells](/wiki/Cell_Biology/Cell_types)

<<[ Eukaryotes](/wiki/Cell_Biology/Cell_types/Eukaryotes) | Unique Properties of Plant Cells

Plant Cells have a number of important differences compared to their animal counterparts. The major ones are the Chloroplasts, Cell walls and Vacuoles. Unlike animal cells, plant cells do not have centrioles.

## Chloroplasts[[edit](/w/index.php?title=Cell_Biology/Cell_types/Plant_cells&action=edit&section=T-1)]

The chloroplasts are an organelle similar to the mitochondria in that they are self reproducing and they are the energy factories of the cell.they are near the large center vacuole. There most of the similarities ends. Chloroplasts capture light energy from the sun and convert it into ATP and sugar. In this way the cell can support itself without food.

## Vacuoles[[edit](/w/index.php?title=Cell_Biology/Cell_types/Plant_cells&action=edit&section=T-2)]

Plants often have large structures containing water surrounded by a membrane in the center of their cells. These are vacuoles and act as a store of water and food (in seeds), a place to dump wastes and a structural support for the cell to maintain turgor. When the plant loses water the vacuoles quickly lose their water, and when plants have a lot of water the vacuoles fill up. In mature plants there is usually one large vacuole in the centre of the cell.

## Cell walls[[edit](/w/index.php?title=Cell_Biology/Cell_types/Plant_cells&action=edit&section=T-3)]

Plant cells are not flaccid like animal cells and have a rigid cell wall around them made of fibrils of cellulose embedded in a matrix of several other kinds of polymers such as pectin and lignin. The cellulose molecules are linear and provide the perfect shape for intermolecular hydrogen bonding to produce long, stiff fibrils. It is the cell wall that is primarily responsible for ensuring the cell does not burst in hypotonic surroundings.

# Parts of the cell[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=13)]

# Membranes[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=14)]

[Parts of the cell](/wiki/Cell_Biology/Parts_of_the_cell) The cell membrane is very important, because it works as a selective filter that allows only certain things to come inside or go outside the cell, it act as a body guard for our body.It can maintain a stable and healthy environment for cell in order to keep people healthy.

plant cell membranes are rigid walls, and animal cell membranes are lipid bilayers.

![](//upload.wikimedia.org/wikibooks/en/thumb/4/4f/Bilayer.png/400px-Bilayer.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Plasma membrane bilayer

The phospholipid bilayer which the cell membrane is an example of, is composed of various cholesterol, [phospholipids](//en.wikipedia.org/wiki/Phospholipid), glycolipids, blagoscony and proteins. Below is an example of a simple [phospholipid bilayer](//en.wikipedia.org/wiki/Phospholipid_bilayer).

![Small bilayer.png](//upload.wikimedia.org/wikibooks/en/f/f0/Small_bilayer.png)

The smaller molecules shown between the [phospholipids](//en.wikipedia.org/wiki/Phospholipid) are [Cholesterol](//en.wikipedia.org/wiki/Cholesterol) molecules. They help to provide rigidity or stability to the membrane. The two main components of [phospholipids](//en.wikipedia.org/wiki/Phospholipid) are shown in these figures by blue circles representing the hydrophilic head groups and by long thin lines representing the hydrophobic fatty acid tails.

Both the interior of the cell and the area surrounding the cell is made up of water or similar aqueous solution. Consequently, phospholipids orient themselves with respect to the water and with each other so that the hydrophilic ("water loving") head groups are grouped together and face the water, and the hydrophobic ("water fearing") tails turn away from the water and toward each other. This self-organization of [phospholipids](//en.wikipedia.org/wiki/Phospholipid) results in one of just a few easily recognizable structures. Cell membranes are constructed of a [phospholipid bilayer](//en.wikipedia.org/wiki/Phospholipid_bilayer) as shown above.

Smaller structures can also form, known as 'micelles' in which there is no _inner_ layer of phospholipid. Instead, the interior of a micell is wholly hydrophobic, filled with the fatty acid chains of the phospholipids and any other hydrophobic molecule they enclose. Micelles are not so important for the understanding of cellular structure, but are useful for demonstrating the principles of hydrophilicity and hydrophobicity, and for contrasting with lipid bilayers.

At least 10 different types of lipids are commonly found in cell membranes. Each type of cell or organelle will have a different percentage of each lipid, protein and carbohydrate. The main types of lipids are:

  * Cholesterol
  * Glycolipids
  * Phosphatidylcholine
  * Sphingomyelin
  * Phosphatidylethnolamine
  * Phosphatydilinositol
  * Phosphatidylserine
  * Phosphatidylglycerol
  * Diphosphatidylglycerol (Cardiolipin)
  * Phosphatidic acid

## The Cell Membrane is Asymmetric[[edit](/w/index.php?title=Cell_Biology/Membranes&action=edit&section=T-1)]

The cell membrane tends to have different composition on one side of the membrane than on the other side of the membrane. The differences can be caused by the different ratios or types of amphipathic lipid-based molecules, the different positioning of the proteins (facing in or facing out), or the fixed orientations of proteins spanning the membrane. Additionally, there are different enzymatic activities in the outer and inner membrane surfaces.

The reason the cell membrane is asymmetric is because when the proteins are synthesized by the preexisting membranes, they are inserted into the membrane in an asymmetric manner. The asymmetry of the cell membrane allows the membrane to be rigid and allows the cell to have a different intracellular environment from the existing extracellular environment. Additionally, the cell membrane's phospholipids are distributed asymmetrically across the lipid bilayer, in a phenomenon called membrane phospholipid asymmetry. There are three mechanisms for transmembrane movement of phospholipids: 1) spontaneous diffusion, 2) facilitated diffusion, 3) ATP-dependent active translocation.

The spontaneous diffusion is a form of passive transport. Because passive transport does not require energy to transport non-polar substances through the membrane, this can happen spontaneously. Facilitated diffusion, like spontaneous diffusion, is a form of passive transport. The molecules or ions in this diffusion pass through the membrane by using specific transmembrane transport proteins.

**Membrane transport of small molecules** Because animal membrane proteins are lipid bilayer which are inner hydrophobic, this character prohibits polar molecules. Transport proteins can provide help for this situation. It can transport polar molecules across the membrane. There are several types of membrane transport proteins. They are uniports and cotransport. Uniports can move solutes from one side to another, change the position of the proteins. Cotransport systems can simultaneously sending two solutes across the lipid bilayer. Solutes are sent in the same direction or opposite directions Transport proteins does not need to be acts natural direction.

  
**Membrane Transport of Macromolecules** Membrane transport of Macromolecules can divide into two parts, they are exocytosis and endocytosis. In exocytosis, the contents of vesicles are released when the vesicle fuses with the cell membrane. There are five steps involved, which are vesicle trafficking, vesicke tethering, vesicle docking, vesicle priming and vesicle fusion. In endocytosis the membrane depresses and pinches off, enclosing the molecule. In receptor-mediated endocytosis, coated pits and vesicles bind to specific receptors on the cell surface, allowing the cell to select what molecules to take and what to reject.

## Important aspects of Membranes[[edit](/w/index.php?title=Cell_Biology/Membranes&action=edit&section=T-2)]

  1. [Phospholipids](/w/index.php?title=Cell_Biology/Print_version/Phospholipids&action=edit&redlink=1)
  2. [Cholesterol](/w/index.php?title=Cell_Biology/Print_version/Cholesterol&action=edit&redlink=1)
  3. [Semi-permeability and osmosis](/w/index.php?title=Cell_Biology/Print_version/Semi-permeability_and_osmosis&action=edit&redlink=1)
  4. [Proteins and channels](/w/index.php?title=Cell_Biology/Print_version/Proteins_and_channels&action=edit&redlink=1)
  5. [Hydrophobicity](/w/index.php?title=Cell_Biology/Print_version/Hydrophobicity&action=edit&redlink=1)
  6. [Self-assembly](/w/index.php?title=Cell_Biology/Print_version/Self-assembly&action=edit&redlink=1)

# Organelles[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=15)]

[Parts of the cell](/wiki/Cell_Biology/Parts_of_the_cell)

![](//upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Biological_cell.svg/350px-Biological_cell.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Schematic of typical animal cell, showing subcellular components.

Organelles: (1) nucleolus (2) nucleus (3) ribosome (4) vesicle (5) rough endoplasmic reticulum (ER) (6) Golgi apparatus (7) Cytoskeleton (8) smooth ER (9) mitochondrion (10) vacuole (11) cytoplasm (12) lysosome (13) centrioles

## Nucleus[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-1)]

The nucleus contains genetic material or DNA in the form of chromatin, or, during mitosis or late interphase, chromosomes. All transcription and replication of genetic material takes place within the nucleus, as does mRNA processing. The nucleolus also resides within the nucleus, and is responsible for rRNA transcription and folding. Translation of mRNA transcripts takes place outside of the nucleus.

==Mitochondria==.

## Ribosomes[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-2)]

Ribosomes are responsible for protein synthesis. They are comprised of interacting protein and nucleic acid chains. Broadly, ribosomes are comprised of a large and a small subunit. The small subunit functions to attach to the mRNA strand and hold it in place during translation, while the large subunit holds and manufactures the growing polypeptide chain. The large subunit is further subdivided into the A (aminoacyl), P (peptidyl), and E (exit) binding sites.

**Aminoacyl Binding Site** The aminoacyl binding site binds a charged tRNA whose anticodon matches the codon in the A site.

**Peptidyl Binding Site** The peptidyl binding site contains the molecular machinery that transfers the bound polypeptide from the tRNA to the polypeptide chain, and holds the growing chain in place.

**Exit Site** The exit site is the terminal binding site for tRNA, where discharged tRNA's are released from the translation complex.

## Endoplasmic Reticulum[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-3)]

The Endoplasmic Reticulum (ER) acts as a transport from the nucleus and ribosomes to the Golgi apparatus. There are two types of endoplasmic reticulum:

### Smooth ER[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-4)]

Smooth ER act as transport for various things, mainly the RNA from the nucleus to the ribosomes (RNA is a small piece of the DNA code specifically designed to tell the ribosomes what to make). Smooth ER appears smooth in texture, hence the name. Smooth ER plays an important role in lipid emulsification and digestion in the cell.

### Rough ER[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-5)]

Rough ER are "rough" because of the ribosomes embedded in them. The rough ER take the protein to the Golgi apparatus to be packaged into vacuoles

## Golgi Complex[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-6)]

The Golgi Complex basically functions as a "packaging center" for the cell, attaching "address labels" (functional groups) to various cell products to direct them to their respective locations, and "packaging" the products into vacuoles to ensure delivery. Anatomically, the Golgi Complex consists of layers of lipid membrane stacked one one top of another, with a cis face and a trans face. As the molecular product being packaged moves through the complex, various enzymes act upon it to induce vacuole formation and functional group attachment.

## Vacuole[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-7)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Paramecium_contractile_vacuoles.jpg/220px-Paramecium_contractile_vacuoles.jpg)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Paramecium, with contractile vacuoles indicated using arrows.

Vacuoles are cellular storage places. Like the cell membrane, they are comprised of a lipid bilayer that functions as a selectively permeable barrier to regulate movement of materials into and out of the compartment. They can serve a variety of purposes, storing food, water, or waste products, or immune functions such as containing dangerous materials or maintaining turgor pressure (in plants). Vacuoles serve very different purposes in plant cells than they do in animal cells.

**Plant Cells** In plants, vacuoles comprise a significant portion of the cell's total volume and often contribute significantly to the function of a differentiated cell. For example, vacuoles in stomata cells contain large numbers of potassium ions, which can be pumped in or out to open or close the stomata.

**Animal Cells** In animal cells, vacuoles serve more subordinate roles, such as assisting in endo- and exocytosis or basic storage of food and waste.

**Central Vacuole** The central vacuole is found only in plant cells. It is filled with water and is pressurised, like a balloon. This forces all the other organelles within the cell out toward the cell wall. This pressure is called _turgor pressure_ and is what gives plants their "crisp" and firm structure.

## Peroxisomes[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-8)]

Peroxisomes perform a variety of metabolic processes and as a by-product, produce hydrogen peroxide. Peroxisomes use peroxase enzyme to break down this hydrogen peroxide into water and oxygen.

## Lysosomes[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-9)]

Lysosomes are vacuoles containing digestive and destructive membranes. In white blood cells, these are used to kill the bacteria or virus, while in tadpole-tail cells they kill the cell by separating the tail from the main body.

They also do much of the cellular digestion involved in [apoptosis](//en.wikipedia.org/wiki/Apoptosis), the process of programmed cell death.

## Links[[edit](/w/index.php?title=Cell_Biology/Organelles&action=edit&section=T-10)]

For more info go to <http://www.tvdsb.on.ca/westmin/science/sbi3a1/Cells/cells.htm>

# Genetic material[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=16)]

[Cell Biology](/wiki/Cell_Biology) | [Parts of the cell](/wiki/Cell_Biology/Parts_of_the_cell)

  1. [Prokaryotes](/w/index.php?title=Cell_Biology/Prokaryotes&action=edit&redlink=1)
  2. [Eukaryotes](/w/index.php?title=Cell_Biology/Eukaryotes&action=edit&redlink=1)
  3. [Nucleus](/wiki/Cell_Biology/Nucleus)
  4. [Nuclear membrane](/w/index.php?title=Cell_Biology/Nuclear_membrane&action=edit&redlink=1)
  5. [Nucleolus](/wiki/Cell_Biology/Nucleolus)
  6. [Codons](/w/index.php?title=Cell_Biology/Codons&action=edit&redlink=1)
  7. [RNA polymerase](/w/index.php?title=Cell_Biology/RNA_polymerase&action=edit&redlink=1)
  8. [Histones](/w/index.php?title=Cell_Biology/Histones&action=edit&redlink=1)

# Energy supply (chloroplasts and mitochondria)[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=17)]

[Parts of the cell](/wiki/Cell_Biology/Parts_of_the_cell)

Chloroplasts are the organelles used for photosynthesis (a process that incorporates light energy into storage as chemical energy) whereas mitochondria used in respiration (a process that releases stored chemical energy). It assumed that you already know the information about these organelles explained in the [organelles](/wiki/Cell_Biology/Organelles) section. If you have not read the entries on chloroplasts and mitochondria from there yet, please go back and read them now.

### Chemicals to know[[edit](/w/index.php?title=Cell_Biology/Energy_supply&action=edit&section=T-1)]

  1. [Important chemicals](/w/index.php?title=Cell_Biology/Print_version/Important_chemicals&action=edit&redlink=1)

### Photosynthesis[[edit](/w/index.php?title=Cell_Biology/Energy_supply&action=edit&section=T-2)]

  1. [Light Dependent Reactions](/w/index.php?title=Cell_Biology/Print_version/Light_Dependent_Reactions&action=edit&redlink=1)
  2. [Calvin-Benson Cycle](/w/index.php?title=Cell_Biology/Print_version/Calvin-Benson_Cycle&action=edit&redlink=1)

### Cellular Respiration[[edit](/w/index.php?title=Cell_Biology/Energy_supply&action=edit&section=T-3)]

  1. [Glycolysis](/w/index.php?title=Cell_Biology/Print_version/Glycolysis&action=edit&redlink=1)
  2. [Krebs cycle](/w/index.php?title=Cell_Biology/Print_version/Krebs_cycle&action=edit&redlink=1)
  3. [Electron transport](/w/index.php?title=Cell_Biology/Print_version/Electron_transport&action=edit&redlink=1)

# Cell division[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=18)]

# Cell cycle[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=19)]

The normal cell cycle consists of 2 major stages. The first is interphase, during which the cell lives and grows larger. The second is Mitotic Phase. Interphase is composed of three subphases. G1 phase (first gap), S phase (synthesis), and G2 phase (second gap). The interphase is the growth of the cell. The normal cell functions of creating proteins and organelles. The Mitotic Phase is composed of Mitosis and Cytokinesis. [Mitosis](/wiki/Cell_Biology/Cell_division/Mitosis), when the cell divides. Mitosis can be further divided into multiple phases. Cytokinesis, which is when the two daughter cells complete their separation. Mitosis is the division of the nucleus and cytokinesis is the division of the cytoplasm. There is some overlap between there two sub phases. Reproductive cell division is called meiosis, which yields a nonidentical daughter cells that have only one set of chromosomes. In other words, they have half as many chromosomes as the parent cell. Meiosis occurs in gonads, ovaries or testes. Therefore combining two gametes together produce 46 chromosomes.

## From Wikipedia[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-1)]

The **cell cycle** is the cycle of a biological cell, starting from the time it is first formed from a dividing parent cell until its own division into two cells, consisting of repeated mitotic cell division and interphase (the growth phase). A cell spends the overwhelming majority of its time in the interphase(about 90% of time).

## Background Information[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-2)]

Genome is a cell's endowment of DNA, which is its genetic information. Prokaryotic genome is often a single long DNA molecule, and Eukaryotic genomes consist of number of DNA molecules. A typical human cell has about 2m of DNA, which is 250,000 times greater than the cell's diameter. Before the cell division, all of the DNA must be copied and then two copies gets separated so that each daughter cell ends up with a complete genome. Chromosomes are the packaged DNA molecules. Because of chromosomes, the replication and distribution of so much DNA is manageable. Every eukaryotic species has a characteristic number of chromosomes in each cell nucleus. They contain two sets of each chromosome: one set inherited from each parent. For example human somatic cells (all body cells except the reproductive cells) each contain 46 chromosomes; the reproductive cells, gametes, have half as many chromosomes as somatic cells. The number of chromosomes in somatic cells varies widely among species. Eukaryotic chromosomes are made of chromatin that is a complex of DNA and associated protein molecules. Each single chromosome contains one very long, linear DNA molecule that carries several hundred to a few thousand genes; the associated proteins maintain the structure of the chromosome and help control the gene activity. When a cell is not dividing, each chromosome is a long thins chromatic fiber; however after DNA duplication chromosomes condense. Each chromatin fiber coils and folds. Each duplicated chromosome has two sister chromatids, containing an identical DNA molecule, initially attached along adhesive protein complex; such attachment is called sister chromatid cohesion. In condensed form of chromosome, a center narrow part is called centromere, a specialized region where the two chromatids are closely attached. The other part of a chromatid on either side of the centromere is referred as arm. Once the sister chromatids separate, they are considered individual chromosomes.

  


## Overview[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikipedia/commons/c/c4/Cell_cycle.png)

Schematic of the cell cycle. I=Interphase, M=Mitosis. The duration of mitosis in relation to the other phases has been exaggerated in this diagram.

Mitotic phase includes both mitosis and cytokinesis which is usually the shortest part of the cell cycle. Interphase accounts about 90%of the cycle; during interphase the cell grows and copies its chromosomes in preparation for cell division. Interphase is divided into sub phases: G1 phase ("first gap"), the S phase ("synthesis"), and G2 phase ("second gap"). The chromosomes are duplicated only during the S phase. During G1 phase cell grows until S phase where the cell prepares for the cell division during G2 phase. Based from human cell, M phase only takes about 1 hour while the S phase occupy about 10-12 hours.

The cell cycle consists of

  * **G1 phase**, the first growth phase
  * **S phase**, during which the DNA is replicated, where S stands for the Synthesis of DNA.
  * **G2 phase** is the second growth phase, also the preparation phase for the
  * **M phase** or [mitosis](/wiki/Cell_Biology/Cell_division/Mitosis) and [cytokinesis](/wiki/Cell_Biology/Cell_division/Mitosis#Cytokinesis), the actual [division](/wiki/Cell_Biology/Cell_division) of the cell into two daughter cells

The cell cycle stops at several checkpoints and can only proceed if certain conditions are met, for example, if the cell has reached a certain diameter. Some cells, such as neurons, never divide once they become locked in a **G0 phase**.

## Mitosis[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-4)]

Mitosis has five stages: prophase, prometaphase, metaphase, anaphase, and telophase. Mitotic spindle starts to form in the cytoplasm during prophase. it is made of microtubules and other associated proteins. while the mitotic spindle assembles, the microtubules of the cytoskeleton disassemble, providing the material used to construct the spindle. In animal cells, the assembly of spindle microtubules starts at the centrosome, the microtubule-organizing center. In plant cells, the centrioles are not present. During interphase in animal cells, the single centrosome replicates; the two centrosomes remain together near the nucleus and they move apart during prophase and prometaphase of mitosis as spindle microtubules grows. The two centrosomes are located at the opposite end of the cell. Then aster, a radial array of short microtubules, extends from each centrosome. Kinetochore is a structure of proteins associated with specific sections of chromosomal DNA at the centromere. Each of the two sister chromatids of a replicated chromosome contains kinetochore as it face in opposite direction. During prometaphase, kinetochore microtubules form as come of the spindle microtubules attach to the kinetochores. After the microtubuels are attached to chromosome's kinetochores, the chromosome begins to move towards the pole from which those microtubules extend. the chromosomes moves in a motion like a tug-of-war. Metaphase plate is the imaginary plane that formed during metaphase the centromeres of all the duplicated chromosomes are on the plane midway between the spindle's two poles. The other microtubules that did not attach to kinetochores overlap and interact with other nonkinetochore microtubules from the opposite pole. The nonkinetochore microtubules are responsible for elongating the whole cell during anaphase. During anaphase, the cohesins holding the sister chromatids of each chromosome are cleaved by enzymes. Then the chromatids separated, and they move towards the opposite ends of the cell. The region of overlap is reduced as motor proteins attached to the microtubules move away from one another, using ATP. As the microtubules push apart from each other, their spindle poles are pushed apart, elongating the cell. As the duplicate groups of chromosomes arrive at the opposite ends of the elongated parent cell, the telophase begins; during telophase nuclei reforms and cytokinesis begins.

  * **G2 of Interphase**:During G2 phase, a nuclear envelope bounds the nucleus, and two centrosomes forms by replication of a single centrosome. In animal cells, each centrosome contains two centrioles. The chromosomes are duplicated during S phase but cannot be seen since they are not condensed yet.
  * **Prophase**: the chromatin fibers coils and dense into chromosomes and the nucleoli disappear. Each duplicated chromosome has tow identical sister chromatids joined at their centromeres along with their arms by cohesins, then the mitotic spindle form. The asters are the radial arrays of shorter microtubules that extend from the centrosomes. Propelled by the lengthening microtubules, the centrosomes move away from each other.
  * **Prometaphase**: As the nuclear envelope fragments, the microtubules extending from each centrosome invade the nuclear area. the chromosome become more condensed as each of the two chromatids of each chromosome has a kinetochore. Some of the microtubules attach to the kinetochores ("kinetochore microtubules" and other nonkinetochore microtubules interact with each from fromt he opposite pole of the spindle.
  * **Metaphase**: Metaphse is the longest stage of mitosis. The centrosomes are placed at the opposite poles of the cell. The chromosomes' centromeres lie ont he metaphse plate as the chromosome convene on the metaphase plate. Each kinetochores of the sister chromatids are attacged to kinetochore microtubules coming from opposite poles.
  * **Anaphase**: Anaphase is the shortest stage of mitosis, and begins whent he cohesin proteins are cleaved, allowing the two sister chromatids of each pair to part suddenly. The two liberated daughter chromosomes moves towards oppostie ends of the cell as the kinetochore microtubules shorten. The cell starts to elongate and nonkinetochore microtubules lengthen. By the end of anaphase, the two ends of the cell have equivalent collections of chromosome.
  * **Telophse**: Two daughter nuclei form in the cell, and nuclear envelopes arise fromt he fragments of the parent cell's nuclear envelope. As nucleoli reappear, the chromosome become less condensed, and completes the division of the one nucleus into two genetically identical nuclei.
  * **Cytokinesis**: In animal cells, cytokinesis involves formation of cleavage furrow; in plante cell the cleavage furrow does not exist. The formation of cell wall in the middle of cell (cell plate) divides the cell into two daughter cells.

## Details of mitosis[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/e/e0/Interphase_mitosis.png)

Schematic of interphase (brown) and mitosis (yellow).

## Cytokinesis[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-6)]

The cytokinesis process begins with cleavage. Cleavage furrow, a shallow groove in the cell surface near the old metaphase plate, is the first sign of cleavage. As it process, contractile ring of actin microfilaments form on the cytoplasmic side. The actin microfilaments interact with the myosin molecules, and cause the ring to contract. As the cleavage furrow deepens, the cell is separated into two with its own nucleus. For plant cells, there is no cleavage furrow because they have the cell walls. Instead of forming cleavages, vesicles derived from the Golgi apparatus move along microtubules to the middle of the cells, and forms cell plate. As the cell plate enlarges, and surrounding membrane fuses with the plasma membrane along the perimeter of the cell and from two daughter cells.

## Binary Fission[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-7)]

Binary fission is a method of asexual reproduction by "division in half". In prokaryotes, binary fission does not involve mitosis, but in single celled eukaryotes that undergo binary fission. In bacteria, motst genes are carried on a single bacterial chromosome that consists of a circular DNA molecule and associated proteins. The chromosome of the bacterium Escherichia coli, is 500 times as long as the cell when it is sctreched out. At the origin of replication, DNA of the bacterial chromosome begins to replicate. As the chromosome continues to replicate, one origin moves rapidly toward the opposite end of the cell, and the cell elongates. When the replication is complete the bacterium is about twice its initial size, and its plasma membrane grows inward, dividing the parent E. coli cell into two daughter cells. Bacteria don’t have mitotic spindles; the two origins of replication end up at opposite ends of the cell or in some other very specific location.

## The Evolution of Mitosis[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-8)]

Since the prokaryotes were on Earth more than a billion years than eukaryotes that mitosis had its origins in simpler prokaryotic mechanism of the cell reproduction can be assumed. Some of the proteins involved in bacterial binary fission are related to eukaryotic proteins that function in mitosis. Possible hypothesis of evolution of mitosis is that prokaryotic cell's reproduction gave rise to mitosis.

  


## The Cell Cycle Control System[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-9)]

Based from mammalian cell grow experiment, possible hypothesis was supported: the cell cycle is driven by specific signaling molecules present in the cytoplasm. In this experiment two cells in different phase of the cell cycle were fused to form a single cell with two nuclei. One cell was in the S phase and the other was in G1, and G1 nucleus immediately entered the S phase, as though stimulated by chemicals present in the cytoplasm of the first cell. Therefore, if a cell undergoing mitosis (M phase) was fused with another cell in any stage of its cell cycle, the second nucleus enteres mitosis. Other experiments on animal cells and yeasts demonstrates the sequential events of the cell cycle control system; the cell cycle control system operates set of molecules in the cell that both triggers and coordinates key events in the cell cycles. The cell cycle control system proceeds on its own, but it is regulated at certain checkpoints by internal and external signals. Animal cells have built-in stop signals that halt the cell cycle at checkpoints until they get go-ahead signals. The signals report whether crucial cellular processes that should have occurred by that point have in fact been completed correctly and thus whether or not the cell cycle should proceed. The three check points are in G1, G2, and M phase. For mammalian cells, G1 check points are the most important. When a cell receives a go-ahead signal at the G1 checkpoint, the cell complete the G1, S, G2 and M phases and divide; however when a cell does not get a go-ahead signal, it will exit the cycle and enter non dividing state, G0 phase. Most of human cells are in G0 phase, such as mature nerve cells and muscle cells. However the liver cells can re-enter the cycle by external signals such as growth factor released during injury. Rhythmic fluctuations in the abundance and activity of cell cycle control molecules pase the sequential events of the cell cycle. The regulatory molecules are portins of two types: protein kinases and cyclins. Portin kinases are enzymes that activate or inactivate other proteins by phosphorylating. The protein kinases give the go-ahead signals at the G1 and G2 checkpoints. The kinases that drive the cell cycle are present at a constant concentration in the growing cell, but they are in an inactive form. In order to activate them, kinase must be attached to a cyclin, a protein that cyclically fluctuating concentration in the cell. Because of such requirement, these are called cyclin-dependent kinases or Cdks. The activity of cdks rises and falls with changes in the concentration of its cyclin partner. The cylclin level rises during the S and G2 phases and then falls rapidly during M phase. MPF, the maturation -promoting factor, or M-phase -promoting factor, activity corresponds to the peaks of cyclin concentration. MPF triggers the cell's passage past the G2 checkpoint into M phase. MPF acts both directly as a kinase and indirectly by activating other kinases. During anaphase, MPF hels switch itself off by initiating a process that leads to the destruction of its own cyclin. The Cdk, noncyclin part of MPF, persists in the cell in inactive form until it associates with new cyclin molecules synthesized during the S and G2 phase of the next round of the cycle. Density-dependent inhibition is a phenomenon in which crowded cells stop dividing. It is caused by external physical factor. Also most animal cells exhibit anchorage dependence; in order to divide, the cells must be attached to a substratum; like a cell density, anchorage is signaled to the cell cycle control system via pathways involving plasma membrane proteins and elements of cytoskeleton linked to them. The loss of cell cycle controls leads to cancer cells, which exhibit neither density-dependent inhibition nor anchorage dependence.

## Reference[[edit](/w/index.php?title=Cell_Biology/Cell_division/Cell_cycle&action=edit&section=T-10)]

Berg, Jeremy M., John L. Tymoczko, and Lubert Stryer. Biochemistry. 7th ed. New York: W.H. Freeman, 2012. Print.

Reece, Campbell, Lisa A. Urry, Michael L. Cain, Steven A. Wasserman, Peter V. Minosky, and Robert B. Jackson. Biology. 8th ed. San Francisco: Cummings, 2010. Print.

# Meiosis[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=20)]

**Meiosis** is a special type of cell division that is designed to produce gametes. Before meiosis occurs, the cell will be double diploid and have a pair of each chromosome, the same as before mitosis.

Meiosis consists of 2 cell divisions, and results in four cells. The first division is when genetic crossover occurs and the traits on the chromosomes are shuffled. The cell will perform a normal prophase, then enter metaphase during which it begins the crossover, then proceed normally through anaphase and telophase.

The first division produces two normal diploid cells, however the process is not complete. The cell will prepare for another division and enter a second prophase. During the second metaphase, the chromosome pairs are separated so that each new cell will get half the normal genes. The cell division will continue thorough anaphase and telophase, and the nuclei will reassemble. The result of the divisions will be 4 haploid gamete cells.

## Crossover[[edit](/w/index.php?title=Cell_Biology/Cell_division/Meiosis&action=edit&section=T-1)]

Crossover is the process by which two chromosomes paired up during prophase I of meiosis exchange a distal portion of their DNA. Crossover occurs when two chromosomes, normally two homologous instances of the same chromosome, break and connect to each other's ends. If they break at the same locus, this merely results in an exchange of genes. This is the normal way in which crossover occurs. If they break at different loci, the result is a duplication of genes on one chromosome and a deletion on the other. If they break on opposite sides of the centromere, this results in one chromosome being lost during cell division.

Any pair of homologous chromosomes may be expected to cross over three or four times during meiosis. This aids evolution by increasing independent assortment, and reducing the genetic linkage between genes on the same chromosome.

# Mitosis[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=21)]

Mitosis is the normal type of cell division. Before the cells can divide, the chromosomes will have duplicated and the cell will have twice the normal set of genes.

The first step of cell division is **prophase**, during which the nucleus dissolves and the chromosomes begin migration to the midline of the cell. (Some biology textbooks insert a phase called "prometaphase" at this point.)The second step, known as **metaphase**, occurs when all the chromosomes are aligned in pairs along the midline of the cell. As the cell enters **anaphase**, the chromatids, which form the chromosomes, will separate and drift toward opposite poles of the cell. As the separated chromatids, now termed chromosomes, reach the poles, the cell will enter **telophase** and nuclei will start to reform. The process of mitosis ends after the nuclei have reformed and the cell membrane begins to separate the cell into two daughter cells, during **cytokinesis**.

![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Major_events_in_mitosis.svg/350px-Major_events_in_mitosis.svg.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

Mitosis divides genetic information during cell division.

The mitotic phase which includes both mitosis and cytokinesis is the shortest part of the cell cycle. The interphase cycle accounts for about 90% of the cell cycle. This phase is where the cell grows and copies its chromosomes in preparation for cell division. In the G1 phase which is also called the “first gap” the cell grows as it copies its chromosomes. In S phase, the cell starts to synthesize the DNA and completes preparation for cell division. In G2 it starts to divide.

In biology, Mitosis is the process of chromosome segregation and nuclear division that follows replication of the genetic material in eukaryotic cells. This process assures that each daughter nucleus receives a complete copy of the organism's genetic material. In most eukaryotes, mitosis is accompanied with cell division or cytokinesis, but there are many exceptions, for instance among fungi. There is another process called meiosis, in which the daughter nuclei receive half the chromosomes of the parent, which is involved in gamete formation and other similar processes, which makes the parent cell still active.

Mitosis is divided into several stages, with the remainder of the cell's growth cycle considered interphase. Properly speaking, a typical cell cycle involves a series of stages: G1, the first growth phase; S, where the genetic material is duplicated; G2, the second growth phase; and M, where the nucleus divides through mitosis. Mitosis is divided into prophase, prometaphase, metaphase, anaphase and telophase.

The whole procedure is very similar among most eukaryotes, with only minor variations. As prokaryotes lack a nucleus and only have a single chromosome with no centromere, they cannot be properly said to undergo mitosis.

## Prophase[[edit](/w/index.php?title=Cell_Biology/Cell_division/Mitosis&action=edit&section=T-1)]

![ProphaseSH.png](//upload.wikimedia.org/wikibooks/en/thumb/d/de/ProphaseSH.png/200px-ProphaseSH.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The genetic material (DNA), which normally exists in the form of chromatin condenses into a highly ordered structure called a chromosome. Since the genetic material has been duplicated, there are two identical copies of each chromosome in the cell. Identical chromosomes (called sister chromosomes) are attached to each other at a DNA element present on every chromosome called the centromere. When chromosomes are paired up and attached, each individual chromosome in the pair is called a chromatid, while the whole unit (confusingly) is called a chromosome. Just to be even more confusing, when the chromatids separate, they are no longer called chromatids, but are called chromosomes again. The task of mitosis is to assure that one copy of each sister chromatid - and only one copy - goes to each daughter cell after cell division.

The other important piece of hardware in mitosis is the centriole, which serves as a sort of anchor. During prophase, the two centrioles - which replicate independently of mitosis - begin recruiting microtubules (which may be thought of as cellular ropes or poles) and forming a mitotic spindle between them. By increasing the length of the spindle (growing the microtubules), the centrioles push apart to opposite ends of the cell nucleus. It should be noted that many eukaryotes, for instance plants, lack centrioles although the basic process is still similar.

## Prometaphase[[edit](/w/index.php?title=Cell_Biology/Cell_division/Mitosis&action=edit&section=T-2)]

[File:InterphaseSH.png](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=InterphaseSH.png)

300px

Some biology texts do not include this phase, considering it a part of prophase. In this phase, the nuclear membrane dissolves in some eukaryotes, reforming later once mitosis is complete. This is called open mitosis, found in most multicellular forms. Many protists undergo closed mitosis, in which the nuclear membrane persists throughout.

Now kinetochores begin to form at the centromeres. This is a complex structure that may be thought of as an 'eyelet' for the microtubule 'rope' - it is the attaching point by which chromosomes may be secured. The kinetochore is an enormously complex structure that is not yet fully understood. Two kinetochores form on each chromosome - one for each chromatid.

When the spindle grows to sufficient length, the microtubules begin searching for kinetochores to attach to.

## Metaphase[[edit](/w/index.php?title=Cell_Biology/Cell_division/Mitosis&action=edit&section=T-3)]

![MetaphaseSH.png](//upload.wikimedia.org/wikibooks/en/thumb/5/5f/MetaphaseSH.png/300px-MetaphaseSH.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

As microtubules find and attach to kinetochores, they begin to line up in the middle of the cell. Proper segragation requires that every kinetochore be attached to a microtubule before separation begins. It is thought that unattached kinetochores control this process by generating a signal - the mitotic spindle checkpoint - that tells the cell to wait before proceeding to anaphase. There are many theories as to how this is accomplished, some of them involving the generation of tension when both microtubules are attached to the kinetochore.

When chromosomes are bivalently attached - when both kinetochores are attached to microtubules emanating from each centriole - they line up in the middle of the spindle, forming what is called the metaphase plate. This does not occur in every organism - in some cases chromosomes move back and forth between the centrioles randomly, only roughly lining up along the midline.

## Anaphase[[edit](/w/index.php?title=Cell_Biology/Cell_division/Mitosis&action=edit&section=T-4)]

[File:AnaphaseSH.png](//commons.wikimedia.org/wiki/Commons:Upload?wpDestFile=AnaphaseSH.png)

250px

Anaphase is the stage of meiosis or mitosis when chromosomes separate and move to opposite poles of the cell (opposite ends of the nuclear spindle). Centromeres are broken and chromatids rip apart.

When every kinetochore is attached to a microtubule and the chromosomes have lined up along the middle of the spindle, the cell proceeds to anaphase. This is divided into two phases. First, the proteins that bind the sister chromatids together are cloven, allowing them to separate. They are pulled apart by the microtubules, towards the respective centrioles to which they are attached. Next, the spindle axis elongates, driving the centrioles (and the set of chromosomes to which they are attached) apart to opposite ends of the cell. These two stages are sometimes called 'early' and 'late' anaphase.

At the end of anaphase, the cell has succeeded in separating identical copies of the genetic material into two distinct populations.

## Telophase[[edit](/w/index.php?title=Cell_Biology/Cell_division/Mitosis&action=edit&section=T-5)]

![TelophaseSH.png](//upload.wikimedia.org/wikibooks/en/thumb/8/86/TelophaseSH.png/200px-TelophaseSH.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

The nonkinetochore microtubules elongate the cell and try to cut the cell in two. The nuclear envelopes start to become created by fragments of the parents cell’s nuclear envelope. Then, the chromatids start to become less tightly coiled together. By this point, cytokinesis is fully under way.

## Cytokinesis[[edit](/w/index.php?title=Cell_Biology/Cell_division/Mitosis&action=edit&section=T-6)]

Cytokinesis refers to the physical division of one eukaryotic cell. Cytokinesis generally follows the replication of the cell's chromosomes, usually mitotically, but sometimes meiotically. Except for some special cases, the amount of cytoplasm in each daughter cell is the same. In animal cells, the cell membrane forms a cleavage furrow and pinches apart like a balloon. In plant cells, a cell plate forms, which becomes the new cell wall separating the daughters. Various patterns occur in other groups.

  
In plant cells, cytokinesis is followed through by the usage of contracting ring of microfilaments that pull the cleavage furrow within itself, cutting the cell in two. In plant cells, vesicles from the Golgi apparatus start to form a cell plate within the center of the cell. When this cell plate solidifies and connects the two ends of the cell, a new cell wall is created and two daughter cells are produced.

![The difference between Cytokinesis for animal and plant cells.](//upload.wikimedia.org/wikibooks/en/thumb/9/98/Cyto.png/800px-Cyto.png)

![](//bits.wikimedia.org/static-1.22wmf18/skins/common/images/magnify-clip.png)

## Regulation of Cell Cycle[[edit](/w/index.php?title=Cell_Biology/Cell_division/Mitosis&action=edit&section=T-7)]

Protein kinases are enzymes that activate or inactivate other proteins by phosphorylating them. These give out the signals for the G1 and G2 checkpoints to occur. However, to be active, the kinase must be attached to a cyclin. This is why it is called a CDK or a cyclin-dependent kinase.

Internal kinetochores exhibit a wait function. Not until all kinetochores are attached to a spindle microtubule does the cell process starts. This helps prevent some chromosomes from being left behind. Density dependent inhibition is when cells have a cue to multiply until a certain level of density is fulfilled. This means that a cell keeps multiplying until there is a full layer or until a certain level of pressure is built upon each other.

One possible explanation of why cancer cells do not follow normal signals is because they have an abnormality in the signaling pathway that conveys the growth factor’s signal to the cell-cycle control system. Usually, a cell will follow normal checkpoints due to the release of CDK in the system that regulate the cell process. However, in a cancer cell, the checkpoints are random. This means that because the cell does not follow density-dependent inhibition or follow the growth signals, the cell replicates at random points.

# Genes[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=22)]

# Expression[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=23)]

Gene expression is the first stage of a process that decodes what the DNA holds in a cell. It is the expression of a gene that gives rise to a protein.

**How does gene expression occur?**

Genetic expression is a wide complex process. It must be regulated by a series of mechanisms.

It starts of with transcription that gives rise to the RNA messenger (RNAm) from DNA. The RNAm in prokariotes is coupled with several ribosomes which are responsibles of translating proteins.

In eukariotes RNAm that is made from DNA is immature, and it is called preRNAm. PreRNAm loses non-coding sections (called exons), becoming onto a RNAm mature. RNAm is coupled to ribosomes on Rough Endoplasmatic Reticle (RER) where translation happens. Translation is made when a new polypeptide is formed. The genetic code indeed says the order of pe polypeptides, but it doen't give us a clue about it tridimensional structure. Tridimensional structure is given by post-translational processes.

Translation occurs following transcription wherein the protein synthesis machinery gets into action and uses its tools to read out the message that the RNA holds.

There are some genes known to be without coding proteins. Yet, they work as regulation sequences in a cell. In this case, the sequences can enhance coding (called "enhancers") or they can inhibit (called "represors". When a protein is coupled with these genes, a substrate or hormone, they join together.

In pluricellular organisms only few cell are allowed to produce a certain type of protein; e.g.: Haemoglobin is encoded in every cell of a mammal organism (it includes human), but only precursors of red blood cell are allowd to express it (red blood cell are not allowed to express it, because they lose it nucleus). However, the enhancers and represors are present in every cell of a mammal

  
**Genetic Information**

In nature, there is information found in all living cells. Different cultures have often studied this information and used various forms of recording techniques to display it. Ancient Egyptians, in particular, referred to this information and its records as "provider of attributes" and determined it ||| to mean several, and that was earlier in human history of recording something that was known about nature.

There were often other signs as well that accompanied Egyptian writings on the source of this "information key of life". Among them were double, water and wick of twisted flax. But the most central one, for modern science, of course, was the snake like determinative that meant a worm or serpent in the limit of life. This limit, water, was "N" meaning that something or someone is, the essence which would be referred to by the Greeks as "esse" or "ens", and in today's English terms, the "essence".

In anthropology, the language of gene expression is rooted in the sources of knowledge that Odhiambo Siangla of Kenya has called "rieko" and Jeremy Narby of Switzeland has termed the "cosmic serpent". Both Siangla and Narby are not only experts in cultures but are trained in communication and expression. And from both the key has been the "three letter word".

In the alphabet of the three letter word found in cell biology are the organic bases, which are adenine (A), guanine (G), cytosine (C) and thymine (T). It is the triplet recipe of these bases that make up the ‘dictionary’ we call in molecular biology genetic code.

The codal system enables the transmission of genetic information to be codified, which at molecular level, is conveyed through genes.

What is gene ? A gene is a region of DNA that produces a functional RNA molecule. If a region of DNA is not functional, that region is not a transmissible form of information for protein synthesis. And because the information is not transmissible, it is not readily functional. There are various sizes of gene. The first recorded attempts to imagine the very small was the Horus Eye, which is also a pristine idea of limit. Today we talk about bases. The insulin gene, for example, has 1.7 x ![10^3](//upload.wikimedia.org/math/8/2/1/8215c811412e29425321dc8966f83cfe.png), about 1700 nucleotides. There exists a receptor gene known as low-density lipoprotein (LDL). This protein has 4.5 x![10^4](//upload.wikimedia.org/math/4/3/7/4378eeb5bb839cc6fae5f03c6e96a5e2.png) nucleotides. In terms of nucleotides this (LDL) approximates to 45,000 nucleotides. Now, with the dystrophic gene as another example, we find the nucleotides to be around 2.0 x![10^8](//upload.wikimedia.org/math/0/3/3/033f7f4c3eb918d9336804647277a218.png), approximately 200,000,000 nucleotides in number.

Now, the introns. It is the noncoding regions of DNA that are called introns meaning the “intervening sequences”. Introns make up a greater part of the nucleotide sequences of a gene. The coding regions are called exons to mean “expression sequences”. They constitute a minority of the nucleotide progression of a DNA and they instruct cellular workshops for the formation of proteins via amino acids.

Through proteins, the expression of genetic information is achieved. In particular are the enzymes. Even during the ancient time the enzymes were understood and utilized well. The enzymes catalyze the chemical reactions of anabolic kind, that is, the building of cellular food and those of catabolic type, the braking down of food. The two processes are collectively termed metabolism. What, further, can we add about proteins?

We can further say that proteins are concentration of heteropolymers manufactured from amino acids. There are 20 amino acids used in synthesizing natural proteins. It is clear that a protein may consist of many, in fact, several hundred amino acid sediments. It is essentially unlimited in number to speak about how many different proteins we can make from combinations of amino acids. Mathematics explains it well. There is therefore a diverse set of proteins whose forms and functions can be achieved by means of a coding system explained below.

Genetic information flows unidirectional, from DNA to protein and with messenger RNA (mRNA) as intermediate. First, DNA encodes genetic information into RNA molecule. This is called transcription (TC) of the information. Then the information gets converted into proteins, being named here translation (TL). It is this concept of information current that is called the Central Dogma of molecular biology. The Central Dogma is the fundamental theme in our exploration on gene articulation.

In order to complete the picture, we can add two further aspects of information flow. We can add duplication of the genetic material, which occurs prior to cell division. And that a DNA, in this case, represents duplication process, —DNA transfer. Wherefore in this case it is known as DNA replication. But where some viruses have RNA instead of DNA as their genetic material, we speak about reverse transcription (RT). With this transcription, we get a DNA molecule as a copy of the viral RNA genome.

In other words, genetic information, whether historically traced world wide (Narby,1998) or particularly assigned to ancient Africa (Siangla,1997) involves gene expression. Both DNA and RNA are polynucleotides, where nucleotides are the monomer—building units, which are composed of three basic subunits called nitrogenous base, sugar, and phosphoric acid. Genetic information is contained in DNA. The genetic code in DNA expresses the connection between the polynucleotide alphabet of four bases and 20 amino acids. In one strand of the parental DNA molecule, there is a dictated amino acid sequence strictly for protein production.

We will discuss in the next few postings, a relatively detailed understanding of the polymerization of amino acids sequence as directed by base sequences of messenger RNA.

At the moment, though, let us note that protein synthesis is an expression of genetic information. Protein synthesis is the cellular procedure, as we have said, of making proteins and involves two main processes: Transcription and Translation. The two processes mean that the direction of the synthesis is from DNA to RNA and then from RNA to protein respectively. Is this true to all organisms?

Yes. With a few exceptions, which are in mitochondria, and as stated above, some viruses become exceptions to this order because in their genetic material, they have RNA instead of DNA as their initial information source. However it is true that in all organisms, methods that relate the nucleotide sequence in messenger RNA to the amino acid sequence in proteins (genetic code proper) are the same. For in the given exceptions there occurs reverse transcription (RT). With that viral example of transcription noted, we get DNA molecular information being copied from the genome of viral RNA.

Building on this clue that is provided by transcription processes, we can readily see that a three-nucleotide sense codon denotes each amino acid. For example, UUU specifies phenylalanine, UCU specifies serine and GCA specifies alanine. But UAC and UAU both specify tyrosine. We will speak more about this tyrosine when expanding cell biology in the study of melanin.

Here now are other ways to see the remaining three properties of the genetic code. One is the contiguous property. With this property the codons do not overlap and at the same time they do not separated by spacers. The other is degenerate property in which there is more than one codon for some amino acids as exemplified by tyrosine in the above paragraph. And finally, there is the unambiguous property. With this genetic code of unambiguity, each codon specifies only one amino acid.

# Translation[[edit](/w/index.php?title=Cell_Biology/Print_version&action=edit&section=24)]

The Translation Phase of Genetic Expression is divided into 2 Steps Transcription and Translation. During Transcription RNA Polymerase unzips the two halfs of the DNA where it needs to transcript. Then free RNA bases Attach to the DNA bases with the Polymerase starting at the promoter and ending at the Termination signal. From this the RNA can become mRNA, rRNA, or tRNA. The mRNA is a ribbon like strand that takes the genetic information from the nucleus of the cell to the ribosome. rRNA forms a globular ball that attaches to the rough E.R. to help make ribosomes. finally the tRNA forms a hair shaped landing base that reads the genetic information to make proteins. Translation happens when mRNA is pulled through a ribosome and tRNA reads the RNA bases on the mRNA to make anti-codons of 3 bases and brings amino-acids to form the protein. This starts with the condon AUG and ends at UAG. When done the protein forms the correct shape and does the task it was created for. This brings the genetic code from the nucleus, which it never leaves, to the cytoplasm of the cell where proteins are produced to upkeep the body.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Cell_Biology/Print_version&oldid=2506470](http://en.wikibooks.org/w/index.php?title=Cell_Biology/Print_version&oldid=2506470)" 

[Category](/wiki/Special:Categories): 

  * [Cell Biology](/wiki/Category:Cell_Biology)

Hidden category: 

  * [Pages with broken file links](/wiki/Category:Pages_with_broken_file_links)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Cell+Biology%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Cell+Biology%2FPrint+version)

### Namespaces

  * [Book](/wiki/Cell_Biology/Print_version)
  * [Discussion](/w/index.php?title=Talk:Cell_Biology/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/wiki/Cell_Biology/Print_version)
  * [Edit](/w/index.php?title=Cell_Biology/Print_version&action=edit)
  * [View history](/w/index.php?title=Cell_Biology/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Cell_Biology/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Cell_Biology/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Cell_Biology/Print_version&oldid=2506470)
  * [Page information](/w/index.php?title=Cell_Biology/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Cell_Biology%2FPrint_version&id=2506470)

### In other languages

  * [Български](//bg.wikibooks.org/wiki/%D0%9A%D0%BB%D0%B5%D1%82%D1%8A%D1%87%D0%BD%D0%B0_%D0%B1%D0%B8%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F/%D0%A2%D0%B8%D0%BF%D0%BE%D0%B2%D0%B5_%D0%BA%D0%BB%D0%B5%D1%82%D0%BA%D0%B8/%D0%9F%D1%80%D0%BE%D0%BA%D0%B0%D1%80%D0%B8%D0%BE%D1%82%D0%B8)
  * [Português](//pt.wikibooks.org/wiki/Biologia_celular/Organelos)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Cell+Biology%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Cell+Biology%2FPrint+version&oldid=2506470&writer=rl)
  * [Printable version](/w/index.php?title=Cell_Biology/Print_version&printable=yes)

  * This page was last modified on 28 March 2013, at 11:03.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Cell_Biology/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
