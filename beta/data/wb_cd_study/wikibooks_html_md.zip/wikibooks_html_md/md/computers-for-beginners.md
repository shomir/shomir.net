# Computers for Beginners/Print version

From Wikibooks, open books for an open world

< [Computers for Beginners](/wiki/Computers_for_Beginners)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Computers_for_Beginners/Print_version) on _14 March 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&oldid=2501616&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Computers for Beginners](/wiki/Computers_for_Beginners)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&action=purge&printable=yes) this page.

**Computers for Beginners** is a book for people with little or no prior computer knowledge. It will teach basics moving slowly toward more advanced topics. The primary learning technique will be tutorial examples since they facilitate learning more effectively. There will be adequate theory prior to and explaining the examples so the user learns what the computer is doing instead of just memorizing keystrokes and mouse clicks.

![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

A _****printable version****_ of Computers for Beginners is available. ([edit it](//en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&action=edit))

![Gnome-mime-application-pdf.svg](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Gnome-mime-application-pdf.svg/40px-Gnome-mime-application-pdf.svg.png)

A _**[PDF version](//upload.wikimedia.org/wikipedia/commons/1/1a/Computers_for_Beginners.pdf)**_ is available. ([info](/wiki/File:Computers_for_Beginners.pdf))

The initial writing of this book will use mostly examples from Windows XP. However, the theories in the book are applicable to any modern operating system (ex: Linux, OSX, Solaris); these operating systems will not be explained separately right now unless there are fundamental differences.

## Table of Contents[[edit](/w/index.php?title=Computers_for_Beginners&action=edit&section=T-1)]

  1. [Introduction](/wiki/Computers_for_Beginners/Introduction)![75 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
  2. [Buying A Computer](/wiki/Computers_for_Beginners/Buying_A_Computer)![100 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    1. Where to Buy
    2. Processor
    3. Etc.
  3. [Flat Out Basics](/wiki/Computers_for_Beginners/The_Basics)![75 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    1. Setting Up and Turning on the Computer
    2. Free Software
    3. Proprietary Software
    4. Choosing my system - Priority "freedom"
    5. Moving the Mouse
    6. Familiarizing yourself with the keyboard
    7. Launching and Working with Programs and Windows
    8. Gooey GUI
  4. [More Basics](/wiki/Computers_for_Beginners/More_Basics)![75 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    1. Files
    2. Installing Programs
    3. Uninstalling Programs
    4. Customizing
  5. [Security](/wiki/Computers_for_Beginners/Security)![100 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    1. Malware
    2. Firewall
  6. [Office Programs](/wiki/Computers_for_Beginners/Office_Programs)![50 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
  7. [Internet](/wiki/Computers_for_Beginners/Internet)![100 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
    1. The Basics 
      1. What is the Internet?
      2. The Internet and the World Wide Web
    2. Web Browsing
    3. Choosing a Password 
      1. Bad Passwords
      2. Good Passwords
    4. Searching: Getting Here from There
    5. E-mail 
      1. Choosing a username and password
      2. Utilizing the options
    6. Web-based E-mail Programs
    7. E-mail through a specialist program
  8. [Multimedia](/wiki/Computers_for_Beginners/Multimedia)![75 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    1. Games 
      1. Playing Games
      2. Modding/Making Games
    2. Images 
      1. File Types
      2. Viewing
      3. Editing
    3. Music 
      1. File Types
      2. Listening
      3. Editing
    4. Video 
      1. Media Types
      2. File Types
      3. Watching
      4. Editing
  9. [Networking](/wiki/Computers_for_Beginners/Networking)![75 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    1. Setting Up a Home Network
    2. Different Uses of Networks 
      1. Sharing Internet Connections
      2. Sharing Files and Printer
      3. Playing Multi-Player Games
  10. [Tips&Tricks](/wiki/Computers_for_Beginners/Tips%26Tricks)![75 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/b/b6/75_percents.svg/9px-75_percents.svg.png)
    1. Truly Removing Log Off User
    2. Kill the Passport Balloon
    3. Kill the Animated Search Character
  11. [Keeping your PC running Smoothly](/wiki/Computers_for_Beginners/Keeping_your_PC_running_Smoothly)![100 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
  12. [Programming](/wiki/Computers_for_Beginners/Programming)
  13. [Glossary](/w/index.php?title=Computers_for_Beginners/Glossary&action=edit&redlink=1)
  14. [Author(s)](/wiki/Computers_for_Beginners/Authors)![100 percents developed  as of Feb 3, 2011](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)

  
  
**Please add {{[alphabetical](/wiki/Template:Alphabetical)}} only to book title pages.**

![50% developed](//upload.wikimedia.org/wikipedia/commons/thumb/c/c2/50%25.svg/24px-50%25.svg.png)

## Contents

  * 1 Table of Contents
  * 2 Introduction
  * 3 What is a Computer?
  * 4 Buying A Computer
    * 4.1 Selecting
      * 4.1.1 Desktop v. Laptop
      * 4.1.2 Optical Drives
      * 4.1.3 Hard Drives
      * 4.1.4 CPU (Processor)
      * 4.1.5 RAM (Memory)
      * 4.1.6 Operating System
      * 4.1.7 Virus Protection
      * 4.1.8 Video card
    * 4.2 Assembling
  * 5 Flat Out Basics
  * 6 What is a computer?
    * 6.1 Brief History
  * 7 Hardware
    * 7.1 The Insides
      * 7.1.1 CPU
      * 7.1.2 Memory
      * 7.1.3 Hard Drive
    * 7.2 The Peripherals
      * 7.2.1 Keyboard and Mouse
        * 7.2.1.1 Keyboard
        * 7.2.1.2 Mouse
      * 7.2.2 Media Devices (Floppy, CD-ROM, DVD, USB)
      * 7.2.3 Monitor
      * 7.2.4 Printer
  * 8 Software
    * 8.1 What is Software?
  * 9 Setup and Boot
  * 10 Operating Systems
  * 11 Basic Operating Tasks
    * 11.1 Moving the Mouse
    * 11.2 Keyboard
    * 11.3 GUI (Gooey)
  * 12 Windows XP
    * 12.1 Booting for the first time
    * 12.2 Running Windows XP
      * 12.2.1 Some useful keyboard shortcuts in Windows
    * 12.3 Launching and Working with Programs and Windows
      * 12.3.1 Background Information
      * 12.3.2 Opening a Window
      * 12.3.3 Modifying the Window
      * 12.3.4 Moving a Window
      * 12.3.5 Working with Multiple Windows
      * 12.3.6 Task Bar
    * 12.4 Windows Gooey GUI
      * 12.4.1 Menu Bar
        * 12.4.1.1 Common Menu Bar Features
      * 12.4.2 Scroll Bar
  * 13 Linux
    * 13.1 Installing an operating system
    * 13.2 Gnome
    * 13.3 K Desktop (KDE)
  * 14 More Basics
    * 14.1 Files
      * 14.1.1 Background Information
      * 14.1.2 File Naming
      * 14.1.3 Organizing and Creating Files
      * 14.1.4 Moving Files with the Cut, Copy, and Paste
      * 14.1.5 Searching For Files
      * 14.1.6 Shortcuts
      * 14.1.7 Compression
        * 14.1.7.1 Extracting
        * 14.1.7.2 Compressing
    * 14.2 Types of Applications
    * 14.3 Installing Applications in Linux
      * 14.3.1 Arch/Chakra Linux
      * 14.3.2 Fedora/Cent/RHT Linux
      * 14.3.3 Ubuntu
    * 14.4 Installing Applications in Windows
    * 14.5 Uninstalling Applications
      * 14.5.1 Windows
      * 14.5.2 Linux
    * 14.6 Customizing
      * 14.6.1 Start Menu
        * 14.6.1.1 Contents
          * 14.6.1.1.1 Dragging, Dropping, and Right Clicking
      * 14.6.2 Taskbar
        * 14.6.2.1 Auto-Hide the Taskbar
        * 14.6.2.2 Show Quick Launch
      * 14.6.3 Screen Size (Resolution)
  * 15 Security
  * 16 Why Security Matters
    * 16.1 Protect Others on the Internet
    * 16.2 Malware can cause trouble with your computer
    * 16.3 Protect Your Privacy
    * 16.4 Criminal Intentions of Crackers
  * 17 Updating
  * 18 User Privileges
  * 19 Physical Access
  * 20 Malware
    * 20.1 Anti-Virus
      * 20.1.1 Worms
    * 20.2 Spyware and Adware Blocker
    * 20.3 Common Spyware Infestation Methods and Prevention
      * 20.3.1 Internet Explorer/ActiveX Exploits
      * 20.3.2 P2P Apps and other Freeware
  * 21 Firewall
    * 21.1 NAT Firewall
    * 21.2 Software Firewall
  * 22 Office Programs
  * 23 Internet
    * 23.1 The Basics
      * 23.1.1 Where is the Internet?
      * 23.1.2 The Internet and the World Wide Web
    * 23.2 Web Browsing
    * 23.3 Choosing a password
      * 23.3.1 Bad passwords
      * 23.3.2 Good passwords
    * 23.4 Searching: getting here from there
    * 23.5 Email
    * 23.6 Web-based email
    * 23.7 E-mail through a specialist program
      * 23.7.1 E-mail hygiene: viruses
    * 23.8 Online Scams
    * 23.9 Links
  * 24 Multimedia
    * 24.1 Games
      * 24.1.1 Playing Games
      * 24.1.2 Making and Modifying Games
    * 24.2 Images
      * 24.2.1 File Types
        * 24.2.1.1 Compressed Formats
        * 24.2.1.2 Uncompressed Formats
        * 24.2.1.3 Vector
      * 24.2.2 Popular image viewing software
        * 24.2.2.1 Google Picasa
        * 24.2.2.2 Windows Media Player
    * 24.3 Music
      * 24.3.1 File Types
        * 24.3.1.1 Lossy Formats
        * 24.3.1.2 Uncompressed Formats
        * 24.3.1.3 Lossless Compressed Formats
      * 24.3.2 Listening
    * 24.4 Video
      * 24.4.1 Media Types
      * 24.4.2 File Types and Codecs
        * 24.4.2.1 Codecs
        * 24.4.2.2 File Types
      * 24.4.3 Watching
    * 24.5 Glossary
    * 24.6 Links
  * 25 Networking
    * 25.1 Setting Up A Home Network
    * 25.2 Different Uses of Networks
      * 25.2.1 Sharing Internet Connection
      * 25.2.2 Files Sharing
      * 25.2.3 Print Sharing
    * 25.3 Source
  * 26 Tips&Tricks
    * 26.1 Truly Removing Log Off User
      * 26.1.1 1) Using group policies:
      * 26.1.2 2) Using registry
    * 26.2 Kill the Passport Balloon
    * 26.3 Kill the Animated Search Character
    * 26.4 Strange errors
  * 27 Keeping your PC running Smoothly =
    * 27.1 Do Some Research
    * 27.2 Update Everything
    * 27.3 Keep your passwords safe
  * 28 Programming
    * 28.1 Taking your first step into the world of programming
    * 28.2 Types of programming languages
    * 28.3 How programs work
  * 29 Authors
    * 29.1 EuropracBHIT
    * 29.2 Deviance99

  


# Introduction[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=1)]

# What is a Computer?[[edit](/w/index.php?title=Computers_for_Beginners/Introduction&action=edit&section=T-1)]

History of Computers

  
What can a computer do for me?

A computer can improve efficiency, streamline productivity, and facilitate communication as well as entertain.

In the work environment, a computer is used to perform a plethora of tasks. A primary function is word processing. A word processor is considered to be a virtual typewriter; it saves the document on a computer and allows instant editing. It also includes tools to review your grammar and to check your spelling, ensuring higher quality written work!

Another productivity use for computers is creating databases. These databases are easily created and can store information for quick access and retrieval. For example, if you have a large address book and want to get a person's address to send them a letter, you can use an address book application. This application uses a directory, or database, to store the contact information of the people you input into it. Then you can use a search feature that lets you look for a person's name (or part of their name) to quickly find their address, instead of flipping through endless pages of an actual address book.

The computer's original function was calculation. A computer is incredibly fast at mathematical accounting - what would take a human hours to complete can be done in seconds. It is wonderful for keeping track of a budget, planning a savings account or performing thousands of other tasks.

Computers entertain by providing DVD-players and music players. Computers can also play video games. In addition, if you have a decent Internet connection, you can watch one of the many TV shows available online for your viewing pleasure.

One of the most utilized features of computers is the gateway it provides to communication. Even a slow Internet connection will make communication easier.

You can e-mail friends and family.

Electronic-mail, unlike regular mail, provides instant delivery to the recipient. Also, if both of you are simultaneously connected to the Internet, some programs will allow instant messaging. This is a means of communicating in real time. This can help save on expensive phone bills. There are services like Skype that allow phone calls over the Internet as well, and most of them are free!

A computer also provides a gateway to the WEB. A huge library filled with billions of pages that are packed with knowledge and games!

[NEXT>> Computers for beginners/buying a computer](/wiki/Computers_for_Beginners/Buying_A_Computer)

# Buying A Computer[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A Wikibookian has nominated this page for cleanup.**  
You can [help make it better](//en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&action=edit). Please review any [relevant discussion](/w/index.php?title=Talk:Computers_for_Beginners/Print_version&action=edit&redlink=1).

## Selecting[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-1)]

When you choose a computer, it is suggested to think about what you want to do with it. If all you plan to do is surf the web, send a few e-mails and write someone a letter, any new computer you find for sale will work well. Currently available computers have more than enough processing power for the tasks most people use. The more expensive models provide extra performance or software that you may or may not use. In fact, even computers as old as five years may be more than adequate for your needs. You can save a bundle by buying a refurbished or used computer from a big company (like Dell or HP) or from a small, local reseller (like Computer Renaissance -- a franchise/chain). Most people spend more than they need.

What you need to get is determined by what you plan to do with your computer. If you don't plan to play high end games, you don't need a $500 video card, a $1000 top of the line processor, and a $400 hard drive. If you are typing letters to your grandkids there is no way you can type faster than even the slowest new computers. Consider what you plan to do, how much you want to spend and chose your computer from there. Don't be the guy who bought a performance computer and 24" LCD screen when he just wanted to play games!

There are a few choices you have to make, as described below:

### Desktop v. Laptop[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-2)]

It comes down to a choice between size and price. Desktop computers (those with a tower case and a separate monitor) offer better value for money. They are usually cheaper and faster than laptops. Laptops, on the other hand, are easy to carry from place to place and can be set-up on any table or your lap (although lap use tends to be discouraged by manufacturers due to heat issues, and most have gone so far as to discourage the use of the term "laptop", preferring "notebook" instead).

If mobility is a must, or in other words would like to be able to take your computer with you anywhere you go, spend the extra to get a laptop. An important factor to consider with laptops is that, due to their compact design, they are also more prone to hardware failure, making an extended warranty a must. If you just plan to use your computer at your desk at home, save a few bucks and get a desktop. For computer gaming, desktops are generally considered greatly superior, as laptops manufacturers are forced to cram lots of hardware into a small chassis. Most laptops are oriented for business use.

The term "Netbook" refers to an increasingly common subgroup of laptops, small-sized devices which are approximately the size of a small book and so highly portable and easy to carry, able to connect to a network and make use of the Internet. In general, they are significantly less powerful than most computers, CPU wise even the average normal size laptop.

For an idea of how big the difference typically is, a laptop will generally cost 20-30% more than a comparable desktop.

### Optical Drives[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-3)]

Almost all computers come with some sort of Compact Disc drive. With a standard CD drive you can play music CDs and install software stored on CDs.

For a little extra you can get a drive that will play both CDs and DVDs. That means you can watch movies on your computer. The next step after that is what is called a recordable CD (CD-R). This allows you to be able to record your own Compact Discs. You can create music CDs or save data to a disc for safe keeping. Some CD-R can also play DVDs and are called combo drives.

The top of the line are DVD recorders (DVD-R, DVD+R or DVD-/+R). They can create both read and write CDs and DVDs. Most home DVD players will play DVDs that you create on your computer. There are two types of DVD recorders: the +R and the -R. Try to get a recorder that works with both formats. If one will fit into your budget, get a DVD recorder.

Currently, a new type of optical disk, the Blu-ray disk, has been released as the successor to double-layered/doubled sided DVD's. At 50GB storage, it is approximately 3 times as large as the largest DVD. However, Blu-ray disks are expensive, but the price of them has fallen down recently. They are generally used to watch High-Definition Movies (or HD movies) and to store large files.

### Hard Drives[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-4)]

Hard drives are like big filing cabinets for your computer. Although they are all the same physical size (except in desktop v. laptop comparison), hard drives come in different capacities. When it comes to hard drives, bigger is better, within reason. As of early 2010 the bottom end is about a 160GB (gigabytes*). This would allow you to install a quite a few programs and still have room left for your data. An upgrade to a 500GB or 1TB (TB = Terabyte) is a good idea, to give yourself that little bit extra room. If you plan to do lots of video editing, or playing lots of games, you might want to consider drives larger than 1 TB. If you start to run out of room for your stuff you can always add a second hard drive later. Remember, there's no sense in buying a 1TB hard drive if you only surf the Net.

As of 2010, a new category of Hard Drives has appeared. They make use of flash memory, a non-moving component, to store information. It's like a filing cabinet, but it doesn't open or close. Since there are no moving parts, reading from and writing to the disk is now much faster. So far capacity and availability is limited, however as it gets cheaper, it is likely drives like these will be found everywhere.

When sorting through HD controllers, SATA150 is better than IDE, SATA 300 is twice as good as SATA150. IDE and SCIS controllers are rarely found nowadays.

### CPU (Processor)[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-5)]

The processor is the brains of the computer; it does all the calculating. Simply put, faster is better. However, faster is generally more expensive, produces more heat and uses more energy. Unless you plan on playing the latest games, or doing a lot of video editing, buy a middle of the pack processor. You can save some money by going with a slower processor, or spend a few extra for a little more speed. This book recommends that you stay away from the very high end as you spend a lot more money for only a small increase in performance. For instance, the highest-end processor in the Core i7 line, labeled the "Extreme Edition" (EE), will add approximatively $1,000 to the price of the chip for only about a 10% speed increase.

There are two main CPU manufacturers, Intel and AMD. Competition keeps them fairly evenly matched. Intel offers the high-end Core i7's and the low-end Core i3's processors while AMD has the high-end Phenon II lines, and the mid-range and low-range 64-bit Athlon 64, respectively. The low-end processors (i3 and Athlon 64) tend to offer 75% of the performance of their big brothers, at about 50% of the price - although this varies between applications.

### RAM (Memory)[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-6)]

RAM (Random Access Memory), is memory that is not on your hard drive that your computer uses to store things you have not saved, such as a web page, a document that you are typing, or as data from a application. RAM is much faster than a hard drive - every letter you type would take about a second if you used just the hard drive. As with most things computer-related, more is better. This book suggests getting a minimum of 1GB (gigabyte) - 2GB (gigabyte) of RAM. If you have a little extra money, you may want to go with 4GB or 6GB. Unless you are going to be doing lots of video editing, anything over that is a little excessive.

In any case, the amount of memory you will need will be dictated by the applications you will be using. For example, games or graphics-heavy applications such as Adobe Photoshop will demand considerably more RAM than text-based software such as email programs and word processors.

### Operating System[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-7)]

An Operating System is a software that interacts with the applications and peripherals. It is on the users choice which operating system he wants to install. Operating systems come into various categories i.e. some designed to act as server and some as client, server operating system serves many individual computers (client) and Client operating system serves the client itself i.e. your individual computer. Operating system in layman term can be defined as a software designed to enable interaction between the hardware and the user. With the help of the operating system you can install various need specific applications and control the peripherals like printers, modem, speakers and removable drives. In short a new computer is only a naked hardware device incapable of any operation, it needs an operating system that interacts between the user and the hardware to bring desired results for performing various tasks.

Most likely the most essential part of a computer is the operating system. An operating system is what connects the computer to the applications, or programs you wish to use, software speaking.

Although Windows is the most popular operating system, this does not necessarily make it the best. You may also consider an Apple Macintosh system, which places focus on a better user interface, or Linux, which intends to be more compact and reliable. As always, take a look at available options, and choose the one that is the best for you.

### Virus Protection[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-8)]

If you are using Windows, virus protection is recommended. Most of them are paid products that require a subscription such as Norton or McAfee, but there are free products or with free personal licenses (non-commercial uses) like AVG, Malwarebytes or Avast!. Linux and Mac have not received too many recent viruses being small segments of the market (a smaller target) and due to those operative system offering a higher degree of protection against virus. You, Yourself must be very careful on what you download. Try to find history or proof on anything you download to assure yourself that it isn't a virus. Sometimes they will pop up as cool looking games that have to be downloaded. These viruses are very dangerous. Some watch your every move and others can burn out your entire computer.

### Video card[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-9)]

Computers aren't very useful if you can't see anything, unless you build a server or other form of distributed workstation. A video card allows the computer to 'talk to' the monitor.

  * If you plan to do **any 3D** gaming whatsoever, you need a graphics card. There are two main companies who produce graphics card chipsets: ATI and Nvidia. Both make good graphics cards in all price and performance ranges and you should do more research before choosing a specific card. Basically, the more expensive cards allow you to play fancier games. Video cards have their own onboard RAM and have their own processor known as a Graphics Processing Unit (or GPU). Sometimes, you will find PCs with dual graphics. This gives the user 2x the power of one card. It will cost more, as having a 2 card configuration requires a dedicated motherboard.
  * If you only want to surf the web, write documents, send and receive email, then _"integrated graphics"_ are fine and costs much less. Most low-end computers come with what is known as integrated graphics--very basic graphics built right into the motherboard, suitable for business applications.

Also keep in mind that graphics processing requires memory. Memory can be available from any single source on your PC.

  * a video card as described here, that has its own on-board memory
  * video chip(s) embedded on the motherboard that have memory
  * video chip(s) that need to share the RAM described above

Most desktop and notebook computers have only one memory source for processing graphics.

## Assembling[[edit](/w/index.php?title=Computers_for_Beginners/Buying_A_Computer&action=edit&section=T-10)]

    _See also [How To Assemble A Desktop PC](/wiki/How_To_Assemble_A_Desktop_PC)_

Building a computer is not as difficult as it sounds. It is not recommended for absolute beginners, but if you have toyed with computers for some time, it might be a good idea, especially if you plan on playing games. It can save you a bundle on hardware. There is a separate WikiBook on this, as well as some other resources online.

# Flat Out Basics[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=3)]

# What is a computer?[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-1)]

Simply put, a computer is a machine that performs mathematical calculations.

## Brief History[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-2)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Analog_Computing_Machine_GPN-2000-000354.jpg/200px-Analog_Computing_Machine_GPN-2000-000354.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A large computer used in the 1940's.

Computers, by our above definition, have been around for thousands of years. One of the earliest computers was the abacus, a series of beads arranged on metal rods. Beads could be slid and forth to operate on numbers. This was a very rudimentary device and is not commonly thought of as a computer in modern times. Our idea of computers involves electricity and electronics.

Electricity makes computers much more efficient. The first computers used an incredible amount of electricity, which changed voltages in vacuum tubes to operate the computer. These computers were given instructions using punch cards, and were behemoths, taking up entire floors of buildings. Only the more privileged universities and government facilities had access to them.

In the 1960's, the vacuum tube was replaced by the integrated circuit and transistor. These greatly reduced the size and power consumption of computers. They were still very large by today's standards, but more institutions had access to computing power than ever before. At the end of the decade, the microchip was invented, which reduced the size of the computer even more.

By the end of the 1970's, computers were widespread in businesses. Using a computer involved typing on a terminal (a keyboard and monitor connected to a large central computer). Soon, parts became small enough to allow many users to have a computer at their home. Thus the Personal Computer, or PC, was born.

Since then, PC's have become tremendously more efficient. They are much smaller, and yet have seen extreme performance gains. In addition to these improvements, computers have become affordable enough for many families worldwide.

# Hardware[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-3)]

Hardware is the stuff you can touch, as opposed to software which is abstract and exists only in a virtual world as computer code. Hardware is made of materials found in the universe and are subject to the laws of physics. Contrary to the latter, software is bound only by the creator's imagination and the user's willingness to believe what the creator wants them to.

## The Insides[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-4)]

Inside the computer case are various components that allow the computer to run.

### CPU[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-5)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/3/38/Sockel7-cpus.JPG/200px-Sockel7-cpus.JPG)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Several CPU microchips.

The Central Processing Unit, or CPU, does nearly all the calculating. It is the main microchip in the computer that distributes tasks to all other parts of the computer. When most people talk about the processor, or chip, it is actually the CPU they are referring to. CPU is the brain of the central processing unit.

### Memory[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-6)]

RAM (Random Access Memory), commonly called just **memory**, holds computer code that needs to be operated on quickly. RAM is plugged into special slots on the motherboard. There is a large link (known as a bus) from the memory to the CPU, allowing information held in memory to quickly interact with the CPU. The amount of RAM available is limited and therefore needs to be constantly cleared and refilled (don't worry; all computers do this automatically). RAM is just one part of the computer that determines your speed.

RAM is referred to as "volatile" memory because the information stored in it disappears when the power is turned off. Hard drives and flash drives, on the other hand, contain non-volatile memory, which is like paper: it can be destroyed or erased, but when properly taken care of, can last forever.

### Hard Drive[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-7)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Harddisk-full.jpg/200px-Harddisk-full.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A partially dismantled hard drive, showing the disc inside.

The hard drive is the main storage area in the computer. It is usually where you put your data to be stored permanently (until you choose to erase it), and it retains data after power is removed.

Virtually all of your data is stored on your hard drive. A hard drive is composed of disk(s), where the data is recorded onto the surface, similar to records, CDs, and DVDs. The size of the hard drive (today's are usually in gigabytes) is determined by how dense (small) the recording is. Many of today's major programs (such as games and media creating and editing programs like Photoshop) and files (such as pictures, music, or video) use a considerable amount of space. Most low-end computers, as of 2011, are shipped with a 160GB (gigabyte) or larger hard drive. As an example, an average .mp3 file takes between 7.5 and 15MB (megabytes) of space. A megabyte is 1/1024th of a gigabyte, thus allowing most new computers to store thousands of such files.

Users who wish to store a lot of media on a computer will want a larger hard drive, as will users who want to store numerous large programs, like modern games, which require a lot of space. Most video games today are distributed via DVD discs that store data, called DVD-ROM (read only memory, which can be read off the disk, but not modified), which can be anywhere from 4.7GB for a single layer disk to 8.5GB for a double layered disk...and many large programs are already taking up more than one disk.

Another concern for users who want higher performance is hard drive speed, measured in RPM (rotations per minute). Most desktop hard drives today are 7200RPM models, with lower end 4200RPM models not commonly seen in new systems (other than laptops), and higher end 10,000RPM hard drives generally seen only in gaming and other extremely high performance computers due to their cost. For example, a 1TB 7200RPM drive costs around 85$ (as of January, 2011), while a 300GB 10,000RPM drive costs almost 300$ (as of February 2011).

Hard drives are constantly increasing in size, both because technology allows, and because of demand for more storage space. For example, an Apple iMac in the late nineties shipped with a 4GB hard drive, and sold for 1,300$ US (although it should be noted that the cost alone is not indicative of the hard drive, or vice versa), compared to a modern iMac which sells for 1000$ US and carries a 160GB hard drive(As of April 2007). Compare to the original IBM PC, which carried only a 10MB hard drive, or 10/1024th of a GB.

Some high end computers already have more than 2 Terabytes, and within decades Petabytes (thousands of Terabytes) and even exobytes (Thousands of Petabytes) will not be unheard of.

## The Peripherals[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-8)]

Peripherals are hardware attached to a computer, but external to the main case that houses the CPU, Hard drives, and other such equipment. They are basically devices that allow people to communicate to the computer. It is generally a good idea, although not as important as it used to be, to add and remove hardware from the computer while it is turned off. Things such as USB storage devices and keyboards/mice can generally be inserted and removed at a whim with no consequence, however more advanced things such as printers should be installed according to the manufacturer's instructions, which may include shutting down your computer.

### Keyboard and Mouse[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-9)]

The keyboard and mouse are basic input devices.

#### Keyboard[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-10)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/99/Cherry-keyboard-big-Enter.jpg/200px-Cherry-keyboard-big-Enter.jpg)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A keyboard with a QWERTY layout.

The keyboard has keys that, when pressed, send information to the computer. The keyboard is the most widely used device for interacting with a computer, and even many modern operating systems, such as Microsoft Windows XP can be operated with nothing but the keyboard or little but the keyboard. The most commonly used keyboard, by far, is the QWERTY layout, which almost all keyboards sold use. This is the same layout as most typewriters sold within the last century. The second most common, but a very distant follower, is the Dvorak Simplified Keyboard. While this is technically better, the industry and consumer market as a whole has mostly rejected it.

The QWERTY keyboard was designed to prevent typewriters from jamming while keys were being pushed at a fast rate, by keeping keys as far apart as possible. The Dvorak keyboard layout was designed for computers, where this is obviously not a problem, and thus places the most commonly used keys where they are easy to reach, and because of that, quicker. However, because of the popularity QWERTY had, the Dvorak keyboard layout never became popular, for two main reasons. The first being that because most people already know how to use QWERTY keyboards, and people are thus unlikely to switch, and the second being that because most people know how to use a QWERTY keyboard, there is very little use of Dvorak.

It is generally advised that you use a QWERTY keyboard, as even though Dvorak users gain significantly faster typing speeds, the rarity of the layout makes it hard for people who use Dvorak to use most other computers.

Keyboards vary in appearance. Those attached to a desktop computer are frequently large with an additional number pad built in on the right side, while laptop keyboards are attached to the computer and are often much smaller. Some keyboards also offer special buttons to control the mouse on the screen or to play music.

#### Mouse[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-11)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Wheel_mouse.JPG/200px-Wheel_mouse.JPG)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

A three button mouse.

The mouse is an input device which is primarily used by physically moving the device across a surface, which causes a pointer symbol, called a "cursor", to move across the screen, and secondarily by pressing a button while the cursor is over an object on the monitor, or "clicking". All mice have at least one button, with the most common layout having three.

  * One button mice: The Apple mighty mouse is the only mouse known to most people which uses a single button. This button is usually activated by pushing on the front of the mouse, or pushing the entire mouse down. This has the benefit of being a simpler interface, and arguably more attractive, but suffers from this of being slightly more of a hassle to use, with tradition "right click" needs being changed to pressing a "control" or "ctrl" key on the keyboard while pressing the main button. These are only used with Macintosh OS, such as Mac OS X.
  * Two button mice: The second most common layout, more common in older computers, which has a button on the left and right, usually for the index and middle finger. While less useful than a three button mouse, they are, when teamed with a standard keyboard, capable of performing almost all computer tasks.
  * Three button mice: The most common layout, Fundamentally the same as a two button mice, but with a third button added between the "left" and "right" click buttons. While the mouse technically has three buttons, this may be confusing to some users, as the "middle"/"center" click button is also a scroll wheel. This design allows the user to scroll through documents, make selections, and do other tasks by moving a finger, rather than pressing an arrow key or "Page up/Page down" key on a keyboard. The center button can also be press inwards to create a "middle click" button, which although not common, is used in some programs to perform a simple function, such as the Firefox web browser, which uses the middle click to open a link in a new tab.
  * Four (or more) button mice: Usually seen only on gaming and multimedia specialization mice, extra buttons generally do not serve any native purpose, and rather are assigned a function to perform by the user. For example, a user who uses the mouse to play games might assign the additional buttons to switch between weapons in a shooter, or cast spells in a fantasy game.

There are two other major differences in mice, which is Optical/Laser mice, and Ball mice. This is how the mice tells where it is, with the laser measuring the distance it crosses when it is moved, and the ball measuring how it rotates. The laser is generally more accurate and less of a hassle to use, and can be used on more surfaces, but the ball mouse is cheaper. Ball mouse are rarely seen today.

The last important consideration when buying a mouse is size. You should always try to put your hand on a mouse and move it around, to see how well it feels in your hand. If it feels awkward, small, big, long, or short, look for something better! Not only will your hands thank you, but you will be more efficient.

### Media Devices (Floppy, CD-ROM, DVD, USB)[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-12)]

These devices carry data, in the same way that a hard drive does, but are much more portable. They are the primary method of storing data outside of a computer, and the main method of transferring information between computers without the use of a network, such as the internet.

There are three main types of these in use today:

  * CD-ROM: Capable of storing 700MB of data, CDs have been the most common method of storing data for most of the last decade or so. They are being largely replaced by DVDs and USB drives (see below).
  * DVD: Capable of storing 4.7GB of data in their single layer form and 8.5GB in their double layer form, they are the most common method today for most store-bought programs, as well as videos.
  * USB/Flash: While not usually used by commercial software, USB 'sticks' and Flash 'cards' have become popular ways of storing data because of their ease of use and low cost. While sizes range from 2GB on old units to 256GB on larger, more expensive modern units, the average stick today is 4 or 8GB, with an average 4GB USB stick costing about 15$ US.

The floppy disk has been phased out.

### Monitor[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-13)]

The monitor is the main method for the computer to produce output, in the same way a book has pages. A book filled with letters, but in a way you can't possible understand or even see is of no use to you, and the same is true for a computer. While older monitors, CRTs, were rather bulky like TVs, newer monitors, or LCDs, are much more compact, and can be easily lifted.

For much of the history of computers, the most common monitors were CRTs, short for Cathode Ray Tubes. They work on the same principle as a television. They were generally heavy, had a lower image quality, and were in general less reliable than an LCD. They come in two forms, the normal version, which has a curved monitor, and "Flat Screen", where the display is completely level (although it still has the bulky back end). It is suggested that if you plan to remove a CRT, it is better for the environment to safely dispose of it (not just into a bin, an electronic waste bin), as CRT's contain high levels of toxic chemicals. The most common type of monitor today is an LCD, or Liquid Crystal Display, which is much lighter, although slightly more expensive. They have a smaller form, a higher image quality, and are overall better than CRT monitors.

_Tip: To take proper care of your monitor, always be sure that the screen is not left on a static image for long periods of time. This can "burn" the image into the monitor, meaning that it will have a ghosting effect, even when that image is not displayed. This can not only be highly annoying, but in some cases, make it so the monitor needs to be replaced. To avoid this, either set a moving screensaver, which will trigger after a set amount of time, or simply turn the monitor off_

### Printer[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-14)]

If you have a printer attached to your computer you can print your information and keep a physical copy of data. Depending on what type of printer you have, you can print in color, double-sided or book form. The output quality of some printers goes from draft (to save ink) all the way to photo quality.

Printers come in all price ranges and in many types. The most common for home use are ink jets (bubble jets) and laser. There are specialized printers for data plotting (mapping), photos only, labels and more.

A lot of printers are "all-in-ones" which simply means they combine more than one function. They can be any combination of printer, copier, fax and scanner. If you are looking to buy an all-in-one make sure it has all the features _you_ are looking for. You don't want to get it home and find out you still need a separate fax machine or scanner that you thought was included!

# Software[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-15)]

## What is Software?[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-16)]

Software is what allows the computer to run. Think of the computer as a person — even with strong muscles, sharp eyes, and a brain to rival Einstein, it's not much good if you can't even think! Software is what almost all people use to input to the computer. Software makes it much easier for the average person to use a computer, especially without training.

If it weren't for software, you'd have to train for years to be able to even check email, and when you did check it, you'd wish you'd just gone to the post office!

If you buy a computer from a store, instead of assembling it yourself, it will almost always include an operating system (usually Microsoft Windows), which will include almost all of the software the average person will use on a day to day basis. However, you should be careful to check, as it is not unheard of to buy a computer thinking that it's cheap, only to find out that you cannot run anything on it due to the lack of an OS!

While most software is designed to be easy to install and use, there will likely be some programs that will be hard to install (this is much more the case on Linux than on Mac OS X or Windows 7), and the easiest way to figure these out is to look for the answer with a search engine, such as Google.

# Setup and Boot[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-17)]

The first thing to do after taking your computer out of the box is to set it up. While many stores offer at home installation, this is generally unneeded for anyone able to operate a computer, as a computer can be hooked up with about the same effort as a television and components.

The basic parts are:

  * The Case: Also known as the 'tower', or incorrectly as the 'CPU', the case is what stores all of the brains of the computer- the graphics card, processor, hard drives, etc. This is the most important and expensive part of your setup, and technically the 'computer' itself.
  * The monitor
  * The keyboard/mouse

You may want Speakers, microphones and webcams to be able to hear sound, input sound or input film clips.

Simply place the case wherever you wish to have it, plug the monitor's cable into the appropriate slot on the back of the computer (should have a monitor picture on the slot), place the monitor where you wish to have it, plug the monitor's cable into the monitor (the ends are usually a white (DVI-D) or blue (VGA, being phased out), plug the keyboard and mouse into the appropriate slots on your computer (USB), and lastly plug the power cable into the power supply on the back of the computer, and into a standard wall outlet. You should consider using a surge protector to protect the delicate electronics inside a computer from any power surge, or loss. You may also consider using a power backup, which will allow you time to shut your computer down safely during a blackout, or even continue to use it until the power is restored, in some cases.

You may have a laptop/notebook computer, which all of the components are integrated into a single compact source that you can carry in a briefcase/backpack. In that case you need only plug in your battery and power cord. Follow the instructions provided by the manufacturer of the computer for putting the battery in the laptop/notebook and plugging in the power cord.

Some additional models differ from the above two designs. For example, the iMac series of Apple computers have the internals and monitor housed in one case, with only the keyboard and mouse separate. Please refer to your instruction manual for setup instructions (Apple usually has very clear instructions). **Note:** Many of the instructions in this Wikibook require a Windows computer.

After everything is assembled, proceed to turn on your computer and your peripherals. It is important to turn the monitor and speakers on first so that you can hear and see any error sounds or messages. You should also pay attention to your computer, and be ready to turn the power off immediately if there are any problems, such as the fans not starting. Though you should be careful, as computer fans can be extremely quiet, if the fans do not start, immediately turn the computer off to prevent the CPU and other delicate components from overheating.

# Operating Systems[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-18)]

The major software application on a computer is called the operating system. The operating system is like the driver of a car. While it might seem like it's only telling the car (computer) what to do, it is in fact also interfacing with the different parts of it, as well as taking any new input (say, a map, or instructions on where to go- which equates to other software) and performing these tasks to the best of its ability. Although many things are compatible across platforms, more involved programs, such as photo editing tools and games, will not work across all platforms, in the same way that if you started giving your cab driver directions in French, he'd probably tell you to get out, unless you were of course, in France!

An operating system, aka "OS", is the middleman between you and the computer. It creates an environment where the user can interact with the computer in an efficient manner.

There are three major OS that you should consider using for your first desktop/notebook PC.

  * Windows: The most recent edition of Windows is Windows 8, previous versions are Windows 7, Windows Vista, Windows XP, and so on.
  * Mac: The second most common OS in desktop systems, Mac OS X is comparatively compared to Windows, although it's market share is increasing. Macs have been designed to be very easy for people to use, and are thus a good choice for a first system, as long as you don't mind not having as many software and games options as Windows users. Many Mac users are extremely loyal to the OS, due to the popularity of the iPod MP3 device, and various other Apple iDevices.
  * Linux: While it is also rare compared to Windows, Linux does have it's advantages. Linux is open source, which means that anyone can change the code around and redistribute it as they want, resulting in many different versions. Though it can be daunting, a Google search can help the average person decide which version of the OS would be best for them. There is a wide range of versions, called distros, ranging from one that's meant to fit on a 50MB business card sized CD to ones that are meant to be easier to use than Windows! Linux can be harder to use than Windows at times, especially because it is almost required that you use the command line occasionally, however users who are willing to put in the effort to search for a solution (usually quick and easy) and copy/paste the answer into the command line will generally appreciate it, with some being as devoted or more so than the aforementioned Mac users! Linux suffers many of the same downfalls as Mac, however, including a lack of commercial software, especially games. This is slightly remedied by the large amount of free, open source Linux games, and the WINE program, which can run many Windows programs, including games, under Linux, without having to emulate the Windows OS. While many 'hardcore' gamers are disappointed by the lack of games, even compared to the Mac, there are many games which are either native to Linux, or work well enough under WINE that most casual gamers will not have a problem. The most popular Linux distro, Ubuntu, has a clean interface and a thorough help system.

# Basic Operating Tasks[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-19)]

### Moving the Mouse[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-20)]

The mouse controls the movement of an on-screen pointer, called the cursor, that often appears as a small white arrow. When you move the mouse, the pointer on-screen moves too, usually in the same direction as the mouse. In other words, move the mouse toward you to move the on-screen pointer toward the bottom of the screen, you move the mouse to the away from you and the arrow moves to the top, and so on. You indicate to the computer what parts of the screen you want to interact with by placing the pointer over those areas on the screen.

### Keyboard[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-21)]

The keyboard is used for inputing text into the computer. It is designed so that users can type all the letters of the alphabet without moving their hands. Many programs from word processors, media players utilize the keyboard.

  * The numbers at the right of the keyboard can work in two ways. While in normal mode, the keys will function as another set of arrow keys, in num lock mode, they will instead be an alternate way of inputting numbers. This is mainly useful when putting in more than a few digits at a time, when using the numbers over the letters becomes more of a hassle than a time saving method.
  * The keys labeled F1, F2, F3 ... at the top of the keyboard are the "function keys". F1 is usually assigned as a "help" key, which will open a help dialog when pressed. If you are having trouble with a program, or just want tips, reading these files can often be useful or insightful.
  * "Ctrl" and "Alt" at the bottom means "control" and "alternative". These keys are normally used to type special symbols or for **shortcuts**. More on that below.

## GUI (Gooey)[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-22)]

Almost all programs that you will be working with will have a **GUI** or **Graphical User Interface**. The GUI is the 'pretty' part of a computer ― the windows, buttons, scroll bars, and task trays. The GUI is really just a front for the command line, which is what does the actual process and such. While almost all Windows and Mac users do not need to worry about this, it is important for users of Linux to know, as they will use the command line for tasks which either cannot be done or are more efficient to do through the command line terminal.

# Windows XP[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-23)]

## Booting for the first time[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-24)]

Turn on the computer as described above.

The boring process of booting up will begin. Booting is just starting up the computer. (Remember to turn on peripherals first!). This may take a few minutes, so be patient. Your computer is testing itself and running a bunch of internal functions that you'll probably never have to worry about. You don't care what's happening inside when you turn on your TV. You just want it on. It's the same with the computer. Just let it do its thing!

If it is the first time booting up the computer running XP operating system, a prompt asking you to choose a user name and password will appear; you may enter up to five different users. Note: if you want the computer to just boot up straight into Windows XP every time you use it, you should create only one user and not enter a password. In Windows XP Home edition, different users have the same programs installed, but may choose different backgrounds for their desktop (more on this later), and have different program icons on it as well; if you have Windows XP Professional, the differences are much fewer. Passwords should be secure, but not as secure as if it were an online password, as you only need to prevent people accessing the actual computer itself- make sure if you choose a password you can remember and _write it down_, as this is one password you simply _cannot_ afford to lose. DON'T ever tape your password to a keyboard or other part of your system. That's the first place everyone looks! There will be some questions that show up on the screen. Answer them the best you can and if you're not sure, use the default. You may be asked to activate your software if the installer has not done so. Microsoft requires you to activate XP. If you don't activate it will quit working and you'll have to install it all over. Activation is usually done over the internet but can also be done by phone. The number will appear on the screen. Register it ASAP!

## Running Windows XP[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-25)]

Now Windows XP has booted up, hopefully, and is running. You should now be looking at a rolling green hillside with a blue sky and clouds. This view is called the **desktop**, which makes sense. The rolling green hillside is called the **background** and can be changed to a variety of pictures installed with Windows XP, or to one you yourself load onto your computer. You'll probably notice a couple of pictures with words like "AOL Free Trial" or "Shortcut to...something" beneath them (don't panic if these particular ones aren't present). These are called **icons** and are linked to specific actions, usually opening a **program** (see below). You can create your own icons, as well as delete ones you do not want. Don't worry, this will be explained later. The blue bar at the bottom of the screen is called the **taskbar**. If you have a program open, it will be represented with a little icon and a name here. On the far left of the taskbar is a large green button which says START; this is logically known as the **Start menu**. If you left click (hereafter simply referred to as "click") it with your mouse, you will open a **menu** which contains links to almost everything in your computer (the first time you ever start Windows XP, the Start menu will automatically be displayed). On the far right of the taskbar, you will see a notification area known as the **system tray**. It contains both temporary and constant notification icons. Right now, it probably has only the clock and a button with a message, asking you to click it if you want to take the Windows XP tour. If you are unfamiliar with computers, it is highly recommended that you take the tour. If you wish to wait, you can take it later by clicking on the **Start menu**, clicking **All Programs**, clicking **Accessories**, and clicking **Tour Windows XP** (this type of menu action will from here on be represented as **START -> All Programs -> Accessories -> Tour Windows XP**).

### Some useful keyboard shortcuts in Windows[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-26)]

The following keyboard shortcuts are used for frequently performed tasks and will speed up your computing. They normally work on all major platforms (Windows, Linux, Mac). (**NOTE:** When you are asked to press multiple buttons at once, you can first press the buttons Ctrl, Alt and Shift, and while keeping them pressed, press the remaining button. For example, to press Alt+Tab you first press and hold down Alt, then momentarily press tab, and then let go of the Alt key.)

  * When filling out a form or a dialogue, enter the text, the press "tab" to get to the next text box or button. To go backwards, press Shift-Tab. Press "enter" to press a button. This will save you from taking your hands off the keyboard to use the mouse.
  * To copy a selected text, or a selected file or folder, press "Ctrl+C"
  * To paste the text or file into a new location, press "Ctrl+V"
  * To select all the text (or items) press "Ctrl+A"
  * To switch between open windows press "Alt-Tab"
  * To log off from you session or to shut down the computer press "Ctrl-Alt-Delete"
  * To select a piece of text or a list of files or folders, click the left mouse button on the starting position, then press and hold "Shift", then click on the end position, then release "Shift"
  * To select text, files, or folders that are not contiguous (side-by-side or together), select the first item by clicking; next press and hold the "Ctrl" (control), click the next item, release the "Ctrl", repeat if necessary.

## Launching and Working with Programs and Windows[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-27)]

#### Background Information[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-28)]

A program does something. Programs can process words, play music, and much much more. One simple program is called Notepad, and it is on many computers. Microsoft Word is a program, AbiWord is a program, and Mozilla Firefox is a program. They will be explained later.

#### Opening a Window[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-29)]

Now it is time for a tutorial.

  1. Left click on the Start Menu. It is in the lower left corner of the screen.
  2. Put the mouse over the words that say "All Programs" or "Programs" (This depends on if you have the classical start menu or not which will be discussed in **a chapter about customization**)
  3. More menus will come out of the arrow. Bring the mouse up to accessories and let it expand.
  4. Click on Notepad.

Another way to say steps 1-3 in a simple fashion is **Start -> All Programs -> Accessories -> Notepad**.

#### Modifying the Window[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-30)]

After doing this, many things happen. First of all, a window appears on the screen. Notice that there are three boxes in the upper right hand corner of the window.Here is what they do:

  1. Click the first box going from left to right. Oh no! It's gone! Don't be startled because Notepad hasn't been lost in oblivion. It's just been minimized.
  2. To get it back, look at the bottom of the screen. You will see a rectangular box that says "Untitled - Notepad". Almost every program will have this little box located in the task bar. When it is gone, the program's not running. Now, click on the box to see Notepad again.
  3. Click the middle square. Notepad now takes up most of the screen. This is called maximizing. Look at the icon that you just clicked. It has changed.
  4. To get it back to normal, click the same button. That is called restoring.
  5. Click the last square (with a big X on it) to close the window. It is gone for good and will never come back (until you do what you did in step one of Opening a Window again). This button is called the "X" button. If someone wanted someone else to press this, they could say "X it out."

#### Moving a Window[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-31)]

Now it's time to learn how to move windows.

  1. To begin, open Notepad again with your new skills.
  2. The place in the border where the three buttons are located is called the titlebar.
  3. Click anywhere on the titlebar except the boxes and hold the mouse button down.
  4. While still holding the button, move the mouse pointer. This is called "dragging". The window will follow the mouse and become an extension of your hand.
  5. When the window is in that perfect location, let go of the button.

#### Working with Multiple Windows[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-32)]

The great thing about computers is that they allow for multi-tasking. You can listen to your favorite tunes, write a book, get work done, chat with their friends, and check your e-mail all at the same time. This can be done with much ease if learned correctly.

Time to get busy.

  1. Open Notepad again.
  2. Open Wordpad, which is located in **Start -> Programs -> Accessories -> Wordpad**.

There should now be two windows on the screen. The Wordpad window is the active window. We know this because its titlebar is brighter than Notepad's. Also, Wordpad's taskbar rectangle is a different color than Notepad's. When a program is active, keyboard and mouse input will go to that program.

  1. Type "Hello." The text is in Wordpad's window because this is the active one. (If nothing shows up, then click in the part where you would type in the Wordpad program).
  2. To make Notepad active, click on its titlebar. If it is covered by Wordpad, move it out of the way (by dragging it). Notepad will come on top of Wordpad once it is activated.
  3. To make Wordpad active again, click its rectangle in the taskbar.
  4. Play with the two programs until you get the hang of working with multiple windows. Use the maximize and minimize buttons. Don't really click any of the buttons on the programs yet. You'll learn that soon enough...

### Task Bar[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-33)]

There are a few more things you should know that you can do with the **task bar** to customize its appearance and behavior:

  1. You can **lock** it (preventing other alterations listed below) 
    * To check if the task bar is locked, hover the mouse over some part of the task bar not occupied by an icon, then click the right mouse button. A **pop-up menu** will appear, with an item "Lock the Taskbar" on it (among others). It can either have a checkmark next to it on the left, or not. If there is a check mark, the task bar is locked. If not, then it's not locked.
    * To change the locked state of the task bar, click on the "Lock the Taskbar" menu item, and the state will change to its opposite - if it was locked before, clicking unlocks it; if it was not locked, clicking locks it.
  2. You can **resize** it (made larger, smaller, or even concealed, vertically) 
    * To do this, the task bar must be unlocked (see immediately above)
    * Click and hold the thin border immediately above the task bar (you should see the cursor change to an up-and-down arrow), and "drag" it upward. You'll see that the task bar becomes fatter, giving it more room for program and quick-launch icons. Dragging it downward does the opposite. If you drag it all the way to the bottom of the screen, the task bar vanishes (except for its sizing border, which you can drag upward again to bring back the task bar.)
  3. You can also **move** it to the top, right, or left edge of the screen 
    * To do this, hover the mouse over some part of the task bar with no icon, then click the left mouse button and hold it down. Then move the mouse up, to the left, or to the right, and observe that the task bar will vanish from the bottom of the screen and reappear at the left, top, or right (according to which direction you dragged it.) When you release the mouse, the task bar will stay where you placed it.
  4. You can select which of its component **tool bars** are displayed on it 
    * _(how-to goes here)_
  5. You can resize (horizontally) the visible **tool bars**
    * _(how-to goes here)_
  6. You can set other **properties** of the task bar, such as whether the clock appears on it, or whether the task bar **auto-hides** itself 
    * _(how-to goes here)_

## Windows Gooey GUI[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-34)]

### Menu Bar[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-35)]

  1. Open Notepad. 
    * Right under the titlebar, there will be a menu bar. There will be File, Edit, Help, and more.
  2. Put your mouse over the word File and click. 
    * A menu will pop up under the word and some choices will appear.
  3. Click Open. 
    * This will open up a dialog to open an existing text file. You don't have to open anything yet but you may if you want.
  4. Click Exit. 
    * This will close the program. It's another way of pressing X.
  5. Open up Notepad and explore the menus. 
    * Nothing will break. If you see something confusing, press cancel. Remember that a great way to learn about the computer is to do stuff on your own. Try opening up other programs from the menu and see what they do. Just try to get comfortable with using the computer.

#### Common Menu Bar Features[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-36)]

Most programs share at least some similar menu bar items. Below is an overview of basic buttons found in the menu bar. It is broken down the same way that the menu bar is. Try these out.

  * **File** \- Basic tasks like saving, opening, printing, and quitting are in the File menu.
  * **Edit** \- The Edit menu can do a number of things: 
    * **Cut, Copy, Paste** \- This is the same thing as right clicking where the curser is and pressing cut, copy, or paste. That means also that it's the same thing as Ctrl-x, Ctrl-c, and Ctrl-v, respectively. To learn more about cutting, copying, and pasting, click here.
    * **Undo/Redo** \- If you ever make a mistake that's hard to fix, like deleting your 10 page paper, a great thing to try is Undo. Most of the time, programs will let you undo numerous times. Redo redoes what you undid with the Undo button. It's like pressing Back and Forward in a web browser. Also, Ctrl-z and Ctrl-y are for Undo and Redo.
    * **Find/Replace** \- Find and Replace are very useful tools, and they are incorporated into many programs. One example below will show how to use find, and the other will show how to use replace. 
      1. Let's say that a woman is on a webpage about muffins, but the only thing that she cares about are blueberry muffins. In order to save time, she goes to Edit -> Find. Then, she types "blueberry". The computer shows her every time that the word "blueberry" is on the page. This also works on other things such as word processors.
      2. Another person writes a 5 page essay that was supposed to be in third-person. However, he has a whole bunch of "you"s in his paper. In order to fix that, the person goes to Edit -> Find/Replace. In Find What, he puts "you" (without quotes), and in Replace With, he puts "one" (without quotes). After clicking "find" and "replace" enough, all the instances of "you" were changed to "one", and whoever wrote the essay got an A+.
  * **View** \- Options in here can change the appearance of a program. Most of it depends on the program you're using. 
    * **Toolbars** \- This lets you decide what toolbars to display if the program has a lot of them. An example of a toolbar is the one with the Save, Open, and New buttons.
  * **Help**
    * If you are wondering how to do something in a program, a good place to look is in Help. After opening the Help menu, you can find help by choosing "Contents" or "Help Contents" or "Online Help".
    * **About** \- A general description of the program you are using is in here. Another useful thing found in here is the version number of the program.
  * **Preferences**
    * Many options for customizing a program can be found in Preferences. It is a window that comes up and is usually organized with tabs. Preferences can usually be found in Edit -> Preferences or Tools -> Options.

### Scroll Bar[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-37)]

When there is too much stuff in a program to be displayed on the screen, a scroll bar appears in the right hand side of the window. Using this scroll bar, one can go up or down through the text or whatever needs scrolling. Scroll bars can also appear on the bottom of a window to scroll left and right. You scroll by using the following methods:

  * Click the squares with the arrow icons. Up is for up, and down is for down. Every time you click the arrows, the bar between them (known as the "scroll bar") goes up or down automatically.
  * Click and hold the scroll bar and drag it. Dragging it down scrolls down the text, and dragging up scrolls up. Release the mouse when finished.
  * There may be a small wheel on your mouse. This is called a "scroll wheel". It will most likely be between the two mouse buttons. You can use this to scroll up and down.
  * The Page Up and Page Down buttons on the keyboard will scroll up and down in large increments.
  * The arrow keys on your keyboard can sometimes be used for scrolling.

On some occasions, there will be scroll bars inside of scroll bars. This may be confusing, but you'll get the hang of it.

# Linux[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-38)]

Linux is an operating system, much like Windows is. The word "Linux" comes from the name of its kernel, which was originally created by Linus Torvalds, while he was still in college. There are other important parts which define the operating system (at least in the sense of the term in which user’s programs are part of an operating system), so you may find other names for the same thing: "GNU/Linux" and "GNU". In its early stages, it had a command interface (that's where you HAVE to type exactly what you want the computer to do), but has now grown into fully featured OS used by enterprises, developers, and power-users at home.

Known worldwide as the core of the Open Source world, Linux is "free" (as in "freedom") by allowing the average user to observe and make changes to the source code of Linux as needed. That means if YOU want some kind of special functionality, YOU can implement it. You can also make copies of GNU/Linux and other free (as in freedom) programs, and give them to other people, while sharing a copy of Windows or Mac OS X is illegal in some countries. For that reason, Linux is as diverse as the humans that inhabit the Earth. Unlike Windows, where there are only a few choices of the OS, there exist literally hundreds of variations of Linux, each of which is created and maintained to perform a specific function for a community of users.

## Installing an operating system[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-39)]

A computer needs an operating system to start running, like a car needs an engine to start moving. But installing an operating system is not for beginners, like installing a car engine is not for beginners. Many excellent car drivers have never installed a car engine.

Recent versions of Linux are widely considered the easiest-to-install operating system so far -- some people say "a chicken could install Linux". However, installing any operating system is not recommended for beginners, and so is outside the scope of this book. After you finish this book, you may be ready to go on to a book that discusses booting a LiveCD or even installing an operating system, for example [A Neutral Look at Operating Systems/Linux#Live CDs](/wiki/A_Neutral_Look_at_Operating_Systems/Linux#Live_CDs).

## Gnome[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-40)]

## K Desktop (KDE)[[edit](/w/index.php?title=Computers_for_Beginners/The_Basics&action=edit&section=T-41)]

![](//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Book_important2.svg/40px-Book_important2.svg.png)

**A Wikibookian has nominated this page for cleanup.**  
You can [help make it better](//en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&action=edit). Please review any [relevant discussion](/w/index.php?title=Talk:Computers_for_Beginners/Print_version&action=edit&redlink=1).

KDE is a Desktop Environment which basically is a style of your GUI for your open source operating system. The project was founded on the 14th of October 1996. It has many, many tools such as [K3B](http://kde.org/applications/multimedia/k3b/), [Koffice](http://www.koffice.org/), and [Kile](http://kile.sourceforge.net/). KDE is very user friendly. Some snapshots of KDE and some of its applications:

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Snapshot.png/120px-Snapshot.png)

KDE Snapshot

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Kapman.png/101px-Kapman.png)

Snapshot of Kapman, a Pacman clone

  * ![](//upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Control_panel_for_the_KDE_Dolphin_file_manager.png/120px-Control_panel_for_the_KDE_Dolphin_file_manager.png)

Snapshot of the Dolphin File Manager

# More Basics[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=4)]

## Files[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-1)]

### Background Information[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-2)]

Any information that is stored on the computer for later use is saved in a file. If there was music on your computer, it might be saved in an mp3 or ogg vorbis file. If one acquired a picture of a monkey and wanted to save if for later use, they might save it as a jpg or png file.

### File Naming[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-3)]

When there is a file on the computer, it is saved on the **hard drive** with a name. This name can be whatever you may desire, but it will have an extension at the end. For example, the picture of a monkey might be called monkey.png. There may be spaces, dashes, and underscores in file names. Using any other special characters such as parenthesis and @ symbols is generally a bad idea. Capital Letters can also be used. If you had a band with the name of Green Pickles and a song called Soup, the name for this song on the computer could be GreenPickles-Soup.mp3, Green Pickles - Soup.mp3, green_pickles-soup.mp3, or whatever you want.

There will also be times when files don't have an extension. Those are mostly text files or executable files which will be explained.

### Organizing and Creating Files[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-4)]

Hard drives are very big these days, and people have a whole bunch of files. To organize all of these files, a method that can be thought of as a brief case can be used. To look at files, humans use a file manager. Clicking on My Computer from the desktop or start menu will do.

Try this:

  1. Click on My Computer on the **Desktop** or Windows Explorer (Start -> Accessories -> Windows Explorer).
  2. Go to Tools -> Folder Options... and click on the File Types tab.
  3. If "Hide extensions for known file types" is checked, uncheck it by clicking in the checkbox. 
    * The previous two steps are not necessary but very useful.
  4. Go to the c: drive (pronounced "c drive") by double clicking on it. 
    * You have just dived into your hard drive. This is where most of your files are stored.
    * a is the floppy drive, d is usually the cd-rom or dvd-rom drive, and other peripherals like usb drives are the next letters.
  5. Scroll up and down. You should see quite a few folders. One will be called "Program Files" and another one will be called "Windows." There will also be more.
  6. The first thing you need is a place to put all of your personal documents. Luckily, Windows has these folders already pre-made. There are folders called My Documents in Windows. 
    1. When you are in the c drive, right click in empty space and click New -> Folder. You can also do this by going to File -> New -> Folder. Give the folder your name by typing it, and press Enter on the keyboard when your finished.
  7. Now, go into that folder by double clicking on it.
  8. If you want, make a few more folders inside of that one for more organization. For example, have one for pictures, one for school/work, one for music, and whatever you can think of. You can also make those folders as you go along.
  9. Close the window when finished.

Now we are going to make a simple file.

  1. Open Notepad.
  2. Type "Hello, I am practicing my computer skills" or whatever you want to type.
  3. Click on File -> Save As
  4. Navigate to C:\YourName\ and call the text file practice.txt.
  5. Open My Computer or Windows Explorer.
  6. Go to C:\YourName\
  7. You will see that there is a file called practice.txt.
  8. Double click on it. 
    * practice.txt was just opened by Notepad!
  9. Close Notepad.

### Moving Files with the Cut, Copy, and Paste[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-5)]

You will now learn how to move files.

  1. Open up My Computer or Windows Explorer
  2. Make a new folder in your folder called computer-practice. For example, it could be C:\YourName\computer-practice\\.
  3. Go to C:\YourName\, right click on practice.txt, and press copy.
  4. Go to C:\YourName\computer-practice\
  5. Right click in empty space and choose paste.
  6. Go to C:\YourName\, right click on practice.txt, and press delete. 
    * When the file is deleted, it is not gone forever. To remove it more, read about the **<recycle bin>**.
    * To save time, cut could have been used instead of copy. The difference is that when you paste after pressing cut, the file is deleted from its original location. You shouldn't use this too much just in case something goes wrong.

Moving one file at a time is fun, but sometimes we need to move a whole bunch at a time.

  1. Go to C:\YourName\computer-practice\
  2. Copy practice.txt
  3. Press paste lots of times. (Hold ctrl and keep pressing v) 
    * The new files will be renamed to something like "copy of practice.txt"
  4. There are two ways to select all of the files in this folder. 
    1. Press Ctrl-A or Edit -> Select All
    2. Click the one on the top, hold shift, and click the one on the bottom.
  5. When they are all highlighted, right click on one of them and press copy. 
    * As usual, the same thing can be done with Edit -> Copy or Ctrl-v
  6. Go to C:\YourName\
  7. Paste the files
  8. Delete all the text files that you just made in C:\YourName\

Sometimes, you only want to select some of the files in a folder

  1. Go to C:\YourName\computer-practice\
  2. Click on the first file.
  3. Hold shift down and click on another one towards the middle. 
    * The files you clicked on and everything in between has been selected.
  4. Click in empty space so everything is deselected.
  5. Click on the first file again.
  6. Hold ctrl and click another file. 
    * The files you clicked are the only ones that are selected.
  7. Hold ctrl and click yet another file.

### Searching For Files[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-6)]

Knowing the name of a file, but not the location, can be very aggravating. Who wants to spend hours searching through an endless amount of folders? The answer is not very many people and that is what file searching is for.

Let's say that someone has a file called important.zip. This person lost it, so they are now going to find it quickly. Here's what the person would do.

  1. Right click Start -> Search.
  2. Type in the file name, select where the file may be located [i.e. My Documents, My Computer.]

There are other things to be done with the find utility. One feature is using *. The * means that anything can be there. For example, searching for *.ogg would find any file that had a .ogg at the end. Searching for *report* would find anything that had the word report in the file name.

### Shortcuts[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-7)]

A shortcut is a file that leads to another file or a website. There main use is for the desktop (The screen behind all the windows. Icons are on the desktop).

Here is one way to use a shortcut.

  1. Right click on the desktop.
  2. Click New -> Shortcut
  3. A **wizard** will come up.
  4. Make the shortcut name "Notepad" and the link location C:\WINDOWS\system32\notepad.exe.

With this shortcut, you can open Notepad in the click of a button. You may now delete this shortcut if you think you'll never use it by right clicking on it.

Here is one way to use an Internet shortcut.

  1. Open up My Computer or Windows Explorer
  2. Go to C:\YourName\computer-practice\
  3. Do the same thing that you would do to make a folder, but click shortcut instead.
  4. A **wizard** will come up.
  5. Make the shortcut name "Never Used A Computer" and the link location <http://en.wikibooks.org/wiki/Never_Used_A_Computer/>.

With this shortcut, you can go to this book's website when you are in the computer-practice folder. You may now delete this shortcut because you'll probably never use it.

### Compression[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-8)]

When a file or more than one file is too big, compression can be used. Compression is used on the internet a lot because it is better to download smaller files. If you've ever seen a file with a .zip extension, then you have witnessed the most common type of compression in Windows. There are also compression formats with a .gz, .bz2, or .rar extension.

#### Extracting[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-9)]

"I got a .zip file from the Internet, now what?" is a common question. The answer is actually quite simple starting with Windows XP. All you have to do is right click on it in My Computer or Windows Explorer and choose "Extract All..." A wizard will come up and it is pretty straightforward. When you click next, it will ask you where to put the files. The default folder is usually good, but you can change it if necessary. Also, if the file has a password, click the Password... button and type it in. When you click Next, the files will be extracted to the directory, and one more thing will come up. It'll be a check box that says "Show extracted files". It is a good idea to make this unchecked because it'll open up a new window if you don't, which is annoying.

If you have an older version of Windows or want to be able to extract files other than zip files, a great option is [7-zip](http://7-zip.org/). It works basically the same way as the first method, or you can use their 7-zip File Manager which should be in the Start Menu.

#### Compressing[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-10)]

Just like files can be uncompressed, it is also possible to make your own .zip files. The easiest way to do this is to do these steps.

  1. Open up My Computer or Windows Explorer
  2. Right click on a file or folder that you want to be compressed.
  3. Choose Send To -> Compressed (zipped) Folder 
    * A .zip file with the same name as the original file for folder will be created in the same directory as the original file or folder.
    * For example, if there was a file called C:\Ronald\Bacon\BaconBenefits.doc, and you compressed it, there would now be a file called C:\Ronald\Bacon\BaconBenefits.zip. BaconBenefits.doc is still there.
  4. If you want to add to the archive, right click the .zip file and click Open.
  5. You can add more files by copying and pasting them in the new window that opens up.

The same can be done in other applications such as 7-zip, WinZip, and WinRar.

## Types of Applications[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-11)]

There are a few types of applications

  * Open Source - Free software where the source code, the language programmers use to make computers do their jobs, is available to everyone. Anyone can change the code and see how it works.
  * Freeware - This is free software that you may acquire legally without any fees.
  * Shareware - This is free software that you may acquire legally without any fees. However, there may be some restrictions (e.g. more advanced features may require a payment.)
  * Commercial - This software is normally sold in boxed packages.
  * Free-Trial - This software allows a period of time where the software can be used without cost, but extended use requires a small payment.

## Installing Applications in Linux[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-12)]

Most Linux-based operating systems come with a [package manager](//en.wikipedia.org/wiki/package_management_system), a tool that simplifies the process of installing and removing programs, and automatically updates installed software. A list of how to install application in major distributions follows (application= name of application you want to install):

#### Arch/Chakra Linux[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-13)]

pacman -S application

#### Fedora/Cent/RHT Linux[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-14)]

yum install application

#### Ubuntu[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-15)]

apt-get install application

## Installing Applications in Windows[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-16)]

Your computer probably came with some software already on it, but what if you need to do something fancy? For almost every task you could think of doing with a computer, there is a software program to let your computer do it.

There are a few ways to install applications

  * Install from a CD or DVD - You put the disc in the drive and follow instructions. The defaults will usually work fine.
  * Install from the internet 
    * You download a file, extract it if it's compressed (.zip, .bz2, .gz, etc.), click on the file with a .exe extension, and follow instructions.
    * On a very rare occasion you have to compile a program from source. This can be tough, but the program will probably have a file called INSTALL that should be read.

Learning is fun, so here's some more useful info. An executable file has either no extension at all or a .exe extension. When a file is executable, you can run it and it will do something. For example, the executable for Notepad is C:\WINDOWS\system32\notepad.exe. When you click on Start -> Accessories -> Notepad, it is really the same thing as going to notepad.exe in Windows Explorer and double-clicking it.

## Uninstalling Applications[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-17)]

### Windows[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-18)]

Sometimes a application is installed, but you don't want it anymore. Removing unwanted applications is like eating pie, easy.

  1. Go to Start -> Control Panel -> Add or Remove
  2. Highlight what you want to remove by clicking on it.
  3. Press Remove or Change/Remove
  4. Follow the instructions. They will most likely be pretty straight forward.

### Linux[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-19)]

## Customizing[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-20)]

This chapter will not explain every secret and tweak in Windows. What it will do is describe things that everyone should know in terms of customizing their computing experience to suite their needs.

### Start Menu[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-21)]

#### Contents[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-22)]

Applications usually put themselves in the Start Menu automatically, but you may find that there is something that needs to be added or tweaked.

There are two ways to edit what is inside of the start menu. Try the first one, and if that doesn't work, the second method will work.

##### Dragging, Dropping, and Right Clicking[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-23)]

### Taskbar[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-24)]

#### Auto-Hide the Taskbar[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-25)]

Have you ever seen someone's desktop and noticed that there is no taskbar, but then when they put their mouse at the bottom of the screen, it appears? That is called auto-hiding the taskbar. This is the kind of thing where some people love it and some people hate it. Here's how to do it.

  1. Right click on the taskbar.
  2. Click Properties.
  3. Check Auto-hide the taskbar.
  4. Press OK or Apply. (Apply won't close the window)

To make it normal again, do the same thing but this time uncheck the box.

#### Show Quick Launch[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-26)]

  1. Do the first two steps as Auto-Hide the Taskbar. 
    1. Right click on the taskbar.
    2. Click Properties.
  2. Check Show Quick Launch.

To deactivate it, do the same thing but this time uncheck the box.

### Screen Size (Resolution)[[edit](/w/index.php?title=Computers_for_Beginners/More_Basics&action=edit&section=T-27)]

There are two factors in determining the size of an image on the monitor. The first one is obvious, the physical size of the monitor. These would be values like 15", 17", 19", etc. Of course, this can't be changed without buying a new monitor.

The other thing that can determine the size of images on the screen is the resolution. To understand it, you have to know a little bit about how monitors work. It's not much.

A pixel is dot on the screen that has exactly one color. When all of those dots are combined, they make up what you see on the monitor. The resolution is how many dots are on the screen. When people describe resolution, they are talking about how many rows and columns of pixels there are, like a chess board. For example, a resolution of 640x480 means that there are 640 pixels going from the left to the right of the screen in one row, and there are 480 pixels going from the top to the bottom of the screen in one column.

Changing the resolution is very simple in Windows.

  1. First right click on the desktop, the area in the screen where the icons are, and click properties. You can also do the same thing by going in Start -> Control Panel -> Display.
  2. After that, go to the Settings tab.
  3. Click and hold the slider under Screen Resolution. Let go when you are at a suitable resolution. 
    * 1024x768 is a good choice. If your monitor can go higher, then do that if the text isn't too small.
  4. Press Apply. 
    * If the screen looks really weird and gets all funky, don't panic. If you don't press Ok to the dialog that comes up, it will automatically change back to where it was in a few seconds.

Also, notice the Color Quality section. Putting it on 32-bit color is a good idea if it isn't there already because it makes everything look so much nicer. If you monitor can't handle it, change it back. ![delta](//upload.wikimedia.org/math/6/3/b/63bcabf86a9a991864777c631c5b7617.png)

# Security[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=5)]

# Why Security Matters[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-1)]

Why should you spend effort to keep your computer secure? There are many reasons why someone would want to do so.

### Protect Others on the Internet[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-2)]

Failure to properly secure your computer could mean that your computer will be used by criminals to send spam messages or be part of an attack against web sites or it may harm your computer hardware and crash your computer.

### Malware can cause trouble with your computer[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-3)]

Malware, viruses, worms and Trojan horses all can affect your computer and attempt to steal personal information from you or make your computer unresponsive, necessitating you to reinstall Windows

### Protect Your Privacy[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-4)]

Many spyware apps may collect information on stuff like your web browsing habits and sell them so ads will be targeted to your tastes.

### Criminal Intentions of Crackers[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-5)]

Many crackers intend to hack to get a hold of credit card numbers, passwords, and other items that they can use for making a profit.

# Updating[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-6)]

Updating is the process of updating certain elements of a program to close vulnerabilities in a certain scenario. This will mean that your computer will be protected against future threats from a certain scenario. In Windows, updates are regularly done around once a month on Tuesdays.

# User Privileges[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-7)]

The administrator account should not be used for anything but administration purposes, or for programs that require administrative privileges. This is because it is too easy for your computer to become victim of malware, Trojan horses and viruses while logged onto an administrators account. This is especially important when performing your normal tasks like browsing the web, checking your e-mail, or word processing. This is because many of the programs that hackers use in an attempt to infect your computer require that you be an administrator to execute. They require writing files to certain directories, and registry keys, that "normal" user do not have access too. These programs are often hidden within webpages, IM chat windows, word processing documents, and e-mails. It is a very good idea to create a new user without administrative privileges to use on a normal basis.

In Windows, a problem often arises when a program needs to have administrative privileges to run. In this case, you can run the program as administrator. In windows operating systems, this is done by right clicking the program to run, selecting 'run as administrator account, and typing in the administrator account's information. If that doesn't work, you can always login to the administrators account to run the program, but be wary of running any other programs while in that account, especially programs that access the Internet like web browsers, chat programs, or e-mail programs.

Sometimes, damaging programs can infect non-administrator accounts. If this happens, these programs are usually limited to the that specific user account. Deleting that user account usually solves the problem. There are viruses sophisticated enough to infect the entire computer from a non-administrator account; however, if you keep your computer up to date with Windows Update and always download the signatures for your Anti-Virus software vulnerabilities in your computer will be closed and the virus cannot damage the system.

You wouldn't hand out a key that could open everything in your house to anyone who asked, so why would you hand out administrative account to anyone? If you really want to protect your data, do not give out your administrator password or account to untrusted people. If other people want to use your computer, it is a good idea to create a general guest account without administrative privileges for them to use. If they use it often, creating a new user for them is also an option.

# Physical Access[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-8)]

If a person has physical access to the computer, there are a few measures that can be taken to prevent damage to the computer. First, change the settings in your computers BIOS so that it boots first to the hard drive. Booting from the hard drive first ensures that a person cannot boot from a bootable media such as a CD-ROM or floppy disk. Often bootable media contains programs that can crack Windows and change the administrators password. As well, operating system (ex: Windows XP, Linux) installation disks are bootable and often have tools that allow users to erase all the information on the computer. NOTE: Do not EVER go into BIOS if you are not 100% sure of what you are doing. Ask someone who has extensive knowledge to help you.

Next, make it so a user needs a password to change the BIOS settings, this prevents someone from changing the boot order and thus booting from a CD-ROM or floppy disk drive. Last, put a lock on the computer case preventing someone from opening the computer case and resetting the jumper on the motherboard that clears the BIOS boot password.

# Malware[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-9)]

Malware is a class of software, which usually does harm to a computer, and is unwanted on the computer by its owner. Malware includes viruses, spyware, adware, and trojan horses.

## Anti-Virus[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-10)]

There are some people who spend their free time writing viruses, programs that do bad things to computers. The threat of getting a virus is high in the digital age of today especially if you are using the Windows operating system. In order to protect your files and everything on your computer, an anti-virus program should be obtained. Anti-virus software is dependent on definitions. Worms can spread through the Internet faster than anti-virus makers can make definitions for them, so you should not protect your self with only anti-virus software.

Here are some good ones:

  * [Kaspersky Antivirus](http://www.kaspersky.com/kaspersky_anti-virus) Kaspersky is good anti-virus program Available in world. But this is a Commercial Anti virus program.
  * [AVG Antivirus](http://free.grisoft.com/freeweb.php/doc/2/) \- This is an outstanding free anti-virus program. It is free for personal use only. A more advanced, professional version is available for purchase as well.
  * [Avast Antivirus](http://www.avast.com) \- This is a popular and Anti-virus program
  * [Norton Anti-Virus](http://www.symantec.com/nav/) \- This is probably the most popular commercial anti-virus. A good choice.
  * [McAfee VirusScan](http://us.mcafee.com/) \- A competitor to Norton Anti-Virus. This one is also a good choice.
  * [NOD32](http://www.eset.com) \- This is one of the top anti-virus scanners based on tests conducted by [ISCA Labs](https://www.icsalabs.com/icsa/icsahome.php). Although it isn't as well known as Norton and McAfee, it still provides an excellent degree of protection along with a faster scanning rate than most other Anti-Virus applications.
  * [TrendMicro PC-Cillin](http://www.trendmicro.com/en/home/us/personal.htm) \- This is also a good choice and has been around for many years.

Make sure that you set up your anti-virus program to update its virus definitions at least every week, or you'll get lost in the dust. If possible set up your anti-virus program to update every day because new viruses are always emerging. To get an idea of how quickly things change you can look at any of the sites listed above and they will list the current top virus threats.

### Worms[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-11)]

Worms are a type of virus that spread automatically through the internet, through exploits in a running service. Examples are Nimda and Msblaster. These can easily be blocked using a firewall, or making sure the services and your Operating System are up-to-date. Doing these can be especially important, because worms can spread faster than anti-virus software can be created, and often don't need any use interaction in order to install.

## Spyware and Adware Blocker[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-12)]

Much of the free software available is not able to remove all spyware and adware.

Spyware and Adware are similar to viruses, except that they don't spread on their own, but can be installed without your knowledge. They are more annoying and can be just as harmful.

Spyware's main motive is to get personal information of whoever is using the computer and send it to a company. Adware is enhanced spyware. It uses the information that it collects to show you advertisements on your computer screen. Adware can be received the same ways as spyware.

There are some good free spyware and adware blockers.

  * **[Spybot - Search & Destroy](http://spybot.info/)**
  * **[Ad-Aware](http://www.lavasoftusa.com/)**
  * **[Windows Defender](http://www.microsoft.com/athome/security/spyware/software/default.mspx/)**

Together, these make a good defense against evil programs.

There are also commercial spyware and adware blockers. The major companies that make anti-virus software have been including spyware/adware detection with their products in recent years.

## Common Spyware Infestation Methods and Prevention[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-13)]

A lot of spyware can be prevented. A few simple steps can save you from a lot of nightmares later.

#### Internet Explorer/ActiveX Exploits[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-14)]

A common avenue is for spyware to install through ActiveX or an exploit in IE, known as a drive by download. These usually affect IE shells like Avant. To prevent this type of installation, tighten up your IE settings, or use an alternative browser like Firefox. If you don't like Firefox we suggest Javacool's Spyware Blocker as an alterative.

#### P2P Apps and other Freeware[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-15)]

Another way to get spyware is by downloading free programs that are bundled with it. Almost every open source program, however, is spyware and adware free. Avoid programs that are known to contain spyware, especially proprietary file-sharing apps, and instead use one on the second list.

Filesharing apps known to contain spyware:

  * Kazaa
  * Bearshare
  * Morpheus

Filesharing apps known not to contain spyware:

  * Ares
  * Azureus
  * BitTorrent (watch out for "rigged" distributions however)
  * eMule
  * Limewire (older versions contained some spyware/adware; make sure you have the latest version to avoid this)
  * Shareaza

The best places to download freeware without spyware, adware, and malware in them are:

  * [download.com](http://www.download.com)
  * [fileplanet.com](http://www.fileplanet.com)
  * [betanews.com](http://fileforum.betanews.com/)
  * [softpedia.com](http://www.softpedia.com)
  * [sourceforge.net](http://www.sourceforge.net)
  * [pcworld.com](http://www.pcworld.com)

# Firewall[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-16)]

A firewall protects your computer by blocking certain network packets. They come in different flavors. Even if you are sent a packet that contains an exploit that is unpatched, a firewall can block the packet.

## NAT Firewall[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-17)]

A NAT Firewall is used in routers. It maps one public IP address to multiple private IP addresses. This will make your whole network appear to be one computer. By default, unsolicited (inbound) packets are dropped, giving you basic firewall protection. Many routers offer more advanced firewall features. By default, any servers run behind the NAT (Network Address Translation) will only be accessible from your LAN (Local Area Network). Port forwarding can be used so that a server can be accessed from the Internet.

## Software Firewall[[edit](/w/index.php?title=Computers_for_Beginners/Security&action=edit&section=T-18)]

A software firewall runs on the client computer. They're also known as personal firewalls. (This can refer to any firewall that only protects one computer like the firewall built into some nForce chipsets.) Because it runs on your computer, it can block or allow traffic depending on the application. For this reason, many people run software firewalls in addition to a hardware firewall. Hardware firewalls are harder to configure for new computer users so software firewalls are more common. However, software firewalls take up resources on the host computer. Windows XP and above comes with a basic firewall that prevents inbound attacks, while allowing other programs to access the Internet.

We suggest:

  * [ZoneAlarm](http://www.zonelabs.com/store/content/catalog/products/sku_list_za.jsp;jsessionid=Dc4Da1lV9qBo2bYL46A2g8qNBbfdzVbEpqq3OkEPonKF7AtxMjQw!-715972716!-1062696903!7551!7552!NONE?dc=12bms&ctry=US&lang=en&lid=dbtopnav_zass) the free firewall for personal users
  * [Norton's Internet Security](http://www.symantec.com/index.htm) More commercial firewall

# Office Programs[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=6)]

Office is commonly defined as a suite of programs made by Microsoft. They can accomplish many daily tasks, and are one of the most commonly used programs of average computer people.

There are several programs in the [Microsoft Office](/wiki/Microsoft_Office) suite:

  * Access, a database program
  * Excel, a spreadsheet program
  * Outlook, an email program
  * PowerPoint, a presentation program
  * Word, a word processor
  * Publisher, a document publishing program

Also part of the Microsoft Office suite are: [Expression Web](//en.wikipedia.org/wiki/Microsoft_Expression_Web) a web publishing program that replaced [Microsoft's FrontPage](//en.wikipedia.org/wiki/Microsoft_FrontPage) a discontinued Web site software, and [Visio](//en.wikipedia.org/wiki/Microsoft_Visio), a diagram making program.

Office suites are not made only by Microsoft. Some companies have taken their own stab at making these handy bundles of programming, and many have succeeded. If you don't want to shell out serious cash (hundreds of US dollars) for the latest version of Microsoft Office, you should take a look at [OpenOffice.org](//en.wikipedia.org/wiki/OpenOffice.org), commonly known as OOo or OpenOffice, a free, open-source office suite which offers almost all the features of Microsoft Office and then some. KDE e.V. also makes an office suite for KDE called [Koffice](//en.wikipedia.org/wiki/KOffice). If you wish to have an alternative to Word, try [AbiWord](//en.wikipedia.org/wiki/AbiWord).

Several online services like Google Docs also let you create and edit office programs.

Once you learn how to use one office program, you can figure out the basics of the other ones without much effort.

# Internet[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=7)]

## The Basics[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-1)]

### Where is the Internet?[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-2)]

In the 21st century the Internet is a pervasive presence in our lives, shaping them both for good and evil. It should not be surprising that the Internet may have motivated you to buy and use a computer to its maximum potential.

So, people "connect" to the Internet. Where _is_ the Internet? The short answer is nowhere and everywhere. The nature of the Internet is not centralized, there is no specific place where the Internet exists. What we call "the Internet" is the ever-changing collection of computers that are all connected together and configured so that they can "talk" to each other. Your computer becomes part of the Internet every time you connect to it, and you usually connect to it through your internet service provider (ISP), and _they_ are permanently connected.

The Internet is what you and others make it by creating a web page and uploading it onto a server. Your web page has now become a part of the Internet.

To define the term, the internet is a collection of many, many computers, including servers and desktop PCs, linked together to send and receive information.

### The Internet and the World Wide Web[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-3)]

Another point that may need clarification is the difference between the Internet and the World Wide Web. People tend to use those terms interchangeably, but there is a difference. The Internet can provide a wide range of services, like web-pages, email, file transfers, instant messages — the list never ends. The World Wide Web (or just "Web"), refers to the collection of inter-linked web-pages, and web-browsing refers to the exploration of those web-pages.

## Web Browsing[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-4)]

Web browsing is probably the most accessible beginners' Internet activity. It is the act of viewing textual or image-based content using the World-Wide Web over the Hypertext Transfer Protocol (HTTP). You are doing this as you read this text.

All recent versions of Windows come with a version of Internet Explorer, and most of them are inextricably integrated with the operating system. The current version, bundled with Windows Vista , is Internet Explorer 8. Windows 98 ships with version 4, and Me or 2000 are integrated with 5.0 or 5.5 (the difference being that 5.5 has support for more advanced security measures).

Internet Explorer is not the only browser, and not necessarily the best. Although it's still by far the most common, many people point out that it's difficult to use and may expose your computer to security risks. If you plan to use the World Wide Web, it's highly recommended that you at least try out one of the alternatives:

  * [Mozilla Firefox](http://www.getfirefox.com) is simple and reliable, and one of the most popular alternative browsers.
  * [Google Chrome](http://chrome.google.com)
  * [Mozilla Suite](http://www.mozilla.org/products/mozilla1.x) (includes e-mail support)
  * [Opera](http://www.opera.com)
  * [Netscape](http://www.netscape.com)

Linux users sometimes want to use command-line, or textual, browsers such as Lynx or Links2 where a graphical user interface is unavailable, for instance when installing, but most browsers are graphical.

When learning to use a browser (graphical or textual) most efficiently, it can be useful to learn keyboard commands, as well as the discrete uses of the Left and Right mouse button. If your mouse has a wheel in the middle, it can be useful to scroll, or for browsers with tabbed browsing support, opening a new tab. Check your settings so you can get the best use of this tool.

The vast majority of Web browsing is done among sites you might already know. The first one that you may have seen is your _home page_. When the browser is out of the box, it may direct to the company (Microsoft for Internet Explorer, Netscape for Netscape and allied products), or it will direct to your Internet Service Provider (the people who manage your connection). You can also have a home page of your choosing. If you are surfing at school or work, your school or work will have a page, as will the library or the Internet cafe.

## Choosing a password[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-5)]

Many web services, such as [email](//en.wikipedia.org/wiki/email), [internet shopping](//en.wikipedia.org/wiki/internet_shopping) or [online banking](//en.wikipedia.org/wiki/online_banking) require the user to "log in" by entering a **username** and **password**.

It is important to choose a good password, that is, a password that cannot be easily [cracked](/w/index.php?title=Cracked&action=edit&redlink=1) by a third party who could potentially gain access to your email account or finances.

### Bad passwords[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-6)]

The following types of passwords should never be used. They can easily be cracked by modern password breaking tools and offer little or no protection in case of an attack.

  * **Dictionary words**, **common phrases** and **names** in any language, even if combined with numbers. For example:
    
    
     webmail, merci, London, clare, beermonster, install, Sony, honey888, password3, fluffy,
     bahnhof, MichaelJackson, mount_everest, jesuschrist, linux7, venividivici, ...
    

  * Passwords **shorter** than 7 characters. For example:
    
    
     fG4ir5, bmw, cat, foo, cng56, girl9, ...
    

  * Passwords containing a modified version of the **user name**. (e.g. if the user name is "martin88", a password such as "martmart" or "nitram")
  * Passwords containing **personal** information about the user or the user's family such as dates of birth, social security numbers, number plates, pet names and addresses. For example:
    
    
     12021967, 12_2_1967, 12Feb67, y67d12m2, abbeyRoad, ...
    

  * Patterns or repetitive sequences
    
    
     qwerty, 9876789, g3g3g3g3, aeiou...
    

  * Contains only digits or letters. For example:
    
    
     wiki, 9876543... ...
    

### Good passwords[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-7)]

Good passwords should:

  * be at least 8 characters long
  * contain upper and lowercase characters, as well as numbers in a random sequence.
  * be easy to remember
    
    
    FQr7erfn5, QWd3fTr6U, rgi82eJiFF0, GI$87d90%nj, kEirt4Pw, ...
    

A convenient way of creating a password is thinking of a "pass phrase" and then abbreviating it into a password. This procedure usually results in a password that is both safe and easy to remember. For example:

  * "Roses are red, violets are blue, I'm a bad poet, so are you" becomes "RarVabIabp5ay", where the first word of each line is represented by a capital and "S" becomes a "5" because both characters look similar.
  * "I use this website to buy cheap flights from Stanstead airport" becomes "IutwtbcffSa"

Using special characters such as *&^%$ also improves a password's safety. However, some applications and websites don't allow passwords to contain special characters. If in doubt, leave them out and make the password longer.

Another convenient way to creating a good password is to change the letters to numbers or symbols in a short phrase. For example, if I wanted to use the phrase "Pepsi Man", I could simple change a few letters to numbers or symbols and get "P3p$1_m4n" an good and easy to use password that is accepted by most websites.

## Searching: getting here from there[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-8)]

A very useful idea for a home page can be a search engine. In a search engine, you can type in words or phrases in regard to a site or topic you may know something or nothing about. There have been many search engines developed over time. Since 1998, the most popular search engine is Google.

The principles to use all search engines are the same. Search engines differ in how much, how widely and how deeply they cover the Internet. The Internet is not just the World Wide Web, it can be Telnet, Usenet, Tymnet, Gopher and File Transfer Protocol. So keep that in mind!

So when looking for a website that we already know, we type in **http://www** into the box at the top below the menus. Or we would go to Open Location and press Control+L (all demonstrations from this point are conducted in Firefox 1.0.1).

When we want to go to Google, we type in <http://www.google.com>

Once you are in Google type in the box "Windows XP For Beginners". Then press Enter/Return or click on Google Search. The button next to it, I'm Feeling Lucky, will take you to the first site that google finds such as "BBC" will take you to "<http://www.bbc.co.uk>". When we 'felt lucky', we clicked on this site: <http://northville.lib.mi.us/tech/tutor/welcome.htm>, which will reinforce many of the concepts we have gone through and learnt.

Many sites have come up. We want to evaluate the ones which give us the most information about what we want to know.

Google gives us the name of the website (written out in full, so you can recall it later; if you can't put your mouse over the link's name), the first few words of the website we want to go to (usually 2 lines long), how big the file is (measured in kilobytes and useful for downloading, especially if you have limited time and resources), and two links called 'Cached' (which shows past versions of the website in the event the present version may not work) and 'Similar Pages' which will give similar pages. In the case of our 'Never Used a Computer Before' search, we found 30 sites similar to the 'I Feel Lucky' site, which incidentally is the first one. Many people, when they search and research, click on the first 10 files they see and gain information that way. This is not always the best thing to do, because most search engines have some form of ranking. Some of this ranking is sorted out by the user patterns of human beings, and others by the vagaries of servers. Some of this is sorted out by advertising. Google is a popular search engine for the reason it is not influenced by advertising.

How do we narrow down the search? On the right, there is a small link called Advanced Search. Advanced Search, as implied, is very powerful. It is something like a similar feature in your word processor or database programme and even in your operating system.

Advanced Search is here (if you are not located in the United States replace '.com' with '.com.au', '.co.uk', '.de', '.fr' or some other domain suffix.)

<http://www.google.com/advanced_search?hl=en>

and then you can play around.

The first four text boxes are to do with restricting the terms of the search with words or phrases - adding, delimiting or deleting. You may well be familiar with this from your word processor's Find and Replace function.

Web pages are in many different languages, file formats, dates and domains. To protect yourself and other people, you may want to use SafeSearch. Most things searched on the Web are 'sex' and 'porn(ography)' in all their forms, so for work and study, SafeSearch would be recommended. Otherwise, no filtering will do the trick. Google is able to limit all these things.

If you need more help then you can look at Advanced Search Tips: <http://www.google.com/help/refinesearch.html>

You might also like to find similar or linked pages to your page.

There are also technology-related searches for Macintosh, Microsoft and Linux (for example).

## Email[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-9)]

E-mail (commonly referred to as email - either spelling is acceptable) is a method of sending messages with a computer. Sending email costs nothing extra over your Internet connection.

You send email either with an **email client** such as [Microsoft Outlook](//en.wikipedia.org/wiki/Microsoft_Outlook) , [Mozilla Thunderbird](//en.wikipedia.org/wiki/Mozilla_Thunderbird) or with a web-based email system. The basic principle is the same for both:

  * The email is written and sent to a server with an email address attached.
  * The server looks at the domain name of the email (the section following the @) and sends the email on its way through the internet.
  * The receiving server receives the email. It looks at the username of the email (the section preceding the @) and stores the email in an appropriate folder on its hard disc.
  * The recipient connects to the Internet and logs into their mail client or webmail site.
  * The receiving server then allows the message to be downloaded by the recipient.

All this often happens in a second or less. The speed depends on the speed of the two previously mentioned servers and all the ISP servers in between, the amount of internet traffic, and the distance between the two servers.

## Web-based email[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-10)]

Web-based email is very convenient compared to email accessed via a client, but almost never has the featureset of clients.

Here is how to sign up for a Yahoo! Mail account. Yahoo! was one of the very first web-based email companies.

  1. Having got to the Yahoo site! (the American one), find 'Sign up'.
  2. The splash screen shows us three choices: Yahoo Mail, Yahoo Mail Plus and Personal Yahoo. The one that will be easiest for our purposes will be Yahoo Mail.
  3. It is always a good idea to read the Privacy Policy [[[1]](http://privacy.yahoo.com/)], and Terms of Service [[[2]](http://docs.yahoo.com/info/terms/)]. Look at everything marked with an asterisk and read the Terms of Service very very carefully. (Even print them out if you can't read them: there is a printable version).
  4. The most important thing is to have a user name and password: 
    * For this demonstration we'll type in neverusedacomputer@yahoo.com where the pattern is username@provider.com.
    * You can make up your own password
    * Follow the tips and hints.
  5. Hopefully you won't forget your password, but 'If You Forget Your Password' is next.
  6. Now that you have remembered your password, you will have to look at Captcha to verify your registration or account. It will be different every time. If you can see it, type it.
  7. Now you have your Yahoo account and you can sign in.

Many of these principles and practices apply to any Internet Service Provider or free service. It is interesting to compare similarities and differences. The basis of getting 'free' e-mail can and will change over time, especially if you intend to keep your address for longer than a month and will use it for many different things. Most people do keep their e-mail addresses for life or as long as is practicable, and will try to maintain continuity over the services they most frequently use. However, there is a danger of forgetfulness or apathy in regard to less frequently used or one-time only services. Ideally, a portal such as Yahoo or Hotmail will provide a very functional and neat e-mail address and many safe explorations on the information superhighway, like message boards, chat and directory links.

## E-mail through a specialist program[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-11)]

There are many programs designed for reading e-mail. A good one is Mozilla Thunderbird and it is meant to work alongside Mozilla Firefox. There are also Outlook and Outlook Express, Eudora and others. Those programs do not need a browser, they are capable of downloading and reading email on their own — they are _stand-alone_.

1\. In your browser, go to Tools -> Read Mail.

2\. If you want to write a new message, then go to Tools -> New Message or press Control+M.

### E-mail hygiene: viruses[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-12)]

One of the main ways that computer viruses propagate is via e-mail. This is usually done by attachments — files that are attached to the e-mail message sent to you. If you don't know the person sending you the email, it's advisable to be careful and not open the attachment that accompanies the e-mail (if any). The types of files that can be infected by viruses are files whose filenames end with **.exe** (executable programs), **.bat**, **.vbs**, **.doc** (Microsoft Word documents), **.xls** (Microsoft Excel files), **.ppt** (Microsoft PowerPoint presentations) and others. Even if you do know the person sending you the e-mail message, they might not know that _their_ computer is infected with a virus and they may unknowingly be sending you infected files, so it's always a good idea to have virus-scanning software. Finally, watch out for files that have names like _file.jpg.bat_. The **.jpg** part of the filename is there to fool you into believing this is a picture file, but it is almost certainly something nasty (due to the **.bat** ending).

One final point you should be careful about: many graphical e-mail programs have a "preview mode" as the default mode for reading email messages. In this mode, the contents of the email are presented to you immediately when you click on the message title in the list of messages. In the past years, we have seen viruses that infect your system immediately when you just _view_ the email message that carries them. It's advisable to disable the preview mode so that you have more control on which messages you want to view: that would give you the chance of deleting the emails you think look suspicious before even viewing their contents (yes, you can often judge from their titles).

## Online Scams[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-13)]

Common sense in the real world applies online. If an offer sounds too good to be true, it probably is. A good idea is to research an offer before you accept it.

A typical scam letter expresses an urgent need for a person to do them a favor. This usually involves some type of inheritance. These scammers are very good, and their letters sound sincere and legitimate. They are not. They also will target anyone who they think has money. There are even reports of religious figures being scammed. One occurred with a Pastor who was scammed into thinking that a Nigerian man had an inheritance of a few million dollars. However, a stipulation was placed on the inheritance that he had to give half of it away to charity but he didn't have the initial money to get to the location of the money in order for it to be released. The Pastor trusted him and in exchange for fronting the $10,000 or so USD, the scammer was to give him a few million for his church for the trouble. Unfortunately, the Pastor was scammed, he never received the money and was out $10,000.

Phishing is another way that crackers will try to obtain your personal information. They send emails claiming to be from reputable companies like Amazon.com or PayPal. The emails claim that they need information from you, like your credit card information or password, for some reason or another. Common excuses are technical glitches and software upgrades. These emails look legitimate at first glance--complete with company logos and professional formatting. They may ask you give you information via phone, through a reply, or through a website, which is also masked as the website of the company that they are trying to imitate. If you ever get an email like this, always treat it like it is evil as most companies would _never_ ask for personal information through email. If anything, call the company and verify that they sent you the email. Also, both Mozilla Firefox and Internet Explorer will detect many phishing sites and warn users that they are malicious.

## Links[[edit](/w/index.php?title=Computers_for_Beginners/Internet&action=edit&section=T-14)]

# Multimedia[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=8)]

food

Multimedia is a process of putting many media together. Even people who have never used a computer before have encountered images, music, videos and games. Some of this media is highly similar to their non-computer form, and others are highly unique. Multimedia files, like other files, are stored on the computer and cannot do anything by themselves. They need programmes to open them, and programmers, designers and you to edit them.

## Games[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-1)]

A game, on the other hand, is an executable file or an application. This means that it is usually (on Windows) an .exe, .com, or .bat file. Games come from the manufacturer. Some operating system versions, like Windows 3.1, had games that come on floppy disks or CD-ROMS. Many of those games were created in Visual Basic or other programming languages or game engines. Many games can also be downloaded from the Internet and are often played there.

Games in the computer world are often as variable as those in the non-computer world. Many games have systems of artificial intelligence to make them more interesting. Many games get much harder as the player goes on, and some users like to cheat or modify the game. There are two sorts of modifications: cosmetic and fundamental.

### Playing Games[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-2)]

In most games, it is a case of installing and loading the particular game from the Setup file. The Setup file will ask you where to save the game. It will either have its own folder, or be installed in Program Files. Program Files is slightly easier, and having games on the desktop is easiest of all.

Before playing the game, you might like to read the Terms of Service and disclaimers. Most game developers and publishers who release games on a commercial basis are very strict on this. With shareware and freeware, it is desirable, though not required, to acknowledge the developer by paying a nominal amount of money or sending them a postcard.

If your game happens to be limited to a certain amount of play, like 10 days or 28 days, respect that and delete it when you've got your use out of it. Some games will have a limited amount of plays, rather than time.

Wikipedia has a list of freeware games and some links to shareware outlets, which will cover a wide range of the twenty-five year history of personal computing. Each archive has its own procedures and rules, such as limits on how much a user can download at a time. Games are considered to be a relatively heavy use of bandwidth, so use common sense and discretion in regard to where and when you load them on your Internet Service Provider.

In the end, it's all an issue of personal preference-what educates and entertains you. Many successful games immerse their users into another world where they can learn computer-and other-skills.

Games also use images, sounds and often videos-either pre-recorded, or in real time.

### Making and Modifying Games[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-3)]

As you become more experienced and confident at a particular game (or game principles in general), you might like to know how to modify your favourite game. Many platform-type games, for instance, have various modifications, like how many or how few obstacles are present in a particular level. Text-based adventure games can be modified by changing the foreground and background colours, changing the grammar of commands or by unlocking a certain cheat. Often a user can find extra information in the manual or on a website about the game. Often, too, other people who play games like to share their modifications in public. Thus we have skins (clothes) from the Sims and Sims 2. Simulation games, like the ones from Maxis/Electronic Arts, are often customisable across a wide range of functions.

The simplest way to modify a game is if the developer puts in an editor with the game. This is common with puzzle games, where users like to create their own levels. The editor runs more or less separately from gameplay, so you can load, save and modify features of the game to your heart's content. A useful thing which editors can do is test your created scenarios to see whether and how they are feasible in the context of the game. It might be fun to make the player-character invincible, as can happen in Pacman, and in some roleplaying games. Conversely, the player character can be put in extreme situations like heat, cold, gravity and natural disasters. It is not just the players and their capacities which can be modified; non-playing characters and the environment can be modified too.

The second easiest way to modify a game is to go to the game's menu and look for preferences or options. Each game, and each game-playing experience, is different!

How do you actually create a game? Programmes like Klik & Play (available in a free version on the Internet, but you might like to ask your computer shop to order it) or a graphic user interface engine would make programming easier. They generally create genre-games. Many fan-games-often very sophisticated-have been created through a Klik & Play interface or similar.

A presentation programme like PowerPoint or Impress (part of the OpenOffice.org suite) might be another option which does not involve buying specialist software. These programmes offer 'click on me' interaction and forms. Something of the same kind of idea was available on almost every Macintosh in the form of HyperCard Player. Windows has similar applications like SuperCard and ToolBook. It is worthwhile to spend a few hours with tutorials. If you want your game to have splash screens and animations, spend time in your graphics programme and then use a client-side language like Flash. If you want to create a hypertext game, then HTML is a good choice. Perl and Python make clean code.

Again, if you can't see and preview what the game is doing, it is not likely to be very successful. Get some of your family members to be beta testers or at least to look at your proposed concept. It can be good to get it on paper, like a storyboard, before putting it to Flash.

It's true that with making a game, you need first to try and then to try again. You might also like to read books on these concepts and techniques to bolster your own practice, and also theses. One example of a good book is Chris Crawford's The Art of Computer Game Design [[3]](http://www.vancouver.wsu.edu/fac/peabody/game-book/Coverpage.html), and a thesis which describes the processes a class of gifted Queensland students used to create a transgressive computer game for the education market is Doing Serious Work of Just Playing: Computer Games in Subject English by Donna Lynette McGrath of the Queensland University of Technology. Chapter Four is especially relevant [[4]](http://adt.library.qut.edu.au/adt-qut/uploads/approved/adt-QUT20040713.153317/public/05Chapter4.pdf), as well as the appendices and tables [[5]](http://adt.library.qut.edu.au/adt-qut/uploads/approved/adt-QUT20040713.153317/public/08Appendixes.pdf). Both sources introduce the idea of a strong narrative or story to a game.

Wikipedia also has many links to tools that will help us make and modify games. Type in particular concepts or genres into your search engine, or bookmark relevant sites in open directories and archives.

Another good way to program a game is to use a Logo-type piece of software. This is particularly used in educational settings, and has a moderate balance between graphics and instructions with a learning curve similar but slightly more difficult than KlikPlay.

If you're really ambitious, you can use 3D or Virtual Reality. However, please remember these games need graphics cards and are not available to the majority. The same is true of games like Active Worlds and Second Life. Much graphic fun can be created with sprites. Create squares, circles and isometric images first!

## Images[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-4)]

Looking at pictures is fun. They spice up time at the computer and make boring text fresh and exciting. But before you view pictures, you should know what you're looking at.

### File Types[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-5)]

#### Compressed Formats[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-6)]

**[jpg](//en.wikipedia.org/wiki/JPEG) or [jpeg](//en.wikipedia.org/wiki/JPEG)** \- Most realistic photos are in this format. Almost every digital camera uses the jpeg format for their pictures. It has great compression and supports enough colors to suit most people's needs. The only draw back is that it uses lossy compression, which means that pictures saved in jpeg loose quality. Line art looks really bad in jpeg, but there are other formats for that.

**[gif](//en.wikipedia.org/wiki/GIF)** \- An easy and common format for creating animated images on web site. Commonly, used for advertisements. It only supports 256 different colors in any given image, thus it often looks grainy. Gif images have a lossless compression, so pictures saved in this format do not lose quality unless they have more than 256 colors.

**[png](//en.wikipedia.org/wiki/PNG)** \- Another popular image type on the Internet. It was created to be an open source replacement for gif's, but it doesn't support animation. This format like jpeg's allows for enough colors to create a realistic photo.

**[mng](//en.wikipedia.org/wiki/MNG)** \- An image format that has potential, but isn't used frequently. Mng has a lot in common with png and is made by most of the same people. The advantage of mng is that it also supports animation like gif's.

#### Uncompressed Formats[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-7)]

Images that aren't compressed get really big. The most popular format is bmp.

#### Vector[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-8)]

Every picture format described so far are raster. This means that they are drawn using different colored dots, or pixels.

Vector images are different because they are drawn with mathematical or vector images. For example, a circle is described using a mathematical equation instead of a whole bunch of dots that are placed to look like a circle. Because of this, you can zoom in forever and the vector circle would not lose quality. Most clip art is some sort of vector format. The main one is that if there was a circle, diagonal line, or something similar, one could zoom in forever and the picture wouldn't

Here are some popular vector formats:

**[swf](//en.wikipedia.org/wiki/Swf)** \- A proprietary format used by Macromedia Flash. Most animated movies on the internet use the swf.

**[svg](//en.wikipedia.org/wiki/Scalable_Vector_Graphics)** \- A basic and widely used format. It's not used for animations with sound.

### Popular image viewing software[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-9)]

Some of the popular image viewers are:

#### Google Picasa[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-10)]

This viewer has a good user interface and is easy to use. Besides being free of cost, it provides good basic image editing features also.

#### Windows Media Player[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-11)]

This comes in built with all Microsoft Windows OS. Although not so rich as the Google Picasa, it is a good alternative.

## Music[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-12)]

Music is a great way to change the mood while working on the computer. With music on your computer, you can make customize CDs, create your own jukebox, and listen to a wide variety of radio stations from all around the world.

### File Types[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-13)]

#### Lossy Formats[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-14)]

Lossy compress music, discarding data in order to compress the file to something much smaller than lossless compression and the original PCM stream. The resulting file will sound inferior to the original. Lossy formats can be compressed to varying sizes, with smaller file sized having lower quality.  


  * **[MP3](//en.wikipedia.org/wiki/MP3)** -The most popular lossy compression format, and the one that is synonymous with digital music. It is supported by all major DAPs and multimedia players.
  * **[OGG Vorbis](//en.wikipedia.org/wiki/OGG_Vorbis)** \- A higher quality codec than MP3, it is also free, but with limted support from DAPs. It is supported by the Rio Karma and most iRiver [DAPs](/w/index.php?title=DAPs&action=edit&redlink=1).
  * **[WMA](//en.wikipedia.org/wiki/WMA)** -
  * **[AAC](//en.wikipedia.org/wiki/AAC)** \- The format used by iTunes, but with FairPlay DRM. The iPod is the only major DAP to support it.
  * **[Real Audio](//en.wikipedia.org/wiki/RealAudio)** -

#### Uncompressed Formats[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-15)]

Uncompressed formats store music in the [PCM](//en.wikipedia.org/wiki/PCM) format, the same used by the Red Book audio CD format. For 2 Channel, 44.1kHz 16 bit audio, this takes up 1378Kbp/s compared to 192Kbp/s for lossy formats like MP3.

**[AIFF](//en.wikipedia.org/wiki/AIFF)** -

**[WAV](//en.wikipedia.org/wiki/WAV)** -

#### Lossless Compressed Formats[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-16)]

Lossless compression shrinks a music file, without a loss of any sound, and can be decompressed back into the original file. However, at around 75% of the original file, they take up more room than lossy compression formats.

**[FLAC](//en.wikipedia.org/wiki/FLAC)** \- A patent free format by the [Xiph.org Foundation](//en.wikipedia.org/wiki/Xiph.org_Foundation), who made Ogg Vorbis.

**[Apple Lossless](//en.wikipedia.org/wiki/Apple_Lossless) (MP4)** -

**[Shorten](//en.wikipedia.org/wiki/Shorten) (SHN)** \- A lossless file format written by [Tony Robinson](http://www.tonyrobinson.com/).

**[Windows Media Audio 9 Lossless](//en.wikipedia.org/wiki/Windows_Media_Audio_9_Lossless) (WMA)** -

### Listening[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-17)]

There is a wide variety of audio players available for free off of the Internet. They usually support Audio CDs and MP3s. Often they also support proprietary formats as well.

**[iTunes](//en.wikipedia.org/wiki/iTunes)** \- Apple's popular audio player which supports listening to CDs, converting audio CDs into a jukebox, making custom CDs, downloading songs off of Apple's iTune store, and listening to streaming radio stations. iTunes also supports listening to music off other computers running iTunes through a local area network (LAN) and uploading songs to popular MP3 players including Apple's iPod.

**[Musicmatch](//en.wikipedia.org/wiki/Musicmatch)** \- Musicmatch similar audio CD features as iTunes. Plus, it has its own Music store. One unique feature it supports is the ability to stream any song in the Musicmatch library for a monthly fee.

**[RealPlayer](//en.wikipedia.org/wiki/RealPlayer)** -

**[Winamp](//en.wikipedia.org/wiki/Winamp)** \- Compared to the jukebox style music players, Winamp's GUI is simple and takes up very little screen space.

**[Windows Media Player](//en.wikipedia.org/wiki/Windows_Media_Player)** -

## Video[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-18)]

### Media Types[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-19)]

A media type is how one would store video if they wanted to share it with other people. For example, a DVD is what most new movies are stored on.

**[DVD](//en.wikipedia.org/wiki/DVD)-Video** \- The popular format that replaced **[VHS](//en.wikipedia.org/wiki/VHS)** as the standard for hollywood production movies. This standard is only produced by manufactures of large movie companies. Home users can not produce this format of video. Video is encoded in MPEG2. Audio can be encoded in PCM, MPEG2 Audio, Dolby Digital, and DTS. However, the DVD spec requires that a DVD contain a PCM or Dolby Digital sound track. Up to 8 audio channels may be used.

**[DVD-R](//en.wikipedia.org/wiki/DVD-R)** and **[DVD+R](//en.wikipedia.org/wiki/DVD_plus_R)** \- A popular format for home made DVD movies. These disc play in most standalone DVD players. These disc can be single layer or dual layer. The single layer are relatively inexpensive and can hold 4.7 GB. The dual layer are very expensive and can hold roughly twice the information.

**[DVD-RW](//en.wikipedia.org/wiki/DVD-RW)** and **[DVD+RW](//en.wikipedia.org/wiki/DVD_plus_RW)** \- A similar format to DVD-R and DVD+R expect it is rewritable.

**[DVD-RAM](//en.wikipedia.org/wiki/DVD-RAM)** \- A format that requires a special drive and isn't real popular. It can support single layer 4.7 GB disc and 9.4 dual layer disc. Like DVD-RW and DVD+RW, it is rewriteable.

**[VCD](//en.wikipedia.org/wiki/Video_CD)** \- A low quality video disc contraining 1374Mb/s MPEG1 video, the same bitrate as audio CDs. VCDs can be burned onto regular CD-Rs and CD-RWs with a CD burner.

**[SVCD](//en.wikipedia.org/wiki/SVCD)** \- Similar to VCD but with slightly higher quality at the cost of not being able to store as much video.

### File Types and Codecs[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-20)]

A file type is the video itself. For example, if someone had a .mpg file on their computer, that would be the file type. When they put in on a DVD-R disk, they are using DVD-R as the media type.

Uncompressed video is very large. Because of that, many compression formats have been developed. Every file type here is a compressed format. Better yet, every file type here uses lossy compression. This means that in order to make the file smaller, quality is lost. Because of this, it is not a good idea to convert from one format to another because more quality will be lost.

#### Codecs[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-21)]

**[MPEG-1](//en.wikipedia.org/wiki/MPEG-1)**: Used for [Video CDs](//en.wikipedia.org/wiki/Video_CD), and also sometimes for online video. The quality is generally less than that of VHS. Includes the [MP3](//en.wikipedia.org/wiki/MP3) standard. Stored in a MPEG file.

**[MPEG-2](//en.wikipedia.org/wiki/MPEG-2)**: Used on [DVD](//en.wikipedia.org/wiki/DVD) and in another form for [SVCD](//en.wikipedia.org/wiki/SVCD). When used on a standard DVD, it offers great picture quality and supports widescreen. When used on SVCD, it is not as good but is certainly better than VCD. Unfortunately, SVCD will only fit around 40 minutes of video on a CD, VCD will fit an hour. Stored in a MPEG file.

**[Windows Media Video](//en.wikipedia.org/wiki/Windows_Media_Video) (WMV)**: [Microsoft](//en.wikipedia.org/wiki/Microsoft)'s proprietary format. It can do anything from low resolution video for dial up internet users to High Definition video to view on an HD TV. files can be burnt to CD and DVD or output to any number of devices. It is also useful for Media Centre PCs. Stored in a .wmv.

**[RealVideo](//en.wikipedia.org/wiki/RealVideo)**: Developed by [Real Networks](//en.wikipedia.org/wiki/Real_Networks). A popular codec in the earlier days of internet when bandwidth was scarce. Now less popular because the required player adds all kinds of unnecessary extras, and monitors usage behavior.

**[Sorenson 3](//en.wikipedia.org/wiki/Sorenson_codec)**: A popular codec used by Apple's QuickTime. Many of the Movie trailers found on the web use this codec.

**[Cinepak](//en.wikipedia.org/wiki/Cinepak)**: A very early codec used by Apple's QuickTime.

**[MPEG4](//en.wikipedia.org/wiki/MPEG4)**: The latest MPEG codec can be used for internet and on disc like WMV.

**[DivX](//en.wikipedia.org/wiki/DivX) & [Xvid](//en.wikipedia.org/wiki/Xvid)**: Types of MPEG 4. Usually stored in an AVI or OGM file.

#### File Types[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-22)]

A player that can play a certain file type will not be able to play that type of file with a codec it can not play.

**[AVI](//en.wikipedia.org/wiki/AVI)**: Used with many different codecs. Can also store uncompressed video. Uses the .avi extension.

**[OGM](//en.wikipedia.org/wiki/OGM)**: A file format similar to AVI supporting soft subtitles. Uses the .ogm extension.

**[MPEG](//en.wikipedia.org/wiki/MPEG)**: A file format used to store various versions of the MPEG codec. Uses the .mpeg or .mpg extension.

**[QuickTime](//en.wikipedia.org/wiki/QuickTime)**: Strickly speaking QuickTime is not a codec, but a file format, API set, and media player developed by Apple. It supports many popular codecs. Some of the more popular include Cinepack, Sorenson 3, and MPEG-4 Video. QuickTime also supports a plug-in architecture that allows other popular codecs such as MPEG 2 and DivX to be added by the user. Uses the .mov extension. And one more product developed by Apple. That is iTune. Used for Downloading MP3 Musics from Various sites. it can easily access to Download Musics Easily.

### Watching[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-23)]

**[Media Player Classic](//en.wikipedia.org/wiki/Media_Player_Classic)** -

**[QuickTime](//en.wikipedia.org/wiki/QuickTime)** -

**[RealPlayer](//en.wikipedia.org/wiki/RealPlayer)** -

**[VLC media player](//en.wikipedia.org/wiki/VLC_media_player) (VLC)** \- A free cross-platform multimedia player than plays almost [anything](http://www.videolan.org/vlc/features.html) you give it, including DVDs.

**[Windows Media Player](//en.wikipedia.org/wiki/Windows_Media_Player)** -

## Glossary[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-24)]

## Links[[edit](/w/index.php?title=Computers_for_Beginners/Multimedia&action=edit&section=T-25)]

# Networking[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=9)]

## Setting Up A Home Network[[edit](/w/index.php?title=Computers_for_Beginners/Networking&action=edit&section=T-1)]

  1. First let's understand the basic pieces of a home network. We all know what a network is, right? A network is a set of hardware and software technologies that allow all the PCs in the home to connect to each other and to the Internet. One example of a network that most PCs connect to is the internet. The internet is generally easy to join, but slow, open, and unsecured.
  2. How is the home network built? A network is built by connecting one or more operating systems together allowing for communication between the two. Usually this is done using hardware devices which move the data from computer to computer, and software programs that convert the sent data and read the received data. A home network is easily built by using a [broadband router](//en.wikipedia.org/wiki/router) which acts as a server to create the network for your home. In addition, routers connect to the larger internet and thus allow the home network computers to all connect to the internet simultaneously.
  3. To get onto the internet through a router, you need broadband internet. Broadband internet is commonly provided by cable and phone companies in the form of cable internet and DSL respectively. They require special modems to connect to their service, called broadband modems. A broadband modem is a device that allows you to quickly send and receive information from the Internet. DSL modems and cable modems are the two popular types of broadband modem. For the most part, cable modems are easier to configure and use, requiring only plugging in the cable line to the modem and the Ethernet cord to the router. The DSL modem requires users to log on to the ISP in order to get Internet access working.
  4. The broadband router is usually a small box - popular companies that make them are Linksys, Netgear, and DLink. One of the router's functions is to share a single Internet account with all the PCs and other devices in the home that want access to the Internet. Usually your Internet Service Provider (ISP) gives you one IP address. An IP address is a unique number for your computer's network card in a particular network (In the case of the ISP, it gives an IP address for the internet). The router works by splitting the single IP address given by your ISP into routable units that go to each computer within your home network, using special numbers that are read by the router. The router then sends the appropriate data to the appropriate IP address of the computer in the home network [Network Address Translation (NAT)](//en.wikipedia.org/wiki/NAT).
  5. Let's look at the typical router. You will see a series of [Ethernet](//en.wikipedia.org/wiki/Ethernet) ports (which look like enlarged telephone line plugs), with one usually not grouped with the others or labeled differently (oftentimes labeled WAN). This port is used to connect to the cable or DSL modem using a [CAT5 cable](//en.wikipedia.org/wiki/CAT5). The other Ethernet (Local Area Network) ports, which are used to attach the home PCs' Ethernet cards. Some routers have the capability to provide wireless networking. A wireless router will also sport one or two antennae, for the purpose of providing a wireless connection to computers with [wireless network](//en.wikipedia.org/wiki/wireless_network) cards.

## Different Uses of Networks[[edit](/w/index.php?title=Computers_for_Beginners/Networking&action=edit&section=T-2)]

### Sharing Internet Connection[[edit](/w/index.php?title=Computers_for_Beginners/Networking&action=edit&section=T-3)]

As the setting up section explains. One of the most basic features of home networking is sharing Internet access between two computers. This can be done with DSL, cable modem, or dial-up.

### Files Sharing[[edit](/w/index.php?title=Computers_for_Beginners/Networking&action=edit&section=T-4)]

### Print Sharing[[edit](/w/index.php?title=Computers_for_Beginners/Networking&action=edit&section=T-5)]

There are two major ways to share a printer across the network. The first requires a stand-alone printer, the other is using a printer that is connect to a computer.

A stand-alone printer is a printer that does not require being attached to a computer to use. Common examples are large office printers. They each have their own network card that allows them to connect directly into the network. These printers then can be assigned a network address, or a host name that allows other computers on the network to find them. In order to set these up please refer to your printer's administration manual.

Most modern printers also have a web-administration guide. A web administration guide shows options that can be set for the printer using a web-based interface. To get to it, you simply open your web browser and put the host name of the printer or the IP address. This will usually ask you for an administrator's account and password to change settings. This will be found in the administration manual, or you may have set it when setting up the printer's IP address.

Next, you will have to install the printer drivers and software on each computer that you want to have use of the printer.

In Windows XP:

  1. Click on the start menu
  2. Choose Run
  3. Type in: Control Panel and press enter
  4. Click Printers and Other Hardware
  5. Choose Printers and Faxes
  6. Under Printer Tasks, choose Add Printer
  7. Click Next, Choose Network Printer, Click Next
  8. Choose the bottom option to "Connect to this printer (or browse for a printer...)"
  9. In the text box, type in the host name or the IP address of the printer
  10. It will ask you if you would like to install the printer, connect yes
  11. It will then install the printer and tell that it has been installed!

The second option is to install a printer that is connected to another computer. First, you need to install the printer according to the instructions provided by the manufacturer on the computer. Next, you will need to get the computer's network name.

This is done in Windows XP by:

  1. Click on the start menu
  2. Choose run
  3. type cmd and press enter
  4. type in ipconfig /all and press enter
  5. write down the host name

Next, go to the computer that you want to connect to the printer.

In Windows XP:

  1. Click on the start menu
  2. Choose Run
  3. Type in: Control Panel and press enter
  4. Click Printers and Other Hardware
  5. Choose Printers and Faxes
  6. Under Printer Tasks, choose Add Printer
  7. Click Next, Choose Network Printer, Click Next
  8. Choose the bottom option to browse for printer
  9. Click Next, this should bring up a list of computers on the network
  10. Find the host name of the computer that the printer is attached to and double click it. (You may have to left-click on the network name before you see the computer).
  11. It will then show the computer and the attached printer. Choose the attached printer and click next.
  12. It will ask you if you would like to install the printer, connect yes
  13. It will then install the printer and tell that it has been installed!

To ensure complete installation, reboot the computer.

## Source[[edit](/w/index.php?title=Computers_for_Beginners/Networking&action=edit&section=T-6)]

[How to Take the First Steps in Home Networking](http://wiki.ehow.com/Take-the-First-Steps-in-Home-Networking)

# Tips&Tricks[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=10)]

## Truly Removing Log Off User[[edit](/w/index.php?title=Computers_for_Beginners/Tips%26Tricks&action=edit&section=T-1)]

We all know that WIN+R will launch the Run dialog. And if you didn't know that before, you do now. It's an easy way to launch programs in your path or Web pages (provided they start with either "http" or "www"). You can make a shortcut to this command easily in Windows XP, but first you need to have the default Start Menu view enabled. Once that's done, simply drag & drop the Run icon from the menu to your desktop (which is akin to a "cradle to the grave" operation). Rename it at will. While we're on the subject of XP Professional's Start Menu, if you wanna get rid of the Help and Logoff icons, TweakUI may not do the trick. But there are 2 methods to do the same used Windows Xp's built-in tools.  


### 1) Using group policies:[[edit](/w/index.php?title=Computers_for_Beginners/Tips%26Tricks&action=edit&section=T-2)]

Launch gpedit.msc (from the Run command line). Be careful what you toggle in here; you could very well deny access to essential Windows features. Select _User Configuration > Administrative Templates > Start Menu and Taskbar > Remove [This] menu from Start Menu_. Of course, [This] could be "Help," "Logoff," or any other menu component. Note that the "F1" key will still respond to your call.

### 2) Using registry[[edit](/w/index.php?title=Computers_for_Beginners/Tips%26Tricks&action=edit&section=T-3)]

![](//upload.wikimedia.org/wikibooks/en/thumb/8/8c/NoLogOff.png/200px-NoLogOff.png)

![](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/magnify-clip.png)

Screenshot of removing/disabling logoff

Type REGEDIT on your run dialog box. Now browse to the following location in the window that opens up. **HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer**. On the right side you may see a [value](/w/index.php?title=Value&action=edit&redlink=1) named **NoLogOff**. Double click on it and change its value to **1** If you don't see the **NoLogOff** [value](/w/index.php?title=Value&action=edit&redlink=1) then create a **[STRING](/w/index.php?title=STRING&action=edit&redlink=1)** [value](/w/index.php?title=Value&action=edit&redlink=1) and name it as **NoLogOff**; now change its [data](/w/index.php?title=Data&action=edit&redlink=1) to **1**  
You may need to reboot.

## Kill the Passport Balloon[[edit](/w/index.php?title=Computers_for_Beginners/Tips%26Tricks&action=edit&section=T-4)]

Too many people are tricked into believing that you need to sign up for a Passport account when you get Windows XP. Wonderful job the marketing folks did, eh? Well, if you don't want to sign up for an account, nobody is forcing you to. At least, not yet. Are you tired of being reminded about signing up? Fire up REGEDIT.EXE and find your way to HKEY_CURRENT_USER \ Software \ Microsoft \ MessengerService. You'll see a "PassportBalloon" binary value in the right-hand pane. Double-click to open it. Now, in the resulting "Edit Binary Value" dialog, press the Delete key and enter: "0a" (that's a zero, sans quotes). This will effectively set the reminder counter to 10 and you won't be bothered with it again. Don't want the Windows Messenger to pop up when you launch Outlook Express? In the Registry, get to HKEY_LOCAL_MACHINE \ SOFTWARE \ Microsoft \ Outlook Express and either edit or add a DWORD Value: "Hide Messenger" (sans quotes). Set this to "2" and you'll be good to go. Thanks to X-Setup (XTEQ.COM) for providing an easier way to get this done. Within that program, you can right-click on a plug-in and select "Information" for details and script code.

## Kill the Animated Search Character[[edit](/w/index.php?title=Computers_for_Beginners/Tips%26Tricks&action=edit&section=T-5)]

When I first saw the default search pane in Windows XP, my instinct was to return it to its classic look; that puppy had to go. Of course, I later discovered that a doggie door is built into the applet. Click "Change preferences" then "Without an animated screen character." If you'd rather give it a bare-bones "Windows 2000" look and feel, fire up your Registry editor and navigate to HKEY_CURRENT_USER \ Software \ Microsoft \ Windows \ CurrentVersion \ Explorer \ CabinetState. You may need to create a new string value labeled "Use Search Asst" and set it to "no" (sans quotes in each case). Before you go that far, let me make you aware of two things. First, you can accomplish the same task via the new TweakUI (available for download at WINDOWSXP.COM). Second, there's a nice benefit to the new Search Companion in Internet Explorer 6.0 (at least, with Microsoft Office's spell checker installed). Launch your browser and tap the F3 key. Now, enter your query, intentionally misspelling a keyword. Look at that! A red squiggly! Right-click on the word and select an appropriate replacement (if necessary). How's that for helpful?

## Strange errors[[edit](/w/index.php?title=Computers_for_Beginners/Tips%26Tricks&action=edit&section=T-6)]

From time to time, you will encounter some persistent errors or issues. The best way to resolve them is to try searching for that error on a search engine. More often than not, you may encounter the result on the first link (especially if you search by the error message), or otherwise have enough information to find the correct path.

While contacting the local computer expert may seem tempting, remember that they want to do work as well. As always, search before asking.

# Keeping your PC running Smoothly =[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=11)]

## Do Some Research[[edit](/w/index.php?title=Computers_for_Beginners/Keeping_your_PC_running_Smoothly&action=edit&section=T-1)]

Is that demo looking tempting enough to download? Or how about that brand new piece of hardware? Well before you do, perhaps you should do some research on it first. By doing your research you can avoid future potential problems by at least being aware of bugs, compatibility issues, security vulnerabilities, and undesirable inclusions like spyware & adware.

**You can research:**

  * Reviews & Ratings
  * Frequently Asked Questions
  * Release Notes
  * Press Releases
  * Version History
  * System Requirements

## Update Everything[[edit](/w/index.php?title=Computers_for_Beginners/Keeping_your_PC_running_Smoothly&action=edit&section=T-2)]

Applications, operating systems, drivers... Nearly everything on your PC can be updated. Updates are often released to remove bugs, fix exploits, improve compatibility, optimize performance, add features, refresh databases, and enhance experiemce.

However you should be aware that some updates are purely optional and may be require certain conditions to be applicable, especially firmware updates.

While you should avoid interrupting software updates, you should never interrupt a firmware update.

**You should update your:**

  * Anti-Virus
  * Anti-Spyware / Anti-Adware
  * Personal Firewall
  * Operating System
  * Internet Browsers
  * Communications Software (E-Mail, IM, and Chat Clients)
  * Productivity Suites
  * Favorite Applications
  * Device Drivers
  * Firmware

**You should run:**

  * Anti-Virus scans
  * Disk - defragmentation tool
  * Disk Cleanup wizard

A useful tutorial on a sequence for managing your computer's health is available at [[6]](http://seniornetwgtn.blogspot.com/) under the **WORKSHOP NOTES** heading _Clean your PC_

## Keep your passwords safe[[edit](/w/index.php?title=Computers_for_Beginners/Keeping_your_PC_running_Smoothly&action=edit&section=T-3)]

Your passwords protect your files, your user accounts, and your online accounts, so don't you think you should protect your password?

**General Guidelines:**

  * Avoid using personal data as passwords--you shouldn't use your birthday, your national insurance/social security number, or proper names as passwords.
  * Include capital letters, numbers, and symbols.
  * If you can, avoid using any word in the dictionary in your password, or any proper names. Crackers (criminal hackers) have lists of nearly all words in English, as well as other languages, and by using a special program, can test thousands of words per second against your password. Ideally, a password should be at least 8 characters (letters/numbers) long, and contain letters and numbers interspersed throughout its length; for example "9hyl8rn25g"; do not use this example as your password!
  * Use multiple passwords.
  * In general, don't EVER give your password to others, even other family members. There are normally ways they can obtain their own user accounts and passwords. Any person who knows a secret doubles the likelihood that secret will be revealed, at the very least.
  * If someone you don't personally know asks you for your password, including individuals from the "phone company", the "cable company", the "ISP", the "bank", the "police", the "government", from "corporate", from "IT" or "MIS", or any individual purporting to hold a position of authority, generally assume that the request is malicious in nature, unless:

1\. They ask you in person--not by phone, by email, or instant messenger; 2. You ask for and they show a tamper-proof photo identification card--merely wearing a uniform is insufficient; 3. You call where they came from, verify that they are actually who they say they are, and verify that in their job, they normally ask people for their passwords.

  * Verify where you enter your password, especially on the Web. There are fake sites that look like real ones which are designed to trick you into giving out your password.
  * When in doubt, change your password.

**Keep the system free from all junk files:**

  * Remove all the files in the Temp Folder, Temporary Internet files Folder, History Folder and the recent document Folder. you can do this by doing the Disk Cleanup.

# Programming[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=12)]

## Taking your first step into the world of programming[[edit](/w/index.php?title=Computers_for_Beginners/Programming&action=edit&section=T-1)]

Computer programming (often simply programming) is the craft of implementing one or more interrelated abstract algorithms using a particular programming language to produce a concrete computer program. Programming has elements of art, science, mathematics, and engineering. The first step to programming is knowing the basics of mathematics (mainly Algebra). Programming is usually done by writing human-readable code into a text editor and then compiling that code into a form the computer understands, called binary file.

## Types of programming languages[[edit](/w/index.php?title=Computers_for_Beginners/Programming&action=edit&section=T-2)]

There are two types of programming languages based on the code or syntax they use. One is low level and the other is high-level programming languages. The difference between them is on the way we write their code. For example, Assembly is a low-level language where the user writes code which is almost identical to the one computers understand (see below for more info). A high-level programming language uses a more natural and human-readable syntax which makes it easier for humans to understand and write. The problem with high-level languages is that the programmer doesn't exactly know how his code will be translated (compiled) into the code the computer understands, thus making it less powerful compared to the low level languages. Today, most programmers use some sort of a high-level language, because it is much easier to learn and understand and often requires much less work.

**Low level languages**

A typical example of a low-level programming language is Assembly. Assembly offers the _lowest_ level of programming experience, meaning that one has absolute control over everything the machine will do. Although this offers programmers the most power, it is very hard to learn and even the most basic task can require a painful amount of work on the part of the programmer. Once compiled, assembly programs offer the fastest execution and most precise processor control possible. Assembly is often used for smaller, speed critical, projects such as writing a device driver, but due to its hard to understand syntax and complexity, today it is being replaced by high-level languages. The big difference between low-level and high-level languages is how the code is compiled into the binary form. Compiler used for compiling Assembly code is named assembler and as programmers say, the code written is assembled into binary form, not compiled (see under compilers for more details). There are also many Assembly languages, each for its platform. Although they are extremely hard to use, they are a very good learning tool, because an Assembly programmer is required to understand how the machine works (mainly CPU and RAM) in order to write code. MASM (Microsoft's Macro Assembler) is a popular assembler for the 80x86 (Pentium/Athlon) platform for Windows, others popular assemblers are TASM (Borland's Turbo Assembler) and the opensource FASM (Flat Assembler). NASM (The Nationwide Assembler), is currently the most versatile and popular compiler in existence.

Randall Hyde has also written a popular assembler for the 80x86 platform, called HLA (High Level Assembly) which is an attempt to simplify learning Assembly with a high-level syntax. Although one can use the high-level syntax, Randall Hyde has repeatedly stressed that a programmer can still code using a series of CMP's and Jcc's, instead of .IF for example.

This is an Assembly code snippet of a program written in MASM which loads two numbers (in the registers eax, and ebx) adds them and stores the result (in the register ecx).
    
    
    .model small, C
     .586
    
     .data
    
     mov eax,5
     mov ebx,10
    
     add eax,ebx
     mov ecx,eax
    
     end
    

**High level languages**

Due to the fact that the complexity of Assembly language programming is extremely hard to learn, and written programs are hard to maintain, low-level languages often cannot be ported to another platform, because they use platform, or, rather, CPU specific instructions, thus written Assembly code for the PC isn't portable to another platform (such as the Mac for example) without the complete rewrite of the program. Programmers were in a need for a language that could be easily understood and be portable, therefore high-level languages were created. The major difference between high-level and low-level languages is the way they are written and compiled.

While Assembly code is assembled into binary without any modifications than converting the syntax into CPU instructions, high-level languages use a compiler which also converts code into binary form, but instead of using a syntax which symbolizes CPU instructions, it used a readable, human-understandable code, thus making it easier and quicker to write, learn and maintain. The downfall is that the compiler is responsible for converting the code and often it produces a slower running binary then Assembly would.

Compilers are extremely good at optimizing code and most of the time produce a binary with the same running speed Assembly would if used correctly. They are also smart enough to tell us if there's a problem in our code and sometimes even fix it by themselves. Today, where speed is not as important as it was many years ago, high-level languages are most programmer's choice.

Although we already know two types of languages, there are also low-level and high-level languages in high level languages. A programming language may even be high-level and low-level at the same time. A typical example of this would be C or C++. Both offer low-level operations (even manipulating the smallest forms known to a computer - bits), but they also offer a natural and easy to use syntax. A typical example of a fully high-level language would be C# or Java which don't offer any low-level operations and are thus even easier to learn and write.

The difference between programming language levels is speed - the higher level the language, the slower the binary and the quicker the learning curve.

Below is the code written in C which (as the previous Assembly example) adds two numbers and stores the result.
    
    
    int main()
    {
      // assign to the variable result the value of 5 + 10
      int result = 5 + 10;
    
      return 0;
    }
    

The mathematical 'equals' operator ('=') has a different meaning in C so let me explain what this program does. It takes two numbers, 5 and 10, adds them and stores them in a local variable (which is stored in RAM) we called 'result'.

Another popular high-level programming language is Microsoft's Visual Basic. It is often used for learning programming, because of its ease of use and understanding. All programming languages require some basic knowledge of mathematics (mainly Algebra) and the basics of how computers work. Also every programming language serves its purpose. For example, PHP is used for programming dynamic web pages while C# is used for programming Windows applications and Java is used for programming platform independent applications.

## How programs work[[edit](/w/index.php?title=Computers_for_Beginners/Programming&action=edit&section=T-3)]

It is very important that you understand at least the very basics of how computers work, because learning any language it is required to know this first. Computers use the processor (CPU) to execute instructions, memory (RAM) to store the running program and hard drive (HDD) to store data and programs that are not running at that time. In order for a program to add two numbers like we did in the previous example, the program must know at compile time and before the program is run, how much memory it should ask for and what it would store there. Computers use variables to do this. Variables are data stored in RAM which can be changed any time while the program is running. In our example, we didn't use variables, but we used constants - plain numbers which can not be changed at runtime. This, you will find, is extremely useless as most of the time we don't know exactly what our program will do.

A calculator would be useless without user input and if it could only add numbers that were already given to him at compile time. Therefore, variables are the primary thing you will get to know at programming. When you run the program we wrote in C, the program knows it has two numbers in it and asks the operating system for space in memory for 2 integer numbers. Integer numbers are whole numbers such as 1, 24 and 1497. Not only does the program have to know how much space it has to ask, but even what type of a variable it will store. Will it be an integer or a character string?

Whenever one uses a program that asks for user input (a calculator for example) it has already made place in RAM for the number one will type in. When you do type it in, it stores it in that place and marks its type - if you type in 33 it will mark it as an integer, if you typed in 3.14 it will mark it as a real number.

Real numbers are numbers with fractions. For example 1.33 is a real number, so is 0.25 and so on. Knowing what type of a variable the program stores, it knows what it can do with it. So if we have real numbers or integers we can multiply them, divide them etc. But we can not do those things with a character string. We can't divide words and letters.

The other major thing to know about programming is that computers can't think. Computers are pretty much useless machines without a human to operate it. The computer does _exactly_ what you tell it to do and nothing more. This, as you have probably notice, doesn't seem true all the time, but it is almost never the computer's fault and almost always programmer's. Computers do not understand numbers, words or any other human-readable type. They can only understand two states; true and false.

You have probably heard that computers work with 1's and 0's but that is not the case. They work with electricity and nothing more. We made up those 1's and 0's to make it simplier for us to understand them. (1's and 0's represent voltage changes).Computers cannot think or do anything useful without someone programming it. They can only compare numbers and nothing else. It is important to know this, so you start thinking as a computer programmer.

  


# Authors[[edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit&section=13)]

## EuropracBHIT[[edit](/w/index.php?title=Computers_for_Beginners/Authors&action=edit&section=T-1)]

The last time [EuropracBHIT](/wiki/User:EuropracBHIT) could say she had 'never used a computer' was in 1990, when an IBM-compatible computer running MS-DOS version 3.1 came into her home. She studied Information Technology from 1996 to 2000, which is the sum of her theoretical knowledge, as well as a course in Desktop Publishing in 2003, where she crystallised high skills in PageMaker and Photoshop, versions of which she had been exploring for the previous ten years first on Macintosh and subsequently on Wintel platforms. Practically, she reads all the manuals before she opens a piece of software, and help files and PDF files. And she plays and has fun, ferreting out what a piece of hardware and its comicontant software can do and testing out its limits. Her principal contributions will be in Internet and Multimedia, as she believes these are the most fun and challenging ways of using a computer in the consumer and education arenas for which this book is targeted. She recommends tutorials because they are a form of 'doing as I do': imitating an experienced computer user as opposed to 'doing what I say' which is following the instructions and feeling very foolish. She thinks that people feeling foolish is the greatest reason why they do not learn to use their computers more efficiently and get out their maximum potential with this and other related technology. In the fifteen years she has been using computers, she has had to tutor and help many people of all ages and skill levels. She thinks the best way to meet the computer's 'mind' is to be logical. However, computers, in her view, do stir passions and emotions, and it is important to deal with these positively, critically and constructively.

## Deviance99[[edit](/w/index.php?title=Computers_for_Beginners/Authors&action=edit&section=T-2)]

[Deviance99](/w/index.php?title=User:Deviance99&action=edit&redlink=1) has had a home PC running Microsoft Windows since he was 9 years old. He has been consulting friends, family, and neighbors since age 15. He started dabbling in Q-Basic computer programming at age 12, and started building his own computers at 14, and discovered Linux at age 17 (23 now). He's been designing webpages since his sophomore year in high school, and has had several jobs making websites. He studied Information Technology from 2001-2005 with a speciality in Multimedia Design, and is current the System Administrator of the Physics Department at the local univerity.

Most of his knowledge of computers is self-taught and complimented with theory from the University. He is an expert using Windows, while an advanced user of Linux with experience setting up and maintaining webservers, mail servers, files servers, clusters, active directory, and a network environment. He just bought his first Apple computer and is virgerously learning it.

![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&oldid=2501616](http://en.wikibooks.org/w/index.php?title=Computers_for_Beginners/Print_version&oldid=2501616)" 

[Category](/wiki/Special:Categories): 

  * [Computers for Beginners](/wiki/Category:Computers_for_Beginners)

Hidden categories: 

  * [Books with print version](/wiki/Category:Books_with_print_version)
  * [Books with PDF version](/wiki/Category:Books_with_PDF_version)
  * [Pages needing attention](/wiki/Category:Pages_needing_attention)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Computers+for+Beginners%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Computers+for+Beginners%2FPrint+version)

### Namespaces

  * [Book](/wiki/Computers_for_Beginners/Print_version)
  * [Discussion](/w/index.php?title=Talk:Computers_for_Beginners/Print_version&action=edit&redlink=1)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Computers_for_Beginners/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Computers_for_Beginners/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Computers_for_Beginners/Print_version&action=edit)
  * [View history](/w/index.php?title=Computers_for_Beginners/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Computers_for_Beginners/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Computers_for_Beginners/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Computers_for_Beginners/Print_version&oldid=2501616)
  * [Page information](/w/index.php?title=Computers_for_Beginners/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Computers_for_Beginners%2FPrint_version&id=2501616)

### In other languages

  * [Русский](//ru.wikibooks.org/wiki/%D0%9A%D0%BE%D0%BC%D0%BF%D1%8C%D1%8E%D1%82%D0%B5%D1%80%D1%8B_%D0%B4%D0%BB%D1%8F_%D0%BD%D0%B0%D1%87%D0%B8%D0%BD%D0%B0%D1%8E%D1%89%D0%B8%D1%85/%D0%9F%D0%BE%D0%BA%D1%83%D0%BF%D0%BA%D0%B0_%D0%BA%D0%BE%D0%BC%D0%BF%D1%8C%D1%8E%D1%82%D0%B5%D1%80%D0%B0)
  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Computers+for+Beginners%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Computers+for+Beginners%2FPrint+version&oldid=2501616&writer=rl)
  * [Printable version](/w/index.php?title=Computers_for_Beginners/Print_version&printable=yes)

  * This page was last modified on 14 March 2013, at 10:04.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Computers_for_Beginners/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
