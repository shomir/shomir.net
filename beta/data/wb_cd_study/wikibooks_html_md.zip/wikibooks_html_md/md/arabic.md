# Arabic/Print version

From Wikibooks, open books for an open world

< [Arabic](/wiki/Arabic)

![Unreviewed changes are displayed on this page](//bits.wikimedia.org/static-1.22wmf19/extensions/FlaggedRevs/frontend/modules/img/1.png)The [latest reviewed version](//en.wikibooks.org/w/index.php?title=Arabic/Print_version&stable=1) was [checked](//en.wikibooks.org/w/index.php?title=Special:Log&type=review&page=Arabic/Print_version) on _2 September 2013_. There are [template/file changes](//en.wikibooks.org/w/index.php?title=Arabic/Print_version&oldid=2553284&diff=cur&diffonly=0) awaiting review.

Jump to: navigation, search

  


![Printer.svg](//upload.wikimedia.org/wikipedia/commons/thumb/2/23/Printer.svg/40px-Printer.svg.png)

**This is the [print version](/wiki/Help:Print_versions) of [Arabic](/wiki/Arabic)**  
You won't see this message or any elements not part of the book's content when you print or [preview](//en.wikibooks.org/w/index.php?title=Arabic/Print_version&action=purge&printable=yes) this page.
تعلم قراءة وكتابة العربية

taˈʕallam qiˈraːʔatu wa kiˈtaːbatu lʕaraˈbiːjah

LEARNING TO READ AND WRITE ARABIC

## The Alphabet الأبجد alʔabd͡ʒad[[edit](/w/index.php?title=Arabic/LearnRW&action=edit&section=T-1)]

  * [Basics](/wiki/Arabic/LearnRW/Alphabet_Basics)
  * [The Arabic Alphabet (normal order)](/wiki/Arabic/LearnRW/Normal_Alphabet_Layout)
  * [The Arabic Alphabet (pyramid of rows)](/wiki/Arabic/LearnRW/Pyramid_Alphabet)
  * [How letters connect](/wiki/Arabic/LearnRW/connecting)
  * [Row 4: ب ت ث ف](/wiki/Arabic/LearnRW/Row_4)
  * [Rows 1 and 3: ه ك م ي](/wiki/Arabic/LearnRW/Row_3_and_1)
  * [Row 6: ا د ذ ر ز و](/wiki/Arabic/LearnRW/Row_6)
  * [Row 2: ط ظ](/wiki/Arabic/LearnRW/Row_2)
  * [Row 7: س ش ص ض ق ل ن](/wiki/Arabic/LearnRW/Row_7)
  * [Row 5: ج ح خ ع غ](/wiki/Arabic/LearnRW/Row_5)

## Vowels التشكيل atˌtaʃˈkiːl[[edit](/w/index.php?title=Arabic/LearnRW&action=edit&section=T-2)]

  * [The short vowels: a, i, u](/wiki/Arabic/LearnRW/a_i_u)
  * [fatḥah (فتحة) fatħah](/wiki/Arabic/LearnRW/fatHa)
  * [Alif (ألف)](/wiki/Arabic/LearnRW/alif)
  * [ḍammah and wāw(ضمة و واو)](/wiki/Arabic/LearnRW/Dammah_and_waaw)
  * [Kasrah and Yā' (كسرة و ياء)](/wiki/Arabic/LearnRW/kasra_and_yaa)
  * [Tanwīn: -an, -in, -un (تنوين)](/wiki/Arabic/LearnRW/an_in_un)
  * [ـَي (ai)](/wiki/Arabic/LearnRW/fatHa_and_Yaa)
  * [Sukūn (سكون) and Shaddah (شدة)](/wiki/Arabic/LearnRW/Sukuun_and_Shadda)

## After Learning the Alphabet بعد تعلم الأبجد ˈbaʕda taˈʕallumi lˈʔabd͡ʒad[[edit](/w/index.php?title=Arabic/LearnRW&action=edit&section=T-3)]

  * [Lām Alif (لام ألف)](/wiki/Arabic/LearnRW/laam-alif)
  * [Ligatures](/w/index.php?title=Arabic/LearnRW/Ligatures&action=edit&redlink=1)
  * [Alif Maqsuura: ى vs. ي (yaa)](/wiki/Arabic/LearnRW/alif_Maksoorah)
  * [Hamzä (همزة)](/wiki/Arabic/LearnRW/hamza_and_Superscript_Alif)
  * [-ah: tā’ marbūṭah): (ة: تاء مربوطة)](/wiki/Arabic/LearnRW/taa%27_MarbooTah)
  * [Al (ال)](/wiki/Arabic/LearnRW/al-_Assimilation)

# Misc[[edit](/w/index.php?title=Arabic/LearnRW&action=edit&section=T-4)]

  * [Lesson planning for a step-by-step introduction of the Arabic alphabet](/wiki/Arabic/Writing_lessons_plan) ![25 percents developed  as of Aug 22, 2006](//upload.wikimedia.org/wikipedia/commons/thumb/a/a5/25_percents.svg/9px-25_percents.svg.png)
  * [Arabic/Arabic alphabet step-by-step](/wiki/Arabic/Arabic_alphabet_step-by-step)
  * [Arabic/Arabic alphabet](/wiki/Arabic/Arabic_alphabet) ![50 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/6/62/50_percents.svg/9px-50_percents.svg.png)
  * [Arabic/Arabic alphabet (by group)](/wiki/Arabic/Arabic_alphabet_\(by_group\))
  * [Arabic/Arabic sounds](/wiki/Arabic/Arabic_sounds) ![100 percents developed  as of Jan 24, 2005](//upload.wikimedia.org/wikipedia/commons/thumb/c/c7/100_percents.svg/9px-100_percents.svg.png)
  * [Using Hamza](//en.wikipedia.org/wiki/Hamza)

## External Links[[edit](/w/index.php?title=Arabic/LearnRW&action=edit&section=T-5)]

  * [Alphabet, with sound, just click on a letter](http://www.arabic2000.com/arabic/alphabet.html)
  * [Complete Arabic Script course (with sound)](http://www.madinaharabic.com/Arabic_Reading_Course/Arabic_%20Reading_Course.htm)
  * [Omniglot](http://www.omniglot.com/writing/arabic.htm) — The Omniglot encyclopedia article for Arabic.
  * [Arabic Alphabet Quiz](http://www.theiling.de/schrift/) — Choose the "Arabic" link.
  * [Babel Arabic Writing Explanation](http://i-cias.com/babel/arabic/)
  * [Arabic Alphabet](http://www.naturalarabic.com/free_article.php?artid=10150) with sound and lessons
  * [Arabic Alphabet](http://arabicgenie.com/blog/free-arabic-resources/arabic-script) writing instructions

## Downloads[[edit](/w/index.php?title=Arabic/LearnRW&action=edit&section=T-6)]

# Romanisation System[[edit](/w/index.php?title=Arabic/Romanisation_System&action=edit&section=T-1)]

In order to make Arabic more accessible, this book uses transliteration along with Arabic written in Arabic letters. The system used in this book is based on the loose conventions used to chat in Arabic when the Arabic alphabet is not supported.

  * The following numerals are used to represent Arabic letters not having a Latin equivalent: 2 3 6 7 9 
    * 2 represents hamza ء (original alif sound). This is the sound that separates vowels for example if "Martin" were written in Arabic. It would most likely not be written with a hamza, because that is not how it is usually pronounced in English. But if you find that someone pronounces "Martin" as "Mart-in" rather than "Mar-tin" then that pronunciation would be written with a hamza in Arabic (like this in transliteration: mart2in).
    * 3 represents 3ain. 3ain is an important Arabic sound, and doesn't come automatically to people unfamiliar with Arabic.
    * 6 is the "emphatic" "t" sound. It is a "t" sound pronounced with more of the tongue touching the roof of the mouth.
    * 7 is a special "h" sound. It is pronounced far deeper in the throat the normal "h".
    * 9 is the emphatic "s" sound. Unlike the normal Arabic "s" sound this "s" sound is pronounced with the tongue near the place behind the upper teeth. This is not a very important phoneme to master.

  


  * The apostrophe is used to indicate modify consonants to represent different consonants. For example: t', d', 7', 3' represent the more frictive versions i.e. (the th in think, the th in "the", the throaty "ch" in Munich, the throaty Parisian French "r" (approximately)).
  * The apostrophe is used after a vowel to lengthen it.

  
The orthography or spelling conventions used with the transliteration are a compromise between transcribing actual pronunciation, and spelling (although in Arabic they do not significantly differ). Keep the following in mind:

  * tilde (~) indicates that the letter before must be pronounced like the letter after it. so (eL~Da'r must be pronounced ed-da'r)
  * The definite article in Arabic will be spelt (L), It is pronounced the same as (L)
  * Anything in parentheses after a word are pronounced in some registers and not others. You will most likely need to be capable of understanding Arabic pronounced either way.

## Examples[[edit](/w/index.php?title=Arabic/Romanisation_System&action=edit&section=T-2)]

  1. L kalime(tu) huna'k(a)
  2. L kita'b(u) huna'k(a)
  3. L kursiy(yu) huna'k(a)
  4. L madrase(tu) huna'k(a)
  5. L mu3allim(u) huna'k(a)
  6. L~tilmi'd'(u) huna'k(a)
  7. L qalam(u) huna'k(a)
  8. L ma77a'ye(tu) huna'k(a)
  9. L~daftar(u) huna'k(a)
  10. L kita'b(u) huna'lik(a)

  


# Lessons دروس[[edit](/w/index.php?title=Arabic/Print_version&action=edit&section=1)]

The definite article ("the" in English) is "al" (spelled ال alif, la'm). It is pronounced with the same sound as the name of the letter "L" (i.e. el). It basically does what the word "the" does; it goes before a definite noun. But it has two extra jobs, because in Arabic, small words like "of" and "is" are not used. To illustrate: the striked-out words in the following English sentences would not translate into an Arabic word once the sentence is translated.
    
    
       The boy <s>is</s> on the roof.
       The sky <s>is</s> blue.
       The girls <s>are</s> here.
       I <s>am</s> going away.
       We <s>are</s> there.
       The book <s>of</s> the boy <s>is</s> here.
    

Luckily, the definite article helps indicate where "is/are/am", and "of" would be. Whenever there are two words, one definite (i.e. starts with "L") and one indefinite (starts without "L"), if the first is definite then you know that "is/are/am" is implied between the two words. If the first is indefinite then you know that "of" is implied between the two words.

## Summary[[edit](/w/index.php?title=Arabic/definiteArticle&action=edit&section=T-1)]

(Y) means some noun  
(Z) means some other noun  

    
    
    →  means "translates to"  
    
    

l- indicates the Arabic definite article  

    
    
    l-(Y)       →  the (Y)
    l-(Y) (Z)   →  the (Y) is (Z)
    (Y) l-(Z)   →  the (Y) of the (Z)
    

## Translation Exercise[[edit](/w/index.php?title=Arabic/definiteArticle&action=edit&section=T-2)]
    
    
    book   كِتابُ keetaab
    airport مَطارُ Mataar
    restaurant مَطعَمُ mat3am
    title/address عُنوانُ  unwan
    big كَبيرُ kabeer
    small صَغيرُ sagheer
    

  1. الكتاب،al ketaab
  2. المطار، al mataar
  3. المطعم،al mat3am
  4. الكتاب صغير.al ketaab sagheer
  5. المطار كبير.al mataar kabeer
  6. المطعم صغير.al mat3am sagheer
  7. عنوان المطار
  8. عنوان المطعم
  9. عنوان الكتاب.

ا

## [Romanisation](/w/index.php?title=Arabic/Print_version/Romanisation&action=edit&redlink=1)[[edit](/w/index.php?title=Arabic/definiteArticle&action=edit&section=T-3)]

## Key[[edit](/w/index.php?title=Arabic/definiteArticle&action=edit&section=T-4)]

  1. The book.
  2. The airport.
  3. The restaurant.
  4. The book is small.
  5. The airport is big.
  6. The restaurant is small.
  7. The address of the airport.
  8. The address of the restaurant.
  9. The title of the book.

# Translation Exercises[[edit](/w/index.php?title=Arabic/Here_and_There&action=edit&section=T-1)]

# Exercise 1[[edit](/w/index.php?title=Arabic/Here_and_There&action=edit&section=T-2)]
    
    
    word كَلِمةُ
    book كِتاب ُ  
    letter (of alphabet) حَرفُ
    chair كُرسِيُّ
    school مَدرَسةُ
    teacherمُعَلِّمُ 
    student تِلمِيذُ
    pen(cil) قَلَمُ
    eraser مِمحَاة
    computer حاسوبُ
    notebook دَفتَرُ
    there/here هُناكَ
    there هُنالِكَ
    

  1. الكَلِمَةُ هُناكَ.
  2. الكِتابُ هُناكَ.
  3. الحَرفُ هُناكَ.
  4. الكُرسيُّ هُناكَ.
  5. المَدرَسةُ هُناكَ.
  6. المُعَلِّمُ هُناكَ.
  7. التِلميذُ هُناكَ.
  8. القَلَمُ هُناكَ.
  9. المَحّايةُ هُناكَ.
  10. الحاسوبُ هُناكَ.
  11. الدَفتَرُ هُناكَ.
  12. الكِتابُ هُنالِكَ.

ا  


## [Romanisation](/w/index.php?title=Arabic/Print_version/ex1/Romanisation&action=edit&redlink=1)[[edit](/w/index.php?title=Arabic/Here_and_There&action=edit&section=T-3)]

## Key[[edit](/w/index.php?title=Arabic/Here_and_There&action=edit&section=T-4)]

2\. The word is there.  
4\. The chair is there.  
6\. The teacher is there.  
8\. The pen is there.  
10\. The computer is there.  
12\. The book is there.  


# Exercise 2[[edit](/w/index.php?title=Arabic/Here_and_There&action=edit&section=T-5)]
    
    
    notebook دَفتَرُ
    there هُنالِكَ 
    computer حاسوبُ
    eraser أستيكة
    pen(cil) قَلَم
    teacherمُعَلِّمُ 
    student تِلمِيذُ
    letter (of the alphabet) حَرفُ
    book كِتابُ
    there/here هُناكَ
    here هُنا
    

  1. الدَفتَرُ هُنالِكَ.
  2. الحاسوبُ هُنالِكَ.
  3. المَحّايةُ هُناكَ.
  4. القَلَمُ هُنالِكَ.
  5. التِلميذُ هُنالِكَ.
  6. المُعَلِّمُ هُناكَ.
  7. الكُرسيُّ هُناكَ.
  8. الحَرفُ هُنالِكَ.
  9. الكِتابُ هُناكَ.
  10. الحاسوبُ هُناكَ.
  11. الدَفتَرُ هُناكَ.
  12. الكِتابُ هُنا.

ا  


  


## [Romanisation](/w/index.php?title=Arabic/Print_version/ex2/Romanisation&action=edit&redlink=1)[[edit](/w/index.php?title=Arabic/Here_and_There&action=edit&section=T-6)]

## Key[[edit](/w/index.php?title=Arabic/Here_and_There&action=edit&section=T-7)]

2\. The computer is there.  
4\. The pen is there.  
6\. The teacher is there.  
8\. The letter is there.  
10\. The computer is there.  
12\. The book is here.  


  


# Exercise 1[[edit](/w/index.php?title=Arabic/available&action=edit&section=T-1)]
    
    
    available ‏مَوْجُوْدٌ ‎mawˈd͡ʒuːd/mawˈd͡ʒuːdun
    unavailable ‏غَيْرُ مَوْجُوْدٍ  ‎ˈɤajru mawˈd͡ʒuːd/ˈɤajru mawˈd͡ʒuːdin
    book ‏كِتَاْبٌ ‎kiˈtaːb/kiˈtaːbun
    chair ‏كُرْسِيٌّ ‎ˈkursiː/ˈkursiːjun
    computer ‏حَاْسُوْبٌ ‎ħaːˈsuːb/ħaːˈsuːbun
    student ‏تِلْمِيْذٌ ‎tilˈmiːð/tilˈmiːðun
    pencil ‏قَلَمٌ ‎ˈqalam/qalamun
    eraser ‏مَحَّاْيَةٌ ‎maħˈħaːjah/maħˈħaːjatun
    word ‏كَلِمَةٌ ‎kaˈlimah/kaˈlimatun
    airport ‏مَطَاْرٌ ‎maˈtˠaːr/maˈtˠaːrun
    restaurant ‏مَطْعَمٌ ‎matˠˈʕam/matˠˈʕamun
    school ‏مَدْرَسَةٌ ‎madˈrasah/madˈrasatun
    here ‏هُنَاْ ‎hunaː
    there ‏هُنَاْكَ ‎huˈnaːk/huˈnaːka
    

  


  1. اَلْكِتَاْبُ مَوْجُوْدٌ.‏ alkiˈtaːbu mawˈd͡ʒuːd
  2. اَلْكُرْسيُّ مَوْجُوْدٌ.‏ alˈkursiːju mawˈd͡ʒuːd
  3. اَلْحَاْسُوْبُ غَيْرُ مَوْجُوْدٍ.‏‏ alħaːˈsuːbu ˈɤajru mawˈd͡ʒuːd
  4. اَلْتِّلْمِيْذُ مَوْجُوْدٌ.‏
  5. اَلْقَلَمُ مَوْجُوْدٌ.‏
  6. اَلْمَحَّاْيَةُ غَيْرُ مَوْجُوْدَةٍ.‏
  7. اَلْكَلِمَةُ غَيْرُ مَوْجُوْدَةِ.‏
  8. اَلْمَطَاْرُ هُنَاْكَ.‏
  9. اَلْمَطْعَمُ مَوْجُوْدٌ.‏
  10. اَلْتِّلْمِيْذُ هُنَاْلِكَ.‏
  11. اَلْمَدْرَسَةُ هُنَاْ.‏
  12. اَلْمَطَاْرُ غَيْرُ مَوْجُوْدٍ.‏

  


# [Romanisation](/w/index.php?title=Arabic/Print_version/Romanisation&action=edit&redlink=1)[[edit](/w/index.php?title=Arabic/available&action=edit&section=T-2)]

# Key[[edit](/w/index.php?title=Arabic/available&action=edit&section=T-3)]

1\. The book is available.  
2\. The chair is available.  
3\. The computer is unavailable.  
4\. The student is available.  
5\. The pen is here.  
6\. The eraser is unavailable.  
8\. The airport is there.  
10\. The student is there.  
12\. The airport is unavailable.  


  
The strange letter لا is a ligature lam + alif (= 'la')

# Exercise 1[[edit](/w/index.php?title=Arabic/existance&action=edit&section=T-1)]

## Vocabulary[[edit](/w/index.php?title=Arabic/existance&action=edit&section=T-2)]
    
    
    exists (to exist)   يوجَد
    doesn't  لا
    
    
    
    book كِتابُ
    school مَدرَسَة
    restaurant مَطعَمُ
    student تِلميذُ
    airport مَطارُ
    word كَلِمَةُ
    pen قَلَمُ
    
    

  
  


  1. الكِتابُ لا يوجَد. There is no book.
  2. المَدرَسةُ لا توجَد. There is no school.
  3. لا يوجد مطعم. There is no restaurant.
  4. هناك تلميذ. There is a student.
  5. هناك مطار. There is an airport.
  6. الكَلِمةُ لا توجَد. The word doesn't exist.
  7. .الكلمة غير موجودة. The word doesn't exist.
  8. هناك كتاب. There is a book.
  9. هناك مدرسة. There is a school.
  10. هناك مطار. There is an airport.
  11. هناك قلم. There is a pen.
  12. لا يوجَد مطار. There is no airport.

  


  


# Key[[edit](/w/index.php?title=Arabic/existance&action=edit&section=T-3)]

2\. There is no school.  
لا توجد مدرسة 4. There is a student  
هناك طالب 6. The word doesn't exist.  
الكلمةُ غير موجودة 8. There is no school.  
ليست هناك مدرسة 10. There is no pen.  
لا يوجد قلم 12. There's no airport.  
لا يوجد مطار. ليس هناك مطار

  


# Exercise 1[[edit](/w/index.php?title=Arabic/thereIs&action=edit&section=T-1)]
    
    
    there is no مامِن
    there is a هُناكَ 
    book كِتابُ
    airport مَطارُ
    restaurant مَطعَمُ
    notebook دَفتَرُ
    hospital مُستَشفَى
    school مَدرَسةُ
    chair  كُرسيُّ
    apartment (home) شُقّةُ
    apartment (building) عِمارَةُ 
    

  1. مامِن كِتابِ.
  2. هُناكَ كِتابُ.
  3. هُناكَ مَطارُ.
  4. هُناكَ مَطعَمُ.
  5. مامِن دَفتَرِ.
  6. هُناكَ مُستَشفى.
  7. مامِن مَدرَسةِ.
  8. مامِن كُرسيُّ.
  9. هُناكَ كُرسيُّ.
  10. مامِن شِقّةِ.
  11. مامِن عِمارةِ.
  12. مامِن عِمارةِ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/thereIs&action=edit&section=T-2)]

2\. There is a book.  
4\. There is a restaurant.  
6\. There is a hospital.  
8\. There is no chair.  
10\. There is no apartment.  
12\. There is no apartment building.  


  


# Exercise 1[[edit](/w/index.php?title=Arabic/describing&action=edit&section=T-1)]
    
    
    big كَبِيْرٌ
    old قَدِيْمٌ
    small صَغِيْرٌ
    new جَدِيْدٌ
    cheap رَخِيْصٌ
    expensive غَاْلٍ
    university جَاْمِعَةٌ
    apartment شُقَّةٌ
    school مَدْرَسَةٌ
    eraser مَحَّاْيَةٌ
    penقَلَمٌ 
    airport مَطَاْرٌ
    computer حَاْسُوْبٌ
    apartment (home) شُقَّةٌ
    

  1. اَلْمَدْرَسَةُ كَبِيْرَةٌ.‏
  2. اَلْجَاْمِعَةُ قَدِيْمَةٌ.‏
  3. اَلْشُّقَّةُ صَغِيْرَةٌ.‏
  4. اَلْمَحَّاْيَةُ جَدِيْدَةٌ.‏
  5. اَلْقَلَمُ رَخِيْصٌ.‏
  6. اَلْمَدْرَسَةُ جَدِيْدَةٌ.‏
  7. اَلْمَطَاْرُ كَبِيْرٌ.‏
  8. اَلْحَاْسُوْبُ غَاْلٍ.‏
  9. اَلْمَطْعَمُ غَاْلٍ.‏
  10. اَلْجَاْمِعَةُ غَاْلِيَةٌ.‏
  11. اَلْمَحَّاْيَةُ غَاْلِيَةٌ.‏
  12. اَلْشُّقَّةُ جَدِيْدَةٌ.‏

# Key[[edit](/w/index.php?title=Arabic/describing&action=edit&section=T-2)]

1\. The School is large.  
2\. The university is old.  
4\. The eraser is new.  
6\. The school is new.  
8\. The computer is expensive.  
10\. University is expensive.  
11\. The eraser is expensive.  
12\. The apartment is new.  


  


# Translation Exercises[[edit](/w/index.php?title=Arabic/pointing&action=edit&section=T-1)]

## Exercise 1[[edit](/w/index.php?title=Arabic/pointing&action=edit&section=T-2)]
    
    
    this هٰذَا\هٰذِهِ
    computer حاسوبُ
    pen/pencil قَلَمُ
    restaurant مَطعَمُ
    eraser مَحّايةُ
    apartment (suite) شُقّةُ
    book كِتابُ
    notebook دَفتَرُ
    student تِلميذُ
    female student تِلميذةُ
    teacher مُعَلِّمُ
    female teacher مُعَلِّمةُ
    

  1. هٰذا حاسوبُ.
  2. هٰذِهِ مَدرَسةُ.
  3. هٰذا قَلَمُ.
  4. هٰذا مَطعَمُ.
  5. هٰذِهِ مَحّايةُ.
  6. هٰذِهِ شُقّةُ.
  7. هٰذا كِتابُ.
  8. هٰذا دَفتَرُ.
  9. هٰذا تِلميذُ.
  10. هٰذا مُعَلِّمُ.
  11. هٰذِهِ تِلميذةُ.
  12. هٰذِهِ مُعَلِّمةُ.

ا  


  


### Key[[edit](/w/index.php?title=Arabic/pointing&action=edit&section=T-3)]

2\. This is a school.  
4\. This is a restaurant.  
6\. This is an apartment.  
8\. This is a notebook.  
10\. This is a (male) teacher.  
12\. This is a (female) teacher.  


## Exercise 2[[edit](/w/index.php?title=Arabic/pointing&action=edit&section=T-4)]
    
    
    that ذٰلِكَ \ تِلْكَ
    student تِلميذَةُ
    airport مَطارُ
    book كِتابُ
    restaurant مَطعَمُ
    eraser مَحّايةُ
    pen قَلَمُ
    teacher مُعَلِّمُ\مُعَلِّمةُ
    

  


  1. ذٰلِكَ تِلميذُ.
  2. تِلْكَ تِلميذة.
  3. هٰذا مَطارُ.
  4. ذٰلِكَ مَطارُ.
  5. ذٰلِكَ كِتابُ.
  6. ذٰلِكَ مَطعَمُ.
  7. تِلْكَ مَحّايةُ.
  8. ذٰلِكَ قَلَمُ.
  9. هٰذِهِ مَحّايةُ.
  10. تِلْكَ مُعَلِّمةُ.
  11. ذٰلِكَ مُعَلِّمُ.
  12. تِلْكَ مُعَلِّمةُ.

ا  


### Key[[edit](/w/index.php?title=Arabic/pointing&action=edit&section=T-5)]

2\. That is a (female) student.  
4\. That is an airport.  
6\. That is a restaurant.  
8\. That is a pen.  
10\. That is a (female) teacher.  
12\. That is a (female) teacher.  


## Exercise 3[[edit](/w/index.php?title=Arabic/pointing&action=edit&section=T-6)]
    
    
    this/that ذٰلِكَ \ تِلْكَ
    this هٰذا\هٰذِهِ
    that ذٰلِكَ \ تِلْكَ 
    airport مَطارُ
    restaurant مَطْعَمُ
    eraser مَحّايةُ
    university جامِعةُ
    pen قَلَمُ
    student تِلميذُ\تِلميذةُ
    apartment (suite) شُقّةُ
    notebook دَفتَرُ
    
    

  1. ذٰلِكَ مَطارُ.
  2. ذٰلِكَ مَطْعَمُ.
  3. تِلْكَ مَحّايةُ.
  4. تِلْكَ جامِعةُ.
  5. ذٰلِكَ مَطارُ.
  6. هٰذا قَلَمُ.
  7. تِلْكَ تِلميذةُ.
  8. ذٰلِكَ قَلَمُ.
  9. تِلْكَ شُقّةُ.
  10. هٰذِهِ تِلميذةُ.
  11. ذٰلِكَ دَفتَرُ.
  12. تِلْكَ جامِعةُ.

ا  


  


### Key[[edit](/w/index.php?title=Arabic/pointing&action=edit&section=T-7)]

2\. That is a restaurant.  
4\. That is a university.  
6\. That is a pen.  
8\. That is a pen.  
10\. This is a student.  
12\. That is a university.  


  


# Translation Exercises[[edit](/w/index.php?title=Arabic/relations&action=edit&section=T-1)]

## Exercise 1[[edit](/w/index.php?title=Arabic/relations&action=edit&section=T-2)]
    
    
    book كِتابُ
    from مِن
    school مَدرَسةُ
    notebook دَفتَرُ
    airport مَطارُ
    with مَعَ
    near قُربَ
    city مَدينةُ
    in في
    above فَوقَ
    apartment (suite) شُقّةُ
    apartment (building) عِمارةُ
    chair كُرسيُّ
    ground أَرضُ
    table طاوِلةُ
    under تَحتَ
    teacher مُعَلِّمُ 
    

  1. الكِتابُ مِن المَدرَسةِ.
  2. الدَفتَرُ مِن المَطارِ.
  3. الكِتابُ مَعَ الدَفتَرِ.
  4. المَطارُ قُربَ المَدينةِ.
  5. المَطارُ في المَدينةِ.
  6. الشَمسُ فَوقَ الـأَرضِ.
  7. الكِتابُ في الشُقّةِ.
  8. العِمارةُ في المَدينةِ.
  9. الكُرسيُّ عَلى الـأَرضِ.
  10. الكِتابُ عَلى الطاوِلةِ.
  11. الطاوِلةُ تَحتَ الكِتابِ.
  12. المُعَلِّمُ في المَطارِ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/relations&action=edit&section=T-3)]

1\. The book is from the school.  
2\. The notebook is from the airport.  
3\. The book is with the notebok.  
4\. The airport is near the city.  
5\. The airport is in the city.  
6\. The sun is above the earth.  
7\. The book is in the apartment.  
8\. The apartment building is in the city.  
9\. The chair is on the ground.  
10\. The book is on the table.  
11\. The table is under the book.  
12\. The teacher is in the airport.  


  


# Translation Exercises[[edit](/w/index.php?title=Arabic/Pointing_and_describing&action=edit&section=T-1)]

# Exercise 1[[edit](/w/index.php?title=Arabic/Pointing_and_describing&action=edit&section=T-2)]
    
    
    this/that ذاكَ\تاكَ
    big كَبيرُ
    pretty/beautiful جَميلُ
    ugly قَبيحُ
    good جَيِّدُ
    cheap رَخيصُ
    expensive/dear غالِ
    this هَذا\هَذِهِ
    that ذَلِكَ\تِلكَ
    

  1. ذاكَ كَبيرُ.
  2. تاكَ جَميلُ.
  3. هَذا قَبيحُ.
  4. ذَلِكَ جَيِّدُ.
  5. تِلكَ قَبيحةُ.
  6. تِلكَ جَيِّدةُ.
  7. تاكَ جَميلةُ.
  8. هَذا رَخيصُ.
  9. ذَلِكَ غالِ.
  10. تِلكَ رَخيصةُ.
  11. هَذا كَبيرُ.
  12. تِلكَ غالِيةُ.

ا

  


# Key[[edit](/w/index.php?title=Arabic/Pointing_and_describing&action=edit&section=T-3)]

2\. That is pretty.  
4\. That is good.  
6\. That is good.  
8\. This is cheap.  
10\. That is cheap.  
12\. That is expensive.  


# Translation Exercises[[edit](/w/index.php?title=Arabic/pronouns1&action=edit&section=T-1)]

# Exercise 1[[edit](/w/index.php?title=Arabic/pronouns1&action=edit&section=T-2)]

  

    
    
    we نَحنُ
    I أَناْ
    here هُنا
    available مَوجودُ
    in في
    airport مَطارُ
    he هُوَ
    restaurant مَطعَمُ
    on عَلى
    ground أَرضُ
    beautiful جَميلُ
    you (to a male) أَنتَ
    you (to a female) أَنتِ
    school مَدرَسةُ
    there هُنالِكَ
    ugly قَبيحُ
    marketplace سوقُ
    

  1. نَحنُ هُنا.
  2. أَنا مَوجودُ.
  3. أَنا في المَطارِ.
  4. هُوَ في المَطعَمِ.
  5. نَحنُ عَلى الـأَرضِ.
  6. هِيَ جَميلةُ.
  7. أَنتَ في المَطارِ.
  8. أَنتَ في المَدرَسةِ.
  9. أَنا هُنا.
  10. أَنتَ هُنالِكَ.
  11. هُوَ قَبيحُ.
  12. أَنتَ في السوقِ.

ا  


  


  


# Key[[edit](/w/index.php?title=Arabic/pronouns1&action=edit&section=T-3)]

1\. We are Here.  
2\. I am available.  
3\. I Am in the Airport.  
4\. He is in the restaurant.  
6\. She is pretty.  
8\. You are in school/ the school.  
10\. You are there.  
11\. He is ugly.  
12\. You are in the market/mall.  


  
13.Father 14.Mother 15.son

# Translation Exercises[[edit](/w/index.php?title=Arabic/possessivePronouns&action=edit&section=T-1)]

# Exercise 1[[edit](/w/index.php?title=Arabic/possessivePronouns&action=edit&section=T-2)]
    
    
    book ُُكِتابُ
    my ـي
    new جَديدُ
    car سَيّارةُ
    cheap رَخيصُ
    far بَعيدُ
    restaurant مَطعَمُ
    his ُـه
    computer حاسوبُ
    expensive غالِ
    your ـكَ
    your (to a female) ـكِ
    bad سَيِّءُ
    here هُنا
    hospital مُستَشفى
    close قَريبُ
    small صَغيرُ
    

  1. كِتابِي جَديدُ.
  2. سَيّارَتِي رَخيصةُ.
  3. مَطعَمُه بَعيدُ.
  4. سَيّارَتُكَ بَعيدةُ.
  5. حاسوبُه غالِ.
  6. مَدرَسَتُه جَيِّدةُ.
  7. مُعَلِّمُكَ سَيِّءُ.
  8. مَدرَسَتُنَا هُنا.
  9. المُستَشفى قَريبةُ.
  10. مَطعَمُكَ صَغيرُ.
  11. دَفتَرُكَ صَغيرُ.
  12. مَطعَمُه رَخيصُ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/possessivePronouns&action=edit&section=T-3)]

1\. My book is new.  
2\. My car is cheap.  
4\. Your car is far.  
6\. Your school is good.  
8\. Our school is here.  
10\. Your restaurant is small.  
12\. His restaurant is cheap.  


  


# Exercise 1[[edit](/w/index.php?title=Arabic/possessionRelationship&action=edit&section=T-1)]
    
    
    at(used to mean "to have") عِندَ
    book كِتابُ
    negation ما
    I have عِندي
    you have عِندَكَ
    you have (to a female) عِندَكِ
    he has عِندَهُ
    we have عِندَنا
    car سَيّارةُ
    restaurant مَطعَمُ
    house بَيتُ
    pen قَلَمُ
    school مَدرَسةُ
    computer حاسوبُ
    eraser مَحّايةُ
    house بَيتُ
    
    

  1. عِندَكَ كِتابُ.
  2. ماعِندِي كِتابُ.
  3. عِندِي سَيّارةُ.
  4. عِندَه مَطعَمُ.
  5. عِندَنَا بَيتُ.
  6. ماعِندِي قَلَمُ.
  7. عِندَنَا مَدرَسةُ.
  8. عِندِي حاسوبُ.
  9. عِندَكَ كِتابُ.
  10. عِندَكِ كِتابُ.
  11. ماعِندِي مَحّايةُ.
  12. ماعِندَنَا بَيتُ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/possessionRelationship&action=edit&section=T-2)]

2\. I don't have a book.  
4\. He has a restaurant.  
6\. I don't have a pen.  
8\. I have a computer.  
10\. You (female) have a book.  
12\. We don't have a house.  


  


# Exercise 1[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-1)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-2)]

  1. كِتابِي هُناكَ.
  2. رِسالَتُه هُناكَ.
  3. كُرسيُّنَا هُناكَ.
  4. مَدرَستُهم هُناكَ.
  5. مُعَلِّمُنَا هُناكَ.
  6. تِلميذِي هُناكَ.
  7. قَلَمُكَ هُناكَ.
  8. مَحّايَتُنَا هُناكَ.
  9. حاسوبُه هُناكَ.
  10. دَفتَرُكِ هُناكَ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-3)]

1\. My book is there.  
2\. His letter is there.  
3\. Our chair is there.  
4\. Their school is there.  
6\. My student is there.  
8\. Our eraser is there.  
10\. Your notebook is there.  


# Exercise 2[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-4)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-5)]

  1. دَفتَرُكَ هُنالِكَ.
  2. حاسوبُه هُنالِكَ.
  3. مَحّايتُكِ هُناكَ.
  4. تِلميذُهَا هُنالِكَ.
  5. مُعَلِّمِي هُناكَ.
  6. كُرسيُّه هُناكَ.
  7. سَيّارَتِي هُنالِكَ.
  8. بَيتِي هُناكَ.
  9. كُرسيُّهَا هُنا.
  10. حاسوبُنَا هُنا.
  11. تِلميذُه هُنالِكَ.
  12. قَلَمُه هُناكَ.
  13. مَحّايَتُه هُنالِكَ.
  14. مَحّايَتُه غَيرُ مَوجودةِ.
  15. مَطارُنَا هُناكَ.
  16. مَطعَمُه مَوجودُ.
  17. تِلميذُه هُنالِكَ.
  18. مَدرَسَتُهَا هُنا.

  
ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-6)]

2\. His computer is there.  
4\. Her student is there.  
6\. His chair is there.  
8\. My house is there.  
10\. Our computer is here.  
12\. His pen is there.  
14\. His eraser is unavailable.  
16\. His restaurant is available.  
18\. Her school is here.  


  


  


# Exercise 3[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-7)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-8)]

  1. مَدرَسَتُنَا كَبيرةُ.
  2. جامِعتُه قَديمةُ.
  3. شُقَّتُهَا صَغيرةُ.
  4. مَحّايَتُه جَديدةُ.
  5. قَلَمِي رَخيصُ.
  6. مَدرَسَتُه جَديدةُ.
  7. مَطارُنَا كَبيرُ.
  8. حاسوبُه غالِ.
  9. مَطعَمِي غالِ.
  10. جامِعَتُنَا غالِيةُ.
  11. مَحّايَتُه غالِيةُ.
  12. شُقّتِي جَديدةُ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-9)]

2\. His university is old.  
4\. Her school is small.  
6\. His school is new.  
8\. His computer is expensive.  
10\. Our university is expensive.  
12\. My apartment is new.  


  


  


# Exercise 4[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-10)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-11)]

  1. هَذا حاسوبِي.
  2. هَذِهِ مَدرَسَتِي.
  3. هَذا قَلَمُنَا.
  4. هَذا مَطعَمُنَا.
  5. هَذِهِ مَحّايَتُه.
  6. هَذِهِ شُقَّتُه.
  7. هَذا كِتابُه.
  8. هَذا دَفتَرُه.
  9. هَذا تِلميذُنَا.
  10. هَذا مُعَلِّمَتُنَا.
  11. هَذِهِ تِلميذِي.
  12. هَذِهِ مُعَلِّمَتِي.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-12)]

2\. This is my school.  
4\. This is our restaurant.  
6\. This is his apartment.  
8\. This is his notebook.  
10\. This is our (female) teacher.  
12\. This is my (female) teacher.  


  


  


# Exercise 5[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-13)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-14)]

  1. ذَلِكَ تِلميذُه.
  2. تِلكَ تِلميذتُهَا .
  3. ذَلِكَ قَلَمِي.
  4. هَذِهِ مَحّايَتِي.
  5. تِلكَ مُعَلِّمَتُنَا.
  6. ذَلِكَ مُعَلِّمُنَا.
  7. تاكَ مُعَلِّمَتُه.
  8. ذاكَ مَطعَمُه.
  9. تاكَ مَحّايَتُه.
  10. تِلكَ جامِعَتُه.
  11. تاكَ شُقَّتُه.
  12. هَذِهِ تِلميذَتُنَا.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-15)]

2\. That is her (female) student.  
4\. This is my eraser.  
6\. That is my teacher.  
8\. That is his restaurant.  
10\. That is his university.  
12\. This is my (female) student.  


  


  


# Exercise 6[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-16)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-17)]

  1. كِتابِي مِن المَدرَسةِ.
  2. سَيّارَتُه مِن المَدينةِ.
  3. كِتابُه مَعَ الدَفتَرِ.
  4. سَيّارَتِِي قُربَ المَطارِ.
  5. كِتابُهَا في شُقَّتِهَا.
  6. كُرسيُّه عَلى الـأَرضِ.
  7. كِتابُنَا عَلى طاوِلَتِه.
  8. مُعَلِّمُنَا في المَطارِ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-18)]

2\. His car is from the city.  
4\. My car is near the airport.  
6\. His chair is on the ground.  
8\. Our teacher is in the airport.  


  


# Exercise 7[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-19)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-20)]

  1. بَيتُ العائِلةِ كَبيرةُ.
  2. مُستَشفى المَدينةِ نَظيفةُ.
  3. مَطعَمُ المَطارِ في المَطارِ.
  4. مَنزِلُ الرَجُلِ شُقَّتُه.
  5. سَيّارةُ الامرَأةِ قَديمةُ.
  6. بابُ المَنزِلِ مَقفولُ.
  7. بابُ السَيّارةِ مَفتوحُ.
  8. عِندِي مِفتاحُ البَيتِ.
  9. ماعِندَكَ مِفتاحُ السَيّارةِ.
  10. مَطارُ المَدينةِ بَعيدةُ.
  11. تِلميذُ الجامِعةِ هُنالِكَ.
  12. قَلَمُ الامرَأةِ هُنا.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-21)]

2\. The city's hospital is clean.  
4\. The home of the man is his apartment.  
6\. The door of the home is closed.  
8\. I have the keys of the house.  
10\. The airport of the city is far.  
12\. The woman's pen is here.  


  


# Exercise 8[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-22)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-23)]

  1. بابُ بَيتِه مَفتوحُ.
  2. جامِعَةُ مَدينَتِهَا صَغيرةُ.
  3. بَيتُ صَديقِي كَبيرُ.
  4. سَيّارةُ صَديقَتِي جَديدةُ.
  5. عِندِي دَفتَرُ صَديقِي.
  6. عِندِه مِفتاحُ سَيّارَتِي.
  7. مَبنى المَدرَسةِ قَديمةُ.
  8. مَبنى المُستَشفى قَديمةُ.
  9. مَدرَسةُ صَديقِه هُنا.
  10. مَدرَسةُ صَديقِه بَعيدةُ.
  11. مُستَشفى صَديقِنَا هُنا.
  12. بَيتُ عائِلَتِه هُنا.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-24)]

2\. The university of her city is small.  
4\. The school of her friend is new.  
6\. He has the keys to my car.  
8\. The building of the hospital is old.  
10\. The school of his friend is far.  
12\. The house of his family is here.  


  


  


# Exercise 9[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-25)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-26)]

  1. ذَهَبَ إِلى البَيتِ.
  2. أَتى إِلى مَدينَتِنَا.
  3. مَشى إِلى السوقِ.
  4. ذَهَبَت.
  5. مَشَت إلى السوقِ.
  6. جَلَسَ هُنا.
  7. أَتَت إِلى شُقَّتِنَا.
  8. جَلَسَت هُنا.
  9. مَشَت إِلى الجامِعةِ.
  10. ذَهَبَ إلى المُستَشفى.
  11. نامَ في سَريرِه.
  12. نامَت في سَريرِهَا.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-27)]

2\. He came to our city.  
4\. She went.  
6\. He sat here.  
8\. She sat here.  
10\. He went to the hospital.  
12\. She slept in her bed.  


  


  


# Exercise 10[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-28)]

## Vocab[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-29)]

  1. ذَهَبَت إلى مِصرَ.
  2. تَذهَبُ إِلى بِلادِهَا.
  3. مَشَت إِلى السوقِ.
  4. تَنامُ في السَريرِ.
  5. جَلَسَت عَلى الكُرسيِّ.
  6. غادَرَت المَكانَ.
  7. تَجلِسُ عَلى الكُرسيِّ.
  8. أَكَلَت خُبزًا في المَطعَمِ.
  9. تَأكُلُ لَحمًا في البَيتِ.

ا  


  


# Key[[edit](/w/index.php?title=Arabic/Review_Exercises&action=edit&section=T-30)]

2\. She goes to her (home) country/land.  
4\. She sleeps in (the) bed.  
6\. She left the place.  
8\. She ate bread in the restaurant.  


  


## [Arabic](/w/index.php?title=Arabic_language&action=edit&redlink=1) ([Semitic](/w/index.php?title=Semitic_languages&action=edit&redlink=1))[[edit](/w/index.php?title=Arabic/Appendix_A&action=edit&section=T-1)]

_See also: [List of Islamic terms in Arabic](/w/index.php?title=List_of_Islamic_terms_in_Arabic&action=edit&redlink=1)_ **Note that this is relevant only to Modern Standard Arabic** and not to the colloquial forms of Arabic spoken in daily life, which vary from place to place. Also, some of the following expressions were written only to suit a male speaker.

Pronunciation guide: Stress in Arabic is most often on the penultimate syllable (i.e., the one preceding the last).

Translation Phrase IPA Pronunciation

Arabic
العربيّة
/alʕaraˈbijja/
_(al-'arabeeya)_

hello/welcome
مرحبًا
/marˈħaba/
_(mar'Haba)_

سلام
/ sa'lām/
_(sa-laam)_

see you
إلى اللقاء
/ilalliˈqaʔ/
_(ila-lli'qa')_

goodbye
مع السلامة
/maʕa ssaˈlaːma/
_(ma-a ssa'la:ma)_

please
من فضلك / لطفاً
/min ˈfadˁlak/,/ lutfan/
_(min 'fad/lak)_,_(Lutfan)_

thanks
شكرًا
/ˈʃukran/
_('Shukran)_

that one
ذٰلك
/ˈðālika/
_('Daalika)_

How much/How many?
كمْ؟
/kam/
_(kam)_

English
الإنجليزيّة
/alʔinʤliˈzeeya/ _(formal)_,  
/alʔinkliˈzeeya/ _(colloquial)_

yes
نعم
/ˈnaʕam/
_('na-am)_

no
لا
/laː/
_(la:)_

Where's the bathroom?
أين الحمّام؟
/ʔejna-l-ħamˈmaːm/
_(ein-al-Ham'ma:m)_

What is your name?
ما اسمك؟
/ˈma smuk/
_('ma smuk)_

I don’t know
لا أعرف
/laː ˈʔaʕrifu/
_(la: 'a-rifu)_

I have no clue.
لا أدري
/laː ˈʔadri/
_(la: 'adri)_

I don’t understand
لا أفهم
/laː ˈʔafham/
_(la: 'afham)_

I don’t remember
لا أتذكر
/laː ʔataˈðakkar/
_(la: ata'Dakkar)_

Welcome
أهلاً وسهلاً بكم
/ˈahlan waˈsahlan ˈbikum/
_('ahlan wa'sahlan 'bikum)_

I am sick
أنا مريض
/ʔana maˈriːdˁ/
_('ana ma'ri:d/)_

Hello
السلام عليكم
/assaˈlaːm ʕaˈlejkum/
_(assa'la:m aa'laykum)_

Hello (response), how are you?
وعليكم السلام! كيف الحال؟
/waʕaˈlejkumu ssaˈlaːm. kayfa lħaːl/
_(wa-a'lejkumu ssa'la:m. kejfa lHa:l)_

Fine, and you?
بخير، الحمد لله. وكيف أنت؟
/biˈxejrin, alˈħamdu lilˁˈlˁahi. waˈkejfa ʔant/
_(bi'xejrin, al'Hamdu lil/'l/ahi. wa'kejfa ant)_

Bye
ودعا
/wada:ʕan/
_(Wida'an)_

Where is the airport?
أين المطار؟
//
_(Ayna al-maTa:r?)_

Help!
 !النجدة
//
_(Annajda:)_

I am hungry.
أنا جائع
//
_(Ana ju:a:n)_

I feel tired.
أشعر بالتعب
//
_(Ash'ur bitta'b)_
![](//en.wikibooks.org/w/index.php?title=Special:CentralAutoLogin/start&type=1x1)

Retrieved from "[http://en.wikibooks.org/w/index.php?title=Arabic/Print_version&oldid=2553284](http://en.wikibooks.org/w/index.php?title=Arabic/Print_version&oldid=2553284)" 

[Categories](/wiki/Special:Categories): 

  * [Arabic](/wiki/Category:Arabic)
  * [Arabic Printable Versions](/w/index.php?title=Category:Arabic_Printable_Versions&action=edit&redlink=1)

## Navigation menu

### Personal tools

  * [Create account](/w/index.php?title=Special:UserLogin&returnto=Arabic%2FPrint+version&type=signup)
  * [Log in](/w/index.php?title=Special:UserLogin&returnto=Arabic%2FPrint+version)

### Namespaces

  * [Book](/wiki/Arabic/Print_version)
  * [Discussion](/wiki/Talk:Arabic/Print_version)

### 

### Variants

### Views

  * [Read](/w/index.php?title=Arabic/Print_version&stable=1)
  * [Latest draft](/w/index.php?title=Arabic/Print_version&stable=0&redirect=no)
  * [Edit](/w/index.php?title=Arabic/Print_version&action=edit)
  * [View history](/w/index.php?title=Arabic/Print_version&action=history)

### Actions

### Search

![Search](//bits.wikimedia.org/static-1.22wmf19/skins/vector/images/search-ltr.png?303-4)

### Navigation

  * [Main Page](/wiki/Main_Page)
  * [Help](/wiki/Help:Contents)
  * [Browse](/wiki/Wikibooks:Card_Catalog_Office)
  * [Cookbook](/wiki/Cookbook:Table_of_Contents)
  * [Wikijunior](/wiki/Wikijunior)
  * [Featured books](/wiki/Wikibooks:Featured_books)
  * [Recent changes](/wiki/Special:RecentChanges)
  * [Donations](//donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&utm_medium=sidebar&utm_campaign=C13_en.wikibooks.org&uselang=en)
  * [Random book](/wiki/Special:Randomrootpage)

### Community

  * [Reading room](/wiki/Wikibooks:Reading_room)
  * [Community portal](/wiki/Wikibooks:Community_Portal)
  * [Bulletin Board](/wiki/Wikibooks:Reading_room/Bulletin_Board)
  * [Help out!](/wiki/Wikibooks:Maintenance)
  * [Policies and guidelines](/wiki/Wikibooks:Policies_and_guidelines)
  * [Contact us](/wiki/Wikibooks:Contact_us)

### Toolbox

  * [What links here](/wiki/Special:WhatLinksHere/Arabic/Print_version)
  * [Related changes](/wiki/Special:RecentChangesLinked/Arabic/Print_version)
  * [Upload file](//commons.wikimedia.org/wiki/Commons:Upload)
  * [Special pages](/wiki/Special:SpecialPages)
  * [Permanent link](/w/index.php?title=Arabic/Print_version&oldid=2553284)
  * [Page information](/w/index.php?title=Arabic/Print_version&action=info)
  * [Cite this page](/w/index.php?title=Special:Cite&page=Arabic%2FPrint_version&id=2553284)

### In other languages

  * ### Sister projects

  * [Wikipedia](//en.wikipedia.org/wiki/Main_Page)
  * [Wikiversity](//en.wikiversity.org/wiki/Wikiversity:Main_Page)
  * [Wiktionary](//en.wiktionary.org/wiki/Wiktionary:Main_Page)
  * [Wikiquote](//en.wikiquote.org/wiki/Main_Page)
  * [Wikisource](//en.wikisource.org/wiki/Main_Page)
  * [Wikinews](//en.wikinews.org/wiki/Main_Page)
  * [Wikivoyage](//en.wikivoyage.org/wiki/Main_Page)
  * [Commons](//commons.wikimedia.org/wiki/Main_Page)
  * [Wikidata](//www.wikidata.org/wiki/Wikidata:Main_Page)

### Print/export

  * [Create a collection](/w/index.php?title=Special:Book&bookcmd=book_creator&referer=Arabic%2FPrint+version)
  * [Download as PDF](/w/index.php?title=Special:Book&bookcmd=render_article&arttitle=Arabic%2FPrint+version&oldid=2553284&writer=rl)
  * [Printable version](/w/index.php?title=Arabic/Print_version&printable=yes)

  * This page was last modified on 2 September 2013, at 13:53.
  * Text is available under the [Creative Commons Attribution/Share-Alike License](//creativecommons.org/licenses/by-sa/3.0/); additional terms may apply. By using this site, you agree to the [Terms of Use](//wikimediafoundation.org/wiki/Terms_of_Use) and [Privacy Policy.](//wikimediafoundation.org/wiki/Privacy_policy)
  * [Privacy policy](//wikimediafoundation.org/wiki/Privacy_policy)
  * [About Wikibooks](/wiki/Wikibooks:Welcome)
  * [Disclaimers](/wiki/Wikibooks:General_disclaimer)
  * [Developers](https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute)
  * [Mobile view](//en.m.wikibooks.org/wiki/Arabic/Print_version)
  * ![Wikimedia Foundation](//bits.wikimedia.org/images/wikimedia-button.png)
  * ![Powered by MediaWiki](//bits.wikimedia.org/static-1.22wmf19/skins/common/images/poweredby_mediawiki_88x31.png)
