Readme for the Enhanced Cues Corpus of Mentioned Language
Shomir Wilson
2012-01-15

The accompanying file (enhanced_cues.csv) contains the 2,393 sentences of the Enhanced Cues Corpus. Each row represents one sentence containing one candidate instance, delieated by a pair of asterisks ('*').

There are three columns:
(1) Codes for categories of mentioned language.
(2) Unique identifiers for each sentence.
(3) The sentences, with candidate instances delineated by pairs of asterisks.

Additional Notes:
-Stylistic cues were stripped out of the sentences to avoid annotator bias.
-The CSV dialect is Microsoft Word. (Python's CSV module has no difficulty reading it.)
-Often, sentences contain more than one candidate instance. This causes them to appear more than once in the corpus, with the stars positioned differently to highlight different phrases.
-Due to unicode/ASCII issues, some extended characters have been replaced by underscores.
-Stars that originally occurred in the sentences have been replaced by underscores; the human reader verified that this did not affect their readability in any cases (there were very few).