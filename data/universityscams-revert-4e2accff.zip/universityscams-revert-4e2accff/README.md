# University Scams Project Corpus Manual

## Usage Information

Text curation produced by this work is made available under a Creative Commons Attribution-NonCommercial-ShareAlike 2.0 Generic license (CC BY-NC-SA 2.0). If you use the dataset toward a publication, you must cite the paper

[publication TBA]

The above paper is also important reading for understanding the structure and contents of the corpus.

The corpus is provided as-is, without guarantees of reliability or completeness. For questions about the corpus, please contact Prof. Shomir Wilson (shomir@psu.edu).

## Overview

The corpus contains scam emails sent to university email addresses, including email bodies, subject lines, and dates. We scraped them from universities' information security websites on April 2, 2022 using the Python library urllib.request. 

The data was cleaned using Python regex pattern matching, string.encode(), string.decode(), BeautifulSoup, html.unescape, and string.replace(). To ensure fidelity with text on the web, we compared by hand the text obtained from our web scraping program with respective websites.

The corpus download contains two folders: with_bodies, which contains emails we scraped that include bodies (i.e., contents beyond the header; we used these emails for the analysis in the paper), and without_bodies, which contains emails for which bodies were unavailable. Under each directory are subdirectories named after universities that posted the emails on the web.  The contents of these subdirectories are .txt files numbered in ascending order.

Each text file represents one email. Each email contains the attributes: source link, to, from, date, subject, and (when available) body. The formatting for these fields is consistent but designed to support human reading. Browsing a few files should be sufficient to understand the format.

## Version History

0.1b: Pre-publication release.


